#define	ICE	1	/* 98.09.09 */
#include    <String.h>
#include    "Mts.h"
#include    "MtsCorep.h"
#include    "MtsErrop.h"
#include    "MtsMailp.h"


#define	M306	1

/*
#define	MON	1	del by Nishikiori
*/
#define DEBUGMAIL	by M.Nishikiroi
/**/
extern  void  _UserInit(void );

#ifndef WIN32
#pragma asm
	OPT NOMEX,NOABSPCADD,E,CASE,frl
*
#ifdef	M306
    Section M68306_REG
*********************************************************************
*                                                                   *
*   �b�������W�X�^�[�̒�`                                          *
*                                                                   *
*   ���̃Z�N�V�����́����������������O�Ԓn�Ƀ}�b�s���O���邱��      *
*                                                                   *
*********************************************************************
        ds.b    $7e0    * Reserved
*
        xdef    __DUMR1A
        xdef    __DUMR2A
        xdef    __DUSRA
        xdef    __DUCSRA
        xdef    __DUCRA
        xdef    __DURBA
        xdef    __DUTBA
        xdef    __DUIPCR
        xdef    __DUACR
        xdef    __DUISR
        xdef    __DUIMR
        xdef    __CTUR
        xdef    __CTLR
*
        xdef    __DUMR1B
        xdef    __DUMR2B
        xdef    __DUSRB
        xdef    __DUCSRB
        xdef    __DUCRB
        xdef    __DURBB
        xdef    __DUTBB
        xdef    __DUIVR
        xdef    __DUOPCR
        xdef    __DUOPS
        xdef    __DUOPR
        xdef    __PBDT

        xdef    __PORT_A_WRITE
        xdef    __PORT_A_READ
        xdef    __PORT_B_WRITE          *98.9.4
        xdef    __PORT_B_READ           *98.9.4

		xdef	ICR

        ds.b    1
__DUMR1A:
__DUMR2A:
        ds.b    1       * $7e1
        ds.b    1
__DUSRA:
__DUCSRA:
        ds.b    1       * $7e3
        ds.b    1
__DUCRA:
        ds.b    1       * $7e5
        ds.b    1
__DURBA:
__DUTBA:
        ds.b    1       * $7e7
        ds.b    1
__DUIPCR:
__DUACR:
        ds.b    1       * $7e9
        ds.b    1
__DUISR:
__DUIMR:
        ds.b    1       * $7eb
        ds.b    1
__CTUR:  
        ds.b    1       * $7ed
        ds.b    1
__CTLR:  
        ds.b    1       * $7ef
*
        ds.b    1
__DUMR1B:
__DUMR2B:
        ds.b    1       * $7f1
        ds.b    1
__DUSRB:
__DUCSRB:
        ds.b    1       * $7f3
        ds.b    1
__DUCRB:
        ds.b    1       * $7e5
        ds.b    1
__DURBB:
__DUTBB:
        ds.b    1       * $7f7
        ds.b    1
__DUIVR:
        ds.b    1       * $7f9
        ds.b    1
__DUOPCR:
        ds.b    1       * $7fb
        ds.b    1
__DUOPS:
        ds.b    1       * $7fd
        ds.b    1
__DUOPR:
        ds.b    1       * $7ff
*
        ds.b    $7c0    * Reserved
CSCR    ds.l    8       * C0:Chip Select Configuration Register
*
DBCR    ds.l    2       * E0:DRam Bank Configuration Register
        ds.l    2
*
__PORT_A_WRITE:
PADT    ds.b    1       * F0:Port A Data
__PBDT:
__PORT_B_WRITE:
PBDT    ds.b    1       *    Port B Data
PADD    ds.b    1       * F2:Port A Data Direction
PBDD    ds.b    1       *    Port B Data Direction
__PORT_A_READ:
PAPA    ds.b    1       * F4:Port A Pin Assignment
__PORT_B_READ:
PBPA    ds.b    1       *    Port B Pin Assignment
        ds.b    2
ISR     ds.w    1       * F8:Interrupt Status Register
ICR     ds.w    1       *    Interrupt Control Register
RRR     ds.b    1       * FC:DRam Refresh Register
BTP     ds.b    1       *    Bus TimeOut Period
SYS     ds.b    1       * FE:System
TmrVct  ds.b    1       * FF:Timer Vector
*
*********************************************************************
*                                                                   *
*   �������[�}�b�v�̒�`                                            *
*                                                                   *
*********************************************************************
*                                                                   *
	xdef	_DRamBank00
	xdef	_DRamBank01
	xdef	_DulPortRam

_ProgramRom     equ     $00800000       * �v���O�����q����
_DulPortRam     equ     $00a40000       * �f���A���|�[�g�q����
_MpuInterIO     equ     $00700000       * �l�������ӂh�n
_AplInterIO     equ     $00a00000       * �@��ˑ��h�n
_DRamBank00     equ     $00000000       * ���C���������[�O �Q�l�o�C�g
_DRamBank01     equ     $00200000       * ���C���������[�P �Q�l�o�C�g
#else
_DRamBank00     equ     $04030000       * ���C���������[�O �S�l�o�C�g
#endif
*
    Section MtsCode
		xdef	_SystemCheckEnd
		xref	_SystemCheck
		xref	_initdebugger
        xref    __SystemStackEnd

StackAndStart:
#ifdef ROM
    dc.l    __SystemStackEnd,Start
#endif
Start:
    movea.l #__SystemStackEnd,sp
    move.w  #$2700,SR
#ifndef	M306
	move.l  #__InterruptVector,d0           ; vector addr top 
	movec   d0,vbr                          ; set interrupt base reg. 
*	move.l  #$0400c020,d0			; data cahce set 
*	movec   d0,dtt0                 ;
*	move.l	#system_init,d0
*	move.w	#$c020,d0				; E1,S10,CM01
*	movec   d0,itt0                 ;
*	move.l  #$00ffc040,d0			; E1,S10,CM10
*	movec   d0,itt1                 ;
****	move.l  #$00ffc040,d0			; E1,S10,CM10 Sirealize
*	move.l  #$00ffc060,d0			; E1,S10,CM10 Unsirealize
*	movec   d0,dtt1                 ;
#endif
*********************************************************************
*                                                                   *
*   �`�b�v�Z���N�g�Ƃc�q�`�l�ݒ�                                    *
*                                                                   *
*********************************************************************
*
#ifdef	M306
    movea.l #ChipSelectTable,a0
    movea.l #CSCR,a1
MI0:
    move.l  (a0)+,(a1)+
    cmpa.l  #ChipSelectTableEnd,a0
    bcs.s   MI0
*
*    move.w  #$c70f,PADD * Port A and B Data Direction  *98.9.4
    move.w  #$c707,PADD * Port A and B Data Direction   *98.9.4

    move.b  #0,PADT	* Port A Data Clear 1997.4.18

    move.w  #$7f7f,ICR  * FA:Interrupt Control Register
*    move.b  #$3f,RRR    * FC:DRam Refresh Register
    move.b  #$0f,RRR    * FC:DRam Refresh Register 3f->0f 98.06.16
    move.b  #$3f,BTP    * FD:Bus TimeOut Period
    move.b  #$45,SYS    * FE:System
    move.b  #$1f,TmrVct * FF:Timer Vextor
*	movea.l #_DRamBank00,a0
*
RamEnd  equ $00200000
#else
RamEnd  equ $04400000
#endif
*	movea.l #_DRamBank00,a0
*    suba.l  a0,a0
MI1:
*   	clr.l   (a0)+
*    cmpa.l  #RamEnd,a0
*	bne.s   MI1

#ifdef ROM
	jmp		_SystemCheck			; for XE21
#endif
_SystemCheckEnd:					; for XE21

    jsr     _MtsInit

#ifdef	M306
	move.b  #$04,__DUOPCR
	move.b  #$60,__DUACR
#if ICE
	move.b	#$60,__CTUR  *ICE�ł͂Ȃ���delay��3/4�̎��ԂɂȂ�΍�
#else
	move.b	#$48,__CTUR  
#endif
	move.b	#$00,__CTLR  
#endif
    xref    Schedule
    jmp     Schedule
#ifdef	M306
*    
*********************************************************************
*                                                                   *
*   �`�b�v�Z���N�g�ׂ̈̃r�b�g��`                                  *
*                                                                   *
*   �R�P�[�P�V�F�b�r�`  �I�����郁�����[��Ԃ̏�ʃr�b�g��ݒ肷��  *
*         �P�U�F�b�r�v  �������ݏ������\�Ƃ���                    *
*         �P�T�F�b�r�q  �ǂݍ��ݏ������\�Ƃ���                    *
*   �P�S�[  �W�F�b�r�e�b�t�@���N�V�����R�[�h�̑I��                  *
*     �V�[  �S�F�b�r�l  �b�r�`�̗L���r�b�g�����K�肷��              *
*     �R�[  �O�F�b�r�c�s�E�G�C�g�N���b�N����ݒ肷��                *
*                                                                   *
*********************************************************************
*
CSW         equ     $00010000   * �������݋���
CSR         equ     $00008000   * �ǂݍ��݋���
CSFCall     equ     $00007f00   * �e�b���ׂċ���
CSM__16M    equ     $00000080   *   �P�U�l�o�C�g���������m���Ȃ�
CSM___8M    equ     $00000090   *     �W�l�o�C�g���������m���Ȃ�
CSM___4M    equ     $000000a0   *     �S�l�o�C�g���������m���Ȃ�
CSM___2M    equ     $000000b0   *     �Q�l�o�C�g���������m���Ȃ�
CSM___1M    equ     $000000c0   *     �P�l�o�C�g���������m���Ȃ�
CSM_512K    equ     $000000d0   * �T�P�Q�j�o�C�g���������m���Ȃ�
CSM_256K    equ     $000000e0   * �Q�T�U�j�o�C�g���������m���Ȃ�
CSM_128K    equ     $000000f0   * �P�Q�W�j�o�C�g���������m���Ȃ�
*
ChipSelectTable:
    dc.l    _ProgramRom+CSW+CSR+CSFCall+CSM___1M+2
    dc.l    _DulPortRam+CSW+CSR+CSFCall+CSM_512K+15
    dc.l    0
    dc.l    0
    dc.l    0
    dc.l    0
    dc.l    0
    dc.l    0
    dc.l    _DRamBank00+CSW+CSR+CSFCall+CSM___2M+4
    dc.l    _DRamBank01+CSW+CSR+CSFCall+CSM___2M+4
ChipSelectTableEnd:
#endif
*
#pragma endasm
#endif

/********************************************************
*   ���荞�݃x�N�^�[�̏�����                            *
********************************************************/
void    _InitPending( void )
{
    _PendingOup= _PendingInp= _PendingBuf;
}

/********************************************************
*   ���荞�݃x�N�^�[�̏�����                            *
********************************************************/
extern  interrupt   void    _SystemCallHandler( void );
extern  interrupt   void    _SystemLevelCallHandler( void );
extern  interrupt   void    (*_InterruptVector[])(void);
extern  VctFrm  _InterruptVectorTable[];
void    _InitVector( void )
{
    VctFrm* pVct;
#ifndef	MON		/* 98.2.28 */
	initdebugger();
	/*
    _InterruptVector[0x00]= _IntError00;
    _InterruptVector[0x01]= _IntError01;
    _InterruptVector[0x02]= _IntError02;
    _InterruptVector[0x03]= _IntError03;
    _InterruptVector[0x04]= _IntError04;
    _InterruptVector[0x05]= _IntError05;
    _InterruptVector[0x06]= _IntError06;
    _InterruptVector[0x07]= _IntError07;
    _InterruptVector[0x08]= _IntError08;
    _InterruptVector[0x09]= _IntError09;
    _InterruptVector[0x0A]= _IntError0A;
    _InterruptVector[0x0B]= _IntError0B;
    _InterruptVector[0x0C]= _IntError0C;
    _InterruptVector[0x0D]= _IntError0D;
    _InterruptVector[0x0E]= _IntError0E;
    _InterruptVector[0x0F]= _IntError0F;
    _InterruptVector[0x10]= _IntError10;
    _InterruptVector[0x11]= _IntError11;
    _InterruptVector[0x12]= _IntError12;
    _InterruptVector[0x13]= _IntError13;
    _InterruptVector[0x14]= _IntError14;
    _InterruptVector[0x15]= _IntError15;
    _InterruptVector[0x16]= _IntError16;
    _InterruptVector[0x17]= _IntError17;
    _InterruptVector[0x18]= _IntError18;
    _InterruptVector[0x19]= _IntError19;
    _InterruptVector[0x1A]= _IntError1A;
    _InterruptVector[0x1B]= _IntError1B;
    _InterruptVector[0x1C]= _IntError1C;
    _InterruptVector[0x1D]= _IntError1D;
    _InterruptVector[0x1E]= _IntError1E;
    _InterruptVector[0x1F]= _IntError1F;
    _InterruptVector[0x20]= _IntError20;
    _InterruptVector[0x21]= _IntError21;
    _InterruptVector[0x22]= _IntError22;
    _InterruptVector[0x23]= _IntError23;
    _InterruptVector[0x24]= _IntError24;
    _InterruptVector[0x25]= _IntError25;
    _InterruptVector[0x26]= _IntError26;
    _InterruptVector[0x27]= _IntError27;
    _InterruptVector[0x28]= _IntError28;
    _InterruptVector[0x29]= _IntError29;
    _InterruptVector[0x2A]= _IntError2A;
    _InterruptVector[0x2B]= _IntError2B;
    _InterruptVector[0x2C]= _IntError2C;
    _InterruptVector[0x2D]= _IntError2D;
    _InterruptVector[0x2E]= _IntError2E;
    _InterruptVector[0x2F]= _IntError2F;
    _InterruptVector[0x30]= _IntError30;
    _InterruptVector[0x31]= _IntError31;
    _InterruptVector[0x32]= _IntError32;
    _InterruptVector[0x33]= _IntError33;
    _InterruptVector[0x34]= _IntError34;
    _InterruptVector[0x35]= _IntError35;
    _InterruptVector[0x36]= _IntError36;
    _InterruptVector[0x37]= _IntError37;
    _InterruptVector[0x38]= _IntError38;
    _InterruptVector[0x39]= _IntError39;
    _InterruptVector[0x3A]= _IntError3A;
    _InterruptVector[0x3B]= _IntError3B;
    _InterruptVector[0x3C]= _IntError3C;
    _InterruptVector[0x3D]= _IntError3D;
    _InterruptVector[0x3E]= _IntError3E;
    _InterruptVector[0x3F]= _IntError3F;
    _InterruptVector[0x40]= _IntError40;
    _InterruptVector[0x41]= _IntError41;
    _InterruptVector[0x42]= _IntError42;
    _InterruptVector[0x43]= _IntError43;
    _InterruptVector[0x44]= _IntError44;
    _InterruptVector[0x45]= _IntError45;
    _InterruptVector[0x46]= _IntError46;
    _InterruptVector[0x47]= _IntError47;
    _InterruptVector[0x48]= _IntError48;
    _InterruptVector[0x49]= _IntError49;
    _InterruptVector[0x4A]= _IntError4A;
    _InterruptVector[0x4B]= _IntError4B;
    _InterruptVector[0x4C]= _IntError4C;
    _InterruptVector[0x4D]= _IntError4D;
    _InterruptVector[0x4E]= _IntError4E;
    _InterruptVector[0x4F]= _IntError4F;
    _InterruptVector[0x50]= _IntError50;
    _InterruptVector[0x51]= _IntError51;
    _InterruptVector[0x52]= _IntError52;
    _InterruptVector[0x53]= _IntError53;
    _InterruptVector[0x54]= _IntError54;
    _InterruptVector[0x55]= _IntError55;
    _InterruptVector[0x56]= _IntError56;
    _InterruptVector[0x57]= _IntError57;
    _InterruptVector[0x58]= _IntError58;
    _InterruptVector[0x59]= _IntError59;
    _InterruptVector[0x5A]= _IntError5A;
    _InterruptVector[0x5B]= _IntError5B;
    _InterruptVector[0x5C]= _IntError5C;
    _InterruptVector[0x5D]= _IntError5D;
    _InterruptVector[0x5E]= _IntError5E;
    _InterruptVector[0x5F]= _IntError5F;
    _InterruptVector[0x60]= _IntError60;
    _InterruptVector[0x61]= _IntError61;
    _InterruptVector[0x62]= _IntError62;
    _InterruptVector[0x63]= _IntError63;
    _InterruptVector[0x64]= _IntError64;
    _InterruptVector[0x65]= _IntError65;
    _InterruptVector[0x66]= _IntError66;
    _InterruptVector[0x67]= _IntError67;
    _InterruptVector[0x68]= _IntError68;
    _InterruptVector[0x69]= _IntError69;
    _InterruptVector[0x6A]= _IntError6A;
    _InterruptVector[0x6B]= _IntError6B;
    _InterruptVector[0x6C]= _IntError6C;
    _InterruptVector[0x6D]= _IntError6D;
    _InterruptVector[0x6E]= _IntError6E;
    _InterruptVector[0x6F]= _IntError6F;
    _InterruptVector[0x70]= _IntError70;
    _InterruptVector[0x71]= _IntError71;
    _InterruptVector[0x72]= _IntError72;
    _InterruptVector[0x73]= _IntError73;
    _InterruptVector[0x74]= _IntError74;
    _InterruptVector[0x75]= _IntError75;
    _InterruptVector[0x76]= _IntError76;
    _InterruptVector[0x77]= _IntError77;
    _InterruptVector[0x78]= _IntError78;
    _InterruptVector[0x79]= _IntError79;
    _InterruptVector[0x7A]= _IntError7A;
    _InterruptVector[0x7B]= _IntError7B;
    _InterruptVector[0x7C]= _IntError7C;
    _InterruptVector[0x7D]= _IntError7D;
    _InterruptVector[0x7E]= _IntError7E;
    _InterruptVector[0x7F]= _IntError7F;
    _InterruptVector[0x80]= _IntError80;
    _InterruptVector[0x81]= _IntError81;
    _InterruptVector[0x82]= _IntError82;
    _InterruptVector[0x83]= _IntError83;
    _InterruptVector[0x84]= _IntError84;
    _InterruptVector[0x85]= _IntError85;
    _InterruptVector[0x86]= _IntError86;
    _InterruptVector[0x87]= _IntError87;
    _InterruptVector[0x88]= _IntError88;
    _InterruptVector[0x89]= _IntError89;
    _InterruptVector[0x8A]= _IntError8A;
    _InterruptVector[0x8B]= _IntError8B;
    _InterruptVector[0x8C]= _IntError8C;
    _InterruptVector[0x8D]= _IntError8D;
    _InterruptVector[0x8E]= _IntError8E;
    _InterruptVector[0x8F]= _IntError8F;
    _InterruptVector[0x90]= _IntError90;
    _InterruptVector[0x91]= _IntError91;
    _InterruptVector[0x92]= _IntError92;
    _InterruptVector[0x93]= _IntError93;
    _InterruptVector[0x94]= _IntError94;
    _InterruptVector[0x95]= _IntError95;
    _InterruptVector[0x96]= _IntError96;
    _InterruptVector[0x97]= _IntError97;
    _InterruptVector[0x98]= _IntError98;
    _InterruptVector[0x99]= _IntError99;
    _InterruptVector[0x9A]= _IntError9A;
    _InterruptVector[0x9B]= _IntError9B;
    _InterruptVector[0x9C]= _IntError9C;
    _InterruptVector[0x9D]= _IntError9D;
    _InterruptVector[0x9E]= _IntError9E;
    _InterruptVector[0x9F]= _IntError9F;
    _InterruptVector[0xA0]= _IntErrorA0;
    _InterruptVector[0xA1]= _IntErrorA1;
    _InterruptVector[0xA2]= _IntErrorA2;
    _InterruptVector[0xA3]= _IntErrorA3;
    _InterruptVector[0xA4]= _IntErrorA4;
    _InterruptVector[0xA5]= _IntErrorA5;
    _InterruptVector[0xA6]= _IntErrorA6;
    _InterruptVector[0xA7]= _IntErrorA7;
    _InterruptVector[0xA8]= _IntErrorA8;
    _InterruptVector[0xA9]= _IntErrorA9;
    _InterruptVector[0xAA]= _IntErrorAA;
    _InterruptVector[0xAB]= _IntErrorAB;
    _InterruptVector[0xAC]= _IntErrorAC;
    _InterruptVector[0xAD]= _IntErrorAD;
    _InterruptVector[0xAE]= _IntErrorAE;
    _InterruptVector[0xAF]= _IntErrorAF;
    _InterruptVector[0xB0]= _IntErrorB0;
    _InterruptVector[0xB1]= _IntErrorB1;
    _InterruptVector[0xB2]= _IntErrorB2;
    _InterruptVector[0xB3]= _IntErrorB3;
    _InterruptVector[0xB4]= _IntErrorB4;
    _InterruptVector[0xB5]= _IntErrorB5;
    _InterruptVector[0xB6]= _IntErrorB6;
    _InterruptVector[0xB7]= _IntErrorB7;
    _InterruptVector[0xB8]= _IntErrorB8;
    _InterruptVector[0xB9]= _IntErrorB9;
    _InterruptVector[0xBA]= _IntErrorBA;
    _InterruptVector[0xBB]= _IntErrorBB;
    _InterruptVector[0xBC]= _IntErrorBC;
    _InterruptVector[0xBD]= _IntErrorBD;
    _InterruptVector[0xBE]= _IntErrorBE;
    _InterruptVector[0xBF]= _IntErrorBF;
    _InterruptVector[0xC0]= _IntErrorC0;
    _InterruptVector[0xC1]= _IntErrorC1;
    _InterruptVector[0xC2]= _IntErrorC2;
    _InterruptVector[0xC3]= _IntErrorC3;
    _InterruptVector[0xC4]= _IntErrorC4;
    _InterruptVector[0xC5]= _IntErrorC5;
    _InterruptVector[0xC6]= _IntErrorC6;
    _InterruptVector[0xC7]= _IntErrorC7;
    _InterruptVector[0xC8]= _IntErrorC8;
    _InterruptVector[0xC9]= _IntErrorC9;
    _InterruptVector[0xCA]= _IntErrorCA;
    _InterruptVector[0xCB]= _IntErrorCB;
    _InterruptVector[0xCC]= _IntErrorCC;
    _InterruptVector[0xCD]= _IntErrorCD;
    _InterruptVector[0xCE]= _IntErrorCE;
    _InterruptVector[0xCF]= _IntErrorCF;
    _InterruptVector[0xD0]= _IntErrorD0;
    _InterruptVector[0xD1]= _IntErrorD1;
    _InterruptVector[0xD2]= _IntErrorD2;
    _InterruptVector[0xD3]= _IntErrorD3;
    _InterruptVector[0xD4]= _IntErrorD4;
    _InterruptVector[0xD5]= _IntErrorD5;
    _InterruptVector[0xD6]= _IntErrorD6;
    _InterruptVector[0xD7]= _IntErrorD7;
    _InterruptVector[0xD8]= _IntErrorD8;
    _InterruptVector[0xD9]= _IntErrorD9;
    _InterruptVector[0xDA]= _IntErrorDA;
    _InterruptVector[0xDB]= _IntErrorDB;
    _InterruptVector[0xDC]= _IntErrorDC;
    _InterruptVector[0xDD]= _IntErrorDD;
    _InterruptVector[0xDE]= _IntErrorDE;
    _InterruptVector[0xDF]= _IntErrorDF;
    _InterruptVector[0xE0]= _IntErrorE0;
    _InterruptVector[0xE1]= _IntErrorE1;
    _InterruptVector[0xE2]= _IntErrorE2;
    _InterruptVector[0xE3]= _IntErrorE3;
    _InterruptVector[0xE4]= _IntErrorE4;
    _InterruptVector[0xE5]= _IntErrorE5;
    _InterruptVector[0xE6]= _IntErrorE6;
    _InterruptVector[0xE7]= _IntErrorE7;
    _InterruptVector[0xE8]= _IntErrorE8;
    _InterruptVector[0xE9]= _IntErrorE9;
    _InterruptVector[0xEA]= _IntErrorEA;
    _InterruptVector[0xEB]= _IntErrorEB;
    _InterruptVector[0xEC]= _IntErrorEC;
    _InterruptVector[0xED]= _IntErrorED;
    _InterruptVector[0xEE]= _IntErrorEE;
    _InterruptVector[0xEF]= _IntErrorEF;
    _InterruptVector[0xF0]= _IntErrorF0;
    _InterruptVector[0xF1]= _IntErrorF1;
    _InterruptVector[0xF2]= _IntErrorF2;
    _InterruptVector[0xF3]= _IntErrorF3;
    _InterruptVector[0xF4]= _IntErrorF4;
    _InterruptVector[0xF5]= _IntErrorF5;
    _InterruptVector[0xF6]= _IntErrorF6;
    _InterruptVector[0xF7]= _IntErrorF7;
    _InterruptVector[0xF8]= _IntErrorF8;
    _InterruptVector[0xF9]= _IntErrorF9;
    _InterruptVector[0xFA]= _IntErrorFA;
    _InterruptVector[0xFB]= _IntErrorFB;
    _InterruptVector[0xFC]= _IntErrorFC;
    _InterruptVector[0xFD]= _IntErrorFD;
    _InterruptVector[0xFE]= _IntErrorFE;
    _InterruptVector[0xFF]= _IntErrorFF;
	*/
#endif
    for( pVct= _InterruptVectorTable; pVct->VectorNo != 0; pVct++ ) {
        _InterruptVector[pVct->VectorNo]= pVct->pIntFnc;
    }
#ifndef WIN32
    _InterruptVector[SystemCallVector]= _SystemCallHandler;
    _InterruptVector[SystemLevelCallVector]= _SystemLevelCallHandler;
#endif
}

/********************************************************
*   �^�X�N�̏�����                                      *
********************************************************/
unsigned*   _Ssp;
unsigned*   _Usp;
void        (*Entry)( STTFrm* pSTT );
void    SetTcb( STTFrm* pSTT )
{
    TcbFrm* pTcb;
    pTcb= &_Tcb[pSTT->TaskNo];
    pTcb->Priority= pSTT->Priority;
    pTcb->Comment=  'Init';
    pTcb->SPTop=    pSTT->StackArea;
    pTcb->MyTaskNo= pSTT->TaskNo;
    
    Entry=    pSTT->Entry;
    pTcb->PCInt=    Entry;
#ifndef	M306
	pTcb->Frame=	0;
#endif
/*  memset( pTcb->SPTop, 0x55, pSTT->StackSize );*/
    memset( pTcb->SPTop, 0x00, pSTT->StackSize );
    _Usp= (unsigned*)(pSTT->StackArea + pSTT->StackSize);
#ifdef  WIN32
    _asm    {
        mov     _Ssp,esp
        mov     esp,_Usp
        push    pSTT
        push    _SysErrorReturn
        push    Entry
        pushad
        mov     _Usp,esp
        mov     esp,_Ssp
    }
#else
/*
    *((STTFrm**)(--_Usp))= pSTT;
    *((void(**)(void))(--_Usp))= _SysErrorReturn;
*/
    *((STTFrm**)(--_Usp))= 0;
    *((void(**)(void))(--_Usp))= 0;
#endif
    pTcb->AdrsReg[7]= (unsigned char*)_Usp;
    _LinkReadyQue( pTcb );   /*  �q�c�p�Ɍq��    */
}

void    SysReceiveTask( STTFrm* pSTT );
void    SysSendTask( STTFrm* pSTT );
void    C104RecieveDrv( STTFrm* pSTT );
void    ElseC104SndRcv( STTFrm* pSTT );
unsigned char   SysReceiveStack [ 4096];
unsigned char   SysSendStack [ 4096];
unsigned char   C104RecieveDrvStack [ 4096];
unsigned char   ElseC104SndRcvStack [ 4096];
STTFrm  _StaticTaskTableSys[]= {
{ "SysReceiveTask", T_SysReceive ,   0x66, 0, 0, SysReceiveTask,  {0,0,0}, SysReceiveStack,    sizeof SysReceiveStack        },
{ "sysSend   Task", T_SysSend    ,   0x66, 0, 0, SysSendTask,     {0,0,0}, SysSendStack,       sizeof SysSendStack           },
{ "C104 Drv  Task", T_C104DRV    ,   0x66, 0, 0, C104RecieveDrv,  {0,0,0}, C104RecieveDrvStack,sizeof C104RecieveDrvStack    },
{ "Else Drv  Task", T_ElsSendRecv,   0x66, 0, 0, ElseC104SndRcv,  {0,0,0}, ElseC104SndRcvStack,sizeof ElseC104SndRcvStack    },
{ 0, }
};

void    _InitTcb( void )
{
    STTFrm* pSTT;
    
    memset( _Tcb, 0, sizeof _Tcb );
    for( pSTT= _StaticTaskTableUsr; pSTT->Entry != 0; pSTT++ ) {
        SetTcb( pSTT );
    }
    for( pSTT= _StaticTaskTableSys; pSTT->Entry != 0; pSTT++ ) {
        SetTcb( pSTT );
    }
}

/*********************************************************
*   �l�a�w�̏�����                  *
*********************************************************/
void    _InitMbx( void )
{
    int     i;
    MbxFrm* pMbx;
    
    memset( _Mbx, 0, sizeof _Mbx );
    for( i= 0; i < TBQ(_Mbx); i++ ) {
        pMbx= &_Mbx[i];
        pMbx->MyMbxNo= i;
        pMbx->OwnerTaskNo= _S_NoOwner;
        pMbx->pTail= (TcbFrm*)pMbx;
    }
    for( i= 0x80; i < 0xf0; i++ ) {
        _FreeMbx( &i );
    }
}

void    _InitMail( void )
{
    int         i;
    SMTFrm*     pSMT;
    MHedFrm*    pMHed;
    MbxFrm*     pMbx;
    char*       pMail;
    pMHed= (MHedFrm*)_MailArea;
    pMbx=  _MbxMemory;
    for( pSMT= _SMT; pSMT->Size > 0; pSMT++ ) {
        for( i= 0; i < pSMT->Count; i++ ) {
            memset( pMHed, 0, sizeof( MHedFrm ) );
            pMHed->DataType=  _S_Domestic;  /* 4:0:�W�U�n�C1:�U�W�n*/
            pMHed->RespMbx=   _S_Domestic;    /*  5:�ԐM�l�����ԍ�    */
            pMHed->Priority=  _S_Unschedule;   /*  6:���[���̗D�揇��  */
            pMHed->OwnerTask= _S_NoOwner;  /*  7:�z�[���l�����m��  */
            pMHed->HomeMbx=   pMbx->MyMbxNo;    /*  8:�z�[���l�����m��  */
            pMHed->Size=      pSMT->Size;
            pMHed->XHomeMbx = 0;	/* ����CPU�̃z�[�����[���{�b�N�X�p 98.7.23 */
            pMail= (char*)(pMHed+1);
            _MailAreaLast=  pMail + pSMT->Size;
            _FreeMail( (int*)&pMail );
            pMHed= (MHedFrm*)_MailAreaLast;
        }
        pMbx++;
    }
}

/********************************************************
*   �Z�}�t�@�[�̏�����              *
********************************************************/
void    _InitSemaphore( void )
{
    int     i;

    memset( _Smp, 0, sizeof _Smp );
    for( i= 0; i < TBQ(_Smp); i++ ) {
        _Smp[i].MySmpNo= i;
    }
}

/*********************************************************
*   initiation of signal                *
*********************************************************/
void    _InitSignal( void )
{
    int     i;

    memset( _Sig, 0, sizeof _Sig );
    for( i= 0; i < TBQ( _Sig ); i++ ) {
        _Sig[i].MySigNo= i;
    }
}

#ifdef DEBUGMAIL
	extern TaskMail[];
#endif

void    MtsInit( void )
{
#ifdef	M306
extern	void    _UserInit(void);
#endif
    _RunTaskNo= _S_NoOwner;
    _ReadyQue= NULL;
    _SaveReadyQue= NULL;
    _TimerQue= NULL;
    _TimeMSec= 0;
    _InitVector();
    _InitPending();
#ifdef  WIN32
    _SCBInx= _SCBCount= 0;
#endif
#ifdef	M306
	_UserInit();
#endif
    _InitTcb();
    _InitMbx();
    _InitMail();         /*  ���[���̏�����      */
    _InitSemaphore();    /*  �Z�}�t�@�[�̏�����  */
    _InitSignal();       /*  �V�O�i���̏�����    */
#ifdef DEBUGMAIL
	memset((char *)TaskMail,0,256);
#endif
}
