//--------------------------------------------------------------
//			Graphics Library
//
//	1. Supported Device : Nanya 161
//
//
//--------------------------------------------------------------
//#define	ON			1
//#define OFF			0

//#define BLACK			0x00
//#define RED			0xe0
//#define GREEN			0x1c
//#define BLUE			0x07
//#define WHITE			0xff


#define BaseLcd_Buffer	FRAMEBUFFER_BASE
#define BaseLcd_Buffer2	FRAMEBUFFER_BASE2
#define Frame_Buffer_Size	GAMEN_X_SIZE*GAMEN_Y_SIZE/2
#define Frame_Buffer1		BaseLcd_Buffer+Frame_Buffer_Size*1

void Lcd_On(int on);
void Lcd_Init(void);
void Lcd_PutPixel(unsigned int x, unsigned int y, int color);
void Lcd_Clrscr(void);
void Lcd_Hline(int y, int x1, int x2, int color);
void Lcd_Vline(int x, int y1, int y2, int color);
void Lcd_Rectangular(int x1, int y1, int x2, int y2, int color);
void Lcd_Bar(int x1, int y1, int x2, int y2, int color);

void Lcd_Putsxyh(int x, int y, int color, char *str, int zx, int zy);
void Lcd_Printf(int x, int y, int color, int zx, int zy, char *fmt,...);

void Lcd_DrawBMP(int x, int y, const unsigned char *fp);
