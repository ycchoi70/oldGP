/*************************************************
    FUNC  : Display Program
    Create: 2002.4.28	M.Owash
**************************************************/
//#include	"cpu7014.h"
#include	"string.h"
#define	DISP_PROC
#include	"disp.h"
#include	"graphics.h"

#include    "Mts.h"
#include    "MtsCifp.h"
#include    "Mail.h"
#include	"Taskhed.h"


/************************************************/
/*	Font Load For Simulater						*/
/************************************************/
void	FontSet(void)
{
	memset(LcdBuff, 0, sizeof(LcdBuff));
	memset(wWidth, 0, sizeof(wWidth));		/* Window Initialize */
	memset(WindowInfo,0,sizeof(WindowInfo));
}
/****************************************************/
/*	Semafo for Disp									*/
/****************************************************/
void	InitSendSema( void )
{
	Iop( SMF_SEND, 1 );
}
void	SetSendSema( void )
{
	Pop( SMF_SEND );
}
void	ResetSendSema( void )
{
	Vop( SMF_SEND );
}
void	InitWinSema( void )
{
	Iop( SMF_WIN, 1 );
}
void	SetWinSema( void )
{
	Pop( SMF_WIN );
}
void	ResetWinSema( void )
{
	Vop( SMF_WIN );
}
void	InitDispSema( void )
{
	Iop( SMF_DISP, 1 );
//	LcdBkFlag= 0;
}
void	SetDispSema( void )
{
	Pop( SMF_DISP );
}
void	ResetDispSema( void )
{
	Vop( SMF_DISP );
}
void	InitUsbHostSema( void )
{
	Iop( SMF_USBHOST, 1 );
//	LcdBkFlag= 0;
}
void	SetUsbHostSema( void )
{
	Pop( SMF_USBHOST );
}
void	ResetUsbHostSema( void )
{
	Vop( SMF_USBHOST );
}
//2011.08.08(For Log File)
void	InitLogFileSema( void )
{
	Iop( SMF_LOG, 1 );
//	LcdBkFlag= 0;
}
void	SetLogFileSema( void )
{
	Pop( SMF_LOG );
}
void	ResetLogFileSema( void )
{
	Vop( SMF_LOG );
}
////////////////////////////////////////////////////////////
int	CheckHan(int idx)
{
	if((idx >= 0x10) && (idx <= 0x19)){
		return(1);
	}else if((idx >= 0x20) && (idx <= 0x26)){
		return(1);
	}else if(idx == 0x0e){
		return(1);
	}
	return(0);
}

COLOR_DT	ChgColorData(int idx)
{
#ifdef	OLD
	COLOR_DT color;
	COLOR_DT color1;

	memcpy(&color1,&idx,4);
	color.b= color1.r;
	color.g= color1.g;
	color.r= color1.b;
	return(color);
#else
	return((idx & 0xff00ff00) | ((idx & 0x00ff0000) >> 16) | ((idx & 0x000000ff) << 16));
#endif
}

/****************************************************/
/*	Draw Line										*/
/****************************************************/
void    XInc( void )
{
    pGraphicMemory++;
}
void    XDec( void )
{
    pGraphicMemory--;
}
void    YInc( void )
{
	pGraphicMemory += GAMEN_X_SIZE;
}
void    YDec( void )
{
	pGraphicMemory -= GAMEN_X_SIZE;
}
#ifdef	XXXX
void * malloc(size_t p)
{
	return(TakeMemory(p));
}
void   free(void * p)
{
	FreeMail((char*)p);
}
#endif

void	__MoveTo( int sx, int sy, int Pattern, int Mode, COLOR_DT Color )
{
	int	WinNo;

	WinNo= TaskWindowNo[_RunTaskNo];
    LastPos.x= (short)sx;
    LastPos.y= (short)sy;
	if( LastPos.x <    0 ){	LastPos.x= 0;	}
	if( LastPos.x >= GAMEN_X_SIZE ){	LastPos.x= GAMEN_X_SIZE-1;	}
	if( LastPos.y <    0 ){	LastPos.y= 0;	}
	if( LastPos.y >= GAMEN_Y_SIZE ){	LastPos.y= GAMEN_Y_SIZE-1;	}
	DrawPtn= Pattern;

    pGraphicMemory= &LcdBuff[WinNo][LastPos.y][LastPos.x];
	*pGraphicMemory= Color;
}
void    DrawHorizontal( int sx, int ex, int y, COLOR_DT color )
{
	for( ;sx <= ex; sx++ ) {
		if(ColorPat[DrawPtn][LineBit] != 0){
			*pGraphicMemory++ = color;
		}else{
			*pGraphicMemory++;
		}
		LineBit= (LineBit + 1) % 24;
	}
}
void    DrawHorizontalPrn( int sx, int ex, int y, COLOR_DT color )
{
    for( ;sx <= ex;  sx++) {
		if(ColorPat[DrawPtn][LineBit] != 0){
			*pGraphicMemory++ = color;
		}else{
			*pGraphicMemory++;
		}
		LineBit= (LineBit + 1) % 24;
	}
    LastPos.x= (short)sx;
    LastPos.y= (short)y;

}
void    RDrawHorizontal( int sx, int ex, int y, COLOR_DT color )
{
	int	WinNo;

	WinNo= TaskWindowNo[_RunTaskNo];
	pGraphicMemory= &LcdBuff[WinNo][LastPos.y][sx];
	for( ;sx >= ex; sx-- ){
		if(ColorPat[DrawPtn][LineBit] != 0){
			*pGraphicMemory= color;
		}
		pGraphicMemory--;
	    LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
	}
}
void    RDrawHorizontalPrn( int sx, int ex, int y, COLOR_DT color )
{
	for( ;sx >= ex; sx--){
		if(ColorPat[DrawPtn][LineBit] != 0){
			*pGraphicMemory-- = color;
		}else{
			*pGraphicMemory--;
		}
		LineBit= (LineBit + 1) % 24;
	}
    LastPos.x= (short)sx;
    LastPos.y= (short)y;

}
void    DrawVertical( int x, int sy, int ey, COLOR_DT color )
{
    for( ;sy <= ey; sy++ ) {
		if(ColorPat[DrawPtn][LineBit] != 0){
		    *pGraphicMemory= color;
		}
		pGraphicMemory += GAMEN_X_SIZE;
		LineBit= (LineBit + 1) % 24;
     }
}
void    DrawVerticalPrn( int x, int sy, int ey, COLOR_DT color )
{
    for( ;sy <= ey; sy++ ) {
		if(ColorPat[DrawPtn][LineBit] != 0){
		    *pGraphicMemory= color;
		}
		pGraphicMemory += GAMEN_X_SIZE;
        LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
	}
	LastPos.x= (short)x;
	LastPos.y= (short)ey;
}
void    RDrawVertical( int x, int sy, int ey, COLOR_DT color )
{
	int	WinNo;

	WinNo= TaskWindowNo[_RunTaskNo];
	pGraphicMemory= &LcdBuff[WinNo][sy][x];
    for( ;sy >= ey; sy-- ) {
		if(ColorPat[DrawPtn][LineBit] != 0){
			*pGraphicMemory= color;
		}
		pGraphicMemory -= GAMEN_X_SIZE;
        LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
     }
}
void    RDrawVerticalPrn( int x, int sy, int ey, COLOR_DT color )
{
    for( ;sy >= ey; sy-- ) {
		if(ColorPat[DrawPtn][LineBit] != 0){
			*pGraphicMemory= color;
		}
		pGraphicMemory -= GAMEN_X_SIZE;
        LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
     }
	LastPos.x= (short)x;
	LastPos.y= (short)ey;
}

void    DrawFnc( int DMst, int DSlave, void (*pMainMoveFnc)(void), void (*pSlaveMoveFnc)(void ), COLOR_DT color )
{
    int     i;
    int     Dlt;
    int     DMst2;
    int     DSlave2;

    Dlt= 0;
    DSlave2= DSlave + DSlave;
    DMst2= DMst + DMst;
    for( i= 0; i < DMst; i++ ) {
        Dlt -= DSlave2;
        if ( Dlt + DMst < 0 ) {
            (*pSlaveMoveFnc)();
            Dlt += DMst2;
        }
        (*pMainMoveFnc)();
		if(ColorPat[DrawPtn][LineBit] != 0){
		    *pGraphicMemory= color;
		}
		LineBit = (LineBit + 1) % 24;
    }
}

/***************************END******************/
