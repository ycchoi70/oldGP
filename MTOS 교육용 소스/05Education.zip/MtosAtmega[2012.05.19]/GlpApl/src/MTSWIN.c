// Sys.cpp : �A�v���P�[�V�����p�N���X�̒�`���s���܂��B
//
#include    "AfxWin.h"
#include    "Mts.h"
#include    "MtsInitp.h"
#include    "Mtserrop.h"
#include    "Mtstimep.h"
#include    "Mtscifp.h"
#include    "MtsWin.h"
#include    <io.h>
#include    <fcntl.h>

extern  unsigned*   _Usp;
extern  unsigned*   _Ssp;

static  CMtsWin*    pMtsWin;

UINT	ThereadApp(LPVOID lpThreadParameter);
UINT	ThereadSys(LPVOID lpThreadParameter);
int     CallBack( MshFrm* pMsh );
CMtsWin::CMtsWin( int CpuNo, void (*pDrawLcdFnc)(void) )
{
    pMtsWin= this;
    m_pDrawLcdFnc= pDrawLcdFnc;
    m_Live= TRUE;
    m_pMSL= new CMSL( CpuNo, &::CallBack );
	_pipe( m_hCommandSysToApp, 1024, O_BINARY );
	_pipe( m_hCommandAppToSys, 1024, O_BINARY );
	_pipe( m_hPortSysToApp, 256, O_BINARY );
	_pipe( m_hPortAppToSys, 256, O_BINARY );
	AfxBeginThread( &ThereadApp, NULL, THREAD_PRIORITY_ABOVE_NORMAL );
	AfxBeginThread( &ThereadSys, NULL, THREAD_PRIORITY_ABOVE_NORMAL );
}

CMtsWin::~CMtsWin()
{
    delete m_pMSL;
	m_Live= FALSE;
	CommandToSys( "Exit" );
	while( m_LiveSys != 0 ) { Sleep(100); }
	CommandToApp( "Exit" );
	while( m_LiveApp != 0 ) { Sleep(100); }
    _close( m_hCommandSysToApp[0] );
	_close( m_hCommandSysToApp[1] );
	_close( m_hCommandAppToSys[0] );
	_close( m_hCommandAppToSys[1] );
	_close( m_hPortSysToApp[0] );
	_close( m_hPortSysToApp[1] );
	_close( m_hPortAppToSys[0] );
	_close( m_hPortAppToSys[1] );
}

//static  char    LcdBufWin[LcdHeight][LcdWidth/8];
void	CMtsWin::CommandToSys( char* pData )
{
	_write( m_hCommandAppToSys[1], pData, strlen( pData ) + 1 );
}

void	CMtsWin::CommandToApp( char* pData )
{
	_write( m_hCommandSysToApp[1], pData, strlen( pData ) + 1 );
}

int		ReadInt( int Handle )
{
	int				Data;
	_read( Handle, &Data, sizeof Data );
	return Data;
}

void	WriteInt( int Handle, int Data )
{
	_write( Handle, &Data, sizeof Data );
}

void	CMtsWin::IntToApp( int Data ) { WriteInt( m_hCommandSysToApp[1], Data ); }
void	CMtsWin::IntToSys( int Data ) { WriteInt( m_hCommandAppToSys[1], Data ); }
int		CMtsWin::IntFromSys( void ) { return ReadInt( m_hCommandSysToApp[0] ); }
int		CMtsWin::IntFromApp( void ) { return ReadInt( m_hCommandAppToSys[0] ); }
void	CMtsWin::PortToApp( int Data ) { WriteInt( m_hPortSysToApp[1], Data ); }
void	CMtsWin::PortToSys( int Data ) { WriteInt( m_hPortAppToSys[1], Data ); }
int		CMtsWin::PortFromSys( void ) { return ReadInt( m_hPortSysToApp[0] ); }
int		CMtsWin::PortFromApp( void ) { return ReadInt( m_hPortAppToSys[0] ); }

static	char	SizeChar[]= { 'B', 'W', 'D' };
unsigned long	CMtsWin::InputPort( int Size, long Port )
{
	CString	Command;
	Command.Format( "Inp%c", SizeChar[Size] );
	CommandToSys( Command.GetBuffer(256) );
	PortToSys( Port );
	return PortFromSys();
}

void	CMtsWin::OutputPort( int Size, long Port, long Data )
{
	CString	Command;
	Command.Format( "Oup%c", SizeChar[Size] );
	CommandToSys( Command.GetBuffer(256) );
	PortToSys( Port );
	PortToSys( Data );
}

BYTE	CMtsWin::WinBinp( long Port ) { return (BYTE) InputPort( 0, Port ); }
WORD	CMtsWin::WinWinp( long Port ) { return (WORD) InputPort( 1, Port ); }
DWORD	CMtsWin::WinDinp( long Port ) { return (DWORD)InputPort( 2, Port ); }

void	CMtsWin::WinBout( long Port, BYTE  Data ) { OutputPort( 0, Port, Data ); }
void	CMtsWin::WinWout( long Port, WORD  Data ) { OutputPort( 1, Port, Data ); }
void	CMtsWin::WinDout( long Port, DWORD Data ) { OutputPort( 2, Port, Data ); }

void	ReadCommand( int Handle, char* pData )
{
	int	Inx= 0;
	char			Data;
	do {
		_read( Handle, &Data, sizeof Data );
		pData[Inx++]= Data;
	} while( Data != 0 );
}

extern  interrupt void  (*_InterruptVector[256])();


void    _Schedule( void )
{
	pMtsWin->CommandToSys( "RunTaskNo" );
    if ( _ReadyQue == 0 ) {
        _RunTaskNo= 0xff;
		pMtsWin->IntToSys( _RunTaskNo );
    }
    else {
        _RunTaskNo= _ReadyQue - _Tcb;
		pMtsWin->IntToSys( _RunTaskNo );
		pMtsWin->CommandToSys( GetpSTT( _RunTaskNo )->Name );
        _asm    {
            pushad
            push    offset _SysRet
            mov _Ssp,esp
            mov ebx,_ReadyQue
            mov esp,124[ebx]
            popad
            ret
    _SysRet:
            popad
        }
    }
}

void    CMtsWin::App( void )
{
    m_LiveApp= 1;
    MtsInit();
    for(;;){
		_Schedule();
		char	Command[64];
		ReadCommand( m_hCommandSysToApp[0], Command );
		if ( strcmp( Command, "Exit" ) == 0 ) { break; }
		else if ( strcmp( Command, "Interrupt" ) == 0 ) {
			(*_InterruptVector[IntFromSys()])(); }
		else if ( strcmp( Command, "SysClock" ) == 0 ) {
			_SystemClockInterruptHandler(); }
		else if ( strcmp( Command, "ReceiveData" ) == 0 ) {
			IAddFlag( T_SysReceive, 1 );
		}
	}
	m_LiveApp= 0;
}

UINT	ThereadApp(LPVOID lpThreadParameter)
{
	pMtsWin->App();
	return 0;
}

void    CMtsWin::System( void )
{
    m_LiveSys= 1;
	for(;;) {
		char	Command[64];
		ReadCommand( m_hCommandAppToSys[0], Command );
		if ( strcmp( Command, "Exit" ) == 0 ) { break; }
		else if ( strcmp( Command, "DrawLcd" ) == 0 ) {
			(*m_pDrawLcdFnc)();
		}
		else if ( strcmp( Command, "RunTaskNo" ) == 0 ) {
			m_RunTaskNo= IntFromApp();
			if ( m_RunTaskNo == 0xff ) { m_RunTaskName= "�ғ��^�X�N�Ȃ�"; }
			else {
				char	Buf[32];
				ReadCommand( pMtsWin->m_hCommandAppToSys[0], Buf );
				m_RunTaskName= Buf;
			}
		}
		else if ( strcmp( Command, "InpB" ) == 0
			   || strcmp( Command, "InpW" ) == 0
			   || strcmp( Command, "InpD" ) == 0 ) {
			int	Port= PortFromApp();
			PortToApp( 0 );
		}
		else if ( strcmp( Command, "OupB" ) == 0
			   || strcmp( Command, "OupW" ) == 0
			   || strcmp( Command, "OupD" ) == 0 ) {
			int	Port= PortFromApp();
			int	Data= PortFromApp();
		}
	}
	m_LiveSys= 0;
}

UINT	ThereadSys(LPVOID lpThreadParameter)
{
	pMtsWin->System();
	return 0;
}

BOOL    CallBack( MshFrm* pMsh ) { return pMtsWin->CallBack( pMsh ); }
BOOL    CMtsWin::CallBack( MshFrm* pMsh )
{
    if ( strcmp( pMsh->Command, "Exit" ) == 0 ) { return FALSE; }
	if ( strcmp( pMsh->Command, "End" ) == 0 ) { return FALSE; }
	if ( pMsh->ByteCount > 0 ) {
		_write( m_hCommandSysToApp[1], "ReceiveData", 12 );
        int SendByteCount;
        for( int RestByteCount= pMsh->ByteCount; RestByteCount > 0; RestByteCount -= SendByteCount ) {
            unsigned char   Buf[2048];
            int SendByteCount= RestByteCount <= sizeof Buf ? RestByteCount : sizeof Buf;
    		m_pMSL->Read( SendByteCount, Buf );
	    	_write( m_hCommandSysToApp[1], &Buf, SendByteCount );
        }
	}
	return TRUE;
}

void    ReadFromSys( void* pBuf, int Size )
{
    _read( pMtsWin->m_hCommandSysToApp[0], pBuf, Size );
}
