#ifndef __2440X_BD_H__
#define __2440X_BD_H__

#include "macros.h"

#include <hal_time.h>

#define TRUE	(1)
#define FALSE	(0)

#define INT_KEY0        0       //EINT0
#define INT_KEY1        1       //EINT1
#define TOUCH_IRQ       9       //EINT9
#define USB_IRQ         11      //EINT11
#define QSLIDE_CLK_IRQ  19      //EINT19
#define ETH_IRQ			16	    //EINT16

#define KEY_LED         1       //GPB1
#define LCD_BLEN        2       //GPB2
#define LCD_PWREN       3       //GPB3

#define ETC_ON          7       //GPC7

#define PWR_MUTE        7       //GPE7
#define L3CLOCK         8       //GPE8
#define L3DATA          9       //GPE9
#define L3MODE          10      //GPE10
#define QSLIDE_DAT      11      //GPE11
#define QSLIDE_ACK      12      //GPE12
#define AMP_ON          13      //GPE13

#define INT_KEY0_PORT   0       //GPF0
#define INT_KEY1_PORT   1       //GPF1


#define USB_IRQ_PORT    3       //GPG3
#define LCD_RESET       4       //GPG4
#define LCD_CS          5       //GPG5
#define LCD_SDA         6       //GPG6
#define LCD_SCL         7       //GPG7
#define USB_nRST        10      //GPG10

#define TCH_XMON        12      //GPG12
#define TCH_XPON        13      //GPG13
#define TCH_YMON        14      //GPG14
#define TCH_YPON        15      //GPG15


#define DE_RE_485       0       //GPH0


//#define ENET_BASE       0x18000000;     // NCS3
#define ENET_BASE       0x10000000;     // NCS2
#define INT_ETH0        1       //EINT1


//#define FRAMEBUF_BASE			(DMA_BUFFER_BASE + 0x00100000)
//#define FRAMEBUF_DMA_BASE		(0x30000000 + 0x00100000)
//
//
//#define ARM920

//===========================================================================
// Board timer constants.
//
//#define S2410FCLK       	(203 * 1000 * 1000)		// 203MHz (FCLK).
//#define PCLKDIV         	4						// P-clock (PCLK) divisor.
//#define S2410PCLK       	(S2410FCLK / PCLKDIV)	// PCLK.
//#define S2410UCLK       	50331648				// 48MHz - for serial UARTs.

//#define PRESCALER			200
//#define D1_2				0x0
//#define D1_4				0x1
//#define D1_8				0x2
//#define D1_16				0x3
//#define D2					2
//#define D4					4
//#define D8					8
//#define D16					16
//
//#define SYS_TIMER_DIVIDER	D4
//#define OEM_CLOCK_FREQ      (S2410PCLK / PRESCALER / SYS_TIMER_DIVIDER)
//#define OEM_COUNT_1MS       (OEM_CLOCK_FREQ / 1000)				// Timer count for 1ms.
//#define RESCHED_PERIOD      1									// Reschedule period in ms.
//#define RESCHED_INCREMENT   (RESCHED_PERIOD * OEM_COUNT_1MS)	// Number of ticks per reschedule period.
//
//
//// Define LCD type of S3C2400X01
//#define STN8BPP     1
//#define TFT16BPP    2
//
//#define LCDTYPE     TFT16BPP   // define LCD type as upper definition.
//
//
//#define AUDIO_CODEC_CLOCK  384
//#if (S2410FCLK == 112800000)
//#define AUDIO_CODEC_CLOCK  256
//#else
//#define AUDIO_CODEC_CLOCK  384
//#endif



#endif //__2440X_BD_H__


