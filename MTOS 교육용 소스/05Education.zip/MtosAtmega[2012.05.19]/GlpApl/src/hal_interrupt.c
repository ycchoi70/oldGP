/*	$ JBOSN : hal_interrupt.c, v 0.1 10-12-03 15:12 $     */

/*
 * Copyright (C) 2003	iBOSN systems
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are not permitted completely.
 *
 */

/*
 * Module Name: hal_interrupt.c
 *
 * Purpose: HAL basic operation for interrupt handling
 * HAL_InterruptInit
 *
 */

#include <hal_interrupt.h>
#include <s2440.h>
#include <s2440bd.h>




/*
  Name: HAL_InterruptInit
  Copyright: 
  Author: jung byoung oh
  Date: 10-12-03 15:05
  Description: Initialize hardware specific interrupt controller
*/
void HAL_InterruptInit( void )
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG*)INT_BASE; 
    volatile IOP_REG    *pIOPRegs = (volatile IOP_REG*)IOP_BASE; 

    // Mask and clear external interrupts
    pIOPRegs->rEINTMASK = 0xFFFFFFFF;
    pIOPRegs->rEINTPEND = 0xFFFFFFFF;

    // Mask and clear internal interrupts
    pINTRegs->rINTMSK = 0xFFFFFFFF;
    pINTRegs->rSRCPND = 0xFFFFFFFF;

    // interrupt mode
    pINTRegs->rINTMOD = 0;


    // S3C2410X developer notice (page 4) warns against writing a 1 to any
    // 0 bit field in the rINTPND register.  Instead we'll write the rINTPND
    // value itself.
    pINTRegs->rINTPND = pINTRegs->rINTPND;

    return;
}

/*
  Name: HAL_InterruptHandler()
  Copyright: 
  Author: jung byoung oh
  Date: 10-12-03 15:06
  Description: hardware interrupt processing handler
      Return : virtual interrupt number.
*/
unsigned HAL_InterruptHandler( void )
{
    unsigned  nIrq;
    unsigned  iSysIntr=0;

    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
    volatile IOP_REG    *pIOPRegs = (volatile IOP_REG*)IOP_BASE; 

    // // read the interrupt status register
    // IntStat = READ_REGISTER_ULONG(INTC_ISR);
    // //DEBUGMSG(1,"\nHAL_InterruptHandler IntStat = %X\n",IntStat);


    // Get pending interrupt(s)
    nIrq = pINTRegs->rINTOFFSET;

//DEBUGMSG(1,"\nHAL_InterruptHandler nIrq = %d\n",nIrq);

    // System timer interrupt?
    if (nIrq == INTSRC_TIMER4)
    {
        // Clear the interrupt
        pINTRegs->rSRCPND = 1 << INTSRC_TIMER4;
        pINTRegs->rINTPND = 1 << INTSRC_TIMER4;

        iSysIntr = SYSINTR_TICK;
    }
	else
	if(nIrq == INTSRC_DMA1) // AUDIO DMA input.
	{  
//DEBUGMSG(1,"\nHAL_InterruptHandler MIC nIrq = %D\n",nIrq);
		pINTRegs->rINTMSK |= BIT_DMA1;
		pINTRegs->rSRCPND  = BIT_DMA1;
		pINTRegs->rINTPND  = BIT_DMA1;

		return(SYSINTR_WAV);
	}
	else
	if(nIrq == INTSRC_DMA2) // AUDIO DMA output.
	{  
//DEBUGMSG(1,"\nHAL_InterruptHandler AUDIO nIrq = %D\n",nIrq);
		pINTRegs->rINTMSK |= BIT_DMA2;
		pINTRegs->rSRCPND  = BIT_DMA2;
		pINTRegs->rINTPND  = BIT_DMA2;

		return(SYSINTR_WAV);
	}
	else
	if (nIrq == INTSRC_TIMER3)
	{
//DEBUGMSG(1,"\nHAL_InterruptHandler Timer = %D\n",nIrq);
		pINTRegs->rINTMSK |= BIT_TIMER3;
		pINTRegs->rSRCPND  = BIT_TIMER3;	/* Interrupt Clear			*/
		pINTRegs->rINTPND  = BIT_TIMER3;

		iSysIntr = SYSINTR_TCH;
	}	     
	else
	if (nIrq == INTSRC_ADC)
	{
//DEBUGMSG(1,"\nHAL_InterruptHandler ADC = %D\n",nIrq);
		pINTRegs->rINTSUBMSK |= BIT_SUB_TC;
		pINTRegs->rINTMSK    |= (unsigned int)BIT_ADC;
		pINTRegs->rSRCPND     = (unsigned int)BIT_ADC;	/* Interrupt Clear			*/
		pINTRegs->rINTPND     = (unsigned int)BIT_ADC;

		iSysIntr = SYSINTR_TCH;
	}
	else
	if(nIrq == INTSRC_USBD) 
	{
//DEBUGMSG(1,"\nHAL_InterruptHandler INTSRC_USBD = %D\n",nIrq);
//DEBUGMSG(1,"HAL_InterruptHandler pINTRegs->rSRCPND = %x\n",pINTRegs->rSRCPND);
//DEBUGMSG(1,"HAL_InterruptHandler pINTRegs->rINTPND = %x\n",pINTRegs->rINTPND);
//DEBUGMSG(1,"HAL_InterruptHandler  148 = %x\n",*(PBYTE)(0x52000148));
//DEBUGMSG(1,"HAL_InterruptHandler  158 = %x\n",*(PBYTE)(0x52000158));
		pINTRegs->rINTMSK |= BIT_USBD;
		pINTRegs->rSRCPND  = BIT_USBD;
		pINTRegs->rINTPND  = BIT_USBD;
//DEBUGMSG(1,"HAL_InterruptHandler pINTRegs->rSRCPND = %x\n",pINTRegs->rSRCPND);
//DEBUGMSG(1,"HAL_InterruptHandler pINTRegs->rINTPND = %x\n",pINTRegs->rINTPND);
		pIOPRegs->rEINTMASK |= (1<<QSLIDE_CLK_IRQ);		// Mask and clear interrupt at first-level controller.
		pIOPRegs->rEINTPEND  = (1<<QSLIDE_CLK_IRQ);		//


		iSysIntr = SYSINTR_UDC;
	}
	else
	if(nIrq == INTSRC_UART0)	// SERIAL (UART0) (physical COM1: P1 connector).
	{
	    unsigned  SubIntPendVal;
		SubIntPendVal = pINTRegs->rSUBSRCPND;

		// Note that we only mask the sub source interrupt - the serial driver will clear the
		// sub source pending register.
		//
		if(SubIntPendVal & INTSUB_ERR0) 
		{
			pINTRegs->rINTSUBMSK |= INTSUB_ERR0;
		}
		else
		if(SubIntPendVal & INTSUB_RXD0) 
		{
			pINTRegs->rINTSUBMSK |= INTSUB_RXD0;
		}
		else
		if(SubIntPendVal & INTSUB_TXD0) 
		{
			pINTRegs->rINTSUBMSK |= INTSUB_TXD0;
		}
		else
		{
			return 0;
		}
	
		// NOTE: Don't clear INTSRC:UART0 here - serial driver does that.
		//
		pINTRegs->rINTMSK |= BIT_UART0;
		pINTRegs->rSRCPND  = BIT_UART0;	/* Interrupt Clear			*/
		pINTRegs->rINTPND  = BIT_UART0;

		iSysIntr = SYSINTR_COM1;
	}
	else
	if(nIrq == INTSRC_UART1)	// SERIAL (UART01) (physical COM2: P1 connector).
	{  
	    unsigned  SubIntPendVal;
		SubIntPendVal = pINTRegs->rSUBSRCPND;

		// Note that we only mask the sub source interrupt - the serial driver will clear the
		// sub source pending register.
		//
		if(SubIntPendVal & INTSUB_ERR1) 
		{
			pINTRegs->rINTSUBMSK |= INTSUB_ERR1;
		}
		else
		if(SubIntPendVal & INTSUB_RXD1) 
		{
			pINTRegs->rINTSUBMSK |= INTSUB_RXD1;
		}
		else
		if(SubIntPendVal & INTSUB_TXD1) 
		{
			pINTRegs->rINTSUBMSK |= INTSUB_TXD1;
		}
		else
		{
			return 0;
		}
	
		// NOTE: Don't clear INTSRC:UART1 here - serial driver does that.
		//
		pINTRegs->rINTMSK |= BIT_UART1;
		pINTRegs->rSRCPND  = BIT_UART1;	/* Interrupt Clear			*/
		pINTRegs->rINTPND  = BIT_UART1;

		iSysIntr = SYSINTR_COM2;
	}
	else
	if(nIrq == INTSRC_UART2)	// IrDA (UART2)
	{
	    unsigned  SubIntPendVal;
		SubIntPendVal = pINTRegs->rSUBSRCPND;

		if(SubIntPendVal & INTSUB_ERR2) 
		{
			pINTRegs->rINTSUBMSK |= INTSUB_ERR2;
		}       
		else
		if(SubIntPendVal & INTSUB_RXD2) 
		{
			pINTRegs->rINTSUBMSK |= INTSUB_RXD2;
		}       
		else
		if(SubIntPendVal & INTSUB_TXD2) 
		{
			pINTRegs->rINTSUBMSK |= INTSUB_TXD2;
		}       
		else
		{
			return 0;
		}

		// NOTE: Don't clear INTSRC:UART2 here - serial driver does that.
		//
		pINTRegs->rINTMSK |= BIT_UART2;
		pINTRegs->rSRCPND  = BIT_UART2;	/* Interrupt Clear			*/
		pINTRegs->rINTPND  = BIT_UART2;
		
		iSysIntr = SYSINTR_COM3;
	}
	else
	if ((pINTRegs->rINTPND & BIT_EINT0) && nIrq == INTSRC_EINT0)	// touch interrupt is connected to EINT1.
	{ 
        //pINTRegs->rINTMSK |= BIT_EINT0;
        pINTRegs->rSRCPND  = BIT_EINT0;        
        pINTRegs->rINTPND  = BIT_EINT0;

		iSysIntr = SYSINTR_KBD;
    }
    else
	if (nIrq == INTSRC_EINT1)	// ETH.
	{ 
        //pINTRegs->rINTMSK |= BIT_EINT1;
        pINTRegs->rSRCPND  = BIT_EINT1;        
        pINTRegs->rINTPND  = BIT_EINT1;

		iSysIntr = SYSINTR_ETH0;
    }
	else 
    if (nIrq == INTSRC_EINT8_23)		// EINT8 ~ 23
	{ 
		unsigned SubMask = pIOPRegs->rEINTPEND & (~pIOPRegs->rEINTMASK);
//DEBUGMSG(1,"\nHAL_InterruptHandler SubMask = %D\n",SubMask);

		if (SubMask & (1<<TOUCH_IRQ))					// EINT9 : Touch
		{
			pIOPRegs->rEINTMASK |= (1<<TOUCH_IRQ);		// Mask and clear interrupt at first-level controller.
			pIOPRegs->rEINTPEND  = (1<<TOUCH_IRQ);		//

			// Note: we don't mask BIT_EINT8_23 because it's shared.
			//
			pINTRegs->rSRCPND  = BIT_EINT8_23;	// Clear pending interrupt at second-level controller.
			pINTRegs->rINTPND  = BIT_EINT8_23;	//

			return(SYSINTR_TCH);
		}
		else
		if (SubMask & (1<<USB_IRQ))					// EINT11 : USB
		{
			pIOPRegs->rEINTMASK |= (1<<USB_IRQ);		// Mask and clear interrupt at first-level controller.
			pIOPRegs->rEINTPEND  = (1<<USB_IRQ);		//

			// Note: we don't mask BIT_EINT8_23 because it's shared.
			//
			pINTRegs->rSRCPND  = BIT_EINT8_23;	// Clear pending interrupt at second-level controller.
			pINTRegs->rINTPND  = BIT_EINT8_23;	//

            if (pIOPRegs->rGPGDAT & (1<<USB_IRQ_PORT))
                pIOPRegs->rGPGDAT &= ~(1<<USB_nRST);
            else
                pIOPRegs->rGPGDAT |=  (1<<USB_nRST);


			return(SYSINTR_UDC);
		}
        else
		if (SubMask & (1<<QSLIDE_CLK_IRQ))					// EINT19 : MEP
		{
			pIOPRegs->rEINTMASK |= (1<<QSLIDE_CLK_IRQ);		// Mask and clear interrupt at first-level controller.
			pIOPRegs->rEINTPEND  = (1<<QSLIDE_CLK_IRQ);		//

			// Note: we don't mask BIT_EINT8_23 because it's shared.
			//
			pINTRegs->rSRCPND  = BIT_EINT8_23;	// Clear pending interrupt at second-level controller.
			pINTRegs->rINTPND  = BIT_EINT8_23;	//

			return(SYSINTR_KBD);
		}
		else
		{
			pINTRegs->rSRCPND  = BIT_EINT8_23;		// Clear pending interrupt at second-level controller.
			pINTRegs->rINTPND  = BIT_EINT8_23;		//
		}
	}
    else
    {
        //unsigned  Mask;
        //unsigned  nIrq2 = 0;
if(nIrq != 0)
{
pINTRegs->rINTMSK |= (1<<nIrq);
pINTRegs->rSRCPND  = (1<<nIrq);        
pINTRegs->rINTPND  = (1<<nIrq);
}

/*
        if (nIrq == INTSRC_EINT4_7 || nIrq == INTSRC_EINT8_23)
        {
    
            // Find external interrupt number
            Mask = pIOPRegs->rEINTPEND;
            Mask &= ~pIOPRegs->rEINTMASK;
            Mask = (Mask ^ (Mask - 1)) >> 5;
            nIrq2 = INTSRC_EINT4_7;
            while (Mask != 0)
            {
                Mask >>= 1;
                nIrq2++;
            }
    
            // Mask and clear interrupt
            Mask = 1 << (nIrq2 - INTSRC_EINT4_7 + 4);
            pIOPRegs->rEINTMASK |= Mask;
            pIOPRegs->rEINTPEND = Mask;
    
            // calculate mask for primary interrupt
            Mask = 1 << nIrq;
    
            // update nIrq
            nIrq = nIrq2;
        }
        else
        {
            // Mask the interrupt
            Mask = 1 << nIrq;
            pINTRegs->rINTMSK |= Mask;
    
        }

        // clear primary interrupt
        pINTRegs->rSRCPND = Mask;
        pINTRegs->rINTPND = Mask;

        //if (nIrq == INTSRC_XXXX)
        //    iSysIntr = SYSINTR_TCH;
        //else
        //if (nIrq == INTSRC_XXXX)
        //    iSysIntr = SYSINTR_TCH;
        

        // unmask interrupts in case it's NOP or invalid
        if (iSysIntr == 0)
        {
            if (nIrq2 == 0)
            {
                // Unmask the primary interrupt
                pINTRegs->rINTMSK &= Mask;
            }
            else
            {
                // Unmask the external interrupt
                Mask = 1 << (nIrq2 - INTSRC_EINT4_7 + 4);
                pIOPRegs->rEINTMASK &= Mask;
            }
        }
*/    
    }

//
//    if( IntStat == 0)
//        return 0;
//
//    //DEBUGMSG(1,"\nHAL_InterruptHandler IntStat = %X\n",IntStat);
//    //Service the timer interrupt. Note that the interrupt interval is hardwired at 1 mSec. (3686.4)
//    if (IntStat & INT_TIMER0) 
//    {
//        unsigned      TimerStatus;
//        //static int i = 0;
//        //DEBUGMSG(1,"\nHAL_InterruptHandler = %X\n",i++);
//
//        TimerStatus = READ_REGISTER_ULONG(TIMER_TOPSTAT);
//        //WRITE_REGISTER_ULONG(INTC_ISR, INT_TIMER0);
//        iSysIntr = SYSINTR_TICK;
//    }
//    else
//    if(IntStat & INT_ADC) 
//    {
//        EXTERN unsigned      TchInterruptState;
//        unsigned      AdcIsr;
//        //DEBUGMSG(1,"\nHAL_InterruptHandler ADC\n");
//        WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_ADC);
//        AdcIsr = READ_REGISTER_ULONG( ADC_ISR );
//        
//        if( AdcIsr & (ADC_ISR_INTTP | ADC_ISR_INTTD | ADC_ISR_INTTU) )
//        {
//            WRITEAND_REGISTER_ULONG( ADC_TPCR, ~ADC_TPCR_TPEN ); // touch disable
//            TchInterruptState |= 0x01;
//            iSysIntr= SYSINTR_TCH;
//        }
//        else
//        {
//            WRITE_REGISTER_ULONG( ADC_ISR, AdcIsr );
//        }
//
////DEBUGMSG(1,"HAL_InterruptHandler ADC TchInterruptState %X\n",TchInterruptState);
//
//    }
//    else
//    if(IntStat & INT_GPIOB) 
//    {
//        EXTERN unsigned      TchInterruptState;
//        unsigned      GpioBState;
//        //DEBUGMSG(1,"\nHAL_InterruptHandler GPIOB\n");
//        //WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_GPIOB);
//        GpioBState = READ_REGISTER_ULONG( GPIO_BSTAT );
//        
//        if( GpioBState & TCH_TIPDOWN_INT )
//        {
//            //WRITE_REGISTER_ULONG( GPIO_BCLR, TCH_TIPDOWN_INT );
//            WRITE_REGISTER_ULONG( GPIO_BCLR, TCH_TIPDOWN_INT );
//            WRITEAND_REGISTER_ULONG( GPIO_BMASK, ~TCH_TIPDOWN_INT );
//            TchInterruptState |= 0x02;
//            iSysIntr= SYSINTR_TCH;
//        }
//        else
//        {
//            WRITEAND_REGISTER_ULONG( GPIO_BMASK, ~GpioBState );
//            WRITE_REGISTER_ULONG( GPIO_BCLR, GpioBState );
//        }
////DEBUGMSG(1,"HAL_InterruptHandler GPIO TchInterruptState %X\n",TchInterruptState);
//    }
//    else
//    if (IntStat & INT_UART1)
//    {
//        DEBUGMSG(0,"\nHAL_InterruptHandler UART1\n");
//        WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_UART1);
//        iSysIntr = SYSINTR_COM;
//    }
//    else
//    if(IntStat & INT_MMC) 
//    {
//        //DEBUGMSG(1,"\nHAL_InterruptHandler MMC\n");
//        //WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_MMC);
//        WRITE_REGISTER_ULONG(MMC_INTRENREG, 0);
//        iSysIntr= SYSINTR_MMC; 
//    }
//    else
//    if(IntStat & INT_UDC) 
//    {
////        DEBUGMSG(1,"\nHAL_InterruptHandler UDC\n");
//        WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_UDC);
//        iSysIntr= SYSINTR_UDC; 
//    }
//    else
//    if(IntStat & INT_I2S) 
//    {
//        //DEBUGMSG(1,"\nHAL_InterruptHandler I2S\n");
//        //WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_MMC);
//        WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_I2S);
//        iSysIntr= SYSINTR_I2S; 
//    }
//    else
//	if(IntStat & INT_DMA) 
//	{
//	    unsigned  FLAGRVal = READ_REGISTER_ULONG(DMAC_FLAGR);
//        //DEBUGMSG(2,"\nHAL_InterruptHandler WAV %X\n", FLAGRVal);
//	    if( FLAGRVal & (DMAC_FLAGR_FLAG00|DMAC_FLAGR_FLAG01) )
//	    {
//            //DEBUGMSG(1,"\nHAL_InterruptHandler WAV\n");
//            WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_DMA);
//		    iSysIntr = SYSINTR_WAV;
//        }
//        else
//        if( FLAGRVal & DMAC_FLAGR_FLAG1 )
//        {
//        }
//        else
//        if( FLAGRVal & DMAC_FLAGR_FLAG2 )
//        {
//        }
//        else
//        {
//        }        
//	}
//    else
//    if( 0 )
//    {
//        iSysIntr = SYSINTR_DUM;
//    }
    ///DEBUGMSG(1,"HAL_InterruptHandler iSysIntr= %X\n",iSysIntr);
    
    return iSysIntr;
}


/*
  Name: HAL_InterruptEnable()
  Copyright: 
  Author: jung byoung oh
  Date: 10-12-03 15:08
  Description: Enable hardware specific interrupt nubmer
        Input: virtual interrupt number.
*/
void HAL_InterruptEnable( unsigned nInterrupt )
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
    volatile IOP_REG    *pIOPRegs = (volatile IOP_REG*)IOP_BASE; 

#ifdef	WIN32
	return;
#endif
//DEBUGMSG(1,"\nHAL_InterruptEnable = %d\n",nInterrupt);
//	return;
    switch(nInterrupt)
    {
    case SYSINTR_TICK:
    {
        // enable interrupt mask
        pINTRegs->rINTMSK &= ~(1 << INTSRC_TIMER4);
        break;
    }


    case SYSINTR_ETH0:
    {
//        DEBUGMSG(0,"\nHAL_InterruptEnable ETH0\n");
        pINTRegs->rINTMSK &= ~BIT_EINT1;
        pINTRegs->rSRCPND  =  BIT_EINT1;
        pINTRegs->rINTPND  =  BIT_EINT1;

//        pINTRegs->rINTMSK &= ~BIT_EINT0;
//        pINTRegs->rSRCPND  =  BIT_EINT0;
//        pINTRegs->rINTPND  =  BIT_EINT0;
//
//        pINTRegs->rINTMSK &= ~INTSRC_EINT8_23;
//		pIOPRegs->rEINTMASK &= ~(1<<QSLIDE_CLK_IRQ);		// Mask and clear interrupt at first-level controller.
//		pIOPRegs->rEINTPEND  = (1<<QSLIDE_CLK_IRQ);		//
        break;
    }

	case SYSINTR_WAV:		// Audio controller (the controller uses both DMA1 and DMA2 interrupts).
    {
//        DEBUGMSG(1,"\nHAL_InterruptEnable SYSINTR_WAV\n");

		// DMA1 (input).
		//
		pINTRegs->rSRCPND  = BIT_DMA1;
		// S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
		if (pINTRegs->rINTPND & BIT_DMA1)
		    pINTRegs->rINTPND = BIT_DMA1;
		pINTRegs->rINTMSK &= ~BIT_DMA1;

		// DMA2 (output).
		//
		pINTRegs->rSRCPND  = BIT_DMA2;
		// S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
		if (pINTRegs->rINTPND & BIT_DMA2)
		    pINTRegs->rINTPND = BIT_DMA2;
		pINTRegs->rINTMSK &= ~BIT_DMA2;
		break;
    }

    case SYSINTR_TCH:
    {
        //DEBUGMSG(1,"\nHAL_InterruptEnable TCH\n");

		pINTRegs->rSRCPND  = (unsigned int)BIT_ADC;
		if (pINTRegs->rINTPND & (unsigned int)BIT_ADC)
		    pINTRegs->rINTPND = (unsigned int)BIT_ADC;
		pINTRegs->rINTMSK &= ~BIT_ADC;

        // timer
		pINTRegs->rSRCPND  = BIT_TIMER3;
		if (pINTRegs->rINTPND & BIT_TIMER3)
		    pINTRegs->rINTPND = BIT_TIMER3;
		pINTRegs->rINTMSK &= ~BIT_TIMER3;

        pINTRegs->rINTMSK &= ~INTSRC_EINT8_23;
		pIOPRegs->rEINTMASK &= ~(1<<TOUCH_IRQ);		// Mask and clear interrupt at first-level controller.
		pIOPRegs->rEINTPEND  = (1<<TOUCH_IRQ);		//

//        WRITEOR_REGISTER_ULONG( GPIO_BMASK, TCH_TIPDOWN_INT );
//        WRITEOR_REGISTER_ULONG(INTC_IER, INT_ADC);
//        WRITEOR_REGISTER_ULONG(INTC_IER, INT_GPIOB);
        break;
    }
	case SYSINTR_UDC:
	{
		pINTRegs->rSRCPND  = BIT_USBD;
		// S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
		if (pINTRegs->rINTPND & BIT_USBD)
		    pINTRegs->rINTPND = BIT_USBD;
		pINTRegs->rINTMSK &= ~BIT_USBD;
		
		pIOPRegs->rEINTMASK &= ~(1<<USB_IRQ);
		pIOPRegs->rEINTPEND  = (1<<USB_IRQ);		//
		break;
	}

    case SYSINTR_COM1:	// Serial port.
//        DEBUGMSG(1,"\nHAL_InterruptEnable SYSINTR_COM1\n");
        pINTRegs->rSUBSRCPND  = (INTSUB_RXD0 | INTSUB_TXD0 | INTSUB_ERR0);
        pINTRegs->rINTSUBMSK &= ~INTSUB_RXD0;
        pINTRegs->rINTSUBMSK &= ~INTSUB_TXD0;
        pINTRegs->rINTSUBMSK &= ~INTSUB_ERR0;
        pINTRegs->rSRCPND     = BIT_UART0;
        // S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
        if (pINTRegs->rINTPND & BIT_UART0)
            pINTRegs->rINTPND = BIT_UART0;

        pINTRegs->rINTMSK    &= ~BIT_UART0;
        break;
    

    case SYSINTR_COM2:	// Serial port.
//        DEBUGMSG(1,"\nHAL_InterruptEnable SYSINTR_COM2\n");
        pINTRegs->rSUBSRCPND  = (INTSUB_RXD1 | INTSUB_TXD1 | INTSUB_ERR1);
        pINTRegs->rINTSUBMSK &= ~INTSUB_RXD1;
        pINTRegs->rINTSUBMSK &= ~INTSUB_TXD1;
        pINTRegs->rINTSUBMSK &= ~INTSUB_ERR1;
        pINTRegs->rSRCPND     = BIT_UART1;
        // S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
        if (pINTRegs->rINTPND & BIT_UART1)
            pINTRegs->rINTPND = BIT_UART1;

        pINTRegs->rINTMSK    &= ~BIT_UART1;
        break;
    
    case SYSINTR_COM3:		// IrDA.
//        DEBUGMSG(1,"\nHAL_InterruptEnable SYSINTR_COM3\n");
        pINTRegs->rSUBSRCPND  = (INTSUB_RXD2 | INTSUB_TXD2 | INTSUB_ERR2);
        pINTRegs->rINTSUBMSK &= ~INTSUB_RXD2;
        pINTRegs->rINTSUBMSK &= ~INTSUB_TXD2;
        pINTRegs->rINTSUBMSK &= ~INTSUB_ERR2;
        pINTRegs->rSRCPND     = BIT_UART2;
        // S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
        if (pINTRegs->rINTPND & BIT_UART2)
            pINTRegs->rINTPND = BIT_UART2;

        pINTRegs->rINTMSK    &= ~BIT_UART2;
        break;


//    case SYSINTR_MMC:
//        {
//        DEBUGMSG(1,"\nHAL_InterruptEnable MMC\n");
//        WRITEOR_REGISTER_ULONG(INTC_IER, INT_MMC);
//        break;
//	    }
//    case SYSINTR_DUM:
//        {
//        break;
//        }
//    case SYSINTR_COM:
//        {
//        DEBUGMSG(1,"HAL_InterruptEnable COM\n");
//        WRITEOR_REGISTER_ULONG(INTC_IER, INT_UART1);
//        break;
//        }
//        
//    case SYSINTR_UDC:
//        {
////        DEBUGMSG(1,"HAL_InterruptEnable UDC\n");
//        WRITEOR_REGISTER_ULONG(INTC_IER, INT_UDC);
//        break;
//        }
//        
//    case SYSINTR_I2S:
//        {
//        //DEBUGMSG(1,"HAL_InterruptEnable I2S\n");
//        WRITE_REGISTER_ULONG(I2S_DMACR, I2S_DMACR_REQMSK);
//        WRITEOR_REGISTER_ULONG(INTC_IER, INT_I2S);
//        break;
//        }
//
//    case SYSINTR_WAV:
//        {
//		DEBUGMSG(1,"**************OEMInterruptEnable for SYSINTR_WAV\n");
//        WRITE_REGISTER_ULONG(DMAC_FLAGR, 0xFF); //clear the flag
//        WRITEOR_REGISTER_ULONG(INTC_IER, INT_DMA);
//		break;
//	    }

    default :
        {
        break;
        }
    }
    
    return;
}

/*
  Name: HAL_InterruptDisable()
  Copyright: 
  Author: jung byoung oh
  Date: 10-12-03 15:10
  Description: disable the specific interrupt number
        Input: virtual interrupt number
*/
void HAL_InterruptDisable( unsigned nInterrupt )
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
    volatile IOP_REG    *pIOPRegs = (volatile IOP_REG*)IOP_BASE; 

    /* 
    * Initialize hardware specific interrupt nubmer
    */
    
//DEBUGMSG(1,"\nHAL_InterruptDisable = %d\n",nInterrupt);
    switch(nInterrupt)
    {
    case SYSINTR_TICK:
    {
        // disable interrupt mask
        pINTRegs->rINTMSK |= (1<<INTSRC_TIMER4);
        break;
    }

    case SYSINTR_ETH0:
    {
//        DEBUGMSG(0,"\nHAL_InterruptDisable ETH0\n");
        break;
    }

	case SYSINTR_WAV:
	{
//        DEBUGMSG(1,"\nHAL_InterruptDisable SYSINTR_WAV\n");
        pINTRegs->rINTMSK |= BIT_DMA1;	// Audio input DMA.
		pINTRegs->rINTMSK |= BIT_DMA2;	// Audio output DMA.
		break;
    }

    case SYSINTR_TCH:
    {
        //DEBUGMSG(1,"\nHAL_InterruptDisable TCH\n");
		pINTRegs->rINTMSK |= (unsigned int)BIT_ADC;
		pINTRegs->rINTMSK |= BIT_TIMER3;
        break;
    }
	case SYSINTR_UDC:
		pINTRegs->rINTMSK |= BIT_USBD;
		pIOPRegs->rEINTMASK |= (1<<USB_IRQ);

		break;

    case SYSINTR_COM1:
        pINTRegs->rINTMSK    |= BIT_UART0;
        pINTRegs->rINTSUBMSK |= INTSUB_RXD0;
        pINTRegs->rINTSUBMSK |= INTSUB_TXD0;
        pINTRegs->rINTSUBMSK |= INTSUB_ERR0;
        break;
    
    case SYSINTR_COM2:
        pINTRegs->rINTMSK    |= BIT_UART1;
        pINTRegs->rINTSUBMSK |= INTSUB_RXD1;
        pINTRegs->rINTSUBMSK |= INTSUB_TXD1;
        pINTRegs->rINTSUBMSK |= INTSUB_ERR1;
        break;
    
    case SYSINTR_COM3:
        pINTRegs->rINTMSK    |= BIT_UART2;
        pINTRegs->rINTSUBMSK |= INTSUB_RXD2;
        pINTRegs->rINTSUBMSK |= INTSUB_TXD2;
        pINTRegs->rINTSUBMSK |= INTSUB_ERR2;
        break;
    

//    case SYSINTR_MMC:
//        {
//        WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_MMC);
//        break;
//	    }
//    case SYSINTR_DUM:
//        {
//        break;
//        }
//    case SYSINTR_COM:
//        {
//        DEBUGMSG(1,"HAL_InterruptDisable COM\n");
//        WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_UART1);
//        break;
//        }
//    case SYSINTR_UDC:
//        {
////        DEBUGMSG(1,"HAL_InterruptDisable UDC\n");
//        WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_UDC);
//        break;
//        }
//    case SYSINTR_I2S:
//        {
//        //DEBUGMSG(1,"HAL_InterruptDisable I2S\n");
//        WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_I2S);
//        break;
//        }
//    case SYSINTR_WAV:
//        {
//		DEBUGMSG(1,"**************OEMInterruptDisable for SYSINTR_WAV\n");
//        WRITEAND_REGISTER_ULONG(INTC_IER, ~INT_DMA);
//		break;
//	    }
    default :
        {
        break;
        }
    }
    
    return;
}

/*
  Name: HAL_InterruptDone()
  Copyright: 
  Author: jung byoung oh
  Date: 10-12-03 15:11
  Description: do the end of interrupt action
        Input: virtual interrupt number
*/

void HAL_InterruptDone( unsigned nInterrupt )
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
    volatile IOP_REG    *pIOPRegs = (volatile IOP_REG*)IOP_BASE; 

    /* 
    * Initialize hardware specific interrupt nubmer
    */
    switch(nInterrupt)
    {
    case SYSINTR_TICK:
    {
        /// enable interrupt mask
        pINTRegs->rSRCPND  = (1<<INTSRC_TIMER4);
        pINTRegs->rINTMSK &= ~(1<<INTSRC_TIMER4);
        break;
    }

    case SYSINTR_ETH0:
    {
//        DEBUGMSG(0,"\nHAL_InterruptDone ETH0\n");
        break;
    }


	case SYSINTR_WAV:
	{
        //DEBUGMSG(1,"\nHAL_InterruptDone SYSINTR_WAV\n");
		// DMA1 is for audio input.
		// DMA2 is for audio output.
		pINTRegs->rSRCPND = (BIT_DMA1 | BIT_DMA2); 
		if (pINTRegs->rINTPND & BIT_DMA1) pINTRegs->rINTPND = BIT_DMA1;
		if (pINTRegs->rINTPND & BIT_DMA2) pINTRegs->rINTPND = BIT_DMA2;
        pINTRegs->rINTMSK &= ~BIT_DMA1;
        pINTRegs->rINTMSK &= ~BIT_DMA2;
		break;
    }

    case SYSINTR_TCH:
    {
        //DEBUGMSG(1,"\nHAL_InterruptDone TCH\n");
		pINTRegs->rSRCPND = (unsigned int)BIT_ADC;
		if (pINTRegs->rINTPND & (unsigned int)BIT_ADC)
		    pINTRegs->rINTPND = (unsigned int)BIT_ADC;
		pINTRegs->rINTMSK &= ~(unsigned int)BIT_ADC;

		pINTRegs->rSRCPND = BIT_TIMER3;
		if (pINTRegs->rINTPND & BIT_TIMER3)
		    pINTRegs->rINTPND = BIT_TIMER3;
		pINTRegs->rINTMSK &= ~BIT_TIMER3;
        break;
    }
	case SYSINTR_UDC:
//        DEBUGMSG(1,"\nHAL_InterruptDone UDC\n");
//DEBUGMSG(1,"HAL_InterruptDone pINTRegs->rSRCPND = %x\n",pINTRegs->rSRCPND);
//DEBUGMSG(1,"HAL_InterruptDone pINTRegs->rINTPND = %x\n",pINTRegs->rINTPND);
		pINTRegs->rSRCPND = BIT_USBD;
		if (pINTRegs->rINTPND & BIT_USBD)
		    pINTRegs->rINTPND = BIT_USBD;
//DEBUGMSG(1,"HAL_InterruptDone pINTRegs->rSRCPND = %x\n",pINTRegs->rSRCPND);
//DEBUGMSG(1,"HAL_InterruptDone pINTRegs->rINTPND = %x\n",pINTRegs->rINTPND);
		pINTRegs->rINTMSK &= ~BIT_USBD;

		pIOPRegs->rEINTMASK &= ~(1<<USB_IRQ);
		pIOPRegs->rEINTPEND  = (1<<USB_IRQ);		//

		break;
    
    case SYSINTR_COM1:
        pINTRegs->rINTMSK    &= ~BIT_UART0;
        //pINTRegs->rINTSUBMSK &= ~INTSUB_RXD0;
        break;
    
    case SYSINTR_COM2:
        pINTRegs->rINTMSK    &= ~BIT_UART1;
        //pINTRegs->rINTSUBMSK &= ~INTSUB_RXD1;
        break;
    
    case SYSINTR_COM3:
        pINTRegs->rINTMSK    &= ~BIT_UART2;
        //pINTRegs->rINTSUBMSK &= ~INTSUB_RXD2;
        break;


//    case SYSINTR_MMC:
//        {
//        WRITEOR_REGISTER_ULONG(INTC_IER, INT_MMC);
//        break;
//	    }
//    case SYSINTR_DUM:
//        {
//        break;
//        }
//    case SYSINTR_COM:
//        {
//        DEBUGMSG(1,"HAL_InterruptDone COM\n");
//        WRITEOR_REGISTER_ULONG(INTC_IER, INT_UART1);
//        break;
//        }
//    case SYSINTR_UDC:
//        {
////        DEBUGMSG(1,"HAL_InterruptDone UDC\n");
//        WRITEOR_REGISTER_ULONG(INTC_IER, INT_UDC);
//        break;
//        }
//    case SYSINTR_I2S:
//        {
//        //DEBUGMSG(1,"HAL_InterruptDone I2S\n");
//        WRITEOR_REGISTER_ULONG(INTC_IER, INT_I2S);
//        break;
//        }
//    case SYSINTR_WAV:
//        {
//		//DEBUGMSG(1,"**************OEMInterruptDone for SYSINTR_WAV\n");
//        WRITEOR_REGISTER_ULONG(INTC_IER, INT_DMA);
//		break;
//	    }
    default :
        {
        break;
        }
    }

    return;
}

extern	void	HAL_ClockInit( void );

void InitTicTimer(void)
{
	HAL_ClockInit();
	HAL_InterruptEnable(SYSINTR_TICK);
}

