/*	$ JBOSN_OS: hal_time.h, v 0.1 2003/05/15 $	*/

/*
 * Copyright (C) 2002	iBOSN systems
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are not permitted completely.
 *
 */

/*
 * Module Name: hal_time.h
 *
 * Purpose: time function definitions.
 *
 */

#ifndef __JBOSN_HAL_TIME_H_
#define __JBOSN_HAL_TIME_H_


//#define S3C2410X_FCLK           202800000                   // 203MHz
#define S3C2410X_FCLK           203000000                   // 203MHz
#define PCLKDIV                 4						    // P-clock (PCLK) divisor.
//#define PCLKDIV                 32						    // P-clock (PCLK) divisor.
#define S3C2410X_PCLK           (S3C2410X_FCLK/PCLKDIV)     // divisor 4

#define HAL_CLOCK_FREQ          (S3C2410X_PCLK/2)

// Timer count value for 1 ms
#define HAL_TICK_FREQ       (1000)
//#define HAL_TICK_FREQ       (100)		//10ms
//#define HAL_TICK_FREQ       (1)			//1000ms
#define HAL_CLOCK_TICK      (HAL_CLOCK_FREQ / HAL_TICK_FREQ)
#define NO_RESCHED_WINDOW   (HAL_CLOCK_TICK / 10)

#define	TIMER_PERIOD        (1000/HAL_TICK_FREQ)

//EXTERN  VOID HAL_ClockInit( VOID );
//EXTERN  VOID HAL_TimerInterruptHandler( PUINT64 pMsCount );


// Board timer constants.
//
#define S2410UCLK       	50331648				// 48MHz - for serial UARTs.

#define PRESCALER			200
//#define D1_2				0x0
//#define D1_4				0x1
//#define D1_8				0x2
//#define D1_16				0x3
//#define D2					2
#define D4					4
//#define D8					8
//#define D16					16
//
#define SYS_TIMER_DIVIDER	D4
#define OEM_CLOCK_FREQ      (S3C2410X_PCLK / PRESCALER / SYS_TIMER_DIVIDER)
//#define OEM_COUNT_1MS       (OEM_CLOCK_FREQ / 1000)				// Timer count for 1ms.
//#define RESCHED_PERIOD      1									// Reschedule period in ms.
//#define RESCHED_INCREMENT   (RESCHED_PERIOD * OEM_COUNT_1MS)	// Number of ticks per reschedule period.
//


#endif ///__JBOSN_HAL_TIME_H_


