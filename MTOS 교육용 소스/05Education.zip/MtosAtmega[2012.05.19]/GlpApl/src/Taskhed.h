/********************************/
/*	����ԍ���`       			*/
/*  1999.8.10                   */
/********************************/
/*	Driver & Handler			*/

#define	T_INIT		    0x11
#define	T_TASK1	        0x12


/************************************/
/*  �Z�}�t�H                        */
/************************************/
#define SMF_DISP	0
#define SMF_WIN		1
#define SMF_SEND	2
#define SMF_USBHOST	3
#define SMF_LOG		4
