#include    "Mts.h"
#include    "MtsScID.h"
#include    "MtsCorep.h"
#include    "MtsSchdp.h"
#include    "MtsTimep.h"
#include    "s2440.h"

//extern	void	Cmt1IntClear();
//extern	void	InClockProc( void );

/********************************************************
*                                                       *
*       �^�C���E�A�E�g�萔�ݒ�                          *
*                                                       *
*       int     set_timer( int et )                     *
*                                                       *
*       �����F  �^�C���E�A�E�g�萔                      *
*                                                       *
********************************************************/
int     _SetTimeOut( int* pParam )
{
    int     OldTimeOut;
    
    OldTimeOut= _ReadyQue->Timer.TimeOutCounter;
    _ReadyQue->Timer.TimeOutCounter= pParam[0];
    return OldTimeOut;
}

/********************************************************
*                                                       *
*       �莞�ԑ҂�                                      *
*                                                       *
*       void    Delay( int dt )                         *
*                                                       *
*       �����F  �҂�����                                *
*                                                       *
********************************************************/
void    _Delay( int* pParam )
{
    TcbFrm* pTcb;
    
    if ( ( _ReadyQue->Timer.TimeOutCounter= pParam[0] ) > 0 ) {
        pTcb= _LinkOffReadyQue();
        pTcb->WaitQue= (TcbFrm*)0;
    }
}

void    _ISystemClockHandler( int* pParam )
{
    TcbFrm* pTcb;
    while( _TimerQue != 0 && ( _TimerQue->TimeOutCounter -= pParam[1] ) <= 0 ) {
        pParam[1]=  - _TimerQue->TimeOutCounter;
        pTcb= (TcbFrm*)((unsigned char*)_TimerQue - ( (unsigned char*)&pTcb->Timer - (unsigned char*)pTcb ));
	    pTcb->DataReg[0]= R_TimeOut;
        _TimerQue= _TimerQue->pLink;          /* �s��������O��   */
        if ( pTcb->WaitQue != 0 ) { /* �X�ɑ��̃L���[�Ɏ�����Ă���ΊO��   */
            _OffQue( (TcbFrm*)pTcb->WaitQue, pTcb );
            switch( pTcb->Status & 0x7f ) {
            case W_Mail:
            case W_Mbx:
                ((MbxFrm*)pTcb->WaitQue)->MailCount++;
                break;
            case W_Semaphore:
                ((SmpFrm*)pTcb->WaitQue)->SmpCounter++;
                break;
            case W_Flag:
            case W_Signal:
            case W_Timer:
            case W_Ready:
            default:
                break;
            }
        }
        pTcb->Status &= 0x7f;   /* ���ɂs��������O���Ă���̂ŕK�v */
        _LinkReadyQue( pTcb );
    }
}



/****************************************
*       timer interrupt                 *
****************************************/
/********************************************************
*                                                       *
*       ������ŋN��                                    *
*                                                       *
*       �������s�̓V�X�e���E�萔                        *
*               �s�h�l�Q�h�m�b�A                        *
*               �s�h�l�Q�c�h�u�ɂ��ȉ��̗l�ɒ�`����  *
*                                                       *
*       ���s���s�h�l�Q�h�m�b�^�s�h�l�Q�c�h�u            *
*                                                       *
*       ��P�@�U�O�g���̏ꍇ                            *
*               �s�h�l�Q�h�m�b���P�O�O�O�i�P�ʂ��b�j    *
*               �s�h�l�Q�c�h�u���@�@�U�O                *
*               ���邢��                                *
*               �s�h�l�Q�h�m�b���@�@�T�O                *
*               �s�h�l�Q�c�h�u���@�@�@�R                *
*               �Ƃ��Ă�����                            *
*                                                       *
********************************************************/
unsigned    _TimeMSec;
extern  void    WaitUSec( int cnt );
extern	void	RESET_INT(void);
/*extern	void	WDT_Reset(void);*/

int	IntFlag;
int	DebugSW;
unsigned    DebugTimeMSec;
int		IncTimeCnt( void )
{
#ifndef	WIN32
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
    pINTRegs->rSRCPND = 1 << INTSRC_TIMER4;
    pINTRegs->rINTPND = 1 << INTSRC_TIMER4;
#endif
//	InClockProc();
    _TimeMSec += SystemClockInterval;
//	if((_TimeMSec & 1) == 0){
//		*(unsigned char*)0x0e000104= 0xfe;
//	}else{
//		*(unsigned char*)0x0e000104= 0xff;
//	}
	return(0);
}
extern	void	HAL_InterruptDone( unsigned nInterrupt );
void	_SystemClockInterruptHandler( void )
{
	int		Ret;

	Ret= IncTimeCnt();
	if(Ret == 0){
	 _PendingRequest( ID_PSystemClock | SystemClockInterval );
	}
#ifndef	WIN32
//	HAL_InterruptDone(1);
#endif
}

unsigned    ReadTimeMsec( void )
{
    return _TimeMSec;
}

/********************************
*                               *
*       soft wait               *
*                               *
********************************/
void    SWait( void )
{
}

