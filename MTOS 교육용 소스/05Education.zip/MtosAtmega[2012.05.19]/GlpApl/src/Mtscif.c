#include    "Mts.h"
#include    "MtsSCID.h"
#include    "MtsSchdP.h"
#include    "MtsCifp.h"
/****************************************************************
*                                                               *
*       �l�s�r�|���[�U�[�E�v���O�����Ԃ̃C���^�[�t�F�[�X        *
*                                                               *
****************************************************************/
/********************************************************
*                                                       *
*       �V�X�e���E�R�[���̃G���g��[�E�A�h���X          *
*                                                       *
*       ���̃A�h���X�́A�^�X�N�E�v���O�����ƓƗ�����    *
*       �����N���邽�߁A�Œ�ł��鎖���]�܂���          *
*                                                       *
********************************************************/
/**/
extern  int _CallMts( int SystemCallID, int* pParam );
#define DEBUGMAIL
/**/
#ifdef DEBUGMAIL
short	TaskMail[256];

void        SendMail(unsigned MbxNo,char* pMail)
{
	struct{
		unsigned	p1;
		char		*p2;
	}p;
	p.p1 = MbxNo;
	p.p2 = pMail;
	TaskMail[_RunTaskNo]--;
	_CallMts( ID_SendMail, (int*)&p );
}
void        ResponseMail(char* pMail) { TaskMail[_RunTaskNo]--;_CallMts( ID_ResponseMail, (int*)&pMail ); }
void        FreeMail(char* pMail) {  TaskMail[_RunTaskNo]--;_CallMts( ID_FreeMail, (int*)&pMail ); }
char*       ReceiveMail(unsigned MbxNo) {
				char *ret;
				ret = (char*)_CallMts( ID_ReceiveMail, (int*)&MbxNo );
				if( (int)ret )	TaskMail[_RunTaskNo]++;
				return ret;
			}
char*       WaitRequest(void ) {
				char *ret;
				ret = (char*)_CallMts( ID_WaitRequest, (int*)0 );
				if( (int)ret )	TaskMail[_RunTaskNo]++;
				return ret;
			}
char*       TakeMail(void ) {
				char *ret;
				ret = (char*)_CallMts( ID_TakeMail, (int*)0 );
				if( (int)ret )	TaskMail[_RunTaskNo]++;
				return ret;
			}
char*       TakeMemory(unsigned Size) {
				char *ret;
				ret = (char*)_CallMts( ID_TakeMemory, (int*)&Size );
				if( (int)ret )	TaskMail[_RunTaskNo]++;
				return ret;
			}
char*       AcceptMail(unsigned MbxNo) {
				char *ret;
				ret = (char*)_CallMts( ID_AcceptMail, (int*)&MbxNo );
				if( (int)ret )	TaskMail[_RunTaskNo]++;
				return ret;
			}
#else
void	SendMail(unsigned MbxNo,char* pMail) {
		struct{
			unsigned p1;
			char	*p2;
		}p;
		p.p1 = MbxNo;
		p.p2 = pMail;
		_CallMts( ID_SendMail, (int*)&p );
 }
void        ResponseMail(char* pMail) { _CallMts( ID_ResponseMail, (int*)&pMail ); }
void        FreeMail(char* pMail) { _CallMts( ID_FreeMail, (int*)&pMail ); }
char*       ReceiveMail(unsigned MbxNo) { return (char*)_CallMts( ID_ReceiveMail, (int*)&MbxNo ); }
char*       WaitRequest(void ) { return (char*)_CallMts( ID_WaitRequest, (int*)0 ); }
char*       TakeMail(void ) { return (char*)_CallMts( ID_TakeMail, (int*)0 ); }
char*       TakeMemory(unsigned Size) { return (char*)_CallMts( ID_TakeMemory, (int*)&Size ); }
char*       AcceptMail(unsigned MbxNo) { return (char*)_CallMts( ID_AcceptMail, (int*)&MbxNo ); }
#endif
int         TakeMbx(void ) { return _CallMts( ID_TakeMbx, (int*)0 ); }
void        FreeMbx(int MbxNo) { _CallMts( ID_FreeMbx, (int*)&MbxNo ); }
int         GetMbxStatus(unsigned MbxNo) { return _CallMts( ID_GetMbxStatus, (int*)&MbxNo ); }
void        AddFlag(int TaskNo,int AddCount)
{
	struct{
		int	p1;
		int	p2;
	}p;
	p.p1 = TaskNo;
	p.p2 = AddCount;
	_CallMts( ID_AddFlag, (int*)&p );
}
int         WaitFlag(int WaitCount) { return _CallMts( ID_WaitFlag, (int*)&WaitCount ); }
int         ClearFlag(void ) { return _CallMts( ID_ClearFlag, (int*)0 ); }
void        Vop(int SmpNo) { _CallMts( ID_v_op, (int*)&SmpNo ); }
int         Pop(int SmpNo) { return _CallMts( ID_p_op, (int*)&SmpNo ); }
void        Iop(int SmpNo,int InitCount)
{
	struct{
		int	p1;
		int	p2;
	}p;
	p.p1 = SmpNo;
	p.p2 = InitCount;
	_CallMts( ID_i_op, (int*)&p );
}
void        OnSignal(int SignalNo,unsigned SetSignal)
{
	struct{
		int	p1;
		unsigned p2;
	}p;
	p.p1 = SignalNo;
	p.p2 = SetSignal;
	_CallMts( ID_OnSignal, (int*)&p );
}
unsigned    OffSignal(int SignalNo,unsigned ClearSignal)
{
	struct{
		int	p1;
		unsigned p2;
	}p;
	p.p1 = SignalNo;
	p.p2 = ClearSignal;
	return _CallMts( ID_OffSignal, (int*)&p );
}
unsigned    WaitSignal(int SignalNo,unsigned OrSignal,unsigned AndSignal)
{
	struct{
		int	p1;
		unsigned p2;
		unsigned p3;
	}p;
	p.p1 = SignalNo;
	p.p2 = OrSignal;
	p.p3 = AndSignal;
	return _CallMts( ID_WaitSignal, (int*)&p );
}
unsigned    ReadSignal(int SignalNo) { return _CallMts( ID_ReadSignal, (int*)&SignalNo ); }
unsigned    ChangeMailResp(char* pMail,int Resp)
{
	struct{
		char*	p1;
		int	p2;
	}p;
	p.p1 = pMail;
	p.p2 = Resp;
	return _CallMts( ID_ChangeMailResp, (int*)&p ); }
unsigned    ChangeMailPriority(char* pMail,int Priority)
{
	struct{
		char*	p1;
		int	p2;
	}p;
	p.p1 = pMail;
	p.p2 = Priority;
	return _CallMts( ID_ChangeMailPriority, (int*)&p );
}
int         SetTimeOut(int TimeOutCount) { return _CallMts( ID_SetTimeOut, (int*)&TimeOutCount ); }
int         Delay(int DelayTimeMsec) { return _CallMts( ID_Delay, (int*)&DelayTimeMsec ); }
unsigned    ChangeTaskPriority(int TaskNo,unsigned NewPriority)
{
	struct{
		int	p1;
		unsigned p2;
	}p;
	p.p1 = TaskNo;
	p.p2 = NewPriority;
	return _CallMts( ID_ChangeTaskPriority, (int*)&p );
}

void        IAddFlag(int TaskNo,short AddCount)
{
    _PendingRequest( ID_PAddFlag | TaskNo << 16 | AddCount );
}

void        Ivop(int SmpNo)
{
    _PendingRequest( ID_Pv_op | SmpNo );
}


void        IOnSignal(int SignalNo,unsigned short SetSignal)
{
    _PendingRequest( ID_POnSignal | SignalNo << 16 | SetSignal );
}
