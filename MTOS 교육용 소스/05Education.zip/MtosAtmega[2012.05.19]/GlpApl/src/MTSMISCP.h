unsigned int __cdecl _ChangeTaskPriority(int *);
/*	void __cdecl Lcdprintf(int,int,char *,...);	*/
