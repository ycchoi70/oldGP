

#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<disp.h>
#include	<s2440.h>


extern	unsigned char	font_data_jpn[128][8];
extern	void    DrawLcd( char* pBitmapBits );

#define BaseLcd_Buffer	FRAMEBUFFER_BASE

//char	LcdBuff[256][352/8];
void	WriteFont(int x,int y,char *addr)
{
	COLOR_DT	*LcdPos;
	unsigned char	*FontPos;
	int		i,j,k;
	int		andData;
	unsigned char	font_y;

	for(i = 0; ; i++,x++){
		if(addr[i] == 0){
			break;
		}
		FontPos = (unsigned char *)&font_data_jpn[addr[i]];
		for(j = 0; j < 8; j++){
			LcdPos= (COLOR_DT *)&LcdBuff[0][(y*8)+j][x*8];
			andData= 0x80;
			font_y= *FontPos++;
			for(k= 0; k < 8; k++){
				if(font_y & andData){	*LcdPos = T_WHITE;	}
				else{					*LcdPos = T_BLACK;	}
				andData >>= 1;
				LcdPos++;
			}
		}
	}
#ifdef	WIN32
	DrawLcd((char *)LcdBuff[0]);
#else
	memcpy((void *)FRAMEBUFFER_BASE,&LcdBuff[0],sizeof(LcdBuff[0]));
#endif
}
void	TextOut(int x,int y,char *addr)
{
	if(y < 256/8){
		WriteFont(x, y, addr);
	}

}
void	TextOutInMenu(int x,int y,char *addr)
{
	TextOut(x,y,addr);	/* Front=Dark,Back=Light,Back=ON */
}


