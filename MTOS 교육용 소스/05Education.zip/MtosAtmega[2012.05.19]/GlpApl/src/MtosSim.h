void	TextOut(int x,int y,char *addr);
