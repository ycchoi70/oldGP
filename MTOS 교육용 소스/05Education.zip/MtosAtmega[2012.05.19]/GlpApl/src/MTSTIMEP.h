extern unsigned int __cdecl ReadTimeMsec(void);
extern void __cdecl SWait(void);
extern void __cdecl _ISystemClockHandler(int*);
int __cdecl _SetTimeOut(int *);
void __cdecl _Delay(int *);
#ifdef	WIN32
void  _SystemClockInterruptHandler(void);
#endif
unsigned    ReadTimeMsec( void );
