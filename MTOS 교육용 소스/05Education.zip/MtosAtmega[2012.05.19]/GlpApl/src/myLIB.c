#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "myLIB.h"
#include "MMU.h"
#include "s2440.h"
#include "glplcd.h"

#ifdef	WIN32
void MMU_EnableICache(void){};
void MMU_DisableICache(void){};
void MMU_EnableDCache(void){};
void MMU_DisableDCache(void){};
void MMU_EnableAlignFault(void){};
void MMU_DisableAlignFault(void){};
void MMU_EnableMMU(void){};
void MMU_DisableMMU(void){};
void MMU_SetFastBusMode(void){};
void MMU_SetAsyncBusMode(void){}; 
void MMU_SetTTBase(int base){};
void MMU_SetDomain(int domain){};

void MMU_InvalidateIDCache(void){};
void MMU_InvalidateICache(void){};
void MMU_InvalidateICacheMVA(unsigned int mva){};
void MMU_PrefetchICacheMVA(unsigned int mva){};
void MMU_InvalidateDCache(void){};
void MMU_InvalidateDCacheMVA(unsigned int mva){};
void MMU_CleanDCacheMVA(unsigned int mva){};
void MMU_CleanInvalidateDCacheMVA(unsigned int mva){};
void MMU_CleanDCacheIndex(unsigned int index){};
void MMU_CleanInvalidateDCacheIndex(unsigned int index){};
void MMU_WaitForInterrupt(void){};
void MMU_InvalidateTLB(void){};
void MMU_InvalidateITLB(void){};
void MMU_InvalidateITLBMVA(unsigned int mva){};
void MMU_InvalidateDTLB(void){};
void MMU_InvalidateDTLBMVA(unsigned int mva){};
void MMU_SetDCacheLockdownBase(unsigned int base){};
void MMU_SetICacheLockdownBase(unsigned int base){};
void MMU_SetDTLBLockdown(unsigned int baseVictim){};
void MMU_SetITLBLockdown(unsigned int baseVictim){};
void MMU_SetProcessId(unsigned int pid){};
#endif




void ChangeClockDivider(int hdivn,int pdivn)
{
     // hdivn,pdivn FCLK:HCLK:PCLK
     //     0,0         1:1:1 
     //     0,1         1:1:2 
     //     1,0         1:2:2
     //     1,1         1:2:4
}

void ChangeMPllValue(int mdiv,int pdiv,int sdiv)
{
	volatile	CLKPWR_REG*	pwrReg= (CLKPWR_REG*)CLKPWR_BASE;

    pwrReg->rMPLLCON = (mdiv<<12) | (pdiv<<4) | sdiv;
}

void ChangeUPllValue(int mdiv,int pdiv,int sdiv)
{
	volatile	CLKPWR_REG*	pwrReg= (CLKPWR_REG*)CLKPWR_BASE;

    pwrReg->rUPLLCON = (mdiv<<12) | (pdiv<<4) | sdiv;
}


int  random(int val)
{
   return rand()%val; 
}	

#define _MMUTT_STARTADDRESS     0x31ff8000
    
void MMU_Init(void)
{
    int i,j;
    //========================== IMPORTANT NOTE =========================
    //The current stack and code area can't be re-mapped in this routine.
    //If you want memory map mapped freely, your own sophiscated MMU
    //initialization code is needed.
    //===================================================================

    MMU_DisableDCache();
    MMU_DisableICache();

    //If write-back is used,the DCache should be cleared.
    for(i=0;i<64;i++)
    	for(j=0;j<8;j++)
    	    MMU_CleanInvalidateDCacheIndex((i<<26)|(j<<5));
    MMU_InvalidateICache();
    
    #if 0
    //To complete MMU_Init() fast, Icache may be turned on here.
    MMU_EnableICache(); 
    #endif
    
    MMU_DisableMMU();
    MMU_InvalidateTLB();

    //MMU_SetMTT(int vaddrStart,int vaddrEnd,int paddrStart,int attr)
    MMU_SetMTT(0x00000000,0x07f00000,0x00000000,RW_CNB);  //bank0
    MMU_SetMTT(0x08000000,0x0ff00000,0x08000000,RW_NCNB); //bank1(FPGA)
    MMU_SetMTT(0x10000000,0x17f00000,0x10000000,RW_CNB);  //bank2(SRAM)
    MMU_SetMTT(0x18000000,0x1ff00000,0x18000000,RW_NCNB); //bank3
    MMU_SetMTT(0x20000000,0x27f00000,0x20000000,RW_NCNB); //bank4
    MMU_SetMTT(0x28000000,0x2ff00000,0x28000000,RW_NCNB); //bank5
    MMU_SetMTT(0x30000000,0x31b00000,0x30000000,RW_CNB);  //bank6-1
    MMU_SetMTT(0x31c00000,0x31c00000,0x31c00000,RW_NCNB); //bank6-2		//USB HOST BUFFER
    MMU_SetMTT(0x31d00000,0x31f00000,0x31d00000,RW_CNB);  //bank6-3		//FRAME BUFFER
    MMU_SetMTT(0x32000000,0x33f00000,0x32000000,RW_CNB);  //bank6-3		//
 
    MMU_SetMTT(0x40000000,0x5af00000,0x40000000,RW_NCNB);//SFR+StepSram    
    MMU_SetMTT(0x5b000000,0xfff00000,0x5b000000,RW_FAULT);//not used

    MMU_SetTTBase(_MMUTT_STARTADDRESS);
    MMU_SetDomain(0x55555550|DOMAIN1_ATTR|DOMAIN0_ATTR); 
    	//DOMAIN1: no_access, DOMAIN0,2~15=client(AP is checked)
    MMU_SetProcessId(0x0);
    MMU_EnableAlignFault();
    	
    MMU_EnableMMU();
    MMU_EnableICache();
    MMU_EnableDCache(); //DCache should be turned on after MMU is turned on.
}    


// attr=RW_CB,RW_CNB,RW_NCNB,RW_FAULT
void ChangeRomCacheStatus(int attr)
{
    int i,j;
    MMU_DisableDCache();
    MMU_DisableICache();
    //If write-back is used,the DCache should be cleared.
    for(i=0;i<64;i++)
    	for(j=0;j<8;j++)
    	    MMU_CleanInvalidateDCacheIndex((i<<26)|(j<<5));
    MMU_InvalidateICache();
    MMU_DisableMMU();
    MMU_InvalidateTLB();
    MMU_SetMTT(0x00000000,0x07f00000,0x00000000,attr);	//bank0
    MMU_SetMTT(0x08000000,0x0ff00000,0x08000000,attr);	//bank1
    MMU_EnableMMU();
    MMU_EnableICache();
    MMU_EnableDCache();
}    
    

void MMU_SetMTT(int vaddrStart,int vaddrEnd,int paddrStart,int attr)
{
    U32 *pTT;
    int i,nSec;
    pTT=(U32 *)_MMUTT_STARTADDRESS+(vaddrStart>>20);
    nSec=(vaddrEnd>>20)-(vaddrStart>>20);
    for(i=0;i<=nSec;i++)*pTT++=attr |(((paddrStart>>20)+i)<<20);
}    

void	HardInitial(void)
{
//     ChangeMPllValue(0x89,5,0);				// Fin=12MHz, Fout=202.8MHz
//     ChangeUPllValue(0x28,1,2);				// Fin=12MHz, Fout=48MHz
    
     MMU_Init();
	 Lcd_Init();
}


