
//=======================================================================
// Define S3C2440 Special Registers 
//=======================================================================
#ifndef __2440X_H__
#define __2440X_H__


/* SA11x0 defines */
#define BIT00	(1<<0)
#define BIT01	(1<<1)
#define BIT02	(1<<2)
#define BIT03	(1<<3)
#define BIT04	(1<<4)
#define BIT05	(1<<5)
#define BIT06	(1<<6)
#define BIT07	(1<<7)
#define BIT08	(1<<8)
#define BIT09	(1<<9)
#define BIT10	(1<<10)
#define BIT11	(1<<11)
#define BIT12	(1<<12)
#define BIT13	(1<<13)
#define BIT14	(1<<14)
#define BIT15	(1<<15)
//#define BIT16	(1<<16)
#define BIT17	(1<<17)
#define BIT18	(1<<18)
#define BIT19	(1<<19)
#define BIT20	(1<<20)
#define BIT21	(1<<21)
#define BIT22	(1<<22)
#define BIT23	(1<<23)
#define BIT24	(1<<24)
#define BIT25	(1<<25)
#define BIT26	(1<<26)
#define BIT27	(1<<27)
#define BIT28	(1<<28)
#define BIT29	(1<<29)
#define BIT30	(1<<30)
#define BIT31	(1<<31)

/*
 * Registers : NAND Controller
 */

#define NAND_BASE_PHYS  0x4E000000
//typedef struct  
//{
//    unsigned int  rNFCONF;          /* 0x00                 */
//    unsigned char rNFCMD;           /* 0x04                 */
//    unsigned char d0[3];            
//    unsigned char rNFADDR;          /* 0x08                 */
//    unsigned char d1[3];            
//    unsigned char rNFDATA;          /* 0x0c                 */
//    unsigned char d2[3];
//    unsigned int  rNFSTAT;          /* 0x10                 */
//    unsigned char rNFECC0;          /* 0x14                 */
//    unsigned char rNFECC1;          /* 0x15                 */
//    unsigned char rNFECC2;          /* 0x16                 */
//} NAND_REG;    

// NAND flash
#define rNFCONF     (*(volatile unsigned *)0x4e000000)      //NAND Flash configuration
#define rNFCONT     (*(volatile unsigned *)0x4e000004)      //NAND Flash configuration
#define rNFCMD      (*(volatile unsigned char *)0x4e000008)            //NADD Flash command
#define rNFADDR     (*(volatile unsigned char *)0x4e00000c)            //NAND Flash address
#define rNFDATA     (*(volatile unsigned char *)0x4e000010)            //NAND Flash data
#define rNFECCD0    (*(volatile unsigned *)0x4e000014)
#define rNFECCD1    (*(volatile unsigned *)0x4e000018)
#define rNFECCD     (*(volatile unsigned *)0x4e00001C)      //NAND Flash ECC
#define rNFSTAT     (*(volatile unsigned char *)0x4e000020)      //NAND Flash operation status
#define rNFESTAT0   (*(volatile unsigned *)0x4e000024)
#define rNFESTAT1   (*(volatile unsigned *)0x4e000028)
#define rNFMECC0    (*(volatile unsigned *)0x4e00002c)
#define rNFMECC1    (*(volatile unsigned *)0x4e000030)
#define rNFSECC     (*(volatile unsigned *)0x4e000034)
#define rNFSBLK     (*(volatile unsigned *)0x4e000038)
#define rNFEBLK     (*(volatile unsigned *)0x4e00003c)

//
// Memory Controller Register
//

//#define MEMCTRL_BASE        0x49000000
#define MEMCTRL_BASE        0x48000000		//2440 Memory Control 0x48000000

typedef struct  {
    unsigned long       rBWSCON;    // 0
    unsigned long       rBANKCON0;  // 4
    unsigned long       rBANKCON1;  // 8
    unsigned long       rBANKCON2;  // c
    unsigned long       rBANKCON3;  // 10
    unsigned long       rBANKCON4;  // 1c
    unsigned long       rBANKCON5;  // 18
    unsigned long       rBANKCON6;  // 1c
    unsigned long       rBANKCON7;  // 20
    unsigned long       rREFRESH;   // 24
    unsigned long       rBANKSIZE;  // 28
    unsigned long       rMRSRB6;    // 2c
    unsigned long       rMRSRB7;     // 30
}MEMreg;

//USB HOST Control
#define MUSB_HOSTL_BASE        0x49000000		
typedef struct {
    unsigned long       rHCREVISION;			// 0
    unsigned long       rHCCONTROL;				// 4
    unsigned long       rHCCOMMONSTATUS;		// 8
    unsigned long       rHCINTERRUPTSTATUS;		// c
    unsigned long       rHCINTERRUPTENABLE;		// 10
    unsigned long       rHCINTERRUPTDISABLE;	// 14
    unsigned long       rHCHCCA;				// 18
    unsigned long       rHCPERIODCUTTENTED;		// 1c
    unsigned long       rHCCONTROLHEADED;		// 20
    unsigned long       rHCCONTROLCURRENTED;	// 24
    unsigned long       rHCBULKHEADED;			// 28
    unsigned long       rHCBULKCURRENTED;		// 2c
    unsigned long       rHDONEHEAD;				// 30
    unsigned long       rHCRMINTERVAL;			// 34
    unsigned long       rHCFMREMAINING;			// 38
    unsigned long       rHCFMNUMBER;			// 3c
    unsigned long       rHCPERIODICSTART;		// 40
    unsigned long       rHCLSTHRESHOLD;			// 44
    unsigned long       rHCRHDISCRIPTORA;		// 48
    unsigned long       rHCRHDISCRIPTORB;		// 4c
    unsigned long       rHCRHSTATUS;			// 50
    unsigned long       rHCRHPORTSTATUS1;		// 54
    unsigned long       rHCRHPORTSTATUS2;		// 58
}USB_HOSTreg;
//
// Clock & Power Management Special Register

#define CLKPWR_BASE     0x4C000000

typedef struct {
    unsigned long       rLOCKTIME;
    unsigned long       rMPLLCON;
    unsigned long       rUPLLCON;
    unsigned long       rCLKCON;
    unsigned long       rCLKSLOW;
    unsigned long       rCLKDIVN;
}CLKPWR_REG;

#define CLKEN_SM_BIT        (1<<0)
#define CLKEN_IDLE_BIT      (1<<2)
#define CLKEN_POWER_OFF     (1<<3)
#define CLKEN_NAND_CTRL     (1<<4)
#define CLKEN_LCDC          (1<<5)
#define CLKEN_USBH          (1<<6)
#define CLKEN_USBD          (1<<7)
#define CLKEN_PWMTIMER      (1<<8)
#define CLKEN_SDI           (1<<9)
#define CLKEN_UART0         (1<<10)
#define CLKEN_UART1         (1<<11)
#define CLKEN_UART2         (1<<12)
#define CLKEN_GPIO          (1<<13)
#define CLKEN_RTC           (1<<14)
#define CLKEN_ADC           (1<<15)
#define CLKEN_IIC           (1<<16)
#define CLKEN_IIS           (1<<17)
#define CLKEN_SPI           (1<<18)


//
// DMA Register
//


#define DMA_BASE        0x4B000000

typedef struct {
        unsigned int    rDISRC0;        // 00
        unsigned int	rDISRCC0;		// 04
        unsigned int    rDIDST0;        // 08
        unsigned int 	rDIDSTC0;		// 0C
        unsigned int    rDCON0;         // 10
        unsigned int    rDSTAT0;        // 14
        unsigned int    rDCSRC0;        // 18
        unsigned int    rDCDST0;        // 1C
        unsigned int    rDMASKTRIG0;    // 20
        unsigned int	rPAD1[7];		// 24 - 3C

        unsigned int    rDISRC1;        // 40
        unsigned int	rDISRCC1;		// 44
        unsigned int    rDIDST1;        // 48
        unsigned int 	rDIDSTC1;		// 4C
        unsigned int    rDCON1;         // 50
        unsigned int    rDSTAT1;        // 54
        unsigned int    rDCSRC1;        // 58
        unsigned int    rDCDST1;        // 5C
        unsigned int    rDMASKTRIG1;    // 60
        unsigned int	rPAD2[7];		// 64 - 7C

        unsigned int    rDISRC2;        // 80
        unsigned int	rDISRCC2;		// 84
        unsigned int    rDIDST2;        // 88
        unsigned int 	rDIDSTC2;		// 8C
        unsigned int    rDCON2;         // 90
        unsigned int    rDSTAT2;        // 94
        unsigned int    rDCSRC2;        // 98
        unsigned int    rDCDST2;        // 9C
        unsigned int    rDMASKTRIG2;    // A0
        unsigned int	rPAD3[7];		// A4 - BC

        unsigned int    rDISRC3;        // C0
        unsigned int	rDISRCC3;		// C4
        unsigned int    rDIDST3;        // C8
        unsigned int 	rDIDSTC3;		// CC
        unsigned int    rDCON3;         // D0
        unsigned int    rDSTAT3;        // D4
        unsigned int    rDCSRC3;        // D8
        unsigned int    rDCDST3;        // DC
        unsigned int    rDMASKTRIG3;    // E0
 }DMA_REG;


//----- Register definitions for DISRCCn control register -----
//
#define SOURCE_PERIPHERAL_BUS				0x00000002
#define FIXED_SOURCE_ADDRESS				0x00000001

//----- Register definitions for DIDSTCn control register -----
//
#define DESTINATION_PERIPHERAL_BUS			0x00000002
#define FIXED_DESTINATION_ADDRESS			0x00000001

//----- Register definitions for DCONn control register -----
//
#define HANDSHAKE_MODE						0x80000000
#define DREQ_DACK_SYNC						0x40000000
#define GENERATE_INTERRUPT					0x20000000
#define SELECT_BURST_TRANSFER				0x10000000
#define SELECT_WHOLE_SERVICE_MODE			0x08000000


// bits[26-24] = select DMA source for the respective channel:
//------------------------------------------------------------
#define XDREQ0_DMA0							0x00000000
#define UART0_DMA0							0x01000000
#define MMC_DMA0							0x02000000
#define TIMER_DMA0							0x03000000
#define USB_EP1_DMA0						0x04000000

#define XDREQ1_DMA1							0x00000000
#define UART1_DMA1							0x01000000
#define I2SSDI_DMA1							0x02000000
#define SPI_DMA1							0x03000000
#define USB_EP2_DMA1						0x04000000

#define I2SSDO_DMA2							0x00000000
#define I2SSDI_DMA2							0x01000000
#define MMC_DMA2							0x02000000
#define TIMER_DMA2							0x03000000
#define USB_EP3_DMA2						0x04000000

#define UART2_DMA3							0x00000000
#define MMC_DMA3							0x01000000
#define SPI_DMA3							0x02000000
#define TIMER_DMA3							0x03000000
#define USB_EP4_DMA3						0x04000000
//------------------------------------------------------------

#define DMA_TRIGGERED_BY_HARDWARE			0x00800000
#define NO_DMA_AUTO_RELOAD					0x00400000

// bits[21-20] = select transfer word size
//------------------------------------------------------------
#define TRANSFER_BYTE						0x00000000				// 8  bits
#define TRANSFER_HALF_WORD					0x00100000				// 16 bits
#define TRANSFER_WORD						0x00200000				// 32 bits

//----- Register definitions for DSTATn status register -----
#define DMA_TRANSFER_IN_PROGRESS			0x00100000

//----- Register definitions for DMASKTRIGn configuration register -----
#define STOP_DMA_TRANSFER					0x00000004
#define ENABLE_DMA_CHANNEL					0x00000002
#define DMA_SW_TRIGGER						0x00000001



//
// Registers : I/O port
//

#define IOP_BASE        0x56000000
typedef struct  {
    unsigned int  rGPACON;		// 00
    unsigned int  rGPADAT;
    unsigned int  rPAD1[2];
    
    unsigned int  rGPBCON;		// 10
    unsigned int  rGPBDAT;
    unsigned int  rGPBUP;
    unsigned int  rPAD2;
    
    unsigned int  rGPCCON;		// 20
    unsigned int  rGPCDAT;
    unsigned int  rGPCUP;
    unsigned int  rPAD3;
    
    unsigned int  rGPDCON;		// 30
    unsigned int  rGPDDAT;
    unsigned int  rGPDUP; 
    unsigned int  rPAD4;
    
    unsigned int  rGPECON;		// 40
    unsigned int  rGPEDAT;
    unsigned int  rGPEUP;
    unsigned int  rPAD5;
    
    unsigned int  rGPFCON;		// 50
    unsigned int  rGPFDAT;
    unsigned int  rGPFUP; 
    unsigned int  rPAD6;
    
    unsigned int  rGPGCON;		// 60
    unsigned int  rGPGDAT;
    unsigned int  rGPGUP; 
    unsigned int  rPAD7;
    
    unsigned int  rGPHCON;		// 70
    unsigned int  rGPHDAT;
    unsigned int  rGPHUP; 
    unsigned int  rPAD8;
    
    unsigned int  rMISCCR;		// 80
    unsigned int  rDCKCON;		
    unsigned int  rEXTINT0;
    unsigned int  rEXTINT1;		
    unsigned int  rEXTINT2;		// 90
	unsigned int  rEINTFLT0;
	unsigned int  rEINTFLT1;
	unsigned int  rEINTFLT2;
	unsigned int  rEINTFLT3;		// A0
	unsigned int  rEINTMASK;
	unsigned int  rEINTPEND;
	unsigned int  rGSTATUS0;
	unsigned int  rGSTATUS1;		// B0
}IOP_REG;  
 

//
// Registers : PWM
//

#define PWM_BASE        0x51000000
typedef struct  {
    unsigned int  rTCFG0;
    unsigned int  rTCFG1;
    unsigned int  rTCON;
    unsigned int  rTCNTB0;
    unsigned int  rTCMPB0;
    unsigned int  rTCNTO0;
    unsigned int  rTCNTB1;
    unsigned int  rTCMPB1;
    unsigned int  rTCNTO1;
    unsigned int  rTCNTB2;
    unsigned int  rTCMPB2;
    unsigned int  rTCNTO2;
    unsigned int  rTCNTB3;
    unsigned int  rTCMPB3;
    unsigned int  rTCNTO3;
    unsigned int  rTCNTB4;
    unsigned int  rTCNTO4;
}PWM_REG ;



//
// Registers : UART
//

#define UART0_BASE      0x50000000
#define UART1_BASE      0x50004000
#define UART2_BASE      0x50008000

typedef struct  {
    unsigned int  rULCON;		//0
    unsigned int  rUCON;		//4
    unsigned int  rUFCON;		//8
    unsigned int  rUMCON;		//c
    unsigned int  rUTRSTAT;		//10
    unsigned int  rUERSTAT;		//14
    unsigned int  rUFSTAT;		//18
    unsigned int  rUMSTAT;		//1c
    unsigned int  rUTXH;		//20
    unsigned int  rURXH;		//24
    unsigned int  rUBRDIV;		//28
}UART_REG, *PUART_REG;

#define	UART_INT0			(1<<28)
#define	UART_INT1			(1<<23)
#define	UART_INT2			(1<<15)

#define UART0_INT_RXD        (1<<0)
#define UART0_INT_TXD        (1<<1)
#define UART0_INT_ERR        (1<<2)
#define UART1_INT_RXD        (1<<3)
#define UART1_INT_TXD        (1<<4)
#define UART1_INT_ERR        (1<<5)
#define UART2_INT_RXD        (1<<6)
#define UART2_INT_TXD        (1<<7)
#define UART2_INT_ERR        (1<<8)

#define UART_IOP_TX0        (2)
#define UART_IOP_RX0        (3)
#define UART_IOP_TX1        (4)
#define UART_IOP_RX1        (5)
#define UART_IOP_TX2        (6)
#define UART_IOP_RX2        (7)

#define FIFO_DEPTH_TX       4
#define FIFO_DEPTH_RX       8


#define INTR_NONE           (0)
#define INTR_LINE           (1<<0)
#define INTR_MODEM          (1<<1)
#define INTR_RX             (1<<2)
#define INTR_TX             (1<<3)

#ifndef	WIN_DLG
#define BAUD_300          (300)
#define BAUD_600          (600)
#define BAUD_1200         (1200)
#define BAUD_2400         (2400)
#define BAUD_4800         (4800)
#define BAUD_9600         (9600)
#define BAUD_19200        (19200)
#define BAUD_38400        (38400)
#define BAUD_57600        (57600)
#define BAUD_115200       (115200)
#endif

//#define BAUD_112500	        115200
//#define BAUD_38400	        38400



// 2410 USB DEVICE Function (Written by Seung-han, Lim)
// Little-Endian	


#define SET_ADDRESS_REG_OFFSET      0x0
#define PWR_REG_OFFSET              0x4
#define EP_INT_REG_OFFSET           0x8
#define USB_INT_REG_OFFSET          0x18
#define EP_INT_EN_REG_OFFSET        0x1C
#define USB_INT_EN_REG_OFFSET       0x2C



 #define EP0_FIFO_REG_OFFSET        0x80
 #define EP1_FIFO_REG_OFFSET        0x84
 #define EP2_FIFO_REG_OFFSET        0x88
 #define EP3_FIFO_REG_OFFSET        0x8C
 #define EP4_FIFO_REG_OFFSET        0x90


 
#define IDXADDR_REG_OFFSET          0x38
// Indexed Registers
#define MAX_PKT_SIZE_REG_OFFSET     0x40
#define IN_CSR1_REG_OFFSET          0x44
#define EP0_CSR_REG_OFFSET          IN_CSR1_REG_OFFSET
#define IN_CSR2_REG_OFFSET          0x48
#define OUT_CSR1_REG_OFFSET         0x50
#define OUT_CSR2_REG_OFFSET         0x54
#define OUT_FIFO_CNT1_REG_OFFSET    0x58
#define OUT_FIFO_CNT2_REG_OFFSET    0x5C


#define BASE_REGISTER_OFFSET        0x140
#define REGISTER_SET_SIZE           0x200


// Power Reg Bits
#define USB_RESET                   0x8
#define MCU_RESUME                  0x4
#define SUSPEND_MODE                0x2
#define SUSPEND_MODE_ENABLE_CTRL    0x1

// EP0 CSR
#define EP0_OUT_PACKET_RDY          0x1
#define EP0_IN_PACKET_RDY           0x2
#define EP0_SENT_STALL              0x4
#define DATA_END                    0x8
#define SETUP_END                   0x10
#define EP0_SEND_STALL              0x20
#define SERVICED_OUT_PKT_RDY        0x40
#define SERVICED_SETUP_END          0x80

// OUT_CSR1_REG Bit definitions
#define OUT_PACKET_READY            0x1
#define FLUSH_OUT_FIFO              0x10
#define OUT_SEND_STALL              0x20
#define OUT_SENT_STALL              0x40
#define OUT_CLR_DATA_TOGGLE         0x80

// OUT_CSR2_REG Bit definitions
#define OUT_DMA_INT_DISABLE         0x10

// IN_CSR1_REG Bit definitions
#define IN_PACKET_READY             0x1
#define UNDER_RUN                   0x4   // Iso Mode Only
#define FLUSH_IN_FIFO               0x8
#define IN_SEND_STALL               0x10
#define IN_SENT_STALL               0x20
#define IN_CLR_DATA_TOGGLE          0x40

// IN_CSR2_REG Bit definitions
#define IN_DMA_INT_DISABLE          0x10
#define SET_MODE_IN                 0x20 
#define SET_TYPE_ISO                0x40  // Note that Samsung does not currently support ISOCH 
#define AUTO_MODE                   0x80

// Can be used for Interrupt and Interrupt Enable Reg - common bit def
#define EP0_INT_INTR                0x1
#define EP1_INT_INTR                0x2
#define EP2_INT_INTR                0x4
#define EP3_INT_INTR                0x8
#define EP4_INT_INTR                0x10

#define CLEAR_ALL_EP_INTRS          (EP0_INT_INTR | EP1_INT_INTR | EP2_INT_INTR | EP3_INT_INTR | EP4_INT_INTR)

#define  EP_INTERRUPT_DISABLE_ALL   0x0   // Bits to write to EP_INT_EN_REG - Use CLEAR

// Bit Definitions for USB_INT_REG and USB_INT_EN_REG_OFFSET
#define USB_RESET_INTR              0x4
#define USB_RESUME_INTR             0x2
#define USB_SUSPEND_INTR            0x1


//struct udcFARBits {				// function address reg
//	BYTE func_addr		:7;		// function_address
//	BYTE addr_up		:1;		// addr_update
//};
//
//struct PMRBits {				// power management reg
//	BYTE sus_en		:1;		// suspend_en
//	BYTE sus_mo		:1;		// suspend_mode
//	BYTE muc_res		:1;		// mcu_resume
//	BYTE usb_re		:1;		// usb_reset
//	BYTE rsvd1		:3;		
//	BYTE iso_up		:1;		// iso_update
//};
//
//struct EIRBits {				// ep interrupt reg
//	BYTE ep0_int		:1;		// ep0_interrupt
//	BYTE ep1_int		:1;		// ep1_interrupt
//	BYTE ep2_int		:1;		// ep2_interrupt
//	BYTE ep3_int		:1;		// ep3_interrupt
//	BYTE ep4_int		:1;		// ep4_interrupt
//	BYTE rsvd0		:3;
//};
//
//struct UIRBits {				// usb interrupt reg
//	BYTE sus_int		:1;		// suspend inaterrupt
//	BYTE resume_int	:1;			// resume interrupt
//	BYTE reset_int		:1;		// reset interrupt
//	BYTE rsvd0		:5;
//};
//
//struct EIERBits {				// interrupt mask reg
//	BYTE ep0_int_en	:1;			// ep1_int_reg
//	BYTE ep1_int_en	:1;			// ep1_int_reg
//	BYTE ep2_int_en	:1;			// ep2_int_reg
//	BYTE ep3_int_en	:1;			// ep3_int_reg
//	BYTE ep4_int_en	:1;			// ep4_int_reg
//	BYTE rsvd0		:3;
//};
//
//struct UIERBits {
//	BYTE sus_int_en	:1;			// suspend_int_en
//	BYTE rsvd1		:1;		
//	BYTE reset_int_en	:1;		// reset_enable_reg
//	BYTE rsvd0		:5;
//};
//
//struct FNR1Bits {				// frame number1 register
//	BYTE fr_n1		:8;		// frame_num1_reg
//};
//
//struct FNR2Bits {				// frame number2 register
//	BYTE fr_n2		:8;		// frame_num2_reg
//};
//
//struct INDEXBits {				// index register
//	BYTE index		:8;		// index_reg
//};
//
//struct EP0ICSR1Bits				// EP0 & ICSR1 shared
//{
//	BYTE opr_ipr		:1;
//	BYTE ipr_		:1;
//	BYTE sts_ur		:1;
//	BYTE de_ff		:1;
//	BYTE se_sds		:1;
//	BYTE sds_sts		:1;
//	BYTE sopr_cdt		:1;
//	BYTE sse_		:1;
//};
//
//struct ICSR2Bits {				// in csr2 areg
//	BYTE rsvd1		:4;
//	BYTE in_dma_int_en	:1;		// in_dma_int_en
//	BYTE mode_in		:1;		// mode_in
//	BYTE iso		:1; 		// iso/bulk mode
//	BYTE auto_set		:1;		// auto_set
//};
//
//struct OCSR1Bits {				// out csr1 reg
//	BYTE out_pkt_rdy	:1;		// out packet reday
//	BYTE rsvd1		:1;
//	BYTE ov_run		:1;		// over_run
//	BYTE data_error	:1;			// data_error
//	BYTE fifo_flush	:1;			// fifo_flush
//	BYTE send_stall	:1;			// send_stall
//	BYTE sent_stall	:1; 			// sent_stall
//	BYTE clr_data_tog	:1;		// clear data toggle
//};
//
//struct OCSR2Bits {				// out csr2 reg
//	BYTE rsvd1		:5;
//	BYTE out_dma_int_en	:1;		// out_dma_int_en
//	BYTE iso		:1;		// iso/bulk mode
//	BYTE auto_clr		:1;		// auto_clr
//};
//
//struct EP0FBits {				// ep0 fifo reg
//	BYTE fifo_data		:8;		// fifo data
//};
//
//struct EP1FBits {				// ep0 fifo reg
//	BYTE fifo_data		:8;		// fifo data
//};
//
//struct EP2FBits {				// ep0 fifo reg
//	BYTE fifo_data		:8;		// fifo data
//};
//
//struct EP3FBits {				// ep0 fifo reg
//	BYTE fifo_data		:8;		// fifo data
//};
//
//struct EP4FBits {				// ep0 fifo reg
//	BYTE fifo_data		:8;		// fifo data
//};
//
//struct MAXPBits {
//	BYTE maxp		:4;		// max packet reg
//	BYTE rsvd0		:4;
//};
//
//struct OFCR1Bits {				// out_fifo_cnt1_reg
//	BYTE out_cnt_low	:8;		// out_cnt_low
//};
//
//struct OFCR2Bits {				// out_fifo_cnt2_reg
//	BYTE out_cnt_high	:8;		// out_cnt_high
//};
//
//struct EP1DCBits {				// ep1 dma interface control
//	BYTE dma_mo_en		:1;		// dma_mode_en
//	BYTE in_dma_run		:1;		// in_dma_run
//	BYTE orb_odr		:1;		// out_run_ob/out_dma_run
//	BYTE demand_mo		:1;		// demand_mode
//	BYTE state		:3;		// state
//	BYTE in_run_ob		:1;		// in_run_ob
//};
//
//struct EP2DCBits {				// ep2 dma interface control
//	BYTE dma_mo_en		:1;		// dma_mode_en
//	BYTE in_dma_run		:1;		// in_dma_run
//	BYTE orb_odr		:1;		// out_run_ob/out_dma_run
//	BYTE demand_mo		:1;		// demand_mode
//	BYTE state		:3;		// state
//	BYTE in_run_ob		:1;		// in_run_ob
//};
//
//struct EP3DCBits {				// ep3 dma interface control
//	BYTE dma_mo_en		:1;		// dma_mode_en
//	BYTE in_dma_run		:1;		// in_dma_run
//	BYTE orb_odr		:1;		// out_run_ob/out_dma_run
//	BYTE demand_mo		:1;		// demand_mode
//	BYTE state		:3;		// state
//	BYTE in_run_ob		:1;		// in_run_ob
//};
//
//struct EP4DCBits {				// ep4 dma interface control
//	BYTE dma_mo_en		:1;		// dma_mode_en
//	BYTE in_dma_run		:1;		// in_dma_run
//	BYTE orb_odr		:1;		// out_run_ob/out_dma_run
//	BYTE demand_mo		:1;		// demand_mode
//	BYTE state		:3;		// state
//	BYTE in_run_ob		:1;		// in_run_ob
//};
//
//struct EP1DUBits {
//	BYTE ep1_unit_cnt	:8;		// ep0_unit_cnt
//};
//
//struct EP2DUBits {
//	BYTE ep2_unit_cnt	:8;		// ep0_unit_cnt
//};
//
//struct EP3DUBits {
//	BYTE ep3_unit_cnt	:8;		// ep0_unit_cnt
//};
//
//struct EP4DUBits {
//	BYTE ep4_unit_cnt	:8;		// ep0_unit_cnt
//};
//
//struct EP1DFBits {
//	BYTE ep1_fifo_cnt	:8;
//};
//
//struct EP2DFBits {
//	BYTE ep2_fifo_cnt	:8;
//};
//
//struct EP3DFBits {
//	BYTE ep3_fifo_cnt	:8;
//};
//
//struct EP4DFBits {
//	BYTE ep4_fifo_cnt	:8;
//};
//
//struct EP1DTLBits {
//	BYTE ep1_ttl_l		:8;
//};
//
//struct EP1DTMBits {
//	BYTE ep1_ttl_m		:8;
//};
//
//struct EP1DTHBits {
//	BYTE ep1_ttl_h		:8;
//};
//
//struct EP2DTLBits {
//	BYTE ep2_ttl_l		:8;
//};
//
//struct EP2DTMBits {
//	BYTE ep2_ttl_m		:8;
//};
//
//struct EP2DTHBits {
//	BYTE ep2_ttl_h		:8;
//};
//
//struct EP3DTLBits {
//	BYTE ep3_ttl_l		:8;
//};
//
//struct EP3DTMBits {
//	BYTE ep3_ttl_m		:8;
//};
//
//struct EP3DTHBits {
//	BYTE ep3_ttl_h		:8;
//};
//
//struct EP4DTLBits {
//	BYTE ep4_ttl_l		:8;
//};
//
//struct EP4DTMBits {
//	BYTE ep4_ttl_m		:8;
//};
//
//struct EP4DTHBits {
//	BYTE ep4_ttl_h		:8;
//};
//
#define UDC_BASE            0x52000000
//typedef struct udcreg {						// PHY BASE : 0x52000140(Little Endian)
//    BYTE            rsved[140];
//	struct udcFARBits	udcFAR;			// 0x140
//	BYTE			rsvd0;				// 0x141
//	BYTE			rsvd1;				// 0x142
//	BYTE			rsvd2;				// 0x143
//	struct PMRBits		PMR;			// 0x144
//	BYTE			rsvd3;				// 0x145
//	BYTE			rsvd4;				// 0x146
//	BYTE			rsvd5;				// 0x147
//	struct EIRBits		EIR;				// 0x148
//	BYTE			rsvd6;				// 0x149
//	BYTE			rsvd7;				// 0x14a
//	BYTE			rsvd8;				// 0x14b
//	BYTE			rsvd9;				// 0x14C
//	BYTE			rsvd10;				// 0x14d
//	BYTE			rsvd11;				// 0x14e
//	BYTE			rsvd12;				// 0x14f
//
//	BYTE			rsvd13;				// 0x150
//	BYTE			rsvd14;				// 0x151
//	BYTE			rsvd15;				// 0x152
//	BYTE			rsvd16;				// 0x153
//	BYTE			rsvd17;				// 0x154
//	BYTE			rsvd18;				// 0x155
//	BYTE			rsvd19;				// 0x156
//	BYTE			rsvd20;				// 0x157
//	struct UIRBits		UIR;				// 0x158
//	BYTE			rsvd21;				// 0x159
//	BYTE			rsvd22;				// 0x15a
//	BYTE			rsvd23;				// 0x15b
//	struct EIERBits		EIER;			// 0x15C
//	BYTE			rsvd24;				// 0x15d
//	BYTE			rsvd25;				// 0x15e
//	BYTE			rsvd26;				// 0x15f
//
//	BYTE			rsvd27;				// 0x160
//	BYTE			rsvd28;				// 0x161
//	BYTE			rsvd29;				// 0x162
//	BYTE			rsvd30;				// 0x163
//	BYTE			rsvd31;				// 0x164
//	BYTE			rsvd32;				// 0x165
//	BYTE			rsvd33;				// 0x166
//	BYTE			rsvd34;				// 0x167
//	BYTE			rsvd35;				// 0x168
//	BYTE			rsvd36;				// 0x169
//	BYTE			rsvd37;				// 0x16a
//	BYTE			rsvd38;			// 0x16b
//	struct UIERBits		UIER;				// 0x16c
//	BYTE			rsvd39;				// 0x16d
//	BYTE			rsvd40;				// 0x16e
//	BYTE			rsvd41;				// 0x16f
//
//	struct FNR1Bits		FNR1;			// 0x170
//	BYTE			rsvd42;				// 0x171
//	BYTE			rsvd43;				// 0x172
//	BYTE			rsvd44;				// 0x173
//	struct FNR2Bits		FNR2;			// 0x174
//	BYTE			rsvd45;				// 0x175
//	BYTE			rsvd46;				// 0x176
//	BYTE			rsvd47;				// 0x177
//	struct INDEXBits	INDEX;				// 0x178
//	BYTE			rsvd48;			// 0x179
//	BYTE			rsvd49;				// 0x17a
//	BYTE			rsvd50;				// 0x17b
//	BYTE			rsvd51;				// 0x17C
//	BYTE			rsvd52;				// 0x17d
//	BYTE			rsvd53;				// 0x17e
//	BYTE			rsvd54;				// 0x17f
//
//	struct MAXPBits		MAXP;			// 0x180
//	BYTE			rsvd56;				// 0x181
//	BYTE			rsvd57;				// 0x182
//	BYTE			rsvd58;				// 0x183
//	struct EP0ICSR1Bits	EP0ICSR1;		// 0x184
//	// struct ICSR1Bits	ICSR1;			// 0x184
//	// struct EP0CSRBits	EP0CSR;			// mapped to the in_csr1 reg 
//	BYTE			rsvd59;				// 0x185
//	BYTE			rsvd60;				// 0x186
//	BYTE			rsvd61;				// 0x187
//	struct ICSR2Bits	ICSR2;			// 0x188
//	BYTE			rsvd63;				// 0x189
//	BYTE			rsvd64;				// 0x18a
//	BYTE			rsvd65;				// 0x18b
//	BYTE			rsvd55;				// 0x180
//	BYTE			rsvd66;				// 0x18d
//	BYTE			rsvd67;				// 0x18e
//	BYTE			rsvd68;				// 0x18f
//
//	struct OCSR1Bits	OCSR1;			// 0x190
//	BYTE			rsvd69;				// 0x191
//	BYTE			rsvd70;				// 0x192
//	BYTE			rsvd71;				// 0x193
//	struct OCSR2Bits	OCSR2;			// 0x194
//	BYTE			rsvd73;				// 0x195
//	BYTE			rsvd74;				// 0x196
//	BYTE			rsvd75;				// 0x197
//	struct OFCR1Bits	OFCR1;			// 0x198
//	BYTE			rsvd76;				// 0x199
//	BYTE			rsvd77;				// 0x19a
//	BYTE			rsvd78;				// 0x19b
//	struct OFCR2Bits	OFCR2;			// 0x19C
//	BYTE			rsvd79;				// 0x19d
//	BYTE			rsvd80;				// 0x19e
//	BYTE			rsvd81;				// 0x19f
//
//	BYTE			rsvd82;				// 0x1A0	
//	BYTE			rsvd83;				// 0x1a1
//	BYTE			rsvd84;				// 0x1a2
//	BYTE			rsvd85;				// 0x1a3
//	BYTE			rsvd86;				// 0x1A4
//	BYTE			rsvd87;				// 0x1a5
//	BYTE			rsvd88;				// 0x1a6
//	BYTE			rsvd89;				// 0x1a7
//	BYTE			rsvd90;				// 0x1A8
//	BYTE			rsvd91;				// 0x1a9
//	BYTE			rsvd92;				// 0x1aa
//	BYTE			rsvd93;				// 0x1ab
//	BYTE			rsvd94;				// 0x1AC
//	BYTE			rsvd95;				// 0x1ad
//	BYTE			rsvd96;				// 0x1ae
//	BYTE			rsvd97;				// 0x1af
//
//	BYTE			rsvd98;				// 0x1B0
//	BYTE			rsvd99;				// 0x1B1
//	BYTE			rsvd100;				// 0x1B2
//	BYTE			rsvd101;				// 0x1B3
//	BYTE			rsvd102;				// 0x1B4
//	BYTE			rsvd103;				// 0x1B5
//	BYTE			rsvd104;				// 0x1B6
//	BYTE			rsvd105;				// 0x1B7
//	BYTE			rsvd106;				// 0x1B8
//	BYTE			rsvd107;				// 0x1B9
//	BYTE			rsvd108;				// 0x1Ba
//	BYTE			rsvd109;				// 0x1Bb
//	BYTE			rsvd110;				// 0x1BC
//	BYTE			rsvd111;				// 0x1Bd
//	BYTE			rsvd112;				// 0x1Be
//	BYTE			rsvd113;				// 0x1Bf
//
//	struct EP0FBits		EP0F;				// 0x1C0
//	BYTE			rsvd114;				// 0x1c1
//	BYTE			rsvd115;				// 0x1c2
//	BYTE			rsvd116;				// 0x1c3
//	struct EP1FBits		EP1F;				// 0x1C4
//	BYTE			rsvd117;				// 0x1c5
//	BYTE			rsvd118;				// 0x1c6
//	BYTE			rsvd119;				// 0x1c7
//	struct EP2FBits		EP2F;				// 0x1C8
//	BYTE			rsvd120;				// 0x1c9
//	BYTE			rsvd121;				// 0x1ca
//	BYTE			rsvd122;				// 0x1cb
//	struct EP3FBits		EP3F;				// 0x1CC
//	BYTE			rsvd123;				// 0x1cd
//	BYTE			rsvd124;				// 0x1ce
//	BYTE			rsvd125;				// 0x1cf
//
//	struct EP4FBits		EP4F;				// 0x1D0
//	BYTE			rsvd126;				// 0x1d1
//	BYTE			rsvd127;				// 0x1d2
//	BYTE			rsvd128;				// 0x1d3
//	BYTE			rsvd169;				// 0x1D4
//	BYTE			rsvd170;				// 0x1d5
//	BYTE			rsvd171;				// 0x1d6
//	BYTE			rsvd172;				// 0x1d7
//	BYTE			rsvd173;				// 0x1D8
//	BYTE			rsvd174;				// 0x1d9
//	BYTE			rsvd175;				// 0x1da
//	BYTE			rsvd176;				// 0x1db
//	BYTE			rsvd177;				// 0x1DC
//	BYTE			rsvd178;				// 0x1dd
//	BYTE			rsvd179;				// 0x1de
//	BYTE			rsvd180;				// 0x1df
//
//	BYTE			rsvd181;				// 0x1F0
//	BYTE			rsvd182;				// 0x1F1
//	BYTE			rsvd183;				// 0x1F2
//	BYTE			rsvd184;				// 0x1F3
//	BYTE			rsvd185;				// 0x1F4
//	BYTE			rsvd186;				// 0x1F5
//	BYTE			rsvd187;				// 0x1F6
//	BYTE			rsvd188;				// 0x1F7
//	BYTE			rsvd189;				// 0x1F8
//	BYTE			rsvd190;				// 0x1F9
//	BYTE			rsvd191;				// 0x1Fa
//	BYTE			rsvd192;				// 0x1Fb
//	BYTE			rsvd193;				// 0x1FC
//	BYTE			rsvd194;				// 0x1Fd
//	BYTE			rsvd195;				// 0x1Fe
//	BYTE			rsvd196;				// 0x1Ff
//
//	struct EP1DCBits	EP1DC;				// 0x200
//	BYTE			rsvd197;				// 0x201
//	BYTE			rsvd198;				// 0x202
//	BYTE			rsvd199;				// 0x203
//	struct EP1DUBits	EP1DU;				// 0x204
//	BYTE			rsvd200;				// 0x205
//	BYTE			rsvd201;				// 0x206
//	BYTE			rsvd202;				// 0x207
//	struct EP1DFBits	EP1DF;				// 0x208
//	BYTE			rsvd203;				// 0x209
//	BYTE			rsvd204;				// 0x20a
//	BYTE			rsvd205;				// 0x20b
//	struct EP1DTLBits	EP1DTL;				// 0x20C
//	BYTE			rsvd206;				// 0x20d
//	BYTE			rsvd207;				// 0x20e
//	BYTE			rsvd208;				// 0x20f
//
//	struct EP1DTMBits	EP1DTM;				// 0x210
//	BYTE			rsvd209;				// 0x211
//	BYTE			rsvd210;				// 0x212
//	BYTE			rsvd211;				// 0x213
//	struct EP1DTHBits	EP1DTH;				// 0x214
//	BYTE			rsvd212;				// 0x215
//	BYTE			rsvd213;				// 0x216
//	BYTE			rsvd214;				// 0x217
//	struct EP2DCBits	EP2DC;				// 0x218
//	BYTE			rsvd215;				// 0x219
//	BYTE			rsvd216;				// 0x21a
//	BYTE			rsvd217;				// 0x21b
//	struct EP2DUBits	EP2DU;				// 0x21C
//	BYTE			rsvd218;				// 0x21d
//	BYTE			rsvd219;				// 0x21e
//	BYTE			rsvd220;				// 0x21f
//
//	struct EP2DFBits	EP2DF;				// 0x220
//	BYTE			rsvd221;				// 0x221
//	BYTE			rsvd222;				// 0x222
//	BYTE			rsvd223;				// 0x223
//	struct EP2DTLBits	EP2DTL;				// 0x224
//	BYTE			rsvd224;				// 0x225
//	BYTE			rsvd225;				// 0x226
//	BYTE			rsvd226;				// 0x227
//	struct EP2DTMBits	EP2DTM;				// 0x228
//	BYTE			rsvd227;				// 0x229
//	BYTE			rsvd228;				// 0x22a
//	BYTE			rsvd229;				// 0x22b
//	struct EP2DTHBits	EP2DTH;				// 0x22C
//	BYTE			rsvd230;				// 0x22d
//	BYTE			rsvd231;				// 0x22e
//	BYTE			rsvd232;				// 0x22f
//
//	BYTE			rsvd233;				// 0x230
//	BYTE			rsvd234;				// 0x231
//	BYTE			rsvd235;				// 0x232
//	BYTE			rsvd236;				// 0x233
//	BYTE			rsvd237;				// 0x234
//	BYTE			rsvd238;				// 0x235
//	BYTE			rsvd239;				// 0x236
//	BYTE			rsvd240;				// 0x237
//	BYTE			rsvd241;				// 0x238
//	BYTE			rsvd242;				// 0x239
//	BYTE			rsvd243;				// 0x23a
//	BYTE			rsvd244;				// 0x23b
//	BYTE			rsvd245;				// 0x23C
//	BYTE			rsvd246;				// 0x23d
//	BYTE			rsvd247;				// 0x23e
//	BYTE			rsvd248;				// 0x23f
//
//	struct EP3DCBits	EP3DC;				// 0x240
//	BYTE			rsvd249;				// 0x241
//	BYTE			rsvd250;				// 0x242
//	BYTE			rsvd251;				// 0x243
//	struct EP3DUBits	EP3DU;				// 0x244
//	BYTE			rsvd252;				// 0x245
//	BYTE			rsvd253;				// 0x246
//	BYTE			rsvd254;				// 0x247
//	struct EP3DFBits	EP3DF;				// 0x248
//	BYTE			rsvd255;				// 0x249
//	BYTE			rsvd256;				// 0x24a
//	BYTE			rsvd257;				// 0x24b
//	struct EP3DTLBits	EP3DTL;				// 0x24C
//	BYTE			rsvd258;				// 0x24d
//	BYTE			rsvd259;				// 0x24e
//	BYTE			rsvd260;				// 0x24f
//
//	struct EP3DTMBits	EP3DTM;				// 0x250
//	BYTE			rsvd261;				// 0x251
//	BYTE			rsvd262;				// 0x252
//	BYTE			rsvd263;				// 0x253
//	struct EP3DTHBits	EP3DTH;				// 0x254
//	BYTE			rsvd264;				// 0x255
//	BYTE			rsvd265;				// 0x256
//	BYTE			rsvd266;				// 0x257
//	struct EP4DCBits	EP4DC;				// 0x258
//	BYTE			rsvd267;				// 0x259
//	BYTE			rsvd268;				// 0x25a
//	BYTE			rsvd269;				// 0x25b
//	struct EP4DUBits	EP4DU;				// 0x25C
//	BYTE			rsvd270;				// 0x25d
//	BYTE			rsvd271;				// 0x25e
//	BYTE			rsvd272;				// 0x25f
//
//	struct EP4DFBits	EP4DF;				// 0x260
//	BYTE			rsvd273;				// 0x261
//	BYTE			rsvd274;				// 0x262
//	BYTE			rsvd275;				// 0x263
//	struct EP4DTLBits	EP4DTL;				// 0x264
//	BYTE			rsvd276;				// 0x265
//	BYTE			rsvd277;				// 0x266
//	BYTE			rsvd278;				// 0x267
//	struct EP4DTMBits	EP4DTM;				// 0x268
//	BYTE			rsvd279;				// 0x269
//	BYTE			rsvd280;				// 0x26a
//	BYTE			rsvd281;				// 0x26b
//	struct EP4DTHBits	EP4DTH;				// 0x26C
//}UDC_REG;
//


#define HwUBFADR            *(volatile unsigned long *)(UDC_BASE + 0x140)
    #define HwUSB_UP                BIT07
#define HwUBPWR             *(volatile unsigned long *)(UDC_BASE + 0x144)
    #define HwUBPWR_ISOUP           BIT07
    #define HwUBPWR_RST             BIT03
    #define HwUBPWR_RSM             BIT02
    #define HwUBPWR_SP              BIT01
    #define HwUBPWR_ENSP            BIT00
#define HwUBEIR             *(volatile unsigned long *)(UDC_BASE + 0x148)
    #define HwUSB_EP2               BIT02
    #define HwUSB_EP1               BIT01
    #define HwUSB_EP0               BIT00
#define HwUBIR              *(volatile unsigned long *)(UDC_BASE + 0x158)
    #define HwUBIR_RST              BIT02
    #define HwUBIR_RSM              BIT01
    #define HwUBIR_SP               BIT00
#define HwUBEIEN            *(volatile unsigned long *)(UDC_BASE + 0x15C)
#define HwUBIEN             *(volatile unsigned long *)(UDC_BASE + 0x16C)
#define HwUBFRM1            *(volatile unsigned long *)(UDC_BASE + 0x170)
#define HwUBFRM2            *(volatile unsigned long *)(UDC_BASE + 0x174)
#define HwUBIDX             *(volatile unsigned long *)(UDC_BASE + 0x178)
#define HwMAXP              *(volatile unsigned long *)(UDC_BASE + 0x180)
#define HwINCSR1            *(volatile unsigned long *)(UDC_BASE + 0x184)
    #define HwUSB_IN_CTGL           BIT06           /* Clear Data Toggle Bit  */
    #define HwUSB_IN_STST           BIT05           /* Stall Handshake issued */
    #define HwUSB_IN_ISST           BIT04           /* Issue Stall Handshake  */
    #define HwUSB_IN_FLFF           BIT03           /* Issue FIFO flush       */
    #define HwUSB_IN_UNDER          BIT02           /* Under Run              */
    #define HwUSB_IN_FNE            BIT01           /* IN FIFO Not Empty      */
    #define HwUSB_IN_IRDY           BIT00           /* IN Packet ready        */
#define HwEP0CSR            HwINCSR1
    #define HwUSB_CLSE              BIT07
    #define HwUSB_CLOR              BIT06
    #define HwUSB_ISST              BIT05
    #define HwUSB_CEND              BIT04
    #define HwUSB_DEND              BIT03
    #define HwUSB_STST              BIT02
    #define HwUSB_IRDY              BIT01
    #define HwUSB_ORDY              BIT00
#define HwINCSR2            *(volatile unsigned long *)(UDC_BASE + 0x188)
    #define HwUSB_ASET              BIT07           /* Auto Set          */
    #define HwUSB_ISO               BIT06           /* ISO/BULK Mode Set */
    #define HwUSB_MDIN              BIT05           /* IN/OUT select     */
    #define HwUSB_DMA               BIT04           /* DMA Enable        */
#define HwOCSR1             *(volatile unsigned long *)(UDC_BASE + 0x190)
    #define HwUSB_OUT_CTGL          BIT07           /* Clear Data Toggle Bit   */
    #define HwUSB_OUT_STST          BIT06           /* Stall Handshake issued  */
    #define HwUSB_OUT_ISST          BIT05           /* Issue Stall Handshake   */
    #define HwUSB_OUT_FLFF          BIT04           /* Issue FIFO flush        */
    #define HwUSB_OUT_FFL           BIT01           /* OUT FIFO FULL           */
    #define HwUSB_ORDY              BIT00           /* IN Packet ready         */
#define HwOCSR2             *(volatile unsigned long *)(UDC_BASE + 0x194)
    #define HwUSB_ACLR              BIT07           /* Auto Clear           */
    #define HwUSB_ISO               BIT06           /* ISO/BULK Mode Select */
#define HwOFIFO1            *(volatile unsigned long *)(UDC_BASE + 0x198)
#define HwOFIFO2            *(volatile unsigned long *)(UDC_BASE + 0x19C)
#define HwEP0FIFO           *(volatile unsigned long *)(UDC_BASE + 0x1C0)
#define HwEP1FIFO           *(volatile unsigned long *)(UDC_BASE + 0x1C4)
#define HwEP2FIFO           *(volatile unsigned long *)(UDC_BASE + 0x1C8)
#define HwEP3FIFO           *(volatile unsigned long *)(UDC_BASE + 0x1CC)
#define HwEP4FIFO           *(volatile unsigned long *)(UDC_BASE + 0x1D0)
#define HwDMACON            *(volatile unsigned long *)(UDC_BASE + 0x200)
    #define	HwDMACON_CKSEL          BIT00           /* Clock select for system bus interface */
#define HwDMAEP1            *(volatile unsigned long *)(UDC_BASE + 0x204)
#define HwDMAEP2            *(volatile unsigned long *)(UDC_BASE + 0x208)





// Interrupt Pending Register (INTREG) (3f0084h)
// Endpoint Int reg
#define INTREG_EP0              0x01
#define INTREG_EP1              0x02
#define INTREG_EP2              0x04
#define INTREG_SUSPEND          0x01
#define INTREG_RESUME           0x02
#define INTREG_RESET            0x04

// ENDPOINT0 CSR REGISTER (EP0CSR) (3f008Ah or 3f008Bh)
#define EP0CSR_OUT_PKT_RDY      0x01
#define EP0CSR_IN_PKT_RDY       0x02
#define EP0CSR_STALL            0x04
#define EP0CSR_DATA_END         0x08
#define EP0CSR_SETUP_END        0x10
#define EP0CSR_ISST             0x20
#define EP0CSR_CLR_OUT_PKT_RDY  0x40
#define EP0CSR_CLR_SETUP_END    0x80

// IN CONTROL STATUS REGISTER (INCSR) (3f008Ah)
#define INCSR1_IN_PKT_RDY       0x01
#define INCSR1_INTPT_ENDP       0x02

#define INCSR1_FIFO_FLUSH       0x08
#define INCSR1_ISST             0x10
#define INCSR1_STST             0x20
#define INCSR1_CLR_DATA_TOGGLE  0x40
#define INCSR2_ISO              0x20     // ISO �� 
#define INCSR2_MDIN             0x10
#define INCSR2_ASET             0x40


// OUT CONTROL STATUS REGISTER (OUTCSR) (3f008Bh)
#define OUTCSR1_OUT_PKT_RDY     0x01
#define OUTCSR1_OVERRUN         0x02
#define OUTCSR1_XMIT_STALL      0x04
#define OUTCSR1_FLFF            0x10
#define OUTCSR1_ISST            0x20
#define OUTCSR1_STST            0x40
#define OUTCSR1_DATA_TOGGLE     0x80
#define OUTCSR2_ACLR            0x80


//
// Registers : Interrupt Controller
//

#define INT_BASE        0x4A000000
typedef struct  {
    unsigned int  rSRCPND;			//0
    unsigned int  rINTMOD;			//4
    unsigned int  rINTMSK;			//8
    unsigned int  rPRIORITY;		//C
    unsigned int  rINTPND;			//10
    unsigned int  rINTOFFSET;		//14
    unsigned int  rSUBSRCPND;		//18
    unsigned int  rINTSUBMSK;		//1C
}INT_REG ;    


// S3C2410X01 Interrupt controller bit positions

#define    BIT_EINT0        (0x1<<0)
#define    BIT_EINT1        (0x1<<1)
#define    BIT_EINT2        (0x1<<2)
#define    BIT_EINT3        (0x1<<3)
#define    BIT_EINT4_7      (0x1<<4)
#define    BIT_EINT8_23     (0x1<<5)
#define    BIT_RSV1         (0x1<<6)
#define    BIT_BAT_FLT      (0x1<<7)
#define    BIT_TICK         (0x1<<8)
#define    BIT_WDT          (0x1<<9)
#define    BIT_TIMER0       (0x1<<10)
#define    BIT_TIMER1       (0x1<<11)
#define    BIT_TIMER2       (0x1<<12)
#define    BIT_TIMER3       (0x1<<13)
#define    BIT_TIMER4       (0x1<<14)
#define    BIT_UART2        (0x1<<15)
#define    BIT_LCD          (0x1<<16)
#define    BIT_DMA0         (0x1<<17)
#define    BIT_DMA1         (0x1<<18)
#define    BIT_DMA2         (0x1<<19)
#define    BIT_DMA3         (0x1<<20)
#define    BIT_MMC	        (0x1<<21)
#define    BIT_SPI0	        (0x1<<22)
#define    BIT_UART1        (0x1<<23)
#define    BIT_RSV2         (0x1<<24)
#define    BIT_USBD         (0x1<<25)
#define    BIT_USBH         (0x1<<26)
#define    BIT_IIC	        (0x1<<27)
#define    BIT_UART0        (0x1<<28)
#define    BIT_SPI1         (0x1<<29)
#define    BIT_RTC	        (0x1<<30)
#define    BIT_ADC	        (0x1<<31)
#define    BIT_ALLMSK       (0xffffffff)

#define	   BIT_SUB_ADC		(0x1<<10)
#define    BIT_SUB_TC		(0x1<<9)
#define    BIT_SUB_ERR2		(0x1<<8)
#define    BIT_SUB_TXD2		(0x1<<7)
#define    BIT_SUB_RXD2		(0x1<<6)
#define    BIT_SUB_ERR1		(0x1<<5)
#define    BIT_SUB_TXD1		(0x1<<4)
#define    BIT_SUB_RXD1		(0x1<<3)
#define    BIT_SUB_ERR0		(0x1<<2)
#define    BIT_SUB_TXD0		(0x1<<1)
#define    BIT_SUB_RXD0		(0x1<<0)
#define    BIT_SUB_ALLMSK	(0x7ff)


// S3C2410X01 Interrupt controller source number
#define    INTSRC_EINT0     0
#define    INTSRC_EINT1     1
#define    INTSRC_EINT2     2
#define    INTSRC_EINT3     3
#define    INTSRC_EINT4_7   4
#define    INTSRC_EINT8_23  5
#define    INTSRC_RSV1      6
#define    INTSRC_BAT_FLT   7
#define    INTSRC_TICK      8
#define    INTSRC_WDT       9
#define    INTSRC_TIMER0    10
#define    INTSRC_TIMER1    11
#define    INTSRC_TIMER2    12
#define    INTSRC_TIMER3    13
#define    INTSRC_TIMER4    14
#define    INTSRC_UART2     15
#define    INTSRC_LCD       16
#define    INTSRC_DMA0      17
#define    INTSRC_DMA1      18
#define    INTSRC_DMA2      19
#define    INTSRC_DMA3      20
#define    INTSRC_MMC	    21
#define    INTSRC_SPI0	    22
#define    INTSRC_UART1     23
#define    INTSRC_RSV2      24
#define    INTSRC_USBD      25
#define    INTSRC_USBH      26
#define    INTSRC_IIC	    27
#define    INTSRC_UART0     28
#define    INTSRC_SPI1      29
#define    INTSRC_RTC	    30
#define    INTSRC_ADC	    31
#define    INTSRC_ALLMSK    (0xffffffff)

// S3C2410X01 Interrupt controller bit positions
// For SUB source pending bit.

#define 	INTSUB_RXD0		(0x1 << 0)
#define		INTSUB_TXD0		(0x1 << 1)
#define		INTSUB_ERR0		(0x1 << 2)
#define		INTSUB_RXD1		(0x1 << 3)
#define 	INTSUB_TXD1		(0x1 << 4)
#define		INTSUB_ERR1		(0x1 << 5)
#define		INTSUB_RXD2		(0x1 << 6)
#define 	INTSUB_TXD2		(0x1 << 7)
#define		INTSUB_ERR2		(0x1 << 8)
#define		INTSUB_TC		(0x1 << 9)
#define		INTSUB_ADC		(0x1 << 10)
#define 	INTSUB_SLLMSK	(0xFFFFFFFF)

#define		INTSUB_BASE     0x4A000018 // serial
#define		INTSUB_MSK      0x4A00001C // serial
#define		BIT_SUB_ALLMSK	(0x7ff)



//
// Registers : LCD Controller
//

#define LCD_BASE        0x4D000000
typedef struct  {
    unsigned int  rLCDCON1;		// 00
    unsigned int  rLCDCON2;		// 04
    unsigned int  rLCDCON3;		// 08
    unsigned int  rLCDCON4;		// 0C
    unsigned int  rLCDCON5;		// 10
    unsigned int  rLCDSADDR1;	// 14
    unsigned int  rLCDSADDR2;	// 18
    unsigned int  rLCDSADDR3;	// 1C
    unsigned int  rREDLUT;		// 20
    unsigned int  rGREENLUT;	// 24
    unsigned int  rBLUELUT;		// 28
    unsigned int  PAD[8];		// 2C - 48
    unsigned int  rDITHMODE;	// 4C
    unsigned int  rTPAL;		// 50
    unsigned int  rLCDINTPND;	// 54
    unsigned int  rLCDSRCPND;	// 58
    unsigned int  rLCDINTMSK;	// 5C	
    unsigned int  rLPCSEL;		// 60
}LCD_REG ;    
//
//// LCD register value...    
//#define MODE_STN_1BIT 	    (1)
//#define MODE_STN_2BIT  	    (2)
//#define MODE_STN_4BIT  	    (4)
//#define MODE_CSTN_8BIT 	    (108)
//#define MODE_CSTN_12BIT     (112)
//#define MODE_TFT_1BIT       (201)
////#define MODE_TFT_2BIT	    (202)
////#define MODE_TFT_4BIT     (204)
//#define MODE_TFT_8BIT       (208)
//#define MODE_TFT_16BIT      (216)
//
//#define SCR_XSIZE           (640)   //for virtual screen  
//#define SCR_YSIZE           (480)
////#define SCR_XSIZE_TFT       (1280)   //for virtual screen  
////#define SCR_YSIZE_TFT       (960)
//#define SCR_XSIZE_TFT       (480)   //for virtual screen  
//#define SCR_YSIZE_TFT       (640)
//
//
//#define LCD_XSIZE_STN       (320)
//#define LCD_YSIZE_STN       (240)
//#define LCD_XSIZE_CSTN      (320)
//#define LCD_YSIZE_CSTN      (240)
////#define LCD_XSIZE_STN       (240)
////#define LCD_YSIZE_STN       (320)
////#define LCD_XSIZE_CSTN      (240)
////#define LCD_YSIZE_CSTN      (320)
////#define LCD_XSIZE_TFT       (640)	
////#define LCD_YSIZE_TFT       (480)
//#define LCD_XSIZE_TFT       (240)	
//#define LCD_YSIZE_TFT       (320)
//
//
//#define ARRAY_SIZE_STN_1BIT     (SCR_XSIZE/8*SCR_YSIZE)
//#define ARRAY_SIZE_STN_2BIT     (SCR_XSIZE/4*SCR_YSIZE)
//#define ARRAY_SIZE_STN_4BIT     (SCR_XSIZE/2*SCR_YSIZE)
//#define ARRAY_SIZE_CSTN_8BIT    (SCR_XSIZE/1*SCR_YSIZE)
//#define ARRAY_SIZE_CSTN_12BIT   (SCR_XSIZE*2*SCR_YSIZE)
//#define ARRAY_SIZE_TFT_8BIT     (SCR_XSIZE/1*SCR_YSIZE)
//#define ARRAY_SIZE_TFT_16BIT    (SCR_XSIZE*2*SCR_YSIZE)
//
//#define HOZVAL_STN          (LCD_XSIZE_STN/4-1)
//#define HOZVAL_CSTN         (LCD_XSIZE_CSTN*3/8-1)
//#define HOZVAL_TFT          (LCD_XSIZE_TFT-1)
//#define LINEVAL_STN         (LCD_YSIZE_STN-1)
//#define LINEVAL_CSTN        (LCD_YSIZE_CSTN-1)
//#define LINEVAL_TFT         (LCD_YSIZE_TFT-1)
//
//#define MVAL                (13)
//#define MVAL_USED           (0)
//
////STN/CSTN timing parameter for LCBHBT161M(NANYA)
//#define WLH                 (3)
//#define WDLY                (3)
//#define LINEBLANK           (1 &0xff)
//
////TFT timing parameter for V16C6448AB(PRIME VIEW) 
///*
//#define VBPD                ((33-1)&0xff)
//#define VFPD                ((10-1)&0xff)
//#define VSPW                ((2-1) &0x3f)
//
//#define HBPD                ((48-1)&0x7f)
//#define HFPD                ((16-1)&0xff)
//#define HSPW                ((96-1)&0xff)
//*/
//#define VBPD                ((1)&0xff)
//#define VFPD                ((2)&0xff)
//#define VSPW                ((1) &0x3f)
//
//#define HBPD                ((6)&0x7f)
//// 
//#define HFPD                ((2)&0xff)
////#define HSPW                ((3)&0xff)
//#define HSPW                ((4)&0xff)
//
//#define CLKVAL_STN_MONO     (22) 	
//    //69.14hz @60Mhz,WLH=16clk,WDLY=16clk,LINEBLANK=1*8,VD=4 
//#define CLKVAL_STN_GRAY     (12) 	
//    //124hz @60Mhz,WLH=16clk,WDLY=16clk,LINEBLANK=1*8,VD=4  
//#define CLKVAL_CSTN         (8) 	
//    //135hz @60Mhz,WLH=16clk,WDLY=16clk,LINEBLANK=1*8,VD=8  
////#define CLKVAL_TFT          (1)
//#define CLKVAL_TFT          (6)
////#define CLKVAL_TFT          (7)
//    //NOTE: 1)SDRAM should have 32-bit bus width. 
//    //      2)HBPD,HFPD,HSPW should be optimized. 
//    //44.6hz @75Mhz
//    //VSYNC,HSYNC should be inverted
//    //HBPD=48VCLK,HFPD=16VCLK,HSPW=96VCLK
//    //VBPD=33HSYNC,VFPD=10HSYNC,VSPW=2HSYNC
//
//#define M5D(n)              ((n) & 0x1fffff)



//
// ADC
//

#define ADC_BASE            0x58000000

typedef struct {
        unsigned int 	rADCCON;
        unsigned int 	rADCTSC;
        unsigned int	rADCDLY;
        unsigned int 	rADCDAT0;
        unsigned int 	rADCDAT1;
		unsigned int	rADCUPDN;
}ADC_REG ;        


//
// Registers : RTC
//



#define RTC_BASE            0x57000000

typedef struct {
	unsigned int  rPAD1[16]; 	// 00 - 3C
    unsigned int  rRTCCON;		// 40
    unsigned int  rTICINT;
    unsigned int  rPAD2[2];      
    unsigned int  rRTCALM;
    unsigned int  rALMSEC;
    unsigned int  rALMMIN;
    unsigned int  rALMHOUR;
    unsigned int  rALMDAY;
    unsigned int  rALMMON;
    unsigned int  rALMYEAR;
    unsigned int  rRTCRST;
    unsigned int  rBCDSEC;
    unsigned int  rBCDMIN;
    unsigned int  rBCDHOUR;
    unsigned int  rBCDDAY;
    unsigned int  rBCDDATE;
    unsigned int  rBCDMON;
    unsigned int  rBCDYEAR;
} RTC_REG;    


//
// Watch-Dog Timver
//

#define WATCH_BASE          0x53000000

typedef struct {
    unsigned long   rWTCON;
    unsigned long   rWTDAT;
    unsigned long   rWTCNT;
} WATCHreg;

    
//
// SD / MMC 
//

#define MMC_BACE            0x5A000000

typedef struct {
    unsigned int   	rSDICON;						//0x5a000000
		#define	SDCON_SDMMC_RESET	(1 << 8)
		#define	SDCON_CLOCK_MMC	(1 << 5)
		#define	SDCON_FIFO_BIG	(1 << 4)
		#define	SDCON_SDIO_INT	(1 << 3)
		#define	SDCON_READ_WAIT	(1 << 2)
		#define	SDCON_CLOCK_UT	(1 << 0)
    unsigned int   	rSDIPRE;						//0x5a000004
    unsigned int   	rSDICMDARG;						//0x5a000008
    unsigned int   	rSDICMDCON;						//0x5a00000c
		#define	CON_ABORT_CMD		(1 << 12)
		#define	CON_CMD_WITHDATA	(1 << 11)
		#define	CON_LONG_RESP		(1 << 10)
		#define	CON_WAIT_RESP		(1 << 9)
		#define	CON_CMD_START		(1 << 8)
    unsigned int   	rSDICMDSTA;						//0x5a000010
		#define	ST_CRC_FAIL	(1 << 12)
		#define	ST_CMD_END	(1 << 11)
		#define	ST_TIME_OUT	(1 << 10)
		#define	ST_RESP_END	(1 << 9)
		#define	ST_CMD_ON	(1 << 8)
    unsigned int   	rSDIRSP0;						//0x5a000014
    unsigned int   	rSDIRSP1;						//0x5a000018
    unsigned int   	rSDIRSP2;						//0x5a00001c
    unsigned int   	rSDIRSP3;						//0x5a000020
    unsigned int 	rSDIDTIMER;						//0x5a000024
    unsigned int	rSDIBSIZE;						//0x5a000028
    unsigned int 	rSDIDATCON;						//0x5a00002c
#define	DATCON_BURST4	(1 << 24)
#define	DATCON_DATSZ_B	(0 << 22)		//Byte
#define	DATCON_DATSZ_H	(1 << 22)		//Half Word
#define	DATCON_DATSZ_W	(2 << 22)		//Word
#define	DATCON_INT_P	(1 << 20)		//Single Type
#define	DATCON_TARSP	(1 << 19)		//Transfer After Response
#define	DATCON_RACMD	(1 << 18)		//Recieve After Command
#define	DATCON_BACMD	(1 << 17)		//Busy After Command
#define	DATCON_BLOCK	(1 << 16)		//Block Mode
#define	DATCON_WIDBUS	(1 << 15)		//Wide Bus Enable
#define	DATCON_DMA		(1 << 14)		//DMA Enable
#define	DATCON_DTST		(1 << 13)		//Data Transfer Start
#define	DATCON_DTMODE0	(0 << 11)		//NOP
#define	DATCON_DTMODE1	(1 << 11)		//Only Busy Check
#define	DATCON_DTMODE2	(2 << 11)		//Data Recieve Mode
#define	DATCON_DTMODE3	(3 << 11)		//Data Tarnsmit Mode
    unsigned int	rSDIDATCNT;						//0x5a000030
    unsigned int	rSDIDATSTA;						//0x5a000034
#define	DTST_NOBUSY			(1 << 11)		//No Busy Signal
#define	DTST_RWAIT_REQ		(1 << 10)		//Read Request Occured
#define	DTST_IOINT			(1 << 9)		//IO Int Detect
#define	DTST_CRC_ST_FAIL	(1 << 7)		//CRC Status Fail
#define	DTST_CRC_REC_FAIL	(1 << 6)		//Rec CRC Fail
#define	DTST_TIME_OUT		(1 << 5)		//Data Time Out
#define	DTST_TRANS_END		(1 << 4)		//Data Transfer Finished
#define	DTST_BUSY_END		(1 << 3)		//Busy Finished
#define	DTST_TX_DATA_ON		(1 << 1)		//Data Tx in Progress
#define	DTST_RX_DATA_ON		(1 << 0)		//Data Rx in Progress
    unsigned int	rSDIFSTA;						//0x5a000038
#define	FFST_RST		(1 << 16)
#define	FFST_ERR0		(0 << 14)			//Normal
#define	FFST_ERR1		(1 << 14)			//Fifo Fail
#define	FFST_ERR2		(2 << 14)			//Fifo Fail Last Transfer
#define	FFST_ERR3		(3 << 14)			//Reserve
#define	FFST_TFDET		(1 << 13)			//Fifo Available Detect for Tx
#define	FFST_RFDET		(1 << 12)			//Fifo Available Detect for Rx
#define	FFST_TFHALF		(1 << 11)			//Tx Fifo Half Full
#define	FFST_TFEMPTY	(1 << 10)			//Tx Fifo Empty
#define	FFST_RFLAST		(1 << 9)			//Rx Fifo Last data ready
#define	FFST_RFFULL		(1 << 8)			//Rx Fifo Full
#define	FFST_RFHALF		(1 << 7)			//Rx Fifo Half Full
#define	FFST_FFCNT		(63 << 0)			//Number of Data in Fifo
    unsigned int	rSDIINTMSK;						//0x5a00003c
#define	INT_NOBUSY		(1 << 18)			//NoBusy Interrupt enable
#define	INT_RSPCRC		(1 << 17)			//RSP Crc Interrupt enable
#define	INT_CMDSENT		(1 << 16)			//Command Sent Interrupt enable
#define	INT_CMDTOUT		(1 << 15)			//Command Response Timeout Interrupt enable
#define	INT_RSPEND		(1 << 14)			//Command Response Recieve Interrupt enable
#define	INT_RWAITREQ	(1 << 13)			//Read Wait Request Interrupt enable
#define	INT_IOINTDET	(1 << 12)			//IO Interrupt Recieve Interrupt enable
#define	INT_FFFAIL		(1 << 11)			//Fifo Fail Interrupt enable
#define	INT_CRCSTERR	(1 << 10)			//CRC Status Error Interrupt enable
#define	INT_DATRECCRC	(1 << 9)			//data Recieve CRC fail Interrupt enable
#define	INT_DATRETOUT	(1 << 8)			//Data Recieve Timeout Interrupt enable
#define	INT_DATFIN		(1 << 7)			//Data Counter Zero Interrupt enable
#define	INT_BUSYFIN		(1 << 6)			//Only Busy Check Complete Interrupt enable
#define	INT_TFHALF		(1 << 4)			//TX Fifo Fill Half Interrupt enable
#define	INT_TFEMPTY		(1 << 3)			//TX Fifo Empty Interrupt enable
#define	INT_RFLAST		(1 << 2)			//RX Fifo Last data Interrupt enable
#define	INT_RFFULL		(1 << 1)			//RX Fifo Full Interrupt enable
#define	INT_RFHALF		(1 << 0)			//RX Fifo Fill Half Interrupt enable
    unsigned int	rSDIDAT;						//0x5a000040
} MMCreg;




//
// IIC 
//

#define IIC_BASE            0x54000000
typedef struct {
        unsigned int    rIICCON;
        unsigned int    rIICSTAT;
        unsigned int    rIICADD;
        unsigned int    rIICDS;
}IICreg;        



//
// IIS 
//

#define IIS_BASE            0x55000000
typedef struct {
        unsigned int    rIISCON;
        unsigned int    rIISMOD;
        unsigned int    rIISPSR;
        unsigned int    rIISFCON;
        unsigned int    rIISFIFO;
}IIS_REG;        


//----- GPIO Configuration Masks -----
#define ENABLE_I2SSDO					0x00000200
#define ENABLE_I2SSDI					0x00000080
#define ENABLE_I2SCDCLK					0x00000020
#define ENABLE_I2SSCLK					0x00000008
#define ENABLE_I2SLRCLK					0x00000002
#define DISABLE_I2S_PULLUPS				0x0000001F

//----- Register definitions for IISCON control register (global config register) -----
#define LR_CHANNEL_INDEX				0x00000100				// Left/right channel index			(read-only)		
#define TRANSMIT_FIFO_READY				0x00000080				// Indicates transmit FIFO is ready	(read-only)
#define RECEIVE_FIFO_READY				0x00000040				// Indicates receive FIFO is ready	(read-only)
#define TRANSMIT_DMA_REQUEST_ENABLE		0x00000020				// Enables transmit DMA request
#define RECEIVE_DMA_REQUEST_ENABLE		0x00000010				// Enables receive DMA request
#define TRANSMIT_IDLE_CMD				0x00000008				// Pauses transmit
#define RECEIVE_IDLE_CMD				0x00000004				// Pauses receive
#define IIS_PRESCALER_ENABLE			0x00000002				// Enables clock prescaler
#define IIS_INTERFACE_ENABLE			0x00000001				// Enables IIS controller

//----- Register definitions for IISMOD status register (global status register) -----
#define IIS_MASTER_MODE					0x00000000				// Selects master/slave mode
#define IIS_SLAVE_MODE					0x00000100				
#define IIS_NOTRANSFER_MODE				0x00000000				// Selects transfer mode
#define IIS_RECEIVE_MODE				0x00000040
#define IIS_TRANSMIT_MODE				0x00000080
#define IIS_TRANSMIT_RECEIVE_MODE		0x000000C0
#define ACTIVE_CHANNEL_LEFT				0x00000000				// Selects active channel
#define ACTIVE_CHANNEL_RIGHT			0x00000020
#define SERIAL_INTERFACE_IIS_COMPAT		0x00000000				// Selects serial interface format
#define SERIAL_INTERFACE_MSBL_COMPAT	0x00000010
#define DATA_8_BITS_PER_CHANNEL			0x00000000				// Selects # of data bits per channel
#define DATA_16_BITS_PER_CHANNEL		0x00000008				
#define MASTER_CLOCK_FREQ_256fs			0x00000000				// Selects master clock frequency
#define MASTER_CLOCK_FREQ_384fs			0x00000004				
#define SERIAL_BIT_CLOCK_FREQ_16fs		0x00000000				// Selects serial data bit clock frequency
#define SERIAL_BIT_CLOCK_FREQ_32fs		0x00000001				
#define SERIAL_BIT_CLOCK_FREQ_48fs		0x00000002				

//----- Register definitions for IISPSR control register (global config register) -----
//		FORMAT:			bits[9:5] - Prescaler Control A
//						bits[4:0] - Prescaler Control B
//
//						Range: 0-31 and the division factor is N+1 (a.k.a. 1-32)
//
//		The I2SLRCLK frequency is determined as follows:
//
//				I2SLRCLK = CODECLK / I2SCDCLK		and		(prescaler+1) = PCLK / CODECLK
//
//		Thus, rearranging the equations a bit we can see that:
//
//				prescaler = (PCLK / CODECLK) - 1 
//		or
//				prescaler = ((PCLK / (IS2LRCLK * IS2CDCLK)) - 1
//		
// Here are some popular values for IS2LRCLK:
//		
#define IS2LRCLK_800					800
#define IS2LRCLK_11025					11025
#define IS2LRCLK_16000					16000
#define IS2LRCLK_22050					22050
#define IS2LRCLK_32000					32000
#define IS2LRCLK_44100					44100
#define IS2LRCLK_48000					48000
#define IS2LRCLK_64000					64000
#define IS2LRCLK_88200					88200
#define IS2LRCLK_96000					96000
	


//----- Register definitions for IISFCON control register (global config register) -----
#define TRANSMIT_FIFO_ACCESS_NORMAL		0x00000000				// Selects the transmit FIFO access mode
#define TRANSMIT_FIFO_ACCESS_DMA		0x00008000				
#define RECEIVE_FIFO_ACCESS_NORMAL		0x00000000				// Selects the receive FIFO access mode
#define RECEIVE_FIFO_ACCESS_DMA			0x00004000				
#define TRANSMIT_FIFO_ENABLE			0x00002000				// Enables transmit FIFO
#define RECEIVE_FIFO_ENABLE				0x00001000				// Enables receive FIFO

//----- Register definitions for IISFIFO control register (global config register) -----
//		NOTE: This register is used to access the transmit/receive FIFO
#define MAX_TRANSMIT_FIFO_ENTRIES		24
#define MAX_RECEIVE_FIFO_ENTRIES		24



//
// SPI 
//

#define SPI_BASE            0x59000000

typedef struct  {
    unsigned int rSPCON0; 	// 00
    unsigned int rSPSTA0;
    unsigned int rSPPIN0;
    unsigned int rSPPRE0;
    unsigned int rSPTDAT0;	// 10
    unsigned int rSPRDAT0;
    unsigned int rPAD[2];
    unsigned int rSPCON1; 	// 20
    unsigned int rSPSTA1;
    unsigned int rSPPIN1;
    unsigned int rSPPRE1;
    unsigned int rSPTDAT1; 	// 30
    unsigned int rSPRDAT1;
    
}SPI_REG ; 



#endif

#define FRAMEBUFFER_BASE    (0x31d00000)			//800*480*4=1536000(Byte)
#define FRAMEBUFFER_BASE2   (0x31e80000)			//800*480*4=1536000(Byte)

