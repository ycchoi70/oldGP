// KeyDlg.h : �w�b�_�[ �t�@�C��
//

/////////////////////////////////////////////////////////////////////////////
// CKeyDlg �_�C�A���O
#include    "Line.h"

#include "CommThread.h" /* �@�ʐM�p�N���X*/


//#define LcdWidth        352
//#define LcdHeight       256
#define LcdWidth        800
#define LcdHeight       480
//#define LcdWidthByte    LcdWidth/8
//#define LcdByteSize     LcdWidthByte*LcdHeight
#define LcdWidthByte    LcdWidth*4
#define LcdByteSize     LcdWidthByte*LcdHeight

typedef unsigned char uchar;
typedef unsigned int  uint;
typedef char * DIB;

class CKeyDlg : public CDialog
{
// �R���X�g���N�V����
public:
	CKeyDlg(CWnd* pParent = NULL);   // �W���̃R���X�g���N�^
	~CKeyDlg();
	void MouseCheck(int, int, CPoint );
	void DrawPixelLine( CDC* pDc, CLine* pLine );
// �_�C�A���O �f�[�^
	//{{AFX_DATA(CKeyDlg)
	enum { IDD = IDD_KeyPanel };
	CStatic	m_LcdDisply;
	CString	m_strT1;
	CString	m_strT3;
	CString	m_strT2;
	CString	m_strT4;
	CString	m_strLow;
	CString	m_strHigh;
	CString	m_strHold;
	CString	m_strSendData;
	CString	m_strRecData;
	//}}AFX_DATA
    CDC     m_LcdCDC;
    CBitmap m_LcdBmp;
    CWnd*   m_pLcdWnd;
    char*   m_pBitmapBits;

	int m_nPort;          /* �|�[�g*/
	int m_nBaudRate;      /* ���x*/
	int	m_nData;		/* �f�[�^�� */
	int	m_nParity;		/* �p���e�B */

	CCommThread m_ComuPort[4]; /* �A�ʐM�p�N���X*/
	// �I�[�o�[���C�h
	// ClassWizard �͉��z�֐��𐶐����I�[�o�[���C�h���܂��B
	//{{AFX_VIRTUAL(CKeyDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g
	//}}AFX_VIRTUAL
	void SerialInit(HWND m_hWnd);

// �C���v�������e�[�V����
protected:

	// �������ꂽ���b�Z�[�W �}�b�v�֐�
	//{{AFX_MSG(CKeyDlg)
	afx_msg void OnKey0();
	afx_msg void OnKey1();
	afx_msg void OnKey2();
	afx_msg void OnKey3();
	afx_msg void OnKey4();
	afx_msg void OnKey5();
	afx_msg void OnKey6();
	afx_msg void OnKey7();
	afx_msg void OnKey8();
	afx_msg void OnKey9();
	afx_msg void OnKeyBS();
	afx_msg void OnKeyCR();
	afx_msg void OnKeyDown();
	afx_msg void OnKeyESC();
	afx_msg void OnKeyHT();
	afx_msg void OnKeyLeft();
	afx_msg void OnKeyN();
	afx_msg void OnKeyRight();
	afx_msg void OnKeyUpper();
	afx_msg void OnKeyV();
	afx_msg void OnKeyW();
	afx_msg void OnKey();
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnClose();
	afx_msg void OnButtonAm();
	afx_msg void OnButtonDsp();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnChangeEditT1();
	afx_msg void OnKillfocusEditT1();
	afx_msg void OnKillfocusEditT2();
	afx_msg void OnKillfocusEditT3();
	afx_msg void OnKillfocusEditT4();
	afx_msg void OnKillfocusEditLow();
	afx_msg void OnKillfocusEditHigh();
	afx_msg void OnButtonHld();
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	//}}AFX_MSG
    LONG OnPaintLcd( UINT RetInf, LONG ppCDM );
	afx_msg LONG OnCommunication(int,long); /* �BWM_COMM_READ CallBack�֐�*/
	DECLARE_MESSAGE_MAP()
};
