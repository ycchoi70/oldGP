#include    "Mts.h"
#include    "MtsCorep.h"
#include    "MtsMiscp.h"
#include    <stdio.h>

#ifdef	OLD
#ifndef WIN32
int errno= 0;
#endif
#endif
/********************************************************
*                                                       *
*       �D�揇�ʂ̕ύX                                  *
*                                                       *
*       int     priority( int tn, int np )              *
*                                                       *
*       �����F  �^�X�N�̔ԍ��i�P�[�P�Q�V�j              *
*       �����F  �V�D�揇��                              *
*       ���A���F                                      *
*       �ύX�O��        �D�揇��                        *
*                                                       *
********************************************************/
unsigned    _ChangeTaskPriority( int *pParam )
{
    TcbFrm* pTcb;
    unsigned    OldPriority;

    pTcb= &_Tcb[pParam[0]];
    OldPriority= pTcb->Priority;
    if ( pParam[1] >= 0 && pTcb->WaitQue != 0 ) {
        _OffQue( (TcbFrm*)pTcb->WaitQue, pTcb );
        pTcb->Priority= pParam[1];
        _LinkPriorityTcb( (TcbFrm*)pTcb->WaitQue, pTcb, pTcb->Status & 0x7f );
    }
    return OldPriority;
}
void    Lcdprintf( int Line, int Column, char* pFrm, ... )
{
extern  int __cdecl sprintf(char *, const char *, ...);
typedef char *  va_list;
extern	void	TextOutInMenu(int x,int y,char *addr);
    char   Buf[64];
    vsprintf( (char *)Buf, pFrm, (va_list)((&pFrm)+1) );
	TextOutInMenu(Column,Line,Buf);
}

