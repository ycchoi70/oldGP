/****************************************************/
/*    FUNC   : USB Device Handler	                */
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 2009.11.07                           */
/*    Update :                                      */
/****************************************************/
#define	USBDEVDRIVER_PROC
#include <string.h>

//#define	USB_LOG

#include "doscomm.h"
#include "glpdos.h"
#include "doscomm.h"
#include "define.h"
#include "gpstruct.h"
#include "commbuff.h"
#include	"mts.h"
#include "mtscifp.h"
#include    "mtsschdp.h"
#include    "mtsscid.h"
#include	"mail.h"
#include	"usbh.h"
#include	"taskhed.h"
#include	"s2440.h"
#include	"udc_2440.h"
#include	"lp_matrix.h"
#include	"lp_comm.h"
#include	"pcmcia.h"
#include	"kansi.h"

#include "rs232c_pc.h"
#include "iohand.h"
#include "sioprotcol.h"
#include "nand.h"

//#define	LOOP_TEST

//int	UsbSlaveCmdLogIdx;
//int	UsbSlaveCmdLog[0x1000];

int	_UsbDevDrvTaskNo;
int	_UsbDevStrageDrvTaskNo;
char	udcRBuff[0x1000];
char	udcCommRBuff[0x1000];
char	udc1RecBuff[0x100];

UART_STRUCT	_Sci_UsbTbl;


extern	int	StrageDirStartSector;
extern	int	StrageDirSectors;

unsigned char	RespInquiry[36]={
   0x00,                        // Device class
   0x80,                        // RMB BYTE is set by inquiry data
   0x02,                        // ANSI SCSI 2
   0x00,                        // Data format = 0
   0x1F,                        // Additional length 27 byte
   0x00, 0x00, 0x00,
	'A','U','T','O','N','I','C','S',
	' ','U','S','B',' ','F','l','a',
	's','h',' ','D','i','s','k',' ',
	' ','3','A',' ',
};
unsigned char	ReadFormat_data[20]={
	0,0,0,8,
};
unsigned char	Read_cap[8]={
	//Total Sector(4Byte), Byte/Sector(4Byte)
	0x00,0x01,0x00,0x00,0x00,0x00,0x02,0x00
};
unsigned char	RequestSens_Data[18]={
	0x70,0x00,0x00,0x00,0x00,0x00,0x00,0x0a,
};
unsigned char dataBuff[100][0x200];
unsigned char udcWBuff[0x200+32];
unsigned char udcdataWBuff[0x10000+32];

extern	int	MS_USB_InterruptHandler( void );


void	SetSciUsbTbl(void)
{
	memset(&_Sci_UsbTbl,0,sizeof(_Sci_UsbTbl));
	_Sci_UsbTbl.ch= USB_CH0;
	
}


void	UsbDevIntEnable(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
//    volatile IOP_REG    *pIOPRegs = (volatile IOP_REG*)IOP_BASE; 

	pINTRegs->rSRCPND  = BIT_USBD;
	// S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
	if (pINTRegs->rINTPND & BIT_USBD)
		pINTRegs->rINTPND = BIT_USBD;
	pINTRegs->rINTMSK &= ~BIT_USBD;
	
//	pIOPRegs->rEINTMASK &= ~(1<<USB_IRQ);
//	pIOPRegs->rEINTPEND  = (1<<USB_IRQ);		//
}


	int	udc_sect;
	int	udc_slen;
	int	send_idx;
	int	write_len;
	int	write_reclen;
	int	udc_len;
	int	udcKind;

int UsbDevDrvProc(int type)
{
	int	ret= -1;

	if(type == USB_COMM){
		return(0);
	}
	//UDC Send Recieve
	udc_len= GetUsbRcvData(type,udcRBuff);
	if(write_len == 0){
		//Strage Check
		memcpy(udcWBuff,udcRBuff,8);
		udcWBuff[3]= 'S';
		memset(&udcWBuff[8],0,4);		//dCSWDataResidue
		udcWBuff[12]= 0;
//UsbSlaveCmdLog[UsbSlaveCmdLogIdx++]= udcRBuff[15];
//UsbSlaveCmdLogIdx &= 0xfff;

		switch(udcRBuff[15]){
		case SCSI_INQUIRY:						//INQUIRY
			SetWriteBuffer(USB_STRAGE,(unsigned char*)&udcWBuff[0],13);
			IoWrite(USB_STRAGE,(unsigned char*)RespInquiry,36);
			break;
		case SCSI_READ_FORMATCAPACITY:						//Read Format Capacity
			SetWriteBuffer(USB_STRAGE,(unsigned char*)&udcWBuff[0],13);
			IoWrite(USB_STRAGE,(unsigned char*)&ReadFormat_data[0],20);
			break;
		case SCSI_REQUEST_SENSE:						// Request Sens		2011.03.23
			SetWriteBuffer(USB_STRAGE,(unsigned char*)&udcWBuff[0],13);
			IoWrite(USB_STRAGE,(unsigned char*)&RequestSens_Data[0],18);
			break;
		case SCSI_READ_CAPACITY:						// Read Capacity
			SetWriteBuffer(USB_STRAGE,(unsigned char*)&udcWBuff[0],13);
			IoWrite(USB_STRAGE,(unsigned char*)&Read_cap[0],8);
			break;
		case SCSI_READ10:						// READ(10)
			udc_sect= (udcRBuff[17] << 24)+ (udcRBuff[18] << 16)+ (udcRBuff[19] << 8)+ udcRBuff[20];
			udc_slen= ((udcRBuff[22] << 8)+ udcRBuff[23])*512;
			ret= 0;
			udcKind= 0;
//			NAND_Read(udc_sect+FRAFH1_FILE_OFFSET,(unsigned char*)udcdataWBuff,udc_slen);
//			memcpy(&udcdataWBuff[udc_slen],udcWBuff,13);
//			SetWriteBuffer((unsigned char*)&udcdataWBuff[0x40],udc_slen-0x40+13);
//			IoWrite((unsigned char*)&udcdataWBuff[0],udc_slen);
			break;
		case SCSI_WRITE10:						//WRITE(10)
			udc_sect= (udcRBuff[17] << 24)+ (udcRBuff[18] << 16)+ (udcRBuff[19] << 8)+ udcRBuff[20];
			udc_slen= ((udcRBuff[22] << 8)+ udcRBuff[23])*512;
			write_len= udc_slen;
			write_reclen= 0;
			if(write_len > 0x10000){
				write_len= 0x10000;
			}
			break;
		case SCSI_MODE_SENSE6:
			SetWriteBuffer(USB_STRAGE,(unsigned char*)&udcWBuff[0],13);
			IoWrite(USB_STRAGE,(unsigned char*)&Read_cap[0],8);
			break;
//		case SCSI_TEST_UNIT_READY:									//2011.08.25
//			if(LogDevChangeFlag > 0){								//Log Device���ύX���ꂽ���ǂ���
//				udcWBuff[12] |= 2;
//				LogDevChangeFlag= 0;
//			}
//			IoWrite(USB_STRAGE,(unsigned char*)&udcWBuff[0],13);	//2011.08.25
//			break;													//2011.08.25
		default:
			IoWrite(USB_STRAGE,(unsigned char*)&udcWBuff[0],13);
			break;
		}
	}else{
		memcpy(&udcdataWBuff[write_reclen],&udcRBuff[0],udc_len);
		write_reclen += udc_len;
		if(write_reclen >= write_len){
			ret= 0;
			udcKind= 1;
//			NAND_Write(udc_sect+FRAFH1_FILE_OFFSET,(unsigned char*)udcdataWBuff,write_len);
//			write_len= 0;
//			IoWrite((unsigned char*)&udcWBuff[0],13);
		}
	}
	return(ret);
}
int	_UsbDevInterruptProc(void)
{
	int		ret;
	int		rc= 0;
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 



	UsbDeviceStartTime= 0;
	UsbDeviceTimeOut= 0;

	ret= MS_USB_InterruptHandler();
	if(ret > 0){
		if(ret & 1){
			_Sci_UsbTbl.CommRecKind[_Sci_UsbTbl.SioBufIdx]= USB_COMM;
			rc |= 1;
		}
		if(ret & 2){
			ret= UsbDevDrvProc(USB_STRAGE);
			if(ret == 0){
				rc |= 2;
			}
		}
	}


	pINTRegs->rSRCPND  = BIT_USBD;
	if (pINTRegs->rINTPND & BIT_USBD)
		pINTRegs->rINTPND = BIT_USBD;
	return(rc);
}
void	_UsbDevInterruptHandler( void )
{
	int	Ret;
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_USBD;
//	pINTRegs->rSRCPND  = BIT_USBD;
//	pINTRegs->rINTPND = BIT_USBD;

	Ret= _UsbDevInterruptProc();
	if(Ret & 1){
   		_PendingRequest( ID_PAddFlag | _UsbDevDrvTaskNo << 16 | 1 );
	}
	if(Ret & 2){
   		_PendingRequest( ID_PAddFlag | _UsbDevStrageDrvTaskNo << 16 | 1 );
	}
	pINTRegs->rINTMSK &= ~BIT_USBD;
}
void UsbDevHandlerInit(void)
{
	SetSciUsbTbl();

	write_len= 0;
	udc_len= 0;
	write_reclen= 0;
	udc_sect= 0;

}
void UsbDevReset(void)
{
	UsbDevHandlerInit();
	InitUDC();
	UsbDevIntEnable();
}
#ifdef	USB_LOG
int	UsbSlaveLogIdx;
int	UsbSlaveLogCnt[0x80];
unsigned char	UsbSlaveLogBuff[0x80][0x800];
int	UsbSlaveSendLogIdx;
int	UsbSlaveSendLogCnt[0x80][3];
unsigned char	UsbSlaveSendLogBuff[0x80][0x800];
int	protLenidx;
int	protlenData1[0x100][4];
int	testFlag;
#endif
int	ProtocolDataProc(int len,char *buff,UART_STRUCT* _SciTbl)
{
	int	i;
	int	ret= 0;
	int	CommRecKind,idx;

	for(i= 0; i < len; i++){
		ret= ConnectPc(buff[i],_SciTbl,&CommRecKind);
		if(ret >= 0){
			memcpy(_SciTbl->SioRecBuff[_SciTbl->SioBufIdx],_SciTbl->IntSioRecBuff,_SciTbl->IntSioRecCnt);
			_SciTbl->SioRecCnt[_SciTbl->SioBufIdx]= _SciTbl->IntSioRecCnt;
			_SciTbl->RecMode= _SciTbl->IntRecMode;
			_SciTbl->CommResult[_SciTbl->SioBufIdx]= ret;
			_SciTbl->CommRecKind[_SciTbl->SioBufIdx]= CommRecKind;
			_SciTbl->SioBufIdx= (_SciTbl->SioBufIdx+1)&1;
			_SciTbl->IntSioRecCnt= 0;
			_SciTbl->IntRecMode= 0;
			break;
		}
	}
	if(ret < 0){	return(ret);	}
	if(_SciTbl->SioBufIdx == 0){	idx= 1;	}
	else{							idx= 0;	}
#ifdef	USB_LOG
UsbSlaveLogCnt[UsbSlaveLogIdx]= _SciTbl->SioRecCnt[idx];
memcpy(&UsbSlaveLogBuff[UsbSlaveLogIdx++],_SciTbl->SioRecBuff[idx],_SciTbl->SioRecCnt[idx]);
UsbSlaveLogIdx &= 0x7f;
if(_SciTbl->SioRecCnt[idx] > 100){
	testFlag++;
//	if(testFlag == 2){
//		testFlag= 0;
//	}
}


#endif
	memcpy(_SciTbl->RecBuff,_SciTbl->SioRecBuff[idx],_SciTbl->SioRecCnt[idx]);
	_SciTbl->RecCnt= _SciTbl->SioRecCnt[idx];
	_SciTbl->Result= _SciTbl->CommResult[idx];
	_SciTbl->RecKind= _SciTbl->CommRecKind[idx];
	if(_SciTbl->RecCnt > PLC_BUF_MAX){
		_SciTbl->RecCnt= PLC_BUF_MAX;
	}
	//Protocol Check
	if(_SciTbl->RecKind != 0){	//LP
#ifdef	MODELTYPE_LP		//2011.01.19
		switch(_SciTbl->Result){
		case 0:
			_SciTbl->SndCnt= PlcCommCheck((char *)&_SciTbl->RecBuff,(char *)_SciTbl->SndBuff,_SciTbl->RecCnt);
			if(_SciTbl->SndCnt > 0){
			}else if(_SciTbl->SndCnt == 0){
				//ACK���M
				_SciTbl->SndBuff[4]= ACK;
				_SciTbl->SndCnt= 5;
			}else{
				//NAK���M
				_SciTbl->SndBuff[4]= NAK;
				_SciTbl->SndCnt= 5;
			}
			break;
		case 1:		/* ACK��M */
			_SciTbl->SndCnt= RP_CommNext((char *)_SciTbl->RecBuff,(char *)_SciTbl->SndBuff);
			break;
		case 2:		/* NAK��M */
			break;
		case 3:		/* �P�������M */
			break;
		default:
			break;
		}
#endif
	}else{
		if(CommonArea.DownLoadCopyFlag != 0){			//Data Copping 2011.09.23
			_Sci_UsbTbl.SndCnt= 0;
			return(0);;
		}
		ret= PCEditorCommProc(_SciTbl);
		if(ret == 1){
			if(PcDownloadStart == 1){
				SetPCTimeOut(EDIT_DWLD_OUT);		//3s
			}else{
				SetPCTimeOut(EDIT_TIME_OUT);		//15s
			}
		}
	}
	return(ret);
}

void	UsbDevDrv( STTFrm* pSTT )     /* USB Device �h���C�o?�X�N */
{
	int	ret;
	int	udcComm_len;
#ifdef	USB_LOG
extern	void	ClearLogData(void);
extern	int	udc_intkindidx;
extern	int	GetMsWriteIdx(void);
extern	int	GetMsReadIdx(void);
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	ClearLogData();
//	UsbSlaveCmdLogIdx= 0;
#endif

	_UsbDevDrvTaskNo= _RunTaskNo;
	UsbDevReset();
	ClearFlag();
#ifdef	USB_LOG
UsbSlaveLogIdx= 0;
UsbSlaveSendLogIdx= 0;
memset(UsbSlaveSendLogCnt,0,sizeof(UsbSlaveSendLogCnt));
protLenidx= 0;
testFlag= 0;
#endif
	while(1){
		UsbDeviceStartTime= 0;
		WaitFlag(1);
		UsbDeviceStartTime= _TimeMSec;
		UsbDeviceTimeOut= 0;
//		if(_Sci_UsbTbl.CommRecKind[_Sci_UsbTbl.SioBufIdx] == USB_COMM){			//Communication Mode
			udcComm_len= GetUsbRcvData(USB_COMM,udcCommRBuff);
//			if(USBDevTestFlag == 1){	continue;	}
#ifdef	LOOP_TEST
			memcpy(_Sci_UsbTbl.SndBuff,udcCommRBuff,udcComm_len);
			_Sci_UsbTbl.SndCnt= udcComm_len;
			SendUsbData(USB_COMM,(unsigned char*)_Sci_UsbTbl.SndBuff,_Sci_UsbTbl.SndCnt);
#else
			ret= ProtocolDataProc(udcComm_len,udcCommRBuff,&_Sci_UsbTbl);
#ifdef	USB_LOG
			protlenData1[protLenidx][0]= udcComm_len;
			protlenData1[protLenidx][1]= ret;
			protlenData1[protLenidx][2]= pINTRegs->rINTMSK;
			protlenData1[protLenidx][3]= _Sci_UsbTbl.IntSioRecCnt;
			protLenidx= (protLenidx+1) & 0xff;
#endif
			if(ret < 0){	continue;	}
			if(_Sci_UsbTbl.SndCnt > 0){
#ifdef	USB_LOG
UsbSlaveSendLogCnt[UsbSlaveSendLogIdx][0]= _Sci_UsbTbl.SndCnt;
UsbSlaveSendLogCnt[UsbSlaveSendLogIdx][1]= (GetMsWriteIdx() << 16) | udc_intkindidx;
UsbSlaveSendLogCnt[UsbSlaveSendLogIdx][2]= GetMsReadIdx();
memcpy(&UsbSlaveSendLogBuff[UsbSlaveSendLogIdx++],_Sci_UsbTbl.SndBuff,_Sci_UsbTbl.SndCnt);
UsbSlaveSendLogIdx &= 0x7f;
#endif
				SendUsbData(USB_COMM,(unsigned char*)_Sci_UsbTbl.SndBuff,_Sci_UsbTbl.SndCnt);
			}
#endif
//		}else{				//Strage
//			switch(udcKind){
//			case 0:
//				ReadCard(DEV_USER2_DISK,udc_sect,udcdataWBuff,udc_slen);
//				memcpy(&udcdataWBuff[udc_slen],udcWBuff,13);
//				SetWriteBuffer(USB_STRAGE,(unsigned char*)&udcdataWBuff[EP1_PACKET_SIZE],udc_slen-EP1_PACKET_SIZE+13);
//				SendUsbData(USB_STRAGE,(unsigned char*)&udcdataWBuff[0],EP1_PACKET_SIZE);
//				break;
//			case 1:
//				WriteCard(DEV_USER2_DISK,udc_sect,udcdataWBuff,write_len);
//				write_len= 0;
//				SendUsbData(USB_STRAGE,(unsigned char*)&udcWBuff[0],13);
//				break;
//			}
//		}
	}
}
void	UsbDevStrageDrv( STTFrm* pSTT )     /* USB Device �h���C�o?�X�N */
{
	_UsbDevStrageDrvTaskNo= _RunTaskNo;
	ClearFlag();
	while(1){
		WaitFlag(1);
		switch(udcKind){
		case 0:		//Read
			ReadCard(DEV_USER2_DISK,udc_sect,udcdataWBuff,udc_slen);
			memcpy(&udcdataWBuff[udc_slen],udcWBuff,13);
			SetWriteBuffer(USB_STRAGE,(unsigned char*)&udcdataWBuff[EP1_PACKET_SIZE],udc_slen-EP1_PACKET_SIZE+13);
			SendUsbData(USB_STRAGE,(unsigned char*)&udcdataWBuff[0],EP1_PACKET_SIZE);
			break;
		case 1:		//Write
			WriteCard(DEV_USER2_DISK,udc_sect,udcdataWBuff,write_len);
			write_len= 0;
			SendUsbData(USB_STRAGE,(unsigned char*)&udcWBuff[0],13);
			if( (udc_sect >= StrageDirStartSector) &&
				(udc_sect < (StrageDirStartSector+ StrageDirSectors)) ){
				StrageEditFlag= 1;
			}
			break;
		}
	}
}
