/*    $ JBOSN : touch.c, v 0.1 2003/09/01 $    */

/*
 * Copyright (C) 2003    iBOSN systems
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are not permitted completely.
 *
 */

/*
 * Module Name: touch.c
 *
 * Purpose: touch pad interface for graphic system of j-bosn
 */
#define	TOUCH_PROC

#include "sgt.h"
#include "hal_interrupt.h"
#include "s2440.h"
#include "hal_time.h"
//#include "touchapi.h"
#include "touchdrv.h"

#include    "mtsschdp.h"
#include    "mtsscid.h"
#include    "Taskhed.h"
#include    "flash.h"
#include    "touch.h"
#include    "nand.h"


//=====================================================================



#define TSP_SAMPLE_RATE_LOW				100
#define TSP_SAMPLE_RATE_HIGH			100
//#define TSP_SAMPLETICK					(OEM_CLOCK_FREQ / TSP_SAMPLE_RATE_LOW)
#define TSP_SAMPLETICK					0xffff

#define ADCPRS							200

#define TSP_CHANGE						15
//#define TSP_INVALIDLIMIT			    40
#define TSP_INVALIDLIMIT			    20


//#define	TSP_SAMPLE_NUM					4 
#define	TSP_SAMPLE_NUM					3 

int     bTSP_DownFlag;

//=======================================================

//static volatile IOP_REG    *gpIOPregs;
static volatile ADC_REG    *gpADCregs;
static volatile INT_REG    *gpINTregs;
//static volatile PWM_REG    *gpPWMregs;

//===================================================================================
static void	Touch_PowerOn(void)
{
//    volatile CLKPWR_REG*    pCLKPWRregs;
//    pCLKPWRregs = (volatile CLKPWR_REG*)CLKPWR_BASE;

    /* Use TSXM, TSXP, TSYM, TSYP            */
//    gpIOPregs->rGPGCON |=  ((0x3 << 30) | (0x3 << 28) | (0x3 << 26) | (0x3 << 24));

    // use EINT9 to touch interrupt
//    gpIOPregs->rGPGCON &=  ~(0x3 << 2);
//    gpIOPregs->rGPGCON |=  (0x2 << 2);

    //gpIOPregs->rGPGUP  |=  (0x1 << 1);        // pull up disable
//    gpIOPregs->rGPGUP  &=  ~(0x1 << 1);          // pull up enable


//    pCLKPWRregs->rCLKCON |= CLKEN_ADC;


    gpADCregs->rADCDLY =    50000;    

    gpADCregs->rADCCON =    (0        << 14) |    /* A/D Converter Enable               */
                            (ADCPRS   <<  6) |    /* Prescaler Setting                  */
                            (0        <<  3) |    /* Analog Input Channel : 0           */ 
                            (0        <<  2) |    /* Normal Operation Mode              */
                            (0        <<  1) |    /* Disable Read Start                 */
                            (0        <<  0);     /* No Operation                       */

    gpADCregs->rADCTSC =    (0        <<  8) |    /* UD_Sen                             */
                            (1        <<  7) |    /* YMON  1 (YM = GND)                 */
                            (1        <<  6) |    /* nYPON 1 (YP Connected AIN[n])      */
                            (0        <<  5) |    /* XMON  0 (XM = Z)                   */
                            (1        <<  4) |    /* nXPON 1 (XP = AIN[7])              */
                            (0        <<  3) |    /* Pull Up Disable                    */
                            (0        <<  2) |    /* Normal ADC Conversion Mode         */
                            (3        <<  0);     /* Waiting Interrupt                  */


    gpINTregs->rINTSUBMSK  &= ~BIT_SUB_TC;

//    gpINTregs->rINTSUBMSK  |= BIT_SUB_TC;

}

//===================================================================================


static void	Touch_SampleStart(void)
{
//	unsigned int tmp;

//	if(TouchRepeatFlag == 0){	return;	}

//	tmp = gpPWMregs->rTCON & (~(0xf << 16));

//	gpPWMregs->rTCON = tmp | (2 << 16);		/* update TCVNTB3, stop					*/
//	gpPWMregs->rTCON = tmp | (9 << 16);		/* interval mode,  start				*/
}

static void	Touch_SampleStop(void)
{
//	gpPWMregs->rTCON &= ~(1 << 16);			/* Timer3, stop							*/
}

//int	Touch_GetXYFlag;

static int	Touch_GetXY(int *px, int *py)
{
	int i;
	int xsum, ysum;
	int x, y;
	int dx, dy;

//	unsigned int	BefNowTime;

    int    bRet = TRUE;

	xsum = ysum = 0;

//	BefNowTime= Plc1msCnt;

//	Touch_GetXYFlag= 0;

	for (i = 0; i < TSP_SAMPLE_NUM; i++)
	{
//		if(i > 0){
//			while(1){
//				if((Plc1msCnt- BefNowTime) > 2){
//					BefNowTime= Plc1msCnt;
//					break;
//				}
//			}
//		}
//		Wait1ms(10);
//Sleep(2);
	    // mesure X
//        gpIOPregs->rGPGUP  |=  (0x1 << 1);        // pull up disable
		gpADCregs->rADCTSC =	(1		<<	8) |		/* UD_Sen								*/
								(0		<<  7) |		/* YMON  1 (YM = GND)					*/
								(0		<<  6) |		/* nYPON 1 (YP Connected AIN[n])		*/
								(1		<<  5) |		/* XMON  0 (XM = Z)						*/
								(1		<<  4) |		/* nXPON 1 (XP = AIN[7])				*/
								(1      <<  3) |		/* Pull Up Disable						*/
								(0      <<  2) |		/* Auto ADC Conversion Mode				*/
								(1		<<  0);			/* No Operation Mode					*/
		gpADCregs->rADCCON = (gpADCregs->rADCCON & ~(7 << 3)) | (5 << 3) | (1 << 14);				/* ADC channel 5 */
		gpADCregs->rADCCON |= (1 << 0);				/* Start Auto conversion				*/

		while (gpADCregs->rADCCON & 0x1);				/* check if Enable_start is low			*/
		while (!(gpADCregs->rADCCON & (1 << 15)));		/* Check ECFLG							*/
		x = gpADCregs->rADCDAT0;
//Sleep(2);//kprintf("Touch_GetPoint:%x", x);
		if (x & 0x8000) {bRet = FALSE; break;}
		x &= 0x3ff;

//		Wait1ms(10);

        // mesure Y
		gpADCregs->rADCTSC =	(1		<<	8) |		/* UD_Sen								*/
								(1		<<  7) |		/* YMON  1 (YM = GND)					*/
								(1		<<  6) |		/* nYPON 1 (YP Connected AIN[5])		*/
								(0		<<  5) |		/* XMON  0 (XM = Z)						*/
								(0		<<  4) |		/* nXPON 1 (XP = AIN[7])				*/
								(1      <<  3) |		/* Pull Up Disable						*/
								(0      <<  2) |		/* Auto ADC Conversion Mode				*/
								(2		<<  0);			/* No Operation Mode					*/

		gpADCregs->rADCCON = (gpADCregs->rADCCON & ~(7 << 3)) | (7 << 3) | (1 << 14);				/* ADC channel 7 */
		gpADCregs->rADCCON |= (1 << 0);				/* Start Auto conversion				*/

		while (gpADCregs->rADCCON & 0x1);				/* check if Enable_start is low			*/
		while (!(gpADCregs->rADCCON & (1 << 15)));		/* Check ECFLG							*/

		y = gpADCregs->rADCDAT1;
//kprintf(" %x\r\n", y);
		if (y & 0x8000) {bRet = FALSE; break;}
		y = 0x3ff - (y&0x3ff);

		gpADCregs->rADCCON = (gpADCregs->rADCCON & ~(1 << 14));				/* ADC Desable */


//		xsum += x;
//		ysum += y;
//		if(i > 0){
			xsum += y;			//X,Y Change
			ysum += x;

//KeySumDataDigit[KeyDataIn][i-1].x= y; 
//KeySumDataDigit[KeyDataIn][i-1].y= x; 
KeySumDataDigit[KeyDataIn][i].x= y; 
KeySumDataDigit[KeyDataIn][i].y= x; 
//		}
	}



//	*px = xsum / (TSP_SAMPLE_NUM-1);
//	*py = ysum / (TSP_SAMPLE_NUM-1);



//    gpIOPregs->rGPGUP  &=  ~(0x1 << 1);                 // pull up enable
	gpADCregs->rADCTSC =	(1		<<	8) |			/* UD_Sen(UP Interrupt)					*/
							(1		<<  7) |			/* YMON  1 (YM = GND)					*/
							(1		<<  6) |			/* nYPON 1 (YP Connected AIN[n])		*/
							(0		<<  5) |			/* XMON  0 (XM = Z)						*/
							(1		<<  4) |			/* nXPON 1 (XP = AIN[7])				*/
							(0      <<  3) |			/* Pull Up Enable						*/
							(0      <<  2) |			/* Normal ADC Conversion Mode			*/
							(3		<<  0);				/* Waiting Interrupt					*/

	
	
	if (!bRet)
    {
//		bTSP_DownFlag = FALSE;
        return bRet;
    }


	bRet= FALSE;
	dx= abs(KeySumDataDigit[KeyDataIn][0].x- KeySumDataDigit[KeyDataIn][1].x);
	if(dx < TSP_INVALIDLIMIT){
//		Touch_GetXYFlag= 2;
		if(KeySumDataDigit[KeyDataIn][0].x > KeySumDataDigit[KeyDataIn][1].x){
			dx= KeySumDataDigit[KeyDataIn][0].x;
		}else{
			dx= KeySumDataDigit[KeyDataIn][1].x;
		}
		if(abs(dx- KeySumDataDigit[KeyDataIn][2].x) < TSP_INVALIDLIMIT){
			bRet= TRUE;
		}
	}
	if(bRet == TRUE){
//		Touch_GetXYFlag= 3;
		bRet= FALSE;
		dy= abs(KeySumDataDigit[KeyDataIn][0].y- KeySumDataDigit[KeyDataIn][1].y);
		if(dy < TSP_INVALIDLIMIT){
			if(KeySumDataDigit[KeyDataIn][0].y > KeySumDataDigit[KeyDataIn][1].y){
				dy= KeySumDataDigit[KeyDataIn][0].y;
			}else{
				dy= KeySumDataDigit[KeyDataIn][1].y;
			}
			if(abs(dy- KeySumDataDigit[KeyDataIn][2].y) < TSP_INVALIDLIMIT){
				bRet= TRUE;
//				Touch_GetXYFlag= 4;

			}
		}
	}
	if(bRet == TRUE){
//		*px = xsum / (TSP_SAMPLE_NUM-1);
//		*py = ysum / (TSP_SAMPLE_NUM-1);
		*px = xsum / (TSP_SAMPLE_NUM);
		*py = ysum / (TSP_SAMPLE_NUM);
	}
	
	
//kprintf("Touch_GetPoint %x", *px);
//kprintf(" %x\r\n", *py);

//	dx = (*px > x) ? (*px - x) : (x - *px);
//	dy = (*py > y) ? (*py - y) : (y - *py);

//	return ((dx > TSP_INVALIDLIMIT || dy > TSP_INVALIDLIMIT) ? FALSE : TRUE);
	return(bRet);
}



//=================================================================================================
//=================================================================================================
//=================================================================================================
//=================================    EXPORTED FUNCTIONS    ======================================
//=================================================================================================
//=================================================================================================
//=================================================================================================
void	BacklightInitial(void)
{
	Cal_Data.BackCal.Prescaler= 0;
	Cal_Data.BackCal.Devid= 16;
	Cal_Data.BackCal.Count= BACKLIGHT_CNT;
	Cal_Data.BackCal.CmpCnt= BACKLIGHT_CMP;
	FlashWriteSeq((char*)TOUCH_CALIB_AREA,(char*)&Cal_Data,sizeof(Cal_Data));
}

void	TouchCalCheck(void)
{
	char*	mp;

	mp= TakeMemory(0x200);
	//(100.100)->(400,400)Data
	FlashReadSeq(mp,(char*)TOUCH_CALIB_AREA,sizeof(Cal_Data));
	memcpy((char*)&Cal_Data,mp,sizeof(Cal_Data));
	if( ((unsigned int)Cal_Data.CalibPos[0].PosDigitX == (unsigned int)0xffffffff) ||
	    ((unsigned int)Cal_Data.CalibPos[0].PosDigitX == (unsigned int)0) ){
		Cal_Data.CalibPos[0].PosDigitX= 100;
		Cal_Data.CalibPos[0].PosDigitY= 100;
		Cal_Data.CalibPos[0].PosAnalogX= 0x00a6;
		Cal_Data.CalibPos[0].PosAnalogY= 0x011b;
		Cal_Data.CalibPos[1].PosDigitX= 600;
		Cal_Data.CalibPos[1].PosDigitY= 400;
		Cal_Data.CalibPos[1].PosAnalogX= 0x02dc;
		Cal_Data.CalibPos[1].PosAnalogY= 0x030e;
	}
	if( ((unsigned int)Cal_Data.BackCal.Devid == (unsigned int)0xffffffff) ||
    	((unsigned int)Cal_Data.BackCal.Devid == (unsigned int)0) ){
		//Backlit Set
		Cal_Data.BackCal.Prescaler= 0;
		Cal_Data.BackCal.Devid= 16;
		Cal_Data.BackCal.Count= BACKLIGHT_CNT;
		Cal_Data.BackCal.CmpCnt= BACKLIGHT_CMP;
	}

	FreeMail(mp);
	//X-a
	fDx1= (float)(Cal_Data.CalibPos[1].PosDigitX- Cal_Data.CalibPos[0].PosDigitX)/
		  (float)(Cal_Data.CalibPos[1].PosAnalogX- Cal_Data.CalibPos[0].PosAnalogX);
	//X-b
	iDx1_b= Cal_Data.CalibPos[0].PosDigitX- (int)(fDx1*(float)Cal_Data.CalibPos[0].PosAnalogX);
	//Y-a
	fDy1= (float)(Cal_Data.CalibPos[1].PosDigitY- Cal_Data.CalibPos[0].PosDigitY)/
		  (float)(Cal_Data.CalibPos[1].PosAnalogY- Cal_Data.CalibPos[0].PosAnalogY);
	//Y-b
	iDy1_b= Cal_Data.CalibPos[0].PosDigitY- (int)(fDy1*(float)Cal_Data.CalibPos[0].PosAnalogY);
    
}
void	TouchInit( void )
{
#ifdef	WIN32
	Cal_Data.BackCal.Prescaler= 0;
	Cal_Data.BackCal.Devid= 16;
	Cal_Data.BackCal.Count= BACKLIGHT_CNT;
	Cal_Data.BackCal.CmpCnt= BACKLIGHT_CMP;
	 return;
#endif
//    gpIOPregs = (volatile IOP_REG *)IOP_BASE;
    gpADCregs = (volatile ADC_REG *)ADC_BASE;
    gpINTregs = (volatile INT_REG *)INT_BASE;
//    gpPWMregs = (volatile PWM_REG *)PWM_BASE;

    Touch_PowerOn();
//	Timer3_Init();

	InterruptEnableTouch();

	UpDown= 0;

	TouchCalCheck();		//Read Touch Calibration
	
	TouchRepeatFlag= 0;

	return;
}
int	TouchRealUp;
unsigned int	istatus;
int	TouchGetPoint1( unsigned int* pfTipState, int *pUncalX, int *pUncalY)
{
	static int x, y;
	unsigned int	status;
//	unsigned int	istatus;
	int	ret;


	TouchRealUp= 0;
	*pfTipState = TOUCH_SAMPLE_VALID;

//	istatus= gpADCregs->rADCUPDN;
	status= gpADCregs->rADCDAT0;
	status |= gpADCregs->rADCDAT1;
//	if(status & (1 << 15))
	if(istatus & (1 << 1))
	{											//UP State
		bTSP_DownFlag = FALSE;

		gpADCregs->rADCTSC &= 0xff;

		Touch_SampleStop();

		gpADCregs->rADCTSC =	(0		<<	8) |			/* UD_Sen(Down Interrupt)				*/
								(1		<<  7) |			/* YMON  1 (YM = GND)					*/
								(1		<<  6) |			/* nYPON 1 (YP Connected AIN[n])		*/
								(0		<<  5) |			/* XMON  0 (XM = Z)						*/
								(1		<<  4) |			/* nXPON 1 (XP = AIN[7])				*/
								(0      <<  3) |			/* Pull Up Enable						*/
								(0      <<  2) |			/* Normal ADC Conversion Mode			*/
								(3		<<  0);				/* Waiting Interrupt					*/

		*pfTipState = TOUCH_SAMPLE_IGNORE;
		ret= 0;

		KeyDat2PosMainFlag= 0;
		KeyDat2PosFlag= 0;
		TouchRealUp= 1;

	}
	else 
	{
		bTSP_DownFlag = TRUE;

		if (!Touch_GetXY(&x, &y)) {
			*pfTipState |= TOUCH_SAMPLE_IGNORE;
		}

		*pUncalX = x;
		*pUncalY = y;

		*pfTipState |= TOUCH_SAMPLE_DOWN;


		*pfTipState |= TOUCH_SAMPLE_VALID;
		Touch_SampleStart();
		if((x == 0) && (y == 0)){
			ret= 0;
		}else{
			if(istatus & 0x03){			//Up,Down Interrupt
			}else{
				*pUncalX= x;
				*pUncalY= y;
			}
			ret= 1;
		}
	}
	return(ret);
}
//int	TestTouch;
int	_TouchIntProc( int source )
{
	unsigned int	fSample = 0;
	int				RawX, CalX, CalX_Org;
	int				RawY, CalY, CalY_Org;
	int				Ret= -1;
	int	i;

	if(source == 0){
		ScanCnt= -1;
	}
	Smouse= TouchGetPoint1( &fSample, &RawX, &RawY );    // Get the point info
	if((Smouse != 0) && ((fSample &= TOUCH_SAMPLE_IGNORE) == 0)){
		NonCalbX= RawX;
		NonCalbY= RawY;

		CalX_Org= (int)(fDx1 * (float)RawX) + iDx1_b;
		CalY_Org= (int)(fDy1 * (float)RawY) + iDy1_b;

		if(CalX_Org < 0){	CalX_Org= 0;	}
		if(CalX_Org >= GAMEN_X_SIZE){	CalX_Org= GAMEN_X_SIZE-1;	}
		if(CalY_Org < 0){	CalY_Org= 0;	}
		if(CalY_Org >= GAMEN_Y_SIZE){	CalY_Org= GAMEN_Y_SIZE-1;	}
		DigCalbX= CalX_Org;
		DigCalbY= CalY_Org;

//		KeyDataDigit[KeyDataIn].x= CalX_Org;
//		KeyDataDigit[KeyDataIn].y= CalY_Org;

//		KeyRealDataDigit[KeyDataIn].x= RawX;
//		KeyRealDataDigit[KeyDataIn].y= RawY;

//if((CalX == 0) && (CalY == 0)){
//	TestTouch= 0;
//}
//		KeyDataIn++;
//		KeyDataIn &= 3;
		UpDown= 1;
		Ret= 0;
		if(source == 0){		//touch Interrupt
			ScanStartX= DigCalbX;		//First Touch Pos
			ScanStartY= DigCalbY;		//First Touch Pos
			ScanBefX= DigCalbX;
			ScanBefY= DigCalbY;
			ScanCnt= 0;
			KeyDat2PosFlag= 0;
			KeyDat2PosMainFlag= 0;
		}else{					//Scan Interrupt
			if(ScanCnt == -1){
				ScanStartX= DigCalbX;		//First Touch Pos
				ScanStartY= DigCalbY;		//First Touch Pos
				ScanBefX= DigCalbX;
				ScanBefY= DigCalbY;
				ScanCnt= 0;
				KeyDat2PosFlag= 0;
				KeyDat2PosMainFlag= 0;
			}else{
				ScanCnt++;
				CalX= abs(ScanBefX- DigCalbX);
				CalY= abs(ScanBefY- DigCalbY);
				if(ScanCnt >= 3){
					ScanCnt= 0;
					if((CalX > TOUCH_DELTA_X) || (CalY > TOUCH_DELTA_Y)){		//�O��l�Ƃ̕ω�
						CalX= abs(ScanStartX- DigCalbX);
						CalY= abs(ScanStartY- DigCalbY);
						if( ((DigCalbX >= TOUCH_2POS_X_LOW) && (DigCalbX <= TOUCH_2POS_X_HIGH)) ||
							((DigCalbY >= TOUCH_2POS_Y_LOW) && (DigCalbY <= TOUCH_2POS_Y_HIGH)) ){
							KeyDat1stX= ScanStartX;
							KeyDat1stY= ScanStartY;
							if((CalX > TOUCH_DELTA_X) && (CalY > TOUCH_DELTA_Y)){		//�Ίp�^�b�`
								if(ScanStartX < (GAMEN_X_SIZE/2)){
									KeyDat2ndX= GAMEN_X_SIZE-1;
								}else{
									KeyDat2ndX= 0;
								}
								if(ScanStartY < (GAMEN_Y_SIZE/2)){
									KeyDat2ndY= GAMEN_Y_SIZE-1;
								}else{
									KeyDat2ndY= 0;
								}
								if(KeyDat2ndX > (GAMEN_X_SIZE-1)){	KeyDat2ndX= (GAMEN_X_SIZE-1);	}
								if(KeyDat2ndY > (GAMEN_Y_SIZE-1)){	KeyDat2ndY= (GAMEN_Y_SIZE-1);	}
							}else{
								if(CalX > TOUCH_DELTA_X){
									KeyDat2ndY= DigCalbY;
									if(ScanStartX < (GAMEN_X_SIZE/2)){ 
										KeyDat2ndX= GAMEN_X_SIZE-1;
									}else{
										KeyDat2ndX= 0;
									}
								}else{
									KeyDat2ndX= DigCalbX;
									if(ScanStartY < (GAMEN_Y_SIZE/2)){ 
										KeyDat2ndY= GAMEN_Y_SIZE-1;
									}else{
										KeyDat2ndY= 0;
									}
								}
							}
							KeyDat2PosMainFlag= 1;
						}else{
							KeyDat2PosMainFlag= 0;
						}
					}
					ScanBefX= DigCalbX;
					ScanBefY= DigCalbY;
					CalX= abs(ScanStartX- DigCalbX);
					CalY= abs(ScanStartY- DigCalbY);
					if((CalX > TOUCH_DELTA_2X) || (CalY > TOUCH_DELTA_2Y)){		//�O��l�Ƃ̕ω�
						KeyDat2PosFlag= 1;
					}
				}else{
					CalX= abs(ScanStartX- DigCalbX);
					CalY= abs(ScanStartY- DigCalbY);
					if((CalX > TOUCH_DELTA_2X) || (CalY > TOUCH_DELTA_2Y)){		//�O��l�Ƃ̕ω�
						KeyDat2PosFlag= 1;
					}
				}
			}
		}

		KeyDataDigit[KeyDataIn].x= CalX_Org;
		KeyDataDigit[KeyDataIn].y= CalY_Org;

		KeyDataIn++;
//		KeyDataIn &= 3;
		KeyDataIn &= MAX_TOUCH_AREA-1;		//2011.08.25
		

	}else{			//Up
//		if(UpDown != 0){			//Touch Up
		if((UpDown != 0) && (TouchRealUp == 1)){			//Touch Up
			UpDown= 0;
			KeyDataDigit[KeyDataIn].x= 0;
			KeyDataDigit[KeyDataIn].y= 0;

//KeyRealDataDigit[KeyDataIn].x= 0;
//KeyRealDataDigit[KeyDataIn].y= 0;
for(i= 0; i < 4; i++){
KeySumDataDigit[KeyDataIn][i].x= 0; 
KeySumDataDigit[KeyDataIn][i].y= 0; 
}
			
			KeyDataIn++;
//			KeyDataIn &= 3;
			KeyDataIn &= MAX_TOUCH_AREA-1;		//2011.08.25
			
			Ret= 0;
		}
	}
	return(Ret);
}
//unsigned int	SubSrcPnd;
//unsigned int	IntSrcPnd;
int	_TouchInterruptProc( void )
{
//	int	ret= -1;
	int	ret= 0;

	gpINTregs->rINTSUBMSK |= (BIT_SUB_TC | BIT_SUB_ADC);
	gpINTregs->rSUBSRCPND  =  (BIT_SUB_TC | BIT_SUB_ADC);
	gpINTregs->rSRCPND     = (unsigned int)BIT_ADC;	/* Interrupt Clear			*/
	gpINTregs->rINTPND     = (unsigned int)BIT_ADC;

//	if(CommonArea.PcUpDownMode == 0){
//		ret= _TouchIntProc(0);
//	}
	if(DataClearFlag == 1){				//2011.05.26
		ret= -1;
	}

	gpINTregs->rSUBSRCPND  =  BIT_SUB_TC;
	gpINTregs->rINTSUBMSK &= ~BIT_SUB_TC;

	istatus= gpADCregs->rADCUPDN;
	gpADCregs->rADCUPDN= 0;
	gpINTregs->rSRCPND = (unsigned int)BIT_ADC;
	if (gpINTregs->rINTPND & (unsigned int)BIT_ADC)
		gpINTregs->rINTPND = (unsigned int)BIT_ADC;
	gpINTregs->rINTMSK &= ~(unsigned int)BIT_ADC;
	return(ret);

}
void	TouchHandleTsk( STTFrm* pSTT )
{
	int	ret;
	T_MAIL*	mp;
	while(1){
		mp= (T_MAIL*)WaitRequest();
		switch(mp->mcmd){
		case 0:		//Pen Interrupt
			if(CommonArea.PcUpDownMode == 0){
				ret= _TouchIntProc(0);
				if(ret == 0){
					AddFlag(T_KEYHAND,1);
				}
			}
			break;
		case 1:		//Timer Interrupt
			if(CommonArea.PcUpDownMode == 0){
				istatus= 0;
				ret= _TouchIntProc(1);
				if(ret == 0){
					AddFlag(T_KEYHAND,1);
				}
			}
			break;
		case 2:
			GetAD_Power((int *)mp->mptr);
			break;
		}
		ResponseMail((char*)mp);
	}
}
void	TouchDriveTsk( STTFrm* pSTT )
{
	T_MAIL*	mp;

	ClearFlag();
	while(1){
		WaitFlag(1);
		mp= (T_MAIL*)TakeMail();
		mp->mcmd= 0;
		SendMail(T_TOUCH_HAND,(char*)mp);
	}
}
void	TouchTmDriveTsk( STTFrm* pSTT )
{
	T_MAIL*	mp;

	ClearFlag();
	while(1){
		WaitFlag(1);
		mp= (T_MAIL*)TakeMail();
		mp->mcmd= 1;
		SendMail(T_TOUCH_HAND,(char*)mp);
	}
}

void	_TouchInterruptHandler( void )
{
	int	Ret;
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK    |= (unsigned int)BIT_ADC;
	Ret= _TouchInterruptProc();
	if(Ret == 0){
//   		_PendingRequest( ID_PAddFlag | T_KEYHAND << 16 | 1 );
   		_PendingRequest( ID_PAddFlag | T_TOUCH_DRV << 16 | 1 );
	}
	gpINTregs->rINTMSK &= ~(unsigned int)BIT_ADC;
}
int	TouchTimerCheck(void)
{
	int	ret= -1;

	if(bTSP_DownFlag == TRUE){
		ret= 0;
	}
	return(ret);
}
/************************************************************/
/* Touch Driver												*/
/************************************************************/
//void	TouchDriverTsk( STTFrm* pSTT )
//{
//	ClearFlag();
//	while(1){
//		WaitFlag(1);
//		_TouchIntProc(ScanModeFlag);
//		AddFlag(T_KEYHAND,1);
//	}
//}
/************************************************************/
/* Battery Read Driver												*/
/************************************************************/
extern	unsigned int	GetNowTime(void);		/* 20060203 */
int	GetAD_Power(int *adValue)
{
	int i;
	int ad_sum;
	int ad_data;
	int	ret= OK;
//	unsigned	NowTime;
//	unsigned	StartTime;
	unsigned int AdcStatus;

#ifdef	WIN32
	*adValue= 0;
	return(0);
#endif
	ad_sum = 0;

//	StartTime= GetNowTime();

	for (i = 0; i < TSP_SAMPLE_NUM; i++)
	{
		AdcStatus= gpADCregs->rADCTSC;
//		gpADCregs->rADCTSC =	(0		<<	8) |		/* UD_Sen								*/
//								(0		<<  7) |		/* YMON  1 (YM = GND)					*/
//								(0		<<  6) |		/* nYPON 1 (YP Connected AIN[n])		*/
//								(0		<<  5) |		/* XMON  0 (XM = Z)						*/
//								(0		<<  4) |		/* nXPON 1 (XP = AIN[7])				*/
//								(0      <<  3) |		/* Pull Up Disable						*/
//								(0      <<  2) |		/* Auto ADC Conversion Mode				*/
//								(0		<<  0);			/* No Operation Mode					*/
		AdcStatus &= 0xffffff00;
		gpADCregs->rADCTSC= AdcStatus;

		gpADCregs->rADCCON = (gpADCregs->rADCCON & ~(7 << 3)) | (0 << 3) | (1 << 14);				/* ADC channel 0 */
		gpADCregs->rADCCON |= (1 << 0);				/* Start Auto conversion				*/

//		while (gpADCregs->rADCCON & 0x1){				/* check if Enable_start is low			*/
//			NowTime= GetNowTime();
//			if((NowTime- StartTime) > 1000){	//1s Over
//				ret= NG;
//				break;
//			}
//		}
//		while (!(gpADCregs->rADCCON & (1 << 15))){		/* Check ECFLG							*/
//			NowTime= GetNowTime();
//			if((NowTime- StartTime) > 1000){	//1s Over
//				ret= NG;
//				break;
//			}
//		}
		while (gpADCregs->rADCCON & 0x1);				/* check if Enable_start is low			*/
		while (!(gpADCregs->rADCCON & (1 << 15)));		/* Check ECFLG							*/


		ad_data = gpADCregs->rADCDAT0;
		ad_data &= 0x3ff;

		if(i > 0){
	 		ad_sum += ad_data;
		}
	}

	ad_data= ad_sum / (TSP_SAMPLE_NUM-1);

	AdcStatus= gpADCregs->rADCTSC;
//	gpADCregs->rADCTSC =	(1		<<	8) |			/* UD_Sen(UP Interrupt)					*/
	AdcStatus &= 0xffffff00;
	AdcStatus |=			(1		<<  7) |			/* YMON  1 (YM = GND)					*/
							(1		<<  6) |			/* nYPON 1 (YP Connected AIN[n])		*/
							(0		<<  5) |			/* XMON  0 (XM = Z)						*/
							(1		<<  4) |			/* nXPON 1 (XP = AIN[7])				*/
							(0      <<  3) |			/* Pull Up Enable						*/
							(0      <<  2) |			/* Normal ADC Conversion Mode			*/
							(3		<<  0);				/* Waiting Interrupt					*/
	gpADCregs->rADCTSC =	AdcStatus;

	*adValue= ad_data;
	return(ret);
}

