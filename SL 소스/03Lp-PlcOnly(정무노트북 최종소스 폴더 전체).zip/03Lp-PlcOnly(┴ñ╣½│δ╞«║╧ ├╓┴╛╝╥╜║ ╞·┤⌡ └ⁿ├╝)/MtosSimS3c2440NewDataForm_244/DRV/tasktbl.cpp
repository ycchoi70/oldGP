/******************************************************/
/*  ?�X�N?�w�b??                                  */
/*  1999.8.10                                         */
/******************************************************/

#include    "define.h"
#include    "Mts.h"
#include    "MtsCifp.h"
#include	"Taskhed.h"
#include	"s2440.h"
//#include	"bios.h"

int	_MyCpuNo = 1;			/**/
unsigned streg = 0;
unsigned short exvct = 0;	/* Exception trap Vector Number */

//extern	void	HardInitial(void);
extern	void	_ei(void);

/******************************************************/
/*  Application Task                                  */
/******************************************************/
extern	void	IniTask( STTFrm* pSTT );
/*extern	void	SetTask( STTFrm* pSTT );*/
extern	void	DispAnalysis( STTFrm* pSTT );

/******************************************************/
/*  Drawing Task	                                  */
/******************************************************/
extern  void	KeyTask( STTFrm* pSTT );
/*extern  void	FileTask(STTFrm* pSTT );*/
extern  void	AlarmDetail_Task(STTFrm* pSTT );

extern  void    Classification_Task( STTFrm* pSTT );
extern  void	TouchKeyWatch_Task( STTFrm* pSTT );
extern	void	WindowDisplay_Task(STTFrm* pSTT);
/******************************************************/
/*  Handler Task                                      */
/******************************************************/
/******************************************************/
/*  Driver Task ?                                    */
/******************************************************/
extern	void    KeyDrv(STTFrm* pSTT);
extern	void    KeyHand(STTFrm* pSTT );
extern	void    RTCDrv(STTFrm* pSTT );
extern	void	PcState( STTFrm* pSTT );
extern	void	PlcState( STTFrm* pSTT );
extern	void	Plc2State( STTFrm* pSTT );
extern	void	PlcHand( STTFrm* pSTT );
extern	void	Plc2Hand( STTFrm* pSTT );
extern	void	FloatState( STTFrm* pSTT );
extern	void	BuzDrv(STTFrm* pSTT);

extern	void	PlcSendRec( STTFrm* pSTT );
extern	void	Sio0Drv( STTFrm* pSTT );
extern	void	Sio0RecDrv( STTFrm* pSTT );
extern	void	Sio1Drv( STTFrm* pSTT );
extern	void	Sio1RecDrv( STTFrm* pSTT );
extern	void    RtcHand( STTFrm* pSTT );

extern	void	MsgTask( STTFrm* pSTT );
extern	void    DebugTask( STTFrm* pSTT );         /* ����������?�X�N */

extern	void	ObservTask( STTFrm* pSTT );
extern	void	ScreenState( STTFrm* pSTT );
extern	void	TimeSwitchTask( STTFrm* pSTT );
extern	void	PlcConnChk( STTFrm* pSTT );
extern	void	PlcMainTask(STTFrm* pSTT);


void	PlcTimIntTask( STTFrm* pSTT );		//Plc Timer 
void PlcIntrruptTask(STTFrm* pSTT);


void	UsbHostDrv( STTFrm* pSTT );			/* USB HOST�h���C�o?�X�N */
void	UsbHostHandler( STTFrm* pSTT );     /* USB HOST Read/Write �n���h��? */
void	UsbDevDrv( STTFrm* pSTT );			/* USB Device �h���C�o?�X�N */
void	NandHandler( STTFrm* pSTT );	    /* NAND Read/Write �n���h��? */

void	DosFileTask( STTFrm* pSTT );
void	LanDriverTsk( STTFrm* pSTT );     /* LAN �h���C�o? */
//void	LanHandleTsk( STTFrm* pSTT );

void	TouchHandleTsk( STTFrm* pSTT );
void	TouchDriveTsk( STTFrm* pSTT );
void	TouchTmDriveTsk( STTFrm* pSTT );

void	UsbDevStrageDrv( STTFrm* pSTT );     /* USB Device �h���C�o?�X�N */

/******************************************************/
/*  Interrupt? ?                                    */
/******************************************************/
#ifdef	WIN32
extern  interrupt   void    _SystemClockInterruptHandler( void );   /* �V�X�e??�C? */

#else

extern  void    _SystemClockInterruptHandler( void );   /* �V�X�e??�C? */


#endif
/******************************************************/
/*  STACK�̈�  ?                                    */
/******************************************************/
#ifdef	WIN32
	unsigned char	KeyDrvStack[8192];
	unsigned char	RTCDrvStack[8192];
	unsigned char	BuzDrvStack[8192];
	unsigned char	Sio0DrvStack[8192];
	unsigned char	Sio0RecDrvStack[8192];
	unsigned char	Sio1DrvStack[8192];
	unsigned char	Sio1RecDrvStack[8192];
	unsigned char	KeyHandStack[8192];
	unsigned char	Plc2HandStack[8192];
	unsigned char	PlcHandStack[8192];
	unsigned char	RtcHandStack[8192];
	unsigned char	PcStateStack[8192];
	unsigned char	PlcStateStack[8192];
/*	unsigned char	Plc2StateStack[8192];*/
	unsigned char	FloatStateStack[8192];
	unsigned char	MsgTaskStack[8192];
	unsigned char	DebugTaskStack[8192];
#ifdef	MODELTYPE_GP		//2011.07.19
	unsigned char	ObservTaskStack[8192];
#endif
/*	unsigned char	ScreenStateStack[8192];*/
	unsigned char	TimeSwitchTaskStack[8192];

/*********************************/
	unsigned char	IniTaskStack[8192];
/*	unsigned char	SetTaskStack[8192];*/
	unsigned char	DispAnalysisStack[8192];
/*	unsigned char	FileReadStack[8192];*/
	unsigned char   Classification_Stack[8192];
	unsigned char   AlarmDetail_Stack[8192];
	unsigned char   WindowDisplay_Task_Stack[8192];

	unsigned char   PlcConnChk_Stack[8192];
#ifdef	MODELTYPE_LP		//2011.01.19
	unsigned char   PlcMainTaskStack[8192];
	unsigned char	PlcTimIntTaskStack[8192];
	unsigned char	PlcIntrruptTaskStack[8192];
#endif

	unsigned char	UsbHostDrvStack[8192];
	unsigned char	UsbHostHandlerStack[8192];
	unsigned char	UsbDevDrvStack[8192];
	unsigned char	NandHandlerStack[8192];
	unsigned char	DosFileTaskStack[8192];
	unsigned char	LanDriverTskStack[8192];
//	unsigned char	LanHandleTskStack[4096];
	unsigned char	TouchHandleTskStack[4096];
	unsigned char	TouchDrvTskStack[4096];
	unsigned char	TouchTmDrvTskStack[4096];

	unsigned char	UsbDevStrageDrvStack[4096];

#else
	unsigned char	KeyDrvStack[4096];
	unsigned char	RTCDrvStack[4096];
	unsigned char	BuzDrvStack[4096];
	unsigned char	Sio0DrvStack[4096];
	unsigned char	Sio0RecDrvStack[4096];
	unsigned char	Sio1DrvStack[4096];
	unsigned char	Sio1RecDrvStack[4096];
	unsigned char	KeyHandStack[4096];
	unsigned char	Plc2HandStack[4096];
	unsigned char	PlcHandStack[4096];
	unsigned char	RtcHandStack[4096];
	unsigned char	PcStateStack[4096];
	unsigned char	PlcStateStack[4096];
/*	unsigned char	Plc2StateStack[4096];*/
	unsigned char	FloatStateStack[4096];
	unsigned char	MsgTaskStack[4096];
	unsigned char	DebugTaskStack[4096];
#ifdef	MODELTYPE_GP		//2011.07.19
	unsigned char	ObservTaskStack[4096];
#endif
/*	unsigned char	ScreenStateStack[4096];*/
	unsigned char	TimeSwitchTaskStack[4096];

/*********************************/
	unsigned char	IniTaskStack[8192];
/*	unsigned char	SetTaskStack[4096];*/
	unsigned char	DispAnalysisStack[4096];
/*	unsigned char	FileReadStack[4096];*/
	unsigned char   Classification_Stack[4096];
	unsigned char   AlarmDetail_Stack[4096];
	unsigned char   WindowDisplay_Task_Stack[4096];

	unsigned char   PlcConnChk_Stack[4096];
#ifdef	MODELTYPE_LP		//2011.01.19
	unsigned char   PlcMainTaskStack[4096];
	unsigned char	PlcTimIntTaskStack[4096];
	unsigned char	PlcIntrruptTaskStack[4096];
#endif

	unsigned char	UsbHostDrvStack[4096];
	unsigned char	UsbHostHandlerStack[4096];
	unsigned char	UsbDevDrvStack[4096];
	unsigned char	NandHandlerStack[4096];
	unsigned char	DosFileTaskStack[4096];
	unsigned char	LanDriverTskStack[4096];
//	unsigned char	LanHandleTskStack[4096];
	unsigned char	TouchHandleTskStack[4096];
	unsigned char	TouchDrvTskStack[4096];
	unsigned char	TouchTmDrvTskStack[4096];

	unsigned char	UsbDevStrageDrvStack[4096];
	
	
#endif
const	STTFrm  _StaticTaskTableUsr[]= { 
{ "INIT  TASK    ", T_INITASK,			0x05, 0, 0, IniTask,				{0,0,0}, IniTaskStack,				sizeof(IniTaskStack)			},
//{ "CLASSIFY TASK ", T_CLASSIFICATION,	0x19, 0, 0, Classification_Task,	{0,0,0}, Classification_Stack,		sizeof(Classification_Stack)	},
//{ "DISPLAY TASK  ", T_DISPANALYSIS,		0x18, 0, 0, DispAnalysis,			{0,0,0}, DispAnalysisStack,			sizeof(DispAnalysisStack)		},
//{ "DISPLAY TASK  ", T_DISP_TASK,		0x18, 0, 0, WindowDisplay_Task,		{0,0,0}, WindowDisplay_Task_Stack,	sizeof(WindowDisplay_Task_Stack)},
{ "Key Drive     ", T_KEY,				0x17, 0, 0, KeyDrv,					{0,0,0}, KeyDrvStack,				sizeof(KeyDrvStack)				},
{ "Buzzer Drive  ", T_BZRDRV,			0x13, 0, 0, BuzDrv,					{0,0,0}, BuzDrvStack,				sizeof(BuzDrvStack)				},
{ "Key Hand      ", T_KEYHAND,			0x15, 0, 0, KeyHand,				{0,0,0}, KeyHandStack,				sizeof(KeyHandStack)			},
//Master is 15,Slave is 19
{ "Sio0 Drive    ", T_SIO422DRV,		0x15, 0, 0, Sio0Drv,				{0,0,0}, Sio0DrvStack,				sizeof(Sio0DrvStack)			},
{ "Sio0 RecDrive ", T_SIO422RCV,		0x13, 0, 0, Sio0RecDrv,				{0,0,0}, Sio0RecDrvStack,			sizeof(Sio0RecDrvStack)			},
//Master is 15,Slave is 19
{ "Sio1 Drive    ", T_SIO232DRV,		0x15, 0, 0, Sio1Drv,				{0,0,0}, Sio1DrvStack,				sizeof(Sio1DrvStack)			},
{ "Sio1 RecDrive ", T_SIO232RCV,		0x13, 0, 0, Sio1RecDrv,				{0,0,0}, Sio1RecDrvStack,			sizeof(Sio1RecDrvStack)			},
{ "RTC Drive     ", T_RTCDRV,			0x15, 0, 0, RTCDrv,					{0,0,0}, RTCDrvStack,				sizeof(RTCDrvStack)				},
{ "RTC Hand      ", T_RTCHAND,			0x14, 0, 0, RtcHand,				{0,0,0}, RtcHandStack,				sizeof(RtcHandStack)			},
{ "PLC Hand      ", T_PLCHAND,			0x15, 0, 0, PlcHand,				{0,0,0}, PlcHandStack,				sizeof(PlcHandStack)			},
{ "PLC Hand2     ", T_PLCHAND2,			0x16, 0, 0, Plc2Hand,				{0,0,0}, Plc2HandStack,				sizeof(Plc2HandStack)			},
{ "PC State      ", T_PCKANSI,			0x18, 0, 0, PcState,				{0,0,0}, PcStateStack,				sizeof(PcStateStack)			},
{ "PLC State     ", T_PLCKANSI,			0x19, 0, 0, PlcState,				{0,0,0}, PlcStateStack,				sizeof(PlcStateStack)			},
//{ "Floating Alarm", T_FLTKANSI,			0x17, 0, 0, FloatState,				{0,0,0}, FloatStateStack,			sizeof(FloatStateStack)			},
//{ "Msg Task      ", T_MSG_TASK,			0x21, 0, 0, MsgTask,				{0,0,0}, MsgTaskStack,				sizeof(MsgTaskStack)			},
{ "Debug Task    ", T_DEBUG,			0x21, 0, 0, DebugTask,				{0,0,0}, DebugTaskStack,			sizeof(DebugTaskStack)			},
#ifdef	MODELTYPE_GP		//2011.07.19
{ "Project St Tsk", T_OBSERV,			0x20, 0, 0, ObservTask,				{0,0,0}, ObservTaskStack,			sizeof(ObservTaskStack)			},
#endif
{ "Time Prc Task ", T_TIME_PROC,		0x14, 0, 0, TimeSwitchTask,			{0,0,0}, TimeSwitchTaskStack,		sizeof(TimeSwitchTaskStack)		},

{ "Plc Cont Task ", T_PLCCON,			0x1f, 0, 0, PlcConnChk,				{0,0,0}, PlcConnChk_Stack,			sizeof(PlcConnChk_Stack)		},
#ifdef	MODELTYPE_LP		//2011.01.19
{ "Plc Main Task ", T_PLCMAIN,			0x14, 0, 0, PlcMainTask,			{0,0,0}, PlcMainTaskStack,			sizeof(PlcMainTaskStack)		},
{ "GLP Time Task ", T_PLCTINT_TASK,		0x13, 0, 0, PlcTimIntTask,			{0,0,0}, PlcTimIntTaskStack,		sizeof(PlcTimIntTaskStack)		},
{ "GLP INT  Task ", T_PLCINTTASK,		0x13, 0, 0, PlcIntrruptTask,		{0,0,0}, PlcIntrruptTaskStack,		sizeof(PlcIntrruptTaskStack)	},
#endif
{ "USB Dev Driv  ", T_USB_DDRV,			0x13, 0, 0, UsbDevDrv,				{0,0,0}, UsbDevDrvStack,			sizeof(UsbDevDrvStack)			},
{ "NAND Handler  ", T_NAND_HAND,		0x18, 0, 0, NandHandler,			{0,0,0}, NandHandlerStack,			sizeof(NandHandlerStack)		},

{ "USB Host Driv ", T_USB_HDRV,			0x18, 0, 0, UsbHostDrv,				{0,0,0}, UsbHostDrvStack,			sizeof(UsbHostDrvStack)			},
{ "USB Host Hand ", T_USB_HHAND,		0x18, 0, 0, UsbHostHandler,			{0,0,0}, UsbHostHandlerStack,		sizeof(UsbHostHandlerStack)		},

{ "Dos File Ctl  ", T_DOS_FILE,			0x18, 0, 0, DosFileTask,			{0,0,0}, DosFileTaskStack,			sizeof(DosFileTaskStack)		},
{ "Lan Driver    ", T_LAN_DRV,			0x18, 0, 0, LanDriverTsk,			{0,0,0}, LanDriverTskStack,			sizeof(LanDriverTskStack)		},
//{ "Lan Driver    ", T_LAN_HAND,			0x18, 0, 0, LanHandleTsk,			{0,0,0}, LanHandleTskStack,			sizeof(LanHandleTskStack)		},

{ "Touch Handler ", T_TOUCH_HAND,		0x18, 0, 0, TouchHandleTsk,			{0,0,0}, TouchHandleTskStack,		sizeof(TouchHandleTskStack)		},
{ "Touch Handler ", T_TOUCH_DRV,		0x18, 0, 0, TouchDriveTsk,			{0,0,0}, TouchDrvTskStack,			sizeof(TouchDrvTskStack)		},
{ "Touch Handler ", T_TCH_TM_DRV,		0x18, 0, 0, TouchTmDriveTsk,		{0,0,0}, TouchTmDrvTskStack,		sizeof(TouchTmDrvTskStack)		},

{ "USB Dev Driv  ", T_USB_SRG_DDRV,		0x13, 0, 0, UsbDevStrageDrv,		{0,0,0}, UsbDevStrageDrvStack,		sizeof(UsbDevStrageDrvStack)	},
{ 0, }
};
SMTFrm  _SMT[]= {
    { 256, 0x00000040 }, /* ?   64�̃�?���� 256�� = 16KB      */
    {  32, 0x00000080 }, /* ?  128�̃�?���� 200�� =  4KB      */
    {  32, 0x00000400 }, /*   ?1K�̃�?����   32�� = 32KB      */
	{   8, 0x00000800 }, /*   ?2�j�̃�?����   8�� = 16KB      */
    {   8, 0x00001000 }, /*   ?4�j�̃�?����   8�� = 32KB      */
    {   8, 0x00002000 }, /*   ?�W�j�̃�?����  8�� = 64KB      */
    {  10, 0x00010000 }, /*   ?64�j�̃�?���� 10�� =640KB      */
    {   2, 0x00040000 }, /*   ?256�j�̃�?���� 2�� =512KB      */
//    {   2, 0x000c0000 }, /*     768�j�̃�?���� 2�� =1536KB      */
//    {   2, 0x00100000 }, /*    1000�j�̃�?���� 2�� =2000KB      */
    {   3, 0x00180000 }, /*    1536�j�̃�?���� 1�� =1536KB      */
//    {   1, 0x00200000 }, /*    1536�j�̃�?���� 1�� =2048KB      *///2022.09.21 Add
    {   0, 0x00000000 }  /*		�I���̂��邵            KB    ?*/
};
char*  _MailAreaLast;
//char   _MailArea[(16+4+32+16+32+64+640+512+1536+1536)*1024+((256+32+32+8+8+8+10+2+2+1)*32)];		/* KB + ��?���̐�*32   total*/
char   _MailArea[(16+4+32+16+32+64+640+512+4608)*1024+((256+32+32+8+8+8+10+2+3)*32)];		/* KB + ��?���̐�*32   total*/


#ifdef	WIN32
VctFrm  _InterruptVectorTable[]= {
    { 0x1f, _SystemClockInterruptHandler  },
#else
const	VctFrm  _InterruptVectorTable[]= {
#endif
    { 0x00, 0                             }
};
