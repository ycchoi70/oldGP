#include	"ctype.h"
#include	"sgt.h"
#include "s2440.h"

#define	END_CHAR		0x0D
#define	TYPE_BYTE		1
#define	TYPE_WORD		2
#define	TYPE_LONG		4
#define	NO_LOGIN		0x00		/* ���O�C�����Ă��Ȃ� */
#define	RR_LOGIN		0x01		/* ���O�C��?����(Ready) */
#define	OK_LOGIN		0x10		/* ���O�C������ */
/**	�������R?���h		**/
#define	UDCMD_0			0x00
#define	UDCMD_RC		0x08	/* SendCamera Command */
#define	UDCMD_IO		0x09	/* I/O Test */
#define	UDCMD_FPGA		0x0A	/* FPGA Register Write */
#define UDCMD_GO		0x0E	/* Do Program Continue */
#define UDCMD_BR		0x0F	/* Break Point Address */
/**	����n�R?���h		**/
#define UDCMD_MEM_R		0x11	/* Memory Read */
#define	UDCMD_MEM_W		0x12	/* Memory Write */
#define UDCMD_MEM_D		0x13	/* Memory Dump */
#define UDCMD_MEM_F		0x14	/* Memory Fill */
#define	UDCMD_MEM_S		0x15	/* Memory Subs */
#define UDCMD_AN		0x16	/* A/D Read */
#define UDCMD_TS		0x17	/* Temp Sensor Read */
/**	����R?���h		**/
#define UDCMD_PLOAD		0x80	/* Program Load */
#define	UDCMD_FLOAD		0x81	/* IDP FPGA Data Load */
/** �V�X�e?�n�R?���h	**/
#define UDCMD_NO_CMD	0xF0	/* NO COMMAND */
#define UDCMD_VER		0xF1	/* About */
#define UDCMD_HELP		0xF2	/* Command Help */
#define UDCMD_CHELP		0xF3	/* Camera Command Help */
#define UDCMD_ECHO		0xF4	/* Echo On */
#define UDCMD_ECHOOF	0xF5	/* Echo Off */
#define UDCMD_LF		0xF6	/* LF On */
#define UDCMD_LFOF		0xF7	/* LF Off */
#define	UDCMD_FACT		0xF8	/* Entry Factory Mode */
#define UDCMD_EXIT		0xFF	/* Quit */

extern	char	*GP_SYSVER;


static	UART_STRUCT*	SciTbl;

extern	int	HexLoad(void);

int	IsHexDigit(unsigned char c)
{
	if((c >= '0') && (c <= '9')){
		return(TRUE);
	}
	if((c >= 'A') && (c <= 'F')){
		return(TRUE);
	}
	if((c >= 'a') && (c <= 'f')){
		return(TRUE);
	}
	return(FALSE);
}
/* For Lib */
unsigned int atolx( unsigned long *data, unsigned char *ptr )
{
	unsigned int dat= 0;
	unsigned char *org= ptr;

	*data= 0;
	while( IsHexDigit( *ptr ) != 0 ){
		if(      '0' <= *ptr && *ptr <= '9' ){	dat= *ptr- '0';	}
		else if( 'A' <= *ptr && *ptr <= 'F' ){	dat= *ptr- 'A'+ 10;	}
		else if( 'a' <= *ptr && *ptr <= 'f' ){	dat= *ptr- 'a'+ 10;	}
		*data= *data* 16+ dat;
		ptr++;
	}
	return( ptr == org ? FALSE : TRUE );
}

/* For Lib */
unsigned int IsSpeace( unsigned char ch )
{
	switch( ch ){
	case ' ':	return( TRUE );
	case '\0':	return( TRUE );
	case '\a':	return( TRUE );
	case '\r':	return( TRUE );
	case '\n':	return( TRUE );
	case '\t':	return( TRUE );
	}
	return( FALSE );
}

/* For Lib */
unsigned char *SkipNextWord( unsigned char *ptr )
{
	for( ;; ptr++ ){ 
		if( *ptr == ' '  ){		break;			}
		if( *ptr == '\0' ){		return( ptr );	}
		if( *ptr == END_CHAR ){	return( ptr );	}
	}
	ptr++;
	return( ptr );
}
/************************************************************/
/*	���b�Z?�W���M											*/
/************************************************************/
void DModeSendMsg( char *ptr )
{
	SciTbl->SndCnt= strlen(ptr);
	strcpy((char *)SciTbl->SndBuff,ptr);
	SendPCData(SciTbl->SndBuff,SciTbl->SndCnt);
}

/************************************************************/
/*	�v�����v�g���M											*/
/************************************************************/
void DModeSendPronpt( void ){	DModeSendMsg( ">" );	}
void DModeSendPriod( void ){	DModeSendMsg( "." );	}

/************************************************************/
/*	���s���M												*/
/************************************************************/
void DModeSendCR( void )
{
	SciTbl->SndBuff[0] = 0x0a;
	SciTbl->SndBuff[1] = 0x0d;
	SciTbl->SndCnt= 2;
	SendPCData(SciTbl->SndBuff,SciTbl->SndCnt);
}

/************************************************************/
/*	���b�Z?�W���M�i�v�����v�g?���t���j					*/
/************************************************************/
void DModeSendOneMsg( char *ptr )
{
	DModeSendMsg( ptr );

	DModeSendCR();
	DModeSendPronpt();
}

/************************************************************/
/*	Welcome���b�Z?�W���M									*/
/************************************************************/
void DModeSendLoginMsg( void )
{
	DModeSendCR();
	DModeSendPronpt();
	DModeSendOneMsg( "Welcome GP Debug Program" );
}

/************************************************************/
/*	�R?���h�G��?���b�Z?�W���M							*/
/************************************************************/
void DModeSendCmdErr( unsigned char *pCmd )
{
	char buf[80];
	
	sprintf( buf, "COMMAND ERROR" );
	DModeSendOneMsg( buf );
}

/************************************************************/
/*	Quit���b�Z?�W���M										*/
/************************************************************/
void DModeSendQuitMsg( void )
{
	DModeSendMsg( "Bye Bye" );
	DModeSendCR();
}
/************************************************************/
/*	�o?�W�����ԍ����M										*/
/************************************************************/
void DModeSendVersion( void )
{
	DModeSendOneMsg( GP_SYSVER );
}

/************************************************************/
/*	Help���b�Z?�W���M										*/
/************************************************************/
void DModeSendHelpMsg( void )
{
	unsigned int i;
	char *HelpMsg[]= {
		" Q | QUIT : Quit this program and go to main program",
		" _ | VER  : View program version",
		" D | DUMP : View memory by byte, word, long word",
		"              D[B|W|L] [s-adr] [e-adr|\\size]",
//		" E | SUBS : Edit memory by byte, word, long word",
//		"              E[B|W|L] [s-adr] [data] [data] ...",
//		"              E : Edit mode (^=adr-1, enter=adr+1, .=exit)",
//		" F | FILL : Fill memory by word",
//		"              F <s-adr> <\\size> <s-data> <inc-data>",
		" R[B|W|L] : Read memory one byte, word, long word",
		" W[B|W|L] : Write memory one byte, word, long word",
		" PLOAD    : Download program by motorola hex format",
		" FLOAD    : Download FPGA configration data by intel hex format",
//		" GACFG    : Execute FPGA Configration",
		" ? | HELP : View this help message",
	};
	
	for( i= 0; i < TBQ(HelpMsg); i++ ){
		DModeSendMsg( HelpMsg[i] );
		DModeSendCR();
	}
	DModeSendPronpt();
}
#ifdef	OLD		//2008.04.07
/************************************************************/
/*	Cam Help���b�Z?�W���M									*/
/************************************************************/
void DModeSendCamHelpMsg( void )
{
	unsigned int i;
	char *HelpMsg[]= {
		"CAM HELP      : CAM HELP.",
	};
	
	for( i= 0; i < TBQ(HelpMsg); i++ ){
		DModeSendMsg( HelpMsg[i] );
		DModeSendCR();
	}
	DModeSendPronpt();
}
/************************************************************/
/*	��������?�h�����֐�									*/
/************************************************************/
unsigned int DModeMemoryRead( unsigned char *pCmd )
{
	unsigned int ret= TRUE;
	unsigned int type;
	unsigned long adr;
	char buf[80];

	if( ret == TRUE ){				/* �R?���h */
		pCmd++;
		switch( *pCmd ){
		case ' ':	type= TYPE_WORD;	break;
		case 'B':	type= TYPE_BYTE;	break;
		case 'W':	type= TYPE_WORD;	break;
		case 'L':	type= TYPE_LONG;	break;
		default:	ret= FALSE;			break;
		}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){				/* �A�h���X */
		atolx( &adr, pCmd );
		adr  &= 0xfffffffe;
	}
	if( ret == TRUE ){				/* ���� */
		switch( type ){
		case TYPE_BYTE:
			sprintf( buf, "%08X:%02X", adr, (unsigned char )*((unsigned char  *)adr) );
			break;
		case TYPE_WORD:
			sprintf( buf, "%08X:%04X", adr, (unsigned short)*((unsigned short *)adr) );
			break;
		case TYPE_LONG:
			sprintf( buf, "%08X:%08X", adr, (unsigned long )*((unsigned long  *)adr) );
			break;
		}
		DModeSendMsg( buf );
	}
	if( ret != TRUE ){	/* ERROR */
		DModeSendMsg( "ERROR!" );
	}
	DModeSendCR();
	DModeSendPronpt();

	return( ret );
}
#endif

/************************************************************/
/*	���������C�g�����֐�									*/
/************************************************************/
unsigned int DModeMemoryWrite( unsigned char *pCmd )
{
	char buf[80];
	unsigned int ret= TRUE;
	unsigned int type;
	unsigned long adr, data;
	unsigned char	*bptr;
	unsigned short	*wptr;
	unsigned long	*lptr;

	if( ret == TRUE ){					/* �R?���h */
		pCmd++;
		switch( *pCmd ){
		case ' ':	type= TYPE_WORD;	break;
		case 'B':	type= TYPE_BYTE;	break;
		case 'W':	type= TYPE_WORD;	break;
		case 'L':	type= TYPE_LONG;	break;
		default:	ret= FALSE;			break;
		}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �A�h���X */
		atolx( &adr, pCmd );
		pCmd= SkipNextWord( pCmd );
		adr  &= 0xfffffffe;
	}

	if( ret == TRUE ){
		switch( type ){
		case TYPE_BYTE:
			bptr= (unsigned char *)adr;
			while( *pCmd != END_CHAR ){	/* Get Data */
				atolx( &data, pCmd );
				sprintf( buf, "%08X: %02X->%02X", bptr, *bptr, data );
										/* �ԐM�쐬 */
				DModeSendMsg( buf );	/* �ԐM���s */
				DModeSendCR();
				*((unsigned char *)bptr++)= (unsigned char)data;
				bptr++;
				pCmd= SkipNextWord( pCmd );
			}
			break;
		case TYPE_WORD:
			wptr= (unsigned short *)adr;
			while( *pCmd != END_CHAR ){	/* Get Data */
				atolx( &data, pCmd );
				sprintf( buf, "%08X: %04X->%04X", wptr, *wptr, data );
										/* �ԐM�쐬 */
				DModeSendMsg( buf );	/* �ԐM���s */
				DModeSendCR();
				*((unsigned short *)wptr++)= (unsigned short)data;
				pCmd= SkipNextWord( pCmd );
			}
			break;
		case TYPE_LONG:
			lptr= (unsigned long *)adr;
			while( *pCmd != END_CHAR ){	/* Get Data */
				atolx( &data, pCmd );
				sprintf( buf, "%08X: %08X->%08X", lptr, *lptr, data );
										/* �ԐM�쐬 */
				DModeSendMsg( buf );	/* �ԐM���s */
				DModeSendCR();
				*((unsigned long *)lptr++)= (unsigned long)data;
				pCmd= SkipNextWord( pCmd );
			}
			break;
		}
	}
	if( ret != TRUE ){
		DModeSendMsg( "ERROR!" );
		DModeSendCR();
	}
	DModeSendPronpt();
	return( ret );
}

/************************************************************/
/*	������?���v?��������쐬�֐�							*/
/*	����	long spos;	Start Position						*/
/*			long size;	Size								*/
/*			long cpos;	Current Position					*/
/************************************************************/
void MakeDumpStr( unsigned int type, char *pBuf, unsigned long spos,
							unsigned long size, unsigned long cpos )
{
	char	frm[16];
	unsigned int	i, max;
	unsigned char	cc;			/* ?������ */
	unsigned long	xp, pos;	/* ���ڃA�h���X,�A�h���X?�W�V����*/
	unsigned long	sadrs, eadrs, epos;

	pos= cpos;
	/* ?���J�n�A�h���X */
	sprintf( pBuf, "%08X: ", pos- (pos% 16) );
	pBuf+= 10;

	/* �f??�i�P�U�i?�L�j */
	xp= pos- (pos% 16);						/* �J�����g?�C��? */
	epos= spos+ size;						/* �I�����A�h���X */
	sadrs= spos- (spos% type);				/* ?���J�n�A�h���X */
	eadrs= epos+ (epos% type == 0 ? 0 : type- epos% type);
											/* ?���I���A�h���X */
	max= 16/ type;							/* �P�s?���ő�� */
	sprintf( frm, "%%0%dX ", type* 2 );		/* ?��?���w�� */
	for( i= 0; i < max; i++, xp+= type ){
		if( i == max/ 2 ){					/* ������?�� */
			sprintf( pBuf, " " );
			pBuf++;
		}
		if( xp < sadrs || xp >= eadrs ){	/* ?�L�Ȃ� */
			sprintf( pBuf, "         " );	/* MAX LONG */
		}
		else{								/* �f???�� */
			sprintf( pBuf, frm, 
				type == TYPE_BYTE ? (unsigned char )*(unsigned char  *)pos :
				type == TYPE_LONG ? (unsigned long )*(unsigned long  *)pos :
									(unsigned short)*(unsigned short *)pos );
			pos+= type;
		}
		pBuf+= (type* 2+ 1);
	}

	/* ��؂蕶�� */
	sprintf( pBuf, " " );
	pBuf+= 1;
	
	/* �f??�i����?�L�j */
	xp= cpos- (cpos% 16);		/* ���ڃA�h���X */
	for( i= 0; i < 16; i++, xp++ ){
		if( i == (16/ 2) ){		/* ������?�� */
			sprintf( pBuf, " " );
			pBuf++;
		}
		cc= *(unsigned char *)xp;
		if(      xp <  sadrs ){	sprintf( pBuf, " " );		}
		else if( xp >= eadrs ){	sprintf( pBuf, " " );		}
		else{
			if( cc < ' ' ){						sprintf( pBuf, "." );		}
			else if( cc < 0x7F){				sprintf( pBuf, "%c", cc );	}
			else if( 0xA0 < cc && cc < 0xE0 ){	sprintf( pBuf, "%c", cc );	}
			else{								sprintf( pBuf, "." );		}
		}
		pBuf++;
	}
}

/************************************************************/
/*	������?���v�����֐�									*/
/************************************************************/
unsigned int DModeMemoryDump( unsigned char *pCmd )
{
	char buf[80];
	unsigned int i, line, ret= TRUE;
	unsigned int type;
	unsigned long adr, sadr, end, size;

	if( ret == TRUE ){					/* �R?���h */
		if( memcmp( pCmd, "DUMP", 4 ) == 0 ){	/* Full Command */
			type= TYPE_WORD;
			pCmd= SkipNextWord( pCmd );
		}
		else{									/* Shortcut Command */
			pCmd++;			/* Skip 'D' */
			switch( *pCmd ){
			case '\0':
			case '\a':
			case '\r':
			case ' ':	type= TYPE_WORD;	break;
			case 'B':	type= TYPE_BYTE;	break;
			case 'W':	type= TYPE_WORD;	break;
			case 'L':	type= TYPE_LONG;	break;
			default:	ret= FALSE;			break;
			}
			pCmd= SkipNextWord( pCmd );
		}
	}
	if( ret == TRUE ){					/* �A�h���X */
		if( atolx( &adr, pCmd ) == FALSE ){	adr= DefaultAdress;	}	
		pCmd= SkipNextWord( pCmd );
		adr  &= 0xfffffffe;
	}
	if( ret == TRUE ){					/* �T�C�Y�E�I���A�h���X */
		if( *pCmd == '\\' ){	/* �T�C�Y */
			pCmd++;
			atolx( &size, pCmd );
		}
		else{					/* �I���A�h���X */
			if( atolx( &end, pCmd ) == FALSE ){	size= 16* 8;		}	/* DEFALT */
			else if( adr < end ){				size= end- adr+ 1;	}
			else{								ret= FALSE;			}
			end  &= 0xfffffffe;
		}
		end= adr+ size;
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){			/* ���� */
		line= (unsigned int)((end % 16 == 0 ? end : end+ 16- (end% 16) )
													/* �I���A�h���X */
							- (adr- (adr% 16))) 	/* �J�n�A�h���X */
							/ 16;					/* �ő�?���� */
		for( i= 0; i < line; i++ ){
			sadr= adr+ i* 16;		/* ?���擪�̃A�h���X�擾 */

			MakeDumpStr( type, buf, adr, size, sadr );
			DModeSendMsg( buf );
			DModeSendCR();
		}
	}
	if( ret != TRUE ){
		DModeSendMsg( "ERROR!" );
		DModeSendCR();
	}
	DefaultAdress= adr+ 16* 8;
	DModeSendPronpt();

	return( ret );
}
#ifdef	OLD		//2008.04.07
/************************************************************/
/*	�������t�B�������֐�									*/
/************************************************************/
unsigned int DModeMemoryFill( unsigned char *pCmd )
{
	unsigned int ret= TRUE;
	unsigned int i;
	unsigned long adr[2], len, inc, data;		/* adr[0]:�I���W�i���A�h���X */
												/* adr[1]:�o�E��?���Ή���A�h���X */

	if( ret == TRUE ){					/* �R?���h */
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �A�h���X */
		if( atolx( &adr[0], pCmd ) == FALSE ){	ret= FALSE;	}
		adr[0]  &= 0xfffffffe;
		pCmd= SkipNextWord( pCmd );
		adr[1]= (adr[0]/ 2)* 2;
	}
	if( ret == TRUE ){					/* �T�C�Y */
		if( *pCmd == '\\' ){
			pCmd++;
			if( atolx( &len, pCmd ) == FALSE ){	ret= FALSE;	}
			pCmd= SkipNextWord( pCmd );
			len= (adr[0]+ len)- adr[1];	/* Size= End- Statrt */
			len= (len/ 2)+ (len% 2);	/* Byte ==> Word */
		}
		else{
			ret= FALSE;
		}
	}
	if( ret == TRUE ){					/* �����l */
		if( atolx( &data, pCmd ) == FALSE ){	ret= FALSE;	}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �C���N�������g�p??�� */
		if( atolx( &inc, pCmd ) == FALSE ){	ret= FALSE;	}
		pCmd= SkipNextWord( pCmd );
	}

	if( ret == TRUE ){
		for( i= 0; i < len; i++ ){
			*((unsigned short *)adr[1]+ i)= (unsigned short)data;
			data+= inc;
		}
	}
	if( ret != TRUE ){
		DModeSendMsg( "ERROR!" );
		DModeSendCR();
	}
	DModeSendPronpt();
	return( ret );
}
/************************************************************/
/*	���������f??�ݒ�i�r�t�a�r�j�����֐�					*/
/************************************************************/
unsigned int DModeMemorySubs( unsigned char *pCmd )
{
	char buf[80];
	unsigned int ret= TRUE, size= 0;
	unsigned long adr, dat;
	unsigned short *wptr;

	if( ret == TRUE ){					/* �R?���h */
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �A�h���X */
		if( atolx( &adr, pCmd ) == FALSE ){	adr= DefaultAdress;	}
		pCmd= SkipNextWord( pCmd );
		adr  &= 0xfffffffe;
	}
	if( ret == TRUE ){					/* �f?? */
		wptr= (unsigned short *)adr;
		/* �A���ݒ� */
		if( *pCmd == '\0' || *pCmd == '\a' || *pCmd == '\r' ){
			SubsModeFlag= TRUE;					/* Flag ON */
			DefaultAdress= adr;
			sprintf( buf, "%08X %04X", DefaultAdress,
							(unsigned short)*((unsigned short *)DefaultAdress) );
			DModeSendMsg( buf );
		}
		/* ���ڐݒ� */
		else{
			while( atolx( &dat, pCmd ) == TRUE ){
				size+= 2;
				*((unsigned short *)wptr++)= (unsigned short)dat;
				pCmd= SkipNextWord( pCmd );
			}
/*19991029 ��?��*/
/*			MakeDumpStr( TYPE_WORD, buf, adr, size, adr );*/
/*			DModeSendMsg( buf );*/
/*			DModeSendCR();*/
/**/
		}
	}
	DModeSendPronpt();

	return( ret );
}
#endif
/************************************************************/
/*	�r�t�a�r���ʏ����֐�									*/
/************************************************************/
unsigned int DModeSubsProc( unsigned char *pCmd )
{
	char buf[80];
	unsigned long dat;
	unsigned short *wptr;

	switch( *pCmd ){
	case '\0':	/* �����̓R?���h */
	case '\r':	/* �����̓R?���h */
		DefaultAdress+= (DefaultAdress% 2);	/* ������ */
		DefaultAdress+= 2;					/* ���� */
		break;
	case '^':	/* �P��R?���h */
		DefaultAdress+= (DefaultAdress% 2);	/* ������ */
		DefaultAdress-= 2;					/* ���� */
		break;
	case '.':	/* �I���R?���h */
		SubsModeFlag= FALSE;				/* Flag OFF */
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	default:	/* ���̑��̃R?���h */
		if( atolx( &dat, pCmd ) == TRUE ){
			DefaultAdress+= (DefaultAdress% 2);	/* ������ */
			wptr= (unsigned short *)DefaultAdress;
			*((unsigned short *)wptr++)= (unsigned short)dat;
			DefaultAdress+= 2;					/* ���� */
		}
		break;
	}

	DModeSendCR();
	sprintf( buf, "%08X %04X", DefaultAdress, (unsigned short)*((unsigned short *)DefaultAdress) );
	DModeSendMsg( buf );
	DModeSendPronpt();
	return( TRUE );
}
#ifdef	OLD	//2008.04.07
/************************************************************/
/*	�e�o�f?���C�g�����֐�									*/
/************************************************************/
unsigned int DModeFpgaWrite( unsigned char *pCmd )
{
	unsigned int ret= TRUE;
//	unsigned int type;
	unsigned long adr, data;

	if( ret == TRUE ){	/* 1st character */
		if( *pCmd != 'G' ){	ret= FALSE;	}
		else{				pCmd++;		}
	}
	if( ret == TRUE ){	/* 2nd character */
//		switch( *pCmd ){
//		case 'A':	type= 1;	break;
//		case 'B':	type= 2;	break;
//		case 'C':	type= 3;	break;
//		case 'D':	type= 4;	break;
//		default:	ret= FALSE;	break;
//		}
		pCmd+= 2;
	}
	if( ret == TRUE ){	/* Get Address */
		atolx( &adr, pCmd );
		pCmd= SkipNextWord( pCmd );
	}

	if( ret == TRUE ){
		atolx( &data, pCmd );

#ifdef INCOMPLETE
//		SetFpga( type, ads, data );
#endif
	return( TRUE );
	}
	return( ret );
	
}
void	IoTest(unsigned char *pCmd)
{
	int	i,operation;
	volatile unsigned long adr,data;
//	int	saveSyscfg;
	unsigned char rData;
	char	buff[16];
	char	*DataSendBuff;

	DataSendBuff= TakeMemory(0x1000);
	memset(DataSendBuff,0,0x1000);
	pCmd= SkipNextWord( pCmd );
	if((pCmd[0] == 'R') || (pCmd[0] == 'r')){
		operation= 0;		//Read
	}else if((pCmd[0] == 'W') || (pCmd[0] == 'w')){
		operation= 1;		//Write
	}else{		//Error
		DModeSendMsg( "ERROR\r\n" );
		return;
	}
	pCmd= SkipNextWord( pCmd );
	/* �A�h���X */
	if( atolx( (unsigned long *)&adr, pCmd ) == FALSE ){	adr= 0x0e000100;	}
	if(operation == 0){		//Read
//		_di();
		for(i=0;i<64;i++){
			if(i%8 == 0){
				sprintf(buff,"%08X",(int)adr+i);		//adr��UP����Ȃ�����
				strcat(DataSendBuff,buff);
			}
//			saveSyscfg=rSYSCFG;
//			rSYSCFG=0x01; 		    
			rData = (*(volatile unsigned char *)adr++ & 0x00ff);
//			rSYSCFG=saveSyscfg; 		      
			sprintf(buff," %02X", rData);
			strcat(DataSendBuff,buff);
			if(i%8 == 7){
				strcat(DataSendBuff,"\x0d\x0a");
			}
		}
//		_ei();
		DModeSendMsg( DataSendBuff );
	}else{		//Write
		pCmd= SkipNextWord( pCmd );
		/* �A�h���X */
		if( atolx( (unsigned long *)&data, pCmd ) == FALSE ){	data= 0;	}
//		saveSyscfg=rSYSCFG;
//		rSYSCFG=0x01;
#ifdef	WIN32
		*(volatile unsigned char *)adr= (volatile unsigned char)data;
#else
		*(volatile unsigned char *)adr= data;
#endif
//		rSYSCFG=saveSyscfg; 		      
		DModeSendCR();
	}
	FreeMail(DataSendBuff);
}
#endif
/************************************************************/
/*	�R?���h�ԍ��̎擾										*/
/*	�ߒl�F	�R?���h�ԍ�									*/
/*			0*:�������R?���h()								*/
/*			1*:����n�R?���h								*/
/*			8*:����R?���h									*/
/*			F*:�V�X�e?�n�R?���h							*/
/************************************************************/
unsigned int GetDModeCmdNo( unsigned char *pCmd )
{
	unsigned int i;
	struct{
		unsigned int		No;
		int		size;
		char	*cmd;
	} DmodeCmdTbl[]= {
		/**	�������R?���h		**/
//		{	UDCMD_AN,	  2, "AN"		},
//		{	UDCMD_TS,	  2, "TS"		},
//		{	UDCMD_RC,	  2, "RC"		},
//		{	UDCMD_IO,	  2, "IO"		},
/*		{	UDCMD_FPGA,	  2, "GA"		},	*/
/*		{	UDCMD_FPGA,	  2, "GB"		},	*/
/*		{	UDCMD_FPGA,	  2, "GC"		},	*/
/*		{	UDCMD_FPGA,	  2, "GD"		},	*/
//		{	UDCMD_GO,	  2, "GO"		},
//		{	UDCMD_GO,	  1, "G"		},
//		{	UDCMD_BR,	  2, "BR"		},
		/**	�Ǎ��݌n�R?���h	**/
//		{	UDCMD_MEM_R,  2, "RB"		},
//		{	UDCMD_MEM_R,  2, "RW"		},
//		{	UDCMD_MEM_R,  2, "RL"		},
		{	UDCMD_MEM_W,  2, "WB"		},
		{	UDCMD_MEM_W,  2, "WW"		},
		{	UDCMD_MEM_W,  2, "WL"		},
		{	UDCMD_MEM_D,  4, "DUMP"		},
		{	UDCMD_MEM_D,  2, "DB"		},
		{	UDCMD_MEM_D,  2, "DW"		},
		{	UDCMD_MEM_D,  2, "DL"		},
		{	UDCMD_MEM_D,  1, "D"		},
//		{	UDCMD_MEM_F,  4, "FILL"		},
//		{	UDCMD_MEM_F,  1, "F"		},
//		{	UDCMD_MEM_S,  4, "SUBS"		},
//		{	UDCMD_MEM_S,  2, "EW"		},
//		{	UDCMD_MEM_S,  1, "E"		},
		/**	����R?���h		**/
//		{	UDCMD_PLOAD,  5, "PLOAD"	},
		{	UDCMD_FLOAD,  5, "FLOAD"	},
		/**	�V�X�e?�n�R?���h	**/
		{	UDCMD_VER,	  3, "VER"		},
		{	UDCMD_VER,	  1, "_"		},
		{	UDCMD_HELP,	  4, "HELP"		},
		{	UDCMD_HELP,	  1, "?"		},
		{	UDCMD_CHELP,  3, "CAM?"		},
		{	UDCMD_EXIT,	  4, "QUIT"		},
		{	UDCMD_EXIT,	  1, "Q"		},
		{	UDCMD_NO_CMD, 1, "\x0D"		},
		{	UDCMD_ECHO,   4, "ECHO"		},
		{	UDCMD_ECHOOF, 5, "_ECHO"	},
		{	UDCMD_LF,     4, "CRLF"		},
		{	UDCMD_LFOF,   5, "_CRLF"	},
//		{	UDCMD_FACT,   3, "/GO"		},
	};

	for( i= 0; pCmd[i] != END_CHAR; i++ ){
		if( 'a' <= pCmd[i] && pCmd[i] <= 'z' ){	pCmd[i]-= ('a'- 'A');	}
	}
	for( i= 0; i < TBQ(DmodeCmdTbl); i++ ){
		if( memcmp( pCmd, DmodeCmdTbl[i].cmd, DmodeCmdTbl[i].size ) == 0 ){
			if( IsSpeace( *(pCmd+ DmodeCmdTbl[i].size) ) == TRUE ||
								DmodeCmdTbl[i].No == UDCMD_NO_CMD ){
				DModeSendCR();
				return( DmodeCmdTbl[i].No );
			}
		}
	}
	return( 0x00 );
}
unsigned int AtoHex( char *ptr )
{
	unsigned int ret;

	for( ret= 0; ; ptr++ ){
		if(      '0' <= *ptr && *ptr <= '9' ){	ret= (ret* 16)+ (*ptr- '0');		}
		else if( 'A' <= *ptr && *ptr <= 'F' ){	ret= (ret* 16)+ (*ptr- 'A'+ 10);	}
		else if( 'a' <= *ptr && *ptr <= 'f' ){	ret= (ret* 16)+	(*ptr- 'a'+ 10);	}
		else{									break;	}
	}
	return( ret );
}
char HextoABuf[16];
char *HextoA( int keta, int hex )
{
	int i, c;
	
	for( i= 0; i < keta; i++ ){
		c= (hex & 0x0F);
		HextoABuf[keta- i- 1]= ( c < 10 ? c+ '0' : c- 10+ 'A');
		hex >>= 4;
	}
	return( HextoABuf );
}
char *SkipToSpace( char *ptr )
{
	int i;

	for( i= 0; i < 100; i++, ptr++ ){
		if( *ptr == ' ' ){	return( ++ptr );	}
	}
	return( (char *)-1 );
}

/************************************************************/
/*	�R?���h�����֐�										*/
/*	�ߒl�F	TRUE :�ʏ폈��									*/
/*			FALSE:�I������									*/
/*	���l�F	�R?���h�ԍ�									*/
/*			0*:�������R?���h()								*/
/*			1*:����n�R?���h								*/
/*			8*:����R?���h									*/
/*			F*:�V�X�e?�n�R?���h							*/
/************************************************************/
unsigned int DModeCommand( unsigned char *pCmd )
{
	extern	void	OutD0( void );

	switch( GetDModeCmdNo( pCmd ) ){
	/**	�������R?���h		**/
//	case UDCMD_AN:					/* A/D Read */
//		return( TRUE );
//	case UDCMD_TS:					/* Temp Sensor Read */
//		return( TRUE );
//	case UDCMD_IO:					/* I/O Test */
//		IoTest( pCmd );
//		DModeSendCR();
//		DModeSendPronpt();
//		return( TRUE );
//	case UDCMD_RC:					/* SendCamera Command */
//	case UDCMD_GO:					/* Do Program Continue */
//	case UDCMD_BR:					/* Break Point Address */
//		DModeSendPronpt();
//		return( TRUE );
//	case UDCMD_FPGA:				/* FPGA Register Write */
//		DModeFpgaWrite( pCmd );
//		DModeSendPronpt();
//		return( TRUE );
	/**	����n�R?���h		**/
//	case UDCMD_MEM_R:				/* Memory Read */
//		DModeMemoryRead( pCmd );	return( TRUE );
	case UDCMD_MEM_W:				/* Memory Write */
		DModeMemoryWrite( pCmd );	return( TRUE );
	case UDCMD_MEM_D:				/* Memory Dump */
		DModeMemoryDump( pCmd );	return( TRUE );
//	case UDCMD_MEM_F:				/* Memory Fill */
//		DModeMemoryFill( pCmd );	return( TRUE );
//	case UDCMD_MEM_S:				/* Memory Subs */
//		DModeMemorySubs( pCmd );	return( TRUE );
	/**	����R?���h		**/
//	case UDCMD_PLOAD:				/* Program Load */
//		PloadFlag= TRUE;
/*		HexLoadRS();*/
//		PloadFlag= FALSE;
//		return( TRUE );
	case UDCMD_FLOAD:				/* IDP FPGA Data Load */
		HexLoad();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	/** �V�X�e?�n�R?���h	**/
	case UDCMD_VER:					/* About */
		DModeSendVersion();			return( TRUE );
	case UDCMD_HELP:				/* HELP */
		DModeSendHelpMsg();			return( TRUE );
	case UDCMD_CHELP:				/* CAM HELP */
//		DModeSendCamHelpMsg();		return( TRUE );
		return( TRUE );
	case UDCMD_EXIT:				/* QUIT */
		DModeSendQuitMsg();			return( FALSE );
	case UDCMD_ECHO:				/* ECHO ON */
		SioEchoFlag = 1;
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_ECHOOF:				/* ECHO OFF */
		SioEchoFlag = 0;
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LF:					/* LF ON */
		SioLFFlag = 1;
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LFOF:				/* LF OFF */
		SioLFFlag = 0;
		DModeSendPronpt();
		return( TRUE );
//	case UDCMD_FACT:
//		DModeSendPronpt();
//		return(TRUE);
	case UDCMD_NO_CMD:				/* NO COMMAND */
		DModeSendPronpt();			return( TRUE );
	default:						/* ERROR */
		DModeSendCR();
		DModeSendCmdErr( pCmd );
		return( TRUE );
	}
//	return( TRUE );
}

int LoginProc( unsigned int cmd, unsigned char *msg )
{
	switch( cmd ){
	case NO_LOGIN:	return( *msg == 0x04 ? RR_LOGIN : NO_LOGIN );
	case RR_LOGIN:
		if( memcmp( msg, "KYOTO", 5 ) == 0 ){
			DModeSendLoginMsg();		/* Welcome Message */
			return( OK_LOGIN );
		}
		if( memcmp( msg, "kyoto", 5 ) == 0 ){
			DModeSendLoginMsg();		/* Welcome Message */
			return( OK_LOGIN );
		}
	}
	return( NO_LOGIN );
}

int DebugTaskProc( int cmd, char *msg )
{
	switch( cmd ){
	case NO_LOGIN:	return( LoginProc( (unsigned char)cmd, (unsigned char *)msg ) );
	case RR_LOGIN:	return( LoginProc( (unsigned char)cmd, (unsigned char *)msg ) );
	case OK_LOGIN:
		if( SubsModeFlag == TRUE ){	DModeSubsProc( (unsigned char *)msg );	}
		else if( DModeCommand( (unsigned char *)msg ) != TRUE ){	return( NO_LOGIN );	}
		break;
	}
	return( cmd );
}
void    DebugTask( STTFrm* pSTT )         /* ����������?�X�N */
{
	char	*mp;

	DModeFlag= 0x00;
	while( TRUE ){
		mp = WaitRequest();
		if( strlen( mp ) != 0 ){
			DModeFlag= DebugTaskProc( DModeFlag, (char *)mp );
		}
		ResponseMail(mp);
	}
}

void	DebugSend(int RecCommCnt, char* CommBuff, UART_STRUCT* pSciTbl)
{
	int		i;
	char	*mp;

	SciTbl= pSciTbl;
	mp= TakeMemory(128);
	for(i= 0; (i< 127) && (i < RecCommCnt); i++){
		mp[i] = CommBuff[i];
	}
	mp[i]= 0;
	SendMail(T_DEBUG,mp);
}



