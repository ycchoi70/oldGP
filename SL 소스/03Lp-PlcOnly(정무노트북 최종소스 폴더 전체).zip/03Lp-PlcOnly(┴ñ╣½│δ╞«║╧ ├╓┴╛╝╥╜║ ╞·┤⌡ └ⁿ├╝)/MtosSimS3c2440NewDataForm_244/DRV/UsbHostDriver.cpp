/****************************************************/
/*    FUNC   : USB Host Handler		                */
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 2009.11.07                           */
/*    Update :                                      */
/****************************************************/
#define	USB_HOST
#include "doscomm.h"
#include "glpdos.h"
#include "define.h"
#include "gpstruct.h"
#include "commbuff.h"
#include	"mts.h"
#include "mtscifp.h"
#include    "mtsschdp.h"
#include    "mtsscid.h"
#include	"mail.h"
#include	"taskhed.h"
#include	"s2440.h"
#include	"usbh.h"
#include	"pcmcia.h"
//#include	"mmcdrv.h"
#include	"sys_setting.h"

//#define	USB_TEST
//#define	USB_TEST_DEL

int		UsbHostConnected;
unsigned int	UsbWaitTime;
extern	void	_ei(void);
extern	void	_di(void);
extern	void	SetDisconnect(void);

void	UsbHostConnectProc(void)
{
	int	ret;

	ret= Hcd_DoTransfer();		//USB EDP Initialize
	if(ret == 0){	//OK
		MountFile(DEV_USB_DISK);
		SetSystemUSBInf();				//2011.06.11
	}
}
void	SendUsbHostHandler(int command)
{
	T_MAIL	*mp;
	int	mbx;
	int		OldResp;

	mbx = TakeMbx();
	mp= (T_MAIL*)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd= command;
	SendMail(T_USB_HHAND,(char*)mp);
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	FreeMail((char *)mp);
	FreeMbx(mbx);
	return;
}
char	ReadBuff[0x1000];
void	UsbHostDrvProc( void )     /* USB HOST�h���C�o�[�X�N */
{
	int	ret;
#ifdef	USB_TEST
	int	i;
	int	wfp;
	int	len;
#endif

	ret= Get_Hcd_DeviceConnectInf();
	if(ret != 0){	//Connect
		if(UsbHostConnected == 0){
			Hcd_DeviceConnect();
			UsbHostConnectProc();
			UsbHostConnected= 1;

			SendUSBState(KEY_USB_ON);


//USB TEST
#ifdef	USB_TEST
//#ifdef	USB_TEST_DEL
//			wfp= Fs_remove("D:\\SpotEye_20100305120045.csv");
//#else
#ifndef	MAKE_FILE
			wfp= Fs_open("D:\\SpotEye_20100305120045.csv",O_CREAT,S_IWRITE);
			if(wfp < 0){					return;	}
			for(i= 0; i < sizeof(ReadBuff); i++){	ReadBuff[i]= i;	}
			len= Fs_write(wfp, ReadBuff,sizeof(ReadBuff));
			Fs_close(wfp);
#else
			wfp= Fs_rename("D:\\SpotEye_5120045.csv","D:\\SpotEye_201003051200451111111111.csv");
#endif


//			wfp= Fs_open("D:\\SpotEye_20100305120046.csv",O_CREAT,S_IWRITE);
//			if(wfp < 0){					return;	}
//			for(i= 0; i < sizeof(ReadBuff); i++){	ReadBuff[i]= i+10;	}
//			len= Fs_write(wfp, ReadBuff,sizeof(ReadBuff));
//			Fs_close(wfp);
//			wfp= Fs_open("D:\\SpotEye_20100305120047.csv",O_CREAT,S_IWRITE);
//			if(wfp < 0){					return;	}
//			for(i= 0; i < sizeof(ReadBuff); i++){	ReadBuff[i]= i+20;	}
//			len= Fs_write(wfp, ReadBuff,sizeof(ReadBuff));
//			Fs_close(wfp);
//#endif
#endif
		}
	}else{									//DisConnect
		if(UsbHostConnected == 1){
			Hcd_DeviceDisConnect();
			DismountFile(DEV_USB_DISK);
			UsbHostConnected= 0;
			SendUSBState(KEY_USB_OFF);
			SetSystemUSBInf();				//2011.06.11
		}
	}
}

void	UsbHostDrv( STTFrm* pSTT )     /* USB HOST�h���C�o�[�X�N */
{
	Hcd_Init();
//	MMC_CardInit();

	UsbHostConnected= 0;
	while(1){
		UsbHostDrvProc();	//USB Host State
//		MmcSdDrv();			//SD Card State
		Delay(100);
	}
}
//unsigned char	dumBuff[0x1000];
unsigned int	GetNowTime(void);
int	UsbReadSector(long sector,long datasize,unsigned char*buff)
{
	int	i;
	int	sectCnt;
	int	ret;
	unsigned int NowTime;

//	SetUsbHostSema();
	sectCnt= datasize/512;
	if(datasize%512){	sectCnt++;	}
	for(i= 0; i < sectCnt; i++){
		ret= bulk_only_transfer(ST_READ,&buff[i*512],sector+i,1);
		if(ret == 1){	break;	}		//Error
		NowTime= GetNowTime();
		if((UsbWaitTime- NowTime) > 100){
			UsbWaitTime= NowTime;
			Delay(20);
		}		//2011.06.01
	}
//	Delay(3000);
//	ret= bulk_only_transfer(ST_READ,dumBuff,0x3f,1);
//	ResetUsbHostSema();
	return(ret);
}
int	UsbWriteSector(long sector,long datasize,unsigned char*buff)
{
	int	i;
	int	sectCnt;
	int	ret;
	unsigned int NowTime;

//	SetUsbHostSema();
	sectCnt= datasize/512;
	if(datasize%512){	sectCnt++;	}
	for(i= 0; i < sectCnt; i++){
		ret= bulk_only_transfer(ST_WRITE,&buff[i*512],sector+i,1);
		if(ret == 1){	break;	}		//Error
		NowTime= GetNowTime();
		if((UsbWaitTime- NowTime) > 50){
			UsbWaitTime= NowTime;
			Delay(20);
		}		//2011.06.01
	}
//	ResetUsbHostSema();
	return(ret);
}
void	UsbHostHandler( STTFrm* pSTT )     /* USB HOST Read/Write �n���h���[ */
{
	T_MAIL	*mp;

	UsbWaitTime= 0;
	while(1){
		mp= (T_MAIL*)WaitRequest();
		switch(mp->mcmd){
		case USB_HOST_CONNECT:
			Hcd_DeviceConnect();
			break;
		case USB_HOST_DISCONNECT:
			Hcd_DeviceDisConnect();
			break;
		case READ_SECTOR:
			UsbReadSector(mp->mext,mp->mpar,(unsigned char*)mp->mptr);
			break;
		case WRITE_SECTOR:
			UsbWriteSector(mp->mext,mp->mpar,(unsigned char*)mp->mptr);
			break;
		case ERASE_SECTOR:
			break;
		}
		ResponseMail((char*)mp);
	}
}

