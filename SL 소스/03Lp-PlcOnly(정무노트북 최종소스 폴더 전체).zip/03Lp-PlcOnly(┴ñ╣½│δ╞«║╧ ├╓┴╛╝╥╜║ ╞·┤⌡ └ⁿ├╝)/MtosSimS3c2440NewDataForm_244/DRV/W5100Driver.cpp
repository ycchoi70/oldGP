///////////////////////////////////////////////////////////
//	Lan Driver
///////////////////////////////////////////////////////////
 
#include	<stdio.h>
#include	<string.h>

#include	"mts.h"
#include	"mtscifp.h"
#include    "mtsschdp.h"
#include    "mtsscid.h"
#include	"mail.h"
#include	"taskhed.h"

#include "w5100.h"
#include "socket.h"

#include "define.h"
#include "gpcommon.h"
#include "rs232c_pc.h"
#include "iohand.h"
#include "sioprotcol.h"
#include "s2440.h"



//#define	W51LOG

//#define	LOOP_TEST


extern	volatile	int	TaskStartFlag;

UART_STRUCT	_Sci_LanTbl;
int	_LanDrvTaskNo;
int	_LanDrvMode;

typedef struct{
   uint8 ip[4];                   // for setting SIP register
   uint8 gw[4];                   // for setting GAR register
   uint8 sn[4];                   // for setting SUBR register
   uint8 mac[6];				  // for setting SHAR register
}TCP_SET;

   uint8 tx_mem_conf = 0x55;          // for setting TMSR regsiter
   uint8 rx_mem_conf = 0x55;          // for setting RMSR regsiter
//   uint8 tx_mem_conf = 0x0a;          // for setting TMSR regsiter
//   uint8 rx_mem_conf = 0x0a;          // for setting RMSR regsiter

   TCP_SET w53Inf;


uint16	lanRecCnt;
uint8	lanRecBuff[0x2000];

#ifdef	W51LOG
int	recLogIdx;
unsigned char	recLogData[0x4000];
int	sndLogIdx;
unsigned char	sndLogData[0x2000];
int	RecsAddridx;
int	SndsAddridx;
int	RecLogStart[128];
int	RecLogCnt[128];
unsigned int	RecLogTime[128];
int	SndLogStart[128];
#endif

unsigned char	DefMacAddr[6]= {0x00,0x08,0xDC,0x00,111,200}; 
unsigned char	DefIpAddr[4]= {192,168,100,100}; 
unsigned char	DefGatewayAddr[4]= {192,168,100,1}; 
unsigned char	DefSubnetAddr[4]= {255,255,255,0}; 

extern	int	ProtocolDataProc(int len,char *buff,UART_STRUCT* _SciTbl);
/* Initialization & Interrupt request routine */


/**
 * "TCP SERVER" loopback program.
 */ 
int	loopback_tcps(SOCKET s, uint16 port, uint8 mode)
{
   uint16 len;
   int	ret= -1;
   
   switch(getSn_SR(s))                // check SOCKET status
   {                                   // ------------
      case SOCK_ESTABLISHED:           // ESTABLISHED?
         if(getSn_IR(s) & Sn_IR_CON)   // check Sn_IR_CON bit
         {
            setSn_IR(s,Sn_IR_CON);     // clear Sn_IR_CON
         }
         if((len=getSn_RX_RSR(s)) > 0) // check the size of received data
         {
            len = recv(s,_Sci_LanTbl.IntSioRecBuff,len);     // recv
			ret= 0;
         }
         break;
                                       // ---------------
   case SOCK_CLOSE_WAIT:               // PASSIVE CLOSED
         disconnect(s);                // disconnect 
         break;
                                       // --------------
   case SOCK_CLOSED:                   // CLOSED
      close(s);                        // close the SOCKET
      socket(s,Sn_MR_TCP,port,mode);   // open the SOCKET  
      break;
                                       // ------------------------------
   case SOCK_INIT:                     // The SOCKET opened with TCP mode
      listen(s);                       // listen to any connection request from "TCP CLIENT"
      break;
   default:
      break;
   }
   return(ret);
}

/**
 * "TCP CLIENT" loopback program.
 */ 
void     loopback_tcpc(SOCKET s, uint8* addr, uint16 port, uint8* buf, uint8 mode)
{
   uint16 len;
   static uint16 any_port = 1000;
   
   switch(getSn_SR(s))                   // check SOCKET status
   {                                      // ------------
      case SOCK_ESTABLISHED:              // ESTABLISHED?
         if(getSn_IR(s) & Sn_IR_CON)      // check Sn_IR_CON bit
         {
//            printf("%d : Connect OK\r\n",s);
            setSn_IR(s,Sn_IR_CON);        // clear Sn_IR_CON
         }
         if((len=getSn_RX_RSR(s)) > 0)    // check the size of received data
         {
            len = recv(s,buf,len);        // recv
            if(len !=send(s,buf,len))     // send
            {
//               printf("%d : Send Fail.len=%d\r\n",s,len);
            }
         }
         break;
                                          // ---------------
   case SOCK_CLOSE_WAIT:                  // PASSIVE CLOSED
         disconnect(s);                   // disconnect 
         break;
                                          // --------------
   case SOCK_CLOSED:                      // CLOSED
      close(s);                           // close the SOCKET
      socket(s,Sn_MR_TCP,any_port++,mode);// open the SOCKET with TCP mode and any source port number
      break;
                                          // ------------------------------
   case SOCK_INIT:                        // The SOCKET opened with TCP mode
      connect(s, addr, port);             // Try to connect to "TCP SERVER"
//      printf("%d : LOOPBACK_TCPC(%d.%d.%d.%d:%d) Started.\r\n",s,addr[0],addr[1],addr[2],addr[3],port);
      break;
   default:
      break;
   }
}

/**
 * UDP loopback program.
 */ 
void     loopback_udp(SOCKET s, uint16 port, uint8* buf, uint8 mode)
{
   uint16 len;
   uint8 destip[4];
   uint16 destport;
   
   switch(getSn_SR(s))
   {
                                                         // -------------------------------
      case SOCK_UDP:                                     // 
         if((len=getSn_RX_RSR(s)) > 0)                   // check the size of received data
         {
            len = recvfrom(s,buf,len,destip,&destport);  // receive data from a destination
            if(len !=sendto(s,buf,len,destip,destport))  // send the data to the destination
            {
//               printf("%d : Sendto Fail.len=%d,",s,len);
//               printf("%d.%d.%d.%d(%d)\r\n",destip[0],destip[1],destip[2],destip[3],destport);
            }
         }
         break;
                                                         // -----------------
      case SOCK_CLOSED:                                  // CLOSED
         close(s);                                       // close the SOCKET
         socket(s,Sn_MR_UDP,port,mode);                  // open the SOCKET with UDP mode
         break;
      default:
         break;
   }
}

void	SetSciLanTbl(void)
{
	memset(&_Sci_LanTbl,0,sizeof(_Sci_LanTbl));
	_Sci_LanTbl.ch= ETHERNET_CH0;
	
}
/**
 * "TCP SERVER" loopback program.
 */ 
void     tcps_Open(SOCKET s, uint16 port)
{
	int	status= 0;

	while(status != 0x03){
		switch(getSn_SR(s))                // check SOCKET status
		{                                   // ------------
		  case SOCK_ESTABLISHED:           // ESTABLISHED?
			 break;
										   // ---------------
		case SOCK_CLOSE_WAIT:               // PASSIVE CLOSED
			 break;
										   // --------------
		case SOCK_CLOSED:                   // CLOSED
		  close(s);                        // close the SOCKET
		  socket(s,Sn_MR_TCP,port,0);   // open the SOCKET  
		  status |= 0x01;
		  break;
										   // ------------------------------
		case SOCK_INIT:                     // The SOCKET opened with TCP mode
		  listen(s);                       // listen to any connection request from "TCP CLIENT"
		  status |= 0x02;
		  break;
		default:
		  break;
		}
		Delay(100);
	}
}
void	LanIntEnable(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
//	volatile IOP_REG	*pIOPRegs   = (IOP_REG *)IOP_BASE;

	pINTRegs->rSRCPND  = BIT_EINT1;
	if (pINTRegs->rINTPND & BIT_EINT1)
		pINTRegs->rINTPND = BIT_EINT1;

	

	pINTRegs->rINTMSK &= ~BIT_EINT1;
	
}
void	LanIntDesable(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_EINT2;
	
}
void	DefaultAddressSet(void)
{
	//MAC Addr
	memcpy(&Env.macAddr[0],DefMacAddr,6);
	//IP Addr
	memcpy(&Env.ipAddr[0],DefIpAddr,4);
	//Subnet Addr
	memcpy(&Env.snAddr[0],DefSubnetAddr,4);
	//Gateway
	memcpy(&Env.gwAddr[0],DefGatewayAddr,4);
	//Port
	Env.PortAddr= 9000;

}
extern	uint8 destip[4];
extern	uint16 destport;
#ifdef	W51LOG
extern	unsigned int	GetNowTime(void);		/* 20060203 */
void	SaveRevLog(void)
{
	int	i;

	RecLogCnt[RecsAddridx]= lanRecCnt;
	RecLogTime[RecsAddridx]= GetNowTime();
	RecLogStart[RecsAddridx++]= recLogIdx;
	RecsAddridx &= 0x7f;
	for(i= 0; i < lanRecCnt; i++){
		recLogData[recLogIdx++]= lanRecBuff[i];
		recLogIdx &= 0x3fff;
	}
}
void	SaveSndLog(void)
{
	int	i;
	SndLogStart[SndsAddridx++]= sndLogIdx;
	SndsAddridx &= 0x7f;
	for(i= 0; i < _Sci_LanTbl.SndCnt; i++){
		sndLogData[sndLogIdx++]= _Sci_LanTbl.SndBuff[i];
		sndLogIdx &= 0x1fff;
	}
}
#endif
void	InitLanDrv(int SocketNo)
{
#ifndef	WIN32
	iinchip_init();							/* initiate W5300 */
	sysinit(tx_mem_conf,rx_mem_conf);	/* allocate internal TX/RX Memory of W5300 */

	setSHAR(Env.macAddr);                                      // set source hardware address
	/* configure network information */
	setGAR(Env.gwAddr);                                     // set gateway IP address
	setSUBR(Env.snAddr);                                    // set subnet mask address
	setSIPR(Env.ipAddr);                                    // set source IP address

	memset(&w53Inf,0,sizeof(w53Inf));
	/* verify network information */
	getSHAR(w53Inf.mac);                                      // get source hardware address 
	getGAR(w53Inf.gw);                                        // get gateway IP address      
	getSUBR(w53Inf.sn);                                       // get subnet mask address     
	getSIPR(w53Inf.ip);                                       // get source IP address       

	tcps_Open(SocketNo,Env.PortAddr);	//Server Open
	socket(UDP_SOCKET,Sn_MR_UDP,Env.PortAddr,0);                  // open the SOCKET with UDP mode
	LanIntEnable();
	IINCHIP_WRITE(Sn_IR(SocketNo), (uint8)0x1f);
	setIMR(0x0f);
#endif
	_LanDrvMode= LAN_NOP;
}
/************************************************************/
/* LAN Driver												*/
/************************************************************/
int	LanConnectFlag;
void	LanDriverTsk( STTFrm* pSTT )
{
//	int	ret;
	int	SocketNo= 0;

	_LanDrvTaskNo= _RunTaskNo;
	SetSciLanTbl();
	while(TaskStartFlag == OFF){
		Delay(100);
	}
	InitLanDrv(SocketNo);
	ClearFlag();
#ifdef	W51LOG
recLogIdx= 0;
sndLogIdx= 0;
RecsAddridx= 0;
SndsAddridx= 0;
#endif
	while(1){
		//Server State
//		ret= loopback_tcps(0,LanPortNo,0);
//		if(ret == 0){
//		}
		WaitFlag(1);
		switch(_LanDrvMode){
		case LAN_DISCONNECT:						//disconnect
			_LanDrvMode= LAN_NOP;
			disconnect(SocketNo);                // disconnect 
			Delay(100);
			SocketNo= (SocketNo+1) & 1;
			tcps_Open(SocketNo,Env.PortAddr);
			break;
		case LAN_RECIVE:						//Recive
			_LanDrvMode= LAN_NOP;
#ifdef	LOOP_TEST
			memcpy(_Sci_LanTbl.SndBuff,lanRecBuff,lanRecCnt);
			_Sci_LanTbl.SndCnt= lanRecCnt;
//			send(SocketNo,_Sci_LanTbl.SndBuff,_Sci_LanTbl.SndCnt);		  // send
			send(SocketNo,(unsigned char*)"ABCDEFG012345",13);		  // send
#else
#ifdef	W51LOG
SaveRevLog();
#endif
			if(ProtocolDataProc(lanRecCnt,(char*)lanRecBuff,&_Sci_LanTbl) < 0){	continue;	}
 			if(_Sci_LanTbl.SndCnt > 0){
#ifdef	W51LOG
SaveSndLog();
#endif
				send(SocketNo,_Sci_LanTbl.SndBuff,_Sci_LanTbl.SndCnt);		  // send
			}
#endif
			break;
		case LAN_UDP_DISCON:		// UDP Disconnect
			disconnect(UDP_SOCKET);                // disconnect 
			Delay(100);
			socket(UDP_SOCKET,Sn_MR_UDP,Env.PortAddr,0);                  // open the SOCKET with UDP mode
			break;
		case LAN_UDP_READ:		//UDP Read(Loop Back)
			if(lanRecCnt > 0){
				destport= Env.PortAddr;
				sendto(UDP_SOCKET,lanRecBuff,lanRecCnt,destip,destport);
			}
			break;
		case LAN_INIT_SOCK:	//Mode Set
#ifndef	WIN32
			disconnect(SocketNo);         // disconnect 
			disconnect(UDP_SOCKET);                // UDP disconnect 
			LanIntDesable();
#endif
			Delay(100);
			SocketNo= (SocketNo+1) & 1;
			InitLanDrv(SocketNo);
			break;
		case LAN_CONNECT:
			LanConnectFlag= 1;
			break;
		case LAN_UDP_CONNECT:
			LanConnectFlag= 2;
			break;
		}
		_LanDrvMode= 0;
	}

}

//void	LanHandleTsk( STTFrm* pSTT )
//{
//	T_MAIL	*mp;

//   while(1){
//		mp= (T_MAIL*)WaitRequest();
//		switch(mp->mcmd){
//		case 0:
//			break;
//		default:
//			break;
//		}
//		ResponseMail((char*)mp);
//   }
//}
extern	int iinchip_irq(void);
int	_LanInterruptProc(void)
{
	int	ret= 0;

    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rSRCPND  = BIT_EINT1;
	pINTRegs->rINTPND  = BIT_EINT1;

	ret= iinchip_irq();

	pINTRegs->rSRCPND  = BIT_EINT1;
	if (pINTRegs->rINTPND & BIT_EINT1)
		pINTRegs->rINTPND = BIT_EINT1;
	pINTRegs->rINTMSK &= ~BIT_EINT1;

	return(ret);
}
void	_LanInterruptHandler( void )
{
	int	ret;
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_EINT1;
	ret= _LanInterruptProc();
	if(ret > 0){
   		_PendingRequest( ID_PAddFlag | _LanDrvTaskNo << 16 | 1 );
	}
	pINTRegs->rINTMSK &= ~BIT_EINT1;
}
void	SendLanInit(void)
{
	LanIntDesable();
	_LanDrvMode= LAN_INIT_SOCK;
	AddFlag(T_LAN_DRV,1);
}

