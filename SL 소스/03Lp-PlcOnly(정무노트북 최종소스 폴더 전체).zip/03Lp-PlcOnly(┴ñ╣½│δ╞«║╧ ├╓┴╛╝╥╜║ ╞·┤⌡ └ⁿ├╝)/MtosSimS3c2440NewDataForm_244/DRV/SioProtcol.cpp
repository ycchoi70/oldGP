/************************************/
/*	SIO�P�v���g�R��					*/
/************************************/
#define	SIOPROTOCOL_PROC
#include    "sgt.h"
#include    "hook_aplplc.h"

/****************************************************/
/*	PC-Connect(Barcode)								*/
/****************************************************/
int	ConnectPcBarcode(unsigned char rs_input_data,unsigned char *SioRecBuff,int *SioRecCnt)
{
	int	ret;

	ret = -1;
	if((rs_input_data == 0x0d) ||
		((rs_input_data >= 0x20) && (rs_input_data <= 0x7f))){
		if(*SioRecCnt < 1024){
			SioRecBuff[(*SioRecCnt)++] = rs_input_data;
		}
		if(rs_input_data == 0x0d){
			ret = 0;	/* Pendding Req */
		}
	}
	return(ret);
}
int PCDownThrue(unsigned char data,int *CommMode,int *SioRecCnt,unsigned char *SioRecBuff,int *CommCnt,int CommKind)		//2011.05.24
{
	int				i;
	unsigned char	bcc;
	int		ret;
	
	/*******************040608*******/
/*	if((BerRecTime+100) < _TimeMSec){ 061024 */	/* Time Out */
//	if(Chanel == 0){		//2011.05.24
#ifdef	WIN32
		if((_TimeMSec- BerRecTime) >= 3000){	/* Time Out */
#else
		int	waitCnt;
		if(CommKind == ETHERNET_CH0){	waitCnt= 1000;	}
		else{					waitCnt= 100;	}
		if((_TimeMSec- BerRecTime) >= waitCnt){	/* Time Out */
#endif
			*CommMode = 0;
			*SioRecCnt = 0;
		}
//	}		//2011.05.24
	BerRecTime= _TimeMSec;
	/*******************************/
	ret = -1;
	switch(*CommMode){
	case 0:		/* Normal */
		if(data == 0xfe){		/* DownLoad Header */
			*CommMode = 1;
			*SioRecCnt = 0;
		}else{
//			switch(Set.Ch1_iKind){
//			case UNIVERSAL:
//			case DEFAULT_PLC:
//				ret= PCDownThrueLG(data,CommMode,SioRecCnt,SioRecBuff);
//				break;
//			case ELSE_PLC:
//				if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
//					ret= PLCPCDOWN(data,CommMode,SioRecCnt,SioRecBuff);
//				}
//				break;
//			}
		}
		break;
	case 1:		/* Length1 */
		*CommCnt = data;
		*CommMode = 2;
		SioRecBuff[(*SioRecCnt)++] = data;
		break;
	case 2:		/* Length2 */
		*CommCnt = *CommCnt + data* 256 + 2;
//KSC20090112
		if(*CommCnt > PLC_BUF_MAX-10){			//20090112
			*CommCnt= PLC_BUF_MAX-10;			//20090112
		}										//20090112
		*CommMode = 3;
		SioRecBuff[(*SioRecCnt)++] = data;
		break;
	case 3:		/* Data */
		if(*SioRecCnt < *CommCnt){
			SioRecBuff[(*SioRecCnt)++] = data;
			if(*SioRecCnt >= *CommCnt){
				/* BCC ?�F�b�N */
				bcc = 0;
				for(i = 0; i < *CommCnt- 1; i++){
					bcc += SioRecBuff[i];
				}
				if(bcc == SioRecBuff[i]){
					ret = 0;	/* Pendding Req */
				}else{
					ret = -1;	/* BCC Error */
				}
			}
		}
		break;
	}
	return(ret);
}
/********************************************************************/
/*	�ėp�ʐM��M�v���g�R��											*/
/*																	*/
/********************************************************************/
int	RxCommProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret;

/* 20060202 */
	if(PlcTimeout != 0){
		if(sync_time < _TimeMSec - PlcTimeout){		/* 20061025 */
			*CommMode =0;
			*RecCnt = 0;
		}
	}
	PlcTimeout = _TimeMSec;
	
/***********************************/
	ret = -1;
	switch(*CommMode){
	case 0:		/* Idle */
		*CommMode = 1;
		*RecCnt = 0;
		RecBuff[(*RecCnt)++] = data;		/* Slave Address */
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		UnvPlcRecCnt= 6;
		UnvPlcRecCmd= data;					/* Command */
		switch(UnvPlcRecCmd){
		case 0x01:
		case 0x02:
		case 0x03:
		case 0x04:
		case 0x05:
		case 0x06:
			UnvPlcRecCnt= 6;
			break;
		case 0x07:
		case 0x0b:
		case 0x0c:
			UnvPlcRecCnt= 2;
			break;
//			break;
		case 0x0f:	/* �A��DO */
			UnvPlcRecCnt= 5;
			break;
		case 0x10:	/* �A���ێ����W�X? */
			UnvPlcRecCnt= 5;
			break;
		case 0x11:	/*  */
			UnvPlcRecCnt= 2;
			break;
		default:
			UnvPlcRecCnt= 6;
			break;
		}
		*CommMode = 2;
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		UnvPlcRecCnt--;
		if(UnvPlcRecCnt <= 0){
			if((UnvPlcRecCmd == 0x0f) || (UnvPlcRecCmd == 0x10)){
				UnvPlcRecCnt= data+ 2;		/* Write Cnt + CRC */
				*CommMode = 3;
			}else{
				ret= 0;		/* Command End */
				PlcTimeout= 0;
			}
		}
		break;
	case 3:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		UnvPlcRecCnt--;
		if(UnvPlcRecCnt <= 0){
			ret= 0;		/* Command End */
			PlcTimeout= 0;
		}
		break;
	}
	return(ret);
}
/****************************************************/
/*	Sio1-PC-Connect									*/
/****************************************************/
int	CheckDebugMode(unsigned char rs_input_data,UART_STRUCT* _SciTbl)
{
	int	ret= 1;
	if(DModeFlag == 0){
		if(rs_input_data == DebugPass[ConnectMode]){
			ConnectMode++;
			if(ConnectMode == 13){
//			if(ConnectMode == 3){
				DModeFlag= 0x10;
				_SciTbl->IntSioRecCnt= 0;
#ifdef	MODELTYPE_LP		//2011.01.19
				PlcSignalInf= OFF;
#endif
			}
		}else{
			ConnectMode= 0;
		}
	}
	if(DModeFlag != 0){
		if(rs_input_data == 0x08){		//BS
			if(_SciTbl->IntSioRecCnt > 0){
				_SciTbl->IntSioRecCnt--;
			}
			ret= -1;
		}else{
			_SciTbl->IntSioRecBuff[_SciTbl->IntSioRecCnt++] = rs_input_data;
			if(rs_input_data == CR){
				ret= 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
void	ReciveTimeOverCheck(UART_STRUCT* _SciTbl)
{
#ifdef	WIN32
	if((_TimeMSec- RecTimeOut) > 3000){
#else
	if((_TimeMSec- RecTimeOut) > 1000){
#endif
#ifdef	MODELTYPE_LP		//2011.01.19
		if(Matrix_Mode < ENQ_ANS_WAIT){
			_SciTbl->IntSioRecCnt= 0;
			_SciTbl->IntRecMode= 0;
			Matrix_Mode= IDLE;
		}
#endif
	}
	RecTimeOut= _TimeMSec;
}
int	ConnectPc(unsigned char rs_input_data,UART_STRUCT* _SciTbl,int* CommRecKind)
{
	int	ret;
//	int	iKind;
//	int	connectflag;
//	int	CommChanel;		//2011.05.24

	//Debug Monitor Check
	ret= CheckDebugMode(rs_input_data,_SciTbl);	if(ret != 1){	return(ret);	}			//Debugger
	//Get Kind
//	connectflag= 0;
//	CommChanel= 0;		//2011.05.24
//	if(_SciTbl->ch == SERIAL_CH1){			//== Port1
//		if(Set.Ch1_iConnect == SERIAL_PORT1){
//			iKind= Set.Ch1_iKind;
//		}else{
//			iKind= Set.Ch2_iKind;
//			connectflag= 1;
//		}
//	}else if(_SciTbl->ch == SERIAL_CH0){	//== Port0
//		if(Set.Ch1_iConnect == SERIAL_PORT0){
//			iKind= Set.Ch1_iKind;
//		}else{
//			iKind= Set.Ch2_iKind;
//			connectflag= 1;
//		}
//	}else{
//		CommChanel= 1;		//2011.05.24
//		iKind= EDITER;
//	}
//	switch(iKind){
//	case UNIVERSAL:		ret= RxCommProc(rs_input_data,(int*)&_SciTbl->IntRecMode,(int*)&_SciTbl->IntSioRecCnt,_SciTbl->IntSioRecBuff);	break;
//	case DEFAULT_PLC:	ret= PlcRecRS(rs_input_data,(int*)&_SciTbl->IntRecMode,(int*)&_SciTbl->IntSioRecCnt,_SciTbl->IntSioRecBuff);									break;
//	case ELSE_PLC:
//		if(connectflag == 0){		//Chanel Flag
//			if(CommonArea.PlcType1.PlcUserFlag != 0){	/* 2008.12.10 */
//				ret= PLC1CHAR_READ(rs_input_data,(int*)&_SciTbl->IntRecMode,(int*)&_SciTbl->IntSioRecCnt,_SciTbl->IntSioRecBuff);
//			}
//			else{
//				ret= RxCommProc(rs_input_data,(int*)&_SciTbl->IntRecMode,(int*)&_SciTbl->IntSioRecCnt,_SciTbl->IntSioRecBuff); // 20120222 by Jmson
//			}
//		}else{
//			if(CommonArea.PlcType2.AuxPlcUserFlag != 0){	/* 2008.12.10 */
//				ret= PLC2CHAR_READ(rs_input_data,(int *)&_SciTbl->IntRecMode,(int *)&_SciTbl->IntSioRecCnt,_SciTbl->IntSioRecBuff);
//			}
//		}
//		break;
//	case EDITER:		/* Editor */
		ReciveTimeOverCheck(_SciTbl);
#ifdef	MODELTYPE_LP		//2011.01.19
		if((_SciTbl->IntRecMode == 0) && (rs_input_data != 0xfe)){
			ret= Rs232c_Char_Proc(rs_input_data,(int *)&_SciTbl->SndCnt,_SciTbl->SndBuff,(int *)&_SciTbl->IntSioRecCnt,_SciTbl->IntSioRecBuff);
			*CommRecKind= 1;
		}else{
			ret= PCDownThrue(rs_input_data,(int*)&_SciTbl->IntRecMode,(int *)&_SciTbl->IntSioRecCnt,_SciTbl->IntSioRecBuff,
//				(int *)&_SciTbl->IntCommCnt,_SciTbl->ch,CommChanel);		//2011.05.24
				(int *)&_SciTbl->IntCommCnt,_SciTbl->ch);
			*CommRecKind= 0;
		}
#else
		ret= PCDownThrue(rs_input_data,(int*)&_SciTbl->IntRecMode,(int *)&_SciTbl->IntSioRecCnt,_SciTbl->IntSioRecBuff,
//			(int *)&_SciTbl->IntCommCnt,_SciTbl->ch,CommChanel);		//2011.05.24
			(int *)&_SciTbl->IntCommCnt,_SciTbl->ch);

		*CommRecKind= 0;
#endif
//		break;
//	case MONITOR:
//		ret= PCDownThrue(rs_input_data,(int *)&_SciTbl->IntRecMode,(int *)&_SciTbl->IntSioRecCnt,_SciTbl->IntSioRecBuff,
//			(int *)&_SciTbl->IntCommCnt,_SciTbl->ch,CommChanel);		//2011.05.24
//			(int *)&_SciTbl->IntCommCnt,_SciTbl->ch);
//		break;
//	case BAR_CODE:
//		ret= ConnectPcBarcode(rs_input_data,_SciTbl->IntSioRecBuff,(int *)&_SciTbl->IntSioRecCnt);
//		break;
//	case ELSE_PLC:
//		if(CommonArea.PlcType2.AuxPlcUserFlag != 0){	/* 2008.12.10 */
//			ret= PLC2CHAR_READ(rs_input_data,(int *)&_SciTbl->IntRecMode,(int *)&_SciTbl->IntSioRecCnt,_SciTbl->IntSioRecBuff);
//		}
//		break;
//	}
	return(ret);
}
/********************************************************************/

/****************************************/
/*	Editor Boadrate Setting				*/
/****************************************/
void	SetEditorBoadrate( int connect, int set_ch )
{
//	int		Kind;			//2012.02.23

//	if(connect == SERIAL_PORT0){	Kind= SERIAL_PORT0;	}
//	else{					Kind= SERIAL_PORT1;	}


	if(set_ch == SERIAL_CH0){	RsModeSetChanel(connect,Set.Ch1_iKind,&Set.Ch1_Serial_Param[0]);	}
	else{						RsModeSetChanel(connect,Set.Ch2_iKind,&Set.Ch2_Serial_Param[0]);	}
}
void	SetRsPortPriority(int port,int kind)
{
	int	taskNo;
	int	priority;

	if(port == SERIAL_PORT0){	taskNo= T_SIO422DRV;	}
	else{			taskNo= T_SIO232DRV;	}
	if(kind == EDITER){	priority= 0x19;	}
	else{				priority= 0x15;	}
	ChangeTaskPriority(taskNo,priority);
}
void	Rs232cBordrateSet( void )
{
//	int		Speed;
//	int		DataBit;
//	int		Parity;
//	int		port;

	/* CH1 Boarate Set */
//	if(Set.Ch1_iConnect == SERIAL_PORT0){	port= SERIAL_PORT0;	}	/* PLC = RS-422 */
//	else{							port= SERIAL_PORT1;	}


	SetRsPortPriority(Set.Ch1_iConnect,Set.Ch1_iKind);	//Set RsPort Priority
//	switch(Set.Ch1_iKind){
//	case EDITER:
		SetEditorBoadrate(Set.Ch1_iConnect,SERIAL_CH0);
//		PlcConnectFlag= 0;
		ClearPlc1ConnectFlag();
//		if(port == SERIAL_PORT1){	PlcEditorPort= 1;	}	//Editor Port Check
//		else{				PlcEditorPort= 0;	}
//		break;
//	case MONITOR:		break;
//	case DEFAULT_PLC:
//		if((Def_Get_Ms_Sel() & 0xFF00) == 0x0100){		/* External Set Apl Serial Set */
//			RsModeSetChanel(port,Set.Ch1_iKind,&Set.Ch1_Serial_Param[0]);
//		}
//		break;
//	case ELSE_PLC:
//		if(IsPlc1Protocol() == OK){
//			if((GET_MS_SEL() & 0xFF00) == 0x0100){		/* External Boadrate Set */
//				RsModeSetChanel(port,Set.Ch1_iKind,&Set.Ch1_Serial_Param[0]);
//			}
//		}
//		break;
//	case PLCTYPE2:		break;
//	default:
//		RsModeSetChanel(port,Set.Ch1_iKind,&Set.Ch1_Serial_Param[0]);
//		break;
//	}
#ifdef	WIN32
extern	int	CheckSetting(void);
	while(1){
		if(CheckSetting() == 0){	break;	}
		Delay(100);
	}
#endif
	/* CH2 Boarate Set */
	SetRsPortPriority(Set.Ch2_iConnect,Set.Ch2_iKind);	//Set RsPort Priority
//	if(Set.Ch2_iConnect == SERIAL_PORT0){	port= SERIAL_PORT0;	}	/* PLC = RS-422 */
//	else{							port= SERIAL_PORT1;	}
//	switch(Set.Ch2_iKind){
//	case EDITER:
		SetEditorBoadrate(Set.Ch2_iConnect,SERIAL_CH1);
//		if(port == SERIAL_PORT1){	PlcEditorPort= 1;	}		//Editor Port Check
//		else{				PlcEditorPort= 0;	}
//		break;
//	case MONITOR:
//		switch(Set.Ch1_iKind){
//		case UNIVERSAL:
//			RsModeSetChanel(port,Set.Ch2_iKind,&Set.Ch2_Serial_Param[0]);		/* 2009.09.04 Add Stop */
//			break;
//		case DEFAULT_PLC:
//			if((Def_Get_Ms_Sel() & 0xFF00) == 0x0100){		/* Apl Serial Set */
//				RsModeSetChanel(port,Set.Ch2_iKind,&Set.Ch2_Serial_Param[0]);		/* 2009.09.04 Add Stop */
//			}else{
//				LG_GetMonBaudrate(&Speed,&DataBit,&Parity);
//				RsModeSet(port,RS_INIT,Speed, DataBit, Parity);
//			}
//			break;
//		case ELSE_PLC:
//			if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
//				if((GET_MS_SEL() & 0xFF00) == 0x0100){		/* Apl Serial Set */
//					RsModeSetChanel(port,Set.Ch2_iKind,&Set.Ch2_Serial_Param[0]);		/* 2009.09.04 Add Stop */
//				}else{
//					GET_MON_BAUDRATE(&Speed,&DataBit,&Parity);
//					RsModeSet(port,RS_INIT,Speed, DataBit, Parity);
//				}
//			}
//			break;
//		}
//		break;
//	case ELSE_PLC:
//		if(IsPlc2Protocol() == OK){	/* 2008.12.10 */
//			if((GET_MS_SEL2() & 0xFF00) == 0x0100){		/* Apl Serial Set */
//				RsModeSetChanel(port,Set.Ch2_iKind,&Set.Ch2_Serial_Param[0]);		/* 2009.09.04 Add Stop */
//			}
//		}
//		break;
//	default:
//		RsModeSetChanel(port,Set.Ch2_iKind,&Set.Ch2_Serial_Param[0]);		/* 2009.09.04 Add Stop */
//		break;
//	}
//	if((Set.Ch1_iKind == EDITER) || (Set.Ch2_iKind == EDITER)){
//		PlcConnectFlag= 0;
//		ClearPlc1ConnectFlag();
//	}
}
void	RsModeSetChanel(int port,int Kind,_SERIALPARAM* pParam)		//2009.09.04
{
	int	Speed;
	int	Parity;
	int	DataBit;

	Speed = pParam[Kind].iSpeed;			/* 9600 */
	Parity = pParam[Kind].iParity;			/* 0:NONE,1:ODD,2:EVEN */
	Parity |= (pParam[Kind].iStop << 8);	/* 0:STOP1,1:STOP2 */
	DataBit = pParam[Kind].iData1;			/* 0:7,1:8 */
	RsModeSet(port,RS_INIT,Speed, DataBit, Parity);
}
#ifdef	WIN32
void	RsModeSetWin(int port,int mode,int bordrate,int ldata,int parity)
{
	int	idx;

	if(port == SERIAL_PORT0){	SioPLCOpenFlag= 1;	idx= 1;		SioPLCMode= 99;	}
	else{				SioPCOpenFlag= 1;	idx= 0;		SioPCMode= 99;	}
	switch(bordrate){
	case RS_300:	simspeed[idx]= 300;		break;
	case RS_600:	simspeed[idx]= 600;		break;
	case RS_1200:	simspeed[idx]= 1200;	break;
	case RS_2400:	simspeed[idx]= 2400;	break;
	case RS_4800:	simspeed[idx]= 4800;	break;
	case RS_9600:	simspeed[idx]= 9600;	break;
	case RS_19200:	simspeed[idx]= 19200;	break;
	case RS_38400:	simspeed[idx]= 38400;	break;
	case RS_57600:	simspeed[idx]= 57600;	break;
	case RS_115200:	simspeed[idx]= 115200;	break;
	}
	if(ldata == RS_DATA7){	simdata[idx]= 7;	}
	else{					simdata[idx]= 8;	}
	simparity[idx]= parity & 0x00ff;		//2009.09.04
	simstop[idx]= (parity & 0xff00) >> 8;	//2009.09.04
	return;
}
void	RsModeSetChanelWin(int port,int Kind,_SERIALPARAM* pParam)		//2009.09.04
{
	int	Speed;
	int	Parity;
	int	DataBit;

	Speed = pParam[Kind].iSpeed;			/* 9600 */
	Parity = pParam[Kind].iParity;			/* 0:NONE,1:ODD,2:EVEN */
	Parity |= (pParam[Kind].iStop << 8);	/* 0:STOP1,1:STOP2 */
	DataBit = pParam[Kind].iData1;			/* 0:7,1:8 */
	RsModeSetWin(port,RS_INIT,Speed, DataBit, Parity);
}
#endif
/****************************************************/
/*	SIO Mode Set									*/
/****************************************************/
/* int parity 0xff00:stop,0x00ff:parity				*/
void	RsModeSet(int port,int mode,int bordrate,int ldata,int parity)
{
#ifdef	WIN32
	int	idx;

	if(port == SERIAL_PORT0){	SioPLCOpenFlag= 1;	idx= 1;		SioPLCMode= 99;	}
	else{				SioPCOpenFlag= 1;	idx= 0;		SioPCMode= 99;	}
	switch(bordrate){
	case RS_300:	simspeed[idx]= 300;		break;
	case RS_600:	simspeed[idx]= 600;		break;
	case RS_1200:	simspeed[idx]= 1200;	break;
	case RS_2400:	simspeed[idx]= 2400;	break;
	case RS_4800:	simspeed[idx]= 4800;	break;
	case RS_9600:	simspeed[idx]= 9600;	break;
	case RS_19200:	simspeed[idx]= 19200;	break;
	case RS_38400:	simspeed[idx]= 38400;	break;
	case RS_57600:	simspeed[idx]= 57600;	break;
	case RS_115200:	simspeed[idx]= 115200;	break;
	}
	if(ldata == RS_DATA7){	simdata[idx]= 7;	}
	else{					simdata[idx]= 8;	}
	simparity[idx]= parity & 0x00ff;		//2009.09.04
	simstop[idx]= (parity & 0xff00) >> 8;	//2009.09.04
	while(1){
		if(port == SERIAL_PORT0){
			if(SioPLCOpenFlag == 0){	break;	}
		}else{
			if(SioPCOpenFlag == 0){	break;	}
		}
		Delay(100);
	}
	return;
#else
	T_MAIL	*mp;
	int		mbx;
	int		OldResp;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RS_CNTL;
	mp->mext = mode;
	if(mode == RS_INIT){
		mp->mpar = bordrate;
		mp->mpec = ldata;
		mp->mcod = parity;
	}
	if(port == SERIAL_PORT0){	SendMail( T_SIO422DRV, (char *)mp );	}
	else{				SendMail( T_SIO232DRV, (char *)mp );	}
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	FreeMail((char *)mp);
	FreeMbx(mbx);
#endif
}
/****************************************************/
/*	RTS ON/OFF Set									*/
/****************************************************/
void	RtsOnOffSet(int port,int mode)
{
	T_MAIL	*mp;
	int		mbx;
	int		OldResp;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = mode;
	if(port == SERIAL_PORT0){	SendMail( T_SIO422DRV, (char *)mp );	}
	else{				SendMail( T_SIO232DRV, (char *)mp );	}
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	FreeMail((char *)mp);
	FreeMbx(mbx);
}

///////////////////////////////////////////////////////////
void	ClearPlc1ConnectFlag(void)
{
	memset(PlcConnectFlag,0,sizeof(PlcConnectFlag));
}
void	ClearConnectFlag(void)
{
	memset(PlcConnectFlag,0,sizeof(PlcConnectFlag));
	memset(&PlcConnectFlag2[0],0,sizeof(PlcConnectFlag2));				/* ksc20090525 */
//	memset(&GroopInf,0,sizeof(GroopInf));
//	memset(&GroopInf.GrpIdx.GroopIdx[0],-1,sizeof(GroopInf.GrpIdx.GroopIdx));
}
/////////////////////////////////////////////////////////
