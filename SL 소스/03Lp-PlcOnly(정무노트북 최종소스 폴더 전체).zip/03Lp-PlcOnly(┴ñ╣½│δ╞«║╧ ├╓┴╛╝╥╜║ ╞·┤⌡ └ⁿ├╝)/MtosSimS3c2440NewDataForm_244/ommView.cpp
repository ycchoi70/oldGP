// ommView.cpp : �C���v�������e�[�V���� �t�@�C��
//

#include "stdafx.h"
#include "mtsap.h"
#include "ommView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CommView

IMPLEMENT_DYNCREATE(CommView, CView)

CommView::CommView()
{
	// TODO: ���̏ꏊ�ɍ\�z�p�̃R�[�h��ǉ����Ă��������B
	/*---------------------------------------------------------------------*/
	/* �ϐ�������*/
	m_nBaudRate = 9600;     /* ���x*/	
	m_bPortInit[0] = FALSE; /* �|�[�g�������t���O*/
	m_bPortInit[1] = FALSE; 
	m_bPortInit[2] = FALSE; 
	m_bPortInit[3] = FALSE; 
	SerialInit();
	/*---------------------------------------------------------------------*/		
}

CommView::~CommView()
{
}


BEGIN_MESSAGE_MAP(CommView, CView)
	//{{AFX_MSG_MAP(CommView)
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
	//}}AFX_MSG_MAP
	/*---------------------------------------------------------------------*/	
	ON_MESSAGE(WM_COMM_READ,OnCommunication) /* �C�ʐM���b�Z�[�WHandler*/
	/*---------------------------------------------------------------------*/
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CommView �`��

void CommView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: ���̈ʒu�ɕ`��p�̃R�[�h��ǉ����Ă�������
}

/////////////////////////////////////////////////////////////////////////////
// CommView �f�f

#ifdef _DEBUG
void CommView::AssertValid() const
{
	CView::AssertValid();
}

void CommView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CommView ���b�Z�[�W �n���h��
/******************************************************************************
'Procedure          :OnCommunication
'Summary            :�EWM_COMM_READ Message CallBack�֐�
'Parameters         :
'Return Value       :
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
LONG CommView::OnCommunication(int port, long lParam)
{
	BYTE aByte;

	int size= (m_ComuPort[port-1].m_QueueRead).GetSize();
	for( int i=0; i< size; i++ )
	{
		(m_ComuPort[port-1].m_QueueRead).GetByte(&aByte);
		if( aByte!= NULL ) m_RecieveBuff[i]= aByte;
		else { i--; size--; }
	}	
/*
	for( i= 0; i< size; i++ )
	{
		ch= buff[i];
		
		PutChar(port,(unsigned char)ch);
	}	
*/
	return 0;
}

/******************************************************************************
'Procedure          :PutChar
'Summary            :��M�f�[�^�\��
'Parameters         :
'Return Value       :
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
#ifdef	OLD
void CSerialCommView::PutChar(int port,unsigned char ch)
{
	CDC *pDC;
	TEXTMETRIC tm;

	pDC= GetDC();
	pDC->GetTextMetrics(&tm);

	if( ch == 10 ) {
		//LF��M���f�[�^�\��
		m_listBox[port-1].InsertString(0,m_strLine[port-1]);
		m_nColPos= 0;	
		m_strLine[port-1].Empty();
	}else{
		// �f�[�^�ǉ�
		m_strLine[port-1].Insert( m_nColPos, ch );
		m_nColPos++;
	}

	/*
	if( ch==10 ) {
		// LF
		m_nLinePos++;			
		if( m_nLinePos>25 ) {
			m_nLinePos= 0;
			m_nColPos= 0;
			ClearAll();
		}
	}else if( ch==13 ){
		// CR
		m_nColPos= 0;
	}else{
		// �f�[�^�\��
		m_strLine[m_nLinePos].Insert( m_nColPos, ch );
		pDC->TextOut(0,m_nLinePos*tm.tmHeight,m_strLine[m_nLinePos]);
		m_nColPos++;
	}
	*/
}
/******************************************************************************
'Procedure          :ProcessErrorMessage
'Summary            :�G���[���b�Z�[�W�\��
'Parameters         :
'Return Value       :
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
void CommView::ProcessErrorMessage(CString msg)
{
	((CMainFrame *)AfxGetMainWnd())->SetStatusBarMessage(msg);
}

/******************************************************************************
'Procedure          :OnSerialSet
'Summary            :�ʐM�|�[�g�ݒ�(m_nPort�Am_nBaudRate)
'Parameters         :
'Return Value       :
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
void CSerialCommView::OnSerialSet() 
{
	/* �F�ʐM�|�[�g�ݒ�(m_nPort�Am_nBaudRate)*/	
	
	if( dlg.DoModal()== IDOK )
	{
		m_nPort= dlg.GetPort();
		m_nBaudRate= dlg.GetBaudRate();
		SerialInit();
	}
	
}
#endif
/******************************************************************************
'Procedure          :OnSerialInit
'Summary            :�ʐM�|�[�g������(Open)
'Parameters         :
'Return Value       :
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
void CommView::SerialInit() 
{
//	if( m_nPort== 0 ){
//		ProcessErrorMessage(_T("�|�[�g��ݒ肵�ĉ������B"));
//		return;
//	}

	CString strTemp;
	strTemp.Format("COM%d", m_nPort);
	/*---------------------------------------------------------------------*/
	/* �DWindow Handle�ݒ�(CommThread�̃��b�Z�[�W���M��Handle)*/
	m_ComuPort[m_nPort-1].SetWindowHandler(m_hWnd);
	/*---------------------------------------------------------------------*/
	/* �G�ʐM�|�[�gOpen*/
	if( !m_ComuPort[m_nPort-1].OpenPort( strTemp, m_nBaudRate, m_nPort ) ){
//		ProcessErrorMessage(_T("�|�[�g���������s!"));
	}else{
//		CString strTemp;
//		strTemp.Format( "�|�[�gCOM%d����������!", m_nPort );
//		ProcessErrorMessage(strTemp);	
//		m_bPortInit[m_nPort-1]= TRUE;
//		m_inputBox.EnableWindow(TRUE);
//		m_outputBox.EnableWindow(TRUE);
//
//		m_inputBox.SetFocus();
//		m_listBox[m_nPort-1].EnableWindow(TRUE);
//		strTemp.Format( "COM%d �I�[�v��!", m_nPort );
//		m_listBox[m_nPort-1].AddString(strTemp);
	}	

}

/******************************************************************************
'Procedure          :OnReturn
'Summary            :Enter�L�[���͎��f�[�^���M
'Parameters         :
'Return Value       :
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
void CommView::DataSend(int port,char *buff, int cnt) 
{	
//	int port;
//	CString strInput;
//	CString strSend;

//	port=m_outputBox.GetCurSel();

//	m_inputBox.GetWindowText(strInput);
//	strSend.Format("%s%c", strInput, 10);   
	// �H�f�[�^���M
//	if(port >=0 && port <4){
//		if( m_bPortInit[port] ){
//			m_ComuPort[port].WriteComm((unsigned char*)(LPCTSTR)strSend,strSend.GetLength());		
//		}else{
//			AfxMessageBox("�o�̓|�[�g���I�[�v�����ĉ������B");
//		}
//	}else{
//		AfxMessageBox("�o�̓|�[�g��ݒ肵�ĉ������B");
//	}
	m_ComuPort[port].WriteComm((unsigned char*)(LPCTSTR)buff,cnt);		
	
}

