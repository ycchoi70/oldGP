#include    "Mts.h"
#include    "MtsCorep.h"
#include    "MtsSmphp.h"

/********************************************************
*                                                       *
*       �Z�}�t�@�[�̏�����                              *
*                                                       *
*       void    i_op( int sn, int in )                  *
*                                                       *
*       �����F  �Z�}�t�@�[�ԍ�                          *
*       �����F  �����l                                  *
*                                                       *
********************************************************/
void    _i_op( int* pParam )
{
    _Smp[pParam[0]].SmpCounter= pParam[1];
}

/********************************************************
*                                                       *
*       �Z�}�t�@�[�҂�                                  *
*                                                       *
*       int     p_op( int sn )                          *
*                                                       *
*       �����F  �Z�}�t�@�[�ԍ�                          *
*       ���A���F                                      *
*       �s�h�l�d�Q�n�t�s�F      �^�C���E�A�E�g          *
*       ���̑��F                �Z�}�t�@�[��            *
*                                                       *
********************************************************/
int     _p_op( int* pParam )
{
    SmpFrm* pSmp;

    pSmp= &_Smp[pParam[0]];
    if ( --pSmp->SmpCounter >= 0 ) {
        _ReadyQue->Timer.TimeOutCounter= 0;
    }
    else {
        _LinkPriorityTcb( (TcbFrm*)pSmp, _LinkOffReadyQue(), W_Semaphore );
    }
    return pSmp->SmpCounter;
}

/********************************************************
*                                                       *
*       �Z�}�t�@�[���Z                                  *
*                                                       *
*       int     v_op( int pn )                          *
*                                                       *
*       �����F          �Z�}�t�@�[�ԍ�                  *
*       ���A���F      �Z�}�t�@�[��                    *
*                                                       *
********************************************************/
int     _v_op( int* pParam )
{
    SmpFrm* pSmp;
    TcbFrm* pTcb;

    pSmp= &_Smp[pParam[0]];
    if ( ++pSmp->SmpCounter <= 0 ) {
        pTcb= pSmp->pLink;
        pSmp->pLink= pTcb->pLink;
        _LinkReadyQue( pTcb );
    }
    return pSmp->SmpCounter;
}
