#include    "cpu.h"
#include    "Mts.h"
#include    "MtsScID.h"
#include    "MtsCorep.h"
#include    "MtsSchdp.h"
#include    "MtsTimep.h"

/********************************************************
*                                                       *
*       �^�C���E�A�E�g�萔�ݒ�                          *
*                                                       *
*       int     set_timer( int et )                     *
*                                                       *
*       �����F  �^�C���E�A�E�g�萔                      *
*                                                       *
********************************************************/
int     _SetTimeOut( int* pParam )
{
    int     OldTimeOut;
    
    OldTimeOut= _ReadyQue->Timer.TimeOutCounter;
    _ReadyQue->Timer.TimeOutCounter= pParam[0];
    return OldTimeOut;
}

/********************************************************
*                                                       *
*       �莞�ԑ҂�                                      *
*                                                       *
*       void    Delay( int dt )                         *
*                                                       *
*       �����F  �҂�����                                *
*                                                       *
********************************************************/
void    _Delay( int* pParam )
{
    TcbFrm* pTcb;
    
    if ( ( _ReadyQue->Timer.TimeOutCounter= pParam[0] ) > 0 ) {
        pTcb= _LinkOffReadyQue();
        pTcb->WaitQue= (TcbFrm*)0;
    }
}

void    _ISystemClockHandler( int* pParam )
{
    TcbFrm* pTcb;

    while( _TimerQue != 0 && ( _TimerQue->TimeOutCounter -= pParam[1] ) <= 0 ) {
        pParam[1]=  - _TimerQue->TimeOutCounter;
        pTcb= (TcbFrm*)((unsigned char*)_TimerQue - ( (unsigned char*)&pTcb->Timer - (unsigned char*)pTcb ));
	    pTcb->DataReg[0]= R_TimeOut;
        _TimerQue= _TimerQue->pLink;          /* �s��������O��   */
        if ( pTcb->WaitQue != 0 ) { /* �X�ɑ��̃L���[�Ɏ�����Ă���ΊO��   */
            _OffQue( (TcbFrm*)pTcb->WaitQue, pTcb );
            switch( pTcb->Status & 0x7f ) {
            case W_Mail:
            case W_Mbx:
                ((MbxFrm*)pTcb->WaitQue)->MailCount++;
                break;
            case W_Semaphore:
                ((SmpFrm*)pTcb->WaitQue)->SmpCounter++;
                break;
            case W_Flag:
            case W_Signal:
            case W_Timer:
            case W_Ready:
            default:
                break;
            }
        }
        pTcb->Status &= 0x7f;   /* ���ɂs��������O���Ă���̂ŕK�v */
        _LinkReadyQue( pTcb );
    }
}



/****************************************
*       timer interrupt                 *
****************************************/
/********************************************************
*                                                       *
*       ������ŋN��                                    *
*                                                       *
*       �������s�̓V�X�e���E�萔                        *
*               �s�h�l�Q�h�m�b�A                        *
*               �s�h�l�Q�c�h�u�ɂ��ȉ��̗l�ɒ�`����  *
*                                                       *
*       ���s���s�h�l�Q�h�m�b�^�s�h�l�Q�c�h�u            *
*                                                       *
*       ��P�@�U�O�g���̏ꍇ                            *
*               �s�h�l�Q�h�m�b���P�O�O�O�i�P�ʂ��b�j    *
*               �s�h�l�Q�c�h�u���@�@�U�O                *
*               ���邢��                                *
*               �s�h�l�Q�h�m�b���@�@�T�O                *
*               �s�h�l�Q�c�h�u���@�@�@�R                *
*               �Ƃ��Ă�����                            *
*                                                       *
********************************************************/
unsigned    _TimeMSec;
extern  void    WaitUSec( int cnt );
extern	void	RESET_INT(void);
extern	void	INT_FLAG_DEC(void);
extern	void	INT_FLAG_INC(void);

int	IntFlag = 0;
int	DebugSW	= 0;
unsigned    DebugTimeMSec;
#ifndef	WIN32
#pragma interrupt  ( _SystemClockInterruptHandler )
#endif
int		IncTimeCnt( void )
{
    _TimeMSec += SystemClockInterval;
	if(DebugSW == 1){			/* �P�O�O������~���Ă�����N�� */
		if((DebugTimeMSec+ 100) < _TimeMSec){
			DebugSW = 0;
		}
	}
	return(0);
}
void	_SystemClockInterruptHandler( void )
{
	int		ret;
	
#ifdef  VC300
extern  void    InitTimer();
    _InitTimer();
#endif

	ret = IncTimeCnt();
	INT_FLAG_INC();
#ifndef	OLD
	if(DebugSW == 0){
		if(ret == 0){
		    _PendingRequest( ID_PSystemClock | SystemClockInterval );
		}
	}
#endif
	INT_FLAG_DEC();
#ifndef	WIN32
	*(unsigned short *)CPU_CMCSR0 &= 0x007f;
#endif
}

unsigned    ReadTimeMsec( void )
{
    return _TimeMSec;
}

/********************************
*                               *
*       soft wait               *
*                               *
********************************/
void    SWait( void )
{
}

