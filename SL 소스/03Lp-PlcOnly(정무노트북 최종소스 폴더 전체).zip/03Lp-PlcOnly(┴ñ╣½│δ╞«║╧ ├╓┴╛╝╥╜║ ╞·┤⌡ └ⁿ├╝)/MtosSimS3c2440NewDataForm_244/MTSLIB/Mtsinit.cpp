#include    <String.h>
#include    "Mts.h"
#include    "MtsCorep.h"
#include    "MtsErrop.h"
#include    "MtsMailp.h"

void    MtsInit( void );
extern  void  _UserInit( void );
extern  void  SetVBR( void );
extern	int	_SystemState;
//extern	void	FontSet(void);
/********************************************************
*   MTS�X�^�[�g                                         *
********************************************************/
extern	int	IntFlag;
extern	int	DebugSW;
extern	int	timeLoopCnt;

void    _Start( void )
{
//	unsigned	*src;
//	int			i;
	
	/* RAM Clear */
//	src= (unsigned *)0x800000;
//	for(i= 0; i < 0x5e000/4; i++){
//		*src= 0;
//		src++;
//	}
	_SystemState = 0;
	timeLoopCnt= 0;
    MtsInit();
	IntFlag= 0;
	DebugSW= 0;


}

/********************************************************
*   ���荞�݃x�N�^�[�̏�����                            *
********************************************************/
void    _InitPending( void )
{
    _PendingOup= _PendingInp= _PendingBuf;
}

/********************************************************
*   ���荞�݃x�N�^�[�̏�����                            *
********************************************************/
//extern  void    _SystemCallHandler( void );
//extern  void    _SystemLevelCallHandler( void );
extern  void    (*_InterruptVector[])(void);
extern  VctFrm  _InterruptVectorTable[];
extern  void    _IntError( void );
extern	void	InitRegDi(unsigned int *p);		/* ���W�X�^������ */
extern	void	InitRegEi(unsigned int *p);		/* ���W�X�^������ */
#ifdef	WIN32
void    _InitVector( void )
{
    VctFrm* pVct;
#ifndef WIN32       /* 98.11.12 */
    int     i;
    for(i = 0; i < 0x100; i++){
        _InterruptVector[i] = _IntError;
    }
#endif
    for( pVct= _InterruptVectorTable; pVct->VectorNo != 0; pVct++ ) {
        _InterruptVector[pVct->VectorNo]= pVct->pIntFnc;
    }
#ifndef WIN32
//    _InterruptVector[SystemCallVector]= _SystemCallHandler;
//    _InterruptVector[SystemLevelCallVector]= _SystemLevelCallHandler;
#endif
}
#endif
/********************************************************
*   �^�X�N�̏�����                                      *
********************************************************/
unsigned*   _Ssp;
unsigned*   _Usp;
void        (*Entry)( STTFrm* pSTT );
extern int Delay(int);
void    SetTcb( STTFrm* pSTT,int flag )
{
    TcbFrm* pTcb;
    pTcb= &_Tcb[pSTT->TaskNo];
	memset(pTcb,0,sizeof(TcbFrm));
    pTcb->Priority= pSTT->Priority;
    pTcb->Comment=  ('I' << 24) + ('n' << 16) + ('i' << 8) + 't';
    pTcb->SPTop=    pSTT->StackArea;
    pTcb->MyTaskNo= pSTT->TaskNo;
    
    Entry=    pSTT->Entry;
    pTcb->PCInt=    Entry;
/*  memset( pTcb->SPTop, 0x55, pSTT->StackSize );*/
    memset( pTcb->SPTop, 0x00, pSTT->StackSize );
    _Usp= (unsigned*)(pSTT->StackArea + pSTT->StackSize);
#ifdef  WIN32
    _asm    {
        mov     _Ssp,esp
        mov     esp,_Usp
        push    pSTT
        push    _SysErrorReturn
        push    Entry
        pushad
        mov     _Usp,esp
        mov     esp,_Ssp
    }
#else
    *((STTFrm**)(--_Usp))= 0;
    *((void(**)(void))(--_Usp))= 0;
#endif
#ifdef	WIN32
    pTcb->AdrsReg[7]= (unsigned char*)_Usp;
#else
	if(flag == 0){
		InitRegDi(&pTcb->SrReg);
	}else{
		InitRegEi(&pTcb->SrReg);
	}
    pTcb->AdrsReg[5]= (unsigned char*)_Usp;				/* ARM7TDI */
#endif
    _LinkReadyQue( pTcb );   /*  �q�c�p�Ɍq��    */
}
void    SysReceiveTask( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
void    SysSendTask( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
void    C104RecieveDrv( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
void    ElseC104SndRcv( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
const	STTFrm  _StaticTaskTableSys[]= {
{ 0, }
};

void    _InitTcb( void )
{
    STTFrm* pSTT;
	int		flag;
    
    memset( _Tcb, 0, sizeof _Tcb );
	flag= 0;
    for( pSTT= (STTFrm*)_StaticTaskTableUsr; pSTT->Entry != 0; pSTT++ ) {
        SetTcb( pSTT,flag++ );
    }
    for( pSTT= (STTFrm*)_StaticTaskTableSys; pSTT->Entry != 0; pSTT++ ) {
        SetTcb( pSTT,flag++ );
    }
}

/*********************************************************
*   �l�a�w�̏�����                  *
*********************************************************/
void    _InitMbx( void )
{
    int     i;
    MbxFrm* pMbx;
    
    memset( _Mbx, 0, sizeof _Mbx );
    for( i= 0; i < TBQ(_Mbx); i++ ) {
        pMbx= &_Mbx[i];
        pMbx->MyMbxNo= i;
        pMbx->OwnerTaskNo= _S_NoOwner;
        pMbx->pTail= (TcbFrm*)pMbx;
    }
    for( i= 0x80; i < 0xf0; i++ ) {
        _FreeMbx( &i );
    }
}

void    _InitMail( void )
{
    int         i;
    SMTFrm*     pSMT;
    MHedFrm*    pMHed;
    MbxFrm*     pMbx;
    char*       pMail;
    pMHed= (MHedFrm*)_MailArea;
    pMbx=  _MbxMemory;
    for( pSMT= _SMT; pSMT->Size > 0; pSMT++ ) {
        for( i= 0; i < pSMT->Count; i++ ) {
            memset( pMHed, 0, sizeof( MHedFrm ) );
            pMHed->DataType=  _S_Domestic;  /* 4:0:�W�U�n�C1:�U�W�n*/
            pMHed->RespMbx=   _S_Domestic;    /*  5:�ԐM�l�����ԍ�    */
            pMHed->Priority=  _S_Unschedule;   /*  6:���[���̗D�揇��  */
            pMHed->OwnerTask= _S_NoOwner;  /*  7:�z�[���l�����m��  */
            pMHed->HomeMbx=   pMbx->MyMbxNo;    /*  8:�z�[���l�����m��  */
            pMHed->Size=      pSMT->Size;
            pMHed->XHomeMbx = 0;	/* ����CPU�̃z�[�����[���{�b�N�X�p 98.7.23 */
            pMail= (char*)(pMHed+1);
            _MailAreaLast=  pMail + pSMT->Size;
            _FreeMail( (int*)&pMail );
            pMHed= (MHedFrm*)_MailAreaLast;
        }
        pMbx++;
    }
}

/********************************************************
*   �Z�}�t�@�[�̏�����              *
********************************************************/
void    _InitSemaphore( void )
{
    int     i;

    memset( _Smp, 0, sizeof _Smp );
    for( i= 0; i < TBQ(_Smp); i++ ) {
        _Smp[i].MySmpNo= i;
    }
}

/*********************************************************
*   initiation of signal                *
*********************************************************/
void    _InitSignal( void )
{
    int     i;

    memset( _Sig, 0, sizeof _Sig );
    for( i= 0; i < TBQ( _Sig ); i++ ) {
        _Sig[i].MySigNo= i;
    }
}

void    MtsInit( void )
{
extern	void	HardInitial( void );

    _RunTaskNo= _S_NoOwner;
    _ReadyQue= NULL;
    _SaveReadyQue= NULL;
    _TimerQue= NULL;
    _TimeMSec= 0;
#ifdef	WIN32
    _InitVector();
#endif
    _InitPending();
#ifdef  WIN32
    _SCBInx= _SCBCount= 0;
//	FontSet();
#else
	HardInitial();
#endif
//    SetVBR();		/* Vector Base Address Set */


    _InitTcb();
    _InitMbx();
    _InitMail();         /*  ���[���̏�����      */
    _InitSemaphore();    /*  �Z�}�t�@�[�̏�����  */
    _InitSignal();       /*  �V�O�i���̏�����    */

}
