// Line.h: CLine �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINE_H__D97C7BEE_F94D_4EDF_BD59_E5FB3D088265__INCLUDED_)
#define AFX_LINE_H__D97C7BEE_F94D_4EDF_BD59_E5FB3D088265__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLine : public CObject 
{
public:
	CLine(int, int, int, int, int);
	virtual ~CLine();

	int sx, sy, ex, ey;
	int pattern;

};


#endif // !defined(AFX_LINE_H__D97C7BEE_F94D_4EDF_BD59_E5FB3D088265__INCLUDED_)
