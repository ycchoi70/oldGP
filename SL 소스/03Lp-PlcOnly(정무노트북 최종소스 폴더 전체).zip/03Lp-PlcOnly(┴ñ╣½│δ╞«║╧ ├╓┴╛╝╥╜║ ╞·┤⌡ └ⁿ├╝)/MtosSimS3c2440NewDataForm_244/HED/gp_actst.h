void	DataViewMenu(int *iScreenNo);
