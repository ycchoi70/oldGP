/********************************************************/
/*	PLC �g�p�O���֐�									*/
/********************************************************/
#ifndef TBQ
#define TBQ(a)      (sizeof a/sizeof a[0])
#endif
/**************************************/
#ifdef	WIN32
	extern	int		Hex2nBin(char *buff,int cnt);
	extern	int		Hex2Bin(char *buff);
	extern	unsigned int LHexAsToBin(char *buff, int cnt);
/* 20081003 */
	extern	int	SendPLCPCData( void );
	extern	int	SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut);
	extern	int		SendPC2PLCData2( int mode,int cnt,char *buff,int TimeOut );
	extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
	extern	int		GetDevNamePLCAddr(int ch,int bFlag,unsigned char src,char *obj,int *DevInfo,int *Address);
	extern	void	RtsOnOffSet(int type,int mode);
	extern	int		SetPLCUsrAddr(int ch,int DevInfo,int Address,unsigned char idx,int bFlag);
	extern	int		SendPLC2PCData( int mode,int cnt,char *buff,int TimeOut );
	extern	void	SendPLCGroup(void);
	extern	void	Rs422Enable(int mode);
	extern	int		SendThruePLC(int mode,int cnt,char *sBuff,int TimeOut);
	extern	void	Bin2Hex(int data,int cnt,char *buff);
	extern	void	Bin2dec(int data,int cnt,char *buff);
	extern	int	gstrlen(char *buff);
	extern	void	gmemset(char *buff,int data,int cnt);
	extern	void	gmemcpy(char *obj,char *src,int cnt);
	extern	void	gstrcpy(char *obj,char *src);
	extern	int	gstrcmp(char *src,char *obj);
	extern	int	gstrncmp(char *src,char *obj,int cnt);
	extern	void	gstrcat(char *src,char *obj);
	extern	int	gatoi(char *buff);
	extern	int	SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut);
	extern	int	SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut );
	unsigned int	GetNowTime(void);		/* 20060203 */
#else
#ifdef	DEFULT_PLC
	extern	int		Hex2nBin(char *buff,int cnt);
	extern	int		Hex2Bin(char *buff);
	extern	unsigned int LHexAsToBin(char *buff, int cnt);
/* 20081003 */
	extern	int	SendPLCPCData( void );
	extern	int	SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut);
	extern	int		SendPC2PLCData2( int mode,int cnt,char *buff,int TimeOut );
	extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
	extern	int		GetDevNamePLCAddr(int ch,int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address);
	extern	void	RtsOnOffSet(int type,int mode);
	extern	int		SetPLCUsrAddr(int ch,int DevInfo,int Address,unsigned char idx,int bFlag);
	extern	int		SendPLC2PCData( int mode,int cnt,char *buff,int TimeOut );
	extern	void	SendPLCGroup(void);
	extern	void	Rs422Enable(int mode);
	extern	int		SendThruePLC(int mode,int cnt,char *sBuff,int TimeOut);
	extern	void	Bin2Hex(int data,int cnt,char *buff);
	extern	void	Bin2dec(int data,int cnt,char *buff);
	extern	int	gstrlen(char *buff);
	extern	void	gmemset(char *buff,int data,int cnt);
	extern	void	gmemcpy(char *obj,char *src,int cnt);
	extern	void	gstrcpy(char *obj,char *src);
	extern	int	gstrcmp(char *src,char *obj);
	extern	int	gstrncmp(char *src,char *obj,int cnt);
	extern	void	gstrcat(char *src,char *obj);
	extern	int	gatoi(char *buff);
	extern	int	SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut);
	extern	int	SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut );
	extern	unsigned int	B_GetNowTime(void);
	extern	int	B_SendThruePLC(int mode,int cnt,char *sBuff,int TimeOut);
#endif
	extern	int	B_Hex2nBin(char *buff,int cnt);
	extern	int	B_Hex2Bin(char *buff);
	extern	unsigned int B_LHexAsToBin(char *buff, int cnt);
/* 20081003 */
	extern	int	B_SendPLCPCData( void );
	extern	int	B_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut);
	extern	int	B_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut );
	extern	int	B_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut);
	extern	int	B_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut );
	extern	int	B_SendPLC2PCData( int mode,int cnt,char *buff,int TimeOut );
	extern	int	B_Delay(int p);
	extern	int	B_ReadSignal(int p);
	extern	void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
	extern	void	B_PlcDevInit(void);
	extern	int	B_SendPLCGroup(void);
	extern	void	B_Bin2Hex(int data,int cnt,char *buff);
	extern	int	B_gstrlen(char *buff);
	extern	void	B_gmemset(char *buff,int data,int cnt);
	extern	void	B_gmemcpy(char *obj,char *src,int cnt);
	extern	void	B_gstrcpy(char *obj,char *src);
	extern	int	B_gstrcmp(char *src,char *obj);
	extern	int	B_gstrncmp(char *src,char *obj,int cnt);
	extern	void	B_gstrcat(char *src,char *obj);
	extern	int	B_SendRecPLC2(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut);
	extern	int	B_SendPC2PLCData2( int mode,int cnt,char *buff,int TimeOut );
	extern	unsigned int	B_GetNowTime(void);
	extern	int	B_SendThruePLC(int mode,int cnt,char *sBuff,int TimeOut);
#endif




#ifdef	WIN32
extern int __cdecl Delay(int);
extern unsigned int __cdecl ReadSignal(int);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	PlcDevInit( void );
extern	unsigned char			GpFont[0x200000];
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		PLCPortOpen;
extern	int		PCPortOpen;
extern	int		SioPCOpenFlag;
extern	int		SioPLCOpenFlag;
#else
#define SGN_PLC		0
#endif


/**************************************/

/********************************************************/
/*	PLC ��?�N�w�b??									*/
/********************************************************/
#ifdef	PLCTYPE_CH1_BUF
#define	___EXT	
#else
#define	___EXT	extern
#endif

___EXT	int		MyStationNo;
___EXT	int		DstStationNo;
___EXT	int		MyStationNo2;
___EXT	int		DstStationNo2;
___EXT	int		MyChanel;			// 20100405

___EXT	int		DeviceFlag;						/* Device Check Flag */
___EXT	int		BitRecCnt;
___EXT	int		BitAndData;

___EXT	int	LgGroopSema;			/* Grooping Semafo */
___EXT	int	LgGroopingFlag;		/* Grooping ON */
___EXT	int	LgLgCommSeq;
___EXT	int	LgCommSeq;

___EXT	int	PLC_Type_In;
___EXT	int	GppPcThruWCnt;		/* PC MOnitor Word Device Count */ 
___EXT	int	GppPcThruBCnt;		/* PC MOnitor Bit Device Count */
___EXT	int	GroopSema;			/* Grooping Semafo */
___EXT	int	GroopingFlag;		/* Grooping ON */
___EXT	int	DoubleWordCnt;	/* C2-Count */
___EXT	char	PLC_Kyoku[2];	/* �o�k�b�ǔ� */
___EXT	int		PcThru1014;					/* PC��GroupMonitor�t���b�O */
___EXT	int		PcThru1014Rec;				/* E00179 ��M�t���b�O */
___EXT	int		PcThruWCnt;
___EXT	int		PcThruBCnt;
___EXT	int		PcThruAllCnt;
___EXT	int		PcThruByteCnt;
___EXT	int		PcThruByteCnt179;
___EXT	int		PcThruByteCntStr;
___EXT	int		PcThruByteCnt1SW;
___EXT	int		PcThruByteCnt1SB;
___EXT	char	PLCFX1N_00E0202[4+4];
___EXT	char	PLCFX1N_00EE804[8+4];
___EXT	char	PLC2FX1N_00E0202[4+4];
___EXT	char	PLC2FX1N_00EE804[8+4];
___EXT	int	GrpDevCnt;
___EXT	int	ProtFlag;
___EXT	int	LgConnectFlag;
___EXT	int	PlcProtLeng;
___EXT	int	PlcSendFlag;		/* ���M���t���O */
___EXT	int	PlcRecCnt;
___EXT	int	PlcRecCmd;
___EXT	int	PlcConectInf[2];
___EXT	int DeviceStartPoint;		/* 0�϶� D100 ����̽�, 1�϶� D101 ����̽�  */
___EXT	int			gSetNumBit;
___EXT	int			gSetNumWord;
___EXT	int	SUnvPlcRecCnt;
___EXT	int	SUnvPlcRecCmd;
___EXT	unsigned	int	Port_TimeoutCnt;		/* 20060203 */
___EXT	int DeviceLHFlag;		/* 0�϶� D100 ����̽�, 1�϶� D101 ����̽�  */

___EXT	int	Time1Char;
___EXT	int	Time1CharPlc;
___EXT	int	Plc70PConnectFlag;
___EXT	int	PlcSendedFlag;
___EXT	int	Pro_Speed;			/* 20061025ksc */
___EXT	unsigned int Plc_sync_time;				/* 20061025ksc */ 



___EXT	unsigned char DataRecCnt;				/* 20090606ksc */ 
___EXT	unsigned char TNSWCheck;				/* 20090606ksc */ 
___EXT	unsigned char TNSW_high;				/* 20090606ksc */ 
___EXT	unsigned char TNSW_low;				/* 20090606ksc */ 
___EXT  int FrameCnt;               /* 20090606ksc */
___EXT	char DLEPlus;				/* 20090606ksc */ 
___EXT	unsigned char CheckDevice;				/* 20090606ksc */ 
___EXT	unsigned char CheckAddr;				/* 20090606ksc */ 

___EXT  int FirstRec;
___EXT	unsigned int gReadFrameIdx;		
___EXT	unsigned int gWriteFrameIdx;



___EXT	unsigned char gReadBlockNo;			/* �б� ���� ��ȣ */	/* 20090606ksc */ 
___EXT	unsigned char gWriteBlockNo;		/* ���� ���� ��ȣ */		/* 20090606ksc */ 
___EXT	unsigned char gGukNo;				/* ���� *//* 20090606ksc */ 
___EXT	unsigned char monitorModeFlag;		/* Monitor mode Flag 20090704 */ 




___EXT	int		PlcThruMonCnt;
___EXT	int		PlcThruMonDataCnt[10];
___EXT	int		PlcThruRecCnt;
___EXT	int		PlcThruRecDataCnt[10];

___EXT	unsigned char	PlcSendBuff[512];
___EXT	unsigned char	PlcRecBuff[512];
___EXT	unsigned char	PcThruWData[512];
___EXT	unsigned char	PcThruBData[512];
___EXT	unsigned char	PcThruAllData[1024];
___EXT	unsigned char	PcThruRecData[512];
___EXT	unsigned char	PlcSendDevData[512];
___EXT	unsigned char	PlcThruMonBuff[10][256];
___EXT	unsigned char	PlcThruRecBuff[10][256];

___EXT		unsigned snowtime;



#ifdef	LOG
___EXTint		logCnt;
___EXTchar	SendReclog[1024];
#endif




