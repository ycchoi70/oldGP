/*	$ JBOSN: hal_interrupt.h, v 0.1 2002/12/17 $	*/

/*
 * Copyright (C) 2002	iBOSN systems
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are not permitted completely.
 *
 */

/*
 * Module Name: hal_interrupt.h
 *
 * Purpose: interrupt relative definition
 *
 */
#ifndef	__JBOSN_HAL_INTERRUPT_H_
#define	__JBOSN_HAL_INTERRUPT_H_

/// define the system used interrupt number
#define     SYSINTR_NOP             (0)
#define     SYSINTR_TICK            (1)
#define     SYSINTR_ETH0            (2)
#define     SYSINTR_WAV             (4)
#define     SYSINTR_USH             (6)			//USB Host
#define     SYSINTR_UDC             (7)			//Device
#define     SYSINTR_TCH             (8)
#define     SYSINTR_KBD             (9)
#define     SYSINTR_COM1            (10)
#define     SYSINTR_COM2            (11)
#define     SYSINTR_COM3            (12)
#define		SYSINTR_MCI0			(13)
#define		SYSINTR_MCI1			(14)

#endif // __JBOSN_HAL_INTERRUPT_H_

void HAL_InterruptEnable( unsigned nInterrupt );
void HAL_InterruptDisable( unsigned nInterrupt );
