
int	Hex2Bin(char *buff);
int	Hex2nBin(char *buff,int cnt);
int	Bin2Hex1Keta(int data);

unsigned char LHexToBin(char as_data);
unsigned int LHexAsToBin(char *buff, int cnt);
void	Bin2Hex2(char data, char *buf);
int	Bin2Hex1(int data);
void	Bin2Hex(int data,int cnt,char *buff);
void	Bin2dec(int data,int cnt,char *buff);
int	gstrlen(char *buff);
void	gmemset(char *buff,int data,int cnt);
void	gmemcpy(char *obj,char *src,int cnt);
void	gstrcpy(char *obj,char *src);
int	gstrcmp(char *src,char *obj);
int	gstrncmp(char *src,char *obj,int cnt);
void	gstrcat(char *src,char *obj);
int	gatoi(char *buff);
float	gatof(char *buff);
int	ParcentEProcSub(float data);
void	ParcentEProc(char* buff,float data);
void	ParcentfProc(char* buff,float data,int keta,int sho);

void	LcdAddrSet(void* FrameAddr);



#ifndef	WIN32
char	*itoa(int data, char *buff, int p);
#endif
