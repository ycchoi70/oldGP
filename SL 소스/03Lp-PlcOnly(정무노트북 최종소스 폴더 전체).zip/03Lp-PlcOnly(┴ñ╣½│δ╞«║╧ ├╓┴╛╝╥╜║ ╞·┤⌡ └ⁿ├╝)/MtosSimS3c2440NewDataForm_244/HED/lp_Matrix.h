
#define	LOG_FILE	"GLP_Log.txt"
#define	MAX_SIM_LOG_SIZE	64*1024

#ifdef	LP_MATRIX_PROC
	char	Jikyoku_Hex[2] ;
	int		Matrix_Mode ;
	int	LinkEstablish ;
	unsigned char BCC_DATA ;
	char	BCC_Check[2],BCC_Check2[3] ;
	int	DenubTimeoutMode;
	int	MatrixTimeoutCnt ;
	int	DenubTimeoutCnt;
	int	MatrixRetryCnt;
	/* ���ǔ�?����ǔ� */
	char	RecStationno[4];
	int		LogStartFlag;
	#ifdef	WIN32
	int		Log_Pos;
	char	LogBuff[0x10000];
	#endif
#else
	extern	char	Jikyoku_Hex[2] ;
	extern	int		Matrix_Mode ;
	extern	int	LinkEstablish ;
	extern	unsigned char BCC_DATA ;
	extern	char	BCC_Check[2],BCC_Check2[3] ;
	extern	int	DenubTimeoutMode;
	extern	int	MatrixTimeoutCnt ;
	extern	int	DenubTimeoutCnt;
	extern	int	MatrixRetryCnt;
	/* ���ǔ�?����ǔ� */
	extern	char	RecStationno[4];
	extern	void	LhtInitLog(void);
#endif

void	SetPlcStationNo(void);
void	Rs232c_Receive_Init(void);
void	LhtInitLog(void);
void	PlcLogWrite(int mode,int cnt,unsigned char *buff);
int Ascii2_Hexa_Check(char *Dat);
int	CheckMyStation(int *recCnt,unsigned char* recBuff);
void	Set1char2buff(char ch,int *recCnt,unsigned char* recBuff);
void	SetRecKyokuBan(unsigned char* sndBuff,unsigned char* recBuff);
int  Rs232c_Char_Proc(char ch,int* sndCnt,unsigned char* sndBuff,int *recCnt,unsigned char* recBuff);
void	MatrixTimeoutProc(void);
