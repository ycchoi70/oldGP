
#define	LIST_VECT_FONT_SIZE	16
void	SetList_Func(int iDispOrder);
void ListDispWatch(int iOrder);
void ListDispWatchItem(int iOrder,int lineNo,_AREA_INFO* dsp_addr);
