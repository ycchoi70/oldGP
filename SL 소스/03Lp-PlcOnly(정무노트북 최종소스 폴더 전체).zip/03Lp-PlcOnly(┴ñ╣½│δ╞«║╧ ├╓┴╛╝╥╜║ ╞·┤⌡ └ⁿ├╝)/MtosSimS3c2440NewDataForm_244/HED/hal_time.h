/*	$ JBOSN_OS: hal_time.h, v 0.1 2003/05/15 $	*/

/*
 * Copyright (C) 2002	iBOSN systems
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are not permitted completely.
 *
 */

/*
 * Module Name: hal_time.h
 *
 * Purpose: time function definitions.
 *
 */

#ifndef __JBOSN_HAL_TIME_H_
#define __JBOSN_HAL_TIME_H_

#define S3C2440X_FCLK           399650000                   // 400MHz
//#define S3C2440X_FCLK           400000000                   // 400MHz
#define PCLKDIV                 6						    // P-clock (PCLK) divisor.
#define S3C2440X_PCLK           (S3C2440X_FCLK/PCLKDIV)     // divisor 4

//#define HAL_CLOCK_FREQ          (S3C2440X_PCLK/2)
#define HAL_CLOCK_FREQ          (S3C2440X_PCLK/16)

// Timer count value for 1 ms
#define HAL_TICK_FREQ_1MS       (1000)	//1ms
#define HAL_TICK_FREQ_10MS       (100)		//10ms
#define HAL_CLOCK_TICK      (HAL_CLOCK_FREQ / HAL_TICK_FREQ_10MS)
#define PLC_CLOCK_TICK      (HAL_CLOCK_FREQ / HAL_TICK_FREQ_1MS)
#define NO_RESCHED_WINDOW   (HAL_CLOCK_TICK / 10)

#define	PLC_30_CNT			(PLC_CLOCK_TICK / 2)			//PLC RUN TIME(50%)
//#define	PLC_30_CNT			(PLC_CLOCK_TICK / 5)			//PLC RUN TIME(20%)

#define	TIMER_PERIOD        (1000/HAL_TICK_FREQ)


#define CLOCK_1S_FREQ16          (S3C2440X_PCLK/16)		//2,4,8,16

#define	MOTION_100K			(100000)	//10Us
#define	MOTION_100K_CNT		(CLOCK_1S_FREQ16/MOTION_100K)


//EXTERN  VOID HAL_ClockInit( VOID );
//EXTERN  VOID HAL_TimerInterruptHandler( PUINT64 pMsCount );


// Board timer constants.
//
#define PRESCALER			200
//#define D1_2				0x0
//#define D1_4				0x1
//#define D1_8				0x2
//#define D1_16				0x3
//#define D2					2
#define D4					4
//#define D8					8
//#define D16					16
//
#define SYS_TIMER_DIVIDER	D4
#define OEM_CLOCK_FREQ      (S3C2410X_PCLK / PRESCALER / SYS_TIMER_DIVIDER)
//#define OEM_COUNT_1MS       (OEM_CLOCK_FREQ / 1000)				// Timer count for 1ms.
//#define RESCHED_PERIOD      1									// Reschedule period in ms.
//#define RESCHED_INCREMENT   (RESCHED_PERIOD * OEM_COUNT_1MS)	// Number of ticks per reschedule period.
//


#endif ///__JBOSN_HAL_TIME_H_


