/**************************************************************
*   Update:07.10.15 M.Owashi
*           [keyword:GLP_071015] �j��?���j�b�N�R?�h�ύX
***************************************************************/
#ifdef	MODELTYPE_LP		//2011.01.19

typedef struct{
	int	cnt;
	int	startNumNo;
	const INST_LEN_PROC	*funpos2;
}COM_XXXTBL;
typedef	struct{
	int	cnt;
	const COM_XXXTBL		*funpos1[16];
}COM_XXTBL;
typedef	struct{
	const COM_XXTBL		*funpos0;
}COM_XTBL;

//0x00
#define	NM_TBL000		0
#define	NM_TBL000_CNT	1
#define	NM_TBL001		NM_TBL000+NM_TBL000_CNT
#define	NM_TBL001_CNT	4
#define	NM_TBL002		NM_TBL001+NM_TBL001_CNT
#define	NM_TBL002_CNT	5
#define	NM_TBL003		NM_TBL002+NM_TBL002_CNT
#define	NM_TBL003_CNT	5
#define	NM_TBL004		NM_TBL003+NM_TBL003_CNT
#define	NM_TBL004_CNT	6
//#define	NM_TBL005		NM_TBL004+NM_TBL004_CNT
//#define	NM_TBL005_CNT	3
#define	NM_TBL009		NM_TBL004+NM_TBL004_CNT
#define	NM_TBL009_CNT	4
#define	NM_TBL00b		NM_TBL009+NM_TBL009_CNT
#define	NM_TBL00b_CNT	4
#define	NM_TBL080		NM_TBL00b+NM_TBL00b_CNT
#define	NM_TBL080_CNT	4
#define	NM_TBL088		NM_TBL080+NM_TBL080_CNT
#define	NM_TBL088_CNT	7
#define	NM_TBL090		NM_TBL088+NM_TBL088_CNT
#define	NM_TBL090_CNT	7
#define	NM_TBL092		NM_TBL090+NM_TBL090_CNT
#define	NM_TBL092_CNT	3
#define	NM_TBL094		NM_TBL092+NM_TBL092_CNT
#define	NM_TBL094_CNT	2
#define	NM_TBL096		NM_TBL094+NM_TBL094_CNT
#define	NM_TBL096_CNT	9
#define	NM_TBL0a0		NM_TBL096+NM_TBL096_CNT
#define	NM_TBL0a0_CNT	11
//0x10
#define	NM_TBL103		NM_TBL0a0+NM_TBL0a0_CNT
#define	NM_TBL103_CNT	6
#define	NM_TBL104		NM_TBL103+NM_TBL103_CNT
#define	NM_TBL104_CNT	6
#define	NM_TBL113		NM_TBL104+NM_TBL104_CNT
#define	NM_TBL113_CNT	6
#define	NM_TBL114		NM_TBL113+NM_TBL113_CNT
#define	NM_TBL114_CNT	6
#define	NM_TBL123		NM_TBL114+NM_TBL114_CNT
#define	NM_TBL123_CNT	6
#define	NM_TBL124		NM_TBL123+NM_TBL123_CNT
#define	NM_TBL124_CNT	6
#define	NM_TBL143		NM_TBL124+NM_TBL124_CNT
#define	NM_TBL143_CNT	6
#define	NM_TBL144		NM_TBL143+NM_TBL143_CNT
#define	NM_TBL144_CNT	6
#define	NM_TBL163		NM_TBL144+NM_TBL144_CNT
#define	NM_TBL163_CNT	6
#define	NM_TBL164		NM_TBL163+NM_TBL163_CNT
#define	NM_TBL164_CNT	6

#define	NM_TBL180		NM_TBL164+NM_TBL164_CNT
#define	NM_TBL180_CNT	6
#define	NM_TBL181		NM_TBL180+NM_TBL180_CNT
#define	NM_TBL181_CNT	5
#define	NM_TBL182		NM_TBL181+NM_TBL181_CNT
#define	NM_TBL182_CNT	5

#define	NM_TBL1c0		NM_TBL182+NM_TBL182_CNT
#define	NM_TBL1c0_CNT	5
#define	NM_TBL1c1		NM_TBL1c0+NM_TBL1c0_CNT
#define	NM_TBL1c1_CNT	5
#define	NM_TBL1c2		NM_TBL1c1+NM_TBL1c1_CNT
#define	NM_TBL1c2_CNT	5

//0x20
#define	NM_TBL200		NM_TBL1c2+NM_TBL1c2_CNT
#define	NM_TBL200_CNT	5
#define	NM_TBL201		NM_TBL200+NM_TBL200_CNT
#define	NM_TBL201_CNT	5
#define	NM_TBL202		NM_TBL201+NM_TBL201_CNT
#define	NM_TBL202_CNT	5
#define	NM_TBL210		NM_TBL202+NM_TBL202_CNT
#define	NM_TBL210_CNT	5
#define	NM_TBL230		NM_TBL210+NM_TBL210_CNT
#define	NM_TBL230_CNT	6
#define	NM_TBL240		NM_TBL230+NM_TBL230_CNT
#define	NM_TBL240_CNT	5
#define	NM_TBL260		NM_TBL240+NM_TBL240_CNT
#define	NM_TBL260_CNT	14
#define	NM_TBL270		NM_TBL260+NM_TBL260_CNT
#define	NM_TBL270_CNT	14
#define	NM_TBL290		NM_TBL270+NM_TBL270_CNT
#define	NM_TBL290_CNT	6
#define	NM_TBL2a0		NM_TBL290+NM_TBL290_CNT
#define	NM_TBL2a0_CNT	6
#define	NM_TBL2b0		NM_TBL2a0+NM_TBL2a0_CNT
#define	NM_TBL2b0_CNT	1
#define	NM_TBL2c0		NM_TBL2b0+NM_TBL2b0_CNT
#define	NM_TBL2c0_CNT	1
#define	NM_TBL2d0		NM_TBL2c0+NM_TBL2c0_CNT
#define	NM_TBL2d0_CNT	1
#define	NM_TBL2e0		NM_TBL2d0+NM_TBL2d0_CNT
#define	NM_TBL2e0_CNT	1
//0x30
#define	NM_TBL300		NM_TBL2e0+NM_TBL2e0_CNT
#define	NM_TBL300_CNT	12
#define	NM_TBL301		NM_TBL300+NM_TBL300_CNT
#define	NM_TBL301_CNT	12
#define	NM_TBL302		NM_TBL301+NM_TBL301_CNT
#define	NM_TBL302_CNT	12

#define	NM_TBL310		NM_TBL302+NM_TBL302_CNT
#define	NM_TBL310_CNT	12
#define	NM_TBL311		NM_TBL310+NM_TBL310_CNT
#define	NM_TBL311_CNT	12
#define	NM_TBL312		NM_TBL311+NM_TBL311_CNT
#define	NM_TBL312_CNT	12

#define	NM_TBL320		NM_TBL312+NM_TBL312_CNT
#define	NM_TBL320_CNT	12
#define	NM_TBL321		NM_TBL320+NM_TBL320_CNT
#define	NM_TBL321_CNT	12
#define	NM_TBL322		NM_TBL321+NM_TBL321_CNT
#define	NM_TBL322_CNT	12

#define	NM_TBL330		NM_TBL322+NM_TBL322_CNT
#define	NM_TBL330_CNT	12
#define	NM_TBL331		NM_TBL330+NM_TBL330_CNT
#define	NM_TBL331_CNT	12
#define	NM_TBL332		NM_TBL331+NM_TBL331_CNT
#define	NM_TBL332_CNT	12

#define	NM_TBL340		NM_TBL332+NM_TBL332_CNT
#define	NM_TBL340_CNT	5
#define	NM_TBL350		NM_TBL340+NM_TBL340_CNT
#define	NM_TBL350_CNT	5
#define	NM_TBL380		NM_TBL350+NM_TBL350_CNT
#define	NM_TBL380_CNT	5
#define	NM_TBL381		NM_TBL380+NM_TBL380_CNT
#define	NM_TBL381_CNT	5
#define	NM_TBL382		NM_TBL381+NM_TBL381_CNT
#define	NM_TBL382_CNT	5
#define	NM_TBL390		NM_TBL382+NM_TBL382_CNT
#define	NM_TBL390_CNT	5
#define	NM_TBL391		NM_TBL390+NM_TBL390_CNT
#define	NM_TBL391_CNT	5
#define	NM_TBL392		NM_TBL391+NM_TBL391_CNT
#define	NM_TBL392_CNT	5
#define	NM_TBL3a0		NM_TBL392+NM_TBL392_CNT
#define	NM_TBL3a0_CNT	5
#define	NM_TBL3a1		NM_TBL3a0+NM_TBL3a0_CNT
#define	NM_TBL3a1_CNT	5
#define	NM_TBL3a2		NM_TBL3a1+NM_TBL3a1_CNT
#define	NM_TBL3a2_CNT	5
#define	NM_TBL3b0		NM_TBL3a2+NM_TBL3a2_CNT
#define	NM_TBL3b0_CNT	5
#define	NM_TBL3b1		NM_TBL3b0+NM_TBL3b0_CNT
#define	NM_TBL3b1_CNT	5
#define	NM_TBL3b2		NM_TBL3b1+NM_TBL3b1_CNT
#define	NM_TBL3b2_CNT	5
#define	NM_TBL3c0		NM_TBL3b2+NM_TBL3b2_CNT
#define	NM_TBL3c0_CNT	5
#define	NM_TBL3d0		NM_TBL3c0+NM_TBL3c0_CNT
#define	NM_TBL3d0_CNT	5
//0x40
#define	NM_TBL400		NM_TBL3d0+NM_TBL3d0_CNT
#define	NM_TBL400_CNT	6
#define	NM_TBL401		NM_TBL400+NM_TBL400_CNT
#define	NM_TBL401_CNT	5
#define	NM_TBL402		NM_TBL401+NM_TBL401_CNT
#define	NM_TBL402_CNT	5
#define	NM_TBL410		NM_TBL402+NM_TBL402_CNT
#define	NM_TBL410_CNT	6
#define	NM_TBL411		NM_TBL410+NM_TBL410_CNT
#define	NM_TBL411_CNT	5
#define	NM_TBL412		NM_TBL411+NM_TBL411_CNT
#define	NM_TBL412_CNT	5
#define	NM_TBL420		NM_TBL412+NM_TBL412_CNT
#define	NM_TBL420_CNT	6
#define	NM_TBL421		NM_TBL420+NM_TBL420_CNT
#define	NM_TBL421_CNT	5
#define	NM_TBL422		NM_TBL421+NM_TBL421_CNT
#define	NM_TBL422_CNT	5
#define	NM_TBL430		NM_TBL422+NM_TBL422_CNT
#define	NM_TBL430_CNT	6
#define	NM_TBL431		NM_TBL430+NM_TBL430_CNT
#define	NM_TBL431_CNT	5
#define	NM_TBL432		NM_TBL431+NM_TBL431_CNT
#define	NM_TBL432_CNT	5

//0x50
#define	NM_TBL500		NM_TBL432+NM_TBL432_CNT
#define	NM_TBL500_CNT	16
#define	NM_TBL501		NM_TBL500+NM_TBL500_CNT
#define	NM_TBL501_CNT	1
#define	NM_TBL520		NM_TBL501+NM_TBL501_CNT
#define	NM_TBL520_CNT	10
#define	NM_TBL530		NM_TBL520+NM_TBL520_CNT
#define	NM_TBL530_CNT	5
#define	NM_TBL580		NM_TBL530+NM_TBL530_CNT
#define	NM_TBL580_CNT	11
#define	NM_TBL584		NM_TBL580+NM_TBL580_CNT
#define	NM_TBL584_CNT	1
#define	NM_TBL586		NM_TBL584+NM_TBL584_CNT
#define	NM_TBL586_CNT	1
#define	NM_TBL600		NM_TBL586+NM_TBL586_CNT
#define	NM_TBL600_CNT	7
#define	NM_TBL700		NM_TBL600+NM_TBL600_CNT
#define	NM_TBL700_CNT	13

//Total Numonic
#define	MAX_INSTRUCT_CODE	NM_TBL700+NM_TBL700_CNT		// Table Max Code
//IRET Code


#ifdef	EARCHRTN_PROC

//+++++++++++++++++++++++++++++++++++++++++++++++++++++
//	�v���O��?�e?�u��
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
const INST_PROC Numonic_Table[MAX_INSTRUCT_CODE]={
//0-0-0
		proc_NOP	,									//1NM_TBL000_CNT
		proc_LOAD	,proc_LOADN	,proc_LOADP	,
		proc_LOADF	,									//4NM_TBL001_CNT
		proc_AND	,proc_ANDN	,proc_ANDP	,
		proc_ANDF	,proc_ANDL	,						//5NM_TBL002_CNT
		proc_OR		,proc_ORN	,proc_ORP	,
		proc_ORF	,proc_ORL	,						//5NM_TBL003_CNT
		proc_OUT	,proc_OUTP	,proc_OUTF	,
		proc_SET	,proc_RST	,proc_ALT	,			//6NM_TBL004_CNT

		proc_MC_LOAD	,proc_MC_LOADN	,proc_MC_LOADP	,
		proc_MC_LOADF	,								//4NM_TBL009_CNT
		proc_MC_OR	,proc_MC_ORN	,proc_MC_ORP	,
		proc_MC_ORF	,									//4NM_TBL00b_CNT

		
		
		proc_CTU	,proc_CTD	,proc_CTUD	,
		proc_CTR	,									//4NM_TBL080_CNT
		proc_TON	,proc_TOFF	,proc_TMR	,
		proc_TMON	,proc_TRTG	,						//5NM_TBL088_CNT
		proc_TTMR	,proc_STMR	,						//Add 2008.05.19
		proc_JMP	,proc_LABEL	,proc_CALL	,
		proc_LABEL	,proc_FCALL	,proc_LABEL	,
		proc_RET	,									//7NM_TBL090_CNT
		proc_FOR	,proc_NEXT	,proc_BREK	,			//3NM_TBL092_CNT
		proc_MCS	,proc_MCR	,						//2NM_TBL094_CNT
		proc_EI		,proc_DI	,proc_ETI	,
		proc_EEI	,proc_DTI	,proc_DEI	,
		proc_TINT	,proc_EINT	,proc_IRET	,			//9NM_TBL096_CNT
		NULL		,NULL		,NULL		,
		proc_STOP	,NULL		,NULL		,
		proc_NOT	,proc_MPUSH	,proc_MLOAD	,
		proc_MPOP	,proc_WDT	,						//11NM_TBL0a0_CNT
//1-0-0
		proc_LOADEQ	,proc_LOADGT,proc_LOADLT,
		proc_LOADNE	,proc_LOADGE,proc_LOADLE,			//6NM_TBL103_CNT
		proc_LOADDEQ,proc_LOADDGT,proc_LOADDLT,
		proc_LOADDNE,proc_LOADDGE,proc_LOADDLE,			//6NM_TBL104_CNT
		proc_ANDEQ	,proc_ANDGT	,proc_ANDLT	,
		proc_ANDNE	,proc_ANDGE	,proc_ANDLE	,			//6NM_TBL113_CNT
		proc_ANDDEQ	,proc_ANDDGT,proc_ANDDLT,
		proc_ANDDNE	,proc_ANDDGE,proc_ANDDLE,			//6NM_TBL114_CNT
		proc_OREQ	,proc_ORGT	,proc_ORLT	,
		proc_ORNE	,proc_ORGE	,proc_ORLE	,			//6NM_TBL123_CNT
		proc_ORDEQ	,proc_ORDGT	,proc_ORDLT	,
		proc_ORDNE	,proc_ORDGE	,proc_ORDLE	,			//6NM_TBL124_CNT

		proc_MC_LOADEQ	,proc_MC_LOADGT,proc_MC_LOADLT,
		proc_MC_LOADNE	,proc_MC_LOADGE,proc_MC_LOADLE,		//6NM_TBL143_CNT
		proc_MC_LOADDEQ,proc_MC_LOADDGT,proc_MC_LOADDLT,
		proc_MC_LOADDNE,proc_MC_LOADDGE,proc_MC_LOADDLE,	//6NM_TBL144_CNT
		proc_MC_OREQ	,proc_MC_ORGT	,proc_MC_ORLT	,
		proc_MC_ORNE	,proc_MC_ORGE	,proc_MC_ORLE	,	//6NM_TBL163_CNT
		proc_MC_ORDEQ	,proc_MC_ORDGT	,proc_MC_ORDLT	,
		proc_MC_ORDNE	,proc_MC_ORDGE	,proc_MC_ORDLE	,	//6NM_TBL164_CNT


		NULL		,NULL		,NULL		,
		proc_CMP	,proc_DCMP	,proc_ACMP	,			//6NM_TBL180_CNT
		NULL		,NULL		,NULL		,
		proc_CMPL	,proc_DCMPL	,						//5NM_TBL181_CNT
		NULL		,NULL		,NULL		,
		proc_CMPG	,proc_DCMPG	,						//5NM_TBL182_CNT

		NULL		,NULL		,NULL		,
		proc_BWCMP	,proc_DBWCMP,						//5NM_TBL1c0_CNT
		NULL		,NULL		,NULL		,
		proc_BWCMPL	,proc_DBWCMPL,						//5NM_TBL1c1_CNT
		NULL		,NULL		,NULL		,
		proc_BWCMPG	,proc_DBWCMPG,						//5NM_TBL1c2_CNT
//2-0-0
		proc_BMOV	,NULL		,NULL		,
		proc_MOV	,proc_DMOV	,					//5NM_TBL200_CNT
		proc_BMOVL	,NULL		,NULL		,
		proc_MOVL	,proc_DMOVL	,					//5NM_TBL201_CNT
		proc_BMOVG	,NULL		,NULL		,
		proc_MOVG	,proc_DMOVG	,					//5NM_TBL202_CNT

		proc_BCMOV	,NULL		,NULL		,
		proc_CMOV	,proc_DCMOV	,					//5NM_TBL210_CNT

		NULL		,NULL		,NULL		,
		proc_XCH	,proc_DXCH	,proc_AXCH	,			//6NM_TBL230_CNT

		NULL		,NULL		,NULL		,
		proc_SWP	,proc_DSWP	,						//5NM_TBL240_CNT

		NULL		,NULL		,NULL		,
		proc_ROR	,proc_DROR	,proc_AROR	,
		NULL		,NULL		,NULL		,
		NULL		,NULL		,proc_RORC	,
		proc_DRORC	,proc_ARORC	,						//13NM_TBL260_CNT

		NULL		,NULL		,NULL		,
		proc_ROL	,proc_DROL	,proc_AROL	,
		NULL		,NULL		,NULL		,
		NULL		,NULL		,proc_ROLC	,
		proc_DROLC	,proc_AROLC	,						//13NM_TBL270_CNT

		NULL		,NULL		,NULL		,
		proc_SFTR	,NULL		,proc_ASFTR	,			//5NM_TBL290_CNT

		NULL		,NULL		,NULL		,
		proc_SFTL	,NULL		,proc_ASFTL	,			//5NM_TBL2a0_CNT
		proc_WSFTR	,									//1NM_TBL2b0_CNT
		proc_WSFTL	,									//1NM_TBL2c0_CNT
		proc_SFTWR	,									//1NM_TBL2d0_CNT
		proc_SFTRD	,									//1NM_TBL2e0_CNT
//3-0-0
		NULL		,NULL		,NULL		,
		proc_ADD	,proc_DADD	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_ADDU	,proc_DADDU	,			//12NM_TBL300_CNT
		NULL		,NULL		,NULL		,
		proc_ADDL	,proc_DADDL	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_ADDUL	,proc_DADDUL,			//12NM_TBL301_CNT
		NULL		,NULL		,NULL		,
		proc_ADDG	,proc_DADDG	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_ADDUG	,proc_DADDUG,			//12NM_TBL302_CNT

		NULL		,NULL		,NULL		,
		proc_SUB	,proc_DSUB	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_SUBU	,proc_DSUBU	,			//12NM_TBL310_CNT
		NULL		,NULL		,NULL		,
		proc_SUBL	,proc_DSUBL	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_SUBUL	,proc_DSUBUL,			//12NM_TBL311_CNT
		NULL		,NULL		,NULL		,
		proc_SUBG	,proc_DSUBG	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_SUBUG	,proc_DSUBUG,			//12NM_TBL312_CNT

		NULL		,NULL		,NULL		,
		proc_MUL	,proc_DMUL	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_MULU	,proc_DMULU	,			//12NM_TBL320_CNT
		NULL		,NULL		,NULL		,
		proc_MULL	,proc_DMULL	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_MULUL	,proc_DMULUL,			//12NM_TBL321_CNT
		NULL		,NULL		,NULL		,
		proc_MULG	,proc_DMULG	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_MULUG	,proc_DMULUG,			//12NM_TBL322_CNT

		NULL		,NULL		,NULL		,
		proc_DIV	,proc_DDIV	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_DIVU	,proc_DDIVU	,			//12NM_TBL330_CNT
		NULL		,NULL		,NULL		,
		proc_DIVL	,proc_DDIVL	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_DIVUL	,proc_DDIVUL,			//12NM_TBL331_CNT
		NULL		,NULL		,NULL		,
		proc_DIVG	,proc_DDIVG	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_DIVUG	,proc_DDIVUG,			//12NM_TBL332_CNT

		NULL		,NULL		,NULL		,
		proc_INC	,proc_DINC	,						//4NM_TBL340_CNT
		NULL		,NULL		,NULL		,
		proc_DEC	,proc_DDEC	,						//4NM_TBL350_CNT
		NULL		,NULL		,NULL		,
		proc_ADDB	,proc_DADDB	,						//5NM_TBL380_CNT
		NULL		,NULL		,NULL		,
		proc_ADDBL	,proc_DADDBL,						//5NM_TBL381_CNT
		NULL		,NULL		,NULL		,
		proc_ADDBG	,proc_DADDBG,						//5NM_TBL382_CNT
		NULL		,NULL		,NULL		,
		proc_SUBB	,proc_DSUBB	,						//5NM_TBL390_CNT
		NULL		,NULL		,NULL		,
		proc_SUBBL	,proc_DSUBBL,						//5NM_TBL391_CNT
		NULL		,NULL		,NULL		,
		proc_SUBBG	,proc_DSUBBG,						//5NM_TBL392_CNT
		NULL		,NULL		,NULL		,
		proc_MULB	,proc_DMULB	,						//5NM_TBL3a0_CNT
		NULL		,NULL		,NULL		,
		proc_MULBL	,proc_DMULBL,						//5NM_TBL3a1_CNT
		NULL		,NULL		,NULL		,
		proc_MULBG	,proc_DMULBG,						//5NM_TBL3a2_CNT
		NULL		,NULL		,NULL		,
		proc_DIVB	,proc_DDIVB	,						//5NM_TBL3b0_CNT
		NULL		,NULL		,NULL		,
		proc_DIVBL	,proc_DDIVBL,						//5NM_TBL3b1_CNT
		NULL		,NULL		,NULL		,
		proc_DIVBG	,proc_DDIVBG,						//5NM_TBL3b2_CNT
		NULL		,NULL		,NULL		,
		proc_INCB	,proc_DINCB	,						//5NM_TBL3c0_CNT
		NULL		,NULL		,NULL		,
		proc_DECB	,proc_DDECB	,						//5NM_TBL3d0_CNT
//4-0-0
		NULL		,NULL		,NULL		,
		proc_WAND	,proc_DWAND	,proc_AWAND	,			//6NM_TBL400_CNT
		NULL		,NULL		,NULL		,
		proc_WANDL	,proc_DWANDL,						//5NM_TBL401_CNT
		NULL		,NULL		,NULL		,
		proc_WANDG	,proc_DWANDG,						//5NM_TBL402_CNT
		NULL		,NULL		,NULL		,
		proc_WOR	,proc_DWOR	,proc_AWOR	,			//6NM_TBL410_CNT
		NULL		,NULL		,NULL		,
		proc_WORL	,proc_DWORL	,						//5NM_TBL411_CNT
		NULL		,NULL		,NULL		,
		proc_WORG	,proc_DWORG	,						//5NM_TBL412_CNT
		NULL		,NULL		,NULL		,
		proc_WXOR	,proc_DWXOR	,proc_AWXOR	,			//6NM_TBL420_CNT
		NULL		,NULL		,NULL		,
		proc_WXORL	,proc_DWXORL,						//5NM_TBL421_CNT
		NULL		,NULL		,NULL		,
		proc_WXORG	,proc_DWXORG,						//5NM_TBL422_CNT
		NULL		,NULL		,NULL		,
		proc_WXNR	,proc_DWXNR	,proc_AWXNR	,			//6NM_TBL430_CNT
		NULL		,NULL		,NULL		,
		proc_WXNRL	,proc_DWXNRL,						//5NM_TBL431_CNT
		NULL		,NULL		,NULL		,
		proc_WXNRG	,proc_DWXNRG,						//5NM_TBL432_CNT
//5-0-0
		proc_BINBCD	,proc_DBINBCD,		
		proc_BCDBIN	,proc_DBCDBIN,		
		proc_BIN2HASC,proc_DBIN2HASC,		
		proc_HASC2BIN,proc_DHASC2BIN,		
		proc_HBCD2DASC,proc_DHBCD2DASC,		
		proc_DASC2BIN,proc_DDASC2BIN,		
//STR2ASC
		proc_STR2ASC,											
		proc_DASC2BCD,proc_DDASC2BCD,		
		proc_BIN2DASC,									//16NM_TBL500_CNT
		proc_DBIN2DASC,									//1NM_TBL501_CNT		
//GRYBIN
		proc_GRYBIN	,proc_DGRYBIN,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,NULL		,proc_BINGRY,
		proc_DBINGRY,									//2NM_TBL520_CNT		
//NEG
		NULL		,NULL		,NULL		,
		proc_NEG	,proc_DNEG	,						//5NM_TBL530_CNT

//DECO
		proc_DECO	,proc_ENCO	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,proc_EXT	,						//11NM_TBL580_CNT
//REF		
		proc_REF	,									//1NM_TBL584_CNT
//SEG
		proc_SEG	,									//1NM_TBL586_CNT
//0x6000
		proc_TCMP	,proc_TADD	,proc_TSUB	,
		proc_TRD	,proc_TWR	,proc_TOUR	,
		proc_TZCP	,									//7NM_TBL600_CNT
//0x7000
		proc_MTVDM	,proc_MTPDM,proc_MTIDM	,
		proc_MTMEC	,proc_MTEMS	,proc_MTCPP	,
		proc_MTFOS	,proc_MTSRS	,proc_MTOBC	,
		proc_MTOVV	,proc_MTOVP	,proc_MTIPT	,
		proc_MTUAI	,									//11NM_TBL700_CNT
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
//	�f�o�b�O�p�f�o�C�X?�F�b�N�e?�u��
//	�v���O��?�e?�u���ɑΉ�����B
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
	// NULL�̓f�o�C�X�Ɋ֌W�Ȃ�����
const INST_DBG_PROC InstDebugDeviceTbl[MAX_INSTRUCT_CODE]={
//0-0-0
		// NOP
		NULL    ,											// 000
		DbugDevB,DbugDevB,DbugDevB,DbugDevB,				// 001
		// AND
		DbugDevB,DbugDevB,DbugDevB,DbugDevB,NULL    ,		// 002
		// OR
		DbugDevB,DbugDevB,DbugDevB,DbugDevB,NULL    ,		// 003
		// OUT
		DbugDevB,DbugDevB,DbugDevB,DbugDevB,DbugDevB,
		DbugDevB,											// 004
		//MC_LOAD
		DbugDevB,DbugDevB,DbugDevB,DbugDevB,				// 009
		//MC_OR
		DbugDevB,DbugDevB,DbugDevB,DbugDevB,				// 00b
		//CTU
		DbugDevWC,DbugDevWC,DbugDevWC,DbugDevWC,			// 080
		// TON
		DbugDevWC,DbugDevWC,DbugDevWC,DbugDevWC,DbugDevWC,	// 088
		NULL	,NULL	,									//2008.05.19 Add
		// JMP
		NULL    ,NULL    ,NULL    ,NULL    ,NULL    ,
		NULL    ,NULL    ,									// 090
		//FOR
		NULL    ,NULL    ,NULL    ,							// 092
		//MCS
		NULL    ,NULL    ,									// 094
		//EI,DI
		NULL    ,NULL    ,NULL    ,NULL    ,NULL    ,
		NULL	,NULL	 ,NULL	  ,NULL	   ,				// 096
		//ELSE
		NULL    ,NULL    ,NULL    ,NULL    ,NULL    ,
		NULL    ,NULL    ,NULL    ,NULL    ,NULL    ,
		NULL    ,											// 0a0
//1-0-0
		//LOADEQ
		DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,
		DbugDevCC,											// 103
		//LOADDEQ
		DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,
		DbugDevCC,											// 104
		//ANDEQ
		DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,
		DbugDevCC,											// 113
		//ANDEQ
		DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,
		DbugDevCC,											// 114
		//OREQ
		DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,
		DbugDevCC,											// 123
		//ORDEQ
		DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,
		DbugDevCC,											// 124
		//MC_LOADEQ
		DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,
		DbugDevCC,											// 143
		//MC_LOADDEQ
		DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,
		DbugDevCC,											// 144
		//MC_OREQ
		DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,
		DbugDevCC,											// 163
		//MC_ORDEQ
		DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,DbugDevCC,
		DbugDevCC,											// 164
		//CMP
		NULL	,NULL	,NULL	,DbugDevCCB	,DbugDevCCB,
		DbugDevBBBC,										// 180
		//CMPL
		NULL	,NULL	,NULL	,DbugDevCCBC,DbugDevCCBC,	// 181
		//CMPG
		NULL	,NULL	,NULL	,DbugDevCCBC,DbugDevCCBC,	// 182
		//BWCMP
		NULL	,NULL	,NULL	,DbugDevCCCB,DbugDevCCCB,	// 1c0
		//BWCMPL
		NULL	,NULL	,NULL	,DbugDevCCCBC,DbugDevCCCBC,	// 1c1
		//BWCMPG
		NULL	,NULL	,NULL	,DbugDevCCCBC,DbugDevCCCBC,	// 1c2
//2-0-0
		// MOV
		DbugDevBB,NULL	,NULL	,DbugDevCW ,DbugDevCW ,		// 200
		// MOVL
		DbugDevBBC,NULL	,NULL	,DbugDevCWC,DbugDevCWC,		// 201
		// MOVG
		DbugDevBBC,NULL	,NULL	,DbugDevCWC,DbugDevCWC,		// 202
		// CMOV
		DbugDevBB,NULL	,NULL	,DbugDevCW ,DbugDevCW ,		// 210
		//XCH
		NULL	,NULL	,NULL	,DbugDevWW ,DbugDevWW ,DbugDevBBC,		// 230 2008.05.19 Add
		//SWP
		NULL	,NULL	,NULL	,DbugDevW  ,DbugDevW,		// 240
		//ROR
		NULL	,NULL	,NULL	,DbugDevWC,DbugDevWC,DbugDevBCC,
		NULL	,NULL	,NULL	,
		NULL	,NULL	,DbugDevWC,DbugDevWC,DbugDevBCC,		//260 2008.05.19 Add 
		//ROL
		NULL	,NULL	,NULL	,DbugDevWC,DbugDevWC,DbugDevBCC,
		NULL	,NULL	,NULL	,
		NULL	,NULL	,DbugDevWC,DbugDevWC,DbugDevBCC,		//270 2008.05.19 Add

		//SFTR,DSFTR
		NULL,NULL,NULL,DbugDevWC,NULL,DbugDevWCC,					// 290
		//SFTL,DSFTL
		NULL,NULL,NULL,DbugDevWC,NULL,DbugDevWCC,					// 2a0
		//WSFTR
		DbugDevWCC,											// 2b0
		//WSFTL
		DbugDevWCC,											// 2c0
		//SFTWR
		DbugDevWWC,											// 2d0
		//SFTRD
		DbugDevWWC,											// 2e0
//3-0-0
		// ADD
		NULL	,NULL	,NULL	,DbugDevCCW,DbugDevCCW,
		NULL	,NULL	,NULL	,NULL	,NULL	,
		DbugDevCCW,DbugDevCCW,								// 300
		// ADDL
		NULL	,NULL	,NULL	,DbugDevCCWC,DbugDevCCWC,
		NULL	,NULL	,NULL	,NULL	,NULL	,
		DbugDevCCWC,DbugDevCCWC,							// 301
		// ADDG
		NULL	,NULL	,NULL	,DbugDevCCWC,DbugDevCCWC,
		NULL	,NULL	,NULL	,NULL	,NULL	,
		DbugDevCCWC,DbugDevCCWC,							// 302

		//SUB
		NULL	,NULL	,NULL	,DbugDevCCW,DbugDevCCW,
		NULL	,NULL	,NULL	,NULL	,NULL	,
		DbugDevCCW,DbugDevCCW,								// 310
		//SUBL
		NULL	,NULL	,NULL	,DbugDevCCWC,DbugDevCCWC,
		NULL	,NULL	,NULL	,NULL	,NULL	,
		DbugDevCCWC,DbugDevCCWC,							// 311
		//SUBG
		NULL	,NULL	,NULL	,DbugDevCCWC,DbugDevCCWC,
		NULL	,NULL	,NULL	,NULL	,NULL	,
		DbugDevCCWC,DbugDevCCWC,							// 312

		//MUL
		NULL	,NULL	,NULL	,DbugDevCCW,DbugDevCCW,
		NULL	,NULL	,NULL	,NULL	,NULL	,
		DbugDevCCW,DbugDevCCW,								// 320
		//MULL
		NULL	,NULL	,NULL	,DbugDevCCWC,DbugDevCCWC,
		NULL	,NULL	,NULL	,NULL	,NULL	,
		DbugDevCCWC,DbugDevCCWC,							// 321
		//MULG
		NULL	,NULL	,NULL	,DbugDevCCWC,DbugDevCCWC,
		NULL	,NULL	,NULL	,NULL	,NULL	,
		DbugDevCCWC,DbugDevCCWC,							// 322

		//DIV
		NULL	,NULL	,NULL	,DbugDevCCW,DbugDevCCW,
		NULL	,NULL	,NULL	,NULL	,NULL	,
		DbugDevCCW,DbugDevCCW,								// 330
		//DIVL
		NULL	,NULL	,NULL	,DbugDevCCWC,DbugDevCCWC,
		NULL	,NULL	,NULL	,NULL	,NULL	,
		DbugDevCCWC,DbugDevCCWC,							// 331
		//DIVG
		NULL	,NULL	,NULL	,DbugDevCCWC,DbugDevCCWC,
		NULL	,NULL	,NULL	,NULL	,NULL	,
		DbugDevCCWC,DbugDevCCWC,							// 332

		// INC
		NULL,NULL,NULL,DbugDevW,DbugDevW,					// 340
		//DEC
		NULL,NULL,NULL,DbugDevW,DbugDevW,					// 350

		//ADDB
		NULL,NULL,NULL,DbugDevCCW,DbugDevCCW,				// 380
		//ADDBL
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 381
		//ADDBG
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 382

		//SUBB
		NULL,NULL,NULL,DbugDevCCW,DbugDevCCW,				// 390
		//SUBBL
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 391
		//SUBBG
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 392

		//MULB
		NULL,NULL,NULL,DbugDevCCW,DbugDevCCW,				// 3a0
		//MULBL
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 3a1
		//MULBG
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 3a2

		//DIVB
		NULL,NULL,NULL,DbugDevCCW,DbugDevCCW,				// 3b0
		//DIVBL
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 3b1
		//DIVBG
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 3b2

		//INCB
		NULL,NULL,NULL,DbugDevW,DbugDevW,					//3c0
		//DECB
		NULL,NULL,NULL,DbugDevW,DbugDevW,					//3d0
//4-0-0
		//WAND
		NULL,NULL,NULL,DbugDevCCW,DbugDevCCW,DbugDevBBBC,				// 400
		//WANDL
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 401
		//WANDG
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 402

		//WOR
		NULL,NULL,NULL,DbugDevCCW,DbugDevCCW,DbugDevBBBC,				// 410
		//WORL
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 411
		//WORG
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 412

		//WXOR
		NULL,NULL,NULL,DbugDevCCW,DbugDevCCW,DbugDevBBBC,				// 420
		//WXORL
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 421
		//WXORG
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 422

		//WXNR
		NULL,NULL,NULL,DbugDevCCW,DbugDevCCW,DbugDevBBBC,				// 430
		//WXNRL
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 431
		//WXNRG
		NULL,NULL,NULL,DbugDevCCWC,DbugDevCCWC,				// 432
//5-0-0
		//BINBCD,DBINBCD
		DbugDevCW	,DbugDevCW	,							// 5000
		//BCDBIN,DBCDBIB
		DbugDevCW	,DbugDevCW	,							// 5002
		//BIN2HASC,DBIN2HASC
		DbugDevCW	,DbugDevCW	,							// 5004
		//HASC2BIN,DHASC2BIN
		NULL		,NULL	,								// 5006
		//HBCD2DASC,DBCD2DASC
		DbugDevCW	,DbugDevCW	,							// 5008
		//DASC2BIN,DDASC2BIN
		DbugDevCW	,DbugDevCW	,							// 500a
		//STR2ASC
		NULL,
		//DASC2BCD,DDASC2BCD
		DbugDevCW	,DbugDevCW	,							// 500d
		//DBIN2DASC,DBIN2DASC
		DbugDevCW	,DbugDevCW	,							// 500f,1010

		//GRYBIN,DGRYBIN
		//BINGRY,DBINGRY
		DbugDevCW	,DbugDevCW	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,NULL		,DbugDevCW	,
		DbugDevCW	,							// 520

		//NEG
		NULL		,NULL		,NULL		,
		DbugDevW	,DbugDevW	,							// 530

		//DECO
		DbugDevWWC	,DbugDevWWC	,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,NULL		,NULL		,
		NULL		,DbugDevW	,							// 580
		//REF
		DbugDevBC	,										// 584
		//SEG
		DbugDevBBC	,										// 586
//0x6000
		//TCMP
		DbugDevCCCWB,DbugDevWWW	,DbugDevWWW	,
		DbugDevW	,DbugDevW	,DbugDevCWB	,
		DbugDevWWWB	,											// 600
//0x7000
		DbugDevCBCCCC,DbugDevCCCCCC	,DbugDevCC	,
		DbugDevC	,DbugDevC	,DbugDevCC	,
		DbugDevC	,DbugDevC	,DbugDevC	,
		DbugDevCC	,DbugDevCC	,DbugDevCCCC,
		DbugDevCC	,
};

//+++++++++++++++++++++++++++++++++++++++++++++++++++++
//	�X�e�b�v�v�Z�p�e?�u��
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//0x0000
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//NOP
	const	INST_LEN_PROC	func_0_0_0[NM_TBL000_CNT]={
		proc_getlen_NOP,
	};
	const	COM_XXXTBL	proc_tbl_0_0_0={NM_TBL000_CNT,NM_TBL000,func_0_0_0};
//LOAD
	const	INST_LEN_PROC	func_0_0_1[NM_TBL001_CNT]={
		proc_getlen_LOAD,proc_getlen_LOADN,proc_getlen_LOADP,proc_getlen_LOADF,
	};
	const	COM_XXXTBL	proc_tbl_0_0_1={NM_TBL001_CNT,NM_TBL001,func_0_0_1};
//AND
	const	INST_LEN_PROC	func_0_0_2[NM_TBL002_CNT]={
		proc_getlen_AND,proc_getlen_ANDN,proc_getlen_ANDP,
		proc_getlen_ANDF,proc_getlen_ANDL
	};
	const	COM_XXXTBL	proc_tbl_0_0_2={NM_TBL002_CNT,NM_TBL002,func_0_0_2};
//OR
	const	INST_LEN_PROC	func_0_0_3[NM_TBL003_CNT]={
		proc_getlen_OR,proc_getlen_ORN,proc_getlen_ORP,
		proc_getlen_ORF,proc_getlen_ORL
	};
	const	COM_XXXTBL	proc_tbl_0_0_3={NM_TBL003_CNT,NM_TBL003,func_0_0_3};
//OUT
	const	INST_LEN_PROC	func_0_0_4[NM_TBL004_CNT]={
		proc_getlen_OUT,proc_getlen_OUTP,proc_getlen_OUTF,
		proc_getlen_SET,proc_getlen_RST,proc_getlen_ALT,
	};
	const	COM_XXXTBL	proc_tbl_0_0_4={NM_TBL004_CNT,NM_TBL004,func_0_0_4};
//MC_LOAD
	const	INST_LEN_PROC	func_0_0_9[NM_TBL009_CNT]={
		proc_getlen_MC_LOAD,proc_getlen_MC_LOADN,proc_getlen_MC_LOADP,proc_getlen_MC_LOADF,
	};
	const	COM_XXXTBL	proc_tbl_0_0_9={NM_TBL009_CNT,NM_TBL009,func_0_0_9};
//MC_OR
	const	INST_LEN_PROC	func_0_0_b[NM_TBL00b_CNT]={
		proc_getlen_MC_OR,proc_getlen_MC_ORN,proc_getlen_MC_ORP,
		proc_getlen_MC_ORF,
	};
	const	COM_XXXTBL	proc_tbl_0_0_b={NM_TBL00b_CNT,NM_TBL00b,func_0_0_b};

//COUNTER
	const	INST_LEN_PROC	func_0_8_0[NM_TBL080_CNT]={
		proc_getlen_CTU,proc_getlen_CTD,proc_getlen_CTUD,
		proc_getlen_CTR
	};
	const	COM_XXXTBL	proc_tbl_0_8_0={NM_TBL080_CNT,NM_TBL080,func_0_8_0};
//TIMER
	const	INST_LEN_PROC	func_0_8_8[NM_TBL088_CNT]={
		proc_getlen_TON,proc_getlen_TOFF,proc_getlen_TMR,
		proc_getlen_TMON,proc_getlen_TRTG,proc_getlen_TTMR,
		proc_getlen_STMR,
	};
	const	COM_XXXTBL	proc_tbl_0_8_8={NM_TBL088_CNT,NM_TBL088,func_0_8_8};
//JMP
	const	INST_LEN_PROC	func_0_9_0[NM_TBL090_CNT]={
		proc_getlen_JMP  ,proc_getlen_LABEL,proc_getlen_CALL,
		proc_getlen_LABEL,proc_getlen_FCALL,proc_getlen_LABEL,
		proc_getlen_RET  ,
	};
	const	COM_XXXTBL	proc_tbl_0_9_0={NM_TBL090_CNT,NM_TBL090,func_0_9_0};
//FOR
	const	INST_LEN_PROC	func_0_9_2[NM_TBL092_CNT]={
		proc_getlen_FOR  ,proc_getlen_NEXT,proc_getlen_BREK,
	};
	const	COM_XXXTBL	proc_tbl_0_9_2={NM_TBL092_CNT,NM_TBL092,func_0_9_2};
//MCS
	const	INST_LEN_PROC	func_0_9_4[NM_TBL094_CNT]={
		proc_getlen_MCS  ,proc_getlen_MCR ,
	};
	const	COM_XXXTBL	proc_tbl_0_9_4={NM_TBL094_CNT,NM_TBL094,func_0_9_4};
//EI
	const	INST_LEN_PROC	func_0_9_6[NM_TBL096_CNT]={
		proc_getlen_EI   ,proc_getlen_DI  ,proc_getlen_ETI	,proc_getlen_EEI,
		proc_getlen_DTI	 ,proc_getlen_DEI ,proc_getlen_TINT	,proc_getlen_EINT,	
		proc_getlen_IRET
	};
	const	COM_XXXTBL	proc_tbl_0_9_6={NM_TBL096_CNT,NM_TBL096,func_0_9_6};
//ELSE
	const	INST_LEN_PROC	func_0_a_0[NM_TBL0a0_CNT]={
		NULL			 ,NULL			   ,NULL,
		proc_getlen_STOP ,NULL             ,NULL,
		proc_getlen_NOT  ,proc_getlen_MPUSH,proc_getlen_MLOAD,
		proc_getlen_MPOP ,proc_getlen_WDT
	};
	const	COM_XXXTBL	proc_tbl_0_a_0={NM_TBL0a0_CNT,NM_TBL0a0,func_0_a_0};
	//---------------------------------------------------------------------
	//0-XTable
	const COM_XXTBL Numonic_Pointer0_0={12,
		&proc_tbl_0_0_0,&proc_tbl_0_0_1,&proc_tbl_0_0_2,
		&proc_tbl_0_0_3,&proc_tbl_0_0_4,NULL,
		NULL,NULL,NULL,
		&proc_tbl_0_0_9,NULL,&proc_tbl_0_0_b};
	const COM_XXTBL Numonic_Pointer0_8={9,
		&proc_tbl_0_8_0,NULL,NULL,NULL,NULL,
		NULL,NULL,NULL,&proc_tbl_0_8_8};
	const COM_XXTBL Numonic_Pointer0_9={7,
		&proc_tbl_0_9_0,NULL,&proc_tbl_0_9_2,NULL,
		&proc_tbl_0_9_4,NULL,&proc_tbl_0_9_6};
	const COM_XXTBL Numonic_Pointer0_a={1,&proc_tbl_0_a_0};
	const COM_XTBL Numonic_Pointer0[16]={
		&Numonic_Pointer0_0,NULL			   ,NULL,
		NULL			   ,NULL			   ,NULL,
		NULL			   ,NULL			   ,&Numonic_Pointer0_8,
		&Numonic_Pointer0_9,&Numonic_Pointer0_a,NULL,
	};
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//0x1000
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//LOAD=
	const	INST_LEN_PROC	func_1_0_3[NM_TBL103_CNT]={
		proc_getlen_LOADEQ,proc_getlen_LOADGT,proc_getlen_LOADLT,
		proc_getlen_LOADNE,proc_getlen_LOADGE,proc_getlen_LOADLE,
	};
	const	COM_XXXTBL	proc_tbl_1_0_3={NM_TBL103_CNT,NM_TBL103,func_1_0_3};
//LOADD=
	const	INST_LEN_PROC	func_1_0_4[NM_TBL104_CNT]={
		proc_getlen_LOADDEQ,proc_getlen_LOADDGT,proc_getlen_LOADDLT,
		proc_getlen_LOADDNE,proc_getlen_LOADDGE,proc_getlen_LOADDLE,
	};
	const	COM_XXXTBL	proc_tbl_1_0_4={NM_TBL104_CNT,NM_TBL104,func_1_0_4};
//AND=
	const	INST_LEN_PROC	func_1_1_3[NM_TBL113_CNT]={
		proc_getlen_ANDEQ,proc_getlen_ANDGT,proc_getlen_ANDLT,
		proc_getlen_ANDNE,proc_getlen_ANDGE,proc_getlen_ANDLE
	};
	const	COM_XXXTBL	proc_tbl_1_1_3={NM_TBL113_CNT,NM_TBL113,func_1_1_3};
//ANDD=
	const	INST_LEN_PROC	func_1_1_4[NM_TBL114_CNT]={
		proc_getlen_ANDDEQ,proc_getlen_ANDDGT,proc_getlen_ANDDLT,
		proc_getlen_ANDDNE,proc_getlen_ANDDGE,proc_getlen_ANDDLE
	};
	const	COM_XXXTBL	proc_tbl_1_1_4={NM_TBL114_CNT,NM_TBL114,func_1_1_4};
//OR=
	const	INST_LEN_PROC	func_1_2_3[NM_TBL123_CNT]={
		proc_getlen_OREQ,proc_getlen_ORGT,proc_getlen_ORLT,
		proc_getlen_ORNE,proc_getlen_ORGE,proc_getlen_ORLE
	};
	const	COM_XXXTBL	proc_tbl_1_2_3={NM_TBL123_CNT,NM_TBL123,func_1_2_3};
//ORD=
	const	INST_LEN_PROC	func_1_2_4[NM_TBL124_CNT]={
		proc_getlen_ORDEQ,proc_getlen_ORDGT,proc_getlen_ORDLT,
		proc_getlen_ORDNE,proc_getlen_ORDGE,proc_getlen_ORDLE
	};
	const	COM_XXXTBL	proc_tbl_1_2_4={NM_TBL124_CNT,NM_TBL124,func_1_2_4};
//MC_LOAD=
	const	INST_LEN_PROC	func_1_4_3[NM_TBL143_CNT]={
		proc_getlen_MC_LOADEQ,proc_getlen_MC_LOADGT,proc_getlen_MC_LOADLT,
		proc_getlen_MC_LOADNE,proc_getlen_MC_LOADGE,proc_getlen_MC_LOADLE,
	};
	const	COM_XXXTBL	proc_tbl_1_4_3={NM_TBL143_CNT,NM_TBL143,func_1_4_3};
//MC_LOADD=
	const	INST_LEN_PROC	func_1_4_4[NM_TBL144_CNT]={
		proc_getlen_MC_LOADDEQ,proc_getlen_MC_LOADDGT,proc_getlen_MC_LOADDLT,
		proc_getlen_MC_LOADDNE,proc_getlen_MC_LOADDGE,proc_getlen_MC_LOADDLE,
	};
	const	COM_XXXTBL	proc_tbl_1_4_4={NM_TBL144_CNT,NM_TBL144,func_1_4_4};
//MC_OR=
	const	INST_LEN_PROC	func_1_6_3[NM_TBL163_CNT]={
		proc_getlen_MC_OREQ,proc_getlen_MC_ORGT,proc_getlen_MC_ORLT,
		proc_getlen_MC_ORNE,proc_getlen_MC_ORGE,proc_getlen_MC_ORLE
	};
	const	COM_XXXTBL	proc_tbl_1_6_3={NM_TBL163_CNT,NM_TBL163,func_1_6_3};
//MC_ORD=
	const	INST_LEN_PROC	func_1_6_4[NM_TBL164_CNT]={
		proc_getlen_MC_ORDEQ,proc_getlen_MC_ORDGT,proc_getlen_MC_ORDLT,
		proc_getlen_MC_ORDNE,proc_getlen_MC_ORDGE,proc_getlen_MC_ORDLE
	};
	const	COM_XXXTBL	proc_tbl_1_6_4={NM_TBL164_CNT,NM_TBL164,func_1_6_4};

//CMP
	const	INST_LEN_PROC	func_1_8_0[NM_TBL180_CNT]={
		NULL,NULL,NULL,proc_getlen_CMP,proc_getlen_DCMP,proc_getlen_ACMP,
	};
	const	COM_XXXTBL	proc_tbl_1_8_0={NM_TBL180_CNT,NM_TBL180,func_1_8_0};
//CMPL
	const	INST_LEN_PROC	func_1_8_1[NM_TBL181_CNT]={
		NULL,NULL,NULL,proc_getlen_CMPL,proc_getlen_DCMPL,
	};
	const	COM_XXXTBL	proc_tbl_1_8_1={NM_TBL181_CNT,NM_TBL181,func_1_8_1};
//CMPG
	const	INST_LEN_PROC	func_1_8_2[NM_TBL182_CNT]={
		NULL,NULL,NULL,proc_getlen_CMPL,proc_getlen_DCMPL,
	};
	const	COM_XXXTBL	proc_tbl_1_8_2={NM_TBL182_CNT,NM_TBL182,func_1_8_2};
//BWCMP
	const	INST_LEN_PROC	func_1_c_0[NM_TBL1c0_CNT]={
		NULL,NULL,NULL,proc_getlen_BWCMP,proc_getlen_DBWCMP,
	};
	const	COM_XXXTBL	proc_tbl_1_c_0={NM_TBL1c0_CNT,NM_TBL1c0,func_1_c_0};
//BWCMPL
	const	INST_LEN_PROC	func_1_c_1[NM_TBL1c1_CNT]={
		NULL,NULL,NULL,proc_getlen_BWCMPL,proc_getlen_DBWCMPL,
	};
	const	COM_XXXTBL	proc_tbl_1_c_1={NM_TBL1c1_CNT,NM_TBL1c1,func_1_c_1};
//BWCMPG
	const	INST_LEN_PROC	func_1_c_2[NM_TBL1c2_CNT]={
		NULL,NULL,NULL,proc_getlen_BWCMPG,proc_getlen_DBWCMPG,
	};
	const	COM_XXXTBL	proc_tbl_1_c_2={NM_TBL1c2_CNT,NM_TBL1c2,func_1_c_2};
//---------------------------------------------------------------------
	//1-XTable
	const COM_XXTBL Numonic_Pointer1_0={
		5,
		NULL,NULL,NULL,&proc_tbl_1_0_3,&proc_tbl_1_0_4
	};
	const COM_XXTBL Numonic_Pointer1_1={
		5,
		NULL,NULL,NULL,&proc_tbl_1_1_3,&proc_tbl_1_1_4
	};
	const COM_XXTBL Numonic_Pointer1_2={
		5,
		NULL,NULL,NULL,&proc_tbl_1_2_3,&proc_tbl_1_2_4
	};
	const COM_XXTBL Numonic_Pointer1_4={
		5,
		NULL,NULL,NULL,&proc_tbl_1_4_3,&proc_tbl_1_4_4
	};
	const COM_XXTBL Numonic_Pointer1_6={
		5,
		NULL,NULL,NULL,&proc_tbl_1_6_3,&proc_tbl_1_6_4
	};
	const COM_XXTBL Numonic_Pointer1_8={
		11,
		&proc_tbl_1_8_0,&proc_tbl_1_8_1,&proc_tbl_1_8_2,NULL,NULL,
		NULL,NULL,NULL,NULL,NULL,NULL
	};
	const COM_XXTBL Numonic_Pointer1_c={
		12,
		&proc_tbl_1_c_0,&proc_tbl_1_c_1,&proc_tbl_1_c_2,NULL,
		NULL,NULL,NULL,NULL,
		NULL,NULL,NULL,NULL
	};
	const COM_XTBL Numonic_Pointer1[16]={
		&Numonic_Pointer1_0,&Numonic_Pointer1_1,&Numonic_Pointer1_2,
		NULL               ,&Numonic_Pointer1_4,NULL,
		&Numonic_Pointer1_6,NULL			   ,&Numonic_Pointer1_8,
		NULL			   ,NULL			   ,NULL,
		&Numonic_Pointer1_c,
	};
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//0x2000
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//MOV
	const	INST_LEN_PROC	func_2_0_0[NM_TBL200_CNT]={
		proc_getlen_BMOV,NULL,NULL,proc_getlen_MOV,proc_getlen_DMOV,
	};
	const	COM_XXXTBL	proc_tbl_2_0_0={NM_TBL200_CNT,NM_TBL200,func_2_0_0};
//MOVL
	const	INST_LEN_PROC	func_2_0_1[NM_TBL201_CNT]={
		proc_getlen_BMOVL,NULL,NULL,proc_getlen_MOVL ,proc_getlen_DMOVL,
	};
	const	COM_XXXTBL	proc_tbl_2_0_1={NM_TBL201_CNT,NM_TBL201,func_2_0_1};
//MOVG
	const	INST_LEN_PROC	func_2_0_2[NM_TBL202_CNT]={
		proc_getlen_BMOVG,NULL,NULL,proc_getlen_MOVG,proc_getlen_DMOVG,
	};
	const	COM_XXXTBL	proc_tbl_2_0_2={NM_TBL202_CNT,NM_TBL202,func_2_0_2};
//CMOV
	const	INST_LEN_PROC	func_2_1_0[NM_TBL210_CNT]={
		proc_getlen_BCMOV,NULL,NULL,proc_getlen_CMOV ,proc_getlen_DCMOV,
	};
	const	COM_XXXTBL	proc_tbl_2_1_0={NM_TBL210_CNT,NM_TBL210,func_2_1_0};
//XCH
	const	INST_LEN_PROC	func_2_3_0[NM_TBL230_CNT]={
		NULL,NULL,NULL,proc_getlen_XCH,proc_getlen_DXCH,proc_getlen_AXCH,
	};
	const	COM_XXXTBL	proc_tbl_2_3_0={NM_TBL230_CNT,NM_TBL230,func_2_3_0};
//SWAP
	const	INST_LEN_PROC	func_2_4_0[NM_TBL240_CNT]={
		NULL,NULL,NULL,proc_getlen_SWP,proc_getlen_DSWP,
	};
	const	COM_XXXTBL	proc_tbl_2_4_0={NM_TBL240_CNT,NM_TBL240,func_2_4_0};
//NROR
	const	INST_LEN_PROC	func_2_6_0[NM_TBL260_CNT]={
		NULL,NULL,NULL,proc_getlen_ROR,
		proc_getlen_DROR,proc_getlen_AROR,NULL,NULL,
		NULL,NULL,NULL,proc_getlen_RORC,
		proc_getlen_DRORC,proc_getlen_ARORC
	};
	const	COM_XXXTBL	proc_tbl_2_6_0={NM_TBL260_CNT,NM_TBL260,func_2_6_0};
//NROL
	const	INST_LEN_PROC	func_2_7_0[NM_TBL270_CNT]={
		NULL,NULL,NULL,proc_getlen_ROL,
		proc_getlen_DROL,proc_getlen_AROL,NULL,NULL,
		NULL,NULL,NULL,proc_getlen_RORC,
		proc_getlen_DROLC,proc_getlen_AROLC
	};
	const	COM_XXXTBL	proc_tbl_2_7_0={NM_TBL270_CNT,NM_TBL270,func_2_7_0};

//SFTR,ASFTR
	const	INST_LEN_PROC	func_2_9_0[NM_TBL290_CNT]={
		NULL,NULL,NULL,proc_getlen_SFTR,NULL,proc_getlen_ASFTR,
	};
	const	COM_XXXTBL	proc_tbl_2_9_0={NM_TBL290_CNT,NM_TBL290,func_2_9_0};
//SFTL,ASFTL
	const	INST_LEN_PROC	func_2_a_0[NM_TBL2a0_CNT]={
		NULL,NULL,NULL,proc_getlen_SFTL,NULL,proc_getlen_ASFTL,
	};
	const	COM_XXXTBL	proc_tbl_2_a_0={NM_TBL2a0_CNT,NM_TBL2a0,func_2_a_0};
//WSFTR
	const	INST_LEN_PROC	func_2_b_0[NM_TBL2b0_CNT]={
		proc_getlen_WSFTR,
	};
	const	COM_XXXTBL	proc_tbl_2_b_0={NM_TBL2b0_CNT,NM_TBL2b0,func_2_b_0};
//WSFTL
	const	INST_LEN_PROC	func_2_c_0[NM_TBL2c0_CNT]={
		proc_getlen_WSFTL,
	};
	const	COM_XXXTBL	proc_tbl_2_c_0={NM_TBL2c0_CNT,NM_TBL2c0,func_2_c_0};
//SFTWR
	const	INST_LEN_PROC	func_2_d_0[NM_TBL2d0_CNT]={
		proc_getlen_SFTWR,
	};
	const	COM_XXXTBL	proc_tbl_2_d_0={NM_TBL2d0_CNT,NM_TBL2d0,func_2_d_0};
//SFTRD
	const	INST_LEN_PROC	func_2_e_0[NM_TBL2e0_CNT]={
		proc_getlen_SFTWR,
	};
	const	COM_XXXTBL	proc_tbl_2_e_0={NM_TBL2e0_CNT,NM_TBL2e0,func_2_e_0};
	//----------------------------------------------------------------------
	//2-XTable
	const COM_XXTBL Numonic_Pointer2_0={
		12,
		&proc_tbl_2_0_0,&proc_tbl_2_0_1,&proc_tbl_2_0_2,
	};
	const COM_XXTBL Numonic_Pointer2_1={
		12,
		&proc_tbl_2_1_0,
	};
	const COM_XXTBL Numonic_Pointer2_3={
		11,
		&proc_tbl_2_3_0,NULL,
	};
	const COM_XXTBL Numonic_Pointer2_4={
		10,
		&proc_tbl_2_4_0,
	};
	const COM_XXTBL Numonic_Pointer2_6={
		10,
		&proc_tbl_2_6_0,NULL,NULL,NULL,
		NULL,NULL,NULL,NULL,
		NULL,NULL
	};
	const COM_XXTBL Numonic_Pointer2_7={
		10,
		&proc_tbl_2_7_0,NULL,
		NULL,NULL,NULL,NULL,
		NULL,NULL
	};
	const COM_XXTBL Numonic_Pointer2_9={1,&proc_tbl_2_9_0};
	const COM_XXTBL Numonic_Pointer2_a={1,&proc_tbl_2_a_0};
	const COM_XXTBL Numonic_Pointer2_b={1,&proc_tbl_2_b_0};
	const COM_XXTBL Numonic_Pointer2_c={1,&proc_tbl_2_c_0};
	const COM_XXTBL Numonic_Pointer2_d={1,&proc_tbl_2_d_0};
	const COM_XXTBL Numonic_Pointer2_e={1,&proc_tbl_2_e_0};
	const COM_XTBL Numonic_Pointer2[16]={
		&Numonic_Pointer2_0,&Numonic_Pointer2_1,NULL,
		&Numonic_Pointer2_3,&Numonic_Pointer2_4,NULL,
		&Numonic_Pointer2_6,&Numonic_Pointer2_7,NULL,
		&Numonic_Pointer2_9,&Numonic_Pointer2_a,&Numonic_Pointer2_b,
		&Numonic_Pointer2_c,&Numonic_Pointer2_d,&Numonic_Pointer2_e,
	};
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//0x3000
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//ADD
	const	INST_LEN_PROC	func_3_0_0[NM_TBL300_CNT]={
		NULL,NULL,NULL,proc_getlen_ADD,
		proc_getlen_DADD,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_ADDU,proc_getlen_DADDU,
	};
	const	COM_XXXTBL	proc_tbl_3_0_0={NM_TBL300_CNT,NM_TBL300,func_3_0_0};
//ADDL
	const	INST_LEN_PROC	func_3_0_1[NM_TBL301_CNT]={
		NULL,NULL,NULL,proc_getlen_ADDL,
		proc_getlen_DADDL,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_ADDUL,proc_getlen_DADDUL,
	};
	const	COM_XXXTBL	proc_tbl_3_0_1={NM_TBL301_CNT,NM_TBL301,func_3_0_1};
//ADDG
	const	INST_LEN_PROC	func_3_0_2[NM_TBL302_CNT]={
		NULL,NULL,NULL,proc_getlen_ADDG,
		proc_getlen_DADDG,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_ADDUG,proc_getlen_DADDUG,
	};
	const	COM_XXXTBL	proc_tbl_3_0_2={NM_TBL302_CNT,NM_TBL302,func_3_0_2};
//SUB
	const	INST_LEN_PROC	func_3_1_0[NM_TBL310_CNT]={
		NULL,NULL,NULL,proc_getlen_SUB,
		proc_getlen_DSUB,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_SUBU,proc_getlen_DSUBU
	};
	const	COM_XXXTBL	proc_tbl_3_1_0={NM_TBL310_CNT,NM_TBL310,func_3_1_0};
//SUBL
	const	INST_LEN_PROC	func_3_1_1[NM_TBL311_CNT]={
		NULL,NULL,NULL,proc_getlen_SUBL,
		proc_getlen_DSUBL,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_SUBUL,proc_getlen_DSUBUL
	};
	const	COM_XXXTBL	proc_tbl_3_1_1={NM_TBL311_CNT,NM_TBL311,func_3_1_1};
//SUBG
	const	INST_LEN_PROC	func_3_1_2[NM_TBL312_CNT]={
		NULL,NULL,NULL,proc_getlen_SUBG,
		proc_getlen_DSUBG,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_SUBUG,proc_getlen_DSUBUG
	};
	const	COM_XXXTBL	proc_tbl_3_1_2={NM_TBL312_CNT,NM_TBL312,func_3_1_2};
//MUL
	const	INST_LEN_PROC	func_3_2_0[NM_TBL320_CNT]={
		NULL,NULL,NULL,proc_getlen_MUL,
		proc_getlen_DMUL,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_MULU,proc_getlen_DMULU
	};
	const	COM_XXXTBL	proc_tbl_3_2_0={NM_TBL320_CNT,NM_TBL320,func_3_2_0};
//MULL
	const	INST_LEN_PROC	func_3_2_1[NM_TBL321_CNT]={
		NULL,NULL,NULL,proc_getlen_MULL,
		proc_getlen_DMULL,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_MULUL,proc_getlen_DMULUL
	};
	const	COM_XXXTBL	proc_tbl_3_2_1={NM_TBL321_CNT,NM_TBL321,func_3_2_1};
//MULG
	const	INST_LEN_PROC	func_3_2_2[NM_TBL322_CNT]={
		NULL,NULL,NULL,proc_getlen_MULG,
		proc_getlen_DMULG,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_MULUG,proc_getlen_DMULUG
	};
	const	COM_XXXTBL	proc_tbl_3_2_2={NM_TBL322_CNT,NM_TBL322,func_3_2_2};
//DIV
	const	INST_LEN_PROC	func_3_3_0[NM_TBL330_CNT]={
		NULL,NULL,NULL,proc_getlen_DIV,
		proc_getlen_DDIV,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_DIVU,proc_getlen_DDIVU
	};
	const	COM_XXXTBL	proc_tbl_3_3_0={NM_TBL330_CNT,NM_TBL330,func_3_3_0};
//DIVL
	const	INST_LEN_PROC	func_3_3_1[NM_TBL331_CNT]={
		NULL,NULL,NULL,proc_getlen_DIVL,
		proc_getlen_DDIVL,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_DIVUL,proc_getlen_DDIVUL
	};
	const	COM_XXXTBL	proc_tbl_3_3_1={NM_TBL331_CNT,NM_TBL331,func_3_3_1};
//DIVG
	const	INST_LEN_PROC	func_3_3_2[NM_TBL332_CNT]={
		NULL,NULL,NULL,proc_getlen_DIVG,
		proc_getlen_DDIVG,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_DIVUG,proc_getlen_DDIVUG
	};
	const	COM_XXXTBL	proc_tbl_3_3_2={NM_TBL332_CNT,NM_TBL332,func_3_3_2};
//INC
	const	INST_LEN_PROC	func_3_4_0[NM_TBL340_CNT]={
		NULL,NULL,NULL,proc_getlen_INC,proc_getlen_DINC,
	};
	const	COM_XXXTBL	proc_tbl_3_4_0={NM_TBL340_CNT,NM_TBL340,func_3_4_0};
//DEC
	const	INST_LEN_PROC	func_3_5_0[NM_TBL350_CNT]={
		NULL,NULL,NULL,proc_getlen_DEC,proc_getlen_DDEC,
	};
	const	COM_XXXTBL	proc_tbl_3_5_0={NM_TBL350_CNT,NM_TBL350,func_3_5_0};
//ADDB
	const	INST_LEN_PROC	func_3_8_0[NM_TBL380_CNT]={
		NULL,NULL,NULL,proc_getlen_ADDB,proc_getlen_DADDB,
	};
	const	COM_XXXTBL	proc_tbl_3_8_0={NM_TBL380_CNT,NM_TBL380,func_3_8_0};
//ADDBL
	const	INST_LEN_PROC	func_3_8_1[NM_TBL381_CNT]={
		NULL,NULL,NULL,proc_getlen_ADDBL,proc_getlen_DADDBL,
	};
	const	COM_XXXTBL	proc_tbl_3_8_1={NM_TBL381_CNT,NM_TBL381,func_3_8_1};
//ADDBG
	const	INST_LEN_PROC	func_3_8_2[NM_TBL382_CNT]={
		NULL,NULL,NULL,proc_getlen_ADDBG,proc_getlen_DADDBG,
	};
	const	COM_XXXTBL	proc_tbl_3_8_2={NM_TBL382_CNT,NM_TBL382,func_3_8_2};
//SUBB
	const	INST_LEN_PROC	func_3_9_0[NM_TBL390_CNT]={
		NULL,NULL,NULL,proc_getlen_SUBB,proc_getlen_DSUBB,
	};
	const	COM_XXXTBL	proc_tbl_3_9_0={NM_TBL390_CNT,NM_TBL390,func_3_9_0};
//SUBBL
	const	INST_LEN_PROC	func_3_9_1[NM_TBL391_CNT]={
		NULL,NULL,NULL,proc_getlen_SUBBL,proc_getlen_DSUBBL,
	};
	const	COM_XXXTBL	proc_tbl_3_9_1={NM_TBL391_CNT,NM_TBL391,func_3_9_1};
//SUBBG
	const	INST_LEN_PROC	func_3_9_2[NM_TBL392_CNT]={
		NULL,NULL,NULL,proc_getlen_SUBBG,proc_getlen_DSUBBG,
	};
	const	COM_XXXTBL	proc_tbl_3_9_2={NM_TBL392_CNT,NM_TBL392,func_3_9_2};
//MULB
	const	INST_LEN_PROC	func_3_a_0[NM_TBL3a0_CNT]={
		NULL,NULL,NULL,proc_getlen_MULB,proc_getlen_DMULB,
	};
	const	COM_XXXTBL	proc_tbl_3_a_0={NM_TBL3a0_CNT,NM_TBL3a0,func_3_a_0};
//MULBL
	const	INST_LEN_PROC	func_3_a_1[NM_TBL3a1_CNT]={
		NULL,NULL,NULL,proc_getlen_MULBL,proc_getlen_DMULBL,
	};
	const	COM_XXXTBL	proc_tbl_3_a_1={NM_TBL3a1_CNT,NM_TBL3a1,func_3_a_1};
//MULBG
	const	INST_LEN_PROC	func_3_a_2[NM_TBL3a2_CNT]={
		NULL,NULL,NULL,proc_getlen_MULBG,proc_getlen_DMULBG,
	};
	const	COM_XXXTBL	proc_tbl_3_a_2={NM_TBL3a2_CNT,NM_TBL3a2,func_3_a_2};
//DIVB
	const	INST_LEN_PROC	func_3_b_0[NM_TBL3b0_CNT]={
		NULL,NULL,NULL,proc_getlen_DIVB,proc_getlen_DDIVB,
	};
	const	COM_XXXTBL	proc_tbl_3_b_0={NM_TBL3b0_CNT,NM_TBL3b0,func_3_b_0};
//DIVBL
	const	INST_LEN_PROC	func_3_b_1[NM_TBL3b1_CNT]={
		NULL,NULL,NULL,proc_getlen_DIVBL,proc_getlen_DDIVBL,
	};
	const	COM_XXXTBL	proc_tbl_3_b_1={NM_TBL3b1_CNT,NM_TBL3b1,func_3_b_1};
//DIVBG
	const	INST_LEN_PROC	func_3_b_2[NM_TBL3b2_CNT]={
		NULL,NULL,NULL,proc_getlen_DIVBG,proc_getlen_DDIVBG,
	};
	const	COM_XXXTBL	proc_tbl_3_b_2={NM_TBL3b2_CNT,NM_TBL3b2,func_3_b_2};
//INCB
	const	INST_LEN_PROC	func_3_c_0[NM_TBL3c0_CNT]={
		NULL,NULL,NULL,proc_getlen_INCB,proc_getlen_DINCB,
	};
	const	COM_XXXTBL	proc_tbl_3_c_0={NM_TBL3c0_CNT,NM_TBL3c0,func_3_c_0};
//DECB
	const	INST_LEN_PROC	func_3_d_0[NM_TBL3d0_CNT]={
		NULL,NULL,NULL,proc_getlen_DECB,proc_getlen_DDECB,
	};
	const	COM_XXXTBL	proc_tbl_3_d_0={NM_TBL3d0_CNT,NM_TBL3d0,func_3_d_0};
	//----------------------------------------------------------------------
	//3-XTable
	const COM_XXTBL Numonic_Pointer3_0={
		12,
		&proc_tbl_3_0_0,&proc_tbl_3_0_1,&proc_tbl_3_0_2,
	};
	const COM_XXTBL Numonic_Pointer3_1={
		12,
		&proc_tbl_3_1_0,&proc_tbl_3_1_1,&proc_tbl_3_1_2,
	};
	const COM_XXTBL Numonic_Pointer3_2={
		12,
		&proc_tbl_3_2_0,&proc_tbl_3_2_1,&proc_tbl_3_2_2,
	};
	const COM_XXTBL Numonic_Pointer3_3={
		12,
		&proc_tbl_3_3_0,&proc_tbl_3_3_1,&proc_tbl_3_3_2,
	};
	const COM_XXTBL Numonic_Pointer3_4={
		10,
		&proc_tbl_3_4_0,NULL,NULL,NULL,
	};
	const COM_XXTBL Numonic_Pointer3_5={
		10,
		&proc_tbl_3_5_0,NULL,NULL,NULL,
	};
	const COM_XXTBL Numonic_Pointer3_8={
		12,
		&proc_tbl_3_8_0,&proc_tbl_3_8_1,&proc_tbl_3_8_2,
	};
	const COM_XXTBL Numonic_Pointer3_9={
		12,
		&proc_tbl_3_9_0,&proc_tbl_3_9_1,&proc_tbl_3_9_2,
	};
	const COM_XXTBL Numonic_Pointer3_a={
		12,
		&proc_tbl_3_a_0,&proc_tbl_3_a_1,&proc_tbl_3_a_2,
	};
	const COM_XXTBL Numonic_Pointer3_b={
		12,
		&proc_tbl_3_b_0,&proc_tbl_3_b_1,&proc_tbl_3_b_2,
	};
	const COM_XXTBL Numonic_Pointer3_c={
		10,
		&proc_tbl_3_c_0,NULL,NULL,NULL,
	};
	const COM_XXTBL Numonic_Pointer3_d={
		10,
		&proc_tbl_3_d_0,NULL,NULL,NULL,
	};
	const COM_XTBL Numonic_Pointer3[16]={
		&Numonic_Pointer3_0,&Numonic_Pointer3_1,&Numonic_Pointer3_2,
		&Numonic_Pointer3_3,&Numonic_Pointer3_4,&Numonic_Pointer3_5,
		NULL			   ,NULL			   ,&Numonic_Pointer3_8,
		&Numonic_Pointer3_9,&Numonic_Pointer3_a,&Numonic_Pointer3_b,
		&Numonic_Pointer3_c,&Numonic_Pointer3_d,
	};
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//0x4000
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//WAND
	const	INST_LEN_PROC	func_4_0_0[NM_TBL400_CNT]={
		NULL,NULL,NULL,proc_getlen_WAND,proc_getlen_DWAND,proc_getlen_AWAND
	};
	const	COM_XXXTBL	proc_tbl_4_0_0={NM_TBL400_CNT,NM_TBL400,func_4_0_0};
//WANDL
	const	INST_LEN_PROC	func_4_0_1[NM_TBL401_CNT]={
		NULL,NULL,NULL,proc_getlen_WANDL,proc_getlen_DWANDL,
	};
	const	COM_XXXTBL	proc_tbl_4_0_1={NM_TBL401_CNT,NM_TBL401,func_4_0_1};
//WANDG
	const	INST_LEN_PROC	func_4_0_2[NM_TBL402_CNT]={
		NULL,NULL,NULL,proc_getlen_WANDG,proc_getlen_DWANDG,
	};
	const	COM_XXXTBL	proc_tbl_4_0_2={NM_TBL402_CNT,NM_TBL402,func_4_0_2};
//WOR
	const	INST_LEN_PROC	func_4_1_0[NM_TBL410_CNT]={
		NULL,NULL,NULL,proc_getlen_WOR,proc_getlen_DWOR,proc_getlen_AWOR
	};
	const	COM_XXXTBL	proc_tbl_4_1_0={NM_TBL410_CNT,NM_TBL410,func_4_1_0};
//WORL
	const	INST_LEN_PROC	func_4_1_1[NM_TBL411_CNT]={
		NULL,NULL,NULL,proc_getlen_WORL,proc_getlen_DWORL,
	};
	const	COM_XXXTBL	proc_tbl_4_1_1={NM_TBL411_CNT,NM_TBL411,func_4_1_1};
//WORG
	const	INST_LEN_PROC	func_4_1_2[NM_TBL412_CNT]={
		NULL,NULL,NULL,proc_getlen_WORG,proc_getlen_DWORG,
	};
	const	COM_XXXTBL	proc_tbl_4_1_2={NM_TBL412_CNT,NM_TBL412,func_4_1_2};
//WXOR
	const	INST_LEN_PROC	func_4_2_0[NM_TBL420_CNT]={
		NULL,NULL,NULL,proc_getlen_WXOR,proc_getlen_DWXOR,proc_getlen_AWXOR
	};
	const	COM_XXXTBL	proc_tbl_4_2_0={NM_TBL420_CNT,NM_TBL420,func_4_2_0};
//XORL
	const	INST_LEN_PROC	func_4_2_1[NM_TBL421_CNT]={
		NULL,NULL,NULL,proc_getlen_WXORL,proc_getlen_DWXORL,
	};
	const	COM_XXXTBL	proc_tbl_4_2_1={NM_TBL421_CNT,NM_TBL421,func_4_2_1};
//WXORG
	const	INST_LEN_PROC	func_4_2_2[NM_TBL422_CNT]={
		NULL,NULL,NULL,proc_getlen_WXORG,proc_getlen_DWXORG,
	};
	const	COM_XXXTBL	proc_tbl_4_2_2={NM_TBL422_CNT,NM_TBL422,func_4_2_2};
//XNR
	const	INST_LEN_PROC	func_4_3_0[NM_TBL430_CNT]={
		NULL,NULL,NULL,proc_getlen_WXNR,proc_getlen_DWXNR,proc_getlen_AWXNR
	};
	const	COM_XXXTBL	proc_tbl_4_3_0={NM_TBL430_CNT,NM_TBL430,func_4_3_0};
//XNRL
	const	INST_LEN_PROC	func_4_3_1[NM_TBL431_CNT]={
		NULL,NULL,NULL,proc_getlen_WXNRL,proc_getlen_DWXNRL,
	};
	const	COM_XXXTBL	proc_tbl_4_3_1={NM_TBL431_CNT,NM_TBL431,func_4_3_1};
//XNRG
	const	INST_LEN_PROC	func_4_3_2[NM_TBL432_CNT]={
		NULL,NULL,NULL,proc_getlen_WXNRG,proc_getlen_DWXNRG,
	};
	const	COM_XXXTBL	proc_tbl_4_3_2={NM_TBL432_CNT,NM_TBL432,func_4_3_2};
//-----------------------------------------------------------------------
	//4-XTable
	const COM_XXTBL Numonic_Pointer4_0={
		12,
		&proc_tbl_4_0_0,&proc_tbl_4_0_1,&proc_tbl_4_0_2,
	};
	const COM_XXTBL Numonic_Pointer4_1={
		12,
		&proc_tbl_4_1_0,&proc_tbl_4_1_1,&proc_tbl_4_1_2,
	};
	const COM_XXTBL Numonic_Pointer4_2={
		12,
		&proc_tbl_4_2_0,&proc_tbl_4_2_1,&proc_tbl_4_2_2,
	};
	const COM_XXTBL Numonic_Pointer4_3={
		12,
		&proc_tbl_4_3_0,&proc_tbl_4_3_1,&proc_tbl_4_3_2,
	};
	const COM_XTBL Numonic_Pointer4[16]={
		&Numonic_Pointer4_0,&Numonic_Pointer4_1,&Numonic_Pointer4_2,
		&Numonic_Pointer4_3,NULL			   ,NULL,
	};
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//0x5000
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//BINBCD
	const	INST_LEN_PROC	func_5_0_0[NM_TBL500_CNT]={
		proc_getlen_BINBCD,proc_getlen_DBINBCD,			//5000,5001
		proc_getlen_BCDBIN,proc_getlen_DBCDBIN,			//5002,5003
		proc_getlen_BIN2HASC,proc_getlen_DBIN2HASC,		//5004,5005
		proc_getlen_HASC2BIN,proc_getlen_DHASC2BIN,		//5006,5007
		proc_getlen_HBCD2DASC,proc_getlen_DHBCD2DASC,	//5008,5009
//		proc_getlen_DASC2BCD,proc_getlen_DDASC2BCD,		//500a,500b
		proc_getlen_DASC2BIN,proc_getlen_DDASC2BIN,		//500a,500b
		proc_getlen_STR2ASC,							//500c
//		proc_getlen_BIN2DASC,proc_getlen_DBIN2DASC,
		proc_getlen_DASC2BCD,proc_getlen_DDASC2BCD,		//500d,500e
		proc_getlen_BIN2DASC,							//500f
	};
	const	COM_XXXTBL	proc_tbl_5_0_0={NM_TBL500_CNT,NM_TBL500,func_5_0_0};
	const	INST_LEN_PROC	func_5_0_1[NM_TBL501_CNT]={
//		proc_getlen_DDASC2BIN,
		proc_getlen_DBIN2DASC,
	};
	const	COM_XXXTBL	proc_tbl_5_0_1={NM_TBL501_CNT,NM_TBL501,func_5_0_1};
//GRYBIN
	const	INST_LEN_PROC	func_5_2_0[NM_TBL520_CNT]={
		proc_getlen_GRYBIN,proc_getlen_DGRYBIN,NULL,NULL,NULL,NULL,
		NULL,NULL,proc_getlen_BINGRY,proc_getlen_DBINGRY,
	};
	const	COM_XXXTBL	proc_tbl_5_2_0={NM_TBL520_CNT,NM_TBL520,func_5_2_0};
//NEG
	const	INST_LEN_PROC	func_5_3_0[NM_TBL530_CNT]={
		NULL,NULL,NULL,proc_getlen_NEG,proc_getlen_DNEG,
	};
	const	COM_XXXTBL	proc_tbl_5_3_0={NM_TBL530_CNT,NM_TBL530,func_5_3_0};
//DECO
	const	INST_LEN_PROC	func_5_8_0[NM_TBL580_CNT]={
		proc_getlen_DECO,proc_getlen_ENCO,NULL,NULL,
		NULL,NULL ,NULL			 ,NULL,
		NULL,NULL,proc_getlen_EXT,
	};
	const	COM_XXXTBL	proc_tbl_5_8_0={NM_TBL580_CNT,NM_TBL580,func_5_8_0};
//REF
	const	INST_LEN_PROC	func_5_8_4[NM_TBL584_CNT]={
		proc_getlen_REF,
	};
	const	COM_XXXTBL	proc_tbl_5_8_4={NM_TBL584_CNT,NM_TBL584,func_5_8_4};
//SEG
	const	INST_LEN_PROC	func_5_8_6[NM_TBL586_CNT]={
		proc_getlen_SEG,
	};
	const	COM_XXXTBL	proc_tbl_5_8_6={NM_TBL586_CNT,NM_TBL586,func_5_8_6};

	//----------------------------------------------------------------------
	//5-XTable
	const COM_XXTBL Numonic_Pointer5_0={2,&proc_tbl_5_0_0,&proc_tbl_5_0_1};
	const COM_XXTBL Numonic_Pointer5_2={1,&proc_tbl_5_2_0};
	const COM_XXTBL Numonic_Pointer5_3={1,&proc_tbl_5_3_0};
	const COM_XXTBL Numonic_Pointer5_8={
		7,
		&proc_tbl_5_8_0,NULL,NULL,NULL,&proc_tbl_5_8_4,
		NULL,&proc_tbl_5_8_6,
	};
	const COM_XTBL Numonic_Pointer5[16]={
		&Numonic_Pointer5_0 ,NULL				,&Numonic_Pointer5_2,
		&Numonic_Pointer5_3 ,NULL				,NULL				,
		NULL				,NULL				,&Numonic_Pointer5_8,
	};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//0x6000
//TCMP
	const	INST_LEN_PROC	func_6_0_0[NM_TBL600_CNT]={
		proc_getlen_TCMP,proc_getlen_TADD,proc_getlen_TSUB,proc_getlen_TRD,
		proc_getlen_TWR,proc_getlen_TOUR,proc_getlen_TZCP,
	};
	const	COM_XXXTBL	proc_tbl_6_0_0={NM_TBL600_CNT,NM_TBL600,func_6_0_0};
	//----------------------------------------------------------------------
	//6-XTable
	const COM_XXTBL Numonic_Pointer6_0={1,&proc_tbl_6_0_0,NULL};
	const COM_XTBL Numonic_Pointer6[16]={
		&Numonic_Pointer6_0,
	};
//0x7000
	const	INST_LEN_PROC	func_7_0_0[NM_TBL700_CNT]={
		proc_getlen_MTVDM,proc_getlen_MTPDM,proc_getlen_MTIDM,proc_getlen_MTMEC,
		proc_getlen_MTEMS,proc_getlen_MTCPP,proc_getlen_MTFOS,proc_getlen_MTSRS,
		proc_getlen_MTOBC,proc_getlen_MTOVV,proc_getlen_MTOVP,proc_getlen_MTIPT,
		proc_getlen_MTUAI,
	};
	const	COM_XXXTBL	proc_tbl_7_0_0={NM_TBL700_CNT,NM_TBL700,func_7_0_0};
	//----------------------------------------------------------------------
	//6-XTable
	const COM_XXTBL Numonic_Pointer7_0={1,&proc_tbl_7_0_0,NULL};
	const COM_XTBL Numonic_Pointer7[16]={
		&Numonic_Pointer7_0,
	};

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Code Table END
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	const COM_XTBL	*NumDaiBunrui[16]={
		Numonic_Pointer0,Numonic_Pointer1,Numonic_Pointer2,Numonic_Pointer3,
		Numonic_Pointer4,Numonic_Pointer5,Numonic_Pointer6,Numonic_Pointer7,
	};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


#else
	extern	const INST_PROC Numonic_Table[MAX_INSTRUCT_CODE];
	extern	const INST_DBG_PROC InstDebugDeviceTbl[MAX_INSTRUCT_CODE];

#endif

#endif			//Model Define
