void		MemorySizeDisp(int* iScreenNo);
