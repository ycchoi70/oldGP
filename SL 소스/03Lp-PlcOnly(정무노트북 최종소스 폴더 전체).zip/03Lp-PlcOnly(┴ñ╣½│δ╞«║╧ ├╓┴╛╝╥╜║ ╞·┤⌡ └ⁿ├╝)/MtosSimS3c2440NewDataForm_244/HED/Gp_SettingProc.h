int	RtcSetting(void);
