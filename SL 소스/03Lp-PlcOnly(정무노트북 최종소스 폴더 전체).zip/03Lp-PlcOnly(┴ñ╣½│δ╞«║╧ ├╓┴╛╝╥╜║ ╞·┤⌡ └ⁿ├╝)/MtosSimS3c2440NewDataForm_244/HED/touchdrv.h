#ifndef _DRV_TOUCH_H_
#define _DRV_TOUCH_H_

//===========================================================================

#define TOUCH_WIDTH             240
#define TOUCH_HEIGHT            320

//===========================================================================



#define TOUCH_SAMPLE_PREVIOUSDOWN       (1<<8)
#define TOUCH_SAMPLE_CALIBRATED         (1<<9)

#define TOUCH_SAMPLE_IGNORE             (1<<0)
#define TOUCH_SAMPLE_VALID              (1<<1)
#define TOUCH_SAMPLE_DOWN               (1<<2)

// for calibaration
#define     MAX_NCALIBRATION        (5)

// Scale factor to support sub-pixel resolutions
#define X_SCALE_FACTOR      4
#define Y_SCALE_FACTOR      4

#define TSP_LCDX					    (TOUCH_WIDTH * X_SCALE_FACTOR)
#define TSP_LCDY						(TOUCH_HEIGHT * Y_SCALE_FACTOR)

extern int    Xscr[MAX_NCALIBRATION];
extern int    Yscr[MAX_NCALIBRATION];

extern int    Xtch[MAX_NCALIBRATION];
extern int    Ytch[MAX_NCALIBRATION];


extern void   TouchInit( void );
extern void     HAL_TouchGetPoint( unsigned int* pfTipState, int *pUncalX, int *pUncalY);

extern int     TouchCalibration( int* pXscr, int* pYscr, int* pXtch, int* pYtch);
extern void     TouchCalibrate( int Xtch, int Ytch, int *pXscr, int *pYscr);

//extern HANDLE   DeviceRegisterTouchPanel( PDEVICECONFIG pDeviceConfigTouch, PBYTE pStack, UINT32 StackSize, UINT32 Priority);

#endif // _DRV_TOUCH_H_
