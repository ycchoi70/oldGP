
#define	NAND_BADMAP_PASS	"Autonics"

//2012.02.11 Flash Access Contorol
#define	FLASH_ERASE			0
#define	FLASH_WRITE_RANDOM	1
#define	FLASH_READ_RANDOM	2
#define	FLASH_WRITE_SEQ		3
#define	FLASH_READ_SEQ		4
#define	FLASH_READ_ECC		5

void	FlashEraze(char *addr, long count);
void	FlashWriteRandom(char *addr,char *data, long count);
void	FlashReadRandom(char *data,char *addr,long count);
void	FlashWriteSeq(char *addr,char *data, long count);
void	FlashReadSeq(char *data,char *addr,long count);

void	FlashRead_ECC(char *data,char *addr,long count);
void	NAND_Map_Check(void);
void	FlashControl(int cmd,char *addr,char *data, long count);
