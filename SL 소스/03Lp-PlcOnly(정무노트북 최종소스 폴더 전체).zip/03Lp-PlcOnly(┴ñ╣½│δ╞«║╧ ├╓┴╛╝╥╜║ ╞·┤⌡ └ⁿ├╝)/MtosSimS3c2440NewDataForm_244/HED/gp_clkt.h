void	SetClock_Func(int iDispOrder);
int	DrawClock_Func(int mode,_CLOCK_EVENT_TBL* ClockEventTbl,int iDispOrder);
void ClockDispWatch(int iOrder);
void CheckWeek(char* cWeek, int iWeek);
void CheckMonth(char* cMonth, int iMonth);
