/***********************************************************
  MMC�J�[�h�h���C�o(SPI���[�h)�w�b�_
  CQ Tech-I Vol. 35�p
     Original Version Interface 2006.3  �F�J����
     TECH-I   Version Interface 2006.9  ���c�h�v
 **********************************************************/

#ifndef _MMCDRV_
#define _MMCDRV_


#define Fld(Size, Shft)	(((Size) << 16) + (Shft))
#define UData(Data)	(Data)
#define FSize(Field)	((Field) >> 16)
#define FShft(Field)	((Field) & 0x0000FFFF)
#define FMsk(Field)	(((UData (1) << FSize (Field)) - 1) << FShft (Field))
#define FAlnMsk(Field)	((UData (1) << FSize (Field)) - 1)
#define FExtr(Data, Field)	((UData (Data) >> FShft (Field)) & FAlnMsk (Field))

/*
 * MMCD Commands
 */

/* class 1, basic commands */
#define	MMC_CMD0	0x40	/* bc, , , GO_IDLE_STATE */
#define MMC_CMD1	0x41	/* bcr, 31:0 OCR, R3, SEND_OP_COND */
#define MMC_CMD2	0x42	/* bcr, , R2, ALL_SEND_CID */
#define MMC_CMD3	0x43	/* ac, 31:16 RCA, R1, SET_RELATIVE_ADDR */
				/* bcr, , R6, SEBD_RELATIVE_ADDR, SD only */
#define MMC_CMD4	0x44	/* bc, 31:16 RCA, , SET_DSR */
#define MMC_CMD7	0x47	/* ac, 31:16 RCA, R1, SEELECT/DESELECT CARD */
#define MMC_CMD9	0x49	/* ac, 31:16 RCA, R2, SEND_CSD */
#define MMC_CMD10	0x4a	/* ac, 31:16 RCA, R2, SEND_CID */
#define MMC_CMD11	0x4b	/* adtc, 31:0 dadr, R1, READ_DAT_UNTIL_STOP */
				/* reserved, SD only */
#define MMC_CMD12	0x4c	/* ac, , R1b, STOP_TRANSMISSION */
#define MMC_CMD13	0x4d	/* ac, 31:16 RCA, R1, SEND_STATUS */
#define MMC_CMD15	0x4f	/* ac, 31:16 RCA, , GO_INACTIVE_SATE */

/* class 2, block oriented read commands */
#define MMC_CMD16	0x50	/* ac, 31:0 blk len, R1, SET_BLOCKLEN */
#define MMC_CMD17	0x51	/* adtc, 31:0 dadr, R1, READ_SINGLE_BLOCK */
#define MMC_CMD18	0x52	/* adtc, 31:0 dadr, R1, READ_MULTIPLE_BLOCK */

/* class 3 */
#define MMC_CMD20	0x54	/* adtc, 31:0 dadr, R1, WRITE_DAT_UNTIL_STOP */
				/* reserved, SD only */

/* class 4, block oriented write commands */
#define MMC_CMD24	0x58	/* adtc, 31:0 dadr, R1, WRITE_BLOCK */
#define MMC_CMD25	0x59	/* adtc, 31:0 dadr, R1, WRITE_MULTIPLE_BLOCK */
#define MMC_CMD26	0x5a	/* adtc, , R1, PROGRAM_CID */
#define MMC_CMD27	0x5b	/* adtc, , R1, PROGRAM_CSD */

/* class 6, block oriented write protection commands */
#define MMC_CMD28	0x5c	/* ac, 31:0 dadr, R1b, SET_WRITE_PROT */
#define MMC_CMD29	0x5d	/* ac, 31:0 dadr, R1b, CLR_WRITE_PROT */
#define MMC_CMD30	0x5e	/* adtc, 31:0 wadr, R1, SEND_WRITE_PROT */

/* class 5, erase commands */
#define MMC_CMD32	0x60	/* ac, 31:0 dadr, R1, TAG_SECTOR_START */
				/* ac, 31:0 dadr, R1, ERASE_WR_BLK_START, SD only */
#define MMC_CMD33	0x61	/* ac, 31:0 dadr, R1, TAG_SECTOR_END */
				/* ac, 31:0 dadr, R1, ERASE_WR_BLK_END, SD only */
#define MMC_CMD34	0x62	/* ac, 31:0 dadr, R1, UNTAG_SECTOR */
#define MMC_CMD35	0x63	/* ac, 31:0 dadr, R1, TAG_ERASE_GROUP_START */
#define MMC_CMD36	0x64	/* ac, 31:0 dadr, R1, TAG_ERASE_GROUP_END */
#define MMC_CMD37	0x65	/* ac, 31:0 dadr, R1, UNTAG_ERASE_GROUP */
				/* MMC_CMD34~MMC_CMD37 reserved, SD only */
#define MMC_CMD38	0x66	/* ac, , R1b, ERASE */

#define MMC_CMD41	0x69	/* adtc, , R1b, LOCK_UNLOCK */
/* class 7, lock card */
#define MMC_CMD42	0x6a	/* adtc, , R1b, LOCK_UNLOCK */

/* class 8, applicatin specific commands */
#define MMC_CMD55	0x77	/* ac, 31:16 RCA, R1, APP_CMD */
#define MMC_CMD56	0x78	/* adtc, 0 RD/WR, R1, GEN_CMD  */

#define MMC_CMD59	0x7b	/*   */
/* application specific commands used/reserved for SD Memory Card */
#define MMC_ACMD6	0x46	/* ac, 1:0 bus width, R1, SET_BUS_WIDTH */
#define MMC_ACMD13	0x4d	/* adtc, , R1, SD_STATUS  */
#define MMC_ACMD22	0x56	/* adtc, , R1, SEND_NUM_WR_BLOCKS */
#define MMC_ACMD23	0x57	/* ac, 22:0 blks, R1, SET_WR_BLK_ERASE_COUNT */
#define MMC_ACMD41	0x69	/* bcr, 31:0 OCR, R3, MMC_SEND_OP_COND */
#define MMC_ACMD42	0x6a	/* ac, 0 set_cd, R1, SET_CLR_CARD_DETECT */
#define MMC_ACMD51	0x73	/* adtc, , R1, SEND_SCR */

/* Command size */
#define MMC_CMD_SIZE	6

/* Command timings */
#define	MMC_TIME_NCR_MIN	2	/* min. of Number of cycles
					   between command and response */
#define MMC_TIME_NCR_MAX	64	/* max. of Number of cycles
					   between command and response */
#define MMC_TIME_NID_MIN	5	/* min. of Number of cycles
					   between card identification or
					   card operation conditions command
					   and the corresponding response */
#define MMC_TIME_NID_MAX	10	/* max. of Number of cycles
					   between card identification or
					   card operation conditions command
					   and the corresponding response */
#define MMC_TIME_NAC_MIN	2	/* min. of Number of cycles
					   between command and 
					   the start of a related data block */
#define MMC_TIME_NRC_MIN	8	/* min. of Number of cycles
					   between the last reponse and
					   a new command */
#define MMC_TIME_NCC_MIN	8	/* min. of Number of cycles
					   between two commands, if no reponse
					   will be send after the first command
					   (e.g. broadcast) */
#define MMC_TIME_NWR_MIN	2	/* min. of Number of cycles
					   between a write command and
					   the start of a related data block */

/* 
 * CID(Card IDentification) Register 
 */
typedef struct {
	unsigned char  mid;	/* Manufacturer ID */
	unsigned short oid;	/* OEM/Application ID */
	unsigned char  pnm[7];	/* Product Name + '\0', MMC only */
	unsigned char  prv;	/* Product Version */
	unsigned int psn;	/* Product Serial Number */
	unsigned char  mdt;	/* Manufacturing date, MMC only */

	/* SD only */
	unsigned char  pnm_sd[6]; /* Product Name + '\0', SD only */
	unsigned short mdt_sd;    /* Manufacturing date, SD only */
} CID_regs;

#define MMC_CID_SIZE	16

/* 
 * OCR (Operation Condition Register)
 */
typedef unsigned int OCR_regs;

#define MMC_OCR_SIZE	4

#define MMC_VDD_20_36	0x00ffff00	/* VDD voltage 2.0 ~ 3.6 */
#define MMC_VDD_27_36	0x00ff8000	/* VDD voltage 2.0 ~ 3.6 */
#define MMC_VDD_20_21	0x00000100	/* VDD voltage 2.0 ~ 2.1 */
#define MMC_VDD_21_22	0x00000200	/* VDD voltage 2.1 ~ 2.2 */
#define MMC_VDD_22_23	0x00000400	/* VDD voltage 2.2 ~ 2.3 */
#define MMC_VDD_23_24	0x00000800	/* VDD voltage 2.3 ~ 2.4 */
#define MMC_VDD_24_25	0x00001000	/* VDD voltage 2.4 ~ 2.5 */
#define MMC_VDD_25_26	0x00002000	/* VDD voltage 2.5 ~ 2.6 */
#define MMC_VDD_26_27	0x00004000	/* VDD voltage 2.6 ~ 2.7 */
#define MMC_VDD_27_28	0x00008000	/* VDD voltage 2.7 ~ 2.8 */
#define MMC_VDD_28_29	0x00010000	/* VDD voltage 2.8 ~ 2.9 */
#define MMC_VDD_29_30	0x00020000	/* VDD voltage 2.9 ~ 3.0 */
#define MMC_VDD_30_31	0x00040000	/* VDD voltage 3.0 ~ 3.1 */
#define MMC_VDD_31_32	0x00080000	/* VDD voltage 3.1 ~ 3.2 */
#define MMC_VDD_32_33	0x00100000	/* VDD voltage 3.2 ~ 3.3 */
#define MMC_VDD_33_34	0x00200000	/* VDD voltage 3.3 ~ 3.4 */
#define MMC_VDD_34_35	0x00400000	/* VDD voltage 3.4 ~ 3.5 */
#define MMC_VDD_35_36	0x00800000	/* VDD voltage 3.5 ~ 3.6 */
#define MMC_nCARD_BUSY	0x80000000	/* Card Power up status bit */

/* 
 * Relative Card Address 
 */
typedef unsigned short RCA_regs;

#define MMC_RCA_SIZE	2

/* 
 * CSD register, rwe == read/write/erase 
 */
typedef struct {
	unsigned char csd;		/* CSD structure */
	unsigned char spec_vers;		/* Spec version, MMC only */
	struct {
		unsigned char man;	/* time mantissa */
		unsigned char exp;	/* time exponent */
	} taac;			/* Data read access-time-1 */
	unsigned char nsac;		/* Data read access-time-2 in CLK cycle */
	struct {
		unsigned char man;	/* rate mantissa */
		unsigned char exp;	/* rate exponent */
	} tran_speed;		/* Max. data transfer rate */
	unsigned short ccc;		/* Card command classes */
	unsigned char read_len;		/* Max. read data block length */
	unsigned char read_part;		/* Partial blocks for read allowed */
	unsigned char write_mis;		/* write block misalignment */
	unsigned char read_mis;		/* read block misalignment */
	unsigned char dsr;		/* DSR implemented */
	unsigned short c_size;		/* Device size */
	unsigned char vcc_r_min;		/* Max. read current at Vcc min */
	unsigned char vcc_r_max;		/* Max. read current at Vcc max */
	unsigned char vcc_w_min;		/* Max. write current at Vcc min */
	unsigned char vcc_w_max;		/* Max. write current at Vcc max */
	unsigned char c_size_mult;	/* Device size multiplier */
	unsigned char er_size;		/* Erase sector size, MMC only */
	unsigned char er_grp_size;	/* Erase group size, MMC only */
	unsigned char wp_grp_size;	/* Write protect group size */
	unsigned char wp_grp_en;		/* Write protect group enable */
	unsigned char dflt_ecc;		/* Manufacturer default ECC, MMC only */
	unsigned char r2w_factor;	/* Write speed factor */
	unsigned char write_len;		/* Max. write data block length */
	unsigned char write_part;	/* Partial blocks for write allowed */
	unsigned char ffmt_grp;		/* File format group, rw */
	unsigned char copy;		/* Copy flag (OTP), rw */
	unsigned char perm_wp;		/* Permanent write protection, rw */
	unsigned char tmp_wp;		/* temporary write protection, rwe */
	unsigned char ffmt;		/* file format, rw */
	unsigned char ecc;		/* ECC, rwe, MMC only */

	/* SD only */
	unsigned char er_blk_en;		/* Erase single block enable, SD only */
	unsigned char er_sec_size;	/* Erase sector size, SD only */
} CSD_regs;

#define MMC_CSD_SIZE	16

#define CSD_VERSION_10	0
#define CSD_VERSION_11	1

#define MMC_PROT_10	0	/* MMC protocol version 1.0 - 1.2 */
#define MMC_PROT_14	1	/* MMC protocol version 1.4 */

#define TAAC_EXP_1NS	0	/* 1ns */
#define TAAC_EXP_10NS	1	/* 10ns */
#define TAAC_EXP_100NS	2	/* 100ns */
#define TAAC_EXP_1UMS	3	/* 1 u-ms */
#define TAAC_EXP_10UMS	4	/* 10 u-ms */
#define TAAC_EXP_100UMS	5	/* 100 u-ms */
#define TAAC_EXP_1MS	6	/* 1ms */
#define TAAC_EXP_10MS	7	/* 10ms */

#define TIME_MAN_NONE	0	/* reserved */
#define TIME_MAN_10	1	/* 1.0 */
#define TIME_MAN_12	2	/* 1.2 */
#define TIME_MAN_13	3	/* 1.3 */
#define TIME_MAN_15	4	/* 1.5 */
#define TIME_MAN_20	5	/* 2.0 */
#define TIME_MAN_25	6	/* 2.5 */
#define TIME_MAN_30	7	/* 3.0 */
#define TIME_MAN_35	8	/* 3.5 */
#define TIME_MAN_40	9	/* 4.0 */
#define TIME_MAN_45	A	/* 4.5 */
#define TIME_MAN_50	B	/* 5.0 */
#define TIME_MAN_55	C	/* 5.5 */
#define TIME_MAN_60	D	/* 6.0 */
#define TIME_MAN_70	E	/* 7.0 */
#define TIME_MAN_80	F	/* 8.0 */

#define TRAN_EXP_100K	0	/* 100kbit/s */
#define TRAN_EXP_1M	1	/* 1Mbit/s */
#define TRAN_EXP_10M	2	/* 10Mbit/s */
#define TRAN_EXP_100M	3	/* 100Mbit/s */

#define CCC_CLASS_0	0x001	/* Card Command Class 0 */
#define CCC_CLASS_1	0x002	/* Card Command Class 1 */
#define CCC_CLASS_2	0x004	/* Card Command Class 2 */
#define CCC_CLASS_3	0x008	/* Card Command Class 3 */
#define CCC_CLASS_4	0x010	/* Card Command Class 4 */
#define CCC_CLASS_5	0x020	/* Card Command Class 5 */
#define CCC_CLASS_6	0x040	/* Card Command Class 6 */
#define CCC_CLASS_7	0x080	/* Card Command Class 7 */
#define CCC_CLASS_8	0x100	/* Card Command Class 8 */
#define CCC_CLASS_9	0x200	/* Card Command Class 9 */
#define CCC_CLASS_10	0x400	/* Card Command Class 10 */
#define CCC_CLASS_11	0x800	/* Card Command Class 11 */

#define BLK_LEN_1	0	/* 2^0 = 1 byte */
#define BLK_LEN_2	1	/* 2^1 = 2 bytes */
#define BLK_LEN_4	2	/* 2^2 = 4 bytes */
#define BLK_LEN_8	3	/* 2^3 = 8 bytes */
#define BLK_LEN_16	4	/* 2^4 = 16 bytes */
#define BLK_LEN_32	5	/* 2^5 = 32 bytes */
#define BLK_LEN_64	6	/* 2^6 = 64 bytes */
#define BLK_LEN_128	7	/* 2^7 = 128 bytes */
#define BLK_LEN_256	8	/* 2^8 = 256 bytes */
#define BLK_LEN_512	9	/* 2^9 = 512 bytes */
#define BLK_LEN_1024	10	/* 2^10 = 1024 bytes */
#define BLK_LEN_2048	11	/* 2^11 = 2048 bytes */
#define MAX_MMC_BLK_LEN	2048

/*
	Memory Capacity = BLOCKNR * BLOCK_LEN
	where
	BLOCKNR = (C_SIZE + 1) * MULT
	MULT = 2^(c_size_mult+2) ( c_size_mult < 8)
	BLOCK_LEN = 2^read_len	( read_len < 12)
 */

#define VCC_MIN_05	0	/* 0.5mA */
#define VCC_MIN_1	1	/* 1mA */
#define VCC_MIN_5	2	/* 5mA */
#define VCC_MIN_10	3	/* 10mA */
#define VCC_MIN_25	4	/* 25mA */
#define VCC_MIN_35	5	/* 35mA */
#define VCC_MIN_60	6	/* 60mA */
#define VCC_MIN_100	7	/* 100mA */

#define VCC_MAX_1	0	/* 1mA */
#define VCC_MAX_5	1	/* 5mA */
#define VCC_MAX_10	2	/* 10mA */
#define VCC_MAX_25	3	/* 25mA */
#define VCC_MAX_35	4	/* 35mA */
#define VCC_MAX_45	5	/* 45mA */
#define VCC_MAX_80	6	/* 80mA */
#define VCC_MAX_200	7	/* 200mA */

				/* the typical block program time is */
#define R2W_FACTOR_1	0	/*   1 Multiples of Read Access Time */
#define R2W_FACTOR_2	1	/*   2 Multiples of Read Access Time */
#define R2W_FACTOR_4	2	/*   4 Multiples of Read Access Time */
#define R2W_FACTOR_8	3	/*   8 Multiples of Read Access Time */
#define R2W_FACTOR_16	4	/*  16 Multiples of Read Access Time */
#define R2W_FACTOR_32	5	/*  32 Multiples of Read Access Time */

#define ECC_NONE	0	/* none. Max.No.ofCorrectable bit/block=0 */
#define ECC_BCH		1	/* 542,512. Max.No.ofCorrectable bit/block=3 */

/* SD only */
/* 
 * SCR(SD CARD Configuration Register)
 */
typedef struct{
	unsigned char scr_version;	/* SCR version */
	unsigned char sd_spec_version;	/* physical layer spec version */
	unsigned char data_status;	/* data status after erase */
	unsigned char sd_security;	/* security protocol */
	unsigned char sd_bus_widths;	/* bus width */  
} SCR_regs;

#define MMC_SCR_SIZE	8

#define SCR_VERSION_10      0		/* SCR version 1.0 */
#define SPEC_VERSION_10     0		/* physical layer spec version 1.0 */
#define SECURITY_PROT_NONE  0		/* no security */
#define SECURITY_PROT_1     1		/* security protocol 1.0 */
#define SECURITY_PROT_2     2		/* security protocol 2.0 */
#define SD_BUS_WIDTH_1      0x01	/* 1 bit (DAT0) */
#define SD_BUS_WIDTH_4      0x04	/* 4 bits (DAT0-3) */

/*
 * R1 status: card status
 * Type
 *	e : error bit
 *	s : status bit
 *	r : detected and set for the actual command response
 *	x : detected and set during command execution. the host must poll
 *	    the card by sending status command in order to read these bits.
 * Clear condition
 *	a : according to the card state
 *	b : always related to the previous command. Reception of
 *	    a valid command will clear it (with a delay of one command)
 *	c : clear by read
 */
typedef unsigned int R1_status;
#define R1_out_of_range		0x80000000	/* er, c */
#define R1_address_err		0x40000000	/* erx, c */
#define R1_block_len_err	0x20000000	/* er, c */
#define R1_erase_seq_err	0x10000000	/* er, c */
#define R1_erase_param		0x08000000	/* ex, c */
#define R1_wp_violation		0x04000000	/* erx, c */
#define R1_card_is_locked	0x02000000	/* sx, a */
#define R1_lock_unlock_fail	0x01000000	/* erx, c */
#define R1_com_crc_err		0x00800000	/* er, b */
#define R1_illegal_command	0x00400000	/* er, b */
#define R1_ecc_fail		0x00200000	/* ex, c */
#define R1_cc_err		0x00100000	/* erx, c */
#define R1_err			0x00080000	/* erx, c */
#define R1_underrun		0x00040000	/* ex, c */
#define R1_overrun		0x00020000	/* ex, c */
#define R1_overwrite		0x00010000	/* erx, c, CID/CSD overwrite */
#define R1_wp_erase_skip	0x00008000	/* sx, c */
#define R1_ecc_disable		0x00004000	/* sx, a */
#define R1_erase_reset		0x00002000	/* sr, c */
#define R1_state		0x00001E00	/* sx, b */
#define R1_buf_empty		0x00000100	/* sx, a */
#define R1_app_cmd		0x00000020	/* sr, c */
#define R1_ERR			0xFDFF0000	/* R1 error mask */

/* SD only */
#define R1_ake_seq_err		0x00000008	/* sr, c */

/* card state flags of R1 */
#define STATE_IDLE	0x00000000	/* 0 */
#define STATE_READY	0x00000200	/* 1 */
#define STATE_IDENT	0x00000400	/* 2 */
#define STATE_STBY	0x00000600	/* 3 */
#define STATE_TRAN	0x00000800	/* 4 */
#define STATE_DATA	0x00000A00	/* 5 */
#define STATE_RCV	0x00000C00	/* 6 */
#define STATE_PRG	0x00000E00	/* 7 */
#define STATE_DIS	0x00001000	/* 8 */

/* SD only */
/* 
 * R6 status: RCA and a part of card status
 */
typedef struct{
	unsigned short rca;             /* RCA */
	unsigned short card_status;     /* card status bits[23,22,19,12:0] */
} R6_status;


/* flags for stat field of the mmc_slot structure */
#define MMC_WP_GRP_EN		0x00000010
#define MMC_PERM_WP		0x00000020
#define MMC_TMP_WP		0x00000040
#define MMC_READ_PART		0x00000100
#define MMC_WRITE_PART		0x00000200

/*
 * MMC/SD Clock rates
 */
#define MMC_MMC_CLOCK_HIGH		20000000
#define MMC_MMC_CLOCK_LOW		400000
#define MMC_SD_CLOCK_HIGH		25000000
#define MMC_SD_CLOCK_LOW		MMC_MMC_CLOCK_LOW

/*
 * MMC command/response structure
 */

/* MMC Response type */
enum {
	MMC_RES_TYPE_NONE = 0,
	MMC_RES_TYPE_R1,
	MMC_RES_TYPE_R1B,
	MMC_RES_TYPE_R2,
	MMC_RES_TYPE_R3,
	MMC_RES_TYPE_R4,
	MMC_RES_TYPE_R5,
	MMC_RES_TYPE_R6,
};

/* MMC Response length */
#define MMC_RES_LEN_SHORT		6
#define MMC_RES_LEN_LONG		17

/* MMC Response flag */
#define MMC_RES_FLAG_DATALINE		0x01 /* transferred on dataline */
#define MMC_RES_FLAG_NOCRC		0x02 /* no crc check */
#define MMC_RES_FLAG_RDATA		0x04 /* data read */
#define MMC_RES_FLAG_WDATA		0x08 /* data write */

/* MMC Command request type */
struct mmc_cmd {
	unsigned char cmd; /* command */
	unsigned int arg; /* command argument */
	unsigned char res_type; /* response type */
	unsigned char res_flag; /* response flag */
	unsigned char res[MMC_RES_LEN_LONG]; /* response buffer */
	unsigned char *data; /* pointer to data buffer */
	unsigned int data_len; /* data length */
	unsigned int t_res; /* timing between command and response */
	unsigned int t_fin; /* timing after response */
};

#define SDICON_MMC	(1 << 5)	/* MMC Type */
#define SDICON_BYTE	(1 << 4)	/* Byte Order Type */
#define SDICON_LE	(0 << 4)	/* D[7:0],D[15:8],D[23:16],D[31:24] */
#define SDICON_BE	(1 << 4)	/* D[31:24],D[23:16],D[15:8],D[7:0] */
#define SDICON_INT	(1 << 3)	/* Receive SDIO INterrupt from card */
#define SDICON_RWE	(1 << 2)	/* Read Wait Enable */
#if defined(CONFIG_BOARD_LN2440SBC) || defined(CONFIG_BOARD_LN2410SBC)/* Not available in LN2440SBC/LN2410SBC and LN24A0SBC - from manual */
#define SDICON_FRESET	(1 << 1)	/* FIFO Reset */
#endif
#define SDICON_ENCLK	(1 << 0)	/* Clock Out Enable */

#define SDIPRE_MSK	(0xff)		/* Baud rate = PCLK/2/(value + 1) */

#define SDICCON_ABORT	(1 << 12)	/* Command type: Abort(CMD12,CMD52) */
#define SDICCON_DATA	(1 << 11)	/* Command type: with Data */
#define SDICCON_LRSP	(1 << 10)	/* Response is 136-bit long */
#define SDICCON_WRSP	(1 << 9)	/* Wait for Response */
#define SDICCON_START	(1 << 8)	/* 0: cmd ready, 1: cmd start */
#define SDICCON_CMD_MSK	(0xff)		/* with start 2bit */

#define SDICSTA_CRC	(1 << 12)	/* CRC error */
#define SDICSTA_SENT	(1 << 11)	/* Command sent */
#define SDICSTA_TOUT	(1 << 10)	/* Command Timeout */
#define SDICSTA_RSP	(1 << 9)	/* Command Response received */
#define SDICSTA_BUSY	(1 << 8)	/* Command transfer in progress */
#define SDICSTA_ALLFLAG	(0x1f00)	/* All flags mask */
#define SDICSTA_RSP_MSK	(0xff)		/* with start 2bit */
#define SDICSTA_ERR	(0x1400)	/* CRC, TOUT */

#define SDIRSP1_CRC7	FExtr(SDIRSP1, Fld(8,24))

#define SDIDCON_DATA_SIZE_WORD (2 << 22)	/* SDIO Interrupt period is ... */

#define SDIDCON_PRD	(1 << 21)	/* SDIO Interrupt period is ... */
				/* when last data block is transferred. */
#define SDIDCON_PRD_2	(0 << 21)	/* 0: exact 2 cycle */
#define SDIDCON_PRD_N	(1 << 21)	/* 1: more cycle */
#define SDIDCON_TARSP	(1 << 20)	/* when data transmit start ... */
#define SDIDCON_TARSP_0	(0 << 20)	/* 0: directly after DatMode set */
#define SDIDCON_TARSP_1	(1 << 20)	/* 1: after response receive */
#define SDIDCON_RACMD	(1 << 19)	/* when data receive start ... */
#define SDIDCON_RACMD_0	(0 << 19)	/* 0: directly after DatMode set */
#define SDIDCON_RACMD_1	(1 << 19)	/* 1: after command sent */
#define SDIDCON_BACMD	(1 << 18)	/* when busy receive start ... */
#define SDIDCON_BACMD_0	(0 << 18)	/* 0: directly after DatMode set */
#define SDIDCON_BACMD_1	(1 << 18)	/* 1: after command sent */
#define SDIDCON_BLK	(1 << 17)	/* transfer mode. 0:stream, 1:block */
#define SDIDCON_WIDE	(1 << 16)	/* Enable Wide bus mode */
#define SDIDCON_DMA	(1 << 15)	/* Enable DMA */
#define SDIDCON_DATA_START	(1 << 14)	/* 24x0a data transfer start */
#define SDIDCON_DATA_MODE_Rx (2 << 12)	/* which direction of data transfer */
#define SDIDCON_DATA_MODE_Tx (3 << 12)	/* which direction of data transfer */
#define SDIDCON_DATA_STOP ~(7 << 12)	/* which direction of data transfer */
#define fSDIDCON_DatMode Fld(2,12)	/* which direction of data transfer */
#define SDIDCON_READY	FInsrt(0x0, fSDIDCON_DatMode)	/* ready */
#define SDIDCON_BUSY	FInsrt(0x1, fSDIDCON_DatMode)	/* only busy check */
#define SDIDCON_RX	FInsrt(0x2, fSDIDCON_DatMode)	/* Data receive */
#define SDIDCON_TX	FInsrt(0x3, fSDIDCON_DatMode)	/* Data transmit */
#define SDIDCON_BNUM	FMsk(Fld(12,0))	/* Block Number(0~4095) */

#define SDIDCNT_CNT(x)	FExtr((x), Fld(12,12))	/* Remaining Blk No. */
#define SDIDCNT_SIZE(x)	FExtr((x), Fld(12,0))	/* Remaining byte of 1 block */

#define SDIDSTA_RWQ	(1 << 10)	/* Read wait request occur */
#define SDIDSTA_INT	(1 << 9)	/* SDIO interrupt detect */
#if defined(CONFIG_BOARD_LN2440SBC) || defined(CONFIG_BOARD_LN2410SBC)/* reserved in LN2440SBC/LN2410SBC and LN24A0SBC */
#define SDIDSTA_EFIFO	(1 << 8)	/* FIFO fail */
#endif
#define SDIDSTA_ETCRC	(1 << 7)	/* Block sent(CRC status error) */
#define SDIDSTA_ERCRC	(1 << 6)	/* Block received(CRC error) */
#define SDIDSTA_TOUT	(1 << 5)	/* Data/Busy receive timeout */
#define SDIDSTA_DFIN	(1 << 4)	/* Data transfer complete */
#define SDIDSTA_BFIN	(1 << 3)	/* Only busy check is finished */
#if defined(CONFIG_BOARD_LN2440SBC) || defined(CONFIG_BOARD_LN2410SBC)/* reserved in LN2440SBC/LN2410SBC and LN24A0SBC */
#define SDIDSTA_SBIT	(1 << 2)	/* Start bit is not detected */
#endif
#define SDIDSTA_TX	(1 << 1)	/* data Tx in progress */
#define SDIDSTA_RX	(1 << 0)	/* data Rx in progress */
#if defined(CONFIG_BOARD_LN2440SBC) || defined(CONFIG_BOARD_LN2410SBC)/* reserved in LN2440SBC/LN2410SBC and LN24A0SBC */
#define SDIDSTA_ERR	(0x1e4)		/* EFIFO, ETCRC, ERCRC, TOUT, SBIT */
#else
#define SDIDSTA_ERR	(0xe)		/* ETCRC, ERCRC, TOUT */
#endif
#define fSDIDSTA_ALL	Fld(11, 0)
#define SDIDSTA_ALL	FMsk(fSDIDSTA_ALL)

#define SDIFSTA_TX	(1 << 13)	/* 0: FIFO is full, 1: FIFO ready */
#define SDIFSTA_RX	(1 << 12)	/* 0: FIFO empty, 1: Data in FIFO */
#define SDIFSTA_TX_HALF	(1 << 11)	/* Data in FIFO are 0:33~64, 1:0~32 */
#define SDIFSTA_TX_EMP	(1 << 10)	/* FIFO is empty */
#define SDIFSTA_RX_LAST	(1 << 9)	/* Last Data ready in FIFO */
#define SDIFSTA_RX_FULL	(1 << 8)	/* FIFO is full */
#define SDIFSTA_FIFO_RESET (1 << 16)	/* FIFO is full */
#define SDIFSTA_RX_HALF	(1 << 7)	/* Data in FIFO are 0:0~31, 1:32~64 */
#define SDIFSTA_CNT	(0x7f)		/* Number of data in FIFO */
#define SDIFSTA_LAST_RX	0x200  		/* 24x0a rx last clear */

#define SDIIMSK_NOBUSY  (1 << 18)       /* No busy Interrupt */
#define SDIIMSK_RCRC	(1 << 17)	/* Response CRC error */
#define SDIIMSK_CSENT	(1 << 16)	/* Command Sent */
#define SDIIMSK_CTOUT	(1 << 15)	/* Command Response Timeout */
#define SDIIMSK_CRSP	(1 << 14)	/* Command Response received */
#define SDIIMSK_RWAIT	(1 << 13)	/* Read Wait Request */
#define SDIIMSK_CARD	(1 << 12)	/* SDIO Interrupt from card */
#define SDIIMSK_EFIFO	(1 << 11)	/* FIFO fail error */
#define SDIIMSK_ETCRC	(1 << 10)	/* CRC status error */
#define SDIIMSK_ERCRC	(1 << 9)	/* Data CRC fail */
#define SDIIMSK_TOUT	(1 << 8)	/* Data Timeout */
#define SDIIMSK_DFIN	(1 << 7)	/* Data transfer complete (cnt = 0) */
#define SDIIMSK_BFIN	(1 << 6)	/* Busy check complete */
#define SDIIMSK_SBIT	(1 << 5)	/* Start bit Error */
#define SDIIMSK_TX_HALF	(1 << 4)	/* Tx FIFO half */
#define SDIIMSK_TX_EMP	(1 << 3)	/* Tx FIFO empty */
#define SDIIMSK_RX_LAST	(1 << 2)	/* Rx FIFO has last data */
#define SDIIMSK_RX_FULL	(1 << 1)	/* Rx FIFO full */
#define SDIIMSK_RX_HALF	(1 << 0)	/* Rx FIFO half */
#define SDIIMSK_ALL	(0x3ffff)

#define SDI_MAX_TX_FIFO	64
#define SDI_MAX_RX_FIFO	64


#define HCLK4_HALF              (1 << 9) /* S3C2440A */ 
#define HCLK3_HALF              (1 << 8) /* S3C2440A */ 

/* Clock and Power Management */
#define CLK_CTL_BASE		0x4C000000
#define bCLKCTL(Nb)		(CLK_CTL_BASE + (Nb))
/* Offset */
#define oLOCKTIME		0x00	/* R/W, PLL lock time count register */
#define oMPLLCON		0x04	/* R/W, MPLL configuration register */
#define oUPLLCON		0x08	/* R/W, UPLL configuration register */
#define oCLKCON			0x0C	/* R/W, Clock generator control reg. */
#define oCLKSLOW		0x10	/* R/W, Slow clock control register */
#define oCLKDIVN		0x14	/* R/W, Clock divider control */
#define oCAMDIVN                0x18    /* R/W, Camera clock divider  */
#define CAMDIVN                 bCLKCTL(oCAMDIVN)
/* Registers */
#define LOCKTIME		bCLKCTL(oLOCKTIME)
#define MPLLCON			bCLKCTL(oMPLLCON)
#define UPLLCON			bCLKCTL(oUPLLCON)
#define CLKCON			bCLKCTL(oCLKCON)
#define CLKSLOW			bCLKCTL(oCLKSLOW)
#define CLKDIVN			bCLKCTL(oCLKDIVN)

/* Fields */
#define fPLL_MDIV		Fld(8,12)
#define fPLL_PDIV		Fld(6,4)
#define fPLL_SDIV		Fld(2,0)


#define GET_PCLK	0
#define GET_HCLK	1

#define GET_UCLK    2   	// ++ laputa for usb clock output check & clock value return 031027
#define GET_UPLL    3		// ++ laputa for  usb clock pll setting value return  031027

//CLOCK SLOW CONTROL REGISTER ITEM 
//it's turn off the M/UPLL for power management 
#define	UCLK_OFF 		(1<<7)    // 0:UCLK ON : ISERTED AUTOMATICALLY, 1: UCLK OFF
#define MPLL_OFF 		(1<<5)	   // 0:PLL TURN ON 1:PLL IS TURN OFF
#define SLOW_BIT 		(1<<4)    // 0:FCLK=MPLL 1:SLOW MODE

/* Clock Divider Control Bit Field*/
#define DIVN_UPLL            	(1<<3)   
#define HDIVN_MASK		(3<<1)
#define PDIVN_MASK              (1) 

#define GET_MDIV(x)	FExtr(x, fPLL_MDIV)
#define GET_PDIV(x)	FExtr(x, fPLL_PDIV)
#define GET_SDIV(x)	FExtr(x, fPLL_SDIV)

#define INICLK  400000
#define MMCCLK  16800000


#define MMC_TIMEOUT_ERROR       (-1)
#define MMC_LBA_RANGE_ERROR     (-2)
#define MMC_INIT_ERROR          (-3)
#define MMC_DEVICE_ERROR        (-4)
#define MMC_IO_ERROR			(-5)

#define MMC_CARD_DECTECT_ERROR  (-6)
#define MMC_WRITE_PROTECT_ERROR (-7)

#define cpu_to_be32(x) (x)

#define MMC_RETRIES_MAX		20
#define MMC_RETRIES_SD_CHECK	2

#endif


#ifdef	MMCDRV_PROC
	int	MmcSdConnected;
#else
	extern	int	MmcSdConnected;
#endif


void	MmcSdDrv( void );
void MMC_CardInit(void);
int	MMC_ReadSector(int sect,unsigned char* buff,int size);
int	MMC_WriteSector(int sect,unsigned char* buff,int size);
int	MMC_SetBlkLen(void);
int	MmcSdConnectProc(void);
