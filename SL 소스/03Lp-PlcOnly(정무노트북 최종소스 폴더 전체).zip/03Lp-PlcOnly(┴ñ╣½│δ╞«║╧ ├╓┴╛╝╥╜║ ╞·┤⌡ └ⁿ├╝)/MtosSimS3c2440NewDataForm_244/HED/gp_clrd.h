void		vClearData(int* iScreenNo);
void		vClearGPData(int* iScreenNo);
void	CenterDisplay(int sX, int sY, int eX, int eY,char* strData);
