
#define	LP_FILE_CHECK	".GLP.PROJ.FILE."
#ifdef	GP_FILECONTROL_PROC
	char cData[50000];
	int iReadbytes, iWrittenbytes;

	//line comment
	char cLComTemp[10], cHexaCode[2];			
	char cLineComment[256];

	#ifdef	WIN32
		FILE *fstreamRead, *fstreamPrj, *fstreamPlc, *fstreamParam, *fstreamLCom, *fstreamRCom, *fstreamLebel, *fstreamVar;
	#else
		int	fstreamRead, fstreamPrj, fstreamPlc, fstreamParam, fstreamLCom, fstreamRCom, fstreamLebel, fstreamVar;
	#endif
	unsigned long dwPLCStartPos, dwPLCEndPos; 
	unsigned long dwParamStartPos, dwParamEndPos; 
	unsigned long dwLComStartPos, dwLComEndPos; 
	unsigned long dwRComStartPos, dwRComEndPos; 
	unsigned long dwLabelStartPos, dwLabelEndPos; 
	unsigned long dwVarStartPos, dwVarEndPos; 
#else
#endif

void GetInitSysFileName(int dev,int idx);
int GetSysFileName(int no,char *buff,int idx,int* select,int *attr,char* uni_name);
int	SetSelectNo(int no,int idx);
void	FileCopySrc2Obj(int src,int obj);
void	DeleteFileProc(int idx);
int	SetNextPage(int idx);
int	SetBefortPage(int idx);
int	ChangeDirProc(int idx);
int	GetGlpDataFile(char* pfilename,char* ofilename,int UniFlag);
//void	fCtlDevClear(int dev1,int dev2);
int	GetGlpDataFileProc(int idx,int obj);
void	WorkFileCopy(int mode);
int	isUsbConnect(void);
int	GetGlpDataFileInstall(int idx);
int	Gp_ConfirmOkNg(int mode,int sx,int sy);
int	setDriveName(int idx,char* fileName);
int makeLpFile(char* cPrjPath,char* sspName,int UniFlag);
void	ClearDirectry(int drv);

int ReadFromSSPFileDumy(unsigned int uReadBytes);
int ReadFromSSPFile(unsigned int uNewStartPos, unsigned int uReadBytes);
int WriteToMnemonicFile(char* cPrjPath);
int WriteToParamFile(char* cPrjPath);
int WriteToVariableFile(char* cPrjPath);
int WriteToLabelFile(char* cPrjPath);
int	GetDevice(int idx);
void	RedispLogList(void);
