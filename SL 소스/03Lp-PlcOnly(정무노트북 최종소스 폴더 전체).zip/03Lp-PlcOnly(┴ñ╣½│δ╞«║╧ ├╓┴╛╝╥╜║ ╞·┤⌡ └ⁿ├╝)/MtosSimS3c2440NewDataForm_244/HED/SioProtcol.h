
#ifdef	SIOPROTOCOL_PROC
#ifdef	WIN32
	extern	int		simspeed[2];
	extern	int		simdata[2];
	extern	int		simparity[2];
	extern	int		simstop[2];		//2009.09.04
	extern	int		SioPCMode;
	extern	int		SioPLCMode;
	extern	int		SioPCOpenFlag;
	extern	int		SioPLCOpenFlag;
#endif
	int		UnvPlcRecCnt;
	int		UnvPlcRecCmd;
	int	ConnectMode;
	char DebugPass[13]= {
		0x04,'a','u','t','o','n','i','c','s','h','m','i',CR
//		0x04,'a',CR
	};
#else
#endif

int	ConnectPcBarcode(unsigned char rs_input_data,unsigned char *SioRecBuff,int *SioRecCnt);
int PCDownThrue(unsigned char data,int *CommMode,int *SioRecCnt,unsigned char *SioRecBuff,int *CommCnt,int CommKind);
int	RxCommProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff);
int	CheckDebugMode(unsigned char rs_input_data,UART_STRUCT* _SciTbl);
void	ReciveTimeOverCheck(UART_STRUCT* _SciTbl);
int	ConnectPc(unsigned char rs_input_data,UART_STRUCT* _SciTbl,int* CommRecKind);
void	SetEditorBoadrate( int connect, int set_ch );
void	SetRsPortPriority(int ch,int kind);
void	Rs232cBordrateSet( void );
void	RsModeSetChanel(int Kind,int ch,_SERIALPARAM* pParam);		//2009.09.04
void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
void	RtsOnOffSet(int type,int mode);
