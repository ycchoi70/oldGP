#ifdef	PLCHAND_PROC
	#ifdef	WIN32
		extern	int		SioPLCMode;
		extern	int		SioPCMode;
		extern	int		SioPCOpenFlag;
		extern	int		SioPLCOpenFlag;
	#endif
	extern	int	K3P_SereaseByteCnt;
	extern	DEV_PC_TBL	K3P_SereaseByte[32];
	extern	unsigned char IndexTable[256];
	extern	int	K3P_SereaseWordCnt;
	extern	DEV_PC_TBL	K3P_SereaseWord[32];

	extern	int U_LowHighFlag;				/* 0:L-H,1:H-L */
	extern	int	U_K3P_SereaseByteCnt;
	extern	DEV_PC_TBL	U_K3P_SereaseByte[32];
	extern	unsigned char U_IndexTable[256];
	extern	int	U_K3P_SereaseWordCnt;
	extern	DEV_PC_TBL	U_K3P_SereaseWord[32];

// 2012.02.24 add
	extern	int	InternalByteCnt;
	extern	DEV_PC_TBL	InternalByte[32];
	extern	unsigned char Internal_IndexTable[256];
	extern	int	InternalWordCnt;
	extern	DEV_PC_TBL	InternalWord[32];
	extern	unsigned char	IntartnalDevIndex[256];

	const	struct{
		int	sadd;		//�w��A�h���X���P�O�O�O�Ŋ������l�iUW�j
		int	oadd;		//���ۂ̃A�h���XUW[NNNN}
	}ChgUWTbl[66]={
		{ 0,    0},{ 1, 1000},{ 2, 2000},{ 3, 3000},{ 4, 4000},
		{ 5, 5000},{ 6, 6000},{ 7, 7000},{ 8, 7300},{ 9,   -1},
		{10, 7600},{11, 7700},{12,   -1},{13, 8000},{14,   -1},
		{15, 8300},{16, 8400},{17,   -1},{18, 8700},{19,   -1},
		{20, 9000},{21,10000},{22,11000},{23,12000},{24,13000},
		{25,14000},{26,15000},{27,16000},{28,17000},{29,18000},
		{30,   -1},{31,   -1},{32,   -1},{33,   -1},{34,   -1},
		{35,   -1},{36,19500},{37,   -1},{38,20000},{39,   -1},
		{40,21000},{41,22000},{42,23000},{43,24000},{44,25000},
		{45,26000},{46,27000},{47,28000},{48,29000},{49,30000},
		{50,   -1},{51,   -1},{52,   -1},{53,   -1},{54,   -1},
		{55,   -1},{56,   -1},{57,   -1},{58,   -1},{59,   -1},
		{60,31000},{61,32000},{62,   -1},{63,   -1},{64,   -1},
		{65,   -1},
	};

//	const	struct{
//		int	sadd;
//		int	eadd;
//	}ChkUWTbl[66]={
//		{   0,    14},{   15,    29},{   30,  1999},{ 2000,  5999},{6000, 6355},
//		{6400,  6655},{ 6700,  6955},{ 7000,  7255},{ 7300,  7555},{7600, 7615},
//		{7700,  7955},{ 8000,  8255},{ 8300,  8315},{ 8400,  8655},{8700, 8955},
//		{9000, 18999},{19500, 19755},{20000, 20999},{21000, 30999},
//	};
	unsigned int sync_time;		/* 20061025ksc */
	int	PlcFreeMbx;
#else
	extern	unsigned int sync_time;		/* 20061025ksc */

#endif

void	PLCSendProc(T_MAIL *mp);
void	PCSendProc(T_MAIL *mp);
int	SendPLC2PCData( int mode,int cnt,char *buff,int TimeOut );
int	SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut );
int	SendPC2PLCData2( int mode,int cnt,char *buff,int TimeOut );
int	PLCRead(int Chanel,int Pole,DEV_DATA *DevInfo);
int	PLCWrite(int Chanel,int Pole,DEV_DATA *DevInfo);
void	PLCWriteNoWait(int Chanel,int Pole,DEV_DATA *DevInfo);
int	GetDevName(int ch,int bFlag,char src,char *obj,int *DevInfo);
int		Device2Index(int ch,int bwflag,char *Name);
int		ElsCheckPLC_Addr(int ch,int bwflag,char *DevName,unsigned int *Address1,unsigned int *Address2,unsigned char DevCode);
int		CheckPlcDevice(int ch,int bwflag,char *Name,int *Address1,int *Address2,unsigned char DevCode);
int	PlcGroopSend1Pole( int ch, int pnum, int Comm );
int	PlcGroopSend( int Comm );
int	SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut);
int	SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut);
int		SendThruePLC(int mode,int cnt,char *sBuff,int TimeOut);
int	PlcControl( T_MAIL *mp );
/* 20081003 */
int	SendPLCPCData( void );
int	MakeGroupDev( int ch );
int	RecGroupDev( int ch );
void	SendPLCGroup(void);
int	PlcConnectProc( int pole );
int	UniMakeAddr(char *Name,int Addr,int bFlag);
int	UniCommRead(T_MAIL *mp);
int	UniCommWrite(T_MAIL *mp);
void	PlcDevInit( void );
void	ChangeAddressPLC16(int Digit1,int Digit0, int *Address);
int	SendPLC2RW(int mode,DEV_DATA *DevInfo,int ch);
int	SendPlcType2Write( int ch,int *StartAddr );
void	SendPlcType1Write( void );
void	ReadDevDataProc(int ch,int pnum,int i,DEV_DATA* pDeviceDataSys);
void	PlcDevInitRead( int mode );
void	IndevRead(T_MAIL *mp);
void	IndevWrite(T_MAIL *mp);
int	GetDevAddInf(int ch,int bwflag,unsigned char src,int *Keta,int *LowMax);
void	ChangeAddressPLC(int Digit1,int Digit0,int *Address,int LowMax,int Keta);
int	GetDevNamePLCAddr(int ch,int bFlag,unsigned char src,char *obj,int *DevInfo,int *Address);
int	GetLowAddressPLC(int Digit0,int Address,int Keta);
int	CheckDevNamePLCAddr(int ch,int bFlag,unsigned char src,char *obj,int *DevInfo,int Address);
void	ChangeAddressUsr(int Digit1,int Digit0, int *Address,int LowMax,int Keta);
int	SetPLCUsrAddr(int ch,int DevInfo,int Address,unsigned char idx,int bFlag);
//int	GetDevCntTime(int bwFlag,char *src, char *obj);
int	GetSendRecTimePlc1(void);
int	GetSendRecTimePlc2(void);
void	PlcHand( STTFrm* pSTT );
void	PlcState( STTFrm* pSTT );
void	Plc2State( STTFrm* pSTT );
void	PlcConnChk( STTFrm* pSTT );
void	IndevWriteProc(T_MAIL *mp);
void	IndevReadProc(T_MAIL *mp);
int	ChangeUWAddr(int bit_word,unsigned long* address);
int	CheckPlc2Connect(void);
int	IsPlc1Protocol(void);
int	IsPlc2Protocol(void);
int	GetMsSel(void);
void	GetPlc2Ver(char* chDsp_Ver);
void	LinkDevReadEntry(void);
int	IsInDevice(unsigned char devCode);
int	CheckPlc1Connect(void);
void	LinkDevCheck(void);

