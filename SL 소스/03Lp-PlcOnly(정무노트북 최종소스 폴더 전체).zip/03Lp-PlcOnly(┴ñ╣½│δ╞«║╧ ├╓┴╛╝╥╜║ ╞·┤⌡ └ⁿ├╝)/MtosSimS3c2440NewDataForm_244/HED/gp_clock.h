void		vClockSet(int* iScreenNo);
int iMaxCheck(int iFocusFlag, int iValue);
int DataChecking(RTC_DATA *SetData);
int		iLeapYear(int year);
int		iNowWeek(RTC_DATA *STime);
void	DefaultClockSet(void);
