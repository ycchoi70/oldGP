/* PLCTYPE_CH2������ ����ϴ� �Լ� �� */
/* ���� �������� �ҽ� �� */
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* APL���� ���������� ȣ���ϴ� �Լ� - �ùķ��̼��϶��� ���, �����δ� �� �Լ��� ASM���� �ۼ��Ǿ� ���� */ 



#ifdef	SH_CPU
#ifdef	WIN32
#define	APL_HOOK 1	
#endif
#endif

/* ARM���� ��ü ����� �Ҷ�, define�� TEST_PROT�� ��� */
/* ���������� ICE�� ������ ���� �ٿ�δ��� ���������� �ּҿ� ���� �����Ƿ� ���α׷��� �������� ������ ������ �����ϵ��� �����ϱ� ���� ���� */ 
/* Win32 �ùķ��̼ǽÿ��� ramproc.cpp�� ����ؼ� ���� */


#ifdef	ARM_CPU
//#ifdef	TEST_PROT
//#ifndef	WIN32
#define	APL_HOOK 1
//#endif
#endif


#ifdef	APL_HOOK		
/********************************************/
/*	�����֐�								*/
/********************************************/

#ifdef	PLCTYPE_CH1

	int	PLC_CONNECT(int *PlcType,int iConnect)
	{
		return(C_Connection(PlcType,iConnect));
	}
	int	GET_PLC_NAME(int bFlag,unsigned char src,char *obj,int *DevInfo)
	{
		return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
	}
	int	PLC1CHAR_READ(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
	{
		return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
	}
	int	PLC_DEV_READ(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
	{
		return(C_PLCCommRead(mp,rDataFx,PlcType));
	}
	int	PLC_DEV_WRITE(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
	{
		return(C_PLCCommWrite(mp,rDataFx,PlcType));
	}
	int	PLCPCDOWN(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
	{
		return(C_PLCPCDownThrue(data,CommMode,RecCnt,RecBuff));
	}
	int	GET_PLC_MAX(int bFlag,int idx)
	{
		return(C_GetDevMaxPLC(bFlag,idx));
	}
	int	GET_PLC_MIN(int bFlag,int idx)
	{
		return(C_GetDevMinPLC(bFlag,idx));
	}
	int		DEVICE_2_INDEX(int bwflag,char *Name)
	{
		return(C_Device2IndexPLC(bwflag,Name));
	}
	int		CHECK_PLC_ADDR(int bwflag,char *Name,int *Address1,int *plctype)
	{
		return(C_CheckPLC_Addr(bwflag,Name,Address1,plctype));
	}
	/* 20070206 */
	void	GET_MON_BAUDRATE(int *Speed,int *DataBit,int *Parity)
	{
		C_GetMonBaudrate(Speed,DataBit,Parity);
	}
	int	GET_SEND_REC_TIME(void)
	{
		return(C_GetSendRecTime());
	}
	void	GET_PLC1_VER(char *Name)
	{
		C_Get_Plc_Ver(Name);
	}
	int	PLC_MAKE_GROUP(int PlcType,int pnum,int gidx)
	{
		return(MakeGroupDevPLC(PlcType,pnum,gidx));
	}
	int	PLC_GROUP_READ(int PlcType,int pnum,int gidx)
	{
		return(C_RecGroupPLCDev(PlcType,pnum,gidx));
	}
	void	PLC_THRU_PROC(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
	{
		C_PLCFxThruProc(CommBuff,RecCommCnt,OutBuff,OutCnt,PlcConnectFlag,PlcType);
	}
	int	GET_MS_SEL(void)
	{
		return(C_Get_Ms_Sel());
	}
#endif
#ifdef	PLCTYPE_CH2
	int	PLC_CONNECT2(int *PlcType,int iConnect)
	{
		return(C_Connection(PlcType,iConnect));
	}
	int	GET_PLC_NAME2(int bFlag,unsigned char src,char *obj,int *DevInfo)
	{
		return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
	}
	int	PLC2CHAR_READ(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
	{
		return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
	}
	int	PLC_DEV_READ2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
	{
		return(C_PLCCommRead(mp,rDataFx,PlcType));
	}
	int	PLC_DEV_WRITE2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
	{
		return(C_PLCCommWrite(mp,rDataFx,PlcType));
	}
	int	PLCPCDOWN2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
	{
		return(C_PLCPCDownThrue(data,CommMode,RecCnt,RecBuff));
	}
	int	GET_PLC_MAX2(int bFlag,int idx)
	{
		return(C_GetDevMaxPLC(bFlag,idx));
	}
	int	GET_PLC_MIN2(int bFlag,int idx)
	{
		return(C_GetDevMinPLC(bFlag,idx));
	}
	int		DEVICE_2_INDEX2(int bwflag,char *Name)
	{
		return(C_Device2IndexPLC(bwflag,Name));
	}
	int		CHECK_PLC_ADDR2(int bwflag,char *Name,int *Address1,int *plctype)
	{
		return(C_CheckPLC_Addr(bwflag,Name,Address1,plctype));
	}
	/* 20070206 */
	void	GET_MON_BAUDRATE2(int *Speed,int *DataBit,int *Parity)
	{
		C_GetMonBaudrate(Speed,DataBit,Parity);
	}
	int	GET_SEND_REC_TIME2(void)
	{
		return(C_GetSendRecTime());
	}
	void	GET_PLC2_VER(char *Name)
	{
		C_Get_Plc_Ver(Name);
	}
	int	PLC_MAKE_GROUP2(int PlcType,int pnum,int gidx)
	{
		return(MakeGroupDevPLC(PlcType,pnum,gidx));
	}
	int	PLC_GROUP_READ2(int PlcType,int pnum,int gidx)
	{
		return(C_RecGroupPLCDev(PlcType,pnum,gidx));
	}
	void	PLC_THRU_PROC2(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
	{
		C_PLCFxThruProc(CommBuff,RecCommCnt,OutBuff,OutCnt,PlcConnectFlag,PlcType);
	}
	int	GET_MS_SEL2(void)
	{
		return(C_Get_Ms_Sel());
	}

#endif
#endif

