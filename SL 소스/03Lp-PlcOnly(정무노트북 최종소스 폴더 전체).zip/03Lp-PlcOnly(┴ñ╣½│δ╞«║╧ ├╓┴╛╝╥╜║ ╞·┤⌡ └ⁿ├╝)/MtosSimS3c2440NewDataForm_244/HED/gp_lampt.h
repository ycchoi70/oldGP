typedef struct{
	int *PointsX;
	int *PointsY;
	int *PointeX;
	int *PointeY;
	int	strCnt;
	char *cDispData;
	int xbai;
	int ybai;
	int iColor;
	int iType;
	int	VectorFlag;			//20100701 add
	int	VectorKind;			//20100701 add
}TEXTPOSITION_PARA;

typedef struct{
	int		strCnt;
	int		VectorFlag;
	char*	cDispData;
	short	iMex;
	int		iCnt;
	char*	cDispBuffer;
	char*	cTextBuffer[10];
}GET_TEXT_PARA;

void	SetLamp_Func(int iDispOrder);
int	DrawLamp_Func(int mode,_LAMP_EVENT_TBL* LampDispEventTbl,int iDispOrder);
void	LampDispWatch(int iOrder);
void	LampDraw(int sX, int sY, int eX, int eY, int iLampNumber, int Flag, int iTagNumber, int iFrameColor, int iLampColor);
void DrawTriangle(short x1,short y1,short x2,short y2,short x3,short y3,short LineColor,short FarmeColor,short	iType);
void vTextPositionDisp(TEXTPOSITION_PARA* param);
void	GetTextString(GET_TEXT_PARA* param);
void	DispLampSwitchImage(int sX,int sY,int eX,int eY,int no);
unsigned char*	SerchUniCode(unsigned char* buff,int code);
