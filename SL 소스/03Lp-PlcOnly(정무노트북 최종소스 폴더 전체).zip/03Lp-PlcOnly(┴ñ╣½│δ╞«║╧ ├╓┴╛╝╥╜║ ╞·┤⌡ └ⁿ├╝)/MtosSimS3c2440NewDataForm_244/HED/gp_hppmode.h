void	MonitoringMode(int* iScreenNo);
