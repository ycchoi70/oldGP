
#define	MAX_LOG_SIZE		(1024*1024)			//1M
//#define	MAX_LOG_SIZE		(1024*2)			//2K
#define	MAX_LOG_FREE_SIZE	(1024*2)			//2M


#define	RECIP_START		2000

#define	TIMSW_SW_SET		0
#define	TIMSW_RECIP_ACT		1
#define	TIMSW_ALMHIST_ENT	2
#define	TIMSW_ALMHIST_DEL	3
#define	TIMSW_ALMHIST_ON	4
#define	TIMSW_OBSEV_ACT		5
#define	TIMSW_BARCODE_IN	6
#define	TIMSW_ALMHIST_DEVCL	7
#define	TIMSW_ALMHIST_DEL1	8
#define	TIMSW_ALMHIST_RST1	9
#define	TIMSW_WRITE_WRITE	10
#define	TIMSW_UNIVERSAL		11
#define	TIMSW_ALMLIST_OFF	12
#define	TIMSW_LOW_BATTERY	13
#define	TIMSW_PRINT			14
#define	TIMSW_PLC_CONNECT_ERR	15
#define	TIMSW_LOG_ENT		16
#define	TIMSW_LOG_WRITE		17
#define	TIMSW_LOGDEV_CHG	18



#ifdef	KANSI_PROC
	/* Write Area Save	2008.05.22 */
	unsigned short	SaveWriteArea[WRT_DEV_CNT];
#else
	/* Write Area Save	2008.05.22 */
	extern	unsigned short	SaveWriteArea[WRT_DEV_CNT];
#endif





void	SetPCTimeOut(unsigned int sTime);
void	SetPC1CharTimeOut(unsigned int sTime);
void	SetPC1CharTimeOut0(unsigned int sTime);
void	SetPLCTimeOut(unsigned int sTime);
void	SetPLC1CharTimeOut(unsigned int sTime);
void	SetPLC1CharTimeOut0(unsigned int sTime);
void	KansiHotClear(int mode);
void	ClearHistry(void);
void	HotStartCheck(void);
void	ClearHistryOffDev(void);
void	DeleteHistry(int didx);
void	ResetHistryDev(int didx);
void	SetAlarmHistDev( int mode );
void	FloatingAlarmOpenClose( int mode );
void	SetfAlarmHistDev( int mode );
void	SetRecipeDevEntry( int mode );
void	SetReadDevEntry( int mode );
void	SetPasswordDevEntry( void );
void	SetSwitchingScreenDev( void );
void	SetObserveDevEntry( int mode );
void	SetAlarmListDev( int mode );
void	SetAlarmListStoredDev( int mode );
void	SetUniversal( int mode );
void	SystemDevOnlyEntry( int mode );
void	SortDeviceData(void);
void	SystemDevEntry( void );
void	SystemDevNoClearEntry( void );
void	SendTimeAction(int p1,int p2,int p3,int p4);
void	WaitSendTimeAction(int p1,int p2,int p3,int p4);
unsigned short ChangeShortLH(unsigned short data);
unsigned long ChangeLongLH(unsigned long data);
void	ObserveAction(OBS_DEV *ObserveDev,int OnOff);
void	SendHost(char *buff,int cnt);
void	SetTotalCnt(DEVICE_TYPE *Device,int cnt);
void	Write_WriteDev( void );
void	Write_AlarmBit( int mode );
void	Write_LowBatteryBit( int mode );
void	WriteRecipeData(int iOffset,char *RecipData);
//void	WriteRecipLast(void);
void	TimeSwitchTask( STTFrm* pSTT );
void	SendAnalsys(int mode);
void	SendKeyData(int mode);
void	SendMsg(int Com,int no,int mode);
int	CheckPlcDeviceUse(void);
void	ScreenState( int loopCnt );
void	ProjectState( int loopCnt );
void	MonitorOffSet(void);
void	PcState( STTFrm* pSTT );
void	ObservProc(int loopCnt);
void    ObservTask(STTFrm* pSTT);
void	StateSignal3(void);
int PrintDataDisplay(void);

void	SetLogDataDev( int mode );
void	SetLogDevice(void);
void	ClearLog(void);
void	EntryLogData(T_MAIL* mp);
void	WriteLogData(void);
void	LogState(void);
int	CheckPrintMode(void);
int PrintDataDisplay(void);
void	SetIndev2RealDev(DEVICE_INF* obj,DEVICE_INF* src);		//2012.02.27

