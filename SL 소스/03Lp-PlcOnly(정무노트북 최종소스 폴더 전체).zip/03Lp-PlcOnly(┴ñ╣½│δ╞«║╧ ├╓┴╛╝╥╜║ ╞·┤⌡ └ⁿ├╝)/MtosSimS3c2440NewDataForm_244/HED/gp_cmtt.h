typedef struct{
	int sX;
	int sY;
	int eX;
	int eY;
	int	iLen;
	char * cDispData;
	int xbai;
	int ybai;
	int iColor;
	int iBackColor;
	int iType;
	int	VectorFlag;			//20100701 add
	int	VectorKind;			//20100701 add
}MULTITEXT_PARA;
void	SetComment_Func(int iDispOrder);
int	DrawComment_Func(int mode,_COMMENT_EVENT_TBL* CommentEventTbl,int iDispOrder);
void	CommentDispWatch(int iOrder);
void vMultiTextDisp(MULTITEXT_PARA* param);
int vCommentDataSet(int inowNum, char *cDataBuffer, unsigned long *iColor, int *iLen,int VectorFlag);
void vCommentDisplayFormat(int i ,char* Data, short SizeV ,short SizeH,int pVectorFlag,int pVectorKind );
void SetComentDevice(int mode,int iOrder);
char*	sysComentFileOpen(int *CommentCnt);
int GetCommentSequence(int idx, int *inowNum, int mCnt, char *cDataBuffer, char* AllTagBuffer);

