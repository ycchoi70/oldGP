/********************************/
/*	����ԍ���`       			*/
/*  1999.8.10                   */
/********************************/
/*	Driver & Handler			*/


#define	T_KEY	        0x01
#define	T_SIO422DRV		0x02
#define	T_SIO232DRV		0x03
#define	T_RTCDRV		0x04
#define	T_SIO422RCV		0x05
#define	T_SIO232RCV		0x06
#define	T_BZRDRV		0x07

#define T_KEYHAND       0x08
#define T_RTCHAND       0x09
#define T_PLCHAND		0x0a
#define T_PLCHAND2		0x0b
#define	T_PCKANSI		0x0c
#define	T_PLCKANSI		0x0d
#define	T_FLTKANSI		0x0e
#define T_MSG_TASK		0x0f


#define	T_INITASK	    0x10
#define	T_SETTASK       0x11
#define	T_DISPANALYSIS	0x12

#define T_PROJECT		0x13
#define T_CLASSIFICATION 0x14
#define T_T_KEY_WATCH	0x15

#define	T_PLC2KANSI		0x16
/*#define T_FILE_TASK		0x16*/


#define	T_OBSERV		0x17
#define	T_TIME_ST		0x18
#define	T_TIME_PROC		0x19

/*#define	T_ALARMDETAIL	0x1a*/
#define	T_DISP_TASK		0x1a
#define	T_DEBUG			0x1b
#define	T_PLCCON		0x1c

/* GLP Task */
#define	T_PLCMAIN		0x1d
#define	T_PLCTINT_TASK	0x1e
#define	T_PLCINTTASK	0x1f
/**/
#define	T_NAND_HAND		0x20
#define	T_USB_HDRV		0x21
#define	T_USB_HHAND		0x22
#define	T_USB_DDRV		0x23
#define	T_DOS_FILE		0x24
#define	T_LAN_DRV		0x25
#define	T_LAN_HAND		0x26

#define	T_TOUCH_HAND	0x27
#define	T_TOUCH_DRV		0x28
#define	T_TCH_TM_DRV	0x29
#define	T_USB_SRG_DDRV	0x2a

/************************************/
/*  �V�O�i��                        */
/************************************/
#define SGN_PLC		0
#define	S_KEY       1
#define S_BUZ       2
#define S_PROJECT	3
#define S_SCREEN	4
#define	SGN_PLC_PRC	5
#define	S_ENV		6
/************************************/
/*  �Z�}�t�H                        */
/************************************/
#define SMF_DISP	0
#define SMF_WIN		1
#define SMF_SEND	2
#define SMF_USBHOST	3
#define SMF_LOG		4
/***********************************/
#define	INI_COMMENT			0
#define	INI_DETAIL_ALARM	1
#define	INI_ENV_STATE		2
#define	INI_NUMIN_BIT		3
#define	INI_ASCIN_BIT		4
#define	INI_ENV_DEVMON		5
/**********************************/
#define	WIN_BASE_DATA		0
#define	KEY_WIN_DATA		1
#define	FLOAT_DATA			2
#define	BMP_DATA			3
#define	ITEM_DATA			4
#define	FILE_LIST_DATA		5
#define	TOUCH_KEY_DATA		6
#define	TOUCH_INPUT_ADDR	7
#define	TOUCH_CALB_LINE		8
#define	TOUCH_TEXT_DSP		9
#define	ITEM_DATA_CLEAR		10
#define	ITEM_ALARM_HIST		11
#define	ITEM_ALARM_LIST		12
#define	ITEM_CLOSE_WIN		13

/*********************************/
//USB Handler Command
#define	USB_HOST_CONNECT		0
#define	USB_HOST_DISCONNECT		1
#define	READ_SECTOR				2
#define	WRITE_SECTOR			3
#define	ERASE_SECTOR			4
//Nand Flash Driver			//2012.02.11
#define	NAND_ERASE				10
#define	NAND_WRITE_RANDOM		11
#define	NAND_READ_RANDOM		12
#define	NAND_WRITE_SEQ			13
#define	NAND_READ_SEQ			14
#define	NAND_READ_ECC			15

/*********************************/
//FILE Handler Command
#define	FS_CMD_CHDIR		0
#define	FS_CMD_OPEN			1
#define	FS_CMD_CLOSE		2
#define	FS_CMD_CREATE		3
#define	FS_CMD_READ			4
#define	FS_CMD_WRITE		5
#define	FS_CMD_FND_FIRST	6
#define	FS_CMD_FND_NEXT		7
#define	FS_CMD_MKDIR		8
#define	FS_CMD_RMDIR		9
#define	FS_CMD_REMOVE		10
#define	FS_CMD_RENAME		11
#define	FS_CMD_SERCH		12
#define	FS_CMD_SEEK			13
#define	FS_CMD_TELL			14
#define	FS_CMD_FLASH_CLOSE	15

#define	FS_CMD_CHDIR_UNI	16
#define	FS_CMD_FND_FIRST_UNI	17
#define	FS_CMD_REMOVE_UNI	18
#define	FS_CMD_OPEN_UNI		19
#define	FS_CMD_SERCH_UNI	20
#define	FS_CMD_RMDIR_UNI		21



void	InitUsbHostSema( void );
void	SetUsbHostSema( void );
void	ResetUsbHostSema( void );

void	InitLogFileSema( void );
void	SetLogFileSema( void );
void	ResetLogFileSema( void );
