

#ifdef	DISPSIM_PROC

	typedef struct tagBITMAPFILEHEADER {
	  unsigned short    bfType;
	  unsigned long   bfSize;
	  unsigned short    bfReserved1;
	  unsigned short    bfReserved2;
	  unsigned long   bfOffBits;
	} BITMAPFILEHEADER, *PBITMAPFILEHEADER;

	typedef struct tagBITMAPINFOHEADER{
	  unsigned long  biSize;
	  long   biWidth;
	  long   biHeight;
	  unsigned short   biPlanes;
	  unsigned short   biBitCount;
	  unsigned long  biCompression;
	  unsigned long  biSizeImage;
	  long   biXPelsPerMeter;
	  long   biYPelsPerMeter;
	  unsigned long  biClrUsed;
	  unsigned long  biClrImportant;
	} BITMAPINFOHEADER, *PBITMAPINFOHEADER;

	const struct{
		int	addr;
		int	ByteCnt;
	}MitudoFont[6][3]= 
	{
		{
			{FONT_HEXA2432,24/8*32},{FONT_HEXA2448,24/8*48},{FONT_HEXA2464,24/8*64},
		},
		{
			{FONT_HEXA3232,32/8*32},{FONT_HEXA3248,32/8*48},{FONT_HEXA3264,32/8*64},
		},
		{
			{0},
		},
		{
			{FONT_HEXA4832,48/8*32},{FONT_HEXA4848,48/8*48},{FONT_HEXA4864,48/8*64},
		},
		{
			{0},
		},
		{
			{FONT_HEXA6432,64/8*32},{FONT_HEXA6448,64/8*48},{FONT_HEXA6464,64/8*64},
		},
	};

	/* 20080822  #define	const�� �����Ͽ��⿡ WIN32�� ���� �ʿ䰡 ����. */
	unsigned char	BlackFont[32]={
		0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
		0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
		0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
		0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	};
	unsigned char	TriangleFont[9][32]={
		{
			0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x00,
			0x03,0x80,0x07,0xc0,0x07,0xc0,0x0f,0xe0,
			0x1f,0xf0,0x1f,0xf0,0x3f,0xf8,0x7f,0xfc,
			0x7f,0xfc,0x00,0x00,0x00,0x00,0x00,0x00, /* �� */
		},
		{
			0x00,0x00,0x00,0x00,0x00,0x00,0x7f,0xfc,
			0x7f,0xfc,0x3f,0xf8,0x1f,0xf0,0x1f,0xf0,
			0x0f,0xe0,0x07,0xc0,0x07,0xc0,0x03,0x80,
			0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00, /* �� */
		},
		{
			0x00,0x00,0x00,0x04,0x00,0x1c,0x00,0x7c,
			0x01,0xfc,0x07,0xfc,0x1f,0xfc,0x7f,0xfc,
			0x1f,0xfc,0x07,0xfc,0x01,0xfc,0x00,0x7c,
			0x00,0x1c,0x00,0x04,0x00,0x00,0x00,0x00, /* �� */
		},
		{
			0x00,0x00,0x10,0x00,0x1c,0x00,0x1f,0x00,
			0x1f,0xc0,0x1f,0xf0,0x1f,0xfc,0x1f,0xff,
			0x1f,0xfc,0x1f,0xf0,0x1f,0xc0,0x1f,0x00,
			0x1c,0x00,0x10,0x00,0x00,0x00,0x00,0x00, /* �� */
		},
		{
			0x00,0x00,0x03,0xc0,0x0f,0xf0,0x1f,0xf8,
			0x3f,0xfc,0x3f,0xfc,0x7f,0xfe,0x7f,0xfe,
			0x7f,0xfe,0x7f,0xfe,0x3f,0xfc,0x3f,0xfc,
			0x1f,0xf8,0x0f,0xf0,0x03,0xc0,0x00,0x00, /* �� */
		},
	};


	int	lcdAddrIdx;
#else
	extern	unsigned char	BlackFont[32];
	extern	unsigned char	TriangleFont[9][32];
	extern	int	lcdAddrIdx;

#endif

void    XInc( void );
void    XDec( void );
void    YInc( void );
void    YDec( void );
void	__MoveTo( int sx, int sy, int Pattern, int Mode, COLOR_DT color );
void    DrawHorizontal( int sx, int ex, int y, COLOR_DT color );
void    DrawHorizontalPrn( int sx, int ex, int y, COLOR_DT color );
void    RDrawHorizontal( int sx, int ex, int y, COLOR_DT color );
void    RDrawHorizontalPrn( int sx, int ex, int y, COLOR_DT color );
void    DrawVertical( int x, int sy, int ey, COLOR_DT color );
void    DrawVerticalPrn( int x, int sy, int ey, COLOR_DT color );
void    RDrawVertical( int x, int sy, int ey, COLOR_DT color );
void    RDrawVerticalPrn( int x, int sy, int ey, COLOR_DT color );
void    DrawFnc( int DMst, int DSlave, void (*pMainMoveFnc)(void), void (*pSlaveMoveFnc)(void ), COLOR_DT color );
void	XNonSetFont(int mode,COLOR_DT **LcdPos,unsigned char **FontPos,int cnt,COLOR_FRM *color);
unsigned char *SetHanFontPos(int xbai,int ybai,int idx);
int	DotWriteFont0(int type,int x,int y,unsigned char *addr,int back,int xbai,int ybai,int mode,int idx,int mitudo,COLOR_FRM *color);
void	DotWriteFont2(int x,int y,unsigned char *addr,int back, int xbai, int ybai, int mode, int mitudo,COLOR_FRM *color);
int	DotWriteFont2Vector(unsigned char *addr, int iSize, int fType, VECTFONT_SIZE* font);
void	DrawDotWriteFont2Vector(_AREA_INFO* xyAddr,VECTFONT_SIZE* font,int mode,COLOR_FRM *color);
void	PaintPatarn1Line(int sx,int ex,int y,int Paint,int Fcolor,int Bcolor,int mode);
void	PutImage( int ssx, int ssy, int eex, int eey, COLOR_DT *pScrBuff);
void	PutImageGp( int ssx, int ssy, int eex, int eey, char *pScrBuff);
void	GetImage( int sx, int sy, int ex, int ey, COLOR_DT *ScrBuff);
void	Dot(int	x, int y,COLOR_DT color);
void	AreaClear(int ssx,int ssy,int eex,int eey,int back);
void	AreaRevers(int ssx,int ssy,int eex,int eey);
void	PutWindow( _AREA_INFO* darea,int no,_AREA_INFO* sarea,LCD_BUF *lcdb);
void	PutWindowReplace( _AREA_INFO* darea,int no,_AREA_INFO* sarea,LCD_BUF *lcdb);
void DmaCopy(unsigned int src, unsigned int dst, unsigned int cnt);			// src=fix, dst=increment, cnt=byte
void	DrawLcdBank1(void);
void	DrawBmpData(int no);
void	ClearDispBuff(int WinNo);
void	ClearDispBuffBackColor(int WinNo,int Color);
void	DrawLcdBank2(int kind,_AREA_INFO* area);
void	DrawLcdBank3(int kind,_AREA_INFO* area);
void	DrawLcdBankClose(int no);
void	DrawLcdBankCloseProc(int no);
int	CulcVectorSize(int pSize,int kind);
int	CulcVectorYSize(int pSize,int pKind);
void	DispBmpCol(int WinNo,int sx,int sy,unsigned char* buff);
int	DispBmpFileCol(int WinNo,char* FileName,int sx, int sy, int ex, int ey,int dispFlag);
void	InitFontLib(void);
void	CloseFontLib(void);
void	DispBmp32(int WinNo,int sx,int sy,unsigned char* buff,int biHeight,int biWidth,int cnt);
void	DispBmp24(int WinNo,int sx,int sy,unsigned char* buff,int biHeight,int biWidth,int cnt);
void	DispBmp16(int WinNo,int sx,int sy,unsigned char* buff,int biHeight,int biWidth,int cnt,float ritux,float rituy);
void	DispBmp8(int WinNo,int sx,int sy,unsigned char* buff,int biHeight,int biWidth,int cnt,float ritux,float rituy);
void	DispBmp4(int WinNo,int sx,int sy,unsigned char* buff,int biHeight,int biWidth,int cnt,float ritux,float rituy);
void	DispBmp1(int WinNo,int sx,int sy,unsigned char* buff,int biHeight,int biWidth,int cnt,float ritux,float rituy);
void	DrawDotWriteFont2VectorCenter(_AREA_INFO* xyAddr,VECTFONT_SIZE* font,int mode,int Start_X, COLOR_FRM *color);
void	PutWindowForward( _AREA_INFO* darea,int no,_AREA_INFO* sarea,LCD_BUF *lcdb);
void	DrawFloating(void);
void	DrawFloatingProc(LCD_BUF* LcdBufAddr);
void	ClearWindowDispBuffBackColor(int WinNo,int idx);
int	CulcVectorSizeChar(int pSize,int pkind,char c);


