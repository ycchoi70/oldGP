#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<math.h>
#ifdef	WIN32
#include	<time.h>
#define	const
#endif

#include	"define.h"
#include	"glplib.h"
#include	"mts.h"
#include	"mtscifp.h"
#include	"mail.h"
#include	"mtstimep.h"
#include	"taskhed.h"
#include	"gpstruct.h"
#include	"doscomm.h"
#include	"glpdos.h"
#include	"CommBuff.h"
#include	"plcCommBuff.h"
#include	"sys_setting.h"
#include	"bios.h"
#include	"piodrv.h"
#include	"disp.h"
#include	"dispsim.h"
#include	"kansi.h"
#include	"plchand.h"
#include	"rtc.h"
#include	"rs232c.h"
#include	"rs232c_pc.h"
#include	"plc_func.h"
#include	"iohand.h"
#include	"rs_232cbuff.h"
/********************************************/
/*	Application								*/
/********************************************/
#include	"gp_sysmes.h"
#include	"gp_actst.h"
#include	"gp_almd.h"
#include	"gp_almh.h"
#include	"gp_alml.h"
#include	"gp_asci.h"
#include	"gp_asct.h"
#include	"gp_listtask.h"
//#include	"gp_backl.h"
#include	"gp_barg.h"
//#include	"gp_batt.h"
//#include	"gp_buzz.h"
#include	"gp_cation.h"
#include	"gp_class.h"
//#include	"gp_clrd.h"
//#include	"gp_clock.h"
#include	"gp_clkt.h"
#include	"gp_cmta.h"
#include	"gp_cmtt.h"
#include	"gp_commonfile.h"
//#include	"gp_dattrn.h"
//#include	"gp_devmon.h"
//#include	"gp_devin1.h"
//#include	"gp_devin2.h"
//#include	"gp_lcdcnt.h"
//#include	"gp_srch.h"
#include	"gp_toucht.h"
//#include	"gp_usrs.h"
#include	"gp_numt.h"
#include	"gp_parts.h"
#include	"gp_lampt.h"
#include	"gp_panelm.h"
#include	"gp_trdg.h"
#include	"gp_lineg.h"
#include	"gp_statis.h"
#include	"gp_numi.h"
#include	"gp_numinp.h"
//#include	"gp_langs.h"
//#include	"gp_hppmode.h"
//#include	"gp_mainc.h"
//#include	"gp_other.h"
//#include	"gp_pcdg.h"
//#include	"gp_plctset.h"
//#include	"gp_prtout.h"
//#include	"gp_screen.h"
//#include	"gp_seriset.h"
//#include	"gp_testmode.h"
//#include	"gp_setmen.h"
//#include	"gp_setup.h"
//#include	"gp_timesw.h"
#include	"gp_title.h"
//#include	"gp_modelver.h"
//#include	"gp_xydevmon.h"
#include	"gp_filecontrol.h"

#include	"gp_dispanl.h"
#include	"gp_listtask.h"
#include	"gp_InputProc.h"


#include	"comlib.h"
#include	"selib.h"

#include	"sioprotcol.h"
#include	"udebtsk.h"

#include "lp_IPDefines.h"
#include "lp_EachRoutins.h"
#include "lp_matrix.h"
#include "lp_io16.h"
#include "lp_param.h"
#include "lp_ioctl.h"
#include "lp_Intepreter.h"
#include "lp_comm.h"

#ifdef	MAIN
	extern	_SETUP			Set;					/* set value save struct */


//	_DISPLAY *Dspname;
//	_DISPLAY1 *LDspname;
	/* kansi.c */
	extern	unsigned	PLCCnNewRec;		/* Main PLC Timeout */
	extern	unsigned	PLCCnNewRec2;		/* Sub PLC Timeout */
	extern	int		PLCCnErrorDsp;
	/* plchand.c */
//	extern	int		PlcConnectFlag;				/* PLC�ڑ��t���O */
	extern	int		PlcConnectFlag[MAX_POLE];				/* PLC�ڑ��t���O */
	extern	int		PlcConnectFlag2[MAX_POLE];			/* PLC�ڑ��t���O(PLC TYPE2) 20081007 */

	const	char *SetcSpeed[10]		= {"300bps","600bps","1200bps","2400bps","4800bps","9600bps","19200bps","38400bps","57600bps","115200bps"};
	/*							  0        1         2         3         4         5          6         7           8          9  */
	const	char *SetcParity[3]	= {"NONE","ODD","EVEN"};
	const	char *SetcData[2]		= {"7BIT","8BIT"};
	const	char *SetcFlow[2]		= {"XON/XOFF","DSR/DTR"};
	const	char *SetcStop[2]		= {"1BIT","2BIT"};

	const	char	*SetDefaultPLC[2]= {"UNIVERSAL","MK-200S(CPU)"};
	const	char	*SetdefaultSerialKind[5]= {"EDITOR","PRINTER","BARCODE","MONITOR","PLC2"};
	const	char	*SetConnectPort[2]= {"RS422 ","RS232C"};

	const	char	*MessConnectErr[]= {
		"DISPLAY SCREEN IS NOT ","AVAILABLE ","DISPLAY ","SCREEN "              ,"IS NOT"   ,"AVAILABLE ","PLC NO CONNECTION","PLC "   ,"NO " ,"CONNECTION",
		""                     ,"\xff\x02" ,"\xff\x01","\xff\x03"             ,"\xff\x04" ,"\xff\x04" ,"ALARM HISTORY"    ,"PRINT?" ,"YES" ,"NO"        ,
		"END"                  ,"Exit"     ,"Menu"    ,"PASSWORD IS INCORRECT","INVALID " ,"VALUE..." ,"SET "             ,"NUMBER ","IS " ,"INCORRECT" ,
		"SET NUMBER IS INCORRECT.","USER "  ,"SCREEN ","IS NOT "    ,"FOUND"
	};


#else
	extern	_DISPLAY *Dspname;
	extern	_DISPLAY1 *LDspname;

	extern	char *SetcSpeed[10];
	extern	char *SetcParity[3];
	extern	char *SetcData[2];
	extern	char *SetcFlow[2];
	extern	char *SetcStop[2];
	extern	char *SetDefaultPLC[2];
	extern	char *SetdefaultSerialKind[5];
	extern	char *SetConnectPort[2];
	extern	char *MessConnectErr[];
#endif
/************************************************************/
void	vPrintOutMain(int* iScreenNo);
void	SendTaskAnal(int p1);
int	SendTaskSet( int p1,int p2 );
int	SendTaskFile( int p1 );
void	IniTask( STTFrm* pSTT );
int	SetTask( int p1 );
void	DispAnalysis( STTFrm* pSTT );
void	PlcConnectDisp(void);
void	PlcConnectDispClr(void);
unsigned long Encrypt(char *s);
void Decrypt(unsigned long x, char *s);
void	FileTask( int mode );
void	DrawLine_Func( int iTagSize, unsigned char *ucTagBuff, int iColor);
void	DrawRect_Func(  int iTagSize, unsigned char *ucTagBuff , int iColor);
void	DrawCircle_Func(  int iTagSize, unsigned char *ucTagBuff , int iColor);
void	DrawText_Func( int iTagSize, unsigned char *ucTagBuff , int iColor);
int	DrawShape(int ShapeNo, int sX, int sY, int eX, int eY, int iFrameC, int iPlateC);
void	vFreemeilAll(void);
void	vWindowFreemeil(void);
void	ClearTagInfo(void);
int	CheckSecurityLevel(int iScreenNow);

int	FontLoad(char *SaveAddr);
void	SendInitTask(int mcod,int mcmd,int VectorFlag,int VectorKind);
void	ClearDeviceMonInfo(void);
void	SetSwitchngBaseNo(int no);
int	GetSwitchngBaseNo(void);

void	vScreenDataSet(int mode);			//2012.02.10
int	Observe_ScreenSet(short	iScreenNum);
unsigned long NowBackColor(int iScreenNum);
int	GetWindowIdx(int iScreenNum);
void	vSysScreenDataSet(void);
void	DefaultClockSet(void);

int	IsClockSetting(void);
int	IsSettingMode(void);
int	GetShapeNo(int ShapeNo);

