//#define	OLD_DATA

void CommonFileSet(void);
DEV_DATA*	GetFreeDeviceHed(DEVICE_INF* pDeviceInf);
void	IncDevCnt(DEVICE_INF* pDeviceInf);
DEV_DATA*	GetFreeDeviceSys(DEVICE_INF* pDeviceInf);
void	IncDevCntSys(DEVICE_INF* pDeviceInf);
void EditCommonFileTimeSwitch(void);
