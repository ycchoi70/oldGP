int		vPrintOut(int* iScreenNo);
int	iPrintOutSelect(int* iScreenNo);
int PrintDataDisplay(void);
int	CheckPrintMode(void);
