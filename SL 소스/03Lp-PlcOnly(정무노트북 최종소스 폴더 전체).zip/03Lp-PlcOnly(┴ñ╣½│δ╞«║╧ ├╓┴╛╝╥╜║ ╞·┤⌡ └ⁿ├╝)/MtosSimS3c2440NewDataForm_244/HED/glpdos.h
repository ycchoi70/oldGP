/****************************************************
*  Dos file system emulation program  common header	*
*	(Aviodos.H)		1997,4,22	Ver 1.10			*
****************************************************/

#define	BOOL		int					/* boolean */
#define	BYTE		unsigned char		/* byte storage */
#ifndef	TRUE
#define	TRUE		1					/* boolean True */
#define	FALSE		0					/* boolean False */
#endif


BOOL	InitializeFileSystem (void);
BOOL	MountMedia (int drive);
BOOL	DisMountMedia (int drive);

int	Fs_chdir (char *name);
int	Fs_open (char *path, int oflag, int pmode);
int	Fs_close (int channel);
int	Fs_creat (char *path, int pmode);
int	Fs_read (int channel, char *buff, int rLen);
int	Fs_write (int channel, char *buff, int rLen);
int Fs_dos_findfirst(char *wildspec, unsigned attr, struct find_t *finddata);
int Fs_dos_findnext(struct find_t *finddata);
int	Fs_mkdir (char *path);
int Fs_rmdir(char *path);
int Fs_remove (char *path);
int Fs_rename (char *oldname, char *newname);
int Fs_search (char *path, int *size);
int Fs_seek (int channel, int offset, int mode);
BOOL TVS_GetDiskFreeSpace (char *root, int *csize, int *ssize, int *free, int *total);
int	Fs_flush_close (int channel);
long	Fs_tell (int channel);

int	SendDosFileTask(int cmd,void* paddr1,void* paddr2,int param1,int param2);
int	IsDevice(int drv);

int	MakeFatFsNand( int hDev, unsigned int nFat, unsigned int FatType, unsigned int nRootDirEntry, unsigned int nSecotorPerCluster );

void	ClearVcAllocMailAll(void);


int	Fs_chdirUni (char *name);
int Fs_dos_findfirstUni(char *wildspec, unsigned attr, struct find_t *finddata);
int Fs_removeUni (char *path);
int	Fs_openUni (char *path, int oflag, int pmode);
int Fs_searchUni (char *path, int *size);
char*	strchrUni(char* src, char cmpChr);
int	strcmpUniAsc(char* src,char* obj);
void	strcatUni(char* old,char* src);
int Fs_rmdirUni(char *path);


//#ifndef	WIN32
/* open    oflag */
#define	O_APPEND	0x0001		/* reposition file ptr to end before every write */
#define	O_BINARY	0x0002		/* open in binary mode */
#define	O_CREAT		0x0004		/* create a new file* no effect if file already exists */
#define	O_EXCL		0x0008		/* return error if file exists, only use with O_CREAT */
#define	O_RDONLY	0x0010		/* open for reading only */
#define	O_RDWR		0x0020		/* open for reading and writing */
#define	O_TEXT		0x0040		/* open in text mode */
#define	O_TRUNC		0x0080		/* open and truncate to 0 length (must have write permission) */
#define	O_WRONLY	0x0100		/* open for writing only */

/* open   pmode */
#define	S_IWRITE	0x0001		/* writing permitted */
#define	S_IREAD		0x0002		/* reading permitted */

//#else
//#include	"fcntl.h"
//#include	"sys\stat.h"
//#endif


#define	FA_RDONLY	0x01		/* Read-only attribute */
#define	FA_HIDDEN	0x02		/* Hidden file */
#define	FA_SYSTEM	0x04		/* System file */
#define	FA_LABEL	0x08		/* Volume label */
#define	FA_DIRECT	0x10		/* Sub Directory */
#define	FA_ARCH		0x20		/* Archive */

#define	FS_SEEK_SET	0
#define	FS_SEEK_CUR	1
#define	FS_SEEK_END	2
