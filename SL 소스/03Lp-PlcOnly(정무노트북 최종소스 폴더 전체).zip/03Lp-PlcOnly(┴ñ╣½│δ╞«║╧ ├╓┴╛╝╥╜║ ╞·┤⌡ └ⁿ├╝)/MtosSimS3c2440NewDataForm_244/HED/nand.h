////////////////////////////////////////////////////////////
//	Nand Command
////////////////////////////////////////////////////////////
#define	CMD_READ_A		0x00
#define	CMD_READ_B		0x01
#define	CMD_PAGEPROG	0x10
#define	CMD_READ_C		0x50
#define	CMD_ERASE1		0x60
#define	CMD_READ_STS	0x70
#define	CMD_SEQIN		0x80
#define	CMD_READ_ID		0x90
#define	CMD_ERASE2		0xd0
#define	CMD_RESET		0xff

//#define	START_BLOCK		64*4
#define	START_BLOCK		0
////////////////////////////////////////////////////////////
//	Nand Page Size & Block size
////////////////////////////////////////////////////////////
#define MAX_NAND_PAGE_SIZE		2048
#define	MAX_NAND_PAGE_PER_BLOCK	64
#define	MAX_NAND_ECC_SIZE		64
//NAND1
#define NAND1_PAGE_SIZE			512
#define	NAND1_PAGE_PER_BLOCK	32
#define	NAND1_ECC_SIZE			16
#define	NAND1_ECC_SIZE_START		(NAND1_ECC_SIZE-8)
//NAND2(K9F1G08U0D)
#define NAND2_PAGE_SIZE			2048
#define	NAND2_PAGE_PER_BLOCK	64
#define	NAND2_ECC_SIZE			64
#define	NAND2_ECC_SIZE_START		(NAND2_ECC_SIZE-8)


//FLASH DISK ADDRESS 2012.02.11
//#define FRAFH1_FILE_OFFSET          (0x00200000/NAND_PAGE_SIZE)
//#define FRAFH2_FILE_OFFSET          (0x01200000/NAND_PAGE_SIZE)
//#define FRAFH3_FILE_OFFSET          (0x03200000/NAND_PAGE_SIZE)
//#define FRAFH4_FILE_OFFSET          (0x03C00000/NAND_PAGE_SIZE)
#define FRAFH1_FILE_OFFSET          (0x00200000)
#define FRAFH2_FILE_OFFSET          (0x01200000)
#define FRAFH3_FILE_OFFSET          (0x03200000)
#define FRAFH4_FILE_OFFSET          (0x03C00000)
//RAM DISK ADDRESS 2012.02.11
#define RAMDISK_ADDRESS				(0x33000000)
#define PTNDISK_ADDRESS				(0x32000000)
//DISK SIZE 2012.02.11
#define ROM_SIZE1        0x01000000		//16Mb							//DEV_A AREA SIZE
#define ROM_SIZE2        0x02000000		//32Mb							//DEV_B SIZE
#define ROM_SIZE3        0x00a00000		//10Mb							//DEV_C SIZE
#define ROM_SIZE4        0x01000000		//16Mb							//DEV_F SIZE(RAM DISK)
#define ROM_SIZE5        0x00800000		//8Mb							//DEV_G SIZE(RAM DISK)
#define ROM_SIZE6        0x00200000		//2Mb							//DEV_E SIZE(PLC DATA)

#define SECTOR_SIZE					512         /* sector size (bytes)for Filesystem */

#define	NAND_MAP_AREA				0x00003000		//Bad Block Map
#define	NAND_RESERVED_AREA			0x03F00000		//

#define	TOUCH_CALIB_AREA			0x0002000									//2012.02.11
#define	MAC_ADDR_AREA				0x0002200		//4Byte:SeqNo,6Byte:MacAddr	//2012.02.11

/*
 * Standard NAND flash commands
 */
//#define NAND_CMD_READ0		0
//#define NAND_CMD_READ1		1
//#define NAND_CMD_RNDOUT		5
//#define NAND_CMD_PAGEPROG	0x10
//#define NAND_CMD_READOOB	0x50
//#define NAND_CMD_ERASE1		0x60
//#define NAND_CMD_STATUS		0x70
//#define NAND_CMD_STATUS_MULTI	0x71
//#define NAND_CMD_SEQIN		0x80
//#define NAND_CMD_RNDIN		0x85
//#define NAND_CMD_READID		0x90
//#define NAND_CMD_ERASE2		0xd0
//#define NAND_CMD_RESET		0xff
/* Extended commands for large page devices */
//#define NAND_CMD_READSTART	0x30
//#define NAND_CMD_RNDOUTSTART	0xE0
//#define NAND_CMD_CACHEDPROG	0x15

typedef struct{
	char	pass[16];
	int		StartBadCnt;
	int		BadNo[123];
}START_MAP;
typedef struct{
	int	ChangeBadCnt;
	int	ReserveStartNo;
	struct{
		int	Original;
		int	NewNo;
	}chgInf[63];
}RANDOM_MAP;

#ifdef	NAND_PROC
	const unsigned char	Nand1ID[4]={0xec,0x76,0x5a,0x3f};
	const unsigned char	Nand2ID[4]={0xf1,0x00,0x15,0x40};
	int				NandBlockNo;						//2012.02.11
	unsigned char	NandBlockBuff[MAX_NAND_PAGE_PER_BLOCK][MAX_NAND_PAGE_SIZE];
	unsigned char	NandPageBuff[MAX_NAND_PAGE_SIZE+MAX_NAND_ECC_SIZE];		//2012.02.11
	unsigned char	Nand_se[MAX_NAND_ECC_SIZE];
	struct{
		START_MAP	StartBadblock;
		RANDOM_MAP	RandomMap;
	}NandBadblockMap;
	unsigned char	NandID[16];
	int	NAND_PAGE_SIZE;
	int	NAND_PAGE_PER_BLOCK;
	int	NAND_ECC_SIZE;
	int	NAND_ECC_SIZE_START;
	int	NandType;
#else
	extern	int				NandBlockNo;						//2012.02.11
	extern	unsigned char	NandBlockBuff[MAX_NAND_PAGE_PER_BLOCK][MAX_NAND_PAGE_SIZE];
	extern	unsigned char	NandPageBuff[MAX_NAND_PAGE_SIZE+MAX_NAND_ECC_SIZE];		//2012.02.11
	extern	unsigned char	Nand_se[MAX_NAND_ECC_SIZE];
	extern	struct{
				START_MAP	StartBadblock;
				RANDOM_MAP	RandomMap;
			}NandBadblockMap;
	extern	unsigned char	NandID[16];
	extern	int	NAND_PAGE_SIZE;
	extern	int	NAND_PAGE_PER_BLOCK;
	extern	int	NAND_ECC_SIZE;
	extern	int	NAND_ECC_SIZE_START;
	extern	int	NandType;
#endif

void NAND_Init(void);
void NAND_ReadID(unsigned char* buff);
void NAND_Open(void);
int NAND_ReadPage(unsigned int block,unsigned int page,unsigned char *buffer);
int NAND_WritePage(unsigned int block,unsigned int page,unsigned char *buffer);
int NAND_EraseBlock(unsigned int block);
int NAND_Read_Random(unsigned int fAddr,unsigned char *buffer,int len);
int NAND_Write_Random(unsigned int fAddr,unsigned char *buffer,int len);
int NAND_Read_Seq(unsigned int fAddr,unsigned char *buffer,int len);
int NAND_Write_Seq(unsigned int fAddr,unsigned char *buffer,int len);
int NAND_IsBadBlock(unsigned block);

int	MakeFatFsNand( int hDev, unsigned int nFat, unsigned int FatType, unsigned int nRootDirEntry, unsigned int nSecotorPerCluster );



int NAND_Read_ECC(unsigned int Sector,unsigned char *buffer,int len);
int NAND_ReadPage_ECC(unsigned int block,unsigned int page,unsigned char *buffer);
