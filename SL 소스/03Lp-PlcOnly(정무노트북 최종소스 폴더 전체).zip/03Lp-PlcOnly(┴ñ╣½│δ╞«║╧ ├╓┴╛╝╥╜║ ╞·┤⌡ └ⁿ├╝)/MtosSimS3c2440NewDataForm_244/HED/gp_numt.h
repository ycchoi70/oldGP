void	SetNumeric_Func(int iDispOrder);
int	DrawNumeric_Func(int mode,_NUMERIC_EVENT_TBL* NumericEventTbl,int iDispOrder);
void	SetRealPos(int iSTemp, char *cImsiData,int iDigits);
void	NumericDispWatch(int iOrder);
