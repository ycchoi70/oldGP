/*** RealView Debugger common constant definitions for RVD ***
  /  
 / /
/ / /\
\\\/ /// CLABSYS
 \\ ///  Cyber Lab System
  \\//
   \/

Revision history___
2004-4-28 John.Yoon@clabsys.com
*/ 

#ifndef __RVD_H__
#define __RVD_H__
#define true	1
#define false 0
#define NO_ERR	0
#define ERROR	1

/*Define error code
*/
#define ERR_INIT	0xE100
#define ERR_ERASE	0xE101
#define ERR_FLASHWR_UNLOCK 0xE102
#define ERR_FLASHWR_LOCK 0xE103
#define ERR_FLASHWR_ERASE 0xE104
#define ERR_FLASHWR_WAIT	0xE105
#define ERR_FLASHWR_VALIDATE	0xE106
#define ERR_ERASE_UNLOCK 0xE107
#define ERR_ERASE_LOCK 0xE108
#define ERR_GETBUFFER 0xE109
#define ERR_FLASH_LOCKED 0xE10A
#define NULL	0


#define WIDTH_BYTE	0
#define WIDTH_HWORD 1
#define WIDTH_WORD	2

#endif //#ifndef __RVD_H__


