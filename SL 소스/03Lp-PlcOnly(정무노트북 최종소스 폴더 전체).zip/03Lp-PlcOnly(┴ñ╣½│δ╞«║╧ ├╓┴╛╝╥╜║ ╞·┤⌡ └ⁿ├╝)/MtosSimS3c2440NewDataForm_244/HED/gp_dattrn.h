void		vDataTrans(int* iScreenNo);
