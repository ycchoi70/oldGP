
#define     KEY_INTERVAL            50
#define     REPEAT_START            500
#define     REPEAT_CONT             300
#define     NOR_BUZZER_TIME         50
#define     ERR_BUZZER_TIME         500
#define     FLS_BUZZER_TIME_ON      40
#define     FLS_BUZZER_TIME_OFF     60
#define     FLS_SHORT_BUZZER_TIME   50


#define S_BUZ_OFF   0x01
#define S_BUZ_SHORT 0x02
#define S_BUZ_LONG  0x04
#define S_BUZ_FLS   0x08
#define S_BUZ_FLS2  0x10
#define S_BUZ_ALM0  0x20
#define S_BUZ_ALM1  0x40
#define S_BUZ_ALM2  0x80
#define S_BUZ_FLS3  0x100

#define S_BUZ_OFF_ELS  0x200           /* �A��??���ȊO�Œ�? 98.12.1 */

void    NormalBuzzer(void);
void    ErrorBuzzer(void);
void    StopBuzzer(void);
void    FlashBuzzer(void);
void    FlashBuzzer2(void);
void    AlarmBuzzer0(void);
void    AlarmBuzzer1(void);
void    AlarmBuzzer2(void);
void    FlashBuzzer3(void);
void    StopBuzzerElse(void);
int   KeyWait( _TOUCHKEY* pKey );
int   KeyAccept( _TOUCHKEY* pKey );
int	CheckReptKey(int x,int y);
void    KeyHand(STTFrm* pSTT );
void KeyGet( KEY_ADDR* pKeyData );
void    KeyDrv(STTFrm* pSTT);
void BuzDrv(STTFrm* pSTT);

