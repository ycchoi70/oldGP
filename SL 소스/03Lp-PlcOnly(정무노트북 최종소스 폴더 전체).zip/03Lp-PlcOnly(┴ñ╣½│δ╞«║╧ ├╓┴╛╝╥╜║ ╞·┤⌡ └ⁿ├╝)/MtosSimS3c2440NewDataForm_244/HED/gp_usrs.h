void		WindowScreenList(int* iScreenNo);
void		WindowScreenNumDisplay(int TLineCnt, int iStartNum);
void	vScreenDataSet(int mode);		//2012.02.10
int	Observe_ScreenSet(short	iScreenNum);
unsigned long NowBackColor(int iScreenNum);
void	vSysScreenDataSet(void);
