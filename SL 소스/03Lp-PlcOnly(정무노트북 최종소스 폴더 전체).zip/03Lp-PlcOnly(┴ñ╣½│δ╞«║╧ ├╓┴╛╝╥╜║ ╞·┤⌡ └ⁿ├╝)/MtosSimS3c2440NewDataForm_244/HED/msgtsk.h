
int	MakeFloat1Line(int idx);
