void	RtcInit(void);
void	SetSysTime( unsigned char *rtc_buf);
void    RtcHand( STTFrm* pSTT );         /* ���v�h���C�u�^�X�N */
void	DateTimeSet(RTC_DATA *SetTime,int rReset);
void	RTCRead(unsigned char *rtcbuf);
void	RTCWrite(unsigned char *rtcbuf,int rRest);
int	CheckDateTime(RTC_DATA *SetData);
