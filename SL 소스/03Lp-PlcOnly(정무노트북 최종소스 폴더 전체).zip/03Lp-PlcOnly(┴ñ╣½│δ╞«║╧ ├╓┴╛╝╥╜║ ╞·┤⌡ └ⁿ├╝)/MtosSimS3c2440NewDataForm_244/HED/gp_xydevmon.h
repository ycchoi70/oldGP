void		vXYDeviceMoni(int* iScreenNo);
