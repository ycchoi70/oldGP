
#define DISPLAY_WIDTH       800
#define DISPLAY_HEIGHT      480
#define DISPLAY_STRIDE      800

#define USB_IRQ_PORT    3       //GPG3
#define USB_nRST        10      //GPG10




#define VALIDSAMPLE_SHIFT               (4)
#define MAX_VALIDSAMPLE                 (1<<VALIDSAMPLE_SHIFT)

#define		TOUCH_DELTA_X		(GAMEN_X_SIZE/4)			
#define		TOUCH_DELTA_Y		((GAMEN_Y_SIZE/4)-20)			
#define		TOUCH_DELTA_X10		(GAMEN_X_SIZE/10)			
#define		TOUCH_DELTA_Y10		(GAMEN_Y_SIZE/10)
#define		TOUCH_2POS_X_LOW	(GAMEN_X_SIZE/2-100)
#define		TOUCH_2POS_X_HIGH	(GAMEN_X_SIZE/2+100)
#define		TOUCH_2POS_Y_LOW	(GAMEN_Y_SIZE/2-100)
#define		TOUCH_2POS_Y_HIGH	(GAMEN_Y_SIZE/2+100)

#define		TOUCH_DELTA_2X		30			
#define		TOUCH_DELTA_2Y		30			

//===========================================================================


//===========================================================================



#define TOUCH_SAMPLE_PREVIOUSDOWN       (1<<8)
#define TOUCH_SAMPLE_CALIBRATED         (1<<9)

#define TOUCH_SAMPLE_IGNORE             (1<<0)
#define TOUCH_SAMPLE_VALID              (1<<1)
#define TOUCH_SAMPLE_DOWN               (1<<2)

// for calibaration
#define     MAX_NCALIBRATION        (5)

// Scale factor to support sub-pixel resolutions
#define X_SCALE_FACTOR      4
#define Y_SCALE_FACTOR      4


#ifdef	TOUCH_PROC
	int       cXscr = -1;
	int       cYscr = -1;

	int       Xscr_prev = -1;
	int       Yscr_prev = -1;
	int       mXscr;
	int       mYscr;
	unsigned int      nValidSample;


	unsigned int   Smouse;
	unsigned int   UpDown;

	int	NonCalbX,NonCalbY;
	int	DigCalbX,DigCalbY;


	int	TouchRepeatFlag;

	//=====================================================================
	#define MAX_NCALIBRATION        (5)
	#define X_CAL_OFFSET            (DISPLAY_WIDTH/5)
	#define Y_CAL_OFFSET            (DISPLAY_HEIGHT/5)

	GLP_CAL_DATA	Cal_Data;
	TCAL_DATA	CalibData[2];
	TCAL_DATA	InCalibData[5];


	float	fDx1;
	float	fDy1;
	int	iDx1_b;
	int	iDy1_b;

	int	ScanStartX;
	int	ScanStartY;
	int	ScanBefX;
	int	ScanBefY;
	int	ScanCnt;
	int	KeyDat2PosFlag;
	int	KeyDat1stX;
	int	KeyDat1stY;
	int	KeyDat2ndX;
	int	KeyDat2ndY;

	int	KeyDat2PosMainFlag;

#else
	extern	int	NonCalbX,NonCalbY;
	extern	int	DigCalbX,DigCalbY;
	extern	int	TouchRepeatFlag;
	extern	int	KeyDat2PosFlag;
	extern	int	KeyDat1stX;
	extern	int	KeyDat1stY;
	extern	int	KeyDat2ndX;
	extern	int	KeyDat2ndY;

	extern	int	KeyDat2PosMainFlag;

	extern	GLP_CAL_DATA	Cal_Data;
	extern	TCAL_DATA	CalibData[2];
	extern	TCAL_DATA	InCalibData[5];
#endif


void	TouchInit( void );
void	Touch_SampleStart(void);
void	Touch_SampleStop(void);
int	GetAD_Power(int *adValue);
void	BacklightInitial(void);
void	TouchCalCheck(void);
