int	Hex2Bin(char *buff);
