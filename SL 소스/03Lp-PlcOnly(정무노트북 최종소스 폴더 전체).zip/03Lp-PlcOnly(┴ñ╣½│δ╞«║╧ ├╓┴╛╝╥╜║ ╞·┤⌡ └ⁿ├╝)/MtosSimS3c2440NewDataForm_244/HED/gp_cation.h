
#define	CATION_MESS_X	232
#define	CATION_MESS_Y	200

#ifdef	GP_CATION_PROC
#endif

extern	int	MakeTaginfo(int iScreenNo,unsigned char *cTagBuf,int *ipOffset,
						int *iLastTag,int iFilePointer,int *iLastTagFlag,int *iObjectSel,int iPos);


int		iCaptionWindow(char *chContent,char *chContent1);
int		iCaptionVerticalWindow(char *chContent,char *chContent1,char *chContent2,char *chContent3,char *chContent4);
void	vBoxInLine(int sX, int sY, int eX, int eY);
void	iScreenMess(char *chContent, char *chContent1, char *chContent2, char *chContent3, char *chContent4);
void	EnterCutting(char* strData);
void	EnterCuttingVctorString(int Cnt,char* strData);
int	getGamenIndx(int no);
void	CatReConfirmOkNg(void);
void	CatReConfirmOkNgInput(void);
int		iCaptionDetailWindow(char *chContent);
