void	SetEnvironmentMode(int *iScreenNo);
