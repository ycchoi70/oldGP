
#ifndef _UDC_TYPES_H_
#define _UDC_TYPES_H_

#include <types.h>

typedef struct _USB_DEVICE_REQUEST      USB_DEVICE_REQUEST;
typedef struct _USB_DEVICE_REQUEST *    PUSB_DEVICE_REQUEST;
struct _USB_DEVICE_REQUEST 
{
    BYTE        bmRequestType;
    BYTE        bRequest;
    UINT16      wValue;
    UINT16      wIndex;
    UINT16      wLength;
//}__attribute__ ((packed)) ;
};


// USB_DEVICE_REQUEST.bmRequestType bits for control Pipes
#define     USB_REQUEST_DEVICE_TO_HOST      0x80
#define     USB_REQUEST_HOST_TO_DEVICE      0x00
#define     USB_REQUEST_STANDARD            0x00
#define     USB_REQUEST_CLASS               0x20
#define     USB_REQUEST_VENDOR              0x40
#define     USB_REQUEST_RESERVED            0x60
#define     USB_REQUEST_FOR_DEVICE          0x00
#define     USB_REQUEST_FOR_INTERFACE       0x01
#define     USB_REQUEST_FOR_ENDPOINT        0x02
#define     USB_REQUEST_FOR_OTHER           0x03

// UFN Transfer Errors
#define     UFN_NO_ERROR                        0x00000000
#define     UFN_DEVICE_NOT_RESPONDING_ERROR     0x00000005
#define     UFN_CANCELED_ERROR                  0x00000101
#define     UFN_NOT_COMPLETE_ERROR              0x00000103
#define     UFN_CLIENT_BUFFER_ERROR             0x00000104


// UFN Events 
typedef enum _UFN_BUS_EVENT {
    UFN_DETACH = 0,
    UFN_ATTACH,
    UFN_RESET,
    UFN_SUSPEND,
    UFN_RESUME,
} UFN_BUS_EVENT, *PUFN_BUS_EVENT;


typedef enum _UFN_BUS_SPEED {
    BS_UNKNOWN_SPEED = 0,
    BS_FULL_SPEED = (1 << 0),
    BS_HIGH_SPEED = (1 << 1),
} UFN_BUS_SPEED, *PUFN_BUS_SPEED;

#define IS_VALID_SPEED(Speed) ( ((Speed) == BS_FULL_SPEED) || ((Speed) == BS_HIGH_SPEED) )


// Transfer flags.
#define USB_ENDPOINT_ADDRESS_IN     0x80
#define USB_ENDPOINT_ADDRESS_OUT    0x00


#define USB_FULL_HIGH_SPEED_CONTROL_MAX_PACKET_SIZE 0x040 // 64 bytes

#define USB_FULL_SPEED_CONTROL_MAX_PACKET_SIZE      0x040 // 64 bytes
#define USB_FULL_SPEED_BULK_MAX_PACKET_SIZE         0x040 // 64 bytes
#define USB_FULL_SPEED_INTERRUPT_MAX_PACKET_SIZE    0x040 // 64 bytes
#define USB_FULL_SPEED_ISOCHRONOUS_MAX_PACKET_SIZE  0x3FF // 1023 bytes

#define USB_HIGH_SPEED_CONTROL_MAX_PACKET_SIZE      0x040 // 64 bytes
#define USB_HIGH_SPEED_BULK_MAX_PACKET_SIZE         0x200 // 512 bytes
#define USB_HIGH_SPEED_INTERRUPT_MAX_PACKET_SIZE    0x400 // 1024 bytes
#define USB_HIGH_SPEED_ISOCHRONOUS_MAX_PACKET_SIZE  0x400 // 1024 bytes


// Messages sent to the notify routine.

// dwParam = UFN_BUS_EVENT
#define UFN_MSG_BUS_EVENTS                  1

// dwParam = wValue from the device request
#define UFN_MSG_CONFIGURED                  2

// dwParam = UFN_BUS_SPEED
#define UFN_MSG_BUS_SPEED                   3

// dwParam = PUSB_DEVICE_REQUEST
// This message is for setup packets that are not processed by the MDD.
// The client is responsible for sending the control status handshake.
#define UFN_MSG_SETUP_PACKET                4

// dwParam = PUSB_DEVICE_REQUEST
// This message is for setup packets that are processed by the MDD.
// The client must not send the control status handshake.
#define UFN_MSG_PREPROCESSED_SETUP_PACKET   5

// dwParam = the USB bus address
#define UFN_MSG_SET_ADDRESS                 6



// return codes
#define EXECUTE_PASS                        0x00000000
#define EXECUTE_FAIL                        0x00000001
#define EXECUTE_ERROR                       0x00000002


#endif // _UDC_TYPES_H_

