
/**********************************************************/
/*   �e������??���w�b??                               */
/***********************************************************/

unsigned int MakeCodeTblSum(unsigned short* src,int cnt);
int	Culc_Instruction_Set(unsigned short *Operand_Area,int cnt);
void	GlpDataClear(void);
int	CheckSendDateTime(RTC_DATA *SetData,int rReset);
int	GetGLPDevAddr(unsigned short *DevData,unsigned short**DevAddr);
#ifdef	WIN32
extern	int	AndTable[16];
#else
extern	const int	AndTable[16];
#endif
void	SetCulcError(void);

unsigned short	GetPatarnData(int ch,int PrnNo,int* idx);


//#define	CMP_EQ	0x0001
//#define	CMP_GT	0x0002
//#define	CMP_GTE	0x0004
//#define	CMP_LT	0x0008
//#define	CMP_LTE	0x0010
//#define	CMP_NE	0x0020
#define	CMP_EQ	0x0002
#define	CMP_GT	0x0004
#define	CMP_LT	0x0001
#define	CMP_NE	0x0008
#define	CMP_GTE	0x0010
#define	CMP_LTE	0x0020

#define	CMP_BGT1	0x0001
#define	CMP_BEQ1	0x0002
#define	CMP_BGT2	0x0004
#define	CMP_BEQ2	0x0008
#define	CMP_BGT3	0x0010



/* int Instruction_Label_Set(int pos) ; */
int Instruction_Number_Set(void) ;
//int	IsProcEnd(int pos);

void proc_LOAD(void);
void proc_LOADN(void);
void proc_LOADP(void);
void proc_LOADF(void);
void proc_MC_LOAD(void);
void proc_MC_LOADN(void);
void proc_MC_LOADP(void);
void proc_MC_LOADF(void);
                      
void proc_AND(void);
void proc_ANDN(void);
void proc_ANDP(void);
void proc_ANDF(void);
void proc_ANDL(void);
                      
void proc_OR(void);
void proc_ORN(void);
void proc_ORP(void);
void proc_ORF(void);
void proc_ORL(void);
void proc_MC_OR(void);
void proc_MC_ORN(void);
void proc_MC_ORP(void);
void proc_MC_ORF(void);

void proc_OUT(void);
void proc_OUTP(void);
void proc_OUTF(void);
void proc_SET(void);
void proc_RST(void);
void proc_ALT(void);
void proc_DF(void);
void proc_DFN(void);
void proc_DFI(void);
void proc_KEEP(void);
                      
void proc_MPUSH(void);
void proc_MLOAD(void);
void proc_MPOP(void);
void proc_NOT(void);
void proc_NOP(void);
void proc_END(void);


void proc_TON(void);
void proc_TOFF(void);
void proc_TMR(void);
void proc_TMON(void);
void proc_TRTG(void);
                      
void proc_CTU(void);
void proc_CTD(void);
void proc_CTUD(void);
void proc_CTR(void);
                      
void proc_MCS(void);
void proc_MCR(void);
void proc_JMP(void);
void proc_CALL(void);
void proc_LABEL(void);
                      
void proc_FCALL(void);
void proc_RET(void);
void proc_FOR(void);
void proc_NEXT(void);
void proc_BREK(void);

void proc_EI(void);
void proc_DI(void);
void proc_ETI(void);
void proc_EEI(void);
void proc_DTI(void);
void proc_DEI(void);
void proc_TINT(void);
void proc_EINT(void);
void proc_IRET(void);
void proc_STC(void);
void proc_CLC(void);
void proc_STOP(void);
void proc_EIN(void);
void proc_DIN(void);
void proc_WDT(void);
void proc_CEND(void);

void proc_LOADEQ(void);
void proc_LOADGT(void);
void proc_LOADLT(void);
void proc_LOADNE(void);
void proc_LOADLE(void);
void proc_LOADGE(void);
void proc_LOADDEQ(void);
void proc_LOADDGT(void);
void proc_LOADDLT(void);
void proc_LOADDNE(void);
void proc_LOADDLE(void);
void proc_LOADDGE(void);
void proc_MC_LOADEQ(void);
void proc_MC_LOADGT(void);
void proc_MC_LOADLT(void);
void proc_MC_LOADNE(void);
void proc_MC_LOADLE(void);
void proc_MC_LOADGE(void);
void proc_MC_LOADDEQ(void);
void proc_MC_LOADDGT(void);
void proc_MC_LOADDLT(void);
void proc_MC_LOADDNE(void);
void proc_MC_LOADDLE(void);
void proc_MC_LOADDGE(void);

void proc_ANDEQ(void);
void proc_ANDGT(void);
void proc_ANDLT(void);
void proc_ANDNE(void);
void proc_ANDLE(void);
void proc_ANDGE(void);
void proc_ANDDEQ(void);
void proc_ANDDGT(void);
void proc_ANDDLT(void);
void proc_ANDDNE(void);
void proc_ANDDLE(void);
void proc_ANDDGE(void);

void proc_OREQ(void);
void proc_ORGT(void);
void proc_ORLT(void);
void proc_ORNE(void);
void proc_ORLE(void);
void proc_ORGE(void);
void proc_ORDEQ(void);
void proc_ORDGT(void);
void proc_ORDLT(void);
void proc_ORDNE(void);
void proc_ORDLE(void);
void proc_ORDGE(void);
void proc_MC_OREQ(void);
void proc_MC_ORGT(void);
void proc_MC_ORLT(void);
void proc_MC_ORNE(void);
void proc_MC_ORLE(void);
void proc_MC_ORGE(void);
void proc_MC_ORDEQ(void);
void proc_MC_ORDGT(void);
void proc_MC_ORDLT(void);
void proc_MC_ORDNE(void);
void proc_MC_ORDLE(void);
void proc_MC_ORDGE(void);

void proc_CMP(void);		//CMP
void proc_DCMP(void);
void proc_ACMP(void);
void proc_CMPL(void);
void proc_DCMPL(void);
void proc_CMPG(void);
void proc_DCMPG(void);

void proc_BWCMP(void);		//BWCMP
void proc_DBWCMP(void);
void proc_BWCMPL(void);
void proc_DBWCMPL(void);
void proc_BWCMPG(void);
void proc_DBWCMPG(void);
void proc_BWCMPT(void);
void proc_DBWCMPT(void);

void proc_BMOV(void);		//MOV
void proc_MOV(void);
void proc_DMOV(void);
void proc_BMOVL(void);
void proc_MOVL(void);
void proc_DMOVL(void);
void proc_BMOVG(void);
void proc_MOVG(void);
void proc_DMOVG(void);
void proc_BMOVT(void);
void proc_MOVT(void);
void proc_DMOVT(void);

void proc_BCMOV(void);		//CMOV
void proc_CMOV(void);
void proc_DCMOV(void);
void proc_BCMOVL(void);
void proc_CMOVL(void);
void proc_DCMOVL(void);
void proc_BCMOVG(void);
void proc_CMOVG(void);
void proc_DCMOVG(void);
void proc_BCMOVT(void);
void proc_CMOVT(void);
void proc_DCMOVT(void);

void proc_XCH(void);
void proc_DXCH(void);
void proc_XCHG(void);
void proc_DXCHG(void);

void proc_SWP(void);
void proc_DSWP(void);
void proc_SWPL(void);
void proc_DSWPL(void);

void proc_NROR(void);
void proc_HROR(void);
void proc_ROR(void);
void proc_DROR(void);
void proc_NRORL(void);
void proc_HRORL(void);
void proc_RORL(void);
void proc_DRORL(void);

void proc_NROL(void);
void proc_HROL(void);
void proc_ROL(void);
void proc_DROL(void);
void proc_NROLL(void);
void proc_HROLL(void);
void proc_ROLL(void);
void proc_DROLL(void);

void proc_NRORC(void);
void proc_HRORC(void);
void proc_RORC(void);
void proc_DRORC(void);
void proc_NRORCL(void);
void proc_HRORCL(void);
void proc_RORCL(void);
void proc_DRORCL(void);

void proc_NROLC(void);
void proc_HROLC(void);
void proc_ROLC(void);
void proc_DROLC(void);
void proc_NROLCL(void);
void proc_HROLCL(void);
void proc_ROLCL(void);
void proc_DROLCL(void);

void proc_SFTR(void);
void proc_SFTL(void);
void proc_ASFTR(void);
void proc_ASFTL(void);
void proc_WSFTR(void);
void proc_WSFTL(void);
void proc_SFTWR(void);
void proc_SFTRD(void);

void proc_ADD(void);
void proc_DADD(void);
void proc_ADDU(void);
void proc_DADDU(void);
void proc_ADDL(void);
void proc_DADDL(void);
void proc_ADDUL(void);
void proc_DADDUL(void);
void proc_ADDG(void);
void proc_DADDG(void);
void proc_ADDUG(void);
void proc_DADDUG(void);
void proc_ADDT(void);
void proc_DADDT(void);
void proc_ADDUT(void);
void proc_DADDUT(void);

void proc_SUB(void);
void proc_DSUB(void);
void proc_SUBU(void);
void proc_DSUBU(void);
void proc_SUBL(void);
void proc_DSUBL(void);
void proc_SUBUL(void);
void proc_DSUBUL(void);
void proc_SUBG(void);
void proc_DSUBG(void);
void proc_SUBUG(void);
void proc_DSUBUG(void);
void proc_SUBT(void);
void proc_DSUBT(void);
void proc_SUBUT(void);
void proc_DSUBUT(void);

void proc_MUL(void);
void proc_DMUL(void);
void proc_MULU(void);
void proc_DMULU(void);
void proc_MULL(void);
void proc_DMULL(void);
void proc_MULUL(void);
void proc_DMULUL(void);
void proc_MULG(void);
void proc_DMULG(void);
void proc_MULUG(void);
void proc_DMULUG(void);
void proc_MULT(void);
void proc_DMULT(void);
void proc_MULUT(void);
void proc_DMULUT(void);

void proc_DIV(void);
void proc_DDIV(void);
void proc_DIVU(void);
void proc_DDIVU(void);
void proc_DIVL(void);
void proc_DDIVL(void);
void proc_DIVUL(void);
void proc_DDIVUL(void);
void proc_DIVG(void);
void proc_DDIVG(void);
void proc_DIVUG(void);
void proc_DDIVUG(void);
void proc_DIVT(void);
void proc_DDIVT(void);
void proc_DIVUT(void);
void proc_DDIVUT(void);

void proc_INC(void);
void proc_DINC(void);
void proc_INCL(void);
void proc_DINCL(void);
void proc_DEC(void);
void proc_DDEC(void);
void proc_DECL(void);
void proc_DDECL(void);

void proc_ADDB(void);
void proc_DADDB(void);
void proc_ADDBL(void);
void proc_DADDBL(void);
void proc_ADDBG(void);
void proc_DADDBG(void);

void proc_SUBB(void);
void proc_DSUBB(void);
void proc_SUBBL(void);
void proc_DSUBBL(void);
void proc_SUBBG(void);
void proc_DSUBBG(void);

void proc_MULB(void);
void proc_DMULB(void);
void proc_MULBL(void);
void proc_DMULBL(void);
void proc_MULBG(void);
void proc_DMULBG(void);

void proc_DIVB(void);
void proc_DDIVB(void);
void proc_DIVBL(void);
void proc_DDIVBL(void);
void proc_DIVBG(void);
void proc_DDIVBG(void);

void proc_INCB(void);
void proc_DINCB(void);
void proc_INCBL(void);
void proc_DINCBL(void);
void proc_DECB(void);
void proc_DDECB(void);
void proc_DECBL(void);
void proc_DDECBL(void);

void proc_WAND(void);
void proc_DWAND(void);
void proc_WANDL(void);
void proc_DWANDL(void);
void proc_WANDG(void);
void proc_DWANDG(void);

void proc_WOR(void);
void proc_DWOR(void);
void proc_WORL(void);
void proc_DWORL(void);
void proc_WORG(void);
void proc_DWORG(void);

void proc_WXOR(void);
void proc_DWXOR(void);
void proc_WXORL(void);
void proc_DWXORL(void);
void proc_WXORG(void);
void proc_DWXORG(void);

void proc_WXNR(void);
void proc_DWXNR(void);
void proc_WXNRL(void);
void proc_DWXNRL(void);
void proc_WXNRG(void);
void proc_DWXNRG(void);

void proc_MEAN(void);
void proc_SQR(void);
void proc_ABS(void);

void proc_BINBCD(void);
void proc_DBINBCD(void);
void proc_BCDBIN(void);
void proc_DBCDBIN(void);
void proc_BIN2HASC(void);
void proc_DBIN2HASC(void);
void proc_HASC2BIN(void);
void proc_DHASC2BIN(void);
void proc_HBCD2DASC(void);
void proc_DHBCD2DASC(void);
void proc_DASC2BCD(void);
void proc_DDASC2BCD(void);
void proc_BIN2DASC(void);
void proc_DBIN2DASC(void);
void proc_DASC2BIN(void);
void proc_DDASC2BIN(void);

void proc_STR2ASC(void);

void proc_DECO(void);
void proc_ENCO(void);
void proc_UNI(void);
void proc_DIS(void);
void proc_COLM(void);
void proc_ROW(void);
void proc_INV(void);
void proc_SRC(void);
void proc_BCC(void);
void proc_EXT(void);

void proc_BTS(void);
void proc_BTR(void);
void proc_BTI(void);
void proc_BTT(void);
void proc_BON(void);
void proc_SUM(void);

void proc_REF(void);

void proc_BSEG(void);
void proc_NSEG(void);
void proc_HSEG(void);
void proc_SEG(void);
void proc_DSEG(void);

void proc_BINGRY(void);
void proc_DBINGRY(void);
void proc_BINGRYL(void);
void proc_GRYBIN(void);
void proc_DGRYBIN(void);

void proc_NEG(void);
void proc_DNEG(void);
void proc_NEGL(void);
void proc_DNEGL(void);

void proc_TCMP(void);
void proc_TADD(void);
void proc_TSUB(void);
void proc_TRD(void);
void proc_TWR(void);
void proc_TOUR(void);
void proc_TZCP(void);
void proc_RAMP(void);
void proc_ABSD(void);
void proc_INCD(void);

void	proc_MTVDM(void);
void	proc_MTPDM(void);
void	proc_MTIDM(void);
void	proc_MTMEC(void);
void	proc_MTEMS(void);
void	proc_MTCPP(void);
void	proc_MTFOS(void);
void	proc_MTSRS(void);
void	proc_MTOBC(void);
void	proc_MTOVV(void);
void	proc_MTOVP(void);
void	proc_MTIPT(void);
void	proc_MTUAI(void);
////////////////////////////////////////////////////////////

int proc_getlen_NOP(int pos);
int proc_getlen_LOAD(int pos);
int proc_getlen_LOADN(int pos);
int proc_getlen_LOADP(int pos);
int proc_getlen_LOADF(int pos);
int proc_getlen_MC_LOAD(int pos);
int proc_getlen_MC_LOADN(int pos);
int proc_getlen_MC_LOADP(int pos);
int proc_getlen_MC_LOADF(int pos);
                      
int proc_getlen_AND(int pos);
int proc_getlen_ANDN(int pos);
int proc_getlen_ANDP(int pos);
int proc_getlen_ANDF(int pos);
int proc_getlen_ANDL(int pos);
                      
int proc_getlen_OR(int pos);
int proc_getlen_ORN(int pos);
int proc_getlen_ORP(int pos);
int proc_getlen_ORF(int pos);
int proc_getlen_MC_OR(int pos);
int proc_getlen_MC_ORN(int pos);
int proc_getlen_MC_ORP(int pos);
int proc_getlen_MC_ORF(int pos);

int proc_getlen_ORL(int pos);
int proc_getlen_OUT(int pos);
int proc_getlen_OUTP(int pos);
int proc_getlen_OUTF(int pos);
int proc_getlen_SET(int pos);
int proc_getlen_RST(int pos);
int proc_getlen_ALT(int pos);
int proc_getlen_DF(int pos);
int proc_getlen_DFN(int pos);
int proc_getlen_DFI(int pos);
int proc_getlen_KEEP(int pos);
                      
int proc_getlen_MPUSH(int pos);
int proc_getlen_MLOAD(int pos);
int proc_getlen_MPOP(int pos);
int proc_getlen_NOT(int pos);
int proc_getlen_NOP(int pos);
int proc_getlen_END(int pos);
                      
int proc_getlen_TON(int pos);
int proc_getlen_TOFF(int pos);
int proc_getlen_TMR(int pos);
int proc_getlen_TMON(int pos);
int proc_getlen_TRTG(int pos);
                      
int proc_getlen_CTU(int pos);
int proc_getlen_CTD(int pos);
int proc_getlen_CTUD(int pos);
int proc_getlen_CTR(int pos);
                      
int proc_getlen_MCS(int pos);
int proc_getlen_MCR(int pos);
int proc_getlen_JMP(int pos);
int proc_getlen_CALL(int pos);
int proc_getlen_LABEL(int pos);
                      
int proc_getlen_FCALL(int pos);
int proc_getlen_RET(int pos);
int proc_getlen_FOR(int pos);
int proc_getlen_NEXT(int pos);
int proc_getlen_BREK(int pos);
int proc_getlen_EI(int pos);
int proc_getlen_DI(int pos);
int proc_getlen_ETI(int pos);
int proc_getlen_EEI(int pos);
int proc_getlen_DTI(int pos);
int proc_getlen_DEI(int pos);
int proc_getlen_TINT(int pos);
int proc_getlen_EINT(int pos);
int proc_getlen_IRET(int pos);
int proc_getlen_STC(int pos);
int proc_getlen_CLC(int pos);
int proc_getlen_STOP(int pos);
int proc_getlen_EIN(int pos);
int proc_getlen_DIN(int pos);
int proc_getlen_WDT(int pos);
int proc_getlen_CEND(int pos);

int proc_getlen_LOADEQ(int pos);
int proc_getlen_LOADGT(int pos);
int proc_getlen_LOADLT(int pos);
int proc_getlen_LOADNE(int pos);
int proc_getlen_LOADLE(int pos);
int proc_getlen_LOADGE(int pos);
int proc_getlen_LOADDEQ(int pos);
int proc_getlen_LOADDGT(int pos);
int proc_getlen_LOADDLT(int pos);
int proc_getlen_LOADDNE(int pos);
int proc_getlen_LOADDLE(int pos);
int proc_getlen_LOADDGE(int pos);
int proc_getlen_MC_LOADEQ(int pos);
int proc_getlen_MC_LOADGT(int pos);
int proc_getlen_MC_LOADLT(int pos);
int proc_getlen_MC_LOADNE(int pos);
int proc_getlen_MC_LOADLE(int pos);
int proc_getlen_MC_LOADGE(int pos);
int proc_getlen_MC_LOADDEQ(int pos);
int proc_getlen_MC_LOADDGT(int pos);
int proc_getlen_MC_LOADDLT(int pos);
int proc_getlen_MC_LOADDNE(int pos);
int proc_getlen_MC_LOADDLE(int pos);
int proc_getlen_MC_LOADDGE(int pos);
int proc_getlen_ANDEQ(int pos);
int proc_getlen_ANDGT(int pos);
int proc_getlen_ANDLT(int pos);
int proc_getlen_ANDNE(int pos);
int proc_getlen_ANDLE(int pos);
int proc_getlen_ANDGE(int pos);
int proc_getlen_ANDDEQ(int pos);
int proc_getlen_ANDDGT(int pos);
int proc_getlen_ANDDLT(int pos);
int proc_getlen_ANDDNE(int pos);
int proc_getlen_ANDDLE(int pos);
int proc_getlen_ANDDGE(int pos);

int proc_getlen_OREQ(int pos);
int proc_getlen_ORGT(int pos);
int proc_getlen_ORLT(int pos);
int proc_getlen_ORNE(int pos);
int proc_getlen_ORLE(int pos);
int proc_getlen_ORGE(int pos);
int proc_getlen_ORDEQ(int pos);
int proc_getlen_ORDGT(int pos);
int proc_getlen_ORDLT(int pos);
int proc_getlen_ORDNE(int pos);
int proc_getlen_ORDLE(int pos);
int proc_getlen_ORDGE(int pos);
int proc_getlen_MC_OREQ(int pos);
int proc_getlen_MC_ORGT(int pos);
int proc_getlen_MC_ORLT(int pos);
int proc_getlen_MC_ORNE(int pos);
int proc_getlen_MC_ORLE(int pos);
int proc_getlen_MC_ORGE(int pos);
int proc_getlen_MC_ORDEQ(int pos);
int proc_getlen_MC_ORDGT(int pos);
int proc_getlen_MC_ORDLT(int pos);
int proc_getlen_MC_ORDNE(int pos);
int proc_getlen_MC_ORDLE(int pos);
int proc_getlen_MC_ORDGE(int pos);

int proc_getlen_CMP(int pos);
int proc_getlen_DCMP(int pos);
int proc_getlen_ACMP(int pos);
int proc_getlen_CMPL(int pos);
int proc_getlen_DCMPL(int pos);
int proc_getlen_CMPG(int pos);
int proc_getlen_DCMPG(int pos);
int proc_getlen_CMPP(int pos);
int proc_getlen_DCMPP(int pos);
int proc_getlen_CMPLP(int pos);
int proc_getlen_DCMPLP(int pos);
int proc_getlen_CMPGP(int pos);
int proc_getlen_DCMPGP(int pos);

int proc_getlen_BWCMP(int pos);
int proc_getlen_DBWCMP(int pos);
int proc_getlen_BWCMPL(int pos);
int proc_getlen_DBWCMPL(int pos);
int proc_getlen_BWCMPG(int pos);
int proc_getlen_DBWCMPG(int pos);
int proc_getlen_BWCMPT(int pos);
int proc_getlen_DBWCMPT(int pos);
int proc_getlen_BWCMPP(int pos);
int proc_getlen_DBWCMPP(int pos);
int proc_getlen_BWCMPLP(int pos);
int proc_getlen_DBWCMPLP(int pos);
int proc_getlen_BWCMPGP(int pos);
int proc_getlen_DBWCMPGP(int pos);
int proc_getlen_BWCMPTP(int pos);
int proc_getlen_DBWCMPTP(int pos);
//int proc_getlen_BLCMP(int pos);
//int proc_getlen_DBLCMP(int pos);
//int proc_getlen_GCMP(int pos);
//int proc_getlen_DGCMP(int pos);
int proc_getlen_BMOV(int pos);
int proc_getlen_MOV(int pos);
int proc_getlen_DMOV(int pos);
int proc_getlen_BMOVL(int pos);
int proc_getlen_MOVL(int pos);
int proc_getlen_DMOVL(int pos);
int proc_getlen_BMOVG(int pos);
int proc_getlen_MOVG(int pos);
int proc_getlen_DMOVG(int pos);
int proc_getlen_BMOVT(int pos);
int proc_getlen_MOVT(int pos);
int proc_getlen_DMOVT(int pos);
int proc_getlen_BMOVP(int pos);
int proc_getlen_MOVP(int pos);
int proc_getlen_DMOVP(int pos);
int proc_getlen_BMOVLP(int pos);
int proc_getlen_MOVLP(int pos);
int proc_getlen_DMOVLP(int pos);
int proc_getlen_BMOVGP(int pos);
int proc_getlen_MOVGP(int pos);
int proc_getlen_DMOVGP(int pos);
int proc_getlen_BMOVTP(int pos);
int proc_getlen_MOVTP(int pos);
int proc_getlen_DMOVTP(int pos);

int proc_getlen_BCMOV(int pos);
int proc_getlen_CMOV(int pos);
int proc_getlen_DCMOV(int pos);
int proc_getlen_BCMOVL(int pos);
int proc_getlen_CMOVL(int pos);
int proc_getlen_DCMOVL(int pos);
int proc_getlen_BCMOVG(int pos);
int proc_getlen_CMOVG(int pos);
int proc_getlen_DCMOVG(int pos);
int proc_getlen_BCMOVT(int pos);
int proc_getlen_CMOVT(int pos);
int proc_getlen_DCMOVT(int pos);
int proc_getlen_BCMOVP(int pos);
int proc_getlen_CMOVP(int pos);
int proc_getlen_DCMOVP(int pos);
int proc_getlen_BCMOVLP(int pos);
int proc_getlen_CMOVLP(int pos);
int proc_getlen_DCMOVLP(int pos);
int proc_getlen_BCMOVGP(int pos);
int proc_getlen_CMOVGP(int pos);
int proc_getlen_DCMOVGP(int pos);
int proc_getlen_BCMOVTP(int pos);
int proc_getlen_CMOVTP(int pos);
int proc_getlen_DCMOVTP(int pos);

//int proc_getlen_BMOVG(int pos);
//int proc_getlen_DBMOVG(int pos);
//int proc_getlen_MOVG(int pos);
//int proc_getlen_DMOVG(int pos);
//int proc_getlen_MOVL(int pos);
//int proc_getlen_DMOVL(int pos);
int proc_getlen_XCH(int pos);
int proc_getlen_DXCH(int pos);
int proc_getlen_XCHG(int pos);
int proc_getlen_DXCHG(int pos);
int proc_getlen_XCHP(int pos);
int proc_getlen_DXCHP(int pos);
int proc_getlen_XCHGP(int pos);
int proc_getlen_DXCHGP(int pos);

//int proc_getlen_BXCH(int pos);
//int proc_getlen_DBXCH(int pos);
int proc_getlen_SWP(int pos);
int proc_getlen_DSWP(int pos);
int proc_getlen_SWPL(int pos);
int proc_getlen_DSWPL(int pos);
int proc_getlen_SWPP(int pos);
int proc_getlen_DSWPP(int pos);
int proc_getlen_SWPLP(int pos);
int proc_getlen_DSWPLP(int pos);

int proc_getlen_NROR(int pos);
int proc_getlen_HROR(int pos);
int proc_getlen_ROR(int pos);
int proc_getlen_DROR(int pos);
int proc_getlen_NRORL(int pos);
int proc_getlen_HRORL(int pos);
int proc_getlen_RORL(int pos);
int proc_getlen_DRORL(int pos);
int proc_getlen_NRORP(int pos);
int proc_getlen_HRORP(int pos);
int proc_getlen_RORP(int pos);
int proc_getlen_DRORP(int pos);
int proc_getlen_NRORLP(int pos);
int proc_getlen_HRORLP(int pos);
int proc_getlen_RORLP(int pos);
int proc_getlen_DRORLP(int pos);
int proc_getlen_NRORC(int pos);
int proc_getlen_HRORC(int pos);
int proc_getlen_RORC(int pos);
int proc_getlen_DRORC(int pos);
int proc_getlen_NRORCL(int pos);
int proc_getlen_HRORCL(int pos);
int proc_getlen_RORCL(int pos);
int proc_getlen_DRORCL(int pos);
int proc_getlen_NRORCP(int pos);
int proc_getlen_HRORCP(int pos);
int proc_getlen_RORCP(int pos);
int proc_getlen_DRORCP(int pos);
int proc_getlen_NRORCLP(int pos);
int proc_getlen_HRORCLP(int pos);
int proc_getlen_RORCLP(int pos);
int proc_getlen_DRORCLP(int pos);

int proc_getlen_NROL(int pos);
int proc_getlen_HROL(int pos);
int proc_getlen_ROL(int pos);
int proc_getlen_DROL(int pos);
int proc_getlen_NROLL(int pos);
int proc_getlen_HROLL(int pos);
int proc_getlen_ROLL(int pos);
int proc_getlen_DROLL(int pos);
int proc_getlen_NROLP(int pos);
int proc_getlen_HROLP(int pos);
int proc_getlen_ROLP(int pos);
int proc_getlen_DROLP(int pos);
int proc_getlen_NROLLP(int pos);
int proc_getlen_HROLLP(int pos);
int proc_getlen_ROLLP(int pos);
int proc_getlen_DROLLP(int pos);
int proc_getlen_NROLC(int pos);
int proc_getlen_HROLC(int pos);
int proc_getlen_ROLC(int pos);
int proc_getlen_DROLC(int pos);
int proc_getlen_NROLCL(int pos);
int proc_getlen_HROLCL(int pos);
int proc_getlen_ROLCL(int pos);
int proc_getlen_DROLCL(int pos);
int proc_getlen_NROLCP(int pos);
int proc_getlen_HROLCP(int pos);
int proc_getlen_ROLCP(int pos);
int proc_getlen_DROLCP(int pos);
int proc_getlen_NROLCLP(int pos);
int proc_getlen_HROLCLP(int pos);
int proc_getlen_ROLCLP(int pos);
int proc_getlen_DROLCLP(int pos);

int proc_getlen_NRCL(int pos);
int proc_getlen_HRCL(int pos);
int proc_getlen_RCL(int pos);
int proc_getlen_DRCL(int pos);
int proc_getlen_NRCLL(int pos);
int proc_getlen_HRCLL(int pos);
int proc_getlen_RCLL(int pos);
int proc_getlen_DRCLL(int pos);
int proc_getlen_NRCLP(int pos);
int proc_getlen_HRCLP(int pos);
int proc_getlen_RCLP(int pos);
int proc_getlen_DRCLP(int pos);
int proc_getlen_NRCLLP(int pos);
int proc_getlen_HRCLLP(int pos);
int proc_getlen_RCLLP(int pos);
int proc_getlen_DRCLLP(int pos);

int proc_getlen_SFTR(int pos);
int proc_getlen_SFTL(int pos);
int proc_getlen_ASFTR(int pos);
int proc_getlen_ASFTL(int pos);
int proc_getlen_WSFTR(int pos);
int proc_getlen_WSFTL(int pos);
int proc_getlen_SFTWR(int pos);
int proc_getlen_SFTRD(int pos);

int proc_getlen_ADD(int pos);
int proc_getlen_DADD(int pos);
int proc_getlen_ADDU(int pos);
int proc_getlen_DADDU(int pos);
int proc_getlen_ADDL(int pos);
int proc_getlen_DADDL(int pos);
int proc_getlen_ADDUL(int pos);
int proc_getlen_DADDUL(int pos);
int proc_getlen_ADDG(int pos);
int proc_getlen_DADDG(int pos);
int proc_getlen_ADDUG(int pos);
int proc_getlen_DADDUG(int pos);
int proc_getlen_ADDT(int pos);
int proc_getlen_DADDT(int pos);
int proc_getlen_ADDUT(int pos);
int proc_getlen_DADDUT(int pos);
int proc_getlen_ADDP(int pos);
int proc_getlen_DADDP(int pos);
int proc_getlen_ADDUP(int pos);
int proc_getlen_DADDUP(int pos);
int proc_getlen_ADDLP(int pos);
int proc_getlen_DADDLP(int pos);
int proc_getlen_ADDULP(int pos);
int proc_getlen_DADDULP(int pos);
int proc_getlen_ADDGP(int pos);
int proc_getlen_DADDGP(int pos);
int proc_getlen_ADDUGP(int pos);
int proc_getlen_DADDUGP(int pos);
int proc_getlen_ADDTP(int pos);
int proc_getlen_DADDTP(int pos);
int proc_getlen_ADDUTP(int pos);
int proc_getlen_DADDUTP(int pos);

int proc_getlen_SUB(int pos);
int proc_getlen_DSUB(int pos);
int proc_getlen_SUBU(int pos);
int proc_getlen_DSUBU(int pos);
int proc_getlen_SUBL(int pos);
int proc_getlen_DSUBL(int pos);
int proc_getlen_SUBUL(int pos);
int proc_getlen_DSUBUL(int pos);
int proc_getlen_SUBG(int pos);
int proc_getlen_DSUBG(int pos);
int proc_getlen_SUBUG(int pos);
int proc_getlen_DSUBUG(int pos);
int proc_getlen_SUBT(int pos);
int proc_getlen_DSUBT(int pos);
int proc_getlen_SUBUT(int pos);
int proc_getlen_DSUBUT(int pos);
int proc_getlen_SUBP(int pos);
int proc_getlen_DSUBP(int pos);
int proc_getlen_SUBUP(int pos);
int proc_getlen_DSUBUP(int pos);
int proc_getlen_SUBLP(int pos);
int proc_getlen_DSUBLP(int pos);
int proc_getlen_SUBULP(int pos);
int proc_getlen_DSUBULP(int pos);
int proc_getlen_SUBGP(int pos);
int proc_getlen_DSUBGP(int pos);
int proc_getlen_SUBUGP(int pos);
int proc_getlen_DSUBUGP(int pos);
int proc_getlen_SUBTP(int pos);
int proc_getlen_DSUBTP(int pos);
int proc_getlen_SUBUTP(int pos);
int proc_getlen_DSUBUTP(int pos);

int proc_getlen_MUL(int pos);
int proc_getlen_DMUL(int pos);
int proc_getlen_MULU(int pos);
int proc_getlen_DMULU(int pos);
int proc_getlen_MULL(int pos);
int proc_getlen_DMULL(int pos);
int proc_getlen_MULUL(int pos);
int proc_getlen_DMULUL(int pos);
int proc_getlen_MULG(int pos);
int proc_getlen_DMULG(int pos);
int proc_getlen_MULUG(int pos);
int proc_getlen_DMULUG(int pos);
int proc_getlen_MULT(int pos);
int proc_getlen_DMULT(int pos);
int proc_getlen_MULUT(int pos);
int proc_getlen_DMULUT(int pos);
int proc_getlen_MULP(int pos);
int proc_getlen_DMULP(int pos);
int proc_getlen_MULUP(int pos);
int proc_getlen_DMULUP(int pos);
int proc_getlen_MULLP(int pos);
int proc_getlen_DMULLP(int pos);
int proc_getlen_MULULP(int pos);
int proc_getlen_DMULULP(int pos);
int proc_getlen_MULGP(int pos);
int proc_getlen_DMULGP(int pos);
int proc_getlen_MULUGP(int pos);
int proc_getlen_DMULUGP(int pos);
int proc_getlen_MULTP(int pos);
int proc_getlen_DMULTP(int pos);
int proc_getlen_MULUTP(int pos);
int proc_getlen_DMULUTP(int pos);

int proc_getlen_DIV(int pos);
int proc_getlen_DDIV(int pos);
int proc_getlen_DIVU(int pos);
int proc_getlen_DDIVU(int pos);
int proc_getlen_DIVL(int pos);
int proc_getlen_DDIVL(int pos);
int proc_getlen_DIVUL(int pos);
int proc_getlen_DDIVUL(int pos);
int proc_getlen_DIVG(int pos);
int proc_getlen_DDIVG(int pos);
int proc_getlen_DIVUG(int pos);
int proc_getlen_DDIVUG(int pos);
int proc_getlen_DIVT(int pos);
int proc_getlen_DDIVT(int pos);
int proc_getlen_DIVUT(int pos);
int proc_getlen_DDIVUT(int pos);
int proc_getlen_DIVP(int pos);
int proc_getlen_DDIVP(int pos);
int proc_getlen_DIVUP(int pos);
int proc_getlen_DDIVUP(int pos);
int proc_getlen_DIVLP(int pos);
int proc_getlen_DDIVLP(int pos);
int proc_getlen_DIVULP(int pos);
int proc_getlen_DDIVULP(int pos);
int proc_getlen_DIVGP(int pos);
int proc_getlen_DDIVGP(int pos);
int proc_getlen_DIVUGP(int pos);
int proc_getlen_DDIVUGP(int pos);
int proc_getlen_DIVTP(int pos);
int proc_getlen_DDIVTP(int pos);
int proc_getlen_DIVUTP(int pos);
int proc_getlen_DDIVUTP(int pos);

int proc_getlen_INC(int pos);
int proc_getlen_DINC(int pos);
int proc_getlen_INCL(int pos);
int proc_getlen_DINCL(int pos);
int proc_getlen_INCP(int pos);
int proc_getlen_DINCP(int pos);
int proc_getlen_INCLP(int pos);
int proc_getlen_DINCLP(int pos);
int proc_getlen_DEC(int pos);
int proc_getlen_DDEC(int pos);
int proc_getlen_DECL(int pos);
int proc_getlen_DDECL(int pos);
int proc_getlen_DECP(int pos);
int proc_getlen_DDECP(int pos);
int proc_getlen_DECLP(int pos);
int proc_getlen_DDECLP(int pos);

int proc_getlen_ADDB(int pos);
int proc_getlen_DADDB(int pos);
int proc_getlen_ADDBL(int pos);
int proc_getlen_DADDBL(int pos);
int proc_getlen_ADDBG(int pos);
int proc_getlen_DADDBG(int pos);
int proc_getlen_ADDBT(int pos);
int proc_getlen_DADDBT(int pos);
int proc_getlen_ADDBP(int pos);
int proc_getlen_DADDBP(int pos);
int proc_getlen_ADDBLP(int pos);
int proc_getlen_DADDBLP(int pos);
int proc_getlen_ADDBGP(int pos);
int proc_getlen_DADDBGP(int pos);
int proc_getlen_ADDBTP(int pos);
int proc_getlen_DADDBTP(int pos);

int proc_getlen_SUBB(int pos);
int proc_getlen_DSUBB(int pos);
int proc_getlen_SUBBL(int pos);
int proc_getlen_DSUBBL(int pos);
int proc_getlen_SUBBG(int pos);
int proc_getlen_DSUBBG(int pos);
int proc_getlen_SUBBT(int pos);
int proc_getlen_DSUBBT(int pos);
int proc_getlen_SUBBP(int pos);
int proc_getlen_DSUBBP(int pos);
int proc_getlen_SUBBLP(int pos);
int proc_getlen_DSUBBLP(int pos);
int proc_getlen_SUBBGP(int pos);
int proc_getlen_DSUBBGP(int pos);
int proc_getlen_SUBBTP(int pos);
int proc_getlen_DSUBBTP(int pos);

int proc_getlen_MULB(int pos);
int proc_getlen_DMULB(int pos);
int proc_getlen_MULBL(int pos);
int proc_getlen_DMULBL(int pos);
int proc_getlen_MULBG(int pos);
int proc_getlen_DMULBG(int pos);
int proc_getlen_MULBT(int pos);
int proc_getlen_DMULBT(int pos);
int proc_getlen_MULBP(int pos);
int proc_getlen_DMULBP(int pos);
int proc_getlen_MULBLP(int pos);
int proc_getlen_DMULBLP(int pos);
int proc_getlen_MULBGP(int pos);
int proc_getlen_DMULBGP(int pos);
int proc_getlen_MULBTP(int pos);
int proc_getlen_DMULBTP(int pos);

int proc_getlen_DIVB(int pos);
int proc_getlen_DDIVB(int pos);
int proc_getlen_DIVBL(int pos);
int proc_getlen_DDIVBL(int pos);
int proc_getlen_DIVBG(int pos);
int proc_getlen_DDIVBG(int pos);
int proc_getlen_DIVBT(int pos);
int proc_getlen_DDIVBT(int pos);
int proc_getlen_DIVBP(int pos);
int proc_getlen_DDIVBP(int pos);
int proc_getlen_DIVBLP(int pos);
int proc_getlen_DDIVBLP(int pos);
int proc_getlen_DIVBGP(int pos);
int proc_getlen_DDIVBGP(int pos);
int proc_getlen_DIVBTP(int pos);
int proc_getlen_DDIVBTP(int pos);

int proc_getlen_INCB(int pos);
int proc_getlen_DINCB(int pos);
int proc_getlen_INCBL(int pos);
int proc_getlen_DINCBL(int pos);
int proc_getlen_INCBP(int pos);
int proc_getlen_DINCBP(int pos);
int proc_getlen_INCBLP(int pos);
int proc_getlen_DINCBLP(int pos);

int proc_getlen_DECB(int pos);
int proc_getlen_DDECB(int pos);
int proc_getlen_DECBL(int pos);
int proc_getlen_DDECBL(int pos);
int proc_getlen_DECBP(int pos);
int proc_getlen_DDECBP(int pos);
int proc_getlen_DECBLP(int pos);
int proc_getlen_DDECBLP(int pos);

int proc_getlen_WAND(int pos);
int proc_getlen_DWAND(int pos);
int proc_getlen_WANDL(int pos);
int proc_getlen_DWANDL(int pos);
int proc_getlen_WANDG(int pos);
int proc_getlen_DWANDG(int pos);
int proc_getlen_WANDT(int pos);
int proc_getlen_DWANDT(int pos);
int proc_getlen_WANDP(int pos);
int proc_getlen_DWANDP(int pos);
int proc_getlen_WANDLP(int pos);
int proc_getlen_DWANDLP(int pos);
int proc_getlen_WANDGP(int pos);
int proc_getlen_DWANDGP(int pos);
int proc_getlen_WANDTP(int pos);
int proc_getlen_DWANDTP(int pos);

int proc_getlen_WOR(int pos);
int proc_getlen_DWOR(int pos);
int proc_getlen_WORL(int pos);
int proc_getlen_DWORL(int pos);
int proc_getlen_WORG(int pos);
int proc_getlen_DWORG(int pos);
int proc_getlen_WORT(int pos);
int proc_getlen_DWORT(int pos);
int proc_getlen_WORP(int pos);
int proc_getlen_DWORP(int pos);
int proc_getlen_WORLP(int pos);
int proc_getlen_DWORLP(int pos);
int proc_getlen_WORGP(int pos);
int proc_getlen_DWORGP(int pos);
int proc_getlen_WORTP(int pos);
int proc_getlen_DWORTP(int pos);

int proc_getlen_WXOR(int pos);
int proc_getlen_DWXOR(int pos);
int proc_getlen_WXORL(int pos);
int proc_getlen_DWXORL(int pos);
int proc_getlen_WXORG(int pos);
int proc_getlen_DWXORG(int pos);
int proc_getlen_WXORT(int pos);
int proc_getlen_DWXORT(int pos);
int proc_getlen_WXORP(int pos);
int proc_getlen_DWXORP(int pos);
int proc_getlen_WXORLP(int pos);
int proc_getlen_DWXORLP(int pos);
int proc_getlen_WXORGP(int pos);
int proc_getlen_DWXORGP(int pos);
int proc_getlen_WXORTP(int pos);
int proc_getlen_DWXORTP(int pos);

int proc_getlen_WXNR(int pos);
int proc_getlen_DWXNR(int pos);
int proc_getlen_WXNRL(int pos);
int proc_getlen_DWXNRL(int pos);
int proc_getlen_WXNRG(int pos);
int proc_getlen_DWXNRG(int pos);
int proc_getlen_WXNRT(int pos);
int proc_getlen_DWXNRT(int pos);
int proc_getlen_WXNRP(int pos);
int proc_getlen_DWXNRP(int pos);
int proc_getlen_WXNRLP(int pos);
int proc_getlen_DWXNRLP(int pos);
int proc_getlen_WXNRGP(int pos);
int proc_getlen_DWXNRGP(int pos);
int proc_getlen_WXNRTP(int pos);
int proc_getlen_DWXNRTP(int pos);

int proc_getlen_MEAN(int pos);
int proc_getlen_SQR(int pos);
int proc_getlen_ABS(int pos);

int proc_getlen_BINBCD(int pos);
int proc_getlen_DBINBCD(int pos);

int proc_getlen_BCDBIN(int pos);
int proc_getlen_DBCDBIN(int pos);

int proc_getlen_BIN2HASC(int pos);
int proc_getlen_DBIN2HASC(int pos);
int proc_getlen_BIN2HASCL(int pos);
int proc_getlen_DBIN2HASCL(int pos);

int proc_getlen_HASC2BIN(int pos);
int proc_getlen_DHASC2BIN(int pos);
int proc_getlen_HASC2BINL(int pos);
int proc_getlen_DHASC2BINL(int pos);

int proc_getlen_HBCD2DASC(int pos);
int proc_getlen_DHBCD2DASC(int pos);
int proc_getlen_HBCD2DASCL(int pos);
int proc_getlen_DHBCD2DASCL(int pos);

int	proc_getlen_DASC2BCD(int pos);
int	proc_getlen_DDASC2BCD(int pos);
int	proc_getlen_DASC2BCDL(int pos);
int	proc_getlen_DDASC2BCDL(int pos);

int proc_getlen_BIN2DASC(int pos);
int proc_getlen_DBIN2DASC(int pos);
int proc_getlen_BIN2DASCL(int pos);
int proc_getlen_DBIN2DASCL(int pos);

int proc_getlen_DASC2BIN(int pos);
int proc_getlen_DDASC2BIN(int pos);
int proc_getlen_DASC2BINL(int pos);
int proc_getlen_DDASC2BINL(int pos);

int proc_getlen_STR2ASC	(int pos);


int proc_getlen_DECO(int pos);
int proc_getlen_ENCO(int pos);
int proc_getlen_UNI(int pos);
int proc_getlen_DIS(int pos);
int proc_getlen_COLM(int pos);
int proc_getlen_ROW(int pos);
int proc_getlen_INV(int pos);
int proc_getlen_SRC(int pos);
int proc_getlen_BCC(int pos);
int proc_getlen_EXT(int pos);

int proc_getlen_BTS(int pos);
int proc_getlen_BTR(int pos);
int proc_getlen_BTI(int pos);
int proc_getlen_BTT(int pos);
int proc_getlen_BON(int pos);
int proc_getlen_SUM(int pos);

int proc_getlen_REF(int pos);

int proc_getlen_BSEG(int pos);
int proc_getlen_NSEG(int pos);
int proc_getlen_HSEG(int pos);
int proc_getlen_SEG(int pos);
int proc_getlen_DSEG(int pos);


int proc_getlen_BINGRY(int pos);
int proc_getlen_DBINGRY(int pos);
int proc_getlen_BINGRYL(int pos);
int proc_getlen_DBINGRYL(int pos);
int proc_getlen_GRYBIN(int pos);
int proc_getlen_DGRYBIN(int pos);
int proc_getlen_GRYBINL(int pos);
int proc_getlen_DGRYBINL(int pos);

int proc_getlen_NEG(int pos);
int proc_getlen_DNEG(int pos);
int proc_getlen_NEGL(int pos);
int proc_getlen_DNEGL(int pos);

int proc_getlen_TCMP(int pos);
int proc_getlen_TADD(int pos);
int proc_getlen_TSUB(int pos);
int proc_getlen_TRD(int pos);
int proc_getlen_TWR(int pos);
int proc_getlen_TOUR(int pos);
int proc_getlen_TZCP(int pos);
int proc_getlen_RAMP(int pos);
int proc_getlen_ABSD(int pos);
int proc_getlen_INCD(int pos);

void	DiIo00(int no);
void	EiIo00(int no);
void	DiTimer(int no);
void	EiTimer(int no);
void	DiPlcInt(void);
void	EiPlcInt(void);
int	Get16Bit(unsigned short data);
void	SetExtIntrrupt(void);

int	GetBin_DevInfo(unsigned char DeviceName,unsigned short **DataAddr,int *idx);
int	RsDevClear(char *buff);
unsigned short*	GetDevAddr(int code);

int	DbugDevB(unsigned short*DBCodeData);
int	DbugDevBB(unsigned short*DBCodeData);
int	DbugDevBBC(unsigned short*DBCodeData);
int	DbugDevBBCC(unsigned short*DBCodeData);
int	DbugDevBBBC(unsigned short*DBCodeData);
int	DbugDevW(unsigned short*DBCodeData);
int	DbugDevWC(unsigned short*DBCodeData);
int	DbugDevWCC(unsigned short*DBCodeData);
int	DbugDevWW(unsigned short*DBCodeData);
int	DbugDevCC(unsigned short*DBCodeData);
int	DbugDevBC(unsigned short*DBCodeData);
int	DbugDevBCC(unsigned short*DBCodeData);
int	DbugDevCW(unsigned short*DBCodeData);
int	DbugDevCWB(unsigned short*DBCodeData);
int	DbugDevCCB(unsigned short*DBCodeData);
int	DbugDevCCBC(unsigned short*DBCodeData);
int	DbugDevCBC(unsigned short*DBCodeData);
int	DbugDevCCW(unsigned short*DBCodeData);
int	DbugDevCCWC(unsigned short*DBCodeData);
int	DbugDevCCWCC(unsigned short*DBCodeData);
int	DbugDevWWC(unsigned short*DBCodeData);
int	DbugDevWWW(unsigned short*DBCodeData);
int	DbugDevCWC(unsigned short*DBCodeData);
int	DbugDevCWCC(unsigned short*DBCodeData);
int	DbugDevCCCB(unsigned short*DBCodeData);
int	DbugDevCCCBC(unsigned short*DBCodeData);
int	DbugDevCCCBCC(unsigned short*DBCodeData);
int	DbugDevWWCB(unsigned short*DBCodeData);
int	DbugDevWWCC(unsigned short*DBCodeData);
int	DbugDevWCWC(unsigned short*DBCodeData);
int	DbugDevWWB(unsigned short*DBCodeData);
int	DbugDevWWWB(unsigned short*DBCodeData);
int	DbugDevCCCWB(unsigned short*DBCodeData);

int	DbugDevCBCCCC(unsigned short*DBCodeData);
int	DbugDevCCCCCC(unsigned short*DBCodeData);
int	DbugDevCCCC(unsigned short*DBCodeData);
int	DbugDevC(unsigned short*DBCodeData);

//Add Routine
void proc_TTMR(void);
void proc_STMR(void);
void proc_AXCH(void);
void proc_AROR(void);
void proc_ARORC(void);
void proc_AROL(void);
void proc_AROLC(void);
void proc_AWAND(void);
void proc_AWOR(void);
void proc_AWXOR(void);
void proc_AWXNR(void);
//
int proc_getlen_TTMR(int pos);
int proc_getlen_STMR(int pos);
int proc_getlen_DXCH(int pos);
int proc_getlen_AXCH(int pos);
int proc_getlen_AROR(int pos);
int proc_getlen_ARORC(int pos);
int proc_getlen_AROL(int pos);
int proc_getlen_AROLC	(int pos);
int proc_getlen_AWAND	(int pos);
int proc_getlen_AWOR	(int pos);
int proc_getlen_AWXOR	(int pos);
int proc_getlen_AWXNR	(int pos);

unsigned short	Change16(int data);
int	DeviceCode2Name(int code, char** Name);
unsigned short BINtoBCD16(unsigned short bin_data);

int	proc_getlen_MTVDM	(int pos);
int	proc_getlen_MTPDM	(int pos);
int	proc_getlen_MTIDM	(int pos);
int	proc_getlen_MTMEC	(int pos);
int	proc_getlen_MTEMS	(int pos);
int	proc_getlen_MTCPP	(int pos);
int	proc_getlen_MTFOS	(int pos);
int	proc_getlen_MTSRS	(int pos);
int	proc_getlen_MTOBC	(int pos);
int	proc_getlen_MTOVV	(int pos);
int	proc_getlen_MTOVP	(int pos);
int	proc_getlen_MTIPT	(int pos);
int	proc_getlen_MTUAI	(int pos);

void	SetMotionError(int ch, int errBit,int no);
int	CheckPosition(int ch,int pos);
int CheckMovingFlt(int ch);
