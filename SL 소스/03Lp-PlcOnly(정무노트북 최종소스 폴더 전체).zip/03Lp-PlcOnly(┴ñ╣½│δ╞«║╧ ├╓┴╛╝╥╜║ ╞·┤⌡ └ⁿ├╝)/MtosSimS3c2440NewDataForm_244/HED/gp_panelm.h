void	SetPanel_Func(int iDispOrder);
int	DrawPanel_Func(int mode,_PANEL_METER_EVENT_TBL* PanelMeterEventTbl,int iDispOrder);
void	PanelMeterDispWatch(int iOrder);
int	GetIntData(unsigned int *pdataAddr,unsigned char *buffer);
int	GetuShortData(unsigned int *pdataAddr,unsigned char *buffer);
int	GetColorData(unsigned long *pdataAddr,unsigned char *buffer);
