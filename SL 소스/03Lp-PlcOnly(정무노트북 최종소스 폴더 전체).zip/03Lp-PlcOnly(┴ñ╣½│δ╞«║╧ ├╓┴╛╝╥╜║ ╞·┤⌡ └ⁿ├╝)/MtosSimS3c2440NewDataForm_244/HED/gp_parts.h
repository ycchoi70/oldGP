void	SetParts_Func(int iDispOrder);
int DrawParts_Func(int mode,_PARTS_EVENT_TBL* partsDispEventTbl,int iDispOrder);
void PartsDispWatch(int iOrder);
void vPartDataSet(int sX,int sY,int eX,int eY, int iNum, int iOrder, short iType, long iColor);
void TagPartsDisp(char* cPartsBuff, int sX, int sY, int eX, int eY, int iPartsDataNo, int iTagEventNo, int iType, int iColor);
int	PartsAnal_Task(int iNum,char* cPartDataBuffer);
