void	vLcdContSetDisp(int* iScreenNo);
int iKeyReturn(int itype);
int iKeyAcceptReturn(int itype);
