/************************************************************/

#define	ERR_BCC		0x01	/* BCC ERROR */
#define	ERR_FILE	0x02	/* File Error */
/************************************************/
/*	�ʐM?�C?�A�E�g�iEditor�j					*/
#define	EDIT_TIME_OUT	15000			/* 15S */
#define	EDIT_DWLD_OUT	15000			/* 15S */

#define	FILE_PROJECT		0
#define	FILE_COMMON			1
#define	FILE_COMMENT		2
#define	FILE_PARTS			3
#define	FILE_BASE			4
#define	FILE_WIND			5
#define	FILE_IMAGE_SCR		6
#define	FILE_IMAGE			7
#define	FILE_VECT_FNT		8
#define	FILE_COMMENT_UNI	9

#define	COMM_MODE_NONE				0
#define	COMM_MODE_DOWNLOAD			1
#define	COMM_MODE_UPLOAD			2
#define	COMM_MODE_UP_PRJHED			3
#define	COMM_MODE_UP_EXTPRJHED		4
#define	COMM_MODE_UP_PRJ_ID			5
#define	COMM_MODE_UP_PASSWORD		6

#define	TBL_REC_SIZE	17		/* Rec- NSize */


#define	MAX_BASE_FILE_CNT	0x10000

#ifdef	IO_HAND_PROC
	unsigned int	Bit32Inf[32]={
		0x00000001,0x00000002,0x00000004,0x00000008,0x00000010,0x00000020,0x00000040,0x00000080,
		0x00000100,0x00000200,0x00000400,0x00000800,0x00001000,0x00002000,0x00004000,0x00008000,
		0x00010000,0x00020000,0x00040000,0x00080000,0x00100000,0x00200000,0x00400000,0x00800000,
		0x01000000,0x02000000,0x04000000,0x08000000,0x10000000,0x20000000,0x40000000,0x80000000,
	};
	int	FileClearFlag;
	int	WriteFileKind[10];	//0:project,1:Common,2:Comment,3:Parts
	unsigned int	BaseFilenoInf[MAX_BASE_FILE_CNT/32];
	unsigned int	ImageFilenoInf[MAX_BASE_FILE_CNT/32];
	unsigned int	WindFilenoInf[32];
#else
	extern	int	FileClearFlag;
	extern	int	WriteFileKind[10];	//0:project,1:Common,2:Comment,3:Parts
	extern	unsigned int	BaseFilenoInf[MAX_BASE_FILE_CNT/32];
	extern	unsigned int	ImageFilenoInf[MAX_BASE_FILE_CNT/32];
	extern	unsigned int	WindFilenoInf[32];
#endif



//LP Proc
extern	void	SetSpecialRegisterAddr(void);
extern	void	SetRunStopSwitch(int OnOff);



void	PrtHand( T_MAIL *mp );
void	BarcodeIn(char *buff);
void	InitInClock( void );
void	InClockProc( void );
unsigned short Unv_crc16(unsigned char *puchMsg, int usDataLen);
void	UniversalError(unsigned char *RecBuff,char *SndBuff,int *SndCnt,int Code);
void	UniversalRead(unsigned char *RecBuff,char *SndBuff,int *SndCnt,int mode);
void	UniversalWrite(unsigned char *RecBuff,int RecCnt,char *SndBuff,int *SndCnt,int mode);
void	UniversalBroadWrite(unsigned char *RecBuff,int RecCnt,char *SndBuff,int *SndCnt,int mode);
int	HanyouComm(char	*RecBuff,int RecCnt,char *SndBuff,int *SndCnt);
void	SetPCEditorBcc(unsigned char *SendBuff,int *SendCommCnt);
void	MakePlcTable(void);
int	GetHexRec(int RecCnt,unsigned char* RecBuff);
void	SetErrorRec( int ErrCd,unsigned char* CommBuff,unsigned char *SendBuff,int *SendCommCnt,int Kind );
int	GPDataCheck( int RecCnt,unsigned char *CommBuff,unsigned char *SendBuff,int *SendCommCnt,int ch );
int	MakeProjectHed(unsigned char *SendBuff,int *SendCommCnt);
int	MakeProjectHedExt(unsigned char *SendBuff,int *SendCommCnt);
void	MakeProjectID( unsigned char *SendBuff,int *SendCommCnt );
void	MakePassWord( unsigned char *SendBuff,int *SendCommCnt );
int	SendFileRead(char *FileName,int code,unsigned char *SendBuff,int *SendCommCnt);
int	BaseWindowFile(unsigned char *SendBuff,int *SendCommCnt);
int	MakeHistryData(int idx, char *buff);
int	MakeFreqData(int idx, char *buff);
int	MakeHistory( unsigned char *SendBuff,int *SendCommCnt );
int	MakeHistoryContinue( unsigned char *SendBuff,int *SendCommCnt );
int	MakeFreq( unsigned char *SendBuff,int *SendCommCnt );
int	MakeFreqContinue( unsigned char *SendBuff,int *SendCommCnt );
void	MakeSendData(unsigned char *SendBuff,int *SendCommCnt);
void	initEditPort( void );
void	SendPCData( unsigned char *SendBuff,int SendCommCnt );
void	SendPLCData( unsigned char *SendBuff,int SendCommCnt,UART_STRUCT* SciTbl);		//2012.02.23
void	ClearPcCom( void );
//void	PCEditorCommProc(int *CommMode,unsigned char *CommBuff,unsigned char *SendBuff,int *SendCommCnt);
int		PCEditorCommProc(UART_STRUCT* SciTbl);
void	PC_CommProc(UART_STRUCT* SciTbl);
void	Uni_Get_Plc1_Ver(char *name);
void	MakeProtocolFile(int devType);
void	DeleteGpFile(char* Device);
int	GetEditBoadrate( void );
void	SendPlcWaitFlag(void);
void	MakeFontFile(void);
void	GpFileAllClear(void);
void	GPAllTaskStop(void);
