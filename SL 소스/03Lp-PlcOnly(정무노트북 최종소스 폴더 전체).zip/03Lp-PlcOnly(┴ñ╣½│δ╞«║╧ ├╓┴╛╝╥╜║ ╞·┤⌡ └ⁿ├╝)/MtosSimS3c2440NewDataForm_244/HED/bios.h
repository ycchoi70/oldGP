/****************************************/
#define	ESC	0x1b
/****************************************/
/* Text Draw Mode						*/
/****************************************/
#define	T_REPLACE	0
#define	T_OR		1
#define	T_XOR		2
#define	T_FRONT		3


//#define	T_BLACK		0
//#define	T_RED		1
//#define	T_YELLOW	2
//#define	T_GREEN		3
//#define	T_BLUE		5
//#define	T_GRAY		8
//#define	T_SILVER	9
//#define	T_LIME		10
//#define	T_WHITE		255
#define	T_BLACK		0x00000000
#define	T_RED		0x00ff0000
#define	T_YELLOW	0x0000ffff
#define	T_GREEN		0x0000ff00
#define	T_BLUE		0x000000ff
#define	T_GRAY		8
#define	T_SILVER	9
#define	T_LIME		10
#define	T_WHITE		0x00ffffff
/****************************************/
/* Paint Mode							*/
/****************************************/
#define	P_NONE		0
#define	P_PTRN1		1
#define	P_PTRN2		2
#define	P_PTRN3		3
#define	P_PTRN4		4
#define	P_PTRN5		5
#define	P_PTRN6		6
#define	P_PTRN7		7
#define	P_PTRN8		8

#define	CLOCK05	0x20
#define	CLOCK10	0x40
#define	CLOCK20	0x80
/****************************************/
/*	BIOS ProtoType						*/
/****************************************/
extern	void	_di(void);
extern	void	_ei(void);
extern	char	*GP_SYSVER;
extern	char	*GP_RELEASE;
extern	char	*GP_RELEASE_DATE;
extern	char	*dVersion;
extern	char	*EnvVersion;
extern	char	*GP_MODEL;
extern	char	*PlcPassword;  /* GLP Data Area Password */

extern	int	IntFlag;


#ifndef	WIN32
	void	DrawLcd( COLOR_DT* pBitmapBits );
#endif
/****************************************/

void	BackLightOnOff(int mode);
void    BuzOn(void);
void    BuzOff(void);

int	BatteryRead( void );
void	RunLed(int mode);
void	ErrorLed(int mode);
void	DebugLed(int mode);
int	RunSWReadProc( void );
int	RunSWRead( void );
void	InitFontload( void );

//gp_anal.cpp
void	PasswordLevelWrite(void);
int		iLeapYear(int year);
int	GetMaxDay(int year,int mon);
int		iNowWeek(RTC_DATA *STime);
void DeviceTableSet(int mode,int ch);



