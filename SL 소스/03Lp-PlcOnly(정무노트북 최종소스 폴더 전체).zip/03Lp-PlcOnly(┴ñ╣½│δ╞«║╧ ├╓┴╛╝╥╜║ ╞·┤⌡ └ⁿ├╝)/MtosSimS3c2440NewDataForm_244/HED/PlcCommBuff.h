/*****************************************/
/*	PLC Common Buffer Area               */
/*****************************************/
#define	RS_TIMEOUT	-1
#define	RS_SUM_ERR	-2

typedef struct{
	int	GrpIdxEntry;
	struct{
		short	GroopIdx[2][256];
		short	GroopFlag[2][256];
	}GrpIdx;
	struct{
		int			gDeviceCnt;				//Grouping Device Count
		int			gDeviceCntBit;			//Grouping Bit Device Count
		int			gDeviceCntWord;			//Grouping Word Device Count
		char		*gDeviceAddr[MAX_DEV_CNT];
	}GroopDev[64];
}GROOPINF_FORM;
#ifdef	DEFULT_PLC
//CH 0 Data
//	int			DeviceCnt[MAX_CHANEL][MAX_POLE];
	int			DeviceCnt;
	int			DeviceCntAddSys;
//	DEV_DATA	DeviceDataHed[MAX_CHANEL][MAX_POLE][MAX_DEV_CNT];  /* Apli */
	DEV_DATA	DeviceDataHed[MAX_DEV_CNT];  /* Apli */
	int			DeviceCntSys[MAX_CHANEL][MAX_POLE];
	int			DeviceCntSysStart[MAX_CHANEL][MAX_POLE];
//	DEV_DATA	DeviceDataSys[MAX_CHANEL][MAX_POLE][MAX_DEV_CNT];  /* System  */
	DEV_DATA	DeviceDataSys[MAX_DEV_CNT];  /* System  */
//	int			DeviceCnt1[MAX_CHANEL][MAX_POLE];
//	int			sDeviceCnt[MAX_CHANEL][MAX_POLE];
	int			DeviceCnt1;
	int			sDeviceCnt;
	/* Device �Ď��̈� */
	char		DeviceData[MAX_DEV_CNT*4];			//Clasification
	char		SaveDeviceData[MAX_DEV_CNT*4];		//Clasification Save Data
	char		DispDeviceData[MAX_DEV_CNT*4];		//Clasification

	GROOPINF_FORM	GroopInf;

	char		LinkBitReadData[4096];			//Link Bit Read data

#else
//	extern	int			DeviceCnt[MAX_CHANEL][MAX_POLE];
	extern	int			DeviceCnt;
	extern	int			DeviceCntAddSys;
//	extern	DEV_DATA	DeviceDataHed[MAX_CHANEL][MAX_POLE][MAX_DEV_CNT];  /* Apli */
	extern	DEV_DATA	DeviceDataHed[MAX_DEV_CNT];  /* Apli */
	extern	int			DeviceCntSys[MAX_CHANEL][MAX_POLE];
	extern	int			DeviceCntSysStart[MAX_CHANEL][MAX_POLE];
//	extern	DEV_DATA	DeviceDataSys[MAX_CHANEL][MAX_POLE][MAX_DEV_CNT];  /* System  */
	extern	DEV_DATA	DeviceDataSys[MAX_DEV_CNT];  /* System  */
//	extern	int			DeviceCnt1[MAX_CHANEL][MAX_POLE];
//	extern	int			sDeviceCnt[MAX_CHANEL][MAX_POLE];
	extern	int			DeviceCnt1;
	extern	int			sDeviceCnt;
	/* Device �Ď��̈� */
	extern	char		DeviceData[MAX_DEV_CNT*4];			//Clasification
	extern	char		SaveDeviceData[MAX_DEV_CNT*4];		//Clasification
	extern	char		DispDeviceData[MAX_DEV_CNT*4];		//Clasification
	extern	GROOPINF_FORM	GroopInf;

	extern	char		LinkBitReadData[4096];			//Link Bit Read data
#endif
