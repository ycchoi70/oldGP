
#define	LIST_Y_SIZE	19

#ifdef	ALARMLIST_PROC
	_ALARM_LIST_EVENT_TBL*	 AlarmListEventTbl;
	short			iDisplayCnt[256];		/* Shot�� ����... */
#endif

void	SetAlarmList_Func(int iDispOrder);
int DrawAlarmList_Func(int mode,_ALARM_LIST_EVENT_TBL* AlarmListEventTbl, int iDispOrder);
int	 GetLineCnt(int iFontSizeH, int iFontSizeV, int sY, int eY,int iVectorFlag,int iVectorKind);
void AlarmListDispWatch(int iOrder);
void	TextSizeCut(int iLen, short ShapeNo, short XDot,short YDot, char* cBuffer);
void	AlarmListCommand(void);
