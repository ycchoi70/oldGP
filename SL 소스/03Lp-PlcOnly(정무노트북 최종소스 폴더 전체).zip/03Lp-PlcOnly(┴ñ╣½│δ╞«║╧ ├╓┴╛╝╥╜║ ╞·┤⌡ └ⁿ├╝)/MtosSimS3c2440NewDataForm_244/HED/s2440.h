//=========================================================================================
// �� �� �� : s2440.h
// ������Ʈ : GP/LP
// ��    �� : Define S3C2440 Special Registers 
// �� �� �� : HMI
// �� �� �� : 2009�� 12�� 10��
// �� �� �� : ����н�(��)
// ��    �� : 
// ��    �� : 
//=========================================================================================

#ifdef	MAIN
#define	____EXT
#else
#define	____EXT	extern
#endif
#ifndef __2440X_H__
#define __2440X_H__

/* SA11x0 defines */
#define BIT00	(1<<0)
#define BIT01	(1<<1)
#define BIT02	(1<<2)
#define BIT03	(1<<3)
#define BIT04	(1<<4)
#define BIT05	(1<<5)
#define BIT06	(1<<6)
#define BIT07	(1<<7)
#define BIT08	(1<<8)
#define BIT09	(1<<9)
#define BIT10	(1<<10)
#define BIT11	(1<<11)
#define BIT12	(1<<12)
#define BIT13	(1<<13)
#define BIT14	(1<<14)
#define BIT15	(1<<15)
//#define BIT16	(1<<16)
#define BIT17	(1<<17)
#define BIT18	(1<<18)
#define BIT19	(1<<19)
#define BIT20	(1<<20)
#define BIT21	(1<<21)
#define BIT22	(1<<22)
#define BIT23	(1<<23)
#define BIT24	(1<<24)
#define BIT25	(1<<25)
#define BIT26	(1<<26)
#define BIT27	(1<<27)
#define BIT28	(1<<28)
#define BIT29	(1<<29)
#define BIT30	(1<<30)
#define BIT31	(1<<31)

///////////////////////////////////////////////////////////////////////////
// Memory Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct  {
    unsigned long       rBWSCON;    // 0
    unsigned long       rBANKCON0;  // 4
    unsigned long       rBANKCON1;  // 8
    unsigned long       rBANKCON2;  // c
    unsigned long       rBANKCON3;  // 10
    unsigned long       rBANKCON4;  // 1c
    unsigned long       rBANKCON5;  // 18
    unsigned long       rBANKCON6;  // 1c
    unsigned long       rBANKCON7;  // 20
    unsigned long       rREFRESH;   // 24
    unsigned long       rBANKSIZE;  // 28
    unsigned long       rMRSRB6;    // 2c
    unsigned long       rMRSRB7;     // 30
}MEM_REG;
#ifdef	WIN32
	____EXT	unsigned char	MEMCTRL_BASE[sizeof(MEM_REG)];
#else
	#define MEMCTRL_BASE        0x48000000
#endif
///////////////////////////////////////////////////////////////////////////
// USB HOST Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct {
    unsigned long       rHCREVISION;			// 0
    unsigned long       rHCCONTROL;				// 4
    unsigned long       rHCCOMMONSTATUS;		// 8
    unsigned long       rHCINTERRUPTSTATUS;		// c
    unsigned long       rHCINTERRUPTENABLE;		// 10
    unsigned long       rHCINTERRUPTDISABLE;	// 14
    unsigned long       rHCHCCA;				// 18
    unsigned long       rHCPERIODCUTTENTED;		// 1c
    unsigned long       rHCCONTROLHEADED;		// 20
    unsigned long       rHCCONTROLCURRENTED;	// 24
    unsigned long       rHCBULKHEADED;			// 28
    unsigned long       rHCBULKCURRENTED;		// 2c
    unsigned long       rHDONEHEAD;				// 30
    unsigned long       rHCRMINTERVAL;			// 34
    unsigned long       rHCFMREMAINING;			// 38
    unsigned long       rHCFMNUMBER;			// 3c
    unsigned long       rHCPERIODICSTART;		// 40
    unsigned long       rHCLSTHRESHOLD;			// 44
    unsigned long       rHCRHDISCRIPTORA;		// 48
    unsigned long       rHCRHDISCRIPTORB;		// 4c
    unsigned long       rHCRHSTATUS;			// 50
    unsigned long       rHCRHPORTSTATUS1;		// 54
    unsigned long       rHCRHPORTSTATUS2;		// 58
}USB_HOST_REG;
#ifdef	WIN32
	____EXT	unsigned char	MUSB_HOSTL_BASE[sizeof(USB_HOST_REG)];
#else
	#define MUSB_HOSTL_BASE        0x49000000		
#endif
///////////////////////////////////////////////////////////////////////////
// Interrupt Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct  {
    unsigned int  rSRCPND;			//0
    unsigned int  rINTMOD;			//4
    unsigned int  rINTMSK;			//8
    unsigned int  rPRIORITY;		//C
    unsigned int  rINTPND;			//10
    unsigned int  rINTOFFSET;		//14
    unsigned int  rSUBSRCPND;		//18
    unsigned int  rINTSUBMSK;		//1C
}INT_REG ;    
#ifdef	WIN32
	____EXT	unsigned char	INT_BASE[sizeof(INT_REG)];
#else
	#define INT_BASE        0x4A000000
#endif
// Interrupt Pending Register (INTREG) (3f0084h)
// Endpoint Int reg
#define INTREG_EP0              0x01
#define INTREG_EP1              0x02
#define INTREG_EP2              0x04
#define INTREG_SUSPEND          0x01
#define INTREG_RESUME           0x02
#define INTREG_RESET            0x04

// ENDPOINT0 CSR REGISTER (EP0CSR) (3f008Ah or 3f008Bh)
#define EP0CSR_OUT_PKT_RDY      0x01
#define EP0CSR_IN_PKT_RDY       0x02
#define EP0CSR_STALL            0x04
#define EP0CSR_DATA_END         0x08
#define EP0CSR_SETUP_END        0x10
#define EP0CSR_ISST             0x20
#define EP0CSR_CLR_OUT_PKT_RDY  0x40
#define EP0CSR_CLR_SETUP_END    0x80

// IN CONTROL STATUS REGISTER (INCSR) (3f008Ah)
#define INCSR1_IN_PKT_RDY       0x01
#define INCSR1_INTPT_ENDP       0x02

#define INCSR1_FIFO_FLUSH       0x08
#define INCSR1_ISST             0x10
#define INCSR1_STST             0x20
#define INCSR1_CLR_DATA_TOGGLE  0x40
#define INCSR2_ISO              0x20     // ISO �� 
#define INCSR2_MDIN             0x10
#define INCSR2_ASET             0x40


// OUT CONTROL STATUS REGISTER (OUTCSR) (3f008Bh)
#define OUTCSR1_OUT_PKT_RDY     0x01
#define OUTCSR1_OVERRUN         0x02
#define OUTCSR1_XMIT_STALL      0x04
#define OUTCSR1_FLFF            0x10
#define OUTCSR1_ISST            0x20
#define OUTCSR1_STST            0x40
#define OUTCSR1_DATA_TOGGLE     0x80
#define OUTCSR2_ACLR            0x80

// S3C2440X01 Interrupt controller bit positions

#define    BIT_EINT0        (0x1<<0)
#define    BIT_EINT1        (0x1<<1)
#define    BIT_EINT2        (0x1<<2)
#define    BIT_EINT3        (0x1<<3)
#define    BIT_EINT4_7      (0x1<<4)
#define    BIT_EINT8_23     (0x1<<5)
#define    BIT_RSV1         (0x1<<6)
#define    BIT_BAT_FLT      (0x1<<7)
#define    BIT_TICK         (0x1<<8)
#define    BIT_WDT          (0x1<<9)
#define    BIT_TIMER0       (0x1<<10)
#define    BIT_TIMER1       (0x1<<11)
#define    BIT_TIMER2       (0x1<<12)
#define    BIT_TIMER3       (0x1<<13)
#define    BIT_TIMER4       (0x1<<14)
#define    BIT_UART2        (0x1<<15)
#define    BIT_LCD          (0x1<<16)
#define    BIT_DMA0         (0x1<<17)
#define    BIT_DMA1         (0x1<<18)
#define    BIT_DMA2         (0x1<<19)
#define    BIT_DMA3         (0x1<<20)
#define    BIT_MMC	        (0x1<<21)
#define    BIT_SPI0	        (0x1<<22)
#define    BIT_UART1        (0x1<<23)
#define    BIT_RSV2         (0x1<<24)
#define    BIT_USBD         (0x1<<25)
#define    BIT_USBH         (0x1<<26)
#define    BIT_IIC	        (0x1<<27)
#define    BIT_UART0        (0x1<<28)
#define    BIT_SPI1         (0x1<<29)
#define    BIT_RTC	        (0x1<<30)
#define    BIT_ADC	        (0x1<<31)
#define    BIT_ALLMSK       (0xffffffff)

#define	   BIT_SUB_AC97		(0x1<<14)
#define	   BIT_SUB_WDT		(0x1<<13)
#define	   BIT_SUB_CAM_P	(0x1<<12)
#define	   BIT_SUB_CAM_C	(0x1<<11)
#define	   BIT_SUB_ADC		(0x1<<10)
#define    BIT_SUB_TC		(0x1<<9)
#define    BIT_SUB_ERR2		(0x1<<8)
#define    BIT_SUB_TXD2		(0x1<<7)
#define    BIT_SUB_RXD2		(0x1<<6)
#define    BIT_SUB_ERR1		(0x1<<5)
#define    BIT_SUB_TXD1		(0x1<<4)
#define    BIT_SUB_RXD1		(0x1<<3)
#define    BIT_SUB_ERR0		(0x1<<2)
#define    BIT_SUB_TXD0		(0x1<<1)
#define    BIT_SUB_RXD0		(0x1<<0)
#define    BIT_SUB_ALLMSK	(0x7ff)


// S3C2440X01 Interrupt controller source number
#define    INTSRC_EINT0     0
#define    INTSRC_EINT1     1
#define    INTSRC_EINT2     2
#define    INTSRC_EINT3     3
#define    INTSRC_EINT4_7   4
#define    INTSRC_EINT8_23  5
#define    INTSRC_RSV1      6
#define    INTSRC_BAT_FLT   7
#define    INTSRC_TICK      8
#define    INTSRC_WDT       9
#define    INTSRC_TIMER0    10
#define    INTSRC_TIMER1    11
#define    INTSRC_TIMER2    12
#define    INTSRC_TIMER3    13
#define    INTSRC_TIMER4    14
#define    INTSRC_UART2     15
#define    INTSRC_LCD       16
#define    INTSRC_DMA0      17
#define    INTSRC_DMA1      18
#define    INTSRC_DMA2      19
#define    INTSRC_DMA3      20
#define    INTSRC_MMC	    21
#define    INTSRC_SPI0	    22
#define    INTSRC_UART1     23
#define    INTSRC_RSV2      24
#define    INTSRC_USBD      25
#define    INTSRC_USBH      26
#define    INTSRC_IIC	    27
#define    INTSRC_UART0     28
#define    INTSRC_SPI1      29
#define    INTSRC_RTC	    30
#define    INTSRC_ADC	    31
#define    INTSRC_ALLMSK    (0xffffffff)

// S3C2440X01 Interrupt controller bit positions
// For SUB source pending bit.

#define 	INTSUB_RXD0		(0x1 << 0)
#define		INTSUB_TXD0		(0x1 << 1)
#define		INTSUB_ERR0		(0x1 << 2)
#define		INTSUB_RXD1		(0x1 << 3)
#define 	INTSUB_TXD1		(0x1 << 4)
#define		INTSUB_ERR1		(0x1 << 5)
#define		INTSUB_RXD2		(0x1 << 6)
#define 	INTSUB_TXD2		(0x1 << 7)
#define		INTSUB_ERR2		(0x1 << 8)
#define		INTSUB_TC		(0x1 << 9)
#define		INTSUB_ADC		(0x1 << 10)
#define 	INTSUB_SLLMSK	(0xFFFFFFFF)

#define		INTSUB_BASE     0x4A000018 // serial
#define		INTSUB_MSK      0x4A00001C // serial
#define		BIT_SUB_ALLMSK	(0x7ff)


///////////////////////////////////////////////////////////////////////////
// DMA Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct {
        unsigned int    rDISRC0;        // 00
        unsigned int	rDISRCC0;		// 04
        unsigned int    rDIDST0;        // 08
        unsigned int 	rDIDSTC0;		// 0C
        unsigned int    rDCON0;         // 10
        unsigned int    rDSTAT0;        // 14
        unsigned int    rDCSRC0;        // 18
        unsigned int    rDCDST0;        // 1C
        unsigned int    rDMASKTRIG0;    // 20
        unsigned int	rPAD1[7];		// 24 - 3C

        unsigned int    rDISRC1;        // 40
        unsigned int	rDISRCC1;		// 44
        unsigned int    rDIDST1;        // 48
        unsigned int 	rDIDSTC1;		// 4C
        unsigned int    rDCON1;         // 50
        unsigned int    rDSTAT1;        // 54
        unsigned int    rDCSRC1;        // 58
        unsigned int    rDCDST1;        // 5C
        unsigned int    rDMASKTRIG1;    // 60
        unsigned int	rPAD2[7];		// 64 - 7C

        unsigned int    rDISRC2;        // 80
        unsigned int	rDISRCC2;		// 84
        unsigned int    rDIDST2;        // 88
        unsigned int 	rDIDSTC2;		// 8C
        unsigned int    rDCON2;         // 90
        unsigned int    rDSTAT2;        // 94
        unsigned int    rDCSRC2;        // 98
        unsigned int    rDCDST2;        // 9C
        unsigned int    rDMASKTRIG2;    // A0
        unsigned int	rPAD3[7];		// A4 - BC

        unsigned int    rDISRC3;        // C0
        unsigned int	rDISRCC3;		// C4
        unsigned int    rDIDST3;        // C8
        unsigned int 	rDIDSTC3;		// CC
        unsigned int    rDCON3;         // D0
        unsigned int    rDSTAT3;        // D4
        unsigned int    rDCSRC3;        // D8
        unsigned int    rDCDST3;        // DC
        unsigned int    rDMASKTRIG3;    // E0
 }DMA_REG;
#ifdef	WIN32
	____EXT	unsigned char	DMA_BASE[sizeof(DMA_REG)];
#else
	#define DMA_BASE        0x4B000000
#endif

//----- Register definitions for DISRCCn control register -----
//
#define SOURCE_PERIPHERAL_BUS				0x00000002
#define FIXED_SOURCE_ADDRESS				0x00000001

//----- Register definitions for DIDSTCn control register -----
//
#define DESTINATION_PERIPHERAL_BUS			0x00000002
#define FIXED_DESTINATION_ADDRESS			0x00000001

//----- Register definitions for DCONn control register -----
//
#define HANDSHAKE_MODE						0x80000000
#define DREQ_DACK_SYNC						0x40000000
#define GENERATE_INTERRUPT					0x20000000
#define SELECT_BURST_TRANSFER				0x10000000
#define SELECT_WHOLE_SERVICE_MODE			0x08000000


// bits[26-24] = select DMA source for the respective channel:
//------------------------------------------------------------
#define XDREQ0_DMA0							0x00000000
#define UART0_DMA0							0x01000000
#define MMC_DMA0							0x02000000
#define TIMER_DMA0							0x03000000
#define USB_EP1_DMA0						0x04000000

#define XDREQ1_DMA1							0x00000000
#define UART1_DMA1							0x01000000
#define I2SSDI_DMA1							0x02000000
#define SPI_DMA1							0x03000000
#define USB_EP2_DMA1						0x04000000

#define I2SSDO_DMA2							0x00000000
#define I2SSDI_DMA2							0x01000000
#define MMC_DMA2							0x02000000
#define TIMER_DMA2							0x03000000
#define USB_EP3_DMA2						0x04000000

#define UART2_DMA3							0x00000000
#define MMC_DMA3							0x01000000
#define SPI_DMA3							0x02000000
#define TIMER_DMA3							0x03000000
#define USB_EP4_DMA3						0x04000000
//------------------------------------------------------------

#define DMA_TRIGGERED_BY_HARDWARE			0x00800000
#define NO_DMA_AUTO_RELOAD					0x00400000

// bits[21-20] = select transfer word size
//------------------------------------------------------------
#define TRANSFER_BYTE						0x00000000				// 8  bits
#define TRANSFER_HALF_WORD					0x00100000				// 16 bits
#define TRANSFER_WORD						0x00200000				// 32 bits

//----- Register definitions for DSTATn status register -----
#define DMA_TRANSFER_IN_PROGRESS			0x00100000

//----- Register definitions for DMASKTRIGn configuration register -----
#define STOP_DMA_TRANSFER					0x00000004
#define ENABLE_DMA_CHANNEL					0x00000002
#define DMA_SW_TRIGGER						0x00000001

///////////////////////////////////////////////////////////////////////////
// CLOCK & POWER Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct {
    unsigned long       rLOCKTIME;		// 0
    unsigned long       rMPLLCON;		// 4
    unsigned long       rUPLLCON;		// 8
    unsigned long       rCLKCON;		// C
    unsigned long       rCLKSLOW;		//10
    unsigned long       rCLKDIVN;		//14
}CLKPWR_REG;
#ifdef	WIN32
	____EXT	unsigned char	CLKPWR_BASE[sizeof(CLKPWR_REG)];
#else
	#define CLKPWR_BASE     0x4C000000
#endif

#define CLKEN_SM_BIT        (1<<0)
#define CLKEN_IDLE_BIT      (1<<2)
#define CLKEN_POWER_OFF     (1<<3)
#define CLKEN_NAND_CTRL     (1<<4)
#define CLKEN_LCDC          (1<<5)
#define CLKEN_USBH          (1<<6)
#define CLKEN_USBD          (1<<7)
#define CLKEN_PWMTIMER      (1<<8)
#define CLKEN_SDI           (1<<9)
#define CLKEN_UART0         (1<<10)
#define CLKEN_UART1         (1<<11)
#define CLKEN_UART2         (1<<12)
#define CLKEN_GPIO          (1<<13)
#define CLKEN_RTC           (1<<14)
#define CLKEN_ADC           (1<<15)
#define CLKEN_IIC           (1<<16)
#define CLKEN_IIS           (1<<17)
#define CLKEN_SPI           (1<<18)

///////////////////////////////////////////////////////////////////////////
// LCD Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct  {
    unsigned int  rLCDCON1;		// 00
    unsigned int  rLCDCON2;		// 04
    unsigned int  rLCDCON3;		// 08
    unsigned int  rLCDCON4;		// 0C
    unsigned int  rLCDCON5;		// 10
    unsigned int  rLCDSADDR1;	// 14
    unsigned int  rLCDSADDR2;	// 18
    unsigned int  rLCDSADDR3;	// 1C
    unsigned int  rREDLUT;		// 20
    unsigned int  rGREENLUT;	// 24
    unsigned int  rBLUELUT;		// 28
    unsigned int  PAD[8];		// 2C - 48
    unsigned int  rDITHMODE;	// 4C
    unsigned int  rTPAL;		// 50
    unsigned int  rLCDINTPND;	// 54
    unsigned int  rLCDSRCPND;	// 58
    unsigned int  rLCDINTMSK;	// 5C	
    unsigned int  rLPCSEL;		// 60
}LCD_REG ;    
#ifdef	WIN32
	____EXT	unsigned char	LCD_BASE[sizeof(LCD_REG)];
#else
	#define LCD_BASE        0x4D000000
#endif
///////////////////////////////////////////////////////////////////////////
// NAND Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct  
{
    unsigned long	rNFCONF;          // 0x00                 
    unsigned long	rNFCONT;          // 0x04  
	union{
	    unsigned char	rNFCMMD;          // 0x08
		unsigned long	rDumy;
	}u1;
	union{
	    unsigned char	rNFADDR;          // 0x0c     
		unsigned long	rDumy;
	}u2;
	union{
	    unsigned char	rNFDATA;          // 0x10
		unsigned long	rDumy;
	}u3;
    unsigned long	rNFECCD0;         // 0x14                 
    unsigned long	rNFECCD1;         // 0x18                 
    unsigned long	rNFECCD;          // 0x1c                 
	union{
	    unsigned char	rNFSTAT;          // 0x20                 
		unsigned long	rDumy;
	}u4;
    unsigned long	rNFESTAT0;        // 0x24                 
    unsigned long	rNFESTAT1;        // 0x28                 
    unsigned long	rNFMECC0;         // 0x2c                 
    unsigned long	rNFMECC1;         // 0x30                 
    unsigned long	rNFSECC;          // 0x34                 
    unsigned long	rNFSBLK;          // 0x38                 
    unsigned long	rNFEBLK;          // 0x3c                 
} NAND_REG;    
#ifdef	WIN32
	____EXT	unsigned char	NAND_BASE_PHYS[sizeof(NAND_REG)];
#else
	#define NAND_BASE_PHYS  0x4E000000
#endif
///////////////////////////////////////////////////////////////////////////
// UART Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct  {
    unsigned int  rULCON;		//0
    unsigned int  rUCON;		//4
    unsigned int  rUFCON;		//8
    unsigned int  rUMCON;		//c
    unsigned int  rUTRSTAT;		//10
    unsigned int  rUERSTAT;		//14
    unsigned int  rUFSTAT;		//18
    unsigned int  rUMSTAT;		//1c
    unsigned int  rUTXH;		//20
    unsigned int  rURXH;		//24
    unsigned int  rUBRDIV;		//28
}UART_REG, *PUART_REG;
#ifdef	WIN32
	____EXT	unsigned char	UART0_BASE[sizeof(UART_REG)];
	____EXT	unsigned char	UART1_BASE[sizeof(UART_REG)];
	____EXT	unsigned char	UART2_BASE[sizeof(UART_REG)];
#else
	#define UART0_BASE      0x50000000
	#define UART1_BASE      0x50004000
	#define UART2_BASE      0x50008000
#endif

#define	UART_INT0			(1<<28)
#define	UART_INT1			(1<<23)
#define	UART_INT2			(1<<15)

#define UART0_INT_RXD        (1<<0)
#define UART0_INT_TXD        (1<<1)
#define UART0_INT_ERR        (1<<2)
#define UART1_INT_RXD        (1<<3)
#define UART1_INT_TXD        (1<<4)
#define UART1_INT_ERR        (1<<5)
#define UART2_INT_RXD        (1<<6)
#define UART2_INT_TXD        (1<<7)
#define UART2_INT_ERR        (1<<8)

#define UART_IOP_TX0        (2)
#define UART_IOP_RX0        (3)
#define UART_IOP_TX1        (4)
#define UART_IOP_RX1        (5)
#define UART_IOP_TX2        (6)
#define UART_IOP_RX2        (7)

#define FIFO_DEPTH_TX       16
#define FIFO_DEPTH_RX       32


#define INTR_NONE           (0)
#define INTR_LINE           (1<<0)
#define INTR_MODEM          (1<<1)
#define INTR_RX             (1<<2)
#define INTR_TX             (1<<3)

#define BAUDRATE_300          (300)
#define BAUDRATE_600          (600)
#define BAUDRATE_1200         (1200)
#define BAUDRATE_2400         (2400)
#define BAUDRATE_4800         (4800)
#define BAUDRATE_9600         (9600)
#define BAUDRATE_19200        (19200)
#define BAUDRATE_38400        (38400)
#define BAUDRATE_57600        (57600)
#define BAUDRATE_115200       (115200)

///////////////////////////////////////////////////////////////////////////
// PWM Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct  {
    unsigned int  rTCFG0;		//00
    unsigned int  rTCFG1;		//04
    unsigned int  rTCON;		//08
    unsigned int  rTCNTB0;		//0C
    unsigned int  rTCMPB0;		//10
    unsigned int  rTCNTO0;		//14
    unsigned int  rTCNTB1;		//18
    unsigned int  rTCMPB1;		//1C
    unsigned int  rTCNTO1;		//20
    unsigned int  rTCNTB2;		//24
    unsigned int  rTCMPB2;		//28
    unsigned int  rTCNTO2;		//2C
    unsigned int  rTCNTB3;		//30
    unsigned int  rTCMPB3;		//34
    unsigned int  rTCNTO3;		//38
    unsigned int  rTCNTB4;		//3C
    unsigned int  rTCNTO4;		//40
}PWM_REG ;
#ifdef	WIN32
	____EXT	unsigned char	PWM_BASE[sizeof(PWM_REG)];
	#define REG_TCNTO4		(PWM_BASE[16])

#else
	#define PWM_BASE        0x51000000
	#define REG_TCNTO4		(*(volatile unsigned *)0x51000040)
#endif


///////////////////////////////////////////////////////////////////////////
// USB Device Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct
{
	unsigned char	d[0x140];			// 0x00
	unsigned long	HwUBFADR;			// 0x140
	    #define HwUSB_UP		BIT07
	unsigned long	HwUBPWR;			// 0x144
		#define HwUBPWR_ISOUP	BIT07
		#define HwUBPWR_RST		BIT03
		#define HwUBPWR_RSM		BIT02
		#define HwUBPWR_SP		BIT01
		#define HwUBPWR_ENSP	BIT00
	unsigned long	HwUBEIR;			// 0x148
		#define HwUSB_EP2		BIT02
		#define HwUSB_EP1		BIT01
		#define HwUSB_EP0		BIT00
	unsigned long	d0[3];
	unsigned long	HwUBIR;				// 0x158
		#define HwUBIR_RST		BIT02
		#define HwUBIR_RSM		BIT01
		#define HwUBIR_SP		BIT00
	unsigned long	HwUBEIEN;			// 0x15C
	unsigned long	d1[3];
	unsigned long	HwUBIEN;			// 0x16C
	unsigned long	HwUBFRM1;			// 0x170
	unsigned long	HwUBFRM2;			// 0x174
	unsigned long	HwUBIDX;			// 0x178
	unsigned long	d2;
	unsigned long	HwMAXP;				// 0x180;
	unsigned long	HwINCSR1;			// 0x184;
		#define HwUSB_IN_CTGL           BIT06           /* Clear Data Toggle Bit  */
		#define HwUSB_IN_STST           BIT05           /* Stall Handshake issued */
		#define HwUSB_IN_ISST           BIT04           /* Issue Stall Handshake  */
		#define HwUSB_IN_FLFF           BIT03           /* Issue FIFO flush       */
		#define HwUSB_IN_UNDER          BIT02           /* Under Run              */
		#define HwUSB_IN_FNE            BIT01           /* IN FIFO Not Empty      */
		#define HwUSB_IN_IRDY           BIT00           /* IN Packet ready        */
		// HwEP0CSR            HwINCSR1
		#define HwUSB_CLSE              BIT07
		#define HwUSB_CLOR              BIT06
		#define HwUSB_ISST              BIT05
		#define HwUSB_CEND              BIT04
		#define HwUSB_DEND              BIT03
		#define HwUSB_STST              BIT02
		#define HwUSB_IRDY              BIT01
		#define HwUSB_ORDY              BIT00
	unsigned long	HwINCSR2;			// 0x188
		#define HwUSB_ASET              BIT07           /* Auto Set          */
		#define HwUSB_ISO               BIT06           /* ISO/BULK Mode Set */
		#define HwUSB_MDIN              BIT05           /* IN/OUT select     */
		#define HwUSB_DMA               BIT04           /* DMA Enable        */
	unsigned long	d3;
	unsigned long	HwOCSR1;			// 0x190
		#define HwUSB_OUT_CTGL          BIT07           /* Clear Data Toggle Bit   */
		#define HwUSB_OUT_STST          BIT06           /* Stall Handshake issued  */
		#define HwUSB_OUT_ISST          BIT05           /* Issue Stall Handshake   */
		#define HwUSB_OUT_FLFF          BIT04           /* Issue FIFO flush        */
		#define HwUSB_OUT_FFL           BIT01           /* OUT FIFO FULL           */
		#define HwUSB_ORDY              BIT00           /* IN Packet ready         */
	unsigned long	HwOCSR2;			// 0x194
		#define HwUSB_ACLR              BIT07           /* Auto Clear           */
		#define HwUSB_ISO               BIT06           /* ISO/BULK Mode Select */
	unsigned long	HwOFIFO1;			// 0x198
	unsigned long	HwOFIFO2;			// 0x19C
	unsigned long	HwEP0FIFO;			// 0x1C0
	unsigned long	HwEP1FIFO;			// 0x1C4
	unsigned long	HwEP2FIFO;			// 0x1C8
	unsigned long	HwEP3FIFO;			// 0x1CC
	unsigned long	HwEP4FIFO;			// 0x1D0
	unsigned long	d4[11];
	unsigned long	HwDMACON;			// 0x200
		#define	HwDMACON_CKSEL          BIT00           /* Clock select for system bus interface */
	unsigned long	HwDMAEP1;			// 0x204
	unsigned long	HwDMAEP2;			// 0x208
}UDC_REG;
#ifdef	WIN32
	____EXT	unsigned char	UDC_BASE[sizeof(UDC_REG)];
#else
	#define UDC_BASE            0x52000000
#endif

// 2440 USB DEVICE Function (Written by Seung-han, Lim)
// Little-Endian	


#define SET_ADDRESS_REG_OFFSET      0x0
#define PWR_REG_OFFSET              0x4
#define EP_INT_REG_OFFSET           0x8
#define USB_INT_REG_OFFSET          0x18
#define EP_INT_EN_REG_OFFSET        0x1C
#define USB_INT_EN_REG_OFFSET       0x2C



 #define EP0_FIFO_REG_OFFSET        0x80
 #define EP1_FIFO_REG_OFFSET        0x84
 #define EP2_FIFO_REG_OFFSET        0x88
 #define EP3_FIFO_REG_OFFSET        0x8C
 #define EP4_FIFO_REG_OFFSET        0x90


 
#define IDXADDR_REG_OFFSET          0x38
// Indexed Registers
#define MAX_PKT_SIZE_REG_OFFSET     0x40
#define IN_CSR1_REG_OFFSET          0x44
#define EP0_CSR_REG_OFFSET          IN_CSR1_REG_OFFSET
#define IN_CSR2_REG_OFFSET          0x48
#define OUT_CSR1_REG_OFFSET         0x50
#define OUT_CSR2_REG_OFFSET         0x54
#define OUT_FIFO_CNT1_REG_OFFSET    0x58
#define OUT_FIFO_CNT2_REG_OFFSET    0x5C


#define BASE_REGISTER_OFFSET        0x140
#define REGISTER_SET_SIZE           0x200


// Power Reg Bits
#define USB_RESET                   0x8
#define MCU_RESUME                  0x4
#define SUSPEND_MODE                0x2
#define SUSPEND_MODE_ENABLE_CTRL    0x1

// EP0 CSR
#define EP0_OUT_PACKET_RDY          0x1
#define EP0_IN_PACKET_RDY           0x2
#define EP0_SENT_STALL              0x4
#define DATA_END                    0x8
#define SETUP_END                   0x10
#define EP0_SEND_STALL              0x20
#define SERVICED_OUT_PKT_RDY        0x40
#define SERVICED_SETUP_END          0x80

// OUT_CSR1_REG Bit definitions
#define OUT_PACKET_READY            0x1
#define FLUSH_OUT_FIFO              0x10
#define OUT_SEND_STALL              0x20
#define OUT_SENT_STALL              0x40
#define OUT_CLR_DATA_TOGGLE         0x80

// OUT_CSR2_REG Bit definitions
#define OUT_DMA_INT_DISABLE         0x10

// IN_CSR1_REG Bit definitions
#define IN_PACKET_READY             0x1
#define UNDER_RUN                   0x4   // Iso Mode Only
#define FLUSH_IN_FIFO               0x8
#define IN_SEND_STALL               0x10
#define IN_SENT_STALL               0x20
#define IN_CLR_DATA_TOGGLE          0x40

// IN_CSR2_REG Bit definitions
#define IN_DMA_INT_DISABLE          0x10
#define SET_MODE_IN                 0x20 
#define SET_TYPE_ISO                0x40  // Note that Samsung does not currently support ISOCH 
#define AUTO_MODE                   0x80

// Can be used for Interrupt and Interrupt Enable Reg - common bit def
#define EP0_INT_INTR                0x1
#define EP1_INT_INTR                0x2
#define EP2_INT_INTR                0x4
#define EP3_INT_INTR                0x8
#define EP4_INT_INTR                0x10

#define CLEAR_ALL_EP_INTRS          (EP0_INT_INTR | EP1_INT_INTR | EP2_INT_INTR | EP3_INT_INTR | EP4_INT_INTR)

#define  EP_INTERRUPT_DISABLE_ALL   0x0   // Bits to write to EP_INT_EN_REG - Use CLEAR

// Bit Definitions for USB_INT_REG and USB_INT_EN_REG_OFFSET
#define USB_RESET_INTR              0x4
#define USB_RESUME_INTR             0x2
#define USB_SUSPEND_INTR            0x1

///////////////////////////////////////////////////////////////////////////
// EATCH DOG Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct {
    unsigned long   rWTCON;		//00
    unsigned long   rWTDAT;		//04
    unsigned long   rWTCNT;		//08
} WATCH_REG;
#ifdef	WIN32
	____EXT	unsigned char	WATCH_BASE[sizeof(WATCH_REG)];
#else
	#define WATCH_BASE          0x53000000
#endif

///////////////////////////////////////////////////////////////////////////
// IIC Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct {
        unsigned int    rIICCON;		//00
        unsigned int    rIICSTAT;		//04
        unsigned int    rIICADD;		//08
        unsigned int    rIICDS;			//0C
}IIC_REG;        
#ifdef	WIN32
	____EXT	unsigned char	IIC_BASE[sizeof(IIC_REG)];
#else
	#define IIC_BASE            0x54000000
#endif

///////////////////////////////////////////////////////////////////////////
// IIS Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct {
        unsigned int    rIISCON;		//00
        unsigned int    rIISMOD;		//04
        unsigned int    rIISPSR;		//08
        unsigned int    rIISFCON;		//0C
        unsigned int    rIISFIFO;		//10
}IIS_REG;        
#ifdef	WIN32
	____EXT	unsigned char	IIS_BASE[sizeof(IIS_REG)];
#else
	#define IIS_BASE            0x55000000
#endif

//----- GPIO Configuration Masks -----
#define ENABLE_I2SSDO					0x00000200
#define ENABLE_I2SSDI					0x00000080
#define ENABLE_I2SCDCLK					0x00000020
#define ENABLE_I2SSCLK					0x00000008
#define ENABLE_I2SLRCLK					0x00000002
#define DISABLE_I2S_PULLUPS				0x0000001F

//----- Register definitions for IISCON control register (global config register) -----
#define LR_CHANNEL_INDEX				0x00000100				// Left/right channel index			(read-only)		
#define TRANSMIT_FIFO_READY				0x00000080				// Indicates transmit FIFO is ready	(read-only)
#define RECEIVE_FIFO_READY				0x00000040				// Indicates receive FIFO is ready	(read-only)
#define TRANSMIT_DMA_REQUEST_ENABLE		0x00000020				// Enables transmit DMA request
#define RECEIVE_DMA_REQUEST_ENABLE		0x00000010				// Enables receive DMA request
#define TRANSMIT_IDLE_CMD				0x00000008				// Pauses transmit
#define RECEIVE_IDLE_CMD				0x00000004				// Pauses receive
#define IIS_PRESCALER_ENABLE			0x00000002				// Enables clock prescaler
#define IIS_INTERFACE_ENABLE			0x00000001				// Enables IIS controller

//----- Register definitions for IISMOD status register (global status register) -----
#define IIS_MASTER_MODE					0x00000000				// Selects master/slave mode
#define IIS_SLAVE_MODE					0x00000100				
#define IIS_NOTRANSFER_MODE				0x00000000				// Selects transfer mode
#define IIS_RECEIVE_MODE				0x00000040
#define IIS_TRANSMIT_MODE				0x00000080
#define IIS_TRANSMIT_RECEIVE_MODE		0x000000C0
#define ACTIVE_CHANNEL_LEFT				0x00000000				// Selects active channel
#define ACTIVE_CHANNEL_RIGHT			0x00000020
#define SERIAL_INTERFACE_IIS_COMPAT		0x00000000				// Selects serial interface format
#define SERIAL_INTERFACE_MSBL_COMPAT	0x00000010
#define DATA_8_BITS_PER_CHANNEL			0x00000000				// Selects # of data bits per channel
#define DATA_16_BITS_PER_CHANNEL		0x00000008				
#define MASTER_CLOCK_FREQ_256fs			0x00000000				// Selects master clock frequency
#define MASTER_CLOCK_FREQ_384fs			0x00000004				
#define SERIAL_BIT_CLOCK_FREQ_16fs		0x00000000				// Selects serial data bit clock frequency
#define SERIAL_BIT_CLOCK_FREQ_32fs		0x00000001				
#define SERIAL_BIT_CLOCK_FREQ_48fs		0x00000002				

//----- Register definitions for IISPSR control register (global config register) -----
//		FORMAT:			bits[9:5] - Prescaler Control A
//						bits[4:0] - Prescaler Control B
//
//						Range: 0-31 and the division factor is N+1 (a.k.a. 1-32)
//
//		The I2SLRCLK frequency is determined as follows:
//
//				I2SLRCLK = CODECLK / I2SCDCLK		and		(prescaler+1) = PCLK / CODECLK
//
//		Thus, rearranging the equations a bit we can see that:
//
//				prescaler = (PCLK / CODECLK) - 1 
//		or
//				prescaler = ((PCLK / (IS2LRCLK * IS2CDCLK)) - 1
//		
// Here are some popular values for IS2LRCLK:
//		
#define IS2LRCLK_800					800
#define IS2LRCLK_11025					11025
#define IS2LRCLK_16000					16000
#define IS2LRCLK_22050					22050
#define IS2LRCLK_32000					32000
#define IS2LRCLK_44100					44100
#define IS2LRCLK_48000					48000
#define IS2LRCLK_64000					64000
#define IS2LRCLK_88200					88200
#define IS2LRCLK_96000					96000
	


//----- Register definitions for IISFCON control register (global config register) -----
#define TRANSMIT_FIFO_ACCESS_NORMAL		0x00000000				// Selects the transmit FIFO access mode
#define TRANSMIT_FIFO_ACCESS_DMA		0x00008000				
#define RECEIVE_FIFO_ACCESS_NORMAL		0x00000000				// Selects the receive FIFO access mode
#define RECEIVE_FIFO_ACCESS_DMA			0x00004000				
#define TRANSMIT_FIFO_ENABLE			0x00002000				// Enables transmit FIFO
#define RECEIVE_FIFO_ENABLE				0x00001000				// Enables receive FIFO

//----- Register definitions for IISFIFO control register (global config register) -----
//		NOTE: This register is used to access the transmit/receive FIFO
#define MAX_TRANSMIT_FIFO_ENTRIES		24
#define MAX_RECEIVE_FIFO_ENTRIES		24

///////////////////////////////////////////////////////////////////////////
// I/O Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct  {
    unsigned int  rGPACON;		// 00
    unsigned int  rGPADAT;		// 04
    unsigned int  rPAD1[2];		// 08 - 0C
    
    unsigned int  rGPBCON;		// 10
    unsigned int  rGPBDAT;		// 14
    unsigned int  rGPBUP;		// 18
    unsigned int  rPAD2;		// 1C
    
    unsigned int  rGPCCON;		// 20
    unsigned int  rGPCDAT;		// 24
    unsigned int  rGPCUP;		// 28
    unsigned int  rPAD3;		// 2C
    
    unsigned int  rGPDCON;		// 30
    unsigned int  rGPDDAT;		// 34
    unsigned int  rGPDUP;		// 38
    unsigned int  rPAD4;		// 3C
    
    unsigned int  rGPECON;		// 40
    unsigned int  rGPEDAT;		// 44
    unsigned int  rGPEUP;		// 48
    unsigned int  rPAD5;		// 4C
    
    unsigned int  rGPFCON;		// 50
    unsigned int  rGPFDAT;		// 54
    unsigned int  rGPFUP;		// 58
    unsigned int  rPAD6;		// 5C
    
    unsigned int  rGPGCON;		// 60
    unsigned int  rGPGDAT;		// 64
    unsigned int  rGPGUP;		// 68
    unsigned int  rPAD7;		// 6C
    
    unsigned int  rGPHCON;		// 70
    unsigned int  rGPHDAT;		// 74
    unsigned int  rGPHUP;		// 78
    unsigned int  rPAD8;		// 7C
    
    unsigned int  rMISCCR;		// 80
    unsigned int  rDCKCON;		// 84
    unsigned int  rEXTINT0;		// 88
    unsigned int  rEXTINT1;		// 8C
    unsigned int  rEXTINT2;		// 90
	unsigned int  rEINTFLT0;	// 94
	unsigned int  rEINTFLT1;	// 98
	unsigned int  rEINTFLT2;	// 9C
	unsigned int  rEINTFLT3;	// A0
	unsigned int  rEINTMASK;	// A4
	unsigned int  rEINTPEND;	// A8
	unsigned int  rGSTATUS0;	// AC
	unsigned int  rGSTATUS1;	// B0
    unsigned int  rPAD9[7];

    unsigned int  rGPJCON;		// d0
    unsigned int  rGPJDAT;
    unsigned int  rGPJUP; 
}IOP_REG;  
#ifdef	WIN32
	____EXT	unsigned char	IOP_BASE[sizeof(IOP_REG)];
#else
	#define IOP_BASE        0x56000000
#endif

#define		TOUCH_IRQ       9       //EINT9
#define		USB_IRQ         11      //EINT11
///////////////////////////////////////////////////////////////////////////
// RTC Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct {
	unsigned int  rPAD1[16]; 	// 00 - 3C
    unsigned int  rRTCCON;		// 40
    unsigned int  rTICINT;		// 44
    unsigned int  rPAD2[2];     // 48 - 4C
    unsigned int  rRTCALM;		// 50
    unsigned int  rALMSEC;		// 54
    unsigned int  rALMMIN;		// 59
    unsigned int  rALMHOUR;		// 5C
    unsigned int  rALMDAY;		// 60
    unsigned int  rALMMON;		// 64
    unsigned int  rALMYEAR;		// 68
    unsigned int  rRTCRST;		// 6C
    unsigned int  rBCDSEC;		// 70
    unsigned int  rBCDMIN;		// 74
    unsigned int  rBCDHOUR;		// 78
    unsigned int  rBCDDATE;		// 7C
    unsigned int  rBCDDAY;		// 80(Week)
    unsigned int  rBCDMON;		// 84
    unsigned int  rBCDYEAR;		// 88
} RTC_REG;    
#ifdef	WIN32
	____EXT	unsigned char	RTC_BASE[sizeof(RTC_REG)];
#else
	#define RTC_BASE            0x57000000
#endif

///////////////////////////////////////////////////////////////////////////
// ADC Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct {
        unsigned int 	rADCCON;		// 00
        unsigned int 	rADCTSC;		// 04
        unsigned int	rADCDLY;		// 08
        unsigned int 	rADCDAT0;		// 0C
        unsigned int 	rADCDAT1;		// 10
		unsigned int	rADCUPDN;		// 14
}ADC_REG ;        
#ifdef	WIN32
	____EXT	unsigned char	ADC_BASE[sizeof(ADC_REG)];
#else
	#define ADC_BASE            0x58000000
#endif

///////////////////////////////////////////////////////////////////////////
// SPI Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct  {
    unsigned int rSPCON0; 		// 00
    unsigned int rSPSTA0;		// 04
    unsigned int rSPPIN0;		// 08
    unsigned int rSPPRE0;		// 0C
    unsigned int rSPTDAT0;		// 10
    unsigned int rSPRDAT0;		// 14
    unsigned int rPAD[2];		// 18 - 1C
    unsigned int rSPCON1; 		// 20
    unsigned int rSPSTA1;		// 24
    unsigned int rSPPIN1;		// 28
    unsigned int rSPPRE1;		// 2C
    unsigned int rSPTDAT1; 		// 30
    unsigned int rSPRDAT1;		// 34
    
}SPI_REG ; 
#ifdef	WIN32
	____EXT	unsigned char	SPI_BASE[sizeof(SPI_REG)];
#else
	#define SPI_BASE            0x59000000
#endif

///////////////////////////////////////////////////////////////////////////
// SD/MMC Controller Register
///////////////////////////////////////////////////////////////////////////
typedef struct {
    unsigned int   	rSDICON;						//0x5a000000
		#define	SDCON_SDMMC_RESET	(1 << 8)
		#define	SDCON_CLOCK_MMC	(1 << 5)
		#define	SDCON_FIFO_BIG	(1 << 4)
		#define	SDCON_SDIO_INT	(1 << 3)
		#define	SDCON_READ_WAIT	(1 << 2)
		#define	SDCON_CLOCK_UT	(1 << 0)
    unsigned int   	rSDIPRE;						//0x5a000004
    unsigned int   	rSDICMDARG;						//0x5a000008
    unsigned int   	rSDICMDCON;						//0x5a00000c
		#define	CON_ABORT_CMD		(1 << 12)
		#define	CON_CMD_WITHDATA	(1 << 11)
		#define	CON_LONG_RESP		(1 << 10)
		#define	CON_WAIT_RESP		(1 << 9)
		#define	CON_CMD_START		(1 << 8)
    unsigned int   	rSDICMDSTA;						//0x5a000010
		#define	ST_CRC_FAIL	(1 << 12)
		#define	ST_CMD_END	(1 << 11)
		#define	ST_TIME_OUT	(1 << 10)
		#define	ST_RESP_END	(1 << 9)
		#define	ST_CMD_ON	(1 << 8)
    unsigned int   	rSDIRSP0;						//0x5a000014
    unsigned int   	rSDIRSP1;						//0x5a000018
    unsigned int   	rSDIRSP2;						//0x5a00001c
    unsigned int   	rSDIRSP3;						//0x5a000020
    unsigned int 	rSDIDTIMER;						//0x5a000024
    unsigned int	rSDIBSIZE;						//0x5a000028
    unsigned int 	rSDIDATCON;						//0x5a00002c
#define	DATCON_BURST4	(1 << 24)
#define	DATCON_DATSZ_B	(0 << 22)		//Byte
#define	DATCON_DATSZ_H	(1 << 22)		//Half Word
#define	DATCON_DATSZ_W	(2 << 22)		//Word
#define	DATCON_INT_P	(1 << 20)		//Single Type
#define	DATCON_TARSP	(1 << 19)		//Transfer After Response
#define	DATCON_RACMD	(1 << 18)		//Recieve After Command
#define	DATCON_BACMD	(1 << 17)		//Busy After Command
#define	DATCON_BLOCK	(1 << 16)		//Block Mode
#define	DATCON_WIDBUS	(1 << 15)		//Wide Bus Enable
#define	DATCON_DMA		(1 << 14)		//DMA Enable
#define	DATCON_DTST		(1 << 13)		//Data Transfer Start
#define	DATCON_DTMODE0	(0 << 11)		//NOP
#define	DATCON_DTMODE1	(1 << 11)		//Only Busy Check
#define	DATCON_DTMODE2	(2 << 11)		//Data Recieve Mode
#define	DATCON_DTMODE3	(3 << 11)		//Data Tarnsmit Mode
    unsigned int	rSDIDATCNT;						//0x5a000030
    unsigned int	rSDIDATSTA;						//0x5a000034
#define	DTST_NOBUSY			(1 << 11)		//No Busy Signal
#define	DTST_RWAIT_REQ		(1 << 10)		//Read Request Occured
#define	DTST_IOINT			(1 << 9)		//IO Int Detect
#define	DTST_CRC_ST_FAIL	(1 << 7)		//CRC Status Fail
#define	DTST_CRC_REC_FAIL	(1 << 6)		//Rec CRC Fail
#define	DTST_TIME_OUT		(1 << 5)		//Data Time Out
#define	DTST_TRANS_END		(1 << 4)		//Data Transfer Finished
#define	DTST_BUSY_END		(1 << 3)		//Busy Finished
#define	DTST_TX_DATA_ON		(1 << 1)		//Data Tx in Progress
#define	DTST_RX_DATA_ON		(1 << 0)		//Data Rx in Progress
    unsigned int	rSDIFSTA;						//0x5a000038
#define	FFST_RST		(1 << 16)
#define	FFST_ERR0		(0 << 14)			//Normal
#define	FFST_ERR1		(1 << 14)			//Fifo Fail
#define	FFST_ERR2		(2 << 14)			//Fifo Fail Last Transfer
#define	FFST_ERR3		(3 << 14)			//Reserve
#define	FFST_TFDET		(1 << 13)			//Fifo Available Detect for Tx
#define	FFST_RFDET		(1 << 12)			//Fifo Available Detect for Rx
#define	FFST_TFHALF		(1 << 11)			//Tx Fifo Half Full
#define	FFST_TFEMPTY	(1 << 10)			//Tx Fifo Empty
#define	FFST_RFLAST		(1 << 9)			//Rx Fifo Last data ready
#define	FFST_RFFULL		(1 << 8)			//Rx Fifo Full
#define	FFST_RFHALF		(1 << 7)			//Rx Fifo Half Full
#define	FFST_FFCNT		(63 << 0)			//Number of Data in Fifo
    unsigned int	rSDIINTMSK;						//0x5a00003c
#define	INT_NOBUSY		(1 << 18)			//NoBusy Interrupt enable
#define	INT_RSPCRC		(1 << 17)			//RSP Crc Interrupt enable
#define	INT_CMDSENT		(1 << 16)			//Command Sent Interrupt enable
#define	INT_CMDTOUT		(1 << 15)			//Command Response Timeout Interrupt enable
#define	INT_RSPEND		(1 << 14)			//Command Response Recieve Interrupt enable
#define	INT_RWAITREQ	(1 << 13)			//Read Wait Request Interrupt enable
#define	INT_IOINTDET	(1 << 12)			//IO Interrupt Recieve Interrupt enable
#define	INT_FFFAIL		(1 << 11)			//Fifo Fail Interrupt enable
#define	INT_CRCSTERR	(1 << 10)			//CRC Status Error Interrupt enable
#define	INT_DATRECCRC	(1 << 9)			//data Recieve CRC fail Interrupt enable
#define	INT_DATRETOUT	(1 << 8)			//Data Recieve Timeout Interrupt enable
#define	INT_DATFIN		(1 << 7)			//Data Counter Zero Interrupt enable
#define	INT_BUSYFIN		(1 << 6)			//Only Busy Check Complete Interrupt enable
#define	INT_TFHALF		(1 << 4)			//TX Fifo Fill Half Interrupt enable
#define	INT_TFEMPTY		(1 << 3)			//TX Fifo Empty Interrupt enable
#define	INT_RFLAST		(1 << 2)			//RX Fifo Last data Interrupt enable
#define	INT_RFFULL		(1 << 1)			//RX Fifo Full Interrupt enable
#define	INT_RFHALF		(1 << 0)			//RX Fifo Fill Half Interrupt enable
    unsigned int	rSDIDAT;						//0x5a000040
} MMC_REG;
#ifdef	WIN32
	____EXT	unsigned char	MMC_BACE[sizeof(MMC_REG)];
#else
	#define MMC_BACE            0x5A000000
#endif



#endif


#define USBHOST_REGS	0x49000000		/* USBH(OHCI) Register Start Address */
#define USBHOST_MEM		0x31c00000		/* USBH(OHCI) Shared Memory Start Address */

#define FRAMEBUFFER_BASE    (0x31d00000)			//800*480*4=1536000(Byte)
#define FRAMEBUFFER_BASE2   (0x31e80000)			//800*480*4=1536000(Byte)


