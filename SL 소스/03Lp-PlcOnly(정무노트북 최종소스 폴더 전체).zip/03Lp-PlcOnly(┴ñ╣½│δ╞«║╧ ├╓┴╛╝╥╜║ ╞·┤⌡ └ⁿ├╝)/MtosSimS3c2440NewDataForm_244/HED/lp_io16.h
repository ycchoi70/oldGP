
#define	MAX_MOTION_CHANEL		2
#define	MAX_MOTION_LIST			256
#define	MAX_MOTION_PATRN_LIST	256

#define	MOTION_NORMAL		0			//Normal Moving
#define	MOTION_MTVDM		1			//Continue Moving from Stop
#define	MOTION_MTPDM		2			//Goto position
#define	MOTION_MTIDM		3			//Patarn Moving
#define	MOTION_MTOBC		4			//Origin Back Moving

#define	MOTION_UNTEN		5
#define	MOTION_POS			6
#define	MOTION_STOP			7
#define	MOTION_MTOBC_STOP	8

#define	MOTION_REV		0
#define	MOTION_FOR		1

#define	MOTION_MV_OFF		0
#define	MOTION_MV_UP_START	1
#define	MOTION_MV_UP		2
#define	MOTION_MV_FLAT		3
#define	MOTION_MV_DW		4
#define	MOTION_MV_DW_END	5
#define	MOTION_MV_DWLL		6
#define	MOTION_LIMIT_REV	7
#define	MOTION_BASE_REV		8
#define	MOTION_BASE_STOP_WAIT1		9
#define	MOTION_BASE_STOP_WAIT2		10
#define	MOTION_BASE_STOP_WAIT3		11


#define	MAX_SLOT_CNT		16
#define	MAX_EXT_CNT			16
#ifdef	WIN32
#ifdef	MAIN
	unsigned int	FPGA_IP_Area[0x1000];
#else
	extern	unsigned int	FPGA_IP_Area[0x1000];
#endif
	#define EXT_IO_ADDR	&FPGA_IP_Area[0]
#else
	#define EXT_IO_ADDR	0x28000000
#endif
#define	EXT_IO_I32O00	0x01
#define	EXT_IO_I28O04	0x02
#define	EXT_IO_I24O08	0x03
#define	EXT_IO_I20O12	0x04
#define	EXT_IO_I16O16	0x05
#define	EXT_IO_I12O20	0x06
#define	EXT_IO_I08O24	0x07
#define	EXT_IO_I04O28	0x08
#define	EXT_IO_I00O32	0x09

#define	EXT_IO_IO		0x00
#define	EXT_IO_COM		0x10
#define	EXT_IO_TEMP		0x20

//External IO Address
#define	EXT_IO_IN_ADDR		0x08
#define	EXT_IO_OUT_ADDR		0x0a
#define	EXT_IO_FILT_ADDR	0x20
#define	EXT_IO_INT_DATA		0x30
#define	EXT_IO_INT_ADDR		0x38
//#define	EXT_IO_OFFSET		0x40
#define	EXT_IO_OFFSET		0x100

typedef struct{
	int	extCnt;				//�O�����
	struct{
		unsigned int	ID;				//0:I/O,1:�ʐM���W��?��,2:���x�v,���̑�
		unsigned char*	address;	//�擪�A�h���X
		int	SlotNo;
		char	Version[8];
		char	Model[16];
	}ExtInfo[MAX_EXT_CNT];
}EXT_IO_INF;

//I/O Parameter Struct
typedef	struct{
	unsigned char	UseFlag;
	unsigned char	DevUseFlag;
	unsigned char	Val[4];
	unsigned char	DevAddr[4];
	unsigned char	dumy[2];
}PARA_FILTER;
typedef	struct{
	unsigned char	UseFlag;
	unsigned char	DevUseFlag;
	unsigned char	Val[8];
	unsigned char	DevAddr[4];
	unsigned char	Label[16][14];
	unsigned char	dumy[18];
}PARA_INT;
typedef	struct{
	unsigned char	UseFlag;
	unsigned char	DevUseFlag;
	unsigned char	Inreg;
	unsigned char	Outreg;
	unsigned char	DevAddr[4];
	unsigned char	dumy[4];
}PARA_MATRIX;
typedef	struct{
	unsigned char	UseFlag;
	unsigned char	DevUseFlag;
	unsigned char	Outreg;
	unsigned char	Dumy;
	unsigned char	DevAddr[4];
	unsigned char	dumy[4];
}PARA_7SEG;
typedef	struct{
	unsigned char	UseFlag;
	unsigned char	DevUseFlag;
	unsigned char	Outreg;		//Y??�g�ԍ�
	unsigned char	DataBit;
	unsigned char	Count;
	unsigned char	Dumy;
	unsigned char	DevAddr[4];
	unsigned char	dumy[2];
}PARA_SIO;
typedef struct{
	unsigned char		slotNo;
	unsigned char		ModuleID;
	unsigned char		Version[2];
	PARA_FILTER	filter;
	PARA_INT	intctl;
	PARA_MATRIX	matrix;
	PARA_7SEG	seg7;
	PARA_SIO	syncSio;
	unsigned char	dumy[204];		//
}PARA_IO;
typedef struct{
	unsigned char	Password[16];
	unsigned char	DebugIoUse;			//080116
	unsigned char	DebugIoOut;			//0:1Scan Out,1:No Out
	unsigned char	DefFilter;			//DEfault Filter
	unsigned char	IoOut;				//Stop���o�͂���A���Ȃ�(FPGA�ɐݒ�)
//	unsigned char	Dumy1;
	unsigned char	ScanTime[4];		//������X�L��������
	struct{
		unsigned char	TimerTime[2];	//Timer Int Cycle
		unsigned char	Label[14];		
	}tInt[8];							//16*8=128Byte
	unsigned char	DevLen[2];
	unsigned short	ClearDevUse[2];
	unsigned short	ClearDev[16][4];	//8*16=128Byte
	unsigned short	TimerKind[3][2];	//0:100ms,1:10ms,2:1ms
	unsigned char	Dumy2[198];		//248-150
}GLP_COMM;

typedef struct{
	int			len;
	char		ver[12];
	GLP_COMM	comm;
	int			slotNum;
	char		SlotName[256][16];
	PARA_IO		io;
}PARAM_FILE;

typedef	struct{
	int	FilterUse;
	int	FilterDevUse;
	char	FilterVal[2];
	unsigned short*	FilterDevAddr;
	unsigned short	FilterDev[2];
	int	InterruptUse;
	int	InterruptDevUse;
	char	InterVal[4];
	unsigned short*	IntDevAddr;
	unsigned short	IntDev[2];
	int	TenkeyUse;
	int	TenkeyDevUse;
	unsigned short*	TenkeyDevAddr;
	unsigned short	TenkeyDev[2];
	int	Tenkey_Inreg;
	int	Tenkey_Outreg;
	int	Seg7Use;
	int	Seg7DevUse;
	unsigned short*	Seg7DevAddr;
	unsigned short	Seg7Dev[2];
	int	Seg7_Outreg;
	int	SyncSioUse;
	int	SyncSioDevUse;
	unsigned short*	SyncSioDevAddr;
	unsigned short	SyncSioDev[2];
	int	Sync_Outreg;
	int	Sync_DataCnt;
	int	Sync_Bit;
	int	SyncSioDataCnt;//Byte Count
	unsigned short	SyncSioData[16];
}GLP_IO_INFO;
//////////////////////////////////////////////////////////////
//Mortion Control Infomation(�`���l������)
//////////////////////////////////////////////////////////////
typedef	struct{
	int	infRegUseFlag;
	unsigned short	infDevice[2];
	unsigned short*	infDeviceAddr;
	int	listRegUseFlag;
	unsigned short	listDevice[2];
	unsigned short*	listDeviceAddr;
}MOTION_REG_INF;
typedef struct{
	unsigned short	Chanel;					//0:Chanel Num(0,1)
	unsigned short	useFlag;				//1:0:no Use,1:Use
	unsigned short	BaseDir;				//2:���_����
	unsigned short	UpTime[5];				//3:�������ԁi�P�`�T�j
	unsigned short	DownTime[5];			//8:�������ԁi�P�`�T�j
	unsigned short	JogUpTime;				//13:JOG��������
	unsigned short	JogDownTime;			//14:JOG��������
	unsigned short	BaseUpTime;				//15:���_��������
	unsigned short	BaseDownTime;			//16:���_��������
	unsigned short	UseLimitSw;				//17:�㉺���~�b�g�g�p(1)�^���g�p(0) Soft
	unsigned short	UseLimitInt;			//18:�㉺���~�b�g�g�p(1)�^���g�p(0) Interrupt
	unsigned short	UseBase;				//19:���_S/W(1)�^H/W(0) Base
	int	SwLimitHigh;						//21:������~�b�g
	int	SwLimitLow;							//22:�������~�b�g
	unsigned int	FirstSpeed;				//24:�������x
	unsigned int	BasePos;				//26:���_�ʒu
	unsigned int	JogSpeed;				//28:JOG���x
	unsigned int	BaseSpeed;				//30:���_���x
}MOTION_FORM;
//////////////////////////////////////////////////////////////
//Mortion �^�]���X�g�t�H�[�}�b�g
//////////////////////////////////////////////////////////////
typedef struct{
	unsigned short	no;						//0:���X�g�ԍ�
	unsigned short	type;					//1:�^�]�`�ԁi0:�^�],1:�ʒu�j
	unsigned short	cordinatin;				//2:�ʒu�w��̂Ƃ��i0:����,1:��΁j
	unsigned short	direction;				//3:�^�]����(0:REV.1:FOR)
	unsigned int	objectPos;				//4:�ڕW�ʒu()
	unsigned int	speed;					//6:�^�]���x(pps)
	unsigned short	uptime;					//8:��������(No)
	unsigned short	downtime;				//9:��������(No)
	unsigned short	dowelltime;				//10:�h�E�F������(ms)
	unsigned short	dumy;					//11:�\��
}MOTION_LIST_FORM;
//////////////////////////////////////////////////////////////
//Mortion ������t�H�[�}�b�g
//////////////////////////////////////////////////////////////
typedef struct{
	int		TCNTStart;				//H/Z
	int		TCNTB;					//H/Z
	int		TCMPB;					//Low Width
	int		FlatTCNTB;				//�葬�o�ߎ���
	int		MaxTCNTB0;				//H/Z
	int		MaxTCNTB;				//H/Z
	int		MinTCNTB;				//H/Z
	int		MinTCNTB1;				//H/Z
	int		FlatMaxTCNTB;			//�葬����
	int		DowellMaxTCNTB;			//Dowell����
	float	UpDeltaSpeed0;			//�����P��Speed
	int		UpMaxSpeed0;			//�ő�Speed
	float	UpDeltaSpeed;			//�����P��Speed
	int		UpMaxSpeed;				//�ő�Speed
	float	DwDeltaSpeed;			//�����P��Speed
	int		DwMinSpeed;				//�ŏ�Speed
	float	DwDeltaSpeed1;			//�����P��Speed
	int		DwMinSpeed1;			//�ŏ�Speed
	float	NowSpeed;				//����Speed
	int		DwChangePos;			//Down Change Position
	int		DwChangeCnt;			//Down Change Count

	int		DwStartSpeed;			//2012.03.28
	int		DwStartTCNTB;			//2012.03.28

	int		upModeFlag;				//�O�F���Z�A�P�F���Z

	int		MoveType;				//
	int		MoveMode;				// 0:�^�]�A1:�ʒu
	int		ContinueType;			// 0:Single,1:Repeat,2:Continue
	int		PatarnNo;				//Patarn Moving
	int		PatarnIdx;				//Index In Patarn
	int		Direction;
	int		ObjectPos;				//�����J�n�ʒu
	int		RealObjectPos;			//��~�ʒu
	int		BasePos;
	int		MoveCommand;			//�ړ��R�}���h
	int		LimitTime;			//���_���A�̃��~�b�g�t�]����(*10)
}MOTION_CTL_FORM;

#ifdef	LP_IO16_PROC
	int	FilterChangeTbl[16]={
		0x00,		//0ms
		0x01,		//1ms
		0x04,		//2ms
		0x06,		//3ms
		0x09,		//4ms    
		0x0b,		//5ms    11
		0x0e,		//6ms    14
		0x11,		//7ms    17
		0x13,		//8ms    19
		0x16,		//9ms    22
		0x18,		//10ms   24
		0x25,		//15ms   37
		0x34,		//20ms   52
	};
	int	slotBit[MAX_SLOT_CNT]={
		0x0001,0x0002,0x0004,0x0008,0x0010,0x0020,0x0040,0x0080,
		0x0100,0x0200,0x0400,0x0800,0x1000,0x2000,0x4000,0x8000,
	};


#endif

#ifdef	WIN32
	extern	void BitDevYOnOffWin32(int nOnBits);
	extern	void BitDevYOnOffWin32T(int nOnBits);
	extern	void BitDevYOnOffWin32C(int nOnBits);
	extern	void WordDevD0D1(unsigned short d[]);
	extern	void BitDevXOnOffWin32(void);
	extern	unsigned int	Xdevice;
	extern	unsigned int	Tdevice;
	extern	unsigned int	Cdevice;
	extern	void BitRunOnOffWin32C(int nOnBits);
#endif
	extern	void	SetTimerKind(unsigned short* time_data);
	extern	const unsigned int	AndTable32[32];


void	IoFunctionOut(void);
void	GetInputScan(int idx,int BitPos,int cnt);
void	SetExtIntrrupt(void);
void	SetClearFilterInt(int sidx);
void	SetClearFunc(int sidx);
void	SetTenkeyPara(int sidx);
void	Set7SegPara(int sidx);
void	SetSyncSio(int sidx);
void	IOScanProc(void);
int	GetSlotPidx(int slotNo);
void	SetFilter(int pidx,int sidx);
void	SetDefaultFilter(int sidx);
void	InitSlotModule(int slotNo);
void	Seg7DataOut(int sidx);
void	SyncDataOut(int sidx);
void	IOOutProc(void);
int	CheckFilter(unsigned short fdata);
int	CheckInterrupt(unsigned short idata);
int	CheckMatrix(unsigned short inreg,unsigned short outreg);
int	Check7Seg(unsigned short idata);
int	CheckSyncSio(unsigned short outreg,unsigned short bit,unsigned short dCnt);
void	SetInterruptKind(void);
void	ParamIO2Fdevice(void);
void	ParamDev2In(int sidx);
void	FilterChange(void);
unsigned char	ChangeFilterIdx(unsigned short data);
void	SetParamdata(char *wBuff);
int	_IoInterruptProc(void);
void	InitExtInf(void);
void	SetOutData(int idx,int BitPos,int cnt);
void	SetStopStatus(int ch);
void	SetMotionPos(int ch,int pos);
void	FpgaIntEnable(void);
void	SetMotionIo(void);
