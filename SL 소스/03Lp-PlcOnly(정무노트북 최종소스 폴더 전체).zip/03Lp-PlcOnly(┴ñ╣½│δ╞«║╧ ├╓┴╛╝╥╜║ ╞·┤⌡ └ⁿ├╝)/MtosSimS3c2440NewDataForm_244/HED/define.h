//#define	TEST_PROT	1 /* Protocol Include */   /* �ڸ�Ʈ�� �ٿ��δ�E���������� �翁E �߿���E�ۼ��� �ڸ�Ʈ ó�� */
//                        �ڸ�Ʈ �����濁EICE��E��� c10000�������� �����ϴ� �߿����� �ҽ��� ���������� �翁E
//#define	RESIZE_TEST
//�ý��� �޼���E����� ���
//GlpAplsim ���丮���� Message.bat ��ǁE GlpMessage���丮���� ������



//#define	LCD_ADDRESS_CHANGE
	
#define	LCD_POSITION_CHANGE	




// ��E����� ���
// 1. GP_Versionü�� ���� �� ��¥ ����
// 2. define���� �� �� ��E����
// 3. sys_setting���� ������Eΰ� �����ڿ�Eΰ� ����, 
// 4. sys_setting���� �����Ʈ OLD ����ENEW����E����
// 5. S ���Ͽ��� ��¥ �� ���� �� ����E����





/****************************************/
/*	CPU MODE							*/
/****************************************/
/* **********************************************************************************************************/
/* hsh 20060314 �𵨸�Edefine	*//* GP New Size Selection */
/* ���ڵ�Edefine													 */	
/* GP_S044_S1D0	0x8011 */										 
/* GP_S044_S1D1	0x8012 */										 

/* GP_S057_S1D0	0x8021 */										 
/* GP_S057_S1D1	0x8022 */										 

/* GP_S070_S1D0	0x8041 */										 
/* GP_S070_S1D1	0x8042 */										 

/* LP_S044_S1D0	0x8201 */										 
/* LP_S044_S1D1	0x8202 */										 

/* LP_S070_S1D0	0x8241 */										 
/* LP_S070_S1D1	0x8242 */										 
/* **********************************************************************************************************/
//#define	GP_S044_S1D0_FIRM	1			//GP-S044S1D0_FIRM
//#define	GP_S044_S1D0_FULL	1			//GP-S044S1D0_FULL
//#define	GP_S044_S1D1_FIRM	1			//GP-S044S1D1_FIRM
//#define	GP_S044_S1D1_FULL	1			//GP-S044S1D1_FULL

//#define	GP_S057_S1D0_FIRM	1			//GP-S057S1D0_FIRM
//#define	GP_S057_S1D0_FULL	1			//GP-S057S1D0_FULL
//#define	GP_S057_S1D1_FIRM	1			//GP-S057S1D1_FIRM
//#define	GP_S057_S1D1_FULL	1			//GP-S057S1D1_FULL

//#define	GP_S070_S1D0_FIRM	1			//GP-S070S1D0_FIRM
//#define	GP_S070_S1D0_FULL	1			//GP-S070S1D0_FULL
//#define	GP_S070_S1D1_FIRM	1			//GP-S070S1D1_FIRM
//#define	GP_S070_S1D1_FULL	1			//GP-S070S1D1_FULL

//#define	LP_S044_S1D0_FIRM	1			//LP-S044S1D0_FIRM	
//#define	LP_S044_S1D0_FULL	1			//LP-S044S1D0_FULL	
//#define	LP_S044_S1D1_FIRM	1			//LP-S044S1D1_FIRM	
//#define	LP_S044_S1D1_FULL	1			//LP-S044S1D1_FULL

#define	LP_S070_S1D0_FIRM	1			//LP-S070S1D0_FIRM	
//#define	LP_S070_S1D0_FULL	1			//LP-S070S1D0_FULL	
//#define	LP_S070_S1D1_FIRM	1			//LP-S070S1D1_FIRM	
//#define	LP_S070_S1D1_FULL	1			//LP-S070S1D1_FULL


/* **********************************************************************************************************/
/* **********************************************************************************************************/
/* KOREA, JAPAN, CHINA, ENGLISH, TAIWAN */
/* **********************************************************************************************************/
#define		KOREA	1				
//#define		JAPAN	1				
//#define		CHINA	1				
//#define		ENGLISH	1				
//#define		TAIWAN	1
/* **********************************************************************************************************/
/* Version Check 0x0x1201  */
/* Bit15, Bit14, Bit13, Bit12 = 1 : SH,			 2 : ARM												*/
/* Bit11, Bit10, Bit09, Bit08 = 1 : mid Version, 2 : last Version										*/
/* Bit07, Bit06, Bit05, Bit04 = 0 : KOREA, 1 : JAPAN,	2 : CHINA, 3 : ENGLISH, 4 : TAIWAN     */	
/* Bit03, Bit02, Bit01, Bit00 = 1 : Firmware Version, 2 : Full Version		                        */
/* **********************************************************************************************************/

#ifdef	LP_S044_S1D0_FIRM
#define	LP_S044_S1D0
#define FIRM_FULL_CODE 1
#endif
#ifdef	LP_S044_S1D0_FULL
#define	LP_S044_S1D0
#define FIRM_FULL_CODE 2
#endif
#ifdef	LP_S044_S1D1_FIRM
#define	LP_S044_S1D1
#define FIRM_FULL_CODE 1
#endif
#ifdef	LP_S044_S1D1_FULL
#define	LP_S044_S1D1
#define FIRM_FULL_CODE 2
#endif

#ifdef	LP_S070_S1D0_FIRM
#define	LP_S070_S1D0
#define FIRM_FULL_CODE 1
#endif
#ifdef	LP_S070_S1D0_FULL
#define	LP_S070_S1D0
#define FIRM_FULL_CODE 2
#endif
#ifdef	LP_S070_S1D1_FIRM
#define	LP_S070_S1D1
#define FIRM_FULL_CODE 1
#endif
#ifdef	LP_S070_S1D1_FULL
#define	LP_S070_S1D1
#define FIRM_FULL_CODE 2
#endif

#ifdef	GP_S057_S1D0_FIRM
#define	GP_S057_S1D0
#define FIRM_FULL_CODE 1
#endif
#ifdef	GP_S057_S1D0_FULL
#define	GP_S057_S1D0
#define FIRM_FULL_CODE 2
#endif
#ifdef	GP_S057_S1D1_FIRM
#define	GP_S057_S1D1
#define FIRM_FULL_CODE 1
#endif
#ifdef	GP_S057_S1D1_FULL
#define	GP_S057_S1D1
#define FIRM_FULL_CODE 2
#endif

#ifdef	GP_S044_S1D0_FIRM
#define	GP_S044_S1D0
#define FIRM_FULL_CODE 1
#endif
#ifdef	GP_S044_S1D0_FULL
#define	GP_S044_S1D0
#define FIRM_FULL_CODE 2
#endif
#ifdef	GP_S044_S1D1_FIRM
#define	GP_S044_S1D1
#define FIRM_FULL_CODE 1
#endif
#ifdef	GP_S044_S1D1_FULL
#define	GP_S044_S1D1
#define FIRM_FULL_CODE 2
#endif

#ifdef	GP_S070_S1D0_FIRM
#define	GP_S070_S1D0
#define FIRM_FULL_CODE 1
#endif
#ifdef	GP_S070_S1D0_FULL
#define	GP_S070_S1D0
#define FIRM_FULL_CODE 2
#endif
#ifdef	GP_S070_S1D1_FIRM
#define	GP_S070_S1D1
#define FIRM_FULL_CODE 1
#endif
#ifdef	GP_S070_S1D1_FULL
#define	GP_S070_S1D1
#define FIRM_FULL_CODE 2
#endif

#ifdef	KOREA	
	#define LANG_CODE 0
#elif	JAPAN	
	#define LANG_CODE 1
#elif	CHINA	
	#define LANG_CODE 2
#elif	ENGLISH	
	#define LANG_CODE 3
#elif	TAIWAN	
	#define LANG_CODE 4
#endif		

/* **********************************************************************************************************/
#define		VER_CHECK_CODE	((2 << 12) | (2 << 8) | (LANG_CODE << 4) | (FIRM_FULL_CODE << 0))
/* **********************************************************************************************************/


#ifdef	GP_S044_S1D0
	#define	SIZE_2480
	#define	GP_S044
	#define	S1D0
	#define	GP_TYPE_CODE	0x8011	
	#define	MAX_FLOAT_CNT	28
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_GP
#endif
#ifdef	GP_S044_S1D1
	#define	SIZE_2480
	#define	GP_S044
	#define	S1D1
	#define	GP_TYPE_CODE	0x8012		
	#define	MAX_FLOAT_CNT	28
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_GP
#endif
#ifdef	GP_S057_S1D0
	#define	SIZE_3224
	#define	GP_S057
	#define	S1D0
	#define	GP_TYPE_CODE	0x8021		
	#define	MAX_FLOAT_CNT	38
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_GP
#endif
#ifdef	GP_S057_S1D1
	#define	SIZE_3224
	#define	GP_S057
	#define	S1D1
	#define	GP_TYPE_CODE	0x8022		
	#define	MAX_FLOAT_CNT	38
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_GP
#endif
#ifdef	LP_S044_S1D0
	#define	SIZE_2480
	#define	LP_S044
	#define	S1D0
	#define	GP_TYPE_CODE	0x8201		
	#define	MAX_FLOAT_CNT	28
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_LP
#endif
#ifdef	LP_S044_S1D1
	#define	SIZE_2480
	#define	LP_S044
	#define	S1D1
	#define	GP_TYPE_CODE	0x8202		
	#define	MAX_FLOAT_CNT	28
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_LP
#endif

#ifdef	LP_S070_S1D0
	#define	SIZE_8048
	#define	LP_S070
	#define	T9D6
	#define	GP_TYPE_CODE	0x8241		
	#define	MAX_FLOAT_CNT	500
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_LP

	#define	ALLF_NAME			"LP-S070-T9D6.GLP"
	#define	F_UP_NAME			"LPA_9248.GLP"
	#define	FIRM_NAME			"LPA_8241.GLP"
#endif
#ifdef	LP_S070_S1D1
	#define	SIZE_8048
	#define	LP_S070
	#define	T9D7
	#define	GP_TYPE_CODE	0x8242		
	#define	MAX_FLOAT_CNT	500
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_LP

	#define	ALLF_NAME			"LP-S070-T9D7.GLP"
	#define	F_UP_NAME			"LPA_9249.GLP"
	#define	FIRM_NAME			"LPA_8242.GLP"
#endif

#ifdef	GP_S070_S1D0
	#define	SIZE_8048
	#define	GP_S070
	#define	T9D6
	#define	GP_TYPE_CODE	0x8041		
	#define	MAX_FLOAT_CNT	500
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_GP

	#define	ALLF_NAME			"GP-S070-T9D6.GLP"
	#define	F_UP_NAME			"GPA_9048.GLP"
	#define	FIRM_NAME			"GPA_8041.GLP"
#endif
#ifdef	GP_S070_S1D1
	#define	SIZE_8048
	#define	GP_S070
	#define	T9D7
	#define	GP_TYPE_CODE	0x8042		
	#define	MAX_FLOAT_CNT	500
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_GP

	#define	ALLF_NAME			"GP-S070-T9D7.GLP"
	#define	F_UP_NAME			"GPA_9049.GLP"
	#define	FIRM_NAME			"GPA_8042.GLP"
#endif


#define PLC1STATUS "PLCPROC"
#define PLC2STATUS "PLCPROC2"



/* LCD �o�b�t??�̈�(240/8*80,320/8*240)*/
/************************************/
/*	�ő�?�O��						*/
/************************************/
#define	MAX_TAG_NO		1024
#define	MAX_DEV_CNT		512
#define	MAX_POLE		257				//CH1-P256(In Device)
#define	IN_DEV_POLE		256
#define	MAX_CHANEL		2

#define	MAX_TOUCH_AREA	4				//2011.08.25

/************************************/
/* ��ʃT�C�Y						*/
/************************************/

//#ifdef	GLP_2480
	#define	GAMEN_START_X	0			//?�b?�Ƃ��킷����
	#define	GAMEN_START_Y	0
	#define	G_START_X	0			//?�b?�Ƃ��킷����
	#define	G_START_Y	0
	#define	GAMEN_X_SIZE	800		/* 051027 */
	#define	GAMEN_Y_SIZE	480		/* 051027 */
	#define	WINDOW_Y_SIZE	480		/* 051027 */
	#define	MESH_X		16
	#define	MESH_Y		20
	#define	MAX_MEMORY_SIZE	2000
//#endif
//#ifdef	GLP_2480
	#define		DEF_CONTRAST			50
//	#define		DEF_LCDCLK  			43  //        767Khz
	#define		DEF_LCDCLK  			55	//070524  600Khz
//	#define		DEF_LCDCLK  			100	//080530  330KHz
//	#define		DEF_LCDCLK  			35	//080530
//#endif


/* �����P�� */
#define	MAX_CHAR		(GAMEN_X_SIZE/8)
#define	MAX_LINE		(GAMEN_Y_SIZE/16)

/* ?�b?�̈� */
//#define	MAX_COLUM_NO	(GAMEN_X_SIZE/MESH_X)
//#define	MAX_LINE_NO		(GAMEN_Y_SIZE/MESH_Y)
//#define	MAX_TOUCH_NO	(MAX_COLUM_NO*MAX_LINE_NO)

#define	PLC_BUF_MAX		1280
#define	EDIT_COM_MAX	1024
//#define	PLC_BUF_MAX		2280
//#define	EDIT_COM_MAX	2048


#define	MAX_BOADRATE_CNT	6	/* �v����??�� */
/************************************/
/* Battery Level					*/
/************************************/

#define	BATT_MAX_REVEL	840		//AD Value(High)
#define	BATT_MIN_REVEL	740		//AD Value(Low)

/************************************/
/* Maxt Ivent Table					*/
/************************************/
#define	MAX_IVENT_CNT	512
//2008.05.22
#define	READ_DEV_CNT	3			/* Read Area Count */
#define	WRT_DEV_CNT		13

#define	OK	0
#define	NG	-1
#define	ON	1
#define	OFF	0
#ifndef	TRUE
#define	TRUE	1
#define	FALSE	0
#endif
#define	ENQ			0x05
#define	STX			0x02
#define	ETX			0x03
#define	EOT			0x04
#define	ACK			0x06
#define	CR			0x0D
#define	DLE			0x10
#define	DC1			0x11
#define	DC2			0x12
#define	NAK			0x15
#define	ETB			0x17


#define	BAUDRATE300		181		/* n=2 */
#define	BAUDRATE600		92
#define	BAUDRATE1200	181		/* n=1 */
#define	BAUDRATE2400	92
#define	BAUDRATE4800	181		/* n=0 */
#define	BAUDRATE9600	92
#define	BAUDRATE19200	 45
#define	BAUDRATE38400	 22
#define	BAUDRATE57600	 14
#define	BAUDRATE115200	  7
/****************************************/
#define	MAX_BASE_NO	512
#define	MAX_WIN_NO	512

/*****************************************/
/*	PC Command			                 */
/*****************************************/
#define	PC_DOWNLD	0x0101
#define	PC_COMMON	0x0102
#define	PC_PROJC	0x0103
#define	PC_BASE		0x0104
#define	PC_WINDW	0x0105
#define	PC_UPLOAD	0x0106
#define	PC_PROJHED	0x0107
#define	PC_COMENT	0x0108
#define	PC_PARTS	0x0109
#define	PC_DOWNLDED	0x010A
#define	PC_PROJEXT	0x010B
#define	PC_PROJDEL	0x010C
#define	PC_ALMHIST	0x010D
#define	PC_ALMFREQ	0x010E

#define	PC_IMAGE_SCR	0x0120		//Image Scr
#define	PC_IMAGE		0x0121		//Image File
#define	PC_COMENT_UNI	0x0122		//Comment Uni Code

#define	PC_PROJID	0x0201
#define	PC_PASSWD	0x0202
#define	PC_TABLEDW	0x0203
#define	PC_FONT		0x0204
#define	PC_PRG1		0x0205
#define	PC_PRG2		0x0206
#define	PC_PRG3		0x0207
#define	PC_PLC_CTL	0x0208		//GLP_2480

#define	PC_VECTOR	0x0210		//Vector Font


#define	PC_MODE_DWNLD	0
#define	PC_MODE_DWNOK	1
#define	PC_MODE_UPLD	2
#define	PC_MODE_UPOK	3
#define	PC_MODE_ERR		9

#define	PC_RCV_START	1
#define	PC_RCV_LENG1	2
#define	PC_RCV_LENG2	3
#define	PC_RCV_DATA		4
#define	PC_RCV_IDLE		5
#define	PC_RCV_OK		0
#define	PC_RCV_THRUE	9
#define	PC_RCV_ERROR	-9

#define	PC_SEND_PROJECT	1
#define	PC_SEND_COMMON	0
#define	PC_SEND_BASE	2
#define	PC_SEND_WINDOW	3
#define	PC_SEND_COMMENT	4
#define	PC_SEND_COMMUNI	5
#define	PC_SEND_PARTS	6
#define	PC_SEND_IMG_SC	7
#define	PC_SEND_IMG		8
#define	PC_SEND_HIST	9
#define	PC_SEND_FREQ	10

#define	PC_SEND_END		11
#define	PC_SEND_PRJHED	12
#define	PC_SEND_PRJEXT	13
#define	PC_SEND_ELSE	14

/* 20020813 choijh add */
#define	ASCII_DISPLAY		1
#define	CLOCK				2
#define	COMMENT				3
#define	ALARM_HISTORY		4
#define	ALARM_LIST			5
#define	PART_DISPLAY		6
#define	LAMP				7
#define	PANELMETER			8
#define	TREND_GRAPH			9
#define	LINE_GRAPH			10
#define	BAR_GRAPH			11
#define	STATISTICS			12
#define	TOUCH_SWITCH		13
#define	NUMERICAL_INPUT		14
#define	ASCII_INPUT			15
#define	LINE				16
#define	RECTANGLE			17
#define	CIRCLE				18
#define	TEXT_DISP			19
#define BITMAP_DATA			20
#define	NUMERICAL_DISPLAY	21
#define	SET_TIME			22
#define	SET_COMMENT			23
#define	SET_LISTBOX			24
#define	SET_IPADDR			25


#define	EDIT_DISP_LINE		0x01
#define	EDIT_DISP_RECT		0x03
#define	EDIT_DISP_CIRCLE	0x06
#define	EDIT_DISP_TEXT		0x09
#define	EDIT_DISP_BMP		0x0A
#define	EDIT_DISP_DXF		0x0B
#define	EDIT_DISP_NUM		0x64
#define	EDIT_DISP_ASCII		0x65
#define	EDIT_DISP_TIME		0x68
#define	EDIT_DISP_COMENT	0x6e
#define	EDIT_DISP_ALARMLIST	0x70
#define	EDIT_DISP_ALARMHIST	0x72
#define	EDIT_DISP_PARTS		0x78
#define	EDIT_DISP_LAMP		0x7a
#define	EDIT_DISP_PANEL		0x7b
#define	EDIT_DISP_TREND		0x82
#define	EDIT_DISP_BAR		0x84
#define	EDIT_DISP_STATSTIC	0x85
#define	EDIT_DISP_LINE_G	0x87

#define	EDIT_SET_TOUCH		0x8c
#define	EDIT_SET_NUMIN		0x96
#define	EDIT_SET_ASCIIIN	0x97

#define	EDIT_SET_TIME		0x9a
#define	EDIT_SET_COMENT		0x9b
#define	EDIT_SET_LISTBOX	0x9c
#define	EDIT_SET_IPADDR		0x9d


/* 20020821 choijh add */
#define SWITCHING_SCREEN_DEVICE	0x11
#define PASSWORD				0x12
#define BARCODE					0x13
#define SYSTEM_INFOMATION		0x14
#define TIME_ACTION				0x15
#define ALARM_HISTORY_COMMON	0x16
#define FLOATING_ALARM			0x17
#define RECIPE					0x18
#define UTILITY					0x19
/* leesi030827  */
#define CLR						0xFFA1
#define	ENT						0xFFA2
#define BS						0xFFA3
#define C_AP					0xFFA4
#define C_DAP					0xFFA5
#define DETAIL					0xFFA6	
#define PW						0xFFA7
#define S_A_E					0xFFA8
#define A_A_E					0xFFA9
#define RESET					0xFFAA
#define UP_DISP					0xFFAB
#define DOWN_DISP				0xFFAC
#define PW_RESET				0xFFAD
#define	KEY_LEFT				0xFFAE
#define	KEY_RIGHT				0xFFAF
#define KEY_END					0xFFB0

#define	KEY_CONT_PULS			0xfe01
#define	KEY_CONT_MINUS			0xfe02
#define	KEY_MOVE_RIGHT			0xfe03
#define	KEY_MOVE_LEFT			0xfe04
#define	KEY_MOVE_UP1			0xfe05
#define	KEY_MOVE_DOWN1			0xfe06
#define	KEY_MOVE_UP2			0xfe07
#define	KEY_MOVE_DOWN2			0xfe08
#define	KEY_CHANGE_DIR1			0xfe09
#define	KEY_CHANGE_DIR2			0xfe0A
#define	KEY_DELET				0xfe0B
#define	KEY_INITIAL				0xfe0C

#define	KEY_DEVICE_IN			0xfe10
#define	KEY_DEVICE_UP			0xfe11
#define	KEY_DEVICE_DOWN			0xfe12
#define	KEY_DEVICE_HEX			0xfe13
#define	KEY_DEVICE_CHN			0xfe14

#define	KEY_INSTALL1			0xfe20
#define	KEY_INSTALL2			0xfe21
#define	KEY_DEL1				0xfe22
#define	KEY_DEL2				0xfe23
#define	KEY_SAVE				0xfe24

#define	KEY_ALL_DEL				0xfe25

#define	KEY_WINDOW_YES			0xfe26
#define	KEY_WINDOW_NO			0xfe27
#define	KEY_WINDOW_CLOSE		0xfe28


#define	KEY_TOUCH_SAVE			0xfe29

#define	KEY_FORMAT1				0xfe30
#define	KEY_FORMAT2				0xfe31
#define	KEY_LOG_SET				0xfe32
#define	KEY_LOG_SET1			0xfe33
#define	KEY_LOG_SET2			0xfe34

#define	KEY_DATA_BASE			0xfe35
#define	KEY_DATA_WIND			0xfe36

//Time Setting Key
#define	KEY_DATE_YY_UP			0xfe40
#define	KEY_DATE_YY_DW			0xfe41
#define	KEY_DATE_MM_UP			0xfe42
#define	KEY_DATE_MM_DW			0xfe43
#define	KEY_DATE_DD_UP			0xfe44
#define	KEY_DATE_DD_DW			0xfe45
#define	KEY_TIME_HH_UP			0xfe46
#define	KEY_TIME_HH_DW			0xfe47
#define	KEY_TIME_MM_UP			0xfe48
#define	KEY_TIME_MM_DW			0xfe49
#define	KEY_TIME_SS_UP			0xfe4a
#define	KEY_TIME_SS_DW			0xfe4b
#define	KEY_TIME_SET			0xfe4c

#define	KEY_PRINTOUT			0xfe4d
#define	KEY_RESET				0xfe4e


#define	KEY_FIRM_UP				0xfe70

#define	KEY_BMP_TEST			0xfe80
#define	KEY_PWM_TEST			0xfe81

#define	KEY_USB_ON				0xf500		//USB ON
#define	KEY_USB_OFF				0xf501		//USB OFF

#define	PC_DNLOAD_START			0xfe00		/* Download ���� *//* ksc20090518 */

#ifndef	KEY_EVENT
#define	KEY_EVENT				0xfd00			
#endif
/* #define	UP_START	0xfc */
#define	PC_UPLOAD_START			0xfc00		/* Upload ���� *//* ksc20090518 */
#define	CHG_BASE1				0xfb00
#define	CHG_BASE2				0xfa00
#define	PC_CONT					0xf900			/* Download Continue blink */
/* #define	PC_ON	0xf8	*/		/* ksc20090518 */
#define	PC_UPDOWN_END			0xf800		/* Download/Upload �Ϸ�E*/
#define	PC_DNLOAD_END			0xf700		/* Download �Ϸ�E*/
#define	PC_UPLOAD_END			0xf600		/* Upload �Ϸ�E*/


#define	KEY_TOUCH_CD			0x0001

#define	KEY_CODE_POS			30

#define	KEY_MAIN_DOT			50
/////////////////////////////////////////////////////////////////////////
#define	MAX_USER_SCREEN		514
#define	MAX_SYS_SCREEN		514

#define	MAX_VECTOR_PTRN	512

#define	MAX_DEV_MON		32			//2012.02.24 16->32
#define	DEVNAME_MAX_CNT	17			//2012.02.24		


#define	USER_SCREEN_START_NUM	1
//	Setting Display definition
#define	SETDSP_MAIN				1
#define	SETDSP_MONIT_MAIN		101
#define	SETDSP_MONIT_IO			116
#define	SETDSP_MONIT_MODEL		136
#define	SETDSP_MONIT_CAPACITY	142

#define	SETDSP_SETTING_MAIN		151
#define	SETDSP_SETTING_PROT		161
#define	SETDSP_SETTING_SIRIAL	162
#define	SETDSP_SETTING_LUNG		166
#define	SETDSP_SETTING_IP		171
#define	SETDSP_SETTING_CONT		176
#define	SETDSP_SETTING_INIT		186
#define	SETDSP_SETTING_TIME		191

#define	SETDSP_FUNC_MAIN		201
#define	SETDSP_FUNC_TIME_MAIN	211
#define	SETDSP_FUNC_TIME_DEV	212
#define	SETDSP_FUNC_TRANS		216

#define	SETDSP_DATA_MAIN		251
#define	SETDSP_DATA_MANAGE		261

#define	SETDSP_DATA_BASE		265
#define	SETDSP_DATA_WINDOW		267
#define	SETDSP_DATA_COMMENT		269


#define	SETDSP_MONIT_DEV		271
#define	SETDSP_MONIT_DEV_BIT	281
#define	SETDSP_MONIT_DEV_WRD	291
#define	SETDSP_MONIT_DEV_DWRD	295

#define	SETDSP_TEST_MAIN		301
#define	SETDSP_TEST_SYSTEM		311
#define	SETDSP_TEST_BATTERY		313
#define	SETDSP_TEST_DSP_ST		316
#define	SETDSP_TEST_DSP_PT1		317
#define	SETDSP_TEST_DSP_PT2		318
#define	SETDSP_TEST_DSP_PT3		319
#define	SETDSP_TEST_DSP_PT4		320
#define	SETDSP_TEST_COM			321
#define	SETDSP_TEST_TOUCH_ST	326
#define	SETDSP_TEST_TOUCH		327
#define	SETDSP_TEST_MEMORY		331
#define	SETDSP_TEST_FONT		336

#define	SETDSP_TEST_BASE		341			//2011.04.19

#define	SETDSP_PARAM_MENU		351		//Main
#define	SETDSP_PARAM_COMM1		361		//Common Config
#define	SETDSP_PARAM_COMM12		362		//Common Config(No Edit)
#define	SETDSP_PARAM_COMM2		363		//Config-2
#define	SETDSP_PARAM_COMM22		364		//Config-2(No Edit)
#define	SETDSP_PARAM_COMM3		365		//Config-3
#define	SETDSP_PARAM_COMM32		366		//Config-3(No Edit)
#define	SETDSP_PARAM_ACT		371		//List-1
#define	SETDSP_PARAM_ACT2		372		//List-1(No Edit)
#define	SETDSP_PARAM_PTRN		373
//#define	SETDSP_PARAM_PTRN2		375

#define	SETDSP_LOG_MENU			400
#define	SETDSP_LOG_PERIOD		401
#define	SETDSP_LOG_CONDITON		402
#define	SETDSP_LOG_BIT_ACTION	405
#define	SETDSP_LOG_WORD_ACTION	406
#define	SETDSP_LOG_BIT_TYPE		409
#define	SETDSP_LOG_WORD_TYPE	410
#define	SETDSP_LOG_BIT_TYPE2	411
#define	SETDSP_LOG_WORD_TYPE2	412
#define	SETDSP_LOG_PERIOD_HOUR	415
#define	SETDSP_LOG_PERIOD_DAY	420
#define	SETDSP_LOG_PERIOD_WEEK	425
#define	SETDSP_LOG_PERIOD_MONTH	430
#define	SETDSP_LOG_PERIOD_RAND	435
#define	SETDSP_FIRM_UPDATE		499
////////////////////////////////////////////////////////////////////////
/* ------------- */
/* leesi 030829 CommonArea.KeyWindow.iKeyType "KeyWindow Type Setting" */
#define KEY_BINARY					3
#define KEY_OCTAL					2
#define KEY_DECIMAL					1
#define KEY_HEX						4
#define KEY_REAL					5
#define KEY_ASCII					6

#define	OVER_CODE					300
/**/

#define SCREEN_0				1
#define SCREEN_1				2
#define	MESSAGE_SCREEN			3
#define	FLOAT_SCREEN			4


#define ALARM_WIDTH				192
#define ALARM_HEIGHT			74
#define	START_YEAR				2000


#define	CODE_UB		0x7f
#define	CODE_UW		0xef
#define	CODE_SB		0x08
#define	CODE_SW		0xf8

#define	PASS_COMMENT_DSP	MAX_UW_WORD+56
#define	SETTING_BASE_ADDR		51
/*****************************************/
/*	Common Buffer Area                   */
/*****************************************/
#define	DEVICE_BIT		0
#define	DEVICE_WORD		1

typedef struct{
	unsigned char	Chanel;
	unsigned char	DevCode;
	unsigned short	PolNum;
	unsigned int	DevAddr;				/* DeviceAddress  */
}DEVICE_INF;
typedef	struct{
	unsigned char	Chanel;
	unsigned char	DevCode;
	unsigned short	PolNum;
	short	DevFlag;		/* 0:Bit,1:Word */
	short	Continus;
	int		DevAddress;
	short	DevCnt;
	short	Order;
	char	*DevData;
	short	SameDevInf;
	short	Patarn;
}DEV_DATA;
typedef struct{
	char	*Device;
	int		StartAddr;
	int		flag;		/* 0:EXT,1:INT */
}DEV_TBL;
typedef struct{
	char	*Device;
	int		DevCode;
	int		StartAddr;
	int		flag;		/* 0:EXT,1:INT */
}DEV_CODE_TBL;
typedef struct{
	char	Kubun;							/* NO USE */
	char	Index;							/* Device Code */
	char	DevName[5];						/* Device Name */
	unsigned char DevInfo;					/* 1 1 1 1 1 1 1 1 */
	                                        /*         ------- */
	                                        /*           0:  8/ 8 */
	                                        /*           1:  8/10 */
	                                        /*           2:  8/16 */
	                                        /*           3: 10/ 8 */
	                                        /*           4: 10/10 */
	                                        /*           5: 10/16 */
	                                        /*           6: 16/ 8 */
	                                        /*           7: 16/10 */
	                                        /*           8: 16/16 */
	                                        /*           9: 10    */
	                                        /* 0 0 1 0 -------    */
											/*     32Bit Word Use */
	                                        /* 0 1 0 0 -------    */
											/*   Word+Bit         */
	                                        /* 1 0 0 0 -------    */
											/*   DevMon Display   */
	unsigned int		DeviceMin;
	unsigned int		DeviceMax;
	int		LowDeviceMin;
	int		LowDeviceMax;
	int		LowKeta;
	int		WordType;
}DEV_PC_TBL;

typedef struct{
	int		cnt;
	unsigned char	frame[50];
}DATA_FRAME;

/****************************************/
/*	Read Device Bit						*/
/****************************************/
/* Signal 1								*/
#define	R_RST_ON	0x0001
#define	R_BLK_ON	0x0002
#define	R_PLC_ON	0x0004				/* PLC Error ?�� */
#define	R_PLC_ON2	0x0008				/* SUB PLC Error ?�� */
#define	R_BAR_DI	0x0010
#define	R_BAR_ON	0x0020
#define	R_INPUT_ON	0x0080				/* Input End Bit */
/* Signal 3								*/
#define	R_BZR_ON	0x0001
#define	R_BZR_S_ON	0x0002
#define	R_BLK_P_ON	0x0010
#define	R_PRT_ON	0x0020
/****************************************/
/*	Write Device Bit					*/
/****************************************/
/* Signal 2								*/
#define	W_ALM_ON	0x0001
#define	W_NUM_IN	0x0010
#define	W_BAR_ON	0x0100
#define	W_LOW_ON	0x1000
/* Signal 4								*/
#define	W_PRT_ON	0x0001
#define	W_RS1E_F	0x0100
#define	W_RS1E_P	0x0200
#define	W_RS1E_O	0x0400
#define	W_RS2E_F	0x1000
#define	W_RS2E_P	0x2000
#define	W_RS2E_O	0x4000
/****************************************/
/*	Trend Buffer Max Size				*/
/****************************************/
#define	TREND_MAX	51
/************************************/
/*	RS-232C DRV						*/
/************************************/
#define	RS_CNTL		0
#define	RS_SEND		1
#define	RS_INIT		0
#define	RS_RTSON	1
#define	RS_RTSOFF	2
#define	RS_300		0
#define	RS_600		1
#define	RS_1200		2
#define	RS_2400		3
#define	RS_4800		4
#define	RS_9600		5
#define	RS_19200	6
#define	RS_38400	7
#define	RS_57600	8
#define	RS_115200	9
#define	RS_NONE		0
#define	RS_ODD		1
#define	RS_EVEN		2
#define	RS_DATA7	0
#define	RS_DATA8	1
#define	RS_STOP01	0		/* 1 bit */
/* #define	RS_STOP15	1	*/	/* 1.5bit */  
#define	RS_STOP02	1		/* 2 bit */
#define	RS_XONOFF	0
#define	RS_DTRDSR	1

//********************************************************
//Communication Chanel
//SERIAL_CH0 = RS_PLC
//SERIAL_CH1 = RS_PC
//USB_CH0 = RS_USB
//ETHERNET_CH0 = RS_NET
//********************************************************
#define	SERIAL_CH0			0		
#define	SERIAL_CH1			1		
#define	USB_CH0				2
#define	ETHERNET_CH0		3
#define	INTERNAL_CH0		99
//*********************************************************

/************************************/
/*	PLC HAND						*/
/************************************/
#define	PLC_CNTL		0
#define	PLC_READ		1
#define	PLC_WRITE		2
#define	PLC_CHK			3
#define	PLC_THRUE		4
#define	PLC_GROOP		5
#define	PLC_GR_MAK		6
#define	PLC_CNECT		7
#define	PLC_GET_NAME	8
#define	PLC_READ2		9
#define	PLC_WRITE2		10
#define	PLC_CNECT2		11
#define	PLC_THRUE_PLC	12
#define	PLC_MONIT_OFF	13
#define	PLC_CON			14

#define	PLC_BIT		0
#define	PLC_WORD	1

/************************************/
/*	RTC HAND						*/
/************************************/
#define	RTC_READ_I	0
#define	RTC_READ	1
#define	RTC_WRITE	2
#define	PRT_WRITE	3
#define	RTC_RUN_LED	4


#define	DEV_CR	0xf0
#define	DEV_TR	0xf1
#define	DEV_CS	0xf8
#define	DEV_TS	0xf9

/************************************/
/*	GLP COMM						*/
/************************************/
enum{IDLE,STX_WAIT,DATA_RECEIVE_COMPLETE_WAIT,BCC1_RECEIVE_WAIT,
	BCC2_RECEIVE_WAIT,ENQ_ANS_WAIT,DATA_SEND_WAIT
};
/* 20060615 Program index */
/************************************/
/*	INDEX TABLE						*/
/************************************/

#define		APL_PROGRAM_START_ADDR	0x30200000
#define		APL_LARG_BUFF_START_ADDR	0x32d00000			//2011.09.21 Change
typedef struct{												//2011.09.21 Change
	union{													//2011.09.21 Change
		unsigned char	bmpResizeBuff[0x200000];			//2011.09.21 Change
		unsigned char	DOWNLOAD_AREA[0x100000];			//2011.09.21 Change
	}workLargBuff;											//2011.09.21 Change
}WORK_LARG;													//2011.09.21 Change


#ifdef	MAIN												//2011.09.21 Change
	#ifdef	WIN32											//2011.09.21 Change
		unsigned char	LargBuffArea[0x200000];				//2011.09.21 Change
	#endif													//2011.09.21 Change
		WORK_LARG	*LargmemBuff;							//2011.09.21 Change
#else														//2011.09.21 Change
	#ifdef	WIN32											//2011.09.21 Change
		extern	unsigned char	LargBuffArea[0x200000];		//2011.09.21 Change
	#endif													//2011.09.21 Change
		extern	WORK_LARG	*LargmemBuff;					//2011.09.21 Change
#endif														//2011.09.21 Change	
#ifdef	WIN32
#ifdef	MAIN
	unsigned char	ProtocolArea[0x10000];
#else
	extern	unsigned char	ProtocolArea[0x10000];
#endif
#define		PLC1_DEV_TABLE	&ProtocolArea[0]
#define		PLC1_PROTOCOL	&ProtocolArea[0x1200]
#define		PLC1_PROTOCOL_SIZE		0x8000
#define		PLC2_DEV_TABLE	&ProtocolArea[0x8000]
#define		PLC2_PROTOCOL	&ProtocolArea[0x9200] 
#define		PLC2_PROTOCOL_SIZE		0x8000
#else
#define		PLC1_DEV_TABLE			0x300F0000        /* 20060614 */
#define		PLC1_PROTOCOL			0x300F1200 
#define		PLC1_PROTOCOL_SIZE		0x8000
#define		PLC2_DEV_TABLE			0x300F8000        /* 20060614 */
#define		PLC2_PROTOCOL			0x300F9200  
#define		PLC2_PROTOCOL_SIZE		0x8000
#endif

//#define		KEY_WINDOW				0x0D0000		/* 20060614 */
//#define		KEY_WINDOW_BIN_H		0x0D0000
//#define		KEY_WINDOW_OCT_H		0x0D0300
//#define		KEY_WINDOW_DEC_H		0x0D0700
//#define		KEY_WINDOW_HEX_H		0x0D0C00
//#define		KEY_WINDOW_REAL_H		0x0D1100
//#define		KEY_WINDOW_ASCII_H		0x0D1600
//#define		KEY_WINDOW_BIN_V		0x0D1D00
//#define		KEY_WINDOW_OCT_V		0x0D2000
//#define		KEY_WINDOW_DEC_V		0x0D2400
//#define		KEY_WINDOW_HEX_V		0x0D2900
//#define		KEY_WINDOW_REAL_V		0x0D2F00
//#define		KEY_WINDOW_ASCII_V		0x0D3400

#define		FONT_ASCII68			0x000000					//0x0D3C00
#define		FONT_ASCII88			FONT_ASCII68+0x000300		//0x0D3F00
#define		FONT_ASCII816			FONT_ASCII88+0x000300		//0x0D4200
#define		FONT_HEXA2432			FONT_ASCII816+0x000600		//0x0D4800
#define		FONT_HEXA2448			FONT_HEXA2432+0x000700		//0x0D4F00
#define		FONT_HEXA2464			FONT_HEXA2448+0x000A00		//0x0D5900
#define		FONT_HEXA3232			FONT_HEXA2464+0x000D00		//0x0D6600
#define		FONT_HEXA3248			FONT_HEXA3232+0x000900		//0x0D6F00
#define		FONT_HEXA3264			FONT_HEXA3248+0x000D00		//0x0D7C00
#define		FONT_HEXA4832			FONT_HEXA3264+0x001100		//0x0D8D00
#define		FONT_HEXA4848			FONT_HEXA4832+0x000D00		//0x0D9A00
#define		FONT_HEXA4864			FONT_HEXA4848+0x001400		//0x0DAE00
#define		FONT_HEXA6432			FONT_HEXA4864+0x001A00		//0x0DC800
#define		FONT_HEXA6448			FONT_HEXA6432+0x001100		//0x0DD900
#define		FONT_HEXA6464			FONT_HEXA6448+0x001A00		//0x0DF300

#define		FONT_NATION 			FONT_HEXA6464+0x002200		//0x0E1500
#define		FONT_END	 			FONT_NATION+0x08EB00
#ifdef	MAIN
	unsigned char	FontArea[FONT_END];
#else
	extern	unsigned char	FontArea[FONT_END];
#endif


//#define		NEWFONT					1

//#define		GP_USER_DATA 			0x170000
//#define		GP_USER_DATA_SIZE		0x060000	/* 768*512 */
//#define		PLC_USER_DATA 			0x1D0000
//#define		PLC_USER_DATA_SIZE		0x020000	/* 256*512 */
//#define		GP_FILE_DIR 			0x1F0000
//#define		GP_FILE_DIR_SIZE 		0x006000	/* 768*32 */
//#define		PLC_FILE_DIR 			0x1F6000
//#define		PLC_FILE_DIR_SIZE 		0x002000	/* 256*32 */
//#define		GP_SETTING_AREA 		0x1F8000
//#define		GP_SETTING_AREA_SIZE	0x001000
//#define		PLC_SETTING_AREA		0x1F9000
//#define		PLC_SETTING_AREA_SIZE	0x001000
//#define		GP_FAT_DIR 				0x1FA000
//#define		GP_FAT_DIR_SIZE			0x001000	/* 768*2= 0x600 */
//#define		PLC_FAT_DIR 			0x1FB000
//#define		PLC_FAT_DIR_SIZE		0x001000	/* 256*2= 0x200 */

//#define		PLC_PARAM_FILE			0x1FC000
#define		PLC_PARAM_SIZE			0x00010000
#define		PLC_SETTING_AREA_SIZE	0x00001000
#ifdef	MAIN
	unsigned char	PlcParamArea[PLC_PARAM_SIZE];
	unsigned char	PlcSettingArea[PLC_SETTING_AREA_SIZE];
#else
	extern	unsigned char	PlcParamArea[PLC_PARAM_SIZE];
	extern	unsigned char	PlcSettingArea[PLC_SETTING_AREA_SIZE];
#endif

//#define		GP_USER_DATA_BLOCK		( GP_USER_DATA_SIZE / 0x10000 )
//#define		PLC_USER_DATA_BLOCK		( PLC_USER_DATA_SIZE / 0x10000 )
/******************************************************************/
/* File System */
//FLASH ADDRESS+++++++++++++++++++++++++++++++++
//#define	FLASH_START			0x00000000
//#define	F_FILE_AREA			(GP_USER_DATA+FLASH_START)
//#define	F_DIR_AREA			(GP_FILE_DIR+FLASH_START)
//#define	F_SETTEIFILE_AREA	(GP_SETTING_AREA+FLASH_START)
//#define	F_SETTEIFILE_SIZE	0x00001000
//#define	F_PLC_SETTEIFILE_AREA	(PLC_SETTING_AREA+FLASH_START)
//#define	F_FAT_AREA			(GP_FAT_DIR+FLASH_START)

//#define	F_FILE_AREA2		(PLC_USER_DATA+FLASH_START)
//#define	F_DIR_AREA2			(PLC_FILE_DIR+FLASH_START)
//#define	F_FAT_AREA2			(PLC_FAT_DIR+FLASH_START)
//++++++++++++++++++++++++++++++++++++++++++++++
//#define	F_FAT_SIZE			0x00002000		/* 8KB  */
//#define	F_DIR_SIZE			0x00008000		/* 32KB */
//#define	F_FILE_BLOCK		8
#define SECT_SIZE   512
//#define SECT_CLST   1
//#define RESV_SECT   0
//#define NOOFFAT     1

#define	GP_USER_DATA_SIZE	0xa00000
//#define GP_TOTAL_SECT  (GP_USER_DATA_SIZE/SECT_SIZE)		/* 256KB-24KB(0x3A000/512) */
//#define PLC_TOTAL_SECT  (PLC_USER_DATA_SIZE/SECT_SIZE)		/* 256KB-24KB(0x3A000/512) */
#define	CLUST_SECT	8			//Cluster per Sect Num
#define GP_TOTAL_CLUST  (GP_USER_DATA_SIZE/SECT_SIZE/CLUST_SECT)
#define	GP_CLUST_BYTE	(SECT_SIZE*CLUST_SECT)

#define	GP_LOG_DATA_SIZE	0x2000000
#define GP_TOTAL_LOG_CLUST  (GP_LOG_DATA_SIZE/SECT_SIZE/CLUST_SECT)

//#define FAT_SECT    2			/* 40000(512FAT) */
//#define SECT_TRCK   1

//#define DIR_BASE    0                    /*   2  */
//#define CLAST_BASE  0			                          /*  2  */
//#define GP_TOTAL_CLAST (GP_TOTAL_SECT-CLAST_BASE)                         /* 358  */
//#define PLC_TOTAL_CLAST (PLC_TOTAL_SECT-CLAST_BASE)                         /* 358  */
//#define DELETED     0xff


//#define NO_DIR_SECT (GP_TOTAL_SECT/(SECT_SIZE/sizeof(struct dir)))
//#define NO_FAT_SECT (GP_TOTAL_SECT/(SECT_SIZE/2))
//#define NO_PLC_DIR_SECT (PLC_TOTAL_SECT/(SECT_SIZE/sizeof(struct dir)))
//#define NO_PLC_FAT_SECT (PLC_TOTAL_SECT/(SECT_SIZE/2))

/*******************/
//#define	APLDW_START		0x04000000
//#define	APLDW_SIZE		0x00004000
//#define	APL_BOADRATE	0x040efff0
//#define	APL_CONTRAST	0x040efff4

typedef struct{
	char	*strData;
	int		dumy;
}PLC_CONST;

typedef struct{
	int		strData;
	int		dumy;
}PLC_INT_CONST;


//LED MODE
#define	LED_MODE_OFF	0x0000
#define	LED_MODE_RUN	0x0001
#define	LED_MODE_ERR	0x0002
#define	LED_MODE_DBG	0x0004
#define	LED_MODE_PSE	0x0008


typedef struct{
	int		iScreenNo;
	void	(*RsCall)( int* );
}SET_PROC;

typedef struct{
	int				year;			/* year[0]:10,year[1]:1 */
	int				mon;			/* mon[0]:10,mon[1]:1 */
	int				day;			/* day[0]:10,day[1]:1 */
	int				week;			/* week               */
	int				hour;			/* hour[0]:10,hour[1]:1 */
	int				min;			/* min[0]:10,min[1]:1 */
	int				sec;			/* sec[0]:10,sec[1]:1 */
} RTC_DATA;



#ifndef	COLOR_DT_DEFINE
#define	COLOR_DT_DEFINE

//typedef  struct{			/* Color Data Table */
//	unsigned char   b;		//BLUE
//	unsigned char   g;		//GREEN
//	unsigned char   r;		//RED
//	unsigned char   d;		//Dumy
//}COLOR_DT;
#define	COLOR_DT	unsigned int
#endif

#define	MAX_FILE_PAGE_CNT	16
typedef struct{
	int		serchFileCnt;
	int		attribute[MAX_FILE_PAGE_CNT];
	int		Select[MAX_FILE_PAGE_CNT];
	char	serchFileName[MAX_FILE_PAGE_CNT][260];
	char	serchFileName_uni[MAX_FILE_PAGE_CNT][260*2];
}FILE_INF;

////////////////////////////////////////////////////////////////////
//	System File Name
////////////////////////////////////////////////////////////////////
#define	ENV_SETING_FILE			"ENV_SET.GP"
#define	SYS_SETING_FILE			"SYS_SET.GP"
#define	USR1_PLC1_PROTCOL_FILE	"PL1_PROT.GP"
#define	USR1_PLC2_PROTCOL_FILE	"PL2_PROT.GP"
#define	USR1_PROJECT_FILE		"PROJECT.GP"
#define	USR1_COMMON_FILE		"COMMON.GP"
#define	USR1_COMMENT_FILE		"COMMENT.GP"
#define	USR1_COMMENT_UNI_FILE	"COMMUNI.GP"
#define	USR1_PARTS_FILE			"PARTS.GP"
#define	USR1_IMAGE_SCR_FILE		"IG_SCR.GP"
#define	USR1_VECT_FILE			"VECT_FNT.GP"
#define	USR1_VECT_FILE_TEMP		"TVECTFNT.GP"

#define	SYS_COMMENT_FILE		"COMMENT.GP"
#define	SYS_PARTS_FILE			"PARTS.GP"



//#define	GP_LOG_FILE				"B:\\LOGDATA.GP"

#define	GP_BASE_DEV	"A:\\"
#define	GP_SYS_DEV	"C:\\"
#define	GP_USB_DEV	"D:\\"
#define	GP_WORK_DEV	"F:\\"
#define	GP_PTN_DEV	"G:\\"

#define	GP_SYS_NATION_DEV	"C:\\NATION\\"
#define	GP_SYS_ENGLISH_DEV	"C:\\ENGLIS\\"

#define	PLC_WORK_DEV	"E:\\"
/******************************************************************/
//GLP File Structure
//2012.02.11 Move To nand.h
//#define	TOUCH_CALIB_AREA	0x0002000
//#define	MAC_ADDR_AREA		0x0002200		//4Byte:SeqNo,6Byte:MacAddr

typedef struct{
	unsigned char	name[100];				//100
	unsigned char	typeflag[4];
	unsigned char	size[4];
	unsigned char	reseve[92];
	unsigned char	version[4];				//200
	unsigned char	id[4];					//204
//2011.09.29	unsigned char	lung;					//208
	unsigned char	model[4];				//208
//2011.09.29	unsigned char	FirmVersion[20];		//209
	unsigned char	FirmVersion[17];		//209
	unsigned char	Sysinf[2];				//229
	unsigned char	reseve1[280];
	unsigned char	sum;
}GLP_HEAD;

#define	KEYWIN_STARTX	9
#define	KEYWIN_STARTY	9
typedef struct{
	int	x;
	int	y;
}KEY_ADDR;
typedef struct{
	int	VectorSaveFlag;
	int	width;
	int	height;
	int	StartY;
}VECTFONT_SIZE;
//Lamp,Touch Text Alinement
#define	ALINE_OVER_TOP		1
#define	ALINE_TOP			2
#define	ALINE_OVER_BOTTOM	3
#define	ALINE_BOTTOM		4
#define	ALINE_CENTER		5
//////////////////////////////
//	RAM_Disk No
//////////////////////////////
#define	DEV_USER1_DISK	0				//USER DOWNLOAD DATA DISK
#define	DEV_USER2_DISK	1				//USB SLAVE DISK
#define	DEV_SYS_DISK	2				//SYSTEM DISK
#define	DEV_USB_DISK	3				//USB HOST DISK
#define	DEV_USER3_DISK	4				//LP DOWNLOAD DATA DISK
#define	DEV_RAM_DISK	5				//USER(GP) DATA COPY
#define	DEV_PTN_DISK	6				//VECT FONT PATARN

typedef struct{
	int	PosDigitX;
	int	PosDigitY;
	int	PosAnalogX;
	int	PosAnalogY;
}TCAL_DATA;
typedef struct{
	int Prescaler;
	int Devid;
	int Count;
	int CmpCnt;
}BCAL_DATA;
typedef struct{
	 TCAL_DATA	CalibPos[2];
	 BCAL_DATA	BackCal;
}GLP_CAL_DATA;
