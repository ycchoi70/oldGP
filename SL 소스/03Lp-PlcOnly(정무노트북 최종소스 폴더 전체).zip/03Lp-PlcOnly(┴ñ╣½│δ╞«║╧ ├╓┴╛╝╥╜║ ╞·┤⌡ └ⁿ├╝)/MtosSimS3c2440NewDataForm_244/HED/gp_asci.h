void	SetAsciiInput_Func(int iDispOrder);
int	DrawAsciiInput_Func(int mode,_ASCIIINPUT_EVENT_TBL* AsciiInputEventTbl,int iDispOrder);
void AsciiInputDispWatch(int iOrder);
int	AsciiInputTouchCheck(int iOrder);
