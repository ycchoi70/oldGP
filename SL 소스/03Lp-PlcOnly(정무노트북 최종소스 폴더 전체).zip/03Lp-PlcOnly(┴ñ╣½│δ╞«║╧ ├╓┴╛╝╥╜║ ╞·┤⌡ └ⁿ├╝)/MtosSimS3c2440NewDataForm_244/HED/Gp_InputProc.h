
typedef struct{
	int	iInputStartX;
	int	iInputStartY;

	int	iInputKind;
	int	i1632BitFlag;
	int	iIntputMaxlen;
	int	*iDataAddr;
	int	iSyoFlag;
	int	iSignedFlag;
	int	imaxValue;
	int	iminValue;
	int	iDecimalPoint;

	int	iBackColor;
	char	cInputData[32];
}INPUT_INFO;


#define	WIN_MSG_FIRM_ERROR		0
#define	WIN_MSG_DELETE			1
#define	WIN_MSG_FIRM_UPDATE		2
#define	WIN_MSG_FIRM_UP_CFM		3
#define	WIN_MSG_INSTALL			4
#define	WIN_MSG_NOW_INSTALL		5
#define	WIN_MSG_DEV_ERROR		6
#define	WIN_MSG_FORMAT			7
#define	WIN_MSG_FORMAT_ERROR	8
#define	WIN_MSG_FORMAT_START	9
#define	WIN_MSG_INSTALL_ERROR	10
#define	WIN_MSG_FILE_COPY		11
#define	WIN_MSG_TOUCH_ERROR		12
#define	WIN_MSG_TOUCH_OK		13
#define	WIN_MSG_PRINT_OUT		14
#define	WIN_MSG_PRINT_OUT_ERROR	15
#define	WIN_MSG_TIMESW_DEL		16
#define	WIN_MSG_TIMESW_ALLDEL	17
#define	WIN_MSG_GP_CLEAR		18
#define	WIN_MSG_LP_CLEAR		19
#define	WIN_MSG_DATA_FILE_COPY	20
#define	WIN_MSG_INSTALL_TYPE_ER	21
#define	WIN_MSG_LOGGER_DELETE_AL	22
#define	WIN_MSG_LOGGER_DELETE_ITM	23
#define	WIN_MSG_LOGGER_SEL_ERROR	24


#ifdef	GP_INPUTPROC

	char*	InputMessTitle[]={
		"FIRMWARE UPDATE"	,"FILE DELETE"	,"FILE INSTALL"	,"DEVICE INPUT"	,
		"FILE FORMAT"		,"DOWNLOAD"		,"TOUCH"		,"PRINT"		,
		"TIME SWITCH"		,"DATA CLEAR"	,"FILE COPY"	,"DATA LOGGER"	,
	};
	char*	InputMessString[]={
		"Do you want to firmware update?",			//0
		"Do you want to delete?",					//1
		"Do you want to install?",					//2
		"Firmware update start",					//3
		"Firmware file error",						//4
		"Install Start",							//5
		"Device Error",								//6
		"Do you want to format?",					//7
		"Can not format",							//8
		"Format Start",								//9
		"Install Error",							//10
		"GP File Copy Start",						//11
		"Touch Area Error!!",						//12
		"Print Alarm history?",						//13
		"Print mode is not.",						//14
		"Touch Area Write OK?",						//15
		"Do you want to delete the Timeswitch?",    //16 
		"Do you want to delete all Timeswitch?",    //17 
		"Do you want to clear GP data?",			//18 
		"Do you want to clear LP data?",			//19 
		"File Copy Start",							//20 
		"Model Type Error",							//21 
		"Do you want to delete all Logger?",	  //22 
		"Do you want to delete the Logger?",	  //23 
		"No Select Item Error!!",				  //24 
	};


	int	siDispOrder;
	int	sScalePosCnt;
	int sTouchSwitchDispCnt;
#else
	extern	int	siDispOrder;
	extern	int	sScalePosCnt;
	extern	int sTouchSwitchDispCnt;
#endif

extern	int		GetKeyWindowCode(int no);

int	Gp_InputProc(INPUT_INFO* in_inf,int inKind);
int	Gp_DeviceNameInputProc(INPUT_INFO* in_inf,int inKind);
void	SaveInpuStatus(void);
void	ReSaveInpuStatus(void);
void	Gp_DeviceInputProc(int inKind);
void	DevisUpProc(void);
void	DevisDownProc(void);
unsigned char *DevMonWinAddr(int kind);
void	MakeDeviceMonGamen(int kind);
void	DevisRedispProc(void);
void	PasswordInputProc(void);
void	ReConfirmOkNg(void);
void	ReConfirmOkNgNoDisp(void);
int	checkWindowArea(int no,_TOUCHKEY* pKeyData);
int	GetKeyData(int iScreenNum,_TOUCHKEY* pKeyData);
void	DevisPoleChangeProc(void);
int	CheckDeviceAddressGetNext(int chanel,int idx,int *addr);

//�߰� 2012.02.24,
void	GetMonitorDevPole(void);
void	GetTimeSwDevPole(void);
void	GetLogSaveDevPole(void);
void	GetLogCondDevPole(void);
void	SetMonitorDevPole(void);
void	SetTimeSwDevPole(void);
void	SetLogSaveDevPole(void);
void	SetLogCondDevPole(void);
int	InternalStartAddr(int code);
