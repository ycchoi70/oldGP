/********************************************/
/*	�ʐM������							*/
/********************************************/
#ifdef	MAIN
/* COM0(RS-422)								*/
/********************************************/
	/* PLC Work */
	/* SIO0 REC/SEND BUFF */
//volatile	int		Comm0RecMode;		/* PLC Rec Mode */
//volatile	int		Comm00RecMode;		/* PLC Rec Mode */
//volatile	int		Sio0SndCnt;
//volatile	int		Sio0RecCnt;
//volatile	int		Sio00RecCnt;
//	unsigned char	Sio0SndBuff[PLC_BUF_MAX];
//	unsigned char	Sio0RecBuff[PLC_BUF_MAX];
//	unsigned char	Sio00RecBuff[PLC_BUF_MAX];
//volatile	int		Sio00BufIdx;		//20090112
//volatile	int		Comm00sRecMode[2];				/* 20090112 */
//volatile	int		Sio00sRecCnt[2];				/* 20090112 */
//volatile	int		Comm00Result[2];				/* 20090112 */
//volatile	int		Comm00RecKind[2];				/* 20090112 */
//	unsigned char	Sio00sRecBuff[2][PLC_BUF_MAX];	/* 20090112 */
/********************************************/
/* COM1(RS-232C)							*/
/********************************************/
//volatile	int		CommMode;			/* Rec Mode par 1 Record */
//volatile	int		PC_CommMode;		/* Rec Mode par 1 Record */
//volatile	int		CommCnt;			/* Recieve Length(Prot) */
//volatile	int		RecCommCnt;			/* Recive Length */
//volatile	int		CommKind;			/* Download File Kind */
//volatile	int		SendCommCnt;		/* Send Length */
//	unsigned char	SendBuff[PLC_BUF_MAX];
//	unsigned char	CommBuff[PLC_BUF_MAX];
	/* SIO0 REC/SEND BUFF */
volatile	int		PlcThrueCnt;
/* 20081003 */
	unsigned char	PlcThrueBuff[512+32];

#else
/********************************************/
/* COM0(RS-422)								*/
/********************************************/
	/* PLC Work */
	/* SIO0 REC/SEND BUFF */
//	extern	volatile	int		Comm0RecMode;		/* PLC Rec Mode */
//	extern	volatile	int		Comm00RecMode;		/* PLC Rec Mode */
//	extern	volatile	int		Sio0SndCnt;
//	extern	volatile	int		Sio0RecCnt;
//	extern	volatile	int		Sio00RecCnt;
//	extern	unsigned char	Sio0SndBuff[PLC_BUF_MAX];
//	extern	unsigned char	Sio0RecBuff[PLC_BUF_MAX];
//	extern	unsigned char	Sio00RecBuff[PLC_BUF_MAX];
//	extern	volatile	int		Sio00BufIdx;		//20090112
//	extern	volatile	int		Comm00sRecMode[2];				/* 20090112 */
//	extern	volatile	int		Sio00sRecCnt[2];				/* 20090112 */
//	extern	volatile	int		Comm00Result[2];				/* 20090112 */
//	extern	volatile	int		Comm00RecKind[2];				/* 20090112 */
//	extern	unsigned char	Sio00sRecBuff[2][PLC_BUF_MAX];	/* 20090112 */
/********************************************/
/* COM1(RS-232C)							*/
/********************************************/
//	extern	volatile	int		CommMode;			/* Rec Mode par 1 Record */
//	extern	volatile	int		PC_CommMode;		/* Rec Mode par 1 Record */
//	extern	volatile	int		CommCnt;			/* Recieve Length(Prot) */
//	extern	volatile	int		RecCommCnt;			/* Recive Length */
//	extern	volatile	int		CommKind;			/* Download File Kind */
//	extern	volatile	int		SendCommCnt;		/* Send Length */
//	extern	unsigned char	SendBuff[PLC_BUF_MAX];
//	extern	unsigned char	CommBuff[PLC_BUF_MAX];
	/* SIO0 REC/SEND BUFF */
	extern	volatile	int		PlcThrueCnt;
/* 20081003 */
	extern	unsigned char	PlcThrueBuff[512+32];
#endif
