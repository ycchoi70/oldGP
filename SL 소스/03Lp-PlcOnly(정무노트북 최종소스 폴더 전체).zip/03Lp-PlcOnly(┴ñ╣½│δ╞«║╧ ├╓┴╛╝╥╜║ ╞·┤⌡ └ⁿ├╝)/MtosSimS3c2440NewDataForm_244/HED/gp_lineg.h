void	SetLineGraph_Func(int iDispOrder);
int	DrawLineGraph_Func(int mode,_LINEGRAPH_EVENT_TBL* LineGraphEventTbl,int iDispOrder);
void LineGraphDispWatch(int iOrder);
