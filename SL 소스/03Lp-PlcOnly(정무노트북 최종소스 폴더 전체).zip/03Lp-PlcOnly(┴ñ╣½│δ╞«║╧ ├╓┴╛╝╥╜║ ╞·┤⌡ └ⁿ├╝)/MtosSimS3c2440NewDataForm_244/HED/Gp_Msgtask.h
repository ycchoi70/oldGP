
#ifdef	MSGTASK_PROC
	int		MsgXbai,MsgYbai;
	int		MsgVector;
	int		MsgVectorKind;
	int		MsgVectorSize;
	int		MsgWidth;
	int		MsgHeight;
	int		MsgCharSize;
	int		MessageCnt;
	int		NowMessageIdx;
	int		NowMessageFlag;
	int		NowMessageXCnt;
	int		MessageCloseFlag;
	/*ksc20040727_owashi*/
	int		MessageOpenFlag;		/* 040726 */
	/*ksc20040727_owashi*/
	int		MessageNo;
	int		NowOnDevCnt;
	int		FloatingMessOn;
	int		FloatOpenFlag;
	#define	ONDEV_FLOAT_CNT	256		/* 2008.05. 23 */
	unsigned long	MessColor;
	unsigned char	NowOnDevNo[ONDEV_FLOAT_CNT];
	unsigned char	NowMessageData[1024+2];
	unsigned char	Now1LineMessage[1024+2];
	unsigned char	Now1LineMakeMessage[1024+2];
#endif
