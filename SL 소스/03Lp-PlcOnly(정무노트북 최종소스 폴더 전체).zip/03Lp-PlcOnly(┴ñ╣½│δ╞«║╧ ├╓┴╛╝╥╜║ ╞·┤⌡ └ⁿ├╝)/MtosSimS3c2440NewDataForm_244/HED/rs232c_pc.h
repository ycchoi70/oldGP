
#include	"s2440.h"


///////////////////////////////////////////////////////////////////////
//	�����̈�
///////////////////////////////////////////////////////////////////////
typedef struct{
	int					ch;				//Chanel
	int					iINT_RXD;		//(0:1,1:8,2:64)
	int					iIOP_TX;		//Count(0:2,1:4,2:6)
	int					iCLKEN_UART;	//
	int					iIntNo;
	int					iINTSRC_UART;
	volatile UART_REG   *pUART;
	volatile	int		SndCnt;
	unsigned char		SndBuff[PLC_BUF_MAX];
	volatile	int		RecCnt;
	volatile	int		sRecCnt[2];
	unsigned char		RecBuff[PLC_BUF_MAX];
	volatile	int		sRecBufIdx;					/* Save Rec Index		*/
	unsigned char		sRecBuff[2][PLC_BUF_MAX];
	volatile	int		RecMode;					/* Rec Mode par 1 Record */
	volatile	int		Result;
	volatile	int		RecKind;
	volatile	int		IntRecMode;					/* Rec Mode par 1 Record */
	volatile	int		IntCommCnt;					/* Command Length		*/
	volatile	int		IntSioRecCnt;				/* Interrupt Rec Count	*/
	unsigned char		IntSioRecBuff[PLC_BUF_MAX];	/* Interrupt Rec Buff	*/
	volatile	int		SioBufIdx;					/* Save Rec Index		*/
	volatile	int		SioRecCnt[2];				/* Save Rec Count		*/
	volatile	int		CommResult[2];				/* Save Rec Result		*/
	volatile	int		CommRecKind[2];				/* Save Rec Kind		*/
	unsigned char		SioRecBuff[2][PLC_BUF_MAX];	/* Save Rec Buff		*/
	volatile	int		UartSndCnt;
	unsigned char		*UartSndPos;
	unsigned char		UartSndBuff[PLC_BUF_MAX];
	int					ReadPos;
	int					Readindex;			//1Block�̃C���f�b�N�X
//	int					Writeindex;			//1Block�̃C���f�b�N�X
	int					WritePos;
	int					WriteLen[64];
	unsigned char		IntSioRecBlockBuff[64][32];	/* Interrupt Rec Buff	*/

#ifdef	WIN32
	int					DataRecieveDone;
	int					DataSendDone;
#endif
}UART_STRUCT;

#ifdef	RS232C_PC
	UART_STRUCT	_Sci0Tbl;
	UART_STRUCT	_Sci1Tbl;
	UART_STRUCT	_Sci2Tbl;

	volatile	unsigned int RecTimeOut;
	int	PlcEditorPort;				//PLC Editor Connect Port
	volatile	unsigned int	PcTimeout;
	volatile	unsigned int	PcTimeout1Char;
	volatile	unsigned int	PcTimeout1Char0;
	volatile	unsigned int	PlcTimeout;
	volatile	unsigned int	PlcTimeout1Char;
	volatile	unsigned int	PlcTimeout1Char0;
	volatile	unsigned int	MonTimeout;
	volatile	unsigned int	SavePcTimeout;
	volatile	unsigned int	SavePcTimeout1Char;
	volatile	unsigned int	SavePcTimeout1Char0;
	volatile	unsigned int	SavePlcTimeout;
	volatile	unsigned int	SavePlcTimeout1Char;
	volatile	unsigned int	SavePlcTimeout1Char0;
	volatile	unsigned int	SaveMonTimeout;
	volatile	unsigned int	GlpTimeout;


	#ifdef	LOG
	int		volatile	rs1Cnt;
	int		volatile	rs1SaveCnt;
	char	rs1log[2048];
	#endif
#else
	extern	UART_STRUCT	_Sci0Tbl;
	extern	UART_STRUCT	_Sci1Tbl;
	extern	UART_STRUCT	_Sci2Tbl;

	extern	volatile	unsigned int RecTimeOut;
	extern	int	PlcEditorPort;				//PLC Editor Connect Port
	extern	volatile	unsigned int	PcTimeout;
	extern	volatile	unsigned int	PcTimeout1Char;
	extern	volatile	unsigned int	PcTimeout1Char0;
	extern	volatile	unsigned int	PlcTimeout;
	extern	volatile	unsigned int	PlcTimeout1Char;
	extern	volatile	unsigned int	PlcTimeout1Char0;
	extern	volatile	unsigned int	MonTimeout;
	extern	volatile	unsigned int	SavePcTimeout;
	extern	volatile	unsigned int	SavePcTimeout1Char;
	extern	volatile	unsigned int	SavePcTimeout1Char0;
	extern	volatile	unsigned int	SavePlcTimeout;
	extern	volatile	unsigned int	SavePlcTimeout1Char;
	extern	volatile	unsigned int	SavePlcTimeout1Char0;
	extern	volatile	unsigned int	SaveMonTimeout;
	extern	volatile	unsigned int	GlpTimeout;
#endif


void	InitSci1( int borate, int ldata, int parity );
void	Sio1RtsOn(void);
void	Sio1RtsOff(void);
void	_Sci1ERInterruptHandler( void );
void	_Sci1RXInterruptHandler( void );
void	_Sci1TXInterruptHandler( void );
int Sio1SendChar( unsigned char ch );
void	InitSci0( int borate, int ldata, int parity );
void	Sio0RtsOn(void);
void	Sio0RtsOff(void);
void	_Sci0ERInterruptHandler( void );
void	_Sci0RXInterruptHandler( void );
void	_Sci0TXInterruptHandler( void );
int Sio0SendChar( unsigned char ch );
void	SetSci0Tbl(void);
#ifndef	WIN_DLG
void	Sio1RecDrv( STTFrm* pSTT );     /* SIO���M�h���C�o�^�X�N */
void	Sio1Drv( STTFrm* pSTT );     /* SIO���M�h���C�o�^�X�N */
#endif
void	Sci0ResetCommMode(void);
void	Sci1ResetCommMode(void);
void	Sci2ResetCommMode(void);
void	SetMaskUart(void);
void	ResetMaskUart(void);
void Uart_SendByte1(int data);

