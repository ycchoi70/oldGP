/****************************************/
/*	PLC1								*/
/****************************************/
int	C_Connection( int *PlcType,int iConnect );
int	GetDevNamePLC(int bFlag,unsigned char src,char *obj,int *DevInfo);
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff);
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType);
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType);
int PLCPCDownThrue(unsigned char data,int *recmode,int *RecCnt,unsigned char *RecBuff);
int	GetDevMaxPLC(int bFlag,int idx);
int	GetDevMinPLC(int bFlag,int idx);
int	Device2IndexPLC(int bwflag,char *Name);
int		CheckPLC_Addr(int bwflag,char *src,int *Address1,int *PlcType);
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity);
int	GetSendRecTime(void);
void	Get_Plc1_Ver(char *name);
int		MakeGroupDevPLC(int PlcType,int pnum,int gidx);
int		RecGroupPLCDev(int PlcType);
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType);
int	Get_Ms_Sel(void);
/****************************************/
/*	PLC2								*/
/****************************************/
int	Connection2( int *PlcType,int iConnect );
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff);
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType);
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType);
int	GetSendRecTime2(void);
void	Get_Plc2_Ver(char *name);
int	Get_Ms_Sel2(void);
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity);
