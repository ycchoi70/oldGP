/***********************************************
 * NAME    : 44BLIB.H                          *
 * Version : 17.Apr.00                         *
 ***********************************************/


#ifndef __44blib_h__
#define __44blib_h__

#ifdef __cplusplus
extern "C" {
#endif

//#define DebugOut Uart_Printf

//#define min(x1,x2) ((x1<x2)? x1:x2)
//#define max(x1,x2) ((x1>x2)? x1:x2)

//#define ONESEC0 (62500)	//16us resolution, max 1.04 sec
//#define ONESEC1 (31250)	//32us resolution, max 2.09 sec
//#define ONESEC2 (15625)	//64us resolution, max 4.19 sec
//#define ONESEC3 (7812)	//128us resolution, max 8.38 sec
//#define ONESEC4 (MCLK/128/(0xff+1))  //@60Mhz, 128*4us resolution, max 32.53 sec

#define NULL 0

//#define EnterPWDN(clkcon) ((void (*)(int))0xe0)(clkcon)


/*44blib.c*/
//void Delay(int time); //Watchdog Timer is used.

//void *malloc(unsigned nbyte); 
//void free(void *pt);


#define     SYSINTR_COM1            (10)
#define     SYSINTR_COM2            (11)
#define     SYSINTR_COM3            (12)


void Port_Init(void);


void	SysHardInitial(void);

int	Timer0_Status(void);
int	Timer1_Status(void);

void Timer0_Init(int cnt);
void SetTimer0Cnt(int tCntB,int tCmpB);
void Timer0_Stop(void);
void Timer0_Start(void);
void Timer1_Init(int cnt);
void SetTimer1Cnt(int tCntB,int tCmpB);
void Timer1_Stop(void);
void Timer1_Start(void);
void	Timer2_Init(int Prescaler,int Devid,int Count,int CmpCnt);
void Timer3_Init(void);
void Timer4_Init(void);
void InterruptEnableTick(void);
void InterruptEnableCom(unsigned nInterrupt);
void InterruptEnableTouch(void);
void InterruptDisableCom(unsigned nInterrupt);
unsigned int	GetCountTimer2(void);
void	Timer3DefltInit(void);
void	SetBacklight(int Prescaler,int Devid,int Count,int CmpCnt);


#ifdef __cplusplus
}
#endif

#endif /*__44blib_h__*/
