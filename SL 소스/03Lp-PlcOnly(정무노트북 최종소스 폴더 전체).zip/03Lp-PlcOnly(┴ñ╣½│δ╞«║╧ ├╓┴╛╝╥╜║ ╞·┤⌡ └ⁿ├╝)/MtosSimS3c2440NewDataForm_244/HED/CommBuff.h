/*****************************************/
/*	Common Buffer Area                   */
/*****************************************/
#define	BUFF_DISP_CNT	16

#ifdef	MAIN
#define	___EXT
#else
#define	___EXT	extern
#endif

/******************************************************
	Data Area Structure
******************************************************/
typedef struct{
	unsigned short		iLineStyle;				/* Line Style */
	unsigned long		iLineColor;				/* Line Color */
} _LINE_INFO;

typedef struct{
	unsigned short		iLineStyle;				/* Rectangle Line Style */
	unsigned long		iLineColor;				/* Rectangle Line Color */
	unsigned short		iPattern;				/* Rectangle Pattern */
	unsigned long		iForeColor;				/* Rectangle Foreground Color */
	unsigned long		iBackColor;				/* Rectangle Background Color */
} _RECTANGLE_INFO;

typedef struct{
	unsigned long		iLineColor;				/* Circle Line Color */
	unsigned short		iPattern;				/* Circle Pattern */
	unsigned long		iForeColor;				/* Circle Foreground Color */
	unsigned long		iBackColor;				/* Circle Background Color */
} _CIRCLE_INFO;

typedef struct{
	unsigned long		iColor;					/* FanShape Color */
	unsigned long		iScaleColor;			/* Scale Color */
} _ORGGATA_INFO;

typedef struct{
	char*				cpDevVal;
	char				cDevName[2];
	unsigned short		iDevFlag;				/* 16 or 32 bit ������ */
	int					iDevNumber;
	int					iRegNumber;
	int					iBitFlag;				/* bit, word Flag */
	short				iOnOff;					/* AlarmHistory���� ���� ���� Ȯ�ο��� �����.*/					
	short				iCnt;
	
} _DEV_SUPERVISOR_TBL;

typedef struct{
	short		sx;
	short		sy;
	short		ex;
	short		ey;
} _AREA_INFO;
/********************************************************************************/
/* ����ü�� : _ALARM_HISTORY_MAIN_INFO											*/
/* ��    �� : ALARM_HISTORY�� ���̴� PROJECT ������ ���� ����ü					*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 26�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� :																	*/
/********************************************************************************/
typedef struct{
/*	short			iDetailDisp;*/		/* Detailed Display (1:Not Display, 2:Comment Window, 3:Base Screen)		 */
/*	int				iCommentNo;  */
	short			iMode;				/* History or Cumulation */
	short			iDelModeChkFlag;	
	int				iDispNoSel;
} _ALARM_HISTORY_MAIN_INFO;


typedef struct{
	int				iSunbun;
	int				iDisplayNo[256];
} _ALARM_HIST_ITEM;


/********************************************************************************/
/* �� �� ü ��: _ALARM_HISTORY_EVENT_TBL										*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
//#define	ALMHIS_SORT_INF				14
//#define	ALMHIS_DSP_STYLE			ALMHIS_SORT_INF+1
//#define	ALMHIS_DSP_RAW				ALMHIS_DSP_STYLE+1
//#define	ALMHIS_FNT_SIZE_H			ALMHIS_DSP_RAW+1
//#define	ALMHIS_FNT_SIZE_V			ALMHIS_FNT_SIZE_H+1
//#define	ALMHIS_SHAPE_NO_INF			ALMHIS_FNT_SIZE_V+1
//#define	ALMHIS_SHAPE_NO				ALMHIS_SHAPE_NO_INF+1
//#define	ALMHIS_FNT_SIZE				ALMHIS_SHAPE_NO+1
//#define	ALMHIS_TYTLE_COL			ALMHIS_FNT_SIZE+1
//#define	ALMHIS_FRAME_COL			ALMHIS_TYTLE_COL+1
//#define	ALMHIS_PLATE_COL			ALMHIS_FRAME_COL+1
//#define	ALMHIS_MESS_WIDE			ALMHIS_PLATE_COL+1
//#define	ALMHIS_MESS_SIZE			ALMHIS_MESS_WIDE+1
//#define	ALMHIS_MESS_POS				ALMHIS_MESS_SIZE+1

typedef struct{
	unsigned int		ShapeNo;
	short				iFontSizeH;
	short				iFontSizeV;
	short				iSortInfomation;		/* Form->Sort : 0x00 : Oldest,	0x01 : Latest */
	short				iDispStyle;				/* 0x02 : Occurrences		0x11 : Restorations		0x?? : Occur Frequency */
	short				iDispRows;
	unsigned long		iTitleColor;
	short				iMainContentInfo;
	short				iDateContentInfo;
	short				iTimeContentInfo;
	unsigned long		iOccurredColor;	
	unsigned long		iFrameColor;
	unsigned long		iPlateColor;
	short				iRestorationInfo;
	short				iRestorationDateInfo;
	short				iRestorationTimeInfo;
	unsigned long		iRestorationColor;		
	short				iOccurredWide;
	short				iMessageWide;
	short				iRestorationWide;
	short				iMessgaeTitleSize;		
	short				iRestoredTitleSize;
	short				iFreqTitleSize;	
	short				iOccurredTitleSize;
	short				iOccurredTextSize;
	short				iRestoredTextSize;
	char*			cMsgTitleContents;
	char*			cFreqTitleContents;
	char*			cRestoredTitleContents;
	char*			cOccurredTitleContents;
	char*			cOccurredTextContents;
	char*			cRestoredTextContents;
	int					SuperVOffset;
	short				VectorFlag;			//20100701 add
	short				VectorKind;			//20100701 add
} _ALARM_HISTORY_EVENT_TBL;

/********************************************************************************/
/* �� �� ü ��: _ALARM_LIST_EVENT_TBL											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
	unsigned int		ShapeNo;
	short				iFontSizeH;
	short				iFontSizeV;
	short				iStorgeChecked;			/* 0x14: Checked    0x10: UnChecked */
	int					iDetailDispChecked;		/* Detail Display Check 0 : No Check, 1 : Comment Window, 2 : Base Screen */
	int					iDevicePointers;		/*iDevicePointers[10];*/	/* Detail Display Number*/
	int					iScrollOnFlag;
	short				iStoreMemoryFlag;
	short				iDisplayDateFlag;
	int					iDevicePnt;
	unsigned int		iCommentStartNo;		/* Comment���۹�ȣ */	
	unsigned long		iPlateColor;
	unsigned long		iFrameColor;	
	short				iNumber;
	short				iSort;
	short				iStoreMemoryVal;		/* Store Memory*/
	int					SuperVOffset;
	short				VectorFlag;			//20100701 add
	short				VectorKind;			//20100701 add
} _ALARM_LIST_EVENT_TBL;
typedef struct{
	short	x1;
	short	y1;
	short	x2;
	short	y2;
} SCALE_POIN;

typedef struct{
	unsigned long	iLineColor;
	unsigned int	iLineType;
} _GRAPH_INFO; 

typedef struct{
	short		isPosX;
	short		isPosY;
	short		iePosX;
	short		iePosY;
} _TT;
/********************************************************************************/
/* �� �� ü ��: _NUMERIC_EVENT_TBL												*/
/* ��    �� : Numeric ������ ���� ����ü										*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
//#define	NUM_PLATE_COLOR		14
//#define	NUM_FRAME_COLOR		NUM_PLATE_COLOR+1
//#define	NUM_FNT_SIZE_H		NUM_FRAME_COLOR+1
//#define	NUM_FNT_SIZE_V		NUM_FNT_SIZE_H+1
//#define	NUM_1632BITFLG		NUM_FNT_SIZE_V+1
//#define	NUM_DEVICE			NUM_1632BITFLG+1
//#define	NUM_FORMAT_UPLW		NUM_DEVICE+5
//#define	NUM_TXT_COLOR		NUM_FORMAT_UPLW+1
//#define	NUM_DEC_POINT		NUM_TXT_COLOR+1
//#define	NUM_DIGITS			NUM_DEC_POINT+1
//#define	NUM_SHAPED			NUM_DIGITS+1
//#define	NUM_SHAPED_NO		NUM_SHAPED+1
//#define	NUM_GAIN1			NUM_SHAPED_NO+1
//#define	NUM_GAIN2			NUM_GAIN1+4
//#define	NUM_OFFSET			NUM_GAIN2+4
//#define	NUM_FNT_SIZE		NUM_OFFSET+4
//#define	NUM_HIGH_QUAL		NUM_FNT_SIZE+1


typedef struct{
	DEVICE_INF			DeviceInf;
	int					iDeviceNumber;
	unsigned long		iPlateColor;			/* Plate �÷����� */
	unsigned long		iFrameColor;			/* Frame �÷����� */
	unsigned long	 	iTextColor;				/* Text	�÷����� */
	short			 	iDecimalPnt;			/* �Ҽ����� ���� ��ġ */
	short			 	iDigits;				/* ǥ���� ��ġ�� ���̰� */
	int					ShapeNo;				/* Shape�� ����ߴٸ� �׿� �ش��ϴ� shape��ȣ */
	int					iGain1;					/* Gain1���� */
	int					iGain2;					/* Gain2���� */
	int					iOffset;				/* Offset���� */
	short				iSignFlag;				/* 0 : Signed BIN		1 : Unsigned BIN */
	short				i1632BitFlag;			/* 0 : 16bit			1 : 32bit */
	short				iFontSizeH;
	short				iFontSizeV;
	short				iFormat;				/* 0x00 : Signed decimal */
												/* 0x01 : Unsigned decimal */
												/* 0x02 : Hexadecimal */
												/* 0x03 : Octal */
												/* 0x04 : Binary */
												/* 0x05 : Real */
	short				iAlignment;				/* 0 : Right Alignment */
												/* 1 : Left Alignment */
												/* 2 : Cneter Alignment */
												/* 3 : Disp All Digits Checked */
	/* char			cDispData[256]; */
	long				lBefDevBal;/* ������ �о�� ����̽� ���� �����Ѵ�. */
	short				iHighQuality;
	int					SuperVOffset;
	short				VectorFlag;			//20100701 add
	short				VectorKind;			//20100701 add
} _NUMERIC_EVENT_TBL;

/********************************************************************************/
/* �� �� ü ��: _ASCII_EVENT_TBL												*/
/* ��    �� : Ascii Display Tag ������ ���� ����ü								*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 16�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
	int					iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	short				iFontSizeH;
	short				iFontSizeV;				/* Font�� ũ������ */
	unsigned long		iPlateColor;			/* Plate �÷����� */
	unsigned long		iFrameColor;			/* Frame �÷����� */
	unsigned long		iTextColor;				/* Text	�÷����� */
	int					ShapeNo;				/* Shape�� ����ߴٸ� �׿� �ش��ϴ� shape��ȣ */
	short				iAlignment;				/* 0 : Right Alignment    1 : Left Alignment    2 : Cneter Alignment */						
	short				iDigits;				/* ǥ���� ��ġ�� ���̰� */
	DEVICE_INF			DeviceInf;
	char*				cBefDevData;			/* choijh 20020811 add */
	int					SuperVOffset;
	short				VectorFlag;			//20100701 add
	short				VectorKind;			//20100701 add
} _ASCII_EVENT_TBL;


/********************************************************************************/
/* �� �� ü ��: _NUMERIC_INPUT_EVENT_TBL										*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : PLC�� ������ �������Ƿ� ����̽��� �������� �ʴ´�.				*/
/********************************************************************************/
//#define	NUMIN_PLATE_COLOR	14
//#define	NUMIN_FRAME_COLOR	NUMIN_PLATE_COLOR+1
//#define	NUMIN_FNT_SIZE_H	NUMIN_FRAME_COLOR+1
//#define	NUMIN_FNT_SIZE_V	NUMIN_FNT_SIZE_H+1
//#define	NUMIN_DEVICE		NUMIN_FNT_SIZE_V+1
//#define	NUMIN_FORMAT		NUMIN_DEVICE+7
//#define	NUMIN_BASE_NUM_COL	NUMIN_FORMAT+1
//#define	NUMIN_DEC_POINT		NUMIN_BASE_NUM_COL+1
//#define	NUMIN_DIGITS		NUMIN_DEC_POINT+1
//#define	NUMIN_USER_ID		NUMIN_DIGITS+1
//#define	NUMIN_DEST_ID		NUMIN_USER_ID+2
//#define	NUMIN_GAIN1			NUMIN_DEST_ID+2
//#define	NUMIN_GAIN2			NUMIN_GAIN1+4
//#define	NUMIN_OFFSET		NUMIN_GAIN2+4
//#define	NUMIN_UP_LW_FLAG	NUMIN_OFFSET+4
//#define	NUMIN_UP_DEVICE		NUMIN_UP_LW_FLAG+1
//#define	NUMIN_UW_DEVICE		NUMIN_UP_DEVICE+7
//#define	NUMIN_TRIG_TYPE		NUMIN_UW_DEVICE+7
//#define	NUMIN_TRIG_DEVICE	NUMIN_TRIG_TYPE+1


typedef struct{
	int					iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	DEVICE_INF			DeviceInf;
	int					ShapeNo;				/* Shape�� ����ߴٸ� �׿� �ش��ϴ� shape��ȣ */
	short				iFormSizeV;
	short				iFormSizeH;				/* Form Tab���� ������ ���� */
	short				iFormFormat;
	short				iAlignment;
	unsigned long		iBasicNumColor;
	short				iDecimalPoint;
	short				iDigits;
	unsigned	int		iUser_id;
	unsigned	int		iMoveDest_id;
	int					iGain1;
	int					iGain2; 
	int					Offset;
	short				iUpperFlag;
	short				iLowerFlag;
	unsigned long		iPlateColor;
	unsigned long		iFrameColor;		
	DEVICE_INF			UpperDevice;
	DEVICE_INF			LowerDevice;
	int					iUpperFixedVal, iLowerFixedVal;	
	DEVICE_INF			TriggerDevice;
	short				iSignFlag;    /* signed unsigned */
	short				i1632BitFlag; /* 16 or 32 */
	int					iUpperRegistNumber;
	int					iLowerRegistNumber;
	int					iTriggerRegistNumber;
	char				cTempBuffer[32];
	long				lBefDevBal;
	int					iHighQuality;
	short				SuperVOffset;
	short				Up_SuperVOffset;
	short				Lw_SuperVOffset;
	short				Tr_SuperVOffset;
	short				VectorFlag;			//20100701 add
	short				VectorKind;			//20100701 add
} _NUMERIC_INPUT_EVENT_TBL;


/********************************************************************************/
/* �� �� ü ��: _ASCIIINPUT_EVENT_TBL											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
	int					iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	int					iTriggerRegistNumber;
	DEVICE_INF			DeviceInf;
	unsigned long		iFrameColor;
	short				iFontSizeH;
	short				iFontSizeV;
	short				iAlignment;
	unsigned long		iTextColor;
	unsigned long		iPlateColor;
	int					ShapeNo;
	short				iDigits;
	unsigned	int		iUser_id;
	unsigned	int		iMoveDest_id;
	DEVICE_INF			TriggerDeviceInf;
	short				Dev_SuperVOffset;
	short				Trig_SuperVOffset;
	short				VectorFlag;			//20100701 add
	short				VectorKind;			//20100701 add
} _ASCIIINPUT_EVENT_TBL;


/********************************************************************************/
/* �� �� ü ��: _CLOCK_EVENT_TBL												*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 28�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
#define	CLOK_FRAME_COLOR	14
#define	CLOK_FNT_KIND		CLOK_FRAME_COLOR+4			//20100701
#define	CLOK_FNT_SIZE_H		CLOK_FNT_KIND+1				//20100701
#define	CLOK_FNT_SIZE_V		CLOK_FNT_SIZE_H+1
#define	CLOK_TXT_COLOR		CLOK_FNT_SIZE_V+1
#define	CLOK_PLATE_COLOR	CLOK_TXT_COLOR+4
#define	CLOK_FORMAT_FLG		CLOK_PLATE_COLOR+4
#define	CLOK_FORMAT_TAG		CLOK_FORMAT_FLG+1
#define	CLOK_SHAPE_ON		CLOK_FORMAT_TAG+1
#define	CLOK_SHAPE_NO		CLOK_SHAPE_ON+1
#define	CLOK_FNT_SIZE		CLOK_SHAPE_NO+1
typedef struct{
	short				iFontSizeV;
	short				iFontSizeH;
	unsigned long		iPlateColor;
	unsigned long		iFrameColor;
	unsigned long		iTextColor;
	unsigned int		ShapeNo;
	unsigned int		iFormatTag;
	unsigned int		iFormatFlag;
	char				sec;
	int					SuperVOffset;
	short				VectorFlag;			//20100701 add
	short				VectorKind;			//20100701 add
} _CLOCK_EVENT_TBL;
/********************************************************************************/
/* �� �� ü ��: SCREEN_TAG_DATA													*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 14�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
		char			cObjects;
		char			UpdateFlag;
		char			UpdateFlag1;
		short			iWindowNo;
		short			DevOrder;
		short			DevCnt;
		short			BeShapeUsed;
		short			sX;
		short			sY;
		short			eX;
		short			eY;
		unsigned char*	TagPos;
		void*			TagStruct;
		union{
			struct{
				short			iTriggerSec;			/* TrendGraph */
				short			iStoreMemoryVal;
				short			NoDeviceFlag;
			}Trend;
			struct{
				char			iOffFontPosition;
				char			iOnFontPosition;
				char			iTriggerTypeSet;
				char			TouchKeyVal;
				short			iBStartDataPos;
				short			iWStartDataPos;
				short			iBActDataPos;
				short			iShapeOption;
				//2011.08.25 Add
				short			sX;
				short			sY;
				short			eX;
				short			eY;
				short			iOptionRepeat;
				unsigned int	iKeyCode;
				////////////////
			}TouchSw;
			struct{
				short			cOffPosition;
				short			cOnPosition;
				short			sX;
				short			sY;
				short			eX;
				short			eY;
			}Lamp;
			struct{
				short			iTriggerTypeVal;
				short			iBStartDataPos;
				short			iTriggerVal;
			}NumIn;
			struct{
				short			iTriggerTypeVal;
				short			iBStartDataPos;
				short			iTriggerVal;
			}AsciiIn;
			struct{
				short			ScalePos;
			}Statics;
			struct{
				short			StoreMemNo;
				short			iStartNo;			//for List TAG
				short			iFontSizeH;
				short			iFontSizeV;
				short			VectorFlag;
				short			VectorKind;
				short			ShapeSize;
			}AlarmList;
			struct{
				short			DevOrder[3];
			}BarGraph;
			struct{
				short			iFormatFlag;
				short			iFormatTag;
				short			iTime[3];
			}Clock;
			struct{
				short			CommentNum;		//20100722
			}Comment;
			struct{
				int				ibmpNo;
			}Bmp;
		}uu;
} SCREEN_TAG_DATA;
/********************************************************************************/
/* �� �� ü ��: _PANEL_METER_EVENT_TBL											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 28�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
//#define	PANEL_DEVICE		14
//#define	PANEL_JUT_X			PANEL_DEVICE+7			//19
//#define	PANEL_JUT_Y			PANEL_JUT_X+2			//21
//#define	PANEL_UPDWFLAG		PANEL_JUT_Y+2			//23
//#define	PANEL_TYPE			PANEL_UPDWFLAG+1		//24
//#define	PANEL_POINT			PANEL_TYPE+1			//25
//#define	PANEL_DIRECTION		PANEL_POINT+1			//26
//#define	PANEL_NEEDLE_COL	PANEL_DIRECTION+1		//27
//#define	PANEL_METER_COL		PANEL_NEEDLE_COL+1		//28
//#define	PANEL_UP_DEVICE		PANEL_METER_COL+1		//29
//#define	PANEL_DW_DEVICE		PANEL_UP_DEVICE+7		//34
//#define	PANEL_FRAME_COLOR	PANEL_DW_DEVICE+7		//39
//#define	PANEL_PLATE_COLOR	PANEL_FRAME_COLOR+1		//40
//#define	PANEL_SHAPED		PANEL_PLATE_COLOR+1		//41
//#define	PANEL_SHAPED_NO		PANEL_SHAPED+1			//42
//#define	PANEL_SCALE_FLAG	PANEL_SHAPED_NO+1		//43
//#define	PANEL_SCALE_PNT		PANEL_SCALE_FLAG+1		//44
//#define	PANEL_SCALE_COLOR	PANEL_SCALE_PNT+1		//45
//#define	PANEL_SIGNED		PANEL_SCALE_COLOR+1		//46

typedef struct{
	int					iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	int					iUpRegisterNumber;
	int					iDwRegisterNumber;
	DEVICE_INF			DeviceInf;
	unsigned int		ShapeNo;
	unsigned short		iUpSel;
	DEVICE_INF			UpDevice;
	unsigned short		iDwSel;
	DEVICE_INF			DwDevice;
	unsigned int		iScalePnts;
	unsigned long		iScaleColor;
	unsigned long		iNeedleColor;
	unsigned long		iMeterPanColor;
	unsigned int		iDirection;
	unsigned int		iType;
	short				iChkSigned;				/* 0x00 : Signed BIN		0x01 : UnSigned BIN */
	short				iChkBit;				/* 0x00 : 16bit			0x01 : 32bit */
	unsigned short		iScaleDispChk;
	unsigned long		iFrameColor;
	unsigned long		iPlateColor;
	int					iUpFixedValue;
	int					iDwFixedValue;	
	unsigned short		iJutX;
	unsigned short		iJutY;
	short				iPoint;

	long				lBefDevVal;
	long				lBefUpDevVal;
	long				lBefDwDevVal;
	short				SuperVOffset;
	short				Up_SuperVOffset;
	short				Dw_SuperVOffset;
} _PANEL_METER_EVENT_TBL;

/* Touch Switch */
typedef struct{
	void				*linkPos;
	short				iIndirectChekFlag;				/* Indirect�� �����ߴ��� ���ߴ����� ����(������ 1, �������� 0) */
	short				iInitValueConditionCheckFlag;	/* Initial Value Condition����(������ 1, �������� 0) */
//	unsigned char				cWordDeviceName[2];				/* Device Name */
//	unsigned int		iWordDeviceNumber;				/* Device Number */
	DEVICE_INF			WordDevice;
//	unsigned char				cIndirectWordDeviceName[2];
//	unsigned int		iIndirectWordDeviceNumber;
	DEVICE_INF			IndirectWordDevice;
	long				iConditionValue;
	long				iResetValue;
	long				iFixedValue;
	short				iExpressFlag;					/* Signed BIN, Unsigned BIN, 16, 32 bit */
	short				iDeviceDataNum;
	int					SuperVOffset;
} _TOUCH_SWITCH_WORD_DEVICE; 

/* Touch Switch */
typedef struct{
	void			*linkPos;
	short			iBitDeviceSetFlag;				/* Bit Device ������ ������ Flag   (Momentary(1), Set(2), Reset(3), Alternate(4)) */
	unsigned char			cBitDeviceName[2];					/* Device Name */
	unsigned int	iBitDeviceNumber;					/* Device Number */
	short			iDeviceDataNum;
	char			cMomentaryFlag;						/* */
	int				SuperVOffset;
	int				MomentSw;						/* 0:OFF,1:ON */
} _TOUCH_SWITCH_BIT_DEVICE; 

typedef struct{
	short		sX;
	short		sY;
	short		eX;
	short		eY;
	short		iVal;
} _COMMENT_WINDOW_KEYVAL; 
/********************************************************************************/
/* �� �� ü ��: _TOUCHSWICH_EVENT_TBL											*/
/* ��    �� :  ������ ���� ����ü												*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
#define	TCHSW_START_X			6
#define	TCHSW_START_Y			TCHSW_START_X+2			//8
#define	TCHSW_END_X				TCHSW_START_Y+2			//10
#define	TCHSW_END_Y				TCHSW_END_X+2			//12
#define	TCHSW_OPTION_TRIG		TCHSW_END_Y+2			//14
#define	TCHSW_DSP_TRIG			TCHSW_OPTION_TRIG+1		//15
#define	TCHSW_SHAPE_OPN			TCHSW_DSP_TRIG+1		//16
#define	TCHSW_OFF_SW_COL		TCHSW_SHAPE_OPN+1		//17
#define	TCHSW_ON_SW_COL			TCHSW_OFF_SW_COL+4		//18
#define	TCHSW_BASE_ACT			TCHSW_ON_SW_COL+4		//19
#define	TCHSW_ONOFF_FRAM_COL	TCHSW_BASE_ACT+1		//20
#define	TCHSW_KEY_CODE			TCHSW_ONOFF_FRAM_COL+4	//21
#define	TCHSW_SHAPE_OPTION		TCHSW_KEY_CODE+2		//23
typedef struct{
	char	dumy[6];
	char	sX[2];
	char	sY[2];
	char	eX[2];
	char	eY[2];
	char	OptionTriger;
	char	DispTriger;
	char	ShapeOption;
	char	OffSwitchColor[4];
	char	OnSwitchColor[4];
	char	BaseAction;
	char	OnOffFrameColor[4];
	unsigned char	KeyCode[2];
	char	OffImageNum[2];
	char	OnImageNum[2];
}TOUCH_TAG_ORG;
typedef struct{
	char	VectorFlag;
	char	TextColor[4];
	char	c68Flag;
	char	FontSizeH;
	char	FontSizeV;
	char	FontPosition;
	char	TextLength[2];
}TOUCH_TAG_TEXT_ORG;
typedef struct{
//	char	dumy[6];
	char	dumy1[2];
	char	dumy2[4];
	unsigned char	TagCnt[2];
	unsigned char	TagPos[100][4];
}BASE_HEADER;
typedef struct{
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	int				iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	int				iDispBitTriggerRegistNumber;
	DEVICE_INF			DeviceInf;

	_TOUCH_SWITCH_WORD_DEVICE				*posWord;
	_TOUCH_SWITCH_BIT_DEVICE				*posBit;

	short				TouchType;
	int					iDispTrigger;
	short				iShapeOption;/* Basic�ǿ��� Shape�������� */
	int					iOptionRepeat;
	short				iSimultaneousPress;
	unsigned long		iOffSwitchColor;
	unsigned long		iOnSwitchColor;
	unsigned long		iOnOffFrameColor;
	short				iIsOffText;
	short				iIsOnText;
	unsigned int		iKeyCode;	
	int					iOffImgNum;
	int					iOnImgNum;
	DEVICE_INF			DispBitTriggerDevice;
	int					iOptionTriggerType;
	DEVICE_INF			OptionTriggerTypeDevice;
	int					iOffTextStart;
	int					iOnTextStart;
	unsigned long		iOffTextColor;
	unsigned long		iOnTextColor;
	short				iOff68DotFlag;
	short				iOn68DotFlag;
	short				iOffFontSizeV;
	short				iOffFontSizeH;
	short				iOnFontSizeV;
	short				iOnFontSizeH;
	short				iOffTextSize;
	short				iOnTextSize;
	char*			cOffTextContent;
	char*			cOnTextContent;
	int				iMomentaryCnt;
	int				iSetCnt;
	int				iResetCnt;
	int				iAlternateCnt;
	int				MemOffset;/* Bit���� */
	int				MemOffset2;/* Word���� */
	int				iIndirectWordUnChkCnt;
	int				iIndirectWordChkCnt;  /* Indirect�������� ���� Word����, Indirect������ Word���� */
	int				iScreenNo;
	int				iActionBit;
	int				iActionWord;
	short			iBaseAction;
	short			iBefKeyDispVal;		/* Key Display On Off*/
	int				iBefKeyVal;			/* Touch On Off */
	short			iOnOffFlag;
	short			iBefSwitch;				/* 040606 */
	short			iBefDspSwitch;			/* 040606 */
	int				SuperVOffset;
	short			iBitPos;
	short			iWordPos;
	short			OnVectorFlag;			//20100701 add
	short			OnVectorKind;			//20100701 add
	short			OffVectorFlag;			//20100701 add
	short			OffVectorKind;			//20100701 add
} _TOUCHSWICH_EVENT_TBL;

/********************************************************************************/
/* �� �� ü ��: _BARGRAPH_EVENT_TBL  											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
//#define	BARGRH_DIRECTION	14
//#define	BARGRH_FRAME_COLOR	BARGRH_DIRECTION+ 1		//15
//#define	BARGRH_CONDITION	BARGRH_FRAME_COLOR+ 1	//16
//#define	BARGRH_CHECKED		BARGRH_CONDITION+ 1		//17
//#define	BARGRH_PALET_COL	BARGRH_CHECKED+ 1		//18
//#define	BARGRH_UP_DEVICE	BARGRH_PALET_COL+ 1		//19
//#define	BARGRH_LW_DEVICE	BARGRH_UP_DEVICE+ 7		//24
//#define	BARGRH_BASE_DEVICE	BARGRH_LW_DEVICE+ 7		//29
//#define	BARGRH_BASE_SC_COL	BARGRH_BASE_DEVICE+ 7	//34
//#define	BARGRH_BASE_SC_PT	BARGRH_BASE_SC_COL+ 1	//35
//#define	BARGRH_BAR_COL		BARGRH_BASE_SC_PT+ 1	//36
//#define	BARGRH_SCALE_POS	BARGRH_BAR_COL+ 1		//37
//#define	BARGRH_SHAPE_ON		BARGRH_SCALE_POS+ 1		//38
//#define	BARGRH_SHAPE_NO		BARGRH_SHAPE_ON+ 1		//39
//#define	BARGRH_MONITOR_BIT	BARGRH_SHAPE_NO+ 1		//40
//#define	BARGRH_DEVICE		BARGRH_MONITOR_BIT+ 1	//41

typedef struct{
	int				iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	int				iBaseRegistNumber;
	int				iUpperRegistNumber;
	int				iLowerRegistNumber;
	DEVICE_INF		BaseDevice;
	unsigned int	ShapeNo;
	unsigned short	BeScaleDisp;
	unsigned short	iScalePoint;	
	unsigned short	iDirecition;/* Direction */
	unsigned long	iFrameColor;
	unsigned short	iBaseCaseInfo;
	unsigned short	iUpperCaseInfo;
	unsigned short	iLowerCaseInfo;
	unsigned short	IsSigned;
	unsigned short	iFrameChecked;
	unsigned short	iScaleDispChecked;
	unsigned short	iScalePosition;
	unsigned long	iPlateColor;
	unsigned long	iScaleColor;	
	DEVICE_INF		DwDevice;
	DEVICE_INF		UpDevice;
	DEVICE_INF		MonitorDevice;
	short			iSignedFlag;			/*	SIGNED 0x00, UNSIGNED 0x01, BCD	0x02 */
	short			iMonitorBitFlag;		/*  16Bit = 0, 32Bit = 1 */
	unsigned long	iBarColor;		

	long			lBefDevVal;
	long			lBefBeDevVal;
	long			lBefUpDevVal;
	long			lBefDwDevVal;
	short			Bas_SuperVOffset;
	short			Dw_SuperVOffset;
	short			Up_SuperVOffset;
	short			Mon_SuperVOffset;
} _BARGRAPH_EVENT_TBL;

/********************************************************************************/
/* �� �� ü ��: _COMMENT_EVENT_TBL  											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 30�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
//#define	COMM_FRAME_COLOR	14
//#define	COMM_FNT_SIZE_H		COMM_FRAME_COLOR+1		//15
//#define	COMM_FNT_SIZE_V		COMM_FNT_SIZE_H+1		//16
//#define	COMM_DEVICE			COMM_FNT_SIZE_V+1		//17
//#define	COMM_BIT_WORD		COMM_DEVICE+7			//22
//#define	COMM_OFF_TXT_COL	COMM_BIT_WORD+1			//23
//#define	COMM_OFF_PLATE_COL	COMM_OFF_TXT_COL+1		//24
//#define	COMM_OFF_ATTRCHK	COMM_OFF_PLATE_COL+1	//25
//#define	COMM_OFF_DIRECT		COMM_OFF_ATTRCHK+1		//26
//#define	COMM_OFF_TXT_LEN	COMM_OFF_DIRECT+1		//27
//#define	COMM_OFF_TXT		COMM_OFF_TXT_LEN+2		//29

//#define	COMM_EDT_TXT_COL	COMM_BIT_WORD+1			//23
//#define	COMM_EDT_PLATE_COL	COMM_EDT_TXT_COL+1		//24
//#define	COMM_EDT_ATTRCHK	COMM_EDT_PLATE_COL+1	//25
//#define	COMM_START_NO		COMM_EDT_ATTRCHK+1		//26
//#define	COMM_SHAPED			COMM_START_NO+2			//28
//#define	COMM_SHAPED_NO		COMM_SHAPED+1			//29
//#define	COMM_FNT_SIZE		COMM_SHAPED_NO+1		//30

typedef struct{
	unsigned short	iSwitch;				/* ȭ�鰻���÷��� ȭ�鰻���� �ʿ��Ѱ�� ON, ȸ���� ������ �ʿ䰡 ���� ��� OFF */
	int				iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	DEVICE_INF		DeviceInf;
	short				iBitWordFlag;
	unsigned short	iFontSizeH;
	unsigned short	iFontSizeV;
	unsigned long	iFrameColor;
	unsigned int	ShapeNo;
	unsigned long	iOffTextColor;
	unsigned long	iOffPlateColor;
	unsigned int	iOffNo;
	unsigned long	iOnTextColor;
	unsigned long	iOnPlateColor;
	unsigned int	iOnNo;
	unsigned short	iOffTxtSize;
	unsigned short	iOnTxtSize; 		
	char*			cOffTextBuffer;
	char*			cOnTextBuffer;
	short			iOffAttrChecked;
	short			iOnAttrChecked;
	short			iOffDirectChecked;
	short			iOnDirectChecked;
	short			iOnTextLength;
	short			iOffTextLength;

	short			iStartNo;
	unsigned long	iEdtTextColor;
	unsigned long	iEdtPlateColor;
	short			iEdtAttrChecked;

	unsigned short	BefBitDevVal;
	long			BefWordDevVal;
	int				SuperVOffset;
	short			VectorFlag;			//20100701 add
	short			VectorKind;			//20100701 add
	short			ComentNumber;		//20100701 add
} _COMMENT_EVENT_TBL;
/********************************************************************************/
/* �� �� ü ��: _LAMP_EVENT_TBL													*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 31��(��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
//Input Buff Pos
//#define	LAMP_START_X			6
//#define	LAMP_START_Y			LAMP_START_X+2
//#define	LAMP_END_X				LAMP_START_Y+2
//#define	LAMP_END_Y				LAMP_END_X+2
//#define	LAMP_SHAPE				LAMP_END_Y+2
//#define	LAMP_OFF_FRAM_COLOR		LAMP_SHAPE+1
//#define	LAMP_ON_FRAM_COLOR		LAMP_OFF_FRAM_COLOR+4
//#define	LAMP_DEVICE				LAMP_ON_FRAM_COLOR+4
//#define	LAMP_SHAPE_INF			LAMP_DEVICE+7
//#define	LAMP_OFF_TXT_COL		LAMP_SHAPE_INF+6
//#define	LAMP_OFF_FNT_SIZ_H		LAMP_OFF_TXT_COL+4
//#define	LAMP_OFF_FNT_SIZ_V		LAMP_OFF_FNT_SIZ_H+1
//#define	LAMP_OFF_POS			LAMP_OFF_FNT_SIZ_V+1
//#define	LAMP_OFF_TXT_LEN		LAMP_OFF_POS+1
//#define	LAMP_OFF_TXT_POS		LAMP_OFF_TXT_LEN+1

typedef struct{
	int				iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	DEVICE_INF		DeviceInf;
	short			iOnFontSizeH;
	short			iOnFontSizeV;
	short			iOffFontSizeH;
	short			iOffFontSizeV;
	unsigned long	iOnFrameColor;
	unsigned long	iOffFrameColor;
	int				OffShapeNo;
	int				OnShapeNo;
	int				OffPartsNo;
	int				OnPartsNo;
	unsigned long	OffLampColor;
	unsigned long	OnLampColor;
	unsigned long	iOffTxtColor;
	unsigned long	iOnTxtColor;
	short			iOffTxtLen;
	short			iOnTxtLen;
	short			iOff68DotFlag;
	short			iOn68DotFlag;
	short			iShapeSelect;
	char*			cOffTxtBuffer;
	char*			cOnTxtBuffer;
	int				iBefDevVal;				/* 20020815 choijh add */ 
	int				SuperVOffset;
	short			OffVectorFlag;			//20100701 add
	short			OffVectorKind;			//20100701 add
	short			OnVectorFlag;			//20100701 add
	short			OnVectorKind;			//20100701 add
} _LAMP_EVENT_TBL;

/********************************************************************************/
/* �� �� ü ��: _LINEGRAPH_EVENT_TBL											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 31��(��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
//#define	LINE_DIRECTION		14
//#define	LINE_FRAME_COLOR	LINE_DIRECTION+1		//15
//#define	LINE_NUMBER			LINE_FRAME_COLOR+1		//16
//#define	LINE_POINTS			LINE_NUMBER+1			//17
//#define	LINE_FIXEDVAL		LINE_POINTS+1			//18
//#define	LINE_PLATE_COL		LINE_FIXEDVAL+1			//19
//#define	LINE_FRAME_CHECK	LINE_PLATE_COL+1		//20
//#define	LINE_UP_DEVICE		LINE_FRAME_CHECK+1		//21
//#define	LINE_LW_DEVICE		LINE_UP_DEVICE+7		//26
//#define	LINE_SCALE_COLOR	LINE_LW_DEVICE+7		//30

typedef struct{
	int				iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	int				iLowerRegistNumber;
	int				iUpperRegistNumber;
	DEVICE_INF		DeviceInf;
	DEVICE_INF		UpperDevice;
	DEVICE_INF		LowerDevice;
	int				ShapeNo;
	short				iScalePosition;
	short				iPoints;
	short				iDirecition;/* Direction */
	short				IsChkVNDisplayed;
	int				VNDisplayedVal;/* Value not Displayed */
	unsigned long		iFrameColor;
	unsigned long		iPlateColor;
	short				iNumber/* Number : ��Ʈ�� ��Ÿ�� ���� ����(�ִ� 8������ ��Ÿ���� �ִ�) */;
	short				iCaseUpFixedVal;
	short				iCaseLoFixedVal;
	short				iSignedFlag;
	short				i1632BitFlag;
	long			lUpperFixedData;
	long			lLowerFixedData;	
	short				iFrameChecked;
	short				iScaleDispChecked;
	unsigned long		iScaleColor;
	short				iScalePointsV;
	short				iScalePointsH;
	_GRAPH_INFO		lf[8];

	long			lBefUpperDevVal;
	long			lBefLowerDevVal;
	char*			cBefMonitorDevVal;/* ������ 400������ ����*/
	short			SuperVOffset;
	short			Up_SuperVOffset;
	short			Lw_SuperVOffset;
} _LINEGRAPH_EVENT_TBL;

typedef struct{
	short	x1;
	short	y1;
} SCALE_POINT;
/********************************************************************************/
/* �� �� ü ��: _STATISTICS_EVENT_TBL											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 1��(��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
//#define	STATIC_TYPE			14
//#define	STATIC_FRAME_COLOR	STATIC_TYPE+1
//#define	STATIC_PARTITION	STATIC_FRAME_COLOR+1
//#define	STATIC_PLATE_COLOR	STATIC_PARTITION+1
//#define	STATIC_DSP_CHK		STATIC_PLATE_COLOR+1
//#define	STATIC_SCALE_COL	STATIC_DSP_CHK+1
//#define	STATIC_SCALE_PNTS	STATIC_SCALE_COL+1
//#define	STATIC_SHAPED		STATIC_SCALE_PNTS+1
//#define	STATIC_SHAPED_NO	STATIC_SHAPED+1
//#define	STATIC_1632FLAG		STATIC_SHAPED_NO+1
//#define	STATIC_DEVICE		STATIC_1632FLAG+1
//#define	STATIC_PART_COLOR	STATIC_DEVICE+7

typedef struct{
	int				iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	DEVICE_INF		DeviceInf;
	int				ShapeNo;
	short				iScalePnts;
	unsigned long		iScaleColor;
	short				iScaleDispChk;
	short				iPartitionNo;
	unsigned long		iFrameColor;
	unsigned long		iPlateColor;
	short				iGraphType;
	short				iDirection;	
	short				iSignedFlag; /* signed unsigned ������ */
	short				i1632BitFlag; /* 16, 32bit ������ */
	unsigned long		iPartitionColor[8]; 
	long			lBefDeviceValue[8];
	/* Memory ������ ������ ���� ����. */
	int				SuperVOffset;
} _STATISTICS_EVENT_TBL;
	/* Memory ������ ������ ���� ����. */

/********************************************************************************/
/* �� �� ü ��: _PARTS_EVENT_TBL												*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 4��(ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
//#define	PARTS_POSITION_INF	14
//#define	PARTS_BIT_WORD		PARTS_POSITION_INF+1
//#define	PARTS_DEVICE		PARTS_BIT_WORD+1
//#define	PARTS_TYPE			PARTS_DEVICE+7

//#define	PARTS_BIT_ON_NO		PARTS_TYPE+2

//#define	PARTS_BIT_ON_COL	PARTS_TYPE+1
//#define	PARTS_BIT_OFF_COL	PARTS_BIT_ON_COL+4
//#define	PARTS_MARK_NO		PARTS_BIT_OFF_COL+4

//#define	PARTS_FIXED_COL		PARTS_TYPE+1
//#define	PARTS_SWTCH_NO		PARTS_FIXED_COL+5

//#define	PARTS_START_NO		PARTS_TYPE+7
//#define	PARTS_PRE_COMENT	PARTS_START_NO+2

typedef struct{
	int					iRegisterNumber;			/* ����̽� ��Ϲ�ȣ	*/
	DEVICE_INF			DeviceInf;
	short				iPositionInfo;			/* iPositionInfo	0x00 : Top-Left,    0x08 : Center	*/ 
	short				iBitWordFlag;			/* iBitWordFlag		0x02 : Bit			0x01 : Word		 0x03 : Fixed*/
	short				iType;
	int					BitOnNo;
	unsigned long		BitOnColor;
	int					BitOffNo;
	unsigned long		BitOffColor;
	int					iPartsSwitchingNo;
	unsigned long		iFixedColor;
	int					iMarkNo;
	short				iStartNo;
	int					iPreComment;
	int				iBefDevVal;
	int				SuperVOffset;
} _PARTS_EVENT_TBL;
	
/********************************************************************************/
/* �� �� ü ��: _TRENDGRAPH_EVENT_TBL											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 31��(��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
//#define	TRND_DIRECTION			14
//#define	TRND_FRAME_COLOR		TRND_DIRECTION+1
//#define	TRND_NUMBER				TRND_FRAME_COLOR+1
//#define	TRND_POINTS				TRND_NUMBER+1
//#define	TRND_LOUP_FLAG			TRND_POINTS+1
//#define	TRND_PLATE_COLOR		TRND_LOUP_FLAG+1
//#define	TRND_FRAME_CHK			TRND_PLATE_COLOR+1
//#define	TRND_UP_DEVICE			TRND_FRAME_CHK+1
//#define	TRND_LO_DEVICE			TRND_UP_DEVICE+7
//#define	TRND_STORE_MEM			TRND_LO_DEVICE+7


typedef struct{
	int					iLowerRegistNumber;
	int					iUpperRegistNumber;
	DEVICE_INF			UpperDevice;
	DEVICE_INF			LowerDevice;
	DEVICE_INF			StMemoryDevice;
	int					ShapeNo;
	short				iScalePosition;
	short				iPoints;
	short				iDirecition;		/* Direction */
	short				IsChkVNDisplayed;
	int					VNDisplayedVal;		/* Value not Displayed */
	unsigned long		iFrameColor;
	unsigned long		iPlateColor;
	short				iNumber				/* Number : ��Ʈ�� ��Ÿ�� ���� ����(�ִ� 8������ ��Ÿ���� �ִ�) */;
	short				iCaseUpFixedVal;
	short				iCaseLoFixedVal;
	short				iSignedFlag;
	short				i1632BitFlag;
	long				lUpperFixedData;
	long				lLowerFixedData;	
	short				iFrameChecked;
	short				iScaleDispChecked;
	unsigned long		iScaleColor;
	short				iScalePointsV;
	short				iScalePointsH;
	_GRAPH_INFO			tf[8];
	int					iStoreMemoryCode;

	long				lBefMonitorDevVal[50];
	long				lBefUpperDevVal;
	long				lBefLowerDevVal;
	short				iStoreMemoryVal;
	short				NoDeviceFlag;
	short				Up_SuperVOffset;
	short				Lw_SuperVOffset;
	short				Mon_SuperVOffset;
} _TRENDGRAPH_EVENT_TBL;



/********************************************************************************/
/* �� �� ü ��: _FIGURE_EVENT_TBL												*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 31��(��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
*/
	short				iDrawType; /* Line : 0x01, Circle : 0x06, Rectangle : 0x03, Text :0x09 , Bmp : 0x0A	*/
		union{
			struct{			/* LINE			*/
				_LINE_INFO			LineType;
			}LineInfo;

			struct{			/* CIRCLE 	*/
				_CIRCLE_INFO		CircleType;
				short	iRadius;	
			}CircleInfo;

			struct{			/* RECTANGLE 	*/
				_RECTANGLE_INFO		RectType;

			}RectInfo;

			struct{			/* TEXT	*/
				unsigned long		iTextColor;
				short				iSizeH;
				short				iSizeV;
				short				LineCnt;
				char*				TextSPoint;
				short				VectorFlag;			//20100701 add
				short				VectorKind;			//20100701 add
				short				Alinment;
			}TextInfo;

			struct{			/* BMP	*/
				int					iTagSizeOf;
				char*				BmpSPoint;
			}BmpInfo;
		}ST;
	int				SuperVOffset;
}_FIGURE_EVENT_TBL;

/********************************************************************************/
/* �� �� ü ��: TIME_ACTION_DB													*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 11�� 19��(ȭ)												*/
/* �� �� �� : �� �� ��  														*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
	short		iMax;
	short		iLine;
	short		iTopY;
} _CLEAN_AREA;
typedef struct{
	char				cInputDispBuff[200];
	char				cBufferData[200];
	short				iInputNo;			/* ���� ��Ŀ���� �ִ� IventTableCnt*/
	short				iFirstflag;			/* ��ġŰ�� ���� ���� 1 : �׷�������, 0 : �� �׷��� ����	*/
	short				iFlag;				/* Cursor ���� flag */
	short				iKeyOnOff;
	short				iLen;				/* ǥ�� ���� */
	short				iKeyType;			/* ���� �Է��ϰ� �ִ� Ű�� Ÿ���� ���Ѵ�. */
} _INPUT_DISPLAY_BUFF;


/********************************************************************************/
/* ����ü�� : _SWITCHING_SCREEN_DEVICE											*/
/* ��    �� : PROJECT ���������� SYSTEM������ ���� ����ü						*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 30�� (��)												*/
/* �� �� �� : �� ���� 															*/
/* ��    �� :																	*/
/********************************************************************************/
typedef struct{
	short			iBaseScreenFlag;
} _SWITCHING_SCREEN_DEVICE;
/****************************/
/*	TAG Common Struct		*/
/****************************/
//typedef struct{
//	volatile	char	UpdateFlag;
//	volatile	char	UpdateFlag1;
//	short				SaveUpdateFlag;
//	short				sX;
//	short				sY;
//	short				eX;
//	short				eY;
//	short				BeShapeUsed;
//}TAG_HED;

/////////////////////////////////////////////////////////////////////////////////
//	Data Area
////////////////////////////////////////////////////////////////////////////////
	___EXT	volatile	int		TaskStartFlag;

	___EXT	volatile	int		DataClearFlag;			//2011.05.26
//	___EXT	volatile	int		USBDevTestFlag;
	___EXT	volatile	int		DevMonInputFlag;
	___EXT	volatile	int		DevMonMakeOffsetFlag;
	___EXT	int	DeviceMonSettingChg;
	___EXT	unsigned char	Device_Code[MAX_DEV_MON];
	___EXT	char	Device_Name[MAX_DEV_MON][5];		//Ascii String
	___EXT	short			Device_iType[MAX_DEV_MON];
	___EXT	unsigned int	Device_Info_offset[2][MAX_DEV_MON][2];
	___EXT	struct{
				int		EntryCnt;
				int		SettingOrder[64];
				int		SettingOrderKind[64];
				int		MessageCnt;
				char*	Setting_offset[2];		//0:Message1,1:Message2
				int		ListEntryCnt;
				int		ListSettingOrder[64];
			}SettingTagInf;
	___EXT	struct{
				int		EntryCnt;
				int		SettingOrder[64];
			}ProglessTagInf;
	___EXT	unsigned int	SirialChanel;
	___EXT	int	SirialSettingOk;
	___EXT	struct{
				int		TextCnt;
				int		DevCnt;
//				int		TextPos[64];
				int		DevPos[64][2];
			}DevMonInf;
	___EXT	int	DevTblidx;
	___EXT	int	DevMonTblidx;
	___EXT	char	DevAddrData[32];
	___EXT	int	MonDevice;
	___EXT	int	MonStartAddr;
	___EXT	int	MonEndAddr;
	___EXT	int	MonDeviceIdx;
	___EXT	int	DevMon_Chanel;
	___EXT	int	DevTimeSwitch_Chanel;		//2012.02.23
	___EXT	int	DevLogSave_Chanel;			//2012.02.23
	___EXT	int	DevLogCond_Chanel;			//2012.02.23
	___EXT	int	DevMon_Pole;
	___EXT	int	DevTimeSwitch_Pole;			//2012.02.23
	___EXT	int	DevLogSave_Pole;			//2012.02.23
	___EXT	int	DevLogCond_Pole;			//2012.02.23
	___EXT	int	DevMon_DevFlag;
	___EXT	int	DevMon_Size;
	___EXT	int	EnvSetiScreenNow;

	___EXT	DEVICE_INF	SaveTimeDev;		//2012.02.27


	___EXT	unsigned int	UsbDeviceTimeOut;
	___EXT	unsigned int	UsbDeviceStartTime;
	___EXT	unsigned int	UsbDebugMode;
	___EXT	int	UsbDebugBreakAddr;

	___EXT	int	ClockSettingPos;				//Clock Setting TAG
	___EXT	int	ClockSettingiOrder;				//Clock Setting TAG
	___EXT	struct{
				int	iBefNum;				//Clock Setting TAG
				int	iNowNum;				//Clock Setting TAG
				int	iMaxNum;				//Clock Setting TAG
				int	iMinNum;				//Clock Setting TAG
				int	AmPm;
				int	inCnt;
			}ClockNum;					//
	___EXT	int				SettingTimeSwicthKind;		//2011.08.16
	___EXT	RTC_DATA		SettingTimeSwitchCheck;		//2011.08.16
	___EXT	RTC_DATA		SettingTime;
	___EXT	RTC_DATA		BefSettingTime;
	___EXT	unsigned char	SettingIpAddr[6];			//for IP,Mac addr Setting

	___EXT	RTC_DATA		SystemTime;
	___EXT	RTC_DATA		ClassNowTime;				//Name Change 2012.03.10
	___EXT	RTC_DATA		DisplayNowTime;
	___EXT	RTC_DATA		DispTskTime;				//2012.03.10
	___EXT	int		ClockDisplayed;

	___EXT	char			pcFileName[16][16];

	___EXT  char			cPcTempFileName[32];/* ���Ϻм��½�ũ���� �о�� ������ �̸� */
	___EXT	int				pcFileCnt;
	___EXT	int				pcNewRec;
	___EXT	int				iBaseScreenCnt;
	___EXT	int				iWinScreenCnt;
	___EXT	int				iSysScreenCnt;

	___EXT	int				PcDownloadStart;		/* 070207 */

	___EXT	int				iNowScreenNum;
	___EXT	short			iSwitch_ScreenNum1;
	___EXT	short			iSwitch_ScreenNum2;
	___EXT	int				iPreviousScreenNum;
	___EXT	int				iScreenPosition;


	___EXT	_COMMENT_WINDOW_KEYVAL		ComWinKey;
	___EXT  SCALE_POIN ScalePoin[52];
	___EXT	short		TrendDisPoint[8][51];	/* GT_Designer������ 8������ ������ Gp������ 4�������� Display �ȴ�. */
	___EXT _CLEAN_AREA					CleanComment;
	/* �� ȭ���  AscDisplayTag�� �ִ� 50������ ǥ���Ҽ� �ִ�. */
	
	___EXT _TT						tt[8];

	___EXT _SWITCHING_SCREEN_DEVICE	SwitchingScreenDevice;
	___EXT _ALARM_HISTORY_MAIN_INFO*	AlarmHistoryMainInfo;
	___EXT _ALARM_HIST_ITEM*			AlarmHistItem;/* �ִ� 256�������� */
	___EXT	int							AlarmHistoryOrder;
	___EXT	int							AlarmListOrder;


	___EXT 	SCREEN_TAG_DATA				ScreenTagData[MAX_TAG_NO];

	___EXT 	_INPUT_DISPLAY_BUFF			InputDisplay;			/* Numeric,AsciiInput���� ���ڸ� ���÷��� �ϱ� ����. */
	___EXT 	int							FirstInputDisplay;		/* Numeric,AsciiInput 2011.05.16 */
	___EXT 	int							FirstInputCurDisplay;	/* Numeric,AsciiInput 2011.05.16 */


	___EXT	short				iHistoryPositionVal;	/* AlarmHistory �� �����ؾ� �� ��ġ��		*/
	___EXT	short				iHistoryOnOff;			/* AlarmHistory�� ���� ����					*/
	___EXT  short				iHistoryDisCnt;			/* AlarmHistory ���÷��� �ϱ� ���� ī���� */

	___EXT  short				iAlarmListDisCnt;		/* AlarmList ���÷��� �ϱ� ���� ī���� */
	
	___EXT  short				iPositionVal;			/* AlarmList �� �����ؾ� �� ��ġ��			*/
	___EXT  short				iAlarmOnOff;			/* AlarmList�� ���� ����					*/
	___EXT  int					iMainKeyCode;
	___EXT  int					iOrderKeyCode;			// Touch TAG Order in Gamen
	___EXT	short				PassWordSettingFg;		/* Password Setting Flag 050411 */
	___EXT	short				PassWordSettingChg;		/* Password Setting Flag 050411 */
	___EXT  short				iAlarmHistFlag;

	___EXT  short				iUserScreenFlag;	/* ȭ���϶��� ���� ó��. */
	___EXT	short				iFirstScreen;
	___EXT	short				iTransFlag;			/* �ٿ�ε尡 �Ǿ����� */
	___EXT  int					iScreenDisp;		/* ȯ�漳������ ��ũ���� ���÷����ϱ� ����... */

	___EXT	int					iOverFlagNum;		/* overlap �ؾ� �ϴ� ��ũ���� ����. */


	___EXT  int					iGlobleOrder;		/* ���� Tag�� ���� */

	___EXT  short				iDeviceScanFlag;		/* ��ĵ����: ON, ��ĵ���� OFF */
	___EXT  int					iDispOrder;				/* Object�� ��¼��� */

	___EXT  unsigned char*		GlobleTagStructAddr;		/* */
	___EXT  unsigned char*		TagStructAddr;				/* */

	___EXT  short					TouchSwitchDispCnt;	/* TouchSwitchDisplayTag�� ���� */
	___EXT  short					NumericInputCnt;	/* NumericInputTag�� ���� */
	___EXT  short					AsciiInputCnt;		/* AsciiInputisplayTag�� ���� */
	___EXT  int					iOnSignalStart;
	___EXT  int					iDeviceOffset;
	___EXT	short					iFigureCnt;				/* Figure�� ���� */
	___EXT  short				AsciiDispCnt1;			/* AsciiDisplayTag Counter */
	___EXT  short				NumericDispCnt1;		/* NumericDisplayTag Counter */
	___EXT  short				TouchSwitchDispCnt1;	/* TouchSwitchDisplayTag Counter */
	___EXT  short				NumericInputCnt1;		/* NumericInputTag Counter */
	___EXT  short				AsciiInputCnt1;			/* AsciiInputisplayTag Counter */	
	___EXT  short				iDeviceSearchCnt1;

	___EXT	short				iPassFlag;					/* Pass Word Flag		*/
	___EXT	char				cPassBuff[9];				/* Input Pass Word Save Buff	*/
	___EXT	short				iPassLevel;					/* Pass Level */
	___EXT	short				iPassPoint;					/* Pass ���� ȭ�� ��ũ���� �迭��° �� */
	___EXT	char				iAlternateflag;				/* Keyflag	*/
	___EXT	char				iPass1Id;					/* Pass1�� ������Ű�� ���� �����÷��� */

	/* leesi 10.02 */
	___EXT  short			iWinStartPx;   /* Window Start Point X */
	___EXT  short			iWinStartPy;   /* Window Start Point Y */
	___EXT  short			iWinEndPx;   /* Window Start Point X */
	___EXT  short			iWinEndPy;   /* Window Start Point Y */

	___EXT  short			iTouchFlag;


	/* leesi 2003.01.09 */
	___EXT	short				iComCnt;					/* Comment�� ����.			*/

	/* leesi 2003.08.20 */
	___EXT	short				iAsciiKeyflag;				/* AsciiKey Display �� ��� Ŀ���� ���� Ű ǥ�� flag	*/
	___EXT	short				iAsciiReDispflag;			/*  */
	___EXT	short				iInputReDispflag;			/* 2011.05.16 */
	___EXT	short				iInputNoDispflag;			/* 2011.05.16 */
	___EXT	int					iTaskActFlag;							/* ��ɺ� Ÿ��ũ Ȱ��ȭ �÷��� */
	/**************************************************************************/

	___EXT	short				DownloadFileInfo;			/* 0:NewFile,1:Openning		*/
	___EXT	short				DownloadFileKind;			/* 0:NewFile,1:Openning		*/
	___EXT	short				PcEditBlockNo;				/* 20100707 Add		*/
	___EXT	short				PcEditErrorCnt;				/* 20100707 Add		*/

	___EXT	int					StartErrorGamenFlag;		/* 2011.09.09 Add		*/
	/**************************************************************************/
	/* Tag Info								*/
	___EXT	short				TagFileCnt;
	___EXT	struct{
				short				iScreenNo;
				short				iOffset;
				unsigned char		*cTagBuf;
				short				iFilePointer;
				short				iPos;
			}TagFileInfo[8];
	/**************************************************************************/
	___EXT	short	PlchandTask;		/* ?�X�N������ */		
	___EXT	short	Plc2handTask;		/* ?�X�N������ */		
	___EXT	short	PlcstateTask;		/* ?�X�N������ */		
	___EXT	short	ConnectTask;		/* ?�X�N������ */
	/**************************************************************************/
	/* PC Work */
	___EXT  int		PcFilefp;
	___EXT  char	DownloadFileName[32];
	___EXT	int		UpLoadMode;		/* */
	___EXT	int		RetryCnt;			/* Retry Count */
	___EXT  char*	UpdateProjectInf;	/* 2008.09.03 */
	___EXT  int		UpdateProjectBaseCnt;	/* 2008.09.03 */
	___EXT  int		UpdateProjectWindowCnt;	/* 2008.09.03 */
	___EXT  int		UpdateProjectBlkNo;	/* 2008.09.03 */
	___EXT  int		UpdateProjectSendCnt;	/* 2008.09.03 */

	/* leesi 2003.02.27 */
	___EXT	char*				iPartPoint;

	___EXT	short				iStoreScreenNum[16];			/* TrendGraph ScreenNum */

	___EXT	char	PlcDataReadBuff[512];		/* PLC Read Temp */
	___EXT	short			ScalePosCnt;
	___EXT	short			ScalePosCnt1;
	___EXT	SCALE_POINT		ScalePoint[8][52];
	/********************************/
	/*	FONT						*/
	/********************************/
//	___EXT	unsigned char			GpFont[0x200000];
	/*******************************/
	___EXT	int		DebugLoop;
	___EXT	volatile	int	GLP_MyTaskNo;

	/* PlcComm.c */
	___EXT	int	SmtStoRecCnt;
	___EXT	int	WpFlag;
	___EXT	char	*WpWriteBuff;
	___EXT	int	*TableCnt;
	___EXT	char	*SWpWriteBuff;
	___EXT	int		ProgDownFlag;

//DEBUG TASK
	___EXT	unsigned int SubsModeFlag;		/* �r�t�a�r��?�h�t���O */
	___EXT	unsigned int PloadFlag;			/* �v���O��?��?�h�t���O */
	___EXT	unsigned long DefaultAdress;			/* �A�h���X�����͎��̃f�t�H���g�l */
	___EXT	int DModeFlag;
	___EXT	int	SioLFFlag;
	___EXT	int	SioEchoFlag;


	___EXT	_TOUCHKEY		Key;
	___EXT	_SCREEN_DATA	Screen[MAX_USER_SCREEN];	
	___EXT	_SCREEN_DATA	WinScreen[3];			/* Max = 3 */				
	___EXT	_SCREEN_DATA	SysScreen[MAX_SYS_SCREEN];			// Setting Screen	
	___EXT	_NOWDEV			BuffDip[BUFF_DISP_CNT];
	___EXT	_NOWDEV			NowDip;
	___EXT	unsigned long	WinScreenBackColor;			/* Back Color */				

	___EXT	int		WaitDisplayTask;
	___EXT	int		WaitClassifTask;
	___EXT	int		WaitBaseChange;
	___EXT	int		WaitSetting;
	___EXT	int		WaitFileTask;

	___EXT	int iScreenNum;

	/*********************************/
	/*	PC Recive Watch              */
	/*********************************/
	___EXT	volatile	int	BaseChangeFlag;			/* Base Change Flag  0:normal,1:Changing(Classification_Task is ON) */
	___EXT	volatile	int	BaseChangeFlag1;		/* Base Change Flag1 0:normal,1:Changing(TouchKeyWriteProc is ON) */
	___EXT	volatile	int	BaseChangeFlag2;		/* Base Change Flag2 0:normal,1:Changing(Key relese Check) */
	___EXT	volatile	int	TrendClerFlag;		/* TrendCler OFF Set 050313 */

	/************************************/
	/*	1�o�b�N���C�g					*/
	/************************************/
	___EXT	int	BackLitsCnt;		/* �b */
	___EXT	int	BackLitmCnt;		/* �� */
	___EXT	int	BackLitSec;
	___EXT	int	BackLitFlag;
	___EXT	int	BuzzerOnFlag;
	/************************************/
/*	___EXT	int		ProtocalDownLoad;		ksc20090516 */  
	/************************************/
	/*	PLC Connect Error State			*/
	/************************************/
	___EXT	int		PLCCnErrorDsp;
	___EXT	int		PLCCnErrorOff;
	___EXT	unsigned	PLCCnNewRec;		/* Main PLC Timeout */
	___EXT	unsigned	PLCCnNewRec2;		/* Sub PLC Timeout */
	___EXT	int		AlarmHistryOutData;			/* Alarm History On/OFF */
	___EXT	int		displayTime;

	___EXT	unsigned int	In100MSecCnt;		/* 100ms Countor */
	___EXT	int		InSecCnt;		/* 1s Countor */
	___EXT	struct find_t UpFinddata;
	___EXT	int		SerchFirstFlag;
	___EXT	int		BlockNo;
	___EXT	int		UpFileSize;
	___EXT	int		UpFileIdx;
	___EXT	char	UpBaseNo[MAX_BASE_NO];
	___EXT	char	UpWinNo[MAX_WIN_NO];
	___EXT	char	UpParts;
	___EXT	char	UpComment;
	___EXT	char	UpHist;
	___EXT	char	UpFreq;
	___EXT	int		CommModeData;
	___EXT	int		PcHistryFlag;
	___EXT	int		HistIdx;
	___EXT	unsigned char	*CommonSendBuf;
	___EXT	unsigned int	f_base_adr;	/* Font Base Address */
	___EXT	unsigned int	f_end_adr;	/* Font Base Address */
	___EXT	int		FontCnt;		/* Font Load Count */
	___EXT	int		Hexidx;
	___EXT	int		FontFirstFlag;
	___EXT	int		FontDownloadFlag;
	___EXT	int		DownLoadComplete;		//2011.04.22

//Font Download
	___EXT	int sLanguageCode;
	___EXT	int sDownKind;
	___EXT	int sFontCode;
	___EXT	int seFontCode;
	___EXT	int sVectorCode;
	___EXT	char sFontName[12];
	___EXT	char seFontName[12];
	___EXT	char sVectorFontName[32+2];

//PLC State
	___EXT	int		PlcKansiFlag;				/* PLC�Ď��t���O */
	___EXT	int		KansiFirst;		
	___EXT	int		PlcErrorFlag;
	___EXT	unsigned int	Ch1PoleFlag;		//Ch1 Pole Use No Bit
	___EXT	int		PlcConnectFlag[MAX_POLE];				/* PLC�ڑ��t���O */
//	___EXT	int		PlcConnectFlag;				/* PLC�ڑ��t���O */
	___EXT	int		PlcType;

	___EXT	int		Plc2ChanelNo;				/* 20081025 */
	___EXT	int		PlcConnectFlag2[MAX_POLE];		/* PLC�ڑ��t���O(PLC TYPE2) 20081007 */
	___EXT	int		PlcType2Flag;
	___EXT	int		PlcLinkChanelFlag[2][MAX_POLE];				/* 20110816 */

	___EXT	unsigned	char	rDataFx[512];
	___EXT	unsigned	char	rDataPlc2[512];
	___EXT	int		ProtocolDownloadFlag;		/* �������� �ٿ�ε� Flag */ /* 20090610 */
	___EXT	int		ProtocolDownloadKind;		/* 0:RS-232C,1:USB,2:Network */ /* 20110811 */
	___EXT	int		ProtocolDownloadCount;		/* 2011.08.24 */

	___EXT	char	Hexbuff[256+2];				//iohand.cpp
	___EXT	char	DataBuf[64];				//motloader.cpp

	___EXT	volatile	unsigned	BerRecTime;		/* 040608 */


//Key Input Buff
	/* KeyData�̈� */
	___EXT	char				KerRepeatFlag;		/* 020917 */
	___EXT	struct{
				int			EntryCnt;
				KEY_ADDR	RepeatNo[8][2];
			}RepeatInf;
	___EXT	int  KeyDataIn;
	___EXT	int  KeyDataOut;

	___EXT	KEY_ADDR  KeyDataDigit[MAX_TOUCH_AREA];
//	___EXT	KEY_ADDR  KeyRealDataDigit[MAX_TOUCH_AREA];
	___EXT	KEY_ADDR  KeySumDataDigit[MAX_TOUCH_AREA][4];
	
	___EXT	unsigned short  KeyRptFlag;
	___EXT	KEY_ADDR		KeyPrev;
	___EXT	unsigned        RptTime1;
	___EXT	unsigned        RptTime2;
	___EXT	int     KeyFreeMbx;         /* Key���͗p */
#ifdef	WIN32
	___EXT	int		MousXaddr;
	___EXT	int		MousYaddr;
	___EXT	int		MousXaddr1;
	___EXT	int		MousYaddr1;
	___EXT	long   lMouseX;
	___EXT	long   lMouseY;
	___EXT	int    lMouseKey;
	___EXT	int    lMouseAction;
#endif
	___EXT	int		StartUpFlag;		//�����オ����		//sgt.cpp
	___EXT	int		StrageEditFlag;		//Strage�X�V
	___EXT	int		ProglessParcent;		//Progless bar
	___EXT	unsigned int		LogSecCnt;	//2011.04.04
	___EXT	int		NormalStartFlag;		//�����グ���ɒ��ڊ��ݒ�֓�������2011.04.08

	___EXT	int		LogDevChangeFlag;		//Log Device���ύX���ꂽ2011.08.25
	___EXT	int		BerforUserGamenNo;		//2011.09.26

//	___EXT	char	LogFileName[260];		//2011.08.17


	___EXT	unsigned char	BaseGamenArea[0x100000];
	___EXT	unsigned char	BaseGamenArea1[0x100000];
	___EXT	unsigned char	KeyGamenArea[0x2000];
	___EXT	unsigned char	MessGamenArea[0x2000];
	___EXT	unsigned char	DevGamenArea[0x2000];
	___EXT	unsigned char	TagStructArea[0x20000];

	___EXT	unsigned char	ProtocolWork[0x10000];


	___EXT	int	VectorFontDBEntryCnt;
	___EXT	int	VectorFontDBEntryPos;
	___EXT	struct{
				int				fType;
				int				iSize;
				VECTFONT_SIZE	font;
				int				len;
				unsigned char	str[128];
			}VectFntDB[MAX_VECTOR_PTRN];
	___EXT	struct{
			int	BuzzerOnOff;			//1:Setting
			int	Buzzer;
	}BuzzerSetting;						//2011.03.19

	___EXT	int	BuzzerOnCheck;			//2011.07.07

#ifdef	WIN32
	#ifdef	MAIN
		unsigned char	VectorFontArea[0x400000];
	#else
		extern	unsigned char	VectorFontArea[0x400000];
	#endif
	#define	VECT_MEM_AREA	&VectorFontArea[0]
#else
	#define	VECT_MEM_AREA	0x32800000
#endif



#include	"GpCommon.h"
