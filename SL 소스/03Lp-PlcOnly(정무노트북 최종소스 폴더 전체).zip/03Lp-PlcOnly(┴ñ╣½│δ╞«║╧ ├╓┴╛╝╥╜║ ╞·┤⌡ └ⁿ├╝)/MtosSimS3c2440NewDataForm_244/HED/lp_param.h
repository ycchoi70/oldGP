
void	InitParamFile(void);
unsigned char*	GetMotionInfo(unsigned char* buff);
unsigned char*	GetMotionList(unsigned char* buff,int size);
void	SetMotionUseFlag(void);
void	SetMotionMoveFlag(int ch,int mode);
unsigned char*	GetMotionPatrnList(unsigned char* buff,int listcnt);
//For Debug
void	InitMotionParam(void);
void	SetMotionUpFlag(int ch,int mode);
void	SetMotionFlatFlag(int ch,int mode);
void	SetMotionDownFlag(int ch,int mode);
void	SetMotionDowellFlag(int ch,int mode);
int	GetParamFile(void);
unsigned char*	GetMotionDevInfo(unsigned char* buff);
void	SetMotionDevice(void);
void	GetMotionDeviceMtInf(int ch,MOTION_FORM* param);
void	GetMotionDeviceMtList(int idx,MOTION_LIST_FORM* param);
unsigned char*	SetMotionList(unsigned char* buff,int listcnt);
unsigned char*	SetMotionInfo(unsigned char* buff);
void	SetMotionStatusFlag(int ch,int OnOff,int flag);
void	ClearLpInf(void);
void	GetMotionPatrnAsciiList(unsigned char* buff,int listcnt);
