void	SetAlarmHistory_Func (int iDispOrder);
int	DrawAlarmHistory_Func (_ALARM_HISTORY_EVENT_TBL* AlarmHistoryEventTbl,int iOrder);
void AlarmHistoryDispWatch(int iOrder);
int ProjectSet(void);		/* 20090610 */
void vHistoryDataSetBitMap(_ALARM_HISTORY_EVENT_TBL* AlarmHistoryEventTbl,int iNum, char *cDataBuffer, int iOrder);
void vHistoryDataSetVector(int type,_ALARM_HISTORY_EVENT_TBL* AlarmHistoryEventTbl,int iNum, char *cDataBuffer, int iOrder);
void	vAlarmHistoryTimeSetting(_ALARM_HISTORY_EVENT_TBL* AlarmHistoryEventTbl,char* cReturnData,short iOnOffType, int iOrder,int iNum);
int	SetAlarmHistoryCommand(void);
int	SetAlarmHistoryCommandCursor(_AREA_INFO* drawAddr);
void	SetAlarmHistUpdate(void);

