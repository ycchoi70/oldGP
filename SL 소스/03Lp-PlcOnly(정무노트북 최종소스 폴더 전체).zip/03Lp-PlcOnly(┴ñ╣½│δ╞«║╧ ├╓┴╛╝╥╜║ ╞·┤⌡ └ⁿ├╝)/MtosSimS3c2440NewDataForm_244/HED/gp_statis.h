void	SetStatistics_Func(int iDispOrder);
int	DrawStatistics_Func(int mode,_STATISTICS_EVENT_TBL* StatisticsEventTbl,int iDispOrder);
void	StatisticsDispWatch(int iOrder);
