

int	IsHexDigit(unsigned char c);
unsigned int atolx( unsigned long *data, unsigned char *ptr );
unsigned int IsSpeace( unsigned char ch );
unsigned char *SkipNextWord( unsigned char *ptr );
void DModeSendMsg( char *ptr );
void DModeSendPronpt( void );
void DModeSendPriod( void );
void DModeSendCR( void );
void DModeSendOneMsg( char *ptr );
void DModeSendLoginMsg( void );
void DModeSendCmdErr( unsigned char *pCmd );
void DModeSendQuitMsg( void );
void DModeSendVersion( void );
void DModeSendHelpMsg( void );
unsigned int DModeMemoryWrite( unsigned char *pCmd );
void MakeDumpStr( unsigned int type, char *pBuf, unsigned long spos,
							unsigned long size, unsigned long cpos );
unsigned int DModeMemoryDump( unsigned char *pCmd );
unsigned int DModeSubsProc( unsigned char *pCmd );
unsigned int GetDModeCmdNo( unsigned char *pCmd );
unsigned int AtoHex( char *ptr );
char *HextoA( int keta, int hex );
char *SkipToSpace( char *ptr );
unsigned int DModeCommand( unsigned char *pCmd );
int LoginProc( unsigned int cmd, unsigned char *msg );
int DebugTaskProc( int cmd, char *msg );
void	DebugSend(int RecCommCnt, char* CommBuff, UART_STRUCT* pSciTbl);
