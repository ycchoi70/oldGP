int WatchingDevice(char *cDevBuff, int iDeviceNumber, unsigned short iFlag, int iRegistNumber, int iBitFlag, int iCnt);
int	CompareDeviceAddr(char *cDevName, int iDevNumber, unsigned short iCnt);
int	AsciiCompareDeviceAddr(char *cDevName, int iDevNumber, int iDevcnt);
