int	GetUsrId(int mode,int No);
int iMainCallSetValue(_TOUCHKEY* iKeyVal);
int	KeyCheckLeftTop(_TOUCHKEY* iKeyVal);
int	KeyCheckRightTop(_TOUCHKEY* iKeyVal);
int	KeyCheckLeftBottom(_TOUCHKEY* iKeyVal);
int	KeyCheckRightBottom(_TOUCHKEY* iKeyVal);
int	KerReleaseCheck(_TOUCHKEY* pKey);
int	Message2InCheck(_TOUCHKEY* iKeyCode);
//File
int	MakeBaseFile(int type,int iScreenNow);
void	MakeKeyWindow(void);
void	MakeKeyWindowNormal(void);
int	MakeKeyWindowdata(int *iLastTag,int* iObjectSel,int *iScreenNo);
void	ClearWindowDisp(int Winno);
void	setOldKeyData(void);

void	FirstScreenProc(void);		//2011.08.31
