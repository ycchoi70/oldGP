/********************************************/
/*	2002.12.14								*/
/********************************************/
#ifndef	LINE_FORM
#ifndef	KEY_DLG
	#include	"gpstruct.h"
#endif
#endif

#define	MAX_PLC_LINK_DEVNO	512
#define	MAX_TIMESWICH_NUM	16

#define	MAX_SERIAL_KIND	10
//#define	MAX_PLC_LINK_ST_NO	32

//#define	MAX_UB_WORD	6048

/* 20080822 Low/High ������ LP�� ����� ����, GP�� ����Ʈ */
#define	MAX_UW_WORD	0x8000
#define	MAX_SW_WORD	0x1000

#define	MAX_LOG_NUM	8
#define	MAX_LOG_CNT	4096

/* 20060623 */
typedef struct{
	short				iSpeed;						/* 0:300, 1:600, 2:1200, 3:2400, 4:4800, 5:9600, 6:19200 7:38400bps 8:57600bps */
	short				iParity;					/* 0:NONE 1:EVEN 2:ODD */
	short				iData1;						/* 0: 7BITS 1:8BITS */
	short				iData2;						/* 0:XON/XOFF 1:DSR/DTR */
	short				iStop;						/* 0:1BITS 1:2BITS */
} _SERIALPARAM;
typedef struct {
	short		iWeek;						/* ���� ����	0:sun ~ 6:sat	*/
	char		chSHour[3];					/* ���� �� �����		*/
	char		chSMinute[3];				/* ���� �� �����		*/
	char		chSSecond[3];				/* ���� �� �����		*/
	char		chEHour[3];					/* �� �� �����			*/	
	char		chEMinute[3];				/* �� �� �����			*/	
	char		chESecond[3];				/* �� �� �����			*/	
}SET_TIMESWITCH;


typedef struct{
	int				UseFlag;
	DEVICE_INF		DevInf;
	int				RepeatNum;
	int				ConsecutiveNum;		//Device Cnt
	int				DataType;			//0:unsigned,1:signed
	RTC_DATA		PeriodicTime;
	DEVICE_INF		ConditionDevInf;
	int				Condition;			//1:Periodic,2:Condition
	int				Action;				//Bit(0:Rising,1:Falling,2:change
	int				PeriodicKind;		//0:No Set,1:Hour,2:Day,3:Week,4:Month
	int				Week;
}LOG_SET_FRM;
/* ******************************************************************************/
/*  ����ü�� : _SETUP															*/
/*  ��    �� : �ý��� ���� �� ����ü											*/
/*  �� �� �� : 2002�� 2�� 18�� (ȭ)												*/
/*  �� �� �� : ȫ �� ��															*/
/*  ��    �� : 																	*/
/* *******************************************************************************/
typedef struct{
	char				System[6];						/* LCTECH */
	/*  ���� */
	short				iLang;							/*  0:English, 1:DownLoad Lang */

	/*  PLC Ÿ�� ���� */
/*	short				iPlcType;*/						/* PlcType 0:Universal,1:Default,2:Els */
																								
/*	short				iConnect;*/						/* 0 : RS-232C, 1 : RS-422 */
	short				iDstSta;						/* 00 ~ 31 */
	short				iGPSta;							/* 00 ~ 255 */

	/* �ø��� ��� ���� */
	/* MAIN PLC */
	short				Ch1_iKind;						/* Connect Kind */
														/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR,7:PLCTYPE2 */
/* 20060623 */
	_SERIALPARAM		Ch1_Serial_Param[MAX_SERIAL_KIND];		
	short				Ch1_iConnect;					/* 0:SIO0 1:SIO1 */
/*	short				Ch1_iPrint;*/							/* 0:EDITER,1:PRINTER,2:BAR_CODE,3:MONITOR,4:PLCTYPE2 */

	/* SUB PLC */
	short				Ch2_iKind;						/* Connect Kind */
														/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR,7:PLCTYPE2 */
	_SERIALPARAM		Ch2_Serial_Param[MAX_SERIAL_KIND];
	short				Ch2_iConnect;					/* 0:SIO0 1:SIO1 */
/*	short				Ch0_iPrint;*/							/* 0:EDITER,1:PRINTER,2:BAR_CODE,3:MONITOR,4:PLCTYPE2 */
	/* Ÿ��Ʋ ȭ�� ���� �ð� */
	short				iTitleDispTime;					/* 0 ~ 60 (sec) */

	/* �޴� ȣ�� ȭ�� */
	short				iCallKey;						/* �»�(0x01), ����(0x02), ���(0x04), ����(0x08)  */

	/* �����Ʈ ���ӽð� */
	short				iBackLightTime;					/* 1 ~ 99 (Min) */

	/* ���� ���� */
	short				iBuzzer;						/* 0:OFF 1:ON */

	/* LCD ���� ���ġ */
	short				iLcdvalue;						/* 0(�帮��) ~ 8(���ϰ�) */

	/*  Data Format */
	short				iDataFormat;                    /* 0(YY/MM/DD),1(YY/DD/MM),2(DD/YY/MM),3(DD/MM/YY),4(MM/DD/YY),5(MM/YY/DD) */
	/* �ð� ����ġ ���� */
	SET_TIMESWITCH	_TIMESWITCH[8];							/* Time Switch ���		*/

	unsigned char	TimeSwitch_DevName[3];				/* TimeSwitch DeviceName  */
	unsigned int		TimeSwitch_DevAdd;

	short				LcdReverseOn;			/* ȭ�� ���� 0:Normal,1:Reverse */

/**************************************************/
/*	PLC Project ID				03/09/22	OWASI */
/**************************************************/
	char	cPlcTypeAdd[20];	/*							*/
	char	cPlcTypeCode[6];	/*							*/
	char	cPlcTypeAdd2[20];	/* Plc Type 2				*/
	char	cPlcTypeCode2[6];	/*							*/
/************************************/
	short	iMessageFlag;	/* Messang 03/12/16 */
	short	OpenBaseNo;		/* Start Base No */
	/* UW Backup ���� */
	short				iuwBackup;						/* 0:OFF 1:ON */

	short	VectorFont;		//20100805
//Log Setting
	LOG_SET_FRM	LogDevInf[MAX_LOG_NUM];





} _SETUP;

typedef struct{
	char	System[6];						/* LCTECH */
	int		LanguageCode;		/* 0 : KOREA, 1 : JAPANES, 2 : CHINESE 3 : ENGLISH */
	int		FontCode;			/* 1 : KODIC, 2 : MYUNGJO	*/
	int		eFontCode;			/* 1 : KODIC, 2 : MYUNGJO	*/
	int		VectorFontCode;			/*  */
	char	FontName[12];		/* Font	*/
	char	eFontName[12];
	char	VectorFontName[32+2];
	//Lan Setting
	unsigned int	PortAddr;
	unsigned char	ipAddr[4];
	unsigned char	snAddr[4];
	unsigned char	gwAddr[4];
	unsigned char	macAddr[6];
	unsigned char	SirialNo[4];		//2011.06.02 Add
} _ENV_PARA;


typedef struct{
	short		DevNo;
	short		Cnt;
	unsigned int sDateTime;
	unsigned int eDateTime;
	char	flag;						/* 0:Start,1:Start+End */
}ALARM_REC;
typedef struct{
	char	OnOff;				/* 0:OFF,1:ON */
	unsigned int	DateTime;
}ALARM_LIST_REC;
typedef struct{
	DEVICE_INF		DevInf;
	int				DevCnt;						/* Device Count  */
}DEVICE_TYPE;
/********* OBSEVE DEVICE *************************/
typedef	struct{
	DEVICE_INF	DevInf1;
	short	Dev1OnOff;				/* 0:OFF,1:ON */
	DEVICE_INF	DevInf2;
	short	Dev2OnOff;				/* 0:OFF,1:ON */
	short	Condition;				/* 0:OFF,1:ON Kansi de tukau */
	short	Action;					/* 0:Moment,1:Set,2:Reset,3:Alternate,4:16bit,5:32bit */
	DEVICE_INF	DevInf3;
	short	point;
	short	kind;					//2011.07.19
	int		FixData;
	DEVICE_INF	DevInf4;
	short	MoveType;				/* 0:FMove,1:BMove */
}OBS_DEV;
/***********************************/
typedef	struct{
	char	ReadWrite;				/* 0:���g�p,1:READ,2:WRITE			*/
	char	DevFlag;				/* 1:�r�b�g,0:���[�h				*/
	DEVICE_INF	DevInf;
	int		DevCnt;						/* �f�o�C�X��						*/
	int		DataAddr;
	int		DataIdx;
}LINK_DEV;
/***********************************/
typedef struct{
	char	System[6];					/* ��������LCTECH�̕���������� */
	struct{
		/* Floating Alarm */				/********************* Check */
		short	fAlarmSetFlag;
		DEVICE_TYPE	fAlarm_Dev;
		short	fAlarm_Time;				/* �Ď����ԁi100ms�j*/
		short	fFont_V;
		short	fFont_H;
		short	CommentStartNo;
		short	fVector;
		short	fVectorKind;
		/* Stored Memory Info */
		short	StoredMemCnt;			/* Stored Memory Use Count */
		struct{
			char	Kind;				/* 0:Alarm List,1:Trande */
			union{
				struct{					/* Alarm list */
					short	AlarmDevCnt;		/* Device Cnt() */
					short	AlarmGno;			/* Screen No */
					DEVICE_TYPE	StorelAlarm;	/* First Device */
					DEVICE_TYPE	StorelAlarmCnt;	/* Total Device */
				}AlarmInfo;
				struct{			/* Trend */
					short	TrandTime;
					short	TrandPoint;
					short	TrandStartIdx;		/* */
					short	TrandEntryCnt;		/* */
					short	TrandEntryIdx;		/* */
					short	TrandWordCnt;			/* 0:16Bit,1:32Bit */
					DEVICE_TYPE	Trand_Dev;	/* Trend Dev Max 8 */
					short	TrandClearMode;		/* Trend Clear Mode 0:none,1:up,2:down */
					DEVICE_TYPE	Trand_ClrDev;	/* Trend Clear Trigger Dev */
				}TrandeInfo;
			}St;
		}StoredInfo[16];
		/* Alarm List */
		DEVICE_TYPE	lAlarm_Dev;			/* Normal Alarm List */
		DEVICE_TYPE	lAlarmCnt_Dev;		/* Normal Alarm List */
		short	lAlarmSetFlag;
		short	lAlarm_Time;				/* �Ď����ԁi100ms�j*/
		/* Trend */
		short	TrandTime;
		short	TrandPoint;
		short	TrandStartIdx;		/* */
		short	TrandEntryCnt;		/* */
		short	TrandEntryIdx;		/* */
		short	TrandWordCnt;		/* 0:16Bit,1:32Bit */
		DEVICE_TYPE	Trand_Dev;		/* Trend Dev Max 8 */
		/* Switching Screen */				/******************** �ּ� CHECK  */
//		unsigned char	Switch_Base_DevName[3];			/* DeviceName      */
//		unsigned int	Switch_Base_DevAdd;				/* DeviceAddress  */
		DEVICE_INF		Switch_Base_Dev;
//		unsigned char	Switch_Over1_DevName[3];			/* DeviceName      */
//		unsigned int	Switch_Over1_DevAdd;				/* DeviceAddress  */
		DEVICE_INF		Switch_Over1_Dev;
//		unsigned char	Switch_Over2_DevName[3];			/* DeviceName      */
//		unsigned int	Switch_Over2_DevAdd;				/* DeviceAddress  */
		DEVICE_INF		Switch_Over2_Dev;
		DEVICE_INF		Setting_Base_Dev;					//20100526
		/* Password */					/******************** �ּ� CHECK  */
		DEVICE_TYPE	Password_Dev;
		char	Password[15][16];		/* 20081023 9->16 */
		short	DispPassinputchk;		/*0220 Display password input error�� Check Flag(check : 0xFF, Uncheck : 0x00)*/	
		/* BarCode */
		DEVICE_TYPE	Barcode_Dev;		/********************* CHECK */
		short	BarCodeInCnt;			/* Input Max Count */
		/* Read Device */
		DEVICE_TYPE	Read_Dev;			/********************* CHECK */
		/* Write Device */
		DEVICE_TYPE	Write_Dev;			/********************* CHECK */
		/* Triger(Obseve) */
		short		Observe_Proj_Cnt;	/******************** �ּ� CHECK  */
		OBS_DEV		Observe_Proj_Dev[40];


		short	Proj_ObserveStatus;			/* 0:Allways,1:sampling */
		short	Proj_ObserveTime;			/* Sampling Time */

		short		Observe_Screen_Cnt;			/******************** �ּ� CHECK  */
		OBS_DEV		Observe_Screen_Dev[40];
		short	Screen_ObserveStatus;		/* 0:Allways,1:sampling */
		short	Screen_ObserveTime;			/* Sampling Time */
		struct {								/********************* CHECK */
			int				StartTime;				/* Sec */
			int				EndTime;
			short			iWeek;					/* ���� ���� 0x01:sun->0x40:sat For Bit*/
			short			OnOffFlag;					/* 0:OFF,1:ON           */
		} _TIMESWITCH[MAX_TIMESWICH_NUM];
//		unsigned char	TimeSwitch_DevName[3];
//		unsigned int	TimeSwitch_DevAdd;
		DEVICE_INF		TimeSwitch_Dev;
		/* Recip */							/********************* CHECK */
		short	RecipCnt;						/* 0:OFF,1->:ON(Data Cnt) */
		short	RecipPoint;
//		unsigned char	Recip_Read_DevName[3];			/* DeviceName      */
//		unsigned int	Recip_Read_DevAdd;				/* DeviceAddress  */
		DEVICE_INF		Recip_Read_Dev;
		short	RecipReadFlag;					/* 0:OFF,1:ON,-1:Un Use */
//		unsigned char	Recip_Write_DevName[3];			/* DeviceName      */
//		unsigned int	Recip_Write_DevAdd;				/* DeviceAddress  */
		DEVICE_INF		Recip_Write_Dev;
		short	RecipWriteFlag;					/* 0:OFF,1:ON */
//		unsigned char *RecipStart;				/* Recip Start Address */
		unsigned int RecipStart;				/* Recip Start Address */
		/* Alarm History */					/********************* CHECK */
		short	AlarmSetFlag;			/* 1:Clear,0:else */
		DEVICE_TYPE	Alarm_Dev;
		DEVICE_TYPE	Alarm_DevStore;
		DEVICE_TYPE	Alarm_DevErase;
		short	Alarm_Time;					/* �Ď����ԁi100ms�j*/
		short	iDetailDisp;		/* Detailed Display (1:Not Display, 2:Comment Window, 3:Base Screen)		 */
		int		iCommentNo;			/* AlarmHistory CommentStartNo */

	}SystemDev;
	/* Password(Project) */			/********************* CHECK */

	short	PasswordOnOff;
	char	ProjPassword[16+1];
	char	ProjID[4+1];
	short	ResetCheck[256];
/************************************/
/*	Alarm History Info				*/
/************************************/
	short	EntryCnt;				/* Entry Count */
	short	EntryIdx;				/* Entry Index */
	short	StartIdx;				/* Start Index */
	short	AlarmTotalCnt;			/* AlarmHistory Total Count */
	short	AlarmTotalOnCnt;		/* AlarmHistory On Device Count */
	short	TotalCnt[256];
	short	DevIdx[256];
	ALARM_REC	AlarmHistRec[1024];
/********************************/
/*	Battery Data				*/
/********************************/
	int		BatteryLevel;				/* Battery Level Data */
/********************************/
/*	�Ď��f�[�^�̈�				*/
/********************************/
	unsigned char	SaveAlarm[256];
	unsigned char	AlarmData[256];
	unsigned char	AlarmHistDelDat;
	unsigned char	sAlarmHistDelDat;
	unsigned char	fSaveAlarm[256];
	unsigned char	fAlarmData[256];
	unsigned char	rRecipeData;
	unsigned char	rSaveRecipeData;
	unsigned char	wRecipeData;
	unsigned char	wSaveRecipeData;
	/**** Read Device Data ********/
	union{		//061124
		unsigned char	ReadDevData[6];
		unsigned short	ReadDevWord[3];		/* 0:Base-No,1:Signal3,2:Recip No0,3:Recipe No1 */
	}Read;
	union{		//061124
		unsigned char	WriteDevData[30];
		unsigned short	WriteDevWord[15];
	}Write;
	unsigned char	BackLightData;
	unsigned char	AlarmHistData;
	/*** PassWord Device Data *****/
	unsigned char	PassWordDevData[2];
	/*** Switching Screen Dev Data ***/
//061124
//	unsigned char	SwitchingData[6];
	unsigned short	SwitchingData[3];
	/*** Trand Graph Data *********/
	unsigned char	TrandDevData[17][8*4];
	unsigned char	TrandDevClrData[16];		/* Trand Cler Trigger Dev Data */
	unsigned char	sTrandDevClrData[16];		/* Trand Cler Trigger Dev Data */
	/*** Alarm List ***************/
	unsigned char	AlarmListData[256];
	unsigned char	sAlarmListData[256];
	unsigned char	AlarmListStoreData[16][256];
	unsigned char	sAlarmListStoreData[16][256];
	/*** Observe Trig *************/
	unsigned char	OvservDataProj[80];
	unsigned char	OvservDataScrren[80];
	/* Stored Memory */
	int	AlarmlistTotalCnt;
	ALARM_LIST_REC	AlarmListRec[256];
	int		TrandeData[8][51];
	union{
		struct{
			int	TotalCnt;
			ALARM_LIST_REC	StoreAlarmListRec[256];
		}Alarm;
		int		TrandeData[8][51];
	}StordMem[16];
/************************************/
/*	PLC Project ID					*/
/************************************/
/************************************/
	struct{
		int		iDefault;
		int		iKeyType;
		int		iDecNo;
		int		iHexNo;
		int		iAsciiNo;
		short	iFlagData;
	} KeyWindow;
	struct{
		int					OpenKeyWinCkeck;
		short				DispCursorWindow;
		short				DispFormat;
	} ProjectAuxSet;
	char	CS_Inf[32];		/* 0->255Bit 0:OFF,1:ON */
	unsigned int	CS_StartAddr;
	char	TS_Inf[32];		/* 0->255Bit 0:OFF,1:ON */
	unsigned int	TS_StartAddr;

	char UtilityLevel[MAX_SYS_SCREEN];
/************************************/
/*	PLC Type1 Setting				*/
/************************************/
	struct{
		char	PlcUserFlag;						/* Use : 0x0ff, Not Use : 0x00	*/
		char	MasterSlave;						/* MASTER(1),SLAVE(2)			*/
		DEVICE_INF	GpDevice;
	}PlcType1;
/************************************/
/*	PLC Type2 Setting				*/
/************************************/
	struct{
		char	AuxPlcUserFlag;						/* Use : 0x0ff, Not Use : 0x00 */
		char	AuxPlcGroupName[20];
		char	AuxPlcTypeName[20];
		char	AuxPlcGroupCode[2+2];
		char	MasterSlave;						/* MASTER(1),SLAVE(2)			*/
		DEVICE_INF	GpDevice;
	}PlcType2;
	int			LinkDevEntryCnt;
	LINK_DEV	LinkDevInf[MAX_PLC_LINK_DEVNO];						/* PLC1 �f�o�C�X���			*/
	int		PcUpDownMode;		/* 0:Idle,1:Rec,2:Send */

	int		EnviromentFlag;
	int		MessageWindowFlag;
	int		DownLoadCopyFlag;			//Data Copping 2011.09.23

}COMMON_AREA;
typedef	struct{
	char	Pass[16];	//2011.08.11
	int	StartIdx;		//Start Pos(Read Idx)
	int	EntryIdx;		//Now Entry Pos(Write Idx)
	int	LogDevCnt;		//Entry Device Count
	int	Log_fp;			//Log File File Descriptor
	int	LogFileCnt;		//Log File Number
	int	LogItemCnt;		//Log File Item Number
	struct{
		int	UseFlag;				//0:nouse,1:use
		DEVICE_INF	LogDev;			//Log Device
		int	DevCnt;					//Log Device Count(Word:<=4,Bit:<=8)
		int	DevData_idx;			//Log Data Index
		int	WordMode;				//Word Data Type(0:Unsigned,1:Signed)
		int	TrigerMode;				//Triger Mode(-1:Time,Else:Triger)
		int	PeriodicKind;			//2011.08.24
		int	Week;					//2011.08.24
		DEVICE_INF	TrigLogDev;		//Triger Device
		int	TrigDevData_idx;		//Triger device Data Index
//		unsigned	int	TrigTime;	//Cycle Time(s)
		RTC_DATA	TrigTime;	//Cycle Time(s)
//		unsigned	int	TrigNowTime;	//Now Time(ms)
		RTC_DATA	TrigNowTime;	//Now Time(ms)
		int	RepeatNum;				//Repeat Number(0:Allways)
		int	RepeatNowNum;			//Repeat write Number
		char	DeviceName[16];		//Save Device Name
	}DevInf[MAX_LOG_NUM];		//0:Log Device,1:Triger Device
	unsigned char	LogDevData[1024];
	unsigned char	LogSaveDevData[1024];
	struct{
		unsigned short	LogTypeNo;	//Devinf Number(0->7)
		unsigned short	LogDate;	//Date(yyyyyyymmmmddddd)
		unsigned long	LogTime;	//Time(hhhhhhhhhhhhmmmmmmmmssssssss)
		unsigned char	Data[8];	//Data
	}LogData[MAX_LOG_CNT];

}LOG_FORM;
extern	_SETUP			Set;					/* set value save struct */
extern	_ENV_PARA		Env;					/* Enviroment struct */

#ifndef	COMM_AREA
extern	COMMON_AREA	CommonArea;
extern	LOG_FORM	LogDataArea;
#endif
#define	INDEV_UN_W	2048
#define	INDEV_UN_B	4096
#define	INDEV_UN_NO	8712
#define	INDEV_READ		15
#define	INDEV_READ_B	30
#define	INDEV_READ_NO	15
#define	INDEV_WRITE		0
#define	INDEV_WRITE_NO	15

#define	Device_Length_UW	0x8000
#define	DUMY_DEV			2000
#define	Device_Length_R_ST	DUMY_DEV
#define	Device_Length_R		4100
#define	MAXDevice_Length_R	4000
#define	Device_Length_V_ST	(Device_Length_R_ST+Device_Length_R)
#define	Device_Length_V		300
#define	MAXDevice_Length_V	256
#define	Device_Length_F_ST	(Device_Length_V_ST+Device_Length_V)
#define	Device_Length_F		300
#define	MAXDevice_Length_F	256
#define	Device_Length_Z_ST	(Device_Length_F_ST+Device_Length_F)
#define	Device_Length_Z		300
#define	MAXDevice_Length_Z	256
#define	Device_Length_X_ST	(Device_Length_Z_ST+Device_Length_Z)
#define	Device_Length_X		300		/* ���̓����[ */
#define	MAXDevice_Length_X	256		/* ���̓����[ */
#define	Device_Length_Y_ST	(Device_Length_X_ST+Device_Length_X)
#define	Device_Length_Y		300		/* �o�̓����[ */
#define	MAXDevice_Length_Y	256		/* �o�̓����[ */

#define	Device_Length_BT_ST	(Device_Length_Y_ST+Device_Length_Y)
#define	Device_Length_BT	100
#define	MAXDevice_Length_BT	16
#define	Device_Length_T_ST	(Device_Length_BT_ST+Device_Length_BT)
#define	Device_Length_T		300
#define	Device_Length_T_BIT		256		//
#define	MAXDevice_Length_T	256		//
#define	Device_Length_ST_ST	(Device_Length_T_ST+Device_Length_T)
#define	Device_Length_ST	300
#define	MAXDevice_Length_ST	256
#define	Device_Length_BC_ST	(Device_Length_ST_ST+Device_Length_ST)
#define	Device_Length_BC	100
#define	MAXDevice_Length_BC	16
#define	Device_Length_C_ST	(Device_Length_BC_ST+Device_Length_BC)
#define	Device_Length_C		300
#define	MAXDevice_Length_C	256
#define	Device_Length_SC_ST	(Device_Length_C_ST+Device_Length_C)
#define	Device_Length_SC	300
#define	MAXDevice_Length_SC	256
#define	Device_Length_M_ST	(Device_Length_SC_ST+Device_Length_SC)
#define	Device_Length_M		10500
#define	MAXDevice_Length_M	10000
#define	Device_Length_S_ST	(Device_Length_M_ST+Device_Length_M)
#define	Device_Length_S		500
#define	MAXDevice_Length_S	256
#define	Device_Length_L_ST	(Device_Length_S_ST+Device_Length_S)
#define	Device_Length_L		1000
#define	MAXDevice_Length_L	256
#define	Device_Length_D_ST	(Device_Length_L_ST+Device_Length_L)
#define	Device_Length_D		10000
#define	MAXDevice_Length_D	10000
#define	FSave_ST			(Device_Length_D_ST+Device_Length_D)		//2011.10.06
#define	Debug_Y_ST			(FSave_ST+Device_Length_F)					//2011.10.06
//2011.10.06#define	Device_Length_END	(Device_Length_D_ST+Device_Length_D+Device_Length_F)
#define	Device_Length_END	(Debug_Y_ST+Device_Length_Y)


typedef struct{
	unsigned short Dumy[DUMY_DEV];			//UW[0000]+2000
	unsigned short R[Device_Length_R];		//UW[2000]+4100
	unsigned short V[Device_Length_V];		//UW[6100]+300
	unsigned short F[Device_Length_F];		//UW[6400]+300
	unsigned short Z[Device_Length_Z];		//UW[6700]+300
	unsigned short X[Device_Length_X];		//UW[7000]+300		UW[7000]	/* ���̓����[ */
	unsigned short Y[Device_Length_Y];		//UW[7300]+300		UW[8000]	/* �o�̓����[ */
	unsigned short BT[Device_Length_BT];	//UW[7600]+100
	unsigned short CT[Device_Length_T];		//UW[7700]+300
	unsigned short ST[Device_Length_T];		//UW[8000]+300
	unsigned short BC[Device_Length_BC];	//UW[8300]+100
	unsigned short CC[Device_Length_C];		//UW[8400]+300
	unsigned short SC[Device_Length_C];		//UW[8700]+300
	unsigned short M[Device_Length_M];		//UW[9000]+10500	UW[20000]
	unsigned short S[Device_Length_S];		//UW[19500]+500
	unsigned short L[Device_Length_L];		//UW[20000]+1000
	unsigned short D[Device_Length_D];		//UW[21000]+10000	UW[40000]
	unsigned short FSave[Device_Length_F];	//Fdevice Save Area
	unsigned short Debug_Y[Device_Length_Y]; //Debug Y 2011.10.06
}PLC_DEV;

#ifndef	COMM_AREA
	extern	union{
		unsigned short	UW[MAX_UW_WORD+MAX_SW_WORD];
		unsigned char	UB[(2048+4356)*2];
		PLC_DEV	PlcDev;
	}InDevArea;
#endif
/********************************/
/*	FONT						*/
/********************************/
//extern	unsigned char			GpFont[0x200000];
