#ifndef __UBISYS_USB_HW_H__
#define __UBISYS_USB_HW_H__

#define	MULT_INTF
//#define	SIGLE_STRAGE

#define	USB_COMM	0
#define	USB_STRAGE	1


//
// EndPoint configuration 
//

//
// The control FIFO is 16 bytes and Cotulla's 
// UDC is an highspeed device.
//
// ----- TEMPORARILY changed to 8 for testing.
//#define EP0Len          16
#define EP0Len          8

//
// The BULK IN/OUT packet size may be configured to 8, 16, 32, or 64 bytes
// Use 64 bytes, the size of Cotulla's Endpoints 1 & 2 FIFO
//
#define EP0_PACKET_SIZE                     8
#define EP1_PACKET_SIZE                     64
#define EP2_PACKET_SIZE                     64
#define EP3_PACKET_SIZE                     64
#define EP4_PACKET_SIZE                     64

//============================================================
// Standard Chapter 9 definition
//============================================================

// Request Codes
#define GET_STATUS          0x00
#define CLEAR_FEATURE       0x01
#define SET_FEATURE         0x03
#define SET_ADDRESS         0x05
#define GET_DESCRIPTOR      0x06
#define SET_DESCRIPTOR      0x07
#define GET_CONFIG          0x08
#define SET_CONFIG          0x09
#define GET_INTERFACE       0x0a
#define SET_INTERFACE       0x0b
//
// Device specific request to handle
// modem control signals
//
#define SET_CONTROL_LINE_STATE  0x22

// Descriptor Types
#define DEVICE              0x01
#define CONFIGURATION       0x02
#define STRING              0x03
#define INTERFACE           0x04
#define ENDPOINT            0x05

// Trace buffer if tracing is enabled.
// Previous address used was at end of NK IMAGE - 0x83F16000
#define UDC_PHYSICAL_TRACE_BUFFER 	0x83E40000 

// Trace types
#define UDCT_INTR			     		1
#define UDCT_EP0			     		2
#define UDCT_SEND_DATA			 	    3
#define UDCT_GET_COMMAND		 	    4
#define UDCT_COMMAND_DONE		        5
#define UDCT_UDCCS0				        6
#define UDCT_PRE_STATUS			        7
#define UDCT_STALL			     		8
#define UDCT_SETUP		  	     		9
#define UDCT_RX_INT			    		10
#define UDCT_NO_RPC			    	    11
#define UDCT_EP1_XMIT		    		12
#define UDCT_TPC			    		13
#define UDCT_TUR			    		14
#define UDCT_FORCE_OPR		    		15
#define UDCT_UDCCS0_STATE	    		16
#define UDCT_PARSE_SETUP	    		17
#define UDCT_GET_DESC		    		18
#define UDCT_INTR_EXIT		    		19
#define UDCT_STATUS_OUT		    	    20
#define UDCT_STATUS_OUT_MISSED	        21
#define UDCT_SET_CONFIG		    	    22
#define UDCT_STATUS_IN		    		23
#define UDCT_ISR			    		24
#define UDCT_XMIT_DONE		    		25
#define UDCT_READ_COMP		    		26
#define UDCT_VENDOR_MODEM_CMD   	    27
#define UDCT_RX_DATA            		28
#define UDCT_RX_INTR_DONE       		29
#define UDCT_TX_DATA            		30
#define UDCT_UDC_ISR0           		31
#define UDCT_UDC_ISR1           		32  
#define UDCT_UDC_CSR_A          		33
#define UDCT_UDC_CSR_B          		34
#define UDCT_UDC_RX_BUF_EMPTY   	    35

#define UDC_STATE(x) x->eState

//============================================================
// EP1/EP2 packet size. For polling this can not be greater than 16
//============================================================
//static unsigned int maxOutPacketSize = EP2Len;
//static unsigned int maxInPacketSize = EP1Len;

//============================================================
// String Descriptor Indexes
//============================================================
#define languagesStringIndex        	0
#define manufactureStringIndex      	1
#define productStringIndex          	2
#define configurationStringIndex    	3
#define interfaceStringIndex        	4
#define SerialNumberStringIndex     	5
#define lastStringIndex             		SerialNumberStringIndex

#define STRING_DESCRIPTOR			    0x03

#define USBData_HighByte(x)             (((x) >> 8) & 0xff)      /* get high byte from the (usb) little endian */
#define USBData_LowByte(x)              ((x) & 0xff)                	/* get low byte from the (usb) little endian */


#ifndef MIN
#define MIN(x,y)		((x) < (y) ? (x) : (y))
#endif

//STATIC UINT32 MS_USB_ClearEndpointStall(UINT32 nEndPoint);
static void	OnReset(void);
//==============================================================================================


//#define UDC_VID            0x0eff
//#define UDC_PID            0x03ff
//#define UDC_VER            0x0007
#define UDC_VID            0x24a1
#define UDC_PID            0x0000
#define UDC_VER            0x0000


#define NUM_ENDPOINTS       2



/*====================================================================================================*/
/*
 * The Device Descriptor.  See the USB Spec for the format.
 */
#define UDC_STANDARD_DESCRIPTOR_TYPE        0x00
#define UDC_DEVICE_DESCRIPTOR_TYPE          0x01
#define UDC_CONFIGURATION_DESCRIPTOR_TYPE   0x02
#define UDC_STRING_DESCRIPTOR_TYPE          0x03
#define UDC_INTERFACE_DESCRIPTOR_TYPE       0x04
#define UDC_ENDPOINT_DESCRIPTOR_TYPE        0x05
#define UDC_POWER_DESCRIPTOR_TYPE           0x06
#define UDC_CLASS_DESCRIPTOR_TYPE           0x20
#define UDC_HID_DESCRIPTOR_TYPE             0x21
#define UDC_REPORT_DESCRIPTOR_TYPE          0x22
#define UDC_PHYSICAL_DESCRIPTOR_TYPE        0x23

#define UDC_ENDPOINT_TYPE_MASK              0x03

#define UDC_ENDPOINT_TYPE_CONTROL           0x00
#define UDC_ENDPOINT_TYPE_ISOCHRONOUS       0x01
#define UDC_ENDPOINT_TYPE_BULK              0x02
#define UDC_ENDPOINT_TYPE_INTERRUPT         0x03

#define UDC_CLASS_CODE_MASSSTORAGE_CLASS_DEVICE     0x08

#define UDC_SUBCLASS_CODE_RBC               0x01
#define UDC_SUBCLASS_CODE_SFF8020I          0x02
#define UDC_SUBCLASS_CODE_QIC157            0x03
#define UDC_SUBCLASS_CODE_UFI               0x04
#define UDC_SUBCLASS_CODE_SFF8070I          0x05
#define UDC_SUBCLASS_CODE_SCSI              0x06

#define UDC_PROTOCOL_CODE_CBI0              0x00
#define UDC_PROTOCOL_CODE_CBI1              0x01
#define UDC_PROTOCOL_CODE_BULK              0x50



/* Mass Storage Class definition ref. S3.1*/
#define UDC_MSD_CLASS_RESET                 0xFF
#define UDC_MSD_CLASS_GET_MAXLUN            0xFE

#define UDC_MSD_RESET                       ((UDC_MSD_CLASS_RESET<<8)|UDC_REQUEST_TYPE_CLASS|UDC_REQUEST_RECIPIENT_INTERFACE|UDC_REQUEST_DIRECTION_H2D)
#define UDC_MSD_GET_MAXLUN                  ((UDC_MSD_CLASS_GET_MAXLUN<<8)|UDC_REQUEST_TYPE_CLASS|UDC_REQUEST_RECIPIENT_INTERFACE|UDC_REQUEST_DIRECTION_D2H)

/* Standard Feature Selector ref */
#define UDC_DEVICE_REMOTE_WAKEUP            (0x0001)
#define UDC_ENDPOINT_HALT                   (0x0000)

/* Standard USB Device Requests ref 9.3*/
/* bmRequestType bitmap */
#define UDC_REQUEST_RECIPIENT_MASK          (0x1F)  // D[4,0]
#define UDC_REQUEST_RECIPIENT_SHIFT         (0)
    #define UDC_REQUEST_RECIPIENT_DEVICE            (0x00<<UDC_REQUEST_RECIPIENT_SHIFT)
    #define UDC_REQUEST_RECIPIENT_INTERFACE         (0x01<<UDC_REQUEST_RECIPIENT_SHIFT)
    #define UDC_REQUEST_RECIPIENT_ENDPOINT          (0x02<<UDC_REQUEST_RECIPIENT_SHIFT)
    #define UDC_REQUEST_RECIPIENT_OTHER             (0x03<<UDC_REQUEST_RECIPIENT_SHIFT)
#define UDC_REQUEST_TYPE_MASK               (0x60)  // D[6,5]
#define UDC_REQUEST_TYPE_SHIFT              (5)
    #define UDC_REQUEST_TYPE_STANDARD               (0x00<<UDC_REQUEST_TYPE_SHIFT)
    #define UDC_REQUEST_TYPE_CLASS                  (0x01<<UDC_REQUEST_TYPE_SHIFT)
    #define UDC_REQUEST_TYPE_VENDOR                 (0x02<<UDC_REQUEST_TYPE_SHIFT)
#define UDC_REQUEST_DIRECTION_MASK          (0x80)  // D[7]
#define UDC_REQUEST_DIRECTION_SHIFT         (7)
    #define UDC_REQUEST_DIRECTION_H2D               (0x00<<UDC_REQUEST_DIRECTION_SHIFT)
    #define UDC_REQUEST_DIRECTION_D2H               (0x01<<UDC_REQUEST_DIRECTION_SHIFT)

/* 'Standard USB Device Requests' Request Codes (bRequest) ref T9.3 */
#define UDC_GET_STATUS                      (0x0000)
#define UDC_CLEAR_FEATURE                   (0x0001)
#define UDC_SET_FEATURE                     (0x0003)
#define UDC_SET_ADDRESS                     (0x0005)
#define UDC_GET_DESCRIPTOR                  (0x0006)
#define UDC_SET_DESCRIPTOR                  (0x0007)
#define UDC_GET_CONFIGURATION               (0x0008)
#define UDC_SET_CONFIGURATION               (0x0009)
#define UDC_GET_INTERFACE                   (0x000A)
#define UDC_SET_INTERFACE                   (0x000B)
#define UDC_SYNC_FRAME                      (0x000C)



#define UDCMASS_EP_RECV                     2           // OUT	(PC  -> UDC)
#define UDCMASS_EP_XMIT                     1           // IN	(UDC -> PC)

#define UDCMASS_RECV_PACKET_SIZE            EP2_PACKET_SIZE
#define UDCMASS_XMIT_PACKET_SIZE            EP1_PACKET_SIZE



//============================================================
// Define the configuration descriptor length
//============================================================
//#define CFGLEN 32
#ifdef	MULT_INTF
#define CFGLEN 69
#else
#define CFGLEN 39
#endif


//============================================================
// Definition 
//============================================================
#define iCONF       18
#define TLEN        (CFGLEN + 18) 



////============================================================
//// Local Function Prototype
////============================================================
//BOOL IsCableConnect( void );
//
//
////============================================================
//// Extern Function Prototype
////============================================================

#endif

unsigned int	MS_USB_GetInterruptType( void );
int	GetUsbRcvData(int type,char* Buff);
void	SendUsbData(int type,unsigned char* buff,int cnt);
void	InitUDC(void);
void	SetWriteBuffer(int type,unsigned char*buff,int len);
void	IoWrite(int type,unsigned char* pBuf,int nReqWrite);

