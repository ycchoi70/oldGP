void	SetAscii_Func(int iDispOrder);
int	DrawAscii_Func(int mode, _ASCII_EVENT_TBL* AsciiDispEventTbl, int iDispOrder);
void AsciiDispWatch(int iOrder);

