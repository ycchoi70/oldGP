/****************************************/
/*      ��??�v���O��?                */
/****************************************/
/*	Buffer                              */ 
#define	MAIN
#include	<string.h>
#include	<stdlib.h>
#include	<stdio.h>

#include	"define.h"
#include	"selib.h"
#include	"mylib.h"
#include	"bios.h"
#include	"s2440.h"
#include	"glplcd.h"
#include	"CommBuff.h"
#include	"disp.h"
#include	"rs232c.h"
#include	"lload.h"
#include	"udebtsk.h"
#include	"touch.h"
#include	"usbh.h"
#include	"udc_2440.h"
#include	"flash.h"
#include	"hardtest.h"

#ifdef	WIN32
#include    "Mts.h"
#include    "MtsCifp.h"
#include    "Mail.h"
#include	"Taskhed.h"
#endif



void	InterruptEnableTick(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

#ifdef	WIN32
	return;
#endif
//    pINTRegs->rINTMSK &= ~(1 << INTSRC_TIMER4);
    pINTRegs->rINTMSK &= ~BIT_WDT;
    pINTRegs->rINTSUBMSK &= ~BIT_SUB_WDT;

}
void	InterruptEnableCom2(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

#ifdef	WIN32
	return;
#endif
	pINTRegs->rSRCPND     = BIT_UART2;
	// S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
	if (pINTRegs->rINTPND & BIT_UART2)
		pINTRegs->rINTPND = BIT_UART2;

	pINTRegs->rINTMSK    &= ~BIT_UART2;
}
void	InterruptEnableCom1(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

#ifdef	WIN32
	return;
#endif
	pINTRegs->rSRCPND     = BIT_UART1;
	// S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
	if (pINTRegs->rINTPND & BIT_UART1)
		pINTRegs->rINTPND = BIT_UART1;

	pINTRegs->rINTMSK    &= ~BIT_UART1;
}

void	InterruptEnableCom0(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

#ifdef	WIN32
	return;
#endif
	pINTRegs->rSRCPND     = BIT_UART0;
	// S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
	if (pINTRegs->rINTPND & BIT_UART0)
		pINTRegs->rINTPND = BIT_UART0;

	pINTRegs->rINTMSK    &= ~BIT_UART0;
}

/************************************************************/
/*	�P�������M												*/
/************************************************************/
int	GetMessage( char *ptr )
{
	int c, no;

	no= 0;
	if(IS_CONSOL() != 0){
		while( TRUE ){
			if( (c= GET_CONSOL()) != 0 ){
				switch( c ){
				case 0x0A:	case 0x0D:
					*(ptr+ no)= c;
					no++;
					return( no );
				case 0x08:
					if( no > 0 ){	no--;	}
					break;
				case 0x04:
					*ptr= c;
					return( 1 );
				default:
					*(ptr+ no)= c;
					no++;
					break;
				}
				if( DModeFlag == 0x10 /*OK_LOGIN*/ ){
				}
			}
#ifdef	WIN32
			Delay(100);
#endif
		}

	}
	return( 0 );
}

#define	TIME_INIDMODE	1

//20080819
char msg[256];
void DubugMain( void )
{

	TouchRepeatFlag= 1;
	ClearDisplay();
	BuzOff();

	TimerStart( TIME_INIDMODE, 500 );		/* Wait 5Sec */  

	while( TRUE ){
		if( DModeFlag != 0x10 ){  
			if( time_flag[TIME_INIDMODE] != 0 ){
				TouchRepeatFlag= 0;
				return;
			}
		}
		if( GetMessage( msg ) != 0 ){
			DModeFlag= DebugTask( DModeFlag, &msg[0] );
		}
#ifdef	WIN32
		Delay(100);
#endif
	}

}
#ifdef	WIN32
COLOR_DT    LcdBufWin[LCD_Y_SIZE][LCD_X_SIZE];
#endif
void	SetLcdAddr(void)
{
#ifdef	WIN32
	LcdBuff= (LCD_BUF*)&LcdBufWin[0];
#else
	LcdBuff= (LCD_BUF*)LCD_BUF_ADDR;
#endif
}
/****************************************/ 
/* Loader Main Prog                     */
/****************************************/
#ifdef	WIN32
void    main_start( STTFrm* pSTT )       /* ���C������?�X�N */
#else
void    main_start(void)
#endif
{

	SetLcdAddr();
	DownloadBuff= (unsigned char*)DOWNLOAD_BUFF;
	HardInitial();				//MMU Setting
	SysHardInitial();
	ClearDisplay();
	SetSci0Tbl();
	InitSci0(115200,8,0);
	SetSci1Tbl();
	InitSci1(115200,8,0);
	SetSci2Tbl();
//	InitSci2(115200,8,0);
	InterruptEnableCom1();
	InterruptEnableCom0();
	InterruptEnableTick();

	NAND_Map_Check();		//20100729


	TouchInit();

	RtcInit();

	Timer3DefltInit();					//Buzzer


	BatteryAdStart= 0;		//2011.1.25
	_ei();

	ForGrandColor.r= 0xff;			//WHITE()
	ForGrandColor.g= 0xff;			//WHITE()
	ForGrandColor.b= 0xff;			//WHITE()
	BackGrandColor.r= 0x00;			//BLACK
	BackGrandColor.g= 0x00;			//BLACK
	BackGrandColor.b= 0x00;			//BLACK

	DModeFlag = 0;
	SioEchoFlag= 0;
	SubsModeFlag= FALSE;			/* �r�t�a�r��?�h�t���O */
	PloadFlag= FALSE;				/* �v���O��?��?�h�t���O */
	DefaultAdress= 0;				/* �A�h���X�����͎��̃f�t�H���g�l */

//	contrast= DEF_CONTRAST;
//	SetContrast(contrast);


	SetBacklight(0,16,BACKLIGHT_CNT,BACKLIGHT_INTERVAL[11]);		//BackLight Default
	BackLightOnOff(ON);

	LCDDisplayEnable(ON);


//	TextOut(4,3,TVS_VERSION_MES);
//	RectAngle(1,1,798,478,T_WHITE,T_BLACK);

	LoaderStartMsg();


	UsbHostInitial();
	UsbDevIntEnable();
	UsbDevHandlerInit();


//	TextOut(11,10,"Hardware Test Mode");


	HardTest();

}
