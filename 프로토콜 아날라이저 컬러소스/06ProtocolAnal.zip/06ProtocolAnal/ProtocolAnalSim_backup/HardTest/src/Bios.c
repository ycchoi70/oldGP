/*********************************************************************/

#define	BIOS_PROC
#include	<stdio.h>
#include	<string.h>

#include	"define.h"
#include	"glplcd.h"

#include	"Commbuff.h"
#include	"bios.h"
#include	"disp.h"
#include	"s2440.h"
#include	"rs232c.h"
#include	"io_define.h"

#include	"HardTest.h"
#include	"touch.h"


#define	DEBUG_KEY




extern	int	TouchTimerCheck(void);


/*#define	LITTLE		1*/

void	DrawLcdBank( unsigned char *buff );

#ifdef	WIN32
extern	void	DrawLcd( char* pBitmapBits );
#else
void	DrawLcd( char* pBitmapBits )
{
	DrawLcdBank((unsigned char *)pBitmapBits);
}
#endif

/****************************************************/
/*    FUNC   : T6963C Contorol						*/
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 2003.8.10                            */
/*    Update :                                      */
/****************************************************/

int		LcdDrawMode;
int		LcdLineCnt;
int		LcdHalfFlag;
int		RefleshFlag;
int		LcdReverse;



int	eFlag;
/****************************************************/
/*	Display Apl Interface							*/
/****************************************************/
void	DrawLcdBank( unsigned char *buff )
{
	memcpy((char *)BaseLcd_Buffer,(char *)&LcdBuff[0],sizeof(LCD_BUF));
//	int	i,j;
//	int* src= (int*)&LcdBuff[0];
//	int* obj= (int*)BaseLcd_Buffer;
//	for(i= 0; i < LCD_Y_SIZE; i++){
//		for(j= 0; j < LCD_X_SIZE; j++){
//			*obj++= *src++;
//		}
//	}

}


void	EraseArea(int iStartX, int iStartY, int iEndX, int iEndY)
{

	int	i,j, k;
	char *addr, *dataAddr;	

#ifdef WIN32
	return;
#endif
	
	addr = (char *)BaseLcd_Buffer; 
	dataAddr = addr;	
	
	
	for(i= iStartY+1; i < iEndY; i++)
	{			
		for(j= iStartX; j < iEndX; j++)	
		{
			dataAddr = addr+(i*800*4+j*4);
			*dataAddr =  0x00;			
			*(dataAddr+1) =  0x00;
			*(dataAddr+2) =  0x00;
			*(dataAddr+3) =  0x00;			
			
			//for(k=0; k < 10000; k++);
			
		}

	}
	
}


void	DotDrawLcdBank( int sx,int sy,int ex,int ey )
{
	int	i,j;
	unsigned int* src;
	unsigned int* obj;		
	LCD_BUF*	LcdFarme= (LCD_BUF*)BaseLcd_Buffer;	
	for(i= sy; i <= ey; i++){		
		src= (unsigned int*)&LcdBuff->lbuff[i][sx];
		obj= (unsigned int*)&LcdFarme->lbuff[i][sx];
		for(j= sx; j <= ex; j++){
			*obj++= *src++;
		}
	}
}

void	Delay200us(int cnt)
{
	volatile	int		j;
	int	i;

	for(i= 0; i < cnt; i++){
		j= 10;
		j= j*5;
	}
}
void	SetContrast(int data)
{

}
/************************************************/
/*	Hardware TEST Program						*/
/************************************************/

int	CheckSRAM(void)
{

	return(0);
}
int	ErrorCnt;
int	CheckSRAMC000000(void)
{

	return(0);
}
int	CheckFLASH(void)
{
	return(0);
}
char	KeyTochDataWork[8+2];
void	WaitTimeMs( int cnt )
{
#ifdef	WIN32
	return;
#endif
	TimerStart( 0, cnt );		/* Wait ms */
	while(time_flag[0] == 0){
		;
	}
}
void	NormBuzzer(void)
{
	BuzOn();
	WaitTimeMs(30);		/* Wait 100ms */
	BuzOff();
}



void	ClearDisplay(void)
{
	ClearDispBuff();
}


void	BackLightOnOff(int mode)
{
#ifndef	WIN32
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;
	if(mode == OFF){
		//Tout2��??�g�ɂ���
		pIOPReg->rGPBCON= pIOPReg->rGPBCON & ~(3 << 4) | (1 << 4);
		pIOPReg->rGPBDAT |= IO_BACK_LIGHT;
	}else{
		//Tout2��PWM�ɂ���
		pIOPReg->rGPBCON= pIOPReg->rGPBCON & ~(3 << 4) | (2 << 4);
	}
#endif
}
void	LCDAllSet(int mode)
{

}
int	InputOkNG(int mode)
{

	return(0);
}



int	Rs232CTest(int mode)
{

	return(0);

}

/****************************************************
*   FUNC  : AD Read                                 *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
****************************************************/
int	IsTestMode(void)
{
	return(0);
}

int	IsTestModeValue(void)
{
	return(0);
}

/********************************************************************/
/*                                                                  */
/*      �u�U?�̃h���C�o?                                          */
/*                                                                  */
/********************************************************************/
void    BuzOn(void)
{
#ifndef	WIN32
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;

	//Tout3��PWM�ɂ���
	pIOPReg->rGPBCON= pIOPReg->rGPBCON & ~(3 << 6) | (2 << 6);
#endif
}

void    BuzOff(void)
{
#ifndef	WIN32
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;

	//Tout3��??�g�ɂ���
	pIOPReg->rGPBCON= pIOPReg->rGPBCON & ~(3 << 6) | (1 << 6);
	pIOPReg->rGPBDAT &= ~IO_BUZZER;
#endif
}

int	RunSWRead( void )
{
#ifdef	WIN32
	extern	int	RunStop;
	if(RunStop == 0){
		return(0x00);
	}else{
		return(0x02);
	}
#else
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;
	return(pIOPReg->rGPGDAT & IO_RUN_SWITCH);
#endif
}

void	RtcInitWrite(unsigned char rtc_buf[])
{
	volatile RTC_REG	*pRtcReg= (RTC_REG*)RTC_BASE;

	pRtcReg->rRTCCON |= (1<<0);

	pRtcReg->rBCDYEAR= 0x00;
	pRtcReg->rBCDMON= 0x01;
	pRtcReg->rBCDDAY= 0x01;
	pRtcReg->rBCDDATE= 0x01;
	pRtcReg->rBCDHOUR= 0x00;
	pRtcReg->rBCDMIN= 0x00;
	pRtcReg->rBCDSEC= 0x00;

	pRtcReg->rRTCCON &= ~(1<<0);
	rtc_buf[6]= 0x00;
	rtc_buf[5]= 0x01;
	rtc_buf[4]= 0x01;
	rtc_buf[3]= 0x00;
	rtc_buf[2]= 0x00;
	rtc_buf[1]= 0x00;
	rtc_buf[0]= 0x00;
}
int	CheckRtc(unsigned char *rtc_buf)
{
	int	ret= OK;
	int	wyear;
	int	wmon;
	int	wday;
	int	wweek;
	int	whour;
	int	wmin;
	int	wsec;

	wyear = ((rtc_buf[6] & 0xf0) >> 4) * 10 + (rtc_buf[6] & 0x0f);
	if(wyear > 99){
		ret= NG;
	}
	wmon = ((rtc_buf[5] & 0x30) >> 4) * 10 + (rtc_buf[5] & 0x0f);
	if((wmon < 1) || (wmon > 12)){
		ret= NG;
	}
	wday = ((rtc_buf[4] & 0x70) >> 4) * 10 + (rtc_buf[4] & 0x0f);
	if((wday < 1) || (wday > 31)){
		ret= NG;
	}
	wweek = rtc_buf[3] & 0x7f;
	if((wweek < 0) || (wweek > 6)){
		ret= NG;
	}
	whour = ((rtc_buf[2] & 0x30) >> 4) * 10 + (rtc_buf[2] & 0x0f);
	if((whour < 0) || (whour > 23)){
		ret= NG;
	}
	wmin = ((rtc_buf[1] & 0x70) >> 4) * 10 + (rtc_buf[1] & 0x0f);
	if((wmin < 0) || (wmin > 59)){
		ret= NG;
	}
	wsec = ((rtc_buf[0] & 0x70) >> 4) * 10 + (rtc_buf[0] & 0x0f);
	if((wsec < 0) || (wsec > 59)){
		ret= NG;
	}
	return(ret);
}
void	RtcInit(void)
{
	volatile RTC_REG	*pRtcReg= (RTC_REG*)RTC_BASE;
	volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE;

	pRtcReg->rTICINT=0xbf;		//�T�O�O���b?�b�N�ݒ�  

	//Intrrupt Enable
    pINTRegs->rSRCPND     = BIT_TICK;
    // S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
    if (pINTRegs->rINTPND & BIT_TICK)
        pINTRegs->rINTPND = BIT_TICK;

    pINTRegs->rINTMSK    &= ~BIT_TICK;
}
void	SetSysTime( unsigned char *rtc_buf)
{
	SystemTime.year = ((rtc_buf[6] & 0xf0) >> 4) * 10 + (rtc_buf[6] & 0x0f);
	SystemTime.mon = ((rtc_buf[5] & 0x30) >> 4) * 10 + (rtc_buf[5] & 0x0f);
	SystemTime.day = ((rtc_buf[4] & 0x70) >> 4) * 10 + (rtc_buf[4] & 0x0f);
	SystemTime.week = rtc_buf[3];
	SystemTime.hour = ((rtc_buf[2] & 0x30) >> 4) * 10 + (rtc_buf[2] & 0x0f);
	SystemTime.min = ((rtc_buf[1] & 0x70) >> 4) * 10 + (rtc_buf[1] & 0x0f);
	SystemTime.sec = ((rtc_buf[0] & 0x70) >> 4) * 10 + (rtc_buf[0] & 0x0f);

}
void	RTCWrite(unsigned char rtc_buf[],int rReset)
{
	RTC_REG	*pRtcReg= (RTC_REG*)RTC_BASE;

	pRtcReg->rRTCCON|=(1<<0);

	pRtcReg->rBCDYEAR= rtc_buf[6];
	pRtcReg->rBCDMON= rtc_buf[5];
	pRtcReg->rBCDDATE= rtc_buf[4];
	pRtcReg->rBCDDAY= rtc_buf[3]+ 1;
	pRtcReg->rBCDHOUR= rtc_buf[2];
	pRtcReg->rBCDMIN= rtc_buf[1];
	pRtcReg->rBCDSEC= rtc_buf[0];

	if(rReset == 1){		//30sReset
		pRtcReg->rRTCRST= 0x0b;		//1011
	}

	pRtcReg->rRTCCON&=~(1<<0);

} // end of Rtc_Set(...)

int	RTCRead(unsigned char *rtc_buf)
{
	RTC_REG	*pRtcReg= (RTC_REG*)RTC_BASE;

	rtc_buf[6]= pRtcReg->rBCDYEAR;
	rtc_buf[5]= pRtcReg->rBCDMON;
	rtc_buf[4]= pRtcReg->rBCDDATE;
	rtc_buf[3]= pRtcReg->rBCDDAY- 1;
	rtc_buf[2]= pRtcReg->rBCDHOUR;
	rtc_buf[1]= pRtcReg->rBCDMIN;
	rtc_buf[0]= pRtcReg->rBCDSEC;
	return(0);
}
int	_RtcInterruptProc(void)
{
	unsigned char	rtc_buf[10];
	volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

    // Clear the interrupt
    pINTRegs->rSRCPND = 1 << INTSRC_TICK;
    pINTRegs->rINTPND = 1 << INTSRC_TICK;
	RTCRead(rtc_buf);
	SetSysTime(rtc_buf);
	return(0);
}
void _RtcTikHandler(void)
{
	volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_TICK;
	_RtcInterruptProc();
	pINTRegs->rINTMSK &= ~BIT_TICK;
} // Rtc_Isr(...)
void	Rs422Enable(int mode)
{
}
int		iLeapYear(int year)
{
	
	if((year % 4) == 0) {				
		if((year % 100) != 0) {				
			return 29;
		}
		else {
			if((year % 400) == 0) {		
				return 29;
			}
			else {
				return 28;				
			}
		}
	}
	else {
		return 28;
	}
}
int	GetMaxDay(int year,int mon)
{
	int	iMax;
	switch(mon)
	{
		case 1:	case 3:	case 5:	case 7:
		case 8:	case 10: case 12:
			iMax = 31;
			break;
		case 4:	case 6:	case 9:	case 11:
			iMax = 30;
			break;
		case 2:
			iMax = iLeapYear(year);
			break;
	}
	return(iMax);
}
int DataChecking(RTC_DATA *SetData)
{
	int iMax;
	int iVal;
	iVal = 0;
	switch(SetData->mon)
	{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			iMax = 31;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			iMax = 30;
			break;
		case 2:
			iMax = iLeapYear(SetData->year);
			break;
	}
	if(SetData->day <= iMax)
		iVal = 1;
	return iVal;
}
int	CheckDateTime(int type,RTC_DATA *SetData)
{
	//Year
	//mon
	if((SetData->mon < 1) || (SetData->mon > 12)){	return(NG);	}
	//day
	if(DataChecking(SetData) == FALSE){				return(NG);	}
	//Hour
	if((SetData->hour < 0) || (SetData->hour > 23)){	return(NG);	}
	//min
	if((SetData->min < 0) || (SetData->min > 59)){	return(NG);	}
	//sec
	if((SetData->sec < 0) || (SetData->sec > 59)){	return(NG);	}
	if(type == 0){
		//week
		if((SetData->week < 0) || (SetData->week > 6)){	return(NG);	}
	}
	return(OK);
}
int		iNowWeek(RTC_DATA *STime)
{
	int iWeek;
	int Datatotal;
	int i;

	if(STime->year!=0)
		Datatotal = (STime->year*365)+(STime->year/4)+1;
	else
		Datatotal = 1;
	if(STime->year%4 == 0 && STime->mon < 3)
		Datatotal--;
	for(i=1;i<STime->mon;i++)
	{
		if(i==1 || i==3 || i==5 || i==7|| i==8 || i==10 || i==12){
			Datatotal+=31;
		}
		else if(i==4 || i==6 || i==9 || i==11){
			Datatotal+=30;
		}
		else if(i==2){
			Datatotal+=28;			
		}

	}
	Datatotal += STime->day; 
	Datatotal += 5;
	iWeek = Datatotal % 7;

	return iWeek;
}


void	Buzzer(int mode)
{
#ifdef	WIN32
/*
	int	err,run;
	extern	void	SetLedOnOff(int err,int run);
	if(mode == ON){
		err= 1;
		run= 0;
	}else{
		err= 1;
		run= 1;
	}
	SetLedOnOff(err,run);
	*/
	return;
#endif
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;

	if(mode == ON){
		//Tout3��PWM�ɂ���
		pIOPReg->rGPBCON= pIOPReg->rGPBCON & ~(3 << 6) | (2 << 6);
	}else{
		//Tout3��??�g�ɂ���
		pIOPReg->rGPBCON= pIOPReg->rGPBCON & ~(3 << 6) | (1 << 6);
		pIOPReg->rGPBDAT &= ~IO_BUZZER;
	}
}


/*
void	Buzzer_t(int mode)
{
#ifdef	WIN32
	int	err,run;
	extern	void	SetLedOnOff(int err,int run);
	if(mode == ON){
		err= 1;
		run= 0;
	}else{
		err= 1;
		run= 1;
	}
	SetLedOnOff(err,run);
	return;
#endif
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;

	if(mode == ON){
		pIOPReg->rGPADAT |= IO_BUZZER;
	}else{
		pIOPReg->rGPADAT |= ~IO_BUZZER;
	}
}
*/
void	DebugLed(int mode)
{
#ifdef	WIN32
	int	err,run;
	extern	void	SetLedOnOff(int err,int run);
	if(mode == ON){
		err= 0;
		run= 0;
	}else{
		err= 1;
		run= 1;
	}
	SetLedOnOff(err,run);
	return;
#endif
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;

	if(mode == ON){
		pIOPReg->rGPADAT &= ~IO_LED_ERROR;
		pIOPReg->rGPADAT &= ~IO_LED_RUN;
	}else{
		pIOPReg->rGPADAT |= IO_LED_RUN | IO_LED_ERROR;
	}
}

void	RunLed(int mode)
{
#ifdef	WIN32
	int	err,run;
	extern	void	SetLedOnOff(int err,int run);
	if(mode == ON){
		err= 1;
		run= 0;
	}else{
		err= 1;
		run= 1;
	}
	SetLedOnOff(err,run);
	return;
#endif
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;

	if(mode == ON){
		pIOPReg->rGPADAT |= IO_LED_ERROR;
		pIOPReg->rGPADAT &= ~IO_LED_RUN;
	}else{
		pIOPReg->rGPADAT |= IO_LED_RUN | IO_LED_ERROR;
	}
}
void	ErrorLed(int mode)
{
#ifdef	WIN32
	int	err,run;
	extern	void	SetLedOnOff(int err,int run);
	if(mode == ON){
		err= 0;
		run= 1;
	}else{
		err= 1;
		run= 1;
	}
	SetLedOnOff(err,run);
	return;
#endif
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;

	if(mode == ON){
		pIOPReg->rGPADAT |= IO_LED_RUN;
		pIOPReg->rGPADAT &= ~IO_LED_ERROR;
	}else{
		pIOPReg->rGPADAT |= IO_LED_RUN | IO_LED_ERROR;
	}
}

//20080814
void	LCDDisplayEnable(int mode)
{
}


void	PaintAngle(int sx,int sy,int ex,int ey)
{
	int	i;
	for(i= sy; i <= ey; i++){
		LineOutNoDraw(sx,i,ex,i);
	}
}


const int iRectSize = 30;
void 	DispCheckPatarn2(volatile unsigned char* pcValue, int iSize, int iStartX, int iStartY)
{
	int i, j;
	volatile unsigned char *pcIOValue;
	
	pcIOValue = pcValue;		
	
	for(i=0; i < iSize; i++)
	{
		for(j=0; j < 8; j++)		
		{
			RectAngle(iStartX+iRectSize*(i*8+j),iStartY,iStartX+iRectSize*(i*8+j+1),iStartY+iRectSize,T_WHITE,T_BLACK);	
			
			if((*pcIOValue >> j ) & 0x01)
				PaintAngle(iStartX+iRectSize*(i*8+j),iStartY,iStartX+iRectSize*(i*8+j+1), iStartY+iRectSize);
			else
				//RectAngle(iStartX+iRectSize*(i*8+j),iStartY,iStartX+iRectSize*(i*8+j+1),iStartY+iRectSize, T_WHITE ,T_BLACK);
				EraseArea(iStartX+iRectSize*(i*8+j),iStartY,iStartX+iRectSize*(i*8+j+1),iStartY+iRectSize);
			
			
		}
		pcIOValue++;					
			
	}
	
	
}


void	DispCheckPatarn(int mode)
{
	int i,j;
	int		Colum,Row,Width,Hight,x_width,y_width;

//	ClearDisplay();
//	TextOut(0,1," Input/Output  Test");


#ifdef	GLP_2480
	Colum= 15;
	Row= 4;
#endif
#ifdef	GP_S044
	Colum= 15;
	Row= 4;
#endif
#ifdef	GP_3224
	Colum= 16;
	Row= 12;
#endif
	Width= LCD_X_SIZE;
	Hight= LCD_Y_SIZE;

	x_width= Width/Colum;
	y_width= Hight/Row;
	for(i= 0; i < 2; i++){
		for(j= 0; j < 8; j++){		
			RectAngle(j*x_width+x_width*7,i*y_width+y_width*2,
				(j+1)*x_width+x_width*7- 1,(i+1)*y_width+y_width*2- 1,T_WHITE,T_BLACK);				
			
			if(mode == 0){
				if((j % 2)==0){
					PaintAngle(j*x_width+x_width*7,i*y_width+y_width*2,
					(j+1)*x_width+x_width*7- 1,(i+1)*y_width+y_width*2- 1);
				}
			}else{
				if((j % 2)!=0){
					PaintAngle(j*x_width+x_width*7,i*y_width+y_width*2,
					(j+1)*x_width+x_width*7- 1,(i+1)*y_width+y_width*2- 1);
				}
			}			
			
		}
		
	}
	DrawLcd((char *)LcdBuff);

	WaitTimeMs(1000);
}
/****************************************/ 
/* Timer Proc                     */
/****************************************/
void	Waitms(int no)
{
	TimerStart(0,no);
	while(1){
		if(time_flag[0] == 1){
			break;
		}
	}
}

/****************************************/ 
/* Timer Interruput                     */
/****************************************/
void	TimerInit( void )
{
	int		i;
	
	for(i = 0; i < 8; i++){
		time_flag[i] = 0;
		time_data[i] = 0;
	}
}   
void	TimerStart(int no,int cnt)
{
	time_flag[no] = 0;
	time_data[no] = cnt;
}
void	TimerStop(int no)
{
	time_flag[no] = 0;
	time_data[no] = 0;
}
void	TimerProc( void )
{
#ifdef	WIN32
	int	i;

	for(i = 0; i < 8; i++){
		if(time_data[i] != 0){
			time_data[i]-= 100;
			if(time_data[i] <= 0){
				time_data[i]= 0;
				time_flag[i] = 1;
			}
		}
	}
#else
	int		i;

    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
//    pINTRegs->rSRCPND = 1 << INTSRC_TIMER4;
//    pINTRegs->rINTPND = 1 << INTSRC_TIMER4;

	pINTRegs->rINTMSK |= BIT_WDT;
    pINTRegs->rSRCPND = (unsigned int)BIT_WDT;
    pINTRegs->rINTPND = (unsigned int)BIT_WDT;
	pINTRegs->rSUBSRCPND= BIT_SUB_WDT;

	for(i = 0; i < 8; i++){
		if(time_data[i] != 0){
			time_data[i]--;
			if(time_data[i] == 0){
				time_flag[i] = 1;
			}
		}
	}
	//Touch Scan Check
	timLoopCnt++;
	if(timLoopCnt >= TOUCH_SCAN_TIME){		//for 200ms
		timLoopCnt= 0;
		TouchTimerCheck();
		if(BatteryAdStart == 1){
			timBatteryCnt++;
			if(timBatteryCnt >= 5){		//for 500ms
				timBatteryCnt= 0;
				BatteryAdOk= GetAD_Power(&BatteryADValue);
			}
		}
	}
	pINTRegs->rINTMSK &= ~BIT_WDT;
#endif
}
/****************************************************
*   FUNC  : Rts ON/OFF                              *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
void	RtsOn(void)
{
	Sio2RtsOn();
}
void	RtsOff(void)
{
	Sio2RtsOff();	 
}
void	Rts0On(void)
{
}
void	Rts0Off(void)
{                    
}
/*----------------------------------------------------------------------*/
/*	�֐���	: _IoInterruptProc()										*/
/*	??	: �h?�n�C��??���v�g�����B								*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: ���荞�݋��h?�n->OK,else->NG							*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
unsigned int IoInterruptData;
void	_IoInterruptProc(void)
{
	volatile unsigned char *PortAddr;
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rSRCPND  = BIT_EINT0;
	pINTRegs->rINTPND  = BIT_EINT0;
	//Bit Check
	PortAddr= (volatile unsigned char *)(IO_START_ADDR+ FPG_PC_REG00);
	IoInterruptData= *PortAddr++;
	IoInterruptData+= *PortAddr++ << 8;
}

void _IoInterruptHandler(void)
{
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE;

	pINTRegs->rINTMSK |= BIT_EINT0;
	_IoInterruptProc();
	pINTRegs->rINTMSK &= ~BIT_EINT0;
}
