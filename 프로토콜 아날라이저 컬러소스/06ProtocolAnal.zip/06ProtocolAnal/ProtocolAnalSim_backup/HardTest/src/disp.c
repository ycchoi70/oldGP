/*************************************************
    FUNC  : Display Program
    Create: 2002.4.28	M.Owash
**************************************************/
#define	DISP_PROC
#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<math.h>

#include	"define.h"
#include	"glplcd.h"
#include	"CommBuff.h"
#include	"bios.h"
#include	"disp.h"





/****************************************************/
/*													*/
/****************************************************/
COLOR_DT	GetColorData(int idx)
{
	COLOR_DT color;

//	if(idx > 255){	idx= 255;	}
//	if(idx < 0){	idx= 0;		}
	color.r= (idx & 0x00ff0000) >> 16;
	color.g= (idx & 0x0000ff00) >> 8;
	color.b= (idx & 0x000000ff);
	color.d= 0;
	return(color);
}
void    XInc( void )
{
    pGraphicMemory++;
}

void    XDec( void )
{
    pGraphicMemory--;
}
void    YInc( void ){	pGraphicMemory += LCD_X_SIZE;	}
void    YDec( void ){	pGraphicMemory -= LCD_X_SIZE;	}
void	__MoveTo( int sx, int sy )
{
    LastPos.x= (short)sx;
    LastPos.y= (short)sy;
	if( LastPos.x <    0 ){	LastPos.x= 0;	}
	if( LastPos.x >= LCD_X_SIZE ){	LastPos.x= LCD_X_SIZE- 1;	}
	if( LastPos.y <    0 ){	LastPos.y= 0;	}
	if( LastPos.y >= LCD_Y_SIZE ){	LastPos.y= LCD_Y_SIZE- 1;	}
    pGraphicMemory= &LcdBuff->lbuff[LastPos.y][LastPos.x];
	*pGraphicMemory= ForGrandColor;
}
void    DrawHorizontal( int sx, int ex, int y )
{
	for( ;sx <= ex; sx++ ) {
		*pGraphicMemory++ = ForGrandColor;
	}

}

void    DrawFnc( int DMst, int DSlave, void (*pMainMoveFnc)(void), void (*pSlaveMoveFnc)(void ) )
{
    int     i;
    int     Dlt;
    int     DMst2;
    int     DSlave2;

    Dlt= 0;
    DSlave2= DSlave + DSlave;
    DMst2= DMst + DMst;
    for( i= 0; i < DMst; i++ ) {
        Dlt -= DSlave2;
        if ( Dlt + DMst < 0 ) {
            (*pSlaveMoveFnc)();
            Dlt += DMst2;
        }
        (*pMainMoveFnc)();
		*pGraphicMemory= ForGrandColor;
    }
}


void	__LineTo(int ex,int ey )
{
    int     Dx;
    int     Dy;
    int     DMst;
    int     DSlave;
    void    (*pXMoveFnc)(void);
    void    (*pYMoveFnc)(void);
    void    (*pMainMoveFnc)(void);
    void    (*pSlaveMoveFnc)(void);

	if( ex <    0 ){	ex=   0;	}
	if( ex >= LCD_X_SIZE ){	ex= LCD_X_SIZE- 1;	}
	if( ey <    0 ){	ey=   0;	}
	if( ey >= LCD_Y_SIZE ){	ey= LCD_Y_SIZE- 1;	}

    Dx= ex- LastPos.x;
    Dy= ey- LastPos.y;
    if( Dy == 0 ){
        if( Dx == 0 ){ return; }
        if( Dx > 0 ){	DrawHorizontal( LastPos.x, ex, ey );	}
        else{			DrawHorizontal( ex, LastPos.x, ey );	}
    }
    else {
        pXMoveFnc= XInc;
        pYMoveFnc= YInc;
        if( Dx < 0 ){	Dx= -Dx;	pXMoveFnc= XDec;	}
        if( Dy < 0 ){	Dy= -Dy;	pYMoveFnc= YDec;	}
        if( Dx >= Dy ){
            pMainMoveFnc = pXMoveFnc;
            pSlaveMoveFnc= pYMoveFnc;
            DMst= Dx;
            DSlave= Dy;
        }
        else{
            pMainMoveFnc = pYMoveFnc;
            pSlaveMoveFnc= pXMoveFnc;
            DMst= Dy;
            DSlave= Dx;
        }
        DrawFnc( DMst, DSlave, pMainMoveFnc, pSlaveMoveFnc );
    }
    __MoveTo( ex, ey );
}

void	LineOut(int sx,int sy,int ex,int ey,int color,int bcolor)
{
	ForGrandColor= GetColorData(color);
	BackGrandColor= GetColorData(bcolor);
    __MoveTo( sx, sy );
    __LineTo( ex, ey );
	DrawLcd((char *)LcdBuff);
}

void	LineOutNoDraw(int sx,int sy,int ex,int ey)
{
/*	return;*/
    __MoveTo( sx, sy );
    __LineTo( ex, ey );
}

void RectAngle(int ssx,int ssy,int eex,int eey,int color,int bcolor)
{
	ForGrandColor= GetColorData(color);
	BackGrandColor= GetColorData(bcolor);
    __MoveTo(ssx,ssy );
	__LineTo(eex,ssy);	/* Right line 	*/
	__LineTo(eex,eey);	/* Bottom line	*/
	__MoveTo(ssx,eey);
	__LineTo(eex,eey);	/* Left line	*/
	__MoveTo(ssx,ssy);
	__LineTo(ssx,eey);	/* Top line		*/
	DrawLcd((char *)LcdBuff);
}
void RectAngleNoDraw(int ssx,int ssy,int eex,int eey,int color,int bcolor)
{
 	ForGrandColor= GetColorData(color);
	BackGrandColor= GetColorData(bcolor);
   __MoveTo(ssx,ssy );
	__LineTo(eex,ssy);	/* Right line 	*/
	__LineTo(eex,eey);	/* Bottom line	*/
	__MoveTo(ssx,eey);
	__LineTo(eex,eey);	/* Left line	*/
	__MoveTo(ssx,ssy);
	__LineTo(ssx,eey);	/* Top line		*/
}
/****************************************************
*   FUNC  : Text Out                                *
*	In    :x,y=Start Position						*
*          addr:Char String Address                 *
*          front:Char Color(0:Light,1:Dark)         *
*          back:Char Back Color(0:Light,1:Dark)     *
*          onoff:Back Color On/Off(0:Off,1:On)      *
*	Out   : 										*
*   AUTHOR : M.Owashi                                *
*   DATE  : 1996.8.28                               *
*	Update:97.04.10 kf								*
****************************************************/
int	TextX,TextY;
unsigned short	TextMode;
void	ClearDispBuff(void)
{
	memset(LcdBuff, 0, sizeof(LCD_BUF));
	DrawLcd((char *)LcdBuff);
}
void	ClearDispBuff_FF(void)
{
	memset(LcdBuff, 0xff, sizeof(LCD_BUF));
	DrawLcd((char *)LcdBuff);
}
void	TextOut1Char(COLOR_DT *LcdAddr,unsigned char code)
{
	int		i,j;
	unsigned char	*FontAddr;
	unsigned char	fchar;
	COLOR_DT		*lcdPos;
	int	andData;

	FontAddr= (unsigned char*)&font_data_jpn[code][0];
	for(i= 0; i < 16; i++){
		lcdPos= LcdAddr+ LCD_X_SIZE*i;
		fchar= *FontAddr++;
		andData= 0x80;
		for(j= 0; j < 8; j++){
			if(fchar & andData){	*lcdPos++ = ForGrandColor;	}
			else{					*lcdPos++ = BackGrandColor;	}
			andData >>= 1;
		}
	}
}
void	TextOut1Char2(COLOR_DT *LcdAddr,unsigned char code)
{
	int		i,j;
	unsigned char	*FontAddr;
	unsigned char	fchar;
	COLOR_DT		*lcdPos;
	int	andData;

	FontAddr= (unsigned char*)&font_data_jpn[code][0];
	for(i= 0; i < 16; i++){
		fchar= *FontAddr++;
		lcdPos= LcdAddr+ LCD_X_SIZE*(i*2);
		andData= 0x80;
		for(j= 0; j < 8; j++){
			if(fchar & andData){	*lcdPos++ = ForGrandColor;	*lcdPos++ = ForGrandColor;	}
			else{					*lcdPos++ = BackGrandColor;	*lcdPos++ = BackGrandColor;	}
			andData >>= 1;
		}
		lcdPos= LcdAddr+ LCD_X_SIZE*(i*2+1);
		andData= 0x80;
		for(j= 0; j < 8; j++){
			if(fchar & andData){	*lcdPos++ = ForGrandColor;	*lcdPos++ = ForGrandColor;	}
			else{					*lcdPos++ = BackGrandColor;	*lcdPos++ = BackGrandColor;	}
			andData >>= 1;
		}
	}
}
void	TextOut(int x,int y,char *addr)
{
	int		i;
	COLOR_DT *LcdAddr;

	if(x >= (LCD_X_SIZE/8)){		return;	}
	if(y >= (LCD_Y_SIZE/16)){	return;	}
	for(i= 0; ; i++){
		if(addr[i] == 0){
			break;
		}
		LcdAddr= &LcdBuff->lbuff[y*16][(x+i)*8];
		TextOut1Char(LcdAddr,(unsigned char)addr[i]);
		LcdAddr++;
	}
	DrawLcd((char *)LcdBuff);
}
void	TextOut2(int x,int y,char *addr)
{
	int		i;
	COLOR_DT *LcdAddr;

	if(x >= (LCD_X_SIZE/16)){		return;	}
	if(y >= (LCD_Y_SIZE/32)){	return;	}
	for(i= 0; ; i++){
		if(addr[i] == 0){
			break;
		}
		LcdAddr= &LcdBuff->lbuff[y*32][(x+i)*16];
		TextOut1Char2(LcdAddr,(unsigned char)addr[i]);
	}
	DrawLcd((char *)LcdBuff);
}
void	DotTextOutNoDraw(int x,int y,char *addr)
{
	int		i;
	COLOR_DT *LcdAddr;

	for(i= 0; ; i++){
		if(addr[i] == 0){
			break;
		}
		LcdAddr= &LcdBuff->lbuff[y*20][(x+i)*8];
		TextOut1Char(LcdAddr,(unsigned char)addr[i]);
		LcdAddr++;
	}
}
