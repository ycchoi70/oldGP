/************************************************/
/*	ARM LCD Contorol							*/
/*	2006.05.11									*/
/************************************************/
#include <string.h>
#include <stdarg.h>
#include "glplcd.h"

#include "define.h"
#include "bios.h"
#include "s2440.h"
#include "io_define.h"






static volatile IOP_REG    *pIOPReg = (volatile IOP_REG *)IOP_BASE;

/************************************************/
/*	LCD Initialize								*/
/************************************************/
void Lcd_Init(void)
{
    volatile LCD_REG    *pLCDReg;
//    volatile CLKPWR_REG  *pCLKPWRRegs = (volatile CLKPWR_REG*)CLKPWR_BASE;

	int		i;
	unsigned short	*faddr;
    unsigned int      FrameBuffer = (unsigned int)FRAMEBUFFER_BASE;

    pIOPReg = (volatile IOP_REG *)IOP_BASE;
    pLCDReg = (volatile LCD_REG *)LCD_BASE;


    memset( (unsigned char *)FrameBuffer, 0, LCD_X_SIZE*LCD_Y_SIZE*4);
	faddr= (unsigned short*)FrameBuffer;
	for(i= 0; i < LCD_X_SIZE*LCD_Y_SIZE; i++){
		*faddr++= 0;
	}


//	S3C2440_REG_LCDCON1 = 	LCDCON1_TFT24BPP 				|
//				  			LCDCON1_TFT 	   				|
//				  			LCDCON1_CLKVAL(LCD_CLKVAL);
 S3C2440_REG_LCDCON1 = (0<<18)| (LCD_CLKVAL<<8) | (0<<7) | (LCDCON1_TFT)  | (LCDCON1_TFT24BPP) |   0 ;
 //         LINECNT  CLKVAL    MMODE   PNRMODE    BPPMODE    ENVID
 //            |        |        |        |          |         +-------- [0]    LCD video output and the logic enable/disable.               
 //            |        |        |        |          |                            0 = Disable the video output and the LCD control signal.
 //            |        |        |        |          |                            1 = Enable the video output and the LCD control signal.
 //            |        |        |        |          +------------------ [4:1] Select the BPP (Bits Per Pixel) mode.
 //            |        |        |        |                                          0000 = 1 bpp for STN, Monochrome mode
 //            |        |        |        |           0001 = 2 bpp for STN, 4-level gray mode
 //            |        |        |        |           0010 = 4 bpp for STN, 16-level gray mode
 //            |        |        |        |           0011 = 8 bpp for STN, color mode (256 color)
 //            |        |        |        |           0100 = packed 12 bpp for STN, color mode (4096 color)
 //            |        |        |        |           0101 = unpacked 12 bpp for STN, color mode (4096 color)
 //            |        |        |        |           0110 = 16 bpp for STN, color mode (4096 color)
 //            |        |        |        |           1000 = 1 bpp for TFT
 //            |        |        |        |           1001 = 2 bpp for TFT
 //            |        |        |        |           1010 = 4 bpp for TFT
 //            |        |        |        |           1011 = 8 bpp for TFT
 //            |        |        |        |           1100 = 16 bpp for TFT
 //            |        |        |        |           1101 = 24 bpp for TFT
 //            |        |        |        +----------------------------- [6:5]  Select the display mode.
 //            |        |        |                                                   00 = 4-bit dual scan display mode (STN)  
 //            |        |        |                   01 = 4-bit single scan display mode (STN)
 //            |        |        |                   10 = 8-bit single scan display mode (STN)
 //            |        |        |                   11 = TFT LCD panel
 //            |        |        +-------------------------------------- [7]   Determine the toggle rate of the VM.       
 //            |        |                           0 = Each Frame 1 = The rate defined by the MVAL
 //            |        +----------------------------------------------- [17:8]  Determine the rates of VCLK and CLKVAL[9:0].                                       
 //            |                                       STN: VCLK = HCLK / (CLKVAL x 2) ( CLKVAL ��2 )
 //            |                                    TFT: VCLK = HCLK / [(CLKVAL+1) x 2] ( CLKVAL �� 0 )   
 //            +-------------------------------------------------------- [27:18] Provide the status of the line counter.
 //                     Down count from LINEVAL to 0(Read only)
//	S3C2440_REG_LCDCON2 = 	LCDCON2_VBPD(LCD_VBACKPORCH)  |
//				  			LCDCON2_LINEVAL(LCD_YRES-1)   |
//				  			LCDCON2_VFPD(LCD_VFRONTPORCH) |
//				  			LCDCON2_VSPW(LCD_VSYNCWIDTH);
 S3C2440_REG_LCDCON2=  (LCD_VBACKPORCH<<24) | ((LCD_YRES-1)<<14) | (LCD_VFRONTPORCH<<6)  |   LCD_VSYNCWIDTH ;
 //           VBPD       LINEVAL       VFPD      VSPW 
 //            |            |           |          +--------------- [5:0] TFT: Vertical sync pulse width determines the VSYNC pulse's high level
 //            |            |           |                                  width by counting the number of inactive lines.
 //            |            |           |                 STN: These bits should be set to zero on STN LCD. 
 //            |            |           +-------------------------- [13:6] TFT: Vertical front porch is the number of inactive lines 
 //            |            |                                                 at the end of a frame, before vertical synchronization period.       
 //            |            |                           STN: These bits should be set to zero on STN LCD.
 //            |            +-------------------------------------- [23:14]  TFT/STN: These bits determine the vertical size of LCD panel                  
 //            +--------------------------------------------------- [31:24] TFT: Vertical back porch is the number of inactive lines 
 //                    at the start of a frame, after vertical synchronization period.                             
 //                                                  STN: These bits should be set to zero on STN LCD.

//	S3C2440_REG_LCDCON3 = 	LCDCON3_HBPD(LCD_HBACKPORCH)  |
//				  			LCDCON3_HOZVAL(LCD_XRES-1)    |
//				  			LCDCON3_HFPD(LCD_HFRONTPORCH);
 S3C2440_REG_LCDCON3= ( LCD_HBACKPORCH<<19 )  | ((LCD_XRES-1)<<8 ) |   LCD_HFRONTPORCH  ; 
 //        HBPD (TFT)                 HFPD (TFT)
 //        WDLY (STN)     HOZVAL      LINEBLANK(STN)
 //            |             |             +---------------------- [7:0] TFT: Horizontal front porch is the number of VCLK periods between
 //            |             |             the end of active data and the rising edge of HSYNC.
 //            |             |           STN: These bits indicate the blank time in one horizontal line
 //            |             |            duration time. These bits adjust the rate of the VLINE finely.
 //            |             |            The unit of LINEBLANK is HCLK x 8.
 //            |             |             Ex) If the value of LINEBLANK is 10, the blank time is inserted to
 //            |             |             VCLK during 80 HCLK.
 //            |             +------------------------------------ [18:8] TFT/STN: These bits determine the horizontal size of LCD panel.
 //            |                                                           HOZVAL has to be determined to meet the condition that total bytes
 //            |                                                           of 1 line are 4n bytes. If the x size of LCD is 120 dot in mono mode,
 //            |                                                           x=120 cannot be supported because 1 line consists of 15 bytes.
 //            |                                                           Instead, x=128 in mono mode can be supported because 1 line is
 //            |                                                           composed of 16 bytes (2n). LCD panel driver will discard the
 //            |                                                           additional 8 dot.
 //            +-------------------------------------------------- [25:19] TFT: Horizontal back porch is the number of VCLK periods between
 //                                                                          the falling edge of HSYNC and the start of active data.          
 //                                                                        STN: WDLY[1:0] bits determine the delay between VLINE and VCLK
 //                                                                          by counting the number of the HCLK. WDLY[7:2] are reserved.
 //                                                                          00 = 16 HCLK, 01 = 32 HCLK, 10 = 48 HCLK, 11 = 64 HCLK

//	S3C2440_REG_LCDCON4 = 	LCDCON4_HSPW(LCD_HSYNCWIDTH)  |
//				  			LCDCON4_MVAL(0);
 S3C2440_REG_LCDCON4=   (LCD_HSYNCWIDTH<<8) |     42;
 //                      HSPW(TFT)
 //           MVAL       WLH(STN)
 //            |             +----------------- [7:0]  TFT: Horizontal sync pulse width determines the HSYNC pulse's
 //            |                                        high level width by counting the number of the VCLK.
 //            |                                       STN: WLH[1:0] bits determine the VLINE pulse's high level width by
 //            |                                        counting the number of the HCLK.
 //            |                                       WLH[7:2] are reserved.
 //            |                                        00 = 16 HCLK, 01 = 32 HCLK, 10 = 48 HCLK, 11 = 64 HCLK
 //            +------------------------------- [15:8] STN: These bit define the rate at which the VM signal will toggle if
 //                                                    the MMODE bit is set to logic '1'.
 //

//	S3C2440_REG_LCDCON5 = 	LCDCON5_FRM565    				|
//				  			LCDCON5_INVVLINE				|
//				  			LCDCON5_INVVFRAME				|	
//							LCDCON5_PWREN					|
//				  			LCDCON5_HWSWP;

 //BPP24BL=0 DRGB,BPP24BL=1 EGBD
 S3C2440_REG_LCDCON5=          (0<<12) | ( 0<<11) | (0<<10)  | (1<<9)   |  (1<<8)   | (0<<7) | (0<<6) | (0<<5)  |  (0<<4) | (0<<3) | (0<<2) | (0<<1) | 0;
 //          VSTATUS  HSTATUS  BPP24BL    FRM565    INVVCLK    INVVLINE   INVVFRAME   INVVD   INVVDEN  INVPWREN   INVLEND   PWREN    ENLEND   BSWP    HWSWP
 /*
  Reserved [31:17] This bit is reserved and the value should be ��0��
  VSTATUS [16:15] TFT: Vertical Status (read only).
   00 = VSYNC 01 = BACK Porch
   10 = ACTIVE 11 = FRONT Porch
  HSTATUS [14:13] TFT: Horizontal Status (read only).
   00 = HSYNC 01 = BACK Porch
   10 = ACTIVE 11 = FRONT Porch
  BPP24BL [12] TFT: This bit determines the order of 24 bpp video memory.
   0 = LSB valid 1 = MSB Valid
  FRM565 [11] TFT: This bit selects the format of 16 bpp output video data.
   0 = 5:5:5:1 Format 1 = 5:6:5 Format
  INVVCLK [10] STN/TFT: This bit controls the polarity of the VCLK active edge.
   0 = The video data is fetched at VCLK falling edge
   1 = The video data is fetched at VCLK rising edge
  INVVLINE [9] STN/TFT: This bit indicates the VLINE/HSYNC pulse polarity.
   0 = Normal 1 = Inverted
  INVVFRAME [8] STN/TFT: This bit indicates the VFRAME/VSYNC pulse polarity.
   0 = Normal 1 = Inverted
  INVVD [7] STN/TFT: This bit indicates the VD (video data) pulse polarity.
   0 = Normal 1 = VD is inverted.
  INVVDEN [6] TFT: This bit indicates the VDEN signal polarity.
   0 = normal 1 = inverted
  INVPWREN [5] STN/TFT: This bit indicates the PWREN signal polarity.
   0 = normal 1 = inverted
  INVLEND [4] TFT: This bit indicates the LEND signal polarity.
   0 = normal 1 = inverted
  PWREN [3] STN/TFT: LCD_PWREN output signal enable/disable.
   0 = Disable PWREN signal 1 = Enable PWREN signal
  ENLEND [2] TFT: LEND output signal enable/disable.
   0 = Disable LEND signal 1 = Enable LEND signal
  BSWP [1] STN/TFT: Byte swap control bit.
   0 = Swap Disable 1 = Swap Enable
  HWSWP [0] STN/TFT: Half-Word swap control bit.
   0 = Swap Disable 1 = Swap Enable

 */

	S3C2440_REG_LPCSEL	= 	LPCSEL_VALUE;

	S3C2440_REG_GPCCON = 0xAAAA56A9;
	S3C2440_REG_GPCUP  = 0x0000FFFF;
	S3C2440_REG_GPDCON = 0xAAAAAAAA;
	S3C2440_REG_GPDUP  = 0x0000FFFF;

#define M5D(n) ((n) & 0x1fffff) // To get lower 21bits
#define M21D(n) ((n) & 0x1fffff) // To get lower 21bits
#define M9D(n) ((n) & 0x1ff) // To get lower 9bits
//	S3C2440_REG_LCDSADDR1 = (FRAMEBUFFER_BASE) >> 1;
 S3C2440_REG_LCDSADDR1 =  (M9D(FRAMEBUFFER_BASE >> 22)<<21) |   (M21D(FRAMEBUFFER_BASE >> 1) ) ;
 //                  LCDBANK                             LCDBASEU
 //                     |                                  +------------ [20:0] For dual-scan LCD : These bits indicate A[21:1] of the start address
 //                     |                                                           of the upper address counter, which is for the upper frame memory
 //                     |                                                           of dual scan LCD or the frame memory of single scan LCD.
 //                     |                                                       For single-scan LCD : These bits indicate A[21:1] of the start
 //                     |                                                           address of the LCD frame buffer.
 //                     +----------------------------------------------- [29:21] These bits indicate A[30:22] of the bank location for the video buffer
 //                                                                                 in the system memory. LCDBANK value cannot be changed even
 //                                                                                 when moving the view port. LCD frame buffer should be within
 //                                                                                 aligned 4MB region, which ensures that LCDBANK value will not be
 //                                                                                 changed when moving the view port. So, care should be taken to use
 //                                                                                 the malloc() function.                                  
 //  
//	S3C2440_REG_LCDSADDR2 = (FRAMEBUFFER_BASE + ((LCD_XRES * LCD_YRES * LCD_BPP )/8)) >> 1;	
 S3C2440_REG_LCDSADDR2 =  (M21D(FRAMEBUFFER_BASE >> 1) ) + (  LCD_XRES      +    0  )    * LCD_YRES*2 ;
 //                   LCDBASEL 
 //                      +--------- [20:0] For dual-scan LCD: These bits indicate A[21:1] of the start address
    //                                          of the lower address counter, which is used for the lower frame
    //                                          memory of dual scan LCD.
    //                                        For single scan LCD: These bits indicate A[21:1] of the end address
    //                                          of the LCD frame buffer.
    //                                          LCDBASEL = ((the frame end address) >>1) + 1 ;
    //                                                   = LCDBASEU + (PAGEWIDTH+OFFSIZE) x (LINEVAL+1) ;
//	S3C2440_REG_LCDSADDR3 = OFFSIZE(0) | PAGEWIDTH(LCD_XRES);
 S3C2440_REG_LCDSADDR3 =     (0)<<11 |  LCD_XRES;
 //               OFFSIZE      PAGEWIDTH
 //                  |             +------------ [10:0] Virtual screen page width (the number of half words).
 //                  |                                    This value defines the width of the view port in the frame.
 //                  +-------------------------- [21:11] Virtual screen offset size (the number of half words).
 //                                                        This value defines the difference between the address of the last half
 //                                                        word displayed on the previous LCD line and the address of the first
 //                                                        half word to be displayed in the new LCD line.                                    

    pLCDReg->rTPAL      = 0x0;
    pLCDReg->rLCDCON1  |= 1;
	pIOPReg->rGPBCON	|= ( 0x1 << 8 );	// GPG4 Output
	pIOPReg->rGPBUP		|= IO_LCD_DISPLAY;	// GPB4 Pull up
	pIOPReg->rGPBDAT	&= ~IO_LCD_DISPLAY;	// GPB4 Hight

}
void Rtc_Set(char hour, char min, char sec)
{

} // end of Rtc_Set(...)
/****************************************************************************************************/
