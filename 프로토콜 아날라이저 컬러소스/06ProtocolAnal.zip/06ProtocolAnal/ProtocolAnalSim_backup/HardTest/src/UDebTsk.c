
#define	UDEBTSK_PROC

#include	<stdio.h>
#include	<string.h>
#include	<ctype.h>

#include	"define.h"

#include	"glplcd.h"
#include	"CommBuff.h"
#include	"selib.h"
#include	"bios.h"
#include	"rs232c.h"
//#include	"motloader.h"
#include	"udebtsk.h"
#include	"lload.h"
#include	"usbh.h"
//#include	"doscomm.h"
//#include	"pcmcia.h"
#include	"nand.h"
//#include	"glpdos.h"
#include	"disp.h"
#include	"touch.h"
#include	"flash.h"
#include	"udc_2440.h"

#include	"hardtest.h"
//#include	"pcmcia.h"
//#include	"mmcdrv.h"

//extern	int	W5300Test(void);


/* For Lib */
int	isHexdigit(unsigned char data)
{
	int	ret;

	ret= 0;
	if(      '0' <= data && data <= '9' ){	ret= 1;	}
	else if( 'A' <= data && data <= 'F' ){	ret= 1;	}
	else if( 'a' <= data && data <= 'f' ){	ret= 1;	}
	return(ret);
}
unsigned int atolx( unsigned long *data, unsigned char *ptr )
{
	unsigned int dat= 0;
	unsigned char *org= ptr;
	unsigned char	getData;

	*data= 0;
	getData= *ptr;
	while( isHexdigit( getData ) != 0 ){
		if(      '0' <= getData && getData <= '9' ){	dat= getData- '0';	}
		else if( 'A' <= getData && getData <= 'F' ){	dat= getData- 'A'+ 10;	}
		else if( 'a' <= getData && getData <= 'f' ){	dat= getData- 'a'+ 10;	}
		*data= *data* 16+ dat;
		ptr++;
		getData= *ptr;
	}
	return( ptr == org ? FALSE : TRUE );
}

/* For Lib */
unsigned int IsSpeace( unsigned char ch )
{
	switch( ch ){
	case ' ':	return( TRUE );
	case '\0':	return( TRUE );
	case '\a':	return( TRUE );
	case '\r':	return( TRUE );
	case '\n':	return( TRUE );
	case '\t':	return( TRUE );
	}
	return( FALSE );
}

/* For Lib */
unsigned char *SkipNextWord( unsigned char *ptr )
{
	unsigned char	getData;
	for( ;; ptr++ ){ 
		getData= *ptr;
		if( getData == ' '  ){		break;			}
		if( getData == '\0' ){		return( ptr );	}
		if( getData == END_CHAR ){	return( ptr );	}
	}
	ptr++;
	return( ptr );
}

/************************************************************/
/*	�P�������M												*/
/************************************************************/
#ifdef	WIN32
extern	void	SioPuts(char *buf);
#endif
void	SendString( char* ptr)
{
#ifdef	WIN32
	SioPuts(ptr);
#else
	while(1){
		if( *ptr == '\0' ){	break;		}

//		if( Sio0SendChar( *ptr ) == TRUE ){	ptr++;	}
		if( Sio1SendChar( *ptr ) == TRUE ){	ptr++;	}
//		if( Sio2SendChar( *ptr ) == TRUE ){	ptr++;	}

	}
#endif
}
/************************************************************/
/*	���b�Z?�W���M											*/
/************************************************************/
void DModeSendMsg( char *ptr )
{
#ifdef	WIN32
	SioPuts(ptr);
#else
	TimerStart( 1, 100 );		/* Wait 1Sec */
	while( time_flag[1] == 0 ){
		if( *ptr == '\0' ){	break;		}

//		if( Sio0SendChar( *ptr ) == TRUE ){	ptr++;	}
		if( Sio1SendChar( *ptr ) == TRUE ){	ptr++;	}
//		if( Sio2SendChar( *ptr ) == TRUE ){	ptr++;	}

	}
#endif
}

/************************************************************/
/*	�v�����v�g���M											*/
/************************************************************/
void DModeSendPronpt( void ){	DModeSendMsg( ">" );	}

/************************************************************/
/*	���s���M												*/
/************************************************************/
void DModeSendCR( void )
{
#ifndef	WIN32
	unsigned int i;
#endif
	unsigned char tbl[4]= { 0x0A, 0x0D, 0x00,	};
	
#ifdef	WIN32
	SioPuts((char*)tbl);
#else
	for( i= 0; tbl[i] != 0x00; i++ ){ 
//		while( Sio0SendChar( tbl[i] ) == FALSE ){	;	}
		while( Sio1SendChar( tbl[i] ) == FALSE ){	;	}
//		while( Sio2SendChar( tbl[i] ) == FALSE ){	;	}
	}
#endif
}

/************************************************************/
/*	���b�Z?�W���M�i�v�����v�g?���t���j					*/
/************************************************************/
void DModeSendOneMsg( char *ptr )
{
	DModeSendMsg( ptr );

//	DModeSendCR();
//	DModeSendPronpt();
}
/************************************************************/
/*	Welcome���b�Z?�W���M									*/
/************************************************************/
void DModeSendLoginMsg( void )
{
//	DModeSendCR();
	DModeSendOneMsg( TVS_VERSION_MES );
	DModeSendCR();
	DModeSendPronpt();
}
void DModeSendLoginMsgAs( void )
{
//	DModeSendCR();
	DModeSendOneMsg( TVS_VERSION_MES );
	DModeSendOneMsg( "\r\nFirmware A/S Mode\r\n" );
	DModeSendPronpt();
}
/************************************************************/
/*	Loaser Start ���b�Z?�W���M									*/
/************************************************************/
void DModeSendStartMsg( void )
{
	DModeSendMsg( TVS_VERSION_MES );
	DModeSendCR();
	DModeSendMsg( "1. Test Program" );
	DModeSendCR();
	DModeSendMsg( "2. System Loader Program" );
	DModeSendCR();
	DModeSendMsg( "Test Program : after 3sec" );
	DModeSendCR();
}
void LoaderStartMsg( void )
{
	DModeSendMsg( TVS_VERSION_MES );
	DModeSendCR();
}
/************************************************************/
/*	�R?���h�G��?���b�Z?�W���M							*/
/************************************************************/
void DModeSendCmdErr( unsigned char *pCmd )
{
	DModeSendOneMsg( "\r\nCOMMAND ERROR\r\n" );
	DModeSendPronpt();
}

/************************************************************/
/*	Quit���b�Z?�W���M										*/
/************************************************************/
void DModeSendQuitMsg( void )
{

	DModeSendMsg( "Bye Bye\r\n" );
	DModeFlag= 0;
}
/************************************************************/
/*	�o?�W�����ԍ����M										*/
/************************************************************/
void DModeSendVersion( void )
{
	DModeSendOneMsg( TVS_VERSION );
	DModeSendCR();
}

/************************************************************/
/*	Help���b�Z?�W���M										*/
/************************************************************/
void DModeSendHelpMsg( void )
{
	unsigned int i;
	
	for( i= 0; i < TBQ(HelpMsg); i++ ){
		DModeSendMsg( HelpMsg[i] );
		DModeSendCR();
	}
	DModeSendPronpt();
}
/************************************************************/
/*	Cam Help���b�Z?�W���M									*/
/************************************************************/
void DModeSendCamHelpMsg( void )
{
	unsigned int i;
	char *HelpMsg[]= {
		"CAM HELP      : CAM HELP.",
	};
	
	for( i= 0; i < TBQ(HelpMsg); i++ ){
		DModeSendMsg( HelpMsg[i] );
		DModeSendCR();
	}
	DModeSendPronpt();
}

/************************************************************/
/*	��������?�h�����֐�									*/
/************************************************************/
unsigned int DModeMemoryRead( unsigned char *pCmd )
{
	unsigned int ret= TRUE;
	unsigned int type;
	unsigned long adr;
	char buf[80];

	if( ret == TRUE ){				/* �R?���h */
		pCmd++;
		switch( *pCmd ){
		case ' ':	type= TYPE_WORD;	break;
		case 'B':	type= TYPE_BYTE;	break;
		case 'W':	type= TYPE_WORD;	break;
		case 'L':	type= TYPE_LONG;	break;
		default:	ret= FALSE;			break;
		}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){				/* �A�h���X */
		atolx( &adr, pCmd );
	}
	if( ret == TRUE ){				/* ���� */
		switch( type ){
		case TYPE_BYTE:
			sprintf( buf, "%08X:%02X", adr, (unsigned char )*((unsigned char  *)adr) );
			(unsigned char *)adr++;
			break;
		case TYPE_WORD:
			sprintf( buf, "%08X:%04X", adr, (unsigned short)*((unsigned short *)adr) );
			(unsigned short *)adr++;
			break;
		case TYPE_LONG:
			sprintf( buf, "%08X:%08X", adr, (unsigned long )*((unsigned long  *)adr) );
			adr++;
			break;
		}
		DModeSendMsg( buf );
	}
	if( ret != TRUE ){	/* ERROR */
		DModeSendMsg( "ERROR!" );
	}
	DModeSendCR();
	DModeSendPronpt();

	return( ret );
}

unsigned int DModeMemoryCycleRead( unsigned char *pCmd )
{
	unsigned int ret= TRUE;
	unsigned int type;
	unsigned long adr;
	volatile	unsigned char bData;
	volatile	unsigned short wData;
	volatile	unsigned long lData;
	unsigned char *badr;
	unsigned short *wadr;
	unsigned long *ladr;
	int				i;
	char buf[80];

	if( ret == TRUE ){				/* �R?���h */
		pCmd++;
		switch( *pCmd ){
		case ' ':	type= TYPE_WORD;	break;
		case 'B':	type= TYPE_BYTE;	break;
		case 'W':	type= TYPE_WORD;	break;
		case 'L':	type= TYPE_LONG;	break;
		default:	ret= FALSE;			break;
		}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){				/* �A�h���X */
		atolx( &adr, pCmd );
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){				/* ���� */
		switch( type ){
		case TYPE_BYTE:
			badr= (unsigned char *)adr;
			sprintf( buf, "%08X:%02X", adr, (unsigned char )*((unsigned char  *)adr) );
			break;
		case TYPE_WORD:
			wadr= (unsigned short *)adr;
			sprintf( buf, "%08X:%04X", adr, (unsigned short)*((unsigned short *)adr) );
			break;
		case TYPE_LONG:
			ladr= (unsigned long *)adr;
			sprintf( buf, "%08X:%08X", adr, (unsigned long )*((unsigned long  *)adr) );
			break;
		}
		DModeSendMsg( buf );
		for(i = 0; ; i++){
			switch( type ){
			case TYPE_BYTE:	bData= *badr;	break;
			case TYPE_WORD:	wData= *wadr;	break;
			case TYPE_LONG:	lData= *ladr;	break;
			}
			if(IS_CONSOL( ) != 0){
				break;
			}
		}
	}
	DModeSendCR();
	DModeSendPronpt();

	return( ret );
}

/************************************************************/
/*	���������C�g�����֐�									*/
/************************************************************/
unsigned int DModeMemoryWrite( unsigned char *pCmd )
{
	char buf[80];
	unsigned int ret= TRUE;
	unsigned int type;
	unsigned long adr, data;
	unsigned char	*bptr;
	unsigned short	*wptr;
	unsigned long	*lptr;

	if( ret == TRUE ){					/* �R?���h */
		pCmd++;
		switch( *pCmd ){
		case ' ':	type= TYPE_WORD;	break;
		case 'B':	type= TYPE_BYTE;	break;
		case 'W':	type= TYPE_WORD;	break;
		case 'L':	type= TYPE_LONG;	break;
		default:	ret= FALSE;			break;
		}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �A�h���X */
		atolx( &adr, pCmd );
		pCmd= SkipNextWord( pCmd );
	}

	if( ret == TRUE ){

		switch( type ){
		case TYPE_BYTE:
			bptr= (unsigned char *)adr;
			while( *pCmd != END_CHAR ){	/* Get Data */
				atolx( &data, pCmd );
				sprintf( buf, "%08X: %02X->%02X", bptr, *bptr, data );
										/* �ԐM�쐬 */
				DModeSendMsg( buf );	/* �ԐM���s */
				DModeSendCR();
				*((unsigned char *)bptr++)= (unsigned char)data;
				bptr++;
				pCmd= SkipNextWord( pCmd );
			}
			break;
		case TYPE_WORD:
			wptr= (unsigned short *)adr;
			while( *pCmd != END_CHAR ){	/* Get Data */
				atolx( &data, pCmd );
				sprintf( buf, "%08X: %04X->%04X", wptr, *wptr, data );
										/* �ԐM�쐬 */
				DModeSendMsg( buf );	/* �ԐM���s */
				DModeSendCR();
				*((unsigned short *)wptr++)= (unsigned short)data;
				pCmd= SkipNextWord( pCmd );
			}
			break;
		case TYPE_LONG:
			lptr= (unsigned long *)adr;
			while( *pCmd != END_CHAR ){	/* Get Data */
				atolx( &data, pCmd );
				sprintf( buf, "%08X: %08X->%08X", lptr, *lptr, data );
										/* �ԐM�쐬 */
				DModeSendMsg( buf );	/* �ԐM���s */
				DModeSendCR();
				*((unsigned long *)lptr++)= (unsigned long)data;
				pCmd= SkipNextWord( pCmd );
			}
			break;
		}
	}
	if( ret != TRUE ){
		DModeSendMsg( "ERROR!" );
		DModeSendCR();
	}
	DModeSendPronpt();
	return( ret );
}
unsigned int DModeMemoryCycleWrite( unsigned char *pCmd )
{
	char buf[80];
	unsigned int ret= TRUE;
	unsigned int type;
	unsigned long adr, data;
	unsigned char	*bptr;
	unsigned short	*wptr;
	unsigned long	*lptr;
	int				i;

	if( ret == TRUE ){					/* �R?���h */
		pCmd++;
		switch( *pCmd ){
		case ' ':	type= TYPE_WORD;	break;
		case 'B':	type= TYPE_BYTE;	break;
		case 'W':	type= TYPE_WORD;	break;
		case 'L':	type= TYPE_LONG;	break;
		default:	ret= FALSE;			break;
		}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �A�h���X */
		atolx( &adr, pCmd );
		pCmd= SkipNextWord( pCmd );
	}

	if( ret == TRUE ){

		atolx( &data, pCmd );
		switch( type ){
		case TYPE_BYTE:
			bptr= (unsigned char *)adr;
			sprintf( buf, "%08X: %02X->%02X", bptr, *bptr, data );
									/* �ԐM�쐬 */
			DModeSendMsg( buf );	/* �ԐM���s */
			DModeSendCR();
			break;
		case TYPE_WORD:
			wptr= (unsigned short *)adr;
			sprintf( buf, "%08X: %04X->%04X", wptr, *wptr, data );
									/* �ԐM�쐬 */
			DModeSendMsg( buf );	/* �ԐM���s */
			DModeSendCR();
			break;
		case TYPE_LONG:
			lptr= (unsigned long *)adr;
			sprintf( buf, "%08X: %08X->%08X", lptr, *lptr, data );
									/* �ԐM�쐬 */
			DModeSendMsg( buf );	/* �ԐM���s */
			DModeSendCR();
			break;
		}
		for(i = 0; ; i++){
			switch( type ){
			case TYPE_BYTE:	*((unsigned char *)bptr)= (unsigned char)data;		break;
			case TYPE_WORD:	*((unsigned short *)wptr)= (unsigned short)data;	break;
			case TYPE_LONG:	*((unsigned long *)lptr)= (unsigned long)data;		break;
			}
			if(IS_CONSOL( ) != 0){
				break;
			}
		}
	}
	if( ret != TRUE ){
		DModeSendMsg( "ERROR!" );
		DModeSendCR();
	}
	DModeSendPronpt();
	return( ret );
}

unsigned int DModePortOut( unsigned char *pCmd )
{
	return( 0 );
}
unsigned int PasswordWrite( unsigned char *pCmd )
{

	return( 0 );
}
/************************************************************/
/*	������?���v?��������쐬�֐�							*/
/*	����	long spos;	Start Position						*/
/*			long size;	Size								*/
/*			long cpos;	Current Position					*/
/************************************************************/
void MakeDumpStr( unsigned int type, char *pBuf, unsigned long spos,
							unsigned long size, unsigned long cpos )
{
	char	frm[16];
	unsigned int	i, max;
	unsigned char	cc;			/* ?������ */
	unsigned long	xp, pos;	/* ���ڃA�h���X,�A�h���X?�W�V����*/
	unsigned long	sadrs, eadrs, epos;

	pos= cpos;
	/* ?���J�n�A�h���X */
	sprintf( pBuf, "%08X: ", pos- (pos% 16) );
	pBuf+= 10;

	/* �f??�i�P�U�i?�L�j */
	xp= pos- (pos% 16);						/* �J�����g?�C��? */
	epos= spos+ size;						/* �I�����A�h���X */
	sadrs= spos- (spos% type);				/* ?���J�n�A�h���X */
	eadrs= epos+ (epos% type == 0 ? 0 : type- epos% type);
											/* ?���I���A�h���X */
	max= 16/ type;							/* �P�s?���ő�� */
	sprintf( frm, "%%0%dX ", type* 2 );		/* ?��?���w�� */
	for( i= 0; i < max; i++, xp+= type ){
		if( i == max/ 2 ){					/* ������?�� */
			sprintf( pBuf, " " );
			pBuf++;
		}
		if( xp < sadrs || xp >= eadrs ){	/* ?�L�Ȃ� */
			sprintf( pBuf, "         " );	/* MAX LONG */
		}
		else{								/* �f???�� */
			sprintf( pBuf, frm, 
				type == TYPE_BYTE ? (unsigned char )*(unsigned char  *)pos :
				type == TYPE_LONG ? (unsigned long )*(unsigned long  *)pos :
									(unsigned short)*(unsigned short *)pos );
			pos+= type;
		}
		pBuf+= (type* 2+ 1);
	}

	/* ��؂蕶�� */
	sprintf( pBuf, " " );
	pBuf+= 1;
	
	/* �f??�i����?�L�j */
	xp= cpos- (cpos% 16);		/* ���ڃA�h���X */
	for( i= 0; i < 16; i++, xp++ ){
		if( i == (16/ 2) ){		/* ������?�� */
			sprintf( pBuf, " " );
			pBuf++;
		}
		cc= *(unsigned char *)xp;
		if(      xp <  sadrs ){	sprintf( pBuf, " " );		}
		else if( xp >= eadrs ){	sprintf( pBuf, " " );		}
		else{
			if( cc < ' ' ){						sprintf( pBuf, "." );		}
			else if( cc < 0x7F){				sprintf( pBuf, "%c", cc );	}
			else if( 0xA0 < cc && cc < 0xE0 ){	sprintf( pBuf, "%c", cc );	}
			else{								sprintf( pBuf, "." );		}
		}
		pBuf++;
	}
}

/************************************************************/
/*	������?���v�����֐�									*/
/************************************************************/
unsigned int DModeMemoryDump( unsigned char *pCmd )
{
	char buf[80];
	unsigned int i, line, ret= TRUE;
	unsigned int type;
	unsigned long adr, sadr, end, size;

	if( ret == TRUE ){					/* �R?���h */
		if( memcmp( pCmd, "DUMP", 4 ) == 0 ){	/* Full Command */
			type= TYPE_WORD;
			pCmd= SkipNextWord( pCmd );
		}
		else{									/* Shortcut Command */
			pCmd++;			/* Skip 'D' */
			switch( *pCmd ){
			case '\0':
			case '\a':
			case '\r':
			case ' ':	type= TYPE_WORD;	break;
			case 'B':	type= TYPE_BYTE;	break;
			case 'W':	type= TYPE_WORD;	break;
			case 'L':	type= TYPE_LONG;	break;
			default:	ret= FALSE;			break;
			}
			pCmd= SkipNextWord( pCmd );
		}
	}
	if( ret == TRUE ){					/* �A�h���X */
		if( atolx( &adr, pCmd ) == FALSE ){	adr= DefaultAdress;	}	
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �T�C�Y�E�I���A�h���X */
		if( *pCmd == '\\' ){	/* �T�C�Y */
			pCmd++;
			atolx( &size, pCmd );
		}
		else{					/* �I���A�h���X */
			if( atolx( &end, pCmd ) == FALSE ){	size= 16* 8;		}	/* DEFALT */
			else if( adr < end ){				size= end- adr+ 1;	}
			else{								ret= FALSE;			}
		}
		end= adr+ size;
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){			/* ���� */
		line= (unsigned int)((end % 16 == 0 ? end : end+ 16- (end% 16) )
													/* �I���A�h���X */
							- (adr- (adr% 16))) 	/* �J�n�A�h���X */
							/ 16;					/* �ő�?���� */
		for( i= 0; i < line; i++ ){
			sadr= adr+ i* 16;		/* ?���擪�̃A�h���X�擾 */

			MakeDumpStr( type, buf, adr, size, sadr );
			DModeSendMsg( buf );
			DModeSendCR();
		}
	}
	if( ret != TRUE ){
		DModeSendMsg( "ERROR!" );
		DModeSendCR();
	}
	DefaultAdress= adr+ 16* 8;
	DModeSendPronpt();

	return( ret );
}

/************************************************************/
/*	�������t�B�������֐�									*/
/************************************************************/
unsigned int DModeMemoryFill( unsigned char *pCmd )
{
	unsigned int ret= TRUE;
	unsigned int i;
	unsigned long adr[2], len, inc, data;		/* adr[0]:�I���W�i���A�h���X */
												/* adr[1]:�o�E��?���Ή���A�h���X */

	if( ret == TRUE ){					/* �R?���h */
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �A�h���X */
		if( atolx( &adr[0], pCmd ) == FALSE ){	ret= FALSE;	}
		pCmd= SkipNextWord( pCmd );
		adr[1]= (adr[0]/ 2)* 2;
	}
	if( ret == TRUE ){					/* �T�C�Y */
		if( *pCmd == '\\' ){
			pCmd++;
			if( atolx( &len, pCmd ) == FALSE ){	ret= FALSE;	}
			pCmd= SkipNextWord( pCmd );
			len= (adr[0]+ len)- adr[1];	/* Size= End- Statrt */
			len= (len/ 2)+ (len% 2);	/* Byte ==> Word */
		}
		else{
			ret= FALSE;
		}
	}
	if( ret == TRUE ){					/* �����l */
		if( atolx( &data, pCmd ) == FALSE ){	ret= FALSE;	}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �C���N�������g�p??�� */
		if( atolx( &inc, pCmd ) == FALSE ){	ret= FALSE;	}
		pCmd= SkipNextWord( pCmd );
	}

	if( ret == TRUE ){
		for( i= 0; i < len; i++ ){
			*((unsigned short *)adr[1]+ i)= (unsigned short)data;
			data+= inc;
		}
	}
	if( ret != TRUE ){
		DModeSendMsg( "ERROR!" );
		DModeSendCR();
	}
	DModeSendPronpt();
	return( ret );
}

/************************************************************/
/*	���������f??�ݒ�i�r�t�a�r�j�����֐�					*/
/************************************************************/
unsigned int DModeMemorySubs( unsigned char *pCmd )
{
	char buf[80];
	unsigned int ret= TRUE, size= 0;
	unsigned long adr, dat;
	unsigned short *wptr;

	if( ret == TRUE ){					/* �R?���h */
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �A�h���X */
		if( atolx( &adr, pCmd ) == FALSE ){	adr= DefaultAdress;	}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �f?? */
		wptr= (unsigned short *)adr;
		/* �A���ݒ� */
		if( *pCmd == '\0' || *pCmd == '\a' || *pCmd == '\r' ){
			SubsModeFlag= TRUE;					/* Flag ON */
			DefaultAdress= adr;
			sprintf( buf, "%08X %04X", DefaultAdress,
							(unsigned short)*((unsigned short *)DefaultAdress) );
			DModeSendMsg( buf );
		}
		/* ���ڐݒ� */
		else{
			while( atolx( &dat, pCmd ) == TRUE ){
				size+= 2;
				*((unsigned short *)wptr++)= (unsigned short)dat;
				pCmd= SkipNextWord( pCmd );
			}
/*19991029 ��?��*/
/*			MakeDumpStr( TYPE_WORD, buf, adr, size, adr );*/
/*			DModeSendMsg( buf );*/
/*			DModeSendCR();*/
/**/
		}
	}
	DModeSendPronpt();

	return( ret );
}

/************************************************************/
/*	�r�t�a�r���ʏ����֐�									*/
/************************************************************/
unsigned int DModeSubsProc( unsigned char *pCmd )
{
	char buf[80];
	unsigned long dat;
	unsigned short *wptr;

	switch( *pCmd ){
	case '\0':	/* �����̓R?���h */
	case '\r':	/* �����̓R?���h */
		DefaultAdress+= (DefaultAdress% 2);	/* ������ */
		DefaultAdress+= 2;					/* ���� */
		break;
	case '^':	/* �P��R?���h */
		DefaultAdress+= (DefaultAdress% 2);	/* ������ */
		DefaultAdress-= 2;					/* ���� */
		break;
	case '.':	/* �I���R?���h */
		SubsModeFlag= FALSE;				/* Flag OFF */
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	default:	/* ���̑��̃R?���h */
		if( atolx( &dat, pCmd ) == TRUE ){
			DefaultAdress+= (DefaultAdress% 2);	/* ������ */
			wptr= (unsigned short *)DefaultAdress;
			*((unsigned short *)wptr++)= (unsigned short)dat;
			DefaultAdress+= 2;					/* ���� */
		}
		break;
	}

	DModeSendCR();
	sprintf( buf, "%08X %04X", DefaultAdress, (unsigned short)*((unsigned short *)DefaultAdress) );
	DModeSendMsg( buf );
	DModeSendPronpt();
	return( TRUE );
}

/************************************************************/
/*	�e�o�f?���C�g�����֐�									*/
/************************************************************/
unsigned int DModeFpgaWrite( unsigned char *pCmd )
{
	unsigned int ret= TRUE;
//	unsigned int type;
	unsigned long adr, data;

	if( ret == TRUE ){	/* 1st character */
		if( *pCmd != 'G' ){	ret= FALSE;	}
		else{				pCmd++;		}
	}
	if( ret == TRUE ){	/* 2nd character */
//		switch( *pCmd ){
//		case 'A':	type= 1;	break;
//		case 'B':	type= 2;	break;
//		case 'C':	type= 3;	break;
//		case 'D':	type= 4;	break;
//		default:	ret= FALSE;	break;
//		}
		pCmd+= 2;
	}
	if( ret == TRUE ){	/* Get Address */
		atolx( &adr, pCmd );
		pCmd= SkipNextWord( pCmd );
	}

	if( ret == TRUE ){
		atolx( &data, pCmd );

#ifdef INCOMPLETE
		SetFpga( type, ads, data );
#endif
	return( TRUE );
	}
	return( ret );
	
}
	struct{
		unsigned int		No;
		unsigned int		size;
		unsigned char	*cmd;
	} DmodeCmdTbl[]= {
		{	UDCMD_GO,	  2, (unsigned char	*)"GO"		},
		{	UDCMD_GO,	  1, (unsigned char	*)"G"		},
		{	UDCMD_BR,	  2, (unsigned char	*)"BR"		},
		/**	�Ǎ��݌n�R?���h	**/
		{	UDCMD_MEM_R,  2, (unsigned char	*)"RB"		},
		{	UDCMD_MEM_R,  2, (unsigned char	*)"RW"		},
		{	UDCMD_MEM_R,  2, (unsigned char	*)"RL"		},
		{	UDCMD_MEM_W,  2, (unsigned char	*)"WB"		},
		{	UDCMD_MEM_W,  2, (unsigned char	*)"WW"		},
		{	UDCMD_MEM_W,  2, (unsigned char	*)"WL"		},
		{	UDCMD_MEM_U,  2, (unsigned char	*)"UB"		},
		{	UDCMD_MEM_U,  2, (unsigned char	*)"UW"		},
		{	UDCMD_MEM_U,  2, (unsigned char	*)"UL"		},
		{	UDCMD_MEM_L,  2, (unsigned char	*)"SB"		},
		{	UDCMD_MEM_L,  2, (unsigned char	*)"SW"		},
		{	UDCMD_MEM_L,  2, (unsigned char	*)"SL"		},
		{	UDCMD_MEM_D,  4, (unsigned char	*)"DUMP"	},
		{	UDCMD_MEM_D,  2, (unsigned char	*)"DB"		},
		{	UDCMD_MEM_D,  2, (unsigned char	*)"DW"		},
		{	UDCMD_MEM_D,  2, (unsigned char	*)"DL"		},
		{	UDCMD_MEM_D,  1, (unsigned char	*)"D"		},
		{	UDCMD_MEM_F,  4, (unsigned char	*)"FILL"	},
		{	UDCMD_MEM_F,  1, (unsigned char	*)"F"		},
		{	UDCMD_MEM_S,  4, (unsigned char	*)"SUBS"	},
		{	UDCMD_MEM_S,  2, (unsigned char	*)"EW"		},
		{	UDCMD_MEM_S,  1, (unsigned char	*)"E"		},
		{	UDCMD_MEM_T,  2, (unsigned char	*)"CM"		},
		{	UDCMD_MEM_FC, 2, (unsigned char	*)"FC"		},
		{	UDCMD_MEM_CP, 2, (unsigned char	*)"CP"		},
		{	UDCMD_MEM_FE, 2, (unsigned char	*)"FE"		},
		{	UDCMD_MEM_FW, 2, (unsigned char	*)"FW"		},
		{	UDCMD_LCD_LT, 2, (unsigned char	*)"LT"		},
		{	UDCMD_LCD_CT, 2, (unsigned char	*)"CT"		},
		{	UDCMD_PRG_CK, 4, (unsigned char	*)"PRCK"	},
		{	UDCMD_EXT_CK, 2, (unsigned char	*)"EX"		},
		{	UDCMD_LCD_CLK,2, (unsigned char	*)"SC"		},
		{	UDCMD_LED,    2, (unsigned char	*)"RT"		},
		{	UDCMD_IO_TEST,2, (unsigned char	*)"IO"		},

		{	UDCMD_RTS_TEST,3, (unsigned char *)"RTS"	},
		{	UDCMD_LCD_TEST,3, (unsigned char *)"LCD"	},
		{	UDCMD_BUZ_BZ,  3, (unsigned char *)"BUZ"	},
		{	UDCMD_FILE_TEST,4, (unsigned char *)"FILE"	},
		{	UDCMD_CALIB,   4, (unsigned char *)"CALB"	},
		{	UDCMD_LD_START,4, (unsigned char *)"LDST"	},
		{	UDCMD_USB_SLAVE,4, (unsigned char *)"USBS"	},
		{	UDCMD_W5300_TEST,3, (unsigned char *)"W53"	},


		{	UDCMD_HARD_TEST,4, (unsigned char *)"TEST"	},

		/**	����R?���h		**/
		{	UDCMD_PLOAD,  5, (unsigned char	*)"PLOAD"	},
		{	UDCMD_FLOAD,  5, (unsigned char	*)"FLOAD"	},
		{	UDCMD_PASS,   2, (unsigned char	*)"PW"		},
		{	UDCMD_FRLD,   4, (unsigned char	*)"FRLD"	},

		/**	�V�X�e?�n�R?���h	**/
		{	UDCMD_VER,	  3, (unsigned char	*)"VER"		},
		{	UDCMD_VER,	  1, (unsigned char	*)"_"		},
		{	UDCMD_HELP,	  4, (unsigned char	*)"HELP"	},
		{	UDCMD_HELP,	  1, (unsigned char	*)"?"		},
		{	UDCMD_CHELP,  4, (unsigned char	*)"USE?"	},
		{	UDCMD_ECHO,   4, (unsigned char	*)"ECHO"	},
		{	UDCMD_ECHOOF, 5, (unsigned char	*)"_ECHO"	},
		{	UDCMD_SERIAL_SET, 9, (unsigned char	*)"SERIALSET"	},  /* 20090717 */
		
		{	UDCMD_EXIT,	  4, (unsigned char	*)"QUIT"	},
		{	UDCMD_EXIT,	  1, (unsigned char	*)"Q"		},
		{	UDCMD_NO_CMD, 1, (unsigned char	*)"\x0D"	},

	};

/************************************************************/
/*	�R?���h�ԍ��̎擾										*/
/*	�ߒl�F	�R?���h�ԍ�									*/
/*			0*:�������R?���h()								*/
/*			1*:����n�R?���h								*/
/*			8*:����R?���h									*/
/*			F*:�V�X�e?�n�R?���h							*/
/************************************************************/
unsigned int GetDModeCmdNo( unsigned char *pCmd )
{
	unsigned int i;

	for( i= 0; pCmd[i] != END_CHAR; i++ ){
		if( 'a' <= pCmd[i] && pCmd[i] <= 'z' ){	pCmd[i]-= ('a'- 'A');	}
	}
	for( i= 0; i < TBQ(DmodeCmdTbl); i++ ){
		if( memcmp( pCmd, DmodeCmdTbl[i].cmd, DmodeCmdTbl[i].size ) == 0 ){
			if( IsSpeace( *(pCmd+ DmodeCmdTbl[i].size) ) == TRUE ||
								DmodeCmdTbl[i].No == UDCMD_NO_CMD ){
				DModeSendCR();
				return( DmodeCmdTbl[i].No );
			}
		}
	}
	return( 0x00 );
}
/************************************************/
/*	Flash Check									*/
/************************************************/
int	FlashWriteProcColl(char *addr,char *data,int size)
{
	return(0);
}
void	FlashErazeCall(short *addr)
{
}
int		FlashCheck(void)
{
	return(0);
}
void	FlashWriteCheck(void)
{
}
void	FlashErazeCheck(void)
{
}
void	JmpApl(void)
{
}
void	RTSCheck(unsigned char *pCmd)
{
	unsigned long	cnt;

	cnt= 0;
	pCmd= SkipNextWord( pCmd );
	if( atolx( &cnt, pCmd ) == FALSE ){	cnt= 0;	}
	if(cnt == 0){
		RtsOff();
	}else{
		RtsOn();
	}
}
void	DrawRectangle(void)
{
	COLOR_DT	color;
	int	i;
	for(i= 0; ; i++){
		if(i >= ((LCD_Y_SIZE-1)-i)){	break;	}
		color= GetColorData((255-i) & 0xff);			//WHITE()
		ForGrandColor= color;			//WHITE()
		RectAngleNoDraw(0+i,0+i,(LCD_X_SIZE-1)-i,(LCD_Y_SIZE-1)-i,T_WHITE,T_BLACK);
	}
	DrawLcd((char *)LcdBuff);
	ForGrandColor.r= 0xff;			//WHITE()
	ForGrandColor.g= 0xff;			//WHITE()
	ForGrandColor.b= 0xff;			//WHITE()
}
void	LCDCheckMess(void)
{
	DModeSendMsg("1.Rectangle\r\n");
	DModeSendMsg("2.Clear\r\n");
	DModeSendMsg("3.Patarn\r\n");
	DModeSendMsg("9.Exit\r\n");
}
void	LCDCheck(unsigned char *pCmd)
{
	int	ret;

	LCDCheckMess();
	while(1){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			if(ret == '9'){	break;	}
			switch(ret){
			case '1':	DrawRectangle();		break;
			case '2':	ClearDisplay();			break;
			}
			LCDCheckMess();
		}
	}
}
void Lcd_Patarn(int mode);

void	LcdCheck()
{

}

void	setBuzClock(int lowclk, int highclk)
{

}

void	setpulseClock(int lowclk, int highclk)
{

}




void	BuzzerChk()
{
	int		bk=1;
	int		ret;
	char	buff[32];

	DModeSendMsg( "Buz High +100 = 1, Buz High -100 = 2, Buz Low +100 = 3, Buz Low -100 = 4" );
	DModeSendCR();
	DModeSendMsg( "Buz High   +1 = 5, Buz High   -1 = 6, Buz Low   +1 = 7, Buz Low   -1 = 8" );
	DModeSendCR();
	DModeSendMsg("Buzzer ON = B, Buzzer OFF = C");
	DModeSendCR();
	DModeSendMsg( "fpga_peried_clk+1 = A, fpga_peried_clk-1 = S, fpga_width_clk+1 = Z, fpga_width_clk-1 = X" );
	DModeSendCR();
	fpga_peried_clk = 88;
	fpga_width_clk = 44;
	while(bk){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			switch(ret){
				case 'B':	case 'b':
					BuzOn();
					DModeSendMsg("Buzzer ON");
					break;
				case 'C':	case 'c':
					BuzOff();
					DModeSendMsg("Buzzer OFF");
					break;
				case '1':
					if(buzhighclk < 0xffff){
						buzhighclk += 100;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '2':
					if(buzhighclk > 0){
						buzhighclk -= 100;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '3':
					if(buzlowclk < 0xffff){
						buzlowclk += 100;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '4':
					if(buzlowclk > 1){
						buzlowclk -= 100;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '5':
					if(buzhighclk < 0xffff){
						buzhighclk++;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '6':
					if(buzhighclk > 0){
						buzhighclk--;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '7':
					if(buzlowclk < 0xffff){
						buzlowclk++;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '8':
					if(buzlowclk > 1){
						buzlowclk--;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case 'a':
				case 'A':
					if(fpga_peried_clk < 0xffff){
						fpga_peried_clk++;
					}
					setpulseClock(fpga_peried_clk, fpga_width_clk);
					sprintf(buff,"fpga_peried_clk=%d\r\n",fpga_peried_clk);
					DModeSendMsg(buff);
					sprintf(buff,"fpga_width_clk=%dHz\r\n",fpga_width_clk); 
					DModeSendMsg(buff);
					break;
				case 's':
				case 'S':
					if(fpga_peried_clk > 0){
						fpga_peried_clk--;
					}
					setpulseClock(fpga_peried_clk, fpga_width_clk);
					sprintf(buff,"fpga_peried_clk=%d\r\n",fpga_peried_clk);
					DModeSendMsg(buff);
					sprintf(buff,"fpga_width_clk=%dHz\r\n",fpga_width_clk); 
					DModeSendMsg(buff);
					break;
				case 'z':
				case 'Z':
					if(fpga_width_clk < 0xffff){
						fpga_width_clk++;
					}
					setpulseClock(fpga_peried_clk, fpga_width_clk);
					sprintf(buff,"fpga_peried_clk=%d\r\n",fpga_peried_clk);
					DModeSendMsg(buff);
					sprintf(buff,"fpga_width_clk=%dHz\r\n",fpga_width_clk); 
					DModeSendMsg(buff);
					break;
				case 'x':
				case 'X':
					if(fpga_width_clk > 1){
						fpga_width_clk--;
					}
					setpulseClock(fpga_peried_clk, fpga_width_clk);
					sprintf(buff,"fpga_peried_clk=%d\r\n",fpga_peried_clk);
					DModeSendMsg(buff);
					sprintf(buff,"fpga_width_clk=%dHz\r\n",fpga_width_clk); 
					DModeSendMsg(buff);
					break;
				case '\r':
				case 0x51:
				case 0x71:
					bk=0;
					break;
				default:
					DModeSendMsg("COMMAND ERROR");
					break;
			}
			DModeSendCR();
		}
	}
}



void	DbgLed()
{
	int		ret;
	int		bk=1;
	char	buff[32];

	DModeSendMsg("Run LED ON=1, Run LED OFF=2, Error LED ON=3, Error LED OFF=4");
	DModeSendCR();
	DModeSendMsg("Run SW Status=5, Run SW AD Value=6, Bat AD Value=7, Debug SW AD Value=8");
	DModeSendCR();
	DModeSendMsg("Buzzer ON = B, Buzzer OFF = C, LCD Eable = E, LCD Disable = D");
	DModeSendCR();
	DModeSendMsg("Back Light ON = L, Back Light OFF = P");
	DModeSendCR();
	DModeSendMsg("PORT E0 Output = R, Fpllo out = T, Fout = Y");
	DModeSendCR();
	while(bk){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			switch(ret){
				case 0x31:
					RunLed(ON);
					DModeSendMsg("Run LED ON");
					break;
				case 0x32:
					RunLed(OFF);
					DModeSendMsg("Run LED OFF");
					break;
				case 0x33:
					ErrorLed(ON);
					DModeSendMsg("ErrorLed LED ON");
					break;
				case 0x34:
					ErrorLed(OFF);
					DModeSendMsg("ErrorLed LED OFF");
					break;
				case 0x35:
					ret= RunSWRead();
					sprintf(buff,"Run SW Status=%d\r",ret);
					DModeSendMsg(buff);
					break;
				case 0x37:
					GetAD_Power(&ret);
					sprintf(buff,"Bat A/D Value=%d\r",ret);
					DModeSendMsg(buff);
					break;
				case 0x42:
				case 0x62:
					BuzOn();
					DModeSendMsg("Buzzer ON");
					break;
				case 0x43:
				case 0x63:
					BuzOff();
					DModeSendMsg("Buzzer OFF");
					break;
				case 0x44:
				case 0x64:
					LCDDisplayEnable(ON);
					DModeSendMsg("LCD Display Disable");
					break;
				case 0x45:
				case 0x65:
					LCDDisplayEnable(OFF);
					DModeSendMsg("LCD Display Enable");
					break;
				case 0x4c:
				case 0x6c:
					BackLightOnOff(ON);
					DModeSendMsg("Back Light ON");
					break;
				case 0x50:
				case 0x70:
					BackLightOnOff(OFF);
					DModeSendMsg("Back Light OFF");
					break;
				case '\r':
				case 0x51:
				case 0x71:
					bk=0;
					break;
				default:
					DModeSendMsg("COMMAND ERROR");
					break;
			}
			DModeSendCR();
		}
	}


}

char	buff_A[1023];
unsigned char LHexToBin(char as_data)
{
	unsigned char ret;

	ret = 0;
	if((as_data >= '0') && (as_data <= '9')){
		ret = (unsigned char)(as_data - '0');
	}
	else if((as_data >= 'A') && (as_data <= 'F')){
		ret = (unsigned char)(as_data - 'A' + 10);
	}
	else if((as_data >= 'a') && (as_data <= 'f')){
		ret = (unsigned char)(as_data - 'a' + 10);
	}
	return(ret);
}
void	DbgIO()
{
	int		ret;
	int		bk=1;
	char	buff[32];
	char	buff1[32];
	int		commcnt;
	char	Commbuff[8];
	unsigned	int	rData;
	unsigned	int	address;
	int		i;
	commcnt= 0;
	memset(Commbuff,0,sizeof(Commbuff));



	DModeSendMsg("R = Read, W = Write, Q = Quit");
	DModeSendCR();
	while(bk){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();

			memset(Commbuff,0,sizeof(Commbuff));
			commcnt = 0;
			switch(ret){
				case 'r':
				case 'R':
					DModeSendMsg("Address[0 - 4, D] Enter : Read, Q : Quit");
					DModeSendCR();
					while(bk){
						if(IS_CONSOL( ) != 0){
							ret= GET_CONSOL();
							switch(ret){
							case  'q':
							case  'Q':
								bk=0;
								break;
							case  'l':
							case  'L':
								ret = '0';
								while(bk){
									if(IS_CONSOL( ) != 0){
										ret= GET_CONSOL();
									}
									switch(ret){
									case  '0':
									case  '1':
									case  '2':
										rData = (*(volatile unsigned char *)(IO_START_ADDR+(ret-'0')) & 0x00ff);
										sprintf(buff,"%02X = %02X\r",ret,rData);
										DModeSendMsg(buff);
										break;
									case  'q':
									case  'Q':
										bk=0;
										break;
									default:
										DModeSendMsg("COMMAND ERROR");
										break;
									}
								}
								break;
							case '\r':
								if(commcnt==0){	break; }

								rData= 0;
								address=0;
								for(i= 0; i < commcnt; i++){
									address = address << 4;
									address |= LHexToBin(Commbuff[i]);
								}
								memset(buff,0,sizeof(buff));
								memset(buff_A,0,sizeof(buff_A));

								strcat(buff_A,Commbuff);

								switch(address){
								case  0x00:
								case  0x01:
								case  0x02:
								case  0x03:
								case  0x04:
									rData = (*(volatile unsigned char *)(IO_START_ADDR+address) & 0x00ff);
									sprintf(buff," = %02X",rData);
									strcat(buff_A,buff);
									break;
								case  0x0d:
									strcat(buff_A,"\x0d\x0a");


									for(i=1;i<257;i++){
										rData = (*(volatile unsigned char *)(IO_START_ADDR+i-1) & 0x00ff);
										sprintf(buff,"%02X = %02X, ", i-1,rData);
										strcat(buff_A,buff);

										if(i%8 == 0){
											strcat(buff_A,"\x0d\x0a");
										}
									}

									break;
								case  0x1d:
									strcat(buff_A,"\x0d\x0a");


									for(i=257;i<513;i++){
										rData = (*(volatile unsigned char *)(IO_START_ADDR+i-1) & 0x00ff);
										sprintf(buff,"%02X = %02X, ", i-1,rData);
										strcat(buff_A,buff);

										if(i%8 == 0){
											strcat(buff_A,"\x0d\x0a");
										}
									}

									break;
								case  0x2d:
									strcat(buff_A,"\x0d\x0a");


									for(i=513;i<769;i++){
										rData = (*(volatile unsigned char *)(IO_START_ADDR+i-1) & 0x00ff);
										sprintf(buff,"%02X = %02X, ", i-1,rData);
										strcat(buff_A,buff);

										if(i%8 == 0){
											strcat(buff_A,"\x0d\x0a");
										}
									}

									break;
								case  0x3d:
									strcat(buff_A,"\x0d\x0a");


									for(i=769;i<1025;i++){
										rData = (*(volatile unsigned char *)(IO_START_ADDR+i-1) & 0x00ff);
										sprintf(buff,"%02X = %02X, ", i-1,rData);
										strcat(buff_A,buff);

										if(i%8 == 0){
											strcat(buff_A,"\x0d\x0a");
										}
									}

									break;
								case  0x4d:
									strcat(buff_A,"\x0d\x0a");


									for(i=1025;i<1281;i++){
										rData = (*(volatile unsigned char *)(IO_START_ADDR+i-1) & 0x00ff);
										sprintf(buff,"%02X = %02X, ", i-1,rData);
										strcat(buff_A,buff);

										if(i%8 == 0){
											strcat(buff_A,"\x0d\x0a");
										}
									}

									break;
								default:
									DModeSendMsg("COMMAND ERROR");
									break;
								}
								memset(Commbuff,0,sizeof(Commbuff));
								commcnt = 0;
								DModeSendMsg(buff_A);
								DModeSendCR();
								break;
							default:
								Commbuff[commcnt++]= ret;
								commcnt = commcnt % 8;
								break;
							}
						}
					}
					bk=1;
					ret=0;
					DModeSendMsg("R = Read, W = Write, Q = Quit");
					DModeSendCR();
					break;
				case 'w':
				case 'W':
					DModeSendMsg("Address[0x00 - 0xFF] Data[XX] Enter : Write, Q : Quit");
					DModeSendCR();
					DModeSendCR();
					memset(Commbuff,0,sizeof(Commbuff));
					memset(buff_A,0,sizeof(buff_A));
					memset(buff1,0,sizeof(buff1));
					commcnt = 0;
					while(bk){
						if(IS_CONSOL( ) != 0){
							ret= GET_CONSOL();
							switch(ret){
							case  'q':
							case  'Q':
								bk=0;
								break;
							case 0x20:
								rData= 0;
								address=0;
								for(i= 0; i < commcnt; i++){
									address = address << 4;
									address |= LHexToBin(Commbuff[i]);
								}
								strcat(buff_A,Commbuff);								
								strcat(buff_A,"\x20");								
								memset(Commbuff,0,sizeof(Commbuff));
								commcnt = 0;
								while(bk){
									if(IS_CONSOL( ) != 0){
										ret= GET_CONSOL();
										if(ret == '\r'){
											bk=0;
											break;
										}
										Commbuff[commcnt++]= ret;
										commcnt = commcnt % 8;
									}
								}
								for(i= 0; i < commcnt; i++){
									rData = rData << 4;
									rData |= LHexToBin(Commbuff[i]);
								}
								strcat(buff_A,Commbuff);	
								if(0x10000000 >= address){
									*(volatile unsigned char *)(IO_START_ADDR+address)= (rData & 0xff);								
								}else{
									DModeSendMsg("COMMAND ERROR");
								}

								bk=1;
								ret=0;


								DModeSendMsg(buff_A);
								DModeSendCR();
								memset(buff,0,sizeof(buff));
								memset(buff1,0,sizeof(buff1));
								memset(buff_A,0,sizeof(buff_A));
								memset(Commbuff,0,sizeof(Commbuff));
								commcnt = 0;
								break;
							default:
								Commbuff[commcnt++]= ret;
								commcnt = commcnt % 8;
								break;
							}
						}
					}
					bk=1;
					ret=0;
					DModeSendMsg("R = Read, W = Write, Q = Quit");
					DModeSendCR();
					break;
				case  'q':
				case  'Q':
					bk=0;
					break;
				default:
					DModeSendMsg("COMMAND ERROR");
					break;			
			}
			DModeSendCR();
		}
	}

}

void	SerialSet()
{

	int		bk=1;
	int		ret;
	char	buff[32];

	DModeSendMsg("0 = Speed   2400bps ");
	DModeSendCR();
	DModeSendMsg("1 = Speed   9600bps ");
	DModeSendCR();
	DModeSendMsg("2 = Speed  38400bps ");
	DModeSendCR();
	DModeSendMsg("3 = Speed 115200bps ");
	DModeSendCR();

	sprintf(buff,"SPEED = %10d bps \r\n", setspeed);
	DModeSendMsg(buff);

	while(bk){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			switch(ret){
				case '0':
					BuzOn();
					setspeed =   2400;
					break;
				case '1':
					BuzOff();
					setspeed =   9600;
					break;
				case '2':
					BuzOff();
					setspeed =  38400;
					break;
				case '3':
					BuzOff();
					setspeed = 115200;
					break;
				case '\r':
				case 0x51:
				case 0x71:
					bk=0;
					break;
				default:
					DModeSendMsg("COMMAND ERROR");
					break;
			}
			sprintf(buff,"setspeed = %10d bps\r\n",setspeed);
			DModeSendMsg(buff);
			DModeSendCR();
//			Uart_Init(0,setspeed);    			// Init UART
		}
	}
}


void	DbgContrast(unsigned char *pCmd)
{
	unsigned long	cnt;

	cnt= 65;
	pCmd= SkipNextWord( pCmd );
	if( atolx( &cnt, pCmd ) == FALSE ){	cnt= 65;	}
	SetContrast(cnt);
	
}
void	DbgLcdClock(unsigned char *pCmd)
{
	unsigned long	cnt;

	cnt= 10;
	pCmd= SkipNextWord( pCmd );
	if( atolx( &cnt, pCmd ) == FALSE ){	cnt= 65;	}
	
}
EXT_IO_INF		extInfo;	/* �O���ڑ���� */
void	ExtBordCheck(void)
{
	int i;
	unsigned char	*addr;
	unsigned char	id_data;

#ifdef	WIN32
	extInfo.extCnt= 0;
	return;
#endif
	addr= (unsigned char *)EXT_IO_ADDR;
	extInfo.extCnt= 0;
	for(i= 0; i < MAX_EXT_CNT; i++){
		id_data= *addr;
		if(id_data != 0xff){
			extInfo.ExtInfo[extInfo.extCnt].ID= id_data;
			extInfo.ExtInfo[extInfo.extCnt++].address= addr;
		}
		addr += 0x400;
	}
}
void	ExtBoardCheck(unsigned char *pCmd)
{
	int	i;
	int	Operation;
	unsigned char *Register;
	int	data;
	int	ret;
	char buff[64];

	pCmd= SkipNextWord( pCmd );
	//Read/Write
	if( atolx( (unsigned long *)&Operation, pCmd ) == FALSE ){	Operation= 0;	}		//0:check,1:read,2:write
	pCmd= SkipNextWord( pCmd );
	//Register
	if( atolx( (unsigned long *)&Register, pCmd ) == FALSE ){	Register= (unsigned char *)0x0e000000;	}		//Address
	pCmd= SkipNextWord( pCmd );
	//Write Data
	if(Operation == 2){
		if( atolx( (unsigned long *)&data, pCmd ) == FALSE ){	data= 0;	}			//Data
	}
	switch(Operation){
	case 0:		//Check
		ExtBordCheck();
		sprintf(buff,"Count=%d\r\n",extInfo.extCnt);
		DModeSendMsg( buff );
		for(i= 0; i < extInfo.extCnt; i++){
			sprintf(buff,"ID=%02X(%08X)\r\n",
				extInfo.ExtInfo[i].ID & 0x00ff,extInfo.ExtInfo[i].address);
			DModeSendMsg( buff );
		}
		break;
	case 1:		//read
		ret= *Register & 0x00ff;
		sprintf(buff,"data=%02X",ret);
		DModeSendCR();
		DModeSendMsg( buff );
		break;
	case 2:		//write
		*Register= data;
		ret= *Register & 0x00ff;
		sprintf(buff,"data=%02X",ret);
		DModeSendCR();
		DModeSendMsg( buff );
		break;
	}

}

//20080818
unsigned int DModeCommandAs( unsigned char *pCmd )
{	
	switch( GetDModeCmdNo( pCmd ) ){
	case UDCMD_FLOAD:				/* FPGA Data Load */
//		FontDownLoad((char *)DownloadBuff,0);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_VER:					/* About */
		DModeSendVersion();			return( TRUE );
	case UDCMD_ECHO:				/* Echo On */
		SioEchoFlag = 1;
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_ECHOOF:				/* Echo Off */
		SioEchoFlag = 0;
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_EXIT:				/* QUIT */
		DModeSendQuitMsg();			return( FALSE );
	case UDCMD_NO_CMD:				/* NO COMMAND */
		DModeSendPronpt();			return( TRUE );
	default:						/* ERROR */
		DModeSendCmdErr( pCmd );
		return( TRUE );
	}
//	return( TRUE );
}

unsigned int DModeCommand( unsigned char *pCmd )
{	
	switch( GetDModeCmdNo( pCmd ) ){
	/**	�������R?���h		**/
	case UDCMD_RC:					/* SendCamera Command */
	case UDCMD_IO:					/* I/O Test */
	case UDCMD_GO:					/* Do Program Continue */
	case UDCMD_BR:					/* Break Point Address */
		DModeSendPronpt();
		return( TRUE );
	/**	����n�R?���h		**/
	case UDCMD_MEM_R:				/* Memory Read */
		DModeMemoryRead( pCmd );	return( TRUE );
	case UDCMD_MEM_W:				/* Memory Write */
		DModeMemoryWrite( pCmd );	return( TRUE );
	case UDCMD_MEM_D:				/* Memory Dump */
		DModeMemoryDump( pCmd );	return( TRUE );
	case UDCMD_MEM_F:				/* Memory Fill */
		DModeMemoryFill( pCmd );	return( TRUE );
	case UDCMD_MEM_S:				/* Memory Subs */
		DModeMemorySubs( pCmd );	return( TRUE );
	case UDCMD_MEM_U:				/* Memory Read */
		DModeMemoryCycleRead( pCmd );	return( TRUE );
	case UDCMD_MEM_L:				/* Memory Write */
		DModeMemoryCycleWrite( pCmd );	return( TRUE );
//	case UDCMD_MEM_T:
//		DModeMemoryCheck( pCmd );	return( TRUE );
	case UDCMD_MEM_P:
		DModePortOut( pCmd );	return( TRUE );
	case UDCMD_MEM_FC:
		if(FlashCheck() == 0){
			DModeSendMsg( "FLASH OK" );
		}else{
			DModeSendMsg( "FLASH NG" );
		}
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_MEM_CP:
		JmpApl();
		return( TRUE );
	case UDCMD_MEM_FE:
		FlashErazeCheck();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_MEM_FW:
		FlashWriteCheck();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LCD_LT:
		LcdCheck();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_BUZ_BZ:
		BuzzerChk();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_FILE_TEST:
//		FileProc();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_CALIB:
//		SetTouchCalibration();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LD_START:
		LoaderStart();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_USB_SLAVE:
		UsbSlaveCheck();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LCD_CT:
		DbgContrast(pCmd);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LCD_CLK:
		DbgLcdClock(pCmd);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LED:
		DbgLed();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_IO_TEST:
		DbgIO();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );

//	case UDCMD_W5300_TEST:
//		W5300Test();
//		DModeSendCR();
//		DModeSendPronpt();
//		return( TRUE );

	case UDCMD_HARD_TEST:
		HardTest();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );

#ifdef	OLD
	case UDCMD_IO_TEST1:
		DbgIO1();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
#endif
	case UDCMD_RTS_TEST:
		RTSCheck(pCmd);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LCD_TEST:
		LCDCheck(pCmd);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_PRG_CK:
//		FontDownLoad((char *)DownloadBuff,1);
		DModeSendCR();
		DModeSendPronpt();
	case UDCMD_EXT_CK:		//External Boad Check
		ExtBoardCheck(pCmd);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	/**	����R?���h		**/
	case UDCMD_PLOAD:				/* Program Load */
		PloadFlag= TRUE;
//		HexLoad((char *)DownloadBuff);
		PloadFlag= FALSE;
		return( TRUE );
	case UDCMD_FLOAD:				/* FPGA Data Load */
//		FontDownLoad((char *)DownloadBuff,0);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_PASS:
		PasswordWrite( pCmd );
		return( TRUE );
	case UDCMD_FRLD:				/* FPGA Data Load */
//		FontRamDownLoad();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	/** �V�X�e?�n�R?���h	**/
	case UDCMD_VER:					/* About */
		DModeSendVersion();			return( TRUE );
	case UDCMD_HELP:				/* HELP */
		DModeSendHelpMsg();			return( TRUE );
	case UDCMD_CHELP:				/* CAM HELP */
		DModeSendCamHelpMsg();		return( TRUE );
	case UDCMD_ECHO:				/* Echo On */
		SioEchoFlag = 1;
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_ECHOOF:				/* Echo Off */
		SioEchoFlag = 0;
		DModeSendPronpt();
		return( TRUE );
 	case UDCMD_SERIAL_SET:			/* Serial Set */ /* 20090717 */
		SerialSet();
		DModeSendCR();
		DModeSendPronpt();
	case UDCMD_EXIT:				/* QUIT */
		DModeSendQuitMsg();			return( FALSE );
	case UDCMD_NO_CMD:				/* NO COMMAND */
		DModeSendPronpt();			return( TRUE );
	default:						/* ERROR */
		DModeSendCmdErr( pCmd );
		return( TRUE );
	}
//	return( TRUE );
}
void	LoaderMessDisp(void)
{
}
int LoginProc( unsigned int cmd, unsigned char *msg )
{
	switch( cmd ){
	case NO_LOGIN:	return( *msg == 0x04 ? RR_LOGIN : NO_LOGIN );
	case RR_LOGIN:
//		if( memcmp( msg, "autonicsprojectii", 17 ) == 0 ){
		if( memcmp( msg, "a", 1 ) == 0 || memcmp( msg, "A", 1 ) == 0){
			DModeSendLoginMsg();		/* Welcome Message */
			LoaderMessDisp();
			return( OK_LOGIN );
		}
		//20080818
//		if( memcmp( msg, "autoas", 6 ) == 0 ){
		if( memcmp( msg, "a", 1 ) == 0 || memcmp( msg, "A", 1 ) == 0){
			DModeSendLoginMsgAs();		/* Welcome Message */
			LoaderMessDisp();
			return( OK_LOGIN_AS );
		}

	}
	return( NO_LOGIN );
}

int DebugTask( int cmd, char *msg )
{
	switch( cmd ){
	case NO_LOGIN:	return( LoginProc( (unsigned char)cmd, (unsigned char *)msg ) );
	case RR_LOGIN:	return( LoginProc( (unsigned char)cmd, (unsigned char *)msg ) );
	case OK_LOGIN:
		if( SubsModeFlag == TRUE ){	DModeSubsProc( (unsigned char *)msg );	}
		else if( DModeCommand( (unsigned char *)msg ) != TRUE ){	return( NO_LOGIN );	}
		break;
	case OK_LOGIN_AS:	//20080818
		if( SubsModeFlag == TRUE ){	DModeSubsProc( (unsigned char *)msg );	}
		else if( DModeCommandAs( (unsigned char *)msg ) != TRUE ){	return( NO_LOGIN );	}
		break;
	}
	return( cmd );
}
void PassWordCheck(char *pbuff)
{
	char msg[256];
extern	int	GetMessage( char *ptr );

	DModeSendMsg( "Input Password" );
	DModeSendCR();

/*	InitCPU();*/
	while( TRUE ){
		if( GetMessage( msg ) != 0 ){
			if(memcmp(pbuff,msg,4) == 0){
				break;
			}
		}
	}
}
void	UsbCheck(void)
{
//	int	ret;
	int	connectflag= 0;

	DModeSendMsg("### USB Check Start ###\r\n");

	while(1){
		if(IS_CONSOL( ) != 0){
			GET_CONSOL();
			break;
		}
		UsbHostDrv( );     /* USB HOST�h���C�o�[�^�X�N */
		if(connectflag != UsbHostConnected){
			connectflag= UsbHostConnected;
			if(connectflag == 0){	DModeSendMsg("USB Disconnect\r\n");	}
			else{
				DModeSendMsg("USB Connect\r\n");
//				GetRootFile();
			}
		}
	}
}
void	LoaderStart(void)
{
	void	(*lfunc)();

	FlashReadSeq((char*)0x30010000,(char*)LOARDER_PROG_AREA,0x80000);	//1M Read
	_di();
	lfunc = (void (*)())0x30010000;
	lfunc();
}
void	UsbSlaveCheck(void)
{
	int	ret;

	DModeSendMsg("USB Slave Start\r\n");
//	UsbDevIntEnable();
//	UsbDevHandlerInit();
//	MakeFatFs( 0, 2, 16, 512, 4 );		//Fat16,Sector/Cluster=8
	while(1){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			if(ret == '9'){	break;	}
		}
//		if( CheckUsbRecData() != 0 ){
//			UsbDevHandler();
//		}
	}
	DModeSendMsg("USB Slave End\r\n");
}

