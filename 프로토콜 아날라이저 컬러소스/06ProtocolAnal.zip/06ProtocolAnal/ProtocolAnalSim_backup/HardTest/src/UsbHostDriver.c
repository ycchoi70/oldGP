/****************************************************/
/*    FUNC   : USB Host Handler		                */
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 2009.11.07                           */
/*    Update :                                      */
/****************************************************/
#define	USB_HOST
//#include	"doscomm.h"
//#include	"glpdos.h"
#include	"define.h"
#include	"glplcd.h"
#include	"commbuff.h"
#include	"s2440.h"
#include	"usbh.h"
//#include	"pcmcia.h"

void	UsbHostConnectProc(void)
{
	int	ret;

	ret= Hcd_DoTransfer();		//USB EDP Initialize
//	ret= InitUSB_Disk();
	if(ret == 0){	//OK
//		MountUsbFile4();
		UsbHostDeviceOK= 1;
	}else{
		UsbHostDeviceOK= 0;
	}
}
void	UsbHostInitial(void)
{
#ifdef	WIN32
	return;
#endif
	Hcd_Init();

	UsbHostConnected= 0;
	UsbHostDeviceOK= 0;
}
extern	void	Wait10ms(int cnt);
int	UsbHostDrv( void )     /* USB HOST�h���C�o�[�X�N */
{
	int	ret;

	ret= Get_Hcd_DeviceConnectInf();
	if(ret != 0){	//Connect
		if(UsbHostConnected == 0){
			Wait10ms(20);
			Hcd_DeviceConnect();
			UsbHostConnectProc();
			UsbHostConnected= 1;
		}
	}else{									//DisConnect
		if(UsbHostConnected == 1){
			Hcd_DeviceDisConnect();
//			DismountUsbFile4();
			UsbHostConnected= 0;
			UsbHostDeviceOK= 0;
		}
	}
	return(ret);
}
//unsigned char	dumBuff[0x1000];
int	UsbReadSector(long sector,long datasize,unsigned char*buff)
{
	int	i;
	int	sectCnt;
	int	ret;

//	SetUsbHostSema();
	sectCnt= datasize/512;
	if(datasize%512){	sectCnt++;	}
	for(i= 0; i < sectCnt; i++){
		ret= bulk_only_transfer(ST_READ,&buff[i*512],sector+i,1);
		if(ret == 1){	break;	}		//Error
	}
//	Delay(3000);
//	ret= bulk_only_transfer(ST_READ,dumBuff,0x3f,1);
//	ResetUsbHostSema();
	return(ret);
}
int	UsbWriteSector(long sector,long datasize,unsigned char*buff)
{
	int	i;
	int	sectCnt;
	int	ret;

//	SetUsbHostSema();
	sectCnt= datasize/512;
	if(datasize%512){	sectCnt++;	}
	for(i= 0; i < sectCnt; i++){
		ret= bulk_only_transfer(ST_WRITE,&buff[i*512],sector+i,1);
		if(ret == 1){	break;	}		//Error
	}
//	ResetUsbHostSema();
	return(ret);
}
