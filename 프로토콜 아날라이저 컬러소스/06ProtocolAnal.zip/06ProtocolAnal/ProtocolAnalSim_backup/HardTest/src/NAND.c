
#include	<string.h>
#define	NAND_PROC
#include "S2440.h"
#include "nand.h"


#ifdef	OLD
NAND_REG	*nandCtl;

#define _CNT(ctl)		   {nandCtl->rNFCONT=ctl;}
#define _CMD(cmd)		   {nandCtl->u1.rNFCMMD=cmd;}
#define _ADDR(addr) 	   {nandCtl->u2.rNFADDR=addr;}	
#define _RstECC()		   {nandCtl->rNFCONT|=(1<<4);}
#define _RstECCLOCK()	   {nandCtl->rNFCONT&=~((1<<6)|(1<<5));}
#define _SetECCLOCK()	   {nandCtl->rNFCONT|=((1<<6)|(1<<5));}
#define _RDDATA() 		(nandCtl->u3.rNFDATA)
#define _WRDATA(data) 	{nandCtl->u3.rNFDATA=data;}
#define _GetRDY() 		(nandCtl->u4.rNFSTAT & 0x01)

#define _WaitRB()    	{while(!(nandCtl->u4.rNFSTAT & (1<<0)));}


void NAND_Reset(void)
{
	volatile int i;

	_CMD(CMD_RESET);	//reset command

	for(i=0;i<10;i++);  //tWB = 100ns. //??????

	_WaitRB();      //wait 200~500us;
}
void NAND_Init(void)
{
#ifdef	WIN32
	return;
#endif
	nandCtl= (NAND_REG*)NAND_BASE_PHYS;
//	rNFCONF=(1<<15)|(1<<14)|(1<<13)|(1<<12)|(1<<11)|(0<<8)|(3<<4)|(0<<0);
	nandCtl->rNFCONF=(0x3<<12)|(0x7<<8)|(0x7<<4)|(0x0<<0);
	nandCtl->rNFCONT=(0x0<<13)|(0x0<<12)|(0x0<<10)|(0x0<<9)|(0x0<<8)|(0x1<<6)|(0x1<<5)|(0x1<<4)|(0x1<<1)|(0x1<<0);

	NAND_Reset();
}
void NAND_Open(void)
{
	unsigned int	ctl;

#ifdef	WIN32
	return;
#endif
	ctl= nandCtl->rNFCONT;
	ctl &= ~(1<<1);
	_CNT(ctl);
}
void NAND_Close(void)
{
	unsigned int	ctl;

	ctl= nandCtl->rNFCONT;
	ctl |= (1<<1);
	_CNT(ctl);
}




void NAND_ReadID(unsigned char* buff)
{
	volatile int i;
//	unsigned int data;

#ifdef	WIN32
	return;
#endif
	NAND_Open();
	_CMD(CMD_READ_ID);
	_ADDR(0x0);

	for(i=0;i<10;i++); //wait tWB(100ns)////?????

	buff[0] = (unsigned char)_RDDATA();	// Maker code       (K9D1G08V0X:0xec)
	buff[1] = (unsigned char)_RDDATA();	// Device code      (K9D1G08V0X:0x76)
	buff[2] = (unsigned char)_RDDATA();	// UniquelID code   (K9D1G08V0X:0xa5)
	buff[3] = (unsigned char)_RDDATA();	// Multi Plane code (K9D1G08V0X:0xc0)

	NAND_Close();
}

int NAND_MarkBadBlock(int block)
{
	int i,rc;
	unsigned int blockPage=(block<<5);

	NAND_Open();
	_CMD(0x50);		            /* Spare array read command                 */
	_CMD(0x80);   // Write 1st command

	_ADDR((NAND_PAGE_SIZE+0x05)& 0xf);		        /* Read the mark of bad block in spare      */
	_ADDR(blockPage & 0xff);	    /* The mark of bad block is in 0 page       */
	_ADDR((blockPage >>  8) & 0xff);  /* For block number A[24:17]            */

	_WRDATA(0x00);	// Write spare array(ECC and Mark)

	_CMD(0x10);   // Write 2nd command

	for(i=0;i<10;i++);  //tWB = 100ns. ////??????
	_WaitRB();    //wait tPROG 200~500us;

	_CMD(0x70);   // Read status command   

	for(i=0;i<3;i++);  //twhr=60ns

	if(_RDDATA()&0x1) // Page write error
	{	
		rc= 0;
	}
	else 
	{
		rc= 1;
	}
	NAND_Close();
	return(rc);
}


int NAND_ReadPage(unsigned int block,unsigned int page,unsigned char *buffer)
{
	int i;
	unsigned int blockPage;
	unsigned char *bufPt=buffer;
//	unsigned int	data;

	NAND_Open();
	page=page&0x1f;
	blockPage=(block<<5)+page;

	_CMD(CMD_READ_A);   // Read command

	_ADDR(0);	    // Column = 0
	_ADDR(blockPage&0xff);	    //
	_ADDR((blockPage>>8)&0xff);   // Block & Page num.
	_ADDR((blockPage>>16)&0xff);   // Block & Page num.

	for(i=0;i<10;i++); //wait tWB(100ns)/////??????
	_WaitRB();    // Wait tR(max 12us)


	for(i=0x0000;i<0x0200;i++){
		*bufPt++ = (unsigned char)_RDDATA();
	}
	NAND_Close();
	return 1;
}

int NAND_WritePage(unsigned int block,unsigned int page,unsigned char *buffer)
{
	int i,rc;
	unsigned int blockPage=(block<<5)+page;
	unsigned char *bufPt=buffer;
//	unsigned char se[16];	   
//	unsigned int	data;

//	memset(se,0,sizeof(se));

//if(block == 0){	return(0);	}

//	se[5]= 0xff;
	NAND_Open();

	_RstECC();
//	_RstECCLOCK();

	_CMD(0x00);		//??????
	_CMD(0x80);   // Write 1st command

	_ADDR(0);			    // Column 0
	_ADDR(blockPage&0xff);	    //
	_ADDR((blockPage>>8)&0xff);   // Block & page num.
	_ADDR((blockPage>>16)&0xff);   // Block & page num.

	for(i=0;i<512;i++)
	{
		_WRDATA(*bufPt++);	// Write one page to NFM from buffer

	}  
//	se[5]=0xff;		// Marking good block
	
//	data= rNFMECC0;
//	se[0x8]=data & 0xff;
//	se[0x9]=(data>>8) & 0xff;
//	se[0xa]=(data>>16) & 0xff;
//	se[0xb]=(data>>24) & 0xff;

//	data= rNFMECC1;
//	se[0xc]=data & 0xff;
//	se[0xd]=(data>>8) & 0xff;
//	se[0xe]=(data>>16) & 0xff;
//	se[0xf]=(data>>24) & 0xff;

//	for(i=0;i<16;i++)
//	{
//		_WRDATA(se[i]);	// Write spare array(ECC and Mark)
//	}  

	_CMD(0x10);   // Write 2nd command

	for(i=0;i<10;i++);  //tWB = 100ns. ////??????
	_WaitRB();    //wait tPROG 200~500us;

	_CMD(0x70);   // Read status command   

	for(i=0;i<3;i++);  //twhr=60ns

	if(_RDDATA()&0x1) // Page write error
	{	
		NAND_MarkBadBlock(block);
		rc= 0;
	}
	else 
	{
		rc= 1;
	}
//	_SetECCLOCK();
	NAND_Close();
	return(rc);
}


int NAND_IsBadBlock(unsigned block)
{
	unsigned blockPage;
	unsigned char data;
	
	NAND_Open();
	blockPage = (block << 5);	    /* For 2'nd cycle I/O[7:5]                  */
	
	_CMD(0x50);		            /* Spare array read command                 */

	_ADDR((NAND_PAGE_SIZE+0x05)& 0xf);		        /* Read the mark of bad block in spare      */
	_ADDR(blockPage & 0xff);	    /* The mark of bad block is in 0 page       */
	_ADDR((blockPage >>  8) & 0xff);  /* For block number A[24:17]            */
	
	_WaitRB();	                /* Wait tR(max 12us)                        */
	
	data = (unsigned char)_RDDATA();
	NAND_Close();
	return ((data != 0xff) ? 1 : 0);
}



int NAND_EraseBlock(unsigned int block)
{
	unsigned int blockPage=(block+ START_BLOCK)<<5;
	int i,rc;

	NAND_Open();
	_CMD(0x60);   // Erase one block 1st command

	_ADDR(blockPage&0xff);	    // Page number=0
	_ADDR((blockPage>>8)&0xff);   
	_ADDR((blockPage>>16)&0xff);   

	_CMD(0xd0);   // Erase one blcok 2nd command

	for(i=0;i<10;i++); //wait tWB(100ns)//??????

	_WaitRB();    // Wait tBERS max 3ms.
	_CMD(0x70);   // Read status command

	if (_RDDATA()&0x1) // Erase error
	{	
		rc= 0;
	}
	else 
	{
		rc= 1;
	}
	NAND_Close();
	return(rc);
}
int NAND_Write(unsigned int Sector,unsigned char *buffer,int len)
{
	int	i,j;
	int	block= Sector/32+ START_BLOCK;
	int	eblock= Sector/32;
	int	page= Sector%32;
	int	pageCnt;
	int	pageByteCnt;
	int	rc= 1;

	while(len > 0){
		pageCnt= NAND_PAGE_PER_BLOCK-page;
		pageByteCnt= pageCnt*NAND_PAGE_SIZE;
		if(len <= pageByteCnt){
			pageCnt= len/NAND_PAGE_SIZE;
			if(len%NAND_PAGE_SIZE){	pageCnt++;	}
			pageByteCnt= pageCnt*NAND_PAGE_SIZE;
		}
		//1 Block Read
		for(i= 0; i < NAND_PAGE_PER_BLOCK; i++){
			rc= NAND_ReadPage(block,i,NandBlockBuff[i]);
			if(rc == 0){	break;	}
		}
		//Eraze
		NAND_EraseBlock(eblock++);
		//Copy to RAM
		for(i= 0; i < pageCnt; i++){
			for(j= 0; j < NAND_PAGE_SIZE; j++){
				NandBlockBuff[page][j]= *buffer++;
			}
			page++;
		}
		for(i= 0; i < NAND_PAGE_PER_BLOCK; i++){
			rc= NAND_WritePage(block,i,NandBlockBuff[i]);
			if(rc == 0){	break;	}
		}
		len -= pageByteCnt;
		block++;
		page= 0;
	}
	return(rc);
}
int NAND_Read(unsigned int Sector,unsigned char *buffer,int len)
{
	int	i;
	int	block= Sector/32+ START_BLOCK;
	int	page= Sector%32;
	int	pageCnt;
	int	rc= 1;

	pageCnt= len/NAND_PAGE_SIZE;
	if(len%NAND_PAGE_SIZE){	pageCnt++;	}
	//Block Read
	for(i= 0; i < pageCnt; ){
		rc= NAND_ReadPage(block,page%NAND_PAGE_PER_BLOCK,buffer);
		if(rc == 0){	break;	}
		buffer += NAND_PAGE_SIZE;
		i++;
		page++;
		if((page%NAND_PAGE_PER_BLOCK) == 0){
			block++;
			page= 0;
		}
	}
	return(rc);
}

#else

NAND_REG	*nandCtl;

#define _CNT(ctl)		   {nandCtl->rNFCONT=ctl;}
#define _CMD(cmd)		   {nandCtl->u1.rNFCMMD=cmd;}
#define _ADDR(addr) 	   {nandCtl->u2.rNFADDR=addr;}	
#define _RstECC()		   {nandCtl->rNFCONT|=(1<<4);}
#define _RstECCLOCK()	   {nandCtl->rNFCONT&=~((1<<6)|(1<<5));}
#define _SetECCLOCK()	   {nandCtl->rNFCONT|=((1<<6)|(1<<5));}
#define _RDDATA() 		(nandCtl->u3.rNFDATA)
#define _WRDATA(data) 	{nandCtl->u3.rNFDATA=data;}
#define _GetRDY() 		(nandCtl->rNFSTAT & 0x01)

#define _WaitRB()    	{while(!(nandCtl->u4.rNFSTAT&(1<<0)));}



void NAND_Reset(void)
{
	volatile int i;

	_CMD(CMD_RESET);	//reset command

	for(i=0;i<10;i++);  //tWB = 100ns. //??????

	_WaitRB();      //wait 200~500us;
}
void NAND_Init(void)
{
#ifdef	WIN32
	return;
#endif
	nandCtl= (NAND_REG*)NAND_BASE_PHYS;
//	rNFCONF=(1<<15)|(1<<14)|(1<<13)|(1<<12)|(1<<11)|(0<<8)|(3<<4)|(0<<0);
	nandCtl->rNFCONF=(0x3<<12)|(0x7<<8)|(0x7<<4)|(0x0<<0);
	nandCtl->rNFCONT=(0x0<<13)|(0x0<<12)|(0x0<<10)|(0x0<<9)|(0x0<<8)|(0x1<<6)|(0x1<<5)|(0x1<<4)|(0x1<<1)|(0x1<<0);

	NAND_Reset();
}
void NAND_Open(void)
{
	unsigned int	ctl;

#ifdef	WIN32
	return;
#endif
	ctl= nandCtl->rNFCONT;
	ctl &= ~(1<<1);
	_CNT(ctl);
}
void NAND_Close(void)
{
	unsigned int	ctl;

	ctl= nandCtl->rNFCONT;
	ctl |= (1<<1);
	_CNT(ctl);
}




void NAND_ReadID(unsigned char* buff)
{
	volatile int i;
//	unsigned int data;

#ifdef	WIN32
	return;
#endif
	NAND_Open();
	_CMD(CMD_READ_ID);
	_ADDR(0x0);

	for(i=0;i<10;i++); //wait tWB(100ns)////?????

	buff[0] = (unsigned char)_RDDATA();	// Maker code       (K9D1G08V0X:0xec)
	buff[1] = (unsigned char)_RDDATA();	// Device code      (K9D1G08V0X:0x76)
	buff[2] = (unsigned char)_RDDATA();	// UniquelID code   (K9D1G08V0X:0xa5)
	buff[3] = (unsigned char)_RDDATA();	// Multi Plane code (K9D1G08V0X:0xc0)

	NAND_Close();
}

int NAND_MarkBadBlock(int block)
{
	int i,rc;
	unsigned int blockPage=(block<<5);

	NAND_Open();
	_CMD(0x50);		            /* Spare array read command                 */
	_CMD(0x80);   // Write 1st command

	_ADDR((NAND_PAGE_SIZE+0x05)& 0xf);		        /* Read the mark of bad block in spare      */
	_ADDR(blockPage & 0xff);	    /* The mark of bad block is in 0 page       */
	_ADDR((blockPage >>  8) & 0xff);  /* For block number A[24:17]            */
	_ADDR((blockPage >>  16) & 0xff);  /* For block number A[24:17]            */

	_WRDATA(0x00);	// Write spare array(ECC and Mark)

	_CMD(0x10);   // Write 2nd command

	for(i=0;i<10;i++);  //tWB = 100ns. ////??????
	_WaitRB();    //wait tPROG 200~500us;

	_CMD(0x70);   // Read status command   

	for(i=0;i<3;i++);  //twhr=60ns

	if(_RDDATA()&0x1) // Page write error
	{	
		rc= 0;
	}
	else 
	{
		rc= 1;
	}
	NAND_Close();
	return(rc);
}

int NAND_ReadPage(unsigned int block,unsigned int page,unsigned char *buffer)
{
	int i;
	unsigned int blockPage;
	unsigned char *bufPt=buffer;
	unsigned int	ecc0;
	unsigned int	ecc1;
	unsigned char se[16];
	unsigned char rse[8];

#ifdef	WIN32
	return 0;
#endif

	NAND_Open();

	_RstECC();

	_RstECCLOCK();

	page=page&0x1f;
	blockPage=(block<<5)+page;

	_CMD(CMD_READ_A);   // Read command

	_ADDR(0);	    // Column = 0
	_ADDR(blockPage&0xff);	    //
	_ADDR((blockPage>>8)&0xff);   // Block & Page num.
	_ADDR((blockPage>>16)&0xff);   // Block & Page num.

	for(i=0;i<10;i++); //wait tWB(100ns)/////??????
	_WaitRB();    // Wait tR(max 12us)


	for(i=0x0000;i<0x0200;i++){
		*bufPt++ = (unsigned char)_RDDATA();
	}

	ecc0= nandCtl->rNFMECC0;
	ecc1= nandCtl->rNFMECC1;

	for(i=0x00;i<0x10;i++)
	{
		se[i] = (unsigned char)_RDDATA();
	}


	_SetECCLOCK();
	NAND_Close();

	rse[0]=ecc0 & 0xff;
	rse[1]=(ecc0>>8) & 0xff;
	rse[2]=(ecc0>>16) & 0xff;
	rse[3]=(ecc0>>24) & 0xff;

	rse[4]=ecc1 & 0xff;
	rse[5]=(ecc1>>8) & 0xff;
	rse[6]=(ecc1>>16) & 0xff;
	rse[7]=(ecc1>>24) & 0xff;

	if( rse[0]==se[0x08] && rse[1]==se[0x09] && rse[2]==se[0x0a] && rse[3]==se[0x0b] &&
		rse[4]==se[0x0c] && rse[5]==se[0x0d] && rse[6]==se[0x0e] && rse[7]==se[0x0f] )
	{
		return 1;
	}else{
		return 0;
	}
}

int NAND_ReadPage_ECC(unsigned int block,unsigned int page,unsigned char *buffer)
{
	int i;
	unsigned int blockPage;
	unsigned char *bufPt=buffer;
//	unsigned int	ecc0;
//	unsigned int	ecc1;
//	unsigned char se[16];
//	unsigned char rse[8];

	NAND_Open();

//	_RstECC();

	page=page&0x1f;
	blockPage=(block<<5)+page;

	_CMD(CMD_READ_A);   // Read command

	_ADDR(0);	    // Column = 0
	_ADDR(blockPage&0xff);	    //
	_ADDR((blockPage>>8)&0xff);   // Block & Page num.
	_ADDR((blockPage>>16)&0xff);   // Block & Page num.

	for(i=0;i<10;i++); //wait tWB(100ns)/////??????
	_WaitRB();    // Wait tR(max 12us)


	for(i=0x0000;i<0x0210;i++){
		*bufPt++ = (unsigned char)_RDDATA();
	}

//	ecc0= nandCtl->rNFMECC0;
//	ecc1= nandCtl->rNFMECC1;

//	for(i=0x00;i<0x10;i++)
//	{
//		se[i] = (unsigned char)_RDDATA();
//	}


	NAND_Close();

//	rse[0]=ecc0 & 0xff;
//	rse[1]=(ecc0>>8) & 0xff;
//	rse[2]=(ecc0>>16) & 0xff;
//	rse[3]=(ecc0>>24) & 0xff;

//	rse[4]=ecc1 & 0xff;
//	rse[5]=(ecc1>>8) & 0xff;
//	rse[6]=(ecc1>>16) & 0xff;
//	rse[7]=(ecc1>>24) & 0xff;

//	if( rse[0]==se[0x08] && rse[1]==se[0x09] && rse[2]==se[0x0a] && rse[3]==se[0x0b] &&
//		rse[4]==se[0x0c] && rse[5]==se[0x0d] && rse[6]==se[0x0e] && rse[7]==se[0x0f] )
//	{
		return 1;
//	}else{
//		return 0;
//	}
}

int NAND_WritePage(unsigned int block,unsigned int page,unsigned char *buffer)
{
	int i,rc;
	unsigned int blockPage=(block<<5)+page;
	unsigned char *bufPt=buffer;
	unsigned char se[16];	   
	unsigned int	data;

#ifdef	WIN32
	return 0;
#endif
	memset(se,0,sizeof(se));

//if(block == 0){	return(0);	}

	se[5]= 0xff;
	NAND_Open();

	_RstECC();
	_RstECCLOCK();

	_CMD(0x00);		//??????
	_CMD(0x80);   // Write 1st command

	_ADDR(0);			    // Column 0
	_ADDR(blockPage&0xff);	    //
	_ADDR((blockPage>>8)&0xff);   // Block & page num.
	_ADDR((blockPage>>16)&0xff);   // Block & page num.

	for(i=0;i<512;i++)
	{
		_WRDATA(*bufPt++);	// Write one page to NFM from buffer

	}  
	se[5]=0xff;		// Marking good block
	
	data= nandCtl->rNFMECC0;
	se[0x8]=data & 0xff;
	se[0x9]=(data>>8) & 0xff;
	se[0xa]=(data>>16) & 0xff;
	se[0xb]=(data>>24) & 0xff;

	data= nandCtl->rNFMECC1;
	se[0xc]=data & 0xff;
	se[0xd]=(data>>8) & 0xff;
	se[0xe]=(data>>16) & 0xff;
	se[0xf]=(data>>24) & 0xff;

	for(i=0;i<16;i++)
	{
		_WRDATA(se[i]);	// Write spare array(ECC and Mark)
	}  

	_CMD(0x10);   // Write 2nd command

	for(i=0;i<10;i++);  //tWB = 100ns. ////??????
	_WaitRB();    //wait tPROG 200~500us;

	_CMD(0x70);   // Read status command   

	for(i=0;i<3;i++);  //twhr=60ns

	if(_RDDATA()&0x1) // Page write error
	{	
		NAND_MarkBadBlock(block);
		rc= 0;
	}
	else 
	{
		rc= 1;
	}
	_SetECCLOCK();
	NAND_Close();
	return(rc);
}

int NAND_IsBadBlock(unsigned block)
{
	int		i;
	unsigned blockPage;
	unsigned char data;
	
	NAND_Open();
	blockPage = (block << 5);	    /* For 2'nd cycle I/O[7:5]                  */
	
	_CMD(0x50);		            /* Spare array read command                 */

	_ADDR((NAND_PAGE_SIZE+0x05)& 0xf);		        /* Read the mark of bad block in spare      */
	_ADDR(blockPage & 0xff);	    /* The mark of bad block is in 0 page       */
	_ADDR((blockPage >>  8) & 0xff);  /* For block number A[24:17]            */
	_ADDR((blockPage >>  16) & 0xff);  /* For block number A[24:17]            */
	
	for(i=0;i<10;i++); //wait tWB(100ns)//??????
	_WaitRB();	                /* Wait tR(max 12us)                        */
	
	data = (unsigned char)_RDDATA();
	NAND_Close();
	return ((data != 0xff) ? 1 : 0);
}



int NAND_EraseBlock(unsigned int block)
{
	unsigned int blockPage=block<<5;
	int i,rc;

	NAND_Open();
	_CMD(0x60);   // Erase one block 1st command

	_ADDR(blockPage&0xff);	    // Page number=0
	_ADDR((blockPage>>8)&0xff);   
	_ADDR((blockPage>>16)&0xff);   

	_CMD(0xd0);   // Erase one blcok 2nd command

	for(i=0;i<10;i++); //wait tWB(100ns)//??????

	_WaitRB();    // Wait tBERS max 3ms.
	_CMD(0x70);   // Read status command

	if (_RDDATA()&0x1) // Erase error
	{	
		NAND_Close();
		NAND_MarkBadBlock(block);
		rc= 0;
	}
	else 
	{
		NAND_Close();
		rc= 1;
	}
	return(rc);
}
int	GetRealBlock(int block)
{
	int	i;
	RANDOM_MAP*	BadInf;
	START_MAP* StartBad;

#ifdef	WIN32
	return 0;
#endif
	BadInf= (RANDOM_MAP*)&NandBadblockMap.RandomMap;
	for(i= 0; i < BadInf->ChangeBadCnt; i++){
		if(block == BadInf->chgInf[i].Original){
			block= BadInf->chgInf[i].NewNo;
			break;
		}
	}
	if(i >= BadInf->ChangeBadCnt){
		StartBad= (START_MAP*)&NandBadblockMap.StartBadblock;
		for(i= 0; i < StartBad->StartBadCnt; i++){
			if(block >= StartBad->BadNo[i]){
				block++;
			}
		}
	}
	return(block);
}
int	GetReserveBlock(int block)
{
	int	i;
	RANDOM_MAP*	BadInf;
//	START_MAP* StartBad;

	BadInf= (RANDOM_MAP*)&NandBadblockMap.RandomMap;
	for(i= 0; i < BadInf->ChangeBadCnt; i++){
		if(block == BadInf->chgInf[i].Original){		//Same No
			BadInf->chgInf[i].NewNo= BadInf->ReserveStartNo++;
			block= BadInf->chgInf[i].NewNo;
			break;
		}
	}
	if(i >= BadInf->ChangeBadCnt){						//New
		BadInf->chgInf[i].NewNo= BadInf->ReserveStartNo++;
		block= BadInf->chgInf[i].NewNo;
	}
//	StartBad= (START_MAP*)&NandBadblockMap.StartBadblock;
//	for(i= 0; i < StartBad->StartBadCnt; i++){
//		if(block >= StartBad->BadNo[i]){
//			block++;
//		}
//	}
	return(block);
}
int	errFlag;
int NAND_Write_Random(unsigned int Sector,unsigned char *buffer,int len)
{
	int	i,j;
	int	block= Sector/NAND_PAGE_PER_BLOCK;
//	int	eblock= Sector/NAND_PAGE_PER_BLOCK;
	int	page= Sector%NAND_PAGE_PER_BLOCK;
	int	pageCnt;
	int	pageByteCnt;
	int	rc= 1;
	int	RealBlock;
	int	ChangeFlag;

#ifdef	WIN32
	return 0;
#endif
	ChangeFlag= 0;
	while(len > 0){
		pageCnt= NAND_PAGE_PER_BLOCK-page;
		pageByteCnt= pageCnt*NAND_PAGE_SIZE;
		if(len <= pageByteCnt){
			pageCnt= len/NAND_PAGE_SIZE;
			if(len%NAND_PAGE_SIZE){	pageCnt++;	}
			pageByteCnt= pageCnt*NAND_PAGE_SIZE;
		}
		RealBlock= GetRealBlock(block);
		//1 Block Read
		for(i= 0; i < NAND_PAGE_PER_BLOCK; i++){
			rc= NAND_ReadPage(RealBlock,i,NandBlockBuff[i]);
			if(rc == 0){	break;	}
			for(j=0;j<100;j++); //wait tWB(100ns)//??????
		}
		//Copy to RAM
		for(i= 0; i < pageCnt; i++){
			for(j= 0; j < NAND_PAGE_SIZE; j++){
				NandBlockBuff[page][j]= *buffer++;
			}
			page++;
		}
		while(1){
			//Eraze
			if(NAND_EraseBlock(RealBlock) == 1){	//Erase OK
				for(i= 0; i < NAND_PAGE_PER_BLOCK; i++){
					rc= NAND_WritePage(RealBlock,i,NandBlockBuff[i]);
					if(rc == 0){	break;	}
				}
				if(rc == 1){						//Write OK
					break;
				}
			}
			RealBlock= GetReserveBlock(block);
			ChangeFlag= 1;
			for(j=0;j<100;j++); //wait tWB(100ns)//??????
		}
		len -= pageByteCnt;
		block++;
		page= 0;
		for(j=0;j<100;j++); //wait tWB(100ns)//??????
	}
	if(ChangeFlag == 1){			//MAP Write
		NAND_Write_Seq(NAND_MAP_AREA/NAND_PAGE_SIZE,(unsigned char*)&NandBadblockMap,0x400);
	}
	if(RealBlock == 0xc82){
		errFlag= 1;
	}else{
		errFlag= 0;
	}
	return(rc);
}
int NAND_Read_Random(unsigned int Sector,unsigned char *buffer,int len)
{
	int	i,j;
	int	block= Sector/NAND_PAGE_PER_BLOCK;
	int	page= Sector%NAND_PAGE_PER_BLOCK;
	int	pageCnt;
	int	rc= 1;
	int	RealBlock;

#ifdef	WIN32
	return 0;
#endif
	pageCnt= len/NAND_PAGE_SIZE;
	if(len%NAND_PAGE_SIZE){	pageCnt++;	}
	//Block Read
	for(i= 0; i < pageCnt; ){
		RealBlock= GetRealBlock(block);
		rc= NAND_ReadPage(RealBlock,page%NAND_PAGE_PER_BLOCK,buffer);
		if(rc == 0){	break;	}
		buffer += NAND_PAGE_SIZE;
		i++;
		page++;
		if((page%NAND_PAGE_PER_BLOCK) == 0){
			block++;
			RealBlock= GetRealBlock(block);
			page= 0;
		}
		for(j=0;j<100;j++); //wait tWB(100ns)//??????
	}
	return(rc);
}
int	CheckStartBlock(int block)
{
	int	i,j;
	int	wBlock;

	if(block > 0){
		for(i= 0,wBlock= 0; ; i++){
			if(NAND_IsBadBlock(i) == 0){
				if(wBlock == block){		//0�@Block ����@�Y��Block Search
					block= i;				//���ۂ�Block
					break;
				}
				wBlock++;
			}
			for(j=0;j<100;j++); //wait tWB(100ns)//??????
		}
	}
	return(block);
}
int NAND_Write_Seq(unsigned int Sector,unsigned char *buffer,int len)
{
	int	i,j;
	int	block= Sector/NAND_PAGE_PER_BLOCK;
	int	page= Sector%NAND_PAGE_PER_BLOCK;
	int	pageCnt;
	int	pageByteCnt;
	int	rc= 1;

#ifdef	WIN32
	return 0;
#endif
	while(len > 0){
		pageCnt= NAND_PAGE_PER_BLOCK-page;
		pageByteCnt= pageCnt*NAND_PAGE_SIZE;
		if(len <= pageByteCnt){
			pageCnt= len/NAND_PAGE_SIZE;
			if(len%NAND_PAGE_SIZE){	pageCnt++;	}
			pageByteCnt= pageCnt*NAND_PAGE_SIZE;
		}
		block= CheckStartBlock(block);		//Start Block Check
		//1 Block Read
		for(i= 0; i < NAND_PAGE_PER_BLOCK; i++){
			rc= NAND_ReadPage(block,i,NandBlockBuff[i]);
			if(rc == 0){	break;	}
			for(j=0;j<100;j++); //wait tWB(100ns)//??????
		}
		//Copy to RAM
		for(i= 0; i < pageCnt; i++){
			for(j= 0; j < NAND_PAGE_SIZE; j++){
				NandBlockBuff[page][j]= *buffer++;
			}
			page++;
		}
		while(1){
			//Eraze
			if(NAND_EraseBlock(block) == 1){		//Eraze OK
				for(i= 0; i < NAND_PAGE_PER_BLOCK; i++){
					rc= NAND_WritePage(block,i,NandBlockBuff[i]);
					if(rc == 0){	break;	}						//Write Error
				}
				if(rc == 1){	break;	}			//Write OK
			}
			block++;
		}
		len -= pageByteCnt;
		block++;
		page= 0;
	}
	return(rc);
}
int NAND_Read_Seq(unsigned int Sector,unsigned char *buffer,int len)
{
	int	i,j;
	int	block= Sector/NAND_PAGE_PER_BLOCK;
	int	page= Sector%NAND_PAGE_PER_BLOCK;
	int	pageCnt;
	int	rc= 1;

#ifdef	WIN32
	return 0;
#endif
	pageCnt= len/NAND_PAGE_SIZE;
	if(len%NAND_PAGE_SIZE){	pageCnt++;	}

	block= CheckStartBlock(block);		//Start Block Check
	//Block Read
	for(i= 0; i < pageCnt; ){
		rc= NAND_ReadPage(block,page%NAND_PAGE_PER_BLOCK,buffer);
		if(rc == 0){	break;	}
		buffer += NAND_PAGE_SIZE;
		i++;
		page++;
		if((page%NAND_PAGE_PER_BLOCK) == 0){
			block++;
			page= 0;
			while(1){
				if(NAND_IsBadBlock(block) == 0){
					break;
				}
				block++;
				for(j=0;j<100;j++); //wait tWB(100ns)//??????
			}
		}
		for(j=0;j<100;j++); //wait tWB(100ns)//??????
	}
	return(rc);
}

int NAND_Read_ECC(unsigned int Sector,unsigned char *buffer,int len)
{
	int	i,j;
	int	block= Sector/NAND_PAGE_PER_BLOCK;
	int	page= Sector%NAND_PAGE_PER_BLOCK;
	int	pageCnt;
	int	rc= 1;

#ifdef	WIN32
	return 0;
#endif
	pageCnt= len/NAND_PAGE_SIZE;
	if(len%NAND_PAGE_SIZE){	pageCnt++;	}
	//Block Read
	for(i= 0; i < pageCnt; ){
		rc= NAND_ReadPage_ECC(block,page%NAND_PAGE_PER_BLOCK,buffer);
		if(rc == 0){	break;	}
		buffer += NAND_PAGE_SIZE+16;
		i++;
		page++;
		if((page%NAND_PAGE_PER_BLOCK) == 0){
			block++;
			page= 0;
		}
		for(j=0;j<500;j++); //wait tWB(100ns)//??????

	}
	return(rc);
}

#endif



