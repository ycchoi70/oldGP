#define	CMD_READ_A		0x00
#define	CMD_READ_B		0x01
#define	CMD_PAGEPROG	0x10
#define	CMD_READ_C		0x50
#define	CMD_ERASE1		0x60
#define	CMD_READ_STS	0x70
#define	CMD_SEQIN		0x80
#define	CMD_READ_ID		0x90
#define	CMD_ERASE2		0xd0
#define	CMD_RESET		0xff

//#define	START_BLOCK		64*4
#define	START_BLOCK		0

#define NAND_PAGE_SIZE		512
#define	NAND_PAGE_PER_BLOCK	32


#define FRAFH1_FILE_OFFSET              (0x00200000/NAND_PAGE_SIZE)
#define FRAFH2_FILE_OFFSET              (0x01200000/NAND_PAGE_SIZE)
#define FRAFH3_FILE_OFFSET              (0x03200000/NAND_PAGE_SIZE)

#define	NAND_MAP_AREA		0x00003000		//Bad Block Map
#define	NAND_RESERVED_AREA	0x03F00000		//

/*
 * Standard NAND flash commands
 */
//#define NAND_CMD_READ0		0
//#define NAND_CMD_READ1		1
//#define NAND_CMD_RNDOUT		5
//#define NAND_CMD_PAGEPROG	0x10
//#define NAND_CMD_READOOB	0x50
//#define NAND_CMD_ERASE1		0x60
//#define NAND_CMD_STATUS		0x70
//#define NAND_CMD_STATUS_MULTI	0x71
//#define NAND_CMD_SEQIN		0x80
//#define NAND_CMD_RNDIN		0x85
//#define NAND_CMD_READID		0x90
//#define NAND_CMD_ERASE2		0xd0
//#define NAND_CMD_RESET		0xff
/* Extended commands for large page devices */
//#define NAND_CMD_READSTART	0x30
//#define NAND_CMD_RNDOUTSTART	0xE0
//#define NAND_CMD_CACHEDPROG	0x15

typedef struct{
	char	pass[16];
	int		StartBadCnt;
	int		BadNo[123];
}START_MAP;
typedef struct{
	int	ChangeBadCnt;
	int	ReserveStartNo;
	struct{
		int	Original;
		int	NewNo;
	}chgInf[63];
}RANDOM_MAP;

#ifdef	NAND_PROC
	unsigned char	NandBlockBuff[NAND_PAGE_PER_BLOCK][NAND_PAGE_SIZE];
	struct{
		START_MAP	StartBadblock;
		RANDOM_MAP	RandomMap;
	}NandBadblockMap;
#else
	extern	unsigned char	NandBlockBuff[NAND_PAGE_PER_BLOCK][NAND_PAGE_SIZE];
	extern	struct{
				START_MAP	StartBadblock;
				RANDOM_MAP	RandomMap;
			}NandBadblockMap;
#endif

void NAND_Init(void);
void NAND_ReadID(unsigned char* buff);
void NAND_Open(void);
int NAND_ReadPage(unsigned int block,unsigned int page,unsigned char *buffer);
int NAND_WritePage(unsigned int block,unsigned int page,unsigned char *buffer);
int NAND_EraseBlock(unsigned int block);
int NAND_Read_Random(unsigned int Sector,unsigned char *buffer,int len);
int NAND_Write_Random(unsigned int Sector,unsigned char *buffer,int len);
int NAND_Read_Seq(unsigned int Sector,unsigned char *buffer,int len);
int NAND_Write_Seq(unsigned int Sector,unsigned char *buffer,int len);
int NAND_IsBadBlock(unsigned block);

int	MakeFatFsNand( int hDev, unsigned int nFat, unsigned int FatType, unsigned int nRootDirEntry, unsigned int nSecotorPerCluster );



int NAND_Read_ECC(unsigned int Sector,unsigned char *buffer,int len);
int NAND_ReadPage_ECC(unsigned int block,unsigned int page,unsigned char *buffer);
