
#define	FLASH_PROC
#include	<string.h>

#include	"define.h"
#include	"typedefs.h"
#include	"rvd.h"
#include	"deviceid.h"
#include	"s2440.h"
#include	"nand.h"
#include	"flash.h"

#ifdef	WIN32
void	_ei(void)
{
}
void	_di(void)
{
}
#endif
/********************************************************
*   FUNC  : Flash Rom Write                         	*
*	In    :												*
*	Out   : 											*
*   AUTHOR : M.Owashi                                	*
*   DATE  : 1996.8.28                               	*
*   DATE  : 1996.8.28									*
*	Update:97.03.13 kf									*
*********************************************************/
void	FlashEraze(char *addr, long count)
{
	int	block;
	int	cnt;

	block= ((int)addr/512)/32;
	cnt= 512*32;
	if((int)addr % cnt){	count-= ((int)addr % cnt);	}
	else{					count-= cnt;				}
	NAND_EraseBlock(block++);
	while(count > 0){
		NAND_EraseBlock(block);
		count-= cnt;
	}

}
void	FlashWriteRandom(char *addr,char *data, long count)
{
	int	sector;

	sector= (int)addr/NAND_PAGE_SIZE;
	NAND_Write_Random(sector,(unsigned char*)data,count);
}
void	FlashReadRandom(char *data,char *addr,long count)
{
	int	sector;

	sector= (int)addr/NAND_PAGE_SIZE;
	NAND_Read_Random(sector,(unsigned char*)data,count);
}
void	FlashWriteSeq(char *addr,char *data, long count)
{
	int	sector;

	sector= (int)addr/NAND_PAGE_SIZE;
	NAND_Write_Seq(sector,(unsigned char*)data,count);
}
void	FlashReadSeq(char *data,char *addr,long count)
{
	int	sector;

	sector= (int)addr/NAND_PAGE_SIZE;
	NAND_Read_Seq(sector,(unsigned char*)data,count);
}

void	FlashRead_ECC(char *data,char *addr,long count)
{
	int	sector;

	sector= (int)addr/NAND_PAGE_SIZE;
	NAND_Read_ECC(sector,(unsigned char*)data,count);
}
void	NAND_Map_Check(void)
{
	int	i,j;
	RANDOM_MAP*	BadInf;
	START_MAP* StartBad;

#ifdef	WIN32
	return;
#endif
	NAND_Read_Seq(NAND_MAP_AREA/NAND_PAGE_SIZE,(unsigned char*)&NandBadblockMap,0x400);
	if(strcmp(&NandBadblockMap.StartBadblock.pass[0],NAND_BADMAP_PASS) == 0){	return;	}
	//Make Bad Map
	memset(&NandBadblockMap,0xff,sizeof(NandBadblockMap));
	//Start Bad Info
	StartBad= (START_MAP*)&NandBadblockMap.StartBadblock;
	strcpy(StartBad->pass,NAND_BADMAP_PASS);
	StartBad->StartBadCnt= 0;
	for(i= 0; i < 4096; i++){
		if(NAND_IsBadBlock(i) == 1){
			StartBad->BadNo[StartBad->StartBadCnt++]= i;
		}
		for(j=0;j<100;j++); //wait tWB(100ns)//??????
	}
	//Random Area
	BadInf= (RANDOM_MAP*)&NandBadblockMap.RandomMap;
	BadInf->ChangeBadCnt= 0;
	BadInf->ReserveStartNo= NAND_RESERVED_AREA/NAND_PAGE_SIZE/NAND_PAGE_PER_BLOCK;
	NAND_Write_Seq(NAND_MAP_AREA/NAND_PAGE_SIZE,(unsigned char*)&NandBadblockMap,0x400);
}
