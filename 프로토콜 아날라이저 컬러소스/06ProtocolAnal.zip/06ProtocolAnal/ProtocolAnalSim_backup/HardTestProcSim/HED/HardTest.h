typedef struct{
	int	x;
	int	y;
}STRUCT_ADDR;

#define	USB_CMD_TEST		"TEST"
#define	USB_CMD_SET_TIME	"STTM"
#define	USB_CMD_SET_PARA	"STPA"

#define	AUT_TOUCH_TEST		0
#define	AUT_LCD_PTN1_TEST	1
#define	AUT_LCD_PTN2_TEST	2
#define	AUT_LCD_PTN3_TEST	3
#define	AUT_LCD_PTN4_TEST	4
#define	AUT_LCD_PTN5_TEST	5
#define	AUT_SRAM_TEST		6
#define	AUT_DRAM_TEST		7
#define	AUT_NAND_TEST		8
#define	AUT_I_O_TEST		9
#define	AUT_LED_TEST		10
#define	AUT_SWITCH_TEST		11
#define	AUT_BUZZER_TEST		12
#define	AUT_BACKL_TEST		13
#define	AUT_BATT_TEST		14

#define	AUT_TCP_TEST		17
#define	AUT_232C_TEST		18
#define	AUT_USB_TEST		19
#define	AUT_SEQ_MAC_TEST	20
#define	AUT_DATE_TIME_TEST	21
#define	AUT_RTC_TEST		22




#ifdef	HARDTEST_PROC
	int	TestColor[9]={T_RED,T_GREEN,T_BLUE,T_BLACK,T_WHITE,T_RED_INV,T_GREEN_INV,T_BLUE_INV,T_WHITE};
	int Test_Flag[30]={-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};

//{Touch, Red, Green, Blue, Black, White, SRAM, SDRAM, NAND FLASH, I/O Port, 
//LED, Switch, Buzzer, Backlight, Battery, W5100, TCP, UDP, RS-232C/RS-422, USB,
//SEQ No./MAC Address, Time}

	STRUCT_ADDR	CalibAddr[5]= {{100,100},{100,400},{700,100},{700,400},{350,250}};
	
	char*	PwmKind[6]={	"Pwm_Timer0","Pwm_Timer1","Pwm_Timer2","Pwm_Timer3","Clkout0","Clkout1"	};
	char*	SrcKind[6]={	"MPLL","UPLL","FCLK","HCLK","PCLK","DCLK"	};
	char*	color[5]={" RED ","GREEN"," BLUE","BLACK","WHITE"};
	TCAL_DATA	CalibData[2];
	TCAL_DATA	InCalibData[5];
	unsigned char	fReadBuff[0x200];
	unsigned char	UsbWriteBuff[0x200];
	unsigned char	UsbReadBuff[0x200];

//	STRUCT_ADDR	CalibAddrArea[4][2]= {
//		{
//			{181,302},{202,330},
//		},
//		{
//			{180,744},{201,772},
//		},
//		{
//			{819,298},{839,327},
//		},
//		{
//			{820,741},{839,770},
//		},
//	};

//	STRUCT_ADDR	CalibAddrArea[4][2]= {
//		{
//			{171,272},{202,331},
//		},
//		{
//			{169,744},{201,781},
//		},
//		{
//			{818,275},{851,327},
//		},
//		{
//			{821,743},{852,778},
//		},
//	};

// (50,80), (50,60), (50,80), (50,60)
#ifdef	WIN32
	STRUCT_ADDR	CalibAddrArea[4][2]= {
		{
			{80,80},{110,110},
		},
		{
			{80,390},{110,410},
		},
		{
			{690,80},{710,110},
		},
		{
			{690,390},{710,410},
		},
	};
#else
#ifdef	OLD
	STRUCT_ADDR	CalibAddrArea[4][2]= {
		{
			{143,273},{223,321},
		},
		{
			{143,735},{223,799},
		},
		{
			{797,272},{877,320},
		},
		{
			{800,747},{880,795},
		},
	};
#else
	//CalibAddr +- 10 ���� ����	
	/*
	STRUCT_ADDR	CalibAddrArea[4][2]= {
		{
			{90, 90},{110,110},
		},
		{
			{90,390},{110,410},
		},
		{
			{590,90},{610,110},
		},
		{
			{590,390},{610,410},
		},
	};
	*/		
	STRUCT_ADDR	CalibAddrArea[4][2]= {
		{
			{114,218},{267,385},
		},
		{
			{114,588},{267,958},
		},
		{
			{637,217},{1052,384},
		},
		{
			{640,597},{1056,954},
		},
	};
		
#endif
#endif


	int	BatteryAdStart;			//2011.1.25
	int	BatteryAdOk;
	int	BatteryADValue;
#else
	extern	int	BatteryAdStart;			//2011.1.25
	extern	int	BatteryAdOk;
	extern	int	BatteryADValue;
#endif

int	MemoryTest(void);

int	SramTest(void);
int	NandFlashTest(void);
int	SdramTest(void);

void	MemoryTest_t(void);

void	SramTest_t(void);

//int	LcdTest(void);


int	IoTest(void);
void	HardTest(void);


#define	TYPE_BYTE		1
#define	TYPE_WORD		2
#define	TYPE_LONG		4
#define	AGAIN			10

#define DELAY	20000000

extern	void DubugMain( void );
int	ItemResult(int mode,int okpass);

void	DisplayHex(int xPos,int yPos,int RxData);
void	DisplayAscii(int xPos,int yPos,int RxData);
void	vSerialSet(int *iSpeed, int *iData1, int *iStop, int *iParity, int *iData2 );
void	DefaultFormDisplay(short iType, char* TitleName);

