
#include	"s2440.h"

#define	PLC_BUF_MAX	1024

#define	RS_CNTL		0
#define	RS_SEND		1
#define	RS_INIT		0
#define	RS_RTSON	1
#define	RS_RTSOFF	2
#define	RS_300		300
#define	RS_600		600
#define	RS_1200		1200
#define	RS_2400		2400
#define	RS_4800		4800
#define	RS_9600		9600
#define	RS_19200	19200
#define	RS_38400	38400
#define	RS_57600	57600
#define	RS_115200	115200
#define	RS300		0
#define	RS600		1
#define	RS1200		2
#define	RS2400		3
#define	RS4800		4
#define	RS9600		5
#define	RS19200		6
#define	RS38400		7
#define	RS57600		8
#define	RS115200	9
#define	RS_NONE		0
#define	RS_ODD		1
#define	RS_EVEN		2
#define	RS_DATA7	0
#define	RS_DATA8	1
#define	RS_STOP01	0		/* 1 bit */
/* #define	RS_STOP15	1	*/	/* 1.5bit */  
#define	RS_STOP02	1		/* 2 bit */
#define	RS_XONOFF	0
#define	RS_DTRDSR	1
#define	RS_PLC		0
#define	RS_PC		1
#define	RS_USB		2

#define	SYSINTR_COM0	10
#define	SYSINTR_COM1	11
#define	SYSINTR_COM2	12






///////////////////////////////////////////////////////////////////////
//	�����̈�
///////////////////////////////////////////////////////////////////////
typedef struct{
	int					ch;				//Chanel
	int					iINT_RXD;		//(0:1,1:8,2:64)
	int					iIOP_TX;		//Count(0:2,1:4,2:6)
	int					iCLKEN_UART;	//
	int					iIntNo;
	int					iINTSRC_UART;
	volatile UART_REG   *pUART;
	volatile	int		SndCnt;
	volatile	int		SndIdx;
	unsigned char		SndBuff[PLC_BUF_MAX];
	volatile	int		RecInIdx;
	volatile	int		RecOutIdx;
	unsigned char		RecBuff[PLC_BUF_MAX];
}UART_STRUCT;

#ifdef	RS232C_PC
	UART_STRUCT	_Sci0Tbl;
	UART_STRUCT	_Sci1Tbl;
	UART_STRUCT	_Sci2Tbl;

	#ifdef	LOG
	int		volatile	rs1Cnt;
	int		volatile	rs1SaveCnt;
	char	rs1log[2048];
	#endif
#else
	extern	UART_STRUCT	_Sci0Tbl;
	extern	UART_STRUCT	_Sci1Tbl;
#endif


void	SetSci0Tbl(void);
void	SciOpen(UART_STRUCT* SciTbl);
void	SciClose(UART_STRUCT* SciTbl);
void	SciTXIntOpen(UART_STRUCT* SciTbl);
void	SciTXIntClose(UART_STRUCT* SciTbl);
void	InitSci(UART_STRUCT* SciTbl,int speed, int ldata, int parity);
void	InitSci0( int speed, int ldata, int parity );
void	SioRtsOn(UART_STRUCT* pUart);
void	Sio0RtsOn(void);
void	SioRtsOff(UART_STRUCT* pUart);
void	Sio0RtsOff(void);
int	_SciERProc( UART_STRUCT* SciTbl );
void Uart_SendByte(UART_STRUCT* SciTbl,int data);
int	_SciRXInterruptProc( UART_STRUCT* SciTbl );
int	_SciTXInterruptProc( UART_STRUCT* SciTbl );
void	_Sci0InterruptProc( void );
int Sio0SendChar( unsigned char ch );
void	SetSci1Tbl(void);
void	InitSci1( int speed, int ldata, int parity );
void	Sio1RtsOn(void);
void	Sio1RtsOff(void);
void	_Sci1InterruptProc( void );
int Sio1SendChar( unsigned char ch );
void	SetSci2Tbl(void);
void	InitSci2( int speed, int ldata, int parity );
void	Sio2RtsOn(void);
void	Sio2RtsOff(void);
void	_Sci2InterruptProc( void );
int Sio2SendChar( unsigned char ch );
int	IsGetSio0( void );
int	IsGetSio1( void );
int	IsGetSio2( void );
int	GetSio0( void );
int	GetSio1( void );
int	GetSio2( void );
void	ClearSio0Cnt(void);
void	ClearSio1Cnt(void);
void	ClearSio2Cnt(void);


