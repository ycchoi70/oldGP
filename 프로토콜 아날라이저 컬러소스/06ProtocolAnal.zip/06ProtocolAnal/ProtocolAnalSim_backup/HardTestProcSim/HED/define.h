// 1. define�� �� ����
// 2. UDebTask.cpp TVS_VERSION_MES ���� ����

//#define LP_TYPE
#define GP_TYPE

#define	GLP_2480
//#define	GP_3224
//#define	GP_S044

//#define	INTEL_FLASH		//Flah Proc(MySelf)
//#define	SST_FLASH			//SST
#define	AMD_FLASH			//
//#define	FLASH_WRITE	 	1 	 /* 0:0xf000,1:������??��   ������ �δ����� flash write ���α׷� ���� [ ���ķ���Ʈ�� write�� ]  �ڸ�Ʈ�� ���� �ٿ�δ� Flash write ���α׷� ��� */ 
//#define	LOADER_ONLY		1 	 //�������f�o�b�K?���͂���B   �ڸ�Ʈ�� Apl�� ��ȯ




#define S3C2440X_FCLK           399650000                   // 400MHz
#define PCLKDIV                 6						    // P-clock (PCLK) divisor.
#define S3C2440X_PCLK           (S3C2440X_FCLK/PCLKDIV)     // divisor 4

#define CLOCK_1S_FREQ16          (S3C2440X_PCLK/16)		//2,4,8,16




#define	OK	0
#define	NG	-1
#define WAIT 99
#define	ON	1
#define	OFF	0

#ifndef	TRUE
#define	TRUE	1
#define	FALSE	0
#endif

#define	ENQ			0x05
#define	STX			0x02
#define	ETX			0x03
#define	ACK			0x06
#define	NAK			0x15
#define	CR			0x0d
#define	LF			0x0a

#define	F_FILE_AREA	0x000c0000

#define	BAUDRATE9600	92
#define	BAUDRATE19200	46
#define	BAUDRATE38400	22
#define	BAUDRATE57600	15
#define	BAUDRATE115200	7


#define	DEFAULT_SPEED	38400
/*****************************************/
/*	PC Command			                 */
/*****************************************/
#define	PC_DOWNLD	0x0101
#define	PC_COMMON	0x0102
#define	PC_PROJC	0x0103
#define	PC_BASE		0x0104
#define	PC_WINDW	0x0105
#define	PC_UPLOAD	0x0106
#define	PC_PROJHED	0x0107
#define	PC_COMENT	0x0108
#define	PC_PARTS	0x0109
#define	PC_DOWNLDED	0x010A

#define	PC_MODE_DWNLD	0
#define	PC_MODE_DWNOK	1
#define	PC_MODE_UPLD	2
#define	PC_MODE_UPOK	3
#define	PC_MODE_ERR		9

#define		PLC1_PROTOCOL			0x0C1200

#ifdef	GLP_2480		//20070110
	#define		DEF_CONTRAST			50
	#define		DEF_LCDCLK  			55
#endif
#ifdef	GP_S044		//20070110
	#define		DEF_CONTRAST			50
	#define		DEF_LCDCLK  			55
#endif
#ifdef	GP_3224
//	#define		DEF_CONTRAST			120
	#define		DEF_CONTRAST			166
//	#define		DEF_LCDCLK  			10
	#define		DEF_LCDCLK  			17
#endif

//#define	BUZ_HIGH_DEFAULT	3999
//#define BUZ_LOW_DEFAULT	((BUZ_HIGH_DEFAULT/3)-1)

#define	BUZ_HIGH_DEFAULT	2800
#define BUZ_LOW_DEFAULT		2300
/*****************************************/
/*	Common Buffer Area                   */
/*****************************************/
typedef	struct{
	short	DevFlag;		/* 0:Byte,1:Word */
	char	DevName[2];
	int		DevAddress;
	int		DevCnt;
	char	*DevData;
}DEV_DATA;
#define	MAX_EXT_CNT		64
#define	EXT_IO_ADDR		0x28000000
#define	EXT_IO_IO		0x00
#define	EXT_IO_COM		0x10
#define	EXT_IO_TEMP		0x20
#define	EXT_IO_I32O00	0x00
#define	EXT_IO_I28O04	0x01
#define	EXT_IO_I24O08	0x02
#define	EXT_IO_I20O12	0x03
#define	EXT_IO_I16O16	0x04
#define	EXT_IO_I12O20	0x05
#define	EXT_IO_I08O24	0x06
#define	EXT_IO_I04O28	0x07
#define	EXT_IO_I00O32	0x08
typedef struct{
	int	extCnt;				//�O�����
	struct{
		int	ID;				//0:I/O,1:�ʐM���W��?��,2:���x�v,���̑�
		void*	address;	//�擪�A�h���X
	}ExtInfo[MAX_EXT_CNT];
}EXT_IO_INF;

#ifdef	WIN32
#ifdef	MAIN
	unsigned int	FPGA_IP_Area[0x1000];
#else
	extern	unsigned int	FPGA_IP_Area[0x1000];
#endif
	#define IO_START_ADDR	&FPGA_IP_Area[0]
#else
	#define IO_START_ADDR	0x28000000
#endif
//Register Define
#define	FPG_ID_ADDR		0x00
#define	FPG_VERSION		0x02
#define	FPG_IO_A		0x08
#define	FPG_IO_B		0x09
#define	FPG_IO_C		0x0a
#define	FPG_IO_D		0x0b
#define	FPG_PC_REG00	0x10	//Port Control
#define	FPG_PC_REG01	0x11
#define	FPG_PC_REG02	0x12
#define	FPG_PC_REG03	0x13
#define	FPG_PC_REG04	0x14
#define	FPG_PC_REG05	0x15
#define	FPG_PC_REG06	0x16
#define	FPG_PC_REG07	0x17
#define	FPG_FC_REG00	0x20	//Filter Control
#define	FPG_FC_REG01	0x21
#define	FPG_FC_REG02	0x22
#define	FPG_FC_REG03	0x23
#define	FPG_IS_REG00	0x30	//Interrupt Status
#define	FPG_IS_REG01	0x31
#define	FPG_IS_REG02	0x32
#define	FPG_IS_REG03	0x33
#define	FPG_IC_REG00	0x38	//Interrupt Control
#define	FPG_IC_REG01	0x39
#define	FPG_IC_REG02	0x3a
#define	FPG_IC_REG03	0x3b
#define	FPG_HS_REG00	0x40	//High Speed Counter
#define	FPG_HS_REG01	0x41
#define	FPG_HS_REG02	0x42
#define	FPG_HS_REG03	0x43
#define	FPG_HS_REG04	0x44	//High Speed Counter Setting
#define	FPG_HS_REG05	0x45
#define	FPG_HS_REG06	0x46
#define	FPG_HS_REG07	0x47
#define	FPG_HS_REG08	0x48	//High Speed Counter Flag
#define	FPG_SW_REG00	0x4a	//Tenkey Low Data
#define	FPG_SW_REG01	0x4b	//Tenkey Upper Data
#define	FPG_7S_REG00	0x4c	//7seg Data
#define	FPG_7S_REG01	0x4d	//7seg Data
#define	FPG_7S_REG02	0x4e	//7seg Data
#define	FPG_7S_REG03	0x4f	//7seg Data
#define	FPG_PW_REG00	0x50	//Puls Width
#define	FPG_PW_REG01	0x51
#define	FPG_PW_REG02	0x52
#define	FPG_PW_REG03	0x53
#define	FPG_PW_REG04	0x54	//Puls period
#define	FPG_PW_REG05	0x55
#define	FPG_PW_REG06	0x56
#define	FPG_PW_REG07	0x57
#define	FPG_EN_REG00	0x58	//Encode Count Input Register
#define	FPG_EN_REG01	0x59
#define	FPG_EN_REG02	0x5a
#define	FPG_EN_REG03	0x5b
#define	FPG_EN_REG04	0x5c	//Encode Flag Input Register
#define	FPG_SI_REG00	0x70	//Sync Count
#define	FPG_SI_REG01	0x71	//Sync Bit Count
#define	FPG_SI_REG02	0x72	//Sync Data
#define	FPG_DP_REG00	0x80	//Patarn Data


#ifdef	MAIN
	#define	__EXT
#else
	#define	__EXT	extern
#endif

#ifndef	TBQ
#define	TBQ(a)			(sizeof(a)/sizeof(a[0]))
#endif
typedef struct{
	int	PosDigitX;
	int	PosDigitY;
	int	PosAnalogX;
	int	PosAnalogY;
}TCAL_DATA;
typedef struct{
	int Prescaler;
	int Devid;
	int Count;
	int CmpCnt;
}BCAL_DATA;
typedef struct{
	 TCAL_DATA	CalibPos[2];
	 BCAL_DATA	BackCal;
}GLP_CAL_DATA;

typedef struct{
	int		iSpeed;
	int		iData1;
	int		iStop;
	int		iParity;
	int		iData2;
}SERISET;
__EXT SERISET SeriSet;
#define		COM_SETTING_ADDR			0x1FC000
//SRAM
#define	START_SRAM		0x10000000
#define	SRAM_SIZE		0x00080000

#define	START_DRAM		0x30000000
#define	DRAM_SIZE		0x02000000

typedef  struct{			/* Color Data Table */
	unsigned char	b;		//BLUE
	unsigned char	g;		//GREEN
	unsigned char	r;		//RED
	unsigned char	d;		//Dummy
}COLOR_DT;
typedef struct{
	int				year;			/* year[0]:10,year[1]:1 */
	int				mon;			/* mon[0]:10,mon[1]:1 */
	int				day;			/* day[0]:10,day[1]:1 */
	int				week;			/* week               */
	int				hour;			/* hour[0]:10,hour[1]:1 */
	int				min;			/* min[0]:10,min[1]:1 */
	int				sec;			/* sec[0]:10,sec[1]:1 */
} RTC_DATA;
