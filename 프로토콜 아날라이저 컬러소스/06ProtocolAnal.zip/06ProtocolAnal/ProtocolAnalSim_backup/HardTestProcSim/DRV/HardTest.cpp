
#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>

#define	HARDTEST_PROC
#include	"define.h"
#include	"io_define.h"
#include	"glplcd.h"
#include	"CommBuff.h"
#include	"bios.h"
#include	"disp.h"
#include	"rs232c.h"
#include	"lload.h"
#include	"hardtest.h"
#include	"touch.h"
#include	"flash.h"
#include	"w5100driver.h"
#include	"W5100.h"
#include	"socket.h"
#include	"usbh.h"
#include	"udc_2440.h"
#include	"selib.h"
#include	"udebtsk.h"
#include	"types.h"


#ifdef	WIN32
#include    "Mts.h"
#include    "MtsCifp.h"
#include    "Mail.h"
#include	"Taskhed.h"
#endif

int iIsPressed;
int iAutoMenuProcess;
int	ItemResultOKNG(int mode,int type);

extern	uint16	lanRecCnt;
extern	uint8	recBuff[0x2000];
extern	int	TCPTest(int iSendKind);
extern	void	TcpServerTest(void);
extern	void DModeSendMsg( char *ptr );
extern	void	_di(void);
extern	void	_ei(void);

void DrawMainMenu(void);
/////////////////////////////////////////////////////////
int	gatoi(char *buff)
{
	char	c;
	int	ret;
	int flag;

	ret= 0;
	flag= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){
			break;
		}
		if((c >= '0') && (c <= '9')){
			ret= ret*10;
			ret+= c- '0';
		}else{
			if(c == '+'){
				continue;
			}
			if(c == '-'){
				flag= 1;
				continue;
			}
			break;
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}

void	WaitRelese(void)
{
	int iKeyCodeX;
	int iKeyCodeY;
	while(1){
		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((iKeyCodeX == 0) && (iKeyCodeY == 0) && (iIsPressed ==1)){
			iIsPressed = 0;
			break;
		}
		else if((iKeyCodeX < 800 && iKeyCodeX > 0) &&(iKeyCodeY < 480 && iKeyCodeY > 0))
		{
			iIsPressed = 1;
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
}

/////////////////////////////////////////////////////////
//	Main Menu
/////////////////////////////////////////////////////////

int iStartPosY = 7*32+10;	
int iUpDownMargin = 16;
int iCharWidthSize = 8;
int icharHeightSize = 16;
int iCharCntPerMenu = 20;
int iMenuWidth = 160;//iCharCntPerMenu*iCharWidthSize;	


void DrawTestMenusButton(void)
{

#ifdef LP_TYPE	
	
	//1.LCD		
	TextOut(0/iCharWidthSize, (iStartPosY+iUpDownMargin/2)/icharHeightSize, "        LCD        ");	
	RectAngle(0*iCharWidthSize, iStartPosY, iMenuWidth, iStartPosY+icharHeightSize+iUpDownMargin, T_WHITE,T_BLACK);			
	
	//2: Battery	   	
	TextOut((iMenuWidth*1)/iCharWidthSize, (iStartPosY+iUpDownMargin/2)/icharHeightSize, "      Battery      ");
	RectAngle(20*iCharWidthSize, iStartPosY, iMenuWidth*2, iStartPosY+icharHeightSize+iUpDownMargin, T_WHITE,T_BLACK);	
	
	//3: Buzzer
	TextOut((iMenuWidth*2)/iCharWidthSize, (iStartPosY+iUpDownMargin/2)/icharHeightSize, "      Buzzer      ");
	RectAngle(40*iCharWidthSize, iStartPosY, iMenuWidth*3, iStartPosY+icharHeightSize+iUpDownMargin, T_WHITE,T_BLACK);		
	
	
    //4: BackLight
	TextOut((iMenuWidth*3)/iCharWidthSize, (iStartPosY+iUpDownMargin/2)/icharHeightSize, "     BackLight     ");
	RectAngle(60*iCharWidthSize, iStartPosY, iMenuWidth*4, iStartPosY+icharHeightSize+iUpDownMargin, T_WHITE,T_BLACK);			
    
    
    //5: Switch 
	TextOut((iMenuWidth*4)/iCharWidthSize, (iStartPosY+iUpDownMargin/2)/icharHeightSize, "      Switch       ");
    RectAngle(80*iCharWidthSize, iStartPosY, iMenuWidth*5, iStartPosY+icharHeightSize+iUpDownMargin, T_WHITE,T_BLACK);       
    
    
    //6. LED	
	TextOut((iMenuWidth*0)/iCharWidthSize, (iStartPosY+(iUpDownMargin + icharHeightSize)*1 + iUpDownMargin/2)/icharHeightSize, "        LED        ");	
	RectAngle(0*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*1, iMenuWidth*1, iStartPosY+(icharHeightSize+iUpDownMargin)*2, T_WHITE,T_BLACK);		
	
	//7: I/O	   	
	TextOut((iMenuWidth*1)/iCharWidthSize, (iStartPosY+(iUpDownMargin + icharHeightSize)*1 + iUpDownMargin/2)/icharHeightSize, "        I/O        ");	
	RectAngle(20*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*1, iMenuWidth*2, iStartPosY+(icharHeightSize+iUpDownMargin)*2, T_WHITE,T_BLACK);	
	
	//8: Serial
	TextOut((iMenuWidth*2)/iCharWidthSize, (iStartPosY+(iUpDownMargin + icharHeightSize)*1 + iUpDownMargin/2)/icharHeightSize, "      Serial       ");	
	RectAngle(40*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*1, iMenuWidth*3, iStartPosY+(icharHeightSize+iUpDownMargin)*2, T_WHITE,T_BLACK);		
	
	
    //9: Ethernet
	TextOut((iMenuWidth*3)/iCharWidthSize, (iStartPosY+(iUpDownMargin + icharHeightSize)*1 + iUpDownMargin/2)/icharHeightSize, "     Ethernet      ");	
	RectAngle(60*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*1, iMenuWidth*4, iStartPosY+(icharHeightSize+iUpDownMargin)*2, T_WHITE,T_BLACK);			
    
    
    //10: USB
	TextOut((iMenuWidth*4)/iCharWidthSize, (iStartPosY+(iUpDownMargin + icharHeightSize)*1 + iUpDownMargin/2)/icharHeightSize, "         USB       ");	
    RectAngle(80*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*1, iMenuWidth*5, iStartPosY+(icharHeightSize+iUpDownMargin)*2, T_WHITE,T_BLACK);
    
    
    //11: Time/RTC	
	TextOut((iMenuWidth*0)/iCharWidthSize, (iStartPosY+(iUpDownMargin + icharHeightSize)*2+iUpDownMargin/2)/icharHeightSize,   "     Time/RTC      ");	
	RectAngle(0*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*2, iMenuWidth, iStartPosY+(icharHeightSize+iUpDownMargin)*3, T_WHITE,T_BLACK);			
	
	
	//12: Mac/Serial	   	
	TextOut((iMenuWidth*1)/iCharWidthSize, (iStartPosY+(iUpDownMargin + icharHeightSize)*2+iUpDownMargin/2)/icharHeightSize,   "    Mac/Serial     ");	
	RectAngle(20*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*2, iMenuWidth*2, iStartPosY+(icharHeightSize+iUpDownMargin)*3, T_WHITE,T_BLACK);	
	
	//13: Report
	TextOut((iMenuWidth*2)/iCharWidthSize, (int)((iStartPosY+(iUpDownMargin + icharHeightSize)*2+iUpDownMargin/2)/icharHeightSize+0.5), "      Report       ");	
	RectAngle(40*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*2, iMenuWidth*3, iStartPosY+(icharHeightSize+iUpDownMargin)*3, T_WHITE,T_BLACK);		
	

	
#else
	
	//1.LCD		
	TextOut(0/iCharWidthSize, (iStartPosY+iUpDownMargin/2)/icharHeightSize, "        LCD        ");	
	RectAngle(0*iCharWidthSize, iStartPosY, iMenuWidth, iStartPosY+icharHeightSize+iUpDownMargin, T_WHITE,T_BLACK);			
	
	//2: Battery	   	
	TextOut((iMenuWidth*1)/iCharWidthSize, (iStartPosY+iUpDownMargin/2)/icharHeightSize, "      Battery      ");
	RectAngle(20*iCharWidthSize, iStartPosY, iMenuWidth*2, iStartPosY+icharHeightSize+iUpDownMargin, T_WHITE,T_BLACK);	
	
	//3: Buzzer
	TextOut((iMenuWidth*2)/iCharWidthSize, (iStartPosY+iUpDownMargin/2)/icharHeightSize, "      Buzzer      ");
	RectAngle(40*iCharWidthSize, iStartPosY, iMenuWidth*3, iStartPosY+icharHeightSize+iUpDownMargin, T_WHITE,T_BLACK);		
	
	
    //4: BackLight
	TextOut((iMenuWidth*3)/iCharWidthSize, (iStartPosY+iUpDownMargin/2)/icharHeightSize, "     BackLight     ");
	RectAngle(60*iCharWidthSize, iStartPosY, iMenuWidth*4, iStartPosY+icharHeightSize+iUpDownMargin, T_WHITE,T_BLACK);			
    
    
    //5: Serial 
	TextOut((iMenuWidth*4)/iCharWidthSize, (iStartPosY+iUpDownMargin/2)/icharHeightSize, "      Serial       ");
    RectAngle(80*iCharWidthSize, iStartPosY, iMenuWidth*5, iStartPosY+icharHeightSize+iUpDownMargin, T_WHITE,T_BLACK);   
    
    
    
    //6. Ethernet	
	TextOut((iMenuWidth*0)/iCharWidthSize, (iStartPosY+(iUpDownMargin + icharHeightSize)*1 + iUpDownMargin/2)/icharHeightSize, "     Ethernet      ");	
	RectAngle(0*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*1, iMenuWidth*1, iStartPosY+(icharHeightSize+iUpDownMargin)*2, T_WHITE,T_BLACK);		
	
	//7: USB	   	
	TextOut((iMenuWidth*1)/iCharWidthSize, (iStartPosY+(iUpDownMargin + icharHeightSize)*1 + iUpDownMargin/2)/icharHeightSize, "        USB        ");	
	RectAngle(20*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*1, iMenuWidth*2, iStartPosY+(icharHeightSize+iUpDownMargin)*2, T_WHITE,T_BLACK);	
	
	//8: Time/RTC
	TextOut((iMenuWidth*2)/iCharWidthSize, (iStartPosY+(iUpDownMargin + icharHeightSize)*1 + iUpDownMargin/2)/icharHeightSize, "     Time/RTC      ");	
	RectAngle(40*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*1, iMenuWidth*3, iStartPosY+(icharHeightSize+iUpDownMargin)*2, T_WHITE,T_BLACK);		
	
	
    //9: Mac/Serial
	TextOut((iMenuWidth*3)/iCharWidthSize, (iStartPosY+(iUpDownMargin + icharHeightSize)*1 + iUpDownMargin/2)/icharHeightSize, "    Mac/Serial     ");	
	RectAngle(60*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*1, iMenuWidth*4, iStartPosY+(icharHeightSize+iUpDownMargin)*2, T_WHITE,T_BLACK);			
    
    
    //10: Report
	TextOut((iMenuWidth*4)/iCharWidthSize, (iStartPosY+(iUpDownMargin + icharHeightSize)*1 + iUpDownMargin/2)/icharHeightSize, "       Report      ");	
    RectAngle(80*iCharWidthSize, iStartPosY+(icharHeightSize+iUpDownMargin)*1, iMenuWidth*5, iStartPosY+(icharHeightSize+iUpDownMargin)*2, T_WHITE,T_BLACK);   
    

#endif
    
	
}

int GetMenuPosition(int iX, int iY)
{
	int iMenuPos = -1;
	
	/* menu number
	
	   	LP System
	   	0: Touch Calibration
	   	1: LCD
	   	2: Battery	   	
	   	3: Buzzer
       	4: Back Light
       	5: Switch 
		6: LED
		7: I/O
		8: Serial
		9: Ethernet
		10: USB 
		11: Time/RTC
		12: Mac/Serial
		13: Report
		
		
		GP System
		1. LCD
		2. Battery
		3. Buzzer
		4. BackLight
		5. Serial
		6. Ethernet
		7. USB
		8. Time/RTC
		9. Mac/Serial
	  	10.report
	*/
	
	
	
	if((iX > 0*iCharWidthSize && iX< iMenuWidth) && (iY > iStartPosY && iY < iStartPosY+icharHeightSize+iUpDownMargin))
	{
		return 1;
	}	
	else if ((iX > 20*iCharWidthSize && iX < iMenuWidth*2) && (iY > iStartPosY && iY < iStartPosY+icharHeightSize+iUpDownMargin))
	{		
		return 2;
	}
	else if ((iX > 40*iCharWidthSize && iX < iMenuWidth*3) && (iY > iStartPosY && iY < iStartPosY+icharHeightSize+iUpDownMargin))
	{
		return 3;
	}
	else if ((iX > 60*iCharWidthSize && iX < iMenuWidth*4) && (iY > iStartPosY && iY < iStartPosY+icharHeightSize+iUpDownMargin))
	{
		return 4;
	}
	else if ((iX > 80*iCharWidthSize && iX < iMenuWidth*5) && (iY > iStartPosY && iY < iStartPosY+icharHeightSize+iUpDownMargin))
	{
		return 5;
	}
	
	
	else if((iX > 0*iCharWidthSize && iX< iMenuWidth*1) && (iY > iStartPosY+(icharHeightSize+iUpDownMargin)*1 && iY < iStartPosY+(icharHeightSize+iUpDownMargin)*2))
	{
		return 6;
	}
	else if((iX > 20*iCharWidthSize && iX< iMenuWidth*2) && (iY > iStartPosY+(icharHeightSize+iUpDownMargin)*1 && iY < iStartPosY+(icharHeightSize+iUpDownMargin)*2))
	{
		return 7;
	}
	else if((iX > 40*iCharWidthSize && iX< iMenuWidth*3) && (iY > iStartPosY+(icharHeightSize+iUpDownMargin)*1 && iY < iStartPosY+(icharHeightSize+iUpDownMargin)*2))
	{
		return 8;
	}
	else if((iX > 60*iCharWidthSize && iX< iMenuWidth*4) && (iY > iStartPosY+(icharHeightSize+iUpDownMargin)*1 && iY < iStartPosY+(icharHeightSize+iUpDownMargin)*2))
	{
		return 9;
	}
	else if((iX > 80*iCharWidthSize && iX< iMenuWidth*5) && (iY > iStartPosY+(icharHeightSize+iUpDownMargin)*1 && iY < iStartPosY+(icharHeightSize+iUpDownMargin)*2))
	{
		return 10;
	}
	
	
	else if((iX > 0*iCharWidthSize && iX< iMenuWidth*1) && (iY > iStartPosY+(icharHeightSize+iUpDownMargin)*2 && iY < iStartPosY+(icharHeightSize+iUpDownMargin)*3))
	{
		return 11;
	}
	else if((iX > 20*iCharWidthSize && iX< iMenuWidth*2) && (iY > iStartPosY+(icharHeightSize+iUpDownMargin)*2 && iY < iStartPosY+(icharHeightSize+iUpDownMargin)*3))
	{
		return 12;
	}
	else if((iX > 40*iCharWidthSize && iX< iMenuWidth*3) && (iY > iStartPosY+(icharHeightSize+iUpDownMargin)*2 && iY < iStartPosY+(icharHeightSize+iUpDownMargin)*3))
	{
		return 13;
	}
	
	/*
	else if((iX > 60*iCharWidthSize && iX< iMenuWidth*4) && (iY > iStartPosY+(icharHeightSize+iUpDownMargin)*2 && iY < iStartPosY+(icharHeightSize+iUpDownMargin)*3))
	{
		return 14;
	}
	else if((iX > 80*iCharWidthSize && iX< iMenuWidth*5) && (iY > iStartPosY+(icharHeightSize+iUpDownMargin)*2 && iY < iStartPosY+(icharHeightSize+iUpDownMargin)*3))
	{
		return 15;
	}
	
	else if((iX > 0*iCharWidthSize && iX< iMenuWidth*1) && (iY > iStartPosY+(icharHeightSize+iUpDownMargin)*3 && iY < iStartPosY+(icharHeightSize+iUpDownMargin)*4))
	{
		return 16;
	}
	*/	
  

	return iMenuPos;
	
}



/////////////////////////////////////////////////////////
//	Memory Test
/////////////////////////////////////////////////////////
int	MemoryTest(void)
{
	int	ret,EndFlag;

	DModeSendMsg("*** Memory Test Start ***\r\n");
	DModeSendMsg(" 1 = SRAM Test\r\n");
	DModeSendMsg(" 2 = Nand Flash Test\r\n");
	DModeSendMsg(" 3 = SDRAM Test\r\n");
	EndFlag= 0;
	while(EndFlag == 0){
		while(1){
			if(IS_CONSOL( ) != 0){
				ret= GET_CONSOL();
				break;
			}
#ifdef	WIN32
			Delay(100);
#endif
		}
		switch(ret){
		case '1':	SramTest();			break;
		case '2':	NandFlashTest();	break;
		case '3':	SdramTest();		break;
		default:
			EndFlag= 1;
			break;
		}
	}
	DModeSendMsg("*** Memory Test End ***\r\n");
	return(0);
}
void	SetLcdColor(int color)
{
	int	i,j;
	COLOR_DT	draw_color;
	COLOR_DT	*LcdPos;

	LcdPos= (COLOR_DT*)LcdBuff;
	draw_color= GetColorData(color);
	for(i= 0; i < LCD_Y_SIZE; i++){
		for(j= 0; j < LCD_X_SIZE; j++){
			*LcdPos++ = draw_color;
		}
	}
	DrawLcd((char *)LcdBuff);
}


void	MemoryTest_t(void)
{
	SetLcdColor(3);
	SramTest_t();
//	ClearDisplay();
//	NandFlashTest();
//	ClearDisplay();
//	SdramTest();
}


/////////////////////////////////////////////////////////
//	SRAM Test
/////////////////////////////////////////////////////////
int	SramTest(void)
{
#ifndef	WIN32
	int	i;
	unsigned short data,sdata;
	unsigned short*	memAddr;
	int	ErrCount;
	char	buff[64];

	DModeSendMsg("*** SRAM Test Start ***\r\n");
	memAddr= (unsigned short*)START_SRAM;
	ErrCount= 0;
	*memAddr= 0xaaaa;
	if(*memAddr != 0xaaaa){	ErrCount++;	}
	*memAddr= 0x5555;
	if(*memAddr != 0x5555){	ErrCount++;	}
	memAddr++;
	if(ErrCount == 0){
		sdata= 0;
		memAddr= (unsigned short*)START_SRAM;
		for(i= 0; i < SRAM_SIZE/sizeof(short); i++){
			if((i % 0x10000) == 0){	data= sdata++;	}
			*memAddr++= data++;
		}
		sdata= 0;
		memAddr= (unsigned short*)START_SRAM;
		for(i= 0; i < SRAM_SIZE/sizeof(short); i++){
			if((i % 0x10000) == 0){	data= sdata++;	}
			if(*memAddr++ != data++){	break;	}
		}
	}
	if((ErrCount != 0) || (i < SRAM_SIZE/sizeof(short))){
		sprintf(buff,"SRAM Test NG(%08X)\r\n",(int)memAddr);
		DModeSendMsg(buff);
	}else{
		DModeSendMsg("SRAM Test OK\r\n");
	}
#else
	Delay(3000);
#endif
	DModeSendMsg("*** SRAM Test End ***\r\n");
	return(0);
}

void	SramTest_t(void)
{
	int	i;
	unsigned short data,sdata;
	unsigned short*	memAddr;
	int	ErrCount;

#ifdef	WIN32
	return;
#endif

	memAddr= (unsigned short*)START_SRAM;
	ErrCount= 0;
	
	*memAddr= 0xaaaa;
	if(*memAddr != 0xaaaa){	
		ErrCount++;	
	}
	*memAddr= 0x5555;
	if(*memAddr != 0x5555){	
		ErrCount++;	
	}
	memAddr++;

	if(ErrCount == 0){
		sdata= 0;
		memAddr= (unsigned short*)START_SRAM;
		for(i= 0; i < SRAM_SIZE/sizeof(short); i++){
			if((i % 0x10000) == 0){	
				data= sdata++;	
			}
			*memAddr++= data++;
		}
		
		sdata= 0;
		memAddr= (unsigned short*)START_SRAM;
		for(i= 0; i < SRAM_SIZE/sizeof(short); i++){
			if((i % 0x10000) == 0){	
				data= sdata++;	
			}
			if(*memAddr++ != data++){	
				break;	
			}
		}
	}
	TextOut2(5,1,"************* Memory  Test *************");	//40 char

	TextOut2(10,5,"SRAM/SDRAM/NAND Test");
	
	for(i= 0; i < DELAY*8; i++){}

	if((ErrCount != 0) || (i < SRAM_SIZE/sizeof(short))){
		TextOut2(32,5,"NG");
		Test_Flag[6] = NG;
	}else{
		TextOut2(32,5,"OK");
		Test_Flag[6] = OK;
	}
	
	for(i= 0; i < DELAY*4; i++){}
	
}

/////////////////////////////////////////////////////////
//	Nand Flash Test
/////////////////////////////////////////////////////////
int	NandFlashTest(void)
{
	DModeSendMsg("*** Nand Test Start ***\r\n");
	DModeSendMsg("*** Nand Test End ***\r\n");
	return(0);
}

/////////////////////////////////////////////////////////
//	SDRAM Test
/////////////////////////////////////////////////////////
int	SdramTest(void)
{
	DModeSendMsg("*** DRAMTest Start ***\r\n");
	DModeSendMsg("***DRAM Test End ***\r\n");
	return(0);
}

/////////////////////////////////////////////////////////
//	LCD Test
/////////////////////////////////////////////////////////
void	LCD_Color(void)
{
	int	i;

	for(i= 0; i < 5; i++){
		SetLcdColor(TestColor[i]);
		while(1){
			if(IS_CONSOL( ) != 0){
				GET_CONSOL();
				break;
			}
		}
	}
}
void	LCD_Color_t(void)
{
	int	i;
	int	iKeyCodeX;
	int	iKeyCodeY;


	for(i= 0; i < 5; i++){
		SetLcdColor(TestColor[i]);

		if(i != 4){
			RectAngle(19*16-20,10*32-10,21*16+20,11*32+10,TestColor[i+5],TestColor[i]);
			RectAngle(29*16-20,10*32-10,31*16+20,11*32+10,TestColor[i+5],TestColor[i]);
		}else{
			RectAngle(19*16-20,10*32-10,21*16+20,11*32+10,T_BLACK,T_WHITE);
			RectAngle(29*16-20,10*32-10,31*16+20,11*32+10,T_BLACK,T_WHITE);
		}

		TextOut2(5,1,"*************** LCD Test ***************");	//40 char

		TextOut2(22,5,color[i]);
		TextOut2(19,10,"OK");
		TextOut2(29,10,"NG");
	

		//WaitRelese();
		while(1){

			ScanKey(&iKeyCodeX,&iKeyCodeY);
			if((iKeyCodeX > 19*16-20) && (iKeyCodeX < 21*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
				Test_Flag[i+1]= OK;
				WaitRelese();
				break;								
			}	
			if((iKeyCodeX > 29*16-20) && (iKeyCodeX < 31*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
				Test_Flag[i+1]= NG;
				WaitRelese();
				break;								
			}
#ifdef	WIN32
			Delay(100);
#endif
		}
	}
}
void	LCD_Font(void)
{
}
void	LCD_Patarn(void)
{
	int	i;
	int	color;

	for(i= 0; i < LCD_Y_SIZE/2; i++){
		color= (GpColor[i%256].r << 16)+ (GpColor[i%256].g << 8)+ GpColor[i%256].b;
//		color= ((255-i) << 16)+ ((255-i) << 8)+ (255-i);
		RectAngleNoDraw(i,i,LCD_X_SIZE-i-1,LCD_Y_SIZE-i-1,color,0);
	}
 	ForGrandColor= GetColorData(T_WHITE);
	DrawLcd((char *)LcdBuff);
}
void	LcdTest(void)
{
	int	EndFlag;
	int	item;

	DModeSendMsg("*** LCD Test Start ***\r\n");
	DModeSendMsg(" 1 = Color\r\n");
	DModeSendMsg(" 2 = Font\r\n");
	DModeSendMsg(" 3 = Patarn\r\n");
	EndFlag= 0;
	while(EndFlag == 0){
		while(1){
			if(IS_CONSOL( ) != 0){
				item= GET_CONSOL();
				break;
			}
#ifdef	WIN32
			Delay(100);
#endif
		}
		switch(item){
		case '1':	LCD_Color();	break;
		case '2':	LCD_Font();		break;
		case '3':	LCD_Patarn();	break;
		default:	EndFlag= 1;		break;
		}
		switch(item){
		case '1':	case '2':	case '3':
			DModeSendMsg(" 1 = Color\r\n");
			DModeSendMsg(" 2 = Font\r\n");
			DModeSendMsg(" 3 = Patarn\r\n");
			break;
		}
	}
	DModeSendMsg("*** LCD Test End ***\r\n");
}
void	LcdTest_t(void)
{
	LCD_Color_t();
	SetLcdColor(3);
	ForGrandColor= GetColorData(T_WHITE);
	BackGrandColor= GetColorData(T_BLACK);
}

/////////////////////////////////////////////////////////
//	Buzzer Test
/////////////////////////////////////////////////////////
int	BuzzerTest(void)
{
	int	ret,EndFlag;

	DModeSendMsg("*** BUZZER Test Start ***\r\n");
	DModeSendMsg(" 1 = BUZZER-ON\r\n");
	DModeSendMsg(" 2 = BUZZER-OFF\r\n");

	EndFlag= 0;
	while(EndFlag == 0){
		while(1){
			if(IS_CONSOL( ) != 0){
				ret= GET_CONSOL();
				break;
			}
#ifdef	WIN32
			Delay(100);
#endif
		}
		switch(ret){
		case '1':	Buzzer(ON);		break;
		case '2':	Buzzer(OFF);	break;
		default:
			EndFlag= 1;
			break;
		}
	}
	DModeSendMsg("*** BUZZER Test End ***\r\n");
	return(0);	
}
/////////////////////////////////////////////////////////
//	Rtc Test
/////////////////////////////////////////////////////////
int	RtcTest(void)
{
	int	sec;
	char	dbuff[24];

	DModeSendMsg("*** RTC Test Start ***\r\n");
	sec= SystemTime.sec;
	sprintf(dbuff,"%4d/%2d/%2d %2d:%2d:%2d",
		SystemTime.year+2000,SystemTime.mon,SystemTime.day,
		SystemTime.hour,SystemTime.min,SystemTime.sec);
	TextOut(20,10,dbuff);
	while(1){
		if(IS_CONSOL( ) != 0){
			GET_CONSOL();
			break;
		}
		if(sec != SystemTime.sec){
			sec= SystemTime.sec;
			sprintf(dbuff,"%4d/%2d/%2d %2d:%2d:%2d",
				SystemTime.year+2000,SystemTime.mon,SystemTime.day,
				SystemTime.hour,SystemTime.min,SystemTime.sec);
			TextOut(20,10,dbuff);
		}
	}
	DModeSendMsg("*** RTC Test End ***\r\n");
	return(0);
}



char cReqTime[8];
char cGetTime[19];

//success 1, fail : 0
int CheckReceivedTimeValue(unsigned char *cTimedata)
{
	unsigned char cData, cData2;


	if(*cTimedata++ != 0x02) // command kinds
		return 0;
	
	cData = *cTimedata++;
	if(cData != 0x03 || cData == 0x83) //Read Holding Registers (0x83: NAK)
		return 0;
	
	if(*cTimedata++ != 0x0C)
		return 0;
	
	cData = *cTimedata++;	// year1
	if(cData > 3)
	{
		return 0;
	}
	
	cData = *cTimedata++;	// year2
	if(cData > 9)
	{
		return 0;
	}
	
	cData = *cTimedata++;	// year3
	if(cData > 9)
	{
		return 0;
	}
	
	cData = *cTimedata++;	// year4
	if(cData > 9)
	{
		return 0;
	}
	
	
	cData = *cTimedata++;	// month1
	if(cData > 1)
	{
		return 0;
	}
	
	
	cData2 = *cTimedata++;	// month2
	if(cData2 > 9 || (cData == 1 && cData2 > 2))
	{
		return 0;
	}
	
	
	cData = *cTimedata++;	// day1
	if(cData > 3)
	{
		return 0;
	}
	
	
	cData2 = *cTimedata++;	// day2
	if(cData > 9 || (cData == 3 && cData2 > 1))
	{
		return 0;
	}	
	
	
	cData = *cTimedata++;	//hour1
	if(cData > 2)
	{
		return 0;
	}
	
	
	cData2 = *cTimedata++;	//hour2
	if(cData > 9 || (cData == 2 && cData2 > 4))
	{
		return 0;
	}		
	
	
	cData = *cTimedata++;	//min1
	if(cData > 6)
	{
		return 0;
	}
	
	
	cData2 = *cTimedata++;	//min2
	if(cData > 6 || (cData == 6 && cData2 != 0))
	{
		return 0;
	}	
	
	
	cData = *cTimedata++;	//sec1
	if(cData > 6)
	{
		return 0;
	}	
	
	
	cData2 = *cTimedata++;	//sec2
	if(cData > 6 || (cData == 6 && cData2 != 0))
	{
		return 0;
	}
	
	return 1;
	
}

int	RtcTest_t(void)
{
	int ret;
	int iKeyCodeX;
	int iKeyCodeY;
	int	sec;
	char	dbuff[24];
	unsigned char 	cNowTime[7];

	SetLcdColor(3);

	TextOut2(5,1,"********** Time Set / RTC Test *********");	//40 char

	TextOut2(7,4,"Status : WAITING");
	TextOut2(7,6,"   RTC :        ");
	
	TextOut2(19,10,"OK");
	TextOut2(29,10,"NG");
	RectAngle(19*16-20,10*32-10,21*16+20,11*32+10,T_WHITE,T_BLACK);
	RectAngle(29*16-20,10*32-10,31*16+20,11*32+10,T_WHITE,T_BLACK);	
	
#ifndef WIN32	
	ret = TCPTest(2); //time request by tcp line		
#else
	ret = OK;
#endif
	
	if(ret == OK){
		TextOut2(16,4,"Time Received OK  ");
	}	
	else if(ret == WAIT)
	{
		
		ret = NG;
		TextOut2(16,4,"Waiting...               ");								
		TimerStart(0,300); // 3s?
		while(1)
		{			
			if(time_flag[0] == 1){		break;	}
			
			if(lanRecCnt > 0)
			{				
				//TextOut2(26,4,(char*)recBuff);					
				
				//check received time format
				if(CheckReceivedTimeValue(recBuff) != 1)
				{
					TextOut2(16,4,"NG :Wrong format         ");	
					ret = NG;															
				}				
				else
				{				
					TextOut2(16,4,"Time Received OK         ");					
					memset(cNowTime, 0x00, sizeof(cNowTime));					
					//year
					cNowTime[6] = recBuff[5]*10 + recBuff[6];					
					
					//mon
					cNowTime[5] = ((recBuff[7]&0x01) << 4) + recBuff[8];
					
					//date					
					cNowTime[4] = ((recBuff[9]&0x03) << 4) + recBuff[10];
					
					//day
					cNowTime[3] = 0x01;					
					
					//hour
					cNowTime[2] = ((recBuff[11]&0x03) << 4) + recBuff[12];					
					
					//min
					cNowTime[1] = ((recBuff[13]&0x07) << 4) + recBuff[14];					
					
					//sec
					cNowTime[0] = ((recBuff[15]&0x07) << 4) + recBuff[16];				
					
					RTCWrite(cNowTime, 0);					
					memset(recBuff, 0x00, lanRecCnt);
					ret= OK;				
					break;					
				}
				
				
				
			}
			
		}		
		
		if(ret == NG && lanRecCnt == 0)
		{
			TextOut2(16,4,"Time Out   ");				
			ret= NG;
		}		
		
		
	}	
	else 
	{
		TextOut2(16,4,"Error      ");
		ret= NG;		
	}	
	
	disconnect(1); //tcp disconect
	
	Test_Flag[AUT_RTC_TEST] =  ret;	
	
	
	sec= SystemTime.sec;
	sprintf(dbuff,"%4d/%2d/%2d %2d:%2d:%2d",
		SystemTime.year+2000,SystemTime.mon,SystemTime.day,
		SystemTime.hour,SystemTime.min,SystemTime.sec);
	TextOut2(16,6,dbuff);
	//WaitRelese();
	while(1){
		if(sec != SystemTime.sec){
			sec= SystemTime.sec;
			sprintf(dbuff,"%4d/%2d/%2d %2d:%2d:%2d",
				SystemTime.year+2000,SystemTime.mon,SystemTime.day,
				SystemTime.hour,SystemTime.min,SystemTime.sec);
			TextOut2(16,6,dbuff);
		}
		
		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((iKeyCodeX > 19*16-20) && (iKeyCodeX < 21*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			Test_Flag[AUT_RTC_TEST]= OK;
			WaitRelese();
			break;								
		}
		if((iKeyCodeX > 29*16-20) && (iKeyCodeX < 31*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			Test_Flag[AUT_RTC_TEST]= NG;
			WaitRelese();
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
	
	return(0);
}

/////////////////////////////////////////////////////////
//	Serial Test
/////////////////////////////////////////////////////////
void	SerialTest(void)
{
	int i, ret;
	volatile IOP_REG    *pIOPReg;
	
	ret = NG;

	TextOut2(5,1,"************* Serial  Test *************");	//40 char

    pIOPReg = (volatile IOP_REG *)IOP_BASE;
	
	SioRtsOff(&_Sci0Tbl);
	SioRtsOff(&_Sci1Tbl);
	SioRtsOn(&_Sci0Tbl);
	SioRtsOn(&_Sci1Tbl);
/*
	if((_Sci0Tbl.pUART->rUMSTAT & 0x1) != 1){		
		ret= 0;
		err= '3';
		TextOut2(8,6,"RTS0 Error");
	}else{
		TextOut2(8,6,"RTS0 OK");
	}
*/
	
	/*
	TextOut2(14,4,"RS-232C RTS => CTS");

	// kwon imsi
	if((_Sci1Tbl.pUART->rUMSTAT & 0x1) != 1){
		TextOut2(33,4,"NG");
#ifndef	WIN32
		for(i= 0; i < DELAY*2; i++){}
#endif
	}else	
	*/
	{
		//TextOut2(33,4,"OK");
		ret = OK;
#ifndef WIN32 
		for(i= 0; i < DELAY*2; i++){}


		pIOPReg->rGPHDAT &= ~(IO_RS422DIR);	//Rs-422 RX Enable

		ClearSio0Cnt();
		ClearSio1Cnt();
		Sio1SendChar(0xaa);
#endif

		TextOut2(12,6,"Serial1 TX => Serial2 RX");

		TimerStart( 0, 100 );		
		while(time_flag[0] == 0){
			if(IsGetSio0() != 0){
				break;
			}
#ifdef	WIN32
		Delay(100);
#endif
		}
		if(GetSio0() != 0xaa){
			TextOut2(36,6," NG");
			ret = NG;
#ifndef	WIN32
			for(i= 0; i < DELAY*2; i++){}
#endif
		}else{
			TextOut2(36,6," OK");
			ret = OK;
#ifndef	WIN32
			for(i= 0; i < DELAY*2; i++){}
#endif
			pIOPReg->rGPHDAT |= IO_RS422DIR;	//Rs-422 TX Enable;
			ClearSio0Cnt();
			ClearSio1Cnt();
			Sio0SendChar(0x55);

			TextOut2(12,8,"Serial2 TX => Serial1 RX");

			TimerStart( 0, 100 );		
			while(time_flag[0] == 0){
				if(IsGetSio1() != 0){
					break;
				}
#ifdef	WIN32
				Delay(100);
#endif
			}
			if(GetSio1() != 0x55){
				TextOut2(36,8," NG");
				ret = NG;
#ifndef	WIN32
				for(i= 0; i < DELAY*2; i++){}
#endif
			}else{
				TextOut2(36,8," OK");
				ret = OK;
#ifndef	WIN32
				for(i= 0; i < DELAY*2; i++){}
#endif
			}
		}
	}	
	
	
	if(iAutoMenuProcess != 1)	
	{
		Test_Flag[AUT_232C_TEST]= ItemResultOKNG(ret, 0);//ItemResult(0,0);
		WaitRelese();
	}
	else
		Test_Flag[AUT_232C_TEST] = ret;	

}
void	SerialAgain(void)
{
	Test_Flag[AUT_232C_TEST]= AGAIN;
	while(1){
		if(Test_Flag[AUT_232C_TEST] == AGAIN){
			SetLcdColor(3);
			SerialTest();
		}else if(Test_Flag[AUT_232C_TEST] == OK || Test_Flag[AUT_232C_TEST] == NG){
			break;
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
}

/////////////////////////////////////////////////////////
//	Battery Test
/////////////////////////////////////////////////////////
int	BatteryTest(void)
{
	int	ret;
	int	befAd;
	char	buff[16];

	DModeSendMsg("*** Battery Test Start ***\r\n");
	ret= GetAD_Power(&befAd);
	if(ret == OK){	sprintf(buff,"AD=%d\r\n",befAd);	}
	DModeSendMsg(buff);
	TimerStart(0,50);		//500ms Start
	BatteryAdStart= 1;
	while(1){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			break;
		}
		if(time_flag[0] != 0){
			TimerStart(0,50);		//500ms Start
//			ret= GetAD_Power(&ADValue);
			if((BatteryAdOk == OK) && (BatteryADValue != befAd)){
				befAd= BatteryADValue;
				sprintf(buff,"AD=%d\r\n",befAd);
				DModeSendMsg(buff);
			}
		}
	}
	DModeSendMsg("*** Battery Test End ***\r\n");
	BatteryAdStart= 0;
	return(0);
}
void	BatteryTest_t(void)
{
	int	ret;
//	int	ADValue;
	int	befAd;
	char	buff[16];
	int iKeyCodeX;
	int iKeyCodeY;

	BatteryAdStart= 1;
	SetLcdColor(3);
	TextOut2(5,1,"************* Battery Test *************");	//40 char

	TextOut2(19,4,"Battery = ");
	TextOut2(18,6,"Battery > 860 OK");

//	ret= GetAD_Power(&befAd);
//	if(BatteryAdOk == OK){	
//		sprintf(buff,"%d",BatteryADValue);	
//		TextOut2(29,5,buff);
//	}
	
	TimerStart(0,50);		//500ms Start	
	TimerStart(2,500);		//5s Start
	befAd= -1;	
	while(1){
		
		if(time_flag[0] != 0){
			TimerStart(0,50);		//500ms Start			
//			ret= GetAD_Power(&ADValue);
			if((BatteryAdOk == OK) && (BatteryADValue != befAd)){	
				befAd= BatteryADValue;
				sprintf(buff,"%d",befAd);
				TextOut2(29,4,buff);
//				for(i= 0; i < DELAY; i++){}
			}
		}
		
		ret = (befAd > 860) ? OK : NG;
		Test_Flag[AUT_BATT_TEST]= ret;	
		
		if(iAutoMenuProcess == 1)						
		{			
			if(ret == OK || time_flag[2] != 0)
				break;				
		}			
		else
		{			
		
			if(ret == OK)
			{
				TextOut2(25,10,"OK");					
			}				
			else
			{
				TextOut2(25,10,"NG");										
			}
			RectAngle(25*16-20,10*32-10,27*16+20,11*32+10,T_WHITE,T_BLACK);					
			
			ScanKey(&iKeyCodeX,&iKeyCodeY);
			if((iKeyCodeX > 25*16-20) && (iKeyCodeX < 27*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10))
			{				
				WaitRelese();
				break;								
			}			
		}
		
#ifdef	WIN32
		Delay(100);
#endif
	}
	BatteryAdStart= 0;
}

/////////////////////////////////////////////////////////
//	SWITCH Test
/////////////////////////////////////////////////////////
int	SwitchTest(void)
{
	int	befSwitch;
	int	ret;

	DModeSendMsg("*** Switch Test Start ***\r\n");
	befSwitch= RunSWRead();
	if(befSwitch != 0){	DModeSendMsg("RUN/STOP= OFF\r\n");	}
	else{				DModeSendMsg("RUN/STOP= ON\r\n");	}
	while(1){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			break;
		}
		ret= RunSWRead();
		if(ret != befSwitch){
			befSwitch= ret;
			if(befSwitch != 0){	DModeSendMsg("RUN/STOP= OFF\r\n");	}
			else{				DModeSendMsg("RUN/STOP= ON\r\n");	}
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
	DModeSendMsg("*** Switch Test End ***\r\n");
	return(0);
}

void	SwitchTest_t(void)
{
	int	befSwitch;
	int iKeyCodeX;
	int iKeyCodeY;

	SetLcdColor(3);

	ForGrandColor= GetColorData(T_WHITE);
	BackGrandColor= GetColorData(T_BLACK);
	TextOut2(5,1,"************* Switch  Test *************");	//40 char

	TextOut2(18,5,"Switch : ");
	TextOut2(19,10,"OK");
	TextOut2(29,10,"NG");
	RectAngle(19*16-20,10*32-10,21*16+20,11*32+10,T_WHITE,T_BLACK);
	RectAngle(29*16-20,10*32-10,31*16+20,11*32+10,T_WHITE,T_BLACK);

	befSwitch= RunSWRead();
	if(befSwitch != 0){	
		TextOut2(27,5,"STOP");
	}else{				
		TextOut2(27,5,"RUN ");
	}
	
	//WaitRelese();
	while(1){
		befSwitch= RunSWRead();

		if(befSwitch != 0){	
			TextOut2(27,5,"STOP");
		}else{				
			TextOut2(27,5,"RUN ");
		}
		
		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((iKeyCodeX > 19*16-20) && (iKeyCodeX < 21*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			Test_Flag[AUT_SWITCH_TEST]= OK;
			WaitRelese();
			break;								
		}
		if((iKeyCodeX > 29*16-20) && (iKeyCodeX < 31*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			Test_Flag[AUT_SWITCH_TEST]= NG;
			WaitRelese();
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
}

/////////////////////////////////////////////////////////
//	LED Test
/////////////////////////////////////////////////////////
int	LedTest(void)
{
	int	ret,EndFlag;

	DModeSendMsg("*** LED Test Start ***\r\n");
	DModeSendMsg(" 1 = RUN-ON\r\n");
	DModeSendMsg(" 2 = RUN-OFF\r\n");
	DModeSendMsg(" 3 = ERROR-ON\r\n");
	DModeSendMsg(" 4 = ERROR-OFF\r\n");
	EndFlag= 0;
	while(EndFlag == 0){
		while(1){
			if(IS_CONSOL( ) != 0){
				ret= GET_CONSOL();
				break;
			}
#ifdef	WIN32
			Delay(100);
#endif
		}
		switch(ret){
		case '1':	RunLed(ON);		break;
		case '2':	RunLed(OFF);	break;
		case '3':	ErrorLed(ON);	break;
		case '4':	ErrorLed(OFF);	break;
		default:
			EndFlag= 1;
			break;
		}
	}
	DModeSendMsg("*** LED Test End ***\r\n");
	return(0);
}
void	LedTest_t(void)
{
	int iKeyCodeX;
	int iKeyCodeY;
	int	kind;
	
	SetLcdColor(3);
	TextOut2(5,1,"*************** LED Test ***************");	//40 char

	TextOut2(13,4,"Check LED (Green <-> Red)");
	TextOut2(19,10,"OK");
	TextOut2(29,10,"NG");
	RectAngle(19*16-20,10*32-10,21*16+20,11*32+10,T_WHITE,T_BLACK);
	RectAngle(29*16-20,10*32-10,31*16+20,11*32+10,T_WHITE,T_BLACK);

	TimerStart(0,200);		//2s Start
	kind= 0;	
	while(1){	
		if(time_flag[0] != 0){
			TimerStart(0,200);		//2s Start
			switch(kind){
			case 0:	RunLed(ON);
					TextOut2(19,6,"GREEN LED ON     ");
				break;
			case 1:	RunLed(OFF);
					TextOut2(19,6,"GREEN LED OFF    ");
				break;
			case 2:	ErrorLed(ON);
					TextOut2(19,6,"RED LED ON       ");
				break;
			case 3:	ErrorLed(OFF);
					TextOut2(19,6,"RED LED OFF      ");
				break;
			}
			kind++;
			kind &= 0x03;
		}

		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((iKeyCodeX > 19*16-20) && (iKeyCodeX < 21*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			Test_Flag[AUT_LED_TEST]= OK;
			WaitRelese();
			DebugLed(ON);
			break;								
		}
		if((iKeyCodeX > 29*16-20) && (iKeyCodeX < 31*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			Test_Flag[AUT_LED_TEST]= NG;
			WaitRelese();
			DebugLed(ON);
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}	
}
/////////////////////////////////////////////////////////
//	Buzzer Test
/////////////////////////////////////////////////////////
void	BuzzerTest_t(void)
{
	int iKeyCodeX;
	int iKeyCodeY;
	int	kind;
	
	SetLcdColor(3);
	TextOut2(5,1,"************* Buzzer  Test *************");	//40 char

	TextOut2(13,5,"Check BUZZER (On <-> Off)");
	TextOut2(19,10,"OK");
	TextOut2(29,10,"NG");
	RectAngle(19*16-20,10*32-10,21*16+20,11*32+10,T_WHITE,T_BLACK);
	RectAngle(29*16-20,10*32-10,31*16+20,11*32+10,T_WHITE,T_BLACK);

	TimerStart(0,30);		//300ms Start
	kind= 0;	
	while(1){	
		if(time_flag[0] != 0){
			TimerStart(0,50);		//500ms Start
			switch(kind){
			case 0:	Buzzer(ON);		break;
			case 1:	Buzzer(OFF);	break;
			}
			kind++;
			kind &= 0x01;
		}

		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((iKeyCodeX > 19*16-20) && (iKeyCodeX < 21*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			Test_Flag[AUT_BUZZER_TEST]= OK;			
			WaitRelese();
//			DebugLed(ON);
			break;								
		}
		if((iKeyCodeX > 29*16-20) && (iKeyCodeX < 31*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			Test_Flag[AUT_BUZZER_TEST]= NG;			
			WaitRelese();
//			DebugLed(ON);
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}	
	Buzzer(OFF);
}

/////////////////////////////////////////////////////////
//	I/O Test
/////////////////////////////////////////////////////////

int	IoTest(void)
{
	volatile unsigned char*	OutPortAddr;
	volatile unsigned char*	InPortAddr;
	int		j;
	//unsigned short	OutData;
	unsigned short	InData;
//	int		ret;

	DModeSendMsg("*** I/O Test Start ***\r\n");
//	InPortAddr= (volatile unsigned char*)(IO_START_ADDR+ FPG_ID_ADDR);

//	InData= (unsigned short)(*InPortAddr++ << 8);
//	InData |= *InPortAddr;


	OutPortAddr= (volatile unsigned char*)(IO_START_ADDR+ FPG_PC_REG00);
	//IN,OUT MODE
	*OutPortAddr++ = 0x00;
//	*OutPortAddr++;
//	*OutPortAddr++;
//	*OutPortAddr++;
	*OutPortAddr++ = 0x00;
	*OutPortAddr++ = 0x00;
	*OutPortAddr++ = 0x00;
	*OutPortAddr++ = 0x00;
	//Filter
	OutPortAddr= (volatile unsigned char *)(IO_START_ADDR+FPG_FC_REG00);
	for(j= 0; j < 2; j++){	//16-16
		*OutPortAddr++ = 0x00;		//No Filter
	}
	//Interrupt
	OutPortAddr= (volatile unsigned char *)(IO_START_ADDR+FPG_IC_REG00);
	for(j= 0; j < 2; j++){	//16-16
		*OutPortAddr++ = 0x00;		//No interrupt
	}

	InPortAddr= (unsigned char*)(IO_START_ADDR+ FPG_IO_A);
	OutPortAddr= (unsigned char*)(IO_START_ADDR+ FPG_IO_C);

	*(OutPortAddr)= 0xaa;
	*(OutPortAddr+1)= 0xaa;
	WaitTimeMs(500);
	*(OutPortAddr)= 0x55;
	*(OutPortAddr+1)= 0x55;
	WaitTimeMs(500);
		
	while(1){
		if(IS_CONSOL( ) != 0){
			GET_CONSOL();
			break;
		}
		InData= (unsigned short)(*InPortAddr) << 8;
		InData |= *(InPortAddr+ 1);
//		ret= 0;
		*(OutPortAddr)= (unsigned char)(InData >> 8);
		*(OutPortAddr+1)= (unsigned char)InData;
//		if(InData == 0xaaaa){
//			*OutPortAddr= 0x55;
//			*(OutPortAddr+1)= 0x55;
//			WaitTimeMs(500);
//			InData= (unsigned short)(*InPortAddr) << 8;
//			InData |= *(InPortAddr+ 1);
//			if(InData == 0x5555){
//				ret= 1;
//			}
//		}
	}
	*OutPortAddr     = ~0;
	*(OutPortAddr+1) = ~0;
	
//	if(ret == 1){	DModeSendMsg("I/O OK\r\n");	}
//	else{			DModeSendMsg("I/O NG\r\n");	}
	DModeSendMsg("*** I/O Test End ***\r\n");
	return(0);
}
extern	void	DispCheckPatarn(int mode);
extern void 	DispCheckPatarn2(volatile unsigned char* pcValue, int iSize, int iStartX, int iStartY);
int	IoTest_t(void)
{
	volatile unsigned char*	OutPortAddr;
	volatile unsigned char*	InPortAddr;
	int		j;
	unsigned short	InData;
	int iKeyCodeX;
	int iKeyCodeY;
	int	ret;

	SetLcdColor(3);
	ForGrandColor= GetColorData(T_WHITE);
	BackGrandColor= GetColorData(T_BLACK);
	TextOut2(5,1,"*************** IO  Test ***************");	//40 char
	
	TextOut2(5,4,"Output:");
	TextOut2(5,7," Input:");
	
	ret = NG;

	OutPortAddr= (volatile unsigned char*)(IO_START_ADDR+ FPG_PC_REG00);
	//IN,OUT MODE
	*OutPortAddr++ = 0x00;
	*OutPortAddr++ = 0x00;
	*OutPortAddr++ = 0x00;
	*OutPortAddr++ = 0x00;
	*OutPortAddr++ = 0x00;
	//Filter
	OutPortAddr= (volatile unsigned char *)(IO_START_ADDR+FPG_FC_REG00);
	for(j= 0; j < 2; j++){	//16-16
		*OutPortAddr++ = 0x00;		//No Filter
	}
	//Interrupt
	OutPortAddr= (volatile unsigned char *)(IO_START_ADDR+FPG_IC_REG00);
	for(j= 0; j < 2; j++){	//16-16
		*OutPortAddr++ = 0x00;		//No interrupt
	}

	InPortAddr= (unsigned char*)(IO_START_ADDR+ FPG_IO_A);
	OutPortAddr= (unsigned char*)(IO_START_ADDR+ FPG_IO_C);

	*(OutPortAddr)= 0xaa;
	*(OutPortAddr+1)= 0xaa;
	DispCheckPatarn2(OutPortAddr, 2,  16*12, 32*4);
	//WaitTimeMs(10);
	InData= (unsigned short)(*InPortAddr) << 8;
	InData |= *(InPortAddr+ 1);
		
	DispCheckPatarn2(InPortAddr, 2,  16*12, 32*7);			
	
	if(InData == 0xaaaa){	
		*OutPortAddr= 0x55;
		*(OutPortAddr+1)= 0x55;				
		
		DispCheckPatarn2(OutPortAddr, 2,  16*12, 32*4);	
		
		//WaitTimeMs(10);
		InData= (unsigned short)(*InPortAddr) << 8;
		InData |= *(InPortAddr+ 1);
		DispCheckPatarn2(InPortAddr, 2,  16*12, 32*7);
		if(InData == 0x5555){
			ret= OK;
		}
	}
	*OutPortAddr     = ~0;
	*(OutPortAddr+1) = ~0;
		
	Test_Flag[AUT_I_O_TEST]= ret;
	
	if(iAutoMenuProcess != 1)
	{
		if(ret == OK){
			TextOut2(24,10,"OK");
		}else{
			TextOut2(24,10,"NG");
		}
		RectAngle(24*16-20,10*32-10,26*16+20,11*32+10,T_WHITE,T_BLACK);		
		while(1){
			ScanKey(&iKeyCodeX,&iKeyCodeY);
			if((iKeyCodeX > 24*16-20) && (iKeyCodeX < 26*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){			
				WaitRelese();
				break;								
			}
#ifdef	WIN32
			Delay(100);
#endif

		}
		
	}	
	
	DModeSendMsg("*** I/O Test End ***\r\n");
	return(0);
}

/////////////////////////////////////////////////////////
// Ethernet Test
/////////////////////////////////////////////////////////
void	W5100Test(void)
{
	int	ret,EndFlag;
	int	item;

	DModeSendMsg("*** W5100 Test Start ***\r\n");
	DModeSendMsg(" 1 = W5100 Open\r\n");
	DModeSendMsg(" 2 = TCP OPEN\r\n");
	DModeSendMsg(" 3 = UDP Open\r\n");
	EndFlag= 0;
	while(EndFlag == 0){
		while(1){
			if(IS_CONSOL( ) != 0){
				item= GET_CONSOL();
				break;
			}
#ifdef	WIN32
			Delay(100);
#endif
		}
		switch(item){
		case '1':
			ret= W5100Open();
			if(ret == 0){	DModeSendMsg("W5100 Open OK\r\n");	}
			else{			DModeSendMsg("W5100 Open NG\r\n");	}
			break;
		case '2':
			ret= TcpOpen();
			if(ret == 0){	DModeSendMsg("TCP Open OK\r\n");	}
			else{			DModeSendMsg("TCP Open NG\r\n");	}
			break;
		case '3':
			ret= UdpOpen();
			if(ret == 0){	DModeSendMsg("UDP Open OK\r\n");	}
			else{			DModeSendMsg("UDP Open NG\r\n");	}
			break;
		default:
			EndFlag= 1;
			break;
		}
	}
	DModeSendMsg("*** W5100 Test End ***\r\n");
}
/////////////////////////////////////////////////////////
//	TCP Test
/////////////////////////////////////////////////////////
void	TCPSendRecTest(void)
{
	DModeSendMsg("*** STCP Send Rec Start ***\r\n");
	if(TCPTest(1) == OK){
		DModeSendMsg("TCP OK\r\n");
	}else{
		DModeSendMsg("TCP NG\r\n");
	}
	DModeSendMsg("*** STCP Send Rec End ***\r\n");
}
/////////////////////////////////////////////////////////
//	W5100 Test
/////////////////////////////////////////////////////////
void	TCP_AutoTest(void)
{
	int	ret;

	SetLcdColor(3);
	TextOut2(5,1,"*************** TCP Test ***************");	//40 char
	TextOut2(10,3,"    Send Data : ABCDEFG012345");
	TextOut2(10,5,"Received Data : ");	
	TextOut2(10,7,"       Status : WAITING");

	
	lanRecCnt= 0;
#ifndef WIN32
	ret= TCPTest(0);
#else
	ret = OK;
#endif
	if(ret == OK){
		TextOut2(29,7,"OK");
	}	
	else if(ret == WAIT)
	{
		ret = NG;
		TextOut2(26,7,"Waiting...");								
		TimerStart(0,300); // 3s?
		while(1)
		{			
			if(time_flag[0] == 1){		break;	}
			
			if(lanRecCnt > 0)
			{
				TextOut2(26,5,(char*)recBuff);					
				if(memcmp(recBuff, "ABCDEFG012345", lanRecCnt) == 0)
				{				
					TextOut2(26,7,"Match      ");									
					ret = OK;					
				}					
				else
				{
					TextOut2(26,7,"MisMatch      ");
					ret = NG;					
				}
				
				memset(recBuff, 0x00, lanRecCnt);
					
				break;
			}
			
		}		
		
		if(ret == NG && lanRecCnt == 0)
		{
			TextOut2(26,7,"Time Out   ");	
		}		
		
	}	
	else 
	{
		TextOut2(26,7,"Error      ");
	}
	
	disconnect(1);                // disconnect 
	
	if(iAutoMenuProcess	!= 1)	
	{
		Test_Flag[AUT_TCP_TEST]= ItemResultOKNG(ret,0);//ItemResult(0,0);
		WaitRelese();
	}
	else
		Test_Flag[AUT_TCP_TEST] = ret;
		
}
void	W5100Test_t(void)
{
	Test_Flag[AUT_TCP_TEST]= AGAIN;

	while(1){
		if(Test_Flag[AUT_TCP_TEST] == AGAIN){
			TCP_AutoTest();
		}else if(Test_Flag[AUT_TCP_TEST] == OK || Test_Flag[AUT_TCP_TEST] == NG){
			break;
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
}

/////////////////////////////////////////////////////////
//	FPGA Test
/////////////////////////////////////////////////////////
void	FpgaIntEnable(void)
{
	volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
	volatile IOP_REG	*pIOPRegs   = (IOP_REG *)IOP_BASE;

	pINTRegs->rSRCPND  = BIT_EINT0;
	if (pINTRegs->rINTPND & BIT_EINT0)
		pINTRegs->rINTPND = BIT_EINT0;
	pINTRegs->rINTMSK &= ~BIT_EINT0;

	pIOPRegs->rEXTINT0= 0x2 << 0;			//Falling edge
}
int	_IoInterrupt(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_EINT0;
	pINTRegs->rSRCPND  = BIT_EINT0;
	pINTRegs->rINTPND  = BIT_EINT0;



	pINTRegs->rSRCPND  = BIT_EINT0;
	if (pINTRegs->rINTPND & BIT_EINT0)
		pINTRegs->rINTPND = BIT_EINT0;
	pINTRegs->rINTMSK &= ~BIT_EINT0;

	return(0);
}

/////////////////////////////////////////////////////////////////////////////
//	TOUCH KEY Caribration
/////////////////////////////////////////////////////////////////////////////
void	DispTouchInAddr(int item)
{
	char	buff[20];

	sprintf(buff,"%3d,%3d Touch\r\n",CalibAddr[item].x,CalibAddr[item].y);
	DModeSendMsg(buff);
}
void	DrawRectLine(int sx,int sy,int ex,int ey,int f_color,int b_color)
{
	LineOut(sx-10,sy,ex+10,ey,f_color,b_color);
	LineOut(sx,sy+10,ex,ey-10,f_color,b_color);
}
void	CaribInPos(int item)
{
	int	KerCodeX;
	int	KerCodeY;
	int	BefNonCalbX,BefNonCalbY;
	int	dtaInFlag;
	char	test_buff[48];
	extern	int	bTSP_DownFlag;

	DispTouchInAddr(item);
	BefNonCalbX= BefNonCalbY= -1;
//	ClearDisplay();
	DrawRectLine(CalibAddr[item].x,CalibAddr[item].y,CalibAddr[item].x,CalibAddr[item].y,T_WHITE,T_BLACK);
	InCalibData[item].PosDigitX= CalibAddr[item].x;
	InCalibData[item].PosDigitY= CalibAddr[item].y;

	BefNonCalbX= NonCalbX;
	BefNonCalbY= NonCalbY;
	dtaInFlag= 0;
	while(1){
		ScanKey(&KerCodeX,&KerCodeY);
		if((BefNonCalbX != NonCalbX) || (BefNonCalbY != NonCalbY)){
			BefNonCalbX= NonCalbX;
			BefNonCalbY= NonCalbY;
			InCalibData[item].PosAnalogX= BefNonCalbX;
			InCalibData[item].PosAnalogY= BefNonCalbY;
			sprintf(test_buff,"Touch=[%5d,%5d]",NonCalbX,NonCalbY);
			TextOut(40,15,test_buff);
			dtaInFlag= 1;
//			break;
		}
		if((dtaInFlag == 1) && (bTSP_DownFlag == 0)){
			break;
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
}
void	CaribInPos_t(int item)
{
	int	KerCodeX;
	int	KerCodeY;
	int	BefNonCalbX,BefNonCalbY;
//	char	test_buff[48];

	BefNonCalbX= BefNonCalbY= -1;

	TextOut2(5,1,"************** Touch Test **************");	//40 char

	LineOut(CalibAddr[item].x-10,CalibAddr[item].y,CalibAddr[item].x+10,CalibAddr[item].y,T_WHITE,T_BLACK);
	LineOut(CalibAddr[item].x,CalibAddr[item].y-10,CalibAddr[item].x,CalibAddr[item].y+10,T_WHITE,T_BLACK);
	RectAngle(16*16-20,10*32-10,21*16+20,11*32+10,T_WHITE,T_BLACK);
	TextOut2(16,10,"Again");
	InCalibData[item].PosDigitX= CalibAddr[item].x;
	InCalibData[item].PosDigitY= CalibAddr[item].y;

	while(1){
		ScanKey(&KerCodeX,&KerCodeY);
		
		if((ScanStartX > CalibAddr[item].x-20) && (ScanStartX < CalibAddr[item].x+20) && (ScanStartY > CalibAddr[item].y-20) && (ScanStartY < CalibAddr[item].y+20)){
			if((BefNonCalbX != NonCalbX) || (BefNonCalbY != NonCalbY)){
				BefNonCalbX= NonCalbX;
				BefNonCalbY= NonCalbY;

				if(ScanStartX != 0 && ScanStartY != 0){
					InCalibData[item].PosAnalogX= BefNonCalbX;
					InCalibData[item].PosAnalogY= BefNonCalbY;
					RectAngle(ScanStartX-1,ScanStartY-1,ScanStartX+1,ScanStartY+1,T_RED,T_BLACK);
					ForGrandColor= GetColorData(T_WHITE);
					ScanStartX= 0;
					ScanStartY= 0;
					break;	
				}	
			}
		}
		
		if((ScanStartX > 16*16-20) && (ScanStartX < 21*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10)){
			ScanStartX= 0;
			ScanStartY= 0;
			Test_Flag[0]= NG;
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
}
void	InposSave(void)
{
	//CalibData
	CalibData[0].PosDigitX= CalibAddr[0].x;
	CalibData[0].PosDigitY= CalibAddr[0].y;
	CalibData[0].PosAnalogX= (InCalibData[0].PosAnalogX+InCalibData[1].PosAnalogX)/2;
	CalibData[0].PosAnalogY= (InCalibData[0].PosAnalogY+InCalibData[2].PosAnalogY)/2;
	CalibData[1].PosDigitX= CalibAddr[3].x;
	CalibData[1].PosDigitY= CalibAddr[3].y;
	CalibData[1].PosAnalogX= (InCalibData[2].PosAnalogX+InCalibData[3].PosAnalogX)/2;
	CalibData[1].PosAnalogY= (InCalibData[1].PosAnalogY+InCalibData[3].PosAnalogY)/2;
	memcpy(&Cal_Data.CalibPos[0],&CalibData,sizeof(CalibData));
	FlashWriteSeq((char*)TOUCH_CALIB_AREA,(char*)&Cal_Data,sizeof(Cal_Data));
	TouchCalCheck();
}
int	CheckPos(void)
{
	int	i;
	int	ret= OK;

	for(i= 0; i < 4; i++){
		if( (InCalibData[i].PosAnalogX > CalibAddrArea[i][0].x) && (InCalibData[i].PosAnalogX < CalibAddrArea[i][1].x) &&
			(InCalibData[i].PosAnalogY > CalibAddrArea[i][0].y) && (InCalibData[i].PosAnalogY < CalibAddrArea[i][1].y) ){		
		}else{
			ret= NG;
			break;
		}
	}
	return(ret);
}
int	SetTouchCalibration(void)
{
	int	EndFlag= 0;
	int	item= 0;
	int	ret= NG;

	ClearDisplay();
	TextOut2(5,1,"********** Touch  Calibration **********");	//40 char

	while(EndFlag == 0){
		switch(item){
		case 0: case 1: case 2: 
			CaribInPos(item);
			break;
		case 3:
			CaribInPos(item);
			ret= CheckPos();
			if(ret == OK){
				InposSave();
			}
			EndFlag= 1;
			break;
		}
		item++;
	}
	return(ret);
}
void	SetTouchCalibration_t(void)
{
	int	EndFlag= 0;
	int	item= 0;
	int	iKeyCodeX;
	int	iKeyCodeY;

	Test_Flag[0]= OK;
	
	while(EndFlag == 0){
		switch(item){
		case 0: case 1: case 2: 
			CaribInPos_t(item);
			if(Test_Flag[0] == NG){
				SetLcdColor(3);
				item= -1;
				Test_Flag[0]= OK;
			}
			break;
		case 3:
			CaribInPos_t(item);
			if(Test_Flag[0] == NG){
				SetLcdColor(3);
				item= -1;
				Test_Flag[0]= OK;
			}else
				EndFlag= 1;
			break;
		}
		item++;
#ifdef	WIN32
		Delay(100);
#endif
	}

	RectAngle(15*16-20,10*32-10,20*16+20,11*32+10,T_WHITE,T_BLACK);
	RectAngle(30*16-20,10*32-10,32*16+20,11*32+10,T_WHITE,T_BLACK);
	TextOut2(15,10,"Again");
	TextOut2(30,10,"OK");

	WaitRelese();
	while(1){
		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((iKeyCodeX > 15*16-20) && (iKeyCodeX < 20*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			Test_Flag[0]= NG;
			break;								
		}
		if((iKeyCodeX > 30*16-20) && (iKeyCodeX < 32*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			Test_Flag[0]= OK;
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
}
int	touchErrorFlag;
void DrawRectLineRect(int sx,int sy,int ex,int ey,int f_color,int b_color)
{
	RectAngle(sx-10,sy-10,ex+10,ey+10,f_color,b_color);
}
int	TouchTestItem(int item)
{
	int	ret= NG;
	int	iKeyCodeX;
	int	iKeyCodeY;
//	int	BefNonCalbX,BefNonCalbY;
	int	dtaInFlag;
	char	test_buff[48];
	extern	int	bTSP_DownFlag;

	DrawRectLineRect(CalibAddr[item].x,CalibAddr[item].y,CalibAddr[item].x,CalibAddr[item].y,T_WHITE,T_BLACK);
//	BefNonCalbX= NonCalbX;
//	BefNonCalbY= NonCalbY;
	dtaInFlag= 0;

	WaitRelese();
	while(1){
		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((iKeyCodeX != 0) && (iKeyCodeY != 0)){
//			if((BefNonCalbX != NonCalbX) || (BefNonCalbY != NonCalbY)){
			sprintf(test_buff,"Key= (%5d,%5d)",iKeyCodeX,iKeyCodeY);
			TextOut(42,12,test_buff);
			if( (iKeyCodeX > CalibAddr[item].x- 10) && (iKeyCodeX < CalibAddr[item].x+ 10) && 
				(iKeyCodeY > CalibAddr[item].y- 10) && (iKeyCodeY < CalibAddr[item].y+ 10) ){
				ret= OK;
			}
//			break;
//			}
			dtaInFlag= 1;
		}
		if((dtaInFlag == 1) && (bTSP_DownFlag == 0)){
			break;
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
	return(ret);
}
int	TouchTest(void)
{
	int	item= 0;
	int	EndFlag= 0;
	int	result[4];

	ClearDisplay();

	TextOut2(9,1,"********** Touch Test **********");
//	TextOut(18,2,"********** Touch Test **********");
	while(EndFlag == 0){
		switch(item){
		case 0: case 1: case 2: 
			result[item]= TouchTestItem(item);
			break;
		case 3:
			result[item]= TouchTestItem(item);
			EndFlag= 1;
			break;
		}
		item++;
	}
	if( (result[0] == OK) && (result[1] == OK) &&
		(result[2] == OK) && (result[3] == OK) ){
		return(OK);
	}else{
		return(NG);
	}
}
void	TouchSelect(void)
{
	int	EndFlag;
	int	item;

	DModeSendMsg("*** TOUTCH CALIB/TEST Start ***\r\n");
	DModeSendMsg(" 1 = Calibration\r\n");
	DModeSendMsg(" 2 = Touch Test\r\n");
	EndFlag= 0;
	while(EndFlag == 0){
		while(1){
			if(IS_CONSOL( ) != 0){
				item= GET_CONSOL();
				break;
			}
#ifdef	WIN32
			Delay(100);
#endif
		}
		switch(item){
		case '1':	SetTouchCalibration();		break;
		case '2':	TouchTest();				break;
		default:	EndFlag= 1;					break;
		}
		if((item == '1') || (item == '2')){
			DModeSendMsg(" 1 = Calibration\r\n");
			DModeSendMsg(" 2 = Touch Test\r\n");
		}
	}
	DModeSendMsg("*** TOUTCH CALIB/TEST End ***\r\n");
}
void	TouchTest_t(void)
{
	Test_Flag[0]= NG;

	while(1){
		if(Test_Flag[0] == NG){
			//ClearDisplay();
			SetLcdColor(3);
			SetTouchCalibration_t();
		}else if(Test_Flag[0] == OK){
			InposSave();
			break;
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
}

/////////////////////////////////////////////////////////
void	Wait10ms(int cnt)
{
	TimerStart(1,cnt);
	while(1){
		if(time_flag[1] != 0){
			break;
		}
	}
}
/////////////////////////////////////////////////////////////////////////////
//	USB Test
/////////////////////////////////////////////////////////////////////////////

void	UsbTest(int mode)
{
	int	ret;

	SetLcdColor(3);
	TextOut2(5,1,"*************** USB Test ***************");	//40 char
	TextOut2(10,3,"    Send Data : ABCDEFG012345");
	TextOut2(10,5,"Received Data : ");	
	TextOut2(10,7,"       Status : WAITING");

	udc_data_len= 0;
#ifndef WIN32
	ret= TCPTest(1);
#else
	ret = OK;
#endif


	if(ret == OK){
		TextOut2(26,7,"OK        ");
	}	
	else if(ret == WAIT)
	{
		ret = NG;
		TextOut2(26,7,"Waiting...");								

		
		TimerStart(2,300);		//1.5s wait
		
		while(1){
			if(udc_data_len != 0){			break;	}
			if(time_flag[2] != 0){		break;	}
		}
		if(time_flag[2] != 0){
			TextOut2(26,7,"Time Out   ");	
			ret = NG;
		}else{

			if(udc_data_len > 0)
			{
				TextOut2(26,5,(char*)udcdataWBuff);					
				if(memcmp(udcdataWBuff, "ABCDEFG012345", 13) == 0)
				{				
					TextOut2(26,7,"Match      ");									
					ret = OK;					
				}					
				else
				{
					TextOut2(26,7,"MisMatch      ");
					ret = NG;					
				}
				
				memset(udcdataWBuff, 0x00, lanRecCnt);	
				
			}			
		}
	}
	else
	{
		TextOut2(26,7,"Error      ");
	}
		
	disconnect(1);                // disconnect 
	
	//kwon imsi Test_Flag[AUT_USB_TEST]= ItemResultOKNG(ret);//ItemResult(0,0);		  
	//ret = OK;	
	//TextOut2(26,7,"Match      ");
	//TextOut2(26,5,"ABCDEFG012345");
	

	if(iAutoMenuProcess	!= 1)	
	{
		Test_Flag[AUT_USB_TEST]= ItemResultOKNG(ret,0);
		WaitRelese();
	}
	else
		Test_Flag[AUT_USB_TEST] = ret;	

}

/*
void	UsbTest(void)
{

	DModeSendMsg("*** USB Test Start ***\r\n");
	TimerStart(0,3000);		//30s Start
	DModeSendMsg("USB Recieve Wait\r\n");
	while(1){
		if(udc_data_len != 0){			break;	}
		if(time_flag[0] != 0){		break;	}
	}
	if(time_flag[0] != 0){
		DModeSendMsg("USB Test Time Out\r\n");
	}else{
		DModeSendMsg("USB Recieve OK\r\n");
		DModeSendMsg((char*)udcdataWBuff);
		DModeSendMsg("\r\n");
		udc_data_len= 0;
	}
	if(time_flag[0] == 0){
		DModeSendMsg("USB Host Connect Wait\r\n");		//25
		while(1){
			UsbHostDrv();
			if(UsbHostConnected == 1){	break;	}
			if(time_flag[0] != 0){		break;	}
		}
		if(time_flag[0] != 0){
			DModeSendMsg("USB Test Time Out\r\n");
		}else{
			DModeSendMsg("USB Send Data\r\n");
		}
	}
	DModeSendMsg("*** USB Test End ***\r\n");
}
*/
  
int	GetStopArea(void)
{
	int	ret= 0;
	int iKeyCodeX;
	int iKeyCodeY;

//	WaitRelese();
//	while(1){
		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((iKeyCodeX > 20*16-20) && (iKeyCodeX < 30*16+20) && (iKeyCodeY > 8*32-10) && (iKeyCodeY < 9*32+10)){
			ret= 1;
//			break;								
		}
//	}
	return(ret);
}
int	ItemResult(int mode,int okpass)
{
	int iKeyCodeX;
	int iKeyCodeY;
	int	ret;
	int	sec;
	char	dbuff[64];

	TextOut(30,19,"                         ");
	TextOut(30,20,"                         ");
	TextOut(30,21,"                         ");

	if(okpass == 0){
		TextOut2(15,11,"Again");
		TextOut2(25,11,"OK");
		TextOut2(32,11,"NG");
		RectAngle(15*16-20,11*32-10,20*16+20,12*32+10,T_WHITE,T_BLACK);
		RectAngle(25*16-20,11*32-10,27*16+20,12*32+10,T_WHITE,T_BLACK);
		RectAngle(32*16-20,11*32-10,34*16+20,12*32+10,T_WHITE,T_BLACK);
	}else{
		TextOut2(13,11,"Again");
		TextOut2(23,11,"OK/PASS");
		TextOut2(35,11,"NG");
		RectAngle(13*16-20,11*32-10,18*16+20,12*32+10,T_WHITE,T_BLACK);
		RectAngle(23*16-20,11*32-10,30*16+20,12*32+10,T_WHITE,T_BLACK);
		RectAngle(35*16-20,11*32-10,37*16+20,12*32+10,T_WHITE,T_BLACK);
	}

	sec= SystemTime.sec;
	WaitRelese();
	while(1){
		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if(okpass == 0){
			if((iKeyCodeX > 15*16-20) && (iKeyCodeX < 20*16+20) && (iKeyCodeY > 11*32-10) && (iKeyCodeY < 12*32+10)){
				ret= AGAIN;
				break;								
			}
			if((iKeyCodeX > 25*16-20) && (iKeyCodeX < 27*16+20) && (iKeyCodeY > 11*32-10) && (iKeyCodeY < 12*32+10)){
				ret= OK;
				break;								
			}
			if((iKeyCodeX > 32*16-20) && (iKeyCodeX < 34*16+20) && (iKeyCodeY > 11*32-10) && (iKeyCodeY < 12*32+10)){
				ret= NG;
				break;								
			}
		}else{
			if((iKeyCodeX > 13*16-20) && (iKeyCodeX < 18*16+20) && (iKeyCodeY > 11*32-10) && (iKeyCodeY < 12*32+10)){
				ret= AGAIN;
				break;								
			}
			if((iKeyCodeX > 23*16-20) && (iKeyCodeX < 30*16+20) && (iKeyCodeY > 11*32-10) && (iKeyCodeY < 12*32+10)){
				ret= OK;
				break;								
			}
			if((iKeyCodeX > 35*16-20) && (iKeyCodeX < 37*16+20) && (iKeyCodeY > 11*32-10) && (iKeyCodeY < 12*32+10)){
				ret= NG;
				break;								
			}
		}
		if(mode == 1){
			if(strncmp(USB_CMD_SET_TIME,(char*)&udcdataWBuff[0],4) == 0 && sec != SystemTime.sec){
				sec= SystemTime.sec;
				sprintf(dbuff,"%4d/%2d/%2d", SystemTime.year+2000,SystemTime.mon,SystemTime.day);
				TextOut2(24,5,dbuff);
				sprintf(dbuff,"%2d:%2d:%2d", SystemTime.hour,SystemTime.min,SystemTime.sec);
				TextOut2(24,7,dbuff);
			}
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
	return(ret);
}
int	ItemResultOKNG(int mode,int type)
{
	int iKeyCodeX;
	int iKeyCodeY;
//	int	sec,ret;
	int	ret;

	TextOut(30,19,"                         ");
	TextOut(30,20,"                         ");

	if(mode == 0){
		TextOut2(20,10,"Again");
		TextOut2(29,10,"OK");
		RectAngle(20*16-20,10*32-10,25*16+20,11*32+10,T_WHITE,T_BLACK);
		RectAngle(29*16-20,10*32-10,31*16+20,11*32+10,T_WHITE,T_BLACK);
	}else{
		TextOut2(20,10,"Again");
		TextOut2(29,10,"NG");
		RectAngle(20*16-20,10*32-10,25*16+20,11*32+10,T_WHITE,T_BLACK);
		RectAngle(29*16-20,10*32-10,31*16+20,11*32+10,T_WHITE,T_BLACK);
	}

//	sec= SystemTime.sec;
	if(type == 1){
		WaitRelese();
	}
	while(1){
		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((iKeyCodeX > 20*16-20) && (iKeyCodeX < 25*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			ret= AGAIN;
			//NormBuzzer();
			break;								
		}
		if((iKeyCodeX > 29*16-20) && (iKeyCodeX < 31*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			ret= mode;
			//NormBuzzer();
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
	return(ret);
}

void	UsbTest_t(void)
{
	int	i,ret;
	int iKeyCodeX;
	int iKeyCodeY;

	SetLcdColor(3);
	TextOut2(5,1,"*************** USB Test ***************");	//40 char
	TextOut2(17,3,"USB Receive Wait");

	TextOut2(20,8,"TEST START");
	RectAngle(20*16-20,8*32-10,30*16+20,9*32+10,T_WHITE,T_BLACK);


	WaitRelese();
	while(1){
		if(udc_data_len != 0){	
			break;	
		}

		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((iKeyCodeX > 20*16-20) && (iKeyCodeX < 30*16+20) && (iKeyCodeY > 8*32-10) && (iKeyCodeY < 9*32+10)){
			break;								
		}



#ifdef	WIN32
		Delay(100);
#endif
	}

	if(udc_data_len != 0){	

		if(strncmp("TEST0123456789:;<=>?",(char*)&udcdataWBuff[0],20) == 0){
			TextOut2(35,3,"OK        ");
		}else{
			TextOut2(35,3,"Error       ");
		}
	
		udc_data_len= 0;
		memset(udcdataWBuff,0,sizeof(udcdataWBuff));

		TextOut2(10,5,"USB Host Connect         Wait");

		WaitRelese();
		while(1){
			UsbHostDrv();
			if(UsbHostDeviceOK == 1){	
				break;	
			}

			ScanKey(&iKeyCodeX,&iKeyCodeY);
			if((iKeyCodeX > 21*16-20) && (iKeyCodeX < 30*16+20) && (iKeyCodeY > 8*32-10) && (iKeyCodeY < 9*32+10)){
				break;								
			}

#ifdef	WIN32
			Delay(100);
#endif
		}

		if(UsbHostDeviceOK == 1){
			TextOut2(35,5,"OK        ");
			memset(UsbWriteBuff,0,sizeof(UsbWriteBuff));
			for(i= 0; i < 20; i++){
				UsbWriteBuff[i]= '0'+i;
			}
			ret= UsbWriteSector(0,0x200,UsbWriteBuff);
			TextOut2(10,7,"Send");
			if(ret == 0){
				TextOut2(35,7,"OK");
			}else{
				TextOut2(35,7,"Error");
			}
		}
	}
	Test_Flag[AUT_USB_TEST]= ItemResult(0,0);
}

void	UsbAgain(void)
{
	int	mode= 0;
	Test_Flag[AUT_USB_TEST]= AGAIN;
	while(1){
		if(Test_Flag[AUT_USB_TEST] == AGAIN){
			UsbTest(mode);
			mode= 1;
		}else if(Test_Flag[AUT_USB_TEST] == OK || Test_Flag[AUT_USB_TEST] == NG){
			break;
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
}
/////////////////////////////////////////////////////////
//	BackLight Test
/////////////////////////////////////////////////////////
void	BackLightTest(void)
{
	int	EndFlag,item;
	int Prescaler;
	int Devid;
	int Count;
	int CmpCnt;
	int UpdwnCnt;
	char	buff[64];

	DModeSendMsg("*** BackLight Test Start ***\r\n");
	DModeSendMsg(" 1 = Pre-UP\r\n");
	DModeSendMsg(" 2 = Pre-DOWN\r\n");
	DModeSendMsg(" 3 = Dev-UP\r\n");
	DModeSendMsg(" 4 = Dev-DOWN\r\n");
	DModeSendMsg(" 5 = Cnt-UP\r\n");
	DModeSendMsg(" 6 = Cnt-DOWN\r\n");
	DModeSendMsg(" 7 = Cmp-UP\r\n");
	DModeSendMsg(" 8 = Cmp-DOWN\r\n");
	DModeSendMsg(" 9 = X10\r\n");
	DModeSendMsg(" 0 = /10\r\n");
	DModeSendMsg(" A = Save\r\n");
	UpdwnCnt= 1;
	Prescaler= Cal_Data.BackCal.Prescaler;
	Devid= Cal_Data.BackCal.Devid;
	Count= Cal_Data.BackCal.Count;
	CmpCnt= Cal_Data.BackCal.CmpCnt;
	sprintf(buff,"Pre=%d,Dev=%d,Cnt=%d,Cmp=%d,X=%d\r\n",
		Prescaler,Devid,Count,CmpCnt,UpdwnCnt);
	SetBacklight(Prescaler,Devid,Count,CmpCnt);
	DModeSendMsg(buff);
	EndFlag= 0;
	SetLcdColor(T_WHITE);
	while(EndFlag == 0){
		while(1){
			if(IS_CONSOL( ) != 0){
				item= GET_CONSOL();
				break;
			}
#ifdef	WIN32
			Delay(100);
#endif
		}
		switch(item){
		case '1':
			if((Prescaler+UpdwnCnt) < 255){	Prescaler+= UpdwnCnt;	}
			else{							Prescaler= 255;			}
			break;
		case '2':	
			if((Prescaler-UpdwnCnt) > 0){	Prescaler-= UpdwnCnt;	}
			else{							Prescaler= 0;			}
			break;
		case '3':
			if(Devid < 16){	Devid*= 2;	}
			else{			Devid= 16;	}
			break;
		case '4':
			if(Devid > 2){	Devid/= 2;	}
			else{			Devid= 2;	}
			break;
		case '5':
			if((Count+UpdwnCnt) < 65535){	Count+= UpdwnCnt;	}
			else{							Count= 65535;		}
			break;
		case '6':
			if((Count-UpdwnCnt) > 0){	Count-= UpdwnCnt;	}
			else{						Count= 0;			}
			break;
		case '7':
			if((CmpCnt+UpdwnCnt) < Count){	CmpCnt+= UpdwnCnt;	}
			else{							CmpCnt= Count;		}
			break;
		case '8':
			if((CmpCnt-UpdwnCnt) > 0){	CmpCnt-= UpdwnCnt;	}
			else{						CmpCnt= 0;			}
			break;
		case '9':
			if(UpdwnCnt < 1000){	UpdwnCnt*= 10;	}
			else{					UpdwnCnt= 1000;	}
			break;
		case '0':
			if(UpdwnCnt > 1){	UpdwnCnt/= 10;	}
			else{				UpdwnCnt= 1;	}
			break;
		case 'A': case 'a':
			Cal_Data.BackCal.Prescaler= Prescaler;
			Cal_Data.BackCal.Devid= Devid;
			Cal_Data.BackCal.Count= Count;
			Cal_Data.BackCal.CmpCnt= CmpCnt;
			FlashWriteSeq((char*)TOUCH_CALIB_AREA,(char*)&Cal_Data,sizeof(Cal_Data));
		default:	EndFlag= 1;					break;
		}
		SetBacklight(Prescaler,Devid,Count,CmpCnt);
		sprintf(buff,"Pre=%d,Dev=%d,Cnt=%d,Cmp=%d,X=%d\r\n",
				Prescaler,Devid,Count,CmpCnt,UpdwnCnt);
		DModeSendMsg(buff);
	}
	DModeSendMsg("*** BackLight Test End ***\r\n");
}
void	BackLightTest_t(void)
{
	int CmpCnt= 1;
	char	buff[10];
	int iKeyCodeX;
	int iKeyCodeY;

	SetLcdColor(T_WHITE);

	RectAngle(19*16-20,10*32-10,21*16+20,11*32+10,T_BLACK,T_WHITE);
	RectAngle(29*16-20,10*32-10,31*16+20,11*32+10,T_BLACK,T_WHITE);
//	RectAngle(79*8-10,6*16-8,81*8+10,7*16+8,T_BLACK,T_WHITE);
//	RectAngle(79*8-10,18*16-8,81*8+10,19*16+8,T_BLACK,T_WHITE);
//	LineOut(640,120,640,280,T_BLACK,T_WHITE);
	TextOut2(5,1,"************ Backlight Test ************");	//40 char
	TextOut2(18,5,"Brightness : ");
	TextOut2(19,10,"OK");
	TextOut2(29,10,"NG");
	
	Cal_Data.BackCal.Prescaler = BACKLIGHT_PRESCALER;
	Cal_Data.BackCal.Devid = BACKLIGHT_DEV_ID;
	Cal_Data.BackCal.Count = BACKLIGHT_CNT;

	SetBacklight(Cal_Data.BackCal.Prescaler,Cal_Data.BackCal.Devid,
		Cal_Data.BackCal.Count,BACKLIGHT_INTERVAL[0]);
	sprintf(buff,"%3d",CmpCnt);
	TextOut2(31,5,buff);
//	RectAngle(630,barY,650,barY+8,T_BLACK,T_WHITE);
	

	TimerStart( 0, 100 );		

	while(1){	
		if(time_flag[0] != 0){
			CmpCnt++;
			if(CmpCnt >= 4){	CmpCnt= 1;	}
			sprintf(buff,"%3d",CmpCnt);
			TextOut2(31,5,buff);
			switch(CmpCnt){
			case 1:
				SetBacklight(Cal_Data.BackCal.Prescaler,Cal_Data.BackCal.Devid,Cal_Data.BackCal.Count,BACKLIGHT_INTERVAL[0]);				
				break;
			case 2:
				SetBacklight(Cal_Data.BackCal.Prescaler,Cal_Data.BackCal.Devid,Cal_Data.BackCal.Count,BACKLIGHT_INTERVAL[7]);
				break;
			case 3:
				SetBacklight(Cal_Data.BackCal.Prescaler,Cal_Data.BackCal.Devid,Cal_Data.BackCal.Count,BACKLIGHT_INTERVAL[11]);
				break;
			case 4:
				//SetBacklight(Cal_Data.BackCal.Prescaler,Cal_Data.BackCal.Devid,
				//	Cal_Data.BackCal.Count,BACKLIGHT_INTERVAL[15]);
				break;
			}
			TimerStart( 0, 100 );		
		}
		
		ScanKey(&iKeyCodeX, &iKeyCodeY);
		if((iKeyCodeX > 19*16-20) && (iKeyCodeX < 21*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			Test_Flag[AUT_BACKL_TEST]= OK;
			WaitRelese();
			break;								
		}
		if((iKeyCodeX > 29*16-20) && (iKeyCodeX < 31*16+20) && (iKeyCodeY > 10*32-10) && (iKeyCodeY < 11*32+10)){
			Test_Flag[AUT_BACKL_TEST]= NG;
			WaitRelese();
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
	TimerStop( 0 );		

	ForGrandColor= GetColorData(T_WHITE);
	BackGrandColor= GetColorData(T_BLACK);


	SetBacklight(Cal_Data.BackCal.Prescaler,Cal_Data.BackCal.Devid,Cal_Data.BackCal.Count,BACKLIGHT_INTERVAL[11]);
}

/////////////////////////////////////////////////////////
//	PWM Timer Test
/////////////////////////////////////////////////////////
int	PwmTimerTest(void)
{
	int	item,EndFlag;
	int Prescaler;
	int Devid;
	int Count;
	int CmpCnt;
	int UpdwnCnt;
	int	kind;
	int	maxcnt;
	int	premax;
	char	buff[64];

	DModeSendMsg("*** Pwm Timer Test Test Start ***\r\n");
	DModeSendMsg(" 1 = Pre-UP\r\n");
	DModeSendMsg(" 2 = Pre-DOWN\r\n");
	DModeSendMsg(" 3 = Dev-UP\r\n");
	DModeSendMsg(" 4 = Dev-DOWN\r\n");
	DModeSendMsg(" 5 = Cnt-UP\r\n");
	DModeSendMsg(" 6 = Cnt-DOWN\r\n");
	DModeSendMsg(" 7 = Cmp-UP\r\n");
	DModeSendMsg(" 8 = Cmp-DOWN\r\n");
	DModeSendMsg(" 9 = X10\r\n");
	DModeSendMsg(" 0 = /10\r\n");
	DModeSendMsg(" A = Kind\r\n");

	Prescaler= 135;
	Devid= 16;
	Count= 0x255;
	CmpCnt= 0x250;
	kind= 0;
	maxcnt= 65535;
	premax= 255;
	UpdwnCnt= 1;
	sprintf(buff,"Pre=%d,Dev=%d,Cnt=%d,Cmp=%d,X=%d,%s\r\n",
		Prescaler,Devid,Count,CmpCnt,UpdwnCnt,PwmKind[kind]);
	DModeSendMsg(buff);
	
	EndFlag= 0;
	while(EndFlag == 0){
		while(1){
			if(IS_CONSOL( ) != 0){
				item= GET_CONSOL();
				break;
			}
#ifdef	WIN32
			Delay(100);
#endif
		}
		switch(item){
		case '1':
			if((Prescaler+UpdwnCnt) < premax){	Prescaler+= UpdwnCnt;	}
			else{							Prescaler= premax;			}
			break;
		case '2':	
			if((Prescaler-UpdwnCnt) > 0){	Prescaler-= UpdwnCnt;	}
			else{							Prescaler= 0;			}
			break;
		case '3':
			if(Devid < 16){	Devid*= 2;	}
			else{			Devid= 16;	}
			break;
		case '4':
			if(Devid > 2){	Devid/= 2;	}
			else{			Devid= 2;	}
			break;
		case '5':
			if((Count+UpdwnCnt) < maxcnt){	Count+= UpdwnCnt;	}
			else{							Count= maxcnt;		}
			break;
		case '6':
			if((Count-UpdwnCnt) > 0){	Count-= UpdwnCnt;	}
			else{						Count= 0;			}
			break;
		case '7':
			if((CmpCnt+UpdwnCnt) < Count){	CmpCnt+= UpdwnCnt;	}
			else{							CmpCnt= Count;		}
			break;
		case '8':
			if((CmpCnt-UpdwnCnt) > 0){	CmpCnt-= UpdwnCnt;	}
			else{						CmpCnt= 0;			}
			break;
		case '9':
			if(UpdwnCnt < 1000){	UpdwnCnt*= 10;	}
			else{					UpdwnCnt= 1000;	}
			break;
		case '0':
			if(UpdwnCnt > 1){	UpdwnCnt/= 10;	}
			else{				UpdwnCnt= 1;	}
			break;
		case 'A': case 'a':
			if(kind < 5){	kind++;		}
			else{			kind= 0;	}
			if((kind == 4) || (kind == 5)){
				maxcnt= 15;
				Prescaler= 5;
				premax= 5;
				if(Prescaler > 5){	Prescaler= 5;	}
			}else{
				maxcnt= 65535;
				premax= 255;
			}
			break;
		default:
			EndFlag= 1;
			break;
		}
		SetPwmReg(kind,Prescaler,Devid,Count,CmpCnt);
		if(kind < 4){
			sprintf(buff,"Pre=%d,Dev=%d,Cnt=%d,Cmp=%d,X=%d,%s\r\n",
				Prescaler,Devid,Count,CmpCnt,UpdwnCnt,PwmKind[kind]);
		}else{
			sprintf(buff,"Src=%d,Dev=%d,Cnt=%d,Cmp=%d,X=%d,%s\r\n",
				Prescaler,Devid,Count,CmpCnt,UpdwnCnt,PwmKind[kind]);
		}
		DModeSendMsg(buff);
	}
	DModeSendMsg("*** Pwm Timer Test Test End ***\r\n");
	return(0);
}

/////////////////////////////////////////////////////////
//	SEQ/MAC Test
/////////////////////////////////////////////////////////
void	SeqNumTest(void)
{
	int	seqnum;
	char	dbuff[64];

	DModeSendMsg("*** Sequence,MAC Start ***\r\n");
	FlashReadSeq((char*)&fReadBuff[0],(char*)MAC_ADDR_AREA,0x200);
	seqnum= *(int*)&fReadBuff[0];
	sprintf(dbuff,"%08d,%02X,%02X,%02X,%02X,%02X,%02X\r\n",
		seqnum,fReadBuff[9],fReadBuff[8],fReadBuff[7],
		fReadBuff[6],fReadBuff[5],fReadBuff[4]);
	DModeSendMsg(dbuff);
	while(1){
		if(IS_CONSOL( ) != 0){
			GET_CONSOL();
			break;
		}
	}
	DModeSendMsg("*** Sequence,MAC End ***\r\n");
}

//success 1, fail : 0
int CheckMacValue(unsigned char *cMacdata)
{
	unsigned char cData, cData2;


	if(*cMacdata++ != 0x02) // command kinds
		return 0;
	
	cData = *cMacdata++;
	if(cData != 0x03 || cData == 0x83) //Read Holding Registers (0x83: NAK)
		return 0;
	
	if(*cMacdata++ != 0x10)
		return 0;	
	
	return 1;
}


unsigned char cMacDataACK[21];
//unsigned char fReadBuff[0x200];
void	SeqNumTest_t(void)
{
	int i, ret;
	int	seqnum;
	char	dbuff[64];
	
	int iKeyCodeX;
	int iKeyCodeY;	
	int	sec;	

	TextOut2(5,1,"**** SEQ No./MAC Address Set Test ****");	//40 char
	
	TextOut2(7,3,"Saved Mac Address   :    ");	
	TextOut2(7,4,"Saved Serial Number :    ");	
	
	TextOut2(7,6,"Received MAC Address:    ");	
	TextOut2(7,7,"Received Serial Number : ");	
	
#ifndef WIN32
	//read saved mac address / serial number
	FlashReadSeq((char*)&fReadBuff[0],(char*)MAC_ADDR_AREA,0x200);
#endif	
	seqnum= *(int*)&fReadBuff[0];
	sprintf(dbuff,"%08d",seqnum);
	TextOut2(30,4,dbuff);
	
	sprintf(dbuff,"%02X:%02X:%02X:%02X:%02X:%02X",fReadBuff[9],fReadBuff[8],fReadBuff[7],fReadBuff[6],fReadBuff[5],fReadBuff[4]);
	TextOut2(30,3,dbuff);
	
		
	TextOut2(7,8,"Status : Standby");	

	memset(recBuff, 0x00, sizeof(recBuff));
	lanRecCnt = 0;

#ifndef WIN32
	ret = TCPTest(3); //mac request by tcp line	
#else
	ret = OK;
#endif
	if(ret == OK){
		TextOut2(16,8,"MAC Received OK      ");
	}	
	else if(ret == WAIT)
	{
		
		ret = NG;
		TextOut2(16,8,"Waiting...               ");				
		
		lanRecCnt = 0;
		TimerStart(0,300); // 3s?		
		while(1)
		{			
			if(time_flag[0] == 1){		break;	}
			
			if(lanRecCnt > 0)
			{								
				//check MAC format
				if(CheckMacValue(recBuff) != 1)
				{
					TextOut2(16,8,"Wrong format NG       ");						
					//make nak protocol
					cMacDataACK[0] = 0x02;
					cMacDataACK[1] = 0x10;
					cMacDataACK[2] = 0x00;
					cMacDataACK[3] = 0x02;
					cMacDataACK[4] = 0x00;
					cMacDataACK[5] = 0x06;
					cMacDataACK[6] = 0x12;
					cMacDataACK[7] = 0x00;										
					cMacDataACK[8] = 0x15;										
					memset(&cMacDataACK[9], 0x00, 10);
					cMacDataACK[19] = 0x00;
					cMacDataACK[20] = 0x00;	
					
					//TCPTest(5);
					send(1, cMacDataACK, sizeof(cMacDataACK));
					ret = NG;
					break;															
				}				
				else
				{				
					TextOut2(16,8,"MAC Received OK         ");	
					
					sprintf(dbuff,"%02X:%02X:%02X:%02X:%02X:%02X",recBuff[3],recBuff[4],recBuff[5],recBuff[6],recBuff[7],recBuff[8]);									
					TextOut2(30, 6,dbuff);									
					
					seqnum= (recBuff[9] << 24)+(recBuff[10] << 16)+(recBuff[11] << 8)+recBuff[12];
					sprintf(dbuff,"%08d",seqnum);
					TextOut2(33,7,dbuff);	
			
					
					//make ack					
					cMacDataACK[0] = 0x02; // header
					cMacDataACK[1] = 0x10;
					cMacDataACK[2] = 0x00;
					cMacDataACK[3] = 0x02;
					cMacDataACK[4] = 0x00;
					cMacDataACK[5] = 0x06;
					cMacDataACK[6] = 0x12;
					cMacDataACK[7] = 0x00;
					cMacDataACK[8] = 0x06;					
					memcpy(&cMacDataACK[9], &recBuff[3], 10);
					cMacDataACK[19] = 0x00;
					cMacDataACK[20] = 0x00;		
					
					//send(1, cMacDataACK, sizeof(cMacDataACK));
					
					ret= OK;
					break;					
					
				}
				
								
				
				
			}
			
		}		
		
		if(ret == NG && lanRecCnt == 0)
		{
			TextOut2(16,8,"Time Out   ");				
			ret= NG;			
		}		
		
		
	}	
	else 
	{
		TextOut2(16,8,"Error      ");
		ret= NG;		
	}			
	

	TextOut(30,19,"                         ");
	TextOut(30,21,"                         ");	

	TextOut2(13,11,"Again");	
	TextOut2(35,11,"PASS");
	RectAngle(13*16-20,11*32-10,18*16+20,12*32+10,T_WHITE,T_BLACK);	
	RectAngle(35*16-20,11*32-10,39*16+20,12*32+10,T_WHITE,T_BLACK);
	
	
	if(ret == OK)
	{		
		TextOut(30,20,"                         ");
		TextOut2(23,11,"ASSIGN");
		RectAngle(23*16-20,11*32-10,30*16+20,12*32+10,T_WHITE,T_BLACK);	
	}
	
	
	//WaitRelese();
	while(1)
	{
		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((iKeyCodeX > 13*16-20) && (iKeyCodeX < 18*16+20) && (iKeyCodeY > 11*32-10) && (iKeyCodeY < 12*32+10)){
			
			//make nak protocol
			cMacDataACK[0] = 0x02;
			cMacDataACK[1] = 0x10;
			cMacDataACK[2] = 0x00;
			cMacDataACK[3] = 0x02;
			cMacDataACK[4] = 0x00;
			cMacDataACK[5] = 0x06;
			cMacDataACK[6] = 0x12;
			cMacDataACK[7] = 0x00;										
			cMacDataACK[8] = 0x15;										
			//memset(&cMacDataACK[9], 0x00, 10);	
			cMacDataACK[7] = 0x00;										
			cMacDataACK[8] = 0x15;									
			cMacDataACK[19] = 0x00;										
			cMacDataACK[20] = 0x10;
			
			send(1, cMacDataACK, sizeof(cMacDataACK));
		
		
			ret= AGAIN;
			WaitRelese();
			break;								
		}
		else if((ret == OK) && (iKeyCodeX > 23*16-20) && (iKeyCodeX < 30*16+20) && (iKeyCodeY > 11*32-10) && (iKeyCodeY < 12*32+10)){								
		
			//make ack														
			send(1, cMacDataACK, sizeof(cMacDataACK));
	
			
			//save mac to flash
			fReadBuff[0] = cMacDataACK[18];
			fReadBuff[1] = cMacDataACK[17];
			fReadBuff[2] = cMacDataACK[16];
			fReadBuff[3] = cMacDataACK[15];
			fReadBuff[4] = cMacDataACK[14];
			fReadBuff[5] = cMacDataACK[13];
			fReadBuff[6] = cMacDataACK[12];
			fReadBuff[7] = cMacDataACK[11];
			fReadBuff[8] = cMacDataACK[10];
			fReadBuff[9] = cMacDataACK[9];
			
#ifndef WIN32			
			FlashWriteSeq((char*)MAC_ADDR_AREA,(char*)fReadBuff,0x200);				
			FlashReadSeq((char*)&fReadBuff[0],(char*)MAC_ADDR_AREA,0x200);
#endif
			
			sprintf(dbuff,"%02X:%02X:%02X:%02X:%02X:%02X",fReadBuff[9],fReadBuff[8],fReadBuff[7],fReadBuff[6],fReadBuff[5],fReadBuff[4]);
			TextOut2(30,3,dbuff);				
			
			seqnum= (fReadBuff[3] << 24)+(fReadBuff[2] << 16)+(fReadBuff[1] << 8)+fReadBuff[0];
			sprintf(dbuff,"%08d",seqnum);
			TextOut2(30,4,dbuff);	
		
			ret= OK;
			WaitRelese();
			
			break;								
		}
		else if((iKeyCodeX > 35*16-20) && (iKeyCodeX < 39*16+20) && (iKeyCodeY > 11*32-10) && (iKeyCodeY < 12*32+10)){
		
			//make nak protocol
			cMacDataACK[0] = 0x02;
			cMacDataACK[1] = 0x10;
			cMacDataACK[2] = 0x00;
			cMacDataACK[3] = 0x02;
			cMacDataACK[4] = 0x00;
			cMacDataACK[5] = 0x06;
			cMacDataACK[6] = 0x12;
			cMacDataACK[7] = 0x00;										
			cMacDataACK[8] = 0x15;										
			//memset(&cMacDataACK[9], 0x00, 10);					
			cMacDataACK[19] = 0x00;										
			cMacDataACK[20] = 0x10;		
			
			send(1, cMacDataACK, sizeof(cMacDataACK));				

#ifndef WIN32						
			FlashReadSeq((char*)&fReadBuff[0],(char*)MAC_ADDR_AREA,0x200);
#endif
			
			if(fReadBuff[9] == 0x58 && fReadBuff[8] == 0xe8 && fReadBuff[7] == 0x08) // autonics mac id
				ret= OK;
			else
				ret= NG;

			WaitRelese();
			break;								
		}		
		
#ifdef	WIN32
		Delay(100);
#endif
	}
	
	disconnect(1); //tcp disconect
	
	Test_Flag[AUT_SEQ_MAC_TEST]= ret;	
	
}




void	SeqNumAgain(void)
{
	Test_Flag[AUT_SEQ_MAC_TEST]= AGAIN;

	while(1){
		if(Test_Flag[AUT_SEQ_MAC_TEST] == AGAIN){
			SetLcdColor(3);
			SeqNumTest_t();
		}else if(Test_Flag[AUT_SEQ_MAC_TEST] == OK || Test_Flag[AUT_SEQ_MAC_TEST] == NG){
			break;
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
}

/////////////////////////////////////////////////////////
//	Time Test
/////////////////////////////////////////////////////////
void	TimeTest_t(void)
{
//	int	sec;
	char	dbuff[24];

	TextOut2(5,1,"************ Time  Set Test ************");	//40 char
	TextOut2(19,3,"Receive Wait");

	TextOut2(20,8,"TEST STOP");
	RectAngle(20*16-20,8*32-10,30*16+20,9*32+10,T_WHITE,T_BLACK);

	while(1){
		if(strncmp(USB_CMD_SET_TIME,(char*)&udcdataWBuff[0],4) == 0){	
			TextOut2(25,3,"OK       ");
			TextOut2(17,5,"Date :");
			TextOut2(17,7,"Time :");

//			sec= SystemTime.sec;
			sprintf(dbuff,"%4d/%2d/%2d", SystemTime.year+2000,SystemTime.mon,SystemTime.day);
			TextOut2(24,5,dbuff);
			sprintf(dbuff,"%2d:%2d:%2d", SystemTime.hour,SystemTime.min,SystemTime.sec);
			TextOut2(24,7,dbuff);

			udcdataWBuff[0]= 0;
			break;	
		}
		if((ScanStartX > 20*16-20) && (ScanStartX < 30*16+20) && (ScanStartY > 8*32-10) && (ScanStartY < 9*32+10)){
			ScanStartX= 0;
			ScanStartY= 0;
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
	Test_Flag[AUT_DATE_TIME_TEST]= ItemResult(1,1);
}
void	TimeAgain(void)
{
	Test_Flag[AUT_DATE_TIME_TEST]= AGAIN;

	while(1){
		if(Test_Flag[AUT_DATE_TIME_TEST] == AGAIN){
			SetLcdColor(3);
			TimeTest_t();
		}else if(Test_Flag[AUT_DATE_TIME_TEST] == OK || Test_Flag[AUT_DATE_TIME_TEST] == NG){
			break;
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
}


/////////////////////////////////////////////////////////
//	Result
/////////////////////////////////////////////////////////
void	Result(void)
{
	int iKeyCodeX;
	int iKeyCodeY;

	SetLcdColor(3);

	TextOut2(5,1,"********* Hardware Test Result *********");	//40 char
//{Touch, Red, Green, Blue, Black, White, SRAM, SDRAM, NAND FLASH, I/O Port, 
//LED, Switch, Buzzer, Backlight, Battery, W5100, TCP, UDP, RS-232C/RS-422, USB, 
//SEQ No./MAC Address, Date/Time}


	TextOut(1,10,"LCD Test");
	if( Test_Flag[AUT_LCD_PTN1_TEST] == OK &&
		Test_Flag[AUT_LCD_PTN2_TEST] == OK && 
		Test_Flag[AUT_LCD_PTN3_TEST] == OK && 
		Test_Flag[AUT_LCD_PTN4_TEST] == OK && 
		Test_Flag[AUT_LCD_PTN5_TEST] == OK){	TextOut(40,10,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(40,10,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(50,10,"Battery Test");
	if(Test_Flag[AUT_BATT_TEST] == OK){		TextOut(90,10,"OK");	}
	else{ForGrandColor= GetColorData(T_RED);	TextOut(90,10,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(1,12,"Buzzer Test");
	if(Test_Flag[AUT_BUZZER_TEST] == OK){	TextOut(40,12,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(40,12,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(50,12,"Backlight Test");
	if(Test_Flag[AUT_BACKL_TEST] == OK){	TextOut(90,12,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(90,12,"NG");	ForGrandColor= GetColorData(T_WHITE);}
	

#ifdef LP_TYPE

	TextOut(1,14,"Switch Test");
	if(Test_Flag[AUT_SWITCH_TEST] == OK){	TextOut(40,14,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(40,14,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(50,14,"LED Test");
	if(Test_Flag[AUT_LED_TEST] == OK){	TextOut(90,14,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(90,14,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(1,16,"I/O Port Test");
	if(Test_Flag[AUT_I_O_TEST] == OK){	TextOut(40,16,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(40,16,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(50,16,"Serial Test");
	if(Test_Flag[AUT_232C_TEST] == OK){		TextOut(90,16,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(90,16,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(1,18,"Ethernet Test");
	if(Test_Flag[AUT_TCP_TEST] == OK ){		TextOut(40,18,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(40,18,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(50,18,"USB Test");
	if(Test_Flag[AUT_USB_TEST] == OK){	TextOut(90,18,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);		TextOut(90,18,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(1,20,"Time/RTC");
	if(Test_Flag[AUT_RTC_TEST] == OK){ TextOut(40,20,"OK"); }
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(40,20,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(50,20,"SEQ No./MAC Address");
	if(Test_Flag[AUT_SEQ_MAC_TEST] == OK){	TextOut(90,20,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(90,20,"NG");	ForGrandColor= GetColorData(T_WHITE);}	
	
#else

	Test_Flag[AUT_SWITCH_TEST] 	= OK;
	Test_Flag[AUT_LED_TEST] 	= OK;
	Test_Flag[AUT_I_O_TEST] 	= OK;	

	TextOut(1,14,"Serial Test");
	if(Test_Flag[AUT_232C_TEST] == OK){		TextOut(40,14,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(40,14,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(50,14,"Ethernet Test");
	if(Test_Flag[AUT_TCP_TEST] == OK ){		TextOut(90,14,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(90,14,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(1,16,"USB Test");
	if(Test_Flag[AUT_USB_TEST] == OK){	TextOut(40,16,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(40,16,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(50,16,"Time/RTC");
	if(Test_Flag[AUT_RTC_TEST] == OK){	TextOut(90,16,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(90,16,"NG");	ForGrandColor= GetColorData(T_WHITE);}

	TextOut(1,18,"SEQ No./MAC Address");
	if(Test_Flag[AUT_SEQ_MAC_TEST] == OK){	TextOut(40,18,"OK");	}
	else{	ForGrandColor= GetColorData(T_RED);	TextOut(40,18,"NG");	ForGrandColor= GetColorData(T_WHITE);}	


#endif
	

	TextOut(1,29," TEST END OK/NG               POWER       MAIN MENU");
	
	
	WaitRelese();
	while(1)
	{
	
#ifdef	WIN32
		Delay(100);
#endif
	
		ScanKey(&iKeyCodeX, &iKeyCodeY);
		if(iKeyCodeY > 450 )
		{
			WaitRelese();
			break;				
		}
		
	}

	
	
	/*
	while(1)
	{
#ifdef	WIN32
		Delay(100);
#endif
	}
	*/
	
}
//////////////////////////////////////////////////////////////////////
//	Motion Control
//////////////////////////////////////////////////////////////////////
int	Timer0IntCnt;
int	Timer1IntCnt;
void	_Timer0InterruptHandler( void )
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE;

	pINTRegs->rINTMSK |= BIT_TIMER0;
    pINTRegs->rSRCPND = BIT_TIMER0;
    pINTRegs->rINTPND = BIT_TIMER0;
	Timer0IntCnt++;
	pINTRegs->rINTMSK &= ~BIT_TIMER0;
}
void	_Timer1InterruptHandler( void )
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE;

	pINTRegs->rINTMSK |= BIT_TIMER1;
    pINTRegs->rSRCPND = BIT_TIMER1;
    pINTRegs->rINTPND = BIT_TIMER1;
	Timer1IntCnt++;
	pINTRegs->rINTMSK &= ~BIT_TIMER1;
}
void	MotionControl(int ch,int OnOff)
{
	int	MaxCnt;

	MaxCnt= CLOCK_1S_FREQ16/100000;
	if(ch == 0){
		if(OnOff == 1){
			Timer0IntCnt= 0;
			Timer0_Init(MaxCnt);
		}else{
			Timer0_Stop();
		}
	}else{
		if(OnOff == 1){
			Timer1IntCnt= 0;
			Timer1_Init(MaxCnt);
		}else{
			Timer1_Stop();
		}
	}
}
void	MotionTest(void)
{
	int	ret,EndFlag;
	char	buff[32];

	Timer0IntCnt= 0;
	Timer1IntCnt= 0;
	DModeSendMsg("*** Motion Test Start ***\r\n");
	DModeSendMsg(" 1 = CH1-ON\r\n");
	DModeSendMsg(" 2 = CH1-OFF\r\n");
	DModeSendMsg(" 3 = CH2-ON\r\n");
	DModeSendMsg(" 4 = CH2-OFF\r\n");

	EndFlag= 0;
	while(EndFlag == 0){
		while(1){
			if(IS_CONSOL( ) != 0){
				ret= GET_CONSOL();
				break;
			}
			//Counter Display
			sprintf(buff,"TOUT0= %8d",Timer0IntCnt);
			TextOut(40,15,buff);
			sprintf(buff,"TOUT1= %8d",Timer1IntCnt);
			TextOut(40,17,buff);

#ifdef	WIN32
			Delay(100);
#endif
		}
		switch(ret){
		case '1':	MotionControl(0,1);	break;
		case '2':	MotionControl(0,0);	break;
		case '3':	MotionControl(1,1);	break;
		case '4':	MotionControl(1,0);	break;
		default:
			EndFlag= 1;
			break;
		}
	}
	MotionControl(0,0);
	MotionControl(1,0);
	DModeSendMsg("*** Motion Test End ***\r\n");
}

/////////////////////////////////////////////////////////
void	dspTestItem(void)
{
	DModeSendMsg("+++++ Hardware TEST +++++\r\n");
	
	/*
	DModeSendMsg("  1 = Touch Test\r\n");
	DModeSendMsg("  2 = LCD Test\r\n");
	DModeSendMsg("  3 = Battery Test\r\n");
	DModeSendMsg("  4 = Buzzer Test\r\n");
	DModeSendMsg("  5 = BackLight Test\r\n");
	DModeSendMsg("  6 = Memory Test\r\n");
	DModeSendMsg("  7 = SWITCH Test\r\n");
	DModeSendMsg("  8 = LED Test\r\n");
	DModeSendMsg("  9 = I/O Test\r\n");
	DModeSendMsg(" 10 = Serial Test\r\n");
	DModeSendMsg(" 11 = TCP Test\r\n");
	DModeSendMsg(" 12 = USB Test\r\n");
	DModeSendMsg(" 13 = RTC Test\r\n");	
	DModeSendMsg(" 99 = Debug\r\n");
	*/	
	
	DModeSendMsg("  1 = Touch Test\r\n");
	DModeSendMsg("  2 = Memory Test\r\n");
	DModeSendMsg("  3 = LCD Test\r\n");
	DModeSendMsg("  4 = I/O Test\r\n");
	DModeSendMsg("  5 = LED Test\r\n");
	DModeSendMsg("  6 = SWITCH Test\r\n");
	DModeSendMsg("  7 = Buzzer Test\r\n");
	DModeSendMsg("  8 = BackLight Test\r\n");
	DModeSendMsg("  9 = Battery Test\r\n");
	DModeSendMsg(" 10 = RTC Test\r\n");
	DModeSendMsg(" 11 = Motion Test\r\n");
	DModeSendMsg(" 12 = W5100 Test\r\n");
	DModeSendMsg(" 13 = Serial Test\r\n");
	DModeSendMsg(" 14 = USB Test\r\n");
	DModeSendMsg(" 15 = PWM Timer Test\r\n");
	DModeSendMsg(" 16 = SEQ/MAC Test\r\n");
	DModeSendMsg(" 17 = TCP Test\r\n");
	DModeSendMsg(" 99 = Debug\r\n");
	
}


void DrawMainMenu(void)
{

	ClearDisplay();

	dspTestItem();
	
#ifdef LP_TYPE
	TextOut2(5,1,"****** Main Menu (LP Test Ver 1.3) *******");	//40 char
#else
	TextOut2(5,1,"****** Main Menu (GP Test Ver 1.3) *******");	//40 char
#endif
	
//  TextOut2(11,3,TVS_VERSION_MES);	//40 char
//                  ***** LP TEST PROGRAM(V1.0/110212) *****

	TextOut2(10, 4, "Hardware Regular Sequence Test");
	RectAngle(10*16-20, 4*32-20, 40*16+20, 5*32+20, T_WHITE,T_BLACK);	
	
	DrawTestMenusButton();
	

	TextOut(39,27,"Autonics HMI 2011.06.20");			//For Version
	
}

void	HardTest(void)
{
	int i;
	int	idx,ret;
	int	EndFlag= 0;
	int iMainMenu = 1;
	int iMenuNum = -1;
	int	cmd;
	
	
	char	buff[8+2];
	int iKeyCodeX;
	int iKeyCodeY;
	
	iAutoMenuProcess = 0;

	memset(buff,0,sizeof(buff));
	ClearDisplay();

//#ifdef	OLD	    		
	// kwon not use touch
	/*
	while(1){		    
		ret= SetTouchCalibration();
		ClearDisplay();
		if(ret == NG){
			continue;
		}
		break;
	}
	
	while(1){
		ret= TouchTest();
		ret= ItemResultOKNG(ret);
		if(ret == 0){
			break;
		}
	
	}
	*/
	
	
//#endif

	/*
	ClearDisplay();

	dspTestItem();
	TextOut2(5,1,"****** Main Menu (LP Test Ver 1.0) *******");	//40 char
//  TextOut2(11,3,TVS_VERSION_MES);	//40 char
//                  ***** LP TEST PROGRAM(V1.0/110212) *****

	TextOut2(10, 4, "Hardware Regular Sequence Test");
	RectAngle(10*16-20, 4*32-20, 40*16+20, 5*32+20, T_WHITE,T_BLACK);	
	
	DrawTestMenusButton();
	

	TextOut(41,27,"USB Host Disconnect ");			//For USB
	*/

	Test_Flag[AUT_TOUCH_TEST]		= OK;
	Test_Flag[AUT_SRAM_TEST] 		= OK;	
	Test_Flag[AUT_DRAM_TEST] 		= OK;	
	Test_Flag[AUT_NAND_TEST] 		= OK;
	Test_Flag[AUT_DATE_TIME_TEST]	= OK;
	Test_Flag[15] 					= OK;
	Test_Flag[16] 					= OK;


	DrawMainMenu();	
	idx= 0;		
	while(1)
	{

		ScanKey(&iKeyCodeX,&iKeyCodeY); // sequence menu
		if((iKeyCodeX > 10*16-20) && (iKeyCodeX < 40*16+20) && (iKeyCodeY > 4*32-20) && (iKeyCodeY < 5*32+20))
		{
			EndFlag= 1;
			iMainMenu = 1;
			iAutoMenuProcess = 1;  
			WaitRelese();
			break;								
		}
		else //specified menu 
		{					
			iMenuNum = GetMenuPosition(iKeyCodeX, iKeyCodeY);						
			iMainMenu = 0;
			iAutoMenuProcess = 0; 						
			
			switch(iMenuNum)
			{
				case 1:
					LcdTest_t(); 
					break;
					
				case 2:
					BatteryTest_t(); 
					break;
					
				case 3:
					BuzzerTest_t();
					break;
				
				case 4:
					BackLightTest_t(); 
					break;					

#ifdef 			LP_TYPE
					
				case 5: 
					SwitchTest_t();
					break;
					
				case 6:
					LedTest_t();
					break;
				
				case 7: 
					IoTest_t();
					break;
					
				case 8: 
					SerialAgain();
					break;
					
				case 9:
					W5100Test_t();
					break;
				case 10:
					UsbAgain(); 
					break;
					
				case 11: 
					RtcTest_t();
					break;
					
				case 12:
					/*
					for(i=0; i <= 22; i++) // check all test result for assigning mac
					{
						if(i == AUT_SEQ_MAC_TEST)	
							continue;
			
						if(Test_Flag[i] != OK)
							break;
					}
		
					if(i == 23 && Test_Flag[AUT_SEQ_MAC_TEST] == NG)					
					*/
						SeqNumAgain();
					break;
				
				case 13: 
					Result();					
					break;
#else
					
				case 5: 
					SerialAgain();
					break;
					
				case 6:
					W5100Test_t();
					break;
				case 7:
					UsbAgain(); 
					break;
					
				case 8: 
					RtcTest_t();
					break;
					
				case 9:
					/*
					for(i=0; i <= 22; i++) // check all test result for assigning mac
					{
						if(i == AUT_SEQ_MAC_TEST)	
							continue;
			
						if(Test_Flag[i] != OK)
							break;
					}
		
					if(i == 23 && Test_Flag[AUT_SEQ_MAC_TEST] == NG)
					*/
						SeqNumAgain();
					break;
				
				case 10: 
					Result();					
					break;



#endif
					
				default:
					iMainMenu = 1;
					break;
				
					
			}			
		
			EndFlag= 1;		
			
			if(iMainMenu == 0)
			{
				DrawMainMenu();
				idx= 0;
				iMainMenu = 1;				
			}
			
			
		}

		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			if(ret == CR){
				buff[idx++]= 0;
				break;
			}
			buff[idx++]= ret;
			idx &= 7;
			EndFlag= 0;
		}else{
#ifdef	WIN32
				Delay(100);
#endif
		}
		
		//kwon - not need to check host usb
		/*		
		UsbHostDrv();
		if(sUsbHostConnected != UsbHostConnected){
			sUsbHostConnected= UsbHostConnected;
			if(sUsbHostConnected == 1){
				sprintf(dbuff,"USB Host Connect(%d)",UsbHostConnectOK);
				TextOut(41,27,dbuff);
			}else{
				TextOut(41,27,"USB Host Disconnect ");
			}
		}
		*/
	}	
	SetLcdColor(3);


	while(EndFlag == 0)
	{
		//ClearDisplay();
		SetLcdColor(3);
		cmd= gatoi(buff);
		switch(cmd){
		//case  1:		TouchSelect();		break;		
		//case  2:		MemoryTest();		break;			
		case  3:		LcdTest();			break;
		case  4:		IoTest();			break;
		case  5:		LedTest();			break;
		case  6:		SwitchTest();		break;
		case  7:		BuzzerTest();		break;
		case  8:		BackLightTest();	break;
		case  9:		BatteryTest();		break;
		case 10:		RtcTest();			break;
		case 11:		MotionTest();		break;
		case 12:		W5100Test();		break;
		case 13:		SerialTest();		break;
		case 14:		UsbAgain();			break;
		case 15:		PwmTimerTest();		break;
		case 16:		SeqNumTest();		break;
//		case 17:		TcpServerTest();	break;		//Sens Mode
		case 17:		TCPSendRecTest();	break;		//Interrupt
		case 99:		DubugMain();		break;
		}
		dspTestItem();

		idx= 0;
		while(1){
			if(IS_CONSOL( ) != 0){
				ret= GET_CONSOL();
				if(ret == CR){
					buff[idx++]= 0;
					break;
				}
				buff[idx++]= ret;
				idx &= 7;
			}else{
#ifdef	WIN32
				Delay(100);
#endif
			} 
		}
	}
	
	if(EndFlag == 1)
	{
	
		LcdTest_t();
		BatteryTest_t();
		BuzzerTest_t();
		BackLightTest_t();
		
#ifdef LP_TYPE	
		SwitchTest_t();
		LedTest_t();
		IoTest_t();
#else
		Test_Flag[AUT_I_O_TEST]	= OK;
		Test_Flag[AUT_LED_TEST] 	= OK;	
		Test_Flag[AUT_SWITCH_TEST] 	= OK;
#endif
		SerialAgain();
		W5100Test_t();		
		UsbAgain();
		RtcTest_t();				
		
		for(i=0; i <= 22; i++) // check all test result for assigning mac
		{
			if(i == AUT_SEQ_MAC_TEST)	
				continue;
			
			if(Test_Flag[i] != OK)
				break;
		}

		if(i == 23 && Test_Flag[AUT_SEQ_MAC_TEST] == NG)		
			SeqNumAgain();
		
		Result();
		
		HardTest();

//#endi		
		
		
	}
//	DModeSendMsg(" Hardware TEST End\n");

}