/****************************************/
/*      ��??�v���O��?                */
/****************************************/
/*	Buffer                              */ 
#define	MAIN
#include	<string.h>
#include	<stdlib.h>
#include	<stdio.h>

#include	"define.h"
#include	"selib.h"
#include	"mylib.h"
#include	"bios.h"
#include	"s2440.h"
#include	"glplcd.h"
#include	"CommBuff.h"
#include	"disp.h"
#include	"rs232c.h"
#include	"lload.h"
#include	"udebtsk.h"
#include	"touch.h"
#include	"usbh.h"
#include	"udc_2440.h"
#include	"flash.h"
#include	"hardtest.h"

#ifdef	WIN32
#include    "Mts.h"
#include    "MtsCifp.h"
#include    "Mail.h"
#include	"Taskhed.h"
#endif

#define MAX_SIO_BUFFER 0x40000
unsigned short GBuffer[MAX_SIO_BUFFER];
int		bufferInIdx;
int		bufferOutIdx;
int		HexAsciiFlag;
int		MonitorStop;
int		PushState;
int		FirstPageFlag;
int		startidx;
int		DispCnt;

void	InterruptEnableTick(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

#ifdef	WIN32
	return;
#endif
//    pINTRegs->rINTMSK &= ~(1 << INTSRC_TIMER4);
    pINTRegs->rINTMSK &= ~BIT_WDT;
    pINTRegs->rINTSUBMSK &= ~BIT_SUB_WDT;

}
void	InterruptEnableCom2(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

#ifdef	WIN32
	return;
#endif
	pINTRegs->rSRCPND     = BIT_UART2;
	// S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
	if (pINTRegs->rINTPND & BIT_UART2)
		pINTRegs->rINTPND = BIT_UART2;

	pINTRegs->rINTMSK    &= ~BIT_UART2;
}
void	InterruptEnableCom1(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

#ifdef	WIN32
	return;
#endif
	pINTRegs->rSRCPND     = BIT_UART1;
	// S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
	if (pINTRegs->rINTPND & BIT_UART1)
		pINTRegs->rINTPND = BIT_UART1;

	pINTRegs->rINTMSK    &= ~BIT_UART1;
}

void	InterruptEnableCom0(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

#ifdef	WIN32
	return;
#endif
	pINTRegs->rSRCPND     = BIT_UART0;
	// S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
	if (pINTRegs->rINTPND & BIT_UART0)
		pINTRegs->rINTPND = BIT_UART0;

	pINTRegs->rINTMSK    &= ~BIT_UART0;
}

/************************************************************/
/*	�P�������M												*/
/************************************************************/
int	GetMessage( char *ptr )
{
	int c, no;

	no= 0;
	if(IS_CONSOL() != 0){
		while( TRUE ){
			if( (c= GET_CONSOL()) != 0 ){
				switch( c ){
				case 0x0A:	case 0x0D:
					*(ptr+ no)= c;
					no++;
					return( no );
				case 0x08:
					if( no > 0 ){	no--;	}
					break;
				case 0x04:
					*ptr= c;
					return( 1 );
				default:
					*(ptr+ no)= c;
					no++;
					break;
				}
				if( DModeFlag == 0x10 /*OK_LOGIN*/ ){
				}
			}
#ifdef	WIN32
			Delay(100);
#endif
		}

	}
	return( 0 );
}

#define	TIME_INIDMODE	1

//20080819
char msg[256];
void DubugMain( void )
{

	TouchRepeatFlag= 1;
	ClearDisplay();
	BuzOff();

	TimerStart( TIME_INIDMODE, 500 );		/* Wait 5Sec */  

	while( TRUE ){
		if( DModeFlag != 0x10 ){  
			if( time_flag[TIME_INIDMODE] != 0 ){
				TouchRepeatFlag= 0;
				return;
			}
		}
		if( GetMessage( msg ) != 0 ){
			DModeFlag= DebugTask( DModeFlag, &msg[0] );
		}
#ifdef	WIN32
		Delay(100);
#endif
	}

}
#ifdef	WIN32
COLOR_DT    LcdBufWin[LCD_Y_SIZE][LCD_X_SIZE];
#endif
void	SetLcdAddr(void)
{
#ifdef	WIN32
	LcdBuff= (LCD_BUF*)&LcdBufWin[0];
#else
	LcdBuff= (LCD_BUF*)LCD_BUF_ADDR;
#endif
}
void	Disp1Page(void)
{
	int	xPos,yPos;
	int		RxData;
	int	cnt;
	int	idx;

	cnt= DispCnt;
	idx= startidx;
	xPos= 5;
	yPos= 2;
	while(1){
		if(xPos == 5){
			memset(&LcdBuff->lbuff[yPos][0],0,((33*800)*4));
			memset(&LcdBuff->lbuff[yPos+35][0],0,((33*800)*4));
		}
		if(cnt > 0){
			RxData= GBuffer[idx];
			
			idx= ( idx + 1 ) & ( MAX_SIO_BUFFER - 1 );
			
			if((RxData & 0xf00) == 0){
				ForGrandColor = GetColorData(T_WHITE);
				BackGrandColor = GetColorData(T_BLACK);
				if(HexAsciiFlag == 0){	
					DisplayAscii(xPos,yPos,RxData);
				}else{
					DisplayHex(xPos,yPos,RxData);
				}
			}else{
				ForGrandColor = GetColorData(T_YELLOW);
				BackGrandColor = GetColorData(T_BLACK);
				if(HexAsciiFlag == 0){
					DisplayAscii(xPos,yPos+35,RxData);
				}else{
					DisplayHex(xPos,yPos+35,RxData);
				}
				
			}
			cnt--;		
		}
		xPos=xPos+10;
		if(xPos >= 790){
			xPos=5;
			yPos+=70;
			if(yPos >= 420){
				
				break;
			}
		}
	}
}

void	GetPreIndex(int xPos,int yPos)
{
	int	LineCount;

	if(startidx == -1){		//First
		LineCount= (yPos-2)/70;
		DispCnt= (LineCount+1)*79+xPos;
		startidx= bufferInIdx-DispCnt;
		if(startidx < 0){
			if(FirstPageFlag == 0){
				startidx= 0;
				DispCnt= bufferInIdx;
			}else{
				startidx+= MAX_SIO_BUFFER;
				if(startidx < bufferInIdx){
					DispCnt-= (bufferInIdx- startidx);
					startidx= bufferInIdx;
				}
			}
		}
	}else{
		startidx -= 79;
		DispCnt += 79;
		if(DispCnt > 6*79){
			DispCnt= 6*79;
		}
		if(startidx < 0){
			if(FirstPageFlag == 0){
				startidx= 0;
				DispCnt= bufferInIdx;
			}else{
				startidx+= MAX_SIO_BUFFER;
				if(startidx < bufferInIdx){
					DispCnt-= (bufferInIdx- startidx);
					startidx= bufferInIdx;
				}
			}
		}
	}
}
void	GetNextIndex(int xPos,int yPos)
{
	int	LineCount;
	int	saveidx;

	if(startidx == -1){		//First
		LineCount= (yPos-2)/70;
		if(LineCount > 1){
			DispCnt= (LineCount-1)*79+xPos;
			startidx= bufferInIdx-DispCnt;
			if(startidx < 0){
				if(FirstPageFlag == 0){
					startidx= 0;
					DispCnt= bufferInIdx;
				}else{
					startidx+= MAX_SIO_BUFFER;
					if(startidx < bufferInIdx){
						DispCnt-= (bufferInIdx- startidx);
						startidx= bufferInIdx;
					}
				}
			}
		}else{
			DispCnt= xPos;
			startidx= bufferInIdx-DispCnt;
		}
	}else{
		if(startidx < bufferInIdx){
			if((startidx+79) < bufferInIdx){
				startidx += 79;
				if((bufferInIdx - startidx) > 6*79){
					DispCnt= 6*79;
				}else{
					DispCnt= bufferInIdx - startidx;
				}
			}
		}else{
			saveidx= startidx;
			startidx += 79;
			if(startidx >= MAX_SIO_BUFFER){
				startidx = startidx- MAX_SIO_BUFFER;
				if(startidx > bufferInIdx){
					startidx= saveidx;
				}
			}
			if(startidx < bufferInIdx){
				DispCnt= bufferInIdx- startidx;
			}else{
				DispCnt= MAX_SIO_BUFFER- startidx+ bufferInIdx+ 1;
			}
		}
		if(DispCnt > 6*79){
			DispCnt=  6*79;
		}
	}
}

void	MainDisplay(void)
{
	int		i;
	for(i=0;i<6;i++){
//		LineOut(0,i*36+17,319,i*36+17,4,0);
//		LineOut(0,i*36+35,319,i*36+35,0,0);
//		LineOut(0,i*36+17,700,i*36+17, T_WHITE, T_BLACK);
		LineOut(0,i*70+35,800,i*70+35, T_WHITE, T_BLACK);
		LineOut(0,i*70+70,800,i*70+70, T_WHITE, T_BLACK);
	}

	TextOut(2,28,"Serial Set");
	RectAngle(5,430,105,475,T_WHITE, T_BLACK);

	if(HexAsciiFlag == 0){
		TextOut(18,28,"ASCII");
	}else{
		TextOut(18,28,"HEX");
	}
	RectAngle(110,430,210,475,T_WHITE, T_BLACK);

	if(MonitorStop == 0){
		TextOut(31,28,"STOP");
	}else{
		TextOut(31,28,"RUN ");
	}
	RectAngle(215,430,315,475,T_WHITE, T_BLACK);

	TextOut(44,28,"PRINT");
	RectAngle(320,430,420,475,T_WHITE, T_BLACK);
}

void	InitDisplay(void)
{
	RectAngle(0,0,799,479,T_WHITE, T_BLACK);
	RectAngle(10,10,790,470,T_WHITE, T_BLACK);
	TextOut2(5,2, "       Autonics Protocol Analyzer       ");
	TextOut2(5,6, "       Start =====> Any Key Touch       ");
	TextOut2(5,10, "                   HMI                  ");
}

int FindKeyCode(int mode, int *tx, int *ty)
{
	if(mode == 0){
		if((5<=*tx)&&(*tx<=105) && (430<= *ty)&& (*ty <=475))
		{// KeyCode return 5,430,105,475,
			return 1;
		}
		if((110<=*tx)&&(*tx<=210) && (430<= *ty)&& (*ty <=475))
		{
			return 2;
		}
		if((215<=*tx)&&(*tx<=315) && (430<= *ty)&& (*ty <=475))
		{
			return 3;
		}
		if((1<=*tx)&&(*tx<=800) && (1<= *ty)&& (*ty <=210))
		{
			return 4;
		}
		if((1<=*tx)&&(*tx<=800) && (211<= *ty)&& (*ty <=420))
		{
			return 5;
		}
		if((320<=*tx)&&(*tx<=420) && (430<= *ty)&& (*ty <=475))
		{
			return 6;
		}
	}else if(mode==1){
		if((480<=*tx)&&(*tx<=680) && (96<= *ty)&& (*ty <=128))
		{// KeyCode return 5,430,105,475,
			return 1;
		}
		if((480<=*tx)&&(*tx<=680) && (160<= *ty)&& (*ty <=192))
		{
			return 2;
		}
		if((480<=*tx)&&(*tx<=680) && (224<= *ty)&& (*ty <=256))
		{
			return 3;
		}
		if((480<=*tx)&&(*tx<=680) && (288<= *ty)&& (*ty <=320))
		{
			return 4;
		}
		if((600<=*tx)&&(*tx<=798) && (430<= *ty)&& (*ty <=478))
		{
			return 5;
		}
	}
	return NG;
}

void	DisplayHex(int xPos,int yPos,int RxData)
{
	unsigned char	buff[10];
	sprintf((char *)buff,"%1X",(RxData >> 4) & 0x0f);
	DotOut(xPos,yPos,buff);
	sprintf((char *)buff,"%1X", RxData & 0x0f);
	DotOut(xPos,yPos+15,buff);
}
void	DisplayAscii(int xPos,int yPos,int RxData)
{
	unsigned char	buff[10];
	if((RxData & 0xff) <= ' '){		/* 0x20 ���� Code */

		buff[0] = RxData & 0xff;
		buff[1] = NULL;
		DotOut(xPos,yPos,buff);
	}else if(((RxData & 0xff) > ' ') && ((RxData & 0xff) < 0x80)){	/* 0x20 �̻� Code */
		buff[0] = RxData & 0xff;
		buff[1] = NULL;
		DotOut(xPos,yPos+10,buff);
	}else{							/* 0x80 �̻� Code */	
		buff[0] = '*';
		buff[1] = NULL;		
		DotOut(xPos,yPos+10,buff);		
	}
}
/****************************************/ 
/* Loader Main Prog                     */
/****************************************/
#ifdef	WIN32
void    main_start( STTFrm* pSTT )       /* ���C������?�X�N */
#else
void    main_start(void)
#endif
{
	int iKeyCode;
	int px,py;
	int		xPos, yPos;
	int		RxData1;
	int		RxData2;

	int		iKeysavecode;
	unsigned	int		ReadTime;


	SetLcdAddr();
	DownloadBuff= (unsigned char*)DOWNLOAD_BUFF;
	HardInitial();				//MMU Setting
	SysHardInitial();
	ClearDisplay();
	SetSci0Tbl();
	InitSci0(115200,8,0);
	SetSci1Tbl();
	InitSci1(115200,8,0);
	SetSci2Tbl();
//	InitSci2(115200,8,0);
	InterruptEnableCom1();
	InterruptEnableCom0();
	InterruptEnableTick();

	NAND_Map_Check();		//20100729


	TouchInit();

	RtcInit();

	Timer3DefltInit();					//Buzzer


	BatteryAdStart= 0;		//2011.1.25
	_ei();

	ForGrandColor.r= 0xff;			//WHITE()
	ForGrandColor.g= 0xff;			//WHITE()
	ForGrandColor.b= 0xff;			//WHITE()
	BackGrandColor.r= 0x00;			//BLACK
	BackGrandColor.g= 0x00;			//BLACK
	BackGrandColor.b= 0x00;			//BLACK

	DModeFlag = 0;
	SioEchoFlag= 0;
	SubsModeFlag= FALSE;			/* �r�t�a�r��?�h�t���O */
	PloadFlag= FALSE;				/* �v���O��?��?�h�t���O */
	DefaultAdress= 0;				/* �A�h���X�����͎��̃f�t�H���g�l */

//	contrast= DEF_CONTRAST;
//	SetContrast(contrast);


	SetBacklight(0,16,BACKLIGHT_CNT,BACKLIGHT_INTERVAL[11]);		//BackLight Default
	BackLightOnOff(ON);

	LCDDisplayEnable(ON);


//	TextOut(4,3,TVS_VERSION_MES);
//	RectAngle(1,1,798,478,T_WHITE,T_BLACK);

	LoaderStartMsg();


	UsbHostInitial();
	UsbDevIntEnable();
	UsbDevHandlerInit();


//	TextOut(11,10,"Hardware Test Mode");


	#ifndef WIN32
	memcpy(&SeriSet, (void*)COM_SETTING_ADDR,sizeof(SeriSet));
#endif
	if((SeriSet.iSpeed < RS300) || (SeriSet.iSpeed>RS115200)){
		SeriSet.iSpeed = RS38400;
		SeriSet.iData1 = RS_DATA8;
		SeriSet.iStop = RS_STOP01;
		SeriSet.iParity = RS_NONE;
		SeriSet.iData2 = RS_XONOFF;
	}

#ifndef WIN32
	InitSci0(SeriSet.iSpeed, SeriSet.iData1,SeriSet.iParity);
	InitSci1(SeriSet.iSpeed, SeriSet.iData1,SeriSet.iParity);
#endif
	InitDisplay();

	xPos = 5;
	yPos = 2;
	ReadTime =0;
	HexAsciiFlag=0;
	MonitorStop=0;
	PushState=0;
	px = py = -1;

	while(1){
		ScanKey(&px,&py);
		if(px != NG && py != NG){
			break;
		}
#ifdef WIN32
		Delay(100);
#endif
	}

	ClearDisplay();
	MainDisplay();
//	ClearSio0Cnt();
//	ClearSio1Cnt();
	
//	CursorOn(xPos, yPos);
//	CursorOn(xPos, yPos+35);

	while(1){
		while(1){
			ReadTime++;
#ifndef WIN32
			if(ReadTime>50000){
#endif
				// ��ġ ��ġ �ľ�
				ScanKey(&px,&py);
				iKeyCode = FindKeyCode(0,&px, &py);
				
				ReadTime=0;
				ForGrandColor = GetColorData(T_WHITE);
				BackGrandColor = GetColorData(T_BLACK);
				switch(iKeyCode)
				{
				case 1:	
					if(PushState == 0){
						if(MonitorStop == 0){
							NormBuzzer();
						}else{
							NormBuzzer();				/*	Buzzer  */
							vSerialSet(&SeriSet.iSpeed, &SeriSet.iData1, &SeriSet.iStop, &SeriSet.iParity, &SeriSet.iData2 );
							memset(GBuffer,0,sizeof(GBuffer));
							bufferInIdx=0;
							InitSci0(SeriSet.iSpeed,SeriSet.iData1,SeriSet.iParity);
							InitSci1(SeriSet.iSpeed,SeriSet.iData1,SeriSet.iParity);
								
							ClearDisplay();
							MainDisplay();
							
							xPos = 5;
							yPos = 2;
						}
					}
					break;
				case 2:
					if(PushState == 0){
						NormBuzzer();
						HexAsciiFlag =~HexAsciiFlag;
						PushState = ~PushState;
					}
					if(HexAsciiFlag==0)
					{
						TextOut(18,28,"ASCII");
					}else{
						TextOut(18,28," HEX ");
					}
					break;
				case 3:
					if(PushState == 0){
						NormBuzzer();
						MonitorStop = ~MonitorStop;
						if(MonitorStop!=0){
							Sio0RtsOff();
							Sio1RtsOff();
							startidx = -1;
							TextOut(31,28,"RUN ");
						}
						else{
							Sio0RtsOn();
							Sio1RtsOn();
							ClearSio0Cnt();
							ClearSio1Cnt();
							TextOut(31,28,"STOP");
						}
						PushState = ~PushState;
					}
					break;
				case 4:
					if(MonitorStop == 0){
						NormBuzzer();
					}else{
						GetPreIndex(xPos,yPos);
						Disp1Page();
					}
					break;
				case 5:
					if(MonitorStop == 0){
						NormBuzzer();
					}else{
						GetNextIndex(xPos,yPos);
						Disp1Page();
					}
					break;
				case 6:
					NormBuzzer();
					NormBuzzer();
					break;
				default:
					PushState = 0;
				//	ClearDisplay();
				//	MainDisplay();
					break;
				}
#ifndef WIN32
			}
#endif
#ifdef WIN32
			Delay(100);
#endif
			RxData1 = GetSio0();
			RxData2 = GetSio1();

			if(MonitorStop ==0)
			{
				if(RxData1 !=-1){
					bufferInIdx = (bufferInIdx+1)&(MAX_SIO_BUFFER-1);
					if(bufferInIdx > MAX_SIO_BUFFER){
						bufferInIdx = 0;
						memset(GBuffer,0,sizeof(GBuffer));
					}
					GBuffer[bufferInIdx]= (unsigned short)(0x0000+(unsigned short)RxData1);
					break;
				}
				else if(RxData2 != -1){
					bufferInIdx = (bufferInIdx+1)&(MAX_SIO_BUFFER-1);
						if(bufferInIdx > MAX_SIO_BUFFER){
						bufferInIdx = 0;
						memset(GBuffer,0,sizeof(GBuffer));
					}
					GBuffer[bufferInIdx]=(unsigned short)(0x0100+(unsigned short)RxData2);
					break;
				}
			}
			//Delay(50);
		}
//		CursorOff(xPos,yPos);
//		CursorOff(xPos,yPos+35);
		if(RxData1!=-1){
			ForGrandColor = GetColorData(T_WHITE);
			BackGrandColor = GetColorData(T_BLACK);
			if(HexAsciiFlag == 0){
				DisplayAscii(xPos,yPos,RxData1);
			}else{
				DisplayHex(xPos,yPos,RxData1);
			}
		}

		if(RxData2!=-1){
			ForGrandColor = GetColorData(T_YELLOW);
			BackGrandColor = GetColorData(T_BLACK);
			if(HexAsciiFlag == 0){
				DisplayAscii(xPos,yPos+35,RxData2);
			}else{
				DisplayHex(xPos,yPos+35,RxData2);
			}

		}
		

		xPos+=10;
		if(xPos>790){
			xPos=5;
			yPos+=70;
			if(yPos >=420 )
			{
				yPos = 2;
			}
			memset(&LcdBuff->lbuff[yPos][0],0,((33*800)*4));
			memset(&LcdBuff->lbuff[yPos+35][0],0,((33*800)*4));
		}
//		CursorOn(xPos,yPos);
//		CursorOn(xPos,yPos+35);

#ifdef WIN32
		DrawLcd((char *)LcdBuff);
		Delay(1);
#endif
	}

}
/*
void	Wait10ms(int cnt)
{
	TimerStart(1,cnt);
	while(1){
		if(time_flag[1] != 0){
			break;
		}
	}
}

int	GetStopArea(void)
{
	int	ret= 0;
	int iKeyCodeX;
	int iKeyCodeY;

//	WaitRelese();
//	while(1){
		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((iKeyCodeX > 20*16-20) && (iKeyCodeX < 30*16+20) && (iKeyCodeY > 8*32-10) && (iKeyCodeY < 9*32+10)){
			ret= 1;
//			break;								
		}
//	}
	return(ret);
}

int	Timer0IntCnt;
int	Timer1IntCnt;
void	_Timer0InterruptHandler( void )
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE;

	pINTRegs->rINTMSK |= BIT_TIMER0;
    pINTRegs->rSRCPND = BIT_TIMER0;
    pINTRegs->rINTPND = BIT_TIMER0;
	Timer0IntCnt++;
	pINTRegs->rINTMSK &= ~BIT_TIMER0;
}
void	_Timer1InterruptHandler( void )
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE;

	pINTRegs->rINTMSK |= BIT_TIMER1;
    pINTRegs->rSRCPND = BIT_TIMER1;
    pINTRegs->rINTPND = BIT_TIMER1;
	Timer1IntCnt++;
	pINTRegs->rINTMSK &= ~BIT_TIMER1;
}
*/

void SpeedDispaly(int iSpeed)
{
	TextOut2(10,3,"SPEED");
	switch(iSpeed){
	case RS300:
		TextOut2(30,3,"300bps   ");
		break;
	case RS600:
		TextOut2(30,3,"600bps   ");
		break;  
	case RS1200:
		TextOut2(30,3,"1200bps  ");
		break;
	case RS2400:
		TextOut2(30,3,"2400bps  ");
		break;
	case RS4800:
		TextOut2(30,3,"4800bps  ");
		break;
	case RS9600:
		TextOut2(30,3,"9600bps  ");
		break;
	case RS19200:
		TextOut2(30,3,"19200bps ");		
		break;
	case RS38400:
		TextOut2(30,3,"38400bps ");
		break;
	case RS57600:
		TextOut2(30,3,"57600bps ");
		break;
	case RS115200:
		TextOut2(30,3,"115200bps");
		break;           
	}
}
void	DataDisplay(int iData1)
{
	TextOut2(10,5,"DATA BIT");
	if(iData1 == RS_DATA7){
		TextOut2(30,5,"7Bit");
	}else{
		TextOut2(30,5,"8Bit");
	}                    
}
void	StopBitDisplay(int iStop)
{
	TextOut2(10,7,"STOP BIT");
	switch(iStop){      /* STOP 20090527 */ 
	case RS_STOP01:
		TextOut2(30,7,"1Bit");
		break;
	case RS_STOP02:
		TextOut2(30,7,"2Bit");
		break;           
	}
//	DrawLcd((char *)LcdBuff);
}			

void	ParityDisplay(int iParity)
{
	TextOut2(10,9,"PARITY BIT");
	switch(iParity){
	case RS_NONE:
		TextOut2(30,9,"None");
		break;
	case RS_ODD:
		TextOut2(30,9,"Odd");
		break;
	case RS_EVEN:
		TextOut2(30,9,"Even");
		break;
	}
//	DrawLcd((char *)LcdBuff);
}

void		vSerialSet(int *iSpeed, int *iData1, int *iStop, int *iParity, int *iData2 )
{	
	int		iKeyCode;
	int		iKeysavecode;
	int		ReadTime;
	int		px,py;


	ClearDisplay();
	DefaultFormDisplay(4 ,"Serial Setting");

	SpeedDispaly(*iSpeed);
  	DataDisplay(*iData1);
  	StopBitDisplay(*iStop);
  	ParityDisplay(*iParity);

	while(1){
#ifdef WIN32
		Delay(100);
#endif
		ScanKey(&px,&py);
		iKeyCode = FindKeyCode(1,&px, &py);
		
		if ((iKeyCode == 1)&&(iKeyCode != iKeysavecode)) /* SPEED */
		{										
			NormBuzzer();				/*	Buzzer  */
			if (*iSpeed > 8 ) {
				*iSpeed = 0;
			} else {
				(*iSpeed)++;
			}
			SpeedDispaly(*iSpeed);
		} else if ((iKeyCode == 2)&&(iKeyCode != iKeysavecode)) 
		{											
			NormBuzzer();				/*	Buzzer  */
			/*  Data1 ����			 */
			if (*iData1 > 0 ) {
				*iData1 = 0;
			} else {
				(*iData1)++;
			}
			DataDisplay(*iData1);
		} else if ((iKeyCode == 3)&&(iKeyCode != iKeysavecode)) 
		{											
			NormBuzzer();				/*	Buzzer  */
			/*  Stop ����			 */
			if (*iStop > 0 ) {
				*iStop = 0;
			} else {
				(*iStop)++;
			}
			StopBitDisplay(*iStop);
		} else if ((iKeyCode == 4)&&(iKeyCode != iKeysavecode)) 
		{										
			NormBuzzer();				/*	Buzzer  */
			/*  Parity ����			 */
			if (*iParity > 1 ) {
				*iParity = 0;
			} else {
				(*iParity)++;
			}	
			ParityDisplay(*iParity);
		} else if ((iKeyCode ==5)&&(iKeyCode != iKeysavecode)) 
		{
			//	FlashEraseWriteProcCall((char*)COM_SETTING_ADDR,(char*)&Set,sizeof(Set));
#ifndef WIN32
			FlashWriteSeq((char*)COM_SETTING_ADDR,(char*)&SeriSet,sizeof(SeriSet));
#endif
			NormBuzzer();				/*	Buzzer  */
			break;
		}
		else{
			iKeyCode=-1;
		}
		iKeysavecode =iKeyCode;
	}
}



void DefaultFormDisplay(short iType, char* TitleName)
{	
	TextOut2(43,14, "OK");
	RectAngle(0,0,799,479,T_WHITE,T_BLACK);
	RectAngle(1,1,798,478,T_WHITE,T_BLACK);
	RectAngle(600,430,798,478,T_WHITE,T_BLACK);
	TextOut2(18,1, TitleName);
	
//	DrawLcd((char *)LcdBuff);
}
