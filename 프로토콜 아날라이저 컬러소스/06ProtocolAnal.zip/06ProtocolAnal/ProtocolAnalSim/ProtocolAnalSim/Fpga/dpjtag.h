/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpjtag.h                                                */
/*                                                                          */
/*  Description:    Definitions of JTAG constants, types, and functions     */
/*                                                                          */
/****************************************************************************/

#ifndef INC_DPJTAG_H
#define INC_DPJTAG_H

/****************************************************************************/
/* JTAG states codes used to identify current and target JTAG states        */
/****************************************************************************/
#define JTAG_RESET			1
#define JTAG_IDLE			2
#define JTAG_SHDR			3
#define JTAG_SHIR			4
#define JTAG_EXDR			5
#define JTAG_EXIR			6
#define JTAG_DRPAUSE		7
#define JTAG_IRPAUSE		8
#define JTAG_DRUPDATE		9
#define JTAG_IRUPDATE		10
#define JTAG_DRCAPTURE		11

/****************************************************************************/
/* Function prototypes                                                      */
/****************************************************************************/
void dp_wait_cycles(DPUCHAR cycles);
void dp_goto_state(DPUCHAR target_state);
void dp_shift_in(DPULONG start_bit, DPUINT num_bits, DPUCHAR* tdi_data,DPUCHAR terminate);
void dp_shift_in_out(DPUINT num_bits, DPUCHAR* tdi_data,DPUCHAR* tdo_data);
void dp_get_and_shift_in(DPUCHAR Variable_ID,DPUINT total_bits_to_shift, DPULONG start_bit_index);
void dp_get_and_shift_in_out(DPUCHAR Variable_ID,DPUCHAR total_bits_to_shift, DPULONG start_bit_index,DPUCHAR* tdo_data);

extern DPUCHAR * page_buffer_ptr;
extern DPULONG requested_bytes;
extern DPUCHAR global_jtag_i;
extern DPUCHAR current_jtag_state;
extern DPUCHAR idx;
extern DPUCHAR data_buf;
extern DPUCHAR bit_buf;
extern DPUCHAR error_code;


#endif /* INC_DPJTAG_H */
