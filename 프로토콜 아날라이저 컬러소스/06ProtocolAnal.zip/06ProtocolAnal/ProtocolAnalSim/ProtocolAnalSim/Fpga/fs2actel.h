/****************************************************************************
** fs2actel.h
**
** Description:
**   External interface of the ABI for the Actel proASIC programmer.
**   Supersedes abiactel.h.
**
** $og:  $ 
 * revision /main/ewe/ewe_fpcomm_parport/1  05/07/27 08:42:09  kiumh 
 
** Revision 1.6  2005/05/17 20:48:05  ernie
** Added support for FlashPro Bit-Bang probe.
**
** Revision 1.5  2004/08/30 22:18:12  ernie
** Explicitly declare __cdecl so other types of clients can use ABI functions.
**
** Revision 1.4  2004/07/30 19:53:11  ernie
** Corrected typos in comments.
**
** Revision 1.3  2004/07/27 15:06:23  ernie
** Added Fs2Fp3bGetResponseWait
**
** Revision 1.2  2004/07/14 18:50:38  ernie
** Added functions Fs2Fp3bGetN and Fs2Fp3bGetBytesWaiting.
**
** Revision 1.1  2004/07/09 21:19:29  ernie
** Initial revision.
**
** $Id:  /main/ewe/3 05/08/02 09:42:00 integ exp $
**
** Copyright (C) 1998-2004 First Silicon Solutions, Inc.
** All rights reserved.
****************************************************************************/
#ifndef _FS2ACTEL_H
#define _FS2ACTEL_H
                            /***********************
                            **                    **
                            **      Includes      **
                            **                    **
                            ***********************/
#include <windows.h>
#include <pshpack4.h>      /* force 4 byte alignment of structure members */

                            /***********************
                            **                    **
                            **  Type declarations **
                            **                    **
                            ***********************/

typedef unsigned char U8;  /* 8-bit unsigned integer  */
typedef signed char   S8;  /* 8-bit signed integer    */
typedef unsigned int U32;  /* 32-bit unsigned integer */
typedef signed int   S32;  /* 32-bit signed integer   */
typedef char * CHARPTR ;   /* char pointer */
typedef U32 ABI_ADDR;
typedef U32 ABI_REGVALUE;

#ifdef ABI_MODULE
# define ABIEXPORT               __declspec(dllexport)
# define ABIVAREXPORT_(type)     __declspec(dllexport) type
#else
#  ifdef __cplusplus
#    define ABIEXPORT extern "C" __declspec(dllimport)
#    define ABIVAREXPORT_(type)  extern "C" __declspec(dllimport) type
#  else
#    define ABIEXPORT            __declspec(dllimport)
#    define ABIVAREXPORT_(type)  __declspec(dllimport) type
#  endif
#endif

#ifdef WIN32
# define ABICDECL __cdecl
#else
# define ABICDECL /**/
#endif

/*
** Error code definitions for return values from ABI functions
*/
#define MAKE_ER(code) (MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, code))
#define GOOD                     ERROR_SUCCESS

#define ER_ABI_NOT_INITIALIZED   MAKE_ER(0x8000)
#define ER_ABI_NO_OPEN_PORT      MAKE_ER(0x8001)
#define ER_NOT_IMPLEMENTED       MAKE_ER(0x8002)
#define ER_NOT_SUPPORTED         MAKE_ER(0x8003)
#define ER_BAD_PARAM             MAKE_ER(0x8004)
#define ER_TEMP_MEM              MAKE_ER(0x8005)
#define ER_ABORTED               MAKE_ER(0x8006)

#define ER_PORT_NOT_SPECIFIED    MAKE_ER(0x810b)
#define ER_PORT_NOT_INSTALLED    MAKE_ER(0x810c)
#define ER_PORT_UNKNOWN          MAKE_ER(0x810d)
#define ER_PORT_ALREADY_OPEN     MAKE_ER(0x810e)
#define ER_PORT_OPEN_FAIL        MAKE_ER(0x810f)
#define ER_PORT_ACQUIRE_FAIL     MAKE_ER(0x8110)
#define ER_PORT_RELEASE_FAIL     MAKE_ER(0x8111)
#define ER_PORT_NOT_EPP          MAKE_ER(0x8112)
#define ER_PORT_NEGOTIATION      MAKE_ER(0x8113)
#define ER_TARGET_POWER          MAKE_ER(0x8124)
#define ER_PORT_NOT_PS2          MAKE_ER(0x812f)
#define ER_WINEXEC               MAKE_ER(0x8114)
#define ER_FLASH_TIMING_LIMIT    MAKE_ER(0x8115)
#define ER_INCORRECT_SYSTEM_TYPE MAKE_ER(0x8117)
#define ER_VERSION_MISMATCH      MAKE_ER(0x8118)
#define ER_DEVICE_NOT_J1         MAKE_ER(0x811a)
#define ER_INTERNAL_TIMEOUT      MAKE_ER(0x811d)
#define ER_HALT_TIMEOUT          MAKE_ER(0x811e)
#define ER_EPP_TIMEOUT           MAKE_ER(0x8121)
#define ER_EPP_DEVICE_RESET      MAKE_ER(0x8122)
#define ER_JTAG_CABLE_FAULT      MAKE_ER(0x8123)
#define ER_TCK_RATE_J2           MAKE_ER(0x8141)
#define ER_OUT_OF_RANGE          MAKE_ER(0x8146)    
#define ER_USB_NO_HID_DEVICES    MAKE_ER(0x8152)
#define ER_USB_NO_FS2_DEVICES    MAKE_ER(0x8153)
#define ER_USB_NO_FS2_SERIAL     MAKE_ER(0x8154)
#define ER_USB_NOT_OPEN          MAKE_ER(0x8155)
#define ER_USB_CANT_GET_PATH     MAKE_ER(0x8156)
#define ER_USB_READ_FAILED       MAKE_ER(0x8157)
#define ER_USB_WRITE_FAILED      MAKE_ER(0x8158)
#define ER_USB_COMM              MAKE_ER(0x8159)
#define ER_USB_TIMEOUT           MAKE_ER(0x815a)
#define ER_USB_CANT_OPEN_HID_DLL MAKE_ER(0x815b)
#define ER_USB_HID_MISSING  MAKE_ER(0x815c)
#define ER_USB_NOT_SUPPORTED     MAKE_ER(0x815d)


/*
** Version.  Static strings indicate system type and version.
*/
typedef struct {
   char *systemType;
   char *version;
   char *copyright;
   char *serialNumber;
} VERSION;

typedef HANDLE HPROBE;

                            /***********************
                            **                    **
                            **  Global Variables  **
                            **                    **
                            ***********************/
#ifndef ABI_MODULE

/****************************************************************************
** abiVersion
**
** Access:
**    Read-only.
**
** Description:
**    Reflects version information about the Abi.
**
****************************************************************************/
ABIVAREXPORT_(VERSION *) abiVersion;

/****************************************************************************
** abiAbort
**
** Access:
**    Read/Write.
**
** Description:
**    The application should write a 1 to this variable to request that any
**    Abi operations currently in progress return immediately and any future
**    Abi functions return before beginning processing.
**
**    Typically abiAbort would be set to 0 before executing a command.  If
**    the user presses ESC or a Cancel button, abiAbort would be set to 1.
**
****************************************************************************/
ABIVAREXPORT_(U32) abiAbort;

#endif



                            /***********************
                            **                    **
                            **     Prototypes     **
                            **                    **
                            ***********************/

/*
** Compatibility key:
**    FlashPro = FlashPro USB or parallel
**    FPL      = FlashPro Lite parallel
**    FP3      = FlashPro 3 revision A (obsolete)
**    FP3B     = FlashPro 3 revision B (shipping version)
**    FPBB     = Bit-bang probe (a/k/a "Wiggler")
*/

/****************************************************************************
** Fs2Init
**
** Description:
**    Init function called to initialize ABI.
**    Must be called before any other ABI function.
**
** Returns:
**    GOOD
**    ER_TEMP_MEM          Insufficient temporary memory available
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B, FPBB
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Init(void);


/****************************************************************************
** Fs2Cleanup
**
** Description:
**    Called just before exiting application to release any resources.
**
** Returns:
**    GOOD
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B, FPBB
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Cleanup(void);


/****************************************************************************
** Fs2OpenPort
**
** Description:
**    Open communication to programmer and return communication handle.
**
** Parameters:
**    portName:  Specify name of port to use:
**                "lpt1", "lpt2", "lpt3" = Flash Pro parallel port
**                    or FPL parallel port
**                "usb", "usb12345" = Flash Pro USB port or FP3 or
**                    FP3B USB port
**                "altlpt1", "altlpt2", "altlpt3" = Flash Pro Bit-Bang
**    hprobe:    Pointer to HPROBE to receive comm handle
**
** Notes:
**    This call sets the parallel port or USB port into a mode
**    compatible with the probe hardware.  lptX uses EPP mode if
**    available, else ECP mode if available, else bidirectional mode.
**    altlptX uses SPP or bidirectional mode.
**
** Returns:
**    GOOD
**    ER_ABI_NOT_INITIALIZED   Must call AbiInit()
**    ER_PORT_*            Communication initialization problem
**    ER_EPP_*             Host communication error
**    ER_USB_*             Host communication error
**    ER_WINEXEC           Could not execute portloc.exe.  Check installation.
**    ER_INCORRECT_SYSTEM_TYPE   System on comport is not Flash Pro
**    ER_VERSION_MISMATCH  Version number from hardware does not match software.
**    ER_DEVICE_NOT_J1     Device on comport is not Flash Pro
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B, FPBB
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2OpenPort(char *portName, HPROBE *hprobe);

/****************************************************************************
** Fs2ClosePort
**
** Parameters:
**    hprobe:    Which probe to close
**
** Description:
**    Release communication to probe
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B, FPBB
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2ClosePort(HPROBE hprobe);

/****************************************************************************
** Fs2JtagReset
** Fs2JtagIdle
** Fs2JtagIrEnter
** Fs2JtagDrEnter
** Fs2JtagShift
** Fs2JtagShiftx
** Fs2JtagRead
** Fs2JtagPauseToPIR
** Fs2JtagPauseToPDR
**
** Description:
**   Reset:    Send TMS=1,1,1,1,1 to go to Test-Logic-Reset state.
**   Idle:     Traverse from Pause to Idle.
**   IrEnter:  Traverse from Idle or Reset to Shift-IR or Pause-IR.
**   DrEnter:  Traverse from Idle or Reset to Shift-DR or Pause-DR.
**   Shift:    Shift <bits> data bits starting at bit 0 of data[0],
**                 then remain in Shift or go to Pause state.
**                 <bits> must be greater than or equal to 1.
**   Shiftx:   Shift <bits> data bits starting at bit 0 of data[0],
**                 then traverse to Run-Test-Idle state.
**                 <bits> must be greater than or equal to 1.
**   Read:     Return data output on TDO from previous shift sequence.
**                 The first bit shifted out on TDO is in bit 0 of data[0].
**   PauseToPIR: Traverse from Pause-DR or Pause-IR to Pause-IR without
**                 going through Idle.
**   PauseToPDR: Traverse from Pause-DR or Pause-IR to Pause-DR without
**                 going through Idle.
**
** Returns:
**    GOOD                 Successful
**    ER_ABI_NOT_INITIALIZED   Must call AbiInit()
**    ER_ABI_NO_OPEN_PORT  Must call AbiOpenPort()
**    ER_INTERNAL_TIMEOUT  Programmer did not respond as expected.  Check connections.
**    ER_JTAG_CABLE_FAULT  JTAG cable not properly connected to target
**    ER_EPP_*             Host communication error
**    ER_USB_*             Host communication error
**
** Compatibility:
**    FlashPro, FPL, FP3, FPBB.  Not valid with FP3B.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2JtagReset(HPROBE hprobe);
ABIEXPORT HRESULT ABICDECL Fs2JtagIdle(HPROBE hprobe);
ABIEXPORT HRESULT ABICDECL Fs2JtagIrEnter(HPROBE hprobe);
ABIEXPORT HRESULT ABICDECL Fs2JtagDrEnter(HPROBE hprobe);
ABIEXPORT HRESULT ABICDECL Fs2JtagShift(HPROBE hprobe, U8 *data, U32 bits);
ABIEXPORT HRESULT ABICDECL Fs2JtagShiftx(HPROBE hprobe, U8 *data, U32 bits);
ABIEXPORT HRESULT ABICDECL Fs2JtagRead(HPROBE hprobe, U8 *data, U32 bits);
ABIEXPORT HRESULT ABICDECL Fs2JtagPauseToPIR(HPROBE hprobe);
ABIEXPORT HRESULT ABICDECL Fs2JtagPauseToPDR(HPROBE hprobe);


/****************************************************************************
** Fs2JtagWait
** Fs2JtagWaitSetup
** Fs2JtagWaitPoll
** Fs2JtagWaitTimer
**
** Description:
**    Wait:      Pause until <ticks> TCK's have been output.  Uses hardware counter.
**    WaitSetup: Start the timer at <ticks> TCK's.  Return immediately.
**    WaitPoll:  Check whether the timer has expired.
**    WaitTimer: Pause until timer has expired without setting it first.
**
** Returns:
**    GOOD                 Successful
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT  Must call Fs2OpenPort()
**    ER_INTERNAL_TIMEOUT  Programmer did not respond as expected.  Check connections.
**    ER_JTAG_CABLE_FAULT  JTAG cable not properly connected to target
**    ER_EPP_*             Host communication error
**    ER_USB_*             Host communication error
**
** Compatibility:
**    FlashPro, FPL, FP3.  Not valid with FP3B or FPBB.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2JtagWait(HPROBE hprobe, U32 ticks);
ABIEXPORT HRESULT ABICDECL Fs2JtagWaitSetup(HPROBE hprobe, U32 ticks);
ABIEXPORT HRESULT ABICDECL Fs2JtagWaitPoll(HPROBE hprobe, BOOLEAN *expired);
ABIEXPORT HRESULT ABICDECL Fs2JtagWaitTimer(HPROBE hprobe);


/****************************************************************************
** Fs2SetJtagEnable
** Fs2GetJtagEnable
**
** Description:
**   Enable or disable output drivers on TCK, TDI, and TMS pins.  After
**   poweron, enable is 0 and the outputs are isolated.
**
** Returns:
**    GOOD                 Successful
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT  Must call Fs2OpenPort()
**    ER_INTERNAL_TIMEOUT  Programmer did not respond as expected.  Check connections.
**    ER_JTAG_CABLE_FAULT  JTAG cable not properly connected to target
**    ER_EPP_*             Host communication error
**    ER_USB_*             Host communication error
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B, FPBB.
****************************************************************************/
typedef enum {
   ABI_JTAG_Z,
   ABI_JTAG_RUN,
   ABI_JTAG_STOP    /* This mode supported for FlashPro3b only */
} ABI_JTAG_MODE;

ABIEXPORT HRESULT ABICDECL Fs2SetJtagEnable(HPROBE hprobe, ABI_JTAG_MODE mode);
ABIEXPORT HRESULT ABICDECL Fs2GetJtagEnable(HPROBE hprobe, ABI_JTAG_MODE *mode);


/****************************************************************************
** Fs2SetSupply
**
** Description:
**   Set one output power supply to specified mode and voltage.
**
** Parameters:
**   supply      Which supply to set voltage of.
**   mode        Set power supply mode
**   millivolts  New power supply voltage, in millivolts
** 
** Returns:
**    GOOD                 Successful
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT  Must call Fs2OpenPort()
**    ER_EPP_*             Host communication error
**    ER_USB_*             Host communication error
**    ER_OUT_OF_RANGE      Unsupported voltage or mode specified
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B.  Not valid with FPBB.
****************************************************************************/
typedef enum {
   ABI_VDDP,      /* I/O voltage */
   ABI_VDDL,      /* Core voltage */
   ABI_VPP,       /* Positive programming voltage */
   ABI_VPN        /* Negative programming voltage */
} ABI_SUPPLY;

#define ABI_VPUMP ABI_VPP
#define ABI_VJTAG ABI_VDDL

typedef enum {
   ABI_GROUND,
   ABI_HIZ,
   ABI_POWER
} ABI_SUPPLY_MODE;

ABIEXPORT HRESULT ABICDECL Fs2SetSupply(HPROBE hprobe, ABI_SUPPLY supply, ABI_SUPPLY_MODE mode, S32 millivolts);


/****************************************************************************
** Fs2GetSupply
**
** Description:
**   Get status of one output power supply
**
** Parameters:
**   supply      Which supply to get status of.
**   mode        Current hardware setting of supply.
**   millivolts  Measured level of supply in millivolts.
** 
** Returns:
**    GOOD                 Successful
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT  Must call Fs2OpenPort()
**    ER_EPP_*             Host communication error
**    ER_USB_*             Host communication error
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B.  Not valid with FPBB.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2GetSupply(HPROBE hprobe, ABI_SUPPLY supply, ABI_SUPPLY_MODE *mode, S32 *millivolts);


/****************************************************************************
** Fs2SetTckRate
** Fs2GetTckRate
**
** Description:
**   Set or Get the frequency of TCK.
**
** Parameters:
**   hertz      TCK frequency in Hertz
**
** Returns:
**    GOOD                 Successful
**    ER_ABI_NOT_INITIALIZED   Must call AbiInit()
**    ER_ABI_NO_OPEN_PORT  Must call Fs2OpenPort()
**    ER_TCK_RATE_J2       Specified frequency is outside supported range.
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B.  Not valid with FPBB.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2SetTckRate(HPROBE hprobe, U32 hertz);
ABIEXPORT HRESULT ABICDECL Fs2GetTckRate(HPROBE hprobe, U32 *hertz);


/****************************************************************************
** Fs2SetOut0
** Fs2GetOut0
** Fs2SetnTRST
** Fs2GetnTRST
**
** Description:
**   Set or Get the setting of discrete output pins
**
** Parameters:
**   state      State of OUT0 or nTRST pin
**     OUT_OFF     pin is high-impedance
**     OUT_TOGGLE  pin toggles at same rate as TCK
**     OUT_LOW     pin is held in low logic state
**     OUT_HIGH    pin is held in high logic state
**
** Returns:
**    GOOD                 Successful
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT  Must call Fs2OpenPort()
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B, FPBB.
****************************************************************************/
typedef enum {
  OUT_OFF,
  OUT_TOGGLE,
  OUT_LOW,
  OUT_HIGH
} ABI_OUT_MODE;

ABIEXPORT HRESULT ABICDECL Fs2SetOut0(HPROBE hprobe, ABI_OUT_MODE state);
ABIEXPORT HRESULT ABICDECL Fs2GetOut0(HPROBE hprobe, ABI_OUT_MODE *state);
ABIEXPORT HRESULT ABICDECL Fs2SetnTRST(HPROBE hprobe, ABI_OUT_MODE state);
ABIEXPORT HRESULT ABICDECL Fs2GetnTRST(HPROBE hprobe, ABI_OUT_MODE *state);


/****************************************************************************
** Fs2GetErrorText
**
** Description:
**    Return error text string for ABI error code.
**
** Returns:
**    error text
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B, FPBB.
****************************************************************************/
ABIEXPORT CHARPTR ABICDECL Fs2GetErrorText(HRESULT err); 


/****************************************************************************
** Fs2Test
**
** Description:
**    Execute hardware selftest when cable plugged into loopback board.
**
** Returns:
**    GOOD
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT  Must call Fs2OpenPort()
**
** Compatibility:
**    FlashPro, FP3, FP3B.  Not valid with FPBB.
****************************************************************************/
#define TEST_MESSAGE_SIZE 1024
typedef struct {
   enum {TEST_PASSED, TEST_FAILED} outcome;
   char message[TEST_MESSAGE_SIZE];
} TEST_RESULT;

ABIEXPORT HRESULT ABICDECL Fs2Test(HPROBE hprobe, TEST_RESULT *result);


/****************************************************************************
** Fs2_Test
**
** Description:
**    Handle options for Console _test command (not used by application)
**
** Returns:
**    GOOD
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT  Must call Fs2OpenPort()
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B, FPBB.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2_Test(HPROBE hprobe, int argc, char *argv[], char *result);


/****************************************************************************
** Fs2JtagTest
**
** Description:
**    Evaluate health of JTAG output signals TCK, TDI, and TMS.  Leaves TAP
**    in Test-Logic-Reset state.  Unlike Fs2Test, Fs2JtagTest is intended to
**    be used while connected to a powered user system.
**
** Returns:
**    GOOD
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT      Must call Fs2OpenPort()
**    ER_NOT_SUPPORTED         System must be a FlashPro3
**
** Compatibility:
**    FP3, FP3B.
****************************************************************************/
/* See definition of TEST_RESULT near the Fs2Test prototype*/
ABIEXPORT HRESULT ABICDECL Fs2JtagTest(HPROBE hprobe, TEST_RESULT *result);

/****************************************************************************
** Fs2GetUsbDeviceList
**
** Description:
**    Return a list of available FlashPro or FlashPro3 devices connected
**    to a USB port on this host.  Devices already in use by this or another
**    application are not listed.  Devices are not necessarily returned in
*     any particular order.
**
** Parameters:
**    devices:   Pointer to array supplied by caller to receive device information.
**          This parameter must point to memory of at least SIZE_FP_DEVICE_ARRAY.
**          All array elements are filled in; those beyond the last physical
**          device attached are filled with zeroes.
**
** Returns:
**    GOOD
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_USB_*                 Host communication error
**
** Compatibility:
**    FlashPro, FP3, FP3B.
****************************************************************************/
typedef enum {
   FP_UNKNOWN,          /* unknown or no device opened or connected */
   FP_FLASH_PRO,        /* flash pro */
   FP_FLASH_PRO_LITE,   /* flash pro lite */
   FP_FLASH_PRO_3,      /* flash pro 3 */
   FP_FLASH_PRO_3B,     /* flash pro 3B */
   FP_FLASH_PRO_ALT     /* flash pro bit-bang mode */
} FP_DEVICE_TYPE;

typedef struct {
   char port[9];         /* Null-terminated string of the form usbNNNNN */
   FP_DEVICE_TYPE type;  /* programmer type */
} FP_DEVICE_INFO;

#define MAX_FPUSB_DEVICES 128
#define SIZE_FP_DEVICE_ARRAY (MAX_FPUSB_DEVICES*sizeof(FP_DEVICE_INFO))

ABIEXPORT HRESULT ABICDECL Fs2GetUsbDeviceList(FP_DEVICE_INFO *devices);


/****************************************************************************
** Fs2GetSystemType
**
** Description:
**    Return the type of programmer currently open.
**
** Parameters:
**    type:   Pointer to FP_DEVICE_TYPE to be filled in with system type.
**
** Returns:
**    GOOD
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT      Must call Fs2OpenPort()
**    ER_USB_*                 Host communication error
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B, FPBB.
****************************************************************************/
/* See Fs2GetUsbDeviceList for definition of FP_DEVICE_TYPE */
ABIEXPORT HRESULT ABICDECL Fs2GetSystemType(HPROBE hprobe, FP_DEVICE_TYPE *type);

/****************************************************************************
** Fs2GetConnectionType
**
** Description:
**    Return the type of connection currently in use
**
** Parameters:
**    type:   Pointer to FP_CONNECTION_TYPE to be filled in with
**    connection type.
**
** Returns:
**    GOOD
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT      Must call Fs2OpenPort()
**    ER_USB_*                 Host communication error
**
** Compatibility:
**    FlashPro, FPL, FP3, FP3B, FPBB.
****************************************************************************/
typedef enum {
   FP_CONNECTION_NONE,   /* no connection */
   FP_CONNECTION_EPP,    /* EPP parallel */
   FP_CONNECTION_ECP,    /* ECP parallel */
   FP_CONNECTION_BIDI,   /* Bidirectional parallel */
   FP_CONNECTION_USBFS,  /* Full-speed (12Mbps) USB */
   FP_CONNECTION_USBHS   /* High-speed (480Mbps) USB */
} FP_CONNECTION_TYPE;

ABIEXPORT HRESULT ABICDECL Fs2GetConnectionType(HPROBE hprobe, FP_CONNECTION_TYPE *type);


/****************************************************************************
** Fs2UsbFlush
**
** Description:
**    Commit all previous ABI operations to hardware
**
** Returns:
**    GOOD
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT      Must call Fs2OpenPort()
**    ER_USB_*                 Host communication error
**
** Compatibility:
**    FlashPro, FP3, FP3B.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2UsbFlush(HPROBE hprobe);

/****************************************************************************
** Fs2UsbSetWaitThreshold
** Fs2UsbGetWaitThreshold
**
** Description:
**    Set the threshold value for Fs2JtagWait / Fs2JtagWaitSetup.  This
**    only affects USB products.  Above the threshold, delays are performed
**    by starting the delay timer and returning, with the host polling
**    through USB to wait for the timer to complete.  Below the
**    threshold, delays are performed directly by probe hardware before
**    returning the USB response packet.  The threshold value should
**    not be much greater than one USB frame interval (1ms).
**
** Parameters:
**    threshold    Length in TCK cycles of the USB timer threshold.
**                 The default is 4000.
**    
** Returns:
**    GOOD
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT      Must call Fs2OpenPort()
**    ER_USB_*                 Host communication error
**
** Compatibility:
**    FlashPro, FP3.  Not valid with FPL, FP3B.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2UsbSetWaitThreshold(U32 threshold);
ABIEXPORT HRESULT ABICDECL Fs2UsbGetWaitThreshold(U32 *threshold);


/****************************************************************************
** Fs2SetPassFailLED
**
** Description:
**    Set state of Pass/Fail LED on Flash Pro 3.
**
** Parameters:
**    state:   State to which LED should be set.
**
** Returns:
**    GOOD
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT      Must call Fs2OpenPort()
**    ER_USB_*                 Host communication error
**    ER_NOT_SUPPORTED         System must be a FlashPro3
**
** Compatibility:
**    FP3, FP3B.
****************************************************************************/
typedef enum {
   LED_OFF,
   LED_RED,
   LED_YELLOW,
   LED_GREEN
} ABI_LED_STATE;

ABIEXPORT HRESULT ABICDECL Fs2SetPassFailLED(HPROBE hprobe, ABI_LED_STATE state);
ABIEXPORT HRESULT ABICDECL Fs2GetPassFailLED(HPROBE hprobe, ABI_LED_STATE *state);

/****************************************************************************
**
** --------------------------- FlashPro3B functions -------------------------
** 
** General notes:
**    - All fp3b functions are valid only for FP3B probes.
**    - With an fp3b probe, some functions above are not supported.
**
****************************************************************************/
typedef enum {
   ABI_TAP_RESET=0,
   ABI_TAP_IDLE=1,
   ABI_TAP_PAUSEIR=2,
   ABI_TAP_PAUSEDR=3
} ABI_TAP_STATE;


/****************************************************************************
** Wait and Pause commands - spec section 3.8.1
** 
** Fs2Fp3bWait
** Fs2Fp3bPause
**
** Parameters:
**    count:  Number of TCK's to wait/pause (1 to 0xffffffff)
**
** Compatibility:
**    FP3B only.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Fp3bWait  (HPROBE hprobe, U32 count);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bPause (HPROBE hprobe, U32 count);

/****************************************************************************
** TAP state traversal commands - spec section 3.8.2
** 
** Fs2Fp3bStop    - Traverse irpause->irstop or drpause->drstop
** Fs2Fp3bReset   - Traverse to reset
** Fs2Fp3bIdle    - Traverse to idle
** Fs2Fp3bPauseIr - Traverse to pauseir
** Fs2Fp3bPauseDr - Traverse to pausedr
**
** Parameters:
**
** Compatibility:
**    FP3B only.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Fp3bStop   (HPROBE hprobe);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bReset  (HPROBE hprobe);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bIdle   (HPROBE hprobe);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bPauseIr(HPROBE hprobe);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bPauseDr(HPROBE hprobe);

/****************************************************************************
** Fs2Fp3bXtms - spec section 3.8.2
**
** Description:
**    Send from 1 to 8 arbitrary TMS 
**
** Parameters:
**    length:  Number of bits to send
**    data:    Data to apply to TMS signal (lsb first)
**    state:   TAP state after the sequence is sent
**
** Compatibility:
**    FP3B only.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Fp3bXtms(HPROBE hprobe, U32 length, U8 *data, ABI_TAP_STATE state);


/****************************************************************************
** Setup and Control Commands - spec section 3.8.3
**
** Fs2Fp3bSetN
** Fs2Fp3bGetN
**
** Description:
**    Set the scan length multiplier to use in subsequent scan commands.
**    Default N after Fs2OpenPort is 1.
**
** Parameters:
**    N:     Value to set/get.  Must be 1, 2, 3, 4, or 5.
**
** Compatibility:
**    FP3B only.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Fp3bSetN(HPROBE hprobe, U32 N);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bGetN(HPROBE hprobe, U32 *N);

/****************************************************************************
** Setup and Control Commands - spec section 3.8.3
**
** Fs2Fp3bSetAutoFlush
**
** Description:
**    Control whether to automatically send pending response in Wait commands.
**    Default autoflush state after Fs2OpenPort is disabled.
**
** Parameters:
**    state:   0=disable autoflush, 1=enable autoflush
**
** Compatibility:
**    FP3B only.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Fp3bSetAutoFlush(HPROBE hprobe, BOOLEAN state);

/****************************************************************************
** Setup and Control Commands - spec section 3.8.3
**
** Fs2Fp3bRead
**
** Description:
**    Queue a read command.  When executed, this will send any pending
**    response from the probe to the host.  This function does not
**    return any data; use Fs2Fp3bGetResponse() for that.
**
** Parameters:
**
** Compatibility:
**    FP3B only.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Fp3bRead(HPROBE hprobe);

/****************************************************************************
** Setup and Control Commands - spec section 3.8.3
**
** Fs2Fp3bSetIrStop
** Fs2Fp3bSetDrStop
**
** Description:
**    Set predefined irstop and drstop states.  Default after
**    Fs2OpenPort is IDLE for both irstop and drstop.
**
** Parameters:
**    state:   Desired TAP state (ABI_TAP_IDLE,ABI_TAP_PAUSEIR,ABI_TAP_PAUSEDR)
**
** Compatibility:
**    FP3B only.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Fp3bSetIrStop(HPROBE hprobe, ABI_TAP_STATE state);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bSetDrStop(HPROBE hprobe, ABI_TAP_STATE state);

/****************************************************************************
** Setup and Control Commands - spec section 3.8.3
**
** Fs2Fp3bSetPreIr
** Fs2Fp3bSetPostIr
** Fs2Fp3bSetPreDr
** Fs2Fp3bSetPostDr
**
** Description:
**    Set prefix/suffix state and length.  The default value after
**    Fs2OpenPort is length 0 for all pre and post sequences.
**
** Parameters:
**    state:   Set pre/post value to 0 (false) or 1 (true)
**    length:  Number of bits in the prefix/suffix
**
** Compatibility:
**    FP3B only.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Fp3bSetPreIr (HPROBE hprobe, BOOLEAN state, U32 length);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bSetPostIr(HPROBE hprobe, BOOLEAN state, U32 length);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bSetPreDr (HPROBE hprobe, BOOLEAN state, U32 length);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bSetPostDr(HPROBE hprobe, BOOLEAN state, U32 length);

/****************************************************************************
** Fs2Fp3bSetStaticJtag
**
** Description:
**    Manage static JTAG output mode
**
** Notes:
**   Fs2SetJtagEnable(2):  Set TCK,TDI,TMS to enabled state, driven with static values
**   Fs2SetJtagEnable(1):  TCK,TDI,TMS driven from JTAG master
**   Fs2SetJtagEnable(0):  TCK,TDI,TMS tristated
**
**   nTRST output set using Fs2SetnTRST().
**
**   Output states set using Fs2Fp3bSetStaticJtag are driven onto the
**   JTAG pins when the pins are in the static output state as set by
**   Fs2Fp3bJtagStatic().
**
** Parameters:
**    signal:  Which signal to set.
**    state:   Drive with 0 (false) or 1 (true)
**
** Compatibility:
**    FP3B only.
****************************************************************************/
typedef enum {
   ABI_JTAG_TCK,
   ABI_JTAG_TMS,
   ABI_JTAG_TDI
} ABI_JTAG_SIGNAL;

ABIEXPORT HRESULT ABICDECL Fs2Fp3bSetStaticJtag(HPROBE hprobe, ABI_JTAG_SIGNAL signal, BOOLEAN state);


/****************************************************************************
** Repeat commands - spec section 3.8.4
**
** Fs2Fp3bRep:
**    Queue a REP command.  All commands between REP and ENDREP will be
**    executed once, then an additional <count> times.  No nesting is
**    allowed.
**
** Fs2Fp3bEndRep:
**    Delimits the end of the repeated sequence.
**
** Fs2Fp3bRepPrev:
**    Execute commands between most recent REP and ENDREP an additional
**    <count> times (0 to 255).
**
** Parameters:
**    count:   Number of times to reexecute commands between REP, ENDREP 
**             (0 to 255).
**
** Compatibility:
**    FP3B only.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Fp3bRep(HPROBE hprobe, U32 count);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bEndRep(HPROBE hprobe);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bRepPrev(HPROBE hprobe, U32 count);

/****************************************************************************
** Scan commands - spec section 3.8.5 thru 3.8.7
** 
** Count must be 1 to 15:
**   Fs2Fp3b[Ir|Dr]Scan  - scan count x 2^(n-1) bits from supplied data
**   Fs2Fp3bB[Ir|Dr]Scan - scan count x 2^(n+2) bits from supplied data
**   Fs2Fp3bP[Ir|Dr]Scan - scan count x 2^(n+6) bits from supplied data
**
** Count must be 1 to 255:
**   Fs2Fp3b[Ir|Dr]Scan0 - scan count bits of zeroes
**   Fs2Fp3b[Ir|Dr]Scan1 - scan count bits of ones
**
** Parameters:
**    n:      set in earlier call to Fs2Fp3BSetN().
**    count:  bit multiplier as described above (1-15 or 1-255)
**    data:   source of data for scan.
**    read:   capture tdo and queue as response data
**
** Compatibility:
**    FP3B only.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Fp3bIrScan  (HPROBE hprobe, U32 count, U8 *data, BOOLEAN read);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bDrScan  (HPROBE hprobe, U32 count, U8 *data, BOOLEAN read);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bIrScan0 (HPROBE hprobe, U32 count, BOOLEAN read);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bDrScan0 (HPROBE hprobe, U32 count, BOOLEAN read);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bIrScan1 (HPROBE hprobe, U32 count, BOOLEAN read);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bDrScan1 (HPROBE hprobe, U32 count, BOOLEAN read);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bBIrScan (HPROBE hprobe, U32 count, U8 *data, BOOLEAN read);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bBDrScan (HPROBE hprobe, U32 count, U8 *data, BOOLEAN read);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bPIrScan (HPROBE hprobe, U32 count, U8 *data, BOOLEAN read);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bPDrScan (HPROBE hprobe, U32 count, U8 *data, BOOLEAN read);


/****************************************************************************
** Data management commands
** 
** Fs2Fp3bGetResponse
**
** Description:
**    Retreive bytes from response packets.  Returns a maximum of
**    *count bytes and fills in the actual number of bytes returned
**    into *count.  If no data is ready to read, the function will
**    return immediately and *count will be 0.
**
** Notes:
**    The probe does not automatically return response data in most
**    cases.  A call to Fs2Fp3bRead() will force any queued response
**    data to be sent back immediately.  A call to Fs2Fp3bWait() will
**    also return any queued data if Fs2Fp3bSetAutoFlush has been
**    enabled.  Otherwise, data is returned from the probe only when a
**    full USB packet has been queued.
**
**    Bytes are returned from the probe in the order they were
**    generated.  The ABI client must read all response bytes
**    in order.
**    
** Fs2Fp3bGetBytesWaiting returns the number of bytes currently ready
** to be read.
**
** Fs2Fp3bGetResponseWait will wait up to <timeout> milliseconds for
** *length bytes to arrive.  An error is returned and *length is set
** to zero if the timeout occurs.
**
** Parameters:
**    count:  (input) maximum number of bytes to read
**            (output) actual number of bytes read
**    data:   global_buf1fer to hold return data.
**    timeout:  (input) milliseconds to wait for requested data.
**
** Compatibility:
**    FP3B only.
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2Fp3bGetResponse(HPROBE hprobe, U32 *length, U8 *data);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bGetResponseWait(HPROBE hprobe, U32 *length, U8 *data, U32 timeout);
ABIEXPORT HRESULT ABICDECL Fs2Fp3bGetBytesWaiting(HPROBE hprobe, U32 *length);

/****************************************************************************
**
** ---------------------- FlashPro Bit-Bang functions ----------------------
** 
** General notes:
**    - These functions are valid only for FPBB probes opened on altlptX.
**
****************************************************************************/

/****************************************************************************
** Fs2SetAltSetup
** Fs2GetAltSetup
**
** Description:
**    Set up or retrieve the altlpt probe signal assignments
**
** Parameters:
**    hprobe:  Which probe to set up
**    setup:   Configuration of port
**
** Standard parallel port status register (port 1)
**    bit 0 = 
**    bit 1 = 
**    bit 2 = 
**    bit 3 = nERROR
**    bit 4 = SELECT
**    bit 5 = PE
**    bit 6 = nACK
**    bit 7 = BUSY (inverted)
** 
** Standard parallel port control register (port 2)
**    bit 0 = nSTROBE (inverted)
**    bit 1 = nAUTOFEED (inverted)
**    bit 2 = nINIT
**    bit 3 = nSELECTIN (inverted)
**    bit 4 = irq_enable
**    bit 5 = out_disable (1=host data drivers off, 0=on)
**    bit 6 = 
**    bit 7 = 
** 
** Returns:
**    GOOD
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT      Must call Fs2OpenPort()
**    ER_NOT_SUPPORTED         System must be FPBB
**    ER_BAD_PARAM             Port must be 0, 1, 2 (tck, tdi, tms, tdo)
**                               or FS2_ALTLPT_NONE (ntrst, out0, jtagenable)
**    ER_BAD_PARAM             Bit must be 0 to 7
**
** Default:
**    tck: port 0, bit 0
**    tdi: port 0, bit 6
**    tms: port 0, bit 1
**    tdo: port 1, bit 7, invert
**    ntrst: port FS2_ALTLPT_NONE
**    out0: port FS2_ALTLPT_NONE
**    jtagenable: port 2, bit 1
**    port0value = 0xB0
**    port2value = 0x04
**
** Compatibility:
**    FPBB only
****************************************************************************/
#define FS2_ALTLPT_NONE -1
typedef struct {
   U32 port;      /* 0 = data, 1 = status, 2 = control, FS2_ALTLPT_NONE = none */
   U8 bit;        /* 0 = bit 0, ... , 7 = bit 7 */
   U8 invert;     /* 0 = signal not inverted in software, 1 = inverted. */
                  /* Invert is independent of hardware inversion.  Example: */
                  /* to read the BUSY signal applied to the port, select */
                  /* invert=1.  Hardware will invert once, then the */
                  /* software inversion will restore the original state. */
} FS2_ALTLPT_SIGNAL;

typedef struct {
   FS2_ALTLPT_SIGNAL tck;
   FS2_ALTLPT_SIGNAL tdi;
   FS2_ALTLPT_SIGNAL tms;
   FS2_ALTLPT_SIGNAL tdo;
   FS2_ALTLPT_SIGNAL ntrst;
   FS2_ALTLPT_SIGNAL out0;
   FS2_ALTLPT_SIGNAL jtagenable;
   U8 port0value;            /* static value for port 0 (data port) */
   U8 port2value;            /* static value for port 2 (control port) */
} FS2_ALTLPT_SETUP;

ABIEXPORT HRESULT ABICDECL Fs2SetAltSetup(HPROBE hprobe, FS2_ALTLPT_SETUP *setup);
ABIEXPORT HRESULT ABICDECL Fs2GetAltSetup(HPROBE hprobe, FS2_ALTLPT_SETUP *setup);

/****************************************************************************
** Fs2AltWrite
** Fs2AltRead
**
** Description:
**    Direct access to parallel port data, status, and control ports
**
** Parameters:
**    hprobe:  Which probe
**    port:    0 = data port, 1 = status port, 2 = control port
**    value:   Value to write or read
**
** Returns:
**    GOOD
**    ER_ABI_NOT_INITIALIZED   Must call Fs2Init()
**    ER_ABI_NO_OPEN_PORT      Must call Fs2OpenPort()
**    ER_NOT_SUPPORTED         System must be FPBB
**    ER_BAD_PARAM             Port must be 0, 1, 2
**
** Compatibility:
**    FPBB only
****************************************************************************/
ABIEXPORT HRESULT ABICDECL Fs2AltWrite(HPROBE hprobe, U32 port, U8 value);
ABIEXPORT HRESULT ABICDECL Fs2AltRead(HPROBE hprobe, U32 port, U8 *value);

#include <poppack.h>    /* restore default structure byte packing */
#endif

/******************************* end of file *******************************/
