/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dputil.c                                                */
/*                                                                          */
/*  Description:    Contains initialization and data checking functions.    */
/*                                                                          */
/****************************************************************************/

#include "dpuser.h"
#include "dpdef.h"
#include "dputil.h"
#include "dpalg.h"
#include "dpcom.h"
#include "dpjtag.h"


void dp_flush_global_buf1(void)
{
    for (global_uchar=0;global_uchar<global_buf_SIZE;global_uchar++)
        global_buf1[global_uchar]=0;
    return;
}

void dp_flush_global_buf2(void)
{
    for (global_uchar=0;global_uchar<global_buf_SIZE;global_uchar++)
        global_buf2[global_uchar]=0;
    return;
}

void dp_init_vars(void)
{
    device_security_flags = 0;
    error_code = DPE_SUCCESS;
    return;
}

void dp_get_support_status(void)
{
    
    global_uint=1;
    support_status = 0;
    for (global_ulong = 0;global_ulong < 16 ;global_ulong ++)
    {
        global_uchar=(DPUCHAR) dp_get_bytes(Header_ID,SUPPORT_STATUS_OFFSET+global_ulong,1);
        if (global_uchar)
            support_status |= global_uint;
        global_uint <<= 1;
    }
    
    return;
}


/*
* Module: dp_check_image_crc
* 		purpose: Performs crc on the entire image.  
* Return value: 
* 	DPINT: User defined integer value which reports DPE_SUCCESS if there is a match or DPE_CRC_MISMATCH if failed. 
* 
*/
void dp_check_image_crc(void)
{
    requested_bytes = 0;
    /* Global_uint is used to hold the value of the calculated CRC */
    global_uint = 0;
    /* DataIndex is used to keep track the byte position in the image that is needed per get_data_request */
    DataIndex = 0;
    image_size = dp_get_bytes(Header_ID,IMAGE_SIZE_OFFSET,4);
    if (image_size == 0)
    {
        error_code = DPE_CRC_MISMATCH;
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nData file is not loaded... \r\n");
        #endif
    }
    else 
    {
        
        requested_bytes = image_size - 2;
        while (requested_bytes)
        {
            page_buffer_ptr = dp_get_data(Header_ID,DataIndex*8);
            if (return_bytes > requested_bytes )
                return_bytes = requested_bytes;
            for (global_ulong=0; global_ulong< return_bytes;global_ulong++)
            {
                global_uchar = page_buffer_ptr[global_ulong];
                dp_compute_crc();
            }
            DataIndex += return_bytes;
            requested_bytes -= return_bytes;
        }
        
        if (global_uint != (DPUINT) dp_get_bytes(Header_ID,image_size - 2,2))
        {
            #ifdef ENABLE_DEBUG
            dp_display_text("\r\nCRC verification failed.  Expected CRC = ");
            dp_display_value(global_uint,HEX);
            dp_display_text(" Actual CRC = ");
            dp_display_value((DPUINT) dp_get_bytes(Header_ID,image_size - 2,2),HEX);
            dp_display_text("\r\n");
            #endif
            error_code = DPE_CRC_MISMATCH;
        }
    }
    
    return;
}


void dp_compute_crc(void)
{
    for (global_jtag_i = 0; global_jtag_i < 8; global_jtag_i++)
    {
        device_rows = (global_uchar ^ global_uint) & 0x01;
        global_uint >>= 1;
        if (device_rows)
            global_uint ^= 0x8408;
        global_uchar >>= 1;
    }
    return;
}

