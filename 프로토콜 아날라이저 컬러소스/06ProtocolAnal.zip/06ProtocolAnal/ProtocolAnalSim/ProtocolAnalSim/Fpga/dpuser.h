/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpuser.h                                                */
/*                                                                          */
/*  Description:    DP user specific file                                   */
/*                   users should define their own functions                */
/*                                                                          */
/****************************************************************************/
#ifndef INC_DPUSER_H
#define INC_DPUSER_H


/*************** Hardware related constants *****************************/
/*
* User Attention: 
* Bit assignments in the hardware JTAG port register 
* 
*/
#define TCK     0x01
#define TDI     0x40
#define TMS     0x02
#define TRST    0x00 /* 0 Means it does not exist */
#define TDO     0x80
/*************** End of hardware related constants ************************/

/* Compiler switches */
/* #define USE_PAGING */
#define ACTEL_DEBUG
#define ENABLE_DEBUG
#define ENABLE_FILE_SYSTEM
#define CORE_SUPPORT
#define CORE_PLAIN
#define CORE_ENCRYPT
#define FROM_SUPPORT
#define FROM_PLAIN
#define FROM_ENCRYPT
#define NVM_SUPPORT
#define NVM_PLAIN
#define NVM_ENCRYPT
#define SECURITY_SUPPORT
/* #define CHAIN_SUPPORT */
#define BSR_SAMPLE
#define ENABLE_AXXE1500_SUPPORT


/*************** End of compiler switches ***********************************/


/***********************************************/
/* DPCHAR    -- 8-bit Windows (ANSI) character */
/*              i.e. 8-bit signed integer      */
/* DPINT     -- 16-bit signed integer          */
/* DPLONG    -- 32-bit signed integer          */
/* DPBOOL    -- boolean variable (0 or 1)      */
/* DPUCHAR   -- 8-bit unsigned integer         */
/* DPUSHORT  -- 16-bit unsigned integer        */
/* DPUINT    -- 16-bit unsigned integer        */
/* DPULONG   -- 32-bit unsigned integer        */
/***********************************************/
typedef unsigned char  DPUCHAR;
typedef unsigned short DPUSHORT;
typedef unsigned int   DPUINT;
typedef unsigned long  DPULONG;
typedef unsigned char  DPBOOL;
typedef          char  DPCHAR;
typedef          int   DPINT;
typedef          long  DPLONG;

#define NULL ((void*)0)
#define TRUE 1
#define FALSE 0

extern DPUCHAR *image_buffer;
DPUCHAR jtag_inp(void);
void jtag_outp(DPUCHAR outdata);
void dp_jtag_init(void);
void dp_jtag_tms(DPUCHAR tms);
void dp_jtag_tms_tdi(DPUCHAR tms, DPUCHAR tdi);
DPUCHAR dp_jtag_tms_tdi_tdo(DPUCHAR tms, DPUCHAR tdi);
void dp_delay(DPULONG microseconds);

#ifdef ENABLE_DEBUG
#define HEX 0
#define DEC 1
#define CHR 2

/******************************************************************************/
/* users should define their own functions to replace the following functions */
/******************************************************************************/
#define DPPRINTF                  printf
int __cdecl printf(const char *, ...);
void dp_display_text(DPCHAR *text);
void dp_display_value(DPULONG value,int descriptive);
void dp_display_array(DPUCHAR *value,int bytes, int descriptive);
#endif


#ifdef ENABLE_FILE_SYSTEM
void *dp_malloc(DPULONG size);
void dp_free(void *ptr);
DPUCHAR dp_get_Action_code(DPCHAR *pAction);
/***********************************************
**	The following string action definitions could be ignored
**	The user can call dp_top with the corresponding action code defined in dpalg.h
***********************************************/
#define DP_PROGRAM_ACTION                   "program"
#define DP_ERASE_ACTION                     "erase"
#define DP_READ_IDCODE_ACTION               "read_idcode"
#define DP_VERIFY_ACTION                    "verify"
#define DP_DEVICE_INFO_ACTION               "device_info"
#define DP_ERASE_ALL_ACTION                 "erase_all"
#define DP_ERASE_FROM_ACTION                "erase_from"
#define DP_PROGRAM_FROM_ACTION              "program_from"
#define DP_VERIFY_FROM_ACTION               "verify_from"
#define DP_PROGRAM_ARRAY_ACTION             "program_array"
#define DP_ERASE_ARRAY_ACTION               "erase_array"
#define DP_VERIFY_ARRAY_ACTION              "verify_array"
#define DP_ENC_DATA_AUTHENTICATION_ACTION   "enc_data_authentication"
#define DP_ERASE_SECURITY_ACTION            "erase_security"
#define DP_PROGRAM_SECURITY_ACTION          "program_security"
#define DP_VERIFY_NVM_ACTION				"verify_nvm"
#define DP_PROGRAM_NVM_ACTION				"program_nvm"
#define DP_VERIFY_DEVICE_INFO               "verify_device_info"
#endif
#endif /* INC_DPUSER_H */


