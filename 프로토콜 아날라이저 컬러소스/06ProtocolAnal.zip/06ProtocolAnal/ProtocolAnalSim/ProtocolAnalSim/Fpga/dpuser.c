/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpuser.c												*/
/*                                                                          */
/*  Description:    user specific file containing JTAG interface functions  */
/*                  and delay function                                      */
/*                                                                          */
/****************************************************************************/

#include "dpuser.h"
#include "dpalg.h"
#include "dpdef.h"
#include "dputil.h"

/* 
* User attention:
* Include files needed to support hardware JTAG interface operations.
* 
*/
#include "fs2actel.h"

/*
* The following definitions are specific for the Parallel board solution. 
* User to replace with their own code.
*
*/
HPROBE gHProbe = NULL;
DPUINT timer_calibration_value=1000;
DPBOOL CheckError( HRESULT status )
{
    ABI_JTAG_MODE mode;
    
    if (status == GOOD)
        return TRUE;
    #ifdef ENABLE_DEBUG
    DPPRINTF( Fs2GetErrorText(status) );
    #endif
    if ( gHProbe )
    {
        Fs2GetJtagEnable( gHProbe, &mode );
        if ( mode == ABI_JTAG_RUN )
            Fs2SetJtagEnable( gHProbe, ABI_JTAG_Z );
        Fs2ClosePort( gHProbe );
        gHProbe = NULL;
        Fs2Cleanup();
    }
    return FALSE;
}



/*
* User attention:
* jtag_port_reg: 	8 bit Static variable to keep track of the state of all the JTAG pins 
* 					at all times during the programming operation.
* Note: User check the variable size to make sure it can cover the hardware IO register. 
* 
*/
static DPUCHAR jtag_port_reg;
/*
* User attention: 
* Module: jtag_inp
* 		purpose: report the logic state of tdo jtag pin
* Arguments: None
* Return value: 8 bit value
* 		0, 0x80
* 
*/
DPUCHAR jtag_inp(void)
{
    DPUCHAR tdo = 0;
    DPUCHAR ret = 0x80;
    CheckError( Fs2AltRead(gHProbe, 1, &tdo) );
    /* For Parallel global_buf1er board, the logic is reversed. */
    if ((tdo&TDO))
        ret = 0;
    return ret;
}
/*
* User attention: 
* Module: jtag_outp
* 		purpose: Set the JTAG port (all JTAG pins)
* Arguments: 8 bit value containing the new state of all the JTAG pins
* Return value: None
* 
*/
void jtag_outp(DPUCHAR outdata)
{
    CheckError( Fs2AltWrite(gHProbe, 0, outdata ) );
}

/*
* No need to change this function
* Module: dp_jtag_init
* 		purpose: Set tck and trstb pins to logic level one
* Arguments:
* 		None
* Return value: None
* 
*/
void dp_jtag_init(void)
{
    jtag_port_reg = TCK | TRST; 
    jtag_outp(jtag_port_reg);
}

/*
* No need to change this function
* Module: dp_jtag_tms
* 		purpose: Set tms pin to a logic level one or zero and pulse tck.
* Arguments: 
* 		tms: 8 bit value containing the new state of tms
* Return value: None
* Constraints: Since jtag_outp function sets all the jtag pins, jtag_port_reg is used 
* 				to modify the required jtag pins and preseve the reset.
* 
*/
void dp_jtag_tms(DPUCHAR tms)		 
{	
    jtag_port_reg &= ~(TMS | TCK);
    jtag_port_reg |= (tms ? TMS : 0);
    jtag_outp(jtag_port_reg);
    jtag_port_reg |= TCK;
    jtag_outp(jtag_port_reg);
}

/*
* No need to change this function
* Module: dp_jtag_tms_tdi
* 		purpose: Set tms amd tdi pins to a logic level one or zero and pulse tck.
* Arguments: 
* 		tms: 8 bit value containing the new state of tms
* 		tdi: 8 bit value containing the new state of tdi
* Return value: None
* Constraints: Since jtag_outp function sets all the jtag pins, jtag_port_reg is used 
* 				to modify the required jtag pins and preseve the reset.
* 
*/
void dp_jtag_tms_tdi(DPUCHAR tms, DPUCHAR tdi)
{
    jtag_port_reg &= ~(TMS | TCK | TDI);
    jtag_port_reg |= ((tms ? TMS : 0) | (tdi ? TDI : 0));
    jtag_outp(jtag_port_reg);
    jtag_port_reg |= TCK;
    jtag_outp(jtag_port_reg);
}

/*
* No need to change this function
* Module: dp_jtag_tms_tdi_tdo
* 		purpose: Set tms amd tdi pins to a logic level one or zero, 
* 				 pulse tck and return tdi level
* Arguments: 
* 		tms: 8 bit value containing the new state of tms
* 		tdi: 8 bit value containing the new state of tdi
* Return value: 
* 		ret: 8 bit variable ontaining the state of tdo.
* Valid return values: 
* 		0x80: indicating a logic level high on tdo
* 		0: indicating a logic level zero on tdo
* Constraints: Since jtag_outp function sets all the jtag pins, jtag_port_reg is used 
* 				to modify the required jtag pins and preseve the reset.
* 
*/
DPUCHAR dp_jtag_tms_tdi_tdo(DPUCHAR tms, DPUCHAR tdi)
{
    DPUCHAR ret = 0x80;
    jtag_port_reg &= ~(TMS | TCK | TDI);
    jtag_port_reg |= ((tms ? TMS : 0) | (tdi ? TDI : 0));
    jtag_outp(jtag_port_reg);
    ret = jtag_inp();
    jtag_port_reg |= TCK;
    jtag_outp(jtag_port_reg);
    return ret;
}

/*
* User attention: 
* Module: dp_delay
* 		purpose: Execute a time delay for a specified amount of time.
* Arguments: 
* 		microseconeds: 32 bit value containing the amount of wait time in microseconds.
* Return value: None
* 
*/
void dp_delay(DPULONG microseconds)
{
    volatile DPULONG i;
    volatile DPULONG j;
    for(i=0;i<microseconds;i++) 
    {
        for (j=0;j<timer_calibration_value;j++) 
        {
            ;
        }
    }
}

#ifdef ENABLE_DEBUG
void dp_display_text(DPCHAR *text)
{
    DPPRINTF("%s",text);
}

void dp_display_value(DPULONG value,int descriptive)
{
    if (descriptive == HEX)
        DPPRINTF("%lX",value);
    else if(descriptive == DEC)
        DPPRINTF("%ld",value);
    else if(descriptive == CHR)
        DPPRINTF("%c",(DPUCHAR)value);
}
void dp_display_array(DPUCHAR *value,int bytes, int descriptive)
{
    int i;
    for (i=0;i < bytes;i++)
    {
        if (descriptive == HEX)
            DPPRINTF("%lX ",value[i]);
        else if(descriptive == DEC)
            DPPRINTF("%ld ",value[i]);
        else if(descriptive == CHR)
            DPPRINTF("%c ",(DPUCHAR)value[i]);
    }
}
#endif


/*
* The following definitions are specific for the Parallel board solution. 
* User to replace with their own code.
*
*/
#ifdef ENABLE_FILE_SYSTEM
#include <io.h>
#include <stdio.h>
#include <time.h>
#include <sys/stat.h>
#include <mmsystem.h>



DPULONG ulDataLenth = 0L;				 /* user defined data length */

void *dp_malloc(DPULONG size)
{
    return malloc( size );
}

void dp_free(void *ptr)
{
    free( ptr );
}

void calculate_timer_calibration_value(void)
{
    DPULONG start, finish;
    DPUINT delta;
    
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nCalculating timer calibration value...");
    #endif
    
    timer_calibration_value = 1000;
    delta = 0;
    while (!delta) 
    {
        start = GetTickCount();
        /* Check the time delay of 300 ms */
        dp_delay(300000);
        finish = GetTickCount();
        if (finish > start)
        {
            delta = finish - start;
            if (delta)
            {
                timer_calibration_value = (DPUINT) (((300* timer_calibration_value) / delta) * 3);
            }
            else
            {
                timer_calibration_value*=2;
            }
        }
    }
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nTimer calibration value = ");
    dp_display_value(timer_calibration_value,DEC);
    #endif
    return;
}

DPUCHAR dp_get_Action_code(DPCHAR *pAction)
{
    if (stricmp(pAction, DP_DEVICE_INFO_ACTION) == 0)
        return DP_DEVICE_INFO_ACTION_CODE;
    else if (stricmp(pAction, DP_READ_IDCODE_ACTION) == 0)
        return DP_READ_IDCODE_ACTION_CODE;
    else if (stricmp(pAction, DP_ERASE_ACTION) == 0)
        return DP_ERASE_ACTION_CODE;
    else if (stricmp(pAction, DP_ERASE_ALL_ACTION) == 0)
        return DP_ERASE_ALL_ACTION_CODE;
    else if (stricmp(pAction, DP_ERASE_ARRAY_ACTION) == 0)
        return DP_ERASE_ARRAY_ACTION_CODE;
    else if (stricmp(pAction, DP_ERASE_FROM_ACTION) == 0)
        return DP_ERASE_FROM_ACTION_CODE;
    else if (stricmp(pAction, DP_ERASE_SECURITY_ACTION) == 0)
        return DP_ERASE_SECURITY_ACTION_CODE;
    else if (stricmp(pAction, DP_PROGRAM_ACTION) == 0)
        return DP_PROGRAM_ACTION_CODE;
    else if (stricmp(pAction, DP_PROGRAM_ARRAY_ACTION) == 0)
        return DP_PROGRAM_ARRAY_ACTION_CODE;
    else if (stricmp(pAction, DP_PROGRAM_FROM_ACTION) == 0)
        return DP_PROGRAM_FROM_ACTION_CODE;
    else if (stricmp(pAction, DP_PROGRAM_NVM_ACTION) == 0)
        return DP_PROGRAM_NVM_ACTION_CODE;
    else if (stricmp(pAction, DP_PROGRAM_SECURITY_ACTION) == 0)
        return DP_PROGRAM_SECURITY_ACTION_CODE;
    else if (stricmp(pAction, DP_VERIFY_ACTION) == 0)
        return DP_VERIFY_ACTION_CODE;
    else if (stricmp(pAction, DP_VERIFY_ARRAY_ACTION) == 0)
        return DP_VERIFY_ARRAY_ACTION_CODE;
    else if (stricmp(pAction, DP_VERIFY_FROM_ACTION) == 0)
        return DP_VERIFY_FROM_ACTION_CODE;
    else if (stricmp(pAction, DP_VERIFY_NVM_ACTION) == 0)
        return DP_VERIFY_NVM_ACTION_CODE;
    else if (stricmp(pAction, DP_ENC_DATA_AUTHENTICATION_ACTION) == 0)
        return DP_ENC_DATA_AUTHENTICATION_ACTION_CODE;
    else if (stricmp(pAction, DP_VERIFY_DEVICE_INFO) == 0)
        return DP_VERIFY_DEVICE_INFO_ACTION_CODE;
    
    return DP_NO_ACTION_FOUND;
}

#endif /* ENABLE_FILE_SYSTEM */

/*
* The following function definitions are specific for the Parallel board solution. 
* User to replace with their own code.
*
*/
int main(int argc, char **argv)
{
    #ifdef ENABLE_FILE_SYSTEM
    DPINT iExitStatus = 0;	
    DPINT iArg;
    DPBOOL bHelp = FALSE;
    DPCHAR *pPort = (DPCHAR*)NULL;
    DPCHAR *pAction = (DPCHAR*)NULL;
    DPCHAR *pFileName = (DPCHAR*)NULL;
    struct _stat sglobal_buf1;
    DPULONG ulFileLength = 0L;
    DPUCHAR* pFile_buffer = (DPUCHAR*)NULL;
    FILE *fp = (FILE*)NULL;
    DPINT iExecResult = DPE_SUCCESS;
    time_t start_time;
    time_t end_time;
    DPINT iTimeDelta;
    
    for (iArg = 1; iArg < argc; iArg++)
    {
        if ((argv[iArg][0] == '-') || (argv[iArg][0] == '/'))
        {
            switch(toupper(argv[iArg][1]))
            {
                case 'A':                /* set action name */
                pAction = &argv[iArg][2];
                break;
                
                case 'P':                /* set LPT port */
                pPort = &argv[iArg][2];
                break;
                
                case 'H':                /* help */
                default:
                bHelp = TRUE;
                break;
            }
        }
        else
        {
            /* it's a filename */
            pFileName = argv[iArg];
        }
    }
    
    if ( bHelp || (pFileName == (DPCHAR*)NULL) )
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("Usage:  directc [options] <filename>\r\n");
        dp_display_text("\r\nAvailable options:\r\n");
        dp_display_text("    -h          : show help message\r\n");
        dp_display_text("    -a<action>  : specify STAPL action name\r\n");
        dp_display_text("    -p<port>    : parallel port (altlpt1, altlpt2 or altlpt3)\r\n");
        #endif
        
        iExitStatus = 101;
    }
    else if ( _access(pFileName, 4) != 0 )
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nError: can't access file ");
        dp_display_text(pFileName);
        #endif
        iExitStatus = 102;
    }
    else
    {
        /* get length of file */
        if ( _stat(pFileName, &sglobal_buf1) == 0 )
            ulFileLength = sglobal_buf1.st_size;
        
        if ((fp = fopen(pFileName, "rb")) == (FILE*)NULL)
        {
            #ifdef ENABLE_DEBUG
            dp_display_text("\r\nError: can't open file ");
            dp_display_text(pFileName);
            #endif
            iExitStatus = 103;
        }
        else
        {
            /*
            *    Read entire file into a global_buf1fer
            */
            pFile_buffer = (DPUCHAR *) dp_malloc(ulFileLength);
            if (pFile_buffer == (DPUCHAR*)NULL)
            {
                #ifdef ENABLE_DEBUG
                dp_display_text("\r\nError: can't allocate memory (");
                dp_display_value(ulFileLength / 1024, DEC);
                dp_display_text(" Kbytes)");
                #endif                    
                iExitStatus = 104;
            }
            else
            {
                if (fread(pFile_buffer, 1, (size_t)ulFileLength, fp) !=
                (size_t) ulFileLength)
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nError reading file ");
                    dp_display_text(pFileName);
                    #endif
                    iExitStatus = 105;
                }
            }
            
            fclose(fp);
        }
        
        if (iExitStatus == 0)
        {
            /*
            *    Init FS2 library and set supplies and open port
            */
            if ( ! CheckError( Fs2Init() ) )
            {
                #ifdef ENABLE_DEBUG
                dp_display_text("\r\nFS2 Board Error: Could not initialize parallel board...");
                #endif
                iExitStatus = 106;
            }
            if ( ! CheckError( Fs2OpenPort( pPort, &gHProbe ) ) )
            {
                #ifdef ENABLE_DEBUG
                dp_display_text("\r\nFS2 Board Error: Could not open port...");
                #endif
                iExitStatus = 107;
            }
            if ( ! CheckError( Fs2SetJtagEnable( gHProbe, ABI_JTAG_RUN ) ) )
            {
                #ifdef ENABLE_DEBUG
                dp_display_text("\r\nFS2 Board Error: Could not enable JTAG ...");
                #endif
                iExitStatus = 108;
            }
            if ( iExitStatus == 0 )
            {
                /*
                *    Execute the directc program
                */
                image_buffer = pFile_buffer;
                calculate_timer_calibration_value();
                Action_code = dp_get_Action_code(pAction);
                time(&start_time);
                iExecResult = dp_top();
                time(&end_time);
                
                if (iExecResult != DPE_SUCCESS)
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nError return code ");
                    dp_display_value(iExecResult,DEC);
                    #endif
                }
                else 
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nExit code = 0... Success");
                    #endif
                }
                
                /*
                *    Print out elapsed time
                */
                iTimeDelta = (int) (end_time - start_time);
                #ifdef ENABLE_DEBUG
                DPPRINTF("\r\nElapsed time = %02u:%02u:%02u",
                iTimeDelta / 3600,            /* hours */
                (iTimeDelta % 3600) / 60,    /* minutes */
                iTimeDelta % 60);            /* seconds */
                #endif
                /*
                *    Print out elapsed time
                */
                
                Fs2SetJtagEnable( gHProbe, ABI_JTAG_Z );
                Fs2ClosePort( gHProbe );
                Fs2Cleanup();
            }
        }
    }
    
    if ( pFile_buffer != (DPUCHAR*)NULL )
        dp_free( pFile_buffer );
    return (iExitStatus);
    #endif
}
