/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpfrom.h                                        */
/*                                                                          */
/*  Description:    Contains the function prototypes.                       */
/*                                                                          */
/****************************************************************************/

#ifndef INC_dpnvm_H
#define INC_dpnvm_H


/****************************************************************************/
/* NVM Opcodes                                                              */
/****************************************************************************/
#define NVM_ADDRESS_SHIFT				0xB8
#define NVM_DATA_SHIFT					0xB9
#define NVM_PROGRAM						0xBA
#define NVM_READ					    0xB7

#define NVM_DATA_SHIFT_ENC				0xC
#define NVM_PROGRAM_ENC					0xD

/****************************************************************************/
/* NVM Register length and parameters                                       */
/****************************************************************************/
#define MAX_LOAD_NVM_ADDRESS_POLL       10000
#define MAX_NVM_READ_POLL               10000
#define NVM_ADDRESS_LENGTH              35
#define NVM_DATA_LENGTH                 32

/****************************************************************************/
/* NVM Calibration Tag Address and data                                     */
/****************************************************************************/
#define NVM_TAG_ADDRESS_BYTE0   0x00
#define NVM_TAG_ADDRESS_BYTE1   0x10
#define NVM_TAG_ADDRESS_BYTE2   0x40
#define NVM_TAG_ADDRESS_BYTE3   0x06
#define NVM_TAG_ADDRESS_BYTE4   0x01
#define NVM_TAG_DATA1_BYTE0     0x43
#define NVM_TAG_DATA1_BYTE1     0x41
#define NVM_TAG_DATA2_BYTE0     0x43
#define NVM_TAG_DATA2_BYTE1     0x42

/****************************************************************************/
/* Function prototypes                                                      */
/****************************************************************************/
void dp_program_nvm_block(DPUCHAR BlockNum);
void dp_verify_nvm_block(DPUCHAR BlockNum);
void dp_enc_program_nvm_block(DPUCHAR BlockNum);
void dp_verify_nvm_action(void);
void dp_program_nvm_action(void);
void dp_verify_calibration(void);

#endif
