/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpcore.c                                                */
/*                                                                          */
/*  Description:    Contains initialization and data checking functions.    */
/*                                                                          */
/****************************************************************************/


#include "dpuser.h"
#include "dpdef.h"
#include "dputil.h"
#include "dpalg.h"
#include "dpjtag.h"
#include "dpcom.h"
#include "dpcore.h"
#include "dpfrom.h"
#include "dpsecurity.h"

DPUINT cycle_count;
#ifdef CORE_SUPPORT
DPUCHAR bol_eol_verify;
DPUCHAR SDNumber;
DPINT RowNumber;


/************************************************************************************************/
/*  Core Action Functions                                                                       */
/************************************************************************************************/
void dp_erase_array_action(void)
{
    device_security_flags |= IS_ERASE_ONLY;
    dp_erase_array();
    return;
}

void dp_program_array_action(void)
{
    #ifdef CORE_ENCRYPT
    if (support_status & CORE_ENCRYPTION_BIT)
    {
        dp_enc_data_authentication();
        if (error_code != DPE_SUCCESS)
            return;
    }
    #endif
    dp_erase_array();
    if (error_code != DPE_SUCCESS)
        return;
    /* Array Programming */
    #ifdef CORE_ENCRYPT    
    if (support_status & CORE_ENCRYPTION_BIT)
    {
        dp_enc_program_array();
        if (error_code == DPE_SUCCESS)
        {
            bol_eol_verify = BOL;
            dp_enc_verify_array();
            if (error_code == DPE_SUCCESS)
            {
                dp_enc_program_rlock();
            }
        }
        if (error_code != DPE_SUCCESS)
            return;
    }
    #endif
    #ifdef CORE_PLAIN
    /* Plain text support */
    if ((support_status & CORE_ENCRYPTION_BIT) == 0)
    {
        dp_program_array();
        if (error_code == DPE_SUCCESS)
        {
            bol_eol_verify = BOL;
            dp_verify_array();
            if (error_code == DPE_SUCCESS)
            {
                dp_program_rlock();
            }
        }
        if (error_code != DPE_SUCCESS)
            return;
    }
    #endif
    
    return;
}

void dp_verify_array_action(void)
{
    /* Array verification */
    #ifdef CORE_ENCRYPT
    if (support_status & CORE_ENCRYPTION_BIT)
    {
        bol_eol_verify = EOL;
        dp_enc_verify_array();
        if (error_code != DPE_SUCCESS)
            return;
    }
    #endif
    #ifdef CORE_PLAIN
    /* Plain text support */
    if ((support_status & CORE_ENCRYPTION_BIT) == 0)
    {
        bol_eol_verify = EOL;
        dp_verify_array();
        if (error_code != DPE_SUCCESS)
            return;
    }
    #endif
    return;
}

#ifdef CORE_ENCRYPT
void dp_enc_data_authentication_action(void)
{
    dp_enc_data_authentication();
    return;
}
#endif
/************************************************************************************************/


/************************************************************************************************/
/* Common Functions                                                                             */
/************************************************************************************************/
void dp_erase_array(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nErase FPGA Array...");
    #endif
    dp_flush_global_buf1();
    global_buf1[0] = UROW_ERASE_BITS_BYTE0 | CORE_ERASE_BITS_BYTE0;
    global_buf1[1] = UROW_ERASE_BITS_BYTE1 | CORE_ERASE_BITS_BYTE1;
    global_buf1[2] = UROW_ERASE_BITS_BYTE2 | CORE_ERASE_BITS_BYTE2;
    
    dp_exe_erase();
    return;
}

void dp_exe_program(void)
{
    /* PROGRAM  */
    opcode = ISC_PROGRAM;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_poll_device();
    
    return;
}

void dp_exe_verify(void)
{
    /* Verify0 */
    opcode = ISC_VERIFY0;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, 2, &bol_eol_verify, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(264);
    
    dp_poll_device();
    if (error_code != DPE_SUCCESS)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nVerify 0 failed\r\nRow Number : "); 
        dp_display_value(RowNumber,DEC);
        #endif
        error_code = DPE_CORE_VERIFY_ERROR;
        return;
    }
    opcode = ISC_VERIFY0;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(2, global_buf1, &global_uchar);
    dp_goto_state(JTAG_DRPAUSE);
    
    if ((global_uchar & 0x3) != 0)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nVerify 0 failed\r\nRow Number : "); 
        dp_display_value(RowNumber,DEC);
        #endif
        error_code = DPE_CORE_VERIFY_ERROR;
        return;
    }
    
    /* Verify1 */
    opcode = ISC_VERIFY1;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, 2, &bol_eol_verify, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(264);
    
    dp_poll_device();
    if (error_code != DPE_SUCCESS)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nVerify 1 failed\r\nRow Number : "); 
        dp_display_value(RowNumber,DEC);
        #endif
        error_code = DPE_CORE_VERIFY_ERROR;
        return;
    }
    
    
    opcode = ISC_VERIFY1;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(2, global_buf1, &global_uchar);
    dp_goto_state(JTAG_DRPAUSE);
    if ((global_uchar & 0x3) != 0)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nVerify 1 failed\r\nRow Number : "); 
        dp_display_value(RowNumber,DEC);
        #endif
        error_code = DPE_CORE_VERIFY_ERROR;
        return;
    }
    return;
}

void dp_reset_address(void)
{
    opcode = ISC_INCREMENT;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    global_uchar = 2;
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, 2, &global_uchar, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    
    return;
}

void dp_increment_address(void)
{
    opcode = ISC_INCREMENT;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    global_uchar = 3;
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, 2, &global_uchar, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    
    return;
}
#ifdef ENABLE_AXXE1500_SUPPORT
void dp_load_row_address(void)
{
    DPUCHAR Tiles;
    DPUCHAR TileSize[132] = {
        1,48,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,
        44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,
        44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44, 1, 1,44,44,44,44,44,44,
        44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,
        44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,
        44,44,44,44,44,44,44,44,44,44,48,1
    };
    
    DPINT LastSumOfTileRows = 0;
    DPINT SumOfTileRows = 0;
    DPUCHAR Address[24]= { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
        DPUINT IO = 0;
        DPUCHAR RP = 0;
        DPUCHAR LH = 0;
        DPUCHAR BitsToShift;
        DPUCHAR AddressIndex;
        /* Calculate which tile the row belongs to and what row within the tile we are programming*/
        for(Tiles = 0; Tiles < 132; Tiles ++)
        {
            SumOfTileRows += TileSize[Tiles];
            if (RowNumber <= (SumOfTileRows -1))
            {
                break;
            }
            else
            {
                LastSumOfTileRows = SumOfTileRows;
            }
        }
        if ((RowNumber - LastSumOfTileRows) >= 38)
        {
            BitsToShift = (DPUCHAR) ((TileSize[Tiles] - 1)  - (RowNumber - LastSumOfTileRows));
            IO = 0x200 >> BitsToShift;
            RP = 0x20 >> BitsToShift;
            LH = 0x20 >> BitsToShift;
            
            Address[22] |= (DPUCHAR) (IO << 6);
            Address[23] |= (DPUCHAR) (IO >> 2);
            Address[22] |= RP;
            Address[21] |= LH << 2;
        }
        /* Setting row select bit */
        if ((RowNumber - LastSumOfTileRows) < 38)
        {
            BitsToShift = (DPUCHAR) (RowNumber - LastSumOfTileRows) + 4;
            AddressIndex = BitsToShift / 8;
            BitsToShift -= (AddressIndex * 8);
            AddressIndex += 16;
            Address[AddressIndex] |= (1 << BitsToShift);
        }
        /* Setting tile bit */
        AddressIndex = Tiles / 8;
        BitsToShift = Tiles - AddressIndex * 8;
        Address[AddressIndex] |= (1 << BitsToShift);
        
        /* Shift the address */
        opcode = ISC_ADDRESS_SHIFT;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IRPAUSE);
        dp_goto_state(JTAG_SHDR);
        dp_shift_in(0, 192, Address,1);
        dp_goto_state(JTAG_IDLE);
        dp_wait_cycles(1);
        
        return;
    }
    #endif
    
    #ifdef CORE_PLAIN
    /************************************************************************************************/
    /* Plain text array programming functions                                                       */
    /************************************************************************************************/
    void dp_program_array(void)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nProgramming FPGA Array...");
        #endif
        dp_reset_address();
        DataIndex = 0;
        for ( RowNumber = device_rows - 1; RowNumber >= 0; RowNumber-- )
        {
            #ifdef ENABLE_DEBUG
            if ((RowNumber % 100) == 0)
                dp_display_text(".");
            #endif
            #ifdef ENABLE_AXXE1500_SUPPORT
            if ((device_ID & AXXE1500X_ID_MASK) == (AXXE1500X_ID & AXXE1500X_ID_MASK))
            {
                if (device_family & DAS_BIT)
                {
                    dp_load_row_address();
                }
            }
            #endif
            dp_load_row_data();
            dp_exe_program();
            if (error_code != DPE_SUCCESS)
            {
                #ifdef ENABLE_DEBUG
                dp_display_text("\r\nFailed to program FPGA Array at row ");
                dp_display_value(RowNumber,DEC);
                #endif
                error_code = DPE_CORE_PROGRAM_ERROR;
                return;
            }
            dp_increment_address();
        }
        return;
    }
    
    
    void dp_verify_array(void)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nVerifying FPGA Array...");
        #endif
        
        dp_reset_address();
        DataIndex = 0;
        for ( RowNumber = device_rows - 1; RowNumber >= 0; RowNumber-- )
        {
            #ifdef ENABLE_DEBUG
            if ((RowNumber % 100) == 0)
                dp_display_text(".");
            #endif
            #ifdef ENABLE_AXXE1500_SUPPORT
            if ((device_ID & AXXE1500X_ID_MASK) == (AXXE1500X_ID & AXXE1500X_ID_MASK))
            {
                if (device_family & DAS_BIT)
                {
                    dp_load_row_address();
                }
            }
            #endif
            dp_load_row_data();
            dp_exe_verify();
            if (error_code != DPE_SUCCESS)
                return;
            dp_increment_address();
        }
        return;
    }
    
    
    /****************************************************************************/
    /*  Address and Data Loading                                                */
    /****************************************************************************/
    void dp_load_row_data(void)
    {
        /* Load one row of FPGA Array data  */
        opcode = ISC_DATA_SHIFT;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IRPAUSE);
        
        for ( SDNumber = 1; SDNumber <= device_SD; SDNumber++ )
        {
            for ( global_ulong = 1; global_ulong <= 8; global_ulong++ )
            {
                dp_goto_state(JTAG_SHDR);
                dp_get_and_shift_in(datastream_ID, ARRAY_ROW_LENGTH, DataIndex);
                dp_goto_state(JTAG_IDLE);
                dp_wait_cycles(3);
                DataIndex = DataIndex + ARRAY_ROW_LENGTH;
            }
        }
        return;
    }
    
    void dp_program_rlock(void)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nProgramming RLOCK...");
        #endif
        
        DataIndex = 0;
        opcode = ISC_DATA_SHIFT;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IRPAUSE);
        
        for ( SDNumber = 1; SDNumber <= device_SD; SDNumber++ )
        {
            for ( global_ulong = 1; global_ulong <= 8; global_ulong++ )
            {
                dp_goto_state(JTAG_SHDR);
                dp_get_and_shift_in(rlock_ID, ARRAY_ROW_LENGTH, DataIndex);
                dp_goto_state(JTAG_IDLE);
                dp_wait_cycles(3);
                DataIndex = DataIndex + ARRAY_ROW_LENGTH;
            }
        }
        
        opcode = ISC_PROGRAM_RLOCK;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IDLE);
        dp_wait_cycles(3);
        dp_poll_device();
        if (error_code != DPE_SUCCESS)
        {
            #ifdef ENABLE_DEBUG
            dp_display_text("\r\nFailed to program RLOCK ");
            #endif
            error_code = DPE_PROGRAM_RLOCK_ERROR;
            return;
        }
        
        return;
    }
    #endif
    
    
    #ifdef CORE_ENCRYPT
    /************************************************************************************************/
    /* Encryption array programming functions                                                       */
    /************************************************************************************************/
    void dp_enc_program_array(void)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nProgramming FPGA Array...");
        #endif
        if (device_family & DUAL_KEY_BIT)
        {
            global_uchar = AES_mode_value;
            dp_set_aes_mode();
        }
        dp_init_aes();
        dp_reset_address();
        
        DataIndex = 0;
        for ( RowNumber = device_rows - 1; RowNumber >= 0; RowNumber-- )
        {
            #ifdef ENABLE_DEBUG
            if ((RowNumber % 100) == 0)
                dp_display_text(".");
            #endif
            #ifdef ENABLE_AXXE1500_SUPPORT
            if ((device_ID & AXXE1500X_ID_MASK) == (AXXE1500X_ID & AXXE1500X_ID_MASK))
            {
                if (device_family & DAS_BIT)
                {
                    dp_load_row_address();
                }
            }
            #endif
            dp_load_enc_row_data();
            dp_exe_program();
            if (error_code != DPE_SUCCESS)
            {
                #ifdef ENABLE_DEBUG
                dp_display_text("\r\nFailed to program FPGA Array at row ");
                dp_display_value(RowNumber,DEC);
                #endif
                error_code = DPE_CORE_PROGRAM_ERROR;
                return;
            }
            dp_increment_address();
        }
        return;
    }
    
    
    void dp_enc_verify_array(void)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nVerifying FPGA Array...");
        #endif
        
        if (device_family & DUAL_KEY_BIT)
        {
            global_uchar = AES_mode_value;
            dp_set_aes_mode();
        }
        
        dp_init_aes();
        dp_reset_address();
        
        DataIndex = 0;
        for ( RowNumber = device_rows - 1; RowNumber >= 0; RowNumber-- )
        {
            #ifdef ENABLE_DEBUG
            if ((RowNumber % 100) == 0)
                dp_display_text(".");
            #endif
            #ifdef ENABLE_AXXE1500_SUPPORT
            if ((device_ID & AXXE1500X_ID_MASK) == (AXXE1500X_ID & AXXE1500X_ID_MASK))
            {
                if (device_family & DAS_BIT)
                {
                    dp_load_row_address();
                }
            }
            #endif
            dp_load_enc_row_data();
            dp_exe_verify();
            if (error_code != DPE_SUCCESS)
                return;
            dp_increment_address();
        }
        return;
    }
    
    void dp_load_enc_row_data(void)
    {
        opcode = DESCRAMBLE;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IRPAUSE);
        
        
        /* Load one row of FPGA Array data  */
        for ( SDNumber = 1; SDNumber <= device_SD; SDNumber++ )
        {
            
            for ( global_ulong = 0; global_ulong <= 1; global_ulong++ )
            {
                dp_goto_state(JTAG_SHDR);
                dp_get_and_shift_in(datastream_ID, AES_BLOCK_LENGTH, DataIndex);
                dp_goto_state(JTAG_IDLE);
                dp_wait_cycles(3);
                dp_delay(48);
                DataIndex = DataIndex + AES_BLOCK_LENGTH;
            }
        }
        return;
    }
    
    void dp_enc_program_rlock(void)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nProgramming Rlock...");
        #endif
        
        DataIndex = 0;
        opcode = DESCRAMBLE;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IRPAUSE);
        for ( SDNumber = 1; SDNumber <= device_SD; SDNumber++ )
        {
            for ( global_ulong = 0; global_ulong <= 1; global_ulong++ )
            {
                dp_goto_state(JTAG_SHDR);
                dp_get_and_shift_in(rlock_ID, AES_BLOCK_LENGTH, DataIndex);
                dp_goto_state(JTAG_IDLE);
                dp_wait_cycles(3);
                dp_delay(48);
                DataIndex = DataIndex + AES_BLOCK_LENGTH;
            }
        }	
        
        opcode = ISC_PROGRAM_RDLC;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IDLE);
        dp_wait_cycles(1);
        dp_poll_device();
        
        return;
    }
    
    void dp_enc_data_authentication(void)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nPerforming Data Authentication...");
        #endif
        
        if (device_family & DUAL_KEY_BIT)
        {
            global_uchar = AES_mode_value;
            dp_set_aes_mode();
        }
        
        
        dp_init_aes();
        dp_reset_address();
        
        DataIndex = 0;
        for ( RowNumber = device_rows - 1; RowNumber >= 0; RowNumber-- )
        {
            
            #ifdef ENABLE_DEBUG
            if ((RowNumber % 100) == 0)
                dp_display_text(".");
            #endif
            
            dp_load_enc_row_data();
            
            dp_exe_authentication();
            if (error_code != DPE_SUCCESS)
                return;
        }
        dp_exe_authentication();
        return;
    }
    
    void dp_exe_authentication(void)
    {
        opcode = ISC_NOOP;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IDLE);
        dp_wait_cycles(3);
        dp_delay(264);
        
        dp_goto_state(JTAG_SHDR);
        dp_shift_in_out(5, (DPUCHAR*)NULL, &global_uchar);
        dp_goto_state(JTAG_DRPAUSE);
        if (global_uchar & 0x8)
        {
            error_code = DPE_AUTHENTICATION_FAILURE;
            #if defined (ENABLE_DEBUG) 
            dp_display_text("\r\nFailed to authenticate the encrypted data.\r\n");
            #endif
        }
        return;
    }
    #endif /* End of CORE_ENCRYPT */
    
    
    void dp_smart_erase(void)
    {
        DPUCHAR SE_iteration;
        global_uchar = 0x5;
        dp_read_factory_row();
        SE_iteration = global_buf1[14] >> 1;
        SE_iteration |= (global_buf1[14] << 7);
        
        for(DataIndex = 0; DataIndex < SE_iteration; DataIndex++)
        {
            dp_erase_tighten();
            
            opcode = ISC_SMART_ERASE;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_shift_in(0, 2, (DPUCHAR*)NULL, 1);
            dp_goto_state(JTAG_IDLE);
            dp_wait_cycles(device_se_wait_cycle);
            dp_poll_smart_erase();    
            
            if (error_code != DPE_SUCCESS)
            {
                #ifdef ENABLE_DEBUG
                dp_display_text("\r\nFailed Smart Erease Operation");
                #endif
                error_code = DPE_ERASE_ERROR;
                return;
            }
            if (global_uchar & 0x2)
            {
                return;
            }
        }
        error_code = DPE_ERASE_ERROR;
        return;
    }
    
    
    
    
    
    
    void dp_erase_tighten(void)
    {
        
        dp_reset_address();
        for ( RowNumber = device_rows - 1; RowNumber >= 0; RowNumber-- )
        {
            opcode = ISC_ERASE_TIGHTEN;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_shift_in(0, 3, (DPUCHAR*)NULL, 1);
            dp_goto_state(JTAG_IDLE);
            dp_wait_cycles(3);
            dp_poll_erase_tighten();
            if (error_code != DPE_SUCCESS)
            {
                #ifdef ENABLE_DEBUG
                dp_display_text("\r\nFailed Smart Erease Operation");
                #endif
                error_code = DPE_ERASE_ERROR;
                return;
            }
            
            dp_increment_address();
            
        }
    }
    
    void dp_poll_erase_tighten(void)
    {
        
        dp_goto_state(JTAG_DRPAUSE);
        for ( global_ulong = 0; global_ulong <= MAX_ERASE_TIGHTEN_POLL; global_ulong++ )
        {
            dp_delay(10);
            opcode = ISC_ERASE_TIGHTEN;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_shift_in_out(3, (DPUCHAR*)NULL, &global_uchar);
            dp_goto_state(JTAG_DRPAUSE);
            
            if ((global_uchar & 0x1) == 0)
            {
                return;
            }
        }
        error_code = DPE_POLL_ERROR;
        return;
    }
    
    
    void dp_poll_smart_erase(void)
    {
        for ( global_ulong = 0; global_ulong <= MAX_ERASE_POLL; global_ulong++ )
        {
            dp_goto_state(JTAG_SHDR);
            dp_shift_in_out(2, (DPUCHAR*)NULL, &global_uchar);
            dp_goto_state(JTAG_DRPAUSE);
            
            if ((global_uchar & 0x1) == 0)
            {
                return;
            }
            dp_delay(2003);
            opcode = ISC_SMART_ERASE;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
        }
        
        error_code = DPE_ERASE_ERROR;
        return;
    }
    
    
    #endif /* End of CORE_SUPPORT */
