/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpnvm.c                                         */
/*                                                                          */
/*  Description:    Contains initialization and data checking functions.    */
/*                                                                          */
/****************************************************************************/

#include "dpuser.h"
#include "dpdef.h"
#include "dpalg.h"
#include "dputil.h"
#include "dpjtag.h"
#include "dpcom.h"
#include "dpnvm.h"
#include "dpsecurity.h"

#ifdef NVM_SUPPORT
DPUCHAR Protection;
DPUINT Par;
DPULONG ParSize;
DPUINT NumOfPart;

/************************************************************************************************/
/*  NVM Action Functions                                                                        */
/************************************************************************************************/
void dp_program_nvm_action(void)
{
    if (support_status & NVM0_SUPPORT_BIT)
    {
        #ifdef NVM_ENCRYPT
        /* Encryption support */
        if (support_status & NVM0_ENCRYPTION_BIT)
        {
            dp_enc_program_nvm_block(0);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
        #ifdef NVM_PLAIN
        /* Plain text support */
        if ((support_status & NVM0_ENCRYPTION_BIT) == 0)
        {
            dp_program_nvm_block(0);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
    }
    if (support_status & NVM1_SUPPORT_BIT)
    {
        /* Encryption support */
        #ifdef NVM_ENCRYPT
        if (support_status & NVM1_ENCRYPTION_BIT)
        {
            dp_enc_program_nvm_block(1);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
        #ifdef NVM_PLAIN
        /* Plain text support */
        if ((support_status & NVM1_ENCRYPTION_BIT) == 0)
        {
            dp_program_nvm_block(1);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
    }
    if (support_status & NVM2_SUPPORT_BIT)
    {
        #ifdef NVM_ENCRYPT
        /* Encryption support */
        if (support_status & NVM2_ENCRYPTION_BIT)
        {
            dp_enc_program_nvm_block(2);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
        #ifdef NVM_PLAIN
        /* Plain text support */
        if ((support_status & NVM2_ENCRYPTION_BIT) == 0)
        {
            dp_program_nvm_block(2);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
    }
    if (support_status & NVM3_SUPPORT_BIT)
    {
        #ifdef NVM_ENCRYPT
        /* Encryption support */
        if (support_status & NVM3_ENCRYPTION_BIT)
        {
            dp_enc_program_nvm_block(3);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
        #ifdef NVM_PLAIN
        /* Plain text support */
        if ((support_status & NVM3_ENCRYPTION_BIT) == 0)
        {
            dp_program_nvm_block(3);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
    }
    return;
}
#ifdef NVM_PLAIN
void dp_verify_nvm_action(void)
{
    if (support_status & NVM0_SUPPORT_BIT)
    {
        if ((support_status & NVM0_ENCRYPTION_BIT) == 0)
        {
            dp_verify_nvm_block(0);
            if (error_code != DPE_SUCCESS)
                return;
        }
    }
    
    if (support_status & NVM1_SUPPORT_BIT)
    {
        if ((support_status & NVM1_ENCRYPTION_BIT) == 0)
        {
            dp_verify_nvm_block(1);
            if (error_code != DPE_SUCCESS)
                return;
        }
    }
    
    if (support_status & NVM2_SUPPORT_BIT)
    {
        if ((support_status & NVM2_ENCRYPTION_BIT) == 0 )
        {
            dp_verify_nvm_block(2);
            if (error_code != DPE_SUCCESS)
                return;
        }
    }
    
    if (support_status & NVM3_SUPPORT_BIT)
    {
        if ((support_status & NVM3_ENCRYPTION_BIT) == 0 )
        {
            dp_verify_nvm_block(3);
            if (error_code != DPE_SUCCESS)
                return;
        }
    }
    return;
}
#endif
/************************************************************************************************/

/************************************************************************************************/
/* PLAIN Programming Support Functions                                                          */
/************************************************************************************************/
#ifdef NVM_PLAIN
void dp_program_nvm_block(DPUCHAR BlockNum)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nProgramming NVM block ");
    dp_display_value(BlockNum,DEC);
    #endif
    
    /* Get how many partitions are in the code */
    NumOfPart = (DPINT) dp_get_bytes(NumOfPart_ID+BlockNum*NVM_OFFSET,0,2);
    DataIndex = 0;
    
    /* Go through all the partions in the file */
    for (Par=0;Par < NumOfPart; Par++)
    {
        /* Get partition size and protection */
        ParSize = dp_get_bytes(NvmParSize_ID+BlockNum*NVM_OFFSET,(Par*32) >> 3,4);
        Protection = (DPUCHAR) dp_get_bytes(NvmProtect_ID+BlockNum*NVM_OFFSET,(Par*3) >> 3,1) << 2;
        
        dp_flush_global_buf2();
        /* Get the starting address of the partition */
        /* 22 is the number of bits per one address */
        /* Par*22 >> 8 is the location of the first byte of the address in the data block*/
        /* The number of bytes to get could be 3 or 4 depending on wether the bits span over 3 or 4 bytes
        (par*22) & 7 is the number of bits that need to be shifted to get to the first valid bit in the address.
        Ex: for par=1, it is equal to 6.
        We add 22 to this value, then the integer value of adding 7 and divide the total by 8 will get the us the number of bytes needed.
        >> ((Par*22) & 7) lines up the address so that it always starts from bit postion 0 */
        global_ulong = dp_get_bytes(NvmAddr_ID+BlockNum*NVM_OFFSET,(Par*22) >> 3,(DPUCHAR)((((Par*22) & 7) + 22 + 7) >> 3)) >> ((Par*22) & 7) ;
        
        /* global_buf2 holds the starting address of the NVM partition */
        global_buf2[1] = (DPUCHAR) (global_ulong << 5) | 0x10;
        global_buf2[2] = (DPUCHAR) (global_ulong >> 3);
        global_buf2[3] = (DPUCHAR) (global_ulong >> 11);
        global_buf2[4] = (DPUCHAR) (global_ulong >> 19);
        
        /* Load NVM Address */
        opcode = NVM_ADDRESS_SHIFT;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IRPAUSE);
        dp_goto_state(JTAG_SHDR);
        dp_shift_in(0, NVM_ADDRESS_LENGTH, global_buf2, 1);
        dp_goto_state(JTAG_IDLE);
        dp_wait_cycles(3);
        dp_delay(20);
        /* Perform address polling */
        for ( global_ulong = 1; global_ulong <= MAX_LOAD_NVM_ADDRESS_POLL; global_ulong++ )
        {
            dp_wait_cycles(3);
            dp_delay(100);
            dp_goto_state(JTAG_SHDR);
            dp_shift_in_out(NVM_ADDRESS_LENGTH, global_buf2, global_buf1);
            dp_goto_state(JTAG_DRPAUSE);
            
            if ((global_buf1[4] & 0x6) != 0)
            {
                if (global_ulong == MAX_LOAD_NVM_ADDRESS_POLL)
                {
                    error_code = DPE_POLL_ERROR;
                    return;
                }
            }
            else 
            {
                break;
            }
        }
        
        /* Load the data */
        opcode = NVM_DATA_SHIFT;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IRPAUSE);
        for (global_uint=1; global_uint <= ParSize ;global_uint++)
        {
            #ifdef ENABLE_DEBUG
            if ((global_uint % 100) == 0)
                dp_display_text(".");
            #endif
            dp_goto_state(JTAG_SHDR);
            dp_get_and_shift_in(NvmData_ID+BlockNum*NVM_OFFSET, NVM_DATA_LENGTH, DataIndex);
            dp_goto_state(JTAG_IDLE);
            dp_wait_cycles(3);
            DataIndex = DataIndex + NVM_DATA_LENGTH;
            
            if ((global_uint % NVM_DATA_LENGTH) == 0)
            {
                opcode = NVM_PROGRAM;
                dp_goto_state(JTAG_SHIR);
                dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
                dp_goto_state(JTAG_IRPAUSE);
                dp_goto_state(JTAG_SHDR);
                dp_shift_in(0, 5, &Protection, 1);
                dp_goto_state(JTAG_IDLE);
                dp_wait_cycles(3);
                
                /* Perform NVM Program polling */
                for ( global_ulong = 1; global_ulong <= MAX_LOAD_NVM_ADDRESS_POLL; global_ulong++ )
                {
                    dp_delay(100);
                    global_uchar = 0;
                    dp_goto_state(JTAG_SHDR);
                    dp_shift_in_out(5, &Protection, &global_uchar);
                    dp_goto_state(JTAG_DRPAUSE);
                    if ((global_uchar & 0x1c) != 0)
                    {
                        if (global_ulong == MAX_LOAD_NVM_ADDRESS_POLL)
                        {
                            error_code = DPE_POLL_ERROR;
                            return;
                        }
                    }
                    else 
                    {
                        break;
                    }
                    
                }
            }
            opcode = NVM_DATA_SHIFT;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
        }	
        
    }
    return;
}

void dp_verify_nvm_block(DPUCHAR BlockNum)
{	
    DPUINT PageAddress;
    DPULONG TmpData;
    DPUCHAR offset;
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nVerifying NVM block ");
    dp_display_value(BlockNum,DEC);
    #endif
    
    /* Get how many partitions are in the code */
    NumOfPart = (DPINT) dp_get_bytes(NumOfPart_ID+BlockNum*NVM_OFFSET,0,2);
    DataIndex = 0;
    
    
    /* Go through all the partions in the file */
    for (Par=0;Par < NumOfPart; Par++)
    {
        /* Get the starting address of the partition */
        /* 22 is the number of bits per one address */
        /* Par*22 >> 8 is the location of the first byte of the address in the data block*/
        /* The number of bytes to get could be 3 or 4 depending on wether the bits span over 3 or 4 bytes
        (par*22) & 7 is the number of bits that need to be shifted to get to the first valid bit in the address.
        Ex: for par=1, it is equal to 6.
        We add 22 to this value, then the integer value of adding 7 and divide the total by 8 will get the us the number of bytes needed.
        >> ((Par*22) & 7) lines up the address so that it always starts from bit postion 0 
        */
        global_ulong = dp_get_bytes(NvmAddr_ID+BlockNum*NVM_OFFSET,(Par*22) >> 3,(DPUCHAR)((((Par*22) & 7) + 22 + 7) >> 3)) >> ((Par*22) & 7) ;
        PageAddress = global_ulong >> 8; /* 14 bit long */
        offset = 0;					 /* 5 bit long */
        /* Get partition size */
        ParSize = dp_get_bytes(NvmParSize_ID+BlockNum*NVM_OFFSET,(Par*32) >> 3,4);
        for (global_uint=0; global_uint < ParSize ;global_uint++)
        {
            #ifdef ENABLE_DEBUG
            if ((global_uint % 100) == 0)
                dp_display_text(".");
            #endif
            
            if (((global_uint % NVM_DATA_LENGTH) == 0) && global_uint)
            {
                PageAddress++;
                for (global_uchar = 0;global_uchar < 32; global_uchar ++)
                {
                    opcode = NVM_READ;
                    dp_goto_state(JTAG_SHIR);
                    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
                    dp_goto_state(JTAG_IRPAUSE);
                    dp_goto_state(JTAG_SHDR);
                    dp_shift_in(0, NVM_ADDRESS_LENGTH, (DPUCHAR*)NULL, 1);
                    dp_goto_state(JTAG_IDLE);
                    dp_wait_cycles(3);
                }
            }
            
            dp_flush_global_buf2();
            
            /* global_buf2 holds the starting address of the NVM partition */
            /* Bit 7 needs to be replaced. */
            global_buf2[1] |= 0x10;				/* 32 Bit word addressing */
            global_buf2[1] &= 0x7F;				/* This is to maintaing bit values 13 and 14 */
            global_buf2[1] |= offset << 7;			/* Overwrite offset */
            global_buf2[2] = (offset >> 1) & 0xf;	/* Overwrite offset */
            global_buf2[2] |= (PageAddress << 5);	/* Overwrite PageAddress */
            global_buf2[3] = (DPUCHAR)(PageAddress >> 3);	/* Overwrite PageAddress */
            global_buf2[4] = (DPUCHAR)(PageAddress >> 11);	/* Overwrite PageAddress */
            
            
            /* Load NVM Address */
            opcode = NVM_ADDRESS_SHIFT;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_shift_in(0, NVM_ADDRESS_LENGTH, global_buf2, 1);
            dp_goto_state(JTAG_IDLE);
            dp_wait_cycles(3);
            dp_delay(20);
            
            /* Perform address polling */
            for ( global_ulong = 0; global_ulong <= MAX_LOAD_NVM_ADDRESS_POLL; global_ulong++ )
            {
                dp_delay(100);
                dp_goto_state(JTAG_SHDR);
                dp_shift_in_out(NVM_ADDRESS_LENGTH, global_buf2, global_buf1);
                dp_goto_state(JTAG_DRPAUSE);
                if ((global_buf1[4] & 0x6) != 0)
                {
                    if (global_ulong == MAX_LOAD_NVM_ADDRESS_POLL)
                    {
                        error_code = DPE_POLL_ERROR;
                        return;
                    }
                }
                else 
                {
                    break;
                }
            }
            
            /* Read the Data */
            TmpData = dp_get_bytes(NvmData_ID+BlockNum*NVM_OFFSET, DataIndex >> 3, 4);
            
            opcode = NVM_READ;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_shift_in(0, NVM_ADDRESS_LENGTH, (DPUCHAR*)NULL, 1);
            dp_goto_state(JTAG_IDLE);
            dp_wait_cycles(3);
            dp_delay(30);
            
            for ( global_ulong = 0; global_ulong <= MAX_NVM_READ_POLL; global_ulong++ )
            {
                dp_goto_state(JTAG_SHDR);
                dp_shift_in_out(NVM_ADDRESS_LENGTH, (DPUCHAR*)NULL, global_buf1);
                dp_goto_state(JTAG_DRPAUSE);
                if (TmpData != ((DPULONG)(global_buf1[0] | (global_buf1[1] << 8) | (global_buf1[2] << 16) | (global_buf1[3] << 24) )) )
                {
                    if (global_ulong == MAX_LOAD_NVM_ADDRESS_POLL)
                    {
                        error_code = DPE_POLL_ERROR;
                        return;
                    }
                }
                else 
                {
                    break;
                }
            }
            
            offset ++;
            DataIndex = DataIndex + 32;
            
        }	
    }
    return;
}


void dp_verify_calibration(void)
{	
    
    DPUINT StartPageAddress;
    DPUINT EndPageAddress;
    DPUCHAR offset;
    
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nChecking for Calibration data... ");
    #endif
    
    global_buf2[0] = NVM_TAG_ADDRESS_BYTE0;
    global_buf2[1] = NVM_TAG_ADDRESS_BYTE1;
    global_buf2[2] = NVM_TAG_ADDRESS_BYTE2;
    global_buf2[3] = NVM_TAG_ADDRESS_BYTE3;
    global_buf2[4] = NVM_TAG_ADDRESS_BYTE4;
    
    /* Load NVM TAG Address */
    opcode = NVM_ADDRESS_SHIFT;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, NVM_ADDRESS_LENGTH, global_buf2, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(20);
    
    for ( global_ulong = 0; global_ulong <= MAX_LOAD_NVM_ADDRESS_POLL; global_ulong++ )
    {
        dp_delay(100);
        dp_goto_state(JTAG_SHDR);
        dp_shift_in_out(NVM_ADDRESS_LENGTH, global_buf2, global_buf1);
        dp_goto_state(JTAG_DRPAUSE);
        if ((global_buf1[4] & 0x6) != 0)
        {
            if (global_ulong == MAX_LOAD_NVM_ADDRESS_POLL)
            {
                error_code = DPE_POLL_ERROR;
                return;
            }
        }
        else 
        {
            break;
        }
    }
    
    /* Read the Data */
    opcode = NVM_READ;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, NVM_ADDRESS_LENGTH, (DPUCHAR*)NULL, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(30);
    dp_flush_global_buf1();
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(NVM_ADDRESS_LENGTH, (DPUCHAR*)NULL, global_buf1);
    dp_goto_state(JTAG_DRPAUSE);
    if ( (global_buf1[0] == 'C') && ((global_buf1[1] == 'A') || (global_buf1[1] == 'B')) )
    {
        device_family |= CALIBRATION_BIT;
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nDevice is calibrated...");
        #endif
    }
    
    
    
    if (device_family & CALIBRATION_BIT)
    {
        
        NumOfPart = (DPINT) dp_get_bytes(NumOfPart_ID,0,2);
        DataIndex = 0;
        
        /* Go through all the partions in the file */
        for (Par=0;Par < NumOfPart; Par++)
        {
            global_ulong = dp_get_bytes(NvmAddr_ID,(Par*22) >> 3,(DPUCHAR)((((Par*22) & 7) + 22 + 7) >> 3)) >> ((Par*22) & 7) ;
            StartPageAddress = global_ulong >> 8; /* 14 bit long */
            offset = (DPUCHAR) (global_ulong & 0x7f);
            
            /* Get partition size */
            ParSize = dp_get_bytes(NvmParSize_ID,(Par*32) >> 3,4);
            EndPageAddress = StartPageAddress + ((ParSize + offset + 31) / 32 ) - 1;
            if ( (EndPageAddress >= 2098) && (StartPageAddress <=2110) )
            {
                error_code = CALIBRATION_OVERLAP_ERROR;
                #ifdef ENABLE_DEBUG
                dp_display_text("\r\nCalibration overlap detected...");
                #endif
            }
        }
    }
    return;
}



#endif
/************************************************************************************************/

/************************************************************************************************/
/* Encrypted Programming Support Functions                                                      */
/************************************************************************************************/
#ifdef NVM_ENCRYPT
void dp_enc_program_nvm_block(DPUCHAR BlockNum)
{
    
    DPINT NvmProtIndex=0;
    DPUINT i;
    DPUINT j;
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nProgramming NVM block ");
    dp_display_value(BlockNum,DEC);
    #endif
    
    if (device_family & DUAL_KEY_BIT)
    {
        global_uchar = 0;
        dp_set_aes_mode();
    }
    dp_init_aes();
    
    
    NumOfPart = (DPINT) dp_get_bytes(NumOfPart_ID+BlockNum*NVM_OFFSET,0,2);
    DataIndex = 0;
    
    for (Par=0;Par < NumOfPart; Par++)
    {
        ParSize = dp_get_bytes(NvmParSize_ID+BlockNum*NVM_OFFSET,(Par*32) >> 3,4);
        dp_init_aes();
        
        for (i=1; i<=ParSize/32;i++)
        {
            #ifdef ENABLE_DEBUG
            if ((i % 100) == 0)
                dp_display_text(".");
            #endif
            
            
            for (j=0; j<=15;j++)
            {
                opcode = NVM_DATA_SHIFT_ENC;
                dp_goto_state(JTAG_SHIR);
                dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
                dp_goto_state(JTAG_IRPAUSE);
                dp_goto_state(JTAG_SHDR);
                dp_get_and_shift_in_out(NvmData_ID + BlockNum*NVM_OFFSET,128,DataIndex,global_buf1);
                dp_goto_state(JTAG_IDLE);
                
                dp_wait_cycles(3);
                dp_delay(10000);
                DataIndex = DataIndex + 128;
                if (global_buf1[0] & 0x10)
                {
                    error_code = DPE_NVM_PROGRAM_ERROR;
                    return;
                }
            }
            
            opcode = NVM_PROGRAM_ENC;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_get_and_shift_in_out(NvmProtect_ID + BlockNum*NVM_OFFSET,128,NvmProtIndex,global_buf1);
            dp_goto_state(JTAG_IDLE);
            dp_wait_cycles(3);
            dp_delay(10000);
            if (global_buf1[0] & 0x10)
            {
                error_code = DPE_NVM_PROGRAM_ERROR;
                return;
            }
            
            NvmProtIndex = NvmProtIndex + 128;
            
        }
    }
    return;
}

#endif
#endif
