/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpalg.h                                                 */
/*                                                                          */
/*  Description:    Contains the function prototypes.                       */
/*                                                                          */
/****************************************************************************/

#ifndef INC_DPALG_H
#define INC_DPALG_H
/* global_buf_SIZE should not exceed 256 bytes */
#define BOL 0
#define EOL 3

#define global_buf_SIZE 16

/************************************************************/
/* Instrunction Set											*/
/************************************************************/
/* General opcodes */
#define ISC_SAMPLE				0x01
#define ISC_ENABLE				0x80
#define ISC_DISABLE				0x81
#define ISC_NOOP				0x84
#define DESELECT_ALL_TILES      0xC0
/* Erase opcodes */
#define ISC_ERASE				0x85

/* UROW opcodes */
#define ISC_PROGRAM_UROW		0xA7
#define ISC_READ_UROW			0xA8
#define ISC_PROGRAM_RLOCK		0x8C

#define HIGHZ                   0x07
#define BYPASS                  0xFF
#define IDCODE                  0x0F
#define USERCODE                0x0e
/* Factory row opcodes */
#define FACTORY_ADDRESS_SHIFT   0xF9
#define READ_FACTORY            0xBF

/************************************************************/
/* Register Length											*/
/************************************************************/
#define MAX_ERASE_POLL		    262140
#define MAX_PROGRAM_POLL		16380
#define OPCODE_BIT_LENGTH		8
#define FACTORY_ROW_BIT_LENGTH  128

/* Action Names -- match actions function */
/* These codes are passed to the main entry function "dp_top" to indicate which action to be performed */
#define DP_NO_ACTION_FOUND                      0
#define DP_DEVICE_INFO_ACTION_CODE              1
#define DP_READ_IDCODE_ACTION_CODE              2
#define DP_ERASE_ACTION_CODE                    3
#define DP_ERASE_ALL_ACTION_CODE                4
#define DP_PROGRAM_ACTION_CODE                  5
#define DP_VERIFY_ACTION_CODE                   6
/* Array only actions */
#define DP_ENC_DATA_AUTHENTICATION_ACTION_CODE  7
#define DP_ERASE_ARRAY_ACTION_CODE              8
#define DP_PROGRAM_ARRAY_ACTION_CODE            9
#define DP_VERIFY_ARRAY_ACTION_CODE             10
/* FROM only actions */
#define DP_ERASE_FROM_ACTION_CODE               11
#define DP_PROGRAM_FROM_ACTION_CODE             12
#define DP_VERIFY_FROM_ACTION_CODE              13
/* Security only actions */
#define DP_ERASE_SECURITY_ACTION_CODE           14
#define DP_PROGRAM_SECURITY_ACTION_CODE         15
/* NVM only actions */
#define DP_PROGRAM_NVM_ACTION_CODE				16
#define DP_VERIFY_NVM_ACTION_CODE				17
#define DP_VERIFY_DEVICE_INFO_ACTION_CODE       18

/****************************************************************************/
/* External common global variables                                         */
/****************************************************************************/
extern DPUCHAR global_uchar;				/* Global tmp should be used once and released		*/
extern DPULONG global_ulong;
extern DPUINT global_uint;
extern DPUCHAR global_buf1[global_buf_SIZE];	/* General purpose global_buf1fer					*/
extern DPUCHAR global_buf2[global_buf_SIZE];
extern DPUCHAR opcode;
extern DPULONG DataIndex;
extern DPUCHAR device_SD;						/* Device specific number of SD tiles				*/
extern DPUINT device_rows;						/* Device specific number of rows					*/
extern DPUCHAR device_family;
extern DPUINT support_status;
extern DPUCHAR device_se_wait_cycle;
extern DPULONG device_ID;
extern DPUCHAR device_rev;
extern DPUCHAR Action_code;
extern DPULONG device_security_flags;
extern DPUINT device_bsr_bit_length;
extern DPUCHAR error_code;
extern DPUCHAR AES_mode_value;

/*
main entry function : user should call this function from their main function
*/

DPUCHAR dp_top(void);
void dp_check_action(void);
void dp_perform_action (void);
/* Action Function Definitions */
void dp_erase_action(void);
void dp_erase_all_action(void);
void dp_program_action(void);
void dp_verify_action(void);

void dp_check_device_ID(void);
void dp_initialize(void);
void dp_exit(void);
void dp_check_security_settings(void);

void dp_erase(void);
void dp_exe_erase(void);
void dp_poll_erase(void);
void dp_poll_device(void);
void dp_read_urow(void);
void dp_program_urow(void);
void dp_init_aes(void);
void dp_set_aes_mode(void);
void dp_vnr(void);
void dp_load_bsr(void);
void dp_read_factory_row(void);
void dp_smart_erase_check(void);

#ifdef ENABLE_DEBUG
void dp_device_info_action(void);
void dp_verify_device_info_action(void);
void dp_read_idcode_action(void);
void dp_read_silsig(void);
void dp_output_security(void);
void dp_display_urow(void);
#endif
#endif /* INC_DPALG_H */


