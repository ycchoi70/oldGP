/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpjtag.c                                                */
/*                                                                          */
/*  Description:    Contains JTAG interface functions                       */
/*                                                                          */
/****************************************************************************/

#include "dpuser.h"
#include "dpdef.h"
#include "dpjtag.h"
#include "dpcom.h"
#include "dpchain.h"

DPUCHAR current_jtag_state;
DPUCHAR * page_buffer_ptr;
DPULONG requested_bytes;
DPUCHAR global_jtag_i;
DPUCHAR idx;
DPUCHAR data_buf;
DPUCHAR bit_buf;

void dp_goto_state(DPUCHAR target_state)
{
    DPUCHAR count=0;
    DPUCHAR tms_bits=0;
    
    switch (target_state) {
        
        case JTAG_RESET:
        dp_jtag_init();
        count =5;
        tms_bits = 0x1f;
        break;
        
        case JTAG_SHDR:
        if ((current_jtag_state == JTAG_RESET) || (current_jtag_state == JTAG_IDLE))
        {
            count = 4;
            tms_bits = 0x2;
        }
        else if ((current_jtag_state == JTAG_IRPAUSE) || (current_jtag_state == JTAG_DRPAUSE))
        {
            count = 5;
            tms_bits = 0x7;
        }
        break;
        
        case JTAG_SHIR:
        if ((current_jtag_state == JTAG_RESET) || (current_jtag_state == JTAG_IDLE))
        {
            count = 5;
            tms_bits = 0x6;
        }
        else if ((current_jtag_state == JTAG_DRPAUSE) || (current_jtag_state == JTAG_IRPAUSE))
        {
            count = 6;
            tms_bits = 0xf;
        }
        else if (current_jtag_state == JTAG_DRUPDATE)
        {
            count = 4;
            tms_bits = 0x3;
        }
        break;
        
        case JTAG_IDLE:
        if (current_jtag_state == JTAG_RESET)
        {
            count = 1;
            tms_bits = 0x0;
        }
        else if ((current_jtag_state == JTAG_EXIR) || (current_jtag_state == JTAG_EXDR))
        {
            count = 2;
            tms_bits = 0x1;
        }
        else if ((current_jtag_state == JTAG_DRPAUSE) || (current_jtag_state == JTAG_IRPAUSE))
        {
            count = 3;
            tms_bits = 0x3;
        }
        else if (current_jtag_state == JTAG_DRCAPTURE)
        {
            count = 3;
            tms_bits = 0x3;
        }
        break;
        
        case JTAG_IRPAUSE:
        if (current_jtag_state == JTAG_EXIR)
        {
            count = 1;
            tms_bits = 0x0;
        }
        break;
        
        case JTAG_DRPAUSE:
        if (current_jtag_state == JTAG_EXDR)
        {
            count = 1;
            tms_bits = 0x0;
        }
        else if (current_jtag_state == JTAG_IDLE)
        {
            count = 4;
            tms_bits = 0x5;
        }
        break;
        
        case JTAG_DRUPDATE:
        if ((current_jtag_state == JTAG_EXDR) || (current_jtag_state == JTAG_EXIR))
        {
            count = 1;
            tms_bits = 0x1;
        }
        break;
        
        case JTAG_DRCAPTURE:
        if (current_jtag_state == JTAG_IRPAUSE)
        {
            count = 5;
            tms_bits = 0xe;
        }
        break;
        
        default:
        error_code = DPE_JTAG_STATE_NOT_HANDLED;
        break;
    }
    
    for (global_jtag_i=0;global_jtag_i<count;global_jtag_i++)
    {
        dp_jtag_tms(tms_bits&0x1);
        tms_bits >>= 1;
    }
    current_jtag_state = target_state;
    
}


void dp_wait_cycles(DPUCHAR cycles)
{
    for (global_jtag_i=0;global_jtag_i<cycles;global_jtag_i++) 
        dp_jtag_tms(0);
    return;
}

#ifndef CHAIN_SUPPORT
void dp_shift_in(DPULONG start_bit, DPUINT num_bits, DPUCHAR* tdi_data, DPUCHAR terminate)
{
    idx = (DPUCHAR) start_bit >> 3;
    bit_buf = 1 << (DPUCHAR)(start_bit & 0x7);
    if (tdi_data == (DPUCHAR*)NULL)
        data_buf = 0;
    else data_buf = tdi_data[idx] >> ((DPUCHAR)(start_bit & 0x7));
    if (terminate == 0)
        num_bits++;
    while (--num_bits)
    {
        dp_jtag_tms_tdi(0, data_buf&0x1);
        data_buf >>= 1;
        bit_buf <<= 1;
        if ((bit_buf & 0xff) == 0 )
        {
            bit_buf = 1;
            idx++;
            if (tdi_data == (DPUCHAR*)NULL)
                data_buf = 0;
            else data_buf = tdi_data[idx];
        }
    }
    if (terminate)
    {
        dp_jtag_tms_tdi(1, data_buf&0x1);
        if (current_jtag_state == JTAG_SHIR)
            current_jtag_state = JTAG_EXIR;
        else if (current_jtag_state == JTAG_SHDR)
            current_jtag_state = JTAG_EXDR;
    }
    return;
}

void dp_shift_in_out(DPUINT num_bits, DPUCHAR* tdi_data, DPUCHAR* tdo_data)
{
    bit_buf = 1;
    idx = 0;
    tdo_data[idx]=0;
    
    if (tdi_data == (DPUCHAR*)NULL)
        data_buf = 0;
    else data_buf = tdi_data[idx];
    
    while (--num_bits)
    {
        if ((bit_buf & 0xff) == 0 )
        {
            bit_buf = 1;
            idx++;
            tdo_data[idx]=0;
            if (tdi_data == (DPUCHAR*)NULL)
                data_buf = 0;
            else data_buf = tdi_data[idx];
        }
        if (dp_jtag_tms_tdi_tdo(0, data_buf&0x1))
            tdo_data[idx] |= bit_buf;
        bit_buf <<= 1;
        data_buf>>=1;
    }
    if ((bit_buf & 0xff) == 0 )
    {
        bit_buf = 1;
        idx++;
        tdo_data[idx]=0;
        if (tdi_data == (DPUCHAR*)NULL)
            data_buf = 0;
        else data_buf = tdi_data[idx];
    }
    if (dp_jtag_tms_tdi_tdo(1, data_buf&0x1))
        tdo_data[idx] |= bit_buf;
    if (current_jtag_state == JTAG_SHIR)
        current_jtag_state = JTAG_EXIR;
    else if (current_jtag_state == JTAG_SHDR)
        current_jtag_state = JTAG_EXDR;
    return;
}

void dp_get_and_shift_in(DPUCHAR Variable_ID,DPUINT total_bits_to_shift, DPULONG start_bit_index)
{
    DPULONG page_start_bit_index;
    DPUINT bits_to_shift;
    DPUCHAR terminate;
    page_start_bit_index = start_bit_index & 0x7;
    requested_bytes =  (page_start_bit_index + total_bits_to_shift + 7) >> 3;
    
    terminate = 0;
    while (requested_bytes)
    {
        page_buffer_ptr = dp_get_data(Variable_ID,start_bit_index);
        
        if (return_bytes >= requested_bytes )
        {
            return_bytes = requested_bytes;
            bits_to_shift = total_bits_to_shift;
            terminate = 1;
        }
        else bits_to_shift = (DPUCHAR) (return_bytes * 8 - page_start_bit_index);
        dp_shift_in(page_start_bit_index, bits_to_shift, page_buffer_ptr,terminate);
        
        requested_bytes = requested_bytes - return_bytes;
        total_bits_to_shift = total_bits_to_shift - bits_to_shift;
        start_bit_index += bits_to_shift;
        page_start_bit_index = start_bit_index & 0x7;
    }
}

void dp_get_and_shift_in_out(DPUCHAR Variable_ID,DPUCHAR total_bits_to_shift, DPULONG start_bit_index,DPUCHAR* tdo_data)
{
    requested_bytes = (DPUCHAR) (total_bits_to_shift + 7) >> 3;
    page_buffer_ptr = dp_get_data(Variable_ID,start_bit_index);
    
    if (return_bytes >= requested_bytes )
    {
        return_bytes = requested_bytes;
    }
    else
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nError: Page buffer size is not big enough...");
        #endif
        return;
    }
    dp_shift_in_out(total_bits_to_shift, page_buffer_ptr,tdo_data);
    return;
}
#endif
