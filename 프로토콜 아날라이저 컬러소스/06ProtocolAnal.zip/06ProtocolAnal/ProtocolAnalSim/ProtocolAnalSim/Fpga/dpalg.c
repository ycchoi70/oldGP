/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpalg.c                                                 */
/*                                                                          */
/*  Description:    Contains initialization and data checking functions.    */
/*                                                                          */
/****************************************************************************/

#include "dpuser.h"
#include "dpdef.h"
#include "dputil.h"
#include "dpjtag.h"
#include "dpcom.h"
#include "dpalg.h"
#include "dpcore.h"
#include "dpfrom.h"
#include "dpnvm.h"
#include "dpsecurity.h"

/*
* General purpose Global variables needed in the program
*/
DPUCHAR global_uchar;					/* Global tmp should be used once and released		*/
DPULONG global_ulong;
DPUINT global_uint;
DPUCHAR global_buf1[global_buf_SIZE];		/* General purpose global_buf1fer					*/
DPUCHAR global_buf2[global_buf_SIZE];	    /* global_buf1fer to hold UROW data					*/

DPUCHAR Action_code;
DPUCHAR opcode;
DPUCHAR AES_mode_value;

DPULONG device_ID;
DPUCHAR device_rev;
DPUINT device_rows;					        /* Device specific number of rows					*/
DPUCHAR device_SD;					        /* Device specific number of SD tiles				*/
DPUCHAR device_family=0;
DPUINT device_bsr_bit_length;
DPUCHAR device_se_wait_cycle;

DPULONG DataIndex;

DPUINT support_status;
DPULONG device_security_flags;
DPUCHAR error_code;


/******************************************************************/
/* main entry function supports plain text array programming only */
/******************************************************************/
DPUCHAR dp_top (void)
{
    dp_init_vars();
    dp_check_image_crc();
    if (error_code == DPE_SUCCESS)
    {
        
        dp_get_support_status();
        dp_goto_state(JTAG_RESET);
        dp_perform_action();
    }
    return error_code;
}

void dp_check_action(void)
{
    if (Action_code == DP_VERIFY_DEVICE_INFO_ACTION_CODE)
    {
    }
    else if ((Action_code == DP_READ_IDCODE_ACTION_CODE) || (Action_code == DP_DEVICE_INFO_ACTION_CODE))
    {
        #ifndef ENABLE_DEBUG
        error_code = DPE_CODE_NOT_ENABLED;
        #endif
    }
    else if (Action_code == DP_ERASE_ACTION_CODE)
    {
        if (((support_status & CORE_SUPPORT_BIT) == 0) && ((support_status & FROM_SUPPORT_BIT) == 0) && ((support_status & SEC_SUPPORT_BIT) == 0))
        {
            error_code = DPE_ACTION_NOT_SUPPORTED;
        }
    }
    else if (Action_code == DP_ERASE_ALL_ACTION_CODE)
    {
    }
    else if (Action_code == DP_PROGRAM_ACTION_CODE)
    {
        if (support_status & CORE_SUPPORT_BIT)
        {
            #ifndef CORE_SUPPORT
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
            if (support_status & CORE_ENCRYPTION_BIT)
            {
                #ifndef CORE_ENCRYPT
                error_code = DPE_CODE_NOT_ENABLED;
                #endif
            }
            /* Checking if core plain is enabled */
            else
            {
                #ifndef CORE_PLAIN
                error_code = DPE_CODE_NOT_ENABLED;
                #endif
            }
        }
        if (support_status & FROM_SUPPORT_BIT)
        {
            #ifndef FROM_SUPPORT
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
            if (support_status & FROM_ENCRYPTION_BIT)
            {
                #ifndef FROM_ENCRYPT
                error_code = DPE_CODE_NOT_ENABLED;
                #endif
            }
            else 
            {
                #ifndef FROM_PLAIN
                error_code = DPE_CODE_NOT_ENABLED;
                #endif
            }
        }
        if ((support_status & (NVM0_ENCRYPTION_BIT | NVM1_ENCRYPTION_BIT | NVM2_ENCRYPTION_BIT | NVM3_ENCRYPTION_BIT)))
        {
            #ifndef NVM_ENCRYPT
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
            if (((support_status & NVM0_ENCRYPTION_BIT) == 0) || ((support_status & NVM1_ENCRYPTION_BIT) == 0) || ((support_status & NVM2_ENCRYPTION_BIT) == 0) || ((support_status & NVM3_ENCRYPTION_BIT) == 0))
            {
                #ifndef NVM_PLAIN
                error_code = DPE_CODE_NOT_ENABLED;
                #endif
            }
            else if (Action_code == DP_VERIFY_NVM_ACTION_CODE)
            {
                error_code = DPE_ACTION_NOT_SUPPORTED;
            }
        }
    }
    else if (Action_code == DP_VERIFY_ACTION_CODE)
    {
        if (((support_status & CORE_SUPPORT_BIT) == 0) && (((support_status & FROM_SUPPORT_BIT) == 0) || (support_status & FROM_ENCRYPTION_BIT)) && ((support_status & NVM_VERIFY_SUPPORT_BIT) == 0))
            error_code = DPE_ACTION_NOT_SUPPORTED;
        if (support_status & CORE_SUPPORT_BIT)
        {
            #ifndef CORE_SUPPORT
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
            if (support_status & CORE_ENCRYPTION_BIT)
            {
                #ifndef CORE_ENCRYPT
                error_code = DPE_CODE_NOT_ENABLED;
                #endif
            }
            /* Checking if core plain is enabled */
            else
            {
                #ifndef CORE_PLAIN
                error_code = DPE_CODE_NOT_ENABLED;
                #endif
            }
        }
        if (support_status & FROM_SUPPORT_BIT)
        {
            #ifndef FROM_SUPPORT
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
            if ((support_status & FROM_ENCRYPTION_BIT) == 0)
            {
                #ifndef FROM_PLAIN
                error_code = DPE_CODE_NOT_ENABLED;
                #endif
            }
        }
        if (support_status & NVM_VERIFY_SUPPORT_BIT)
        {
            #ifndef NVM_SUPPORT
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
            #ifndef NVM_PLAIN
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
        }
    }
    /* Core Code and Data support check */
    else if ((Action_code == DP_ERASE_ARRAY_ACTION_CODE) || (Action_code == DP_PROGRAM_ARRAY_ACTION_CODE) || (Action_code == DP_VERIFY_ARRAY_ACTION_CODE))
    {
        if ((support_status & CORE_SUPPORT_BIT) == 0)
            error_code = DPE_ACTION_NOT_SUPPORTED;
        /* Checking if the core support is enabled */
        #ifndef CORE_SUPPORT
        error_code = DPE_CODE_NOT_ENABLED;
        #endif
        if (support_status & CORE_ENCRYPTION_BIT)
        {
            #ifndef CORE_ENCRYPT
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
        }
        /* Checking if core plain is enabled */
        else
        {
            #ifndef CORE_PLAIN
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
        }
    }
    else if (Action_code == DP_ENC_DATA_AUTHENTICATION_ACTION_CODE)
    {
        if ( (support_status & CORE_ENCRYPTION_BIT) == 0)
            error_code = DPE_ACTION_NOT_SUPPORTED;
        #ifndef CORE_SUPPORT
        error_code = DPE_CODE_NOT_ENABLED;
        #endif
        #ifndef CORE_ENCRYPT
        error_code = DPE_CODE_NOT_ENABLED;
        #endif
    }
    /* FROM Code and Data support check */
    else if ((Action_code == DP_ERASE_FROM_ACTION_CODE) || (Action_code == DP_PROGRAM_FROM_ACTION_CODE) || (Action_code == DP_VERIFY_FROM_ACTION_CODE))
    {
        if ((support_status & FROM_SUPPORT_BIT) == 0)
            error_code = DPE_ACTION_NOT_SUPPORTED;
        #ifndef FROM_SUPPORT
        error_code = DPE_CODE_NOT_ENABLED;
        #endif
        if (support_status & FROM_ENCRYPTION_BIT)
        {
            #ifndef FROM_ENCRYPT
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
            if (Action_code == DP_VERIFY_FROM_ACTION_CODE)
            {
                error_code = DPE_ACTION_NOT_SUPPORTED;
            }
        }
        /* Checking if FROM plain is enabled */
        else
        {
            #ifndef FROM_PLAIN
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
        }
    }
    else if ((Action_code == DP_PROGRAM_NVM_ACTION_CODE) || (Action_code == DP_VERIFY_NVM_ACTION_CODE))
    {
        if ((support_status & (NVM0_SUPPORT_BIT | NVM1_SUPPORT_BIT | NVM2_SUPPORT_BIT | NVM3_SUPPORT_BIT)) == 0)
            error_code = DPE_ACTION_NOT_SUPPORTED;
        #ifndef NVM_SUPPORT
        error_code = DPE_CODE_NOT_ENABLED;
        #endif
        if ((support_status & (NVM0_ENCRYPTION_BIT | NVM1_ENCRYPTION_BIT | NVM2_ENCRYPTION_BIT | NVM3_ENCRYPTION_BIT)))
        {
            #ifndef NVM_ENCRYPT
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
        }
        else if (((support_status & NVM0_ENCRYPTION_BIT) == 0) || ((support_status & NVM1_ENCRYPTION_BIT) == 0) || ((support_status & NVM2_ENCRYPTION_BIT) == 0) || ((support_status & NVM3_ENCRYPTION_BIT) == 0))
        {
            #ifndef NVM_PLAIN
            error_code = DPE_CODE_NOT_ENABLED;
            #endif
        }
        else if (Action_code == DP_VERIFY_NVM_ACTION_CODE)
        {
            error_code = DPE_ACTION_NOT_SUPPORTED;
        }
    }
    else if ((Action_code == DP_ERASE_SECURITY_ACTION_CODE) || (Action_code == DP_PROGRAM_SECURITY_ACTION_CODE))
    {
        if ((support_status & SEC_SUPPORT_BIT) == 0)
            error_code = DPE_ACTION_NOT_SUPPORTED;
        #ifndef SECURITY_SUPPORT
        error_code = DPE_CODE_NOT_ENABLED;
        #endif
    }
    else 
    {
        error_code = DPE_ACTION_NOT_FOUND;
    }
    
    
    #ifdef ENABLE_DEBUG
    if (error_code == DPE_ACTION_NOT_FOUND)
        dp_display_text("\r\nUser Error: Action not found...");
    else if (error_code == DPE_ACTION_NOT_SUPPORTED)
        dp_display_text("\r\nUser Error: Data file does not contain the data needed to support requested action.  Check original STAPL file configuration.");
    else if (error_code == DPE_CODE_NOT_ENABLED)
        dp_display_text("\r\nUser Error: Compiled code does not support the requesed action.  Re-compile the code with the arropriate compile option enabled...");
    #endif
    
    return;
    
}
void dp_perform_action (void)
{
    dp_check_device_ID();
    if (error_code == DPE_SUCCESS)
    {
        dp_initialize();
        if (error_code == DPE_SUCCESS)
        {
            dp_read_device_security();
            if (error_code == DPE_SUCCESS)
            {
                dp_check_dual_key();
                if (error_code == DPE_SUCCESS)
                {
                    if ((Action_code != DP_READ_IDCODE_ACTION_CODE) && (Action_code != DP_DEVICE_INFO_ACTION_CODE) && (Action_code != DP_VERIFY_DEVICE_INFO_ACTION_CODE))
                    {
                        dp_check_security_settings();
                        if (error_code == DPE_SUCCESS)
                        {
                            dp_verify_id_dmk();
                            if (error_code == DPE_SUCCESS)
                            {
                                dp_check_action();
                                if (error_code == DPE_SUCCESS)
                                {
                                    #ifdef NVM_SUPPORT
                                    if ((Action_code == DP_PROGRAM_NVM_ACTION_CODE) || (Action_code == DP_PROGRAM_ACTION_CODE))
                                    {
                                        if (support_status & NVM0_SUPPORT_BIT)
                                        {
                                            #ifdef NVM_ENCRYPT
                                            if (support_status & NVM0_ENCRYPTION_BIT)
                                            {
                                            }
                                            #endif
                                            #ifdef NVM_PLAIN
                                            if ((support_status & NVM0_ENCRYPTION_BIT) == 0)
                                            {
                                                dp_verify_calibration();
                                            }
                                            #endif
                                        }
                                    }
                                    #endif
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if (error_code == DPE_SUCCESS)
        {
            switch (Action_code) 
            {
                #ifdef ENABLE_DEBUG
                case DP_READ_IDCODE_ACTION_CODE: 
                {
                    dp_read_idcode_action();
                    break;
                }
                case DP_DEVICE_INFO_ACTION_CODE:
                {
                    dp_device_info_action();
                    break;
                }
                case DP_VERIFY_DEVICE_INFO_ACTION_CODE:
                {
                    dp_verify_device_info_action();
                    break;
                }
                #endif
                case DP_ERASE_ACTION_CODE: 
                {
                    dp_erase_action();
                    break;         
                }
                case DP_ERASE_ALL_ACTION_CODE:
                {
                    dp_erase_all_action();
                    break;
                }
                case DP_PROGRAM_ACTION_CODE: 
                {
                    dp_program_action();
                    break;
                }
                case DP_VERIFY_ACTION_CODE: 
                {
                    if ((support_status & CORE_SUPPORT_BIT) || ((support_status & FROM_SUPPORT_BIT) && ((support_status & FROM_ENCRYPTION_BIT) == 0)) || (support_status & NVM_VERIFY_SUPPORT_BIT))
                        dp_verify_action();
                    else 
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nAction not found...");
                        #endif
                        error_code = DPE_ACTION_NOT_FOUND;
                    }
                    break;
                }
                #ifdef CORE_SUPPORT
                case DP_ERASE_ARRAY_ACTION_CODE: 
                {
                    if (support_status & CORE_SUPPORT_BIT)
                    {
                        dp_erase_array_action();
                    }
                    else
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nAction not found...");
                        #endif
                        error_code = DPE_ACTION_NOT_FOUND;
                    }
                    break;         
                }
                case DP_PROGRAM_ARRAY_ACTION_CODE: 
                {
                    if (support_status & CORE_SUPPORT_BIT)
                    {
                        dp_program_array_action();
                    }
                    else
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nAction not found...");
                        #endif
                        error_code = DPE_ACTION_NOT_FOUND;
                    }
                    break;         
                }
                case DP_VERIFY_ARRAY_ACTION_CODE: 
                {
                    if (support_status & CORE_SUPPORT_BIT)
                    {
                        dp_verify_array_action();
                    }
                    else
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nAction not found...");
                        #endif
                        error_code = DPE_ACTION_NOT_FOUND;
                    }
                    break;         
                }
                #ifdef CORE_ENCRYPT
                case DP_ENC_DATA_AUTHENTICATION_ACTION_CODE: 
                {
                    if (support_status & CORE_ENCRYPTION_BIT)
                    {
                        dp_enc_data_authentication_action();
                    }
                    else
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nAction not found...");
                        #endif
                        error_code = DPE_ACTION_NOT_FOUND;
                    }
                    break;         
                }
                #endif
                #endif
                #ifdef FROM_SUPPORT
                case DP_ERASE_FROM_ACTION_CODE: 
                {
                    if (support_status & FROM_SUPPORT_BIT)
                    {
                        dp_erase_from_action();
                    }
                    else
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nAction not found...");
                        #endif
                        error_code = DPE_ACTION_NOT_FOUND;
                    }
                    break;         
                }
                case DP_PROGRAM_FROM_ACTION_CODE: 
                {
                    if (support_status & FROM_SUPPORT_BIT)
                    {
                        dp_program_from_action();
                    }
                    else
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nAction not found...");
                        #endif
                        error_code = DPE_ACTION_NOT_FOUND;
                    }
                    break;         
                }
                case DP_VERIFY_FROM_ACTION_CODE: 
                {
                    if ((support_status & FROM_SUPPORT_BIT) && ((support_status & FROM_ENCRYPTION_BIT) == 0))
                    {
                        dp_verify_from_action();
                    }
                    else
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nAction not found...");
                        #endif
                        error_code = DPE_ACTION_NOT_FOUND;
                    }
                    break;         
                }
                #endif
                #ifdef NVM_SUPPORT
                case DP_PROGRAM_NVM_ACTION_CODE: 
                {
                    if (support_status & (NVM0_SUPPORT_BIT | NVM1_SUPPORT_BIT | NVM2_SUPPORT_BIT | NVM3_SUPPORT_BIT))
                    {
                        dp_program_nvm_action();
                    }
                    else
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nAction not found...");
                        #endif
                        error_code = DPE_ACTION_NOT_FOUND;
                    }
                    break;         
                }
                #ifdef NVM_PLAIN
                case DP_VERIFY_NVM_ACTION_CODE: 
                {
                    if (support_status & NVM_VERIFY_SUPPORT_BIT)
                        dp_verify_nvm_action();
                    else 
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nAction not found...");
                        #endif
                        error_code = DPE_ACTION_NOT_FOUND;
                    }
                    break;
                }
                #endif
                #endif
                #ifdef SECURITY_SUPPORT
                case DP_ERASE_SECURITY_ACTION_CODE: 
                {
                    if (support_status & SEC_SUPPORT_BIT)
                        dp_erase_security_action();
                    else 
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nAction not found...");
                        #endif
                        error_code = DPE_ACTION_NOT_FOUND;
                    }
                    break;         
                }
                case DP_PROGRAM_SECURITY_ACTION_CODE: 
                {
                    if (support_status & SEC_SUPPORT_BIT)
                        dp_program_security_action();
                    else 
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nAction not found...");
                        #endif
                        error_code = DPE_ACTION_NOT_FOUND;
                    }
                    break;         
                }
                #endif
                default:
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nAction not found...");
                    #endif
                    error_code = DPE_ACTION_NOT_FOUND;
                }
            }
        }
        dp_exit();
    }
    return;    
}


void dp_check_device_ID(void)
{
    opcode = IDCODE;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(IDCODE_LENGTH, (DPUCHAR*)NULL, global_buf1);
    dp_goto_state(JTAG_IDLE);
    device_ID = ((DPULONG) global_buf1 [0]) | (((DPULONG) global_buf1 [1]) <<8) | (((DPULONG) global_buf1 [2]) <<16) | (((DPULONG) global_buf1 [3]) <<24); 
    device_rev = (DPUCHAR) (device_ID >> 28);
    device_se_wait_cycle=0;
    
    
    /* DataIndex is a variable used for loading the array data but not used now.  
    * Therefore, it can be used to store the Data file ID for */
    DataIndex = dp_get_bytes(Header_ID,ID_OFFSET,4);
    
    /* Identifying target device and setting its parms */
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nActID = ");
    dp_display_value(device_ID,HEX);
    dp_display_text(" ExpID = ");
    dp_display_value(DataIndex,HEX);
    #endif
    
    if ( ((device_ID & AXXE600X_ID_MASK) == (AXXE600X_ID & AXXE600X_ID_MASK)) && ((device_ID & AXXE600X_ID_MASK) == (DataIndex & AXXE600X_ID_MASK)) )
    {
        device_SD = AXXE600X_SD;
        device_rows = AXXE600X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AXXE600X_BSR_BIT_LENGTH;
        device_se_wait_cycle = AXXE600X_SE_WAIT_CYCLE;
    }
    #ifdef ENABLE_AXXE1500_SUPPORT
    else if (((device_ID & AXXE1500X_ID_MASK) == (AXXE1500X_ID & AXXE1500X_ID_MASK)) && ((device_ID & AXXE1500X_ID_MASK) == (DataIndex & AXXE1500X_ID_MASK)))
    {
        device_SD = AXXE1500X_SD;
        device_rows = AXXE1500X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AXXE1500X_BSR_BIT_LENGTH;
        device_se_wait_cycle = AXXE1500X_SE_WAIT_CYCLE;
    }
    #endif
    else if (((device_ID & AXXE3000X_ID_MASK) == (AXXE3000X_ID & AXXE3000X_ID_MASK)) && ((device_ID & AXXE3000X_ID_MASK) == (DataIndex & AXXE3000X_ID_MASK)))
    {
        device_SD = AXXE3000X_SD;
        device_rows = AXXE3000X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AXXE3000X_BSR_BIT_LENGTH;
        device_se_wait_cycle = AXXE3000X_SE_WAIT_CYCLE;
    }
    else if (((device_ID & AXX030X_ID_MASK) == (AXX030X_ID & AXX030X_ID_MASK)) && ((device_ID & AXX030X_ID_MASK) == (DataIndex & AXX030X_ID_MASK)))
    {
        device_SD = AXX030X_SD;
        device_rows = AXX030X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AXX030X_BSR_BIT_LENGTH;
    }
    else if (((device_ID & AXX060X_ID_MASK) == (AXX060X_ID & AXX060X_ID_MASK)) && ((device_ID & AXX060X_ID_MASK) == (DataIndex & AXX060X_ID_MASK)))
    {
        device_SD = AXX060X_SD;
        device_rows = AXX060X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AXX060X_BSR_BIT_LENGTH;
    }
    else if (((device_ID & AXX125X_ID_MASK) == (AXX125X_ID & AXX125X_ID_MASK)) && ((device_ID & AXX125X_ID_MASK) == (DataIndex & AXX125X_ID_MASK)))
    {
        device_SD = AXX125X_SD;
        device_rows = AXX125X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AXX125X_BSR_BIT_LENGTH;
    }
    else if (((device_ID & AXX250X_ID_MASK) == (AXX250X_ID & AXX250X_ID_MASK)) && ((device_ID & AXX250X_ID_MASK) == (DataIndex & AXX250X_ID_MASK)))
    {
        device_SD = AXX250X_SD;
        device_rows = AXX250X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AXX250X_BSR_BIT_LENGTH;
    }
    else if (((device_ID & AXX400X_ID_MASK) == (AXX400X_ID & AXX400X_ID_MASK)) && ((device_ID & AXX400X_ID_MASK) == (DataIndex & AXX400X_ID_MASK)))
    {
        device_SD = AXX400X_SD;
        device_rows = AXX400X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AXX400X_BSR_BIT_LENGTH;
    }
    else if (((device_ID & AXX600X_ID_MASK) == (AXX600X_ID & AXX600X_ID_MASK)) && ((device_ID & AXX600X_ID_MASK) == (DataIndex & AXX600X_ID_MASK)))
    {
        device_SD = AXX600X_SD;
        device_rows = AXX600X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AXX600X_BSR_BIT_LENGTH;
    }
    else if (((device_ID & AXX1000X_ID_MASK) == (AXX1000X_ID & AXX1000X_ID_MASK)) && ((device_ID & AXX1000X_ID_MASK) == (DataIndex & AXX1000X_ID_MASK)))
    {
        device_SD = AXX1000X_SD;
        device_rows = AXX1000X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AXX1000X_BSR_BIT_LENGTH;
    }
    else if (((device_ID & AGLP030X_ID_MASK) == (AGLP030X_ID & AGLP030X_ID_MASK)) && ((device_ID & AGLP030X_ID_MASK) == (DataIndex & AGLP030X_ID_MASK)))
    {
        device_SD = AGLP030X_SD;
        device_rows = AGLP030X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AGLP030X_BSR_BIT_LENGTH;
    }
    else if (((device_ID & AGLP060X_ID_MASK) == (AGLP060X_ID & AGLP060X_ID_MASK)) && ((device_ID & AGLP060X_ID_MASK) == (DataIndex & AGLP060X_ID_MASK)))
    {
        device_SD = AGLP060X_SD;
        device_rows = AGLP060X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AGLP060X_BSR_BIT_LENGTH;
    }
    else if (((device_ID & AGLP125X_ID_MASK) == (AGLP125X_ID & AGLP125X_ID_MASK)) && ((device_ID & AGLP125X_ID_MASK) == (DataIndex & AGLP125X_ID_MASK)))
    {
        device_SD = AGLP125X_SD;
        device_rows = AGLP125X_ROWS;
        device_family |= AXX_BIT;
        device_bsr_bit_length = AGLP125X_BSR_BIT_LENGTH;
    }
    else if (((device_ID & AFS090_ID_MASK) == (AFS090_ID & AFS090_ID_MASK)) && ((device_ID & AFS090_ID_MASK) == (DataIndex & AFS090_ID_MASK)))
    {
        device_SD = AFS090_SD;
        device_rows = AFS090_ROWS;
        device_family |= AFS_BIT;
        device_bsr_bit_length = AFS090_BSR_BIT_LENGTH;
    }
    else if (((device_ID & AFS250_ID_MASK) == (AFS250_ID & AFS250_ID_MASK)) && ((device_ID & AFS250_ID_MASK) == (DataIndex & AFS250_ID_MASK)))
    {
        device_SD = AFS250_SD;
        device_rows = AFS250_ROWS;
        device_family |= AFS_BIT;
        device_bsr_bit_length = AFS250_BSR_BIT_LENGTH;
    }
    else if (((device_ID & AFS600_ID_MASK) == (AFS600_ID & AFS600_ID_MASK) ) && ((device_ID & AFS600_ID_MASK) == (DataIndex & AFS600_ID_MASK)))
    {
        device_SD = AFS600_SD;
        device_rows = AFS600_ROWS;
        device_family |= AFS_BIT;
        device_bsr_bit_length = AFS600_BSR_BIT_LENGTH;
        device_se_wait_cycle = AFS600_SE_WAIT_CYCLE;
    }
    else if (((device_ID & AFS1500_ID_MASK) == (AFS1500_ID & AFS1500_ID_MASK) ) && ((device_ID & AFS1500_ID_MASK) == (DataIndex & AFS1500_ID_MASK)))
    {
        device_SD = AFS1500_SD;
        device_rows = AFS1500_ROWS;
        device_family |= AFS_BIT;
        device_bsr_bit_length = AFS1500_BSR_BIT_LENGTH;
        device_se_wait_cycle = AFS1500_SE_WAIT_CYCLE;
    }
    else
    {
        error_code = DPE_IDCODE_ERROR;
    }
    return;
}


void dp_vnr(void)
{
    opcode = DESELECT_ALL_TILES;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(1);
    return;
}

void dp_load_bsr(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nSetting BSR Configurations...");
    #endif
    opcode = ISC_SAMPLE;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in_out(OPCODE_BIT_LENGTH, &opcode, &global_uchar);
    dp_goto_state(JTAG_IRPAUSE);
    
    #ifdef BSR_SAMPLE
    if (!(global_uchar & 0x4))
    {
        dp_get_bytes(BsrPattern_ID,0,1);
        if (return_bytes)
        {
            dp_goto_state(JTAG_SHDR);
            dp_get_and_shift_in(BsrPattern_ID, device_bsr_bit_length, 0);
            dp_goto_state(JTAG_IDLE);
        }
    }
    else 
    {
        dp_goto_state(JTAG_DRCAPTURE);
        dp_goto_state(JTAG_IDLE);
    }
    #else
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nLoading BSR...");
    #endif
    dp_get_bytes(BsrPattern_ID,0,1);
    if (return_bytes)
    {
        dp_goto_state(JTAG_SHDR);
        dp_get_and_shift_in(BsrPattern_ID, device_bsr_bit_length, 0);
        dp_goto_state(JTAG_IDLE);
    }
    #endif
    
    return;
}

void dp_initialize(void)
{
    /* Execute ISC_ENABLE */
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nInitializing Target Device...");
    #endif
    dp_load_bsr();
    dp_vnr();
    
    opcode = ISC_ENABLE;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, 18, (DPUCHAR*)(DPUCHAR*)NULL, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(1000);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(18, (DPUCHAR*)NULL, global_buf1);
    dp_goto_state(JTAG_DRPAUSE);
    
    if ((global_buf1[2] & 0x3) != 0x3)
    {
        error_code = DPE_INIT_FAILURE;
    }
    else
    {
        opcode = ISC_NOOP;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IRPAUSE);
        dp_goto_state(JTAG_SHDR);
        dp_shift_in_out(5, (DPUCHAR*)NULL, &global_uchar);
        dp_goto_state(JTAG_DRPAUSE);
        
        if ((global_uchar & 0x4) == 0x4)
        {
            error_code = DPE_INIT_FAILURE;
        }
    }
    if (error_code == DPE_SUCCESS)
    {
        if ((Action_code != DP_READ_IDCODE_ACTION_CODE) && (Action_code != DP_DEVICE_INFO_ACTION_CODE) && (Action_code != DP_VERIFY_DEVICE_INFO_ACTION_CODE))
        {
            if (support_status & (CORE_ENCRYPTION_BIT | FROM_ENCRYPTION_BIT | NVM0_ENCRYPTION_BIT | NVM1_ENCRYPTION_BIT | NVM2_ENCRYPTION_BIT | NVM3_ENCRYPTION_BIT))
            {
                global_uchar = 0;
                for (global_uint = 0;global_uint < 16;global_uint++)
                {
                    global_uchar |= (DPUCHAR) dp_get_bytes(KDATA_ID,(DPULONG)global_uint,1);
                }
                
                if (return_bytes && (global_uchar != 0))
                {
                    dp_verify_enc_key();
                }
            }
        }
        if (error_code == DPE_SUCCESS)
        {                 
            dp_get_bytes(UKEY_ID,0,1);
            if (return_bytes)
                dp_match_security();
            #ifdef CORE_SUPPORT
            dp_smart_erase_check();
            #endif
        }
    }
    return;
}

void dp_exit(void)
{
    opcode = ISC_DISABLE;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    dp_delay(200);
    
    opcode = BYPASS;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in_out(OPCODE_BIT_LENGTH, &opcode, &global_uchar);
    dp_goto_state(JTAG_IDLE);
    
    if (!(global_uchar & 0x4))
    {
        opcode = HIGHZ;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IDLE);
        dp_wait_cycles(1);
    }
    dp_delay(200);
    dp_goto_state(JTAG_RESET);
    
    return;
}




void dp_erase_action(void)
{
    #ifdef SECURITY_SUPPORT
    if (support_status & SEC_SUPPORT_BIT)
        device_security_flags |= SET_ERASE_SEC;
    #endif
    device_security_flags |= IS_ERASE_ONLY;
    dp_erase();
    return;
}

void dp_program_action(void)
{
    #ifdef CORE_SUPPORT
    #ifdef CORE_ENCRYPT
    if (support_status & CORE_SUPPORT_BIT)
    {
        if (support_status & CORE_ENCRYPTION_BIT)
        {
            dp_enc_data_authentication();
            if (error_code != DPE_SUCCESS)
                return;
        }
    }
    #endif
    #endif
    dp_erase();
    if (error_code != DPE_SUCCESS)
        return;
    #ifdef CORE_SUPPORT
    /* Array Programming */
    if (support_status & CORE_SUPPORT_BIT)
    {
        
        #ifdef CORE_ENCRYPT
        /* Encryption support */
        if (support_status & CORE_ENCRYPTION_BIT)
        {
            dp_enc_program_array();
            if (error_code == DPE_SUCCESS)
            {
                bol_eol_verify = BOL;
                dp_enc_verify_array();
                if (error_code == DPE_SUCCESS)
                {
                    dp_enc_program_rlock();
                }
            }
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
        #ifdef CORE_PLAIN
        /* Plain text support */
        if ((support_status & CORE_ENCRYPTION_BIT) == 0)
        {
            dp_program_array();
            if (error_code == DPE_SUCCESS)
            {
                bol_eol_verify = BOL;
                dp_verify_array();
                if (error_code == DPE_SUCCESS)
                {
                    dp_program_rlock();
                }
            }
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
    }
    #endif
    #ifdef FROM_SUPPORT
    /* From Programming */
    if (support_status & FROM_SUPPORT_BIT)
    {
        #ifdef FROM_ENCRYPT
        /* Encryption support */
        if (support_status & FROM_ENCRYPTION_BIT)
        {
            dp_enc_program_from();
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
        /* Plain text support */
        #ifdef FROM_PLAIN
        if ((support_status & FROM_ENCRYPTION_BIT) == 0)
        {
            dp_program_from();
            if (error_code == DPE_SUCCESS)
            {
                dp_verify_from();
            }
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
    }
    #endif
    dp_program_silsig();
    if (error_code != DPE_SUCCESS)
        return;
    #ifdef NVM_SUPPORT
    if (support_status & NVM0_SUPPORT_BIT)
    {
        #ifdef NVM_ENCRYPT
        /* Encryption support */
        if (support_status & NVM0_ENCRYPTION_BIT)
        {
            dp_enc_program_nvm_block(0);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
        #ifdef NVM_PLAIN
        /* Plain text support */
        if ((support_status & NVM0_ENCRYPTION_BIT) == 0)
        {
            dp_program_nvm_block(0);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
    }
    if (support_status & NVM1_SUPPORT_BIT)
    {
        #ifdef NVM_ENCRYPT
        /* Encryption support */
        if (support_status & NVM1_ENCRYPTION_BIT)
        {
            dp_enc_program_nvm_block(1);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
        #ifdef NVM_PLAIN
        /* Plain text support */
        if ((support_status & NVM1_ENCRYPTION_BIT) == 0)
        {
            dp_program_nvm_block(1);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
    }
    if (support_status & NVM2_SUPPORT_BIT)
    {
        #ifdef NVM_ENCRYPT
        /* Encryption support */
        if (support_status & NVM2_ENCRYPTION_BIT)
        {
            dp_enc_program_nvm_block(2);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
        #ifdef NVM_PLAIN
        /* Plain text support */
        if ((support_status & NVM2_ENCRYPTION_BIT) == 0)
        {
            dp_program_nvm_block(2);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
    }
    if (support_status & NVM3_SUPPORT_BIT)
    {
        #ifdef NVM_ENCRYPT
        /* Encryption support */
        if (support_status & NVM3_ENCRYPTION_BIT)
        {
            dp_enc_program_nvm_block(3);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
        #ifdef NVM_PLAIN
        /* Plain text support */
        if ((support_status & NVM3_ENCRYPTION_BIT) == 0)
        {
            dp_program_nvm_block(3);
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
    }
    #endif
    #ifdef SECURITY_SUPPORT
    if (support_status & SEC_SUPPORT_BIT)
    {
        dp_program_security();
        if (error_code != DPE_SUCCESS)
            return;
    }
    #endif    
    return;
}

void dp_verify_action(void)
{
    #ifdef CORE_SUPPORT    
    /* Array verification */
    
    if (support_status & CORE_SUPPORT_BIT)
    {
        #ifdef CORE_ENCRYPT
        /* Encryption support */
        if (support_status & CORE_ENCRYPTION_BIT)
        {
            
            bol_eol_verify = EOL;
            dp_enc_verify_array();
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
        #ifdef CORE_PLAIN
        /* Plain text support */
        if ((support_status & CORE_ENCRYPTION_BIT) == 0 )
        {
            bol_eol_verify = EOL;
            dp_verify_array();
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
    }
    #endif
    #ifdef FROM_SUPPORT
    /* From verification */
    if (support_status & FROM_SUPPORT_BIT)
    {
        /* Plain text support */
        #ifdef FROM_PLAIN
        if ((support_status & FROM_ENCRYPTION_BIT) == 0)
        {
            dp_verify_from();
            if (error_code != DPE_SUCCESS)
                return;
        }
        #endif
    }
    #endif
    #ifdef NVM_SUPPORT
    #ifdef NVM_PLAIN
    if (support_status & NVM0_SUPPORT_BIT)
    {
        /* Plain support */
        if ((support_status & NVM0_ENCRYPTION_BIT)  == 0)
        {
            dp_verify_nvm_block(0);
            if (error_code != DPE_SUCCESS)
                return;
        }
    }
    if (support_status & NVM1_SUPPORT_BIT)
    {
        /* Plain support */
        if ((support_status & NVM1_ENCRYPTION_BIT)  == 0)
        {
            dp_verify_nvm_block(1);
            if (error_code != DPE_SUCCESS)
                return;
        }
    }
    if (support_status & NVM2_SUPPORT_BIT)
    {
        /* Plain support */
        if ((support_status & NVM2_ENCRYPTION_BIT)  == 0)
        {
            dp_verify_nvm_block(2);
            if (error_code != DPE_SUCCESS)
                return;
        }
    }
    if (support_status & NVM3_SUPPORT_BIT)
    {
        /* Plain support */
        if ((support_status & NVM3_ENCRYPTION_BIT)  == 0)
        {
            dp_verify_nvm_block(3);
            if (error_code != DPE_SUCCESS)
                return;
        }
    }
    #endif
    #endif
    return;
}

void dp_erase_all_action(void)
{
    #if defined (ENABLE_DEBUG) 
    dp_display_text("\r\nErase FPGA Array, FlashROM and Security Settings ...");
    #endif
    global_buf1[0] = 0x0f;
    global_buf1[1] = 0xc0;
    global_buf1[2] = 0x7f;
    
    device_security_flags |= IS_ERASE_ONLY;
    dp_exe_erase();
    return;
}

void dp_verify_device_info_action(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nVerifying device info...");
    #endif
    
    /* Checking security bit settings against what is in the Data file */
    if ((device_family & AFS_BIT) == AFS_BIT)
    {
        global_ulong = dp_get_bytes(ULOCK_ID,0,3);
    }
    else 
    {
        global_ulong = dp_get_bytes(ULOCK_ID,0,2);
        global_ulong <<= 12;
    }
    global_ulong |= ULFLR;
    
    if ((device_security_flags & 0x003FFFFF) != (global_ulong & 0x003FFFFF))
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nUser LOCK Setting Error...");
        #endif
        error_code = DPE_USER_LOCK_SETTING_ERROR;
        return;
    }
    
    
    dp_read_urow();
    
    /* Checksum verification -- Bit 112 - 127 */
    
    global_uint = global_buf2[14] | (global_buf2[15] << 8);
    global_ulong = dp_get_bytes(CHECKSUM_ID, 0, 2);
    
    if ((global_ulong & 0xFFFF) != global_uint)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nUROW Setting Error...");
        #endif
        error_code = DPE_UROW_SETTING_ERROR;
        return;
    }
    
    /* Design Name verification - Bits 32 to 101*/
    for (global_uint=4;global_uint<13;global_uint++)
    {
        
        global_uchar = (DPUCHAR) dp_get_bytes(ACT_UROW_DESIGN_NAME_ID,global_uint - 4,1);
        if (global_uint == 12)
            global_buf2[global_uint] &= 0x3F;
        
        if (global_uchar != global_buf2[global_uint])
        {
            #ifdef ENABLE_DEBUG
            dp_display_text("\r\nUROW Setting Error...");
            #endif
            error_code = DPE_UROW_SETTING_ERROR;
            return;
        }
        
    }
    
    
    
    return;
}



void dp_erase(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nErase...");
    #endif
    dp_flush_global_buf1();
    global_buf1[0] = UROW_ERASE_BITS_BYTE0;
    global_buf1[1] = UROW_ERASE_BITS_BYTE1;
    global_buf1[2] = UROW_ERASE_BITS_BYTE2;
    #ifdef CORE_SUPPORT
    if (support_status & CORE_SUPPORT_BIT)
    {
        global_buf1[0] |= CORE_ERASE_BITS_BYTE0;
        global_buf1[1] |= CORE_ERASE_BITS_BYTE1;
        global_buf1[2] |= CORE_ERASE_BITS_BYTE2;
    }
    #endif
    /* This is for FROM erase.  Need to get which bits are set to erase from the data file. */
    #ifdef FROM_SUPPORT
    if (support_status & FROM_SUPPORT_BIT)
    {
        
        global_uchar = (DPUCHAR) dp_get_bytes(FRomAddressMask_ID,0,1);
        if (global_uchar & 0x1)
            global_buf1[1]|=0x80;
        global_buf1[2]|=(global_uchar >> 1);
        
    }
    #endif
    #ifdef SECURITY_SUPPORT
    /* This is for security erase */
    if (support_status & SEC_SUPPORT_BIT)
    {
        global_buf1[0]|=0xe;
    }
    #endif
    dp_exe_erase();
    return;
}

void dp_exe_erase(void)
{
    if ( global_buf1[14 >> 3] & (1 << (14 & 7)) )
    {
        dp_read_urow();
    }
    
    opcode = ISC_ERASE;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, 23, global_buf1, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_poll_erase();
    if (error_code != DPE_SUCCESS)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nFailed Erase Operation");
        #endif
        error_code = DPE_ERASE_ERROR;
        return;
    }
    #ifdef CORE_SUPPORT
    if ((device_family & SMART_ERASE_BIT) && (global_buf1[0]&0x1))
    {
        dp_smart_erase();
        if (error_code != DPE_SUCCESS)
        {
            #ifdef ENABLE_DEBUG
            dp_display_text("\r\nFailed Smart Erase Operation");
            #endif
            error_code = DPE_ERASE_ERROR;
            return;
        }
    }
    #endif
    
    if ( global_buf1[14 >> 3] & (1 << (14 & 7)) )
    {
        dp_program_urow();
        if (error_code != DPE_SUCCESS)
        {
            #ifdef ENABLE_DEBUG
            dp_display_text("\r\nFailed UROW programming");
            #endif
            return;
        }
    }
    return;
}

void dp_poll_erase(void)
{
    /* Check for erase status */
    opcode = ISC_NOOP;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    for ( global_ulong = 0; global_ulong <= MAX_ERASE_POLL; global_ulong++ )
    {
        dp_delay(1000);
        /* check for ROWBUSY and COLBUSY */
        dp_goto_state(JTAG_SHDR);
        dp_shift_in_out(5, (DPUCHAR*)NULL, &global_uchar);
        dp_goto_state(JTAG_IDLE);
        
        if ((global_uchar & 0x3) == 0)
        {
            return;
        }
    }
    error_code = DPE_ERASE_ERROR;
    return;
}

void dp_poll_device(void)
{
    /* Check for program status */
    opcode = ISC_NOOP;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    for ( global_ulong = 0; global_ulong <= MAX_PROGRAM_POLL; global_ulong++ )
    {
        dp_delay(100);
        /* check for ROWBUSY, COLBUSY and and MAC fail */
        dp_goto_state(JTAG_SHDR);
        dp_shift_in_out(5, (DPUCHAR*)NULL, &global_uchar);
        dp_goto_state(JTAG_IDLE);
        
        if ((global_uchar & 0xb) == 0)
        {
            return;
        }
    }
    error_code = DPE_POLL_ERROR;
    return;
}



/********************************************************************************************************************/
/* Debug enable functions only                                                                                      */
/********************************************************************************************************************/
#ifdef ENABLE_DEBUG
void dp_read_idcode_action(void)
{
    opcode = IDCODE;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(IDCODE_LENGTH, (DPUCHAR*)NULL, global_buf1);
    dp_goto_state(JTAG_DRPAUSE);
    global_ulong = global_buf1[0] | global_buf1[1] << 8 | global_buf1[2] << 16 | global_buf1[3] << 24;
    dp_display_text("\r\nIDCODE: ");
    dp_display_value(global_ulong,HEX);
    
    
    return;
}

void dp_device_info_action(void)
{
    dp_read_silsig();
    dp_read_urow();
    dp_display_urow();
    if (!((device_security_flags & ULUFJ) && ((support_status & SEC_SUPPORT_BIT)==0)))
        dp_read_from();
    global_uchar = 0;
    dp_read_factory_row();
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nFSN: ");
    dp_display_array(global_buf1,16,HEX);
    #endif	
    
    
    
    dp_output_security();
    
    return;
}

void dp_read_silsig(void)
{
    opcode = USERCODE;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(SILSIG_BIT_LENGTH, (DPUCHAR*)NULL, global_buf1);
    dp_goto_state(JTAG_DRPAUSE);
    dp_display_text("\r\nSILSIG: ");
    dp_display_array(global_buf1,SILSIG_BYTE_LENGTH,HEX);
    
}

void dp_display_urow(void)
{
    dp_display_text("\r\nUser information: ");
    dp_display_text("\r\nCYCLE COUNT: ");
    dp_display_value(cycle_count,DEC);
    dp_display_text("\r\nCHECKSUM = ");
    dp_display_array(&global_buf2[14],2,HEX);
    dp_display_text("\r\nDesign Name = ");
    dp_display_array(&global_buf2[4],9,HEX);
    dp_display_text("\r\n==================================================");
    return;
}

void dp_output_security(void)
{
    dp_display_text("\r\nSecurity Setting : ");
    
    if (device_security_flags & ULUFP)
        dp_display_text("\r\nFlashROM Write/Erase protected by pass key.");
    if (device_security_flags & ULUFJ)
        dp_display_text("\r\nFlashROM Read protected by pass key.");
    if (device_security_flags & ULAWE)
        dp_display_text("\r\nArray Write/Erase protected by pass key.");
    if (device_security_flags & ULARD)
        dp_display_text("\r\nArray Verify protected by pass key.");
    if (device_security_flags & ULUFE)
        dp_display_text("\r\nEncrypted FlashROM Programming Enabled.");
    if (device_security_flags & ULARE)
        dp_display_text("\r\nEncrypted FPGA Array Programming Enabled.");
    
    if ((device_family & AFS_BIT) == AFS_BIT)
    {        
        if (device_security_flags & ULNW0)
            dp_display_text("\r\nNVM block 0 Write protected by pass key.");
        if (device_security_flags & ULNR0)
            dp_display_text("\r\nNVM block 0 Read protected by pass key.");
        if (device_security_flags & ULNW1)
            dp_display_text("\r\nNVM block 1 Write protected by pass key.");
        if (device_security_flags & ULNR1)
            dp_display_text("\r\nNVM block 1 Read protected by pass key.");
        if (device_security_flags & ULNC0)
            dp_display_text("\r\nEncrypted NVM block 0 Programming Enabled.");
        if (device_security_flags & ULNC1)
            dp_display_text("\r\nEncrypted NVM block 1 Programming Enabled.");
    }
    
    dp_display_text("\r\n==================================================");
    return;
}
#endif
/********************************************************************************************************************/


void dp_read_urow(void)
{
    /* read UROW */
    dp_vnr();
    
    opcode = ISC_READ_UROW;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(264);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(UROW_LENGTH, (DPUCHAR*)NULL, global_buf2);
    dp_goto_state(JTAG_DRPAUSE);	
    
    cycle_count = (global_buf2[12] >> 6) | (global_buf2[13] << 2);
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nACTEL_SLOG_UROW = ");
    dp_display_array(global_buf2,16,HEX);
    #endif
    
    return;
}

void dp_program_urow(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nProgramming UROW...");
    #endif
    
    
    for (global_uchar=0;global_uchar<global_buf_SIZE;global_uchar++)
        global_buf1[global_uchar] = 0xff;
    
    
    for (global_uchar=0;global_uchar<8;global_uchar++)
    {
        opcode = ISC_UFROM_ADDR_SHIFT;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IRPAUSE);
        dp_goto_state(JTAG_SHDR);
        dp_shift_in(0,3,&global_uchar,1);
        dp_goto_state(JTAG_IDLE);	
        dp_wait_cycles(1);
        
        opcode = ISC_PROGRAM_UFROM;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IRPAUSE);
        dp_goto_state(JTAG_SHDR);
        dp_shift_in(0,FROM_ROW_BIT_LENGTH,global_buf1,1);
        dp_goto_state(JTAG_IDLE);	
        dp_wait_cycles(5);
        dp_delay(10000);
    }
    if ((device_security_flags & IS_ERASE_ONLY) == 0)
    {
        #ifdef CORE_SUPPORT
        cycle_count++;
        if (cycle_count == 1023)
            cycle_count = 0;
        else if (cycle_count == 1024)
            cycle_count = 1;
        #endif
    }
    else 
    {
        for (global_uchar=0;global_uchar<16;global_uchar++)
        {
            global_buf2[global_uchar]=0xFF;
        }
    }
    
    if ((device_security_flags & PERM_LOCK_BIT) && (device_security_flags & ULAWE))
    {
        device_security_flags |= IS_RESTORE_DESIGN;
    }
    if (((device_security_flags & IS_ERASE_ONLY) == 0) || (device_security_flags & IS_RESTORE_DESIGN))
    {
        /* Constucting the UROW data */
        if ((device_security_flags & IS_RESTORE_DESIGN) == 0)
        {
            for (global_uchar=0;global_uchar<2;global_uchar++)
            {
                global_buf2[global_uchar+14] = (DPUCHAR) dp_get_bytes(CHECKSUM_ID,global_uchar,1);
            }
            for (global_uchar=0;global_uchar<9;global_uchar++)
            {
                global_buf2[global_uchar+4] = (DPUCHAR) dp_get_bytes(ACT_UROW_DESIGN_NAME_ID,global_uchar,1);
            }
        }
    }
    
    global_buf2[12] |= ((DPUCHAR) (cycle_count << 6));
    global_buf2[13] = (DPUCHAR) (cycle_count >> 2);
    global_buf2[3] |= DC_PROGAMMING_METHOD << 5;
    
    opcode = ISC_PROGRAM_UROW;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0,UROW_LENGTH,global_buf2,1);
    dp_goto_state(JTAG_IDLE);	
    dp_wait_cycles(15);
    
    dp_poll_device();
    if (error_code != DPE_SUCCESS)
    {
        error_code = DPE_PROGRAM_UROW_ERROR;
        return;
    }
    
    dp_vnr();
    
    /* readback and verify UROW */
    opcode = ISC_READ_UROW;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    
    dp_wait_cycles(3);
    dp_delay(264);
    
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(UROW_LENGTH,(DPUCHAR*)NULL,global_buf1);
    dp_goto_state(JTAG_DRPAUSE);	
    
    for ( global_uchar = 0; global_uchar < 16; global_uchar++ )
    {
        if (global_buf1[global_uchar] != global_buf2[global_uchar])
        {
            error_code = DPE_PROGRAM_UROW_ERROR;
            return;
        }
    }
    return;
}

void dp_init_aes(void)
{
    opcode = AES_INIT;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, AES_BIT_LENGTH, (DPUCHAR*)NULL,1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(120);
}

void dp_set_aes_mode(void)
{
    opcode = AES_MODE;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, AES_MODE_BIT_LENGTH, &global_uchar,1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(1);
}
/************************************************************************************************************************************/
/* --- If data is encrypted for a given block, the device must also be encrytpted for that block                                    */
/* --- If a device block is encrypted, the data must either be encrypted or a VALID key must be present                             */
/*     It is enough to check if the match result is valid if the data is not encrypted.                                             */
/************************************************************************************************************************************/
void dp_check_security_settings(void)
{
    /* Plain text vs encryption check */
    if ( (Action_code == DP_ERASE_ACTION_CODE) || (Action_code == DP_ERASE_ALL_ACTION_CODE) || (Action_code == DP_PROGRAM_ACTION_CODE) || 
    (Action_code == DP_VERIFY_ACTION_CODE) || (Action_code == DP_ERASE_ARRAY_ACTION_CODE) || (Action_code == DP_PROGRAM_ARRAY_ACTION_CODE) || 
    (Action_code == DP_VERIFY_ARRAY_ACTION_CODE) || (Action_code == DP_ENC_DATA_AUTHENTICATION_ACTION_CODE) )
    {
        if (support_status & CORE_SUPPORT_BIT)
        {
            /* Data is encrypted */
            if (support_status & CORE_ENCRYPTION_BIT)
            {
                /* Device must be encrypted */
                if ((device_security_flags & ULARE) == 0)
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nFPGA Array Encryption is enforced. Plain text programming and verification is prohibited.");
                    #endif
                    error_code = DPE_CORE_ENC_ERROR;
                    return;
                }
            }
            /* Data is plain text */
            else
            {
                /* Device must not be encrytped or a valid key must be present */
                if ((device_security_flags & ULARE) && ((device_security_flags & SEC_KEY_OK) == 0))
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nFPGA Array Encryption is not enforced.");
                    dp_display_text("\r\nCannot gaurantee valid AES key present in target device.");
                    dp_display_text("\r\nUnable to proceed with Encrypted FPGA Array operation.");
                    #endif
                    error_code = DPE_CORE_PLAIN_ERROR;
                    return;
                }
                if ((device_security_flags & ULARD) && ((device_security_flags & SEC_KEY_OK) == 0))
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nFPGA Array Verification is protected by pass key.");
                    dp_display_text("\r\nA valid pass key needs to be provided.");
                    #endif
                    error_code = DPE_CORE_PLAIN_ERROR;
                    return;
                }
                
                if ( (Action_code == DP_ERASE_ACTION_CODE) || (Action_code == DP_ERASE_ALL_ACTION_CODE) || (Action_code == DP_PROGRAM_ACTION_CODE) || 
                (Action_code == DP_ERASE_ARRAY_ACTION_CODE) || (Action_code == DP_PROGRAM_ARRAY_ACTION_CODE) || 
                (Action_code == DP_ENC_DATA_AUTHENTICATION_ACTION_CODE) )
                {
                    /* If device is keyed, the security match must pass */
                    if ((device_security_flags & ULAWE) && ((device_security_flags & SEC_KEY_OK) == 0))
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nFPGA Array Write/Erase is protected by pass key.");
                        dp_display_text("\r\nA valid pass key needs to be provided.");
                        #endif
                        error_code = DPE_CORE_PLAIN_ERROR;
                        return;
                    }
                }
            }
        }
    }
    if ( (Action_code == DP_ERASE_ACTION_CODE) || (Action_code == DP_ERASE_ALL_ACTION_CODE) || (Action_code == DP_PROGRAM_ACTION_CODE) || 
    (Action_code == DP_VERIFY_ACTION_CODE) || (Action_code == DP_ERASE_FROM_ACTION_CODE) || (Action_code == DP_PROGRAM_FROM_ACTION_CODE) || 
    (Action_code == DP_VERIFY_FROM_ACTION_CODE) )
    {
        if (support_status & FROM_SUPPORT_BIT)
        {
            /* Data is encrypted */
            if (support_status & FROM_ENCRYPTION_BIT)
            {
                /* Device must be encrypted */
                if ((device_security_flags & ULUFE) == 0)
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nFlashROM Encryption is enforced. Plain text programming and verification is prohibited.");
                    #endif
                    error_code = DPE_FROM_ENC_ERROR;
                    return;
                }
            }
            /* Data is plain text */
            else
            {
                /* Device must not be encrytped or a valid key must be present */
                if ((device_security_flags & ULUFE) && ((device_security_flags & SEC_KEY_OK) == 0))
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nFlashROM Encryption is not enforced.");
                    dp_display_text("\r\nCannot gaurantee valid AES key present in target device.");
                    dp_display_text("\r\nUnable to proceed with Encrypted FlashROM programming.");
                    #endif
                    error_code = DPE_FROM_PLAIN_ERROR;
                    return;
                }
                
                if ((device_security_flags & ULUFJ) && ((device_security_flags & SEC_KEY_OK) == 0))
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nFROM Verification is protected by pass key.");
                    dp_display_text("\r\nA valid pass key needs to be provided.");
                    #endif
                    error_code = DPE_CORE_PLAIN_ERROR;
                    return;
                }
                
                if ( (Action_code == DP_ERASE_ACTION_CODE) || (Action_code == DP_ERASE_ALL_ACTION_CODE) || (Action_code == DP_PROGRAM_ACTION_CODE) || 
                (Action_code == DP_ERASE_FROM_ACTION_CODE) || (Action_code == DP_PROGRAM_FROM_ACTION_CODE))
                {
                    /* If device is keyed, the security match must pass */
                    if ((device_security_flags & ULUFP) && ((device_security_flags & SEC_KEY_OK) == 0))
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nFROM Write/Erase is protected by pass key.");
                        dp_display_text("\r\nA valid pass key needs to be provided.");
                        #endif
                        error_code = DPE_CORE_PLAIN_ERROR;
                        return;
                    }
                }
            }
        }
    }
    
    if ( (Action_code == DP_PROGRAM_ACTION_CODE) || (Action_code == DP_VERIFY_ACTION_CODE) || 
    (Action_code == DP_PROGRAM_NVM_ACTION_CODE) || (Action_code == DP_VERIFY_NVM_ACTION_CODE) )
    {
        if (support_status & NVM0_SUPPORT_BIT)
        {
            /* Data is encrypted */
            if (support_status & NVM0_ENCRYPTION_BIT)
            {
                /* Device must be encrypted */
                if ((device_security_flags & ULNC0) == 0)
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nNVM block 0 Encryption is enforced. Plain text programming is prohibited.");
                    #endif
                    error_code = DPE_NVM0_ENC_ERROR;
                    return;
                }
            }
            /* Data is plain text */
            else
            {
                /* Device must not be encrytped or a valid key must be present */
                if ((device_security_flags & ULNC0) && ((device_security_flags & SEC_KEY_OK) == 0))
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nNVM block 0 Encryption is not enforced.");
                    dp_display_text("\r\nCannot gaurantee valid AES key present in target device.");
                    dp_display_text("\r\nUnable to proceed with Encrypted NVM programming.");
                    #endif
                    error_code = DPE_NVM0_PLAIN_ERROR;
                    return;
                }
                
                if ((device_security_flags & ULNR0) && ((device_security_flags & SEC_KEY_OK) == 0))
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nNVM block 0 Read is protected by pass key.");
                    dp_display_text("\r\nA valid pass key needs to be provided.");
                    #endif
                    error_code = DPE_NVM0_PLAIN_ERROR;
                    return;
                }
                
                if ( (Action_code == DP_PROGRAM_ACTION_CODE) || (Action_code == DP_PROGRAM_NVM_ACTION_CODE))
                {
                    /* If device is keyed, the security match must pass */
                    if ((device_security_flags & ULNW0) && ((device_security_flags & SEC_KEY_OK) == 0))
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nNVM block 0 Read is protected by pass key.");
                        dp_display_text("\r\nA valid pass key needs to be provided.");
                        #endif
                        error_code = DPE_NVM0_PLAIN_ERROR;
                        return;
                    }
                }
            }
        }
        if (support_status & NVM1_SUPPORT_BIT)
        {
            /* Data is encrypted */
            if (support_status & NVM1_ENCRYPTION_BIT)
            {
                /* Device must be encrypted */
                if ((device_security_flags & ULNC1) == 0)
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nNVM block 1 Encryption is enforced. Plain text programming is prohibited.");
                    #endif
                    
                    error_code = DPE_NVM1_ENC_ERROR;
                    return;
                }
            }
            /* Data is plain text */
            else
            {
                /* Device must not be encrytped or a valid key must be present */
                if ((device_security_flags & ULNC1) && ((device_security_flags & SEC_KEY_OK) == 0))
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nNVM block 1 Encryption is not enforced.");
                    dp_display_text("\r\nCannot gaurantee valid AES key present in target device.");
                    dp_display_text("\r\nUnable to proceed with Encrypted NVM programming.");
                    #endif
                    error_code = DPE_NVM1_PLAIN_ERROR;
                    return;
                }
                if ((device_security_flags & ULNR1) && ((device_security_flags & SEC_KEY_OK) == 0))
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nNVM block 1 Read is protected by pass key.");
                    dp_display_text("\r\nA valid pass key needs to be provided.");
                    #endif
                    error_code = DPE_NVM1_PLAIN_ERROR;
                    return;
                }
                
                if ( (Action_code == DP_PROGRAM_ACTION_CODE) || (Action_code == DP_PROGRAM_NVM_ACTION_CODE))
                {
                    /* If device is keyed, the security match must pass */
                    if ((device_security_flags & ULNW1) && ((device_security_flags & SEC_KEY_OK) == 0))
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nNVM block 1 Read is protected by pass key.");
                        dp_display_text("\r\nA valid pass key needs to be provided.");
                        #endif
                        error_code = DPE_NVM1_PLAIN_ERROR;
                        return;
                    }
                }
            }
        }
        if (support_status & NVM2_SUPPORT_BIT)
        {
            /* Data is encrypted */
            if (support_status & NVM2_ENCRYPTION_BIT)
            {
                if ((device_security_flags & ULNC2) == 0)
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nNVM block 2 Encryption is enforced. Plain text programming is prohibited.");
                    #endif
                    error_code = DPE_NVM2_ENC_ERROR;
                    return;
                }
            }
            /* Data is plain text */
            else
            {
                /* Device must not be encrytped or a valid key must be present */
                if ((device_security_flags & ULNC2) && ((device_security_flags & SEC_KEY_OK) == 0))
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nNVM block 2 Encryption is not enforced.");
                    dp_display_text("\r\nCannot gaurantee valid AES key present in target device.");
                    dp_display_text("\r\nUnable to proceed with Encrypted NVM programming.");
                    #endif
                    error_code = DPE_NVM2_PLAIN_ERROR;
                    return;
                }
                if ((device_security_flags & ULNR2) && ((device_security_flags & SEC_KEY_OK) == 0))
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nNVM block 2 Read is protected by pass key.");
                    dp_display_text("\r\nA valid pass key needs to be provided.");
                    #endif
                    error_code = DPE_NVM2_PLAIN_ERROR;
                    return;
                }
                
                if ( (Action_code == DP_PROGRAM_ACTION_CODE) || (Action_code == DP_PROGRAM_NVM_ACTION_CODE))
                {
                    /* If device is keyed, the security match must pass */
                    if ((device_security_flags & ULNW2) && ((device_security_flags & SEC_KEY_OK) == 0))
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nNVM block 2 Read is protected by pass key.");
                        dp_display_text("\r\nA valid pass key needs to be provided.");
                        #endif
                        error_code = DPE_NVM2_PLAIN_ERROR;
                        return;
                    }
                }
            }
        }
        if (support_status & NVM3_SUPPORT_BIT)
        {
            /* Data is encrypted */
            if (support_status & NVM3_ENCRYPTION_BIT)
            {
                /* Device must be encrypted */
                if ((device_security_flags & ULNC3) == 0)
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nNVM block 3 Encryption is enforced. Plain text programming is prohibited.");
                    #endif
                    error_code = DPE_NVM3_ENC_ERROR;
                    return;
                }
            }
            /* Data is plain text */
            else
            {
                /* Device must not be encrytped or a valid key must be present */
                if ((device_security_flags & ULNC3) && ((device_security_flags & SEC_KEY_OK) == 0))
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nNVM block 3 Encryption is not enforced.");
                    dp_display_text("\r\nCannot gaurantee valid AES key present in target device.");
                    dp_display_text("\r\nUnable to proceed with Encrypted NVM programming.");
                    #endif
                    error_code = DPE_NVM3_PLAIN_ERROR;
                    return;
                }
                if ((device_security_flags & ULNR3) && ((device_security_flags & SEC_KEY_OK) == 0))
                {
                    #ifdef ENABLE_DEBUG
                    dp_display_text("\r\nNVM block 3 Read is protected by pass key.");
                    dp_display_text("\r\nA valid pass key needs to be provided.");
                    #endif
                    error_code = DPE_NVM3_PLAIN_ERROR;
                    return;
                }
                
                if ( (Action_code == DP_PROGRAM_ACTION_CODE) || (Action_code == DP_PROGRAM_NVM_ACTION_CODE))
                {
                    /* If device is keyed, the security match must pass */
                    if ((device_security_flags & ULNW3) && ((device_security_flags & SEC_KEY_OK) == 0))
                    {
                        #ifdef ENABLE_DEBUG
                        dp_display_text("\r\nNVM block 3 Read is protected by pass key.");
                        dp_display_text("\r\nA valid pass key needs to be provided.");
                        #endif
                        error_code = DPE_NVM3_PLAIN_ERROR;
                        return;
                    }
                }
            }
        }
    }
    
    /* Plain text vs encryption check */
    if ( (Action_code == DP_ERASE_SECURITY_ACTION_CODE) || (Action_code == DP_PROGRAM_SECURITY_ACTION_CODE) )
        
    {
        if (support_status & SEC_SUPPORT_BIT)
        {
            /* Device must be encrypted */
            if ((device_security_flags & ULUPC) && ((device_security_flags & SEC_KEY_OK) == 0))
            {
                #ifdef ENABLE_DEBUG
                dp_display_text("\r\nError, pass key match failure.");
                #endif
                error_code = DPE_MATCH_ERROR;
                return;
            }
        }
    }
    if (device_family & DUAL_KEY_BIT)
    {
        if (support_status & CORE_ENCRYPTION_BIT)
        {
            AES_mode_value = 2;
        }
        else 
        {
            AES_mode_value = 1;
        }
        support_status |= CORE_ENCRYPTION_BIT;
    }
    
    
    return;
}

void dp_read_factory_row(void)
{
    
    dp_vnr();
    opcode = FACTORY_ADDRESS_SHIFT;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, 3, &global_uchar, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(1);
    
    opcode = READ_FACTORY;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(264);
    
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(FACTORY_ROW_BIT_LENGTH, (DPUCHAR*)NULL, global_buf1);
    dp_goto_state(JTAG_DRPAUSE);
    
    
    return;
}

void dp_smart_erase_check(void)
{
    
    global_uchar = 0;
    dp_read_factory_row();
    if ((global_buf1[6] & 0x70) == 0x30)
    {
        device_family |= SMART_ERASE_BIT;
    }
    else if ((global_buf1[6] & 0x70) == 0x0)
    {
        device_family |= DAS_BIT;
    }
    
    return;
}

