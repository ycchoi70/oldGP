/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpdef.h                                                 */
/*                                                                          */
/*  Description:    This file contains error code definitions				*/
/*	and special character definitions										*/
/*                                                                          */
/****************************************************************************/

#ifndef INC_DPDEFINE_H
#define INC_DPDEFINE_H

#define DC_PROGAMMING_METHOD        0x2

/************************************************************/
/* Erase Bits Definitions									*/
/************************************************************/
#define CORE_ERASE_BITS_BYTE0		0x1		/*Bit 0 */
#define CORE_ERASE_BITS_BYTE1		0x0		/*Bit 0 */
#define CORE_ERASE_BITS_BYTE2		0x0		/*Bit 0 */
#define ULOCK_ERASE_BITS_BYTE0		0x2		/*Bit 1 */
#define ULOCK_ERASE_BITS_BYTE1		0x0		/*Bit 1 */
#define ULOCK_ERASE_BITS_BYTE2		0x0		/*Bit 1 */
#define DMK_ERASE_BITS_BYTE0		0x4		/*Bit 2 */
#define DMK_ERASE_BITS_BYTE1		0x0		/*Bit 2 */
#define DMK_ERASE_BITS_BYTE2		0x0		/*Bit 2 */
#define UKEY_ERASE_BITS_BYTE0		0x8		/*Bit 3 */
#define UKEY_ERASE_BITS_BYTE1		0x0		/*Bit 3 */
#define UKEY_ERASE_BITS_BYTE2		0x0		/*Bit 3 */
#define FLOCK_ERASE_BITS_BYTE0		0x10	/*Bit 4 */
#define FLOCK_ERASE_BITS_BYTE1		0x0		/*Bit 4 */
#define FLOCK_ERASE_BITS_BYTE2		0x0		/*Bit 4 */
#define FPRM_ERASE_BITS_BYTE0		0xE0	/*Bits 5-10*/
#define FPRM_ERASE_BITS_BYTE1		0x7		/*Bits 5-10*/
#define FPRM_ERASE_BITS_BYTE2		0x0		/*Bits 5-10*/
#define FKEY_ERASE_BITS_BYTE0		0x0		/*Bit 11*/
#define FKEY_ERASE_BITS_BYTE1		0x8		/*Bit 11*/
#define FKEY_ERASE_BITS_BYTE2		0x0		/*Bit 11*/
#define SECEN_ERASE_BITS_BYTE0		0x0		/*Bit 12*/
#define SECEN_ERASE_BITS_BYTE1		0x10	/*Bit 12*/
#define SECEN_ERASE_BITS_BYTE2		0x0		/*Bit 12*/
#define VIRREF_ERASE_BITS_BYTE0		0x0		/*Bit 13*/
#define VIRREF_ERASE_BITS_BYTE1		0x20	/*Bit 13*/
#define VIRREF_ERASE_BITS_BYTE2		0x0		/*Bit 13*/
#define UROW_ERASE_BITS_BYTE0		0x0		/*Bit 14*/
#define UROW_ERASE_BITS_BYTE1		0x40	/*Bit 14*/
#define UROW_ERASE_BITS_BYTE2		0x0		/*Bit 14*/
#define FROM_ERASE_BITS_BYTE0		0x0		/*Bit 14*/
#define FROM_ERASE_BITS_BYTE1		0x80	/*Bit 14*/
#define FORM_ERASE_BITS_BYTE2		0x07F	/*Bit 14*/

/************************************************************/
/* Error code definitions									*/
/************************************************************/
#define DPE_SUCCESS                 0
#define DPE_IDCODE_ERROR            6
#define DPE_INIT_FAILURE		    25
#define DPE_ERASE_ERROR			    8
#define DPE_CORE_PROGRAM_ERROR	    10
#define DPE_CORE_VERIFY_ERROR	    11
#define DPE_PROGRAM_RLOCK_ERROR     10
#define DPE_POLL_ERROR			    7   
#define DPE_PROGRAM_UROW_ERROR      24
#define DPE_FROM_VERIFY_ERROR   	20
#define DPE_FROM_PROGRAM_ERROR   	10  
#define DPE_DMK_VERIFY_ERROR        31
#define DPE_UROW_ERROR              11
#define DPE_VERIFY_ERROR		    12
#define DPE_NVM_PROGRAM_ERROR       41
#define DPE_NVM_VERIFY_ERROR		39
#define DPE_SEC_PROGRAMMING_ERROR   22
#define DPE_AES_PROGRAMMING_ERROR   23
#define DPE_ULOCK_ERROR             16
#define DPE_MATCH_ERROR             35
#define DPE_AUTHENTICATION_FAILURE  18
#define DPE_CORE_ENC_ERROR          33
#define DPE_CORE_PLAIN_ERROR        37
#define DPE_FROM_ENC_ERROR          34
#define DPE_FROM_PLAIN_ERROR        36
#define DPE_NVM0_ENC_ERROR          47
#define DPE_NVM0_PLAIN_ERROR        49
#define DPE_NVM1_ENC_ERROR          47
#define DPE_NVM1_PLAIN_ERROR        49
#define DPE_NVM2_ENC_ERROR          47
#define DPE_NVM2_PLAIN_ERROR        49
#define DPE_NVM3_ENC_ERROR          47
#define DPE_NVM3_PLAIN_ERROR        49
#define DPE_USER_LOCK_SETTING_ERROR 42
#define DPE_UROW_SETTING_ERROR      43
#define DPE_AES_SEC_ERROR           31
#define DPE_SILSIG_PROGRAM_ERROR	14
#define DPE_PROGRAM_SECURITY_ERROR	38
#define DPE_CRC_MISMATCH			100
#define DPE_JTAG_STATE_NOT_HANDLED	110
#define DPE_ACTION_NOT_FOUND        150
#define DPE_ACTION_NOT_SUPPORTED    151
#define DPE_CODE_NOT_ENABLED        152
#define CALIBRATION_OVERLAP_ERROR   153


/************************************************************/
/* Block Support status bits								*/
/************************************************************/
#define SUPPORT_STATUS_OFFSET	    39
#define CORE_SUPPORT_BIT			0x0001
#define FROM_SUPPORT_BIT			0x0002
#define NVM_SUPPORT_BIT				0x0004
#define NVM0_SUPPORT_BIT			0x0008
#define NVM1_SUPPORT_BIT			0x0010
#define NVM2_SUPPORT_BIT			0x0020
#define NVM3_SUPPORT_BIT			0x0040
#define NVM_VERIFY_SUPPORT_BIT  	0x0080
#define SEC_SUPPORT_BIT				0x0100
#define AES_SUPPORT_BIT				0x0200
#define CORE_ENCRYPTION_BIT			0x0400
#define FROM_ENCRYPTION_BIT			0x0800
#define	NVM0_ENCRYPTION_BIT			0x1000
#define	NVM1_ENCRYPTION_BIT			0x2000
#define	NVM2_ENCRYPTION_BIT			0x4000
#define	NVM3_ENCRYPTION_BIT			0x8000

/************************************************************/
/* Family code definitions									*/
/************************************************************/
#define AXX_BIT         0x1
#define AFS_BIT         0x2
#define SMART_ERASE_BIT 0x4
#define DUAL_KEY_BIT    0x8
#define CALIBRATION_BIT 0x10
#define DAS_BIT         0x20

/************************************************************/
/* Data file Tags to indicate M1, M3 or M7 data             */
/************************************************************/
#define M7		7
#define M1		1
#define P1		3


/************************************************************/
/* Device specific parameters								*/
/************************************************************/
/* Supported A3PE/A3PEL/AGLE     */
#define	AXXE600X_ID			        0x023261CF 
#define	AXXE600X_ID_MASK	        0x03FFFFFF
#define	AXXE600X_SD			        6
#define	AXXE600X_ROWS		        3444
#define	AXXE600X_COLS		        1184
#define AXXE600X_BSR_BIT_LENGTH     1056
#define AXXE600X_SE_WAIT_CYCLE      87

#ifdef ENABLE_AXXE1500_SUPPORT
#define	AXXE1500X_ID			    0x0253A1CF
#define	AXXE1500X_ID_MASK	        0x03FFFFFF
#define	AXXE1500X_SD			    10
#define	AXXE1500X_ROWS		        5644
#define	AXXE1500X_COLS		        1956
#define AXXE1500X_BSR_BIT_LENGTH    1740
#define AXXE1500X_SE_WAIT_CYCLE     137
#endif

#define AXXE3000X_ID		        0x0274E1CF
#define AXXE3000X_ID_MASK	        0x03FFFFFF
#define AXXE3000X_SD		        14
#define AXXE3000X_ROWS		        7844
#define AXXE3000X_COLS		        2728
#define AXXE3000X_BSR_BIT_LENGTH    2424
#define AXXE3000X_SE_WAIT_CYCLE     187

/* Supported A3P/A3PL/AGL     */
#define AXX030X_ID			        0x049011CF
#define AXX030X_ID_MASK   	        0x07FFFFFF
#define AXX030X_SD   		        2
#define AXX030X_ROWS 		        625
#define AXX030X_COLS 		        412
#define AXX030X_BSR_BIT_LENGTH      288

#define AXX060X_ID			        0x029121CF
#define AXX060X_ID_MASK   	        0x06FFFFFF
#define AXX060X_SD   		        2
#define AXX060X_ROWS 		        1244
#define AXX060X_COLS 		        412
#define AXX060X_BSR_BIT_LENGTH      372

#define AXX125X_ID   		        0x02A121CF
#define AXX125X_ID_MASK		        0x06FFFFFF
#define AXX125X_SD   		        4
#define AXX125X_ROWS 		        1244
#define AXX125X_COLS 		        798
#define AXX125X_BSR_BIT_LENGTH      564

#define AXX250X_ID			        0x02A141CF
#define AXX250X_ID_MASK             0x06FFFFFF
#define AXX250X_SD			        4
#define AXX250X_ROWS			    2300
#define AXX250X_COLS			    798
#define AXX250X_BSR_BIT_LENGTH      708

#define AXX400X_ID			        0x02B141CF
#define AXX400X_ID_MASK             0x06FFFFFF
#define AXX400X_SD			        6
#define AXX400X_ROWS			    2300
#define AXX400X_COLS			    1184
#define AXX400X_BSR_BIT_LENGTH      900

#define	AXX600X_ID			        0x02b261CF
#define	AXX600X_ID_MASK		        0x06FFFFFF
#define	AXX600X_SD			        6
#define	AXX600X_ROWS			    3444
#define	AXX600X_COLS			    1184
#define AXX600X_BSR_BIT_LENGTH      1056

#define AXX1000X_ID			        0x12C281CF
#define AXX1000X_ID_MASK		    0x06FFFFFF
#define AXX1000X_SD			        8
#define AXX1000X_ROWS		        4500
#define AXX1000X_COLS		        1570
#define AXX1000X_BSR_BIT_LENGTH     1392

/* Supported AGLP     */
#define AGLP030X_ID			        0x0E1011CF
#define AGLP030X_ID_MASK   	        0x0FFFFFFF
#define AGLP030X_SD   		        2
#define AGLP030X_ROWS 		        625
#define AGLP030X_COLS 		        412
#define AGLP030X_BSR_BIT_LENGTH     288

#define AGLP060X_ID			        0x0E1121CF
#define AGLP060X_ID_MASK   	        0x0EFFFFFF
#define AGLP060X_SD   		        2
#define AGLP060X_ROWS 		        1244
#define AGLP060X_COLS 		        412
#define AGLP060X_BSR_BIT_LENGTH     372

#define AGLP125X_ID   		        0x0E2121CF
#define AGLP125X_ID_MASK		    0x0EFFFFFF
#define AGLP125X_SD   		        4
#define AGLP125X_ROWS 		        1244
#define AGLP125X_COLS 		        798
#define AGLP125X_BSR_BIT_LENGTH     564

/* Supported AFS Devices */
#define AFS090_ID			        0x031921CF 
#define AFS090_ID_MASK              0x0BFFFFFF
#define AFS090_SD			        3
#define AFS090_ROWS			        1244
#define AFS090_COLS			        605
#define AFS090_BSR_BIT_LENGTH       468

#define AFS250_ID			        0x032141CF
#define AFS250_ID_MASK              0x0FFFFFFF
#define AFS250_SD			        4
#define AFS250_ROWS			        2300
#define AFS250_COLS			        798
#define AFS250_BSR_BIT_LENGTH       708

#define AFS600_ID			        0x033261CF
#define AFS600_ID_MASK		        0x0FFFFFFF
#define AFS600_SD			        6
#define AFS600_ROWS			        3444
#define AFS600_COLS			        1184
#define AFS600_BSR_BIT_LENGTH       1056
#define AFS600_SE_WAIT_CYCLE        87

#define AFS1500_ID			        0x0353A1CF
#define AFS1500_ID_MASK		        0x0FFFFFFF
#define AFS1500_SD			        10
#define AFS1500_ROWS		        5644
#define AFS1500_COLS		        1956
#define AFS1500_BSR_BIT_LENGTH      1740
#define AFS1500_SE_WAIT_CYCLE       137

#define M7BYTE0                     0x45
#define M7BYTE1                     0x49
#define M7BYTE2                     0x66
#define M7BYTE3                     0x73
#define M7BYTE4                     0x3F
#define M7BYTE5                     0x5F
#define M7BYTE6                     0x01
#define M7BYTE7                     0x26
#define M7BYTE8                     0x11
#define M7BYTE9                     0xE9
#define M7BYTE10                    0xEE
#define M7BYTE11                    0x2E
#define M7BYTE12                    0x3A
#define M7BYTE13                    0x62
#define M7BYTE14                    0x37
#define M7BYTE15                    0xE1

#define M1BYTE0                     0x77
#define M1BYTE1                     0x50
#define M1BYTE2                     0xE9
#define M1BYTE3                     0x8F
#define M1BYTE4                     0xB1
#define M1BYTE5                     0x1E
#define M1BYTE6                     0x29
#define M1BYTE7                     0x3E
#define M1BYTE8                     0x86
#define M1BYTE9                     0x88
#define M1BYTE10                    0xB4
#define M1BYTE11                    0xCC
#define M1BYTE12                    0x48
#define M1BYTE13                    0x65
#define M1BYTE14                    0xDD
#define M1BYTE15                    0xAC

#define P1BYTE0                     0x15
#define P1BYTE1                     0x7d
#define P1BYTE2                     0x69
#define P1BYTE3                     0x38
#define P1BYTE4                     0xae
#define P1BYTE5                     0x09
#define P1BYTE6                     0x5f
#define P1BYTE7                     0x5e
#define P1BYTE8                     0x17
#define P1BYTE9                     0x4e
#define P1BYTE10                    0x5a
#define P1BYTE11                    0x37
#define P1BYTE12                    0x14
#define P1BYTE13                    0xe5
#define P1BYTE14                    0xa9
#define P1BYTE15                    0xe7

#define FCBYTE0                     0x86
#define FCBYTE1                     0x00
#define FCBYTE2                     0x50
#define FCBYTE3                     0x43
#define FCBYTE4                     0x64
#define FCBYTE5                     0x9C
#define FCBYTE6                     0x52
#define FCBYTE7                     0x40
#define FCBYTE8                     0xC6
#define FCBYTE9                     0x73
#define FCBYTE10                    0xB0
#define FCBYTE11                    0xFB
#define FCBYTE12                    0x75
#define FCBYTE13                    0xE7
#define FCBYTE14                    0xFF
#define FCBYTE15                    0xFD

#endif /* INC_DPDEFINE_H */

