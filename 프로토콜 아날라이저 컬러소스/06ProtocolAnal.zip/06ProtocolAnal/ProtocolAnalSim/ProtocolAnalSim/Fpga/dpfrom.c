/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpfrom.c                                        */
/*                                                                          */
/*  Description:    Contains initialization and data checking functions.    */
/*                                                                          */
/****************************************************************************/

#include "dpuser.h"
#include "dpdef.h"
#include "dpalg.h"
#include "dputil.h"
#include "dpjtag.h"
#include "dpcom.h"
#include "dpfrom.h"
#include "dpsecurity.h"

DPUCHAR FromRowNumber;
#ifdef FROM_SUPPORT
DPUCHAR ucFRomAddressMask;

/************************************************************************************************/
/*  FROM Action Functions                                                                       */
/************************************************************************************************/
void dp_erase_from_action(void)
{
    device_security_flags |= IS_ERASE_ONLY;
    device_security_flags |= IS_RESTORE_DESIGN;
    dp_erase_from();
    return;
}

void dp_program_from_action(void)
{
    dp_erase_from();
    if (error_code != DPE_SUCCESS)
        return;
    
    /* Encryption support */
    #ifdef FROM_ENCRYPT
    if (support_status & FROM_ENCRYPTION_BIT)
    {
        dp_enc_program_from();
        if (error_code != DPE_SUCCESS)
            return;
    }
    #endif
    #ifdef FROM_PLAIN
    /* Plain text support */
    if ((support_status & FROM_ENCRYPTION_BIT) == 0)
    {
        dp_program_from();
        if (error_code == DPE_SUCCESS)
        {
            dp_verify_from();
        }
        if (error_code != DPE_SUCCESS)
            return;
    }
    #endif
    return;
}

void dp_verify_from_action(void)
{
    #ifdef FROM_PLAIN    
    /* Plain text support */
    if ((support_status & FROM_ENCRYPTION_BIT) == 0 )
    {
        dp_verify_from();
        if (error_code != DPE_SUCCESS)
            return;
    }
    #endif
    return;
}
/************************************************************************************************/

/************************************************************************************************/
/* Common Functions                                                                             */
/************************************************************************************************/
void dp_erase_from(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nErase FlashROM...");
    #endif
    dp_flush_global_buf1();
    global_buf1[0] = UROW_ERASE_BITS_BYTE0;
    global_buf1[1] = UROW_ERASE_BITS_BYTE1;
    global_buf1[2] = UROW_ERASE_BITS_BYTE2;
    
    /* This is for FROM erase.  Need to get which bits are set to erase from the data file. */
    
    global_uchar = (DPUCHAR) dp_get_bytes(FRomAddressMask_ID,0,1);
    if (global_uchar & 0x1)
        global_buf1[1]|=0x80;
    global_buf1[2]|=(global_uchar >> 1);
    device_security_flags |= IS_ERASE_ONLY;
    device_security_flags |= IS_RESTORE_DESIGN;
    
    dp_exe_erase();
    return;
}


/************************************************************************************************/
/*  FROM Plain Text Programming Functions                                                       */
/************************************************************************************************/
#ifdef FROM_PLAIN
void dp_program_from(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nProgramming FlashROM...");
    #endif
    DataIndex=0;
    global_uint = 0x80; /* global_uchar could be used in place if FromAddressMaskIndex */
    
    ucFRomAddressMask = (DPUCHAR) dp_get_bytes(FRomAddressMask_ID,0,1);
    /* Since RowNumber could be an 8 bit variable or 16 bit, it will wrap around */
    for (FromRowNumber=7;(FromRowNumber&0xff) != 255 ;FromRowNumber--)
    {
        if (ucFRomAddressMask & global_uint)
        {
            opcode = ISC_UFROM_ADDR_SHIFT;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_shift_in(0,3,&FromRowNumber,1);
            dp_goto_state(JTAG_DRUPDATE);		
            
            opcode = ISC_PROGRAM_UFROM;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_get_and_shift_in(FRomStream_ID, FROM_ROW_BIT_LENGTH, DataIndex);
            dp_goto_state(JTAG_IDLE);
            dp_wait_cycles(5);
            DataIndex = DataIndex + FROM_ROW_BIT_LENGTH;
            
            dp_poll_device();
            if (error_code != DPE_SUCCESS)
                return;
        }
        global_uint>>=1;
    }
    return;
}

void dp_verify_from(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nVerifying FlashROM...");
    #endif
    dp_vnr();
    
    DataIndex=0;
    global_uint=0x80; /* global_uchar could be used in place if FromAddressMaskIndex */
    
    ucFRomAddressMask = (DPUCHAR) dp_get_bytes(FRomAddressMask_ID,0,1);
    for (FromRowNumber=7;(FromRowNumber&0xff) != 255 ;FromRowNumber--)
    {
        if (ucFRomAddressMask & global_uint)
        {
            opcode = ISC_UFROM_ADDR_SHIFT;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_shift_in(0,3,&FromRowNumber,1);
            dp_goto_state(JTAG_DRUPDATE);
            
            opcode = ISC_VERIFY_UFROM;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_get_and_shift_in(FRomStream_ID, FROM_ROW_BIT_LENGTH, DataIndex);
            dp_goto_state(JTAG_IDLE);
            dp_wait_cycles(3);
            
            dp_poll_device();
            if (error_code != DPE_SUCCESS)
                return;
            
            opcode = ISC_VERIFY_UFROM;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_shift_in_out(FROM_ROW_BIT_LENGTH,(DPUCHAR*)NULL,global_buf1);
            dp_goto_state(JTAG_DRPAUSE);		
            
            if ((global_buf1[0]&0x3) !=0x3)
            {
                error_code = DPE_FROM_VERIFY_ERROR;
                return;
            }
            DataIndex = DataIndex + FROM_ROW_BIT_LENGTH;
        }
        global_uint>>=1;
    }
    return;
}
#endif


#ifdef FROM_ENCRYPT
/*********************** ENCRYPTION **************************/
void dp_enc_program_from(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nProgramming FlashROM...");
    #endif
    if (device_family & DUAL_KEY_BIT)
    {
        global_uchar = 0;
        dp_set_aes_mode();
    }
    
    
    DataIndex=0;
    global_uint = 0x1; /* global_uint could be used in place if FromAddressMaskIndex */
    
    ucFRomAddressMask = (DPUCHAR) dp_get_bytes(FRomAddressMask_ID,0,1);
    
    for (FromRowNumber=1;FromRowNumber <= 8 ;FromRowNumber++)
    {
        if (ucFRomAddressMask & global_uint)
        {
            dp_init_aes();
            
            opcode = ISC_DESCRAMBLE_UFROM;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_get_and_shift_in(FRomStream_ID, FROM_ROW_BIT_LENGTH, DataIndex);
            dp_goto_state(JTAG_IDLE);
            dp_wait_cycles(1);
            dp_delay(48);
            
            DataIndex = DataIndex + FROM_ROW_BIT_LENGTH;
            
            opcode = ISC_PROGRAM_ENC_UFROM;
            dp_goto_state(JTAG_SHIR);
            dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
            dp_goto_state(JTAG_IRPAUSE);
            dp_goto_state(JTAG_SHDR);
            dp_get_and_shift_in(FRomStream_ID, FROM_ROW_BIT_LENGTH, DataIndex);
            dp_goto_state(JTAG_IDLE);
            dp_wait_cycles(5);
            DataIndex = DataIndex + FROM_ROW_BIT_LENGTH;
            dp_poll_device();
            if (error_code != DPE_SUCCESS)
                return;
        }
        global_uint<<=1;
    }
    return;
}
#endif
#endif

#ifdef ENABLE_DEBUG
void dp_read_from(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\n\r\nFlashROM Information: ");
    #endif
    dp_vnr();
    
    for (FromRowNumber=7;(FromRowNumber&0xff) != 255 ;FromRowNumber--)
    {
        opcode = ISC_UFROM_ADDR_SHIFT;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IRPAUSE);
        dp_goto_state(JTAG_SHDR);
        dp_shift_in(0,3,&FromRowNumber,1);
        dp_goto_state(JTAG_DRUPDATE);
        
        opcode = ISC_READ_UFROM;
        dp_goto_state(JTAG_SHIR);
        dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
        dp_goto_state(JTAG_IRPAUSE);
        
        dp_goto_state(JTAG_SHDR);
        dp_shift_in(0,FROM_ROW_BIT_LENGTH,(DPUCHAR*)NULL,1);
        dp_goto_state(JTAG_IDLE);
        dp_wait_cycles(3);
        dp_delay(100);
        
        
        dp_goto_state(JTAG_SHDR);
        dp_shift_in_out(FROM_ROW_BIT_LENGTH,(DPUCHAR*)NULL,global_buf1);
        dp_goto_state(JTAG_DRPAUSE);
        dp_display_text("\r\n");
        dp_display_array(global_buf1,FROM_ROW_BYTE_LENGTH,HEX);
    }
    dp_display_text("\r\n==================================================");
    return;
}
#endif
