#include	<string.h>
#include	<stdio.h>

#include	"bios.h"
#include	"flash.h"
#include	"rs232c.h"
#include	"lload.h"
#include	"udebtsk.h"


/***********************************************/
/*  16�i�E2�i�ϊ�����   		                  */
/*       1995.11.8                             */
/***********************************************/
unsigned char LHexToBin(char as_data)
{
	unsigned char ret;

	ret = 0;
	if((as_data >= '0') && (as_data <= '9')){
		ret = (unsigned char)(as_data - '0');
	}
	else if((as_data >= 'A') && (as_data <= 'F')){
		ret = (unsigned char)(as_data - 'A' + 10);
	}
	else if((as_data >= 'a') && (as_data <= 'f')){
		ret = (unsigned char)(as_data - 'a' + 10);
	}
	return(ret);
}
/***********************************************/
/*  16�i�E2�i�ϊ�����   		                  */
/*       1995.11.8                             */
/***********************************************/
unsigned int LHexAsToBin(char *buff, int cnt)
{
	int		i;
	unsigned int hex_data;

	hex_data = 0;
	for(i = 0; i < cnt; i++){
		hex_data = hex_data << 4;
		hex_data += LHexToBin(buff[i]);
	}
	return(hex_data);
}
void	Bin2Hex2(char data, char *buf)
{
	unsigned char	high,low;

	high = (data & 0xf0) >> 4;
	low = data & 0x0f;
	if(high > 9){	high += 55;	}
	else{			high += 48;	}
	if(low > 9){	low += 55;	}
	else{			low += 48;	}
	buf[0] = high;
	buf[1] = low;
}
void	Bin2Hex4(unsigned short data, char *buf)
{
	char	high,low;

	high = (data & 0xff00) >> 8;
	low	= data & 0xff;
	Bin2Hex2(high,buf);
	Bin2Hex2(low,&buf[2]);
}

int	GetSioChar( void )
{
	int	ret;
	
	TimerStart( 2, 3000 );		/* 30s */
	ret = 0;
	while(time_flag[2] == 0){
		ret = GET_CONSOL();
		if(ret != 0){
			break;
		}
	}
	return(ret);
}


void	Wait500(void)
{
	int		i;
	int		cnt;
	int		cnt1;

	for(i= 0; i < 500; i++){
		cnt = 10;
		cnt1 = 3;
		cnt= cnt+ cnt1;
	}
}
/***********************************************/
/*  �ް�ں��ގ�荞�ݏ���                      */
/*       1995.11.8                             */
/***********************************************/
int	DataSet(char *buff, char *data_adr, int cnt)
{
	int		i;
	
	for(i = 0; i < cnt; i++){
						/* ���ސ� */
		data_adr[i] = (unsigned char)LHexAsToBin(&buff[i*2],2);
	}
	return(0);
}
/************************************************/
/* Load the Hex data from RS232C to Flash-ROM	*/
/* Update:97.06.10 kf							*/
/************************************************/
extern	void	RtsOn(void);
extern	void	RtsOff(void);
	char	rbuff[256+1];
	char	DataBuf[64];
int	FlashWriteProcCheck(char *addr,char *data,int size)
{
	FlashWriteSeq(addr,data,size);
	return(0);
}

int	HexLoad(char *SaveAddr)
{
	int		i;
	char	*data_adr;
	char	*base_adr;
	int		len;
    char    *location;
	char	type;
	unsigned int	chksum;
	int		ret;
	int		end_flag;
	int		DispCount= 0;	/* 19991118UOI */

	end_flag = 0;				/* End Flag */
	rbuff[256] = 0;
	memset(SaveAddr,0xff,0x200000);
	base_adr= (char*)0xffffffff;
	while(end_flag == 0){
		if( DispCount++ % 100 == 100-1 ){	Sio1SendChar( '.' );	}
		for(i = 0; i < 256; i++){	/* 1 Line Read */
			while(1){
				ret = GetSioChar();
				if((ret == 0) || 
				  ((ret >= 0x20) && (ret <= 0x80)) ||
				  (ret == 0x0d)){
					  break;
				}
			}
			rbuff[i] = ret;
			if((ret == 0x0d) || (ret == 0)){
				break;
			}
		}
		if(ret == 0){		/* Time Out */
			break;
		}
		rbuff[i] = 0;
		if(rbuff[0] != 'S'){
			continue;		/*ں��޽���ϰ��łȂ� */
		}
        RtsOff();
                                /* ���������� */
		len = strlen(rbuff);
		chksum = 0;
		for(i = 0; i < len/2 - 1; i++){
			chksum += LHexAsToBin(&rbuff[i*2+2],2);
		}
		if((chksum & 0xff) != 0xff){
			break;			/*�����Ѵװ */
		}
		len = LHexAsToBin(&rbuff[2],2);		/* ���ސ� */
		type = rbuff[1];			/* �ް����� */
		switch(type){
		case '1':			/* 2�o�C�g���ڽ */
            location = (char *)LHexAsToBin(&rbuff[4],4);
			if((int)base_adr == 0xffffffff){
				base_adr = (char *)((unsigned int)location & 0xffe00000);	//2MB
			}
            data_adr = location- base_adr+ SaveAddr;		/* ���ސ� */
			DataSet(&rbuff[8],DataBuf,len - 3);
			break;
		case '2':			/* 3�o�C�g���ڽ */
            location = (char *)LHexAsToBin(&rbuff[4],6);
			if((int)base_adr == 0xffffffff){
				base_adr = (char *)((unsigned int)location & 0xffe00000);	//2MB
			}
            data_adr = location- base_adr+ SaveAddr;		/* ���ސ� */
			DataSet(&rbuff[10],DataBuf,len - 4);
			break;
		case '3':			/* 4�o�C�g���ڽ */
            location = (char *)LHexAsToBin(&rbuff[4],8);
			if((int)base_adr == 0xffffffff){
				base_adr = (char *)((unsigned int)location & 0xffe00000);	//2MB
			}
            data_adr = location- base_adr+ SaveAddr;		/* ���ސ� */
			DataSet(&rbuff[12],DataBuf,len - 5);
			break;
		case '7':	  		/* �I��ں��� */
		case '8':	  		/* �I��ں��� */
		case '9':	  		/* �I��ں��� */
			end_flag = 1;
			_di();
			Wait500();
        	FlashWriteProcCheck((char *)base_adr,SaveAddr,(long)(data_adr-SaveAddr));
			break;
		}
        RtsOn();
	}
	if(end_flag == 0){
		Sio1SendChar( '\r' );
		Sio1SendChar( '\n' );
		Sio1SendChar( 'E' );
		Sio1SendChar( 'R' );
		Sio1SendChar( 'R' );
		Sio1SendChar( 'O' );
		Sio1SendChar( 'R' );
	}
	Sio1SendChar( '\r' );
	Sio1SendChar( '\n' );
	Sio1SendChar( '>' );
	return(0);
}
/********************************************/
/*	Font Load Program						*/
/********************************************/
int	FlashProcCheck(char *addr,char *data,int size)
{
	int		i,ret;
	unsigned int	*obj,*src;

	ret= 0;
	obj= (unsigned int*)addr;
	src= (unsigned int*)data;
	for(i= 0; i < size/4; i++){
		if(*obj++ != *src++){
			ret= -1;
			break;
		}
	}
	return(ret);
}
void	FontDownLoad(char *SaveAddr,int mode)
{
	int		i;
	char	*data_adr;
	char	*base_adr;
	int		len;
    char    *location;
	char	type;
	unsigned int	chksum;
	int		ret;
	int		end_flag;
	int		DispCount= 0;	/* 19991118UOI */

	end_flag = 0;				/* End Flag */
	rbuff[256] = 0;
	memset(SaveAddr,0xff,0x200000);
	base_adr = (char *)0xffffffff;
	while(end_flag == 0){
		if( DispCount++ % 100 == 100-1 ){	Sio1SendChar( '.' );	}
		for(i = 0; i < 256; i++){	/* 1 Line Read */
			while(1){
				ret = GetSioChar();
				if((ret == 0) || 
				  ((ret >= 0x20) && (ret <= 0x80)) ||
				  (ret == 0x0d)){
					  break;
				}
			}
			rbuff[i] = ret;
			if((ret == 0x0d) || (ret == 0)){
				break;
			}
		}
		if(ret == 0){		/* Time Out */
			break;
		}
		rbuff[i] = 0;
		if(rbuff[0] != 'S'){
			continue;		/*ں��޽���ϰ��łȂ� */
		}
        RtsOff();			/* �ʐM���~�߂� */
                                /* ���������� */
		len = strlen(rbuff);
		chksum = 0;
		for(i = 0; i < len/2 - 1; i++){
			chksum += LHexAsToBin(&rbuff[i*2+2],2);
		}
		if((chksum & 0xff) != 0xff){
			break;			/*�����Ѵװ */
		}
		len = LHexAsToBin(&rbuff[2],2);		/* ���ސ� */
		type = rbuff[1];			/* �ް����� */
		switch(type){
		case '1':			/* 2�o�C�g���ڽ */
            location = (char *)LHexAsToBin(&rbuff[4],4);
			if((int)base_adr == 0xffffffff){
				base_adr = (char *)((unsigned int)location & 0xffff0000);	//2MB
			}
            data_adr = location- base_adr+ SaveAddr;		/* ���ސ� */
			DataSet(&rbuff[8],DataBuf,len - 3);
			memcpy(data_adr,DataBuf,len - 3);
			data_adr += len - 3;
			break;
		case '2':			/* 3�o�C�g���ڽ */
            location = (char *)LHexAsToBin(&rbuff[4],6);
			if((int)base_adr == 0xffffffff){
				base_adr = (char *)((unsigned int)location & 0xffff0000);
			}
            data_adr = location- base_adr+ SaveAddr;		/* ���ސ� */
			DataSet(&rbuff[10],DataBuf,len - 4);
			memcpy(data_adr,DataBuf,len - 4);
			data_adr += len - 4;
			break;
		case '3':			/* 4�o�C�g���ڽ */
            location = (char *)LHexAsToBin(&rbuff[4],8);
			if((int)base_adr == 0xffffffff){
				base_adr = (char *)((unsigned int)location & 0xffff0000);
			}
            data_adr = location- base_adr+ SaveAddr;		/* ���ސ� */
			DataSet(&rbuff[12],DataBuf,len - 5);
			memcpy(data_adr,DataBuf,len - 5);
			data_adr += len - 5;
			break;
		case '7':	  		/* �I��ں��� */
		case '8':	  		/* �I��ں��� */
		case '9':	  		/* �I��ں��� */
			SendString( "File Writting\r\n" );
			end_flag = 1;
//	        FlashWriteProcCheck((char *)base_adr,SaveAddr,(long)(data_adr-SaveAddr));
	        FlashWriteProcCheck((char *)0x10000,SaveAddr,(long)(data_adr-SaveAddr));
			break;
		}
        RtsOn();
	}
	if(end_flag == 0){
		SendString("ERROR\r\n");
	}
	SendString("\r\n>");
}

/********************************************/
/*	Font Load Program						*/
/********************************************/
void	FontRamDownLoad(void)
{
	int		i;
	char	*data_adr;
	int		len;
    char    *location;
	char	type;
	unsigned int	chksum;
	int		ret;
	int		end_flag;
	int		DispCount= 0;	/* 19991118UOI */

	end_flag = 0;				/* End Flag */
	rbuff[256] = 0;
	while(end_flag == 0){
		if( DispCount++ % 100 == 100-1 ){	Sio1SendChar( '.' );	}
		for(i = 0; i < 256; i++){	/* 1 Line Read */
			while(1){
				ret = GetSioChar();
				if((ret == 0) || 
				  ((ret >= 0x20) && (ret <= 0x80)) ||
				  (ret == 0x0d)){
					  break;
				}
			}
			rbuff[i] = ret;
			if((ret == 0x0d) || (ret == 0)){
				break;
			}
		}
		if(ret == 0){		/* Time Out */
			break;
		}
		rbuff[i] = 0;
		if(rbuff[0] != 'S'){
			continue;		/*ں��޽���ϰ��łȂ� */
		}
        RtsOff();			/* �ʐM���~�߂� */
                                /* ���������� */
		len = strlen(rbuff);
		chksum = 0;
		for(i = 0; i < len/2 - 1; i++){
			chksum += LHexAsToBin(&rbuff[i*2+2],2);
		}
		if((chksum & 0xff) != 0xff){
			break;			/*�����Ѵװ */
		}
		len = LHexAsToBin(&rbuff[2],2);		/* ���ސ� */
		type = rbuff[1];			/* �ް����� */
		switch(type){
		case '3':			/* 4�o�C�g���ڽ */
            location = (char *)LHexAsToBin(&rbuff[4],8);
			if(((int)location < 0x0c000000) || ((int)location >= 0x0cf00000)){	/* 0x10000< || 0x80000>= */
				break;
			}
            data_adr = location;		/* ���ސ� */
			DataSet(&rbuff[12],DataBuf,len - 5);
			memcpy(data_adr,DataBuf,len - 5);
			break;
		case '7':	  		/* �I��ں��� */
		case '8':	  		/* �I��ں��� */
		case '9':	  		/* �I��ں��� */
			end_flag = 1;
			break;
		}
        RtsOn();
	}
	if(end_flag == 0){
		Sio1SendChar( '\r' );
		Sio1SendChar( '\n' );
		Sio1SendChar( 'E' );
		Sio1SendChar( 'R' );
		Sio1SendChar( 'R' );
		Sio1SendChar( 'O' );
		Sio1SendChar( 'R' );
	}
	Sio1SendChar( '\r' );
	Sio1SendChar( '\n' );
	Sio1SendChar( '>' );
}

