#ifdef _WINDOWS
//#include    "stdafx.h"
#endif
#include	"stdio.h"
#include	"string.h"

#include "define.h"
#include "glplcd.h"
#include "commbuff.h"
#include "disp.h"
#include "doscomm.h"
#include "glpdos.h"
#include "usbh.h"
#include "lload.h"
#include "bios.h"
#include "pcmcia.h"
//#include "mmcdrv.h"
#include "touch.h"
#include "udebtsk.h"
#include "filecontrol.h"
#include "rs232c.h"

#define	FILE_START_X	60
#define	FILE_START_Y	60



char	ufileName[260];
char	sfileName[260];

char*	fctlDevName[5]={
	"USR1 File",
	"USR2 File",
	"SYS  File",
	"USB  File",
	"RAM  File"
};
int			fctlDevKind[2];
FILE_INF	DevNameInf[2];
int			dev_page[2];

int	setDriveName(int drive,char* fileName)
{
	int	ret= 0;

	switch(fctlDevKind[drive]){
	case 0:	strcpy(fileName,"A:");	break;
	case 1:	strcpy(fileName,"B:");	break;
	case 2:	strcpy(fileName,"C:");	break;
	case 3:	strcpy(fileName,"D:");	break;
	case 4:	strcpy(fileName,"E:");	break;
	default:	ret= -1;			break;
	}
	return(ret);
}
void	serchFileNameProc(int drive,FILE_INF *DevName,char *name)
{
	int		err;
	int		file_cnt= 0;
	struct find_t finddata;
	char	filename[16];

	switch(fctlDevKind[drive]){
	case 0:	strcpy(filename,"A:\\");	break;
	case 1:	strcpy(filename,"B:\\");	break;
	case 2:	strcpy(filename,"C:\\");	break;
	case 3:	strcpy(filename,"D:\\");	break;
	case 4:	strcpy(filename,"E:\\");	break;
	}
	strcat(filename,name);
	err = Fs_dos_findfirst(filename, 0, &finddata);
	while(err >= 0){
		// Volumem Label Check
		if ( (finddata.attrib & FA_LABEL) == 0x00 ) {
			file_cnt++;
			if((file_cnt > dev_page[drive]*16) && (file_cnt <= (dev_page[drive]+1)*16)){
				if ( (finddata.attrib & FA_DIRECT) != 0x00 ) {		//Directory
					DevName->attribute[DevName->serchFileCnt]= 1;
				}else{
					DevName->attribute[DevName->serchFileCnt]= 0;
				}
				strcpy(DevName->serchFileName[DevName->serchFileCnt++],finddata.name);
				if(DevName->serchFileCnt >= 16){	break;	}
			}
		}
		err = Fs_dos_findnext(&finddata);
	}
}
const int	fileColorTbl[3]={
	T_RED,T_GREEN,T_GREEN
};
void	DispFileName(void)
{
	int	i,j;

	ClearDispBuff();
	RectAngleNoDraw(0,LCD_Y_SIZE-16*3-1,8*10,LCD_Y_SIZE-1);
	DotTextOutNoDraw(8/8,(LCD_Y_SIZE-16*2)/20,"DV1 CHG");

	RectAngleNoDraw(0,LCD_Y_SIZE-16*6-1,8*10,LCD_Y_SIZE-16*3-1);
	DotTextOutNoDraw(8/8,(LCD_Y_SIZE-16*5)/20,"DV1 DEL");

	RectAngleNoDraw(8*10,LCD_Y_SIZE-16*3-1,8*20,LCD_Y_SIZE-1);
	DotTextOutNoDraw((8+8*10)/8,(LCD_Y_SIZE-16*2)/20,"DV2 CHG");

	RectAngleNoDraw(8*10,LCD_Y_SIZE-16*6-1,8*20,LCD_Y_SIZE-16*3-1);
	DotTextOutNoDraw((8+8*10)/8,(LCD_Y_SIZE-16*5)/20,"DV2 DEL");

	RectAngleNoDraw(8*20,LCD_Y_SIZE-16*3-1,8*30,LCD_Y_SIZE-1);
	DotTextOutNoDraw((8+8*20)/8,(LCD_Y_SIZE-16*2)/20,"DV1 NXT");
	RectAngleNoDraw(8*20,LCD_Y_SIZE-16*6-1,8*30,LCD_Y_SIZE-16*3-1);
	DotTextOutNoDraw((8+8*20)/8,(LCD_Y_SIZE-16*5)/20,"DV1 BEF");

	RectAngleNoDraw(8*30,LCD_Y_SIZE-16*3-1,8*40,LCD_Y_SIZE-1);
	DotTextOutNoDraw((8+8*30)/8,(LCD_Y_SIZE-16*2)/20,"DV2 NXT");
	RectAngleNoDraw(8*30,LCD_Y_SIZE-16*6-1,8*40,LCD_Y_SIZE-16*3-1);
	DotTextOutNoDraw((8+8*30)/8,(LCD_Y_SIZE-16*5)/20,"DV2 BEF");



	RectAngleNoDraw(8*40,LCD_Y_SIZE-16*3-1,8*50,LCD_Y_SIZE-1);
	DotTextOutNoDraw((8+8*40)/8,(LCD_Y_SIZE-16*2)/20,"BMP DSP");

	RectAngleNoDraw(LCD_X_SIZE-8*10-1,LCD_Y_SIZE-16*3-1,LCD_X_SIZE-1,LCD_Y_SIZE-1);
	DotTextOutNoDraw((LCD_X_SIZE-8*8)/8,(LCD_Y_SIZE-16*2)/20,"COPY");

	DotTextOutNoDraw( 60/8,40/20,fctlDevName[fctlDevKind[0]]);
	DotTextOutNoDraw(260/8,40/20,fctlDevName[fctlDevKind[1]]);
	for(i= 0; i < 2; i++){
		for(j= 0; j < DevNameInf[i].serchFileCnt; j++){
			if(DevNameInf[i].attribute[j] == 0){	//File
				ForGrandColor= GetColorData(T_GREEN);			//WHITE()
				DotTextOutNoDraw( (60+i*200)/8,(60+j*20)/20,DevNameInf[i].serchFileName[j]);
			}else{									//Directory
				ForGrandColor= GetColorData(T_RED);			//WHITE()
				DotTextOutNoDraw( (60+i*200)/8,(60+j*20)/20,DevNameInf[i].serchFileName[j]);
			}
			ForGrandColor= GetColorData(T_WHITE);			//WHITE()
			if(DevNameInf[i].Select[j] == 0){
				DotTextOutNoDraw( (44+i*200)/8,(60+j*20)/20," ");
			}else{
				DotTextOutNoDraw( (44+i*200)/8,(60+j*20)/20,"*");
			}
		}
	}
	DrawLcd((char *)LcdBuff);
}

void	FileCopyUSB2Sys(void)
{
	int		i;
	int		rfp,wfp,len;
	int	loop;
	char	*serchReadBuff;
	char	buff[32];

	serchReadBuff= (char*)DOWNLOAD_BUFF;
	for(i= 0; i < DevNameInf[1].serchFileCnt; i++){
		if(DevNameInf[1].Select[i] != 0){
			DevNameInf[1].Select[i]= 0;
			if(DevNameInf[1].attribute[i] == 1){	continue;	}	//Directory
//			strcpy(ufileName,"D:");
			if(setDriveName(1,ufileName) == -1){	continue;	}
			strcat(ufileName,DevNameInf[1].serchFileName[i]);
			rfp = Fs_open(ufileName,O_RDONLY,S_IREAD);
			if(rfp < 0){	continue;	}
//			strcpy(sfileName,"C:");
			if(setDriveName(0,sfileName) == -1){	continue;	}
			strcat(sfileName,DevNameInf[1].serchFileName[i]);
			wfp = Fs_open(sfileName,O_CREAT,S_IWRITE);
			if(wfp < 0){
				continue;
			}
			loop= 0;
			while(1){
				sprintf(buff,"R/W=%4d",loop++);
				DotTextOut( 60/8,350/20,buff);
				len= Fs_read (rfp, serchReadBuff,0x10000);
				if(len <= 0){	break;	}
				Fs_write (wfp, serchReadBuff,len);
			}
			sprintf(buff,"        ");
			DotTextOut( 60/8,350/20,buff);
			Fs_close(rfp);
			Fs_close(wfp);
		}
	}

}
void	UsbChangeDir(int drive,FILE_INF * DevName)
{
	int	i;

	for(i= 0; i < DevName->serchFileCnt; i++){
		if(DevName->Select[i] != 0){
			DevName->Select[i]= 0;
			if(DevName->attribute[i] == 1){	break;	}
		}
	}
	if(i >= DevName->serchFileCnt){	return;	} 
	//Change Directory
	if(setDriveName(drive,ufileName) == -1){	return;	}
	strcat(ufileName,DevName->serchFileName[i]);

	Fs_chdir(ufileName);
	dev_page[drive]= 0;
}
void	UsbDeleteFile(int drive,FILE_INF * DevName)
{
	int	i;

	for(i= 0; i < DevName->serchFileCnt; i++){
		if(DevName->Select[i] == 0){	continue;	}
		DevName->Select[i]= 0;
		//Change Directory
		if(setDriveName(drive,ufileName) == -1){	break;	}
		strcat(ufileName,DevName->serchFileName[i]);
		if(DevName->attribute[i] == 0){
			Fs_remove(ufileName);
		}else{
			Fs_rmdir(ufileName);
		}
	}
}

void	vFileControl(void)
{
	int	i;
	int	sUsbHostConnected;
//	int	sMmcSdConnected;
	int	iKeyCode;
	int	sTouch;
	int	eTouch;
	int	xTouch;
	int	yTouch;
	int	EndFlag;

	sUsbHostConnected= UsbHostConnected;
//	sMmcSdConnected= MmcSdConnected;
	sTouch= (FILE_START_Y/MESH_Y)*(LCD_X_SIZE/MESH_X)+ 1;
	eTouch= ((FILE_START_Y+16*20)/MESH_Y)*(LCD_X_SIZE/MESH_X);

	fctlDevKind[0]= 0;		//USR1
	fctlDevKind[1]= 2;		//SYSTEM
	memset(dev_page,0,sizeof(dev_page));
	EndFlag= 0;
	TouchRepeatFlag= 0;

	while (EndFlag == 0) {

		memset(DevNameInf,0,sizeof(DevNameInf));
		for(i= 0; i < 2; i++){
			if((fctlDevKind[i] == 3) && (UsbHostConnected == 0)){	continue;	}
//			if((fctlDevKind[i] == 4) && (MmcSdConnected == 0)){	continue;	}
			serchFileNameProc(i,&DevNameInf[i],"*.*");
		}

		DispFileName();
		while(1){
			if((fctlDevKind[0] == 3) || (fctlDevKind[1] == 3)){		//USB Select
				if(sUsbHostConnected != UsbHostConnected){
					sUsbHostConnected= UsbHostConnected;
					if(fctlDevKind[0] == 3){
						DevNameInf[0].serchFileCnt= 0;
						if(sUsbHostConnected == 1){	serchFileNameProc(0,&DevNameInf[0],"*.*");	}
					}else{
						DevNameInf[1].serchFileCnt= 0;
						if(sUsbHostConnected == 1){	serchFileNameProc(1,&DevNameInf[1],"*.*");	}
					}
					DispFileName();
				}
			}
//			if((fctlDevKind[0] == 4) || (fctlDevKind[1] == 4)){		//SD Select
//				if(sMmcSdConnected != MmcSdConnected){
//					sMmcSdConnected= MmcSdConnected;
//					if(fctlDevKind[0] == 4){
//						DevNameInf[0].serchFileCnt= 0;
//						if(sMmcSdConnected == 1){	serchFileNameProc(0,&DevNameInf[0],"*.*");	}
//					}else{
//						DevNameInf[1].serchFileCnt= 0;
//						if(sMmcSdConnected == 1){	serchFileNameProc(1,&DevNameInf[1],"*.*");	}
//					}
//					DispFileName();
//				}
//			}
//			iKeyCode= ScanKey();
			if(iKeyCode == 1){
				EndFlag= 1;
				break;
			}
			//
			if(iKeyCode > 0){
				xTouch= iKeyCode % (LCD_X_SIZE/MESH_X);
				yTouch= iKeyCode / (LCD_X_SIZE/MESH_X);


				if((iKeyCode >= sTouch) && (iKeyCode <= eTouch)){		//File Select
					xTouch= ((iKeyCode- sTouch) % (LCD_X_SIZE/MESH_X))/((LCD_X_SIZE/MESH_X)/3);
					yTouch= (iKeyCode- sTouch) / (LCD_X_SIZE/MESH_X);
					if(xTouch < 2){
						if(yTouch < DevNameInf[xTouch].serchFileCnt){
							if(DevNameInf[xTouch].Select[yTouch] == 0){
								DevNameInf[xTouch].Select[yTouch]= 1;
								DotTextOut( (44+xTouch*200)/8,(60+yTouch*20)/20,"*");
							}else{
								DevNameInf[xTouch].Select[yTouch]= 0;
								DotTextOut( (44+xTouch*200)/8,(60+yTouch*20)/20," ");
							}
						}
					}
				}
				//Copy
				if((xTouch >= (LCD_X_SIZE/MESH_X)-5) && (yTouch >= (LCD_Y_SIZE/MESH_Y)-3)){
					FileCopyUSB2Sys();
					DevNameInf[0].serchFileCnt= 0;
					serchFileNameProc(0,&DevNameInf[0],"*.*");	//Sys File Search
					DispFileName();
				}
				//Disp1 Dir Change
				if((xTouch >= 0) && (xTouch <= 5) && (yTouch >= (LCD_Y_SIZE/MESH_Y)-3)){
					UsbChangeDir(0,&DevNameInf[0]);
					DevNameInf[0].serchFileCnt= 0;
					serchFileNameProc(0,&DevNameInf[0],"*.*");	//Sys File Search
					DispFileName();
				}
				//Disp2 Dir Change
				if((xTouch >= 6) && (xTouch <= 10) && (yTouch >= (LCD_Y_SIZE/MESH_Y)-3)){
					UsbChangeDir(1,&DevNameInf[1]);
					DevNameInf[1].serchFileCnt= 0;
					serchFileNameProc(1,&DevNameInf[1],"*.*");	//Sys File Search
					DispFileName();
				}
				//File Delete DEV1
				if((xTouch >= 0) && (xTouch <= 5) && (yTouch >= 19) && (yTouch <= 21)){
					UsbDeleteFile(0,&DevNameInf[0]);
					DevNameInf[0].serchFileCnt= 0;
					serchFileNameProc(0,&DevNameInf[0],"*.*");	//Sys File Search
					DispFileName();
				}
				//File Delete DEV2
				if((xTouch >= 6) && (xTouch <= 10) && (yTouch >= 19) && (yTouch <= 21)){
					UsbDeleteFile(1,&DevNameInf[1]);
					DevNameInf[1].serchFileCnt= 0;
					serchFileNameProc(1,&DevNameInf[1],"*.*");	//Sys File Search
					DispFileName();
				}
				//DEVICE 1
				if((xTouch >= 4) && (xTouch <= 8) && (yTouch == 2)){
					fctlDevKind[0]++;
					if(fctlDevKind[0] >= 5){								fctlDevKind[0]= 0;		}
					DevNameInf[0].serchFileCnt= 0;
					if((fctlDevKind[0] == 3) && (sUsbHostConnected == 0)){
//					}else if((fctlDevKind[0] == 4) && (sMmcSdConnected == 0)){
					}else{
						serchFileNameProc(0,&DevNameInf[0],"*.*");	//Sys File Search
					}
					DispFileName();
				}
				//DEVICE 2
				if((xTouch >= 17) && (xTouch <= 21) && (yTouch == 2)){
					fctlDevKind[1]++;
					if(fctlDevKind[1] >= 5){								fctlDevKind[1]= 0;		}
					DevNameInf[1].serchFileCnt= 0;
					if((fctlDevKind[1] == 3) && (sUsbHostConnected == 0)){
//					}else if((fctlDevKind[1] == 4) && (sMmcSdConnected == 0)){
					}else{
						serchFileNameProc(1,&DevNameInf[1],"*.*");	//Sys File Search
					}
					DispFileName();
				}
				//DEV1 NEXT
				if((xTouch >= 11) && (xTouch <= 15) && (yTouch >= (LCD_Y_SIZE/MESH_Y)-3)){
					if(DevNameInf[0].serchFileCnt == 16){	dev_page[0]++;	}
					DevNameInf[0].serchFileCnt= 0;
					serchFileNameProc(0,&DevNameInf[0],"*.*");	//Sys File Search
					DispFileName();
				}
				//DEV1 BEF
				if((xTouch >= 11) && (xTouch <= 15) && (yTouch >= 19) && (yTouch <= 21)){
					if(dev_page[0] > 0){	dev_page[0]--;	}
					DevNameInf[0].serchFileCnt= 0;
					serchFileNameProc(0,&DevNameInf[0],"*.*");	//Sys File Search
					DispFileName();
				}
				//DEV2 NEXT
				if((xTouch >= 16) && (xTouch <= 20) && (yTouch >= (LCD_Y_SIZE/MESH_Y)-3)){
					if(DevNameInf[1].serchFileCnt == 16){	dev_page[1]++;	}
					DevNameInf[1].serchFileCnt= 0;
					serchFileNameProc(1,&DevNameInf[1],"*.*");	//Sys File Search
					DispFileName();
				}
				//DEV2 BEF
				if((xTouch >= 16) && (xTouch <= 20) && (yTouch >= 19) && (yTouch <= 21)){
					if(dev_page[1] > 0){	dev_page[1]--;	}
					DevNameInf[1].serchFileCnt= 0;
					serchFileNameProc(1,&DevNameInf[1],"*.*");	//Sys File Search
					DispFileName();
				}
				//MENU
				if((xTouch >= 21) && (xTouch <= 25) && (yTouch >= (LCD_Y_SIZE/MESH_Y)-3)){
					break;
				}
			}
			UsbHostDrv();
//			MmcSdDrv();
		}
	} /*  end while  */
	ClearDispBuff();
	TouchRepeatFlag= 1;
}
int	LoadProgFile(int idx)
{
	int	rfp;
	int	len;
	char*	ReadBuff;
	int	ret= -1;

	ReadBuff= (char*)APL_PROG_START;
	if(setDriveName(0,ufileName) == -1){	return(ret);	}
	strcat(ufileName,DevNameInf[0].serchFileName[idx]);
	rfp = Fs_open(ufileName,O_RDONLY,S_IREAD);
	if(rfp >= 0){
		while(1){
			len= Fs_read (rfp, ReadBuff,0x10000);
			if(len <= 0){	break;	}
			ReadBuff += 0x10000;
		}
		Fs_close(rfp);
		ret= 0;
	}
	return(ret);
}
int	ProgFileCheck(void)
{
	int	ret= -1;
	int	i;

	fctlDevKind[0]= 3;		//USB HOST
	if(UsbHostConnected == 1){
		while(1){
			DevNameInf[0].serchFileCnt= 0;
			serchFileNameProc(0,&DevNameInf[0],"*.*");
			if(DevNameInf[0].serchFileCnt == 0){	break;	}
			for(i= 0; i < DevNameInf[0].serchFileCnt; i++){
				if( (DevNameInf[0].attribute[i] == 0) &&
					(memcmp(DevNameInf[0].serchFileName[i],"PROG",4) == 0)){		//Program File
					if(LoadProgFile(i) == 0){
						ret= 0;
						break;
					}
				}
			}
			if((ret == 0) || (DevNameInf[0].serchFileCnt < 16)){	break;	}
		}
	}
	return(ret);
}
/////////////////////////////////////////////////////////////////////////////////
void	DispLoadFileName(void)
{
	int	j;

	ClearDispBuff();
	RectAngleNoDraw(0,LCD_Y_SIZE-16*3-1,8*10,LCD_Y_SIZE-1);
	DotTextOutNoDraw(8/8,(LCD_Y_SIZE-16*2)/20,"DV1 CHG");

	RectAngleNoDraw(0,LCD_Y_SIZE-16*6-1,8*10,LCD_Y_SIZE-16*3-1);
	DotTextOutNoDraw(8/8,(LCD_Y_SIZE-16*5)/20,"DV1 DEL");

	RectAngleNoDraw(8*20,LCD_Y_SIZE-16*3-1,8*30,LCD_Y_SIZE-1);
	DotTextOutNoDraw((8+8*20)/8,(LCD_Y_SIZE-16*2)/20,"DV1 NXT");
	RectAngleNoDraw(8*20,LCD_Y_SIZE-16*6-1,8*30,LCD_Y_SIZE-16*3-1);
	DotTextOutNoDraw((8+8*20)/8,(LCD_Y_SIZE-16*5)/20,"DV1 BEF");

	RectAngleNoDraw(LCD_X_SIZE-8*10-1,LCD_Y_SIZE-16*3-1,LCD_X_SIZE-1,LCD_Y_SIZE-1);
	DotTextOutNoDraw((LCD_X_SIZE-8*8)/8,(LCD_Y_SIZE-16*2)/20,"RUN");


	RectAngleNoDraw(8*40,LCD_Y_SIZE-16*3-1,8*50,LCD_Y_SIZE-1);
	DotTextOutNoDraw((8+8*40)/8,(LCD_Y_SIZE-16*2)/20," DEBUG");

	DotTextOutNoDraw( 60/8,40/20,fctlDevName[fctlDevKind[0]]);
	for(j= 0; j < DevNameInf[0].serchFileCnt; j++){
		if(DevNameInf[0].attribute[j] == 0){	//File
			ForGrandColor= GetColorData(T_GREEN);			//WHITE()
			DotTextOutNoDraw( 60/8,(60+j*20)/20,DevNameInf[0].serchFileName[j]);
		}else{									//Directory
			ForGrandColor= GetColorData(T_RED);			//WHITE()
			DotTextOutNoDraw( 60/8,(60+j*20)/20,DevNameInf[0].serchFileName[j]);
		}
		ForGrandColor= GetColorData(T_WHITE);			//WHITE()
		if(DevNameInf[0].Select[j] == 0){
			DotTextOutNoDraw( 44/8,(60+j*20)/20," ");
		}else{
			DotTextOutNoDraw( 44/8,(60+j*20)/20,"*");
		}
	}
	DrawLcd((char *)LcdBuff);
}
int	vFileLoadControl(void)
{
	int	sUsbHostConnected;
	int	iKeyCode;
	int	sTouch;
	int	eTouch;
	int	xTouch;
	int	yTouch;
	int	EndFlag;
	int	ret= -1;
	int	i;

	sUsbHostConnected= UsbHostConnected;
	sTouch= (FILE_START_Y/MESH_Y)*(LCD_X_SIZE/MESH_X)+ 1;
	eTouch= ((FILE_START_Y+16*20)/MESH_Y)*(LCD_X_SIZE/MESH_X);

	fctlDevKind[0]= 3;		//USB
	memset(dev_page,0,sizeof(dev_page));
	EndFlag= 0;
	TouchRepeatFlag= 0;

	while (EndFlag == 0) {

		memset(DevNameInf,0,sizeof(DevNameInf));
		if(UsbHostConnected == 1){
			serchFileNameProc(0,&DevNameInf[0],"*.*");
		}

		DispLoadFileName();
		while(1){
			if(sUsbHostConnected != UsbHostConnected){
				sUsbHostConnected= UsbHostConnected;
				DevNameInf[0].serchFileCnt= 0;
				dev_page[0]= 0;
				if(sUsbHostConnected == 1){	serchFileNameProc(0,&DevNameInf[0],"*.*");	}
				DispLoadFileName();
			}
//			iKeyCode= ScanKey();
			if(iKeyCode > 0){
				xTouch= iKeyCode % (LCD_X_SIZE/MESH_X);
				yTouch= iKeyCode / (LCD_X_SIZE/MESH_X);


				if((iKeyCode >= sTouch) && (iKeyCode <= eTouch)){		//File Select
					xTouch= ((iKeyCode- sTouch) % (LCD_X_SIZE/MESH_X))/((LCD_X_SIZE/MESH_X)/3);
					yTouch= (iKeyCode- sTouch) / (LCD_X_SIZE/MESH_X);
					if(xTouch < 2){
						if(yTouch < DevNameInf[xTouch].serchFileCnt){
							if(DevNameInf[xTouch].Select[yTouch] == 0){
								DevNameInf[xTouch].Select[yTouch]= 1;
								DotTextOut( (44+xTouch*200)/8,(60+yTouch*20)/20,"*");
							}else{
								DevNameInf[xTouch].Select[yTouch]= 0;
								DotTextOut( (44+xTouch*200)/8,(60+yTouch*20)/20," ");
							}
						}
					}
				}
				//Load & Run
				if((xTouch >= (LCD_X_SIZE/MESH_X)-5) && (yTouch >= (LCD_Y_SIZE/MESH_Y)-3)){
					for(i= 0; i < DevNameInf[0].serchFileCnt; i++){
						if(DevNameInf[0].Select[i] != 0){
							DevNameInf[0].Select[i]= 0;
							if(DevNameInf[0].attribute[i] == 1){	continue;	}	//Directory
							ClearDispBuff();
							DotTextOut( 100/8,100/20,"Now Loading");
							ret= LoadProgFile(i);
							break;
						}
					}
					EndFlag= 1;
					break;
				}
				//Disp1 Dir Change
				if((xTouch >= 0) && (xTouch <= 5) && (yTouch >= (LCD_Y_SIZE/MESH_Y)-3)){
					UsbChangeDir(0,&DevNameInf[0]);
					DevNameInf[0].serchFileCnt= 0;
					dev_page[0]= 0;
					serchFileNameProc(0,&DevNameInf[0],"*.*");	//Sys File Search
					DispLoadFileName();
				}
				//File Delete DEV1
				if((xTouch >= 0) && (xTouch <= 5) && (yTouch >= 19) && (yTouch <= 21)){
					UsbDeleteFile(0,&DevNameInf[0]);
					DevNameInf[0].serchFileCnt= 0;
					serchFileNameProc(0,&DevNameInf[0],"*.*");	//Sys File Search
					DispLoadFileName();
				}
				//DEV1 NEXT
				if((xTouch >= 11) && (xTouch <= 15) && (yTouch >= (LCD_Y_SIZE/MESH_Y)-3)){
					if(DevNameInf[0].serchFileCnt == 16){	dev_page[0]++;	}
					DevNameInf[0].serchFileCnt= 0;
					serchFileNameProc(0,&DevNameInf[0],"*.*");	//Sys File Search
					DispLoadFileName();
				}
				//DEV1 BEF
				if((xTouch >= 11) && (xTouch <= 15) && (yTouch >= 19) && (yTouch <= 21)){
					if(dev_page[0] > 0){	dev_page[0]--;	}
					DevNameInf[0].serchFileCnt= 0;
					serchFileNameProc(0,&DevNameInf[0],"*.*");	//Sys File Search
					DispLoadFileName();
				}
				//MENU
				if((xTouch >= 21) && (xTouch <= 25) && (yTouch >= (LCD_Y_SIZE/MESH_Y)-3)){
					ClearDispBuff();
					DotTextOut( 100/8,100/20,"Debugger Start For RS-232C");
					WaitTimeMs(100);
					DubugMain();
//					DotTextOut( 100/8,100/20,"#######################");
//					WaitTimeMs(100);
					DispLoadFileName();
				}
			}
			UsbHostDrv();
			if(IS_CONSOL( ) != 0){
				DubugMain();
			}
		}
	} /*  end while  */
	ClearDispBuff();
	TouchRepeatFlag= 1;
	return(ret);
}
