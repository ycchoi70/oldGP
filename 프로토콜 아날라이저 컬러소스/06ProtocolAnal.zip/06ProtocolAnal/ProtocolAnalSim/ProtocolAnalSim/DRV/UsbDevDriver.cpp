/****************************************************/
/*    FUNC   : USB Device Handler	                */
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 2009.11.07                           */
/*    Update :                                      */
/****************************************************/
#define	USBDEVDRIVER_PROC
#include <string.h>


#include "doscomm.h"
#include "glpdos.h"
#include "doscomm.h"
#include "define.h"
#include "glplcd.h"
#include "commbuff.h"
#include "usbh.h"
#include "s2440.h"
#include "udc_2440.h"
#include "pcmcia.h"
#include "rs232c.h"

#define	USB_SLAVE_DEV	2		//0:USER1,1:USER2,2:SYSTEM

int	_UsbDevDrvTaskNo;
int	UsbSendCnt;
int	UsbRecCnt;
char	udcRBuff[0x100];

UART_STRUCT	_Sci_UsbTbl;

//#ifdef	USB_STRAGE
unsigned char	RespInquiry[36]={
   0x00,                        // Device class
   0x80,                        // RMB BYTE is set by inquiry data
   0x02,                        // ANSI SCSI 2
   0x00,                        // Data format = 0
   0x1F,                        // Additional length 27 byte
   0x00, 0x00, 0x00,
	'A','U','T','O','N','I','C','S',
	'U','S','B',' ','F','l','a','s',
	'h',' ','D','i','s','k',' ',' ',
	' ',' ',' ',' ',
};
unsigned char	Request_sens[18]={
	0,
};
unsigned char	Read_cap[8]={
	//Total Sector(4Byte), Byte/Sector(4Byte)
	0x00,0x00,0x10,0x00,0x00,0x00,0x02,0x00
};
int	write_len= 0;
int	write_reclen;
unsigned char dataBuff[100][0x200];
unsigned char udcWBuff[0x200+32];
unsigned char udcdataWBuff[0x10000+32];

//#endif
int	logIdx;
int	logCnt;
unsigned char	logBuff[128][32];

void	SetSciUsbTbl(void)
{
	memset(&_Sci_UsbTbl,0,sizeof(_Sci_UsbTbl));
	_Sci_UsbTbl.ch= RS_USB;
	
}


void	UsbDevIntEnable(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
//    volatile IOP_REG    *pIOPRegs = (volatile IOP_REG*)IOP_BASE; 
#ifdef	WIN32
	return;
#endif

	pINTRegs->rSRCPND  = BIT_USBD;
	// S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
	if (pINTRegs->rINTPND & BIT_USBD)
		pINTRegs->rINTPND = BIT_USBD;
	pINTRegs->rINTMSK &= ~BIT_USBD;
	
//	pIOPRegs->rEINTMASK &= ~(1<<USB_IRQ);
//	pIOPRegs->rEINTPEND  = (1<<USB_IRQ);		//
}

int	_UsbDevInterruptProc(void)
{
	int	ret;
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

//	pINTRegs->rINTMSK |= BIT_USBD;
	pINTRegs->rSRCPND  = BIT_USBD;
	pINTRegs->rINTPND  = BIT_USBD;

	ret= MS_USB_InterruptHandler();

	pINTRegs->rSRCPND  = BIT_USBD;
	if (pINTRegs->rINTPND & BIT_USBD)
		pINTRegs->rINTPND = BIT_USBD;
//	pINTRegs->rINTMSK &= ~BIT_USBD;
	return(ret);
}
void	_UsbDevInterruptHandler( void )
{

    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_USBD;
	_UsbDevInterruptProc();
	if( CheckUsbRecData() != 0 ){
		UsbDevHandler();
	}
	pINTRegs->rINTMSK &= ~BIT_USBD;
}
void UsbDevHandlerInit(void)
{
	SetSciUsbTbl();

	write_len= 0;
	udc_len= 0;
	write_reclen= 0;
	udc_sect= 0;

logIdx= 0;
logCnt= 0;

}
void	UsbDevHandler( void )
{
#ifdef	USB_STRAGE

	//UDC Send Recieve
	udc_len= GetUsbRcvData(udcRBuff);

	if(write_len == 0){
//log Write
logCnt++;
if((udcRBuff[15] != 0) || (logCnt < 10)){
memcpy(&logBuff[logIdx++][0],udcRBuff,32);
logIdx &= 0x7f;
}
		//Strage Check
		memcpy(udcWBuff,udcRBuff,8);
		udcWBuff[3]= 'S';
		memset(&udcWBuff[8],0,4);		//dCSWDataResidue
		udcWBuff[12]= 0;
		switch(udcRBuff[15]){
		case 0x12:						//INQUIRY
			SetWriteBuffer((unsigned char*)&udcWBuff[0],13);
			IoWrite((unsigned char*)&RespInquiry[0],36);
			break;
		case 0x23:						//Request Sens
			SetWriteBuffer((unsigned char*)&udcWBuff[0],13);
			IoWrite((unsigned char*)&Request_sens[0],12);
			break;
		case 0x25:						// Read Capacity
			SetWriteBuffer((unsigned char*)&udcWBuff[0],13);
			IoWrite((unsigned char*)&Read_cap[0],8);
			break;
		case 0x28:						// READ(10)
			udc_sect= (udcRBuff[17] << 24)+ (udcRBuff[18] << 16)+ (udcRBuff[19] << 8)+ udcRBuff[20];
			udc_slen= ((udcRBuff[22] << 8)+ udcRBuff[23])*512;
			ReadCard(USB_SLAVE_DEV,udc_sect,(unsigned char*)udcdataWBuff,udc_slen);
//			RamReadSector(udc_sect,(unsigned char*)udcdataWBuff,udc_slen);
			memcpy(&udcdataWBuff[udc_slen],udcWBuff,13);
			SetWriteBuffer((unsigned char*)&udcdataWBuff[EP1_PACKET_SIZE],udc_slen-EP1_PACKET_SIZE+13);
			IoWrite((unsigned char*)&udcdataWBuff[0],EP1_PACKET_SIZE);
			break;
		case 0x2a:						//WRITE(10)
			udc_sect= (udcRBuff[17] << 24)+ (udcRBuff[18] << 16)+ (udcRBuff[19] << 8)+ udcRBuff[20];
			udc_slen= ((udcRBuff[22] << 8)+ udcRBuff[23])*512;
			write_len= udc_slen;
			write_reclen= 0;
			if(write_len > 0x10000){	write_len= 0x10000;	}
			break;
		case 0x1a:
			SetWriteBuffer((unsigned char*)&udcWBuff[0],13);
			IoWrite((unsigned char*)&Read_cap[0],8);
			break;
		default:
			IoWrite((unsigned char*)&udcWBuff[0],13);
			break;
		}
	}else{
		memcpy(&udcdataWBuff[write_reclen],&udcRBuff[0],udc_len);
		write_reclen += udc_len;
		if(write_reclen >= write_len){
			WriteCard(USB_SLAVE_DEV,udc_sect,udcdataWBuff,write_len);	//USER1
//			RamWriteSector(udc_sect,udcdataWBuff,write_len);
			write_len= 0;
			IoWrite((unsigned char*)&udcWBuff[0],13);
		}
	}
#else
//	int	i;
//
//	for(i= 0; i < 0x60; i++){
//		udcdataWBuff[i]= ' '+i;
//	}
//	IoWrite((char*)&udcdataWBuff[0],0x40);
//	IoWrite((char*)&udcdataWBuff[0x40],0x20);
	//UDC Send Recieve
	udc_len= GetUsbRcvData(udcRBuff);
	IoWrite((char*)&udcRBuff[0],udc_len);
#endif
}
