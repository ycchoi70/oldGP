/*	Buffer                              */ 
#include	<string.h>
#include	<stdlib.h>
#include	<stdio.h>
// 
#include	"define.h"
#include	"selib.h"
#include	"mylib.h"
#include	"bios.h"
#include	"s2440.h"
#include	"glplcd.h"
#include	"CommBuff.h"
#include	"disp.h"
#include	"rs232c.h"
#include	"lload.h"
#include	"udebtsk.h"
#include	"touch.h"
#include	"usbh.h"
#include	"udc_2440.h"
#include	"flash.h"

/*	Buffer                              */ 

//#ifdef	WIN32
#include    "Mts.h"
#include    "MTSCIFP.h"
#include    "Mail.h"
#include	"Taskhed.h"
//#endif

extern int mTimeStop;
void    observe_start( STTFrm* pSTT )       /* ���C������?�X�N */
{
	int cnt;
	int i;
	int signal;
	char text[50];
	cnt =0;
	TimerInit();
	
	while(1){
		switch(signal){//ReadSignal(1)
		case 1: //TextOut(57,28,"Test Task");
			//Timer Start
			TimerStart(1,3000);
		//	OffSignal(1,1);
			break;
		case 2: //TextOut(57,28,"Observe Task");
			// Timer Stop
			mTimeStop=1;
			cnt = time_data[1];
			if(cnt!=0){cnt = 3000 - cnt;}
			else cnt =0;
			TimerStop(1);
			mTimeStop=0;
		//	OffSignal(1,2);
			break;
		default:
			cnt =0;
		//	OffSignal(1,1);
		//	OffSignal(1,2);
			break;
		}
		
		//display
		sprintf(text, "%3d ms",cnt);
		TextOut(57,28,text);

#ifdef WIN32
		Delay(1000);
#endif
	
	}
}