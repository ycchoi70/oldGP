/************************************************
*  Dos emuration interface functions			*
*				1997,4,22		Ver 1.10		*
************************************************/
#ifdef	WIN32
#include	<direct.h>
#include	<io.h>
#endif
#include	<string.h>

#include	"define.h"
#include	"doscomm.h"
#include	"glpdos.h"

extern	SimDosSystem	System;

/************************************************
*  change current directory						*
************************************************/
#ifdef	WIN32
void	DevnameChange(char* name,char* newname)
{

	if(((name[0] >= 'A') && (name[0] <= 'D')) && (name[1] == ':')){
		switch(name[0]){
		case 'A':
			strcpy(newname,"DEV_A\\");
			break;
		case 'B':
			strcpy(newname,"DEV_B\\");
			break;
		case 'C':
			strcpy(newname,"DEV_C\\");
			break;
		case 'D':
			strcpy(newname,"DEV_D\\");
			break;
		}
		strcat(newname,&name[2]);
	}else{
		strcpy(newname,name);
	}
}
#endif

int	Fs_chdir (char *name)
{
#ifdef	WIN32
	char	newpath[260];
	DevnameChange(name,newpath);
	if (_chdir (newpath) != 0) return -1;	/* error return */
	return 0;								/* normal return */

#else
	if (ChangeDir (name) != 0) return -1;	/* error return */
	return 0;								/* normal return */
#endif
}


/**********************************************************************************
* int open(path, flag, pmode) - open or create a file
*
* Purpose:
*       Opens the file and prepares for subsequent reading or writing.
*       the flag argument specifies how to open the file:
*         O_APPEND -   reposition file ptr to end before every write
*         O_BINARY -   open in binary mode
*         O_CREAT -    create a new file* no effect if file already exists
*         O_EXCL -     return error if file exists, only use with O_CREAT
*         O_RDONLY -   open for reading only
*         O_RDWR -     open for reading and writing
*         O_TEXT -     open in text mode
*         O_TRUNC -    open and truncate to 0 length (must have write permission)
*         O_WRONLY -   open for writing only
*       exactly one of O_RDONLY, O_WRONLY, O_RDWR must be given
*
*       The pmode argument is only required when O_CREAT is specified.  Its
*       flag settings:
*         S_IWRITE -   writing permitted
*         S_IREAD -    reading permitted
*         S_IREAD | S_IWRITE - both reading and writing permitted
*       The current file-permission maks is applied to pmode before
*       setting the permission (see umask).
*
*       Note, the creat() function also uses this function but setting up the
*       correct arguments and calling open(). creat() sets the __creat_flag
*       to 1 prior to calling open() so open() can return correctly. open()
*       returns the file handle in eax in this case.
*
* Entry:
*       const char *path - file name
*       int flag - flags for open()
*       int pmode - permission mode for new files
*
* Exit:
*       returns file handle of open file if successful
*       returns -1 (and sets errno) if fails
*
* Exceptions:
*
*******************************************************************************/
#ifdef	WIN32
//#define	O_APPEND	0x0001		/* reposition file ptr to end before every write */
//#define	O_BINARY	0x0002		/* open in binary mode */
//#define	O_CREAT		0x0004		/* create a new file* no effect if file already exists */
//#define	O_EXCL		0x0008		/* return error if file exists, only use with O_CREAT */
//#define	O_RDONLY	0x0010		/* open for reading only */
//#define	O_RDWR		0x0020		/* open for reading and writing */
//#define	O_TEXT		0x0040		/* open in text mode */
//#define	O_TRUNC		0x0080		/* open and truncate to 0 length (must have write permission) */
//#define	O_WRONLY	0x0100		/* open for writing only */

//#define _O_RDONLY       0x0000  /* open for reading only */
//#define _O_WRONLY       0x0001  /* open for writing only */
//#define _O_RDWR         0x0002  /* open for reading and writing */
//#define _O_APPEND       0x0008  /* writes done at eof */

//#define _O_CREAT        0x0100  /* create and open file */
//#define _O_TRUNC        0x0200  /* open and truncate */
//#define _O_EXCL         0x0400  /* open only if file doesn't already exist */
int	oflagTbl[][2]={
	{0x0001,0x0008},
	{0x0002,0x8000},
	{0x0004,0x8102},		//Creat=(_O_CREAT|_O_RDWR|_O_BINARY)
	{0x0008,0x0400},
	{0x0010,0x8000},		//Read Only=(_O_RDONLY|_O_BINARY);
	{0x0020,0x0002},
	{0x0040,0x4000},
	{0x0080,0x0200},
	{0x0100,0x0001},
};
int	pmodeTbl[][2]={
//#define _S_IREAD        0000400         /* read permission, owner */
//#define _S_IWRITE       0000200         /* write permission, owner */
	{0x0001,0000200 | 0000400},
	{0x0002,0000400 | 0000200},
};

#endif
int	Fs_open (char *path, int oflag, int pmode)
{
	int		channel;
#ifdef	WIN32
	int	i,soflag,spmode;
	char	newpath[260];
//#ifdef	OLD
//	char	buffer[20];
//	char	buffer1[30];
//   int fh;
//   unsigned byteswritten;

//	for(i= 0; i < 20; i++){
//		buffer[i]= i+0x20;
//	}

//   if( (fh = _open( "write.o", _O_RDWR | _O_CREAT | _O_BINARY, 
//                               _S_IREAD | _S_IWRITE )) != -1 )
//   {
//      if(( byteswritten = _write( fh, buffer, sizeof( buffer ))) == -1 )
//			;
//      else
//			;
//      _close( fh );
//   }
//   memset(buffer1,0xff,sizeof(buffer1));
//   if( (fh = _open( "write.o", _O_RDONLY | _O_BINARY )) != -1 )
//   {
//      byteswritten = _read( fh, buffer1, sizeof( buffer1 ));
//      _close( fh );
//   }

//#endif

	for(i= 0; i < TBQ(oflagTbl); i++){
		if(oflagTbl[i][0] == oflag){
			soflag= oflagTbl[i][1];
			break;
		}
	}
	for(i= 0; i < TBQ(pmodeTbl); i++){
		if(pmodeTbl[i][0] == pmode){
			spmode= pmodeTbl[i][1];
			break;
		}
	}
	DevnameChange(path,newpath);
	channel= _open(newpath,soflag,spmode);
#else
	if (oflag & O_TRUNC) {
		channel = File_Open (path, _TRUNC);
		if (channel < 0) return -1;
	}
	else if (oflag & O_CREAT) {				/* create mode */
		channel = File_Open (path, _CREATE);
		if (channel < 0) return -1;
	}
	else if (oflag & O_RDWR) {				/* create mode */
		channel = File_Open (path, _CREATE);
		if (channel < 0) return -1;
	}
	else if (oflag & O_APPEND){				/* update mode */
		channel = File_Open (path, _UPDATE);
		if (channel < 0) return -1;
		channel = File_Open (path, _CREATE);
		if (channel < 0) return -1;
		File_Seek(channel,0,FS_SEEK_END);
	}
	else {								/* exist open mode */
		channel = File_Open (path, _OPEN);
		if (channel < 0) return -1;
	}
	System.iFcb[channel].oflag = oflag;
	System.iFcb[channel].pmode = pmode;
#endif
		return channel;

}


/*******************************************************************************
* int _close(fh) - close a file handle
*
* Purpose:
*       Closes the file associated with the file handle fh.
*
* Entry:
*       int fh - file handle to close
*
* Exit:
*       returns 0 if successful, -1 (and sets errno) if fails
*
* Exceptions:
*
*******************************************************************************/

int	Fs_close (int channel)
{
		if (channel < 0) return -1;
#ifdef	WIN32
		_close(channel);
#else
		File_Close (0,channel);
#endif
		return 0;
}
int	Fs_flush_close (int channel)
{
		if (channel < 0) return -1;
#ifdef	WIN32
		_close(channel);
#else
		File_Close (1,channel);
#endif
		return 0;
}


/*******************************************************************************
* int creat(path, pmode) - create a new file
*
* Purpose:
*       If file specified does not exist, _creat creates a new file
*       with the given permission setting and opens it for writing.
*       If the file already exists and its permission allows writing,
*       creat truncates it to 0 length and open it for writing.
*       The only Xenix mode bit supprted by DOS is user write (S_IWRITE).
*
* Entry:
*       char *path - filename to create
*       int pmode - permission mode setting for new file
*
* Exit:
*       returns handle for created file
*       returns -1 and sets errno if fails.
*
* Exceptions:
*
*******************************************************************************/

int	Fs_creat (char *path, int pmode)
{
	return (Fs_open (path, O_CREAT | O_TRUNC, pmode));
}


/*******************************************************************************
* int read(fh, buf, cnt) - read bytes from a file handle
*
* Purpose:
*       Attempts to read cnt bytes from fh into a buffer.
*       If the file is in text mode, CR-LF's are mapped to LF's, thus
*       affecting the number of characters read.  This does not
*       affect the file pointer.
*
*       NOTE:  The stdio _IOCTRLZ flag is tied to the use of FEOFLAG.
*       Cross-reference the two symbols before changing FEOFLAG's use.
*
* Entry:
*       int fh - file handle to read from
*       char *buf - buffer to read into
*       int cnt - number of bytes to read
*
* Exit:
*       Returns number of bytes read (may be less than the number requested
*       if the EOF was reached or the file is in text mode).
*       returns -1 (and sets errno) if fails.
*
* Exceptions:
*
*******************************************************************************/

int	Fs_read (int channel, char *buff, int rLen)
{
#ifndef	WIN32
	long	pointer;
#endif
	int		status;

		if (channel < 0) return -1;
#ifdef	WIN32
		status= _read(channel,buff,rLen);
#else
		pointer = System.iFcb[channel].CurrentData;
		status = File_Read (channel, buff, rLen, pointer);
#endif
		if (status < 0) return -1;
		return status;
}


/*******************************************************************************
* int write(fh, buf, cnt) - write bytes to a file handle
*
* Purpose:
*       Writes count bytes from the buffer to the handle specified.
*       If the file was opened in text mode, each LF is translated to
*       CR-LF.  This does not affect the return value.  In text
*       mode ^Z indicates end of file.
*
*       Multi-thread notes:
*       (1) _write() - Locks/unlocks file handle
*           _write_lk() - Does NOT lock/unlock file handle
*
* Entry:
*       int fh - file handle to write to
*       char *buf - buffer to write from
*       unsigned int cnt - number of bytes to write
*
* Exit:
*       returns number of bytes actually written.
*       This may be less than cnt, for example, if out of disk space.
*       returns -1 (and set errno) if fails.
*
* Exceptions:
*
*******************************************************************************/

int	Fs_write (int channel, char *buff, int rLen)
{
#ifndef	WIN32
	long	pointer;
#endif
	int		status;

		if (channel < 0) return -1;
#ifdef	WIN32
		status= _write(channel,buff,rLen);
#else
		pointer = System.iFcb[channel].CurrentData;
		status = File_Write (channel, buff, rLen, pointer);
#endif
		if (status < 0) return -1;
		return status;
}


/*******************************************************************************
* unsigned _dos_findfirst(wildspec, finddata) - Find first matching file
*
* Purpose:
*       Finds the first file matching a given wild card filespec and
*       returns data about the file.
*
* Entry:
*       char * wild - file spec optionally containing wild cards
*
*       unsigned attr - file attribute byte used in slecting
*
*				FA_RDONLY	Read-only attribute
*				FA_HIDDEN	Hidden file
*				FA_SYSTEM	System file
*				FA_LABEL	Volume label
*				FA_DIRECT	Directory
*				FA_ARCH		Archive
*
*
*       struct _finddata_t * finddata - structure to receive file data
*
* Exit:
*       Good return:
*       Unique handle identifying the group of files matching the spec
*
*       Error return:
*       Returns -1 and errno is set to error value
*
* Exceptions:
*       None.
*
*******************************************************************************/
#ifdef	WIN32
	long	findfp;
	struct _finddata_t	_finddata;
#endif
int Fs_dos_findfirst(char *wildspec, unsigned attr, struct find_t *finddata)
{
#ifdef	WIN32
	char	newpath[260];
	DevnameChange(wildspec,newpath);
	findfp = _findfirst(newpath, &_finddata);
	if(findfp >= 0){
		finddata->attrib= _finddata.attrib;
		strcpy(finddata->name,_finddata.name);
		finddata->size= _finddata.size;
		finddata->wr_date= _finddata.time_write;
		finddata->wr_time= _finddata.time_write;
		return(0);
	}else{
		return(findfp);
	}
#else
	return Find_First (wildspec, attr, finddata);
#endif
}


/*******************************************************************************
* unsigned _dos_findnext(finddata) - Find next matching file
*
* Purpose:
*       Finds the next file matching a given wild card filespec and
*       returns data about the file.
*
* Entry:
*       hfind - handle from _findfirst
*
*       struct _finddata_t * finddata - structure to receive file data
*
* Exit:
*       Good return:
*       0 if file found
*       -1 if error or file not found
*       errno set
*
* Exceptions:
*       None.
*
*******************************************************************************/

int Fs_dos_findnext(struct find_t *finddata)
{
#ifdef	WIN32
	 int rc= _findnext(findfp, &_finddata);
	 if(rc >= 0){
		finddata->attrib= _finddata.attrib;
		strcpy(finddata->name,_finddata.name);
		finddata->size= _finddata.size;
		finddata->wr_date= _finddata.time_write;
		finddata->wr_time= _finddata.time_write;
	 }
	 return(rc);
#else
	return Find_Next (finddata);
#endif
}


/*******************************************************************************
* int mkdir(path) - make a directory
*
* Purpose:
*       creates a new directory with the specified name
*
* Entry:
*       char *path - name of new directory
*
* Exit:
*       returns 0 if successful
*       returns -1 and sets errno if unsuccessful
*
* Exceptions:
*
*******************************************************************************/

int	Fs_mkdir (char *path)
{
#ifdef	WIN32
		char	newpath[260];
		DevnameChange(path,newpath);
		if (_mkdir(newpath) != 0) return -1;
#else
		if (MakeDirectory (path) != 0) return -1;
#endif
		return 0;
}


/*******************************************************************************
* int rmdir(path) - remove a directory
*
* Purpose:
*       deletes the directory speicifed by path.  The directory must
*       be empty, and it must not be the current working directory or
*       the root directory.
*
* Entry:
*       char *path - directory to remove
*
* Exit:
*       returns 0 if successful
*       returns -1 and sets errno if unsuccessful
*
* Exceptions:
*
*******************************************************************************/

int Fs_rmdir(char *path)
{
#ifdef	WIN32
		char	newpath[260];
		DevnameChange(path,newpath);
		if (_rmdir (newpath) < 0) return -1;
#else
		if (DelDir (path) < 0) return -1;
#endif
		return 0;
}


/*******************************************************************************
* int remove(path) - delete the given file or directory
*
* Purpose:
*       This version deletes the given file because there are no
*       links under OS/2.
*
*
* Entry:
*       char *path -    file to delete
*
* Exit:
*       returns 0 if successful
*       returns -1 and sets errno if unsuccessful
*
* Exceptions:
*
*******************************************************************************/

int Fs_remove (char *path)
{
#ifdef	WIN32
		char	newpath[260];
		DevnameChange(path,newpath);
		if (_unlink ((char *)newpath) < 0) return -1;
#else
		if (Delete ((char *)path) < 0) return -1;
#endif
		return 0;
}


/*******************************************************************************
* int rename(oldname, newname) - rename a file
*
* Purpose:
*       Renames a file to a new name -- no file with new name must
*       currently exist.
*
* Entry:
*       _TSCHAR *oldname -      name of file to rename
*       _TSCHAR *newname -      new name for file
*
* Exit:
*       returns 0 if successful
*       returns not 0 and sets errno if not successful
*
* Exceptions:
*
*******************************************************************************/

int Fs_rename (char *oldname, char *newname)
{
#ifdef	WIN32
		char	new_oldname[260];
		char	new_newname[260];
		DevnameChange(oldname,new_oldname);
		DevnameChange(newname,new_newname);
		if (rename ((char *)oldname, (char *)newname) < 0) return -1;
#else
		if (FileRename ((char *)oldname, (char *)newname) < 0) return -1;
#endif
		return 0;
}

int Fs_search (char *path, int *size)
{
#ifdef	WIN32
		int	handle;
		char	newpath[260];
		DevnameChange(path,newpath);
		handle= _open(newpath,O_RDONLY,S_IREAD);
		if(handle < 0){	return(handle);	}
		*size= _filelength(handle);
		_close(handle);
		return(0);
#else
	return(File_Search (path,size));
#endif
}
int Fs_seek (int channel, int offset, int mode)
{
#ifdef	WIN32
	return(_lseek(channel,offset,mode));
#else
	return(File_Seek(channel,offset,mode));
#endif
}
int	IsDevice(int drv)
{
	return(System.DriveStatus & (1 << drv));			// 20100615 add
}
