/****************************************************/
/*    FUNC   : USB Host Handler		                */
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 2009.11.07                           */
/*    Update :                                      */
/****************************************************/
#define	USB_HOST
#include	"doscomm.h"
#include	"glpdos.h"
#include	"define.h"
#include	"glplcd.h"
#include	"commbuff.h"
#include	"s2440.h"
#include	"usbh.h"
#include	"pcmcia.h"

int	UsbHostConnectProc(void)
{
	int	ret;

	ret= Hcd_DoTransfer();		//USB EDP Initialize
	if(ret == 0){	//OK
		MountFile(DEV_USB_DISK);
	}
	return(ret);
}
void	UsbHostInitial(void)
{
	Hcd_Init();

	UsbHostConnected= 0;
}
int	UsbHostDrv( void )     /* USB HOST�h���C�o�[�X�N */
{
	int	ret;

	ret= Get_Hcd_DeviceConnectInf();
	if(ret != 0){	//Connect
		if(UsbHostConnected == 0){
			Hcd_DeviceConnect();
			UsbHostConnectProc();
			UsbHostConnected= 1;
		}
	}else{									//DisConnect
		if(UsbHostConnected == 1){
			Hcd_DeviceDisConnect();
			DismountFile(DEV_USB_DISK);
			UsbHostConnected= 0;
		}
	}
	return(ret);
}
//unsigned char	dumBuff[0x1000];
int	UsbReadSector(long sector,long datasize,unsigned char*buff)
{
	int	i,retry;
	int	sectCnt;
	int	ret;

//	SetUsbHostSema();
	sectCnt= datasize/512;
	if(datasize%512){	sectCnt++;	}
	for(i= 0; i < sectCnt; i++){
		for(retry= 0; retry < 3; retry++){
			ret= bulk_only_transfer(ST_READ,&buff[i*512],sector+i,1);
			if(ret == 0){	break;	}		//Read OK
		}
		if(ret == 1){	break;	}		//Read Error
	}
//	Delay(3000);
//	ret= bulk_only_transfer(ST_READ,dumBuff,0x3f,1);
//	ResetUsbHostSema();
	return(ret);
}
int	UsbWriteSector(long sector,long datasize,unsigned char*buff)
{
	int	i,retry;
	int	sectCnt;
	int	ret;

//	SetUsbHostSema();
	sectCnt= datasize/512;
	if(datasize%512){	sectCnt++;	}
	for(i= 0; i < sectCnt; i++){
		for(retry= 0; retry < 3; retry++){
			ret= bulk_only_transfer(ST_WRITE,&buff[i*512],sector+i,1);
			if(ret == 0){	break;	}		//OK
		}
		if(ret == 1){	break;	}		//Error
	}
//	ResetUsbHostSema();
	return(ret);
}
