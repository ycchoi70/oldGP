/******************************************************/
/*  �^�X�N�@�w�b�_�[                                  */
/*  1999.8.10                                         */
/******************************************************/
#include	"stdio.h"

#include    "Mts.h"
#include    "MtsCifp.h"
#include    "Mail.h"
#include	"Taskhed.h"


#include	"define.h"
#include	"glplcd.h"
#include	"CommBuff.h"
#include	"bios.h"
#include	"disp.h"

int	_MyCpuNo = 1;			/**/
unsigned streg = 0;
unsigned short exvct = 0;	/* Exception trap Vector Number */


/******************************************************/
/*  Application Task                                  */
/******************************************************/
extern	void    main_start( STTFrm* pSTT );       /* ���C�������^�X�N */
extern	void	observe_start( STTFrm* pSTT);

/******************************************************/
/*  Handler Task                                      */
/******************************************************/
/******************************************************/
/*  Driver Task �@                                    */
/******************************************************/
/******************************************************/
/*  Interrupt�@ �@                                    */
/******************************************************/
#ifdef	WIN32
extern  interrupt   void    _SystemClockInterruptHandler( void );   /* �V�X�e���^�C�} */

#else


#endif
/******************************************************/
/*  STACK�̈�  �@                                    */
/******************************************************/
unsigned char   main_startStack		[   8192];     /* �����������^�X�N */
unsigned char	observe_startStack	[	8192];

STTFrm  _StaticTaskTableUsr[]= {
{ "INIT  TASK    ", T_INIT,       0x10, 0, 0, main_start,      {0,0,0}, main_startStack,		sizeof(main_startStack)		},
{ "OBSERVE   TASK", T_OBSERVE,    0x20, 0, 0, observe_start,   {0,0,0}, observe_startStack,		sizeof(observe_startStack)		},
{ 0, }
};

SMTFrm  _SMT[]= {
    {192, 0x00000100 }, /* �@�Q�T�U�̃��[���� 192��  48KB    */
    { 48, 0x00000400 }, /*   �@�P�j�̃��[����  48��  48KB     */
    { 16, 0x00001000 }, /*   �@�S�j�̃��[����  16��  64KB     */
    {  4, 0x00002000 }, /*   �@�W�j�̃��[�����@ 4��  32KB     */
    {  4, 0x00008000 },	/*   �R�Q�j�̃��[�����@ 4�� 128KB      */
    {  2, 0x00030000 },	/* �P�X�Q�j�̃��[�����@ 2�� 384KB      */
    {  0, 0x00000000 }  /* �I���̂��邵                 �@*/
};

char*  _MailAreaLast;
char   _MailArea[704*1024+(266*32)];

VctFrm  _InterruptVectorTable[]= {
#ifdef	WIN32
    { 0x1f, _SystemClockInterruptHandler  },
#else
    { 0xcc, _SystemClockInterruptHandler  },
#endif
    { 0x00, 0                             }
};
