/*    $ JBOSN : format_fat.c, v 0.1 2003/09/01 $    */

/*
 * Copyright (C) 2003    iBOSN systems
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are not permitted completely.
 *
 */

/*
 * Module Name: format_fat.c
 *
 * Purpose: format the block device to fat 
 */

#include <define.h>
#include <string.h>

//#include <panic.h>
//#include <dev/blockapi.h>

#include "nand.h"


#define BLOCK_SIZE				       1024

int	FalshOffset;



typedef struct _DISK_INFO_
{
    unsigned int      nTotalSector;
    unsigned int      nBytePerSector;

    unsigned short      nCylinders;
    unsigned short      nHead;
    unsigned short      nSector;
    unsigned short      fDisk;
        #define                 DISK_INFO_FLAG_MBR                              (1<<0)
        #define                 DISK_INFO_FLAG_CHS_UNCERTAIN                    (1<<1)
        #define                 DISK_INFO_FLAG_UNFORMATTED                      (1<<2)
}DISK_INFO, *DISK_PINFO;



typedef struct MasterBootRecode {
    unsigned char    checkRoutionOnx86[446];
    struct {
        unsigned char    bootDescriptor;             /* 0x80: bootable device, 0x00: non-bootable */
        unsigned char    firstPartitionSector[3];    /* 1st sector number */
        unsigned char    fileSystemDescriptor;       /* 1:FAT12, 4:FAT16(less than 32MB), 5:�g�� DOS �p?�e�B�V����,
                                               6:FAT16(more 32MB), 0xb:FAT32(more 2GB),
                                               0xc:FAT32 Int32h �g��, 0xe:FAT16 Int32h �g��,
                                               0xf:�g�� DOS �p?�e�B�V������ Int32h �g�� */
        unsigned char    lastPartitionSector[3];
        unsigned char    firstSectorNumbers[4];      /* first sector number (link to BPB sector) */
        unsigned char    numberOfSectors[4];
    }   partitionTable[4];
    unsigned char    sig[2];                         /* 0x55, 0xaa */
}   MBRecode;


MBRecode	MbrRecordData;



//static int hBlockDev;

static int    nTotalSector;
static int	DevKind;

/* Constant definitions */
//#define SECTOR_SIZE     512         /* sector size (bytes) */

#define TEST_BUFFER_BLOCKS      16
#define SECTORS_PER_BLOCK ( BLOCK_SIZE / SECTOR_SIZE )

#define ROM_SIZE1        0x01000000		//16Mb							//DEV_A AREA SIZE
#define ROM_SIZE2        0x02000000		//32Mb							//DEV_B SIZE
#define ROM_SIZE3        0x00a00000		//10Mb							//DEV_C SIZE
#define ROM_SIZE4        0x01000000		//16Mb							//DEV_F SIZE(RAM DISK)
#define ROM_SIZE5        0x00800000		//8Mb							//DEV_G SIZE(RAM DISK)
#define ROM_SIZE6        0x00200000		//2Mb							//DEV_E SIZE(LP_DATA DISK)
//EXTERN unsigned char RamBuf[ROM_SIZE];
//unsigned char RamBuf[ROM_SIZE];

/* Macro definitions */

/* Report a failure message and return a failure error code */

#ifdef BIG_ENDIAN

#define CF_LE_W(v)  ((((v) & 0x00ff) << 8) | (((v) & 0xff00) >> 8))
#define CT_LE_W(v)  ((((v) & 0x00ff) << 8) | (((v) & 0xff00) >> 8))
#define CF_LE_L(v)  ((((v) & 0x0000ff00) <<  8) | (((v) & 0x00ff0000) >> 8) |
                    (((v) & 0x000000ff) << 24) | (((v) & 0xff000000) >> 24))
#define CT_LE_L(v)  ((((v) & 0x0000ff00) <<  8) | (((v) & 0x00ff0000) >> 8) |
                    (((v) & 0x000000ff) << 24) | (((v) & 0xff000000) >> 24))

#else

#define CF_LE_W(v)  v
#define CF_LE_L(v)  v
#define CT_LE_W(v)  v
#define CT_LE_L(v)  v

#endif

/* Mark a cluster in the FAT as bad */

#define mark_sector_bad( sector ) mark_FAT_sector( sector, 0xfff7 )

/* Compute ceil(a/b) */

//inline int
__inline int
cdiv (int a, int b)
{
  return (a + b + 1) / b;
}

/* MS-DOS filesystem structures -- I included them here instead of
   including linux/msdos_fs.h since that doesn't include some fields we
   need */

//#define SECTOR_SIZE     512         /* sector size (bytes) */

#define ATTR_RO         1           /* read-only */
#define ATTR_HIDDEN     2           /* hidden */
#define ATTR_SYS        4           /* system */
#define ATTR_VOLUME     8           /* volume label */
#define ATTR_DIR        16          /* directory */
#define ATTR_ARCH       32          /* archived */

#define ATTR_NONE       0           /* no attribute bits */
#define ATTR_UNUSED     (ATTR_VOLUME | ATTR_ARCH | ATTR_SYS | ATTR_HIDDEN)
    /* attribute bits that are copied "as is" */

#define MSDOS_EXT_SIGN 0x29             /* extended boot sector signature */
#define MSDOS_FAT12_SIGN "FAT12   "     /* FAT12 filesystem signature */
#define MSDOS_FAT16_SIGN "FAT16   "     /* FAT16 filesystem signature */
#define MSDOS_FAT32_SIGN "FAT32   "     /* FAT32 filesystem signature */

#define BOOT_SIGN 0xAA55                /* Boot sector magic number */

struct fat_boot_sector
{
    unsigned char   boot_jump[3];    /* Boot strap short or near jump */
    char            system_id[8];        /* Name - can be used to special case
                                        partition manager volumes */
    unsigned char   sector_size[2];    /* bytes per logical sector */
    unsigned char   cluster_size;    /* sectors/cluster */
    unsigned short  reserved;    /* reserved sectors */
    unsigned char   fats;        /* number of FATs */
    unsigned char   dir_entries[2];    /* root directory entries */
    unsigned char   sectors[2];    /* number of sectors */
    unsigned char   media;        /* media code (unused) */
    unsigned short  fat_length;    /* sectors/FAT */
    unsigned short  secs_track;    /* sectors per track */
    unsigned short  heads;        /* number of heads */
    unsigned long   hidden;        /* hidden sectors (unused) */
    unsigned long   total_sect;    /* number of sectors (if sectors == 0) */
};


struct fat32_boot_sector
{
    struct fat_boot_sector fbs;    /* Shared between plain FAT and FAT32 */

    unsigned long fat32_length;    /* sectors/FAT */
    unsigned short flags;        /* bit 8: fat mirroring, low 4: active fat */
    unsigned char version[2];    /* major, minor filesystem version */
    unsigned long root_cluster;    /* first cluster in root directory */
    unsigned short info_sector;    /* filesystem info sector */
    unsigned short backup_boot;    /* backup boot sector */
    unsigned short RESERVED2[6];    /* Unused */
};

/* XXX: The amount of boot code is different for FAT32 and older FATs */
struct fat_volume_info
{
    unsigned char drive_number;    /* BIOS drive number */
    unsigned char RESERVED;    /* Unused */
    unsigned char ext_boot_sign;    /* 0x29 if fields below exist (DOS 3.3+) */
    unsigned char volume_id[4];    /* Volume ID number */
    char volume_label[11];    /* Volume label */
    char fs_type[8];        /* Typically FAT12, FAT16, or FAT32 */
    /* Boot code comes next, all but 2 bytes to fill up sector */
    /* Boot sign comes last, 2 bytes */
	char	dumy[2];		//2009.02.26
};

struct fat32_boot_fsinfo 
{
    unsigned long reserved1;    /* Nothing as far as I can tell */
    unsigned long signature;    /* 0x61417272L */
    unsigned long free_clusters;    /* Free cluster count.  -1 if unknown */
    unsigned long next_cluster;    /* Most recently allocated cluster.
                   * Unused under Linux. */
    unsigned long reserved2[4];
};

struct msdos_dir_entry
{
    char name[8], ext[3];    /* name and extension */
    unsigned char attr;        /* attribute bits */
    char unused[8];
    unsigned short starthi;
    unsigned short time, date, start;    /* time, date and first cluster */
    unsigned long size;        /* file size (in bytes) */
};

/* The "boot code" we put into the filesystem... it writes a message and
   tells the user to try again.  The last two bytes are the boot sign
   bytes.  On FAT32, it is less than 448 chars */

char dummy_boot_jump[3] = { (char)0xeb, 0x3c, (char)0x90 };

char dummy_boot_code[450] =
  "\x0e"            /* push cs */
  "\x1f"            /* pop ds */
  "\xbe\x5b\x7c"        /* mov si, offset message_txt */
                /* write_msg: */
  "\xac"            /* lodsb */
  "\x22\xc0"            /* and al, al */
  "\x74\x0b"            /* jz key_press */
  "\x56"            /* push si */
  "\xb4\x0e"            /* mov ah, 0eh */
  "\xbb\x07\x00"        /* mov bx, 0007h */
  "\xcd\x10"            /* int 10h */
  "\x5e"            /* pop si */
  "\xeb\xf0"            /* jmp write_msg */
                /* key_press: */
  "\x32\xe4"            /* xor ah, ah */
  "\xcd\x16"            /* int 16h */
  "\xcd\x19"            /* int 19h */
  "\xeb\xfe"            /* foo: jmp foo */
                /* message_txt: */

  "This is not a bootable disk.  Please insert a bootable floppy and\r\n"
  "press any key to try again ... \r\n";

#define MESSAGE_OFFSET 29    /* Offset of message in above code */

/* Global variables - the root of all evil :-) - see these and weep! */

// static char *program_name = "mkdosfs";    /* Name of the program */
// static char *device_name = NULL;    /* Name of the device on which to create the filesystem */
// static int check = FALSE;    /* Default to no readablity checking */
// static int verbose = FALSE;    /* Default to verbose mode off */
// static long volume_id;        /* Volume ID number */
// //static time_t create_time;    /* Creation time */
//static char VolumeName[] = "MSDOS5.0"; /* Volume name */
static int gBlocks;        /* Number of blocks in filesystem */
// static int badblocks = 0;    /* Number of bad blocks in the filesystam */
static int gnFat = 2;        /* Default number of FATs to produce */
static int gFatType = 0;    /* Size in bits of FAT entries */
static int gFatLength = 0;    /* Size of the FAT */
// static int dev = -1;        /* FS block device file handle */
// static unsigned int currently_testing = 0;    /* Block currently being tested (if autodetect bad blocks) */
static struct fat32_boot_sector bs;    /* Boot sector data */
static struct fat_volume_info vi;    /* Volume info */
// //static unsigned char *fsinfo_sector = NULL; /* FAT32 signature sector */
static int gStartDataSector;    /* Sector number for the start of the data area */
//static int gStartDataBlock;    /* Block number for the start of the data area */
// static int block_size = BLOCK_SIZE;    /* Size of a block */
//static unsigned char *fat;    /* File allocation table */
//static struct msdos_dir_entry *root_dir;    /* Root directory */
static int gSizeRootDir;    /* Size of the root directory in bytes */
static int gnSecotorPerCluster = 0;    /* Number of sectors per disk cluster */
static int gnRootDirEntry = 0;    /* Number of root directory entries */
// //static char blank_sector[SECTOR_SIZE];    /* Blank sector - all zeros */
static char TempSector[SECTOR_SIZE];    /* TempSector - all zeros */


/* Function prototype definitions */

// static void MarkFatCluster (unsigned char* pByte, int cluster, unsigned int value);
// static void mark_FAT_sector (int sector, unsigned int value);
// static long DoCheck (char *buffer, int try, unsigned int current_block);
// static void alarm_intr (int alnum);
// static void CheckBlocks (void);
// static void get_list_blocks (char *filename);
// static int valid_offset (int fd, int offset);
// static int count_blocks (char *filename);
// //static void check_mount (char *device_name);
// static void establish_params (int device_num);
// static void setup_tables (void);
// static void write_tables (void);


// /* The function implementations */
// 
// /* Handle the reporting of fatal errors.  Volatile to let gcc know that this doesn't return */
 
void	MakeMbRecord(int drv)
{
	int	ToatalSect;
	int	i;
	memset(&MbrRecordData,0,sizeof(MbrRecordData));
	
	MbrRecordData.partitionTable[0].bootDescriptor= 0;				//Non bootable
	MbrRecordData.partitionTable[0].firstPartitionSector[0]= 0x00;		//Start Partition Sector
	MbrRecordData.partitionTable[0].firstPartitionSector[1]= 0x00;		//Start Partition Sector
	MbrRecordData.partitionTable[0].fileSystemDescriptor= 0x04;		//FAT16(less than 32MB)
	MbrRecordData.partitionTable[0].firstSectorNumbers[0]= 1;		//Boot Sector No
	switch(drv){
	case DEV_USER1_DISK:	ToatalSect= ROM_SIZE1/SECTOR_SIZE;	break;
	case DEV_USER2_DISK:	ToatalSect= ROM_SIZE2/SECTOR_SIZE;	break;
	case DEV_SYS_DISK:		ToatalSect= ROM_SIZE3/SECTOR_SIZE;	break;
	case DEV_USER3_DISK:	ToatalSect= ROM_SIZE6/SECTOR_SIZE;	break;
	case DEV_RAM_DISK:		ToatalSect= ROM_SIZE4/SECTOR_SIZE;	break;
	case DEV_PTN_DISK:		ToatalSect= ROM_SIZE5/SECTOR_SIZE;	break;
	}
	for(i= 0; i < 4; i++){
		MbrRecordData.partitionTable[0].numberOfSectors[i]= ToatalSect % 0x100;
		ToatalSect >>= 8;
	}
	MbrRecordData.partitionTable[0].lastPartitionSector[0]= MbrRecordData.partitionTable[0].numberOfSectors[0]; 
	MbrRecordData.partitionTable[0].lastPartitionSector[1]= MbrRecordData.partitionTable[0].numberOfSectors[1]; 
	MbrRecordData.partitionTable[0].lastPartitionSector[2]= MbrRecordData.partitionTable[0].numberOfSectors[2]; 
	MbrRecordData.sig[0]= 0x55;
	MbrRecordData.sig[1]= 0xaa;
}


/* Mark the specified cluster as having a particular value */

static void
MarkFatCluster (unsigned char* pFat, int cluster, unsigned int value)
{
    if (gFatType == 16)
    {
        value &= 0xffff;
        pFat[2 * cluster] = (unsigned char) (value & 0x00ff);
        pFat[(2 * cluster) + 1] = (unsigned char) (value >> 8);
    }
    else
    if (gFatType == 32)
    {
        value &= 0xfffffff;
        pFat[4 * cluster] =       (unsigned char)  (value & 0x000000ff);
        pFat[(4 * cluster) + 1] = (unsigned char) ((value & 0x0000ff00) >> 8);
        pFat[(4 * cluster) + 2] = (unsigned char) ((value & 0x00ff0000) >> 16);
        pFat[(4 * cluster) + 3] = (unsigned char) ((value & 0xff000000) >> 24);
    }
    else
    {
        value &= 0x0fff;
        if( ((cluster * 3) & 0x1) == 0 )
        {
            pFat[3 * cluster / 2] = (unsigned char) (value & 0x00ff);
            pFat[(3 * cluster / 2) + 1] = (unsigned char) ((pFat[(3 * cluster / 2) + 1] & 0x00f0)
                                                        | ((value & 0x0f00) >> 8));
        }
        else
        {
            pFat[3 * cluster / 2] = (unsigned char) ((pFat[3 * cluster / 2] & 0x000f) | ((value & 0x000f) << 4));
            pFat[(3 * cluster / 2) + 1] = (unsigned char) ((value & 0x0ff0) >> 4);
        }
    }
}

// 
// /* Mark a specified sector as having a particular value in it's FAT entry */
// 
// static void
// mark_FAT_sector (int sector, unsigned int value)
// {
//   int cluster;
// 
//   cluster = (sector - gStartDataSector) / (int) (bs.fbs.cluster_size);
//   if (cluster < 0)
//     kprintf("Invalid cluster number in mark_FAT_sector: probably bug!");
// 
//   MarkFatCluster (cluster, value);
// }
// 
// 
// /* Perform a test on a block.  Return the number of blocks that could be read successfully */
// 
// static long
// DoCheck (char *buffer, int try, unsigned int current_block)
// {
//     long got;
// 
//     /* Seek to the correct location */
//     if( lseek (dev, current_block * block_size, SEEK_SET) != current_block * block_size )
//         kprintf ("seek failed during testing for blocks");
//     
//     got = read (dev, buffer, try * block_size);    /* Try reading! */
//     if( got < 0 )
//         got = 0;
//     
//     if( got & (block_size - 1) )
//         kprintf ("Unexpected values in DoCheck: probably bugs\n");
// 
//     got /= block_size;
//     
//     return got;
// }
// 
// 
// /* Alarm clock handler - display the status of the quest for bad blocks!  Then retrigger the alarm for five senconds
//    later (so we can come here again) */
// 
// static void
// alarm_intr (int alnum)
// {
//   if (currently_testing >= gBlocks)
//     return;
// 
//   signal (SIGALRM, alarm_intr);
//   alarm (5);
//   if (!currently_testing)
//     return;
// 
//   kprintf ("%d... ", currently_testing);
//   fflush (stdout);
// }
// 
// 
// static void
// CheckBlocks (void)
// {
//     int try, got;
//     int i;
//     static char blkbuf[BLOCK_SIZE * TEST_BUFFER_BLOCKS];
//     
//     if (verbose)
//     {
//         kprintf ("Searching for bad blocks ");
//         fflush (stdout);
//     }
//     currently_testing = 0;
//     if (verbose)
//     {
//         signal (SIGALRM, alarm_intr);
//         alarm (5);
//     }
//     try = TEST_BUFFER_BLOCKS;
//     while (currently_testing < gBlocks)
//     {
//         if( currently_testing + try > gBlocks )
//             try = gBlocks - currently_testing;
//         got = DoCheck (blkbuf, try, currently_testing);
//         currently_testing += got;
//         if (got == try)
//         {
//             try = TEST_BUFFER_BLOCKS;
//             continue;
//         }
//         else
//             try = 1;
// 
//         if( currently_testing < gStartDataBlock )
//             kprintf ("bad blocks before data-area: cannot make fs");
//     
//         for (i = 0; i < SECTORS_PER_BLOCK; i++)    /* Mark all of the sectors in the block as bad */
//             mark_sector_bad (currently_testing * SECTORS_PER_BLOCK + i);
// 
//         badblocks++;
//         currently_testing++;
//     }
//     
//     if(verbose)
//         kprintf ("\n");
//     
//     if(badblocks)
//         kprintf ("%d bad block%s\n", badblocks, (badblocks > 1) ? "s" : "");
// }
// 
// 
// static void
// get_list_blocks (char *filename)
// {
//   int i;
//   FILE *listfile;
//   unsigned long blockno;
// 
//   listfile = fopen (filename, "r");
//   if (listfile == (FILE *) NULL)
//     kprintf ("Can't open file of bad blocks");
// 
//   while (!feof (listfile))
//     {
//       fscanf (listfile, "%ld\n", &blockno);
//       for (i = 0; i < SECTORS_PER_BLOCK; i++)    /* Mark all of the sectors in the block as bad */
//     mark_sector_bad (blockno * SECTORS_PER_BLOCK + i);
//       badblocks++;
//     }
//   fclose (listfile);
// 
//   if (badblocks)
//     kprintf ("%d bad block%s\n", badblocks,
//         (badblocks > 1) ? "s" : "");
// }
// 
// 
// /* Given a file descriptor and an offset, check whether the offset is a valid offset for the file - return FALSE if it
//    isn't valid or TRUE if it is */
// 
// static int
// valid_offset (int fd, int offset)
// {
//   char ch;
// 
//   if (lseek (fd, offset, 0) < 0)
//     return FALSE;
//   if (read (fd, &ch, 1) < 1)
//     return FALSE;
//   return TRUE;
// }
// 
// 
// /* Given a filename, look to see how many blocks of BLOCK_SIZE are present, returning the answer */
// 
// static int
// count_blocks (char *filename)
// {
//   unsigned long high, low;
//   int fd;
// 
//   if ((fd = open (filename, O_RDONLY)) < 0)
//     {
//       perror (filename);
//       exit (1);
//     }
//   low = 0;
// 
//   for (high = 1; valid_offset (fd, high); high *= 2)
//     low = high;
//   while (low < high - 1)
//     {
//       const int mid = (low + high) / 2;
// 
//       if (valid_offset (fd, mid))
//     low = mid;
//       else
//     high = mid;
//     }
//   valid_offset (fd, 0);
//   close (fd);
// 
//   return (low + 1) / BLOCK_SIZE;
// }
// 
// 
// ///* Check to see if the specified device is currently mounted - abort if it is */
// //
// //static void
// //check_mount (char *device_name)
// //{
// //  FILE *f;
// //  struct mntent *mnt;
// //
// //  if ((f = setmntent (MOUNTED, "r")) == NULL)
// //    return;
// //  while ((mnt = getmntent (f)) != NULL)
// //    if (strcmp (device_name, mnt->mnt_fsname) == 0)
// //      kprintf ("%s contains a mounted file system.");
// //  endmntent (f);
// //}


/* Establish the geometry and media parameters for the device */

static void
EstablishParams( int drv )
{
    //struct hd_geometry geometry;
    //struct floppy_struct param;
    
    DISK_INFO       DiskInfo;
    int nSector;
    
    //if ((device_num & 0xff00) == 0x0200)    /* Is this a floppy diskette? */
    //{
    //    if (ioctl (dev, FDGETPRM, &param))    /*  Can we get the diskette geometry? */
    //        kprintf ("unable to get diskette geometry for '%s'");
    //
    //    bs.fbs.secs_track = param.sect;    /*  Set up the geometry information */
    //    bs.fbs.heads = param.head;
    //    switch (param.size)    /*  Set up the media descriptor byte */
    //    {
    //    case 720:        /* 5.25", 2, 9, 40 - 360K */
    //        bs.fbs.media = (char) 0xfd;
    //        bs.fbs.cluster_size = (char) 2;
    //        bs.fbs.dir_entries[0] = (char) 112;
    //        bs.fbs.dir_entries[1] = (char) 0;
    //        break;
    //
    //    case 1440:        /* 3.5", 2, 9, 80 - 720K */
    //        bs.fbs.media = (char) 0xf9;
    //        bs.fbs.cluster_size = (char) 2;
    //        bs.fbs.dir_entries[0] = (char) 112;
    //        bs.fbs.dir_entries[1] = (char) 0;
    //        break;
    //
    //    case 2400:        /* 5.25", 2, 15, 80 - 1200K */
    //        bs.fbs.media = (char) 0xf9;
    //        bs.fbs.cluster_size = (char) 1;
    //        bs.fbs.dir_entries[0] = (char) 224;
    //        bs.fbs.dir_entries[1] = (char) 0;
    //        break;
    //    
    //    case 5760:        /* 3.5", 2, 36, 80 - 2880K */
    //        bs.fbs.media = (char) 0xf0;
    //        bs.fbs.cluster_size = (char) 2;
    //        bs.fbs.dir_entries[0] = (char) 224;
    //        bs.fbs.dir_entries[1] = (char) 0;
    //        break;
    //    
    //    case 2880:        /* 3.5", 2, 18, 80 - 1440K */
    //    default:        /* Anything else */
    //        bs.fbs.media = (char) 0xf0;
    //        bs.fbs.cluster_size = (char) 1;
    //        bs.fbs.dir_entries[0] = (char) 224;
    //        bs.fbs.dir_entries[1] = (char) 0;
    //        break;
    //    }
    //}
    //else
    ///* Must be a hard disk then! */
    {
        /* Can we get the drive geometry? (Note I'm not too sure about */
        /* whether to use HDIO_GETGEO or HDIO_REQ) */
        //if (ioctl (dev, HDIO_GETGEO, &geometry))
        //    kprintf ("unable to get drive geometry for '%s'");
		switch(drv){
		case DEV_USER1_DISK:	DiskInfo.nTotalSector = ROM_SIZE1/SECTOR_SIZE;	break;
		case DEV_USER2_DISK:	DiskInfo.nTotalSector = ROM_SIZE2/SECTOR_SIZE;	break;
		case DEV_SYS_DISK:		DiskInfo.nTotalSector = ROM_SIZE3/SECTOR_SIZE;	break;
		case DEV_USER3_DISK:	DiskInfo.nTotalSector = ROM_SIZE6/SECTOR_SIZE;	break;
		case DEV_RAM_DISK:		DiskInfo.nTotalSector = ROM_SIZE4/SECTOR_SIZE;	break;
		case DEV_PTN_DISK:		DiskInfo.nTotalSector = ROM_SIZE5/SECTOR_SIZE;	break;
		}
		DiskInfo.nHead = 0;

		gBlocks = DiskInfo.nTotalSector / SECTORS_PER_BLOCK;

        bs.fbs.secs_track = DiskInfo.nTotalSector;    /* Set up the geometry information */
        bs.fbs.heads = DiskInfo.nHead;
        bs.fbs.media = (char) 0xf8; /* Set up the media descriptor for a hard drive */
        bs.fbs.dir_entries[0] = (char) 0;    /* Default to 512 entries */
        bs.fbs.dir_entries[1] = (char)((gFatType == 32) ? 0 : 2);    /* No limits on FAT32 root directory */
        if( gFatType == 32 )
        {
            /* This follows what Microsoft's format command does for FAT32 */
            nSector = gBlocks * SECTORS_PER_BLOCK;
            bs.fbs.cluster_size = (nSector >= 524288) ? 8 : 1;
        }
        else
        {
            bs.fbs.cluster_size = (char) 4; /* Start at 4 sectors per cluster */
        }
    }

    return;
}


/* Create the filesystem data tables */
static void
SetupTables_BootSector( void )
{
    int     cluster_count = 0;
    int     i;
    unsigned int    fatlength12, fatlength16, fatlength32;
    unsigned int    maxclust12, maxclust16, maxclust32;
    unsigned int    clust12, clust16, clust32;
    int     fatdata;            /* Sectors for FATs + data area */
    int     maxclustsize;
    
    strcpy (bs.fbs.system_id, "MSDOS5.0");
    if (gnSecotorPerCluster)
        bs.fbs.cluster_size = (char) gnSecotorPerCluster;

    if (gnRootDirEntry && gFatType != 32)
    {
        bs.fbs.dir_entries[0] = (char) (gnRootDirEntry & 0x00ff);
        bs.fbs.dir_entries[1] = (char) ((gnRootDirEntry & 0xff00) >> 8);
    }
    else
        gnRootDirEntry = bs.fbs.dir_entries[0] + (bs.fbs.dir_entries[1] << 8);
    
    vi.volume_id[0] = (unsigned char) 'A';//(volume_id & 0x000000ff);
    vi.volume_id[1] = (unsigned char) 'U';//((volume_id & 0x0000ff00) >> 8);
    vi.volume_id[2] = (unsigned char) 'T';//((volume_id & 0x00ff0000) >> 16);
    vi.volume_id[3] = (unsigned char) 'N';//(volume_id >> 24);
    
	switch(DevKind){
	case DEV_USER1_DISK:
		memcpy(vi.volume_label, "DATA_DISK  ", 11);
		break;
	case DEV_USER2_DISK:
		memcpy(vi.volume_label, "GP/LP_DISK ", 11);
		break;
	case DEV_SYS_DISK:
		memcpy(vi.volume_label, "SYSTEM_DISK", 11);
		break;
	case DEV_USER3_DISK:
		memcpy(vi.volume_label, "LPDATA_DISK", 11);
		break;
	case DEV_RAM_DISK:
		memcpy(vi.volume_label, "RAM_DISK   ", 11);
		break;
	case DEV_PTN_DISK:
		memcpy(vi.volume_label, "RAM_PT_DISK", 11);
		break;
	}
	memcpy(bs.fbs.boot_jump, dummy_boot_jump, 3);
    
    i = SECTOR_SIZE - sizeof(struct fat_volume_info) - ((gFatType == 32) ? 
                    sizeof(struct fat32_boot_sector) : sizeof(struct fat_boot_sector));
    dummy_boot_code[i-2] = BOOT_SIGN & 0xff;
    dummy_boot_code[i-1] = (char)(BOOT_SIGN >> 8);
    
    bs.fbs.sector_size[0] = (char) (SECTOR_SIZE & 0x00ff);
    bs.fbs.sector_size[1] = (char) ((SECTOR_SIZE & 0xff00) >> 8);
    bs.fbs.reserved = (gFatType == 32) ? 32 : 1;
    bs.fbs.fats = (char) gnFat;
    nTotalSector = gBlocks * SECTORS_PER_BLOCK;
    if (nTotalSector >= 65536)
    {
        bs.fbs.sectors[0] = (char) 0;
        bs.fbs.sectors[1] = (char) 0;
        bs.fbs.total_sect = nTotalSector;
    }
    else
    {
        bs.fbs.sectors[0] = (char) (nTotalSector & 0x00ff);
        bs.fbs.sectors[1] = (char) ((nTotalSector & 0xff00) >> 8);
        bs.fbs.total_sect = 0;
    }
    bs.fbs.hidden = 0;
    
    fatdata = nTotalSector - bs.fbs.reserved;
    
    /* XXX: If we ever change to automatically create FAT32 partitions
    * without forcing the user to specify it, this will have to change */
    if (gFatType != 32)
    {
        fatdata -= cdiv (gnRootDirEntry * 32, SECTOR_SIZE);
    }
    
    if (gnSecotorPerCluster)
    {
        bs.fbs.cluster_size = maxclustsize = gnSecotorPerCluster;
    }
    else
    {
        /* An initial guess for bs.fbs.cluster_size should already be set */
        maxclustsize = 128;
    }
    
    do
    {
//        clust12 = (long long) fatdata *SECTOR_SIZE / ((int) bs.fbs.cluster_size * SECTOR_SIZE + 3);
        clust12 = (unsigned int)((__int64) fatdata *SECTOR_SIZE / ((int) bs.fbs.cluster_size * SECTOR_SIZE + 3));
        fatlength12 = cdiv ((clust12 * 3 + 1) >> 1, SECTOR_SIZE);
        maxclust12 = (fatlength12 * 2 * SECTOR_SIZE) / 3;
        if (maxclust12 > 4086)
            maxclust12 = 4086;
        if (clust12 > maxclust12)
            clust12 = 0;
    
//        clust16 = (long long) fatdata *SECTOR_SIZE / ((int) bs.fbs.cluster_size * SECTOR_SIZE + 4);
        clust16 = (unsigned int)((__int64) fatdata *SECTOR_SIZE / ((int) bs.fbs.cluster_size * SECTOR_SIZE + 4));
        fatlength16 = cdiv (clust16 * 2, SECTOR_SIZE);
        maxclust16 = (fatlength16 * SECTOR_SIZE) / 2;
        if (maxclust16 > 65526)
            maxclust16 = 65526;
        if (clust16 > maxclust16)
            clust16 = 0;
    
//        clust32 = (long long) fatdata *SECTOR_SIZE /((int) bs.fbs.cluster_size * SECTOR_SIZE + 4);
        clust32 = (unsigned int)((__int64) fatdata *SECTOR_SIZE /((int) bs.fbs.cluster_size * SECTOR_SIZE + 4));
        fatlength32 = cdiv (clust32 * 4, SECTOR_SIZE);
        maxclust32 = (fatlength32 * SECTOR_SIZE) / 4;
        if (maxclust32 > 0xffffff6)
            maxclust32 = 0xffffff6;
        if (clust32 > maxclust32)
            clust32 = 0;
    
        if( (clust12 && (gFatType == 12 || gFatType == 0)) ||
            (clust16 && (gFatType == 16 || gFatType == 0)) ||
            (clust32 && (gFatType == 32)))
        {
            break;
        }
    
        bs.fbs.cluster_size <<= 1;
    }while( bs.fbs.cluster_size <= maxclustsize );
    
    /* Use the optimal FAT size */
    /* XXX: Force use of clust32 if specified on command line */
    if( !gFatType )
        gFatType = (clust16 > clust12) ? 16 : 12;
    
    switch (gFatType)
    {
    case 12:
        cluster_count = clust12;
        gFatLength = bs.fbs.fat_length = fatlength12;
        memcpy(vi.fs_type, MSDOS_FAT12_SIGN, 8);
        break;
    
    case 16:
        cluster_count = clust16;
        gFatLength = bs.fbs.fat_length = fatlength16;
        memcpy(vi.fs_type, MSDOS_FAT16_SIGN, 8);
        break;
    
    case 32:
        cluster_count = clust32;
        bs.fbs.fat_length = 0;
        gFatLength = bs.fat32_length = fatlength32;
        bs.flags = 0;
        bs.version[0] = 0;
        bs.version[1] = 0;
        bs.root_cluster = 2 /* XXX: ? */;
        bs.info_sector = 1;
        bs.backup_boot = 6;
        memset(&bs.RESERVED2, 0, sizeof(bs.RESERVED2));
        memcpy(vi.fs_type, MSDOS_FAT32_SIGN, 8);
        break;
    
    default:
		break;
//        kprintf("FAT not 12, 16, or 32 bits\n");
    }
    
    vi.ext_boot_sign = MSDOS_EXT_SIGN;
    
    if (!cluster_count)
    {
//        if (gnSecotorPerCluster)    /* If yes, kprintf if we'd spec'd sectors per cluster */
//            kprintf ("Too many clusters for file system - try more sectors per cluster");
//        else
//            kprintf ("Attempting to create too large a file system");
    }

    gStartDataSector = (int) (bs.fbs.reserved) + gnFat * gFatLength;
//    gStartDataBlock = (gStartDataSector + SECTORS_PER_BLOCK - 1) / SECTORS_PER_BLOCK;

//    if (gBlocks < gStartDataBlock + 32)    /* Arbitrary undersize file system! */
//        kprintf ("Too few blocks for viable file system");
    
    //if (verbose)
    //{
    //    kprintf("%s has %d head%s and %d sector%s per track,\n", 
    //            device_name, bs.fbs.heads, (bs.fbs.heads != 1) ? "s" : "",
    //            bs.fbs.secs_track, (bs.fbs.secs_track != 1) ? "s" : ""); 
    //    kprintf("using 0x%02x media descriptor, with %d sectors;\n", (int) (bs.fbs.media), nTotalSector);
    //    kprintf("file system has %d %d-bit FAT%s and %d sector%s per cluster.\n",
    //    (int) (bs.fbs.fats), gFatType, (bs.fbs.fats != 1) ? "s" : "",
    //    (int) (bs.fbs.cluster_size), (bs.fbs.cluster_size != 1) ? "s" : "");
    //    kprintf ("FAT size is %d sector%s, and provides %d cluster%s.\n",
    //    gFatLength, (gFatLength != 1) ? "s" : "",
    //    cluster_count, (cluster_count != 1) ? "s" : "");
    //    if (gFatType != 32)
    //    {
    //        kprintf ("Root directory contains %d slots.\n",
    //        (int) (bs.fbs.dir_entries[0]) + (int) (bs.fbs.dir_entries[1]) * 256);
    //    }
    //        kprintf ("Volume ID is %08lx, ", volume_id);
    //    if ( strcmp(VolumeName, "           ") )
    //        kprintf("volume label %s.\n", VolumeName);
    //    else
    //        kprintf("no volume label.\n");
    //}

}


/* Create the filesystem data tables */
static void
SetupTables_Fat( unsigned char* pFat )
{
        
//    /* Make the file allocation tables! */
//    if( (fat = (unsigned char *) malloc (gFatLength * SECTOR_SIZE)) == NULL )
//        kprintf ("unable to allocate space for FAT image in memory");
//
//    memset(fat, 0, gFatLength * SECTOR_SIZE);
    
    memset( pFat, 0, SECTOR_SIZE );

    MarkFatCluster (pFat, 0, 0xfffffff);    /* Initial fat entries */
    MarkFatCluster (pFat, 1, 0xfffffff);

    /* XXX: Not sure about this one */
    if (gFatType == 32) 
    {
        MarkFatCluster (pFat, 2, 0xffffff8);
    }
    pFat[0] = (unsigned char) bs.fbs.media;    /* Put media type in first byte! */
    
    /* Make the root directory entries */
    if (gFatType == 32)
    {
        gSizeRootDir = bs.fbs.cluster_size * SECTOR_SIZE;
    }
    else
    {
        gSizeRootDir = 
            ((int) (bs.fbs.dir_entries[1]) * 256 + (int) (bs.fbs.dir_entries[0])) * sizeof (struct msdos_dir_entry);
    }
}


/* Create the filesystem data tables */
static void
SetupTables_RootDir( struct msdos_dir_entry *root_dir )
{
//    root_dir = (struct msdos_dir_entry *) malloc (gSizeRootDir);
//    if (root_dir == NULL)
//    {
//        free (fat);        /* Tidy up before we kprintf! */
//        kprintf ("unable to allocate space for root directory in memory");
//    }

    memset( root_dir, 0, SECTOR_SIZE );
    //memset(root_dir, 0, gSizeRootDir);
    //if ( memcmp(VolumeName, "           ", 11) != 0 )
    //{
//        memcpy(root_dir[0].name, VolumeName, 11);


		switch(DevKind){
		case DEV_USER1_DISK:
			memcpy(root_dir[0].name, "DATA_DISK  ", 11);
			break;
		case DEV_USER2_DISK:
			memcpy(root_dir[0].name, "GP/LP_DISK ", 11);
			break;
		case DEV_SYS_DISK:
			memcpy(root_dir[0].name, "SYSTEM_DISK", 11);
			break;
		case DEV_USER3_DISK:
			memcpy(root_dir[0].name, "LPDATA_DISK", 11);
			break;
		case DEV_RAM_DISK:
			memcpy(root_dir[0].name, "RAM_DISK   ", 11);
			break;
		case DEV_PTN_DISK:
			memcpy(root_dir[0].name, "RAM_PT_DISK", 11);
			break;
		}
        root_dir[0].attr = ATTR_VOLUME;
        //ctime = localtime(&create_time);
        root_dir[0].time = 0;//(unsigned short)((ctime->tm_sec >> 1) + (ctime->tm_min << 5) + (ctime->tm_hour << 11));
        root_dir[0].date = 0;//(unsigned short)(ctime->tm_mday + ((ctime->tm_mon+1) << 5) + ((ctime->tm_year-80) << 9));
        root_dir[0].starthi = 0;
        root_dir[0].start = 0;
        root_dir[0].size = 0;
    //}
    
    //memset(TempSector, 0, SECTOR_SIZE);
}


/* Create the filesystem data tables */
static void
SetupTables_FsInfo( unsigned char *fsinfo_sector )
{
    if (gFatType == 32)
    {
        unsigned long clusters, fat_clusters;
    
        //fsinfo_sector = malloc(SECTOR_SIZE);
        //if (fsinfo_sector == NULL) 
        //{
        //    kprintf ("unable to allocate space for fsinfo sector in memory");
        //}
        memset(fsinfo_sector, 0, SECTOR_SIZE);
        fsinfo_sector[0] = 'R';
        fsinfo_sector[1] = 'R';
        fsinfo_sector[2] = 'a';
        fsinfo_sector[3] = 'A';
    
        fsinfo_sector[0x1e4] = 'r';
        fsinfo_sector[0x1e5] = 'r';
        fsinfo_sector[0x1e6] = 'A';
        fsinfo_sector[0x1e7] = 'a';
    
        clusters = (nTotalSector - gStartDataSector) / bs.fbs.cluster_size;
        fat_clusters = gFatLength * SECTOR_SIZE * 8 / 32;
    
        if (clusters+2 > fat_clusters)
            clusters = fat_clusters - 2;
    
        fsinfo_sector[0x1e8] = (unsigned char)(clusters & 0xff);
        fsinfo_sector[0x1e9] = (unsigned char)((clusters & 0xff00) >> 8);
        fsinfo_sector[0x1ea] = (unsigned char)((clusters & 0xff0000) >> 16);
        fsinfo_sector[0x1eb] = (unsigned char)((clusters & 0xff000000) >> 24);
        fsinfo_sector[0x1ec] = 0x02;
        fsinfo_sector[0x1ed] = 0x00;
        fsinfo_sector[0x1ee] = 0x00;
        fsinfo_sector[0x1ef] = 0x00;
    
        fsinfo_sector[0x1fe] = BOOT_SIGN & 0xff;
        fsinfo_sector[0x1ff] = BOOT_SIGN >> 8;
    }
}


/* Write the new filesystem's data tables to disk
 * XXX: This should take care of swapping issues as it writes them
 */

static void
WriteTables( int drv )
{
//    int x, n, i;
    int x, i;
	unsigned int wAddress;

    struct msdos_dir_entry *root_dir;

    int   SaveiSector = 0;
    int   iSector = 0;

    //if (lseek (dev, 0, SEEK_SET))
    //{
    //    free (fat);
    //    if (fsinfo_sector) free (fsinfo_sector);
    //        free (root_dir);
    //    kprintf ("seek failed whilst writing tables");
    //}
    //n = write (dev, TempSector, SECTOR_SIZE);
    //if (n != SECTOR_SIZE)
    //{
    //    free (fat);
    //    if (fsinfo_sector) free (fsinfo_sector);
    //        free (root_dir);
    //    kprintf ("failed whilst blanking boot sector");
    //}

    //IoWrite(hBlockDev, TempSector, 0 );

    //if (lseek (dev, 0, SEEK_SET))
    //{
    //    free (fat);
    //    if (fsinfo_sector) free (fsinfo_sector);
    //        free (root_dir);
    //    kprintf ("seek 2 failed whilst writing tables");
    //}

    SetupTables_BootSector();
    
    bs.fbs.fat_length = CT_LE_W(bs.fbs.fat_length);
    bs.fbs.secs_track = CT_LE_W(bs.fbs.secs_track);
    bs.fbs.heads      = CT_LE_W(bs.fbs.heads);
    bs.fbs.hidden     = CT_LE_L(bs.fbs.hidden);
    bs.fbs.total_sect = CT_LE_L(bs.fbs.total_sect);
    
    if (gFatType == 32)
    {
        bs.fat32_length = CT_LE_L(bs.fat32_length);
        bs.flags        = CT_LE_W(bs.flags);
        bs.root_cluster = CT_LE_L(bs.root_cluster);
        bs.info_sector  = CT_LE_W(bs.info_sector);
        bs.backup_boot  = CT_LE_W(bs.backup_boot);
    }
    
    //root_dir[0].time = CT_LE_W(root_dir[0].time);
    //root_dir[0].date = CT_LE_W(root_dir[0].date);
    
    /* Write out the primary and the backup if on FAT32 */
//	memset(TempSector,0x00,sizeof(TempSector));
    iSector = 0;
#ifdef	MBR_INFO
	MakeMbRecord(drv);
	if(drv <= DEV_USER3_DISK){		//NAND File
	    NAND_Write_Random( iSector+FalshOffset, (unsigned char*)&MbrRecordData, 512);
	}else{
	    memcpy( (char*)((iSector*SECTOR_SIZE)+FalshOffset), (unsigned char*)&MbrRecordData, 512);
	}
    iSector++;
#endif
    for (x = 0; x < ((gFatType == 32) ? 2 : 1); x++)
    {
        int   Offset = 0;

        if (gFatType == 32)
        {
            memcpy(TempSector, &bs, sizeof(struct fat32_boot_sector) );
            //n = write (dev, (char *) &bs, sizeof (struct fat32_boot_sector));
            //if (n != sizeof (struct fat32_boot_sector))
            //{
            //    free (fat);
            //    free (root_dir);
            //    kprintf ("failed whilst writing boot sector");
            //}
            Offset = sizeof(struct fat32_boot_sector);
        }
        else
        {
            memcpy( TempSector, &bs, sizeof (struct fat_boot_sector) );
            //n = write (dev, (char *) &bs, sizeof (struct fat_boot_sector));
            //if (n != sizeof (struct fat_boot_sector))
            //{
            //    free (fat);
            //    free (root_dir);
            //    kprintf ("failed whilst writing boot sector");
            //}
            Offset = sizeof(struct fat_boot_sector);
        }

        memcpy( TempSector + Offset, &vi, sizeof (struct fat_volume_info) );
        //n = write (dev, (char *) &vi, sizeof (struct fat_volume_info));
        //if (n != sizeof (struct fat_volume_info))
        //{
        //    free (fat);
        //    if (fsinfo_sector) free (fsinfo_sector);
        //        free (root_dir);
        //    kprintf ("failed whilst writing boot sector");
        //}
        Offset += sizeof (struct fat_volume_info);
    
        //i = SECTOR_SIZE - sizeof(struct fat_volume_info) - ((gFatType == 32) ?
        //        sizeof(struct fat32_boot_sector) : sizeof(struct fat_boot_sector));
    
        memcpy( TempSector + Offset, dummy_boot_code, SECTOR_SIZE-Offset );
        //n = write (dev, dummy_boot_code, i);
        //
        //if (n != i)
        //{
        //    free (fat);
        //    if (fsinfo_sector)
        //        free (fsinfo_sector);
        //    free (root_dir);
        //    kprintf ("failed whilst writing boot sector");
        //}
//TempSector[0x1c2]= 3;
		if(drv <= DEV_USER3_DISK){
	        NAND_Write_Random( (unsigned int)(iSector+FalshOffset), (unsigned char*)TempSector, 512);
		}else{
			wAddress= ((iSector*SECTOR_SIZE)+FalshOffset);
	        memcpy( (char*)wAddress, (unsigned char*)TempSector, 512);
		}

        iSector++;


        // fsinfo
        if (gFatType == 32)
        {

            SetupTables_FsInfo( (unsigned char *)TempSector );
            //memcpy( TempSector, fsinfo_sector, SECTOR_SIZE );
//            memcpy( RamBuf + iSector*512, (unsigned char*)TempSector, 512);
			if(drv <= DEV_USER3_DISK){
		        NAND_Write_Random( (unsigned int)(iSector+FalshOffset), (unsigned char*)TempSector, 512);
			}else{
				wAddress= ((iSector*SECTOR_SIZE)+FalshOffset);
		        memcpy( (char*)wAddress, (unsigned char*)TempSector, 512);
			}
            iSector++;
            //n = write (dev, fsinfo_sector, SECTOR_SIZE);
            //if (n != SECTOR_SIZE)
            //{
            //    kprintf ("failed whilst writing boot sector");
            //}

            /* So far, two sectors have gone out. Write out blanks */
            for (i = 2; i < bs.backup_boot; i++)
            {
//                memset( TempSector, 0, SECTOR_SIZE );
                memset( TempSector, 0xff, SECTOR_SIZE );
//                memcpy( RamBuf + iSector*512, (unsigned char*)TempSector, 512);
				if(drv <= DEV_USER3_DISK){
			        NAND_Write_Random( (unsigned int)(iSector+FalshOffset), (unsigned char*)TempSector, 512);
				}else{
					wAddress= ((iSector*SECTOR_SIZE)+FalshOffset);
					memcpy( (char*)wAddress, (unsigned char*)TempSector, 512);
				}
                iSector++;
                //n = write (dev, TempSector, SECTOR_SIZE);
                //if (n != SECTOR_SIZE)
                //{
                //    free (fat);
                //    if (fsinfo_sector)
                //        free (fsinfo_sector);
                //    free (root_dir);
                //    kprintf ("failed whilst blanking boot sector");
                //}
            }
        }
    }
#ifdef	MBR_INFO
    iSector = (int)(bs.fbs.reserved+1);
#else
    iSector = (int)(bs.fbs.reserved);
#endif
    //n = lseek (dev, SECTOR_SIZE * (int) (bs.fbs.reserved), SEEK_SET);
    //if (n != SECTOR_SIZE * (int) (bs.fbs.reserved))
    //{
    //    free (fat);
    //    if (fsinfo_sector)
    //        free (fsinfo_sector);
    //    free (root_dir);
    //    kprintf ("seek 3 failed whilst writing tables");
    //}

    for (x = 1; x <= gnFat; x++)
    {
        SetupTables_Fat( (unsigned char *)TempSector );
        //unsigned char*   pFat;
        //pFat = (unsigned char*)&fat;
        for( i = 0; i < gFatLength; i++ )
        {
            //memcpy( TempSector, pFat, SECTOR_SIZE );
            //pFat += SECTOR_SIZE;
//            memcpy( RamBuf + iSector*512, (unsigned char*)TempSector, 512);
			if(drv <= DEV_USER3_DISK){
			    NAND_Write_Random( (unsigned int)(iSector+FalshOffset), (unsigned char*)TempSector, 512);
			}else{
				wAddress= ((iSector*SECTOR_SIZE)+FalshOffset);
		        memcpy( (char*)wAddress, (unsigned char*)TempSector, 512);
			}
            memset( TempSector, 0, SECTOR_SIZE );
            iSector++;
        }
        //n = write (dev, fat, fat_length * SECTOR_SIZE);
        //if (n != fat_length * SECTOR_SIZE)
        //{
        //    free (fat);
        //    free (root_dir);
        //    kprintf ("failed whilst writing FAT");
        //}
    }

	SaveiSector= iSector;
    memset( TempSector, 0, SECTOR_SIZE );
    for( i = 0; i < gSizeRootDir; i+=SECTOR_SIZE )
    {
//        memcpy( RamBuf + iSector*512, (unsigned char*)TempSector, 512);
		if(drv <= DEV_USER3_DISK){
			NAND_Write_Random( (unsigned int)(iSector+FalshOffset), (unsigned char*)TempSector, 512);
		}else{
			wAddress= ((iSector*SECTOR_SIZE)+FalshOffset);
		    memcpy( (char*)wAddress, (unsigned char*)TempSector, 512);
		}
		iSector++;
    }

    // 
    root_dir = (struct msdos_dir_entry *)TempSector;
    SetupTables_RootDir( root_dir );
    root_dir[0].time = CT_LE_W(root_dir[0].time);
    root_dir[0].date = CT_LE_W(root_dir[0].date);
	iSector= SaveiSector;
//        memcpy( RamBuf + iSector*512, (unsigned char*)TempSector, 512);
	if(drv <= DEV_USER3_DISK){
		NAND_Write_Random( (unsigned int)(iSector+FalshOffset), (unsigned char*)TempSector, 512);
	}else{
		wAddress= ((iSector*SECTOR_SIZE)+FalshOffset);
		memcpy( (char*)wAddress, (unsigned char*)TempSector, 512);
	}

    //n = write (dev, (char *) root_dir, gSizeRootDir);
    //if (n != gSizeRootDir)
    //{
    //    free (fat);
    //    if (fsinfo_sector)
    //        free (fsinfo_sector);
    //    free (root_dir);
    //    kprintf ("failed whilst writing root directory");
    //}

    //free (root_dir);   /* Free up the root directory space from SetupTables */
    //free (fat);  /* Free up the fat table space reserved during SetupTables */

    return;
}


/* Report the command usage and return a failure error code */
/*
void
usage (void)
{
  fatal_error("\
Usage: %s [OPTIONS] /dev/name [blocks]\n\n\
  -c            Check filesystem as is gets built\n\
  -f <num>      Number of FATs (between 1 and 4)\n\
  -F <num>      FAT size (12, 16, or 32)\n\
  -i <id>       Volume ID as hexadecimal number (i.e. 0x0410)\n\
  -l <filename> Bad block filename\n\
  -m <filename> Boot message filename--text is used as a boot message\n\
  -n <name>     Volume name\n\
  -r <num>      Root directory entries (not applicable to FAT32)\n\
  -s <num>      Sectors per cluster (2, 4, 8, 16, 32, 64, or 128)\n\
  -v            Verbose execution\n");
}
*/

/* The "main" entry point into the utility - we pick up the options and attempt to process them in some sort of sensible
   way.  In the event that some/all of the options are invalid we need to tell the user so that something can be done! */

int	MakeFatFsNand( int hDev, unsigned int nFat, unsigned int FatType, unsigned int nRootDirEntry, unsigned int nSecotorPerCluster )
{
//    unsigned char    VolumeName[] = "JBOSN";
//    unsigned char    BootMessage[] = "JBOSN Boot";
//    unsigned char    BadBlockName[] = "Bad";
//    unsigned int  VolumeId = 0x0410;

//kprintf ("\t\t MakeFatFs\n\n");


    gFatType = FatType;
    if( FatType != 12 && FatType != 16 && FatType != 32 )
    {
//        kprintf ("Bad FAT type\n");
        return FALSE;
    }

    gnFat = nFat;
    if( nFat < 1 || nFat > 4 )
    {
//        kprintf ("Bad number of FATs\n");
        return FALSE;
    }

    gnRootDirEntry = nRootDirEntry;
    if( nRootDirEntry < 16 || nRootDirEntry > 32768 )
    {
//        kprintf ("Bad number of root directory entries\n");
        return FALSE;
    }

    gnSecotorPerCluster = nSecotorPerCluster;
    if( nSecotorPerCluster != 1 && nSecotorPerCluster != 2 &&
        nSecotorPerCluster != 4 && nSecotorPerCluster != 8 &&
        nSecotorPerCluster != 16 && nSecotorPerCluster != 32 &&
        nSecotorPerCluster != 64 && nSecotorPerCluster != 128 )
    {
//        kprintf ("Bad number of sectors per cluster \n");
        return FALSE;
    }

	DevKind= hDev;
    if(hDev == DEV_USER1_DISK){			FalshOffset= FRAFH1_FILE_OFFSET;	}
    else if(hDev == DEV_USER2_DISK){	FalshOffset= FRAFH2_FILE_OFFSET;	}
	else if(hDev == DEV_SYS_DISK){		FalshOffset= FRAFH3_FILE_OFFSET;	}
	else if(hDev == DEV_USER3_DISK){	FalshOffset= FRAFH4_FILE_OFFSET;	}
	else if(hDev == DEV_RAM_DISK){		FalshOffset= RAMDISK_ADDRESS;		}
	else if(hDev == DEV_PTN_DISK){		FalshOffset= PTNDISK_ADDRESS;		}
	else{	return FALSE;	}

    EstablishParams(hDev);                          /* Establish the media parameters */
    //SetupTables();                              /* Establish the file system tables */

    //if( bCheck )                                /* Determine any bad block locations and mark them */
    //CheckBlocks ();
    //else
    //if( listfile )
    //    get_list_blocks (listfile);

    WriteTables(hDev);                         /* Write the file system tables away! */

    return TRUE;
}

