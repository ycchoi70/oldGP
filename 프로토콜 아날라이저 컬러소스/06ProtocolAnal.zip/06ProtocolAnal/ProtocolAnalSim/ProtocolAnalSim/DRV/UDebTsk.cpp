
#define	UDEBTSK_PROC

#include	<stdio.h>
#include	<string.h>
#include	<ctype.h>

#include	"define.h"

#include	"glplcd.h"
#include	"CommBuff.h"
#include	"selib.h"
#include	"bios.h"
#include	"rs232c.h"
#include	"motloader.h"
#include	"udebtsk.h"
#include	"lload.h"
#include	"usbh.h"
#include	"doscomm.h"
#include	"pcmcia.h"
#include	"nand.h"
#include	"glpdos.h"
#include	"disp.h"
#include	"touch.h"
#include	"flash.h"
#include	"udc_2440.h"
#include	"pcmcia.h"
//#include	"mmcdrv.h"
//#include	"dpuser.h"

//extern	void	W5300Test(void);






/* For Lib */
int	isHexdigit(unsigned char data)
{
	int	ret;

	ret= 0;
	if(      '0' <= data && data <= '9' ){	ret= 1;	}
	else if( 'A' <= data && data <= 'F' ){	ret= 1;	}
	else if( 'a' <= data && data <= 'f' ){	ret= 1;	}
	return(ret);
}
unsigned int atolx( unsigned long *data, unsigned char *ptr )
{
	unsigned int dat= 0;
	unsigned char *org= ptr;
	unsigned char	getData;

	*data= 0;
	getData= *ptr;
	while( isHexdigit( getData ) != 0 ){
		if(      '0' <= getData && getData <= '9' ){	dat= getData- '0';	}
		else if( 'A' <= getData && getData <= 'F' ){	dat= getData- 'A'+ 10;	}
		else if( 'a' <= getData && getData <= 'f' ){	dat= getData- 'a'+ 10;	}
		*data= *data* 16+ dat;
		ptr++;
		getData= *ptr;
	}
	return( ptr == org ? FALSE : TRUE );
}

/* For Lib */
unsigned int IsSpeace( unsigned char ch )
{
	switch( ch ){
	case ' ':	return( TRUE );
	case '\0':	return( TRUE );
	case '\a':	return( TRUE );
	case '\r':	return( TRUE );
	case '\n':	return( TRUE );
	case '\t':	return( TRUE );
	}
	return( FALSE );
}

/* For Lib */
unsigned char *SkipNextWord( unsigned char *ptr )
{
	unsigned char	getData;
	for( ;; ptr++ ){ 
		getData= *ptr;
		if( getData == ' '  ){		break;			}
		if( getData == '\0' ){		return( ptr );	}
		if( getData == END_CHAR ){	return( ptr );	}
	}
	ptr++;
	return( ptr );
}

/************************************************************/
/*	�P�������M												*/
/************************************************************/
#ifdef	WIN32
extern	void	SioPuts(char *buf);
#endif
void	SendString( char* ptr)
{
#ifdef	WIN32
	SioPuts(ptr);
#else
	while(1){
		if( *ptr == '\0' ){	break;		}

//		if( Sio0SendChar( *ptr ) == TRUE ){	ptr++;	}
		if( Sio1SendChar( *ptr ) == TRUE ){	ptr++;	}
//		if( Sio2SendChar( *ptr ) == TRUE ){	ptr++;	}

	}
#endif
}
/************************************************************/
/*	���b�Z?�W���M											*/
/************************************************************/
void DModeSendMsg( char *ptr )
{
#ifdef	WIN32
	SioPuts(ptr);
#else
	TimerStart( 1, 100 );		/* Wait 1Sec */
	while( time_flag[1] == 0 ){
		if( *ptr == '\0' ){	break;		}

//		if( Sio0SendChar( *ptr ) == TRUE ){	ptr++;	}
		if( Sio1SendChar( *ptr ) == TRUE ){	ptr++;	}
//		if( Sio2SendChar( *ptr ) == TRUE ){	ptr++;	}

	}
#endif
}

/************************************************************/
/*	�v�����v�g���M											*/
/************************************************************/
void DModeSendPronpt( void ){	DModeSendMsg( ">" );	}

/************************************************************/
/*	���s���M												*/
/************************************************************/
void DModeSendCR( void )
{
#ifndef	WIN32
	unsigned int i;
#endif
	unsigned char tbl[4]= { 0x0A, 0x0D, 0x00,	};
	
#ifdef	WIN32
	SioPuts((char*)tbl);
#else
	for( i= 0; tbl[i] != 0x00; i++ ){ 
//		while( Sio0SendChar( tbl[i] ) == FALSE ){	;	}
		while( Sio1SendChar( tbl[i] ) == FALSE ){	;	}
//		while( Sio2SendChar( tbl[i] ) == FALSE ){	;	}
	}
#endif
}

/************************************************************/
/*	���b�Z?�W���M�i�v�����v�g?���t���j					*/
/************************************************************/
void DModeSendOneMsg( char *ptr )
{
	DModeSendMsg( ptr );

//	DModeSendCR();
//	DModeSendPronpt();
}
/************************************************************/
/*	Welcome���b�Z?�W���M									*/
/************************************************************/
void DModeSendLoginMsg( void )
{
//	DModeSendCR();
	DModeSendOneMsg( TVS_VERSION_MES1 );
	DModeSendOneMsg( TVS_VERSION_MES2 );
	DModeSendCR();
	DModeSendPronpt();
}
void DModeSendLoginMsgAs( void )
{
//	DModeSendCR();
	DModeSendOneMsg( TVS_VERSION_MES1 );
	DModeSendOneMsg( TVS_VERSION_MES2 );
	DModeSendOneMsg( "\r\nFirmware A/S Mode\r\n" );
	DModeSendPronpt();
}
/************************************************************/
/*	Loaser Start ���b�Z?�W���M									*/
/************************************************************/
void DModeSendStartMsg( void )
{
	DModeSendMsg( TVS_VERSION_MES1 );
	DModeSendMsg( TVS_VERSION_MES2 );
	DModeSendCR();
	DModeSendMsg( "1. Test Program" );
	DModeSendCR();
	DModeSendMsg( "2. System Loader Program" );
	DModeSendCR();
	DModeSendMsg( "Test Program : after 3sec" );
	DModeSendCR();
}
void LoaderStartMsg( void )
{
	DModeSendMsg( TVS_VERSION_MES1 );
	DModeSendMsg( TVS_VERSION_MES2 );
	DModeSendCR();
}
/************************************************************/
/*	�R?���h�G��?���b�Z?�W���M							*/
/************************************************************/
void DModeSendCmdErr( unsigned char *pCmd )
{
	DModeSendOneMsg( "\r\nCOMMAND ERROR\r\n" );
	DModeSendPronpt();
}

/************************************************************/
/*	Quit���b�Z?�W���M										*/
/************************************************************/
void DModeSendQuitMsg( void )
{

	DModeSendMsg( "Bye Bye\r\n" );
	DModeFlag= 0;
}
/************************************************************/
/*	�o?�W�����ԍ����M										*/
/************************************************************/
void DModeSendVersion( void )
{
	DModeSendOneMsg( TVS_VERSION );
	DModeSendCR();
}

/************************************************************/
/*	Help���b�Z?�W���M										*/
/************************************************************/
void DModeSendHelpMsg( void )
{
	unsigned int i;
	
	for( i= 0; i < TBQ(HelpMsg); i++ ){
		DModeSendMsg( HelpMsg[i] );
		DModeSendCR();
	}
	DModeSendPronpt();
}
/************************************************************/
/*	Cam Help���b�Z?�W���M									*/
/************************************************************/
void DModeSendCamHelpMsg( void )
{
	unsigned int i;
	char *HelpMsg[]= {
		"CAM HELP      : CAM HELP.",
	};
	
	for( i= 0; i < TBQ(HelpMsg); i++ ){
		DModeSendMsg( HelpMsg[i] );
		DModeSendCR();
	}
	DModeSendPronpt();
}

/************************************************************/
/*	��������?�h�����֐�									*/
/************************************************************/
unsigned int DModeMemoryRead( unsigned char *pCmd )
{
	unsigned int ret= TRUE;
	unsigned int type;
	unsigned long adr;
	char buf[80];

	if( ret == TRUE ){				/* �R?���h */
		pCmd++;
		switch( *pCmd ){
		case ' ':	type= TYPE_WORD;	break;
		case 'B':	type= TYPE_BYTE;	break;
		case 'W':	type= TYPE_WORD;	break;
		case 'L':	type= TYPE_LONG;	break;
		default:	ret= FALSE;			break;
		}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){				/* �A�h���X */
		atolx( &adr, pCmd );
	}
	if( ret == TRUE ){				/* ���� */
		switch( type ){
		case TYPE_BYTE:
			sprintf( buf, "%08X:%02X", adr, (unsigned char )*((unsigned char  *)adr) );
			(unsigned char *)adr++;
			break;
		case TYPE_WORD:
			sprintf( buf, "%08X:%04X", adr, (unsigned short)*((unsigned short *)adr) );
			(unsigned short *)adr++;
			break;
		case TYPE_LONG:
			sprintf( buf, "%08X:%08X", adr, (unsigned long )*((unsigned long  *)adr) );
			adr++;
			break;
		}
		DModeSendMsg( buf );
	}
	if( ret != TRUE ){	/* ERROR */
		DModeSendMsg( "ERROR!" );
	}
	DModeSendCR();
	DModeSendPronpt();

	return( ret );
}

unsigned int DModeMemoryCycleRead( unsigned char *pCmd )
{
	unsigned int ret= TRUE;
	unsigned int type;
	unsigned long adr;
	volatile	unsigned char bData;
	volatile	unsigned short wData;
	volatile	unsigned long lData;
	unsigned char *badr;
	unsigned short *wadr;
	unsigned long *ladr;
	int				i;
	char buf[80];

	if( ret == TRUE ){				/* �R?���h */
		pCmd++;
		switch( *pCmd ){
		case ' ':	type= TYPE_WORD;	break;
		case 'B':	type= TYPE_BYTE;	break;
		case 'W':	type= TYPE_WORD;	break;
		case 'L':	type= TYPE_LONG;	break;
		default:	ret= FALSE;			break;
		}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){				/* �A�h���X */
		atolx( &adr, pCmd );
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){				/* ���� */
		switch( type ){
		case TYPE_BYTE:
			badr= (unsigned char *)adr;
			sprintf( buf, "%08X:%02X", adr, (unsigned char )*((unsigned char  *)adr) );
			break;
		case TYPE_WORD:
			wadr= (unsigned short *)adr;
			sprintf( buf, "%08X:%04X", adr, (unsigned short)*((unsigned short *)adr) );
			break;
		case TYPE_LONG:
			ladr= (unsigned long *)adr;
			sprintf( buf, "%08X:%08X", adr, (unsigned long )*((unsigned long  *)adr) );
			break;
		}
		DModeSendMsg( buf );
		for(i = 0; ; i++){
			switch( type ){
			case TYPE_BYTE:	bData= *badr;	break;
			case TYPE_WORD:	wData= *wadr;	break;
			case TYPE_LONG:	lData= *ladr;	break;
			}
			if(IS_CONSOL( ) != 0){
				break;
			}
		}
	}
	DModeSendCR();
	DModeSendPronpt();

	return( ret );
}

/************************************************************/
/*	���������C�g�����֐�									*/
/************************************************************/
unsigned int DModeMemoryWrite( unsigned char *pCmd )
{
	char buf[80];
	unsigned int ret= TRUE;
	unsigned int type;
	unsigned long adr, data;
	unsigned char	*bptr;
	unsigned short	*wptr;
	unsigned long	*lptr;

	if( ret == TRUE ){					/* �R?���h */
		pCmd++;
		switch( *pCmd ){
		case ' ':	type= TYPE_WORD;	break;
		case 'B':	type= TYPE_BYTE;	break;
		case 'W':	type= TYPE_WORD;	break;
		case 'L':	type= TYPE_LONG;	break;
		default:	ret= FALSE;			break;
		}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �A�h���X */
		atolx( &adr, pCmd );
		pCmd= SkipNextWord( pCmd );
	}

	if( ret == TRUE ){

		switch( type ){
		case TYPE_BYTE:
			bptr= (unsigned char *)adr;
			while( *pCmd != END_CHAR ){	/* Get Data */
				atolx( &data, pCmd );
				sprintf( buf, "%08X: %02X->%02X", bptr, *bptr, data );
										/* �ԐM�쐬 */
				DModeSendMsg( buf );	/* �ԐM���s */
				DModeSendCR();
				*((unsigned char *)bptr++)= (unsigned char)data;
				bptr++;
				pCmd= SkipNextWord( pCmd );
			}
			break;
		case TYPE_WORD:
			wptr= (unsigned short *)adr;
			while( *pCmd != END_CHAR ){	/* Get Data */
				atolx( &data, pCmd );
				sprintf( buf, "%08X: %04X->%04X", wptr, *wptr, data );
										/* �ԐM�쐬 */
				DModeSendMsg( buf );	/* �ԐM���s */
				DModeSendCR();
				*((unsigned short *)wptr++)= (unsigned short)data;
				pCmd= SkipNextWord( pCmd );
			}
			break;
		case TYPE_LONG:
			lptr= (unsigned long *)adr;
			while( *pCmd != END_CHAR ){	/* Get Data */
				atolx( &data, pCmd );
				sprintf( buf, "%08X: %08X->%08X", lptr, *lptr, data );
										/* �ԐM�쐬 */
				DModeSendMsg( buf );	/* �ԐM���s */
				DModeSendCR();
				*((unsigned long *)lptr++)= (unsigned long)data;
				pCmd= SkipNextWord( pCmd );
			}
			break;
		}
	}
	if( ret != TRUE ){
		DModeSendMsg( "ERROR!" );
		DModeSendCR();
	}
	DModeSendPronpt();
	return( ret );
}
unsigned int DModeMemoryCycleWrite( unsigned char *pCmd )
{
	char buf[80];
	unsigned int ret= TRUE;
	unsigned int type;
	unsigned long adr, data;
	unsigned char	*bptr;
	unsigned short	*wptr;
	unsigned long	*lptr;
	int				i;

	if( ret == TRUE ){					/* �R?���h */
		pCmd++;
		switch( *pCmd ){
		case ' ':	type= TYPE_WORD;	break;
		case 'B':	type= TYPE_BYTE;	break;
		case 'W':	type= TYPE_WORD;	break;
		case 'L':	type= TYPE_LONG;	break;
		default:	ret= FALSE;			break;
		}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �A�h���X */
		atolx( &adr, pCmd );
		pCmd= SkipNextWord( pCmd );
	}

	if( ret == TRUE ){

		atolx( &data, pCmd );
		switch( type ){
		case TYPE_BYTE:
			bptr= (unsigned char *)adr;
			sprintf( buf, "%08X: %02X->%02X", bptr, *bptr, data );
									/* �ԐM�쐬 */
			DModeSendMsg( buf );	/* �ԐM���s */
			DModeSendCR();
			break;
		case TYPE_WORD:
			wptr= (unsigned short *)adr;
			sprintf( buf, "%08X: %04X->%04X", wptr, *wptr, data );
									/* �ԐM�쐬 */
			DModeSendMsg( buf );	/* �ԐM���s */
			DModeSendCR();
			break;
		case TYPE_LONG:
			lptr= (unsigned long *)adr;
			sprintf( buf, "%08X: %08X->%08X", lptr, *lptr, data );
									/* �ԐM�쐬 */
			DModeSendMsg( buf );	/* �ԐM���s */
			DModeSendCR();
			break;
		}
		for(i = 0; ; i++){
			switch( type ){
			case TYPE_BYTE:	*((unsigned char *)bptr)= (unsigned char)data;		break;
			case TYPE_WORD:	*((unsigned short *)wptr)= (unsigned short)data;	break;
			case TYPE_LONG:	*((unsigned long *)lptr)= (unsigned long)data;		break;
			}
			if(IS_CONSOL( ) != 0){
				break;
			}
		}
	}
	if( ret != TRUE ){
		DModeSendMsg( "ERROR!" );
		DModeSendCR();
	}
	DModeSendPronpt();
	return( ret );
}

unsigned int DModeMemoryCheck( unsigned char *pCmd )
{
	char buf[80];
	unsigned int ret= TRUE;
	unsigned long data;
	unsigned long sdata;
	unsigned long	*lptr;
	int				i;

	DModeSendCR();
	DModeSendMsg( "RAM Memory Check Start" );	/* �ԐM���s */
	DModeSendCR();
	lptr= (unsigned long *)(SRAM_ADDR+ 0x10000);
	ret = 0;
	for(i = 0; i < (SRAM_SIZE-0x20000)/4; i++){
		sdata= *lptr;
		*lptr= 0xaaaaaaaa;
		data= *lptr;
		if(data != 0xaaaaaaaa){
			sprintf( buf, "%08X: ERROR(W:AAAAAAAA,R:%08X", lptr, data );
			DModeSendMsg(buf);
			DModeSendCR();
			ret= 1;
		}
		*lptr= 0x55555555;
		data= *lptr;
		if(data != 0x55555555){
			sprintf( buf, "%08X: ERROR(W:55555555,R:%08X", lptr, data );
			DModeSendMsg(buf);
			DModeSendCR();
			ret= 1;
		}
		*lptr= sdata;
		lptr++;
		if(IS_CONSOL( ) != 0){
			break;
		}
	}
	if(ret == 0){
		lptr= (unsigned long *)(SRAM_ADDR+ 0x10000);
		for(i= 0; i < (SRAM_SIZE-0x20000)/4; i++){
			*lptr++= i;
		}
		lptr= (unsigned long *)(SRAM_ADDR+ 0x10000);
		for(i= 0; i < (SRAM_SIZE-0x20000)/4; i++){
			if(*lptr++ != (unsigned)i){
				lptr--;
				sprintf( buf, "%08X: ERROR(W:%08X,R:%08X", lptr, i, *lptr );
				DModeSendMsg(buf);
				DModeSendCR();
				ret= 1;
				break;
			}
		}
	}
	//SRAM_MEMORY_ADDR
#ifdef	LOADER_RAM
	if(ret == 0){
		memcpy((char *)(SRAM_ADDR+ 0x10000),(char *)SRAM_ADDR,0x10000);
		lptr= (unsigned long *)SRAM_ADDR;
		for(i = 0; i < 0x10000/4; i++){
			sdata= *lptr;
			*lptr= 0xaaaaaaaa;
			data= *lptr;
			if(data != 0xaaaaaaaa){
				sprintf( buf, "%08X: ERROR(W:AAAAAAAA,R:%08X", lptr, data );
				DModeSendMsg(buf);
				DModeSendCR();
				ret= 1;
			}
			*lptr= 0x55555555;
			data= *lptr;
			if(data != 0x55555555){
				sprintf( buf, "%08X: ERROR(W:55555555,R:%08X", lptr, data );
				DModeSendMsg(buf);
				DModeSendCR();
				ret= 1;
			}
			*lptr= sdata;
			lptr++;
			if(IS_CONSOL( ) != 0){
				break;
			}
		}
		if(ret == 0){
			lptr= (unsigned long *)SRAM_ADDR;
			for(i= 0; i < 0x10000/4; i++){
				*lptr++= i;
			}
			lptr= (unsigned long *)SRAM_ADDR;
			for(i= 0; i < 0x10000/4; i++){
				if(*lptr++ != (unsigned)i){
					lptr--;
					sprintf( buf, "%08X: ERROR(W:%08X,R:%08X", lptr, i, *lptr );
					DModeSendMsg(buf);
					DModeSendCR();
					ret= 1;
					break;
				}
			}
		}
		memcpy((char *)SRAM_ADDR,(char *)(SRAM_ADDR+ 0x10000),0x10000);
	}
#endif
	if( ret == 0 ){
		DModeSendMsg( "SRAM OK" );
	}else{
		DModeSendMsg( "SRAM NG" );
	}
	DModeSendCR();
	DModeSendPronpt();
	return( ret );
}

unsigned int DModePortOut( unsigned char *pCmd )
{
	return( 0 );
}
unsigned int PasswordWrite( unsigned char *pCmd )
{

	return( 0 );
}
/************************************************************/
/*	������?���v?��������쐬�֐�							*/
/*	����	long spos;	Start Position						*/
/*			long size;	Size								*/
/*			long cpos;	Current Position					*/
/************************************************************/
void MakeDumpStr( unsigned int type, char *pBuf, unsigned long spos,
							unsigned long size, unsigned long cpos )
{
	char	frm[16];
	unsigned int	i, max;
	unsigned char	cc;			/* ?������ */
	unsigned long	xp, pos;	/* ���ڃA�h���X,�A�h���X?�W�V����*/
	unsigned long	sadrs, eadrs, epos;

	pos= cpos;
	/* ?���J�n�A�h���X */
	sprintf( pBuf, "%08X: ", pos- (pos% 16) );
	pBuf+= 10;

	/* �f??�i�P�U�i?�L�j */
	xp= pos- (pos% 16);						/* �J�����g?�C��? */
	epos= spos+ size;						/* �I�����A�h���X */
	sadrs= spos- (spos% type);				/* ?���J�n�A�h���X */
	eadrs= epos+ (epos% type == 0 ? 0 : type- epos% type);
											/* ?���I���A�h���X */
	max= 16/ type;							/* �P�s?���ő�� */
	sprintf( frm, "%%0%dX ", type* 2 );		/* ?��?���w�� */
	for( i= 0; i < max; i++, xp+= type ){
		if( i == max/ 2 ){					/* ������?�� */
			sprintf( pBuf, " " );
			pBuf++;
		}
		if( xp < sadrs || xp >= eadrs ){	/* ?�L�Ȃ� */
			sprintf( pBuf, "         " );	/* MAX LONG */
		}
		else{								/* �f???�� */
			sprintf( pBuf, frm, 
				type == TYPE_BYTE ? (unsigned char )*(unsigned char  *)pos :
				type == TYPE_LONG ? (unsigned long )*(unsigned long  *)pos :
									(unsigned short)*(unsigned short *)pos );
			pos+= type;
		}
		pBuf+= (type* 2+ 1);
	}

	/* ��؂蕶�� */
	sprintf( pBuf, " " );
	pBuf+= 1;
	
	/* �f??�i����?�L�j */
	xp= cpos- (cpos% 16);		/* ���ڃA�h���X */
	for( i= 0; i < 16; i++, xp++ ){
		if( i == (16/ 2) ){		/* ������?�� */
			sprintf( pBuf, " " );
			pBuf++;
		}
		cc= *(unsigned char *)xp;
		if(      xp <  sadrs ){	sprintf( pBuf, " " );		}
		else if( xp >= eadrs ){	sprintf( pBuf, " " );		}
		else{
			if( cc < ' ' ){						sprintf( pBuf, "." );		}
			else if( cc < 0x7F){				sprintf( pBuf, "%c", cc );	}
			else if( 0xA0 < cc && cc < 0xE0 ){	sprintf( pBuf, "%c", cc );	}
			else{								sprintf( pBuf, "." );		}
		}
		pBuf++;
	}
}

/************************************************************/
/*	������?���v�����֐�									*/
/************************************************************/
unsigned int DModeMemoryDump( unsigned char *pCmd )
{
	char buf[80];
	unsigned int i, line, ret= TRUE;
	unsigned int type;
	unsigned long adr, sadr, end, size;

	if( ret == TRUE ){					/* �R?���h */
		if( memcmp( pCmd, "DUMP", 4 ) == 0 ){	/* Full Command */
			type= TYPE_WORD;
			pCmd= SkipNextWord( pCmd );
		}
		else{									/* Shortcut Command */
			pCmd++;			/* Skip 'D' */
			switch( *pCmd ){
			case '\0':
			case '\a':
			case '\r':
			case ' ':	type= TYPE_WORD;	break;
			case 'B':	type= TYPE_BYTE;	break;
			case 'W':	type= TYPE_WORD;	break;
			case 'L':	type= TYPE_LONG;	break;
			default:	ret= FALSE;			break;
			}
			pCmd= SkipNextWord( pCmd );
		}
	}
	if( ret == TRUE ){					/* �A�h���X */
		if( atolx( &adr, pCmd ) == FALSE ){	adr= DefaultAdress;	}	
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �T�C�Y�E�I���A�h���X */
		if( *pCmd == '\\' ){	/* �T�C�Y */
			pCmd++;
			atolx( &size, pCmd );
		}
		else{					/* �I���A�h���X */
			if( atolx( &end, pCmd ) == FALSE ){	size= 16* 8;		}	/* DEFALT */
			else if( adr < end ){				size= end- adr+ 1;	}
			else{								ret= FALSE;			}
		}
		end= adr+ size;
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){			/* ���� */
		line= (unsigned int)((end % 16 == 0 ? end : end+ 16- (end% 16) )
													/* �I���A�h���X */
							- (adr- (adr% 16))) 	/* �J�n�A�h���X */
							/ 16;					/* �ő�?���� */
		for( i= 0; i < line; i++ ){
			sadr= adr+ i* 16;		/* ?���擪�̃A�h���X�擾 */

			MakeDumpStr( type, buf, adr, size, sadr );
			DModeSendMsg( buf );
			DModeSendCR();
		}
	}
	if( ret != TRUE ){
		DModeSendMsg( "ERROR!" );
		DModeSendCR();
	}
	DefaultAdress= adr+ 16* 8;
	DModeSendPronpt();

	return( ret );
}

/************************************************************/
/*	�������t�B�������֐�									*/
/************************************************************/
unsigned int DModeMemoryFill( unsigned char *pCmd )
{
	unsigned int ret= TRUE;
	unsigned int i;
	unsigned long adr[2], len, inc, data;		/* adr[0]:�I���W�i���A�h���X */
												/* adr[1]:�o�E��?���Ή���A�h���X */

	if( ret == TRUE ){					/* �R?���h */
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �A�h���X */
		if( atolx( &adr[0], pCmd ) == FALSE ){	ret= FALSE;	}
		pCmd= SkipNextWord( pCmd );
		adr[1]= (adr[0]/ 2)* 2;
	}
	if( ret == TRUE ){					/* �T�C�Y */
		if( *pCmd == '\\' ){
			pCmd++;
			if( atolx( &len, pCmd ) == FALSE ){	ret= FALSE;	}
			pCmd= SkipNextWord( pCmd );
			len= (adr[0]+ len)- adr[1];	/* Size= End- Statrt */
			len= (len/ 2)+ (len% 2);	/* Byte ==> Word */
		}
		else{
			ret= FALSE;
		}
	}
	if( ret == TRUE ){					/* �����l */
		if( atolx( &data, pCmd ) == FALSE ){	ret= FALSE;	}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �C���N�������g�p??�� */
		if( atolx( &inc, pCmd ) == FALSE ){	ret= FALSE;	}
		pCmd= SkipNextWord( pCmd );
	}

	if( ret == TRUE ){
		for( i= 0; i < len; i++ ){
			*((unsigned short *)adr[1]+ i)= (unsigned short)data;
			data+= inc;
		}
	}
	if( ret != TRUE ){
		DModeSendMsg( "ERROR!" );
		DModeSendCR();
	}
	DModeSendPronpt();
	return( ret );
}

/************************************************************/
/*	���������f??�ݒ�i�r�t�a�r�j�����֐�					*/
/************************************************************/
unsigned int DModeMemorySubs( unsigned char *pCmd )
{
	char buf[80];
	unsigned int ret= TRUE, size= 0;
	unsigned long adr, dat;
	unsigned short *wptr;

	if( ret == TRUE ){					/* �R?���h */
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �A�h���X */
		if( atolx( &adr, pCmd ) == FALSE ){	adr= DefaultAdress;	}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �f?? */
		wptr= (unsigned short *)adr;
		/* �A���ݒ� */
		if( *pCmd == '\0' || *pCmd == '\a' || *pCmd == '\r' ){
			SubsModeFlag= TRUE;					/* Flag ON */
			DefaultAdress= adr;
			sprintf( buf, "%08X %04X", DefaultAdress,
							(unsigned short)*((unsigned short *)DefaultAdress) );
			DModeSendMsg( buf );
		}
		/* ���ڐݒ� */
		else{
			while( atolx( &dat, pCmd ) == TRUE ){
				size+= 2;
				*((unsigned short *)wptr++)= (unsigned short)dat;
				pCmd= SkipNextWord( pCmd );
			}
/*19991029 ��?��*/
/*			MakeDumpStr( TYPE_WORD, buf, adr, size, adr );*/
/*			DModeSendMsg( buf );*/
/*			DModeSendCR();*/
/**/
		}
	}
	DModeSendPronpt();

	return( ret );
}

/************************************************************/
/*	�r�t�a�r���ʏ����֐�									*/
/************************************************************/
unsigned int DModeSubsProc( unsigned char *pCmd )
{
	char buf[80];
	unsigned long dat;
	unsigned short *wptr;

	switch( *pCmd ){
	case '\0':	/* �����̓R?���h */
	case '\r':	/* �����̓R?���h */
		DefaultAdress+= (DefaultAdress% 2);	/* ������ */
		DefaultAdress+= 2;					/* ���� */
		break;
	case '^':	/* �P��R?���h */
		DefaultAdress+= (DefaultAdress% 2);	/* ������ */
		DefaultAdress-= 2;					/* ���� */
		break;
	case '.':	/* �I���R?���h */
		SubsModeFlag= FALSE;				/* Flag OFF */
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	default:	/* ���̑��̃R?���h */
		if( atolx( &dat, pCmd ) == TRUE ){
			DefaultAdress+= (DefaultAdress% 2);	/* ������ */
			wptr= (unsigned short *)DefaultAdress;
			*((unsigned short *)wptr++)= (unsigned short)dat;
			DefaultAdress+= 2;					/* ���� */
		}
		break;
	}

	DModeSendCR();
	sprintf( buf, "%08X %04X", DefaultAdress, (unsigned short)*((unsigned short *)DefaultAdress) );
	DModeSendMsg( buf );
	DModeSendPronpt();
	return( TRUE );
}

	struct{
		unsigned int		No;
		unsigned int		size;
		unsigned char	*cmd;
	} DmodeCmdTbl[]= {
		{	UDCMD_GO,	  2, (unsigned char	*)"GO"		},
		{	UDCMD_GO,	  1, (unsigned char	*)"G"		},
		{	UDCMD_BR,	  2, (unsigned char	*)"BR"		},
		/**	�Ǎ��݌n�R?���h	**/
		{	UDCMD_MEM_R,  2, (unsigned char	*)"RB"		},
		{	UDCMD_MEM_R,  2, (unsigned char	*)"RW"		},
		{	UDCMD_MEM_R,  2, (unsigned char	*)"RL"		},
		{	UDCMD_MEM_W,  2, (unsigned char	*)"WB"		},
		{	UDCMD_MEM_W,  2, (unsigned char	*)"WW"		},
		{	UDCMD_MEM_W,  2, (unsigned char	*)"WL"		},
		{	UDCMD_MEM_U,  2, (unsigned char	*)"UB"		},
		{	UDCMD_MEM_U,  2, (unsigned char	*)"UW"		},
		{	UDCMD_MEM_U,  2, (unsigned char	*)"UL"		},
		{	UDCMD_MEM_L,  2, (unsigned char	*)"SB"		},
		{	UDCMD_MEM_L,  2, (unsigned char	*)"SW"		},
		{	UDCMD_MEM_L,  2, (unsigned char	*)"SL"		},
		{	UDCMD_MEM_D,  4, (unsigned char	*)"DUMP"	},
		{	UDCMD_MEM_D,  2, (unsigned char	*)"DB"		},
		{	UDCMD_MEM_D,  2, (unsigned char	*)"DW"		},
		{	UDCMD_MEM_D,  2, (unsigned char	*)"DL"		},
		{	UDCMD_MEM_D,  1, (unsigned char	*)"D"		},
		{	UDCMD_MEM_F,  4, (unsigned char	*)"FILL"	},
		{	UDCMD_MEM_F,  1, (unsigned char	*)"F"		},
		{	UDCMD_MEM_S,  4, (unsigned char	*)"SUBS"	},
		{	UDCMD_MEM_S,  2, (unsigned char	*)"EW"		},
		{	UDCMD_MEM_S,  1, (unsigned char	*)"E"		},
		{	UDCMD_MEM_T,  2, (unsigned char	*)"CM"		},
		{	UDCMD_MEM_FC, 2, (unsigned char	*)"FC"		},
		{	UDCMD_MEM_CP, 2, (unsigned char	*)"CP"		},
		{	UDCMD_MEM_FE, 2, (unsigned char	*)"FE"		},
		{	UDCMD_MEM_FW, 2, (unsigned char	*)"FW"		},
		{	UDCMD_LCD_LT, 2, (unsigned char	*)"LT"		},
		{	UDCMD_LCD_CT, 2, (unsigned char	*)"CT"		},
		{	UDCMD_PRG_CK, 4, (unsigned char	*)"PRCK"	},
		{	UDCMD_EXT_CK, 2, (unsigned char	*)"EX"		},
		{	UDCMD_LCD_CLK,2, (unsigned char	*)"SC"		},
		{	UDCMD_LED,    2, (unsigned char	*)"RT"		},
		{	UDCMD_IO_TEST,2, (unsigned char	*)"IO"		},

		{	UDCMD_RTS_TEST,3, (unsigned char *)"RTS"	},
		{	UDCMD_LCD_TEST,3, (unsigned char *)"LCD"	},
		{	UDCMD_BUZ_BZ,  3, (unsigned char *)"BUZ"	},
		{	UDCMD_FILE_TEST,4, (unsigned char *)"FILE"	},
		{	UDCMD_CALIB,   4, (unsigned char *)"CALB"	},
		{	UDCMD_LD_START,4, (unsigned char *)"LDST"	},
		{	UDCMD_USB_SLAVE,4, (unsigned char *)"USBS"	},
		{	UDCMD_W5300_TEST,3, (unsigned char *)"W53"	},
		{	UDCMD_FPGA_WRITE,4, (unsigned char *)"FPGA"	},
		{	UDCMD_FPGA_CLK,4, (unsigned char *)"FPCL"	},
		{	UDCMD_FPGA_TDI,4, (unsigned char *)"FPTD"	},
		{	UDCMD_FPGA_TMS,4, (unsigned char *)"FPTM"	},
		{	UDCMD_NAND_DMP,2, (unsigned char *)"NB"		},
		{	UDCMD_NAND_DMP,2, (unsigned char *)"NW"		},
		{	UDCMD_NAND_DMP,2, (unsigned char *)"NL"		},
		{	UDCMD_NAND_DMP,1, (unsigned char *)"N"		},
		



		/**	����R?���h		**/
		{	UDCMD_PLOAD,  5, (unsigned char	*)"PLOAD"	},
		{	UDCMD_FLOAD,  5, (unsigned char	*)"FLOAD"	},
		{	UDCMD_PASS,   2, (unsigned char	*)"PW"		},
		{	UDCMD_FRLD,   4, (unsigned char	*)"FRLD"	},

		/**	�V�X�e?�n�R?���h	**/
		{	UDCMD_VER,	  3, (unsigned char	*)"VER"		},
		{	UDCMD_VER,	  1, (unsigned char	*)"_"		},
		{	UDCMD_HELP,	  4, (unsigned char	*)"HELP"	},
		{	UDCMD_HELP,	  1, (unsigned char	*)"?"		},
		{	UDCMD_CHELP,  4, (unsigned char	*)"USE?"	},
		{	UDCMD_ECHO,   4, (unsigned char	*)"ECHO"	},
		{	UDCMD_ECHOOF, 5, (unsigned char	*)"_ECHO"	},
		{	UDCMD_SERIAL_SET, 9, (unsigned char	*)"SERIALSET"	},  /* 20090717 */
		
		{	UDCMD_EXIT,	  4, (unsigned char	*)"QUIT"	},
		{	UDCMD_EXIT,	  1, (unsigned char	*)"Q"		},
		{	UDCMD_NO_CMD, 1, (unsigned char	*)"\x0D"	},

	};

/************************************************************/
/*	�R?���h�ԍ��̎擾										*/
/*	�ߒl�F	�R?���h�ԍ�									*/
/*			0*:�������R?���h()								*/
/*			1*:����n�R?���h								*/
/*			8*:����R?���h									*/
/*			F*:�V�X�e?�n�R?���h							*/
/************************************************************/
unsigned int GetDModeCmdNo( unsigned char *pCmd )
{
	unsigned int i;

	for( i= 0; pCmd[i] != END_CHAR; i++ ){
		if( 'a' <= pCmd[i] && pCmd[i] <= 'z' ){	pCmd[i]-= ('a'- 'A');	}
	}
	for( i= 0; i < TBQ(DmodeCmdTbl); i++ ){
		if( memcmp( pCmd, DmodeCmdTbl[i].cmd, DmodeCmdTbl[i].size ) == 0 ){
			if( IsSpeace( *(pCmd+ DmodeCmdTbl[i].size) ) == TRUE ||
								DmodeCmdTbl[i].No == UDCMD_NO_CMD ){
				DModeSendCR();
				return( DmodeCmdTbl[i].No );
			}
		}
	}
	return( 0x00 );
}
/************************************************/
/*	Flash Check									*/
/************************************************/
int	FlashWriteProcColl(char *addr,char *data,int size)
{
	return(0);
}
void	FlashErazeCall(short *addr)
{
}
int		FlashCheck(void)
{
	return(0);
}
void	FlashWriteCheck(void)
{
}
void	FlashErazeCheck(void)
{
}
void	JmpApl(void)
{
}
void	RTSCheck(unsigned char *pCmd)
{
	unsigned long	cnt;

	cnt= 0;
	pCmd= SkipNextWord( pCmd );
	if( atolx( &cnt, pCmd ) == FALSE ){	cnt= 0;	}
	if(cnt == 0){
		RtsOff();
	}else{
		RtsOn();
	}
}
void	DrawRectangle(void)
{
	COLOR_DT	color;
	int	i;
	for(i= 0; ; i++){
		if(i >= ((LCD_Y_SIZE-1)-i)){	break;	}
		color= GetColorData((255-i) & 0xff);			//WHITE()
		ForGrandColor= color;			//WHITE()
		RectAngleNoDraw(0+i,0+i,(LCD_X_SIZE-1)-i,(LCD_Y_SIZE-1)-i);
	}
	DrawLcd((char *)LcdBuff);
	ForGrandColor.r= 0xff;			//WHITE()
	ForGrandColor.g= 0xff;			//WHITE()
	ForGrandColor.b= 0xff;			//WHITE()
}
int	otheroData[10][10];
void	DrawRed(int x, int y)
{
	int	i;

	ForGrandColor= GetColorData(T_RED);			//WHITE()
	for(i= 0; i < 39; i++){
		LineOutNoDraw(160+32*x+1,40+40*y+1+i,160+32*(x+1)-1,40+40*y+1+i);
	}
}
void	DrawGreen(int x, int y)
{
	int	i;

	ForGrandColor= GetColorData(T_GREEN);			//WHITE()
	for(i= 0; i < 39; i++){
		LineOutNoDraw(160+32*x+1,40+40*y+1+i,160+32*(x+1)-1,40+40*y+1+i);
	}
}
void	DrawStone(int x, int y,int no)
{
	if(no == 1){	DrawRed(x,y);	}
	else{			DrawGreen(x,y);	}
}
int	put_chheck(int x,int y,int no)
{
	int	i,j,k,l;
	int	okFlag= -1;

	if(otheroData[y][x] != 0){	return(-1);	}
	//�ׂɕʂ̐΂����邩
	//��
	if(x > 0){
		if((otheroData[y][x-1] != 0) && (otheroData[y][x-1] != no)){
			for(i= x-2; i >= 0; i--){
				if(otheroData[y][i] == no){		//OK
					okFlag= 0;
					for(j= x-1; j > i; j--){

						otheroData[y][j]= no;
						DrawStone(j,y,no);
					}
					break;
				}
			}
		}
	}
	//�E
	if(x < 9){
		if((otheroData[y][x+1] != 0) && (otheroData[y][x+1] != no)){
			for(i= x+2; i <= 9; i++){
				if(otheroData[y][i] == no){		//OK
					okFlag= 0;
					for(j= x+1; j < i; j++){
						otheroData[y][j]= no;
						DrawStone(j,y,no);
					}
					break;
				}
			}
		}
	}
	//��
	if(y > 0){
		if((otheroData[y-1][x] != 0) && (otheroData[y-1][x] != no)){
			for(i= y-2; i >= 0; i--){
				if(otheroData[i][x] == no){		//OK
					okFlag= 0;
					for(j= y-1; j > i; j--){
						otheroData[j][x]= no;
						DrawStone(x,j,no);
					}
					break;
				}
			}
		}
	}
	//��
	if(y < 9){
		if((otheroData[y+1][x] != 0) && (otheroData[y+1][x] != no)){
			for(i= y+2; i <= 9; i++){
				if(otheroData[i][x] == no){		//OK
					okFlag= 0;
					for(j= y+1; j < i; j++){
						otheroData[j][x]= no;
						DrawStone(x,j,no);
					}
					break;
				}
			}
		}
	}
	//�΂ߍ���
	if((x > 0) && (y > 0)){
		if((otheroData[y-1][x-1] != 0) && (otheroData[y-1][x-1] != no)){
			for(i= x-2,j= y-2; (i >= 0) && (j >= 0); i--,j--){
				if(otheroData[j][i] == no){		//OK
					okFlag= 0;
					for(k= x-1,l= y-1; (k > i) && (l > j); k--,l--){
						otheroData[l][k]= no;
						DrawStone(k,l,no);
					}
					break;
				}
			}
		}
	}
	//�΂߉E��
	if((x < 9) && (y > 0)){
		if((otheroData[y-1][x+1] != 0) && (otheroData[y-1][x+1] != no)){
			for(i= x+2,j= y-2; (i <= 9) && (j >= 0); i++,j--){
				if(otheroData[j][i] == no){		//OK
					okFlag= 0;
					for(k= x+1,l= y-1; (k < i) && (l > j); k++,l--){
						otheroData[l][k]= no;
						DrawStone(k,l,no);
					}
					break;
				}
			}
		}
	}
	//�΂ߍ���
	if((x > 0) && (y < 9)){
		if((otheroData[y+1][x-1] != 0) && (otheroData[y+1][x-1] != no)){
			for(i= x-2,j= y+2; (i >= 0) && (j <= 9); i--,j++){
				if(otheroData[j][i] == no){		//OK
					okFlag= 0;
					for(k= x-1,l= y+1; (k > i) && (l < j); k--,l++){
						otheroData[l][k]= no;
						DrawStone(k,l,no);
					}
					break;
				}
			}
		}
	}
	//�΂߉E��
	if((x < 9) && (y < 9)){
		if((otheroData[y+1][x+1] != 0) && (otheroData[y+1][x+1] != no)){
			for(i= x+2,j= y+2; (i <= 9) && (j <= 9); i++,j++){
				if(otheroData[j][i] == no){		//OK
					okFlag= 0;
					for(k= x+1,l= y+1; (k < i) && (l < j); k++,l++){
						otheroData[l][k]= no;
						DrawStone(k,l,no);
					}
					break;
				}
			}
		}
	}
	return(okFlag);
}
int	GetPutArea(int *x,int *y,int no)
{
	int	i,j;
	int	OkFlag= -1;

	for(i= 0; i < 10; i++){
		for(j= 0; j < 10; j++){
			if(otheroData[i][j] == 0){
				if(put_chheck(j,i,no) == 0){
					otheroData[i][j]= no;
					DrawStone(j,i,no);
					OkFlag= 0;	
					break;
				}
			}
		}
		if(j < 10){	break;	}
	}
	return(OkFlag);
}
void	DispAmount(void)
{
	int	i,j;
	int	aka= 0;
	int	midori= 0;
	char	buff[30];

	for(i= 0; i < 10; i++){
		for(j= 0; j < 10; j++){
			if(otheroData[i][j] == 1){
				aka++;
			}
			if(otheroData[i][j] == 2){
				midori++;
			}
		}
	}
	sprintf(buff,"YOU=%3d,CPU=%3d",aka,midori);
	DotTextOut(0,23,buff);
}
void	WaitKeyProc(void)
{
	while(1){
		if(IS_CONSOL( ) != 0){
			GET_CONSOL();
			break;
		}
	}
}
void	DrawRectangleOsero(void)
{
	int	i;
	int	KerCode;
	int	x,y;
	int	ret;

	ClearDisplay();
	memset(otheroData,0,sizeof(otheroData));
	for(i= 0; i < 11; i++){
		LineOutNoDraw(160,40+i*40,160+320,40+i*40);
		LineOutNoDraw(160+i*32,40,160+i*32,40+400);
	}
	DrawRed(4,4);	otheroData[4][4]= 1;
	DrawRed(5,5);	otheroData[5][5]= 1;
	DrawGreen(5,4);	otheroData[5][4]= 2;
	DrawGreen(4,5);	otheroData[4][5]= 2;
	DrawLcd((char *)LcdBuff);
	while(1){
//		KerCode= ScanKey();
		if(KerCode != 0){
			x= (KerCode-1)%(LCD_X_SIZE/MESH_X);
			y= (KerCode-1)/(LCD_X_SIZE/MESH_X);
			if((x >= 10) && (x <= 29) && (y >= 2) && (y <= 21)){
				x-= 10; y-= 2;
				x /= 2; y /= 2;
				if(put_chheck(x,y,1) != 0){	continue;	}
				otheroData[y][x]= 1;
				DrawStone(x,y,1);
				GetPutArea(&x,&y,2);
				DispAmount();
			}
		}
		if(IS_CONSOL( ) != 0){	//
			ret= GET_CONSOL();
			if(ret == '9'){	break;	}		//End
			GetPutArea(&x,&y,2);
			DispAmount();
		}
	}
	ForGrandColor= GetColorData(T_WHITE);			//WHITE()
}
void	LCDCheckMess(void)
{
	DModeSendMsg("1.Rectangle\r\n");
	DModeSendMsg("2.Clear\r\n");
	DModeSendMsg("3.Patarn\r\n");
	DModeSendMsg("9.Exit\r\n");
}
void	LCDCheck(unsigned char *pCmd)
{
	int	ret;

	LCDCheckMess();
	while(1){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			if(ret == '9'){	break;	}
			switch(ret){
			case '1':	DrawRectangle();		break;
			case '2':	ClearDisplay();			break;
			case '3':	DrawRectangleOsero();	break;
			}
			LCDCheckMess();
		}
	}
}
void Lcd_Patarn(int mode);

void	LcdCheck()
{

}

void	setBuzClock(int lowclk, int highclk)
{

}

void	setpulseClock(int lowclk, int highclk)
{

}




void	BuzzerChk()
{
	int		bk=1;
	int		ret;
	char	buff[32];

	DModeSendMsg( "Buz High +100 = 1, Buz High -100 = 2, Buz Low +100 = 3, Buz Low -100 = 4" );
	DModeSendCR();
	DModeSendMsg( "Buz High   +1 = 5, Buz High   -1 = 6, Buz Low   +1 = 7, Buz Low   -1 = 8" );
	DModeSendCR();
	DModeSendMsg("Buzzer ON = B, Buzzer OFF = C");
	DModeSendCR();
	DModeSendMsg( "fpga_peried_clk+1 = A, fpga_peried_clk-1 = S, fpga_width_clk+1 = Z, fpga_width_clk-1 = X" );
	DModeSendCR();
	fpga_peried_clk = 88;
	fpga_width_clk = 44;
	while(bk){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			switch(ret){
				case 'B':	case 'b':
					BuzOn();
					DModeSendMsg("Buzzer ON");
					break;
				case 'C':	case 'c':
					BuzOff();
					DModeSendMsg("Buzzer OFF");
					break;
				case '1':
					if(buzhighclk < 0xffff){
						buzhighclk += 100;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '2':
					if(buzhighclk > 0){
						buzhighclk -= 100;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '3':
					if(buzlowclk < 0xffff){
						buzlowclk += 100;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '4':
					if(buzlowclk > 1){
						buzlowclk -= 100;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '5':
					if(buzhighclk < 0xffff){
						buzhighclk++;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '6':
					if(buzhighclk > 0){
						buzhighclk--;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '7':
					if(buzlowclk < 0xffff){
						buzlowclk++;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case '8':
					if(buzlowclk > 1){
						buzlowclk--;
					}
					setBuzClock(buzlowclk, buzhighclk);
					sprintf(buff,"buzhighclk=%d\r\n",buzhighclk);
					DModeSendMsg(buff);
					sprintf(buff,"buzlowclk=%dHz\r\n",buzlowclk); 
					DModeSendMsg(buff);
					break;
				case 'a':
				case 'A':
					if(fpga_peried_clk < 0xffff){
						fpga_peried_clk++;
					}
					setpulseClock(fpga_peried_clk, fpga_width_clk);
					sprintf(buff,"fpga_peried_clk=%d\r\n",fpga_peried_clk);
					DModeSendMsg(buff);
					sprintf(buff,"fpga_width_clk=%dHz\r\n",fpga_width_clk); 
					DModeSendMsg(buff);
					break;
				case 's':
				case 'S':
					if(fpga_peried_clk > 0){
						fpga_peried_clk--;
					}
					setpulseClock(fpga_peried_clk, fpga_width_clk);
					sprintf(buff,"fpga_peried_clk=%d\r\n",fpga_peried_clk);
					DModeSendMsg(buff);
					sprintf(buff,"fpga_width_clk=%dHz\r\n",fpga_width_clk); 
					DModeSendMsg(buff);
					break;
				case 'z':
				case 'Z':
					if(fpga_width_clk < 0xffff){
						fpga_width_clk++;
					}
					setpulseClock(fpga_peried_clk, fpga_width_clk);
					sprintf(buff,"fpga_peried_clk=%d\r\n",fpga_peried_clk);
					DModeSendMsg(buff);
					sprintf(buff,"fpga_width_clk=%dHz\r\n",fpga_width_clk); 
					DModeSendMsg(buff);
					break;
				case 'x':
				case 'X':
					if(fpga_width_clk > 1){
						fpga_width_clk--;
					}
					setpulseClock(fpga_peried_clk, fpga_width_clk);
					sprintf(buff,"fpga_peried_clk=%d\r\n",fpga_peried_clk);
					DModeSendMsg(buff);
					sprintf(buff,"fpga_width_clk=%dHz\r\n",fpga_width_clk); 
					DModeSendMsg(buff);
					break;
				case '\r':
				case 0x51:
				case 0x71:
					bk=0;
					break;
				default:
					DModeSendMsg("COMMAND ERROR");
					break;
			}
			DModeSendCR();
		}
	}
}



void	DbgLed()
{
	int		ret;
	int		bk=1;
	char	buff[32];

	DModeSendMsg("Run LED ON=1, Run LED OFF=2, Error LED ON=3, Error LED OFF=4");
	DModeSendCR();
	DModeSendMsg("Run SW Status=5, Run SW AD Value=6, Bat AD Value=7, Debug SW AD Value=8");
	DModeSendCR();
	DModeSendMsg("Buzzer ON = B, Buzzer OFF = C, LCD Eable = E, LCD Disable = D");
	DModeSendCR();
	DModeSendMsg("Back Light ON = L, Back Light OFF = P");
	DModeSendCR();
	DModeSendMsg("PORT E0 Output = R, Fpllo out = T, Fout = Y");
	DModeSendCR();
	while(bk){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			switch(ret){
				case 0x31:
					RunLed(ON);
					DModeSendMsg("Run LED ON");
					break;
				case 0x32:
					RunLed(OFF);
					DModeSendMsg("Run LED OFF");
					break;
				case 0x33:
					ErrorLed(ON);
					DModeSendMsg("ErrorLed LED ON");
					break;
				case 0x34:
					ErrorLed(OFF);
					DModeSendMsg("ErrorLed LED OFF");
					break;
				case 0x35:
					ret= RunSWRead();
					sprintf(buff,"Run SW Status=%d\r",ret);
					DModeSendMsg(buff);
					break;
				case 0x37:
					ret= BatteryRead();
					sprintf(buff,"Bat A/D Value=%d\r",ret);
					DModeSendMsg(buff);
					break;
				case 0x42:
				case 0x62:
					BuzOn();
					DModeSendMsg("Buzzer ON");
					break;
				case 0x43:
				case 0x63:
					BuzOff();
					DModeSendMsg("Buzzer OFF");
					break;
				case 0x44:
				case 0x64:
					LCDDisplayEnable(ON);
					DModeSendMsg("LCD Display Disable");
					break;
				case 0x45:
				case 0x65:
					LCDDisplayEnable(OFF);
					DModeSendMsg("LCD Display Enable");
					break;
				case 0x4c:
				case 0x6c:
					BackLightOnOff(ON);
					DModeSendMsg("Back Light ON");
					break;
				case 0x50:
				case 0x70:
					BackLightOnOff(OFF);
					DModeSendMsg("Back Light OFF");
					break;
				case '\r':
				case 0x51:
				case 0x71:
					bk=0;
					break;
				default:
					DModeSendMsg("COMMAND ERROR");
					break;
			}
			DModeSendCR();
		}
	}


}
extern	unsigned char LHexToBin(char as_data);
extern	unsigned int LHexAsToBin(char *buff, int cnt);

char	buff_A[1023];
void	DbgIO()
{

}

void	SerialSet()
{

	int		bk=1;
	int		ret;
	char	buff[32];

	DModeSendMsg("0 = Speed   2400bps ");
	DModeSendCR();
	DModeSendMsg("1 = Speed   9600bps ");
	DModeSendCR();
	DModeSendMsg("2 = Speed  38400bps ");
	DModeSendCR();
	DModeSendMsg("3 = Speed 115200bps ");
	DModeSendCR();

	sprintf(buff,"SPEED = %10d bps \r\n", setspeed);
	DModeSendMsg(buff);

	while(bk){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			switch(ret){
				case '0':
					BuzOn();
					setspeed =   2400;
					break;
				case '1':
					BuzOff();
					setspeed =   9600;
					break;
				case '2':
					BuzOff();
					setspeed =  38400;
					break;
				case '3':
					BuzOff();
					setspeed = 115200;
					break;
				case '\r':
				case 0x51:
				case 0x71:
					bk=0;
					break;
				default:
					DModeSendMsg("COMMAND ERROR");
					break;
			}
			sprintf(buff,"setspeed = %10d bps\r\n",setspeed);
			DModeSendMsg(buff);
			DModeSendCR();
		}
	}
}


void	DbgContrast(unsigned char *pCmd)
{
	unsigned long	cnt;

	cnt= 65;
	pCmd= SkipNextWord( pCmd );
	if( atolx( &cnt, pCmd ) == FALSE ){	cnt= 65;	}
	
}
void	DbgLcdClock(unsigned char *pCmd)
{
	unsigned long	cnt;

	cnt= 10;
	pCmd= SkipNextWord( pCmd );
	if( atolx( &cnt, pCmd ) == FALSE ){	cnt= 65;	}
	
}
EXT_IO_INF		extInfo;	/* �O���ڑ���� */
void	ExtBordCheck(void)
{
	int i;
	unsigned char	*addr;
	unsigned char	id_data;

#ifdef	WIN32
	extInfo.extCnt= 0;
	return;
#endif
	addr= (unsigned char *)EXT_IO_ADDR;
	extInfo.extCnt= 0;
	for(i= 0; i < MAX_EXT_CNT; i++){
		id_data= *addr;
		if(id_data != 0xff){
			extInfo.ExtInfo[extInfo.extCnt].ID= id_data;
			extInfo.ExtInfo[extInfo.extCnt++].address= addr;
		}
		addr += 0x400;
	}
}
void	ExtBoardCheck(unsigned char *pCmd)
{
	int	i;
	int	Operation;
	unsigned char *Register;
	int	data;
	int	ret;
	char buff[64];

	pCmd= SkipNextWord( pCmd );
	//Read/Write
	if( atolx( (unsigned long *)&Operation, pCmd ) == FALSE ){	Operation= 0;	}		//0:check,1:read,2:write
	pCmd= SkipNextWord( pCmd );
	//Register
	if( atolx( (unsigned long *)&Register, pCmd ) == FALSE ){	Register= (unsigned char *)0x0e000000;	}		//Address
	pCmd= SkipNextWord( pCmd );
	//Write Data
	if(Operation == 2){
		if( atolx( (unsigned long *)&data, pCmd ) == FALSE ){	data= 0;	}			//Data
	}
	switch(Operation){
	case 0:		//Check
		ExtBordCheck();
		sprintf(buff,"Count=%d\r\n",extInfo.extCnt);
		DModeSendMsg( buff );
		for(i= 0; i < extInfo.extCnt; i++){
			sprintf(buff,"ID=%02X(%08X)\r\n",
				extInfo.ExtInfo[i].ID & 0x00ff,extInfo.ExtInfo[i].address);
			DModeSendMsg( buff );
		}
		break;
	case 1:		//read
		ret= *Register & 0x00ff;
		sprintf(buff,"data=%02X",ret);
		DModeSendCR();
		DModeSendMsg( buff );
		break;
	case 2:		//write
		*Register= data;
		ret= *Register & 0x00ff;
		sprintf(buff,"data=%02X",ret);
		DModeSendCR();
		DModeSendMsg( buff );
		break;
	}

}

//20080818
unsigned int DModeCommandAs( unsigned char *pCmd )
{	
	switch( GetDModeCmdNo( pCmd ) ){
	case UDCMD_FLOAD:				/* FPGA Data Load */
		FontDownLoad((char *)DownloadBuff,0);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_VER:					/* About */
		DModeSendVersion();			return( TRUE );
	case UDCMD_ECHO:				/* Echo On */
		SioEchoFlag = 1;
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_ECHOOF:				/* Echo Off */
		SioEchoFlag = 0;
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_EXIT:				/* QUIT */
		DModeSendQuitMsg();			return( FALSE );
	case UDCMD_NO_CMD:				/* NO COMMAND */
		DModeSendPronpt();			return( TRUE );
	default:						/* ERROR */
		DModeSendCmdErr( pCmd );
		return( TRUE );
	}
//	return( TRUE );
}

unsigned int DModeCommand( unsigned char *pCmd )
{	
	switch( GetDModeCmdNo( pCmd ) ){
	/**	�������R?���h		**/
	case UDCMD_RC:					/* SendCamera Command */
	case UDCMD_IO:					/* I/O Test */
	case UDCMD_GO:					/* Do Program Continue */
	case UDCMD_BR:					/* Break Point Address */
		DModeSendPronpt();
		return( TRUE );
	/**	����n�R?���h		**/
	case UDCMD_MEM_R:				/* Memory Read */
		DModeMemoryRead( pCmd );	return( TRUE );
	case UDCMD_MEM_W:				/* Memory Write */
		DModeMemoryWrite( pCmd );	return( TRUE );
	case UDCMD_MEM_D:				/* Memory Dump */
		DModeMemoryDump( pCmd );	return( TRUE );
	case UDCMD_MEM_F:				/* Memory Fill */
		DModeMemoryFill( pCmd );	return( TRUE );
	case UDCMD_MEM_S:				/* Memory Subs */
		DModeMemorySubs( pCmd );	return( TRUE );
	case UDCMD_MEM_U:				/* Memory Read */
		DModeMemoryCycleRead( pCmd );	return( TRUE );
	case UDCMD_MEM_L:				/* Memory Write */
		DModeMemoryCycleWrite( pCmd );	return( TRUE );
	case UDCMD_MEM_T:
		DModeMemoryCheck( pCmd );	return( TRUE );
	case UDCMD_MEM_P:
		DModePortOut( pCmd );	return( TRUE );
	case UDCMD_MEM_FC:
		if(FlashCheck() == 0){
			DModeSendMsg( "FLASH OK" );
		}else{
			DModeSendMsg( "FLASH NG" );
		}
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_MEM_CP:
		JmpApl();
		return( TRUE );
	case UDCMD_MEM_FE:
		FlashErazeCheck();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_MEM_FW:
		FlashWriteCheck();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LCD_LT:
		LcdCheck();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_BUZ_BZ:
		BuzzerChk();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_FILE_TEST:
		FileProc();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_CALIB:
		SetTouchCalibration();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LD_START:
		LoaderStart();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_USB_SLAVE:
		UsbSlaveCheck();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LCD_CT:
		DbgContrast(pCmd);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LCD_CLK:
		DbgLcdClock(pCmd);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LED:
		DbgLed();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_IO_TEST:
		DbgIO();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );

//	case UDCMD_W5300_TEST:
//		W5300Test();
//		DModeSendCR();
//		DModeSendPronpt();
//		return( TRUE );
//	case UDCMD_FPGA_WRITE:
//		FpgaWriteMain("C:\\FPGA.DAT");
//		DModeSendCR();
//		DModeSendPronpt();
//		return( TRUE );

	case UDCMD_FPGA_CLK:
		FpgaSignalTest(0);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_FPGA_TDI:
		FpgaSignalTest(1);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_FPGA_TMS:
		FpgaSignalTest(2);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_NAND_DMP:
		DModeNandDump( pCmd );	return( TRUE );


	case UDCMD_RTS_TEST:
		RTSCheck(pCmd);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_LCD_TEST:
		LCDCheck(pCmd);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_PRG_CK:
		FontDownLoad((char *)DownloadBuff,1);
		DModeSendCR();
		DModeSendPronpt();
	case UDCMD_EXT_CK:		//External Boad Check
		ExtBoardCheck(pCmd);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	/**	����R?���h		**/
	case UDCMD_PLOAD:				/* Program Load */
		PloadFlag= TRUE;
		HexLoad((char *)DownloadBuff);
		PloadFlag= FALSE;
		return( TRUE );
	case UDCMD_FLOAD:				/* FPGA Data Load */
		FontDownLoad((char *)DownloadBuff,0);
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_PASS:
		PasswordWrite( pCmd );
		return( TRUE );
	case UDCMD_FRLD:				/* FPGA Data Load */
		FontRamDownLoad();
		DModeSendCR();
		DModeSendPronpt();
		return( TRUE );
	/** �V�X�e?�n�R?���h	**/
	case UDCMD_VER:					/* About */
		DModeSendVersion();			return( TRUE );
	case UDCMD_HELP:				/* HELP */
		DModeSendHelpMsg();			return( TRUE );
	case UDCMD_CHELP:				/* CAM HELP */
		DModeSendCamHelpMsg();		return( TRUE );
	case UDCMD_ECHO:				/* Echo On */
		SioEchoFlag = 1;
		DModeSendPronpt();
		return( TRUE );
	case UDCMD_ECHOOF:				/* Echo Off */
		SioEchoFlag = 0;
		DModeSendPronpt();
		return( TRUE );
 	case UDCMD_SERIAL_SET:			/* Serial Set */ /* 20090717 */
		SerialSet();
		DModeSendCR();
		DModeSendPronpt();
	case UDCMD_EXIT:				/* QUIT */
		DModeSendQuitMsg();			return( FALSE );
	case UDCMD_NO_CMD:				/* NO COMMAND */
		DModeSendPronpt();			return( TRUE );
	default:						/* ERROR */
		DModeSendCmdErr( pCmd );
		return( TRUE );
	}
//	return( TRUE );
}
void	LoaderMessDisp(void)
{
}
int LoginProc( unsigned int cmd, unsigned char *msg )
{
	switch( cmd ){
	case NO_LOGIN:	return( *msg == 0x04 ? RR_LOGIN : NO_LOGIN );
	case RR_LOGIN:
//		if( memcmp( msg, "autonicsprojectii", 17 ) == 0 ){
		if( memcmp( msg, "a", 1 ) == 0 || memcmp( msg, "A", 1 ) == 0){
			DModeSendLoginMsg();		/* Welcome Message */
			LoaderMessDisp();
			return( OK_LOGIN );
		}
		//20080818
//		if( memcmp( msg, "autoas", 6 ) == 0 ){
		if( memcmp( msg, "a", 1 ) == 0 || memcmp( msg, "A", 1 ) == 0){
			DModeSendLoginMsgAs();		/* Welcome Message */
			LoaderMessDisp();
			return( OK_LOGIN_AS );
		}

	}
	return( NO_LOGIN );
}

int DebugTask( int cmd, char *msg )
{
	switch( cmd ){
	case NO_LOGIN:	return( LoginProc( (unsigned char)cmd, (unsigned char *)msg ) );
	case RR_LOGIN:	return( LoginProc( (unsigned char)cmd, (unsigned char *)msg ) );
	case OK_LOGIN:
		if( SubsModeFlag == TRUE ){	DModeSubsProc( (unsigned char *)msg );	}
		else if( DModeCommand( (unsigned char *)msg ) != TRUE ){	return( NO_LOGIN );	}
		break;
	case OK_LOGIN_AS:	//20080818
		if( SubsModeFlag == TRUE ){	DModeSubsProc( (unsigned char *)msg );	}
		else if( DModeCommandAs( (unsigned char *)msg ) != TRUE ){	return( NO_LOGIN );	}
		break;
	}
	return( cmd );
}
void PassWordCheck(char *pbuff)
{
	char msg[256];
extern	int	GetMessage( char *ptr );

	DModeSendMsg( "Input Password" );
	DModeSendCR();

/*	InitCPU();*/
	while( TRUE ){
		if( GetMessage( msg ) != 0 ){
			if(memcmp(pbuff,msg,4) == 0){
				break;
			}
		}
	}
}
void	UsbCheck(void)
{
//	int	ret;
	int	connectflag= 0;

	DModeSendMsg("### USB Check Start ###\r\n");

	while(1){
		if(IS_CONSOL( ) != 0){
			GET_CONSOL();
			break;
		}
		UsbHostDrv( );     /* USB HOST�h���C�o??�X�N */
		if(connectflag != UsbHostConnected){
			connectflag= UsbHostConnected;
			if(connectflag == 0){	DModeSendMsg("USB Disconnect\r\n");	}
			else{
				if(IsDevice(3) != 0){
					DModeSendMsg("USB Connect\r\n");
					GetRootFile();
				}
			}
		}
	}
}
void	FileFormatMess(void)
{
	DModeSendMsg("1.USR1 FORMAT\r\n");
	DModeSendMsg("2.USR2 FORMAT\r\n");
	DModeSendMsg("3.SYS FORMAT\r\n");
	DModeSendMsg("4.RAMDSK FORMAT\r\n");
	DModeSendMsg("5.NAND MAP Clear\r\n");
	DModeSendMsg("9.Exit\r\n");
}
unsigned char testBuff[512];

void	FileFormat(void)
{
	int	ret;
//	int	i;


	FileFormatMess();
	while(1){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			if(ret == '9'){	break;	}
			switch(ret){
			case '1':
				DModeSendMsg("### USR1 FORMAT Start ###\r\n");
				MakeFatFsNand( DEV_USER1_DISK, 2, 16, 1024, 4 );		//Fat16,Sector/Cluster(16MB)
				MountFile(DEV_USER1_DISK);

//for(i= 0; i < 48; i++){
//	NAND_Read_Random(i+FRAFH1_FILE_OFFSET,(unsigned char*)testBuff,0x200);
//}
				
				break;
			case '2':
				DModeSendMsg("### USR2 FORMAT Start ###\r\n");
				MakeFatFsNand( DEV_USER2_DISK, 2, 16, 512, 4 );		//Fat16,Sector/Cluster(32MB)
				MountFile(DEV_USER2_DISK);
				break;
			case '3':
				DModeSendMsg("### SYS FORMAT Start ###\r\n");
				MakeFatFsNand( DEV_SYS_DISK, 2, 16, 512, 4 );		//Fat16,Sector/Cluster(12MB)
				MountFile(DEV_SYS_DISK);

//for(i= 0; i < 48; i++){
//	NAND_Read_Random(i+FRAFH3_FILE_OFFSET,(unsigned char*)testBuff,0x200);
//}
				break;
			case '4':
				DModeSendMsg("### RAMDISK FORMAT Start ###\r\n");
				MakeFatFsNand( DEV_RAM_DISK, 2, 16, 512, 4 );		//Fat16,Sector/Cluster
				MountFile(DEV_RAM_DISK);
				break;

			case 5:
				DModeSendMsg("### NAND MAP Clear Start ###\r\n");
				NAND_Map_Clear();
				break;

			
			}
			FileFormatMess();
		}
	}
}
void	System1FileCopy(char* filename)
{
	int	fp;
	int	wfp;
	int	len;
//	int	i;
	char	dbuff[32];

	fp= Fs_open(filename,O_RDONLY,S_IREAD);
	if(fp < 0){	return;	}
	filename[0]= 'C';
	wfp= Fs_open(filename,O_CREAT,S_IWRITE);
	if(wfp < 0){	Fs_close(fp);	return;	}

	while(1){
		len= Fs_read(fp,(char*)DownloadBuff,0x200000);
		if(len <= 0){	break;	}
		Fs_write(wfp,(char*)DownloadBuff,len);
	}
	Fs_close(wfp);
	Fs_close(fp);
	sprintf(dbuff,"%s Copy End\r\n",filename);
	DModeSendMsg(dbuff);
}
void	System1NationFileCopy(char* filename)
{
	int	fp;
	int	wfp;
	int	len;
//	int	i;
	char	dbuff[32];

	fp= Fs_open(filename,O_RDONLY,S_IREAD);
	if(fp < 0){	return;	}
	filename[0]= 'C';
	wfp= Fs_open(filename,O_CREAT,S_IWRITE);
	if(wfp < 0){	Fs_close(fp);	return;	}

	while(1){
		len= Fs_read(fp,(char*)DownloadBuff,0x200000);
		if(len <= 0){	break;	}
		Fs_write(wfp,(char*)DownloadBuff,len);
	}
	Fs_close(wfp);
	Fs_close(fp);
	sprintf(dbuff,"%s Copy End\r\n",filename);
	DModeSendMsg(dbuff);
}
void	SystemFileCopy(void)
{
	int		err;
	struct find_t finddata;
	char	filename[32];
	int	wfp;

	DModeSendMsg("### System File Copy Start ###\r\n");

	//Dir �쐬

	Fs_mkdir("C:\\NATION");
	Fs_mkdir("C:\\ENGLIS");

	wfp= Fs_open("C:\\NATION\\TEST.DAT",O_CREAT,S_IWRITE);
	if(wfp < 0){	return;	}
	Fs_write(wfp,(char*)"test",4);
	Fs_close(wfp);

	while(1){
		if(IS_CONSOL( ) != 0){
			GET_CONSOL();
			break;
		}
		UsbHostDrv( );     /* USB HOST�h���C�o??�X�N */
		if(UsbHostConnected == 1){
			MountFile(DEV_SYS_DISK);
			System1FileCopy("D:\\ASC68.FNT");
			System1FileCopy("D:\\ASC88.FNT");
			System1FileCopy("D:\\ASC816.FNT");
			System1FileCopy("D:\\HEXA2432.FNT");
			System1FileCopy("D:\\HEXA2448.FNT");
			System1FileCopy("D:\\HEXA2464.FNT");
			System1FileCopy("D:\\HEXA3232.FNT");
			System1FileCopy("D:\\HEXA3248.FNT");
			System1FileCopy("D:\\HEXA3264.FNT");
			System1FileCopy("D:\\HEXA4832.FNT");
			System1FileCopy("D:\\HEXA4848.FNT");
			System1FileCopy("D:\\HEXA4864.FNT");
			System1FileCopy("D:\\HEXA6432.FNT");
			System1FileCopy("D:\\HEXA6448.FNT");
			System1FileCopy("D:\\HEXA6464.FNT");
			System1FileCopy("D:\\NATION.FNT");
			//System File
			sprintf(filename,"D:\\*.GP");
			err = Fs_dos_findfirst(filename, 0, &finddata);
			while(err >= 0){
				if ( (finddata.attrib & FA_DIRECT) == 0x00 ){	//File
					sprintf(filename,"D:\\");
					sprintf(&filename[3],finddata.name);
					System1FileCopy(filename);
				}
				err = Fs_dos_findnext(&finddata);
			}
			//Nation File
			sprintf(filename,"D:\\NATION\\*.GP");
			err = Fs_dos_findfirst(filename, 0, &finddata);
			while(err >= 0){
				if ( (finddata.attrib & FA_DIRECT) == 0x00 ){	//File
					sprintf(filename,"D:\\NATION\\");
					sprintf(&filename[10],finddata.name);
					System1NationFileCopy(filename);
				}
				err = Fs_dos_findnext(&finddata);
			}
			//English File
			sprintf(filename,"D:\\ENGLIS\\*.GP");
			err = Fs_dos_findfirst(filename, 0, &finddata);
			while(err >= 0){
				if ( (finddata.attrib & FA_DIRECT) == 0x00 ){	//File
					sprintf(filename,"D:\\ENGLIS\\");
					sprintf(&filename[10],finddata.name);
					System1NationFileCopy(filename);
				}
				err = Fs_dos_findnext(&finddata);
			}

			DModeSendMsg("### System File Copy End ###\r\n");
			break;
		}
	}
}

void	AplFileCopy(void)
{

	DModeSendMsg("### Application File Copy Start ###\r\n");

	while(1){
		if(IS_CONSOL( ) != 0){
			GET_CONSOL();
			break;
		}
		UsbHostDrv( );     /* USB HOST�h���C�o??�X�N */
		if(UsbHostConnected == 1){
			MountFile(DEV_SYS_DISK);

			strcpy(tempfileName,PATH);
			strcat(tempfileName,FIRM_NAME);

			System1FileCopy(tempfileName);
			DModeSendMsg("### Application File Copy End ###\r\n");
			break;
		}
	}
}
void	LoaderFileCopy(void)
{
	int	fp;
	int	len;

	DModeSendMsg("### Loader File Copy Start ###\r\n");

	while(1){
		if(IS_CONSOL( ) != 0){
			GET_CONSOL();
			break;
		}
		UsbHostDrv( );     /* USB HOST�h���C�o??�X�N */
		if(UsbHostConnected == 1){

			strcpy(tempfileName,PATH);
			strcat(tempfileName,LOAD_NAME);

			fp= Fs_open(tempfileName,O_RDONLY,S_IREAD);
			if(fp < 0){	return;	}
			len= Fs_read(fp,(char*)DownloadBuff,0x200000);
			Fs_close(fp);
			FlashWriteSeq((char*)LOARDER_PROG_AREA,(char*)DownloadBuff,len);
			DModeSendMsg("### Loader File Copy End ###\r\n");
			break;
		}
	}
}





void	BootFileCopy(void)
{
	int	fp;
	int	len;

	DModeSendMsg("### Boot File Copy Start ###\r\n");

	while(1){
		if(IS_CONSOL( ) != 0){
			GET_CONSOL();
			break;
		}
		UsbHostDrv( );     /* USB HOST�h���C�o??�X�N */
		if(UsbHostConnected == 1){

			strcpy(tempfileName,PATH);
			strcat(tempfileName,BOOT_NAME);

			fp= Fs_open(tempfileName,O_RDONLY,S_IREAD);
			if(fp < 0){	return;	}
			len= Fs_read(fp,(char*)DownloadBuff,0x200000);
			Fs_close(fp);
			FlashWriteSeq((char*)BOOT_PROG_AREA,(char*)DownloadBuff,len);
			DModeSendMsg("### Boot File Copy End ###\r\n");
			break;
		}
	}
}

char*	NANDFLASH_FILE_NAME = "D:\\nandflash.bin";

void	NandFlashDataCopy(void)
{
	int	fp;
	int	count;
	int	i,ret;
	char	DispBuff[32];
	
	DModeSendMsg("### NandFlash Data -> USB Memory Copy Start ###\r\n");
	DModeSendMsg("### 0 : 0x200000,  1 : Full, 9 : Exit   ###\r\n");

	ret = 0;
	count = 0;
	while(1){
		if(IS_CONSOL( ) != 0){
			ret = GET_CONSOL();
			if(ret == '9'){	break;	}
			switch(ret){
			case '0':	count = 1;		break;
			case '1':	count = 32;		break;
			}
		}
		if(ret == '0' || ret == '1') {

			DModeSendMsg("### NandFlash Data File Copy Start ###\r\n");
			UsbHostDrv( );     /* USB HOST�h���C�o??�X�N */
			if(UsbHostConnected == 1){

				fp= Fs_open(NANDFLASH_FILE_NAME,O_CREAT,S_IWRITE);
				if(fp < 0){	return;	}

				for(i=0;i<count;i++){

					FlashRead_ECC((char*)DownloadBuff,(char*)(i*0x200000), 0x200000);
					Fs_write(fp, (char*)DownloadBuff,0x210000);

					sprintf(DispBuff,"Block %d : Copy End\r\n",i+1);
					DModeSendMsg(DispBuff);
				}
				Fs_close(fp);

				DModeSendMsg("### NandFlash Data File Copy End ###\r\n");
				DModeSendMsg("### File Create D:\\nandflash.bin ###\r\n");
				break;
			}

		}
	}
}
extern	int NAND_IsBadBlock(unsigned block);
void	NandFlashRomCheck(void)
{
	int	i,j;
	char	buff[32];

	sprintf(buff,"Bad Block Check Start\r\n");
	DModeSendMsg(buff);

	for(i= 0; i < 4096; i++){
		if(NAND_IsBadBlock(i) == 1){
			sprintf(buff,"ErrBlock= %d\r\n",i);
			DModeSendMsg(buff);
		}
		for(j=0;j<100;j++); //wait tWB(100ns)//??????
	}
	sprintf(buff,"Bad Block Check END\r\n");
	DModeSendMsg(buff);
}

extern	void	vFileControl(void);
void	FileProcMess(void)
{
	DModeSendMsg("1.USB Check\r\n");
	DModeSendMsg("2.NAND FILE Format\r\n");
	DModeSendMsg("3.SYS FILE Copy(USB->SYS)\r\n");
	DModeSendMsg("4.APL PROG Copy(USB->SYS)\r\n");
	DModeSendMsg("5.LOADER PROG Copy(USB->)\r\n");
	DModeSendMsg("6.File Ctl\r\n");
	DModeSendMsg("7.BOOT PROG Copy(USB->)\r\n");
	DModeSendMsg("8.NandFlash Copy(NandFlash->USB)\r\n");
	DModeSendMsg("0.NandFlash Check\r\n");
	DModeSendMsg("9.Exit\r\n");
}
void	FileProc(void)
{
	int	ret;
	int	connectflag= 0;


	FileProcMess();
	UsbHostConnected= 0;		//Re Mount
	while(1){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			if(ret == '9'){	break;	}
			switch(ret){
			case '0':	NandFlashRomCheck();break;
			case '1':	UsbCheck();			break;
			case '2':	FileFormat();		break;
			case '3':	SystemFileCopy();	break;
			case '4':	AplFileCopy();		break;
			case '5':	LoaderFileCopy();	break;
			case '6':	vFileControl();		break;
			case '7':	BootFileCopy();		break;
			case '8':	NandFlashDataCopy();		break;			
			}
			FileProcMess();
		}
		UsbHostDrv( );     /* USB HOST�h���C�o??�X�N */
		if(connectflag != UsbHostConnected){
			connectflag= UsbHostConnected;
			if(connectflag == 0){	DModeSendMsg("USB Disconnect\r\n");	}
			else{
				if(IsDevice(3) != 0){
					DModeSendMsg("USB Connect\r\n");
				}
			}
		}
	}
	DModeSendMsg("USB PROC End\r\n");
}
void	InApos(void)
{
//	int	KerCode;
	int	BefNonCalbX,BefNonCalbY;
	char	test_buff[48];

	DModeSendMsg("100,100 Touch\r\n");
	BefNonCalbX= BefNonCalbY= -1;
	ClearDisplay();
	RectAngle(TOUCH_CAL_X1-1,TOUCH_CAL_Y1-1,TOUCH_CAL_X1+1,TOUCH_CAL_Y1+1);
	CalibData[0].PosDigitX= TOUCH_CAL_X1;
	CalibData[0].PosDigitY= TOUCH_CAL_Y1;
	while(1){
		if(IS_CONSOL( ) != 0){
			GET_CONSOL();
			CalibData[0].PosAnalogX= BefNonCalbX;
			CalibData[0].PosAnalogY= BefNonCalbY;
			break;
		}
//		KerCode= ScanKey();
//		ScanKey();
		if((BefNonCalbX != NonCalbX) || (BefNonCalbY != NonCalbY)){
			BefNonCalbX= NonCalbX;
			BefNonCalbY= NonCalbY;
			sprintf(test_buff,"Touch=[%5d,%5d]",NonCalbX,NonCalbY);
			DotTextOut(5,3,test_buff);
		}
	}
}
void	InBpos(void)
{
//	int	KerCode;
	int	BefNonCalbX,BefNonCalbY;
	char	test_buff[48];

	DModeSendMsg("600,400 Touch\r\n");
	BefNonCalbX= BefNonCalbY= -1;
	ClearDisplay();
	RectAngle(TOUCH_CAL_X2-1,TOUCH_CAL_Y2-1,TOUCH_CAL_X2+1,TOUCH_CAL_Y2+1);
	CalibData[1].PosDigitX= TOUCH_CAL_X2;
	CalibData[1].PosDigitY= TOUCH_CAL_Y2;
	while(1){
		if(IS_CONSOL( ) != 0){
			GET_CONSOL();
			CalibData[1].PosAnalogX= BefNonCalbX;
			CalibData[1].PosAnalogY= BefNonCalbY;
			break;
		}
//		KerCode= ScanKey();
//		ScanKey();
		if((BefNonCalbX != NonCalbX) || (BefNonCalbY != NonCalbY)){
			BefNonCalbX= NonCalbX;
			BefNonCalbY= NonCalbY;
			sprintf(test_buff,"Touch=[%5d,%5d]",NonCalbX,NonCalbY);
			DotTextOut(5,3,test_buff);
		}
	}

}
void	InposSave(void)
{
	FlashWriteSeq((char*)TOUCH_CALIB_AREA,(char*)&CalibData[0],sizeof(CalibData));
}
void	TouchCalibrationMess(void)
{
	DModeSendMsg("1.A-Position\r\n");
	DModeSendMsg("2.B-Position\r\n");
	DModeSendMsg("8.Save Exit\r\n");
	DModeSendMsg("9.Exit\r\n");
}
void	SetTouchCalibration(void)
{
	int	ret;

	TouchCalibrationMess();
	while(1){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			if(ret == '9'){	break;	}
			switch(ret){
			case '1':	InApos();		break;
			case '2':	InBpos();		break;
			case '8':	InposSave();	break;
			}
			if(ret == '8'){	break;	}
			TouchCalibrationMess();
		}
	}
}
void	LoaderStart(void)
{
	void	(*lfunc)();

	FlashReadSeq((char*)0x30010000,(char*)LOARDER_PROG_AREA,0x80000);	//1M Read
	_di();
	lfunc = (void (*)())0x30010000;
	lfunc();
}
void	UsbSlaveCheck(void)
{
	int	ret;

	DModeSendMsg("USB Slave Start\r\n");
//	UsbDevIntEnable();
//	UsbDevHandlerInit();
//	MakeFatFs( 0, 2, 16, 512, 4 );		//Fat16,Sector/Cluster=8
	while(1){
		if(IS_CONSOL( ) != 0){
			ret= GET_CONSOL();
			if(ret == '9'){	break;	}
		}
//		if( CheckUsbRecData() != 0 ){
//			UsbDevHandler();
//		}
	}
	DModeSendMsg("USB Slave End\r\n");
}
int	Fs2AltWrite(unsigned char data);
#define IO_TCK     0x40		//GPJ6
#define IO_TDI     0x20		//GPG5
#define IO_TMS     0x80		//GPB7
#define IO_TRST    0x00 /* 0 Means it does not exist */
#define IO_TDO     0x40		//GPB6

void	FpgaSignalTest(int type)
{
	volatile IOP_REG    *pIOPReg= (volatile IOP_REG *)IOP_BASE;

	while(1){
		if(IS_CONSOL() != 0){
			GET_CONSOL();
			break;
		}
		switch(type){
		case 0:
			pIOPReg->rGPJDAT |= IO_TCK;
			pIOPReg->rGPJDAT &= ~IO_TCK;
			break;
		case 1:
			pIOPReg->rGPGDAT |= IO_TDI;
			pIOPReg->rGPGDAT &= ~IO_TDI;
			break;
		case 2:
			pIOPReg->rGPBDAT |= IO_TMS;
			pIOPReg->rGPBDAT &= ~IO_TMS;
			break;
		}
	}
}

/************************************************************/
/*	NAND Dump�����֐�										*/
/************************************************************/
unsigned char	NandReadArea[0x200+16];
void MakeNandDumpStr( unsigned int type, char *pBuf, unsigned long spos,
							unsigned long size, unsigned long cpos, unsigned long dpos )
{
	char	frm[16];
	unsigned int	i, max;
	unsigned char	cc;			/* ?������ */
	unsigned long	xp, pos;	/* ���ڃA�h���X,�A�h���X?�W�V����*/
	unsigned long	sadrs, eadrs, epos;

	pos= cpos;
	/* ?���J�n�A�h���X */
	sprintf( pBuf, "%08X: ", pos- (pos% 16) );
	pBuf+= 10;

	/* �f??�i�P�U�i?�L�j */
	xp= pos- (pos% 16);						/* �J�����g?�C��? */
	epos= spos+ size;						/* �I�����A�h���X */
	sadrs= spos- (spos% type);				/* ?���J�n�A�h���X */
	eadrs= epos+ (epos% type == 0 ? 0 : type- epos% type);
											/* ?���I���A�h���X */
	max= 16/ type;							/* �P�s?���ő�� */
	sprintf( frm, "%%0%dX ", type* 2 );		/* ?��?���w�� */
	for( i= 0; i < max; i++, xp+= type ){
		if( i == max/ 2 ){					/* ������?�� */
			sprintf( pBuf, " " );
			pBuf++;
		}
		if( xp < sadrs || xp >= eadrs ){	/* ?�L�Ȃ� */
			sprintf( pBuf, "         " );	/* MAX LONG */
		}
		else{								/* �f???�� */
			sprintf( pBuf, frm, 
				type == TYPE_BYTE ? (unsigned char )*(unsigned char  *)dpos :
				type == TYPE_LONG ? (unsigned long )*(unsigned long  *)dpos :
									(unsigned short)*(unsigned short *)dpos );
			dpos+= type;
		}
		pBuf+= (type* 2+ 1);
	}

	/* ��؂蕶�� */
	sprintf( pBuf, " " );
	pBuf+= 1;
	
	/* �f??�i����?�L�j */
	xp= dpos- (dpos% 16);		/* ���ڃA�h���X */
	for( i= 0; i < 16; i++, xp++ ){
		if( i == (16/ 2) ){		/* ������?�� */
			sprintf( pBuf, " " );
			pBuf++;
		}
		cc= *(unsigned char *)xp;
		if(      xp <  sadrs ){	sprintf( pBuf, " " );		}
		else if( xp >= eadrs ){	sprintf( pBuf, " " );		}
		else{
			if( cc < ' ' ){						sprintf( pBuf, "." );		}
			else if( cc < 0x7F){				sprintf( pBuf, "%c", cc );	}
			else if( 0xA0 < cc && cc < 0xE0 ){	sprintf( pBuf, "%c", cc );	}
			else{								sprintf( pBuf, "." );		}
		}
		pBuf++;
	}
}
unsigned int DModeNandDump( unsigned char *pCmd )
{
	char buf[80];
	unsigned int i, ret= TRUE;
	unsigned int type;
	unsigned long adr, sadr, size;

	if( ret == TRUE ){					/* �R?���h */
		pCmd++;			/* Skip 'D' */
		switch( *pCmd ){
		case '\0':
		case '\a':
		case '\r':
		case ' ':	type= TYPE_WORD;	break;
		case 'B':	type= TYPE_BYTE;	break;
		case 'W':	type= TYPE_WORD;	break;
		case 'L':	type= TYPE_LONG;	break;
		default:	ret= FALSE;			break;
		}
		pCmd= SkipNextWord( pCmd );
	}
	if( ret == TRUE ){					/* �A�h���X */
		if( atolx( &adr, pCmd ) == FALSE ){	adr= DefaultAdress;	}	
		pCmd= SkipNextWord( pCmd );
	}
//	if( ret == TRUE ){					/* �T�C�Y�E�I���A�h���X */
//		if( *pCmd == '\\' ){	/* �T�C�Y */
//			pCmd++;
//			atolx( &size, pCmd );
//		}
//		else{					/* �I���A�h���X */
//			if( atolx( &end, pCmd ) == FALSE ){	size= 16* 8;		}	/* DEFALT */
//			else if( adr < end ){				size= end- adr+ 1;	}
//			else{								ret= FALSE;			}
//		}
//		end= adr+ size;
//		pCmd= SkipNextWord( pCmd );
//	}
	if( ret == TRUE ){			/* ���� */
		FlashRead_ECC((char*)NandReadArea,(char*)adr,512);
		size= 16*33;
		for( i= 0; i < 33; i++ ){
			sadr= adr+ i* 16;		/* ?���擪�̃A�h���X�擾 */
			MakeNandDumpStr( type, buf, adr, size, sadr,  (unsigned long)&NandReadArea[i*16]);
			DModeSendMsg( buf );
			DModeSendCR();
		}
	}
	if( ret != TRUE ){
		DModeSendMsg( "ERROR!" );
		DModeSendCR();
	}
	DefaultAdress= adr+ 16* 8;
	DModeSendPronpt();

	return( ret );
}
