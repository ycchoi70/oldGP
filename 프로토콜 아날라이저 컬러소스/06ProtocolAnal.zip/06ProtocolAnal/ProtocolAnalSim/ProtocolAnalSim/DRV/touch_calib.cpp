/*	$ JBOSN : touch.c, v 0.1 2003/09/01 $	*/

/*
 * Copyright (C) 2003	iBOSN systems
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are not permitted completely.
 *
 */

/*
 * Module Name: touch.c
 *
 * Purpose: touch pad interface for graphic system of j-bosn
 */
#define	TOUCH_CALIB_PROC
#include "define.h"


typedef struct _MATRIX      MATRIX;
typedef struct _MATRIX     *PMATRIX;
struct _MATRIX
{
    __int64   a11, a12, a13;
    __int64   a21, a22, a23;
    __int64   a31, a32, a33;
};

typedef struct _CALIBRATION     CALIBRATION;
typedef struct _CALIBRATION    *PCALIBRATION;
struct _CALIBRATION
{
    int   a1;
    int   b1;
    int   c1;
    int   a2;
    int   b2;
    int   c2;
    int   Delta;
};



static  int                    bCalibrated = FALSE;
static  CALIBRATION             Calibration;


__int64	MatrixOp( PMATRIX pMatrix )
{
    __int64       Rest;
    __int64       Temp;
    
    Temp = pMatrix->a11 * pMatrix->a22;
    Rest = Temp * pMatrix->a33;
    
    Temp = pMatrix->a21 * pMatrix->a32;
    Temp = Temp * pMatrix->a13;
    Rest = Rest + Temp;

    Temp = pMatrix->a12 * pMatrix->a23;
    Temp = Temp * pMatrix->a31;
    Rest = Rest + Temp;
    
    Temp = pMatrix->a13 * pMatrix->a22;
    Temp = Temp * pMatrix->a31;
    Rest = Rest - Temp;

    Temp = pMatrix->a12 * pMatrix->a21;
    Temp = pMatrix->a33 * Temp;
    Rest = Rest - Temp;

    Temp = pMatrix->a23 * pMatrix->a32;
    Temp = Temp * pMatrix->a11;
    Rest = Rest - Temp;

    return Rest;
}


int
TouchCalibration( int* pXscr, int* pYscr, int* pXtch, int* pYtch)
{
    int   Xscrmin = pXscr[1];
    int   Yscrmin = pYscr[1];
    int   Xscrmax = pXscr[3];
    int   Yscrmax = pYscr[3];

    int   Xtchmin = pXtch[1];
    int   Ytchmin = pYtch[1];
    int   Xtchmax = pXtch[3];
    int   Ytchmax = pYtch[3];

    Calibration.Delta = (1<< 16);

    
    Calibration.a1 = Calibration.Delta*( Xscrmin - Xscrmax ) / (Xtchmin - Xtchmax);
    Calibration.b1 = 0;
    Calibration.c1 = (Calibration.Delta * Xscrmin) - (Calibration.a1*Xtchmin) ;
    
    Calibration.a2 = 0;
    Calibration.b2 = Calibration.Delta*( Yscrmin - Yscrmax ) / (Ytchmin - Ytchmax);
    Calibration.c2 = (Calibration.Delta * Yscrmin) - (Calibration.b2*Ytchmin);

    bCalibrated = TRUE;

    return TRUE;
}

/*
int
TouchCalibration( int* pXscr, int* pYscr, int* pXtch, int* pYtch)
{
    int   i;
    FLOAT   Sx, Sy, Sxy, Sxx, Syy, Sm, Sn, Smx, Smy, Snx, Sny, S;
    FLOAT   T1, T2, T3, T4, T5, T6, Q;

    Sx = Sy = Sxy = Sxx = Syy = Sm = Sn = Smx = Smy = Snx = Sny = S = 0;

    for( i = 0; i < 5; i++ )
    {
        Sx  += pXtch[i];
        Sy  += pYtch[i];
        Sxy += pXtch[i] * pYtch[i];
        Sxx += pXtch[i] * pXtch[i];
        Syy += pYtch[i] * pYtch[i];

        Sm  += pXscr[i];
        Sn  += pYscr[i];
        Smx += pXscr[i] * pXtch[i];
        Smy += pXscr[i] * pYtch[i];
        Snx += pYscr[i] * pXtch[i];
        Sny += pYscr[i] * pYtch[i];
        
        S += 1;
    }
    

    T1 = Sxy * Sy - Sx * Syy;
    T2 = Sxy * Sx - Sxx * Sy;
    T3 = Sxx * Syy - Sxy * Sxy;
    T4 = Syy * S - Sy * Sy;
    T5 = Sx * Sy - Sxy * S;
    T6 = Sxx * S - Sx * Sx;
    
    Q = T1 * Sx + T2 * Sy + T3 * S;

    if( Q == 0 )
        return FALSE;
        
    Calibration.Delta = (1<<16);
    Calibration.a1 = ((T4 *Smx + T5 * Smy + T1 * Sm) / Q + 0.5/65536) * 65536;
    Calibration.b1 = ((T5 *Smx + T6 * Smy + T2 * Sm) / Q + 0.5/65536) * 65536;
    Calibration.c1 = ((T1 *Smx + T2 * Smy + T3 * Sm) / Q + 0.5/65536) * 65536;
    
    Calibration.a2 = ((T4 *Snx + T5 * Sny + T1 * Sn) / Q + 0.5/65536) * 65536;
    Calibration.b2 = ((T5 *Snx + T6 * Sny + T2 * Sn) / Q + 0.5/65536) * 65536;
    Calibration.c2 = ((T1 *Snx + T2 * Sny + T3 * Sn) / Q + 0.5/65536) * 65536;


    if( (Calibration.a1 == 0x80000000) ||
        (Calibration.b1 == 0x80000000) ||
        (Calibration.c1 == 0x80000000) ||
        (Calibration.a2 == 0x80000000) ||
        (Calibration.b2 == 0x80000000) ||
        (Calibration.c2 == 0x80000000) )
            return FALSE;

    return TRUE;
}
*/

void
TouchCalibrate( int Xtch, int Ytch, int *pXscr, int *pYscr)
{
    int   X, Y;

    if ( !bCalibrated )
    {
        *pXscr = Xtch;
        *pYscr = Ytch;

        return;
    }

//    DEBUG2(1," Xtch = %D\n", Xtch );
//    DEBUG2(1," Ytch = %D\n", Ytch );

    X = (Calibration.a1 * Xtch + Calibration.b1 * Ytch + Calibration.c1) / Calibration.Delta;
    Y = (Calibration.a2 * Xtch + Calibration.b2 * Ytch + Calibration.c2) / Calibration.Delta;


//    DEBUG2(1," Calibration.a2 * Xtch = %D\n", Calibration.a2 * Xtch );
//    DEBUG2(1," Calibration.b2 * Ytch = %D\n", Calibration.b2 * Ytch );
//    DEBUG2(1," Calibration.a2 * Xtch + Calibration.b2 * Ytch = %D\n", Calibration.a2 * Xtch + Calibration.b2 * Ytch );
//    DEBUG2(1," Calibration.a2 * Xtch + Calibration.b2 * Ytch + Calibration.c2 = %D\n", Calibration.a2 * Xtch + Calibration.b2 * Ytch + Calibration.c2 );
//    DEBUG2(1," (Calibration.a2 * Xtch + Calibration.b2 * Ytch + Calibration.c2) / Calibration.Delta = %D\n", (Calibration.a2 * Xtch + Calibration.b2 * Ytch + Calibration.c2) / Calibration.Delta );
//
//
//    DEBUG2(1," Calibration.a1 = %D\n", Calibration.a1 );
//    DEBUG2(1," Calibration.b1 = %D\n", Calibration.b1 );
//    DEBUG2(1," Calibration.c1 = %D\n", Calibration.c1 );
//    DEBUG2(1," Calibration.a2 = %D\n", Calibration.a2 );
//    DEBUG2(1," Calibration.b2 = %D\n", Calibration.b2 );
//    DEBUG2(1," Calibration.c2 = %D\n", Calibration.c2 );
//    DEBUG2(1," Calibration.Delta = %D\n", Calibration.Delta );
//
//    DEBUG2(1," Calibration X = %D\n", X );
//    DEBUG2(1," Calibration Y = %D\n", Y );

    if( X < 0 ) X = 0;
    if( Y < 0 ) Y = 0;

    *pXscr = (int)X;
    *pYscr = (int)Y;
}
