/****************************************************
*  PCMCIA flush memory control program				*
*			1997,4,22		Ver 1.10				*
*	Create:Ver 1.10		97.04.22 Sugita				*
*	Update:Ver 1.11		97.05.01 Kenichiro Fujiwara	*
*****************************************************/
#include	<string.h>
#include	"doscomm.h"
#include	"glpdos.h"
#include	"pcmcia.h"
#include	"define.h"
#include	"nand.h"
#include	"usbh.h"
#include	"udebtsk.h"
//#include	"mmcdrv.h"

#define	READ_SECTOR				2
#define	WRITE_SECTOR			3


extern	int	DisMountMedia (int drive);

int	WaitDrvRdyCheck( void );

int	MountMedia (int drive);
int	ReadBPB (int drive, XBPB *xBPB);
//long	Partion;

volatile	int		PCCardHasBeenMounted[MAX_DEVICE];	/*  */
//int	drive ;	 /* 2 = c: */


int	InitCard(void);

typedef	struct MediaInfoFrm_t {
	long	TotalKB;
	long	OccupiedKB;
	long	FreeKB;
} MediaInfoFrm;


long	SectBytes;
long	ClustSects;
long	MaxClust;
long	ClustBytes;
MediaInfoFrm	MediaInfo;
volatile	long	CardFreeSize;		/* Card Free Size /1024 byte */
volatile	long	CardRSize;
volatile	long	CardSize;


void	Delay400ns(void)
{
	int		i;
	for(i= 0; i < 30; i++){
		;
	}
}
/****************************************************
*  Card I/O service functions						*
****************************************************/

/****************************************************
*  Real Write sectors								*
****************************************************/
void	SendStrageHandler(int drive, int command, long sect, BYTE *buffer, long datasize)
{

	switch(drive){
	case DEV_USER1_DISK:			//NAND Flash File
		if(command == READ_SECTOR){
			NAND_Read_Random(sect+FRAFH1_FILE_OFFSET,(unsigned char*)buffer,datasize);
		}else{
			NAND_Write_Random(sect+FRAFH1_FILE_OFFSET,(unsigned char*)buffer,datasize);
		}
		break;
	case DEV_USER2_DISK:
		if(command == READ_SECTOR){
			NAND_Read_Random(sect+FRAFH2_FILE_OFFSET,(unsigned char*)buffer,datasize);
		}else{
			NAND_Write_Random(sect+FRAFH2_FILE_OFFSET,(unsigned char*)buffer,datasize);
		}
		break;
	case DEV_SYS_DISK:
		if(command == READ_SECTOR){
			NAND_Read_Random(sect+FRAFH3_FILE_OFFSET,(unsigned char*)buffer,datasize);
		}else{
			NAND_Write_Random(sect+FRAFH3_FILE_OFFSET,(unsigned char*)buffer,datasize);
		}
		break;
	case DEV_USB_DISK:			//USB(HOST) Mass Strage
		if(command == READ_SECTOR){
			UsbReadSector(sect,datasize,(unsigned char*)buffer);
		}else{
			UsbWriteSector(sect,datasize,(unsigned char*)buffer);
		}
		break;
	case DEV_USER3_DISK:		//LP Data File
		if(command == READ_SECTOR){
			NAND_Read_Random(sect+FRAFH4_FILE_OFFSET,(unsigned char*)buffer,datasize);
		}else{
			NAND_Write_Random(sect+FRAFH4_FILE_OFFSET,(unsigned char*)buffer,datasize);
		}
		break;
	case DEV_RAM_DISK:			//RAM DISK
		if(command == READ_SECTOR){
			memcpy((unsigned char*)buffer,(char*)((sect*SECTOR_SIZE)+RAMDISK_ADDRESS),datasize);
		}else{
			memcpy((char*)((sect*SECTOR_SIZE)+RAMDISK_ADDRESS),(unsigned char*)buffer,datasize);
		}
		break;
	case DEV_PTN_DISK:		//PTN DISK
		if(command == READ_SECTOR){
			memcpy((unsigned char*)buffer,(char*)((sect*SECTOR_SIZE)+RAMDISK_ADDRESS),datasize);
		}else{
			memcpy((char*)((sect*SECTOR_SIZE)+RAMDISK_ADDRESS),(unsigned char*)buffer,datasize);
		}
		break;
	}
	return;
}
void WriteCard (int drive, long sect, BYTE *buffer, long datasize)
{
	SendStrageHandler(drive,WRITE_SECTOR,sect,buffer,datasize);
}
/****************************************************
*  Real Read sectors								*
****************************************************/
void ReadCard (int drive, long sect, BYTE *buffer, long datasize)
{
	SendStrageHandler(drive,READ_SECTOR,sect,buffer,datasize);
}

/****************************************************
* Flush Card Sectors								*
****************************************************/

void	EraseSectors (int drive, long sect, int sectors)
{
	switch(drive){
	case 0:			//NAND Flash File
		break;
	case 1:			//NAND Flash File
		break;
	default:			//USB Mass Strage
		break;
	}
	return;
}

/****************************************************
*  Test For Card Flush end							*
****************************************************/
int	TestForErasedSectors (void)
{
	return TRUE;
}

/********************************************************
*  Get Card File System blocking parameter block		*
********************************************************/
int	ReadBPB (int drive, XBPB *xBPB)
{
//	int	Mode;
	BYTE	buffer[512];
	BYTE	*pBuf;
	MBRecode	*pMbr;
	unsigned int	work;
	unsigned short	swork;
	int	bootSector;
	
	xBPB->StartSectorOffset= 0;
	ReadCard (drive, 0, buffer, 512L);		//0 Sector Read
	pMbr= (MBRecode*)buffer;
	xBPB->FatType = 12;					/* FAT type 0:12, 1:16, 2:32 */
//	if(pMbr->checkRoutionOnx86[0] != 0xeb){		//USB MMC Check
	if(memcmp(&buffer[3],"MSDOS",5) != 0){		//2011.1.13 add
		bootSector= pMbr->partitionTable[0].firstSectorNumbers[0];
		bootSector+= pMbr->partitionTable[0].firstSectorNumbers[1] << 8;				//20100331
		bootSector+= pMbr->partitionTable[0].firstSectorNumbers[2] << 16;				//20100331
		bootSector+= pMbr->partitionTable[0].firstSectorNumbers[3] << 24;				//20100331
		if(bootSector < 0){	return FALSE;		}										//20100331

		xBPB->StartSectorOffset= bootSector;
		xBPB->FatType = 16;					/* FAT type 0:12, 1:16, 2:32 */
		switch(pMbr->partitionTable[0].fileSystemDescriptor){
		case 1:
			xBPB->FatType = 12;					/* FAT type 0:12, 1:16, 2:32 */
			break;
		case 4: case 6: case 14:
			xBPB->FatType = 16;					/* FAT type 0:12, 1:16, 2:32 */
			break;
		case 12: case 13:
			xBPB->FatType = 32;					/* FAT type 0:12, 1:16, 2:32 */
			break;
		}

		ReadCard (drive, bootSector, buffer, 512L);		//0 Sector Read
		//MSDOS(FAT) Check							//2011.1.13 add
		if(memcmp(&buffer[3],"MSDOS",5) != 0){		//2011.1.13 add
			if(memcmp(&buffer[3],"MSWIN",5) != 0){		//2011.08.17 add
				return FALSE;							//2011.1.13 add
			}
		}											//2011.1.13 add
	}
	//MSDOS(FAT) Check							//20010 add
//	if(memcmp(&buffer[3],"MSDOS",5) != 0){		//20010 add
//		return FALSE;							//20010 add
//	}											//20010 add

	pBuf = buffer;
	xBPB->DUMMY0[0] = *pBuf++;			/* near jmp with Nop */
	xBPB->DUMMY0[1] = *pBuf++;			/* near jmp with Nop */
	xBPB->DUMMY0[2] = *pBuf++;			/* near jmp with Nop */
	memcpy(xBPB->Name,pBuf,8);			/* product name */
	pBuf += 8;
	swork = (unsigned short)*pBuf++;
	swork += (unsigned short)((unsigned short)*pBuf++ << 8);
	xBPB->SectorPerBytes = (short)swork;		/* Sector/Bytes */
	xBPB->ClusterPerSectors = *pBuf++;			/* cluster/Sectors */
	swork = (unsigned short)*pBuf++;
	swork += (unsigned short)((unsigned short)*pBuf++ << 8);
	xBPB->ReservedSectors = (short)swork;		/* reserved sectors */
	xBPB->AllocFat = *pBuf++;					/* number of fat alloction (1 or 2) */
	swork = (unsigned short)*pBuf++;
	swork += (unsigned short)((unsigned short)*pBuf++ << 8);
	xBPB->Dirs = (unsigned short)swork;		/* root directorys */
	swork = (unsigned short)*pBuf++;
	swork += (unsigned short)((unsigned short)*pBuf++ << 8);
	xBPB->Sectors = (unsigned short)swork;	/* number of sectors */
	xBPB->discripter = *pBuf++;				/* Media Discripter */
	swork = (unsigned short)*pBuf++;
	swork += (unsigned short)((unsigned short)*pBuf++ << 8);
	if(swork == 0){		//FAT32
		xBPB->FatType = 32;					/* FAT type 0:12, 1:16, 2:32 */
	}
	if(xBPB->FatType == 12){
		if((xBPB->Sectors/xBPB->ClusterPerSectors) > 0x1000){
			xBPB->FatType = 16;					/* FAT type 0:12, 1:16, 2:32 */
		}
	}
	xBPB->FatPerSectors = (short)swork;		/* FAT area size */
	swork = (unsigned short)*pBuf++;
	swork += (unsigned short)((unsigned short)*pBuf++ << 8);
	xBPB->DUMMY1 = (short)swork;				/* Track/Sectors */
	swork = (unsigned short)*pBuf++;
	swork += (unsigned short)((unsigned short)*pBuf++ << 8);
	xBPB->DUMMY2 = (short)swork;				/* heads */
	work = (unsigned int)*pBuf++;
	work += (unsigned int)((unsigned int)*pBuf++ << 8);
	work += (unsigned int)((unsigned int)*pBuf++ << 16);
	work += (unsigned int)((unsigned int)*pBuf++ << 24);
	xBPB->HiddenSectors = (long)work;		/* hidden sectors */
	work = (unsigned int)*pBuf++;
	work += (unsigned int)((unsigned int)*pBuf++ << 8);
	work += (unsigned int)((unsigned int)*pBuf++ << 16);
	work += (unsigned int)((unsigned int)*pBuf++ << 24);
	xBPB->Sectors2 = (long)work;			/* maximum sectors (over 32MB) */
	if(xBPB->FatType == 12){
		if(xBPB->Sectors == 0){
			if((xBPB->Sectors2/xBPB->ClusterPerSectors) > 0x1000){
				xBPB->FatType = 16;					/* FAT type 0:12, 1:16, 2:32 */
			}
		}
	}
	if(xBPB->FatType == 32){					/* FAT type 0:12, 1:16, 2:32 */
		work = (unsigned int)*pBuf++;
		work += (unsigned int)((unsigned int)*pBuf++ << 8);
		work += (unsigned int)((unsigned int)*pBuf++ << 16);
		work += (unsigned int)((unsigned int)*pBuf++ << 24);
		xBPB->FatPerSectors = (short)work;		/* FAT area size */
		pBuf++;
		pBuf++;
		pBuf++;
		pBuf++;
		work = (unsigned int)*pBuf++;
		work += (unsigned int)((unsigned int)*pBuf++ << 8);
		work += (unsigned int)((unsigned int)*pBuf++ << 16);
		work += (unsigned int)((unsigned int)*pBuf++ << 24);
		xBPB->Dirs= work;					//root Sector

	}

	return TRUE;
}

int	MountFile(int drv)
{
#ifndef	WIN32

	if ( !MountMedia (drv) ) {
		return	-2;				/* NG --> -2 */
	}

#else
#endif

	return	OK;
}
int	DismountFile(int drv)
{
#ifndef	WIN32

	if ( !DisMountMedia (drv) ) {
		return	-2;				/* NG --> -2 */
	}
#endif
	return	OK;
}
void	GetRootFile(void)
{
	int		err;

	struct find_t finddata;
	char	filename[16];

	strcpy(filename,"D:\\");
	err = Fs_dos_findfirst(filename, 0, &finddata);
	while(err >= 0){
		// Volumem Label Check
		if ( (finddata.attrib & FA_LABEL) == 0x00 ) {
			DModeSendMsg(finddata.name);
			DModeSendMsg("\r\n");
		}
		err = Fs_dos_findnext(&finddata);
	}
}


#ifdef	OLD
char	testWbuff[1024];
char	testRbuff[4096];
void	FileTest( void )
{
#ifndef	OLD
	int	i,cnt;
	int	fp;

	for(i= 0; i < 1024; i++){
		testWbuff[i]= i;
	}
	fp = Fs_open("B:\\test.dat",O_CREAT,S_IWRITE);
	if(fp >= 0){
		cnt= Fs_write (fp, testWbuff,sizeof(testWbuff));
		Fs_close(fp);

	}
	memset(testRbuff,0xff,sizeof(testRbuff));
	fp = Fs_open("B:\\test.dat",O_RDONLY,S_IREAD);
	if(fp >= 0){
		cnt= Fs_seek(fp,10,FS_SEEK_CUR);
		if(cnt == 0){
			cnt= Fs_read (fp, testRbuff,sizeof(testRbuff));
		}
		cnt= Fs_seek(fp,0,FS_SEEK_SET);
		if(cnt == 0){
			cnt= Fs_read (fp, testRbuff,sizeof(testRbuff));
		}
		cnt= Fs_seek(fp,0,FS_SEEK_END);
		if(cnt == 0){
			cnt= Fs_read (fp, testRbuff,sizeof(testRbuff));
		}
		Fs_close(fp);
		for(i= 0; i < 1024; i++){
			testWbuff[i]= 1023-i;
		}
		fp = Fs_open("B:\\test.dat",O_APPEND,S_IREAD);
		{
			cnt= Fs_write (fp, testWbuff,sizeof(testWbuff));
			Fs_close(fp);
		}
		memset(testRbuff,0xff,sizeof(testRbuff));
		fp = Fs_open("B:\\test.dat",O_RDONLY,S_IREAD);
		if(fp >= 0){
			cnt= Fs_read (fp, testRbuff,sizeof(testRbuff));
			Fs_close(fp);
		}
	}




//	for(i= 0; i < 1024; i++){
//		testWbuff[i]= 1023-i;
//	}
//	fp = Fs_open("B:\\test.dat",O_CREAT,S_IWRITE);
//	if(fp >= 0){
//		cnt= Fs_write (fp, testWbuff,sizeof(testWbuff));
//		Fs_close(fp);
//
//	}
	memset(testRbuff,0xff,sizeof(testRbuff));
	fp = Fs_open("B:\\test.dat",O_RDONLY,S_IREAD);
	if(fp >= 0){
		Fs_read (fp, testRbuff,sizeof(testRbuff));
		Fs_close(fp);

	}
	for(i= 0; i < 1024; i++){
		testWbuff[i]= 1023-i;
	}
	fp = Fs_open("B:\\test.dat",O_CREAT,S_IWRITE);
	if(fp >= 0){
		Fs_write (fp, testWbuff,sizeof(testWbuff));
		Fs_close(fp);

	}
	memset(testRbuff,0xff,sizeof(testRbuff));
	fp = Fs_open("B:\\test.dat",O_RDONLY,S_IREAD);
	if(fp >= 0){
		Fs_read (fp, testRbuff,sizeof(testRbuff));
		Fs_close(fp);

	}
#else
//	Fs_mkdir("B:\\TEST_DIR");
	Fs_mkdir("B:\\test_directory2");
	Fs_mkdir("B:\\test_directory2\\test_dir111");
#endif
}
#endif


