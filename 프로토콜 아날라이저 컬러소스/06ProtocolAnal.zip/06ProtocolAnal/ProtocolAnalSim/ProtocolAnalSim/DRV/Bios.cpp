/*********************************************************************/

#define	BIOS_PROC
#include	<stdio.h>
#include	<string.h>

#include	"define.h"
#include	"glplcd.h"

#include	"Commbuff.h"
#include	"bios.h"
#include	"disp.h"
#include	"s2440.h"
#include	"rs232c.h"
#include	"io_define.h"



#define	DEBUG_KEY





#define	LCD_DISPLAY		0x0040		//20080814




extern	int	TouchTimerCheck(void);

int mTimeStop;
/*#define	LITTLE		1*/

extern	volatile	int	time_flag[8];

void	DrawLcdBank( unsigned char *buff );

#ifdef	WIN32
extern	void	DrawLcd( char* pBitmapBits );
#else
void	DrawLcd( char* pBitmapBits )
{
	DrawLcdBank((unsigned char *)pBitmapBits);
}
#endif

/****************************************************/
/*    FUNC   : T6963C Contorol						*/
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 2003.8.10                            */
/*    Update :                                      */
/****************************************************/

int		LcdDrawMode;
int		LcdLineCnt;
int		LcdHalfFlag;
int		RefleshFlag;
int		LcdReverse;



int	eFlag;
/****************************************************/
/*	Display Apl Interface							*/
/****************************************************/
void	DrawLcdBank( unsigned char *buff )
{
	memcpy((char *)BaseLcd_Buffer,(char *)&LcdBuff[0],sizeof(LCD_BUF));
//	int	i,j;
//	int* src= (int*)&LcdBuff[0];
//	int* obj= (int*)BaseLcd_Buffer;
//	for(i= 0; i < LCD_Y_SIZE; i++){
//		for(j= 0; j < LCD_X_SIZE; j++){
//			*obj++= *src++;
//		}
//	}

}
void	DotDrawLcdBank( int sx,int sy,int ex,int ey )
{
	int	i,j;
	unsigned int* src;
	unsigned int* obj;
	LCD_BUF*	LcdFarme= (LCD_BUF*)BaseLcd_Buffer;
	for(i= sy; i <= ey; i++){
		src= (unsigned int*)&LcdBuff->lbuff[i][sx];
		obj= (unsigned int*)&LcdFarme->lbuff[i][sx];
		for(j= sx; j <= ex; j++){
			*obj++= *src++;
		}
	}
}

void	Delay200us(int cnt)
{
	volatile	int		j;
	int	i;

	for(i= 0; i < cnt; i++){
		j= 10;
		j= j*5;
	}
}
/************************************************/
/*	Hardware TEST Program						*/
/************************************************/
int	BatteryRead( void );

int	CheckSRAM(void)
{

	return(0);
}
int	ErrorCnt;
int	CheckSRAMC000000(void)
{

	return(0);
}
int	CheckFLASH(void)
{
	return(0);
}
char	KeyTochDataWork[8+2];
void	WaitTimeMs( int cnt )
{
	TimerStart( 0, cnt );		/* Wait ms */
	while(time_flag[0] == 0){
		;
	}
}
void	NormBuzzer(void)
{
#ifndef WIN32
	BuzOn();
	WaitTimeMs(100);		/* Wait 100ms */
	BuzOff();
#endif
}



void	ClearDisplay(void)
{
	ClearDispBuff();
}


int	TouchTest(void)
{

	return(0);
}


void	BackLightOnOff(int mode)
{
	#ifndef	WIN32
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;
	if(mode == OFF){
		//Tout2��??�g�ɂ���
		pIOPReg->rGPBCON= pIOPReg->rGPBCON & ~(3 << 4) | (1 << 4);
#ifdef	BACKLIGHT_OLD_CHIP
		pIOPReg->rGPBDAT &= ~IO_BACK_LIGHT;		//=0(Old Boad)
#endif
#ifdef	BACKLIGHT_NEW_CHIP
		pIOPReg->rGPBDAT |= IO_BACK_LIGHT;		//=1(New Boad)
#endif
	}else{
		//Tout2��PWM�ɂ���
		pIOPReg->rGPBCON= pIOPReg->rGPBCON & ~(3 << 4) | (2 << 4);
	}
#endif
}
void	LCDAllSet(int mode)
{

}
int	InputOkNG(int mode)
{

	return(0);
}



int	Rs232CTest(int mode)
{

	return(0);

}

/****************************************************
*   FUNC  : AD Read                                 *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
****************************************************/
int	BatteryRead( void )
{
	return(0);
}

int	IsTestMode(void)
{
	return(0);
}

int	IsTestModeValue(void)
{
	return(0);
}

void    BuzOn(void)
{
}
void    BuzOff(void)
{
}

int	RunSWRead( void )
{
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;
	return(pIOPReg->rGPEDAT & 0x0002);
}

void	RtcInitWrite(unsigned char rtc_buf[])
{
	volatile RTC_REG	*pRtcReg= (RTC_REG*)RTC_BASE;

	pRtcReg->rRTCCON |= (1<<0);

	pRtcReg->rBCDYEAR= 0x00;
	pRtcReg->rBCDMON= 0x01;
	pRtcReg->rBCDDAY= 0x01;		//Week
	pRtcReg->rBCDDATE= 0x01;
	pRtcReg->rBCDHOUR= 0x00;
	pRtcReg->rBCDMIN= 0x00;
	pRtcReg->rBCDSEC= 0x00;

	pRtcReg->rRTCCON &= ~(1<<0);
	rtc_buf[6]= 0x00;
	rtc_buf[5]= 0x01;
	rtc_buf[4]= 0x01;
	rtc_buf[3]= 0x00;
	rtc_buf[2]= 0x00;
	rtc_buf[1]= 0x00;
	rtc_buf[0]= 0x00;
}
int	CheckRtc(unsigned char *rtc_buf)
{
	int	ret= OK;
	unsigned char	work;

	work = ((rtc_buf[6] & 0xf0) >> 4) * 10 + (rtc_buf[6] & 0x0f);
	if(work > 99){
		ret= NG;
	}
	work = ((rtc_buf[5] & 0x30) >> 4) * 10 + (rtc_buf[5] & 0x0f);
	if((work < 1) || (work > 12)){
		ret= NG;
	}
	work = ((rtc_buf[4] & 0x70) >> 4) * 10 + (rtc_buf[4] & 0x0f);
	if((work < 1) || (work > 31)){
		ret= NG;
	}
	work = rtc_buf[3] & 0x7f;
	if(work > 6){
		ret= NG;
	}
	work = ((rtc_buf[2] & 0x30) >> 4) * 10 + (rtc_buf[2] & 0x0f);
	if(work > 23){
		ret= NG;
	}
	work = ((rtc_buf[1] & 0x70) >> 4) * 10 + (rtc_buf[1] & 0x0f);
	if(work > 59){
		ret= NG;
	}
	work = ((rtc_buf[0] & 0x70) >> 4) * 10 + (rtc_buf[0] & 0x0f);
	if(work > 59){
		ret= NG;
	}
	return(ret);
}
void	RtcInit(void)
{
	volatile RTC_REG	*pRtcReg= (RTC_REG*)RTC_BASE;
	volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
	pRtcReg->rTICINT=0xbf;		//�T�O�O���b?�b�N�ݒ�  

	//Intrrupt Enable
    pINTRegs->rSRCPND     = BIT_TICK;
    // S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
    if (pINTRegs->rINTPND & BIT_TICK)
        pINTRegs->rINTPND = BIT_TICK;

    pINTRegs->rINTMSK    &= ~BIT_TICK;
}
void	SetSysTime( unsigned char *rtc_buf)
{
	SystemTime.year = ((rtc_buf[6] & 0xf0) >> 4) * 10 + (rtc_buf[6] & 0x0f);
	SystemTime.mon = ((rtc_buf[5] & 0x30) >> 4) * 10 + (rtc_buf[5] & 0x0f);
	SystemTime.day = ((rtc_buf[4] & 0x70) >> 4) * 10 + (rtc_buf[4] & 0x0f);
	SystemTime.week = rtc_buf[3];
	SystemTime.hour = ((rtc_buf[2] & 0x30) >> 4) * 10 + (rtc_buf[2] & 0x0f);
	SystemTime.min = ((rtc_buf[1] & 0x70) >> 4) * 10 + (rtc_buf[1] & 0x0f);
	SystemTime.sec = ((rtc_buf[0] & 0x70) >> 4) * 10 + (rtc_buf[0] & 0x0f);

}
void	RTCWrite(unsigned char rtc_buf[],int rReset)
{
	RTC_REG	*pRtcReg= (RTC_REG*)RTC_BASE;

	pRtcReg->rRTCCON|=(1<<0);

	pRtcReg->rBCDYEAR= rtc_buf[6];
	pRtcReg->rBCDMON= rtc_buf[5];
	pRtcReg->rBCDDATE= rtc_buf[4];
	pRtcReg->rBCDDAY= rtc_buf[3]+ 1;
	pRtcReg->rBCDHOUR= rtc_buf[2];
	pRtcReg->rBCDMIN= rtc_buf[1];
	pRtcReg->rBCDSEC= rtc_buf[0];

	if(rReset == 1){		//30sReset
		pRtcReg->rRTCRST= 0x0b;		//1011
	}

	pRtcReg->rRTCCON&=~(1<<0);

} // end of Rtc_Set(...)

int	RTCRead(unsigned char *rtc_buf)
{
	RTC_REG	*pRtcReg= (RTC_REG*)RTC_BASE;

	rtc_buf[6]= pRtcReg->rBCDYEAR;
	rtc_buf[5]= pRtcReg->rBCDMON;
	rtc_buf[4]= pRtcReg->rBCDDATE;
	rtc_buf[3]= pRtcReg->rBCDDAY- 1;	//Week
	rtc_buf[2]= pRtcReg->rBCDHOUR;
	rtc_buf[1]= pRtcReg->rBCDMIN;
	rtc_buf[0]= pRtcReg->rBCDSEC;
	return(0);
}
int	_RtcInterruptProc(void)
{
	unsigned char	rtc_buf[10];
	volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

    // Clear the interrupt
    pINTRegs->rSRCPND = 1 << INTSRC_TICK;
    pINTRegs->rINTPND = 1 << INTSRC_TICK;
	RTCRead(rtc_buf);
	SetSysTime(rtc_buf);
	return(0);
}
void _RtcTikHandler(void)
{
	volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_TICK;
	_RtcInterruptProc();
	pINTRegs->rINTMSK &= ~BIT_TICK;
} // Rtc_Isr(...)
void	Rs422Enable(int mode)
{
}
void	RunLed(int mode)
{
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;

	if(mode == ON){
		pIOPReg->rGPADAT |= IO_LED_ERROR;
		pIOPReg->rGPADAT &= ~IO_LED_RUN;
	}else{
		pIOPReg->rGPADAT |= IO_LED_RUN | IO_LED_ERROR;
	}
}
void	ErrorLed(int mode)
{
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;

	if(mode == ON){
		pIOPReg->rGPADAT |= IO_LED_RUN;
		pIOPReg->rGPADAT &= ~IO_LED_ERROR;
	}else{
		pIOPReg->rGPADAT |= IO_LED_RUN | IO_LED_ERROR;
	}
}

//20080814
void	LCDDisplayEnable(int mode)
{
}


void	PaintAngle(int sx,int sy,int ex,int ey)
{
	int	i;
	for(i= sy; i <= ey; i++){
		LineOut(sx,i,ex,i,0,0);
	}
}
void	DispCheckPatarn(int mode)
{
	int i,j;
	int		Colum,Row,Width,Hight,x_width,y_width;

	ClearDisplay();
	DotTextOut(0,1," Input/Output  Test");



	Colum= 15;
	Row= 4;



	Width= LCD_X_SIZE;
	Hight= LCD_Y_SIZE;

	x_width= Width/Colum;
	y_width= Hight/Row;
	for(i= 0; i < 2; i++){
		for(j= 0; j < 8; j++){
			RectAngle(j*x_width+x_width*7,i*y_width+y_width*2,
				(j+1)*x_width+x_width*7- 1,(i+1)*y_width+y_width*2- 1);
			if(mode == 0){
				if((j % 2)==0){
					PaintAngle(j*x_width+x_width*7,i*y_width+y_width*2,
					(j+1)*x_width+x_width*7- 1,(i+1)*y_width+y_width*2- 1);
				}
			}else{
				if((j % 2)!=0){
					PaintAngle(j*x_width+x_width*7,i*y_width+y_width*2,
					(j+1)*x_width+x_width*7- 1,(i+1)*y_width+y_width*2- 1);
				}
			}
		}
	}
	DrawLcd((char *)LcdBuff);
	WaitTimeMs(1000);
}
int	IoTest(void)
{

	return(0);
}
/****************************************/ 
/* Timer Proc                     */
/****************************************/
void	Waitms(int no)
{
	TimerStart(0,no);
	while(1){
		if(time_flag[0] == 1){
			break;
		}
	}
}

/****************************************/ 
/* Timer Interruput                     */
/****************************************/
void	TimerInit( void )
{
	int		i;
	
	for(i = 0; i < 8; i++){
		time_flag[i] = 0;
		time_data[i] = 0;
	}
}   
void	TimerStart(int no,int cnt)
{
	time_flag[no] = 0;
	time_data[no] = cnt;
}
void	TimerStop(int no)
{
	time_flag[no] = 0;
	time_data[no] = 0;
}
void	TimerProc( void )
{
	int		i;
#ifndef	WIN32
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

//    pINTRegs->rSRCPND = 1 << INTSRC_TIMER4;
//    pINTRegs->rINTPND = 1 << INTSRC_TIMER4;
//	pINTRegs->rINTSUBMSK |= BIT_SUB_WDT;
	pINTRegs->rINTMSK |= (unsigned int)BIT_WDT;
    pINTRegs->rSRCPND = (unsigned int)BIT_WDT;
    pINTRegs->rINTPND = (unsigned int)BIT_WDT;
	pINTRegs->rSUBSRCPND= BIT_SUB_WDT;
#endif
	for(i = 0; i < 8; i++){
		if(time_data[i] != 0){
			time_data[i]--;
			if(time_data[i] == 0 || mTimeStop == 1){
				time_flag[i] = 1;
				mTimeStop=0;
			}
		}
	}
	//Touch Scan Check
	timLoopCnt++;
	if(timLoopCnt >= TOUCH_SCAN_TIME){		//for 200ms
		timLoopCnt= 0;
		TouchTimerCheck();
	}
#ifndef	WIN32
//	pINTRegs->rSUBSRCPND= BIT_SUB_WDT;

//	pINTRegs->rSRCPND = (unsigned int)BIT_WDT;
//	if (pINTRegs->rINTPND & (unsigned int)BIT_WDT)
//		pINTRegs->rINTPND = (unsigned int)BIT_WDT;

//	pINTRegs->rINTSUBMSK &= ~BIT_SUB_WDT;
	pINTRegs->rINTMSK &= ~(unsigned int)BIT_WDT;
#endif
}
/****************************************************
*   FUNC  : Rts ON/OFF                              *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
void	RtsOn(void)
{
	Sio2RtsOn();
}
void	RtsOff(void)
{
	Sio2RtsOff();
}
void	Rts0On(void)
{
}
void	Rts0Off(void)
{                    
}
int	Hex2nBin(char *buff,int cnt)
{
	int		i;
	int		ret;

	ret= 0;
	for(i= 0; i < cnt; i++){
		ret= ret << 4;
		if((buff[i] >= '0') && (buff[i] <= '9')){	ret += buff[i] - '0';	}
		else if((buff[i] >= 'A') && (buff[i] <= 'F')){	ret += (buff[i] - 'A') + 10;	}
		else if((buff[i] >= 'a') && (buff[i] <= 'f')){	ret += (buff[i] - 'a') + 10;	}
	}
	return(ret);
}
int	gatoi(char *buff)
{
	char	c;
	int	ret;
	int flag;

	ret= 0;
	flag= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){
			break;
		}
		if((c >= '0') && (c <= '9')){
			ret= ret*10;
			ret+= c- '0';
		}else{
			if(c == '+'){
				continue;
			}
			if(c == '-'){
				flag= 1;
				continue;
			}
			break;
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}
unsigned int IoInterruptData;
void	_IoInterruptProc(void)
{
	volatile unsigned char *PortAddr;
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rSRCPND  = BIT_EINT0;
	pINTRegs->rINTPND  = BIT_EINT0;
	//Bit Check
	PortAddr= (volatile unsigned char *)(IO_START_ADDR+ FPG_PC_REG00);
	IoInterruptData= *PortAddr++;
	IoInterruptData+= *PortAddr++ << 8;
}
void _IoInterruptHandler(void)
{
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE;

	pINTRegs->rINTMSK |= BIT_EINT0;
	_IoInterruptProc();
	pINTRegs->rINTMSK &= ~BIT_EINT0;
}