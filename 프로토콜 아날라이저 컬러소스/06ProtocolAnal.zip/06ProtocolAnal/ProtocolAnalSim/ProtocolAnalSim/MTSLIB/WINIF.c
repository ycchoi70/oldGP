// Sys.cpp : �A�v���P�[�V�����p�N���X�̒�`���s���܂��B
//
#ifdef  _WINDOWS
#include "stdafx.h"
#include	"Mts.h"
#include	"MtsCifp.h"
//#include	"MtsIf.h"
#include	"MtsInitP.h"
#include	"MtsErroP.h"
#include	"MtsTimeP.h"
//#include	"TaskHed.h"
#include	"io.h"
#include	"FCNTL.h"
#include    "MailSlot.h"

unsigned char   TestStack[4096];
extern  unsigned*   _Usp;
extern  unsigned*   _Ssp;

//PCHFrm	Pch;
int		PchCount;
int	hCommandSysToApp[2];
int	hCommandAppToSys[2];
int	hPortSysToApp[2];
int	hPortAppToSys[2];

static  CDialog*    m_pLcdDlg;
static  CBitmap*    m_pLcdBmp;
//static  char    LcdBufWin[LcdHeight][LcdWidth/8];
void	CommandToSys( char* pData )
{
	_write( hCommandAppToSys[1], pData, strlen( pData ) + 1 );
}

void	CommandToApp( char* pData )
{
	_write( hCommandSysToApp[1], pData, strlen( pData ) + 1 );
}

int		ReadInt( int Handle )
{
	int				Data;
	_read( Handle, &Data, sizeof Data );
	return Data;
}

void	WriteInt( int Handle, int Data )
{
	_write( Handle, &Data, sizeof Data );
}

void	IntToApp( int Data ) { WriteInt( hCommandSysToApp[1], Data ); }
void	IntToSys( int Data ) { WriteInt( hCommandAppToSys[1], Data ); }
int		IntFromSys( void ) { return ReadInt( hCommandSysToApp[0] ); }
int		IntFromApp( void ) { return ReadInt( hCommandAppToSys[0] ); }
void	PortToApp( int Data ) { WriteInt( hPortSysToApp[1], Data ); }
void	PortToSys( int Data ) { WriteInt( hPortAppToSys[1], Data ); }
int		PortFromSys( void ) { return ReadInt( hPortSysToApp[0] ); }
int		PortFromApp( void ) { return ReadInt( hPortAppToSys[0] ); }

void    DrawLcd( int ByteCount, char* pBitmapBits )
{
	CommandToSys( "DrawLcd" );
	IntToSys( ByteCount );
	IntToSys( (int)pBitmapBits );
}

static	char	SizeChar[]= { 'B', 'W', 'D' };
unsigned long	InputPort( int Size, long Port )
{
	CString	Command;
	Command.Format( "Inp%c", SizeChar[Size] );
	CommandToSys( Command.GetBuffer(256) );
	PortToSys( Port );
	return PortFromSys();
}

void	OutputPort( int Size, long Port, long Data )
{
	CString	Command;
	Command.Format( "Oup%c", SizeChar[Size] );
	CommandToSys( Command.GetBuffer(256) );
	PortToSys( Port );
	PortToSys( Data );
}

BYTE	WinBinp( long Port ) { return (BYTE) InputPort( 0, Port ); }
WORD	WinWinp( long Port ) { return (WORD) InputPort( 1, Port ); }
DWORD	WinDinp( long Port ) { return (DWORD)InputPort( 2, Port ); }

void	WinBout( long Port, BYTE  Data ) { OutputPort( 0, Port, Data ); }
void	WinWout( long Port, WORD  Data ) { OutputPort( 1, Port, Data ); }
void	WinDout( long Port, DWORD Data ) { OutputPort( 2, Port, Data ); }

void	ReadCommand( int Handle, char* pData )
{
	int	Inx= 0;
	char			Data;
	do {
		_read( Handle, &Data, sizeof Data );
		pData[Inx++]= Data;
	} while( Data != 0 );
}

extern  interrupt void  (*_InterruptVector[256])();


void    _Schedule( void )
{
	CommandToSys( "RunTaskNo" );
    if ( _ReadyQue == 0 ) {
        _RunTaskNo= 0xff;
		IntToSys( _RunTaskNo );
    }
    else {
        _RunTaskNo= _ReadyQue - _Tcb;
		IntToSys( _RunTaskNo );
		CommandToSys( GetpSTT( _RunTaskNo )->Name );
        _asm    {
            pushad
            push    offset _SysRet
            mov _Ssp,esp
            mov ebx,_ReadyQue
            mov esp,124[ebx]
            popad
            ret
    _SysRet:
            popad
        }
    }
}

int	RunApp;
void	ReadFromPC( char* pMail )
{
	int PchByteCount= IntFromSys();
	_read( hCommandSysToApp[0], pMail, PchByteCount );
}

UINT	ThereadApp(LPVOID lpThreadParameter)
{
	RunApp= 1;
	_pipe( hCommandSysToApp, 1024, O_BINARY );
	_pipe( hCommandAppToSys, 1024, O_BINARY );
	_pipe( hPortSysToApp, 256, O_BINARY );
	_pipe( hPortAppToSys, 256, O_BINARY );
    MtsInit();
    for(;;){
		_Schedule();
		char	Command[64];
		ReadCommand( hCommandSysToApp[0], Command );
		if ( strcmp( Command, "Exit" ) == 0 ) { break; }
		else if ( strcmp( Command, "Interrupt" ) == 0 ) {
			(*_InterruptVector[IntFromSys()])(); }
		else if ( strcmp( Command, "SysClock" ) == 0 ) {
			_SystemClockInterruptHandler(); }
		else if ( strcmp( Command, "PcCommand--" ) == 0 ) {
			IAddFlag( T_SysReceive, 1 );
		}
	}
	_close( hCommandSysToApp[0] );
	_close( hCommandSysToApp[1] );
	_close( hCommandAppToSys[0] );
	_close( hCommandAppToSys[1] );
	_close( hPortSysToApp[0] );
	_close( hPortSysToApp[1] );
	_close( hPortAppToSys[0] );
	_close( hPortAppToSys[1] );
	RunApp= 0;
	return 0;
}

int	RunSys;
UINT	ThereadSys(LPVOID lpThreadParameter)
{
	RunSys= 1;
	for(;;) {
		char	Command[64];
		ReadCommand( hCommandAppToSys[0], Command );
		if ( strcmp( Command, "Exit" ) == 0 ) { return 0; }
		else if ( strcmp( Command, "DrawLcd" ) == 0 ) {
			int		ByteCount= IntFromApp();
			char* pBitmapBits= (char*)IntFromApp();
			m_pLcdBmp->SetBitmapBits( ByteCount, pBitmapBits );
			m_pLcdDlg->Invalidate( FALSE );
		}
		else if ( strcmp( Command, "RunTaskNo" ) == 0 ) {
			int RunTaskNo= IntFromApp();
			if ( RunTaskNo == 0xff ) { RunTaskName= "�ғ��^�X�N�Ȃ�"; }
			else {
				char	Buf[32];
				ReadCommand( hCommandAppToSys[0], Buf );
				RunTaskName= Buf;
			}
		}
		else if ( strcmp( Command, "InpB" ) == 0
			   || strcmp( Command, "InpW" ) == 0
			   || strcmp( Command, "InpD" ) == 0 ) {
			int	Port= PortFromApp();
			PortToApp( 0 );
		}
		else if ( strcmp( Command, "OupB" ) == 0
			   || strcmp( Command, "OupW" ) == 0
			   || strcmp( Command, "OupD" ) == 0 ) {
			int	Port= PortFromApp();
			int	Data= PortFromApp();
		}
	}
	RunSys= 0;
	return 0;
}

int	CallBack( MshFrm* pMsh )
{
	if ( strcmp( pMsh->Address, "Exit" ) == 0 ) {
		return 1;
	}
	if ( strcmp( pMsh->Address, "End" ) == 0 ) { return 1; }
	if ( pMsh->ByteCount > 0 ) {
		struct	{
			char	Command[12];
			int		ByteCount;
			PCHFrm	Pch;
		}	Buf;
		strcpy( Buf.Command, "PcCommand--" );
		Buf.ByteCount= pMsh->ByteCount;
		pMailSlot->Read( pMsh->ByteCount, &Buf.Pch );
		_write( hCommandSysToApp[1], &Buf, 16 + pMsh->ByteCount );
	}
	return 0;
}

void    OpenMts( char* MyName, CDialog* pLcdDlg, CBitmap* pLcdBmp )
{
    m_pLcdDlg= pLcdDlg;
    m_pLcdBmp= pLcdBmp;
    CMailSlot	MailSlot= CMailSlot( MyName, &CallBack, TRUE );
	AfxBeginThread( &ThereadApp, NULL, THREAD_PRIORITY_ABOVE_NORMAL );
	AfxBeginThread( &ThereadSys, NULL, THREAD_PRIORITY_ABOVE_NORMAL );
  /* �h���C�o�[�� */
	pMailSlot->StartToApp();
}

void    CloseMts( void )
{
	CommandToSys( "Exit" );
	while( RunSys != 0 ) { Sleep(100); }
	CommandToApp( "Exit" );
	while( RunApp != 0 ) { Sleep(100); }
}

#endif
