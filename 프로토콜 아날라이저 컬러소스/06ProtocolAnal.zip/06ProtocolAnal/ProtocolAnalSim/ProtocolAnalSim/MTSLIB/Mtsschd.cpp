#include    "Mts.h"
#include    "MtsSCID.h"
#include    "MtsMailP.h"
#include    "MtsFlagP.h"
#include    "MtsSmphP.h"
#include    "MtsSgnlP.h"
#include    "MtsTimeP.h"
#include    "MtsMiscP.h"
#define	M306	1

struct  {
    int     (*SystemCall)( int* pParam );
    int     ParamCount;
}   _SystemCallTable[]  = {
/*00*/{ (int(*)(int*))_SendMail,        2 },
/*01*/{ (int(*)(int*))_ResponseMail,    1 },
/*02*/{ (int(*)(int*))_FreeMail,        1 },
/*03*/{ (int(*)(int*))_FreeMbx,         1 },
/*04*/{ (int(*)(int*))0,                0 },
/*05*/{ (int(*)(int*))0,                0 },
/*06*/{ (int(*)(int*))0,                0 },
/*07*/{ (int(*)(int*))_GetMbxStatus,    1 },
/*08*/{ (int(*)(int*))_ReceiveMail,     1 },
/*09*/{ (int(*)(int*))_WaitRequest,     0 },
/*0a*/{ (int(*)(int*))_TakeMail,        0 },
/*0b*/{ (int(*)(int*))_TakeMemory,      1 },
/*0c*/{ (int(*)(int*))_TakeMbx,         0 },
/*0d*/{ (int(*)(int*))0,                0 },
/*0e*/{ (int(*)(int*))0,                0 },
/*0f*/{ (int(*)(int*))_AcceptMail,      1 },
/*10*/{ (int(*)(int*))_AddFlag,         2 },
/*11*/{ (int(*)(int*))_WaitFlag,        1 },
/*12*/{ (int(*)(int*))_ClearFlag,       0 },
/*13*/{ (int(*)(int*))0,                0 },
/*14*/{ (int(*)(int*))_v_op,            1 },
/*15*/{ (int(*)(int*))_p_op,            1 },
/*16*/{ (int(*)(int*))_i_op,            2 },
/*17*/{ (int(*)(int*))0,                0 },
/*18*/{ (int(*)(int*))_OnSignal,        2 },
/*19*/{ (int(*)(int*))_OffSignal,       2 },
/*1a*/{ (int(*)(int*))_WaitSignal,      3 },
/*1b*/{ (int(*)(int*))_ReadSignal,      1 },
/*1c*/{ (int(*)(int*))0,                0 },
/*1d*/{ (int(*)(int*))0,                0 },
/*1e*/{ (int(*)(int*))0,                0 },
/*1f*/{ (int(*)(int*))0,                0 },
/*20*/{ (int(*)(int*))0,                0 },
/*21*/{ (int(*)(int*))0,                0 },
/*22*/{ (int(*)(int*))_ChangeMailResp,  2 },
/*23*/{ (int(*)(int*))_ChangeMailPriority,  2 },
/*24*/{ (int(*)(int*))0,                0 },
/*25*/{ (int(*)(int*))0,                0 },
/*26*/{ (int(*)(int*))0,                0 },
/*27*/{ (int(*)(int*))0,                0 },
/*28*/{ (int(*)(int*))_SetTimeOut,      1 },
/*29*/{ (int(*)(int*))_Delay,           1 },
/*2a*/{ (int(*)(int*))0,                0 },
/*2b*/{ (int(*)(int*))0,                0 },
/*2c*/{ (int(*)(int*))_ChangeTaskPriority,  2 },
/*2d*/{ (int(*)(int*))0,                0 },
/*2e*/{ (int(*)(int*))0,                0 },
/*2f*/{ (int(*)(int*))0,                0 }
};

void    (*_PendingFncTable[16])( int *pParam )= {
    (void(*)(int*))0,                   /* 0x00000000   */
    (void(*)(int*))_ISystemClockHandler,/* 0x01000000   */
    (void(*)(int*))_AddFlag,			/* 0x02000000   */
    (void(*)(int*))_v_op,				/* 0x03000000   */
    (void(*)(int*))_OnSignal,			/* 0x04000000   */
    (void(*)(int*))0,                   /* 0x05000000   */
    (void(*)(int*))0,                   /* 0x06000000   */
    (void(*)(int*))0,                   /* 0x07000000   */
    (void(*)(int*))0,                   /* 0x08000000   */
    (void(*)(int*))0,                   /* 0x0a000000   */
    (void(*)(int*))0,                   /* 0x0b000000   */
    (void(*)(int*))0,                   /* 0x0c000000   */
    (void(*)(int*))0,                   /* 0x0d000000   */
    (void(*)(int*))0,                   /* 0x0e000000   */
    (void(*)(int*))0                    /* 0x0f000000   */
};

#ifdef WIN32
extern  unsigned*   _Ssp;
extern  void        _Schedule(void );
int     _SystemLevelCall( int SystemFnc( int * ), int Param )
{
    return SystemFnc( &Param );
}

extern  unsigned    _TimeMSec;
int     _CallMts( int SystemCallID, int *pParam )
{
	int		i;

    SCBFrm* pSCB= &_SCB[_SCBInx++];
    _SCBInx %= TBQ(_SCB);
    if ( _SCBCount < TBQ(_SCB) ) { _SCBCount++; }
    pSCB->TimeMSec= _TimeMSec;
    pSCB->TaskNo= _RunTaskNo;
    pSCB->FncNo= SystemCallID;
    for( i= 0; i < _SystemCallTable[SystemCallID].ParamCount; i++ ) {
        pSCB->Param[i]= pParam[i];
    }
    _SaveReadyQue= _ReadyQue;
    _SaveReadyQue->DataReg[0]= (*_SystemCallTable[SystemCallID].SystemCall)( pParam );
    if ( _ReadyQue != _SaveReadyQue ) {
        _asm    {
            push    offset _SysRet
            pushad
            mov ebx,_SaveReadyQue
            mov 124[ebx],esp
            mov esp,_Ssp
            jmp _Schedule
        }
    }
_SysRet:
    return _ReadyQue->DataReg[0];
}

/********************************************************
*                                                       *
*       ���荞�ݏ����ɂ��y���f�B���O���̗v��������    *
*                                                       *
********************************************************/
void    _PendingPro( void )
{
    int		ParaBuf[2];
    unsigned    PendingCode;
    
	if ( _PendingOup == _PendingInp ) { return; }
    PendingCode= *_PendingOup++;
    if ( _PendingOup >= &_PendingBuf[1024] ) { _PendingOup= _PendingBuf; }
    ParaBuf[0]= PendingCode >> 16 & 0x000000ff;
	ParaBuf[1]= PendingCode & 0x0000ffff;
    (*_PendingFncTable[PendingCode>>24])( &ParaBuf[0] );
}

void    _PendingRequest( unsigned PendingCode )
{
    *_PendingInp++= PendingCode;
    if ( _PendingInp >= &_PendingBuf[1024] ) { _PendingInp= _PendingBuf; }
    while( _PendingOup != _PendingInp ) { _PendingPro(); }
    _Schedule();
}

void	INT_FLAG_INC( void )
{
}
void	INT_FLAG_DEC( void )
{
}
void	di( void )
{
}
void	ei( void )
{
}
void	RESET_SYSTEM( void )
{
}
void	RESET_INT_IRQ( void )
{
}
void	RESET_INT( void )
{
}
void	SetVBR( void )
{
}
int	_SystemState;
//void	main( void )
//{
//}
#else
#ifdef	NO_SIM
extern  unsigned*   _Ssp;
extern  void        _Schedule(void );
int     _SystemLevelCall( int SystemFnc( int * ), int Param )
{
    return SystemFnc( &Param );
}

extern  unsigned    _TimeMSec;
int     _CallMts( int SystemCallID, int *pParam )
{
	int		i;

    SCBFrm* pSCB= &_SCB[_SCBInx++];
    _SCBInx %= TBQ(_SCB);
    if ( _SCBCount < TBQ(_SCB) ) { _SCBCount++; }
    pSCB->TimeMSec= _TimeMSec;
    pSCB->TaskNo= _RunTaskNo;
    pSCB->FncNo= SystemCallID;
    for( i= 0; i < _SystemCallTable[SystemCallID].ParamCount; i++ ) {
        pSCB->Param[i]= pParam[i];
    }
    _SaveReadyQue= _ReadyQue;
    _SaveReadyQue->DataReg[0]= (*_SystemCallTable[SystemCallID].SystemCall)( pParam );
    if ( _ReadyQue != _SaveReadyQue ) {
        _asm    {
            push    offset _SysRet
            pushad
            mov ebx,_SaveReadyQue
            mov 124[ebx],esp
            mov esp,_Ssp
            jmp _Schedule
        }
    }
_SysRet:
    return _ReadyQue->DataReg[0];
}

/********************************************************
*                                                       *
*       ���荞�ݏ����ɂ��y���f�B���O���̗v��������    *
*                                                       *
********************************************************/
void    _PendingPro( void )
{
    int		ParaBuf[2];
    unsigned    PendingCode;
    
	if ( _PendingOup == _PendingInp ) { return; }
    PendingCode= *_PendingOup++;
    if ( _PendingOup >= &_PendingBuf[1024] ) { _PendingOup= _PendingBuf; }
    ParaBuf[0]= PendingCode >> 16 & 0x000000ff;
	ParaBuf[1]= PendingCode & 0x0000ffff;
    (*_PendingFncTable[PendingCode>>24])( &ParaBuf[0] );
}

void    _PendingRequest( unsigned PendingCode )
{
    *_PendingInp++= PendingCode;
    if ( _PendingInp >= &_PendingBuf[1024] ) { _PendingInp= _PendingBuf; }
    while( _PendingOup != _PendingInp ) { _PendingPro(); }
    _Schedule();
}

void	INT_FLAG_INC( void )
{
}
void	INT_FLAG_DEC( void )
{
}
void	di( void )
{
}
void	ei( void )
{
}
void	RESET_SYSTEM( void )
{
}
void	RESET_INT_IRQ( void )
{
}
void	RESET_INT( void )
{
}
void	SetVBR( void )
{
}
int	_SystemState;
//void	main( void )
//{
//}
void        _Schedule(void )
{
}
void    _SystemCallHandler( void )
{
	
}
void    _SystemLevelCallHandler( void )
{
}
#endif

#endif

