#include    <String.h>
#include    "Mts.h"
#include    "MtsCorep.h"
#include    "MtsErrop.h"
#include    "MtsMailp.h"

void    MtsInit( void );
extern  void  _UserInit( void );
extern  void  SetVBR( void );
extern	int	_SystemState;
/********************************************************
*   MTS�X�^�[�g                                         *
********************************************************/

void    _Start( void )
{
//extern	void	HardInitial( void );
	_SystemState = 0;
    MtsInit();
    SetVBR();		/* Vector Base Address Set */
//	HardInitial();
/*    ei();*/
/*    Schedule();*/
}

/********************************************************
*   ���荞�݃x�N�^�[�̏�����                            *
********************************************************/
void    _InitPending( void )
{
    _PendingOup= _PendingInp= _PendingBuf;
}

/********************************************************
*   ���荞�݃x�N�^�[�̏�����                            *
********************************************************/
extern  void    _SystemCallHandler( void );
extern  void    _SystemLevelCallHandler( void );
extern  void    (*_InterruptVector[])(void);
extern  VctFrm  _InterruptVectorTable[];
extern  void    _IntError( void );
extern  void    _IntError1( void );
void    _InitVector( void )
{
    VctFrm* pVct;
#ifndef WIN32       /* 98.11.12 */
    int     i;
    for(i = 0; i < 0x100; i++){
        _InterruptVector[i] = _IntError;
    }
#endif
    for( pVct= _InterruptVectorTable; pVct->VectorNo != 0; pVct++ ) {
        _InterruptVector[pVct->VectorNo]= pVct->pIntFnc;
    }
#ifndef WIN32
    _InterruptVector[SystemCallVector]= _SystemCallHandler;
    _InterruptVector[SystemLevelCallVector]= _SystemLevelCallHandler;
#endif
}

/********************************************************
*   �^�X�N�̏�����                                      *
********************************************************/
unsigned*   _Ssp;
unsigned*   _Usp;
void        (*Entry)( STTFrm* pSTT );
extern int Delay(int);
void    SetTcb( STTFrm* pSTT )
{
    TcbFrm* pTcb;
    pTcb= &_Tcb[pSTT->TaskNo];
    pTcb->Priority= pSTT->Priority;
    pTcb->Comment=  'I' << 24 + 'n' << 16 + 'i' << 8 + 't';
    pTcb->SPTop=    pSTT->StackArea;
    pTcb->MyTaskNo= pSTT->TaskNo;
    
    Entry=    pSTT->Entry;
    pTcb->PCInt=    Entry;
#ifdef	OLD
	pTcb->Frame=	0;
#endif
/*  memset( pTcb->SPTop, 0x55, pSTT->StackSize );*/
    memset( pTcb->SPTop, 0x00, pSTT->StackSize );
    _Usp= (unsigned*)(pSTT->StackArea + pSTT->StackSize);
#ifdef  WIN32
    _asm    {
        mov     _Ssp,esp
        mov     esp,_Usp
        push    pSTT
        push    _SysErrorReturn
        push    Entry
        pushad
        mov     _Usp,esp
        mov     esp,_Ssp
    }
#else
    *((STTFrm**)(--_Usp))= 0;
    *((void(**)(void))(--_Usp))= 0;
#endif
    pTcb->AdrsReg[7]= (unsigned char*)_Usp;
    _LinkReadyQue( pTcb );   /*  �q�c�p�Ɍq��    */
}
void    SysReceiveTask( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
void    SysSendTask( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
void    C104RecieveDrv( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
void    ElseC104SndRcv( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
#ifdef	OLD
unsigned char   SysReceiveStack [ 4096];
unsigned char   SysSendStack [ 4096];
unsigned char   C104RecieveDrvStack [ 4096];
unsigned char   ElseC104SndRcvStack [ 4096];
#endif
STTFrm  _StaticTaskTableSys[]= {
#ifdef	OLD
{ "SysReceiveTask", T_SysReceive ,   0x66, 0, 0, SysReceiveTask,  {0,0,0}, SysReceiveStack,    sizeof SysReceiveStack        },
{ "sysSend   Task", T_SysSend    ,   0x66, 0, 0, SysSendTask,     {0,0,0}, SysSendStack,       sizeof SysSendStack           },
{ "C104 Drv  Task", T_C104DRV    ,   0x66, 0, 0, C104RecieveDrv,  {0,0,0}, C104RecieveDrvStack,sizeof C104RecieveDrvStack    },
{ "Else Drv  Task", T_ElsSendRecv,   0x66, 0, 0, ElseC104SndRcv,  {0,0,0}, ElseC104SndRcvStack,sizeof ElseC104SndRcvStack    },
#endif
{ 0, }
};

void    _InitTcb( void )
{
    STTFrm* pSTT;
    
    memset( _Tcb, 0, sizeof _Tcb );
    for( pSTT= _StaticTaskTableUsr; pSTT->Entry != 0; pSTT++ ) {
        SetTcb( pSTT );
    }
    for( pSTT= _StaticTaskTableSys; pSTT->Entry != 0; pSTT++ ) {
        SetTcb( pSTT );
    }
}

/*********************************************************
*   �l�a�w�̏�����                  *
*********************************************************/
void    _InitMbx( void )
{
    int     i;
    MbxFrm* pMbx;
    
    memset( _Mbx, 0, sizeof _Mbx );
    for( i= 0; i < TBQ(_Mbx); i++ ) {
        pMbx= &_Mbx[i];
        pMbx->MyMbxNo= i;
        pMbx->OwnerTaskNo= _S_NoOwner;
        pMbx->pTail= (TcbFrm*)pMbx;
    }
    for( i= 0x80; i < 0xf0; i++ ) {
        _FreeMbx( &i );
    }
}

void    _InitMail( void )
{
    int         i;
    SMTFrm*     pSMT;
    MHedFrm*    pMHed;
    MbxFrm*     pMbx;
    char*       pMail;
    pMHed= (MHedFrm*)_MailArea;
    pMbx=  _MbxMemory;
    for( pSMT= _SMT; pSMT->Size > 0; pSMT++ ) {
        for( i= 0; i < pSMT->Count; i++ ) {
            memset( pMHed, 0, sizeof( MHedFrm ) );
            pMHed->DataType=  _S_Domestic;  /* 4:0:�W�U�n�C1:�U�W�n*/
            pMHed->RespMbx=   _S_Domestic;    /*  5:�ԐM�l�����ԍ�    */
            pMHed->Priority=  _S_Unschedule;   /*  6:���[���̗D�揇��  */
            pMHed->OwnerTask= _S_NoOwner;  /*  7:�z�[���l�����m��  */
            pMHed->HomeMbx=   pMbx->MyMbxNo;    /*  8:�z�[���l�����m��  */
            pMHed->Size=      pSMT->Size;
            pMHed->XHomeMbx = 0;	/* ����CPU�̃z�[�����[���{�b�N�X�p 98.7.23 */
            pMail= (char*)(pMHed+1);
            _MailAreaLast=  pMail + pSMT->Size;
            _FreeMail( (int*)&pMail );
            pMHed= (MHedFrm*)_MailAreaLast;
        }
        pMbx++;
    }
}

/********************************************************
*   �Z�}�t�@�[�̏�����              *
********************************************************/
void    _InitSemaphore( void )
{
    int     i;

    memset( _Smp, 0, sizeof _Smp );
    for( i= 0; i < TBQ(_Smp); i++ ) {
        _Smp[i].MySmpNo= i;
    }
}

/*********************************************************
*   initiation of signal                *
*********************************************************/
void    _InitSignal( void )
{
    int     i;

    memset( _Sig, 0, sizeof _Sig );
    for( i= 0; i < TBQ( _Sig ); i++ ) {
        _Sig[i].MySigNo= i;
    }
}

void    MtsInit( void )
{

    _RunTaskNo= _S_NoOwner;
    _ReadyQue= NULL;
    _SaveReadyQue= NULL;
    _TimerQue= NULL;
    _TimeMSec= 0;
    _InitVector();
    _InitPending();
#ifdef  WIN32
    _SCBInx= _SCBCount= 0;
#else
#endif
    _InitTcb();
    _InitMbx();
    _InitMail();         /*  ���[���̏�����      */
    _InitSemaphore();    /*  �Z�}�t�@�[�̏�����  */
    _InitSignal();       /*  �V�O�i���̏�����    */

}
