#include    "Mts.h"


#ifdef      WIN32
int             _RunTaskNo;
TcbFrm*         _ReadyQue;
TcbFrm*         _SaveReadyQue;
TmqFrm*         _TimerQue;
unsigned*       _PendingInp;
unsigned*       _PendingOup;
unsigned        _PendingBuf[1024];
SmpFrm          _Smp[16];
SigFrm          _Sig[16];
MbxFrm          _Mbx[256];
TcbFrm          _Tcb[128];
void interrupt  (*_InterruptVector[256])();
unsigned*       _SystemStackEnd;
int             _SCBInx;
int             _SCBCount;
SCBFrm          _SCB[4096];
#else

#ifdef	NO_SIM
#define interrupt
int             _RunTaskNo;
TcbFrm*         _ReadyQue;
TcbFrm*         _SaveReadyQue;
TmqFrm*         _TimerQue;
unsigned*       _PendingInp;
unsigned*       _PendingOup;
unsigned        _PendingBuf[1024];
SmpFrm          _Smp[16];
SigFrm          _Sig[16];
MbxFrm          _Mbx[256];
TcbFrm          _Tcb[128];
void interrupt  (*_InterruptVector[256])();
unsigned*       _SystemStackEnd;
int             _SCBInx;
int             _SCBCount;
SCBFrm          _SCB[4096];
#endif

#endif
