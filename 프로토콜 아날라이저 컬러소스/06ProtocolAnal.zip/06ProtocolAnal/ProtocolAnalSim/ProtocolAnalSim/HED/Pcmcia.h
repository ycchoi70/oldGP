/****************************************************
*					PCMCIA.H						*
*	TVS-A01  Memory Card Control				    *
* Memory Card: CompactFlash(CF)						*
*					1997,4,22		Ver. 1.10		*
****************************************************/

void WriteCard (int drive, long sect, BYTE *buffer, long datasize);
void ReadCard (int drive, long sect, BYTE *buffer, long datasize);
void	EraseSectors (int drive, long sect, int sectors);

int	ReadBPB (int drive, XBPB *xBPB);

int	MountFile(int drv);
int	DismountFile(int drv);
void	GetRootFile(void);


int	MakeFatFs( int hDev, unsigned int nFat, unsigned int FatType, unsigned int nRootDirEntry, unsigned int nSecotorPerCluster );
void	RamReadSector(long sect, unsigned char *buffer, long datasize);
void	RamWriteSector(long sect, unsigned char *buffer, long datasize);



