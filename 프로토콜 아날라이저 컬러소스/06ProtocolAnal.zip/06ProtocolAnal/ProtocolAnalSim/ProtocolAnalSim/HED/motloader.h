

void	FontRamDownLoad(void);
void	FontDownLoad(char *SaveAddr,int mode);
int	HexLoad(char *SaveAddr);
unsigned char LHexToBin(char as_data);
