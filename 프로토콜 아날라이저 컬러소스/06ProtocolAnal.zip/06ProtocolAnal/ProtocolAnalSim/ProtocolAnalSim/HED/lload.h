
#define	APL_PROG_START		0x30200000
//#define	APL_PROG_TYPE		0x30200020
//#define	APL_PROG_MODEL		0x30200028
#define	LCD_BUF_ADDR		0x31d00000
#define	DOWNLOAD_BUFF		0x31000000

#define	BOOT_PROG_AREA		0x00000000		//
#define	TOUCH_CALIB_AREA	0x00002000		//Hardware Setting Data : Touch Cal, Contrast, 
#define	MAC_ADDR_AREA		0x00008200		//serial No : 4byte, Mac No : 6byte, IP add : 12Byte
#define	LOARDER_PROG_AREA	0x00010000		//
#define	NAND_RESERVED_AREA	0x03F00000		//

#define	IS_CONSOL()		IsGetSio1()
#define	GET_CONSOL()	GetSio1()


#ifdef	MAIN
	int DModeFlag;
	int			setspeed;
	/********************************************************/
	/*	�A�v���P?�V�����W�����v							*/
	/********************************************************/
	void	(*func)();
#else
	extern	int DModeFlag;
	extern	int			setspeed;
#endif


int	GetMessage( char *ptr );
void DubugMain( void );
int	MakeFatFsNand( int hDev, unsigned int nFat, unsigned int FatType, unsigned int nRootDirEntry, unsigned int nSecotorPerCluster );

