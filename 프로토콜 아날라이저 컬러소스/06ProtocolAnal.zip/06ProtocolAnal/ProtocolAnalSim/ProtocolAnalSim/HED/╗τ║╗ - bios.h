
#define	TOUCH_SCAN_TIME	10		//*10ms


//CNT	FRYQUENCY	34700	120Hz, 70Hz �̻󿡼��� ȭ�� �������� ������ ����. ���� 120Hz�� ����.
//CMP	Duty		31200	10%	- 0	100%, 0 - 70% ��� ��ȭ���� 70% - 100% ��� ��ȭ���� �����.
//					�� 16�ܰ迡�� 12�ܰ�� 4�ܰ�� ���� 	

#define	BACKLIGHT_FRYQUENCY		34700	//120Hz		
#define	BACKLIGHT_DUTY_DEFAULT	0x2D50	//12Point		




#ifdef	BIOS_PROC
	volatile	int	time_flag[8];
	int	time_data[8];
	int	timLoopCnt;
	int	timBatteryCnt;		//2011.125

//int    BACKLIGHT_INTERVAL[16] ={0x79E0, 0x7ED8, 0x6BD0, 0x64C8, 0x5DC0, 0x5654, 0x4EE8, 0x477C, 
//                               0x4010, 0x38A4, 0x3138, 0x29CC, 0x1C20, 0x0E74, 0x0000};

//                              10%                                                     100%  
int    BACKLIGHT_INTERVAL[16] ={0x79E0, 0x73A0, 0x6D60, 0x6720, 0x607C, 0x59D8, 0x5334, 0x4C2C, 
                                0x4524, 0x3D54, 0x3584, 0x2D50, 0x251C, 0x1A90, 0x0E74, 0x0000};

#else
	extern	volatile	int	time_flag[8];
	extern	int	time_data[8];
	extern	int	timLoopCnt;
	extern	int	timBatteryCnt;		//2011.125


//int    BACKLIGHT_INTERVAL[16] ={0x79E0, 0x7ED8, 0x6BD0, 0x64C8, 0x5DC0, 0x5654, 0x4EE8, 0x477C, 
//                               0x4010, 0x38A4, 0x3138, 0x29CC, 0x1C20, 0x0E74, 0x0000};

//                              10%                                                     100%  
extern	int    BACKLIGHT_INTERVAL[16];


#endif



void	DrawLcd( char* pBitmapBits );
void	DotDrawLcdBank( int sx,int sy,int ex,int ey );
int	CheckSRAM(void);
int	IsTestMode(void);
int	IsTestModeValue(void);
int	CheckFLASH(void);
void	NormBuzzer(void);
void   ScanKey(int* x,int* y);
void	ClearDisplay(void);
int	InputOkNG(int mode);
int	Rs232CTest(int mode);
int	BatteryRead( void );
void    BuzOn(void);
void    BuzOff(void);
void	SetSysTime( unsigned char *rtc_buf);
void	RtcInit(void);
void	RTCWrite(unsigned char rtc_buf[],int rReset);
int	RTCRead(unsigned char *rtcbuf);
int		iNowWeek(RTC_DATA *STime);
int	CheckRtc(unsigned char *rtc_buf);
void	RtcInitWrite(unsigned char rtc_buf[]);
int		iNowWeek(RTC_DATA *STime);
int	CheckDateTime(int type,RTC_DATA *SetData);
void	Rs422Enable(int mode);
void	WaitTimeMs( int cnt );
void	SetContrast(int data);
void	ClearDispBuff_FF(void);




void	_ei(void);
void	_di(void);


void	BackLightOnOff(int mode);
void	RunLed(int mode);
void	DebugLed(int mode);
void	ErrorLed(int mode);
void	LCDDisplayEnable(int mode);
int	RunSWRead( void );
void	Buzzer(int mode);

extern	char	*TVS_VERSION_MES;


void	TimerInit( void );
void	TimerStart(int no,int cnt);
void	TimerStop(int no);
void	TimerProc( void );
void	RtsOn(void);
void	RtsOff(void);
void	Rts0On(void);
void	Rts0Off(void);
void	Waitms(int no);

