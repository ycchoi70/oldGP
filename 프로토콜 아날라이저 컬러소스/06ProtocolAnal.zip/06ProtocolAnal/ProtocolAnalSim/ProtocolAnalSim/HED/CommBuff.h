/*****************************************/
/*	Common Buffer Area                   */
/*****************************************/

typedef  struct{			/* Color Data Table */
	unsigned char	b;		//BLUE
	unsigned char	g;		//GREEN
	unsigned char	r;		//RED
	unsigned char	d;		//Dummy
}COLOR_DT;
typedef struct{
	int				year;			/* year[0]:10,year[1]:1 */
	int				mon;			/* mon[0]:10,mon[1]:1 */
	int				day;			/* day[0]:10,day[1]:1 */
	int				week;			/* week               */
	int				hour;			/* hour[0]:10,hour[1]:1 */
	int				min;			/* min[0]:10,min[1]:1 */
	int				sec;			/* sec[0]:10,sec[1]:1 */
} RTC_DATA;




	__EXT	RTC_DATA	SystemTime;	/* Now Time                     */

	__EXT	int		SioLFFlag;
	__EXT	int		SioEchoFlag;
	__EXT	int		SendRecMode;
	__EXT	int		CommMode;
	__EXT	int		CommCnt;
	__EXT	int		RecCommCnt;
	__EXT	int		CommKind;
	__EXT	int		SendCommCnt;
	__EXT	unsigned char	SendBuff[128];
	__EXT	unsigned char	CommBuff[2048];

	__EXT	int		LangageFlag;
	__EXT	int		contrast;
    __EXT	int     lcdclk;
    __EXT	int     buzhighclk;
    __EXT	int     buzlowclk;

    __EXT	int     fpga_peried_clk;
    __EXT	int     fpga_width_clk;

    __EXT	int     readCount40000;
	__EXT	char	ProglessStr[64];
    __EXT	int     readSum40000;
    __EXT	int     readSumCnt40000;


   __EXT	char	tempfileName[260];
