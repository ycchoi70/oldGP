#ifndef __UBISYS_USB_HW_H__
#define __UBISYS_USB_HW_H__


//#define	USB_COMM
#define	USB_STRAGE


//
// EndPoint configuration 
//

//
// The control FIFO is 16 bytes and Cotulla's 
// UDC is an highspeed device.
//
// ----- TEMPORARILY changed to 8 for testing.
#define EP0_PACKET_SIZE                     8
#define EP1_PACKET_SIZE                     64
#define EP2_PACKET_SIZE                     64
#define EP3_PACKET_SIZE                     64
#define EP4_PACKET_SIZE                     64


//
// The BULK IN/OUT packet size may be configured to 8, 16, 32, or 64 bytes
// Use 64 bytes, the size of Cotulla's Endpoints 1 & 2 FIFO
//

//============================================================
// Standard Chapter 9 definition
//============================================================

// Request Codes
#define GET_STATUS          0x00
#define CLEAR_FEATURE       0x01
#define SET_FEATURE         0x03
#define SET_ADDRESS         0x05
#define GET_DESCRIPTOR      0x06
#define SET_DESCRIPTOR      0x07
#define GET_CONFIG          0x08
#define SET_CONFIG          0x09
#define GET_INTERFACE       0x0a
#define SET_INTERFACE       0x0b
//
// Device specific request to handle
// modem control signals
//
#define SET_CONTROL_LINE_STATE  0x22

// Descriptor Types
#define DEVICE              0x01
#define CONFIGURATION       0x02
#define STRING              0x03
#define INTERFACE           0x04
#define ENDPOINT            0x05

// Trace buffer if tracing is enabled.
// Previous address used was at end of NK IMAGE - 0x83F16000
#define UDC_PHYSICAL_TRACE_BUFFER 	0x83E40000 

// Trace types
#define UDCT_INTR			     		1
#define UDCT_EP0			     		2
#define UDCT_SEND_DATA			 	    3
#define UDCT_GET_COMMAND		 	    4
#define UDCT_COMMAND_DONE		        5
#define UDCT_UDCCS0				        6
#define UDCT_PRE_STATUS			        7
#define UDCT_STALL			     		8
#define UDCT_SETUP		  	     		9
#define UDCT_RX_INT			    		10
#define UDCT_NO_RPC			    	    11
#define UDCT_EP1_XMIT		    		12
#define UDCT_TPC			    		13
#define UDCT_TUR			    		14
#define UDCT_FORCE_OPR		    		15
#define UDCT_UDCCS0_STATE	    		16
#define UDCT_PARSE_SETUP	    		17
#define UDCT_GET_DESC		    		18
#define UDCT_INTR_EXIT		    		19
#define UDCT_STATUS_OUT		    	    20
#define UDCT_STATUS_OUT_MISSED	        21
#define UDCT_SET_CONFIG		    	    22
#define UDCT_STATUS_IN		    		23
#define UDCT_ISR			    		24
#define UDCT_XMIT_DONE		    		25
#define UDCT_READ_COMP		    		26
#define UDCT_VENDOR_MODEM_CMD   	    27
#define UDCT_RX_DATA            		28
#define UDCT_RX_INTR_DONE       		29
#define UDCT_TX_DATA            		30
#define UDCT_UDC_ISR0           		31
#define UDCT_UDC_ISR1           		32  
#define UDCT_UDC_CSR_A          		33
#define UDCT_UDC_CSR_B          		34
#define UDCT_UDC_RX_BUF_EMPTY   	    35

#define UDC_STATE(x) x->eState

//============================================================
// EP1/EP2 packet size. For polling this can not be greater than 16
//============================================================
//static unsigned int maxOutPacketSize = EP2Len;
//static unsigned int maxInPacketSize = EP1Len;

//============================================================
// String Descriptor Indexes
//============================================================
#define languagesStringIndex        	0
#define manufactureStringIndex      	1
#define productStringIndex          	2
#define configurationStringIndex    	3
#define interfaceStringIndex        	4
#define SerialNumberStringIndex     	5
#define lastStringIndex             		SerialNumberStringIndex

#define STRING_DESCRIPTOR			    0x03

#define USBData_HighByte(x)             (((x) >> 8) & 0xff)      /* get high byte from the (usb) little endian */
#define USBData_LowByte(x)              ((x) & 0xff)                	/* get low byte from the (usb) little endian */


//============================================================
// Define the configuration descriptor length
//============================================================
//#define CFGLEN 32
#define CFGLEN 39



//============================================================
// Definition 
//============================================================
#define iCONF       18
#define TLEN        (CFGLEN + 18) 
#define PAGE_NUM    8

////============================================================
//// Local Function Prototype
////============================================================
//BOOL IsCableConnect( void );
//
//
////============================================================
//// Extern Function Prototype
////============================================================

#endif

#ifdef	USBDEVDRIVER_PROC
	int	udc_sect;
	int	udc_slen;
	int	send_len;
	int	send_idx;
//	int	write_len;
//	int	write_reclen;
	int	udc_len;
#else
#endif

unsigned int	MS_USB_GetInterruptType( void );
int	GetUsbRcvData(char* Buff);
void	SendUsbData(unsigned char* buff,int cnt);
void	InitUDC(void);
int	MS_USB_InterruptHandler( void );
void	IoWrite(unsigned char* pBuf,int nReqWrite);
void UsbDevHandlerInit(void);
void	UsbDevHandler( void );
void	UsbDevIntEnable(void);
int	CheckUsbRecData(void);
void	SetWriteBuffer(unsigned char*buff,int len);

