/*** Common flash interface interface(CFI) definitions for RVD ***
  /  
 / /
/ / /\
\\\/ /// CLABSYS
 \\ ///  Cyber Lab System
  \\//
   \/

Revision history___
2004-4-28 John
*/



#ifndef __CFI_H__
#define __CFI_H__

/* CFI Query Identification String */

#define QUERY_STRING	0x10	//
#define PRIMARY_VENDOR_COMMAND_SET	0x13
#define ADDRESS_PRIMAY_ALGORITHM_TABLE	0x15
#define ALTERNATIVE_VENDOR_COMMAND_SET	0x17
#define ADDRESS_ALTERNATIVE_ALGORITHM_TABLE	0x19


/* System Interface Information */
// ...
// ...

/* Flash Geometry Information */

#define DEVICE_SIZE	0x27
#define FLASH_DEVICE_DESCRIPTION	0x28
#define BUFFER_NUMBER_OF_BUFFER	0x2A
#define	NUMBER_IF_ERASE_BLOCK_REGION	0x2C
#define ERASE_BLOCK_REGION_INFERMATION	0x2D
#define ADDITIONAL_ERASE_REGION_INFORMATION_START	0x31

/* Vendor Command Set & Control Interface ID Code */

#define NO_COMMANDSET	0x0
#define INTELSHARP_EXT	0x1
#define AMDFUJITSU_STANDARD	0x2
#define INTEL_STANDARD	0x3
#define AMDFUJITSU_EXT	0x4
#define MITSUBISHI_STANDARD	0x100
#define MITSUBISHI_EXT	0x101

#endif	//__CFI_H__
