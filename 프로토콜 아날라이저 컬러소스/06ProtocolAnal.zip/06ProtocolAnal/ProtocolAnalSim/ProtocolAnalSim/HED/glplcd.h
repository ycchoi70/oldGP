
#define		LCD_X_SIZE			800		// x resolition
#define		LCD_Y_SIZE			480		// y resolution
#define		MESH_X				16
#define		MESH_Y				20


#define FRAMEBUFFER_BASE    (0x31D00000)			//640*480*2=614400(Byte)
#define BaseLcd_Buffer		FRAMEBUFFER_BASE

#define 	io_p2v(PhAdd)   (PhAdd)
#define 	__REG(x)	(*((volatile unsigned int *)io_p2v(x)))

	#define LCD_XRES            800		// x resolition
	#define LCD_YRES            480		// y resolution
//	#define LCD_BPP             16		// RGB 5-6-5 format
	#define LCD_BPP             24		// RGB 8-8-8 format
		                                 		

//#define LCD_BPP             16		// RGB 5-6-5 format
		                                 		
//#define LCD_HFRONTPORCH     16		// Front Porch
#define LCD_HFRONTPORCH     2		// Front Porch
//#define LCD_HBACKPORCH      16		// Back Porch(640*480)
#define LCD_HBACKPORCH      2		// Back Porch
//#define LCD_HSYNCWIDTH      24		// Hsync Width(640*480)
#define LCD_HSYNCWIDTH      13		// Hsync Width
		                                 		
//#define LCD_VFRONTPORCH     33		// Front Porch(640*480)
#define LCD_VFRONTPORCH     2		// Front Porch
//#define LCD_VBACKPORCH      10		// Back Porch(640*480)
#define LCD_VBACKPORCH      2		// Back Porch
//#define LCD_VSYNCWIDTH      2		// Vsync Width(640*480)
#define LCD_VSYNCWIDTH      4		// Vsync Width
		                                 		
#define LPCSEL_VALUE        0xF84	// LPC3600 Disable (0x06 ?)

//#define LCD_CLKVAL			0x02	// Determine the rates of VCLK(640*480)
#define LCD_CLKVAL			0x03	// Determine the rates of VCLK

// LCD Controller 1 Register
#define LCDCON1_CLKVAL(x)		((x) << 8)
#define LCDCON1_MMODE			(1<<7)
#define LCDCON1_DSCAN4			(0<<5)
#define LCDCON1_STN4			(1<<5)
#define LCDCON1_STN8			(2<<5)
#define LCDCON1_TFT				(3<<5)
#define LCDCON1_STN1BPP			(0<<1)
#define LCDCON1_STN2GREY		(1<<1)
#define LCDCON1_STN4GREY		(2<<1)
#define LCDCON1_STN8BPP			(3<<1)
#define LCDCON1_STN12BPP		(4<<1)
#define LCDCON1_TFT1BPP			(8<<1)
#define LCDCON1_TFT2BPP			(9<<1)
#define LCDCON1_TFT4BPP			(10<<1)
#define LCDCON1_TFT8BPP			(11<<1)
#define LCDCON1_TFT16BPP		(12<<1)
#define LCDCON1_TFT24BPP		(13<<1)
#define LCDCON1_ENVID			(1 <<0)

#define LCDCON1_MODEMASK		0x1E

// LCD Controller 2 Register
#define LCDCON2_VBPD(x)			( (x) << 24)
#define LCDCON2_LINEVAL(x)		( (x) << 14)
#define LCDCON2_VFPD(x)			( (x) <<  6)
#define LCDCON2_VSPW(x)			( (x) <<  0)
#define LCDCON2_GET_VBPD(x)		(((x) >> 24) & 0xFF)
#define LCDCON2_GET_VFPD(x)		(((x) >>  6) & 0xFF)
#define LCDCON2_GET_VSPW(x)		(((x) >>  0) & 0x3F)

// LCD Controller 3 Register
#define LCDCON3_HBPD(x)			( (x) << 19)
#define LCDCON3_WDLY(x)			( (x) << 19)
#define LCDCON3_HOZVAL(x)		( (x) <<  8)
#define LCDCON3_HFPD(x)			( (x) <<  0)
#define LCDCON3_LINEBLANK(x)	( (x) <<  0)
#define LCDCON3_GET_HBPD(x)		(((x) >> 19) & 0x7F)
#define LCDCON3_GET_HFPD(x)		(((x) >>  0) & 0xFF)

// LCD Controller 4 Register
#define LCDCON4_MVAL(x)			((x) << 8)
#define LCDCON4_HSPW(x)			((x) << 0)
#define LCDCON4_WLH(x)			((x) << 0)
#define LCDCON4_GET_HSPW(x)		( ((x) >>  0) & 0xFF)

// LCD Controller 5 Register
#define LCDCON5_BPP24BL			(1<<12)
#define LCDCON5_FRM565			(1<<11)
#define LCDCON5_INVVCLK			(1<<10)
#define LCDCON5_INVVLINE		(1<<9)
#define LCDCON5_INVVFRAME		(1<<8)
#define LCDCON5_INVVD			(1<<7)
#define LCDCON5_INVVDEN			(1<<6)
#define LCDCON5_INVPWREN		(1<<5)
#define LCDCON5_INVLEND			(1<<4)
#define LCDCON5_PWREN			(1<<3)
#define LCDCON5_ENLEND			(1<<2)
#define LCDCON5_BSWP			(1<<1)
#define LCDCON5_HWSWP			(1<<0)

// Framebuffer Start Addressed 

#define LCDBANK(x)				((x) << 21)
#define LCDBASEU(x)				 (x)
#define OFFSIZE(x)				((x) << 11)
#define PAGEWIDTH(x)			 (x)

#define S3C2440_REG_LCDCON1				__REG(0x4D000000)
#define S3C2440_REG_LCDCON2				__REG(0x4D000004)
#define S3C2440_REG_LCDCON3				__REG(0x4D000008)
#define S3C2440_REG_LCDCON4				__REG(0x4D00000C)
#define S3C2440_REG_LCDCON5				__REG(0x4D000010)
#define S3C2440_REG_LCDSADDR1			__REG(0x4D000014)
#define S3C2440_REG_LCDSADDR2			__REG(0x4D000018)
#define S3C2440_REG_LCDSADDR3			__REG(0x4D00001C)
#define S3C2440_REG_REDLUT				__REG(0x4D000020)
#define S3C2440_REG_GREENLUT			__REG(0x4D000024)
#define S3C2440_REG_BLUELUT				__REG(0x4D000028)
#define S3C2440_REG_DITHMODE			__REG(0x4D00004C)
#define S3C2440_REG_TPAL				__REG(0x4D000050)
#define S3C2440_REG_LCDINTPND			__REG(0x4D000054)
#define S3C2440_REG_LCDSRCPND			__REG(0x4D000058)
#define S3C2440_REG_LCDINTMSK			__REG(0x4D00005C)
#define S3C2440_REG_LPCSEL				__REG(0x4D000060)

#define	S3C2440_REG_GPACON				__REG(0x56000000)
#define	S3C2440_REG_GPADAT				__REG(0x56000004)
#define	S3C2440_REG_GPBCON				__REG(0x56000010)
#define	S3C2440_REG_GPBDAT				__REG(0x56000014)
#define	S3C2440_REG_GPBUP				__REG(0x56000018)
#define	S3C2440_REG_GPCCON				__REG(0x56000020)
#define	S3C2440_REG_GPCDAT				__REG(0x56000024)
#define	S3C2440_REG_GPCUP				__REG(0x56000028)
#define	S3C2440_REG_GPDCON				__REG(0x56000030)
#define	S3C2440_REG_GPDDAT				__REG(0x56000034)
#define	S3C2440_REG_GPDUP				__REG(0x56000038)
#define	S3C2440_REG_GPECON				__REG(0x56000040)
#define	S3C2440_REG_GPEDAT				__REG(0x56000044)
#define	S3C2440_REG_GPEUP				__REG(0x56000048)
#define	S3C2440_REG_GPFCON				__REG(0x56000050)
#define	S3C2440_REG_GPFDAT				__REG(0x56000054)
#define	S3C2440_REG_GPFUP				__REG(0x56000058)
#define	S3C2440_REG_GPGCON				__REG(0x56000060)
#define	S3C2440_REG_GPGDAT				__REG(0x56000064)
#define	S3C2440_REG_GPGUP				__REG(0x56000068)
#define	S3C2440_REG_GPHCON				__REG(0x56000070)
#define	S3C2440_REG_GPHDAT				__REG(0x56000074)
#define	S3C2440_REG_GPHUP				__REG(0x56000078)
                                		
#define S3C2440_REG_MISCCR				__REG(0x56000080)


void Lcd_Init(void);
