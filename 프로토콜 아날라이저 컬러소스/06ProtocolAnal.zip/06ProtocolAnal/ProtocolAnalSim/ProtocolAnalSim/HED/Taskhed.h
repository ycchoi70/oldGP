/********************************/
/*	����ԍ���`       			*/
/*  1999.8.10                   */
/********************************/
/*	Driver & Handler			*/

#define	T_INIT		    0x11
#define	T_TASK1	        0x12
#define T_OBSERVE		0x13