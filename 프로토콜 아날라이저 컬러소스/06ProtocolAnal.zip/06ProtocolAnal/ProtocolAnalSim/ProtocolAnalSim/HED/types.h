/*	$ JBOSN: types.h, v 0.1 2002/12/17 $	*/

/*
 * Copyright (C) 2002	Jung Byong-Oh
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are not permitted completely.
 *
 */

/*
 * Module Name: types.h
 *
 * Purpose: Type definitions.
 *
 */

/* Useful typedefs */

#ifndef __JBOSN_TYPES_H_
#define __JBOSN_TYPES_H_


/* The left side of these typedefs are machine and compiler dependent */
typedef signed   char           CHAR;
typedef signed   short          WCHAR;
typedef signed   short          SHORT;
typedef signed   int            INT;
typedef double                  DOUBLE;
typedef float                   FLOAT;
typedef unsigned char           UCHAR;
typedef unsigned short          USHORT;
typedef unsigned int            UINT;
typedef CHAR                   *PCHAR;
typedef WCHAR                  *PWCHAR;
typedef SHORT                  *PSHORT;
typedef INT                    *PINT;
typedef UCHAR                  *PUCHAR;
typedef USHORT                 *PUSHORT;
typedef UINT                   *PUINT;
typedef DOUBLE                 *PDOUBLE;
typedef FLOAT                  *PFLOAT;

typedef signed   char          INT8;
typedef signed   short         INT16;
typedef signed   int           INT32;
#ifdef	WIN32
typedef signed   __int64       INT64;
#else
typedef signed   long long     INT64;
#endif
typedef unsigned char          UINT8;
typedef unsigned short         UINT16;
typedef unsigned int           UINT32;
#ifdef	WIN32
typedef unsigned __int64       UINT64;
#else
typedef unsigned long long     UINT64;
#endif

typedef INT8                   *PINT8;
typedef INT16                  *PINT16;
typedef INT32                  *PINT32;
typedef INT64                  *PINT64;
typedef UINT8                  *PUINT8;
typedef UINT16                 *PUINT16;
typedef UINT32                 *PUINT32;
typedef UINT64                 *PUINT64;

#define VOID                    void
#define PVOID                   void *

//typedef void                    VOID;
//typedef void                   *PVOID;

typedef UINT32                  BOOL;
typedef UCHAR                   BYTE;
typedef UCHAR                  *PBYTE;
typedef USHORT                  WORD;
typedef UINT32                  DWORD;
typedef UINT64                  DDWORD;
typedef CHAR                    SBYTE;
typedef SHORT                   SWORD;
typedef INT                     SDWORD;

typedef UINT32                  JB_ERR;

typedef UINT32                  HANDLE;

#define CONST                   const
#define PUBLIC			
#define PRIVATE                 static
#define STATIC                  static
#define EXTERN                  extern
#define INLINE                  inline
#define VOLATILE                volatile
#define REGISTER                register

#ifndef	TRUE
#define TRUE                    (1)
#define FALSE                   (0)
#endif
#ifndef	NULL
#define NULL                    (0)
#endif

// windows definition
typedef long                    LONG;
typedef unsigned long           ULONG;
#define MAKEWORD(a, b)          ((WORD)(((BYTE)(a)) | ((WORD)((BYTE)(b))) << 8))
#define MAKELONG(a, b)          ((LONG)(((WORD)(a)) | ((DWORD)((WORD)(b))) << 16))
#define LOWORD(l)               ((WORD)(l))
#define HIWORD(l)               ((WORD)(((DWORD)(l) >> 16) & 0xFFFF))
#define LOBYTE(w)               ((BYTE)(w))
#define HIBYTE(w)               ((BYTE)(((WORD)(w) >> 8) & 0xFF))
 


typedef unsigned char             __u8;
typedef unsigned char               u8;
typedef unsigned short          __le16;
typedef unsigned short          __be16;
typedef unsigned short           __u16;
typedef unsigned short             u16;
typedef short                      s16;
typedef __int64					 __s64;
typedef unsigned __int64           u64;
typedef unsigned int             __u32;
typedef unsigned int               u32;
typedef __u32					__le32;
typedef __u32					__be32;


typedef char int8;                        /**< The 8-bit signed data type. */

typedef volatile char vint8;              /**< The volatile 8-bit signed data type. */
                                           
typedef unsigned char uint8;              /**< The 8-bit unsigned data type. */
                                           
typedef volatile unsigned char vuint8;    /**< The volatile 8-bit unsigned data type. */
                                           
typedef short int16;                      /**< The 16-bit signed data type. */
                                           
typedef volatile short vint16;            /**< The volatile 16-bit signed data type. */
                                           
typedef unsigned short uint16;            /**< The 16-bit unsigned data type. */
                                           
typedef volatile unsigned short vuint16;  /**< The volatile 16-bit unsigned data type. */
                                           
typedef long int32;                       /**< The 32-bit signed data type. */
                                           
typedef volatile long vint32;             /**< The volatile 32-bit signed data type. */
                                           
typedef unsigned long uint32;             /**< The 32-bit unsigned data type. */
                                           
typedef volatile unsigned long vuint32;   /**< The volatile 32-bit unsigned data type. */

/**
 * The SOCKET data type.
 */
typedef uint8 SOCKET;


typedef unsigned long	ulong;
typedef unsigned short	ushort;
typedef unsigned char	uchar;
typedef unsigned int    uint;

#ifndef __cplusplus
typedef int				bool;
#define	true			1
#define false			0
#endif

// print in hex value.
// type= 8 : print in format "ff".
// type=16 : print in format "ffff".
// type=32 : print in format "ffffffff".
typedef enum {
	VAR_LONG=32,
	VAR_SHORT=16,
	VAR_CHAR=8
} VAR_TYPE;

#ifndef NULL
#define NULL (void *)0
#endif


#endif /* __JBOSN_TYPES_H_ */


