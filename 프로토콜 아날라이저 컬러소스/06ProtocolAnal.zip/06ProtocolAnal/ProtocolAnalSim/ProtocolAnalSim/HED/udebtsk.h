////////////////////////////////////////////////////////////////////
//	V2.4	2011.01.13	Boot���R?�h�F���ύX�i�O��EB->"MSDOS"�j
//	V2.5	2011.01.17	System Faile�̃f�B���N�g��?�ύX
///////////////////////////////////////////////////////////////////

#define	END_CHAR		0x0D
#define	TYPE_BYTE		1
#define	TYPE_WORD		2
#define	TYPE_LONG		4
#define	NO_LOGIN		0x00		/* ���O�C�����Ă��Ȃ� */
#define	RR_LOGIN		0x01		/* ���O�C��?����(Ready) */
#define	OK_LOGIN		0x10		/* ���O�C������ */
#define	OK_LOGIN_AS		0x05		//20080818
/**	�������R?���h		**/
#define	UDCMD_0			0x00
#define	UDCMD_RC		0x08	/* SendCamera Command */
#define	UDCMD_IO		0x09	/* I/O Test */
#define	UDCMD_FPGA		0x0A	/* FPGA Register Write */
#define UDCMD_GO		0x0E	/* Do Program Continue */
#define UDCMD_BR		0x0F	/* Break Point Address */
/**	����n�R?���h		**/
#define UDCMD_MEM_R		0x11	/* Memory Read */
#define	UDCMD_MEM_W		0x12	/* Memory Write */
#define UDCMD_MEM_D		0x13	/* Memory Dump */
#define UDCMD_MEM_F		0x14	/* Memory Fill */
#define	UDCMD_MEM_S		0x15	/* Memory Subs */
#define UDCMD_MEM_U		0x16	/* Memory c/s Read */
#define	UDCMD_MEM_L		0x17	/* Memory c/s Write */
#define	UDCMD_MEM_T		0x18	/* RAM Check(800000->87ffff) */
#define	UDCMD_MEM_P		0x19	/* Port Out */
#define	UDCMD_MEM_FC	0x1A	/* Flash Check */
#define	UDCMD_MEM_CP	0x1B	/* Program Copy & Exe */
#define	UDCMD_MEM_FE	0x1C	/* Flash Eraze */
#define	UDCMD_MEM_FW	0x1D	/* Flash Write */
#define	UDCMD_LCD_LT	0x1E	/* LCD Check [LCD Contrast and LCD VClk] */
#define	UDCMD_PRG_CK	0x1F	/* PROGRAM Check */
#define	UDCMD_LCD_CT	0x20	/* LCD Contrast */
#define	UDCMD_EXT_CK	0x21	/* EXT Boad Check */
#define	UDCMD_LCD_CLK	0x22	/* LCD Clock Set */
#define	UDCMD_LED		0x23	/* LED Test */

#define	UDCMD_IO_TEST	0x24	/* IO Test */
#ifdef	OLD
#define	UDCMD_IO_TEST1	0x25	/* IO Test */
#endif

#define	UDCMD_RTS_TEST	0x26	/* IO Test */
#define	UDCMD_LCD_TEST	0x27	/* IO Test */
#define	UDCMD_BUZ_BZ	0x28	/* IO Test */
#define	UDCMD_FILE_TEST	0x29	/* USB Test */
#define	UDCMD_CALIB		0x2a	/* Touch Area Calibration */
#define	UDCMD_USB_SLAVE	0x2b	/* USB Slave Check */

#define	UDCMD_W5300_TEST	0x2c	/* W5300 Check */
#define	UDCMD_FPGA_WRITE	0x2d	/* Fpga Write */

#define	UDCMD_FPGA_CLK	0x2e	/* Fpga Write */
#define	UDCMD_FPGA_TDI	0x2f	/* Fpga Write */
#define	UDCMD_FPGA_TMS	0x30	/* Fpga Write */
#define	UDCMD_NAND_DMP	0x31	/* NAND DUMP */

#define	UDCMD_LD_START	0x7f	/* Loader Start Check */

/**	����R?���h		**/
#define UDCMD_PLOAD		0x80	/* Program Load */
#define	UDCMD_FLOAD		0x81	/* Font Load(0x80000) */
#define	UDCMD_PASS		0x82	/* Password Write */
#define	UDCMD_FRLD		0x83	/* Font Load(0x0c300000) */
/** �V�X�e?�n�R?���h	**/
#define UDCMD_NO_CMD	0xF0	/* NO COMMAND */
#define UDCMD_VER		0xF1	/* About */
#define UDCMD_HELP		0xF2	/* Command Help */
#define UDCMD_CHELP		0xF3	/* Camera Command Help */
#define UDCMD_ECHO		0xF4	/* ECHO On */
#define UDCMD_ECHOOF	0xF5	/* ECHO Off */
#define UDCMD_SERIAL_SET	0xF6	/* Serial Set */ /* 20090717 */
#define UDCMD_EXIT		0xFF	/* Quit */

#ifdef	UDEBTSK_PROC


//*********************************************************************************************
//		20110325	���� 
//		20110419	����ũ �߰�, ��ũ ��Ī define ó��
//		20110817	USB ������ ���� �б� ó�� �߰�
//*********************************************************************************************

	char	*TVS_VERSION = "V1.0/111027"; 
	char	*TVS_VERSION_MES1 = P_ID_NAME;
	char	*TVS_VERSION_MES2 = "FIRMWARE UPDATE (V1.0/111027)";  //USB ������ ���� �б� ó�� ���� 

//	char	*TVS_VERSION = "V1.0/110817"; 
//	char	*TVS_VERSION_MES1 = P_ID_NAME;
//	char	*TVS_VERSION_MES2 = "FIRMWARE UPDATE (V1.0/110817)";  //USB ������ ���� �б� ó�� ���� 

//	char	*TVS_VERSION = "V1.0/110810"; 
//	char	*TVS_VERSION_MES1 = P_ID_NAME;
//	char	*TVS_VERSION_MES2 = "FIRMWARE UPDATE (V1.0/110810)";  //USB ������ ���� �б� ó�� ���� 

//	char	*TVS_VERSION = "V1.0/110614"; 
//	char	*TVS_VERSION_MES1 = P_ID_NAME;
//	char	*TVS_VERSION_MES2 = "FIRMWARE UPDATE (V1.0/110614)";  //USB ������ ���� �б� ó�� ���� 

//	char	*TVS_VERSION = "V1.0/110609"; 
//	char	*TVS_VERSION_MES1 = P_ID_NAME;
//	char	*TVS_VERSION_MES2 = "FIRMWARE UPDATE (V1.0/110609)";  //USB �б� ó�� ����[���ϼ��� �߿��������Ʈ���], ����� ����

//	char	*TVS_VERSION = "V1.0/110602"; 
//	char	*TVS_VERSION_MES1 = P_ID_NAME;
//	char	*TVS_VERSION_MES2 = "FIRMWARE UPDATE (V1.0/110602)";  //�߿��� ������Ʈ ���α׷���

//	char	*TVS_VERSION = "V1.0/110524"; 
//	char	*TVS_VERSION_MES1 = P_ID_NAME;
//	char	*TVS_VERSION_MES2 = "FIRMWARE UPDATE (V1.0/110524)";

//	char	*TVS_VERSION = "V1.0/110421"; 
//	char	*TVS_VERSION_MES1 = P_ID_NAME;
//	char	*TVS_VERSION_MES2 = "FIRMWARE UPDATE (V1.0/110421)";

//	char	*TVS_VERSION = "V1.0/110325"; 
//	char	*TVS_VERSION_MES1 = P_ID_NAME;
//	char	*TVS_VERSION_MES2 = "FIRMWARE UPDATE (V1.0/110325)";
	
	
	char *HelpMsg[]= {
		" Q | QUIT : Quit this program and go to main program",
		" _ | VER  : View program version",
		" D | DUMP : View memory by byte, word, long word",
		"              D[B|W|L] [s-adr] [e-adr|\\size]",
		" E | SUBS : Edit memory by byte, word, long word",
		"              E[B|W|L] [s-adr] [data] [data] ...",
		"              E : Edit mode (^=adr-1, enter=adr+1, .=exit)",
		" F | FILL : Fill memory by word",
		"              F <s-adr> <\\size> <s-data> <inc-data>",
		" R[B|W|L] : Read memory one byte, word, long word",
		" W[B|W|L] : Write memory one byte, word, long word",
		" U[B|W|L] : Cycle R memory one byte, word, long word",
		"              UB <s-adr> <s-data>",
		" S[B|W|L] : Cycle W memory one byte, word, long word",
		"              SB <s-adr> <s-data>",
		" CM       : SRAM memory Read/Write Check",
		" FC       : Flash Check(0x50000)",
		" EX       : External Board Check",
		" PLOAD    : Download program by motorola hex format",
		" FLOAD    : Download Font hex(0x6FD00) format",
		" PRCK     : Apl Program Check",
		" PW       : Hard Test Password Set('9999')",
		" LT       : LCD Contrast Test and LCD VClk Test",
		"            Contrast Up = 1, Contrast Down = 2, Vclk Up = 3, Vclk Down = 4",
		" CT       : LCD Contrast Test",
		"            CT Num(1-255)",
		" SC       : LCD Vclk Test",
		"            SC Num(1-255)",
		" RT       : Run LED and Error LED Test",
		"            Run LED ON = 1, Run LED OFF = 2, Error LED ON = 3, Error LED OFF = 4",
        "            Run SW Status = 5, Run SW AD Value = 6, Bat AD Value = 7",
		"            Debug SW AD Value=8, Buzzer ON = B, Buzzer OFF = C",
		" IO       : Input/Output Test",
		"            R = Input Port Read, W HXXXX = Output Write",
		" BUZ      : Buzzer Test",
		" CALB     : Touch Calibration",
		" FILE     : File Control",
		" ? | HELP : View this help message",
	};

	unsigned int SubsModeFlag;		/* �r�t�a�r��?�h�t���O */
	unsigned int PloadFlag;			/* �v���O��?��?�h�t���O */
	unsigned long DefaultAdress;			/* �A�h���X�����͎��̃f�t�H���g�l */
	TCAL_DATA	CalibData[2];

	unsigned char	*DownloadBuff;		//2MB
#else
	extern	unsigned int SubsModeFlag;		/* �r�t�a�r��?�h�t���O */
	extern	unsigned int PloadFlag;			/* �v���O��?��?�h�t���O */
	extern	unsigned long DefaultAdress;			/* �A�h���X�����͎��̃f�t�H���g�l */
	extern	unsigned char	*DownloadBuff;		//2MB
#endif

void DModeSendMsg( char *ptr );
void	SendString( char* ptr);
void DModeSendPronpt( void );
void	UsbCheck(void);
void	FileProc(void);
void	SetTouchCalibration(void);
void LoaderStartMsg( void );
int DebugTask( int cmd, char *msg );
void	LoaderStart(void);
void	UsbSlaveCheck(void);
void	BootFileCopy(void);
void	TouchCalCheck(void);
void	NandFlashDataCopy(void);
void	FpgaSignalTest(int type);
unsigned int DModeNandDump( unsigned char *pCmd );
