int	W5100Open(void);
int	TcpOpen(void);
int	UdpOpen(void);
void TcpServerTest(void);
