

#define DISPLAY_WIDTH       800
#define DISPLAY_HEIGHT      480
#define DISPLAY_STRIDE      800

#define TOUCH_IRQ       9       //EINT9
#define USB_IRQ_PORT    3       //GPG3
#define USB_nRST        10      //GPG10




#define VALIDSAMPLE_SHIFT               (4)
#define MAX_VALIDSAMPLE                 (1<<VALIDSAMPLE_SHIFT)




//Backlight chip change
//*****************************************
//#define	BACKLIGHT_OLD_CHIP	
#define	BACKLIGHT_NEW_CHIP



#ifdef	BACKLIGHT_OLD_CHIP
#define	BACKLIGHT_CNT	34700
#define	BACKLIGHT_CMP	0x2D50
#endif

#ifdef	BACKLIGHT_NEW_CHIP
#define	BACKLIGHT_CNT	833
#define	BACKLIGHT_CMP	278
#endif


//===========================================================================


//===========================================================================



#define TOUCH_SAMPLE_PREVIOUSDOWN       (1<<8)
#define TOUCH_SAMPLE_CALIBRATED         (1<<9)

#define TOUCH_SAMPLE_IGNORE             (1<<0)
#define TOUCH_SAMPLE_VALID              (1<<1)
#define TOUCH_SAMPLE_DOWN               (1<<2)

// for calibaration
#define     MAX_NCALIBRATION        (5)

// Scale factor to support sub-pixel resolutions
#define X_SCALE_FACTOR      4
#define Y_SCALE_FACTOR      4


#ifdef	TOUCH_PROC
	int       cXscr = -1;
	int       cYscr = -1;

	int       Xscr_prev = -1;
	int       Yscr_prev = -1;
	int       mXscr;
	int       mYscr;
	unsigned int      nValidSample;


	unsigned int   Xmouse;
	unsigned int   Ymouse;
	unsigned int   Smouse;
	unsigned int   UpDown;

	int	NonCalbX,NonCalbY;
	int	DigCalbX,DigCalbY;


	int	TouchRepeatFlag;

	//=====================================================================
	#define MAX_NCALIBRATION        (5)
	#define X_CAL_OFFSET            (DISPLAY_WIDTH/5)
	#define Y_CAL_OFFSET            (DISPLAY_HEIGHT/5)

	 int    Xscr[MAX_NCALIBRATION] ={DISPLAY_WIDTH/2,  X_CAL_OFFSET, X_CAL_OFFSET, DISPLAY_WIDTH-X_CAL_OFFSET, DISPLAY_WIDTH-X_CAL_OFFSET};
	 int    Yscr[MAX_NCALIBRATION] ={DISPLAY_HEIGHT/2, Y_CAL_OFFSET, DISPLAY_HEIGHT-Y_CAL_OFFSET, DISPLAY_HEIGHT-Y_CAL_OFFSET, Y_CAL_OFFSET};

	 int    Xtch[MAX_NCALIBRATION] ={0x1dd, 0x2fa, 0x2f7, 0x0f7, 0x0ed};
	 int    Ytch[MAX_NCALIBRATION] ={0x217, 0x11a, 0x2e0, 0x2ee, 0x11f};

//	 TCAL_DATA	CalibPos[2];
	GLP_CAL_DATA	Cal_Data;

	float	fDx1;
	float	fDy1;
	int	iDx1_b;
	int	iDy1_b;

	int  KeyDataIn;
	int  KeyDataOut;
	int  KeyData[4];

	int  KeyDataX[4];
	int  KeyDataY[4];

	int	ScanStartX;
	int	ScanStartY;
	int	ScanBefX;
	int	ScanBefY;
	int	ScanCnt;
	int	KeyDat2PosFlag;
	int	KeyDat1stX;
	int	KeyDat1stY;
	int	KeyDat2ndX;
	int	KeyDat2ndY;

#else
	extern	GLP_CAL_DATA	Cal_Data;
	extern int    Xscr[MAX_NCALIBRATION];
	extern int    Yscr[MAX_NCALIBRATION];

	extern int    Xtch[MAX_NCALIBRATION];
	extern int    Ytch[MAX_NCALIBRATION];

	extern	int	NonCalbX,NonCalbY;
	extern	int	DigCalbX,DigCalbY;
	extern	int	TouchRepeatFlag;
#endif


void	TouchInit( void );
//void	Timer3Init(void);
void	Touch_SampleStart(void);
void	Touch_SampleStop(void);
