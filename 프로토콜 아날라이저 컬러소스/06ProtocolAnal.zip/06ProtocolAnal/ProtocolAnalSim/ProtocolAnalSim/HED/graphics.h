//--------------------------------------------------------------
//			Graphics Library
//
//	1. Supported Device : Nanya 161
//
//
//--------------------------------------------------------------
#define	ON			1
#define OFF			0

#define BLACK			0x00
#define RED			0xe0
#define GREEN			0x1c
#define BLUE			0x07
#define WHITE			0xff


//#define FRAMEBUFFER_BASE    (0x30800000)			//640*480*2=614400(Byte)
//#define FRAMEBUFFER_BASE_T  (0x30900000)
//#define BaseLcd_Buffer		FRAMEBUFFER_BASE

//#define Frame_Buffer_Size	LCD_X_SIZE*LCD_Y_SIZE/2
//#define Frame_Buffer1		BaseLcd_Buffer+Frame_Buffer_Size*1

//void Lcd_Init(void);

