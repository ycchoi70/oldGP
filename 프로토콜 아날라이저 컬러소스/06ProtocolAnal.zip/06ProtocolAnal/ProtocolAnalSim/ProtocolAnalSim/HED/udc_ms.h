#ifndef _UDC_MS_H_   
#define _UDC_MS_H_

//#include <types.h>
#include "udc_types.h"
#include "udc_ms_protocol.h"

#define ERROR_SUCCESS   0

typedef struct _USB_PIPE_STATE
{   
    BOOL    fSendingLess;
} USB_PIPE_STATE, * PUSB_PIPE_STATE;


// Direction flags
#define DATA_OUT            0x00000000
#define DATA_IN             0x00000001

// Command block
typedef struct _TRANSPORT_COMMAND 
{
    UINT32 Flags;            // [in]  - DATA_IN or DATA_OUT
    UINT32 Timeout;          // [in]  - timeout for this command block; not used
    UINT32 Length;           // [in]  - length of the command block buffer
    PVOID  CommandBlock;     // [in]  - address of the command block buffer
} TRANSPORT_COMMAND, *PTRANSPORT_COMMAND;

// Data block
typedef struct _TRANSPORT_DATA_BUFFER 
{
    UINT32 RequestLength;    // [in]  - requested length
    UINT32 TransferLength;   // [out] - number of bytes actually transferred 
    PVOID  DataBlock;        // [in]  - address of the data buffer
} TRANSPORT_DATA, *PTRANSPORT_DATA;


// Mass storage class states
typedef enum _MSC_STATE {
    MSC_STATE_UNKNOWN = 0,
    MSC_STATE_IDLE,
    MSC_STATE_COMMAND_TRANSPORT,
    MSC_STATE_DATA_IN_TRANSPORT,
    MSC_STATE_DATA_OUT_TRANSPORT,
    MSC_STATE_STATUS_TRANSPORT,
    MSC_STATE_WAIT_FOR_RESET,
} MSC_STATE, *PMSC_STATE;


//============================================================
// Definitions of EP0 state machine.
//============================================================
#define WAIT_FOR_SETUP			1
#define DATA_STATE_XMIT		    2
#define DATA_STATE_RCVR		    3
#define WAIT_FOR_OUT_STATUS	    4
#define WAIT_FOR_IN_STATUS	    5


/*
 @doc
 @struct RX_BUFFER_INFO | Driver Receive Buffer Information.
 */
typedef struct __RX_BUFFER_INFO 
{
    volatile	UINT32              Read;
    volatile	UINT32              Write;              /* @field Current Write index. */
    UINT32              Length[32];             /* @field Length of buffer */
    UCHAR               RxCharBuffer[32][64];       /* @field Start of buffer */
    //CRITICAL_SECTION    CS;		/* @field Critical section */
} RX_BUFFER_INFO, *PRX_BUFFER_INFO;

//#define RxResetFifo(pSH)   pSH->RxBufferInfo.Write = pSH->RxBufferInfo.Read = 0
//#define RxEnterCS(pSH)	   EnterCriticalSection (&(pSH->RxBufferInfo.CS))
//#define RxLeaveCS(pSH)	   LeaveCriticalSection (&(pSH->RxBufferInfo.CS))
#define RxWrite(pSH)	   (pSH->RxBufferInfo.Write)
#define RxRead(pSH)	   (pSH->RxBufferInfo.Read)
#define RxLength(pSH)	   (pSH->RxBufferInfo.Length[pSH->RxBufferInfo.Read])

#define RxBuffWrite(pSH)   (pSH->RxBufferInfo.RxCharBuffer[pSH->RxBufferInfo.Write])
#define RxBuffRead(pSH)   (pSH->RxBufferInfo.RxCharBuffer[pSH->RxBufferInfo.Read])

typedef struct __TX_BUFFER_INFO 
{
    UINT32               Permissions;        /* @field Current permissions */
    UINT32               Read;               /* @field Current Read index. */
    UINT32               Length;             /* @field Length of buffer */
    PUCHAR              TxCharBuffer;       /* @field Start of buffer */
    //CRITICAL_SECTION    CS;                 /* @field Critical section */
} TX_BUFFER_INFO, *PTX_BUFFER_INFO;

//#define TxEnterCS(pSH)	   EnterCriticalSection (&(pSH->TxBufferInfo.CS))
//#define TxLeaveCS(pSH)	   LeaveCriticalSection (&(pSH->TxBufferInfo.CS))
#define TxRead(pSH)		   (pSH->TxBufferInfo.Read)
#define TxLength(pSH)	   (pSH->TxBufferInfo.Length)
#define TxBytesAvail(pSH)  (TxLength(pSH)-TxRead(pSH))
#define TxBuffRead(pSH)	   (pSH->TxBufferInfo.TxCharBuffer+pSH->TxBufferInfo.Read)
#define TxBuffer(pSS)	   (pSS->TxBufferInfo.TxCharBuffer)


/*
 * @doc HWINTERNAL
 * @struct SER_INFO | Private structure.
 */
typedef struct __MS_INFO 
{
	//CRITICAL_SECTION	    TransmitCritSec1;		// @field Protects tx action
	//CRITICAL_SECTION	    ReceiveCritSec1;		// @field Protects rx action
	UINT32                   fAbortRead:1;   // @field Used for PURGE
    UINT32                   fAbortTransmit:1;// @field Used for PURGE

    RX_BUFFER_INFO          RxBufferInfo;	// @field rx buffer info.
    TX_BUFFER_INFO          TxBufferInfo;	// @field tx buffer info.

	HANDLE			        hReadEvent;		// @field Serial event, both rx and tx
	HANDLE			        hTransmitEvent;	// @field transmit event, both rx and tx

	UINT32			        RxBytes;	    // @field Record of total bytes received.
	UINT32			        TxBytes;	    // @field Record of total bytes transmitted.
	UINT32			        TxBytesPending;	// @field Record of total bytes awaiting transmit.
	UINT32			        TxBytesSent;	// @field Record of bytes sent in one transmission
	HANDLE			        hKillDispatchThread;	// @field Synchonize thread end

	UINT32			        DroppedBytesMDD;// @field Record of bytes dropped by MDD.
	UINT32			        DroppedBytesPDD;// @field Record of bytes dropped by PDD.


  	//CRITICAL_SECTION        HwRegCritSec;               // @field Protects SA_USB registers from non-atomic

    /* access (addr/data pairs) */
    //CRITICAL_SECTION        TransmitCritSec;            // @field Protects UART TX FIFO from simultaneous access
    UINT32		            DroppedBytes;               // @field Number of dropped bytes 
    //COMSTAT                 Status;                     // @field Bitfield representing Win32 comm status. 
    HANDLE		            FlushDone;                  // @field Handle to flush done event.
    
    HANDLE                  pNoSuspendThread;           // @field 
    /* We have our own dispatch thread. */
    HANDLE                  pDispatchThread;            // @field ReceiveThread 
    UINT32                   KillRxThread:1;             // @field Flag to terminate SA_USB_DispatchThread.
    
    /* USB Path change thread. */
    HANDLE                  USBPathChangedThread;
    UINT32                   dwNumberOfEventsUsed;       // Number of events used by USB client driver
    HANDLE                  hInterruptEvent;            // @field Interrupt event
    HANDLE                  hShutdownEvent;             // @field shutdown ext USB tranceiver event
    HANDLE                  hShutdownFinishedEvent;     // @field ext USB tranceiver shutdown finished event


    /* now hardware specific goodies */
    UINT32                   dwIntID;

    UINT32                   dwIOLen;                    // @field IO Length
    UINT32                   dwIRQ;                      // @field Interrupt number for this peripheral
    UINT32                   dwDevIndex;                 // @field Index of device
    WORD                     wSOFStableCnt;              // @field How many iterations without SOF
    //volatile XLLP_INTC_T    *pINTCRegs;                 // Interrupt Controller registers base address
    //volatile UDC_REGS       *pUDCRegs;                  // UDC registers base address
    //volatile XLLP_CLKMGR_T  *pCLKRegs;                  //CLK Base Address
    //volatile XLLP_GPIO_T    *pGPIORegs;    	            // GPIO registers base address
    //volatile DRIVER_GLOBALS *pDrvGlobals;               // Driver globals base address
    //volatile XLLP_BCR_T     *pBCRReg;                   // @field for board specific stuff
    //volatile XLLP_PWRMGR_T  *pPwrReg;                   // Power Manager base address
    int                     eState;                     // @field Current EP0 state machine
    
    /* EP0 Data Xfer info */
    int                     nXmitLength;                // @field Current EP0 xfer length
    PBYTE                   pXmitData;                  // @field Pointer to xmit data for EP0
    int                     nXmitIndex;                 // @field Index into the current EP0 xmit buffer
    int                     nXmitReq;                   // @field Requested amount of data on EP0
    
    //SetupPKG                dReq;                       // @field USB endpoint 0 command
    USB_DEVICE_REQUEST      dReq;
    BYTE                    cIntStat;                   // @field Last known interrupt status
    BYTE                    dConfIdx;                   // @field USB Configuration Index
    BYTE                    dInterface;                 // @field USB Interface Index
    BYTE                    dSetting;                   // @field USB Setting Index
    BYTE                    dAddress;                   // @field USB device Address

    UINT32                   UDC_Reset;          
    UINT32                   UDC_ResetTimeOut;
    
} MS_INFO, *PMS_INFO;


//__inline  UINT32 RxBytesAvail(PMS_INFO pMsInfo) 
//{
//    // Note: We have to copy RxRead and RxWrite index to local in order to make it atomic.
//    register UINT32 RxWIndex=RxWrite(pMsInfo), RxRIndex=RxRead(pMsInfo);
//    return (RxWIndex>=RxRIndex?RxWIndex- RxRIndex : RxLength(pMsInfo) - RxRIndex + RxWIndex );
//}
#define RxLengthW(pSH)	   (pSH->RxBufferInfo.Length[pSH->RxBufferInfo.Write])


typedef enum 
{
    UDC_INTR_NONE	=   0,
    UDC_INTR_SETUP	=   (1<<0),
    UDC_INTR_RX	    =   (1<<1),
    UDC_INTR_TX	    =   (1<<2),
    UDC_INTR_CABLE	= 	(1<<20),
    UDC_INTR_RESET	=   (1<<21),
    UDC_INTR_SUSPEND=   (1<<22),
    UDC_INTR_RESUME =   (1<<23),
} UDC_INTERRUPT_TYPE;


#define CONTROL_TRANSFER    0
#define IN_TRANSFER         1
#define OUT_TRANSFER        2
#define MAX_TRANSFER        3

#define	SUSPEND_INT

#define MASS_STORAGE_INTERFACE_CLASS            0x08
#define SCSI_TRANSPARENT_INTERFACE_SUBCLASS     0x06
#define CBIT_INTERFACE_PROTOCOL                 0x00
#define BOT_INTERFACE_PROTOCOL                  0x50


//============================================================
// Extern Functino Prototype 
//============================================================

#endif //_UDC_MS_H_ 
