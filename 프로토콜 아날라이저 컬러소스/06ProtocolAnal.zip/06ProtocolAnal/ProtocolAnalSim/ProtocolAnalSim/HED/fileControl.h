
typedef struct{
	int		serchFileCnt;
	int		attribute[20];
	int		Select[20];
	char	serchFileName[20][260];
}FILE_INF;

int	setDriveName(int drive,char* fileName);
void	serchFileNameProc(int drive,FILE_INF *DevName,char *name);
void	DispFileName(void);
void	FileCopyUSB2Sys(void);
void	UsbChangeDir(int drive,FILE_INF * DevName);
void	UsbDeleteFile(int drive,FILE_INF * DevName);
void	vFileControl(void);
int	LoadProgFile(int idx);
int	ProgFileCheck(void);
void	DispLoadFileName(void);
int	vFileLoadControl(void);
