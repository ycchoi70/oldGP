
#ifndef __MACROS_H__
#define __MACROS_H__

#define READ_REGISTER_ULONG(reg)    (*(volatile unsigned long *)(reg))
#define READ_REGISTER_USHORT(reg)   ((volatile unsigned short)*(volatile unsigned short *)(reg))
#define READ_REGISTER_UCHAR(reg)    (*(volatile unsigned char *)(reg))
#define WRITE_REGISTER_ULONG(reg, val)  (*(volatile unsigned long *)(reg)) = (val)
#define WRITE_REGISTER_USHORT(reg, val) (*(volatile unsigned short *)(reg)) = (val)
#define WRITE_REGISTER_UCHAR(reg, val)  (*(volatile unsigned char *)(reg)) = (val)

#define WRITEAND_REGISTER_ULONG(reg, val)  (*(volatile unsigned long *)(reg)) &= (val)
#define WRITEAND_REGISTER_USHORT(reg, val) (*(volatile unsigned short *)(reg)) &= (val)
#define WRITEAND_REGISTER_UCHAR(reg, val)  (*(volatile unsigned char *)(reg)) &= (val)

#define WRITEOR_REGISTER_ULONG(reg, val)  (*(volatile unsigned long *)(reg)) |= (val)
#define WRITEOR_REGISTER_USHORT(reg, val) (*(volatile unsigned short *)(reg)) |= (val)
#define WRITEOR_REGISTER_UCHAR(reg, val)  (*(volatile unsigned char *)(reg)) |= (val)

#endif //__MACROS_H__

