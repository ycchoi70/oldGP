/****************************************************/
/*    FUNC   : TVS-700 BIOS Program                */
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 2001.8.10                            */
/*    Update :                                      */
/****************************************************/
#include "stdafx.h"
#include "stdio.h"
#define	APL_START	0x0000000
#define	APL_END		0x0010000
//:XX
unsigned char	dataBuff[0x40000];		// 256KB	
/***********************************************/
/*  16�i�E2�i�ϊ�����   		                  */
/*       1995.11.8                             */
/***********************************************/
unsigned char LHexToBin(char as_data)
{
	unsigned char ret;

	ret = 0;
	if((as_data >= '0') && (as_data <= '9')){
		ret = (unsigned char)(as_data - '0');
	}
	else if((as_data >= 'A') && (as_data <= 'F')){
		ret = (unsigned char)(as_data - 'A' + 10);
	}
	return(ret);
}
/***********************************************/
/*  16�i�E2�i�ϊ�����   		                  */
/*       1995.11.8                             */
/***********************************************/
unsigned int LHexAsToBin(char *buff, int cnt)
{
	int		i;
	unsigned int hex_data;

	hex_data = 0;
	for(i = 0; i < cnt; i++){
		hex_data = hex_data << 4;
		hex_data += LHexToBin(buff[i]);
	}
	return(hex_data);
}
/***********************************************/
/*  �ް�ں��ގ�荞�ݏ���                      */
/*       1995.11.8                             */
/***********************************************/
int	DataSet(char *buff, unsigned char *data_adr, int cnt)
{
	int		i;
	
	for(i = 0; i < cnt; i++){
						/* ���ސ� */
		data_adr[i] = (unsigned char)LHexAsToBin(&buff[i*2],2);
	}
	return(0);
}
int	FPGAdAtaRecieve(char *FileName)
{
	FILE	*fp;
	char rBuff[128];
	unsigned char *location= 0;
	int		DataLeng;

	memset(dataBuff, 0xff, sizeof(dataBuff));
	fp=fopen(FileName, "rt");
	if(fp == NULL){
		return(-1);
	}
	int	LoadTotal= 0;
	int end_flag= 0;
	int ret= 0;

	//Data Read
	while(end_flag == 0){
		if(fgets(rBuff,sizeof(rBuff),fp) == NULL){
			break;
		}
		if(rBuff[0] != 'S'){
			continue;
		}
		int len = strlen(rBuff) - 1;
		int chksum = 0;
		for(int i = 0; i < (len - 1)/2; i++){
			chksum += LHexAsToBin(&rBuff[i*2+2],2);
		}
		if((chksum & 0xff) != 0xff){
			continue;			/*�����Ѵװ */
		}
		len = LHexAsToBin(&rBuff[2],2);		/* ���ސ� */
		char type= rBuff[1];		/* Data Type */
		switch(type){
			case '1':			/* 2�o�C�g���ڽ */
                location = (unsigned char *)LHexAsToBin(&rBuff[4],4);
				if((unsigned int)location >= 0xffff0000){
					location = (unsigned char *)((unsigned int)location & 0x0000ffff);
				}
				if(((int)location < APL_START) || ((int)location >= APL_END)){	/* 0x10000< || 0x80000>= */
					break;
				}
				location= (unsigned char *)((int)location+ (int)dataBuff);
				DataSet(&rBuff[8],location,len - 3);
				break;
			case '2':			/* 3�o�C�g���ڽ */
                location = (unsigned char *)LHexAsToBin(&rBuff[4],6);
				if((unsigned int)location >= 0xffff0000){
					location = (unsigned char *)((unsigned int)location & 0x0000ffff);
				}
				if(((int)location < APL_START) || ((int)location >= APL_END)){	/* 0x10000< || 0x80000>= */
					break;
				}
				location= (unsigned char *)((int)location+ (int)dataBuff);
				DataSet(&rBuff[10],location,len - 4);
				break;
			case '3':			/* 4�o�C�g���ڽ */
                location = (unsigned char *)LHexAsToBin(&rBuff[4],8);
				if((unsigned int)location >= 0xffff0000){
					location = (unsigned char *)((unsigned int)location & 0x0000ffff);
				}
				if(((int)location < APL_START) || ((int)location >= APL_END)){	/* 0x10000< || 0x80000>= */
					break;
				}
				location= (unsigned char *)((int)location+ (int)dataBuff);
				DataSet(&rBuff[12],location,len - 5);
				break;
			case '7':	  		/* �I��ں��� */
			case '8':	  		/* �I��ں��� */
			case '9':	  		/* �I��ں��� */
				end_flag = 1;
				break;
		}
	}
	fclose(fp);
	DataLeng= 0x10000;

	char wFileName[128];
	for(int i= 0;;i++){
		if(FileName[i] == '.'){
			break;
		}
		wFileName[i]= FileName[i];
	}
	wFileName[i]= 0;
	strcat(wFileName, "new.mot");
	fp= fopen(wFileName,"wt");
	if(fp == NULL){
		return(-1);
	}
	for(int idx= 0; idx < DataLeng;){
		int	sum;
		int	lIdx;
		if((idx % 0x10000) == 0){
#ifdef	OLD
			sprintf(rBuff, ":02000002");
			sprintf(&rBuff[9],"%04X",idx / 0x10000 * 0x1000);
			lIdx= strlen(rBuff);
			sum= 0;
			for(int j= 0; j < (lIdx- 1) / 2; j++){
				sum += LHexAsToBin(&rBuff[j*2+1],2);
			}
			sum= 0x100- sum;
			sprintf(&rBuff[lIdx],"%02X\n", sum & 0xff);
			fputs(rBuff,fp);
#endif
		}
		if((idx+ 16) < (DataLeng)){
			sprintf(rBuff, "S113");
			sprintf(&rBuff[4],"%04X",idx % 0x10000);
			for(int j= 0; j < 16; j++){
				sprintf(&rBuff[8+j*2],"%02X",dataBuff[idx++]);
			}
		}else{
			sprintf(rBuff, "S1");
			int Cnt= (DataLeng)- idx;
			sprintf(&rBuff[2],"%02X",Cnt+3);
			sprintf(&rBuff[4],"%04X",idx % 0x10000);
			for(int j= 0; j < Cnt; j++){
				sprintf(&rBuff[8+j*2],"%02X",dataBuff[idx++]);
			}
		}
		sum= 0;
		lIdx= strlen(rBuff);
		for(int j= 0; j < (lIdx- 1) / 2; j++){
			sum += LHexAsToBin(&rBuff[j*2+2],2);
		}
		sum= 0xff- sum;
		sprintf(&rBuff[lIdx],"%02X\n", sum & 0xff);
		fputs(rBuff,fp);
	}
	fclose(fp);
	return(0);
}
/////////////////////////////////////////////////////
// Motroler File Out
/////////////////////////////////////////////////////
int	MakeMotFile(char *FileName,int OffSet,unsigned char *StartAddr,int leng)
{
	FILE	*fp;
	char rBuff[128];

	fp= fopen(FileName,"wt");
	if(fp == NULL){
		return(-1);
	}
	for(int idx= 0; idx < leng;){
		int	sum;
		int	lIdx;

		if((idx+ 16) < leng){
			sprintf(rBuff, "S213");
			sprintf(&rBuff[4],"%06X",(idx+ OffSet) % 0x1000000);
			for(int j= 0; j < 16; j++){
				sprintf(&rBuff[10+j*2],"%02X",StartAddr[idx++]);
			}
		}else{
			sprintf(rBuff, "S1");
			int Cnt= (leng)- idx;
			sprintf(&rBuff[2],"%02X",Cnt+3);
			sprintf(&rBuff[4],"%06X",(idx+ OffSet) % 0x1000000);
			for(int j= 0; j < Cnt; j++){
				sprintf(&rBuff[10+j*2],"%02X",StartAddr[idx++]);
			}
		}
		sum= 0;
		lIdx= strlen(rBuff);
		for(int j= 0; j < (lIdx- 1) / 2; j++){
			sum += LHexAsToBin(&rBuff[j*2+2],2);
		}
		sum= 0xff- sum;
		sprintf(&rBuff[lIdx],"%02X\n", sum & 0xff);
		fputs(rBuff,fp);
	}
	fclose(fp);
	return(0);
}
