//----------------------------------------------
// Make Font
//----------------------------------------------
#include "stdafx.h"
#include "stdio.h"
#ifdef	OLD
#define	ASC68		0x6fd00
#define	ASC88		0x70000
#define	ASC816		0x70300
#define	SYMBOL16		0x70900
#define	HANGUL16	0x79600
#define	HANJA16		0x8bbc0
#define	HEXA2432	0xb3640
#define	HEXA2448	0xb3ca0
#define	HEXA2464	0xb4630
#define	HEXA3232	0xb52f0
#define	HEXA3248	0xb5b70
#define	HEXA3264	0xb6830
#define	HEXA4832	0xb7930
#define	HEXA4848	0xb85f0
#define	HEXA4864	0xb9910
#define	HEXA6432	0xbb290
#define	HEXA6448	0xbc390
#define	HEXA6464	0xbdd10
#define	FONTEND		0xbff10
#else
#define	ASC68		0x0b0000
#define	ASC88		0x0b0800
#define	ASC816		0x0b1000
#define	HEXA2432	0x0b1800
#define	HEXA2448	0x0b2000
#define	HEXA2464	0x0b3000
#define	HEXA3232	0x0b4000
#define	HEXA3248	0x0b5000
#define	HEXA3264	0x0b6000
#define	HEXA4832	0x0b8000
#define	HEXA4848	0x0b9000
#define	HEXA4864	0x0bb000
#define	HEXA6432	0x0bd000
#define	HEXA6448	0x0bf000
#define	HEXA6464	0x0c1000
#define	FONTEND0	0x0c5000
#define	SYMBOL16	0x0d0000
#define	HANGUL16	0x0e0000
#define	HANJA16		0x100000
#define	FONTEND		0x127a80
#endif

unsigned char ROMBuff[0x200000];
unsigned char FontROM[0x10000];
extern	int	MakeMotFile(char *FileName,int OffSet,unsigned char *StartAddr,int leng);
int rFlag[20];
int	MakeFont(char *FileName)
{
	FILE	*fp;
	int		len;

	memset(ROMBuff, 0xff, sizeof(ROMBuff));
	fp=fopen("kanji16.fnt", "rb");
	if(fp != 0){
		len= fread(&ROMBuff[SYMBOL16 ], 1, FONTEND- SYMBOL16 , fp);
		fclose(fp);
		MakeMotFile("kanji16.mot",SYMBOL16 ,&ROMBuff[SYMBOL16 ],0xf0000- SYMBOL16 );
	}
	return(0);
}