font file

hangul16.fnt : 16 x 16 �ѱ���Ʈ

kanji16.fnt  : 16 x 16 kanji ��Ʈ

kata.fnt     : 8 x 8, 
               8 x 16 
               katakana ��Ʈ

hexa.fnt     : 32 x 32, 
               32 x 48, 
               32 x 64, 
               48 x 32, 
               48 x 48, 
               48 x 64, 
               64 x 32, 
               64 x 48, 
               64 x 64
               16���� ��Ʈ ���� "0123456789ABCDE.F"
