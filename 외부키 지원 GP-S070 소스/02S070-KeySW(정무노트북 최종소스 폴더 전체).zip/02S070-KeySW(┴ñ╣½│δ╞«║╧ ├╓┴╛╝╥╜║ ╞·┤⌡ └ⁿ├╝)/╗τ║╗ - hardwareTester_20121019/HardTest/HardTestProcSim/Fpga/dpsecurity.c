/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpsecurity.c                                            */
/*                                                                          */
/*  Description:    Contains initialization and data checking functions.    */
/*                                                                          */
/****************************************************************************/

#include "dpuser.h"
#include "dpdef.h"
#include "dpalg.h"

#include "dpjtag.h"
#include "dpcom.h"
#include "dpsecurity.h"
#include "dputil.h"

#ifdef SECURITY_SUPPORT
/************************************************************************************************/
/*  NVM Action Functions                                                                        */
/************************************************************************************************/
void dp_erase_security_action(void)
{
    device_security_flags |= IS_ERASE_ONLY;
    dp_erase_security();
    return;
}

void dp_program_security_action(void)
{
    dp_erase_security();
    if (error_code != DPE_SUCCESS)
        return;
    if (support_status & SEC_SUPPORT_BIT)
    {
        dp_program_security();
        if (error_code != DPE_SUCCESS)
            return;
    }
    return;
}
/************************************************************************************************/

/************************************************************************************************/
/*  Programming Support Functions                                                               */
/************************************************************************************************/
void dp_erase_security(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nErase Security...");
    #endif
    dp_flush_global_buf1();
    global_buf1[0] = UROW_ERASE_BITS_BYTE0;
    global_buf1[1] = UROW_ERASE_BITS_BYTE1;
    global_buf1[2] = UROW_ERASE_BITS_BYTE2;
    
    // This is for FROM erase.  Need to get which bits are set to erase from the data file.
    global_buf1[0]|=0xe;
    device_security_flags |= IS_RESTORE_DESIGN;
    
    dp_exe_erase();
    return;
}

void dp_program_security(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nProgramming Security...");
    #endif
    dp_write_sec_key();
    if (error_code != DPE_SUCCESS)
        return;
    if (support_status & AES_SUPPORT_BIT)
    {
        dp_write_enc_key();
        if (error_code != DPE_SUCCESS)
            return;
    }
    dp_match_security();
    if ((device_security_flags & SEC_KEY_OK) == 0)
    {
        error_code = DPE_MATCH_ERROR;
        return;
    }
    dp_program_ulock();
    if (error_code != DPE_SUCCESS)
        return;
    
    return;
}


void dp_write_sec_key(void)
{
    opcode = ISC_PROGRAM_UKEY;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_get_and_shift_in(UKEY_ID, UKEY_BIT_LENGTH, 0);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_poll_device();
    
    return;
}

void dp_write_enc_key(void)
{
    if (device_family & DUAL_KEY_BIT)
    {
        global_uchar = 0;
        dp_set_aes_mode();
    }    
    opcode = ISC_PROGRAM_DMK;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_get_and_shift_in(DMK_ID, DMK_BIT_LENGTH, 0);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(15);
    
    dp_poll_device();
    if (error_code != DPE_SUCCESS)
        return;
    dp_verify_enc_key();
    
    return;
}


void dp_program_ulock(void)
{
    
    dp_flush_global_buf1();
    
    if ((device_family & AFS_BIT) == AFS_BIT)
    {
        global_uint = ULOCK_AFS_BIT_LENGTH;
        /* Read security configuration from the data file */
        global_ulong = dp_get_bytes(ULOCK_ID,0,3);
        /* Set the register content to be loaded into the chip */
        global_buf1[0] = (DPUCHAR) global_ulong;
        global_buf1[1] = (DPUCHAR) ((global_ulong >> 8) | 0x80);
        global_buf1[2] = (DPUCHAR) ((global_ulong >> 16) & 0x3F);
        global_ulong = dp_get_bytes(SILSIG_ID,0,4);
        global_buf1[3] = (DPUCHAR) global_ulong;
        global_buf1[4] = (DPUCHAR) (global_ulong >> 8);
        global_buf1[5] = (DPUCHAR) (global_ulong >> 16);
        global_buf1[6] = (DPUCHAR) (global_ulong >> 24);
    }
    else
    {
        global_uint = ULOCK_A3P_AGL_BIT_LENGTH;
        /* Read security configuration from the data file */
        global_ulong = dp_get_bytes(ULOCK_ID,0,2);
        /* Set the register content to be loaded into the chip */
        global_buf1[0] = (DPUCHAR) (global_ulong | 0x4);
        global_buf1[1] = (DPUCHAR) ((global_ulong >> 8) & 0xF3);
        global_ulong = dp_get_bytes(SILSIG_ID,0,4);
        global_buf1[1] |= (DPUCHAR) (global_ulong << 4);
        global_buf1[2] = (DPUCHAR) (global_ulong >> 4);
        global_buf1[3] = (DPUCHAR) (global_ulong >> 12);
        global_buf1[4] = (DPUCHAR) (global_ulong >> 20);
        global_buf1[5] = (DPUCHAR) (global_ulong >> 28);
    }
    
    opcode = ISC_PROGRAM_SECURITY;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, global_uint, global_buf1,1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    
    dp_poll_device();
    if (error_code != DPE_SUCCESS)
        return;
    
    
    opcode = ISC_QUERY_SECURITY;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    
    dp_flush_global_buf2();
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(global_uint, (DPUCHAR*)NULL, global_buf2);
    dp_goto_state(JTAG_DRPAUSE);
    
    if ((device_family & AFS_BIT) == AFS_BIT)
    {    
        if ((global_buf1[0]) != (global_buf2[0]))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
        if ((global_buf1[1]) != (global_buf2[1]))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
        if ((global_buf1[2] & 0x3F) != (global_buf2[2]& 0x3F))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
        if ((global_buf1[3]) != (global_buf2[3]))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
        if ((global_buf1[4]) != (global_buf2[4]))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
        if ((global_buf1[5]) != (global_buf2[5]))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
        if ((global_buf1[6]) != (global_buf2[6]))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
    }
    else 
    {    
        if ((global_buf1[0]) != (global_buf2[0]))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
        if ((global_buf1[1] & 0xF3) != (global_buf2[1]& 0xF3))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
        if ((global_buf1[2]) != (global_buf2[2]))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
        if ((global_buf1[3]) != (global_buf2[3]))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
        if ((global_buf1[4]) != (global_buf2[4]))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
        if ((global_buf1[5] & 0xF) != (global_buf2[5]& 0xF))
        {
            error_code = DPE_ULOCK_ERROR;
            return;
        }
    }
    
    
    return;
}
#endif


void dp_match_security(void)
{
    opcode = ISC_MATCH_UKEY;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_get_and_shift_in(UKEY_ID, UKEY_BIT_LENGTH, 0);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(48);
    
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(DMK_BIT_LENGTH, (DPUCHAR*)NULL, global_buf1);
    dp_goto_state(JTAG_DRPAUSE);
    if ((global_buf1[0] & 0x3) == 0x1)
        device_security_flags |= SEC_KEY_OK;
    
    
    if (support_status & SEC_SUPPORT_BIT)
    {
        
        global_ulong = dp_get_bytes(UKEY_ID,0,4);
        global_ulong |= dp_get_bytes(UKEY_ID,4,4);
        global_ulong |= dp_get_bytes(UKEY_ID,8,4);
        global_ulong |= dp_get_bytes(UKEY_ID,12,4);
        
        
        if (global_ulong == 0)
            device_security_flags |= PERM_LOCK_BIT;
    }
    
    return;
}

void dp_verify_enc_key(void)
{
    
    if (device_family & DUAL_KEY_BIT)
    {
        global_uchar = 0;
        dp_set_aes_mode();
    }
    dp_init_aes();
    
    opcode = ISC_VERIFY_DMK;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_get_and_shift_in(KDATA_ID, DMK_BIT_LENGTH, 0);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(256);
    
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(DMK_BIT_LENGTH, (DPUCHAR*)NULL, global_buf1);
    dp_goto_state(JTAG_DRPAUSE);
    
    if ((global_buf1[15] & 0xC0) != 0xC0)
    {
        error_code = DPE_DMK_VERIFY_ERROR;
        return;
    }
    return;
}

void dp_read_device_security(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nReading Security...");
    #endif
    
    if ((device_family & AFS_BIT) == AFS_BIT)
    {
        global_uint = ULOCK_AFS_BIT_LENGTH;
    }
    else
    {
        global_uint = ULOCK_A3P_AGL_BIT_LENGTH;
    }
    opcode = ISC_QUERY_SECURITY;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_flush_global_buf2();
    /* reset only the security bit locations */
    device_security_flags &= 0xFF000000;
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(global_uint, (DPUCHAR*)NULL, global_buf2);
    dp_goto_state(JTAG_DRPAUSE);
    
    if ((device_family & AFS_BIT) == AFS_BIT)
    {
        device_security_flags |= (global_buf2[0] | (global_buf2[1] << 8) | (global_buf2[2] << 16));
    }
    /* This step is to line up the security flags for AFS and A3P.  This is usedful so that the mask bits are the same for both families */
    else
    {
        device_security_flags |= ((global_buf2[0] << 12) | (global_buf2[1] << 20));
    }
    
    return;
}

void dp_program_silsig(void)
{
    #ifdef ENABLE_DEBUG
    dp_display_text("\r\nProgramming SILSIG...");
    #endif
    
    
    
    if ((device_family & AFS_BIT) == AFS_BIT)
    {
        global_uint = ULOCK_AFS_BIT_LENGTH;
        /* Set the register content to be loaded into the chip */
        global_buf1[0] = (DPUCHAR) device_security_flags;
        global_buf1[1] = (DPUCHAR) (device_security_flags >> 8);
        global_buf1[2] = (DPUCHAR) (device_security_flags >> 16);
        global_ulong = dp_get_bytes(SILSIG_ID,0,4);
        global_buf1[3] = (DPUCHAR) global_ulong;
        global_buf1[4] = (DPUCHAR) (global_ulong >> 8);
        global_buf1[5] = (DPUCHAR) (global_ulong >> 16);
        global_buf1[6] = (DPUCHAR) (global_ulong >> 24);
    }
    else
    {
        global_uint = ULOCK_A3P_AGL_BIT_LENGTH;
        /* Read security configuration from the data file */
        global_buf1[0] = (DPUCHAR) (device_security_flags >> 12);
        global_buf1[1] = (DPUCHAR) (device_security_flags >> 20) & 0xF;
        
        global_ulong = dp_get_bytes(SILSIG_ID,0,4);
        global_buf1[1] |= (DPUCHAR) (global_ulong << 4);
        global_buf1[2] = (DPUCHAR) (global_ulong >> 4);
        global_buf1[3] = (DPUCHAR) (global_ulong >> 12);
        global_buf1[4] = (DPUCHAR) (global_ulong >> 20);
        global_buf1[5] = (DPUCHAR) (global_ulong >> 28);
    }
    
    
    opcode = ISC_PROGRAM_SECURITY;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, global_uint, global_buf1,1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    
    dp_poll_device();
    if (error_code != DPE_SUCCESS)
        error_code = DPE_ULOCK_ERROR;
    
    
    return;
}
void dp_check_dual_key(void)
{
    if ((device_ID & AXXE600X_ID_MASK) == (AXXE600X_ID & AXXE600X_ID_MASK) || 
    #ifdef ENABLE_AXXE1500_SUPPORT
    (device_ID & AXXE1500X_ID_MASK) == (AXXE1500X_ID & AXXE1500X_ID_MASK) || 
    #endif
    (device_ID & AXXE3000X_ID_MASK) == (AXXE3000X_ID & AXXE3000X_ID_MASK) || 
    ( ( (device_ID & AFS600_ID_MASK) == (AFS600_ID & AFS600_ID_MASK) ) && (device_rev > 1) ) ||
    (device_ID & AFS1500_ID_MASK) == (AFS1500_ID & AFS1500_ID_MASK))
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nChecking for Dual Key Device...");
        #endif
        
        global_uchar = 1;
        dp_set_aes_mode();
        dp_init_aes();
        dp_verify_fc_dmk();
        /* Need to reset to DMK mode */
        
        global_uchar = 0;
        dp_set_aes_mode();
        dp_init_aes();
        
        if(error_code != DPE_SUCCESS)
            return;
    }
}

void dp_verify_id_dmk(void)
{
    
    if ( (device_ID & AXX030X_ID_MASK) != (AXX030X_ID & AXX030X_ID_MASK) && (device_ID & AGLP030X_ID_MASK) != (AGLP030X_ID & AGLP030X_ID_MASK) )
    {
        if (device_family & DUAL_KEY_BIT)
        {
            global_uchar = 1;
            dp_set_aes_mode();
        }
        
        dp_init_aes();
        dp_verify_m7_dmk();
        if(error_code != DPE_SUCCESS)
            return;
        dp_verify_m1_dmk();
        if(error_code != DPE_SUCCESS)
            return;
        dp_verify_p1_dmk();
        if(error_code != DPE_SUCCESS)
            return;
        
        if (device_family & DUAL_KEY_BIT)
        {
            if ( ((device_security_flags | M7_DEVICE) == 0) && ((device_security_flags | M1_DEVICE) == 0) && ((device_security_flags | P1_DEVICE) == 0))
            {
                #ifdef ENABLE_DEBUG
                dp_display_text("\r\nError: Core enabled device detected...");
                #endif
                error_code = DPE_IDCODE_ERROR;
            }
        }
    }
    return;
}

void dp_verify_m7_dmk(void)
{
    global_buf1[0]=M7BYTE0;
    global_buf1[1]=M7BYTE1;
    global_buf1[2]=M7BYTE2;
    global_buf1[3]=M7BYTE3;
    global_buf1[4]=M7BYTE4;
    global_buf1[5]=M7BYTE5;
    global_buf1[6]=M7BYTE6;
    global_buf1[7]=M7BYTE7;
    global_buf1[8]=M7BYTE8;
    global_buf1[9]=M7BYTE9;
    global_buf1[10]=M7BYTE10;
    global_buf1[11]=M7BYTE11;
    global_buf1[12]=M7BYTE12;
    global_buf1[13]=M7BYTE13;
    global_buf1[14]=M7BYTE14;
    global_buf1[15]=M7BYTE15;
    
    opcode = ISC_VERIFY_DMK;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, DMK_BIT_LENGTH, global_buf1,1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(256);
    
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(DMK_BIT_LENGTH, (DPUCHAR*)NULL, global_buf2);
    dp_goto_state(JTAG_DRPAUSE);
    if ((global_buf2[15] & 0x80) == 0)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nFailed to verify AES Sec...");
        #endif
        error_code = DPE_AES_SEC_ERROR;
        return;
    }
    else if (global_buf2[15] & 0x40)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nM7 Device Detected...");
        #endif
        device_security_flags |= M7_DEVICE;
    }
    
    global_uchar = (DPUCHAR) dp_get_bytes(Header_ID,M_DEVICE_OFFSET,1);
    
    if ((device_security_flags & M7_DEVICE) && (global_uchar != M7))
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nError: M7 Device Detected. Data file is not compiled for M7 Device...");
        #endif
        error_code = DPE_IDCODE_ERROR;
        return;
    }
    else if (((device_security_flags & M7_DEVICE) == 0) && (global_uchar == M7))
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nError: M7 Device is not Detected. Data file is compiled for M7 Device...");
        #endif
        error_code = DPE_IDCODE_ERROR;
        return;
    }
    
    return;
}

void dp_verify_m1_dmk(void)
{
    global_buf1[0]=M1BYTE0;
    global_buf1[1]=M1BYTE1;
    global_buf1[2]=M1BYTE2;
    global_buf1[3]=M1BYTE3;
    global_buf1[4]=M1BYTE4;
    global_buf1[5]=M1BYTE5;
    global_buf1[6]=M1BYTE6;
    global_buf1[7]=M1BYTE7;
    global_buf1[8]=M1BYTE8;
    global_buf1[9]=M1BYTE9;
    global_buf1[10]=M1BYTE10;
    global_buf1[11]=M1BYTE11;
    global_buf1[12]=M1BYTE12;
    global_buf1[13]=M1BYTE13;
    global_buf1[14]=M1BYTE14;
    global_buf1[15]=M1BYTE15;
    
    opcode = ISC_VERIFY_DMK;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, DMK_BIT_LENGTH, global_buf1,1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(256);
    
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(DMK_BIT_LENGTH, (DPUCHAR*)NULL, global_buf2);
    dp_goto_state(JTAG_DRPAUSE);
    if ((global_buf2[15] & 0x80) == 0)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nFailed to verify AES Sec...");
        #endif
        error_code = DPE_AES_SEC_ERROR;
        return;
    }
    else if (global_buf2[15] & 0x40)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nM1 Device Detected...");
        #endif
        device_security_flags |= M1_DEVICE;
    }
    
    global_uchar = (DPUCHAR) dp_get_bytes(Header_ID,M_DEVICE_OFFSET,1);
    
    if ((device_security_flags & M1_DEVICE) && (global_uchar != M1))
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nError: M1 Device Detected. Data file is not compiled for M1 Device...");
        #endif
        error_code = DPE_IDCODE_ERROR;
        return;
    }
    else if (((device_security_flags & M1_DEVICE) == 0) && (global_uchar == M1))
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nError: M1 Device is not Detected. Data file is compiled for M1 Device...");
        #endif
        error_code = DPE_IDCODE_ERROR;
        return;
    }
    return;
}

void dp_verify_p1_dmk(void)
{
    global_buf1[0]=P1BYTE0;
    global_buf1[1]=P1BYTE1;
    global_buf1[2]=P1BYTE2;
    global_buf1[3]=P1BYTE3;
    global_buf1[4]=P1BYTE4;
    global_buf1[5]=P1BYTE5;
    global_buf1[6]=P1BYTE6;
    global_buf1[7]=P1BYTE7;
    global_buf1[8]=P1BYTE8;
    global_buf1[9]=P1BYTE9;
    global_buf1[10]=P1BYTE10;
    global_buf1[11]=P1BYTE11;
    global_buf1[12]=P1BYTE12;
    global_buf1[13]=P1BYTE13;
    global_buf1[14]=P1BYTE14;
    global_buf1[15]=P1BYTE15;
    
    opcode = ISC_VERIFY_DMK;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, DMK_BIT_LENGTH, global_buf1,1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(256);
    
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(DMK_BIT_LENGTH, (DPUCHAR*)NULL, global_buf2);
    dp_goto_state(JTAG_DRPAUSE);
    if ((global_buf2[15] & 0x80) == 0)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nFailed to verify AES Sec...");
        #endif
        error_code = DPE_AES_SEC_ERROR;
        return;
    }
    else if (global_buf2[15] & 0x40)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nP1 Device Detected...");
        #endif
        device_security_flags |= P1_DEVICE;
    }
    
    global_uchar = (DPUCHAR) dp_get_bytes(Header_ID,M_DEVICE_OFFSET,1);
    
    if ((device_security_flags & P1_DEVICE) && (global_uchar != P1))
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nError: P1 Device Detected. Data file is not compiled for P1 Device...");
        #endif
        error_code = DPE_IDCODE_ERROR;
        return;
    }
    else if (((device_security_flags & P1_DEVICE) == 0) && (global_uchar == P1))
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nError: P1 Device is not Detected. Data file is compiled for P1 Device...");
        #endif
        error_code = DPE_IDCODE_ERROR;
        return;
    }
    return;
}


void dp_verify_fc_dmk(void)
{
    global_buf1[0]=FCBYTE0;
    global_buf1[1]=FCBYTE1;
    global_buf1[2]=FCBYTE2;
    global_buf1[3]=FCBYTE3;
    global_buf1[4]=FCBYTE4;
    global_buf1[5]=FCBYTE5;
    global_buf1[6]=FCBYTE6;
    global_buf1[7]=FCBYTE7;
    global_buf1[8]=FCBYTE8;
    global_buf1[9]=FCBYTE9;
    global_buf1[10]=FCBYTE10;
    global_buf1[11]=FCBYTE11;
    global_buf1[12]=FCBYTE12;
    global_buf1[13]=FCBYTE13;
    global_buf1[14]=FCBYTE14;
    global_buf1[15]=FCBYTE15;
    
    opcode = ISC_VERIFY_DMK;
    dp_goto_state(JTAG_SHIR);
    dp_shift_in(0, OPCODE_BIT_LENGTH, &opcode, 1);
    dp_goto_state(JTAG_IRPAUSE);
    dp_goto_state(JTAG_SHDR);
    dp_shift_in(0, DMK_BIT_LENGTH, global_buf1,1);
    dp_goto_state(JTAG_IDLE);
    dp_wait_cycles(3);
    dp_delay(256);
    
    dp_goto_state(JTAG_SHDR);
    dp_shift_in_out(DMK_BIT_LENGTH, (DPUCHAR*)NULL, global_buf2);
    dp_goto_state(JTAG_DRPAUSE);
    if ((global_buf2[15] & 0x80) == 0)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nFailed to verify AES Sec...");
        #endif
        error_code = DPE_AES_SEC_ERROR;
        return;
    }
    else if (global_buf2[15] & 0x40)
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nSingle Key Device Detected...");
        #endif
    }
    else 
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nDual Key Device Detected...");
        #endif
        device_family |= DUAL_KEY_BIT;
    }
    
    
    return;
}

