/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpcom.h                                                 */
/*                                                                          */
/*  Description:    Contains functions prototypes needed to access the data	*/
/*	from external flash or other means of communication						*/
/*                                                                          */
/****************************************************************************/

#ifndef INC_DPCOM_H
#define INC_DPCOM_H

extern DPULONG return_bytes;
extern DPULONG image_size;

/* user attention is required.  PAGE_BUFFER_SIZE needs to be specified in bytes */
#define PAGE_BUFFER_SIZE 4

/* 
* Data block ID definitions
*/
#define Header_ID		        0
#define ACT_UROW_DESIGN_NAME_ID 1
#define BsrPattern_ID 			2  
#define SILSIG_ID 				3		
#define CHECKSUM_ID				4
#define datastream_ID 			5
#define rlock_ID 				6
#define FRomAddressMask_ID 		7 
#define FRomStream_ID 	    	8 

/* These defintions are the same as NVM block zoro.  They are defined to aviod confusion when pogram and verify NVM functions are called. */
#define NVM_OFFSET		        5
#define NvmParSize_ID 			9 
#define NumOfPart_ID 			10
#define NvmAddr_ID 				11
#define NvmData_ID 				12
#define NvmProtect_ID 			13


#define NvmParSize_0_ID 		9 
#define NumOfPart_0_ID 			10
#define NvmAddr_0_ID 			11
#define NvmData_0_ID 			12
#define NvmProtect_0_ID 		13
#define NvmParSize_1_ID 		14
#define NumOfPart_1_ID 			15
#define NvmAddr_1_ID 			16
#define NvmData_1_ID 			17
#define NvmProtect_1_ID 		18
#define NvmParSize_2_ID 		19
#define NumOfPart_2_ID 			20
#define NvmAddr_2_ID 			21
#define NvmData_2_ID 			22
#define NvmProtect_2_ID 		23
#define NvmParSize_3_ID 		24
#define NumOfPart_3_ID 			25
#define NvmAddr_3_ID 			26
#define NvmData_3_ID 			27
#define NvmProtect_3_ID 		28
#define UKEY_ID					29
#define DMK_ID					30
#define KDATA_ID				31
#define ULOCK_ID				32

/*
* Location of special variables needed in the header section of the image file
*/
#define BTYES_PER_TABLE_RECORD	9
#define ACTEL_HEADER_SIZE		24
#define HEADER_SIZE_OFFSET		24
#define IMAGE_SIZE_OFFSET		25
#define MIN_IMAGE_SIZE			56
#define M_DEVICE_OFFSET			30
#define ID_OFFSET				31


DPUCHAR * dp_get_data(DPUCHAR var_ID,DPULONG bit_index);
DPUCHAR * dp_get_header_data(DPULONG bit_index);
void dp_get_page_data(DPULONG image_requested_address);
void dp_get_data_block_address(DPUCHAR requested_var_ID);
DPUCHAR * dp_get_data_block_element_address(DPULONG bit_index);
DPULONG dp_get_bytes(DPUCHAR var_ID,DPULONG byte_index,DPUCHAR requested_bytes);
DPULONG dp_get_header_bytes(DPULONG byte_index,DPUCHAR requested_bytes);
#endif /* INC_DPCOM_H */


