/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpcom.h                                                 */
/*                                                                          */
/*  Description:    Contains functions prototypes needed to access the data	*/
/*	from external flash or other means of communication						*/
/*                                                                          */
/****************************************************************************/

#ifndef INC_DPUTIL_H
#define INC_DPUTIL_H

void dp_flush_global_buf1(void);
void dp_flush_global_buf2(void);
void dp_init_vars(void);
void dp_get_support_status(void);
void dp_compute_crc(void);
void dp_check_image_crc(void);

#endif /* INC_DPUTIL_H */


