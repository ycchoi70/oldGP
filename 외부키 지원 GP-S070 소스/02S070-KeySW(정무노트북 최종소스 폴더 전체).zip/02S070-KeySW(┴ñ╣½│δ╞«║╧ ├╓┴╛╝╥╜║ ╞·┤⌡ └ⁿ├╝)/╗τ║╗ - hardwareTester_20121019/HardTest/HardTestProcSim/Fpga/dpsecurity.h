/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpsecurity.h                                            */
/*                                                                          */
/*  Description:    Contains the function prototypes.                       */
/*                                                                          */
/****************************************************************************/

#ifndef INC_dpsecurity_H
#define INC_dpsecurity_H

/****************************************************************************/
/* Security Opcodes                                                         */
/****************************************************************************/
#define ISC_PROGRAM_UKEY        0x8B
#define ISC_PROGRAM_DMK         0x91
#define ISC_VERIFY_DMK          0x0A
#define AES_INIT                0xDD
#define ISC_MATCH_UKEY          0x92
#define ISC_PROGRAM_SECURITY    0xA3
#define ISC_QUERY_SECURITY      0xA4
#define AES_MODE                0xAC

/****************************************************************************/
/* Security Bit Locations for AFS devices.                                  */
/****************************************************************************/
#define ULNR0               0x0000001
#define ULNW0               0x0000002
#define ULNC0               0x0000004
#define ULNR1               0x0000008
#define ULNW1               0x0000010
#define ULNC1               0x0000020
#define ULNR2               0x0000040
#define ULNW2               0x0000080
#define ULNC2               0x0000100
#define ULNR3               0x0000200
#define ULNW3               0x0000400
#define ULNC3               0x0000800
#define ULARD               0x0001000
#define ULAWE               0x0002000
#define ULULR               0x0004000
#define ULFLR               0x0008000
#define ULUFJ               0x0010000
#define ULUFP               0x0020000
#define ULUFE               0x0040000
#define ULUPC               0x0080000
#define ULARE               0x0100000
#define ULUWE               0x0200000
#define ULOPT0              0x0400000
#define ULOPT1              0x0800000
#define SEC_KEY_OK          0x01000000
#define PERM_LOCK_BIT       0x02000000
#define IS_ERASE_ONLY       0x04000000
#define IS_RESTORE_DESIGN   0x08000000
#define SET_ERASE_SEC       0x10000000
#define M7_DEVICE           0x20000000
#define M1_DEVICE           0x40000000
#define P1_DEVICE           0x80000000
/****************************************************************************/
/* NVM Register length and parameters                                       */
/****************************************************************************/
#define UKEY_BIT_LENGTH				128
#define DMK_BIT_LENGTH				128
#define AES_BIT_LENGTH				128
#define AES_MODE_BIT_LENGTH         3
#define ULOCK_A3P_AGL_BIT_LENGTH    44
#define ULOCK_AFS_BIT_LENGTH		56
#define SILGIG_BIT_LENGTH			32


/****************************************************************************/
/* Function prototypes                                                      */
/****************************************************************************/
void dp_program_security(void);
void dp_write_sec_key(void);
void dp_write_enc_key(void);
void dp_verify_enc_key(void);
void dp_match_security(void);
void dp_program_ulock(void);
void dp_read_device_security(void);
void dp_program_silsig(void);
void dp_erase_security_action(void);
void dp_erase_security(void);
void dp_program_security_action(void);
void dp_check_dual_key(void);
void dp_verify_id_dmk(void);
void dp_verify_p1_dmk(void);
void dp_verify_m1_dmk(void);
void dp_verify_m7_dmk(void);
void dp_verify_fc_dmk(void);
#endif
