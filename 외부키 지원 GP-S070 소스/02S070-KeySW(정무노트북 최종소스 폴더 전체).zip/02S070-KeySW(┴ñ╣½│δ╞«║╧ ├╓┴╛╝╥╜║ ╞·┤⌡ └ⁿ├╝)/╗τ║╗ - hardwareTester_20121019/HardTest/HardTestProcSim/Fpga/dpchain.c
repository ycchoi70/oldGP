/****************************************************************************/
/*                                                                          */
/*  DirectC			        Copyright (C) Actel Corporation 2008            */
/*  Version 2.3				Release date August 29, 2008                    */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  Module:         dpchain.c                                               */
/*                                                                          */
/*  Description:    Contains chain functions                                */
/*                                                                          */
/****************************************************************************/

#include "dpuser.h"
#include "dpchain.h"
#include "dpjtag.h"
#include "dpcom.h"

#ifdef CHAIN_SUPPORT
DPUCHAR dp_preir_data[PREIR_DATA_SIZE];
DPUCHAR dp_predr_data[PREDR_DATA_SIZE];
DPUCHAR dp_postir_data[POSTIR_DATA_SIZE];
DPUCHAR dp_postdr_data[POSTDR_DATA_SIZE];

DPUINT dp_preir_length = PREIR_LENGTH_VALUE;
DPUINT dp_predr_length = PREDR_LENGTH_VALUE;
DPUINT dp_postir_length = POSTIR_LENGTH_VALUE;
DPUINT dp_postdr_length = POSTDR_LENGTH_VALUE;


void dp_shift_in(DPULONG start_bit, DPUINT num_bits, DPUCHAR* tdi_data, DPUCHAR terminate)
{
    if (current_jtag_state == JTAG_SHIR)
    {
        if (dp_preir_length > 0)
        {
            dp_do_shift_in(0,dp_preir_length, dp_preir_data,0);
        }
        if (dp_postir_length > 0)
        {
            dp_do_shift_in(start_bit,num_bits, tdi_data,0);
            dp_do_shift_in(0,dp_postir_length, dp_postir_data, terminate);
        }
        else
        {
            dp_do_shift_in(start_bit,num_bits, tdi_data,terminate);
        }	
    }
    else if (current_jtag_state == JTAG_SHDR)
    {
        if (dp_predr_length > 0)
        {
            dp_do_shift_in(0,dp_predr_length, dp_predr_data,0);
        }
        if (dp_postdr_length > 0)
        {
            dp_do_shift_in(start_bit,num_bits, tdi_data,0);
            dp_do_shift_in(0,dp_postdr_length, dp_postdr_data, terminate);
        }
        else
        {
            dp_do_shift_in(start_bit,num_bits, tdi_data,terminate);
        }
    }
    return;
}

void dp_shift_in_out(DPUINT num_bits, DPUCHAR* tdi_data, DPUCHAR* tdo_data)
{
    if (current_jtag_state == JTAG_SHIR)
    {
        if (dp_preir_length > 0)
        {
            dp_do_shift_in(0,dp_preir_length, dp_preir_data,0);
        }
        if (dp_postir_length > 0)
        {
            dp_do_shift_in_out(num_bits, tdi_data,tdo_data,0);
            dp_do_shift_in(0,dp_postir_length, dp_postir_data, 1);
        }
        else
        {
            dp_do_shift_in_out(num_bits, tdi_data,tdo_data,1);
        }	
    }
    else if (current_jtag_state == JTAG_SHDR)
    {
        if (dp_predr_length > 0)
        {
            dp_do_shift_in(0,dp_predr_length, dp_predr_data,0);
        }
        if (dp_postdr_length > 0)
        {
            dp_do_shift_in_out(num_bits, tdi_data,tdo_data,0);
            dp_do_shift_in(0,dp_postdr_length, dp_postdr_data, 1);
        }
        else
        {
            dp_do_shift_in_out(num_bits, tdi_data,tdo_data,1);
        }
    }
    return;
}


void dp_do_shift_in(DPULONG start_bit, DPUINT num_bits, DPUCHAR* tdi_data, DPUCHAR terminate)
{
    idx = (DPUCHAR) start_bit >> 3;
    bit_buf = 1 << (DPUCHAR)(start_bit & 0x7);
    if (tdi_data == (DPUCHAR*)NULL)
        data_buf = 0;
    else data_buf = tdi_data[idx] >> ((DPUCHAR)(start_bit & 0x7));
    if (terminate == 0)
        num_bits++;
    while (--num_bits)
    {
        dp_jtag_tms_tdi(0, data_buf&0x1);
        data_buf >>= 1;
        bit_buf <<= 1;
        if ((bit_buf & 0xff) == 0 )
        {
            bit_buf = 1;
            idx++;
            if (tdi_data == (DPUCHAR*)NULL)
                data_buf = 0;
            else data_buf = tdi_data[idx];
        }
    }
    if (terminate)
    {
        dp_jtag_tms_tdi(1, data_buf&0x1);
        if (current_jtag_state == JTAG_SHIR)
            current_jtag_state = JTAG_EXIR;
        else if (current_jtag_state == JTAG_SHDR)
            current_jtag_state = JTAG_EXDR;
    }
    return;
}

void dp_do_shift_in_out(DPUINT num_bits, DPUCHAR* tdi_data, DPUCHAR* tdo_data, DPUCHAR terminate)
{
    bit_buf = 1;
    idx = 0;
    tdo_data[idx]=0;
    
    if (tdi_data == (DPUCHAR*)NULL)
        data_buf = 0;
    else data_buf = tdi_data[idx];
    
    while (--num_bits)
    {
        if ((bit_buf & 0xff) == 0 )
        {
            bit_buf = 1;
            idx++;
            tdo_data[idx]=0;
            if (tdi_data == (DPUCHAR*)NULL)
                data_buf = 0;
            else data_buf = tdi_data[idx];
        }
        if (dp_jtag_tms_tdi_tdo(0, data_buf&0x1))
            tdo_data[idx] |= bit_buf;
        bit_buf <<= 1;
        data_buf>>=1;
    }
    if ((bit_buf & 0xff) == 0 )
    {
        bit_buf = 1;
        idx++;
        tdo_data[idx]=0;
        if (tdi_data == (DPUCHAR*)NULL)
            data_buf = 0;
        else data_buf = tdi_data[idx];
    }
    if(terminate)
    {
        if (dp_jtag_tms_tdi_tdo(1, data_buf&0x1))
            tdo_data[idx] |= bit_buf;
        if (current_jtag_state == JTAG_SHIR)
            current_jtag_state = JTAG_EXIR;
        else if (current_jtag_state == JTAG_SHDR)
            current_jtag_state = JTAG_EXDR;
    }
    else 
    {
        if (dp_jtag_tms_tdi_tdo(0, data_buf&0x1))
            tdo_data[idx] |= bit_buf;
    }
    return;
}

void dp_get_and_shift_in(DPUCHAR Variable_ID,DPUINT total_bits_to_shift, DPULONG start_bit_index)
{
    DPULONG page_start_bit_index;
    DPUINT bits_to_shift;
    DPUCHAR terminate;
    page_start_bit_index = start_bit_index & 0x7;
    requested_bytes = (DPUCHAR) (page_start_bit_index + total_bits_to_shift + 7) >> 3;
    
    if (current_jtag_state == JTAG_SHIR)
    {
        if (dp_preir_length > 0)
        {
            dp_do_shift_in(0,dp_preir_length, dp_preir_data,0);
        }
    }
    else if (current_jtag_state == JTAG_SHDR)
    {
        if (dp_predr_length > 0)
        {
            dp_do_shift_in(0,dp_predr_length, dp_predr_data,0);
        }
    }
    
    terminate = 0;
    while (requested_bytes)
    {
        page_buffer_ptr = dp_get_data(Variable_ID,start_bit_index);
        
        if (return_bytes >= requested_bytes )
        {
            return_bytes = requested_bytes;
            bits_to_shift = total_bits_to_shift;
            terminate = 1;
            if (((current_jtag_state == JTAG_SHIR) && dp_postir_length) || ((current_jtag_state == JTAG_SHDR) && dp_postdr_length))
                terminate =0;
        }
        else bits_to_shift = (DPUCHAR) (return_bytes * 8 - page_start_bit_index);
        dp_do_shift_in(page_start_bit_index, bits_to_shift, page_buffer_ptr,terminate);
        
        requested_bytes = requested_bytes - return_bytes;
        total_bits_to_shift = total_bits_to_shift - bits_to_shift;
        start_bit_index += bits_to_shift;
        page_start_bit_index = start_bit_index & 0x7;
    }
    
    if (current_jtag_state == JTAG_SHIR)
    {
        if (dp_postir_length > 0)
        {
            dp_do_shift_in(0,dp_postir_length, dp_postir_data,1);
        }
    }
    else if (current_jtag_state == JTAG_SHDR)
    {
        if (dp_postdr_length > 0)
        {
            dp_do_shift_in(0,dp_postdr_length, dp_postdr_data,1);
        }
    }
    return;
}

void dp_get_and_shift_in_out(DPUCHAR Variable_ID,DPUCHAR total_bits_to_shift, DPULONG start_bit_index,DPUCHAR* tdo_data)
{
    requested_bytes = (DPUCHAR) (total_bits_to_shift + 7) >> 3;
    page_buffer_ptr = dp_get_data(Variable_ID,start_bit_index);
    
    if (return_bytes >= requested_bytes )
    {
        return_bytes = requested_bytes;
        dp_shift_in_out(total_bits_to_shift, page_buffer_ptr,tdo_data);
    }
    else
    {
        #ifdef ENABLE_DEBUG
        dp_display_text("\r\nError: Page buffer size is not big enough...");
        #endif
    }
    
    return;
}
#endif
