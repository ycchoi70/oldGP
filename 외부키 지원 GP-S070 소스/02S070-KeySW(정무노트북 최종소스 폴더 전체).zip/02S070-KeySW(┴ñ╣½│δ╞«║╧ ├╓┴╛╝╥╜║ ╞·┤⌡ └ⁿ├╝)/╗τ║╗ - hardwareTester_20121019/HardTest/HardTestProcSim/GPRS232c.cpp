/*/////////////////////////////////////////////////////////////////////
��	��	��	:	GPRS232ccpp
���α׷���	:	CGPRS232c Ŭ���� ������
��		��	:	RS232C ��� ���
Ŭ �� ����  :	CGPRS232c
��	��	��  :	�� �� ��
����  �̷�  :	2002-04-01 �ۼ�
/////////////////////////////////////////////////////////////////////*/

#include "stdafx.h"
#include "GPRS232c.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

UINT Receive232Thread(LPVOID wndParam);

/*/////////////////////////////////////////////////////////////////////
FUNCTION	:	������
METHOD NAME	:
PARAMETER	:
RETURN		:
/////////////////////////////////////////////////////////////////////*/
CGPRS232c::CGPRS232c()
{
	m_pParent = NULL;
	m_Data = NULL;
	Receive232WinThread = NULL;
	m_ioRead.hEvent		= NULL;
	m_ioWrite.hEvent	= NULL;
}

/*/////////////////////////////////////////////////////////////////////
FUNCTION	:	�Ҹ���
METHOD NAME	:
PARAMETER	:
RETURN		:
/////////////////////////////////////////////////////////////////////*/
CGPRS232c::~CGPRS232c()
{
	if (m_Data)	delete[] m_Data;
	
	if (m_ioRead.hEvent)
		CloseHandle(m_ioRead.hEvent);

	if (m_ioWrite.hEvent)
		CloseHandle(m_ioWrite.hEvent);

	Close();
}

/*/////////////////////////////////////////////////////////////////////
FUNCTION	:	RS232C ��� �α� ���� �ۼ�
METHOD NAME	:
PARAMETER	:
RETURN		:
/////////////////////////////////////////////////////////////////////*/
void CGPRS232c::LogFile(LPBYTE buf, INT size, BOOL bRcvSnd) 
{
	HANDLE	hFile;
	DWORD	dwWritten;
	char    szNewLine[] = {"\r\n"};
	char    szSend[] = {"SEND=> "};
	char    szRecv[] = {"RECV=> "};

	hFile = CreateFile( "../tmp/RS232C.LOG", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );
	SetFilePointer( hFile, 0, NULL, FILE_END );

	if( bRcvSnd ){
		WriteFile( hFile, szSend, sizeof(szSend), &dwWritten, NULL );	// �۽� ������ �ε���
	}else{
		WriteFile( hFile, szRecv, sizeof(szRecv), &dwWritten, NULL );	// ���� ������ �ε���
	}

	WriteFile( hFile, buf, size, &dwWritten, NULL );					// ������ 
	WriteFile( hFile, szNewLine, sizeof(szNewLine), &dwWritten, NULL );	// ���� �ڵ�
	
	CloseHandle( hFile );
}


/*/////////////////////////////////////////////////////////////////////
FUNCTION	:	RS232C ��� CREATE
METHOD NAME	:
PARAMETER	:
RETURN		:
/////////////////////////////////////////////////////////////////////*/
BOOL CGPRS232c::Create(CWnd* pParent, DWORD nRcvMaxLen, DWORD nSndMaxLen)
{
	m_ioRead.Offset		= 0;
	m_ioRead.OffsetHigh = 0;
	m_ioWrite.Offset	= 0;
	m_ioWrite.OffsetHigh= 0;

	m_ioRead.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	if (m_ioRead.hEvent)
	{
		m_ioWrite.hEvent = ::CreateEvent(NULL, TRUE, FALSE, NULL);
		if (m_ioWrite.hEvent)
		{
			m_pParent = pParent;
			m_nRcvMaxLen = nRcvMaxLen;		//���Ź���
			m_nSndMaxLen = nSndMaxLen;		//�۽Ź���

			m_Data = new BYTE[nRcvMaxLen + 1];

			return TRUE;
		}
		
		::CloseHandle(m_ioRead.hEvent);
		//050621
		m_ioRead.hEvent= NULL;
	}
	return FALSE;
}


/*/////////////////////////////////////////////////////////////////////
FUNCTION	:	RS232C ��� OPEN
METHOD NAME	:
PARAMETER	:
RETURN		:
/////////////////////////////////////////////////////////////////////*/
// 2007.06.28 by ycchoi
//BOOL CGPRS232c::Open(CString strPort, DWORD nRate, BYTE nParity , BYTE nSize, BYTE nStop)
BOOL CGPRS232c::Open(CString strPort, DWORD nRate, BYTE nParity , BYTE nSize, BYTE nStop, BOOL bDsrFlow)
{
	DCB	Dcb;

	if(Receive232WinThread)	return FALSE;

	m_Handle = CreateFile(	strPort,
							GENERIC_READ|GENERIC_WRITE,
							0,
							NULL,
							OPEN_EXISTING,
							FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
							NULL
						  );

	if(m_Handle == HANDLE(-1))
		return FALSE;

	if(SetCommMask(m_Handle, EV_RXCHAR) == FALSE){
		CloseHandle(m_Handle);
		return FALSE;
	}

	if(SetupComm(m_Handle, m_nRcvMaxLen, m_nSndMaxLen) == FALSE){
		CloseHandle(m_Handle);
		return FALSE;
	}

	if(PurgeComm(m_Handle, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR) == FALSE){
		CloseHandle(m_Handle);
		return FALSE;
	}
	//if(PurgeComm(m_Handle, PURGE_TXCLEAR | PURGE_RXCLEAR) == FALSE){
	//	CloseHandle(m_Handle);
	//	return FALSE;
	//}


	//////////////////////////////////////////////////////////////////////////
	// 2007.06.28 by ycchoi
	//////////////////////////////////////////////////////////////////////////
	// [��������]
	// FirmWare DownLoad vs Etc ��� ����� ������� Option������ ���ؼ� ���� ��
	// 1. Firmware Dlownload ��
	//    --> Autonics ��õ Cable ���(DSR Flow Signal ���)
	// 2. Etc 
	//    --> �Ϲ����� Sirial Cable ��� ����(2,3,5���� �����ص� ��� ����)
	//
	// [��������]
	// 1. serial port���� write time out�� 10sec�� ���� �Ǿ� �ִ� ���� ���
	//		������ ���� 1sec �Ǵ� 10sec�� �����Ѵ�.
	// 2. firmware download�� 10 sec, etc ��� ����� 1sec�� ����
	//////////////////////////////////////////////////////////////////////////

	// 2006/08/12 EDIT	
//	//COMMTIMEOUTS CommTimeouts = { 0xFFFFFFFFL, 0, 1000, 0, 1000 };
//	COMMTIMEOUTS CommTimeouts = { 0xFFFFFFFFL, 0, 1000, 0, 10000 };

	COMMTIMEOUTS CommTimeouts = { 0xFFFFFFFFL, 0, 1000, 0, 10000 };
	if(bDsrFlow)	CommTimeouts.WriteTotalTimeoutConstant = 10000;	
	else			CommTimeouts.WriteTotalTimeoutConstant = 1000;

	if(SetCommTimeouts(m_Handle, &CommTimeouts) == FALSE){
		CloseHandle(m_Handle);
		return FALSE;
	}

	Dcb.DCBlength = sizeof(Dcb);
	if(GetCommState(m_Handle, &Dcb) == FALSE){
		CloseHandle(m_Handle);
		return FALSE;
	}

	//////////////////////////////////////////////////////////////////////////
	// 2007.06.28 by ycchoi
	//////////////////////////////////////////////////////////////////////////
	// ��� ��ſ��� DSR Flow�� On�ؼ� ��� �ϴ� �κ� ����
	//////////////////////////////////////////////////////////////////////////
	
/*	�����ҽ�
	Dcb.BaudRate = nRate;
	Dcb.ByteSize = nSize;
	Dcb.StopBits = nStop;
	Dcb.Parity	 = nParity;
	Dcb.fOutxCtsFlow = 1;
	Dcb.fOutxDsrFlow = 1;

	Dcb.fOutxCtsFlow	= 0;
	// 2006/08/12 EDIT
	//Dcb.fOutxDsrFlow	= 0;
	Dcb.fOutX			= 0;
	Dcb.fInX			= 0;
*/

	
//////////////////////////////////////////////////////////////////////////
// debug ���� ����(���簪 Ȯ��)	
/*
	CString sMsg;
	sMsg.Format("BCDLenght[%d]\n"
				"BaudRate[%d]\n"
				"fBinary[%d]\n"
				"fParity[%d]\n"
				"fOutxCtsFlow[%d]\n"
				"fOutxDsrFlow[%d]\n"
				"fDtrControl[%d]\n"
				"fDsrSensitivity[%d]\n"
				"fTXContinueOnXoff[%d]\n"
				"fOutX[%d]\n"
				"fInX[%d]\n"
				"fErrorChar[%d]\n"
				"fNull[%d]\n"
				"fRtsControl[%d]\n"
				"fAbortOnError[%d]\n"
				"fDummy2[%d]\n"
				"wReserved[%d]\n"
				"XonLim[%d]\n"
				"XoffLim[%d]\n"
				"ByteSize[%d]\n"
				"Parity[%d]\n"
				"StopBits[%d]\n"
				"XonChar[%d]\n"
				"XoffChar[%d]\n"
				"ErrorChar[%d]\n"
				"EofChar[%d]\n"
				"EvtChar[%d]\n"
				"wReserved1[%d]\n",
				Dcb.DCBlength,
				Dcb.BaudRate,
				Dcb.fBinary,
				Dcb.fParity,
				Dcb.fOutxCtsFlow,
				Dcb.fOutxDsrFlow,
				Dcb.fDtrControl,
				Dcb.fDsrSensitivity,
				Dcb.fTXContinueOnXoff,
				Dcb.fOutX,
				Dcb.fInX,
				Dcb.fErrorChar,
				Dcb.fNull,
				Dcb.fRtsControl,
				Dcb.fAbortOnError,
				Dcb.fDummy2,
				Dcb.wReserved,
				Dcb.XonLim,
				Dcb.XoffLim,
				Dcb.ByteSize,
				Dcb.Parity,
				Dcb.StopBits,
				Dcb.XonChar,
				Dcb.XoffChar,
				Dcb.ErrorChar,
				Dcb.EofChar,
				Dcb.EvtChar,
				Dcb.wReserved1);
	AfxMessageBox(sMsg);
*/
// Debug ���� ��
//////////////////////////////////////////////////////////////////////////

	Dcb.BaudRate = nRate;
	Dcb.ByteSize = nSize;
	Dcb.StopBits = nStop;
	Dcb.Parity	 = nParity;
	Dcb.fOutX	 = 0;
	Dcb.fInX	 = 0;

	//////////////////////////////////////////////////////////////////////////
	// 2007.06.28 by ycchoi
	//////////////////////////////////////////////////////////////////////////
	// FirmWare DownLoad vs Etc ��� ����� ������� Option������ ���ؼ� ���� ��
	// 1. Firmware Dlownload ��
	//    --> Autonics ��õ Cable ���(DSR Flow Signal ���)
	// 2. Etc 
	//    --> �Ϲ����� Sirial Cable ��� ����(2,3,5���� �����ص� ��� ����)
	//////////////////////////////////////////////////////////////////////////
	if(bDsrFlow)	Dcb.fOutxDsrFlow = 1;
	else			Dcb.fOutxDsrFlow = 0;

	if (SetCommState(m_Handle, &Dcb) == FALSE)
	{
		CloseHandle(m_Handle);
		DWORD err= GetLastError();
		return FALSE;
	}

//////////////////////////////////////////////////////////////////////////
// Debug ���� ����(���� �� Ȯ��)
/*
	Dcb.DCBlength = sizeof(Dcb);
	if(GetCommState(m_Handle, &Dcb) == FALSE){
		CloseHandle(m_Handle);
		return FALSE;
	}

		sMsg.Format("BCDLenght[%d]\n"
				"BaudRate[%d]\n"
				"fBinary[%d]\n"
				"fParity[%d]\n"
				"fOutxCtsFlow[%d]\n"
				"fOutxDsrFlow[%d]\n"
				"fDtrControl[%d]\n"
				"fDsrSensitivity[%d]\n"
				"fTXContinueOnXoff[%d]\n"
				"fOutX[%d]\n"
				"fInX[%d]\n"
				"fErrorChar[%d]\n"
				"fNull[%d]\n"
				"fRtsControl[%d]\n"
				"fAbortOnError[%d]\n"
				"fDummy2[%d]\n"
				"wReserved[%d]\n"
				"XonLim[%d]\n"
				"XoffLim[%d]\n"
				"ByteSize[%d]\n"
				"Parity[%d]\n"
				"StopBits[%d]\n"
				"XonChar[%d]\n"
				"XoffChar[%d]\n"
				"ErrorChar[%d]\n"
				"EofChar[%d]\n"
				"EvtChar[%d]\n"
				"wReserved1[%d]\n",
				Dcb.DCBlength,
				Dcb.BaudRate,
				Dcb.fBinary,
				Dcb.fParity,
				Dcb.fOutxCtsFlow,
				Dcb.fOutxDsrFlow,
				Dcb.fDtrControl,
				Dcb.fDsrSensitivity,
				Dcb.fTXContinueOnXoff,
				Dcb.fOutX,
				Dcb.fInX,
				Dcb.fErrorChar,
				Dcb.fNull,
				Dcb.fRtsControl,
				Dcb.fAbortOnError,
				Dcb.fDummy2,
				Dcb.wReserved,
				Dcb.XonLim,
				Dcb.XoffLim,
				Dcb.ByteSize,
				Dcb.Parity,
				Dcb.StopBits,
				Dcb.XonChar,
				Dcb.XoffChar,
				Dcb.ErrorChar,
				Dcb.EofChar,
				Dcb.EvtChar,
				Dcb.wReserved1);
	AfxMessageBox(sMsg);
*/	
// Debug ���� ��
//////////////////////////////////////////////////////////////////////////

	Receive232WinThread = ::AfxBeginThread((AFX_THREADPROC)Receive232Thread, LPVOID(this), THREAD_PRIORITY_NORMAL);

	if( Receive232WinThread == NULL ){
		CloseHandle(m_Handle);
	}

	char	buff[16];
	strcpy(buff,strPort.GetBuffer(128));
	
	m_PortNo= atoi(&buff[3]);



	return Receive232WinThread != NULL;
}

/*/////////////////////////////////////////////////////////////////////
FUNCTION	:	RS232C ��� CLOSE
METHOD NAME	:
PARAMETER	:
RETURN		:
/////////////////////////////////////////////////////////////////////*/
void CGPRS232c::Close()
{
	/*
	if (Receive232WinThread)
	{
		if (TerminateThread(Receive232WinThread->m_hThread, 0) == FALSE)
			return;

		delete Receive232WinThread;
		Receive232WinThread = NULL;

		if (SetCommMask(m_Handle, 0 ) == FALSE)
			return;
		
		if (EscapeCommFunction(m_Handle, CLRDTR ) == FALSE)
			return;
		
		if (PurgeComm(m_Handle, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR ) == FALSE)
			return;
		
		if (CloseHandle(m_Handle) == FALSE)
			return;
	}
	*/

	if (Receive232WinThread)
	{
		SetCommMask(m_Handle, 0 );
		
		EscapeCommFunction(m_Handle, CLRDTR );
		
		PurgeComm(m_Handle, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR );
		
		CloseHandle(m_Handle);

		if (TerminateThread(Receive232WinThread->m_hThread, 0) == FALSE)
			return;

		delete Receive232WinThread;
		Receive232WinThread = NULL;
	}
}

/*/////////////////////////////////////////////////////////////////////
FUNCTION	:	������ ����
METHOD NAME	:
PARAMETER	:
RETURN		:
/////////////////////////////////////////////////////////////////////*/
DWORD CGPRS232c::Receive(LPVOID lpData)
{

#if _DEBUG
//	LogFile( (LPBYTE)lpData, m_RcvLen, FALSE );
#endif

	memcpy(lpData, m_Data, m_RcvLen);
	return m_RcvLen;
}

/*/////////////////////////////////////////////////////////////////////
FUNCTION	:	������ �۽�
METHOD NAME	:
PARAMETER	:
RETURN		:
/////////////////////////////////////////////////////////////////////*/
/*
BOOL CGPRS232c::Send(LPCVOID pBuff, DWORD nLength)
{
	DWORD dLength;

#if _DEBUG
//	LogFile( (LPBYTE)lpData, nLength, TRUE );
#endif
	return WriteFile(m_Handle, pBuff, nLength, &dLength, &m_ioWrite);
}*/
/*
Another major topic affecting the behavior of read and write operations is time-outs. 
Time-outs affect read and write operations in the following way. If an operation takes 
longer than the computed time-out period, the operation is completed. There is no error 
code that is returned by ReadFile, WriteFile, GetOverlappedResult, or WaitForSingleObject.
All indicators used to monitor the operation indicate that it completed successfully. 
The only way to tell that the operation timed out is that the number of bytes actually 
transferred are fewer than the number of bytes requested. So, if ReadFile returns TRUE, 
but fewer bytes were read than were requested, the operation timed out. 
If an overlapped write operation times out, the overlapped event handle is signaled and WaitForSingleObject 
returns WAIT_OBJECT_O. GetOverlappedResult returns TRUE, but dwBytesTransferred contains 
the number of bytes that were transferred before the time-out. The following code demonstrates 
how to handle this in an overlapped write operation:
*/
// J.S.LIM 2004/06/07 : Copied form MSDN

BOOL CGPRS232c::Send(LPCVOID pBuff, DWORD nToWrite)
{
	DWORD dwWritten;
	DWORD dwRes;
	BOOL  fRes;
	char * buff;
	DWORD savecount = 0;
	int rtycount = 0;

	// Create this write operation's OVERLAPPED structure hEvent.
// 2007.10.03 backup by ycchoi
//	m_ioWrite.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	// 2007.10.03 by ycchoi
	// Create()���� �̹� Event Handle�� ���������Ƿ� ������ �ٽ�
	// Handle�� ��������� ����, Handle ������ �����ʾ��� ��쿡��
	// �ٽ� �����ϵ��� ����
//	if(m_ioWrite.hEvent == NULL)
//		m_ioWrite.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	
//	if (m_ioWrite.hEvent == NULL)
	  // Error creating overlapped event handle.
//	  return FALSE;

	int Endflag = 0;
	dwWritten = 0;
	buff = (char *)pBuff;
	while(Endflag == 0)
	{
	   // Issue write
	   if (!WriteFile(m_Handle, &buff[savecount], nToWrite-savecount, &dwWritten, &m_ioWrite))
	   {
		  if (GetLastError() != ERROR_IO_PENDING)
		  { 
			 // WriteFile failed, but it isn't delayed. Report error.
			 fRes = FALSE;
		  }
		  else 
		  {
			// Write is pending.
			// 2007.09.20 by ycchoi
			// firmware download�� �߸��� port�� ���� �� ���,
			// ��� ��õ��ϰ� �Ǿ�, ���α׷��� ���� �� ���� ���¸� �����ϴ� ������ �ذ� �ϱ� ���ؼ�
			// ��� �ð��� 200ms * 6 = 1.2s �� �ǵ��� �Ѵ�.
			dwRes = WaitForSingleObject(m_ioWrite.hEvent, 1000);
//			dwRes = WaitForSingleObject(m_ioWrite.hEvent, INFINITE);
			switch(dwRes)
			{
				// Overlapped event has been signaled. 
				case WAIT_OBJECT_0:
					
					// 2006/08/12 EDIT
					// if (!GetOverlappedResult(m_Handle, &m_ioWrite, &dwWritten, FALSE))
					if (!GetOverlappedResult(m_Handle, &m_ioWrite, &dwWritten, TRUE))
					{
						   fRes = FALSE;
					}
					else
					{
						savecount += dwWritten;
						if (savecount != nToWrite) 
						{
							// The write operation timed out. I now need to 
							// decide if I want to abort or retry. If I retry, 
							// I need to send only the bytes that weren't sent. 
							// If I want to abort, I would just set fRes to 
							// FALSE and return.
							//						 fRes = FALSE;
							if(rtycount++ < 6){
								continue;
							}
						}

						// Write operation completed successfully.
						if(rtycount < 6)	fRes = TRUE;
						else				fRes = FALSE;

						Endflag = 1;
					}
					break;

				default:
					// An error has occurred in WaitForSingleObject. This usually 
					// indicates a problem with the overlapped event handle.
					fRes = FALSE;
					Endflag = 1;
					break;
			} // siwtch(dwRes)
		  } // else
	   }
	   else 
	   {
		  // WriteFile completed immediately.
		  if (dwWritten != nToWrite) {
			// The write operation timed out. I now need to 
			// decide if I want to abort or retry. If I retry, 
			// I need to send only the bytes that weren't sent. 
			// If I want to abort, then I would just set fRes to 
			// FALSE and return.
			  fRes = FALSE;
		  }
		  else{
			  fRes = TRUE;
		  }
		  Endflag = 1;
	   }
	} // while

//	CloseHandle(m_ioWrite.hEvent);
	//050621
	m_ioWrite.hEvent= NULL;
	return fRes;
}
//
/*/////////////////////////////////////////////////////////////////////
FUNCTION	:	RS232C ��� ���� üũ
METHOD NAME	:
PARAMETER	:
RETURN		:
/////////////////////////////////////////////////////////////////////*/
BOOL CGPRS232c::IsOpen()
{
	return Receive232WinThread != NULL;
}

/*/////////////////////////////////////////////////////////////////////
FUNCTION	:	�����͸� �����ϴ� Thread
METHOD NAME	:
PARAMETER	:
RETURN		:
/////////////////////////////////////////////////////////////////////*/
UINT Receive232Thread(LPVOID wndParam)
{
	CGPRS232c*	WinRs232c = (CGPRS232c*)wndParam;

	DWORD	nEvtMask = 0;

	while(TRUE){

		WaitCommEvent(WinRs232c->m_Handle, &nEvtMask, NULL);

		if((nEvtMask & EV_RXCHAR) == EV_RXCHAR){

			do{
				COMSTAT	ComStat;
				DWORD	nError;
				if(ClearCommError(WinRs232c->m_Handle, &nError, &ComStat)){

					// start add 2009.01.17 by ycchoi
					// ��� Error Code�� Ȯ������ �ʰ� COMSTAT�� ������ Ȱ���ϴ� ���� ,
					// ���� �߻����� ����Ÿ�� ó���ϰ� �ȴ�. �̷� ���, ������ ������ ����Ÿ�� 
					// ��� ó���ϰ� �Ǿ ���� ������ ó�� �Ǿ��� ��쿡�� �ٷ� ���� ���� ���ϴ� ������ �ִ�.
					// �׷���, ���� �ڵ带 Ȯ���ϰ� ����(0x0000)�� �ƴ� ���� ����Ÿ�� ó�� ���� �ʵ��� �Ѵ�.
					if(nError) break;
					// end   add 2009.01.17 by ycchoi

					DWORD	nLength = min(WinRs232c->m_nRcvMaxLen, ComStat.cbInQue);
					if(ReadFile(WinRs232c->m_Handle, WinRs232c->m_Data, nLength, &WinRs232c->m_RcvLen, &WinRs232c->m_ioRead)){	
						
//#ifdef _DEBUG
//						{
//							CString szDebug, szTmp;
//							szDebug.Format("[TH(ECode:%04x)::Rx:%d] << ", nError, WinRs232c->m_RcvLen);
//							for(int xx=0; xx<(int)WinRs232c->m_RcvLen; xx++)
//							{
//								szTmp.Format("<%02x>", WinRs232c->m_Data[xx]);
//								szDebug += szTmp;
//							}
//							szDebug += "\n";
//							
//							OutputDebugString(szDebug);
//						}
//#endif

						if(WinRs232c->m_RcvLen && WinRs232c->m_pParent){
							WinRs232c->m_pParent->SendMessage(GP_RS232C_RECEIVE, WinRs232c->m_PortNo, LPARAM(WinRs232c));
							//WinRs232c->m_pParent->PostMessage(GP_RS232C_RECEIVE, 0, LPARAM(WinRs232c));
						}
					}
				}
			}while(WinRs232c->m_RcvLen);
		}
	}

	return TRUE;
}
