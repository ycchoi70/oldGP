/*	$ JBOSN : hal_time.c, v 0.1 10-12-03 15:12 $	*/

/*
 * Copyright (C) 2003	iBOSN systems
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are not permitted completely.
 *
 */

/*
 * Module Name: hal_time.c
 *
 * Purpose: HAL basic initialization of time related hardware
 *
 */
#ifdef	WIN32
#define	__irq
#endif

#include "define.h"
#include "hal_time.h"
#include "s2440.h"

//#define FROM_BCD(n)     ((((n) >> 4) * 10) + ((n) & 0xf))
//#define TO_BCD(n)       ((((n) / 10) << 4) | ((n) % 10))
//#define RTC_YEAR_DATUM  1980

/*
  Name: HAL_ClockInit()
  Copyright: 
  Author: jung boung oh
  Date: 10-12-03 15:02
  Description: initialize hardware specific clock controller.
*/
//#define _ISR_STARTADDRESS	0x30000000
//#define pISR_TIMER4    (*(unsigned *)(_ISR_STARTADDRESS+0x58))

//void HAL_ClockInit( void )
//{
//    volatile PWM_REG    *pPWMRegs = (PWM_REG *)PWM_BASE;
//    volatile INT_REG    *pIntRegs = (INT_REG *)INT_BASE; 
//    unsigned      TCON;
//    //SYSTEMTIME st;


//    // Set prescaler 1 to 1 
//    pPWMRegs->rTCFG0 &= ~0x0000FF00;		//priscaler= 0
////    pPWMRegs->rTCFG0 = 0x0000FF00;

//    // Select MUX input 1/2
//    pPWMRegs->rTCFG1 &= ~(0xF << 16);
//	//1/16
//    pPWMRegs->rTCFG1 = 0x3 << 16;

//    // Set timer register
//    pPWMRegs->rTCNTB4 = HAL_CLOCK_TICK;
////    pPWMRegs->rTCNTB4 = 0xffff;

//    // Start timer in auto reload mode
//    TCON = pPWMRegs->rTCON & ~(0x0F << 20);
//    pPWMRegs->rTCON = TCON | (0x2 << 20);
//    pPWMRegs->rTCON = TCON | (0x5 << 20);


//    // unmask for timer4
//    pIntRegs->rINTMSK &= ~(1 << INTSRC_TIMER4);

//    return;
//}

void HAL_ClockInit( void )
{
    volatile WATCH_REG    *pWDTRegs = (WATCH_REG *)WATCH_BASE;
//    volatile INT_REG    *pIntRegs = (INT_REG *)INT_BASE;

	                  //Pre= 0    WDT EN      CLK SEL    INT EI     RST DI
	pWDTRegs->rWTCON= (250 << 8) | (1 << 5) | (1 << 3) | (1 << 2) | (0 << 0);		//250/32/83

	pWDTRegs->rWTDAT= 83;
}
