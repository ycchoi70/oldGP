///////////////////////////////////////////////////////////
//	Lan Driver
///////////////////////////////////////////////////////////

#include	<stdio.h>
#include	<string.h>

#include "define.h"
#include "s2440.h"
#include "w5100.h"
#include "socket.h"
#include "bios.h"

#ifdef	WIN32
#include    "Mts.h"
#include    "MtsCifp.h"
#include    "Mail.h"
#include	"Taskhed.h"
#endif


#define TX_RX_MAX_BUF_SIZE	1024

extern	void DModeSendMsg( char *ptr );

typedef struct{
   uint8 ip[4];                   // for setting SIP register
   uint8 gw[4];                   // for setting GAR register
   uint8 sn[4];                   // for setting SUBR register
   uint8 mac[6];				  // for setting SHAR register
   int	PortAddr;
}TCP_SET;

   uint8 tx_mem_conf = 0x55;          // for setting TMSR regsiter
   uint8 rx_mem_conf = 0x55;          // for setting RMSR regsiter
   
   TCP_SET	Set;
   TCP_SET w53Inf;
  
   uint8 serverip[4] = {192,168,111,100};              // "TCP SERVER" IP address for loopback_tcpc()

   int	_LanDrvMode;

/* Initialization & Interrupt request routine */


/**
 * "TCP SERVER" loopback program.
 */ 
void     loopback_tcps(SOCKET s, uint16 port, uint8* buf, uint8 mode)
{
   uint16 len;
   
   switch(getSn_SR(s))                // check SOCKET status
   {                                   // ------------
      case SOCK_ESTABLISHED:           // ESTABLISHED?
         if(getSn_IR(s) & Sn_IR_CON)   // check Sn_IR_CON bit
         {
            setSn_IR(s,Sn_IR_CON);     // clear Sn_IR_CON
         }
         if((len=getSn_RX_RSR(s)) > 0) // check the size of received data
         {
            len = recv(s,buf,len);     // recv
            if(len !=send(s,buf,len))  // send
            {
//               printf("%d : Send Fail.len=%d\r\n",s,len);
            }
         }
         break;
                                       // ---------------
   case SOCK_CLOSE_WAIT:               // PASSIVE CLOSED
         disconnect(s);                // disconnect 
         break;
                                       // --------------
   case SOCK_CLOSED:                   // CLOSED
      close(s);                        // close the SOCKET
      socket(s,Sn_MR_TCP,port,mode);   // open the SOCKET  
      break;
                                       // ------------------------------
   case SOCK_INIT:                     // The SOCKET opened with TCP mode
      listen(s);                       // listen to any connection request from "TCP CLIENT"
//      printf("%d : LOOPBACK_TCPS(%d) Started.\r\n",s,port);
      break;
   default:
      break;
   }
}

/**
 * "TCP CLIENT" loopback program.
 */ 
void     loopback_tcpc(SOCKET s, uint8* addr, uint16 port, uint8* buf, uint8 mode)
{
//   uint16 len;
   static uint16 any_port = 1000;
 	int	status= 0;
  
	while(status != 0x07){
	   switch(getSn_SR(s))                   // check SOCKET status
	   {                                      // ------------
	      case SOCK_ESTABLISHED:              // ESTABLISHED?
#ifdef	OLD
	         if(getSn_IR(s) & Sn_IR_CON)      // check Sn_IR_CON bit
	         {
	//            printf("%d : Connect OK\r\n",s);
	            setSn_IR(s,Sn_IR_CON);        // clear Sn_IR_CON
	         }
	         if((len=getSn_RX_RSR(s)) > 0)    // check the size of received data
	         {
	            len = recv(s,buf,len);        // recv
	            if(len !=send(s,buf,len))     // send
	            {
	//               printf("%d : Send Fail.len=%d\r\n",s,len);
	            }
	         }
#endif
			status |= 0x04;
	         break;
	                                          // ---------------
	   case SOCK_CLOSE_WAIT:                  // PASSIVE CLOSED
	         disconnect(s);                   // disconnect 
	         break;
	                                          // --------------
	   case SOCK_CLOSED:                      // CLOSED
	   	if((status & 0x01) == 0)
	   	{
	   		
	      close(s);                           // close the SOCKET
	      socket(s,Sn_MR_TCP,any_port++,mode);// open the SOCKET with TCP mode and any source port number
			status |= 0x01;
	   	}
	      break;
	                                          // ------------------------------
	   case SOCK_INIT:                        // The SOCKET opened with TCP mode
	   	if((status & 0x02) == 0)
	   	{
	      connect(s, addr, port);             // Try to connect to "TCP SERVER"
	//      printf("%d : LOOPBACK_TCPC(%d.%d.%d.%d:%d) Started.\r\n",s,addr[0],addr[1],addr[2],addr[3],port);
			status |= 0x02;
	   	}
	      break;
	   default:
	      break;
	   }
	}
}

/**
 * UDP loopback program.
 */ 
void     loopback_udp(SOCKET s, uint16 port, uint8* buf, uint8 mode)
{
   uint16 len;
   uint8 destip[4];
   uint16 destport;
   
   switch(getSn_SR(s))
   {
                                                         // -------------------------------
      case SOCK_UDP:                                     // 
         if((len=getSn_RX_RSR(s)) > 0)                   // check the size of received data
         {
            len = recvfrom(s,buf,len,destip,&destport);  // receive data from a destination
            if(len !=sendto(s,buf,len,destip,destport))  // send the data to the destination
            {
//               printf("%d : Sendto Fail.len=%d,",s,len);
//               printf("%d.%d.%d.%d(%d)\r\n",destip[0],destip[1],destip[2],destip[3],destport);
            }
         }
         break;
                                                         // -----------------
      case SOCK_CLOSED:                                  // CLOSED
         close(s);                                       // close the SOCKET
         socket(s,Sn_MR_UDP,port,mode);                  // open the SOCKET with UDP mode
         break;
      default:
         break;
   }
}

/**
 * "TCP SERVER" loopback program.
 */ 
int     tcps_Open(SOCKET s, uint16 port)
{
	int	status= 0;

	TimerStart(1,100);	//1s Start
	while(status != 0x03){
		switch(getSn_SR(s))                // check SOCKET status
		{                                   // ------------
		case SOCK_ESTABLISHED:           // ESTABLISHED?
			break;
								   // ---------------
		case SOCK_CLOSE_WAIT:               // PASSIVE CLOSED
			break;
								   // --------------
		case SOCK_CLOSED:                   // CLOSED
			close(s);                        // close the SOCKET
			socket(s,Sn_MR_TCP,port,0);   // open the SOCKET  
			status |= 0x01;
			break;
								   // ------------------------------
		case SOCK_INIT:                     // The SOCKET opened with TCP mode
			listen(s);                       // listen to any connection request from "TCP CLIENT"
			status |= 0x02;
			break;
			default:
			break;
		}
		if(time_flag[1] != 0){	break;	}	//Time Out
	}
	if(status != 0x03){	return(-1);	}
	return(0);
}

void	LanIntEnable(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
//	volatile IOP_REG	*pIOPRegs   = (IOP_REG *)IOP_BASE;

	pINTRegs->rSRCPND  = BIT_EINT1;
	if (pINTRegs->rINTPND & BIT_EINT1)
		pINTRegs->rINTPND = BIT_EINT1;
	pINTRegs->rINTMSK &= ~BIT_EINT1;
	
}

//uint8 	bIsRecData = 0;
uint16	lanRecCnt;
uint8	recBuff[0x2000];
int	W5100IntFlag;
uint8	ir_status;
uint8	ir_mask;
unsigned char	DefMacAddr[6]= {0x00,0x08,0xDC,0x00,111,200}; 
unsigned char	DefIpAddr[4]= {192,168,100,100}; 
unsigned char	DefGatewayAddr[4]= {192,168,100,1}; 
unsigned char	DefSubnetAddr[4]= {255,255,255,0}; 
uint8 DestDefIpAddr[4] = {192,168,100,101};
void	DefaultAddressSet(void)
{
	//MAC Addr
	memcpy(&Set.mac[0],DefMacAddr,6);
	//IP Addr
	memcpy(&Set.ip[0],DefIpAddr,4);
	//Subnet Addr
	memcpy(&Set.sn[0],DefSubnetAddr,4);
	//Gateway
	memcpy(&Set.gw[0],DefGatewayAddr,4);
	//Port
	Set.PortAddr= 9000;
}
	int	SocketNo;
int	W5100Open(void)
{
	int	ret= 0;

	SocketNo= 0;
	DefaultAddressSet();
	iinchip_init();							/* initiate W5300 */
	sysinit(tx_mem_conf,rx_mem_conf);	/* allocate internal TX/RX Memory of W5300 */
	setSHAR(Set.mac);                                      // set source hardware address
	/* configure network information */
	setGAR(Set.gw);                                     // set gateway IP address
	setSUBR(Set.sn);                                    // set subnet mask address
	setSIPR(Set.ip);                                    // set source IP address

	memset(&w53Inf,0,sizeof(w53Inf));
	/* verify network information */
	getSHAR(w53Inf.mac);                                      // get source hardware address 
	getGAR(w53Inf.gw);                                        // get gateway IP address      
	getSUBR(w53Inf.sn);                                       // get subnet mask address     
	getSIPR(w53Inf.ip);                                       // get source IP address       

	if(memcmp(w53Inf.mac,Set.mac,sizeof(Set.mac)) != 0){	ret= -1;	}
	if(memcmp(w53Inf.gw,Set.gw,sizeof(Set.mac)) != 0){	ret= -1;	}
	if(memcmp(w53Inf.sn,Set.sn,sizeof(Set.mac)) != 0){	ret= -1;	}
	if(memcmp(w53Inf.ip,Set.ip,sizeof(Set.mac)) != 0){	ret= -1;	}
	return(ret);
}
int	TcpOpen(void)
{
	return(tcps_Open(0,Set.PortAddr));	//Server Open
}
int	UdpOpen(void)
{
	int	ret;
	ret= socket(2,Sn_MR_UDP,Set.PortAddr,0);                  // open the SOCKET with UDP mode
	if(ret == 1){	return(0);		}						//OK
	return(-1);
}

int InitSocketServer(SOCKET s, uint16 port)
{
	if(socket(s, Sn_MR_TCP, port, 0) == 0)
		return 0;
	else
		listen(s);
	
	return 1;
}

void EthernetTest(uint8 *buf, uint16 len)
{
	int i;
	char buff[128];

	for(i = 0; i < len; i++){
//		buff[i]= buf[i];		
		sprintf(&buff[i*2],"%02x",buf[i]);
		//DModeSendMsg(buf);
		//DModeSendMsg("\r\n");
	}
	buff[i*2]= 0;
	DModeSendMsg(buff);
	DModeSendMsg("\r\n");
	//DModeSendMsg("Ethernet Test OK\r\n");

}

void ProcessTcpServer(SOCKET s)
{
	int len;
	unsigned char data_buf[TX_RX_MAX_BUF_SIZE];

	switch(getSn_SR(s))
	{
	case SOCK_ESTABLISHED:
		if((len = getSn_RX_RSR(s)) > 0)
		{
			if(len > TX_RX_MAX_BUF_SIZE) len = TX_RX_MAX_BUF_SIZE;

			len = recv(s, data_buf, len);

			send(s, data_buf, len);

			EthernetTest(data_buf, len);
		}
		break;
	case SOCK_CLOSE_WAIT:
		disconnect(s);
		break;
	case SOCK_CLOSED:
		InitSocketServer(s, Set.PortAddr);
		break;
	}
}
//////////////////////////////////////////////////
//	Sense Mode
//////////////////////////////////////////////////
int	GetStopArea(void);
void TcpServerTest(void)
{
//	int len, i;
	int len;
	unsigned char data_buf[TX_RX_MAX_BUF_SIZE]={0};
	SOCKET s=0;
//	char buff[30];
	int test_flag=0;

	W5100Open();

	InitSocketServer(s, Set.PortAddr);

//	for(i = 0; i < 9; i++){
//		buff[i]= data_buf[i];		
//	}

	DModeSendMsg("*** STCP Send Rec Start ***\r\n");
		
	while(strncmp("W5100Test",(char*)&data_buf[0],9)!=0)
	{
		switch(getSn_SR(s))
		{
		case SOCK_ESTABLISHED:
			if((len = getSn_RX_RSR(s)) > 0)
			{
				if(len > TX_RX_MAX_BUF_SIZE) len = TX_RX_MAX_BUF_SIZE;

				len = recv(s, data_buf, len);

				send(s, data_buf, len);

				EthernetTest(data_buf, len);
				if(strncmp("W5100Test",(char*)&data_buf[0],9)==0)
					test_flag=1;
			}
			break;
		case SOCK_CLOSE_WAIT:
			disconnect(s);
			break;
		case SOCK_CLOSED:
			InitSocketServer(s, Set.PortAddr);
			break;
		}
		if(GetStopArea() == 1){	break;	}	//stop
#ifdef	WIN32
		Delay(100);
#endif
	}

	if(test_flag == 1)
		DModeSendMsg("TCP OK\r\n");
	else
		DModeSendMsg("TCP NG\r\n");
	DModeSendMsg("*** STCP Send Rec End ***\r\n");
}

/************************************************************/
/* LAN Driver												*/
/************************************************************/
extern	int	SendOk;
uint8 send_data_buf[0x200];
int	LanDriverTsk(int iSendKind)
{
	int iResult;

	uint8 *imsi;
	
	uint16 port = 9000;	


	int	ret= NG;	

	W5100IntFlag= 3;
	W5100Open();
//	UdpOpen();

	memset(send_data_buf, 0x00, sizeof(send_data_buf));

	LanIntEnable();
	IINCHIP_WRITE(Sn_IR(0), (uint8)0x1f);
	setIMR(0x0f);
#ifndef	WIN32
	if(TcpOpen() == NG){	return(ret);	}
#endif	
			W5100IntFlag= 0;
			SendOk= 0;
			

			if(iSendKind == 0) // �̴��� request
			{
				imsi = (unsigned char*)"Ethernet"; 
				memcpy(send_data_buf, imsi, 8);	
				loopback_tcpc(1, DestDefIpAddr, port, send_data_buf,1);
				iResult = send(1, send_data_buf, 8);

			}
			else if (iSendKind == 1) // USB request
			{
				imsi = (unsigned char*)"USB"; 
				memcpy(send_data_buf, imsi, 3);	
				loopback_tcpc(1, DestDefIpAddr, port, send_data_buf,1);
				iResult = send(1, send_data_buf, 3);
			}
			else if (iSendKind == 2) // Time
			{
				imsi = (unsigned char*)"Time";
				memcpy(send_data_buf, imsi, 8);	
				loopback_tcpc(1, DestDefIpAddr, port, send_data_buf,1);
				iResult = send(1, send_data_buf, 8);
				
			}
			else if (iSendKind == 3) // MAC request
			{
				imsi = (unsigned char*)"MAC"; 
				memcpy(send_data_buf, imsi, 3);	
				loopback_tcpc(1, DestDefIpAddr, port, send_data_buf,1);
				iResult = send(1, send_data_buf, 3);
				
			}
			else if (iSendKind == 4) // MAC ack
			{
				imsi = (unsigned char*)recBuff; 
				memcpy(send_data_buf, imsi, 21);	
				//loopback_tcpc(1, DestDefIpAddr, port, send_data_buf,1);
				iResult = send(1, send_data_buf, 21);
				
			}
			else if (iSendKind == 5) // MAC nak
			{
				imsi = (unsigned char*)recBuff; 
				memcpy(send_data_buf, imsi, 8);	
				//loopback_tcpc(1, DestDefIpAddr, port, send_data_buf,1);
				iResult = send(1, send_data_buf, 8);
				
			}
			ret= WAIT;						
			
#ifdef	WIN32
		Delay(100);
#endif
	return(ret);
}

int	TCPTest(int iSendKind)
{
	return(LanDriverTsk(iSendKind));
}
extern	void iinchip_irq(void);

int	_LanInterruptProc(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rSRCPND  = BIT_EINT1;
	pINTRegs->rINTPND  = BIT_EINT1;

	iinchip_irq();

	pINTRegs->rSRCPND  = BIT_EINT1;
	if (pINTRegs->rINTPND & BIT_EINT1)
		pINTRegs->rINTPND = BIT_EINT1;

	return(0);
}
void	_LanInterruptHandler( void )
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_EINT1;
	_LanInterruptProc();
	pINTRegs->rINTMSK &= ~BIT_EINT1;
}
