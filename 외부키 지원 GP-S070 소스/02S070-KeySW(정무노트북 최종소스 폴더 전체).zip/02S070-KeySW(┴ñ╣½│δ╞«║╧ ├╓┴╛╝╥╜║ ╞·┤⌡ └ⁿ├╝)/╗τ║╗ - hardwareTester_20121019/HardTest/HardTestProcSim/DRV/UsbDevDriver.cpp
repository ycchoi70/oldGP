/****************************************************/
/*    FUNC   : USB Device Handler	                */
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 2009.11.07                           */
/*    Update :                                      */
/****************************************************/
#define	USBDEVDRIVER_PROC
#include <string.h>


//#include "doscomm.h"
//#include "glpdos.h"
//#include "doscomm.h"
#include "define.h"
#include "glplcd.h"
#include "commbuff.h"
#include "usbh.h"
#include "s2440.h"
#include "udc_2440.h"
//#include "pcmcia.h"
#include "rs232c.h"
#include "HardTest.h"
#include "bios.h"
#include "flash.h"
#include "nand.h"

#define	USB_SLAVE_DEV	0		//0:USER1,1:USER2,2:SYSTEM

//#define	UDC_LOG

UART_STRUCT	_Sci_UsbTbl;


#ifdef	UDC_LOG
int	UdcIntFlagidx;
int	UdcIntFlag[0x1000];
#endif

//#ifdef	USB_STRAGE
unsigned char	RespInquiry[36]={
   0x00,                        // Device class
   0x80,                        // RMB BYTE is set by inquiry data
   0x02,                        // ANSI SCSI 2
   0x00,                        // Data format = 0
   0x1F,                        // Additional length 27 byte
   0x00, 0x00, 0x00,
	'A','U','T','O','N','I','C','S',
	'U','S','B',' ','F','l','a','s',
	'h',' ','D','i','s','k',' ',' ',
	' ',' ',' ',' ',
};
unsigned char	Request_sens[18]={
	0,
};
unsigned char	Read_cap[8]={
	//Total Sector(4Byte), Byte/Sector(4Byte)
	0x00,0x00,0x10,0x00,0x00,0x00,0x02,0x00
};
//int	write_len= 0;
//int	write_reclen;

//#endif
char*	UsbTestCmd[]={
	USB_CMD_TEST,USB_CMD_SET_TIME,USB_CMD_SET_PARA,
};




void	SetSciUsbTbl(void)
{
	memset(&_Sci_UsbTbl,0,sizeof(_Sci_UsbTbl));
	_Sci_UsbTbl.ch= RS_USB;
	
}


void	UsbDevIntEnable(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
//    volatile IOP_REG    *pIOPRegs = (volatile IOP_REG*)IOP_BASE; 
#ifdef	WIN32
	return;
#endif

	pINTRegs->rSRCPND  = BIT_USBD;
	// S3C2410X Developer Notice (page 4) warns against writing a 1 to a 0 bit in the INTPND register.
	if (pINTRegs->rINTPND & BIT_USBD)
		pINTRegs->rINTPND = BIT_USBD;
	pINTRegs->rINTMSK &= ~BIT_USBD;
	
//	pIOPRegs->rEINTMASK &= ~(1<<USB_IRQ);
//	pIOPRegs->rEINTPEND  = (1<<USB_IRQ);		//
}

int	_UsbDevInterruptProc(void)
{
	int	ret;
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

//	pINTRegs->rINTMSK |= BIT_USBD;
//	pINTRegs->rSRCPND  = BIT_USBD;
//	pINTRegs->rINTPND  = BIT_USBD;

	ret= MS_USB_InterruptHandler();

	pINTRegs->rSRCPND  = BIT_USBD;
	if (pINTRegs->rINTPND & BIT_USBD)
		pINTRegs->rINTPND = BIT_USBD;
//	pINTRegs->rINTMSK &= ~BIT_USBD;
	return(ret);
}
void	_UsbDevInterruptHandler( void )
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_USBD;

	_UsbDevInterruptProc();
	if( CheckUsbRecData() != 0 ){
		UsbDevHandler();
	}
	pINTRegs->rINTMSK &= ~BIT_USBD;
}
void UsbDevHandlerInit(void)
{
	SetSciUsbTbl();

	write_len= 0;
	udc_len= 0;
	write_reclen= 0;
	udc_sect= 0;
	udc_data_len= 0;


#ifdef	UDC_LOG
	UdcIntFlagidx= 0;
#endif
}
void	SetRtcTime(unsigned char* RecData)
{
	RTC_DATA	rtcDateTime;
	unsigned char	rtc_buf[10];

	rtcDateTime.year= RecData[0];
	rtcDateTime.mon= RecData[1];
	rtcDateTime.day= RecData[2];
	rtcDateTime.hour= RecData[3];
	rtcDateTime.min= RecData[4];
	rtcDateTime.sec= RecData[5];
	rtcDateTime.week= iNowWeek(&rtcDateTime);
	if(CheckDateTime(0,&rtcDateTime) == OK){
		rtc_buf[6] = (rtcDateTime.year / 10 << 4) | (rtcDateTime.year % 10);
		rtc_buf[5] = (rtcDateTime.mon / 10 << 4) | (rtcDateTime.mon % 10);
		rtc_buf[4] = (rtcDateTime.day / 10 << 4) | (rtcDateTime.day % 10);
		rtc_buf[3] = rtcDateTime.week;
		rtc_buf[2] = (rtcDateTime.hour / 10 << 4) | (rtcDateTime.hour % 10);
		rtc_buf[1] = (rtcDateTime.min / 10 << 4) | (rtcDateTime.min % 10);
		rtc_buf[0] = (rtcDateTime.sec / 10 << 4) | (rtcDateTime.sec % 10);
		RTCWrite(rtc_buf,0);
	}
}
void	SetMacAddr(unsigned char* RecData)
{
	FlashWriteSeq((char*)MAC_ADDR_AREA,(char*)RecData,0x200);
}
void	UsbDevHandler( void )
{
	int	i,j;
//#ifdef	USB_STRAGE

	//UDC Send Recieve
	udc_len= GetUsbRcvData(udcRBuff);

	if(write_len == 0){
		//Strage Check
		memcpy(udcWBuff,udcRBuff,8);
		udcWBuff[3]= 'S';
		memset(&udcWBuff[8],0,4);		//dCSWDataResidue
		udcWBuff[12]= 0;
		switch(udcRBuff[15]){
		case 0x12:						//INQUIRY
			SetWriteBuffer((unsigned char*)&udcWBuff[0],13);
			IoWrite((unsigned char*)&RespInquiry[0],36);
			break;
		case 0x23:						//Read Format Capacity
			SetWriteBuffer((unsigned char*)&udcWBuff[0],13);
			IoWrite((unsigned char*)&Request_sens[0],12);
			break;
		case 0x25:						// Read Capacity
			SetWriteBuffer((unsigned char*)&udcWBuff[0],13);
			IoWrite((unsigned char*)&Read_cap[0],8);
			break;
		case 0x28:						// READ(10)
			udc_sect= (udcRBuff[17] << 24)+ (udcRBuff[18] << 16)+ (udcRBuff[19] << 8)+ udcRBuff[20];
			udc_slen= ((udcRBuff[22] << 8)+ udcRBuff[23])*512;
//			ReadCard(USB_SLAVE_DEV,udc_sect,(unsigned char*)udcdataWBuff,udc_slen);
			udc_slen= 0x200;
			for(i= 0x1ff,j= 0; i >= 0; i--){
				udcdataWBuff[j++]= (i+ ' ') & 0x7f;
			}
			memcpy(&udcdataWBuff[udc_slen],udcWBuff,13);
			SetWriteBuffer((unsigned char*)&udcdataWBuff[EP1_PACKET_SIZE],udc_slen-EP1_PACKET_SIZE+13);
			IoWrite((unsigned char*)&udcdataWBuff[0],EP1_PACKET_SIZE);
			break;
		case 0x2a:						//WRITE(10)
			udc_sect= (udcRBuff[17] << 24)+ (udcRBuff[18] << 16)+ (udcRBuff[19] << 8)+ udcRBuff[20];
			udc_slen= ((udcRBuff[22] << 8)+ udcRBuff[23])*512;
			write_len= udc_slen;
			write_reclen= 0;
			if(write_len > 0x10000){	write_len= 0x10000;	}
			break;
		case 0x1a:
			SetWriteBuffer((unsigned char*)&udcWBuff[0],13);
			IoWrite((unsigned char*)&Read_cap[0],8);
			break;
		default:
			IoWrite((unsigned char*)&udcWBuff[0],13);
			break;
		}
	}else{
		memcpy(&udcdataWBuff[write_reclen],&udcRBuff[0],udc_len);
		write_reclen += udc_len;
		if(write_reclen >= write_len){
//			WriteCard(USB_SLAVE_DEV,udc_sect,udcdataWBuff,write_len);	//USER1
			udc_data_len= write_reclen;
			write_len= 0;
			IoWrite((unsigned char*)&udcWBuff[0],13);
			

		}
	}
//#else
//	int	i;
//
//	for(i= 0; i < 0x60; i++){
//		udcdataWBuff[i]= ' '+i;
//	}
//	IoWrite((char*)&udcdataWBuff[0],0x40);
//	IoWrite((char*)&udcdataWBuff[0x40],0x20);
	//UDC Send Recieve
//	udc_len= GetUsbRcvData(udcRBuff);
//	IoWrite((unsigned char*)&udcRBuff[0],udc_len);
//#endif
}
