
#define	NAND_BADMAP_PASS	"Autonics"

void	FlashEraze(char *addr, long count);
void	FlashWriteRandom(char *addr,char *data, long count);
void	FlashReadRandom(char *data,char *addr,long count);
void	FlashWriteSeq(char *addr,char *data, long count);
void	FlashReadSeq(char *data,char *addr,long count);

void	FlashRead_ECC(char *data,char *addr,long count);
void	NAND_Map_Check(void);
