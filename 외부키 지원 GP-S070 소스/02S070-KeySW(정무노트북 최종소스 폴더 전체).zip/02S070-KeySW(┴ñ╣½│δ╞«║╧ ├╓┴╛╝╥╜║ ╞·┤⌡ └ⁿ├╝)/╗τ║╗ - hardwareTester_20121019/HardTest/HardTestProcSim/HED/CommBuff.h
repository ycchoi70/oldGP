/*****************************************/
/*	Common Buffer Area                   */
/*****************************************/





	__EXT	RTC_DATA	SystemTime;	/* Now Time                     */

	__EXT	int		SioLFFlag;
	__EXT	int		SioEchoFlag;
	__EXT	int		SendRecMode;
	__EXT	int		CommMode;
	__EXT	int		CommCnt;
	__EXT	int		RecCommCnt;
	__EXT	int		CommKind;
	__EXT	int		SendCommCnt;

	__EXT	int		LangageFlag;
	__EXT	int		contrast;
    __EXT	int     lcdclk;
    __EXT	int     buzhighclk;
    __EXT	int     buzlowclk;

    __EXT	int     fpga_peried_clk;
    __EXT	int     fpga_width_clk;

