
#define	APL_PROG_START		0x30100000
#define	LCD_BUF_ADDR		0x31d00000
#define	DOWNLOAD_BUFF		0x31000000

#define	BOOT_PROG_AREA		0x0000000
//#define	TOUCH_CALIB_AREA	0x0002000
//#define	MAC_ADDR_AREA		0x0002200
#define	LOARDER_PROG_AREA	0x0010000

#define	IS_CONSOL()		IsGetSio1()
#define	GET_CONSOL()	GetSio1()


#ifdef	MAIN
	int DModeFlag;
	int			setspeed;
	/********************************************************/
	/*	�A�v���P?�V�����W�����v							*/
	/********************************************************/
	void	(*func)();
#else
	extern	int DModeFlag;
	extern	int			setspeed;
#endif


int	GetMessage( char *ptr );
void DubugMain( void );

