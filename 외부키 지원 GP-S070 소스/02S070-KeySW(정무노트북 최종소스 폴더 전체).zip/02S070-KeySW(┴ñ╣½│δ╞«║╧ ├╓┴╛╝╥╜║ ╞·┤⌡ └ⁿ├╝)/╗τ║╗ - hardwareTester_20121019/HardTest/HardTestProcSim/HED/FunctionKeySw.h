	//�ܺ�Ű �Է� ���� �߰� 
#define MAX_KEY_SW_NUM		10		//Switch Key Count

typedef struct{
	volatile unsigned *KeyOutDevice;
	unsigned short KeyOutData;
}KEY_PORT_TBL;

#ifdef	WIN32
	unsigned long	KeySwPortArea;
	KEY_PORT_TBL KeySwPortTbl[MAX_KEY_SW_NUM] = {
		{(volatile	unsigned *)&KeySwPortArea,0x0001},		//T-Comm0  PORT-B(B4)
		{(volatile	unsigned *)&KeySwPortArea,0x0002},		//T-Comm1  PORT-B(B5)
		{(volatile	unsigned *)&KeySwPortArea,0x0004},		//T-Comm2  PORT-B(B6)
		{(volatile	unsigned *)&KeySwPortArea,0x0008},		//T-Comm3  PORT-F(F2)
		{(volatile	unsigned *)&KeySwPortArea,0x0010},		//T-Comm4  PORT-F(F4)
		{(volatile	unsigned *)&KeySwPortArea,0x0020},		//T-Comm5  PORT-F(F3)
		{(volatile	unsigned *)&KeySwPortArea,0x0040},		//T-Comm6  PORT-G(G0)
		{(volatile	unsigned *)&KeySwPortArea,0x0080},		//T-Comm7  PORT-G(G1)
		{(volatile	unsigned *)&KeySwPortArea,0x0100},		//T-Comm8  PORT-G(G2)
		{(volatile	unsigned *)&KeySwPortArea,0x0200},		//T-Comm9  PORT-G(G3)
//		{(volatile	unsigned *)&KeySwPortArea,0x0400},		//T-Comm10 PORT-G(G4)
//		{(volatile	unsigned *)&KeySwPortArea,0x0800},		//T-Comm11 PORT-G(G5)
//		{(volatile	unsigned *)&KeySwPortArea,0x1000},		//T-Comm12 PORT-G(G6)
//		{(volatile	unsigned *)&KeySwPortArea,0x2000},		//T-Comm13 PORT-F(F8)
//		{(volatile	unsigned *)&KeySwPortArea,0x4000},		//T-Comm14 PORT-F(F7)
//		{(volatile	unsigned *)&KeySwPortArea,0x8000},		//T-Comm15 PORT-F(F6)
	};
#else
	KEY_PORT_TBL KeySwPortTbl[MAX_KEY_SW_NUM] = {
		{(volatile	unsigned *)0x1d2000c,0x0010},		//T-Comm0  PORT-B(B4)
		{(volatile	unsigned *)0x1d2000c,0x0020},		//T-Comm1  PORT-B(B5)
		{(volatile	unsigned *)0x1d2000c,0x0040},		//T-Comm2  PORT-B(B6)
		{(volatile	unsigned *)0x1d20038,0x0004},		//T-Comm3  PORT-F(F2)
		{(volatile	unsigned *)0x1d20038,0x0010},		//T-Comm4  PORT-F(F4)
		{(volatile	unsigned *)0x1d20038,0x0008},		//T-Comm5  PORT-F(F3)
		{(volatile	unsigned *)0x1d20044,0x0001},		//T-Comm6  PORT-G(G0)
		{(volatile	unsigned *)0x1d20044,0x0002},		//T-Comm7  PORT-G(G1)
		{(volatile	unsigned *)0x1d20044,0x0004},		//T-Comm8  PORT-G(G2)
		{(volatile	unsigned *)0x1d20044,0x0008},		//T-Comm9  PORT-G(G3)
//		{(volatile	unsigned *)0x1d20044,0x0010},		//T-Comm10 PORT-G(G4)
//		{(volatile	unsigned *)0x1d20044,0x0020},		//T-Comm11 PORT-G(G5)
//		{(volatile	unsigned *)0x1d20044,0x0040},		//T-Comm12 PORT-G(G6)
//		{(volatile	unsigned *)0x1d20038,0x0100},		//T-Comm13 PORT-F(F8)
//		{(volatile	unsigned *)0x1d20038,0x0080},		//T-Comm14 PORT-F(F7)
//		{(volatile	unsigned *)0x1d20038,0x0040},		//T-Comm15 PORT-F(F6)
	};
#endif