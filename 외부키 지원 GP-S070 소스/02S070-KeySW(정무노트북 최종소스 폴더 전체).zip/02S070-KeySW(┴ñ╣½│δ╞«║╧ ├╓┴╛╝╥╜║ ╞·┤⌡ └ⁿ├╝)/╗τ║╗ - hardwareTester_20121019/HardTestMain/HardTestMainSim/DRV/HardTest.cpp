
#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>

#define	HARDTEST_PROC
#include 	"types.h"
#include	"define.h"
#include	"glplcd.h"
#include	"CommBuff.h"
#include	"bios.h"
#include	"disp.h"
#include	"rs232c.h"
#include	"lload.h"
#include	"hardtest.h"
#include	"touch.h"
#include	"flash.h"
#include	"w5100driver.h"
#include	"usbh.h"
#include	"udc_2440.h"
#include	"selib.h"
#include	"udebtsk.h"
#include	"glpdos.h"
#include	"socket.h"

#ifdef	WIN32
#include    "Mts.h"
#include    "MtsCifp.h"
#include    "Mail.h"
#include	"Taskhed.h"
#endif

extern	void DModeSendMsg( char *ptr );
extern	void	_di(void);
extern	void	_ei(void);
/////////////////////////////////////////////////////////
int	gatoi(char *buff)
{
	char	c;
	int	ret;
	int flag;

	ret= 0;
	flag= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){
			break;
		}
		if((c >= '0') && (c <= '9')){
			ret= ret*10;
			ret+= c- '0';
		}else{
			if(c == '+'){
				continue;
			}
			if(c == '-'){
				flag= 1;
				continue;
			}
			break;
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}
int	Hex2nBin(char *buff,int cnt)
{
	int		i;
	int		ret;

	ret= 0;
	for(i= 0; i < cnt; i++){
		ret= ret << 4;
		if(buff[i] > '9'){	ret += (buff[i] - 'A') + 10;	}
		else{				ret += buff[i] - '0';			}
	}
	return(ret);
}
/////////////////////////////////////////////////////////
//	FPGA Test
/////////////////////////////////////////////////////////
void	FpgaIntEnable(void)
{
	volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
	volatile IOP_REG	*pIOPRegs   = (IOP_REG *)IOP_BASE;

	pINTRegs->rSRCPND  = BIT_EINT0;
	if (pINTRegs->rINTPND & BIT_EINT0)
		pINTRegs->rINTPND = BIT_EINT0;
	pINTRegs->rINTMSK &= ~BIT_EINT0;

	pIOPRegs->rEXTINT0= 0x2 << 0;			//Falling edge
}
int	_IoInterrupt(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_EINT0;
	pINTRegs->rSRCPND  = BIT_EINT0;
	pINTRegs->rINTPND  = BIT_EINT0;
	pINTRegs->rSRCPND  = BIT_EINT0;
	if (pINTRegs->rINTPND & BIT_EINT0)
		pINTRegs->rINTPND = BIT_EINT0;
	pINTRegs->rINTMSK &= ~BIT_EINT0;

	return(0);
}
/////////////////////////////////////////////////////////
void	Wait10ms(int cnt)
{
	TimerStart(1,cnt);
	while(1){
		if(time_flag[1] != 0){
			break;
		}
	}
}
void	UsbTest(void)
{
	int		i,ret;
	int	iKeyCodeX;
	int iKeyCodeY;
//	int	sUsbHostConnected;
//	char	buff[32];

	DModeSendMsg("*** USB Test Start(Host) ***\r\n");
	TextOut2(10,1,"********** USB Test **********");

	if(UsbHostDeviceOK == 0){
		DModeSendMsg("!!! Device Not Ready !!!\r\n");
		TextOut2(11,3,"!!! Device Not Ready !!!");
		TextOut2(30,10,"Next");
		RectAngle(30*16-20,10*32-10,34*16+20,11*32+10,T_WHITE,T_BLACK);
		while(1){
			if((ScanStartX > 30*16-20) && (ScanStartX < 34*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10)){
				ScanStartX= 0;
				ScanStartY= 0;
				ClearDisplay();
				NormBuzzer();
				break;								
			}
#ifdef	WIN32
			Delay(100);
#endif
		}
		return;
	}

	DModeSendMsg("USB Host Connect Wait(30s)\r\n");
	TextOut2(10,3,"USB Host Connect         Wait(30s)");
	TimerStart(0,3000);		//30s Start

//	sUsbHostConnected= UsbHostConnected;
//	while(1){
//		UsbHostDrv();
//		if(UsbHostDeviceOK == 1){ break;	}
//		if(time_flag[0] != 0){		break;	}
//		if(sUsbHostConnected != UsbHostConnected){
//			sUsbHostConnected= UsbHostConnected;
//			if(sUsbHostConnected == 1){
//				sprintf(buff,"Connect(%d)",UsbHostDeviceOK);
//				TextOut(10,28,buff);
//			}else{
//				TextOut(10,28,"Disconnect");
//			}
//		}
//#ifdef	WIN32
//		Delay(100);
//#endif
//	}
//	if(time_flag[0] != 0){
//		DModeSendMsg("USB Test Time Out\r\n");
//		TextOut2(35,3,"Time Out  ");
//	}else{
		DModeSendMsg("USB Connect OK\r\n");
		TextOut2(35,3,"OK        ");
		
		DModeSendMsg("USB Send Data\r\n");
		TextOut2(10,5,"Send");
		memset(UsbWriteBuff,0,sizeof(UsbWriteBuff));
		strcpy((char*)UsbWriteBuff,USB_CMD_TEST);
		for(i= 0; i < 16; i++){
			UsbWriteBuff[i+4]= '0'+i;
		}
		ret= UsbWriteSector(0,0x200,UsbWriteBuff);
		
		if(ret == 0){
			DModeSendMsg("USB Send OK\r\n");
			TextOut2(35,5,"OK");

			DModeSendMsg("USB Wait Response\r\n");
			TextOut2(10,7,"USB Response             Wait(15s)");		
			
			while(1){
				if(udc_data_len != 0){	break;	}
				if(time_flag[0] != 0){	break;	}
			}
			if(time_flag[0] != 0){
				DModeSendMsg("USB Test Time Out\r\n");
				TextOut2(35,7,"Time Out     ");
			}else{
				DModeSendMsg((char*)udcdataWBuff);
				DModeSendMsg("\r\n");

				if(strncmp("0123456789:;<=>?@ABC",(char*)&udcdataWBuff[0],20) == 0){
					TextOut2(35,7,"OK        ");
				}else{
					TextOut2(35,7,"Error       ");
				}
			}
		}else{
			DModeSendMsg("!!! USB Send Error !!!\r\n");
			TextOut2(35,5,"Error");
		}
//	}

	DModeSendMsg("*** USB Test End ***\r\n");

	RectAngle(23*16-20,10*32-10,27*16+20,11*32+10,T_WHITE,T_BLACK);
	TextOut2(23,10,"Next");

	while(1){
		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((ScanStartX > 23*16-20) && (ScanStartX < 27*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10) || (IS_CONSOL( ) != 0)){
			ScanStartX= 0;
			ScanStartY= 0;
			ClearDisplay();
			NormBuzzer();
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
}


char cReqTime[8];
char cGetTime[19];

//success 1, fail : 0
int CheckReceivedTimeValue(char *cTimedata)
{
	unsigned char cData, cData2;


	if(*cTimedata++ != 0x03) // command kinds
		return 0;
	
	if(*cTimedata++ != 0x03) //Read Holding Registers
		return 0;
	
	if(*cTimedata++ != 0x0C)
		return 0;
	
	cData = *cTimedata++;	// year1
	if(cData > 3)
	{
		return 0;
	}
	
	cData = *cTimedata++;	// year2
	if(cData > 9)
	{
		return 0;
	}
	
	cData = *cTimedata++;	// year3
	if(cData > 9)
	{
		return 0;
	}
	
	cData = *cTimedata++;	// year4
	if(cData > 9)
	{
		return 0;
	}
	
	
	cData = *cTimedata++;	// month1
	if(cData > 1)
	{
		return 0;
	}
	
	
	cData2 = *cTimedata++;	// month2
	if(cData2 > 9 || (cData == 1 && cData2 > 2))
	{
		return 0;
	}
	
	
	cData = *cTimedata++;	// day1
	if(cData > 3)
	{
		return 0;
	}
	
	
	cData2 = *cTimedata++;	// day2
	if(cData > 9 || (cData == 3 && cData2 > 1))
	{
		return 0;
	}	
	
	
	cData = *cTimedata++;	//hour1
	if(cData > 2)
	{
		return 0;
	}
	
	
	cData2 = *cTimedata++;	//hour2
	if(cData > 9 || (cData == 2 && cData2 > 4))
	{
		return 0;
	}		
	
	
	cData = *cTimedata++;	//min1
	if(cData > 6)
	{
		return 0;
	}
	
	
	cData2 = *cTimedata++;	//min2
	if(cData > 6 || (cData == 6 && cData2 != 0))
	{
		return 0;
	}	
	
	
	cData = *cTimedata++;	//sec1
	if(cData > 6)
	{
		return 0;
	}	
	
	
	cData2 = *cTimedata++;	//sec2
	if(cData > 6 || (cData == 6 && cData2 != 0))
	{
		return 0;
	}
	
	return 1;
	
}

void	SetTime(void)
{
	int i, iRecCnt;
	
//	volatile IOP_REG    *pIOPReg;
	
	ClearSio1Cnt();	

	
	//make modbus protocol for time request
	cReqTime[0] = 0x03;
	cReqTime[1] = 0x03;
	cReqTime[2] = 0x00;
	cReqTime[3] = 0x0c;
	cReqTime[4] = 0x00;
	cReqTime[5] = 0x07;
	cReqTime[6] = 0x00;
	cReqTime[7] = 0x00;
	
	//send data to pc
	for (i=0; i < sizeof(cReqTime); i++)
	{
		Sio1SendChar(cReqTime[i]);
	}	
	
	
	ClearSio1Cnt();
	iRecCnt = 0;
	TimerStart( 0, 500 ); // 5s wait	
	while(time_flag[0] == 0)
	{	
		iRecCnt = IsGetSio1();		
		
		if(iRecCnt >= sizeof(cGetTime))
		{
			for(i=0; i < iRecCnt; i++)
			{
				cGetTime[i] = GetSio1();
			}

			//protocol format check
			if(CheckReceivedTimeValue(cGetTime) != 1)
			{
				return;				
			}		
			

		//send to lp/gp
			cGetTime[0] = 0x02; //modbus change addr to lp/gp?
			send(0,(unsigned char*)cGetTime,sizeof(cGetTime));
			break;
		}	
	

#ifdef	WIN32
		Delay(100);
#endif
	}	
	

}

void	SetSlaveTime(void)
{
//	int	i;
	int	ret;
	int	sec;
	int	iKeyCodeX;
	int iKeyCodeY;
	char	buff[30];

	DModeSendMsg("*** SetTime Start ***\r\n");
	TextOut2(7,1,"********** Set Time start **********");

	if(UsbHostDeviceOK == 0){
		DModeSendMsg("!!! Device Not Ready !!!\r\n");
		TextOut2(11,3,"!!! Device Not Ready !!!");
		TextOut2(30,10,"Next");
		RectAngle(30*16-20,10*32-10,34*16+20,11*32+10,T_WHITE,T_BLACK);
		while(1){
			if((ScanStartX > 30*16-20) && (ScanStartX < 34*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10)){
				ScanStartX= 0;
				ScanStartY= 0;
				ClearDisplay();
				NormBuzzer();
				break;								
			}
#ifdef	WIN32
			Delay(100);
#endif
		}
		return;
	}

	TextOut2(16,10,"Send");
	TextOut2(30,10,"Next");
	RectAngle(16*16-20,10*32-10,20*16+20,11*32+10,T_WHITE,T_BLACK);
	RectAngle(30*16-20,10*32-10,34*16+20,11*32+10,T_WHITE,T_BLACK);
	TextOut2(17,5,"Date :");
	TextOut2(17,7,"Time :");
	sec= SystemTime.sec;
	sprintf(buff,"%4d/%2d/%2d",SystemTime.year+2000,SystemTime.mon,SystemTime.day);
	TextOut2(25,5,buff);
	sprintf(buff,"%2d:%2d:%2d",SystemTime.hour,SystemTime.min,SystemTime.sec);
	TextOut2(25,7,buff);

	while(1){	
		if(sec != SystemTime.sec){
			sec= SystemTime.sec;
			sprintf(buff,"%4d/%2d/%2d",SystemTime.year+2000,SystemTime.mon,SystemTime.day);
			TextOut2(25,5,buff);
			sprintf(buff,"%2d:%2d:%2d",SystemTime.hour,SystemTime.min,SystemTime.sec);
			TextOut2(25,7,buff);
		}

		ScanKey(&iKeyCodeX,&iKeyCodeY);
		if((ScanStartX > 16*16-20) && (ScanStartX < 20*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10) || IS_CONSOL( ) != 0){
			NormBuzzer();
			ScanStartX= 0;
			ScanStartY= 0;
			memset(UsbWriteBuff,0,sizeof(UsbWriteBuff));
			strcpy((char*)UsbWriteBuff,USB_CMD_SET_TIME);
			UsbWriteBuff[4]= SystemTime.year;
			UsbWriteBuff[5]= SystemTime.mon;
			UsbWriteBuff[6]= SystemTime.day;
			UsbWriteBuff[7]= SystemTime.hour;
			UsbWriteBuff[8]= SystemTime.min;
			UsbWriteBuff[9]= SystemTime.sec;
			ret= UsbWriteSector(0,0x200,UsbWriteBuff);

			if(ret != 0){
				DModeSendMsg("!!! USB Send Error !!!\r\n");
				TextOut2(15,12,"!!! USB Send Error !!!");
			}else{
				DModeSendMsg("!!! USB Send OK !!!\r\n");
				TextOut2(19,12,"USB Send OK");
			}
		}
		if((ScanStartX > 30*16-20) && (ScanStartX < 34*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10)){
			NormBuzzer();
			ScanStartX= 0;
			ScanStartY= 0;
			ClearDisplay();
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
	DModeSendMsg("+++++ SetTime End +++++\r\n");
}


int	SetSlaveParamProc(int SeqNo,unsigned char* MacAddr)
{
	int		ret;
	int		i;

	memset(UsbWriteBuff,0,sizeof(UsbWriteBuff));
	strcpy((char*)UsbWriteBuff,USB_CMD_SET_PARA);
	*(int*)&UsbWriteBuff[4]= SeqNo;
	for(i= 0; i < 6; i++){
		UsbWriteBuff[8+i]= MacAddr[i];
	}
	ret= UsbWriteSector(0,0x200,UsbWriteBuff);
	if(ret != 0){
		DModeSendMsg("!!! USB Send Error !!!\r\n");
		TextOut2(15,12,"!!! USB Send Error !!!");
	}
	return(ret);
}

void	SetSlaveParam(void)
{
	int		fp,fp1,i;
	int		SeqNo;
	int		Carry,ret;
	unsigned char MacNo[6];
	char	buff[64];
	char	temp[16];

	DModeSendMsg("*** SetSlaveParam Start ***\r\n");
	TextOut2(6,1,"******** Set SlaveParam start ********");
	if(UsbHostDeviceOK == 0){
		DModeSendMsg("!!! Device Not Ready !!!\r\n");
		TextOut2(11,3,"!!! Device Not Ready !!!");
		TextOut2(30,10,"Next");
		RectAngle(30*16-20,10*32-10,34*16+20,11*32+10,T_WHITE,T_BLACK);
		while(1){
			if((ScanStartX > 30*16-20) && (ScanStartX < 34*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10)){
				NormBuzzer();
				ScanStartX= 0;
				ScanStartY= 0;
				ClearDisplay();
				break;								
			}
#ifdef	WIN32
			Delay(100);
#endif
		}
		return;
	}

	TextOut2(16,10,"Send");
	TextOut2(30,10,"Next");
	RectAngle(16*16-20,10*32-10,20*16+20,11*32+10,T_WHITE,T_BLACK);
	RectAngle(30*16-20,10*32-10,34*16+20,11*32+10,T_WHITE,T_BLACK);

		fp = Fs_open("B:\\ST_PARAM.TXT",O_RDWR,S_IREAD);
		if(fp < 0){
			fp = Fs_open("B:\\ST_PARAM.TXT",O_CREAT,S_IWRITE);
			if(fp < 0){
				DModeSendMsg("!!! File Create Error !!!\r\n");
				TextOut2(11,3,"!!! File Create Error !!!");
				ClearDisplay();
				return;
			}
			sprintf(buff,"%08d,%02X.%02X.%02X.%02X.%02X.%02X\r\n",1,0,0,0,0,0,1);
			Fs_write(fp,buff,strlen(buff));
			Fs_close(fp);
			fp = Fs_open("B:\\ST_PARAM.TXT",O_RDWR,S_IREAD);
			if(fp < 0){
				DModeSendMsg("!!! File Create Error !!!\r\n");
				TextOut2(11,3,"!!! File Create Error !!!");
				ClearDisplay();
				return;
			}
		}

		Fs_read(fp,buff,28);
		
		memcpy(temp,buff,8);
		temp[8]= 0;
		SeqNo= gatoi(temp);
		for(i= 0; i < 6; i++){
			MacNo[5-i]= Hex2nBin(&buff[i*3+9],2);
		}

		TextOut2(17,5,"SEQ No. :");
		TextOut2(10,7,"MAC Address :");
		sprintf(buff,"%08d",SeqNo);
		TextOut2(27,5,buff);
		sprintf(buff,"%02X:%02X:%02X:%02X:%02X:%02X",MacNo[5],MacNo[4],MacNo[3],MacNo[2],MacNo[1],MacNo[0]);
		TextOut2(24,7,buff);

	while(1){

		if((ScanStartX > 16*16-20) && (ScanStartX < 20*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10) || IS_CONSOL( ) != 0)
		{
			NormBuzzer();
			ScanStartX= 0;
			ScanStartY= 0;

			ret= SetSlaveParamProc(SeqNo,MacNo);

			if(ret == 0){
				fp1 = Fs_open("B:\\LOG.TXT",O_APPEND,S_IWRITE);
				if(fp1 < 0){
					fp1 = Fs_open("B:\\LOG.TXT",O_CREAT,S_IWRITE);
					if(fp1 < 0){
						DModeSendMsg("!!! File Create Error !!!\r\n");
						TextOut2(11,3,"!!! File Create Error !!!");
						ClearDisplay();
						return;
					}
				}
				//Log Write
				Fs_seek (fp1, 0, FS_SEEK_END);
				sprintf(buff,"%08d,%02X.%02X.%02X.%02X.%02X.%02X,%04d/%02d/%02d %02d:%02d:%02d\r\n",
					SeqNo,MacNo[5],MacNo[4],MacNo[3],MacNo[2],MacNo[1],MacNo[0],
					SystemTime.year+2000,SystemTime.mon,SystemTime.day,
					SystemTime.hour,SystemTime.min,SystemTime.sec);
				Fs_write(fp1,buff,strlen(buff));
				Fs_close(fp1);

				//Sequence No
				SeqNo++;
				Carry= 1;
				for(i= 0; i < 6; i++){
					MacNo[i] += Carry;
					if(MacNo[i] > 0){	break;	}
				}

				Fs_seek (fp, 0, FS_SEEK_SET);
				sprintf(buff,"%08d,%02X.%02X.%02X.%02X.%02X.%02X\r\n",
					SeqNo,MacNo[5],MacNo[4],MacNo[3],MacNo[2],MacNo[1],MacNo[0]);
				Fs_write(fp,buff,strlen(buff));
				Fs_close(fp);
			}
			break;
		}
		if((ScanStartX > 30*16-20) && (ScanStartX < 34*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10)){
			NormBuzzer();
			ScanStartX= 0;
			ScanStartY= 0;
			ClearDisplay();
			break;								
		}
	}
	DModeSendMsg("*** SetSlaveParam End ***\r\n");
}


int CheckReceivedMacValue(char * pcData)
{
	return 1;
}

char cRequestMac[8];
char cGetMac[15];
extern uint16	lanRecCnt;
extern uint8	recBuff[0x2000];
unsigned char cMacDataACK[21];
void SetMacAddrAndSerialNum(void)
{
	int i;
	int iRecCnt;
	
	//1. request to pc
		//1-1 make request mac protocol to pc 
		cRequestMac[0] = 0x03; // addr for pc
		cRequestMac[1] = 0x03; // Read Holding Registers
		cRequestMac[2] = 0x00; // addr for mac command1
		cRequestMac[3] = 0x01; // addr for mac command2
		cRequestMac[4] = 0x00; // read byte1 
		cRequestMac[5] = 0x05; // read byte2  (mac = 6byte, serial = 4byte)
		cRequestMac[6] = 0x00; // crc1
		cRequestMac[7] = 0x00; // crc2
		
		//send data to pc
		for (i=0; i < sizeof(cRequestMac); i++)
		{
			Sio1SendChar(cRequestMac[i]);
		}
		
		
		ClearSio1Cnt();
		TimerStart( 0, 500 ); // 5s wait			
		while(time_flag[0] == 0)
		{
			iRecCnt = IsGetSio1();
			
			
			//2. get mac/serial num
			//2-1 make gotten mac protocol from pc
			if(iRecCnt >= sizeof(cGetMac))
			{
				
				for(i=0; i < iRecCnt; i++)			
				{
					cGetMac[i] = GetSio1();
				}
				
				//protocol format check
				if(CheckReceivedMacValue(cGetMac) != 1)
				{
					return;				
				}				
	
				//3. send mac. serial num to lp/gp 
				cGetMac[0] = 0x02; //modbus change addr to lp/gp?
				send(0,(unsigned char*)cGetMac,sizeof(cGetMac));
				break;
			}
#ifdef	WIN32
		Delay(100);
#endif
		}
		
		
		//4. ack from lp/gp				
		memset(recBuff, 0x00, sizeof(recBuff));
		lanRecCnt = 0;
		//TimerStart( 0, 60000 ); // 1min wait
		//while(time_flag[0] == 0)		
		while(1)
		{
			if(lanRecCnt > 0)
			{
			
				recBuff[0] = 0x03;
				
				//send data to pc
				for (i=0; i < 21; i++)
				{
					Sio1SendChar(recBuff[i]);
				}
				
				break;				
								
			}		

		}
		
		/*
		//send time out nak 
		if(time_flag[0] == 1)
		{
		
			cMacDataACK[0] = 0x02;
			cMacDataACK[1] = 0x10;
			cMacDataACK[2] = 0x00;
			cMacDataACK[3] = 0x02;
			cMacDataACK[4] = 0x00;
			cMacDataACK[5] = 0x06;
			cMacDataACK[6] = 0x12;
			cMacDataACK[7] = 0x00;										
			cMacDataACK[8] = 0x15;										
			memset(&cMacDataACK[9], 0x00, 10);
			
			
			for (i=0; i < sizeof(cMacDataACK); i++)
			{
				Sio1SendChar(cMacDataACK[i]);
			}	
					
			
		}
		*/

	
}


extern	int	W5100Test(void);
extern void LanDriverInit(void);

void	TCPTest(void)
{
	W5100Test();
	
	/*kwon
	DModeSendMsg("*** TCP Test Start ***\r\n");
	TextOut2(6,1,"******** TCP Test start ********");
	TextOut2(16,10,"Send");
	TextOut2(30,10,"Next");
	RectAngle(16*16-20,10*32-10,20*16+20,11*32+10,T_WHITE,T_BLACK);
	RectAngle(30*16-20,10*32-10,34*16+20,11*32+10,T_WHITE,T_BLACK);

	while(1){

		if((ScanStartX > 16*16-20) && (ScanStartX < 20*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10) || IS_CONSOL( ) != 0)
		{
			NormBuzzer();
			ScanStartX= 0;
			ScanStartY= 0;
			W5100Test();
			break;
		}
		if((ScanStartX > 30*16-20) && (ScanStartX < 34*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10)){
			NormBuzzer();
			ScanStartX= 0;
			ScanStartY= 0;
			ClearDisplay();
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}
	*/
}
int	GetMaxDay(int year,int mon);
void	SetTimeOpe(void)
{
	int y,m,d,hh,mm,ss;
	int	work;
	RTC_DATA	rtcDateTime;
	unsigned char	rtc_buf[10];
	char	buff[64+2];

	TextOut2(6,1,"******** Time Setting ********");
	TextOut2(16,10,"Set");
	TextOut2(30,10,"End");
	RectAngle(16*16-20,10*32-10,20*16+20,11*32+10,T_WHITE,T_BLACK);
	RectAngle(30*16-20,10*32-10,34*16+20,11*32+10,T_WHITE,T_BLACK);

	y= SystemTime.year+2000;
	m= SystemTime.mon;
	d= SystemTime.day;
	hh= SystemTime.hour;
	mm= SystemTime.min;
	ss= SystemTime.sec;
	sprintf(buff,"%4d/%2d/%2d %2d:%2d:%2d",y,m,d,hh,mm,ss);
	TextOut2(16,4,buff);

	while(1){
		//UP
		if((ScanStartX > 16*16) && (ScanStartX < 35*16) && (ScanStartY > 3*32) && (ScanStartY < 3*32+32) || IS_CONSOL( ) != 0)
		{
			NormBuzzer();
			if(ScanStartX < (16+5)*16){		y++;	}
			else if(ScanStartX < (16+8)*16){
				m++;
				if(m > 12){	m= 1;	}
			}else if(ScanStartX < (16+11)*16){
				work= GetMaxDay(y,m);
				d++;
				if(d > work){
					d= 1;
				}
			}else if(ScanStartX < (16+14)*16){
				hh++;	if(hh > 59){	hh= 0;	}
			}else if(ScanStartX < (16+17)*16){
				mm++;	if(mm > 59){	mm= 0;	}
			}else{
				ss++;	if(ss > 59){	ss= 0;	}
			}
			sprintf(buff,"%4d/%2d/%2d %2d:%2d:%2d",y,m,d,hh,mm,ss);
			TextOut2(16,4,buff);
			ScanStartX= 0;
			ScanStartY= 0;
		}
		//DOWN
		if((ScanStartX > 16*16) && (ScanStartX < 35*16) && (ScanStartY > 5*32) && (ScanStartY < 5*32+32) || IS_CONSOL( ) != 0)
		{
			NormBuzzer();
			if(ScanStartX < (16+5)*16){		y--;	}
			else if(ScanStartX < (16+8)*16){
				m--;
				if(m < 1){	m= 12;	}
			}else if(ScanStartX < (16+11)*16){
				work= GetMaxDay(y,m);
				d--;
				if(d < 1){
					d= work;
				}
			}else if(ScanStartX < (16+14)*16){
				hh--;	if(hh < 0){	hh= 59;	}
			}else if(ScanStartX < (16+17)*16){
				mm--;	if(mm < 0){	mm= 59;	}
			}else{
				ss--;	if(ss < 0){	ss= 59;	}
			}
			sprintf(buff,"%4d/%2d/%2d %2d:%2d:%2d",y,m,d,hh,mm,ss);
			TextOut2(16,4,buff);
			ScanStartX= 0;
			ScanStartY= 0;
		}
		//Set
		if((ScanStartX > 16*16-20) && (ScanStartX < 20*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10) || IS_CONSOL( ) != 0)
		{
			NormBuzzer();
			ScanStartX= 0;
			ScanStartY= 0;
			rtcDateTime.year= y-2000;
			rtcDateTime.mon= m;
			rtcDateTime.day= d;
			rtcDateTime.hour= hh;
			rtcDateTime.min= mm;
			rtcDateTime.sec= ss;
			rtcDateTime.week= iNowWeek(&rtcDateTime);
			if(CheckDateTime(0,&rtcDateTime) == OK){
				rtc_buf[6] = (rtcDateTime.year / 10 << 4) | (rtcDateTime.year % 10);
				rtc_buf[5] = (rtcDateTime.mon / 10 << 4) | (rtcDateTime.mon % 10);
				rtc_buf[4] = (rtcDateTime.day / 10 << 4) | (rtcDateTime.day % 10);
				rtc_buf[3] = rtcDateTime.week;
				rtc_buf[2] = (rtcDateTime.hour / 10 << 4) | (rtcDateTime.hour % 10);
				rtc_buf[1] = (rtcDateTime.min / 10 << 4) | (rtcDateTime.min % 10);
				rtc_buf[0] = (rtcDateTime.sec / 10 << 4) | (rtcDateTime.sec % 10);
				RTCWrite(rtc_buf,0);
			}
			break;
		}
		//Cancel
		if((ScanStartX > 30*16-20) && (ScanStartX < 34*16+20) && (ScanStartY > 10*32-10) && (ScanStartY < 11*32+10)){
			NormBuzzer();
			ScanStartX= 0;
			ScanStartY= 0;
			ClearDisplay();
			break;								
		}
#ifdef	WIN32
		Delay(100);
#endif
	}

}
/////////////////////////////////////////////////////////
void	dspTestItem(void)
{
	int	x,y;

	/* kwon
	DModeSendMsg("+++++ Hardware TEST +++++\r\n");	
	DModeSendMsg("  1 = USB Test\r\n");
	DModeSendMsg("  2 = Set Slave Time\r\n");
	DModeSendMsg("  3 = Set Slave SerialNo/MAC Address\r\n");
	DModeSendMsg("  4 = TCP Test\r\n");
	DModeSendMsg("  5 = Set Time User\r\n");
	DModeSendMsg("  6 = Set Time\r\n");
	*/

	TextOut2(0,1,"                                                  ");
	TextOut2(13,1,"*** Hardware TEST JIG ***");

	
	x= 8,y= 5;
	TextOut2(x,y,"Waiting Request from LP/GP System");	
	
	/* kwon
	x= 9,y= 5;
	TextOut2(x,y,"1:USB TEST");
	RectAngle(x*16-1,y*32-1,(x+32)*16+1,(y+1)*32+1,T_WHITE,T_BLACK);
	x= 9,y= 7;
	TextOut2(x,y,"2:Set Slave Time");
	RectAngle(x*16-1,y*32-1,(x+32)*16+1,(y+1)*32+1,T_WHITE,T_BLACK);
	x= 9,y= 9;
	TextOut2(x,y,"3:Set Slave SerialNo/MAC Address");
	RectAngle(x*16-1,y*32-1,(x+32)*16+1,(y+1)*32+1,T_WHITE,T_BLACK);
	x= 9,y= 11;
	TextOut2(x,y,"4:TCP Test");
	RectAngle(x*16-1,y*32-1,(x+32)*16+1,(y+1)*32+1,T_WHITE,T_BLACK);
	*/
	
//	x= 9,y= 11;
//	TextOut2(x,y,"4:Set Time");
//	RectAngle(x*16-1,y*32-1,(x+32)*16+1,(y+1)*32+1,T_WHITE,T_BLACK);
}
struct{
	int	Startx;
	int	Starty;
	int	Endx;
	int	Endy;
}TouchArea[5]={
	{	9*16-1,5*32-1,(9+32)*16+1,(5+1)*32+1	},
	{	9*16-1,7*32-1,(9+32)*16+1,(7+1)*32+1	},
	{	9*16-1,9*32-1,(9+32)*16+1,(9+1)*32+1	},
	{	9*16-1,11*32-1,(9+32)*16+1,(11+1)*32+1	},
	{	9*16-1,3*32-1,(9+32)*16+1,(3+1)*32+1	},
};

extern int W5100IntFlag;
extern int isReceivedAndEnd;
extern int iCommKind;
extern	unsigned char	UsbWriteBuff[0x200];

void	HardTest(void)
{
//	int	idx,EndFlag,ret;
//	int	cmd;
//	int	KerCodeX;
//	int	KerCodeY;
//	int	i;
//	int	sec;
	int	sUsbHostConnected;
	char	buff[64+2];

	ClearDisplay();
	dspTestItem();
	
	LanDriverInit();
	

	sUsbHostConnected= -1;

	while(1)
	{
		W5100Test();		
		
		UsbHostDrv();
		if(sUsbHostConnected != UsbHostConnected){
			sUsbHostConnected= UsbHostConnected;
			if(sUsbHostConnected == 1){
				sprintf(buff,"      Connected(%d)           ",UsbHostDeviceOK);
				TextOut2(8,9,buff);
			}else{
				sprintf(buff,"      Disconnected(%d)       ",UsbHostDeviceOK);
				TextOut2(8,9,buff);
			}
				
		}
		//process message
		if(W5100IntFlag== 2 ||  isReceivedAndEnd == 3)//receive		
		{
			if(iCommKind == 1) //ethernet
			{				
				TextOut2(8,5,"    Processing Ethernet Test     ");
			}
			else if (iCommKind == 2) //USB
			{
				
				TextOut2(8,5,"      Processing USB Test        ");														
				
				TimerStart(1,300);								
				
				while(1)
				{
			
//					UsbHostDrv();
					if(UsbHostDeviceOK == 1)
					{
						memcpy(UsbWriteBuff, "ABCDEFG012345", 13);
						UsbWriteSector(0, 0x200, UsbWriteBuff);
						break;
						TextOut2(8,11,"Send OK");
						while(1){
							UsbHostDrv();
							if(UsbHostConnected == 0){
								break;
							}
						}
						TextOut2(8,11,"       ");
					}					
					
					if(time_flag[1] != 0)
						break;
				}
				
				
				/*
				memset(UsbWriteBuff,0,sizeof(UsbWriteBuff));
				strcpy((char*)UsbWriteBuff,USB_CMD_TEST);
				for(i= 0; i < 16; i++){
					UsbWriteBuff[i+4]= '0'+i;
				}
				*/								
				
			}
			else if (iCommKind == 3) //Time
			{
				TextOut2(8,5,"       Processing Time           ");
				SetTime();				
			
			}
			else if (iCommKind == 4) //MAC
			{
				TextOut2(8,5,"       Processing MAC            ");					
				SetMacAddrAndSerialNum();
		
			}

			isReceivedAndEnd = 0;
			iCommKind = 0;
		}
		else
			TextOut2(8,5,"Waiting Request from LP/GP System");	

#ifdef	WIN32
		Delay(100);	
#endif
	}

}
