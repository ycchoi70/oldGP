/*    $ JBOSN : touch.c, v 0.1 2003/09/01 $    */

/*
 * Copyright (C) 2003    iBOSN systems
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are not permitted completely.
 *
 */

/*
 * Module Name: touch.c
 *
 * Purpose: touch pad interface for graphic system of j-bosn
 */
#include <stdlib.h>
#define	TOUCH_PROC
#include "define.h"
#include "s2440.h"
#include "touch.h"
#include "glplcd.h"
#include "flash.h"
#include "nand.h"
#include "bios.h"




#define ABS(a)              ((a)>0 ? (a): -(a))


#define PRESCALER			200
#define D4					4
#define SYS_TIMER_DIVIDER	D4
#define OEM_CLOCK_FREQ      (S3C2440X_PCLK / PRESCALER / SYS_TIMER_DIVIDER)

//=======================================================

#define TSP_SAMPLE_RATE_LOW				100
#define TSP_SAMPLE_RATE_HIGH			100
//#define TSP_SAMPLETICK					(OEM_CLOCK_FREQ / TSP_SAMPLE_RATE_LOW)
#define TSP_SAMPLETICK					0xffff

#define ADCPRS							200


#define TSP_INVALIDLIMIT			    40



#define	TSP_SAMPLE_NUM					4 

int     bTSP_DownFlag;

//=======================================================

//static volatile IOP_REG    *gpIOPregs;
static volatile ADC_REG    *gpADCregs;
static volatile INT_REG    *gpINTregs;


int	TouchProcFlag;
//===================================================================================

unsigned int	SelectSample( unsigned int Sample1, unsigned int Sample2 )
{
    unsigned int Smax, Smin;
    
    if( Sample1 > Sample2 )
    {
        Smax = Sample1>>16;
        Smin = Sample2>>16;
    }
    else
    {
        Smax = Sample2>>16;
        Smin = Sample1>>16;
    }

    Sample1 = Sample1 & 0x3FF;
    Sample2 = Sample2 & 0x3FF;

    if( Sample1 > Sample2 )
    {
        if( Smax > Sample1 )
            Smax = Sample1;
        
        if( Smin < Sample2 )
            Smin = Sample2;
    }
    else
    {
        if( Smax > Sample2 )
            Smax = Sample2;
        if( Smin < Sample1 )
            Smin = Sample1;
    }

    return (Smax + Smin)>>1 ;
}

static void	Touch_PowerOn(void)
{
    volatile CLKPWR_REG*    pCLKPWRregs;
    pCLKPWRregs = (volatile CLKPWR_REG*)CLKPWR_BASE;

    /* Use TSXM, TSXP, TSYM, TSYP            */
//    gpIOPregs->rGPGCON |=  ((0x3 << 30) | (0x3 << 28) | (0x3 << 26) | (0x3 << 24));

    // use EINT9 to touch interrupt
//    gpIOPregs->rGPGCON &=  ~(0x3 << 2);
//    gpIOPregs->rGPGCON |=  (0x2 << 2);

    //gpIOPregs->rGPGUP  |=  (0x1 << 1);        // pull up disable
//    gpIOPregs->rGPGUP  &=  ~(0x1 << 1);          // pull up enable


    pCLKPWRregs->rCLKCON |= CLKEN_ADC;


    gpADCregs->rADCDLY =    50000;    

    gpADCregs->rADCCON =    (1        << 14) |    /* A/D Converter Enable               */
                            (ADCPRS   <<  6) |    /* Prescaler Setting                  */
                            (0        <<  3) |    /* Analog Input Channel : 0           */ 
                            (0        <<  2) |    /* Normal Operation Mode              */
                            (0        <<  1) |    /* Disable Read Start                 */
                            (0        <<  0);     /* No Operation                       */

    gpADCregs->rADCTSC =    (0        <<  8) |    /* UD_Sen                             */
                            (1        <<  7) |    /* YMON  1 (YM = GND)                 */
                            (1        <<  6) |    /* nYPON 1 (YP Connected AIN[n])      */
                            (0        <<  5) |    /* XMON  0 (XM = Z)                   */
                            (1        <<  4) |    /* nXPON 1 (XP = AIN[7])              */
                            (0        <<  3) |    /* Pull Up Disable                    */
                            (0        <<  2) |    /* Normal ADC Conversion Mode         */
                            (3        <<  0);     /* Waiting Interrupt                  */


    gpINTregs->rINTSUBMSK  &= ~BIT_SUB_TC;

}

//===================================================================================

int	Touch_GetXY(int *px, int *py)
{
	int i;
	int xsum, ysum;
	int x, y;
	int dx, dy;

    int    bRet = TRUE;

	xsum = ysum = 0;

	for (i = 0; i < TSP_SAMPLE_NUM; i++)
	{
//Sleep(2);
	    // mesure X
//        gpIOPregs->rGPGUP  |=  (0x1 << 1);        // pull up disable(EINT9

		gpADCregs->rADCTSC =	(0		<<	8) |		/* UD_Sen								*/
								(0		<<  7) |		/* YMON  1 (YM = GND)					*/
								(0		<<  6) |		/* nYPON 1 (YP Connected AIN[n])		*/
								(1		<<  5) |		/* XMON  0 (XM = Z)						*/
								(1		<<  4) |		/* nXPON 1 (XP = AIN[7])				*/
								(1      <<  3) |		/* Pull Up Disable						*/
								(0      <<  2) |		/* Auto ADC Conversion Mode				*/
								(1		<<  0);			/* No Operation Mode					*/
		gpADCregs->rADCCON = (gpADCregs->rADCCON & ~(7 << 3)) | (5 << 3);				/* ADC channel 5 */
		gpADCregs->rADCCON |= (1 << 0);				/* Start Auto conversion				*/

		while (gpADCregs->rADCCON & 0x1);				/* check if Enable_start is low			*/
		while (!(gpADCregs->rADCCON & (1 << 15)));		/* Check ECFLG							*/

		x = gpADCregs->rADCDAT0;
//Sleep(2);//kprintf("Touch_GetPoint:%x", x);
		if (x & 0x8000) {bRet = FALSE; break;}
		x &= 0x3ff;


        // mesure Y
		gpADCregs->rADCTSC =	(0		<<	8) |		/* UD_Sen								*/
								(1		<<  7) |		/* YMON  1 (YM = GND)					*/
								(1		<<  6) |		/* nYPON 1 (YP Connected AIN[5])		*/
								(0		<<  5) |		/* XMON  0 (XM = Z)						*/
								(0		<<  4) |		/* nXPON 1 (XP = AIN[7])				*/
								(1      <<  3) |		/* Pull Up Disable						*/
								(0      <<  2) |		/* Auto ADC Conversion Mode				*/
								(2		<<  0);			/* No Operation Mode					*/

		gpADCregs->rADCCON = (gpADCregs->rADCCON & ~(7 << 3)) | (7 << 3);				/* ADC channel 7 */
		gpADCregs->rADCCON |= (1 << 0);				/* Start Auto conversion				*/

		while (gpADCregs->rADCCON & 0x1);				/* check if Enable_start is low			*/
		while (!(gpADCregs->rADCCON & (1 << 15)));		/* Check ECFLG							*/

		y = gpADCregs->rADCDAT1;
//kprintf(" %x\r\n", y);
		if (y & 0x8000) {bRet = FALSE; break;}
		y = 0x3ff - (y&0x3ff);

//		xsum += x;
//		ysum += y;
		xsum += y;
		ysum += x;
	}

	*px = xsum / TSP_SAMPLE_NUM;
	*py = ysum / TSP_SAMPLE_NUM;



//    gpIOPregs->rGPGUP  &=  ~(0x1 << 1);                 // pull up enable(EINT9

	gpADCregs->rADCTSC =	(1		<<	8) |			/* UD_Sen(UP Interrupt)					*/
							(1		<<  7) |			/* YMON  1 (YM = GND)					*/
							(1		<<  6) |			/* nYPON 1 (YP Connected AIN[n])		*/
							(0		<<  5) |			/* XMON  0 (XM = Z)						*/
							(1		<<  4) |			/* nXPON 1 (XP = AIN[7])				*/
							(0      <<  3) |			/* Pull Up Enable						*/
							(0      <<  2) |			/* Normal ADC Conversion Mode			*/
							(3		<<  0);				/* Waiting Interrupt					*/

	
	
	if (!bRet)
    {
		bTSP_DownFlag = FALSE;
        return bRet;
    }
//kprintf("Touch_GetPoint %x", *px);
//kprintf(" %x\r\n", *py);

	dx = (*px > x) ? (*px - x) : (x - *px);
	dy = (*py > y) ? (*py - y) : (y - *py);

	return ((dx > TSP_INVALIDLIMIT || dy > TSP_INVALIDLIMIT) ? FALSE : TRUE);
}



//=================================================================================================
//=================================================================================================
//=================================================================================================
//=================================    EXPORTED FUNCTIONS    ======================================
//=================================================================================================
//=================================================================================================
//=================================================================================================

void	TouchCalCheck(void)
{
#ifdef	WIN32
	return;
#endif
	FlashReadSeq((char*)&Cal_Data.CalibPos[0],(char*)TOUCH_CALIB_AREA,sizeof(Cal_Data));
	if((unsigned int)Cal_Data.CalibPos[0].PosDigitX == (unsigned int)0xffffffff){
		Cal_Data.CalibPos[0].PosDigitX= 100;
		Cal_Data.CalibPos[0].PosDigitY= 100;
		Cal_Data.CalibPos[0].PosAnalogX= 0x00a6;
		Cal_Data.CalibPos[0].PosAnalogY= 0x011b;
		Cal_Data.CalibPos[1].PosDigitX= 600;
		Cal_Data.CalibPos[1].PosDigitY= 400;
		Cal_Data.CalibPos[1].PosAnalogX= 0x02dc;
		Cal_Data.CalibPos[1].PosAnalogY= 0x030e;
//		FlashWrite((char*)TOUCH_CALIB_AREA,(char*)&CalibPos[0],sizeof(CalibPos));
	}
	if((unsigned int)Cal_Data.BackCal.Prescaler == (unsigned int)0xffffffff){
		//Backlit Set
		Cal_Data.BackCal.Prescaler= 135;
		Cal_Data.BackCal.Devid= 16;
		Cal_Data.BackCal.Count= 0x255;
		Cal_Data.BackCal.CmpCnt= 0x250;
	}
	//X-a
	fDx1= (float)(Cal_Data.CalibPos[1].PosDigitX-Cal_Data.CalibPos[0].PosDigitX)/
		  (float)(Cal_Data.CalibPos[1].PosAnalogX- Cal_Data.CalibPos[0].PosAnalogX);
	//X-b
	iDx1_b= Cal_Data.CalibPos[0].PosDigitX- (int)(fDx1*(float)Cal_Data.CalibPos[0].PosAnalogX);
	//Y-a
	fDy1= (float)(Cal_Data.CalibPos[1].PosDigitY-Cal_Data.CalibPos[0].PosDigitY)/
		  (float)(Cal_Data.CalibPos[1].PosAnalogY- Cal_Data.CalibPos[0].PosAnalogY);
	//Y-b
	iDy1_b= Cal_Data.CalibPos[0].PosDigitY- (int)(fDy1*(float)Cal_Data.CalibPos[0].PosAnalogY);
}
void	TouchInit( void )
{
#ifdef	WIN32
	 return;
#endif
//    gpIOPregs = (volatile IOP_REG *)IOP_BASE;
    gpADCregs = (volatile ADC_REG *)ADC_BASE;
    gpINTregs = (volatile INT_REG *)INT_BASE;

    Touch_PowerOn();

	gpINTregs->rSRCPND  = (unsigned int)BIT_ADC;
	if (gpINTregs->rINTPND & (unsigned int)BIT_ADC)
		gpINTregs->rINTPND = (unsigned int)BIT_ADC;
	gpINTregs->rINTMSK &= ~BIT_ADC;

//    gpINTregs->rINTMSK &= ~INTSRC_EINT8_23;
//	gpIOPregs->rEINTMASK &= ~(1<<TOUCH_IRQ);		// Mask and clear interrupt at first-level controller.
//	gpIOPregs->rEINTPEND  = (1<<TOUCH_IRQ);		//

	UpDown= 0;

	TouchProcFlag= 0;

	//(100.100)->(600,400)Data
//	FlashRead((char*)&CalibPos[0],(char*)TOUCH_CALIB_AREA,sizeof(CalibPos));
	TouchCalCheck();

	TouchRepeatFlag= 0;

	timLoopCnt= 0;		//Touch Timer Start
}



static	int	SaveX,	SaveY;
int	TouchGetPoint1( unsigned int* pfTipState, int *pUncalX, int *pUncalY)
{
	static int x, y;
	unsigned int	status;
	unsigned int	istatus;
	int	ret;

		*pfTipState = TOUCH_SAMPLE_VALID;

		istatus= gpADCregs->rADCUPDN;
		status= gpADCregs->rADCDAT0;
		status |= gpADCregs->rADCDAT1;
	//	if ( (gpADCregs->rADCDAT0 & (1 << 15)) |
	//		 (gpADCregs->rADCDAT1 & (1 << 15)) )
		if(status & (1 << 15))
		{											//UP State
			bTSP_DownFlag = FALSE;
			KeyDat2PosFlag= 0;

			//DEBUGMSG(ZONE_TIPSTATE, (TEXT("up\r\n")));

			gpADCregs->rADCTSC &= 0xff;

	//		*pUncalX = x;
	//		*pUncalY = y;

//			Touch_SampleStop();

			gpADCregs->rADCTSC =	(0		<<	8) |			/* UD_Sen(Down Interrupt)				*/
									(1		<<  7) |			/* YMON  1 (YM = GND)					*/
									(1		<<  6) |			/* nYPON 1 (YP Connected AIN[n])		*/
									(0		<<  5) |			/* XMON  0 (XM = Z)						*/
									(1		<<  4) |			/* nXPON 1 (XP = AIN[7])				*/
									(0      <<  3) |			/* Pull Up Enable						*/
									(0      <<  2) |			/* Normal ADC Conversion Mode			*/
									(3		<<  0);				/* Waiting Interrupt					*/

			*pfTipState = TOUCH_SAMPLE_IGNORE;
			ret= 0;


		}
		else 
		{
			bTSP_DownFlag = TRUE;

			if (!Touch_GetXY(&x, &y)) 
				*pfTipState = TOUCH_SAMPLE_IGNORE;


			*pUncalX = x;
			*pUncalY = y;

			*pfTipState |= TOUCH_SAMPLE_DOWN;


			*pfTipState = TOUCH_SAMPLE_VALID;
//			Touch_SampleStart();
			if((x == 0) && (y == 0)){
				ret= 0;
			}else{
				if(istatus & 0x03){
				}else{
					*pUncalX= SaveX;
					*pUncalY= SaveY;
				}
				ret= 1;
			}
			SaveX= x;
			SaveY= y;
		}
	return(ret);
}

int	_TouchIntProc( int source )
{
	unsigned int	fSample = 0;
	int				RawX, CalX;
	int				RawY, CalY;
	int				Ret= -1;

	if(TouchProcFlag != 0){	return(0);	}
	TouchProcFlag= 1;

	Smouse= TouchGetPoint1( &fSample, &RawX, &RawY );    // Get the point info
	if(Smouse != 0){

		NonCalbX= RawX;
		NonCalbY= RawY;


		CalX= (int)(fDx1 * (float)RawX) + iDx1_b;
		CalY= (int)(fDy1 * (float)RawY) + iDy1_b;

		if(CalX < 0){	CalX= 0;	}
		if(CalX >= LCD_X_SIZE){	CalX= LCD_X_SIZE-1;	}
		if(CalY < 0){	CalY= 0;	}
		if(CalY >= LCD_Y_SIZE){	CalY= LCD_Y_SIZE-1;	}
		DigCalbX= CalX;
		DigCalbY= CalY;

//        Xmouse = (unsigned int)(CalX/MESH_X);
//        Ymouse = (unsigned int)(CalY/MESH_Y);
//		if(Xmouse > LCD_X_SIZE/MESH_X){		Xmouse= 0;	}
//		if(Ymouse > LCD_Y_SIZE/MESH_Y){		Ymouse= 0;	}
//		KeyData[KeyDataIn++]= Ymouse*(LCD_X_SIZE/MESH_X)+Xmouse+ 1;
		KeyDataX[KeyDataIn]= DigCalbX;
		KeyDataY[KeyDataIn++]= DigCalbY;
		KeyDataIn &= 3;
		UpDown= 1;
		Ret= 0;
		if(source == 0){		//touch Interrupt
			ScanStartX= DigCalbX;		//First Touch Pos
			ScanStartY= DigCalbY;		//First Touch Pos
			ScanBefX= DigCalbX;
			ScanBefY= DigCalbY;
			ScanCnt= 0;
			KeyDat2PosFlag= 0;
		}else{					//Scan Interrupt
			ScanCnt++;
			//����1/4�ȏ�łQ?�ڂ�?�b?�Ƃ���B
//			if((DigCalbX > LCD_X_SIZE/2) || (DigCalbY > LCD_Y_SIZE/2)){		//1 Pos
//				ScanStartX= DigCalbX;		//First Touch Pos
//				ScanStartY= DigCalbY;		//First Touch Pos
//				KeyDat2PosFlag= 0;
//			}else{
				CalX= abs(ScanBefX- DigCalbX);
				CalY= abs(ScanBefY- DigCalbY);
//				if((CalX > TOUCH_DELTA_X10) || (CalY > TOUCH_DELTA_Y10)){		//�O��l�Ƃ̕ω�
				if(ScanCnt >= 3){
					ScanCnt= 0;
					if((CalX > TOUCH_DELTA_X) || (CalY > TOUCH_DELTA_Y)){		//�O��l�Ƃ̕ω�
						CalX= abs(ScanStartX- DigCalbX);
						CalY= abs(ScanStartY- DigCalbY);
	//					if(((CalX > TOUCH_DELTA_X) || (CalY > TOUCH_DELTA_Y)) &&
						if( ((DigCalbX >= TOUCH_2POS_X_LOW) && (DigCalbX <= TOUCH_2POS_X_HIGH)) ||
							((DigCalbY >= TOUCH_2POS_Y_LOW) && (DigCalbY <= TOUCH_2POS_Y_HIGH)) ){
							//2 pos touch
							KeyDat1stX= DigCalbX- CalX;
							KeyDat2ndX= DigCalbX+ CalX;
							KeyDat1stY= DigCalbY- CalY;
							KeyDat2ndY= DigCalbY+ CalY;
							KeyDat2PosFlag= 1;
						}else{
	//						ScanStartX= DigCalbX;		//First Touch Pos
	//						ScanStartY= DigCalbY;		//First Touch Pos
							KeyDat2PosFlag= 0;
						}
					}
					ScanBefX= DigCalbX;
					ScanBefY= DigCalbY;
				}
			}
//		}
	}else{			//Up
		if(UpDown != 0){
			UpDown= 0;
	        Xmouse = 0;
		    Ymouse = 0;
			KeyDataX[KeyDataIn]= 0;
			KeyDataY[KeyDataIn++]= 0;
			KeyDataIn &= 3;
			Ret= 0;
		}
	}
	TouchProcFlag= 0;
	return(Ret);
}
int	_TouchInterruptProc( void )
{
	int	ret;

	gpINTregs->rINTSUBMSK |= BIT_SUB_TC;
	gpINTregs->rINTMSK    |= (unsigned int)BIT_ADC;
	gpINTregs->rSRCPND     = (unsigned int)BIT_ADC;	/* Interrupt Clear			*/
	gpINTregs->rINTPND     = (unsigned int)BIT_ADC;

	ret= _TouchIntProc(0);

	gpINTregs->rSUBSRCPND  =  BIT_SUB_TC;
	gpINTregs->rINTSUBMSK &= ~BIT_SUB_TC;

	gpADCregs->rADCUPDN= 0;
	gpINTregs->rSRCPND = (unsigned int)BIT_ADC;
	if (gpINTregs->rINTPND & (unsigned int)BIT_ADC)
		gpINTregs->rINTPND = (unsigned int)BIT_ADC;
	gpINTregs->rINTMSK &= ~(unsigned int)BIT_ADC;

	return(ret);

}
void	_TouchInterruptHandler( void )
{

	_TouchInterruptProc();
}
int	TouchTimerCheck(void)
{
	int	ret= -1;

	if((bTSP_DownFlag == TRUE) && (TouchRepeatFlag == 1)){
		ret= _TouchIntProc(1);
		if(ScanCnt == 0)		//First Scan
		ScanCnt++;
	}
	return(ret);
}


void   ScanKey(int* x,int* y)
{
//	int	ret= 0;

	if(KeyDataIn != KeyDataOut){
		*x= KeyDataX[KeyDataOut];
		*y= KeyDataY[KeyDataOut++];
		KeyDataOut &= 3;
	}else{
		*x= 0;
		*y= 0;
	}
//    return(ret);
}
#ifdef	WIN32
void	SetScanKey(void)
{
extern	long   lMouseX;
extern	long   lMouseY;
extern	int    lMouseKey;
extern	int    lMouseAction;
	if(lMouseAction != 0){
//		Xmouse = (unsigned int)(lMouseX/MESH_X);
//		Ymouse = (unsigned int)(lMouseY/MESH_Y);
//		if(Xmouse > LCD_X_SIZE/MESH_X){		Xmouse= 0;	}
//		if(Ymouse > LCD_Y_SIZE/MESH_Y){		Ymouse= 0;	}
		KeyDataX[KeyDataIn]= lMouseX;
		KeyDataY[KeyDataIn++]= lMouseY;
	}else{
		KeyDataX[KeyDataIn]= 0;
		KeyDataY[KeyDataIn++]= 0;
	}
	KeyDataIn &= 3;
}
#endif

int	GetAD_Power(int *adValue)
{
	int i;
	int ad_sum;
	int ad_data;
	int	ret= OK;

	ad_sum = 0;


	TimerStart( 1, 100 );		/* 1s */
	for (i = 0; i < TSP_SAMPLE_NUM; i++)
	{
		gpADCregs->rADCTSC =	(0		<<	8) |		/* UD_Sen								*/
								(0		<<  7) |		/* YMON  1 (YM = GND)					*/
								(0		<<  6) |		/* nYPON 1 (YP Connected AIN[n])		*/
								(0		<<  5) |		/* XMON  0 (XM = Z)						*/
								(0		<<  4) |		/* nXPON 1 (XP = AIN[7])				*/
								(0      <<  3) |		/* Pull Up Disable						*/
								(0      <<  2) |		/* Auto ADC Conversion Mode				*/
								(0		<<  0);			/* No Operation Mode					*/

		gpADCregs->rADCCON = (gpADCregs->rADCCON & ~(7 << 3)) | (0 << 3);				/* ADC channel 0 */
		gpADCregs->rADCCON |= (1 << 0);				/* Start Auto conversion				*/

		while (gpADCregs->rADCCON & 0x1){				/* check if Enable_start is low			*/
			if(time_flag[1] != 0){
				ret= NG;
			}
		}
		while (!(gpADCregs->rADCCON & (1 << 15))){		/* Check ECFLG							*/
			if(time_flag[1] != 0){
				ret= NG;
			}
		}

		ad_data = gpADCregs->rADCDAT0;
		ad_data &= 0x3ff;


 		ad_sum += ad_data;
	}

	ad_data= ad_sum / TSP_SAMPLE_NUM;


	gpADCregs->rADCTSC =	(1		<<	8) |			/* UD_Sen(UP Interrupt)					*/
							(1		<<  7) |			/* YMON  1 (YM = GND)					*/
							(1		<<  6) |			/* nYPON 1 (YP Connected AIN[n])		*/
							(0		<<  5) |			/* XMON  0 (XM = Z)						*/
							(1		<<  4) |			/* nXPON 1 (XP = AIN[7])				*/
							(0      <<  3) |			/* Pull Up Enable						*/
							(0      <<  2) |			/* Normal ADC Conversion Mode			*/
							(3		<<  0);				/* Waiting Interrupt					*/

	*adValue= ad_data;
	return(ret);
}


