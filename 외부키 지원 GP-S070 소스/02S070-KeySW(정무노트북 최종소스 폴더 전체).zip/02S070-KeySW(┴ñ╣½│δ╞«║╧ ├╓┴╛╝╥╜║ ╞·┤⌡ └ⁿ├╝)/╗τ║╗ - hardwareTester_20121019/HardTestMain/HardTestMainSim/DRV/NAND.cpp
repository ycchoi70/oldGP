
#include	<string.h>
#define	NAND_PROC
#include "S2440.h"
#include "nand.h"


volatile	NAND_REG	*nandCtl;

#define _CNT(ctl)		   {nandCtl->rNFCONT=ctl;}
#define _CMD(cmd)		   {nandCtl->u1.rNFCMMD=cmd;}
#define _ADDR(addr) 	   {nandCtl->u2.rNFADDR=addr;}	
#define _RstECC()		   {nandCtl->rNFCONT|=(1<<4);}
#define _RstECCLOCK()	   {nandCtl->rNFCONT&=~((1<<6)|(1<<5));}
#define _SetECCLOCK()	   {nandCtl->rNFCONT|=((1<<6)|(1<<5));}
#define _RDDATA() 		(nandCtl->u3.rNFDATA)
#define _WRDATA(data) 	{nandCtl->u3.rNFDATA=data;}
#define _GetRDY() 		(nandCtl->rNFSTAT & 0x01)

#define _WaitRB()    	{while(!(nandCtl->u4.rNFSTAT&(1<<0)));}



void NAND_Reset(void)
{
	volatile int i;

	_CMD(CMD_RESET);	//reset command

	for(i=0;i<10;i++);  //tWB = 100ns. //??????

	_WaitRB();      //wait 200~500us;
}
void NAND_Init(void)
{
#ifdef	WIN32
	return;
#endif
	nandCtl= (NAND_REG*)NAND_BASE_PHYS;
//	rNFCONF=(1<<15)|(1<<14)|(1<<13)|(1<<12)|(1<<11)|(0<<8)|(3<<4)|(0<<0);
	nandCtl->rNFCONF=(0x3<<12)|(0x7<<8)|(0x7<<4)|(0x0<<0);
	nandCtl->rNFCONT=(0x0<<13)|(0x0<<12)|(0x0<<10)|(0x0<<9)|(0x0<<8)|(0x1<<6)|(0x1<<5)|(0x1<<4)|(0x1<<1)|(0x1<<0);

	NAND_Reset();

	memset(NandID,0,sizeof(NandID));
	NAND_ReadID(NandID);
	//ID�ɂ��ݒ��ς���B(Default NAND1)
	NAND_PAGE_SIZE= NAND1_PAGE_SIZE;
	NAND_PAGE_PER_BLOCK= NAND1_PAGE_PER_BLOCK;
	NAND_ECC_SIZE= NAND1_ECC_SIZE;
	NAND_ECC_SIZE_START= NAND1_ECC_SIZE_START;
	NandType= 0;
	if(memcmp(NandID,Nand1ID,4) == 0){
		//ID1
		NAND_PAGE_SIZE= NAND1_PAGE_SIZE;
		NAND_PAGE_PER_BLOCK= NAND1_PAGE_PER_BLOCK;
		NAND_ECC_SIZE= NAND1_ECC_SIZE;
		NAND_ECC_SIZE_START= NAND1_ECC_SIZE_START;
		NandType= 0;
	}else if(memcmp(NandID,Nand2ID,4) == 0){
		//NAND ID2
		NAND_PAGE_SIZE= NAND2_PAGE_SIZE;
		NAND_PAGE_PER_BLOCK= NAND2_PAGE_PER_BLOCK;
		NAND_ECC_SIZE= NAND2_ECC_SIZE;
		NAND_ECC_SIZE_START= NAND2_ECC_SIZE_START;
		NandType= 1;
	}

}
void NAND_Open(void)
{
	unsigned int	ctl;

#ifdef	WIN32
	return;
#endif
	ctl= nandCtl->rNFCONT;
	ctl &= ~(1<<1);
	_CNT(ctl);
}
void NAND_Close(void)
{
	unsigned int	ctl;

	ctl= nandCtl->rNFCONT;
	ctl |= (1<<1);
	_CNT(ctl);
}




void NAND_ReadID(unsigned char* buff)
{
	volatile int i;
//	unsigned int data;

#ifdef	WIN32
	return;
#endif
	NAND_Open();
	_CMD(CMD_READ_ID);
	_ADDR(0x0);

	for(i=0;i<10;i++); //wait tWB(100ns)////?????

	buff[0] = (unsigned char)_RDDATA();	// Maker code       (K9D1G08V0X:0xec)
	buff[1] = (unsigned char)_RDDATA();	// Device code      (K9D1G08V0X:0x76)
	buff[2] = (unsigned char)_RDDATA();	// UniquelID code   (K9D1G08V0X:0xa5)
	buff[3] = (unsigned char)_RDDATA();	// Multi Plane code (K9D1G08V0X:0xc0)

	NAND_Close();
}

int NAND_MarkBadBlock(int block)
{
	int i,rc;
	unsigned int blockPage;
	unsigned int address;

	NAND_Open();
	if(NandType == 0){
		blockPage=(block<<5);
		_CMD(CMD_READ_C);		            /* Spare array read command                 */
		_CMD(CMD_SEQIN);   // Write 1st command
		_ADDR((NAND_PAGE_SIZE+0x05)& 0xf);		        /* Read the mark of bad block in spare      */
		_ADDR(blockPage & 0xff);	    /* The mark of bad block is in 0 page       */
		_ADDR((blockPage >>  8) & 0xff);  /* For block number A[24:17]            */
		_ADDR((blockPage >>  16) & 0xff); /* For block number A[25]            */
	}else{
		_CMD(CMD_READ_A);		//??????
		_CMD(CMD_SEQIN);   // Write 1st command
		blockPage=(block<<6);
		address= NAND_PAGE_SIZE+0x05;
		_ADDR(address&0xff);					// Column = 0
		_ADDR((address>>8)&0xff);				// Column = 0
		_ADDR(blockPage&0xff);					// Row
		_ADDR((blockPage>>8)&0xff);				// Row Block & Page num.
	}
	_WRDATA(0x00);	// Write spare array(ECC and Mark)

	_CMD(CMD_PAGEPROG);   // Write 2nd command

	for(i=0;i<10;i++);  //tWB = 100ns. ////??????
	_WaitRB();    //wait tPROG 200~500us;

	_CMD(CMD_READ_STS);   // Read status command   

	for(i=0;i<3;i++);  //twhr=60ns

	if(_RDDATA()&0x1){	rc= 0;	}
	else{				rc= 1;	}
	NAND_Close();
	return(rc);
}

int NAND_ReadPage(unsigned int block,unsigned int page,unsigned char *buffer)
{
	int i;
	unsigned int blockPage;
	unsigned char *bufPt=buffer;
	unsigned int	ecc0;
	unsigned int	ecc1;
//	unsigned char se[16];
//	unsigned char se[MAX_NAND_ECC_SIZE];
	unsigned char rse[8];
	int	EccCheckFlag;			//2012.02.11

	NAND_Open();

	_RstECC();

	_RstECCLOCK();

	_CMD(CMD_READ_A);   // Read command

	if(NandType == 0){
		page=page&0x1f;
		blockPage=(block<<5)+page;
		_ADDR(0);						// Column = 0
		_ADDR(blockPage&0xff);			// Row[A9:A16]
		_ADDR((blockPage>>8)&0xff);		// Row[A17:A24]Block & Page num.
		_ADDR((blockPage>>16)&0xff);	// Row[A25]Block & Page num.
	}else{
		page=page&0x3f;
		blockPage=(block<<6)+page;
		_ADDR(0);						// Column = 0
		_ADDR(0);						// Column = 0
		_ADDR(blockPage&0xff);			// Row[A12:A19]
		_ADDR((blockPage>>8)&0xff);		// Row[A20:A27]Block & Page num.
	}

	for(i=0;i<10;i++); //wait tWB(100ns)/////??????
	_WaitRB();    // Wait tR(max 12us)


//	for(i=0x0000;i<0x0200;i++){
	for(i=0x0000;i<NAND_PAGE_SIZE;i++){
		*bufPt++ = (unsigned char)_RDDATA();
	}

	ecc0= nandCtl->rNFMECC0;
	ecc1= nandCtl->rNFMECC1;

//	for(i=0x00;i<0x10;i++)
	for(i=0x00;i<NAND_ECC_SIZE;i++)
	{
//		se[i] = (unsigned char)_RDDATA();
		Nand_se[i] = (unsigned char)_RDDATA();
	}


	_SetECCLOCK();
	NAND_Close();

	rse[0]=ecc0 & 0xff;
	rse[1]=(ecc0>>8) & 0xff;
	rse[2]=(ecc0>>16) & 0xff;
	rse[3]=(ecc0>>24) & 0xff;

	rse[4]=ecc1 & 0xff;
	rse[5]=(ecc1>>8) & 0xff;
	rse[6]=(ecc1>>16) & 0xff;
	rse[7]=(ecc1>>24) & 0xff;

// 2012.02.11
//	if( rse[0]==se[0x08] && rse[1]==se[0x09] && rse[2]==se[0x0a] && rse[3]==se[0x0b] &&
//		rse[4]==se[0x0c] && rse[5]==se[0x0d] && rse[6]==se[0x0e] && rse[7]==se[0x0f] )
	EccCheckFlag= 0;
	for(i= 0; i < 8; i++){
//		if(rse[i] != se[NAND_ECC_SIZE_START+i]){
		if(rse[i] != Nand_se[NAND_ECC_SIZE_START+i]){
			EccCheckFlag= 1;
			break;
		}
	}
	if( EccCheckFlag == 0 )
	{
		return 1;
	}else{
		return 0;
	}
}

int NAND_ReadPage_ECC(unsigned int block,unsigned int page,unsigned char *buffer)
{
	int i;
	unsigned int blockPage;
	unsigned char *bufPt=buffer;
//	unsigned int	ecc0;
//	unsigned int	ecc1;
//	unsigned char se[16];
//	unsigned char rse[8];

	NAND_Open();

//	_RstECC();


	_CMD(CMD_READ_A);   // Read command

	if(NandType == 0){
		page=page&0x1f;
		blockPage=(block<<5)+page;
		_ADDR(0);						// Column = 0
		_ADDR(blockPage&0xff);			// Row[A9:A16]
		_ADDR((blockPage>>8)&0xff);		// Row[A17:A24]Block & Page num.
		_ADDR((blockPage>>16)&0xff);	// Row[A25]Block & Page num.
	}else{
		page=page&0x3f;
		blockPage=(block<<6)+page;
		_ADDR(0);						// Column = 0
		_ADDR(0);						// Column = 0
		_ADDR(blockPage&0xff);			// Row[A12:A19]
		_ADDR((blockPage>>8)&0xff);		// Row[A20:A27]Block & Page num.
	}

	for(i=0;i<10;i++); //wait tWB(100ns)/////??????
	_WaitRB();    // Wait tR(max 12us)


//	for(i=0x0000;i<0x0210;i++){
	for(i=0x0000;i<(NAND_PAGE_SIZE+ NAND_ECC_SIZE);i++){
		*bufPt++ = (unsigned char)_RDDATA();
	}

//	ecc0= nandCtl->rNFMECC0;
//	ecc1= nandCtl->rNFMECC1;

//	for(i=0x00;i<0x10;i++)
//	{
//		se[i] = (unsigned char)_RDDATA();
//	}


	NAND_Close();

//	rse[0]=ecc0 & 0xff;
//	rse[1]=(ecc0>>8) & 0xff;
//	rse[2]=(ecc0>>16) & 0xff;
//	rse[3]=(ecc0>>24) & 0xff;

//	rse[4]=ecc1 & 0xff;
//	rse[5]=(ecc1>>8) & 0xff;
//	rse[6]=(ecc1>>16) & 0xff;
//	rse[7]=(ecc1>>24) & 0xff;

//	if( rse[0]==se[0x08] && rse[1]==se[0x09] && rse[2]==se[0x0a] && rse[3]==se[0x0b] &&
//		rse[4]==se[0x0c] && rse[5]==se[0x0d] && rse[6]==se[0x0e] && rse[7]==se[0x0f] )
//	{
		return 1;
//	}else{
//		return 0;
//	}
}

int NAND_WritePage(unsigned int block,unsigned int page,unsigned char *buffer)
{
	int i,rc;
//	unsigned int blockPage=(block<<5)+page;
	unsigned int blockPage=block;
	unsigned char *bufPt=buffer;
//	unsigned char se[16];
//	unsigned char se[MAX_NAND_ECC_SIZE];
	unsigned int	data;

//	memset(se,0,sizeof(se));
	memset(Nand_se,0,sizeof(Nand_se));

//if(block == 0){	return(0);	}

//	se[5]= 0xff;
	Nand_se[5]= 0xff;
	NAND_Open();

	_RstECC();
	_RstECCLOCK();

//	_CMD(0x00);		//??????
//	_CMD(0x80);   // Write 1st command
	_CMD(CMD_READ_A);		//??????
	_CMD(CMD_SEQIN);   // Write 1st command

	if(NandType == 0){
		blockPage=(block<<5)+page;
		_ADDR(0);						// Column 0
		_ADDR(blockPage&0xff);			// Row[A9:A16]
		_ADDR((blockPage>>8)&0xff);		// Row[A17:A24]Block & page num.
		_ADDR((blockPage>>16)&0xff);	// Row[A25]Block & page num.
	}else{
		blockPage=(block<<6)+page;
		_ADDR(0);						// Column = 0
		_ADDR(0);						// Column = 0
		_ADDR(blockPage&0xff);			// Row[A12:A19]
		_ADDR((blockPage>>8)&0xff);		// Row[A20:A27]Block & Page num.
	}

//	for(i=0;i<512;i++)
	for(i=0;i<NAND_PAGE_SIZE;i++)
	{
		_WRDATA(*bufPt++);	// Write one page to NFM from buffer

	}  
//	se[5]=0xff;		// Marking good block
	Nand_se[5]=0xff;		// Marking good block
	
	data= nandCtl->rNFMECC0;
//	se[0x8]=data & 0xff;
//	se[0x9]=(data>>8) & 0xff;
//	se[0xa]=(data>>16) & 0xff;
//	se[0xb]=(data>>24) & 0xff;
	Nand_se[NAND_ECC_SIZE_START]=data & 0xff;
	Nand_se[NAND_ECC_SIZE_START+1]=(data>>8) & 0xff;
	Nand_se[NAND_ECC_SIZE_START+2]=(data>>16) & 0xff;
	Nand_se[NAND_ECC_SIZE_START+3]=(data>>24) & 0xff;

	data= nandCtl->rNFMECC1;
//	se[0xc]=data & 0xff;
//	se[0xd]=(data>>8) & 0xff;
//	se[0xe]=(data>>16) & 0xff;
//	se[0xf]=(data>>24) & 0xff;
	Nand_se[NAND_ECC_SIZE_START+4]=data & 0xff;
	Nand_se[NAND_ECC_SIZE_START+5]=(data>>8) & 0xff;
	Nand_se[NAND_ECC_SIZE_START+6]=(data>>16) & 0xff;
	Nand_se[NAND_ECC_SIZE_START+7]=(data>>24) & 0xff;

//	for(i=0;i<16;i++)
	for(i=0;i<NAND_ECC_SIZE;i++)
	{
//		_WRDATA(se[i]);	// Write spare array(ECC and Mark)
		_WRDATA(Nand_se[i]);	// Write spare array(ECC and Mark)
	}  

//	_CMD(0x10);   // Write 2nd command
	_CMD(CMD_PAGEPROG);   // Write 2nd command

	for(i=0;i<10;i++);  //tWB = 100ns. ////??????
	_WaitRB();    //wait tPROG 200~500us;

//	_CMD(0x70);   // Read status command   
	_CMD(CMD_READ_STS);   // Read status command   

	for(i=0;i<3;i++);  //twhr=60ns

	if(_RDDATA()&0x1) // Page write error
	{	
		NAND_MarkBadBlock(block);
		rc= 0;
	}
	else 
	{
		rc= 1;
	}
	_SetECCLOCK();
	NAND_Close();
	return(rc);
}

int NAND_IsBadBlock(unsigned block)
{
	int		i;
	unsigned int blockPage;
	unsigned char data;
	unsigned int address;
	
	NAND_Open();
	if(NandType == 0){
		blockPage = (block << 5);	    /* For 2'nd cycle I/O[7:5]                  */
		_CMD(CMD_READ_C);		            /* Spare array read command                 */

		_ADDR((NAND_PAGE_SIZE+0x05)& 0xf);		        /* Read the mark of bad block in spare      */
		_ADDR(blockPage & 0xff);			/* The mark of bad block is in 0 page       */
		_ADDR((blockPage >>  8) & 0xff);	/* For block number A[24:17]            */
		_ADDR((blockPage >>  16) & 0xff);	/* For block number A[24:17]            */
	}else{
		_CMD(CMD_READ_A);   // Read command
		blockPage=(block<<6);
		address= NAND_PAGE_SIZE+0x05;
		_ADDR(address&0xff);				// Column = 0
		_ADDR((address>>8)&0xff);			// Column = 0
		_ADDR(blockPage&0xff);				//
		_ADDR((blockPage>>8)&0xff);			// Block & Page num.
	}
	for(i=0;i<10;i++); //wait tWB(100ns)//??????
	_WaitRB();	                /* Wait tR(max 12us)                        */
	
	data = (unsigned char)_RDDATA();

	NAND_Close();
	return ((data != 0xff) ? 1 : 0);
}



int NAND_EraseBlock(unsigned int block)
{
	unsigned int blockPage;
	int i,rc;

	NAND_Open();
//	_CMD(0x60);   // Erase one block 1st command
	_CMD(CMD_ERASE1);   // Erase one block 1st command

	if(NandType == 0){
		blockPage=block<<5;
		_ADDR(blockPage&0xff);	    // Page number=0
		_ADDR((blockPage>>8)&0xff);   
		_ADDR((blockPage>>16)&0xff);   
	}else{
		blockPage=block<<6;
		_ADDR(blockPage&0xff);	    // Page number=0
		_ADDR((blockPage>>8)&0xff);   
	}

//	_CMD(0xd0);   // Erase one blcok 2nd command
	_CMD(CMD_ERASE2);   // Erase one blcok 2nd command

	for(i=0;i<10;i++); //wait tWB(100ns)//??????

	_WaitRB();    // Wait tBERS max 3ms.
//	_CMD(0x70);   // Read status command
	_CMD(CMD_READ_STS);   // Read status command

	if (_RDDATA()&0x1) // Erase error
	{	
		NAND_Close();
		NAND_MarkBadBlock(block);
		rc= 0;
	}
	else 
	{
		NAND_Close();
		rc= 1;
	}
	return(rc);
}
int	GetRealBlock(int block)
{
	int	i;
	RANDOM_MAP*	BadInf;
	START_MAP* StartBad;

	BadInf= (RANDOM_MAP*)&NandBadblockMap.RandomMap;
	for(i= 0; i < BadInf->ChangeBadCnt; i++){
		if(block == BadInf->chgInf[i].Original){
			block= BadInf->chgInf[i].NewNo;
			break;
		}
	}
	if(i >= BadInf->ChangeBadCnt){
		StartBad= (START_MAP*)&NandBadblockMap.StartBadblock;
		for(i= 0; i < StartBad->StartBadCnt; i++){
			if(block >= StartBad->BadNo[i]){
				block++;
			}
		}
	}
	return(block);
}
int	GetReserveBlock(int block)
{
	int	i;
	RANDOM_MAP*	BadInf;
//	START_MAP* StartBad;

	BadInf= (RANDOM_MAP*)&NandBadblockMap.RandomMap;
	for(i= 0; i < BadInf->ChangeBadCnt; i++){
		if(block == BadInf->chgInf[i].Original){		//Same No
			BadInf->chgInf[i].NewNo= BadInf->ReserveStartNo++;
			block= BadInf->chgInf[i].NewNo;
			break;
		}
	}
	if(i >= BadInf->ChangeBadCnt){						//New
		BadInf->chgInf[i].NewNo= BadInf->ReserveStartNo++;
		block= BadInf->chgInf[i].NewNo;
	}
//	StartBad= (START_MAP*)&NandBadblockMap.StartBadblock;
//	for(i= 0; i < StartBad->StartBadCnt; i++){
//		if(block >= StartBad->BadNo[i]){
//			block++;
//		}
//	}
	return(block);
}
//int	errFlag;
int NAND_Write_Random(unsigned int fAddr,unsigned char *buffer,int len)
{
	int	i,j;
	unsigned int Sector= fAddr/NAND_PAGE_SIZE;	//2012.02.11
	int	StartIdx= fAddr%NAND_PAGE_SIZE;			//2012.02.11
	int	block= Sector/NAND_PAGE_PER_BLOCK;
//	int	eblock= Sector/NAND_PAGE_PER_BLOCK;
	int	page= Sector%NAND_PAGE_PER_BLOCK;
	int	pageCnt;
	int	pageByteCnt;
	int	rc= 1;
	int	RealBlock;
	int	ChangeFlag;

	ChangeFlag= 0;
	while(len > 0){
		pageCnt= NAND_PAGE_PER_BLOCK-page;
		pageByteCnt= pageCnt*NAND_PAGE_SIZE;
		if(len <= pageByteCnt){
			pageCnt= len/NAND_PAGE_SIZE;
			if(len%NAND_PAGE_SIZE){	pageCnt++;	}
			pageByteCnt= pageCnt*NAND_PAGE_SIZE;
		}
		RealBlock= GetRealBlock(block);
		//1 Block Read
		for(i= 0; i < NAND_PAGE_PER_BLOCK; i++){
			rc= NAND_ReadPage(RealBlock,i,NandBlockBuff[i]);
			if(rc == 0){	break;	}
			for(j=0;j<100;j++); //wait tWB(100ns)//??????
		}
		//Copy to RAM
		for(i= 0; i < pageCnt; i++){
//			for(j= 0; j < NAND_PAGE_SIZE; j++){			//2012.02.11
			for(j= StartIdx; j < NAND_PAGE_SIZE; j++){
				NandBlockBuff[page][j]= *buffer++;
			}
			page++;
			StartIdx= 0;								//2012.02.11
		}
		while(1){
			//Eraze
			if(NAND_EraseBlock(RealBlock) == 1){	//Erase OK
				for(i= 0; i < NAND_PAGE_PER_BLOCK; i++){
					rc= NAND_WritePage(RealBlock,i,NandBlockBuff[i]);
					if(rc == 0){	break;	}
				}
				if(rc == 1){						//Write OK
					break;
				}
			}
			RealBlock= GetReserveBlock(block);
			ChangeFlag= 1;
			for(j=0;j<100;j++); //wait tWB(100ns)//??????
		}
		len -= pageByteCnt;
		block++;
		page= 0;
		for(j=0;j<100;j++); //wait tWB(100ns)//??????
	}
	if(ChangeFlag == 1){			//MAP Write
//		NAND_Write_Seq(NAND_MAP_AREA/NAND_PAGE_SIZE,(unsigned char*)&NandBadblockMap,0x400);
		NAND_Write_Seq(NAND_MAP_AREA,(unsigned char*)&NandBadblockMap,0x400);
	}
//	if(RealBlock == 0xc82){
//		errFlag= 1;
//	}else{
//		errFlag= 0;
//	}
	return(rc);
}
int NAND_Read_Random(unsigned int fAddr,unsigned char *buffer,int len)
{
	int	i,j;
	unsigned int Sector= fAddr/NAND_PAGE_SIZE;		//2012.02.11
	int	StartIdx= fAddr%NAND_PAGE_SIZE;				//2012.02.11
	int	block= Sector/NAND_PAGE_PER_BLOCK;
	int	page= Sector%NAND_PAGE_PER_BLOCK;
	int	pageCnt;
	int	rc= 1;
	int	RealBlock;

	pageCnt= len/NAND_PAGE_SIZE;
	if(len%NAND_PAGE_SIZE){	pageCnt++;	}
	//Block Read
	for(i= 0; i < pageCnt; ){
		RealBlock= GetRealBlock(block);
//		rc= NAND_ReadPage(RealBlock,page%NAND_PAGE_PER_BLOCK,buffer);
		rc= NAND_ReadPage(RealBlock,page%NAND_PAGE_PER_BLOCK,NandPageBuff);
		if(rc == 0){	break;	}
		if(len <= NAND_PAGE_SIZE){							//2012.02.11
			memcpy(buffer,&NandPageBuff[StartIdx],len);		//2012.02.11
			break;											//2012.02.11
		}													//2012.02.11
		memcpy(buffer,&NandPageBuff[StartIdx],NAND_PAGE_SIZE);	//2012.02.11
		StartIdx= 0;										//2012.02.11
		len-= NAND_PAGE_SIZE;								//2012.02.11
		buffer += NAND_PAGE_SIZE;
		i++;
		page++;
		if((page%NAND_PAGE_PER_BLOCK) == 0){
			block++;
			RealBlock= GetRealBlock(block);
			page= 0;
		}
		for(j=0;j<100;j++); //wait tWB(100ns)//??????
	}
	return(rc);
}
int	CheckStartBlock(int block)
{
	int	i,j;
	int	wBlock;

	if(block > 0){
		for(i= 0,wBlock= 0; ; i++){
			if(NAND_IsBadBlock(i) == 0){
				if(wBlock == block){		//0�@Block ����@�Y��Block Search
					block= i;				//���ۂ�Block
					break;
				}
				wBlock++;
			}
			for(j=0;j<100;j++); //wait tWB(100ns)//??????
		}
	}
	return(block);
}
int NAND_Write_Seq(unsigned int fAddr,unsigned char *buffer,int len)
{
	int	i,j;
	unsigned int Sector= fAddr/NAND_PAGE_SIZE;			//2012.02.11
	int	StartIdx= fAddr%NAND_PAGE_SIZE;					//2012.02.11
	int	block= Sector/NAND_PAGE_PER_BLOCK;
	int	page= Sector%NAND_PAGE_PER_BLOCK;
	int	pageCnt;
	int	pageByteCnt;
	int	rc= 1;

	while(len > 0){
		pageCnt= NAND_PAGE_PER_BLOCK-page;
		pageByteCnt= pageCnt*NAND_PAGE_SIZE;
		if(len <= pageByteCnt){
			pageCnt= len/NAND_PAGE_SIZE;
			if(len%NAND_PAGE_SIZE){	pageCnt++;	}
			pageByteCnt= pageCnt*NAND_PAGE_SIZE;
		}
		block= CheckStartBlock(block);		//Start Block Check
		//1 Block Read
		for(i= 0; i < NAND_PAGE_PER_BLOCK; i++){
			rc= NAND_ReadPage(block,i,NandBlockBuff[i]);
			if(rc == 0){	break;	}
			for(j=0;j<100;j++); //wait tWB(100ns)//??????
		}
		//Copy to RAM
		for(i= 0; i < pageCnt; i++){
//			for(j= 0; j < NAND_PAGE_SIZE; j++){				//2012.02.11
			for(j= StartIdx; j < NAND_PAGE_SIZE; j++){		//2012.02.11
				NandBlockBuff[page][j]= *buffer++;
			}
			page++;
			StartIdx= 0;									//2012.02.11
		}
		while(1){
			//Eraze
			if(NAND_EraseBlock(block) == 1){		//Eraze OK
				for(i= 0; i < NAND_PAGE_PER_BLOCK; i++){
					rc= NAND_WritePage(block,i,NandBlockBuff[i]);
					if(rc == 0){	break;	}						//Write Error
				}
				if(rc == 1){	break;	}			//Write OK
			}
			block++;
		}
		len -= pageByteCnt;
		block++;
		page= 0;
	}
	return(rc);
}
int NAND_Read_Seq(unsigned int fAddr,unsigned char *buffer,int len)
{
	int	i,j;
	unsigned int Sector= fAddr/NAND_PAGE_SIZE;		//2012.02.11
	int	StartIdx= fAddr%NAND_PAGE_SIZE;				//2012.02.11
	int	block= Sector/NAND_PAGE_PER_BLOCK;
	int	page= Sector%NAND_PAGE_PER_BLOCK;
	int	pageCnt;
	int	rc= 1;

	pageCnt= len/NAND_PAGE_SIZE;
	if(len%NAND_PAGE_SIZE){	pageCnt++;	}

	block= CheckStartBlock(block);		//Start Block Check
	//Block Read
	for(i= 0; i < pageCnt; ){
//		rc= NAND_ReadPage(block,page%NAND_PAGE_PER_BLOCK,buffer);	//2012.02.11
		rc= NAND_ReadPage(block,page%NAND_PAGE_PER_BLOCK,NandPageBuff);	//2012.02.11
		if(rc == 0){	break;	}
		if(len <= NAND_PAGE_SIZE){									//2012.02.11
			memcpy(buffer,&NandPageBuff[StartIdx],len);				//2012.02.11
			break;													//2012.02.11
		}															//2012.02.11
		memcpy(buffer,&NandPageBuff[StartIdx],NAND_PAGE_SIZE);		//2012.02.11
		StartIdx= 0;												//2012.02.11
		len-= NAND_PAGE_SIZE;										//2012.02.11
		buffer += NAND_PAGE_SIZE;
		i++;
		page++;
		if((page%NAND_PAGE_PER_BLOCK) == 0){
			block++;
			page= 0;
			while(1){
				if(NAND_IsBadBlock(block) == 0){
					break;
				}
				block++;
				for(j=0;j<100;j++); //wait tWB(100ns)//??????
			}
		}
		for(j=0;j<100;j++); //wait tWB(100ns)//??????
	}
	return(rc);
}

int NAND_Read_ECC(unsigned int fAddr,unsigned char *buffer,int len)
{
	int	i,j;
	unsigned int Sector= fAddr/NAND_PAGE_SIZE;			//2012.02.11
	int	StartIdx= fAddr%NAND_PAGE_SIZE;					//2012.02.11
	int	block= Sector/NAND_PAGE_PER_BLOCK;
	int	page= Sector%NAND_PAGE_PER_BLOCK;
	int	pageCnt;
	int	rc= 1;

	pageCnt= len/NAND_PAGE_SIZE;
	if(len%NAND_PAGE_SIZE){	pageCnt++;	}
	//Block Read
	for(i= 0; i < pageCnt; ){
//		rc= NAND_ReadPage_ECC(block,page%NAND_PAGE_PER_BLOCK,buffer);		//2012.02.11
		rc= NAND_ReadPage_ECC(block,page%NAND_PAGE_PER_BLOCK,NandPageBuff);	//2012.02.11
		if(rc == 0){	break;	}
		if(len <= NAND_PAGE_SIZE){									//2012.02.11
			memcpy(buffer,&NandPageBuff[StartIdx],len);				//2012.02.11
			break;													//2012.02.11
		}															//2012.02.11
		memcpy(buffer,&NandPageBuff[StartIdx],NAND_PAGE_SIZE);		//2012.02.11
		StartIdx= 0;												//2012.02.11
		len-= NAND_PAGE_SIZE;										//2012.02.11
//		buffer += NAND_PAGE_SIZE+16;
		buffer += NAND_PAGE_SIZE+NAND_ECC_SIZE;
		i++;
		page++;
		if((page%NAND_PAGE_PER_BLOCK) == 0){
			block++;
			page= 0;
		}
		for(j=0;j<500;j++); //wait tWB(100ns)//??????

	}
	return(rc);
}
//////////////// End //////////////////////////////////////////////////////////



