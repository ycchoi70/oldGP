
#include <string.h>
#include <stdio.h>
#include "define.h"
#include "s2440.h"


#include "udc_ms.h"
#include "udc_2440.h"




MS_INFO	MsInfo;
PMS_INFO	pMsInfAddr= &MsInfo;


#ifndef MIN
#define MIN(x,y)		((x) < (y) ? (x) : (y))
#endif

//STATIC UINT32 MS_USB_ClearEndpointStall(UINT32 nEndPoint);
static void	OnReset(void);
//==============================================================================================


#define MASS_VID            0x140E
#define MASS_PID            0xB002


#define NUM_ENDPOINTS       2



/*====================================================================================================*/
/*
 * The Device Descriptor.  See the USB Spec for the format.
 */
#define UDC_STANDARD_DESCRIPTOR_TYPE        0x00
#define UDC_DEVICE_DESCRIPTOR_TYPE          0x01
#define UDC_CONFIGURATION_DESCRIPTOR_TYPE   0x02
#define UDC_STRING_DESCRIPTOR_TYPE          0x03
#define UDC_INTERFACE_DESCRIPTOR_TYPE       0x04
#define UDC_ENDPOINT_DESCRIPTOR_TYPE        0x05
#define UDC_POWER_DESCRIPTOR_TYPE           0x06
#define UDC_CLASS_DESCRIPTOR_TYPE           0x20
#define UDC_HID_DESCRIPTOR_TYPE             0x21
#define UDC_REPORT_DESCRIPTOR_TYPE          0x22
#define UDC_PHYSICAL_DESCRIPTOR_TYPE        0x23

#define UDC_ENDPOINT_TYPE_MASK              0x03

#define UDC_ENDPOINT_TYPE_CONTROL           0x00
#define UDC_ENDPOINT_TYPE_ISOCHRONOUS       0x01
#define UDC_ENDPOINT_TYPE_BULK              0x02
#define UDC_ENDPOINT_TYPE_INTERRUPT         0x03

#define UDC_CLASS_CODE_MASSSTORAGE_CLASS_DEVICE     0x08

#define UDC_SUBCLASS_CODE_RBC               0x01
#define UDC_SUBCLASS_CODE_SFF8020I          0x02
#define UDC_SUBCLASS_CODE_QIC157            0x03
#define UDC_SUBCLASS_CODE_UFI               0x04
#define UDC_SUBCLASS_CODE_SFF8070I          0x05
#define UDC_SUBCLASS_CODE_SCSI              0x06

#define UDC_PROTOCOL_CODE_CBI0              0x00
#define UDC_PROTOCOL_CODE_CBI1              0x01
#define UDC_PROTOCOL_CODE_BULK              0x50



/* Mass Storage Class definition ref. S3.1*/
#define UDC_MSD_CLASS_RESET                 0xFF
#define UDC_MSD_CLASS_GET_MAXLUN            0xFE

#define UDC_MSD_RESET                       ((UDC_MSD_CLASS_RESET<<8)|UDC_REQUEST_TYPE_CLASS|UDC_REQUEST_RECIPIENT_INTERFACE|UDC_REQUEST_DIRECTION_H2D)
#define UDC_MSD_GET_MAXLUN                  ((UDC_MSD_CLASS_GET_MAXLUN<<8)|UDC_REQUEST_TYPE_CLASS|UDC_REQUEST_RECIPIENT_INTERFACE|UDC_REQUEST_DIRECTION_D2H)

/* Standard Feature Selector ref */
#define UDC_DEVICE_REMOTE_WAKEUP            (0x0001)
#define UDC_ENDPOINT_HALT                   (0x0000)

/* Standard USB Device Requests ref 9.3*/
/* bmRequestType bitmap */
#define UDC_REQUEST_RECIPIENT_MASK          (0x1F)  // D[4,0]
#define UDC_REQUEST_RECIPIENT_SHIFT         (0)
    #define UDC_REQUEST_RECIPIENT_DEVICE            (0x00<<UDC_REQUEST_RECIPIENT_SHIFT)
    #define UDC_REQUEST_RECIPIENT_INTERFACE         (0x01<<UDC_REQUEST_RECIPIENT_SHIFT)
    #define UDC_REQUEST_RECIPIENT_ENDPOINT          (0x02<<UDC_REQUEST_RECIPIENT_SHIFT)
    #define UDC_REQUEST_RECIPIENT_OTHER             (0x03<<UDC_REQUEST_RECIPIENT_SHIFT)
#define UDC_REQUEST_TYPE_MASK               (0x60)  // D[6,5]
#define UDC_REQUEST_TYPE_SHIFT              (5)
    #define UDC_REQUEST_TYPE_STANDARD               (0x00<<UDC_REQUEST_TYPE_SHIFT)
    #define UDC_REQUEST_TYPE_CLASS                  (0x01<<UDC_REQUEST_TYPE_SHIFT)
    #define UDC_REQUEST_TYPE_VENDOR                 (0x02<<UDC_REQUEST_TYPE_SHIFT)
#define UDC_REQUEST_DIRECTION_MASK          (0x80)  // D[7]
#define UDC_REQUEST_DIRECTION_SHIFT         (7)
    #define UDC_REQUEST_DIRECTION_H2D               (0x00<<UDC_REQUEST_DIRECTION_SHIFT)
    #define UDC_REQUEST_DIRECTION_D2H               (0x01<<UDC_REQUEST_DIRECTION_SHIFT)

/* 'Standard USB Device Requests' Request Codes (bRequest) ref T9.3 */
#define UDC_GET_STATUS                      (0x0000)
#define UDC_CLEAR_FEATURE                   (0x0001)
#define UDC_SET_FEATURE                     (0x0003)
#define UDC_SET_ADDRESS                     (0x0005)
#define UDC_GET_DESCRIPTOR                  (0x0006)
#define UDC_SET_DESCRIPTOR                  (0x0007)
#define UDC_GET_CONFIGURATION               (0x0008)
#define UDC_SET_CONFIGURATION               (0x0009)
#define UDC_GET_INTERFACE                   (0x000A)
#define UDC_SET_INTERFACE                   (0x000B)
#define UDC_SYNC_FRAME                      (0x000C)



typedef struct _UDC_DEVICE_DESCRIPTOR_
{
   BYTE         Length;                         // length: size in BYTEs           
   BYTE         DescriptorType;                 // descriptor type  
   USHORT       Version;                        // USB version in BCD type
   BYTE         DeviceClass;                    // device class     
   BYTE         DeviceSubclass;                 // device subclass  
   BYTE         DeviceProtocol;                 // device protocol  
   BYTE         MaxPacketSize;                  // maximum packet size  
   USHORT       VendorId;                       // vendor id
   USHORT       ProductId;                      // product id
   USHORT       DeviceId;                       // device id in BCD type
   BYTE         iManufacture;                   // manufacturer: index to string descriptor
   BYTE         iProduct;                       // product: index to string descriptor
   BYTE         iSerial;                        // serial number: index to string descriptor
   BYTE         n_Configuration;                // number of configurations

} UDC_DEVICE_DESCRIPTOR, *UDC_PDEVICE_DESCRIPTOR;

/*
 * The Configuration Descriptor.  See the USB Spec for the format.
 */
typedef struct _UDC_CONFIGURATION_DESCRIPTOR_
{
    BYTE        Length;                         // length in BYTEs           
    BYTE        DescriptorType;                 // descriptor type  
    USHORT      TotalLength;                    // total length: in BYTEs
    BYTE        n_Interfaces;                   // number of interfaces
    BYTE        Configuration;                  // configuration value
    BYTE        iConfiguration;                 // index of configuration
    BYTE        Attributes;                     // attributes
    BYTE        MaxPower;                       // maximun power: in 2mA units

} UDC_CONFIGURATION_DESCRIPTOR, *UDC_PCONFIGURATION_DESCRIPTOR;


/*
 * The Interface Descriptor.  See the USB Spec for the format.
 */
typedef struct _UDC_INTERFACE_DESCRIPTOR_
{
    BYTE        Length;                         // length: size in BYTEs
    BYTE        DescriptorType;                 // descriptor type
    BYTE        n_Interface;                    // interface number
    BYTE        AlternateSetting;               // alternate setting
    BYTE        n_Endpoints;                    // number of endpoints
    BYTE        InterfaceClass;                 // interface class
    BYTE        InterfaceSubclass;              // interface subclass
    BYTE        InterfaceProtocol;              // interface protocol
    BYTE        iInterface;                     // index of interface

} UDC_INTERFACE_DESCRIPTOR, *UDC_PINTERFACE_DESCRIPTOR;


/*
 * The Endpoint Descriptor.  See the USB Spec for the format.
 */
typedef struct _UDC_ENDPOINT_DESCRIPTOR_
{
    BYTE        Length;                         // length: size in BYTEs
    BYTE        DescriptorType;                 // descriptor type
    BYTE        EpAddress;                      // endpoint address
    BYTE        Attributes;                     // attributes
    USHORT      MaxPacketSize;                  // maximum packet size
    BYTE        Interval;                       // interval

} UDC_ENDPOINT_DESCRIPTOR, *UDC_PENDPOINT_DESCRIPTOR;

/*
 * The String Descriptor.  See the USB Spec for the format.
 */
typedef struct _UDC_STRING_DESCRIPTOR_
{
    BYTE        Length;                         // length: size in BYTEs
    BYTE        DescriptorType;                 // descriptor type
    BYTE        n_String;                         // UNICODE encoded string

} UDC_STRING_DESCRIPTOR, *UDC_PSTRING_DESCRIPTOR;

typedef CONST struct _UDC_STRING_LANGUAGE_DESCRIPTOR_
{
    BYTE        bLength;
    BYTE        bDescriptorType;
	UINT16      ulanguageID[2];
} UDC_STRING_LANGUAGE_DESCRIPTOR;

typedef struct _UDC_STRING_INTERFACE_DESCRIPTOR
{
    BYTE        bLength;
    BYTE        bDescriptorType;
    BYTE        Interface[22];
} UDC_STRING_INTERFACE_DESCRIPTOR;

typedef struct _UDC_STRING_CONFIGURATION_DESCRIPTOR_
{
    BYTE        bLength;
    BYTE        bDescriptorType;
    BYTE        Configuration[16];
} UDC_STRING_CONFIGURATION_DESCRIPTOR;


#define UDC_LENGTH_SERIALNUMBER		16

typedef CONST struct _UDC_STRING_SERIALNUMBER_DESCRIPTOR_
{
    BYTE        bLength;
    BYTE        bDescriptorType;
    BYTE        SerialNum[UDC_LENGTH_SERIALNUMBER*2];
} UDC_STRING_SERIALNUMBER_DESCRIPTOR;

typedef CONST struct _UDC_STRING_PRODUCT_DESCRIPTOR_
{
    BYTE        bLength;
    BYTE        bDescriptorType;
    BYTE        Product[36];
} UDC_STRING_PRODUCT_DESCRIPTOR;

typedef CONST struct _UDC_STRING_MANUFACTURER_DESCRIPTOR_
{
    BYTE        bLength;
    BYTE        bDescriptorType;
    BYTE        Manufacturer[26];
} UDC_STRING_MANUFACTURER_DESCRIPTOR;

typedef struct _MS_CONFIGURATION_DESCRIPTOR_
{
   // Configuration Descriptor
   UDC_CONFIGURATION_DESCRIPTOR     Configuration;

   // Interface Descriptor
   UDC_INTERFACE_DESCRIPTOR         Interface;
   
   // End Point Descriptor
   UDC_ENDPOINT_DESCRIPTOR          RxEP;
   UDC_ENDPOINT_DESCRIPTOR          TxEP;

}MS_CONFIGURATION_DESCRIPTOR, *MS_PCONFIGURATION_DESCRIPTORR;

#define UDCMASS_EP_RECV                     2           // OUT	(PC  -> UDC)
#define UDCMASS_EP_XMIT                     1           // IN	(UDC -> PC)

#define UDCMASS_RECV_PACKET_SIZE            EP2_PACKET_SIZE
#define UDCMASS_XMIT_PACKET_SIZE            EP1_PACKET_SIZE

/************************************************************************
*    CONSTANT DEFINE
************************************************************************/
UDC_DEVICE_DESCRIPTOR gMASS_DeviceDescriptor = 
{
    sizeof(UDC_DEVICE_DESCRIPTOR),      // bLength
    UDC_DEVICE_DESCRIPTOR_TYPE,         // bDescriptorType
    0x0110,                             // bcdUSB
    0,                                  // bDeviceClass
    0,                                  // bDeviceSubClass
    0,                                  // bDeviceProtocol
    EP0_PACKET_SIZE,                    // bMaxPacketSize0
    MASS_VID,                           // idVendor
    MASS_PID,                           // idProduct
    0x0100,                             // bcdDevice
    1,    //STR_INDEX_MANUFACTURER,     // iManufacturer
    2,    //STR_INDEX_PRODUCT,          // iProduct
    3,    //STR_INDEX_SERIALNUMBER,     // iSerialNumber
    1                                   // bNumConfigurations
};

UDC_STRING_LANGUAGE_DESCRIPTOR gStrLanguage =
{
    sizeof(UDC_STRING_LANGUAGE_DESCRIPTOR),
    UDC_STRING_DESCRIPTOR_TYPE,
    {
        0x0412,            // Korean
        0x0409,            // English
    }
};

UDC_STRING_MANUFACTURER_DESCRIPTOR gStrManufacturer =
{
    sizeof(UDC_STRING_MANUFACTURER_DESCRIPTOR),
    UDC_STRING_DESCRIPTOR_TYPE,
    {
        'A', 0,
        'C', 0,
        'R', 0,
        'O', 0,
        'T', 0,
        'E', 0,
        'L', 0,
        'E', 0,
        'C', 0,
        'O', 0,
        'M', 0,
        ' ', 0,
        ' ', 0
    }
};

UDC_STRING_PRODUCT_DESCRIPTOR gStrProduct =
{
    sizeof(UDC_STRING_PRODUCT_DESCRIPTOR),
    UDC_STRING_DESCRIPTOR_TYPE,
    {
        'M', 0,
        'E', 0,
        'M', 0,
        'O', 0,
        'R', 0,
        'Y', 0,
        'D', 0,
        'I', 0,
        'S', 0,
        'K', 0,
        ' ', 0,
        'A', 0,
        'd', 0,
        'a', 0,
        'p', 0,
        't', 0,
        'e', 0,
        'r', 0
    }
};

UDC_STRING_SERIALNUMBER_DESCRIPTOR gStrSerialNum =
{
    sizeof(UDC_STRING_SERIALNUMBER_DESCRIPTOR),
    UDC_STRING_DESCRIPTOR_TYPE,
    {
        '0',0,
        '0',0,
        '0',0,
        '0',0,

        '0',0,
        '0',0,
        '0',0,
        '0',0,

        '0',0,
        '0',0,
        '0',0,
        '0',0,

        '0',0,
        '0',0,
        '0',0,
        '0',0
    }
};

//static const BYTE gMASSConfigurationDescriptorType[TLEN] =
//{
    // configuration descriptor
//        9,               // bLength
//        UDC_CONFIGURATION_DESCRIPTOR_TYPE,                  // bDescriptorType
//        0x20,0x00,         //wTotalLength
//        1,                                                  // bNumInterfaces
//        1,                                                  // bConfigurationValue
//        0,                                                  // iConfiguration, index of config. string
//        0xc0,                                               // bmAttributes, Self-powered and No Remote-Wakeup
//        45,                                                  // MaxPower, 2mA unit, 90mA for TCC730
    
    // interface descriptor
//        9,                   // bLength
//        UDC_INTERFACE_DESCRIPTOR_TYPE,                      // bDescriptorType
//        0,                                                  // bInterfaceNumber
//        0,                                                  // bAlternateSetting
//        NUM_ENDPOINTS,                                      // bNumEndpoints
//        UDC_CLASS_CODE_MASSSTORAGE_CLASS_DEVICE,            // bInterfaceClass
//        UDC_SUBCLASS_CODE_SCSI,                             // bInterfaceSubClass
//        UDC_PROTOCOL_CODE_BULK,                             // bInterfaceProtocol
//        0,                                                   // iInterface
    
    // endpoint descriptor EP1=In(Send)
//		7,                   // bLength
//        UDC_ENDPOINT_DESCRIPTOR_TYPE,                       // bDescriptorType
//        UDC_REQUEST_DIRECTION_D2H | UDCMASS_EP_XMIT,        // bEndpointAddress, dir | ep_index
//        UDC_ENDPOINT_TYPE_BULK,                             // bmAttributes
//        0x40,0x00,                           // wMaxPacketSize
//        0,                                                   // bInterval

    // endpoint descriptor EP2=Out(Recv)
//		7,                   // bLength
//        UDC_ENDPOINT_DESCRIPTOR_TYPE,                       // bDescriptorType
//        UDC_REQUEST_DIRECTION_H2D | UDCMASS_EP_RECV,        // bEndpointAddress, dir | ep_index
//        UDC_ENDPOINT_TYPE_BULK,                             // bmAttributes
//        0x40,0x00,                           // wMaxPacketSize
//        0,                                                   // bInterval
//};

//#define CONFIG_DESCRIPTOR_LENGTH    (sizeof(UDC_CONFIGURATION_DESCRIPTOR)+ sizeof(UDC_INTERFACE_DESCRIPTOR)+(NUM_ENDPOINTS * sizeof(UDC_ENDPOINT_DESCRIPTOR)))


//============================================================
// Languages Supported by the Device
//============================================================
static const BYTE LanguagesStringDescriptor[] =
{
    // String index zero for all languages returns a string descriptor taht
    // contains an 
    // array to two-byte LANGID codes supported by the device.  LANGID is
    // defined by the 
    // Microsoft for Windows as described in Developing International
    // Software for Windows.
    
    4,                 	        // Length of descriptor  
    STRING_DESCRIPTOR,          // Descriptor Type   
    0x09, 0x04                  // LANGID (English) 
};

//============================================================
// Define the configuration descriptor itself
//============================================================

static const BYTE uStd[TLEN]=  
{
    18,                 			// bLength
    DEVICE,             			// bDescriptorType
    0x10,0x01,               			// bcdUSB (compliant with V1.1)
    0xf1,               			    // bDeviceClass 
    0xf2,               			    // bDeviceSubClass
    0xf3,               			    // bDeviceProtocol
    EP0_PACKET_SIZE,        		// ??bMaxPacketSize0 EP0Len EP0Len
#ifdef	USB_COMM
    0xff, 0x0e,          			// idVendor (Samsung's VID - 0x04E8) 
    0xff, 0x03,         			// idProduct (Assigned PID - 0x6613 ) 
    0x07, 0x00,               			// bcdDevice
#else
    0xbb, 0x04,          			// idVendor (Samsung's VID - 0x04E8) 
    0x43, 0x0c,         			// idProduct (Assigned PID - 0x6613 ) 
    0x00, 0x01,               			// bcdDevice
#endif
    0x01,				 	    // iManufacturer - index of Manf String Descriptor
    0x02,						// iProduct - index of Product String Descriptor
    0x03,                  			// iSerialNumber - Index of Serial Number String
    0x01,                  			// bNumConfigurations

    /* std_config */
    9,                  			// bLength
    CONFIGURATION,      		    // bDescriptorType
    CFGLEN%256,CFGLEN/256,          // wTotalLength
    1,                 				// bNumInterfaces
    1,                  			// bConfigurationValue
    0x40,                  			// iConfiguration
    0x80,               			// bmAttributes (although remote wakeup capable, not supported)
    0x32,                  			// 0??MaxPower (x2 mA)  (Is this correct?)

    /* std_inter */
    9,                 	            // bLength
    INTERFACE,  	                // bDescriptorType
    0,                  	        // bInterfaceNumber
    0,                  	        // bAlternateSetting
    3,                  	        // bNumEndpoints (number endpoints used, excluding EP0)
#ifdef	USB_COMM
    0x02,            	            // bInterfaceClass
    0x00,        	                // bInterfaceSubClass
    0x00,         	                // bInterfaceProtocol
#else
    0x08,            	            // bInterfaceClass
    0x06,        	                // bInterfaceSubClass
    0x50,         	                // bInterfaceProtocol
#endif
    0x60,                  	        // ilInterface  (Index of this interface string desc.)
    	
    /* endpoint1 - IN */
    7,                 	            // bLength
    ENDPOINT,    	                // bDescriptorType
    0x81,                           // bEndpointAddress (10000010 = IN, EP 1)
    2,                  	        // bmAttributes  (Bulk)
    EP1_PACKET_SIZE, 0,     	                // wMaxPacketSize
    0,                  	        // bInterval (ignored for Bulk)
    	
    /* endpoint2 - Out */
    7,                  	        // bLength
    ENDPOINT,    	                // bDescriptorType
    2,                  	        // bEndpointAddress (00000010 = OUT, EP 2)
    2,                  	        // bmAttributes  (Bulk)
    EP2_PACKET_SIZE, 0,                      // wMaxPacketSize
    0,                  	        // bInterval (ignored for Bulk)

    /* endpoint3 - Interrupt */
    7,                  	        // bLength
    ENDPOINT,    	                // bDescriptorType
    0x83,                  	        // bEndpointAddress (10000011 = OUT, EP 3)
    0x03,                  	        // bmAttributes  (Interrupt)
    EP3_PACKET_SIZE, 0,                      // wMaxPacketSize
    1,                  	        // bInterval 
};


//============================================================
// Model String "MITS M7000"
//============================================================
static const  BYTE ProductStringDescriptor[] =
{
    22,                             // Length of descriptor
    STRING_DESCRIPTOR,      	    // Descriptor Type
    'M',  0x00,               		// String in unicode
    'I',  0x00,
    'T',  0x00,
    'S',  0x00,
    ' ',  0x00,
    'M',  0x00,              	 	// String in unicode
    '7',  0x00,
    '0',  0x00,
    '0',  0x00,
    '0',  0x00,
};


//============================================================
// Manufacture String Descriptor - "Samsung"
//============================================================
static const BYTE ManufactureStringDescriptor[] =
{
    16,                             // Length of descriptor 
    STRING_DESCRIPTOR,              // Descriptor Type
    'S', 0x00,                      // String in unicode
    'a', 0x00,
    'm', 0x00,
    's', 0x00,
    'u', 0x00,
    'n', 0x00,
    'g', 0x00,
};
static const  BYTE SirialStringDescriptor[] =
{
    42,                             // Length of descriptor
    STRING_DESCRIPTOR,      	    // Descriptor Type
    '0',  0x00,               		// String in unicode
    '0',  0x00,
    '0',  0x00,
    '8',  0x00,
    '0',  0x00,
    '1',  0x00,              	 	// String in unicode
    '2',  0x00,
    '5',  0x00,
    'A',  0x00,
    '3',  0x00,
    '0',  0x00,
    '0',  0x00,
    '0',  0x00,
    '0',  0x00,
    '0',  0x00,
    '0',  0x00,
    '1',  0x00,
    '3',  0x00,
    '1',  0x00,
    '0',  0x00,
};

//============================================================
// Variable 
//============================================================


//#define CTRLR_BASE_REG_ADDR(offset) ((volatile PUINT32)(UDC_BASE + 0x140 + (offset)))
#define CTRLR_BASE_REG_ADDR(offset) ((PUINT32)(UDC_BASE + 0x140 + (offset)))
#define UDC_READ_REG(a)             (*CTRLR_BASE_REG_ADDR(a))
#define UDC_WRITE_REG(a,b)          (*CTRLR_BASE_REG_ADDR(a) = (b))

// Calling with dwMask = 0 and SET reads and writes the contents unchanged.
//INLINE UINT32
//__inline UINT32
UINT32
UDC_MASK_REG (UINT32 nOffset, UINT32 Mask, BOOL bSet)
{
    UINT32  vRet;
    VOLATILE UINT32 *pReg = CTRLR_BASE_REG_ADDR(nOffset);

    vRet = *pReg;
    if (bSet)   vRet |=  Mask;
    else        vRet &= ~Mask;

    *pReg = vRet;

    return vRet;
}

// Calling with dwMask = 0 and SET reads and writes the contents unchanged.
//INLINE UINT32
//__inline UINT32
UINT32
UDC_MASK_INDEX_REG (UINT32 nEndPoint, UINT32 nOffset, UINT32 Mask, BOOL bSet)
{
    UINT32  vRet = 0;

    UDC_WRITE_REG (IDXADDR_REG_OFFSET, nEndPoint);
    vRet = UDC_MASK_REG (nOffset, Mask, bSet);

    return vRet;
}


// Read an indexed register.
//INLINE UINT32
//__inline UINT32
UINT32
UDC_READ_INDEX_REG (UINT32 nEndPoint, UINT32 nOffset)
{
    UINT32  vRet;
    UDC_WRITE_REG(IDXADDR_REG_OFFSET, nEndPoint);
    vRet = UDC_READ_REG(nOffset);
    
    return vRet;
}


// Write an indexed register.
//INLINE VOID
//__inline VOID
VOID
UDC_WRITE_INDEX_REG(UINT32 nEndPoint, UINT32 nOffset, UINT32 Val)
{  
    UDC_WRITE_REG(IDXADDR_REG_OFFSET, nEndPoint);
    UDC_WRITE_REG(nOffset, Val);
}


/*==================================================================================*/

STATIC VOID
MS_USB_SetAddress(BYTE  Address)
{
    // Make sure that the Address Update bit is set (0x80)
    UDC_WRITE_REG(SET_ADDRESS_REG_OFFSET, (0x80 | Address));

    UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, DATA_END);

}

//STATIC INLINE VOID
STATIC __inline VOID
ClearEndPointInterrupt(UINT32 nEndPoint)
{    
    // Clear the Endpoint Interrupt
    UDC_WRITE_REG(EP_INT_REG_OFFSET, 1<<nEndPoint);

    return;
}

//STATIC INLINE VOID
//STATIC __inline VOID
//SetEndPointInterrupt (UINT32 nEndPoint, BOOL bEnable)
//{
    // Disable the Endpoint Interrupt
//    UINT32 EpIntReg = UDC_READ_REG(EP_INT_EN_REG_OFFSET);

//    if (bEnable)
//        EpIntReg |= 1<<nEndPoint;
//    else
//        EpIntReg &= ~(1<<nEndPoint);

//    UDC_WRITE_REG (EP_INT_EN_REG_OFFSET, EpIntReg);

//    return;
//}

//================================= ENDPOINT ======================================================

PUBLIC UINT32 
MS_USB_StallEndPoint( PMS_INFO pMsInfo, UINT32 dwFlags )
{

    if( dwFlags == CONTROL_TRANSFER )
    {
        // Must Clear Out Packet Ready when sending Stall
        UINT32  Ep0StallBits = (DATA_END | SERVICED_OUT_PKT_RDY | EP0_SEND_STALL);
        UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, Ep0StallBits);
    }
    else
    if( dwFlags == IN_TRANSFER )
    {
        UDC_MASK_INDEX_REG(0, IN_CSR1_REG_OFFSET, (IN_SEND_STALL), TRUE);
    }
    else
    if( dwFlags == OUT_TRANSFER )
    {
        // Must Clear Out Packet Ready when sending Stall
        UDC_MASK_INDEX_REG(0, OUT_CSR1_REG_OFFSET, (OUT_SEND_STALL), TRUE);
        UDC_MASK_INDEX_REG(0, OUT_CSR1_REG_OFFSET, (OUT_PACKET_READY), FALSE);
    }

    return ERROR_SUCCESS;
}


// Clear an endpoint stall.
//STATIC UINT32 
//MS_USB_ClearEndpointStall(UINT32 nEndPoint)
//{
//    if (nEndPoint == CONTROL_TRANSFER)
//    {
        // Must Clear both Send and Sent Stall
//        UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, 0);
//    }
//    else
//    if (nEndPoint == IN_TRANSFER)
//    {
//        UDC_MASK_INDEX_REG(nEndPoint, IN_CSR1_REG_OFFSET, (IN_SEND_STALL | IN_CLR_DATA_TOGGLE ), TRUE);

        // Must Clear both Send and Sent Stall
//        UDC_MASK_INDEX_REG(nEndPoint, IN_CSR1_REG_OFFSET, (IN_SEND_STALL  | IN_SENT_STALL), FALSE);               
//    }
//    else
//    { // Out Endpoint
        // Must Clear both Send and Sent Stall
//        UDC_MASK_INDEX_REG(nEndPoint, OUT_CSR1_REG_OFFSET, ( OUT_SEND_STALL | OUT_CLR_DATA_TOGGLE ), TRUE);
//        UDC_MASK_INDEX_REG(nEndPoint, OUT_CSR1_REG_OFFSET, ( OUT_SEND_STALL  | OUT_SENT_STALL), FALSE);
//    }

//    return ERROR_SUCCESS;
//}


/*==================================================================================*/
/*========================== FROM HERE, interrupt management =======================*/
/*==================================================================================*/
//PUBLIC UDC_INTERRUPT_TYPE 
UINT32	MS_USB_GetInterruptType( void )
{
    UINT32  fInterrupt = 0;
	volatile	UINT32	EP2IrqStatus2;
	volatile	UINT32	EP2IrqStatus1;

    UINT32  EpIrqStat = UDC_READ_REG(EP_INT_REG_OFFSET);
    UINT32  USBIrqStat = UDC_READ_REG(USB_INT_REG_OFFSET);


	if (USBIrqStat & USB_RESET_INTR){
		fInterrupt |= UDC_INTR_RESET;
	}
	if (USBIrqStat & USB_SUSPEND_INTR){
		fInterrupt |= UDC_INTR_SUSPEND;
	}
	if (USBIrqStat & USB_RESUME_INTR){
		fInterrupt |= UDC_INTR_RESUME;
	}
	if (EpIrqStat & EP0_INT_INTR){
        fInterrupt |= UDC_INTR_SETUP;
    }
	if (EpIrqStat & EP1_INT_INTR){		//Input
		EP2IrqStatus1 = UDC_READ_INDEX_REG (OUT_TRANSFER, OUT_CSR1_REG_OFFSET);
		EP2IrqStatus2 = UDC_READ_INDEX_REG (OUT_TRANSFER, OUT_CSR2_REG_OFFSET);
        fInterrupt |= UDC_INTR_RX;  
		UDC_WRITE_REG(EP_INT_REG_OFFSET,EpIrqStat);
	}
	if (EpIrqStat & EP2_INT_INTR){		//Output
		EP2IrqStatus1 = UDC_READ_INDEX_REG (OUT_TRANSFER, OUT_CSR1_REG_OFFSET);
		EP2IrqStatus2 = UDC_READ_INDEX_REG (OUT_TRANSFER, OUT_CSR2_REG_OFFSET);
        fInterrupt |= UDC_INTR_TX;
		UDC_WRITE_REG(EP_INT_REG_OFFSET,EpIrqStat);
	}
    if (EpIrqStat & EP3_INT_INTR){
        fInterrupt |= (1<<3);
    }
    if (EpIrqStat & EP4_INT_INTR){
        fInterrupt |= (1<<4);
	}
	return fInterrupt;
}

/*
 * MS_USB_ResetHandler
 *
 * This handler is called for reset interrupts
 */
VOID MS_USB_ResetHandler(PMS_INFO pMsInfo)
{
 
    OnReset();

    UDC_STATE(pMsInfo) = WAIT_FOR_SETUP;
	
}


/*
 * MS_USB_TxIntHandler
 *
 * Read characters up to the max packet length from the IN FIFO. Return the
 * number of characters read in the supplied argument. The function returns
 * a boolean indicating whether event characters are present.
 */

UINT32 XmitData(PBYTE pBuffer, UINT32 BufLen)
{
    UINT32  i;
    volatile UINT32  Csr;
    UINT32  nXmit;
	UINT32  EP2IrqStatus1;

//    VOLATILE PBYTE pFifoReg = (VOLATILE PBYTE)CTRLR_BASE_REG_ADDR(EP1_FIFO_REG_OFFSET);
    VOLATILE PBYTE pFifoReg = (PBYTE)CTRLR_BASE_REG_ADDR(EP1_FIFO_REG_OFFSET);

	while(1){
		EP2IrqStatus1 = UDC_READ_INDEX_REG (IN_TRANSFER, IN_CSR1_REG_OFFSET);
		if ((EP2IrqStatus1 & 0x01) == 0){
			break;
		}
	}

    Csr = UDC_READ_INDEX_REG (IN_TRANSFER, IN_CSR1_REG_OFFSET);

    if (EP1_PACKET_SIZE <= BufLen)
        nXmit = EP1_PACKET_SIZE;
    else
        nXmit = BufLen;    

    for (i = 0; i < nXmit; i++)
        *pFifoReg = *pBuffer++;

    UDC_WRITE_INDEX_REG(IN_TRANSFER, IN_CSR1_REG_OFFSET, IN_PACKET_READY);

    return nXmit;
}
UINT32 MS_USB_TxIntHandler(PBYTE pTxBuffer, UINT32 *pBufLen)
{
	UINT32	len;
	len= XmitData(pTxBuffer,*pBufLen);
	*pBufLen= len;
    return len;
}


/*
 * MS_USB_RxIntHandler
 *
 * Read characters up to the max packet length from the IN FIFO. Return the
 * number of characters read in the supplied argument. The function returns
 * a boolean indicating whether event characters are present.
 */

UINT32 MS_USB_RxIntHandler(PMS_INFO pMsInfo,
						 PBYTE pRxBuffer,
						 UINT32 *pBuffLen) 
{
	UINT32	CompleteFlag;
    INT32 BufLen = (INT32)*pBuffLen;
    UINT32  Csr;
	int		i;
    int		nFifo;
    

//	VOLATILE PBYTE pFifoReg = (VOLATILE PBYTE)CTRLR_BASE_REG_ADDR(EP2_FIFO_REG_OFFSET);
	VOLATILE PBYTE pFifoReg = (PBYTE)CTRLR_BASE_REG_ADDR(EP2_FIFO_REG_OFFSET);

    Csr = UDC_READ_INDEX_REG (OUT_TRANSFER, OUT_CSR1_REG_OFFSET);

    nFifo = UDC_READ_INDEX_REG (OUT_TRANSFER, OUT_FIFO_CNT1_REG_OFFSET);
	CompleteFlag= 0;
    if (nFifo <= BufLen){
		CompleteFlag= 1;
        *pBuffLen = nFifo;
	}else{
        nFifo = *pBuffLen;    
	}
    for(i= 0; i < nFifo; i++)
        pRxBuffer[i] = (BYTE) *pFifoReg;

    Csr &= ~OUT_PACKET_READY;
    UDC_WRITE_INDEX_REG (OUT_TRANSFER, OUT_CSR1_REG_OFFSET, Csr);

    return CompleteFlag;

}

/*==================================================================================*/
/*============================= FROM HERE, EP0 management ==========================*/
/*==================================================================================*/


/*----------------------------------------------------------------------------
 *	XmitEP0OneByte
 *
 *	Transmits data to EP0.  This makes sure that we don't have a premature
 *	status stage.
 *----------------------------------------------------------------------------*/
VOID XmitEP0OneByte( PMS_INFO pMsInfo, BYTE Byte )
{
//    volatile PBYTE pFifoReg = (volatile PBYTE)CTRLR_BASE_REG_ADDR(EP0_FIFO_REG_OFFSET);
    volatile PBYTE pFifoReg = (PBYTE)CTRLR_BASE_REG_ADDR(EP0_FIFO_REG_OFFSET);

	// Check for premature status stage.
    //    return;

	// Is there a stall?
    //    return;

    // send data
    *pFifoReg = Byte;
    UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, EP0_IN_PACKET_RDY|DATA_END);

    return;

}

/*----------------------------------------------------------------------------
 *	XmitEP0Data
 *
 *	Transmits data to EP0.  This makes sure that we don't have a premature
 *	status stage.
 *----------------------------------------------------------------------------*/
VOID XmitEP0Data( PMS_INFO pMsInfo )
{
	int     nXferCount;
  	int     nIndex;
	PBYTE   pData;
	INT32   i;
	int		bEndPacket= 0;
//	UINT32	EP0IrqStatus;

//    volatile PBYTE pFifoReg = (volatile PBYTE)CTRLR_BASE_REG_ADDR(EP0_FIFO_REG_OFFSET);
    volatile PBYTE pFifoReg = (PBYTE)CTRLR_BASE_REG_ADDR(EP0_FIFO_REG_OFFSET);
	
	// The ParseSetup has already setup the structure to determine how much
	// data to send.  Determine if this is the last data packet.
	if( pMsInfo->nXmitLength <= EP0_PACKET_SIZE ) 
	{						
		nXferCount = pMsInfo->nXmitLength;
		bEndPacket= 1;

    } 
	else
	{
		// More data to send 
		UDC_STATE( pMsInfo ) = DATA_STATE_XMIT;
		nXferCount = EP0_PACKET_SIZE;
	}

	// Get the current index from the state structure and shove the data
	// into the FIFO's.  Adjust the remaining length
	nIndex = pMsInfo->nXmitIndex;
	//pData  = pMsInfo->pXmitData;
	pMsInfo->nXmitIndex = nIndex+nXferCount;
	pMsInfo->nXmitLength -= nXferCount;

	//
	// Write to the FIFO directly to send the bytes.
	//
	pData  = pMsInfo->pXmitData + nIndex;

	for (i = 0; i < nXferCount; i++)
	{
		*pFifoReg = *pData++;
	}

	if (bEndPacket)
        UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, EP0_IN_PACKET_RDY|DATA_END); //SERVICED_OUT_PKT_RDY
    else
        UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, EP0_IN_PACKET_RDY); //SERVICED_OUT_PKT_RDY
	// switch states to OUT STATUS (or Handshake) WAIT
	// when the transmission is done.
	// the transmission is done when:
	//		the transmitted length equals the requested length, or
	//		there are no more bytes to send. (in this case, a 0 length
	//		packet would have just been transmitted.)

	// switch states to OUT STATUS (or Handshake) WAIT
	// when the transmission is done.
	// the transmission is done when:
	//		the transmitted length equals the requested length, or
	//		there are no more bytes to send. (in this case, a 0 length
	//		packet would have just been transmitted.)
	if( pMsInfo->nXmitIndex == pMsInfo->nXmitReq )
	{
		UDC_STATE( pMsInfo ) = WAIT_FOR_OUT_STATUS;
	}

    if (nXferCount == 0)
	{
//        UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, EP0_IN_PACKET_RDY|DATA_END);
		UDC_STATE( pMsInfo ) = WAIT_FOR_OUT_STATUS;
	}
	else
	if (pMsInfo->nXmitLength==0)
	{
//        UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, EP0_IN_PACKET_RDY|DATA_END);
		UDC_STATE( pMsInfo ) = WAIT_FOR_OUT_STATUS;
	}
	else
	{
    }

    return;

}


STATIC BOOL
UsbRequestGetStringDescriptor( UINT16 wValue, BYTE **txDatP, BYTE *txDatLen )
{
    UINT16      descriptorIndex;
    PBYTE       stringDescriptor;
    
    descriptorIndex = USBData_LowByte (wValue);    // get the descriptor index in the low byte
    if ( descriptorIndex <= lastStringIndex )
    {
        switch (descriptorIndex)
        {
        case languagesStringIndex:
            stringDescriptor = (PBYTE)LanguagesStringDescriptor;
//            stringDescriptor = (PBYTE)&gStrLanguage;
            break;
        case manufactureStringIndex:
            stringDescriptor = (PBYTE)ManufactureStringDescriptor;
//            stringDescriptor = (PBYTE)&gStrManufacturer;
            break;
        case productStringIndex:
            stringDescriptor = (PBYTE)ProductStringDescriptor;
//            stringDescriptor = (PBYTE)&gStrProduct;
            break;
		case SerialNumberStringIndex:
		case configurationStringIndex:
            stringDescriptor = (PBYTE)SirialStringDescriptor;
//            stringDescriptor = (PBYTE)&gStrSerialNum;
            break;
        default:
            stringDescriptor = (PBYTE)LanguagesStringDescriptor; // for no panic
            break;
        }
        
        *txDatLen = stringDescriptor[0];
        *txDatP = stringDescriptor;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}


/*
 * Read the command from the endpoint 0 FIFO
 */
STATIC BOOL
getCommand( PMS_INFO pMsInfo, VOID *dataP )
{
    UINT32  i;
    UINT32  nLen;
    PBYTE   pBuf;

    // New setup packet
    nLen = UDC_READ_INDEX_REG(0, OUT_FIFO_CNT1_REG_OFFSET);

    nLen = MIN( nLen, EP0_PACKET_SIZE );

    pBuf = (PBYTE)dataP;
    for (i=0; i < nLen; i++)
        *pBuf++ = *(PBYTE)CTRLR_BASE_REG_ADDR(EP0_FIFO_REG_OFFSET);

    //UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, SERVICED_OUT_PKT_RDY);
    //UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, SERVICED_OUT_PKT_RDY|DATA_END);
    pBuf = (PBYTE)dataP;

    return (nLen == 8 /*sizeof(USB_DEVICE_REQUEST)*/);
}

/*
 * Read 8 Bytes from the endpoint 0 FIFO
 */
//STATIC UINT32
//getCommandEightBytes( PMS_INFO pMsInfo, VOID *dataP )
//{
//	PBYTE       pBuf = (PBYTE) dataP;
//	UINT32      nTotalBytes = 8;
   
//	memset( pBuf, 0x55, 8 );

//	while (nTotalBytes > 0)
//	{
//        *pBuf++ = *(PBYTE)CTRLR_BASE_REG_ADDR(EP0_FIFO_REG_OFFSET);
//		nTotalBytes--;
//	}

    //UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, SERVICED_OUT_PKT_RDY|DATA_END);

//	return 0;
//}


/*----------------------------------------------------------------------------
 *	ParseSetup
 *
 *	Parse through the setup command and perform actions based upon the
 *	requests.  The caller has already read the data from the FIFO and placed
 *	into the info structure.
 *----------------------------------------------------------------------------*/
BOOL	ParseSetup( PMS_INFO pMsInfo )
{
    BOOL    bErr = FALSE;
    PBYTE   p;
    UINT16  wLen, wTotLen = 0;
//    static int count = 0;

	/*
	 * Decode and execute the command. We support two sets of commands, vendor
	 * specific (modem control) and chapter 9 standard commands.
	 */
    if (pMsInfo->dReq.bmRequestType & USB_REQUEST_CLASS) 
    { 
        // vendor or class command

        // Bulk only Mass Storage Reset
//        BOT_DeviceNotify( pMsInfo, UFN_MSG_SETUP_PACKET, (UINT32)&pMsInfo->dReq);

        /* 
        * Vendor or Class command is complete
        */
        return FALSE;
    }

    /* 
	* Standard chapter 9 commands
	*/
    switch (pMsInfo->dReq.bRequest) 
	{
	case GET_DESCRIPTOR:
		switch ((BYTE)(pMsInfo->dReq.wValue>>8)) 
		{
		case DEVICE:
			p = (PBYTE)uStd;
			if(pMsInfo->dReq.wLength == 0x40){
				wLen= EP0_PACKET_SIZE;
			}else{
				wLen = (BYTE)MIN(uStd[0],pMsInfo->dReq.wLength);
			}
			wTotLen = uStd[0];
			break;

		case CONFIGURATION:
			p = (PBYTE)&uStd[iCONF];
			wLen = (BYTE)MIN(CFGLEN,pMsInfo->dReq.wLength);
			wTotLen = CFGLEN;
			break;

		case STRING:
			UsbRequestGetStringDescriptor( (UINT16)pMsInfo->dReq.wValue,
								  			(PBYTE *)&p, 
								 			(PBYTE) &wTotLen);
			wLen = (BYTE)MIN(wTotLen,pMsInfo->dReq.wLength);
			break;

		default:
			p = NULL;
			wLen = 0;
			wTotLen = 0;
			break;					
	    }

		// Is there data to send?
		if( wLen ) 
		{
			// Setup the pointers in the HW structure and then
			// call to have the data transfer initiated.
			pMsInfo->pXmitData = p;
			pMsInfo->nXmitIndex = 0;
			pMsInfo->nXmitLength = (int) wLen;
			pMsInfo->nXmitReq = (int) pMsInfo->dReq.wLength;

//			count = (int) pMsInfo->dReq.wLength;

            //HwEP0CSR |= EP0CSR_CLR_OUT_PKT_RDY;    
            //UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, SERVICED_OUT_PKT_RDY);

            // Send IN Data
	    	XmitEP0Data( pMsInfo );
		}
		break;
	case SET_CONFIG:
		// Save the configuration index into our state structure.
		pMsInfo->dConfIdx = (BYTE)pMsInfo->dReq.wValue;
		UDC_STATE( pMsInfo ) = WAIT_FOR_IN_STATUS;

        // start the IN and OUT transaction

		break;
	case SET_ADDRESS:
        //Not passed to software
		pMsInfo->dAddress = (BYTE) pMsInfo->dReq.wValue;

        // set address
        MS_USB_SetAddress(pMsInfo->dAddress);
//		pMsInfo->dReq.bRequest= GET_STATUS;	//���̊��荞�݂ŉ��ɂ����Ȃ��悤��
//		ResetCnt= 0;
		break;

	case GET_STATUS:
        //Not passed to software
        break;
	case SET_DESCRIPTOR:
		break;
	case GET_INTERFACE:
        //Not passed to software
        break;
	case GET_CONFIG:
        //Not passed to software
        break;
	case SET_INTERFACE:
        pMsInfo->dInterface = (BYTE) pMsInfo->dReq.wIndex;
        pMsInfo->dSetting = (BYTE) pMsInfo->dReq.wValue;
        UDC_STATE( pMsInfo ) = WAIT_FOR_IN_STATUS;
        break;
	case CLEAR_FEATURE:
        //Not passed to software
		/*
        * Request to the endpoint (Clear Halt)
        */
        if (pMsInfo->dReq.bmRequestType == 0x02)          
        { 
            /*
            * Switch on endpoint number (wIndex)
            */
            switch (pMsInfo->dReq.wIndex & 0xF) 
            {
            case 0:
                /*
                * Control endpoint. Not suggested.
                */
                break;
            case 1:
                /*
                * IN endpoint. Clear FIFO and force stall and  clear status
                */
                UDC_WRITE_INDEX_REG (IN_TRANSFER, IN_CSR1_REG_OFFSET, FLUSH_IN_FIFO);
                break;
             case 2:
                /*
                *OUT endpoint. Clear FIFO and force stall and  clear status
                */
                UDC_WRITE_INDEX_REG (OUT_TRANSFER, OUT_CSR1_REG_OFFSET, FLUSH_OUT_FIFO);
                break;
            }
        }
        break;
	case SET_FEATURE:
        if (pMsInfo->dReq.bmRequestType == 0x02)
        {
            switch (pMsInfo->dReq.wIndex & 15) 
            {
            case 0:
                /* 
                * Control endpoint. Not suggested.
                */
                break;
            case 1:
                /* 
                * IN endpoint. Set FST to force stall condition
                */
                break;
            case 2:
                /*
                * OUT endpoint. Set FST to force stall condition
                */
                break;
            }
        }
        break;
	default:
        // Unknown command received.
        bErr = TRUE;
        break;
	}

	return bErr;
}

int	ttflag;
/*----------------------------------------------------------------------------
 *	Process a setup packet for Endpoint 0.  
 *----------------------------------------------------------------------------*/
VOID ProcessEP0Setup( PMS_INFO pMsInfo )
{
    UINT32  EP0IrqStatus;

    EP0IrqStatus = UDC_READ_INDEX_REG(0, EP0_CSR_REG_OFFSET);

    // Make sure that everything is correct to read the setup packet from
    // the FIFO's
    if (EP0IrqStatus & EP0_OUT_PACKET_RDY)
    {
        // Setup packet is available.  Read it from the FIFO's
        if (!getCommand(pMsInfo, (void*)&pMsInfo->dReq)) 
        {
            // Failed to properly get the data from the FIFO's.
            // Force a STALL condition.
            MS_USB_StallEndPoint(pMsInfo, CONTROL_TRANSFER);
            //UDC_WRITE_INDEX_REG( 0, EP0_CSR_REG_OFFSET, EP0_SEND_STALL | SERVICED_OUT_PKT_RDY | DATA_END);

        }
//        UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, SERVICED_OUT_PKT_RDY|SETUP_END);
        UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, SERVICED_OUT_PKT_RDY);

		// Process the setup command.  This routine will parse
		// the setup command and possibly call the xmit EP0 routine
		// to start the transfer of the descriptor back to the host.
		// The state will be updated by the routine.

		if( ParseSetup( pMsInfo )) 
		{
			// Parsing of the setup failed.  Force a STALL and
			// then go back to IDLE state.

			MS_USB_StallEndPoint(pMsInfo, CONTROL_TRANSFER);
		}
	}
}	


/*----------------------------------------------------------------------------
 *	ProcessEP0OutStatus
 *
 *	Called to handle the condition where the state machine was waiting for 
 *	a OUT status.
 *----------------------------------------------------------------------------*/
PUBLIC VOID
ProcessEP0OutStatus( PMS_INFO pMsInfo )
{

//    kprintf("ProcessEP0OutStatus\n");

/*
    // Make sure the OPR bit is set and SA and RNE are not set.
    if((UDC_CSR0( pMsInfo ) & (XLLP_UDC_UDCCSR0_OPR | XLLP_UDC_UDCCSR0_SA)) == XLLP_UDC_UDCCSR0_OPR ) 
    {
        // Out status was received.  Turn off OPR and move to wait for setup
        UDCTrace( pMsInfo, UDCT_STATUS_OUT, UDC_CSR0( pMsInfo ));
    
        // The next two steps should be done atomically to guarantee 
        // that IR0 bit reflects correct status of another OUT/IN pkt!
        // Clear the OPR bit.
        UDC_CSR0_MWRITE( UDC_CSR0(pMsInfo), XLLP_UDC_UDCCSR0_OPR );
        // Clear the IR0_0 interrupt due to OPR.
        UDC_ISR0_CLEAR_ENDPOINT_INTR( UDC_ISR0(pMsInfo), XLLP_UDC_UDCISR0_IR0_0);
        
        UDC_STATE( pMsInfo ) = WAIT_FOR_SETUP;
    } 
    else 
    if (0 == UDC_CSR0( pMsInfo ))
    {
        // IN Data has been sent out. 
        // STATUS Stage has not been received yet.
    }
    else
    {
        //We should not be here.
        UDC_STATE( pMsInfo ) = WAIT_FOR_SETUP;
    }
*/
}

/*----------------------------------------------------------------------------
 *	ProcessEP0InStatus
 *
 *	Called to handle condition where the state machine is waiting for an
 *	in status.
 *----------------------------------------------------------------------------*/
PUBLIC VOID
ProcessEP0InStatus (PMS_INFO pMsInfo)
{

//    kprintf("ProcessEP0InStatus\n");

	//For Standard Chapter 9 EP0 No data commands,
	//we should not be here as UDC handles them automatically.
/*
	UDC_CSR0_MWRITE( UDC_CSR0(pMsInfo), XLLP_UDC_UDCCSR0_IPR );
	UDC_STATE( pMsInfo ) = WAIT_FOR_SETUP;
    return;
*/
}

/*----------------------------------------------------------------------------
 *	Services End Point 0.
 *
 *	This routine gets invoked as a result of a line interrupt being report
 *	by the MS_USB_GetInterruptType routine.
 *-----------------------------------------------------------------------------*/
void	MS_USB_SetupHandler( PMS_INFO pMsInfo )
{
    UINT32  EP0IrqStatus;

    ClearEndPointInterrupt(0);

    EP0IrqStatus = UDC_READ_INDEX_REG(0, EP0_CSR_REG_OFFSET);

	if (EP0IrqStatus & SETUP_END)
    {

		UDC_WRITE_INDEX_REG(0, EP0_CSR_REG_OFFSET, SERVICED_SETUP_END);

		UDC_STATE(pMsInfo) = WAIT_FOR_SETUP;
    }

    // Set By USB if protocol violation detected
    if (EP0IrqStatus & EP0_SENT_STALL)
    {
        // Must Clear both Send and Sent Stall
		UDC_STATE(pMsInfo) = WAIT_FOR_SETUP;
    }


	switch (UDC_STATE(pMsInfo)) 
	{
	case WAIT_FOR_SETUP:
		// This indicates we should be processing a setup packet.
		ProcessEP0Setup( pMsInfo );
		break;
	case DATA_STATE_XMIT:
        // Transmit the next data packet for EP0
		XmitEP0Data( pMsInfo );
		break;
	case DATA_STATE_RCVR:
		// Receive the next data packet
		break;
	case WAIT_FOR_OUT_STATUS:
		if (EP0IrqStatus & EP0_OUT_PACKET_RDY){
			UDC_STATE(pMsInfo) = WAIT_FOR_SETUP;
			ProcessEP0Setup( pMsInfo );
		}else{
			// Process the OUT status state
			ProcessEP0OutStatus( pMsInfo );
			UDC_STATE(pMsInfo) = WAIT_FOR_SETUP;
		}
		break;
	case WAIT_FOR_IN_STATUS:
		// Process in IN status state
		ProcessEP0InStatus( pMsInfo );
		break;
  	default:
		break;
	}

    return;
}


/*==================================================================================*/
/*========================== FROM HERE, connection management ======================*/
/*==================================================================================*/



/*==================================================================================*/
/*========================== FROM HERE, initialzation  =============================*/
/*==================================================================================*/


static void	OnReset(void)
{
	UDC_REG* pUdcReg= (UDC_REG*)UDC_BASE;

    pUdcReg->HwUBPWR = 0x00000001;               // RST RSM SP ENSP(1)		//0x52000144
    pUdcReg->HwUBFADR = 0x00000080;              // UP=1(ADDR_UPDATE)		//0x52000140
    
    // [ EP0 ] SET UP
    pUdcReg->HwUBIDX = 0x00000000;			//0								//0x52000178
//    pUdcReg->HwEP0CSR = 0x00000000;											//0x52000184
    pUdcReg->HwINCSR1 = 0x00000000;											//0x52000184
	
//    HwMAXP = 0x02;                      // MAX PACKET SIZE 16 byte	//0x5200018C(440->0x52000180) 
    pUdcReg->HwMAXP = 0x01;                      // MAX PACKET SIZE 8 byte	//0x5200018C(440->0x52000180) 
    
    // [ EP2 ] SET UP (PC->TCC)
    pUdcReg->HwUBIDX = OUT_TRANSFER;          // 2							//0x52000178
    pUdcReg->HwINCSR2 = 0x00000000;              // OUT						//0x52000188
    pUdcReg->HwOCSR2 = 0x00000000;               // x Auto Clear ACLR[7]		//0x52000194
    pUdcReg->HwMAXP = 0x08;                      // MAX PACKET SIZE 64 byte  //0x5200018C(440->0x52000180) 
    
    // [ EP1 ] SET UP (TCC->PC)
    pUdcReg->HwUBIDX = IN_TRANSFER;          // 1							//0x52000178
    pUdcReg->HwINCSR2 = 0x00000020;              // IN MDI[5]				//0x52000188
    pUdcReg->HwOCSR2 = 0x00000000;               // x Auto Clear ACLR[7]		//0x52000194
    pUdcReg->HwMAXP = 0x08;                      // MAX PACKET SIZE 64 byte  //0x5200018C(440->0x52000180) 

    // [ EP3 ] SET UP (TCC->PC)
    pUdcReg->HwUBIDX = MAX_TRANSFER;          // 3							//0x52000178
    pUdcReg->HwINCSR2 = 0x00000020;              // IN MDI[5]				//0x52000188
    pUdcReg->HwOCSR2 = 0x00000000;               // x Auto Clear ACLR[7]		//0x52000194
    pUdcReg->HwMAXP = 0x08;                      // MAX PACKET SIZE 64 byte  //0x5200018C(440->0x52000180) 

    pUdcReg->HwUBIR = 0x07;													//0x52000158
    pUdcReg->HwUBEIR = 0x07;													//0x52000148
    
    pUdcReg->HwUBEIEN = 0x00000007;              // Enable Interrupt of EP2,EP1,EP0	//0x5200015C
    pUdcReg->HwUBIEN = 0x00000007;               // Enable Interrupt of RST RSM SP	//0x5200016C

    return;
}

//
// MS_USB_Init
//
// Initialize the UDC.
//

VOID MS_USB_Init (PMS_INFO pMsInfo)
{
//    VOLATILE IOP_REG        *pIOPRegs = (volatile IOP_REG*)IOP_BASE;
    VOLATILE CLKPWR_REG     *pCLKPWRregs = (VOLATILE CLKPWR_REG*)CLKPWR_BASE;
#ifdef	WIN32
	return;
#endif

//    pIOPRegs->rGPGDAT |= USB_nRST;										//???????
//    pIOPRegs->rGPGUP  |= USB_nRST;  //pull-up disable					//???????
//    pIOPRegs->rGPGCON = (pIOPRegs->rGPGCON & ~((3<<(USB_nRST*2)))) | 
//                                               (1<<(USB_nRST*2));		//GPG10=output

//    pIOPRegs->rGPGDAT |= USB_IRQ_PORT;									//???????
//    pIOPRegs->rGPGUP  |= USB_IRQ_PORT;  //pull-up disable				//???????
//    pIOPRegs->rGPGCON = (pIOPRegs->rGPGCON & ~((3<<(USB_IRQ_PORT*2)))) | 
//                                               (2<<(USB_IRQ_PORT*2));	//GPG3=EINT11

//    pIOPRegs->rEXTINT1 = (pIOPRegs->rEXTINT1 & ~((7<<12))) | 
//                                                 (7<<12);				//EINT11=Both edge triger

    pCLKPWRregs->rCLKCON |= CLKEN_USBD;									//USB Clock

//    pIOPRegs->rGPGDAT &= ~(1<<USB_nRST);								//GPG10=0

	OnReset();
    return;
}

VOID MS_USB_Suspend( VOID )
{
	UDC_REG* pUdcReg= (UDC_REG*)UDC_BASE;

	pUdcReg->HwUBIEN &= 0xFE;
	pUdcReg->HwUBIR |= HwUBIR_SP;		//Int Clear
}

STATIC VOID
DoTxData( PMS_INFO pMsInfo )
{
    UINT32   Len;


    // Check the flow control status, and if not flowed off, call the
    // hw TX routine to actually transmit some data.
    Len = UDCMASS_XMIT_PACKET_SIZE;

    MS_USB_RxIntHandler(pMsInfo, RxBuffWrite(pMsInfo), &Len);

    // Update Fifo info
    RxLengthW(pMsInfo) += Len;
    RxWrite(pMsInfo) ++;
	RxWrite(pMsInfo) &= 0x1f;

    return;
}
void	IoWrite(unsigned char* pBuf,int nReqWrite)
{

	unsigned int	Len= nReqWrite;
	MS_USB_TxIntHandler(pBuf, &Len);
}

int	MS_USB_InterruptHandler( void )
{
    INT                     RoomLeft = 0;
    UINT32      IntType = 0;
	int			ret= 0;
	PMS_INFO pMsInfo;

	IntType = MS_USB_GetInterruptType();
        if(IntType == 0) 
        {
            return 0;
        }

        if( IntType & UDC_INTR_RESET )				//Reset
        {
    
            /* Call low level line status clean up code.
            * Then unmask the interrupt
            */
            MS_USB_ResetHandler(&MsInfo);
        }
        
        if( IntType & UDC_INTR_SETUP )				//Setting(Control)
        {
    
            /* Call low level status clean up code.
            */
		    MS_USB_SetupHandler(&MsInfo);

        }

		//From PC To SlaveUSB 
        if ( IntType & UDC_INTR_TX )				//EP2(OutPut)
        {
            DoTxData( &MsInfo );
			pMsInfo= &MsInfo;
			if( RxWrite(pMsInfo) != RxRead(pMsInfo) ){
				ret= 1;
			}
       }

		//From SlaveUSB To PC 
        if( IntType & UDC_INTR_RX )					//EP1(Input)
        {
            // IntType's read data event. Optimize the read by reading chunks
            // if the user has not specified using xflow control
            // or event/error/eof characters. Ack the receive,
            // unmask the interrupt, get the current data pointer
            // and see if data is available.
            // Note: We have to copy RxRead and RxWrite index to local in order to make it atomic.

            register UINT32 TxWIndex = TxRead(pMsInfAddr);//, RxRIndex=RxRead(pMsInfo);
    

            RoomLeft = TxLength(pMsInfAddr) - TxWIndex;

            if( RoomLeft ) 
            {
                MsInfo.DroppedBytesPDD += MS_USB_TxIntHandler(TxBuffRead(pMsInfAddr), (unsigned int*)&RoomLeft);
				MsInfo.DroppedBytes = 0;
            }

            TxRead(pMsInfAddr) += RoomLeft;

            // again 
            RoomLeft = TxLength(pMsInfAddr) - TxRead(pMsInfAddr);
        }
		//Suspemded 2009.02.25
		if(IntType & UDC_INTR_SUSPEND){
			MS_USB_Suspend();
		}


    return(ret);
}
int	GetUsbRcvData(char* Buff)
{
	int	len;

	len= MsInfo.RxBufferInfo.Length[MsInfo.RxBufferInfo.Read];
	memcpy(Buff,MsInfo.RxBufferInfo.RxCharBuffer[MsInfo.RxBufferInfo.Read],len);
	MsInfo.RxBufferInfo.Length[MsInfo.RxBufferInfo.Read]= 0;		//Length Clear
	MsInfo.RxBufferInfo.Read= (MsInfo.RxBufferInfo.Read+1) & 0x1f;
	return(len);
}

void	SendUsbData(unsigned char* buff,int cnt)
{
	if(cnt <= EP1_PACKET_SIZE){
		IoWrite(&buff[0],cnt);
	}else{
		SetWriteBuffer(&buff[EP1_PACKET_SIZE],cnt- EP1_PACKET_SIZE);
		IoWrite(&buff[0],EP1_PACKET_SIZE);
	}
	return;
}
void	InitUDC(void)
{
	memset(&MsInfo,0,sizeof(MS_INFO));
    MS_USB_Init(&MsInfo);
}

int	CheckUsbRecData(void)
{
	return(RxRead(pMsInfAddr)- RxWrite(pMsInfAddr));
}
void	SetWriteBuffer(unsigned char*buff,int len)
{
	TxBuffer(pMsInfAddr)= buff;
	TxLength(pMsInfAddr)= len;
	TxRead(pMsInfAddr)= 0;
}

