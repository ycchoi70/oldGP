
#define	TOUCH_SCAN_TIME	10		//*10ms

#ifdef	BIOS_PROC
	volatile	int	time_flag[8];
	int	time_data[8];
	int	timLoopCnt;
	int	RtcReadTime;
#else
	extern	volatile	int	time_flag[8];
	extern	int	time_data[8];
	extern	int	timLoopCnt;
	extern	int	RtcReadTime;
#endif



void	DrawLcd( char* pBitmapBits );
void	DotDrawLcdBank( int sx,int sy,int ex,int ey );
int	CheckSRAM(void);
int	IsTestMode(void);
int	IsTestModeValue(void);
int	CheckFLASH(void);
void	NormBuzzer(void);
void   ScanKey(int* x,int* y);
void	ClearDisplay(void);
int	InputOkNG(int mode);
int	Rs232CTest(int mode);
int	BatteryRead( void );
void    BuzOn(void);
void    BuzOff(void);
void	SetSysTime( unsigned char *rtc_buf);
void	RtcInit(void);
void	RTCWrite(unsigned char rtc_buf[],int rReset);
int	RTCRead(unsigned char *rtcbuf);
int	CheckRtc(unsigned char *rtc_buf);
void	RtcInitWrite(unsigned char rtc_buf[]);
int	CheckDateTime(int type,RTC_DATA *SetData);
int		iNowWeek(RTC_DATA *STime);
void	Rs422Enable(int mode);
void	WaitTimeMs( int cnt );
void	SetContrast(int data);
void	ClearDispBuff_FF(void);




void	_ei(void);
void	_di(void);


void	BackLightOnOff(int mode);
void	RunLed(int mode);
void	ErrorLed(int mode);
void	LCDDisplayEnable(int mode);
int	RunSWRead( void );
void	Buzzer(int mode);

extern	char	*TVS_VERSION_MES;


void	TimerInit( void );
void	TimerStart(int no,int cnt);
void	TimerStop(int no);
void	TimerProc( void );
void	RtsOn(void);
void	RtsOff(void);
void	Rts0On(void);
void	Rts0Off(void);
void	Waitms(int no);

