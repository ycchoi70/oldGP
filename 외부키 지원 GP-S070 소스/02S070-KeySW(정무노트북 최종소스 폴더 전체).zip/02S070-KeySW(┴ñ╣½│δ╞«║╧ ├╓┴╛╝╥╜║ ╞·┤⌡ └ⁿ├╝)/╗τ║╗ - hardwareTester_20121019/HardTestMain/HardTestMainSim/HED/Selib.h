/***********************************************
 * NAME    : 44BLIB.H                          *
 * Version : 17.Apr.00                         *
 ***********************************************/


#ifndef __44blib_h__
#define __44blib_h__

#ifdef __cplusplus
extern "C" {
#endif

#define DebugOut Uart_Printf




#ifndef NULL
#define NULL    0
#endif


#define EnterPWDN(clkcon) ((void (*)(int))0xe0)(clkcon)


/*44blib.c*/
//void Delay(int time); //Watchdog Timer is used.

//void *malloc(unsigned nbyte); 
//void free(void *pt);

void Port_Init(void);

void Led_Display(int data);


void	SysHardInitial(void);
void	SetBacklight(int Prescaler,int Devid,int Count,int CmpCnt);
void	Timer0_Init(int Prescaler,int Devid,int Count,int CmpCnt);
void	Timer1_Init(int Prescaler,int Devid,int Count,int CmpCnt);
void	Timer2_Init(int Prescaler,int Devid,int Count,int CmpCnt);
void	Timer3_Init(int Prescaler,int Devid,int Count,int CmpCnt);
void	SetPwmReg(int kind,int Prescaler,int Devid,int Count,int CmpCnt);
void	Timer3DefltInit(void);

#ifdef __cplusplus
}
#endif

#endif /*__44blib_h__*/
