
#define	BACKLIGHT_CNT	34700
#define	BACKLIGHT_CMP	0x2D50

typedef struct{
	int	x;
	int	y;
}STRUCT_ADDR;

#define	USB_CMD_TEST		"TEST"
#define	USB_CMD_SET_TIME	"STTM"
#define	USB_CMD_SET_PARA	"STPA"

#ifdef	HARDTEST_PROC

int	TestColor[5]={T_RED,T_GREEN,T_BLUE,T_BLACK,T_WHITE};
	STRUCT_ADDR	CalibAddr[5]= {{100,100},{100,400},{600,100},{600,400},{350,250}};
	char*	PwmKind[6]={	"Pwm_Timer0","Pwm_Timer1","Pwm_Timer2","Pwm_Timer3","Clkout0","Clkout1"	};
	char*	SrcKind[6]={	"MPLL","UPLL","FCLK","HCLK","PCLK","DCLK"	};
	TCAL_DATA	CalibData[2];
	TCAL_DATA	InCalibData[5];
	unsigned char	UsbWriteBuff[0x200];
#endif

int	MemoryTest(void);

int	SramTest(void);
int	NandFlashTest(void);
int	SdramTest(void);

//int	LcdTest(void);


int	IoTest(void);
void	HardTest(void);


#define	TYPE_BYTE		1
#define	TYPE_WORD		2
#define	TYPE_LONG		4

#define DELAY	20000000

extern	void DubugMain( void );
