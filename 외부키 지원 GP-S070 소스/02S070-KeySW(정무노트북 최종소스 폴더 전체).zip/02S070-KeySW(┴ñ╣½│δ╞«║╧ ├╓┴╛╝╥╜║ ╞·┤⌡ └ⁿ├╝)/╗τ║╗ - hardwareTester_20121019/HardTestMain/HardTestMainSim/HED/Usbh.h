/*
****************************************************************************
		R E N E S A S   T E C H N O L O G Y    P R O P R I E T A R Y

	COPYRIGHT (c)	2004 BY Renesas Technology Corp.
						---  ALL RIGHTS RESERVED  ---

	File Name	:Usbh.h
	Working		:�\���̒�`�Ȃ�
	Date		:2004_06_10
****************************************************************************
*/

#ifndef	_USBH_DEFS
#define _USBH_DEFS

/*	Definitions	*/

#define ENDIAN_BIG		0
#define ENDIAN_LITTLE	1
#define	FULLSPEED		0				/* FullSpeedDevice */
#define	LOWSPEED		1				/* LowSpeedDevice */
//#define USBHOST_REGS	0x49000000		/* USBH(OHCI) Register Start Address */
//#define USBHOST_MEM		0x30300000		/* USBH(OHCI) Shared Memory Start Address */
#define USBHOST_MEM		0x31C00000		/* USBH(OHCI) Shared Memory Start Address */

			/* USBHOST_MEM + 0x0000000 -> USBHOST_MEM + 0x000004FF : HCCA�AED�ATD    */
			/* USBHOST_MEM + 0x0000500 ->                          : �f�[�^�o�b�t�@  */



//
// M A N D A T O R Y   S C S I - 2   C O M M A N D S
//

#define SCSI_TEST_UNIT_READY            0x00
#define SCSI_REQUEST_SENSE              0x03
#define SCSI_INQUIRY                    0x12
#define SCSI_SEND_DIAGNOSTIC            0x1D

//
// M A N D A T O R Y   D E V I C E   S P E C I F I C   C O M M A N D S
//

#define SCSI_READ6                      0x08
#define SCSI_READ10                     0x28
#define SCSI_READ_CAPACITY              0x25
#define SCSI_READ_FORMATCAPACITY        0x23

//
// O P T I O N A L   D E V I C E   S P E C I F I C   C O M M A N D S
//

#define SCSI_MODE_SELECT6               0x15
#define SCSI_MODE_SENSE6                0x1A
#define SCSI_START_STOP                 0x1B
#define SCSI_WRITE6                     0x0A
#define SCSI_WRITE10                    0x2A
#define SCSI_MODE_SELECT10              0x55
#define SCSI_MODE_SENSE10               0x5A

// XP
#define SCSI_PREVENT_ALLOW_MEDIUM_REMOVAL   0x1E
#define SCSI_VERIFY                     0x2F

//
// ( A T A P I )   C D - R O M   C O M M A N D S
//

#define SCSI_CD_READ_TOC                0x43
#define SCSI_CD_PLAY10                  0x45
#define SCSI_CD_PLAY_MSF                0x47
#define SCSI_CD_PAUSE_RESUME            0x4B
#define SCSI_CD_STOP                    0x4E

//
// M O D E  P A G E S
//

#define MODE_PAGE_FLEXIBLE_DISK         0x05
#define MODE_PAGE_CDROM                 0x0D
#define MODE_PAGE_CDROM_AUDIO           0x0E
#define MODE_PAGE_CDROM_CAPS            0x2A

//
// S C S I - 2   S E N S E   K E Y S
//

#define SENSE_NONE                      0x00
#define SENSE_RECOVERED_ERROR           0x01
#define SENSE_NOT_READY                 0x02
#define SENSE_MEDIUM_ERROR              0x03
#define SENSE_HARDWARE_ERROR            0x04
#define SENSE_ILLEGAL_REQUEST           0x05
#define SENSE_UNIT_ATTENTION            0x06
#define SENSE_DATA_PROTECT              0x07
#define SENSE_BLANK_CHECK               0x08

//
// S C S I - 2   A S C
//

#define ASC_LUN                         0x04
#define ASC_INVALID_COMMAND_FIELD       0x24
#define ASC_MEDIA_CHANGED               0x28
#define ASC_RESET                       0x29
#define ASC_COMMANDS_CLEARED            0x2F
#define ASC_MEDIUM_NOT_PRESENT          0x3A

/*	Typedefs	*/
/*
 * USB directions
 *
 * This bit flag is used in endpoint descriptors' bEndpointAddress field.
 * It's also one of three fields in control requests bRequestType.
 */
#define USB_DIR_OUT			0		/* to device */
#define USB_DIR_IN			0x80		/* to host */

/*
 * USB types, the second of three bRequestType fields
 */
#define USB_TYPE_MASK			(0x03 << 5)
#define USB_TYPE_STANDARD		(0x00 << 5)
#define USB_TYPE_CLASS			(0x01 << 5)
#define USB_TYPE_VENDOR			(0x02 << 5)
#define USB_TYPE_RESERVED		(0x03 << 5)

/*
 * USB recipients, the third of three bRequestType fields
 */
#define USB_RECIP_MASK			0x1f
#define USB_RECIP_DEVICE		0x00
#define USB_RECIP_INTERFACE		0x01
#define USB_RECIP_ENDPOINT		0x02
#define USB_RECIP_OTHER			0x03
/* From Wireless USB 1.0 */
#define USB_RECIP_PORT 			0x04
#define USB_RECIP_RPIPE 		0x05

/*
 * Standard requests, for the bRequest field of a SETUP packet.
 *
 * These are qualified by the bRequestType field, so that for example
 * TYPE_CLASS or TYPE_VENDOR specific feature flags could be retrieved
 * by a GET_STATUS request.
 */
#define USB_REQ_GET_STATUS			0x00
#define USB_REQ_CLEAR_FEATURE		0x01
#define USB_REQ_SET_FEATURE			0x03
#define USB_REQ_SET_ADDRESS			0x05
#define USB_REQ_GET_DESCRIPTOR		0x06
#define USB_REQ_SET_DESCRIPTOR		0x07
#define USB_REQ_GET_CONFIGURATION	0x08
#define USB_REQ_SET_CONFIGURATION	0x09
#define USB_REQ_GET_INTERFACE		0x0A
#define USB_REQ_SET_INTERFACE		0x0B
#define USB_REQ_SYNCH_FRAME			0x0C

#define USB_REQ_SET_ENCRYPTION		0x0D	/* Wireless USB */
#define USB_REQ_GET_ENCRYPTION		0x0E
#define USB_REQ_RPIPE_ABORT			0x0E
#define USB_REQ_SET_HANDSHAKE		0x0F
#define USB_REQ_RPIPE_RESET			0x0F
#define USB_REQ_GET_HANDSHAKE		0x10
#define USB_REQ_SET_CONNECTION		0x11
#define USB_REQ_SET_SECURITY_DATA	0x12
#define USB_REQ_GET_SECURITY_DATA	0x13
#define USB_REQ_SET_WUSB_DATA		0x14
#define USB_REQ_LOOPBACK_DATA_WRITE	0x15
#define USB_REQ_LOOPBACK_DATA_READ	0x16
#define USB_REQ_SET_INTERFACE_DS	0x17

/*
 * USB feature flags are written using USB_REQ_{CLEAR,SET}_FEATURE, and
 * are read as a bit array returned by USB_REQ_GET_STATUS.  (So there
 * are at most sixteen features of each type.)
 */
#define USB_DEVICE_SELF_POWERED		0	/* (read only) */
#define USB_DEVICE_REMOTE_WAKEUP	1	/* dev may initiate wakeup */
#define USB_DEVICE_TEST_MODE		2	/* (wired high speed only) */
#define USB_DEVICE_BATTERY			2	/* (wireless) */
#define USB_DEVICE_B_HNP_ENABLE		3	/* (otg) dev may initiate HNP */
#define USB_DEVICE_WUSB_DEVICE		3	/* (wireless)*/
#define USB_DEVICE_A_HNP_SUPPORT	4	/* (otg) RH port supports HNP */
#define USB_DEVICE_A_ALT_HNP_SUPPORT	5	/* (otg) other RH port does */
#define USB_DEVICE_DEBUG_MODE		6	/* (special devices only) */

#define USB_ENDPOINT_HALT		0	/* IN/OUT will STALL */



typedef	struct SetupDataType {						/*	�Z�b�g�A�b�v�f�[�^�̍\���̒�`	*/
	unsigned long			bmRequest:8;			/*	Characteristics of request	*/
	unsigned long			bRequest:8;				/*	Request number	*/
	unsigned long			wValue:16;				/*	Word-sized field that varies according to request	*/
	unsigned long			wIndex:16;				/*	Word-sized field that varies according to request	*/
													/*		This field is used in requests to specifyEndpoint or Inferface	*/
	unsigned long			wLength:16;				/*	Number of bytes to transfer if there is a Data stage	*/
} SetupDataType;


typedef	struct CBWDataType {						/*	MassStorage(BulkOnly)�]�����Ɏg���ACBW�̍\���̒�`	*/
	unsigned long			dCBWSignature;			/*	using to recognize CBW	*/
	unsigned long			dCBWTag;				/*	Comand Block Tag	*/
	unsigned long			dCBWDataTransferLength;	/*	HOST expectant data length	*/
	unsigned long			bmCBWFlags:8;			/*	data transfer direction	*/
	unsigned long			bCBWLUN:8;				/*	LUN	*/
	unsigned long			bCBWCBLength:8;			/*	CBWCB command length	*/
	unsigned long			cmdOpeCode:8;			/*	command Operation Code	*/
	unsigned long			cmd1:8;					/*	command	*/
	unsigned long			cmd2:8;					/*	command	*/
	unsigned long			cmd3:8;					/*	command	*/
	unsigned long			cmd4:8;					/*	command	*/
	unsigned long			cmd5:8;					/*	command	*/
	unsigned long			cmd6:8;					/*	command	*/
	unsigned long			cmd7:8;					/*	command	*/
	unsigned long			cmd8:8;					/*	command	*/
	unsigned long			cmd9:8;					/*	command	*/
	unsigned long			cmd10:8;				/*	command	*/
	unsigned long			cmd11:8;				/*	command	*/
	unsigned long			cmd12:8;				/*	command	*/
	unsigned long			cmd13:8;				/*	command	*/
	unsigned long			cmd14:8;				/*	command	*/
	unsigned long			cmd15:8;				/*	command	*/
	unsigned long			dummy:8;				/*	command	*/
} CBWDataType;


typedef	struct CSWDataType {						/*	MassStorage(BulkOnly)�]�����Ɏg���ACSW�̍\���̒�`	*/
	unsigned long			dCSWSignature;			/*	using to recognize CSW	*/
	unsigned long			dCSWTag;				/*	related Tag for CBW	*/
	signed long				dCSWDataResidue;		/*	difference between HOST expectant data length and executed data length	*/
	unsigned long			bCSWStatus:8;			/*	command status	*/
	unsigned long			dummy:24;				/*	command status	*/
} CSWDataType;


typedef struct HC_REG {								/*	USBH HostController�̃��W�X�^	*/
	unsigned long	HcRevision;
	unsigned long	HcControl;
	unsigned long	HcCommandStatus;
	unsigned long	HcInterruptStatus;
	unsigned long	HcInterruptEnable;
	unsigned long	HcInterruptDisable;
	unsigned long	HcHCCA;
	unsigned long	HcPeriodCurrentED;
	unsigned long	HcControlHeadED;
	unsigned long	HcControlCurrentED;
	unsigned long	HcBulkHeadED;
	unsigned long	HcBulkCurrentED;
	unsigned long	HcDoneHead;
	unsigned long	HcFmInterval;
	unsigned long	HcFrameRemaining;
	unsigned long	HcFmNumber;
	unsigned long	HcPeriodicStart;
	unsigned long	HcLSThreshold;
	unsigned long	HcRhDescriptorA;
	unsigned long	HcRhDescriptorB;
	unsigned long	HcRhStatus;
	unsigned long	HcRhPortStatus1;
	unsigned long	HcRhPortStatus2;
} HC_REG;

typedef struct HC_ED {								/*	Endpoint Descriptor�̍\���̒�`	*/
#ifdef	BIG_ENDIAN
	unsigned long	dummy1:5;						/*		*/
	unsigned long	MPS:11;							/*	MaxPacketSize		11bit	0-2047	*/
	unsigned long	F:1;							/*	Format				1bit	F=1:isochronous,F=0:others	*/
	unsigned long	K:1;							/*	SKIP				1bit	K=1:go to the next ED	*/
	unsigned long	S:1;							/*	SPEED				1bit	S=0:full speed,S=1:low speed	*/
	unsigned long	D:2;							/*	Direction			2bit	D=0,3:get direction from TD , D=1:OUT , D=2:IN	*/
	unsigned long	EN:4;							/*	EndPoint No.		4bit	0-15	*/
	unsigned long	FA:7;							/*	Function Address	7bit	0-127	*/
#else
	unsigned long	FA:7;							/*	Function Address	7bit	0-127	*/
	unsigned long	EN:4;							/*	EndPoint No.		4bit	0-15	*/
	unsigned long	D:2;							/*	Direction			2bit	D=0,3:get direction from TD , D=1:OUT , D=2:IN	*/
	unsigned long	S:1;							/*	SPEED				1bit	S=0:full speed,S=1:low speed	*/
	unsigned long	K:1;							/*	SKIP				1bit	K=1:go to the next ED	*/
	unsigned long	F:1;							/*	Format				1bit	F=1:isochronous,F=0:others	*/
	unsigned long	MPS:11;							/*	MaxPacketSize		11bit	0-2047	*/
	unsigned long	dummy1:5;						/*		*/
#endif
	unsigned long	TailP;							/*	physical pointer to HC_TD	*/
	unsigned long	HeadP;							/*	flags + phys ptr to HC_TD	*/
	unsigned long	NextED;							/*	phys ptr to HC_ED	*/
} HC_ED;

typedef struct HC_GTD {								/*	General Transfer Descriptor�̍\���̒�`	*/
#ifdef	BIG_ENDIAN
	unsigned long	CC:4;							/*	condition code	*/
	unsigned long	EC:2;							/*	Error count	*/
	unsigned long	Toggle:2;						/*	Data toggle, T= 0x:acquied from ED toggle carry,  10:DATA0,  11:DATA1	*/
	unsigned long	IntD:3;							/*	Delay Interrupt    111:no interrupt	*/
	unsigned long	DP:2;							/*	Direction PID  00:SETUP,  01:OUT ,  10:IN  ,11:reserved	*/
	unsigned long	R:1;							/*	Buffer Rounding  0:must exactly define buffer  1: smaller packet than buffer not error	*/
	unsigned long	dummy:2;						/*	dummy	*/
	unsigned long	dummy1:16;						/*	dummy	*/
#else
	unsigned long	dummy1:16;						/*	dummy	*/
	unsigned long	dummy:2;						/*	dummy	*/
	unsigned long	R:1;							/*	Buffer Rounding  0:must exactly define buffer  1: smaller packet than buffer not error	*/
	unsigned long	DP:2;							/*	Direction PID  00:SETUP,  01:OUT ,  10:IN  ,11:reserved	*/
	unsigned long	IntD:3;							/*	Delay Interrupt    111:no interrupt	*/
	unsigned long	Toggle:2;						/*	Data toggle, T= 0x:acquied from ED toggle carry,  10:DATA0,  11:DATA1	*/
	unsigned long	EC:2;							/*	Error count	*/
	unsigned long	CC:4;							/*	condition code	*/
#endif
	unsigned long	CBP;							/*	current buffer pointer	*/
	unsigned long	NextTD;							/*	phys ptr to HC_TD	*/
	unsigned long	BE;								/*	buffer end	*/
} HC_GTD;

typedef struct HC_HCCA {							/*	HCCA�̍\���̒�`	*/
	unsigned long	HccaInterruptList[32];			/*	InterruptTree�\���ւ̃|�C���^	*/
#ifdef	BIG_ENDIAN
	unsigned long	HccaPad1:16;					/*	*/
	unsigned long	HccaFrameNumber:16;				/*	���݂�FrameNumber	*/
#else
	unsigned long	HccaFrameNumber:16;				/*	���݂�FrameNumber	*/
	unsigned long	HccaPad1:16;					/*	*/
#endif
	unsigned long	HccaDoneHead;					/*	������������TD�Q�ւ̃|�C���^	*/
	unsigned long	reserve[29];
} HC_HCCA;


typedef struct USBDeviceInfo {
	unsigned char	devAddress;						/*	�f�o�C�X�A�h���X	*/

	unsigned char	ep0MPS;							/*	Endpoint0��MaxPacketSize	*/
	unsigned char	ifClass;						/*	Interface Class	*/
	unsigned char	ifSubClass;						/*	Interface SubClass	*/
	unsigned char	ifProtocol;						/*	Interface Protocol	*/
	unsigned char	ifHaveEpNum;					/*	�ڑ����ꂽ�f�o�C�X������Endpoint�̌�	*/
	unsigned char	ifIndex;						/*	Interface Index	*/
	unsigned char	ifSetting;						/*	Interface Index	*/

	unsigned char	DeviceType;						/*	1:MSC_BOT_SCSI 2:HID 0:Others	*/

/*	for HIDDevice	*/
	unsigned char	IntEPAddress;					/*	InterruptEndpoint�̃A�h���X	*/
	unsigned char	IntEPAttribute;					/*	InterruptEndpoint��Endpoint�ԍ��A����	*/
	unsigned char	IntEPMaxPacketSize;				/*	InterruptEndpoint��MaxPacketSize	*/
	unsigned char	IntEPInterval;					/*	InterruptEndpoint��PollingRate	*/

/*	for MSCDevice	*/
	unsigned char	BulkInEPAddress;				/*	BulkInEndpoint�̃A�h���X	*/
	unsigned char	BulkInEPAttribute;				/*	BulkInEndpoint��Endpoint�ԍ��A����	*/
	unsigned char	BulkInEPMaxPacketSize;			/*	BulkInEndpoint��MaxPacketSize	*/
	
	unsigned char	BulkOutEPAddress;				/*	BulkOutEndpoint�̃A�h���X	*/
	unsigned char	BulkOutEPAttribute;				/*	BulkOutEndpoint��Endpoint�ԍ��A����	*/
	unsigned char	BulkOutEPMaxPacketSize;			/*	BulkOutEndpoint��MaxPacketSize	*/

	unsigned char	Configration;					/* = 1 */
	unsigned char	bDeviceClass;					/* Device Class Code */
	unsigned char	bDeviceSubClass;				/* Device Sub Class Code */
	unsigned char	bDeviceProtocol;					/* Device Protocol Code */

	unsigned char	LunNumber;
} USBDeviceInfo;

//
//#define		GET_STATUS					0
//#define		CLEAR_FEATURE				1
//#define		Reserved_for_future_use_2	2
//#define		SET_FEATURE					3
//#define		Reserved_for_future_use_4	4
//#define		SET_ADDRESS					5
//#define		GET_DESCRIPTOR				6
//#define		SET_DESCRIPTOR				7
//#define		GET_CONFIGURATION			8
//#define		SET_CONFIGURATION			9
//#define		GET_INTERFACE				10
//#define		SET_INTERFACE				11
//#define		SYNCH_FRAME					12

#define		hub_cls_sp_request_ClearHubFeature			((0x20 << 8) | CLEAR_FEATURE  )
#define		hub_cls_sp_request_ClearPortFeature			((0x23 << 8) | CLEAR_FEATURE  )
//#define	hub_cls_sp_request_GetBusState				((0xA3 << 8) | GET_STATUS     )
#define		hub_cls_sp_request_GetHubDescripter			((0xA0 << 8) | GET_DESCRIPTOR )
#define		hub_cls_sp_request_GetHubStatus				((0xA0 << 8) | GET_STATUS     )
#define		hub_cls_sp_request_GetPortStatus			((0xA3 << 8) | GET_STATUS     )
//#define	hub_cls_sp_request_SetHubDescriptor			((0x20 << 8) | SET_DESCRIPTOR )
#define		hub_cls_sp_request_SetHubFeature			((0x20 << 8) | SET_FEATURE    )
#define		hub_cls_sp_request_SetPortFeature			((0x23 << 8) | SET_FEATURE    )

//	Hub Class Feature Selectors
//	See USB2.0 specification 11.24.2 Table 11-17 p.421
#define		C_HUB_LOCAL_POWER			0	//	Hub
#define		C_HUB_OVER_CURRENT			1	//	Hub
#define		PORT_CONNECTION				0	//	Port
#define		PORT_ENABLE					1	//	Port
#define		PORT_SUSPEND				2	//	Port
#define		PORT_OVER_CURRENT			3	//	Port
#define		PORT_RESET					4	//	Port
#define		PORT_POWER					8	//	Port
#define		PORT_LOW_SPEED				9	//	Port
#define		C_PORT_CONNECTION			16	//	Port
#define		C_PORT_ENABLE				17	//	Port
#define		C_PORT_SUSPEND				18	//	Port
#define		C_PORT_OVER_CURRENT			19	//	Port
#define		C_PORT_RESET				20	//	Port


/*
 * HcControl (control) register masks
 */
#define OHCI_CTRL_CBSR	(3 << 0)	/* control/bulk service ratio */
#define OHCI_CTRL_PLE	(1 << 2)	/* periodic list enable */
#define OHCI_CTRL_IE	(1 << 3)	/* isochronous enable */
#define OHCI_CTRL_CLE	(1 << 4)	/* control list enable */
#define OHCI_CTRL_BLE	(1 << 5)	/* bulk list enable */
#define OHCI_CTRL_HCFS	(3 << 6)	/* host controller functional state */
#define OHCI_CTRL_IR	(1 << 8)	/* interrupt routing */
#define OHCI_CTRL_RWC	(1 << 9)	/* remote wakeup connected */
#define OHCI_CTRL_RWE	(1 << 10)	/* remote wakeup enable */

/* pre-shifted values for HCFS */
#define OHCI_USB_RESET		(0 << 6)
#define OHCI_USB_RESUME		(1 << 6)
#define OHCI_USB_OPER		(2 << 6)
#define OHCI_USB_SUSPEND	(3 << 6)

#endif

//	IN
#define		REQUEST_SENSE					0
#define		INQUIRY							1
#define		MODE_SENSE						2
#define		ST_UNIT_READY					3
#define		READ_CAPACITY					4
#define		READ_FORM_CAPACITY				5
#define		ST_READ							6
#define		PRE_FECT						7
//	OUT
#define		TEST_UNIT_READY					8
#define		START_STOP_UNIT					9
#define		PREVENT_ALLOW_MEDIUM_REMOVAL	10
#define		ST_WRITE						11

#ifdef	USB_HOST_DRIVER
	unsigned char		commands[ 12 ][ 2 ]		=	{
		{ 0x06, 0x03 },		//	REQUEST_SENSE
		{ 0x06, 0x12 },		//	INQUIRY	
		{ 0x06, 0x1A },		//	MODE_SENSE
		{ 0x06, 0x00 },		//	ST_READ6
		{ 0x0A, 0x25 },		//	READ_CAPACITY
		{ 0x0A, 0x23 }, 	//	ST_WRITE
		{ 0x0A, 0x28 },		//	ST_READ
		{ 0x0A, 0x34 },		//	PRE-FETCH

		{ 0x06, 0x00 },		//	TEST_UNIT_READY
		{ 0x06, 0x1B },		//	START_STOP_UNIT
		{ 0x06, 0x1E },		//	PREVENT_ALLOW_MEDIUM_REMOVAL
		{ 0x0A, 0x2A }, 	//	ST_WRITE

	};

	//Mass Storage inquiry command response data
	static unsigned char MS_UFI_Inquiry_Data[] = 
	{
	   0x00,                        // Device class
	   0x80,                        // RMB BYTE is set by inquiry data
	   0x02,                        // ANSI SCSI 2
	   0x00,                        // Data format = 0
	   0x1F,                        // Additional length 27 byte
	   0x00, 0x00, 0x00,
	   'S','A','M','S','U','N','G',' ',
	   'M','a','s','s',' ','S','t','o',
	   'r','a','g','e',' ',' ',' ',' ',
	   '1','.','0','0'
	};


	int		UsbHostConnected;
	int		UsbHostDeviceOK;
#else
	extern	int		UsbHostConnected;
	extern	int		UsbHostDeviceOK;

#endif



int		InitUSB_Disk(void);
void	Hcd_Init(void);
unsigned long	Get_Hcd_DeviceConnectInf(void);
unsigned char	Hcd_DeviceConnect(void);
void	Hcd_DeviceDisConnect(void);
unsigned char bulk_only_transfer( unsigned char command_index, unsigned char *buffer_ptr, unsigned long logical_block_address, unsigned short allocation_length );
int		Hcd_DoTransfer(void);


extern	int		UsbHostConnected;

int	UsbReadSector(long sector,long datasize,unsigned char*buff);
int	UsbWriteSector(long sector,long datasize,unsigned char*buff);
int	UsbHostDrv( void );     /* USB HOST�h���C�o�[�X�N */
void	UsbHostInitial(void);


