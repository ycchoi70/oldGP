/****************************************************
*  Dos file system emulation program  common header	*
*	(Doscomm.H)		1997,4,22	Ver 1.10			*
****************************************************/
#ifndef	DOSCOMM_DEF
#define	DOSCOMM_DEF

//#ifndef TBQ
//#define TBQ(a)      (sizeof a/sizeof a[0])
//#endif

#define	BOOL		int					/* boolean */
#define	BYTE		unsigned char		/* byte storage */
#ifndef	TRUE
#define	TRUE		1					/* boolean True */
#define	FALSE		0					/* boolean False */
#endif

#define	MAX_DEVICE	5

#define	MaxOpen		16		/* Maximum concurrent open files */
#define	IbuffSize	0x8000	/* Maximum internal buffer size */

#define	_CREATE		1					/* file create mode */
#define	_OPEN		2					/* file open mode */
#define	_READ		4					/* normal read mode */
#define	_WRITE		8					/* normal write mode */
#define	_UPDATE		0x10				/* write override mode */
#define	_TRUNC		0x20				/* write truncate mode */

struct find_t {
    unsigned char	reserved[25];		//00-10:FileName
										//11:mode
										//12:drive
										//13:att
										//14-15:DirNo
										//16-19:Cluster No
										//20-23:DirMax
										//24:dirbuff.dummy
	unsigned char	attrib;				
    unsigned int	wr_time;
	unsigned int	wr_date;
	long			size;
    char			name[260];
};

typedef struct {				/* file Directory segment */
	char	Name[8];			/* File Name */
	char	Extention[3];		/* File Name extention */
	BYTE	Attributes;			/* File Attributes */
	BYTE	dummy;				/* dummy */
	BYTE	msTime;				/* dummy */
	short	VfatTime;				/* Create time */
	short	VfatDate;				/* Create time */
	short	AcsDate;				/* Create time */
	unsigned short	StartClusterHigh;		/* Start Cluster number */
	short	Time;				/* Create time */
	short	Date;				/* Create Date */
	unsigned short	StartCluster;		/* Start Cluster number */
	long	FileSize;			/* File Size */
} DIR;

typedef struct {
	BYTE	DUMMY0[3];			/* near jmp with Nop */
	char	Name[8];			/* product name */

	short	SectorPerBytes;		/* Sector/Bytes */
	BYTE	ClusterPerSectors;	/* cluster/Sectors */
	unsigned short	ReservedSectors;	/* reserved sectors */
	BYTE	AllocFat;			/* number of fat alloction (1 or 2) */
	unsigned short	Dirs;		/* root directorys */
	unsigned short	Sectors;	/* number of sectors */
	BYTE	discripter;			/* Media Discripter */
	short	FatPerSectors;		/* FAT area size */
	short	DUMMY1;				/* Track/Sectors */
	short	DUMMY2;				/* heads */
	long	HiddenSectors;		/* hidden sectors */
	long	Sectors2;			/* maximum sectors (over 32MB) */

	long	MaxSectors;			/* maximum sectors */
	long	MaxCluster;			/* number of Clusters */
	long	StartDir;			/* start of Root Dir sector */
	long	StartFat;			/* start of FAT sector */
	short	FatType;			/* FAT type 0:12, 1:16, 2:32 */
	long	ClusterOffset;		/* 1st(2) cluster sector offset */
	long	CurrentDirCluster;	/* start of current dir. cluster number */
	char	CurrentPath[512];	/* current directory name */
	long	StartSectorOffset;	/* BPB Start Offset */
} XBPB;


typedef struct {
	DIR		CurrentDirBlock;			/* current directory original block */
	int		oflag;
	int		pmode;

	long	StartDirCluster;			/* Start of current dir. cluster */
	long	CurrentDirCluster;			/* current dir. cluster number */
	int		CurrentDir;					/* Directory number */

	long	CurrentCluster;				/* Current cluster Number */
	long	BeginCluster;				/* Start of cluster number */
	int		RelativeCluster;			/* Current Releative cluster number */

	long	FileSize;					/* file size */
	int		ClusterSize;				/* one of cluster size */
	long	CurrentData;				/* Current data pointer */
	int		Access;						/* access mode */
	int		Drive;						/* drive number */
	int		DirMode;					/* TRUE: root,  FALSE: sub dir */

	int		LongStartDir;				// Long Name Start Directory off Number(20100319)
	long	LongCurrentCluster;			/* Current cluster Number */
} IFCB;


typedef struct {
	char			CurrentDrive;		/* current drive name */
	BYTE			DriveStatus;		/* Installed drive */
//	void			*DriverPointer[MAX_DEVICE];	/* driver entry pointer */
	int				NumberOfOpenFiles;	/* current open files */
	unsigned int	OpenFlag;			/* current open file status */
	IFCB			iFcb[MaxOpen];		/* internal file control block */
	DIR				CurrentDirBlock;	/* current directory block */
//	XBPB			xBpb[MAX_DEVICE];			/* extended BPB */
//	BOOL			WriteBusy;			/* write busy status */
//	int				WriteBufferNumber;	/* current write buffer number */
//	int				AllocPointer;		/* next buffer allocation pointer */
} SimDosSystem;

/*  Buffer Write Sequence */

#define	ERASE_REQUEST	1				/* cluster erase request mode */
#define	ERASE_END		2				/* end of erase */
#define	ERASE			(ERASE_REQUEST | ERASE_END)
#define	WRITE_REQUEST	0x10			/* write request */
#define	READ_REQUEST	0x20


/* Buffer Status */

#define	USED			1
#define	READ_SYSTEM		(USED | 2)
#define	WRITE_SYSTEM	(READ_SYSTEM | 4)
#define	READ_DATA		(USED | 8)
#define	WRITE_DATA		(READ_DATA | 0x10)
#define	WRITE			0x14

typedef struct {
	int		Status;				/* buffer used status */
	int		WriteSequence;		/* write mode current sequence */
	int		Mode;				/* 0=cluster, 1=sector */
	int		FatMode;			/* 0=other	, 1=FAT */
	int		Drive;				/* drive number */
	long	Cluster;			/* cluster number */
	BYTE	*pt;				/* buffer pointer */
} BUFF;

typedef struct {
	BYTE		mask[11];		/* unsigned char reserved[21]; */
	BOOL		mode;			/* TRUE: root, FALSE: Sub dir */
	int			drive;			/* drive number */
	BYTE		att;			/* requested attribute */
	long		DirNo;			/* current dir number */
//	unsigned short		cluster;
//	unsigned short		DirMax;			/* number of dir entries */
	long		cluster;
	long		DirMax;			/* number of dir entries */
} FINDSTR;

typedef struct MasterBootRecode {
    BYTE    checkRoutionOnx86[446];
    struct {
        BYTE    bootDescriptor;             /* 0x80: bootable device, 0x00: non-bootable */
        BYTE    firstPartitionSector[3];    /* 1st sector number */
        BYTE    fileSystemDescriptor;       /* 1:FAT12, 4:FAT16(less than 32MB), 5:�g�� DOS �p�[�e�B�V����,
                                               6:FAT16(more 32MB), 0xb:FAT32(more 2GB),
                                               0xc:FAT32 Int32h �g��, 0xe:FAT16 Int32h �g��,
                                               0xf:�g�� DOS �p�[�e�B�V������ Int32h �g�� */
        BYTE    lastPartitionSector[3];
        BYTE    firstSectorNumbers[4];      /* first sector number (link to BPB sector) */
        BYTE    numberOfSectors[4];
    }   partitionTable[4];
    BYTE    sig[2];                         /* 0x55, 0xaa */
}   MBRecode;
/* FAT16 BPB */
typedef struct FAT16BPB_t {
    BYTE    jmpOpeCode[3];          /* 0xeb ?? 0x90 */
    BYTE    OEMName[8];
    /* FAT16 */
    BYTE    bytesPerSector[2];      /* bytes/sector */
    BYTE    sectorsPerCluster;      /* sectors/cluster */
    BYTE    reservedSectors[2];     /* reserved sector, beginning with sector 0 */
    BYTE    numberOfFATs;           /* file allocation table */
    BYTE    rootEntries[2];         /* root entry (512) */
    BYTE    totalSectors[2];        /* partion total secter */
    BYTE    mediaDescriptor;        /* 0xf8: Hard Disk */
    BYTE    sectorsPerFAT[2];       /* sector/FAT (FAT32 always zero: see bigSectorsPerFAT) */
    BYTE    sectorsPerTrack[2];     /* sector/track (not use) */
    BYTE    heads[2];               /* heads number (not use) */
    BYTE    hiddenSectors[4];       /* hidden sector number */
    BYTE    bigTotalSectors[4];     /* total sector number */
//FAT32
    /* info */
    BYTE    driveNumber;
    BYTE    unused;
    BYTE    extBootSignature;
    BYTE    serialNumber[4];
    BYTE    volumeLabel[11];
    BYTE    fileSystemType[8];      /* "FAT16   " */
    BYTE    loadProgramCode[448];
    BYTE    sig[2];                 /* 0x55, 0xaa */
}    fat16;
/* FAT32 BPB */
typedef struct FAT32BPB_t {
    BYTE    jmpOpeCode[3];          /* 0xeb ?? 0x90 */
    BYTE    OEMName[8];
    /* FAT32 */
    BYTE    bytesPerSector[2];
    BYTE    sectorsPerCluster;
    BYTE    reservedSectors[2];
    BYTE    numberOfFATs;
    BYTE    rootEntries[2];
    BYTE    totalSectors[2];
    BYTE    mediaDescriptor;
    BYTE    sectorsPerFAT[2];
    BYTE    sectorsPerTrack[2];
    BYTE    heads[2];
    BYTE    hiddenSectors[4];
    BYTE    bigTotalSectors[4];
    BYTE    bigSectorsPerFAT[4];    /* sector/FAT for FAT32 */
//FAT32
    BYTE    extFlags[2];            /* use index zero (follows) */
                                    /* bit 7      0: enable FAT mirroring, 1: disable mirroring */
                                    /* bit 0-3    active FAT number (bit 7 is 1) */
    BYTE    FS_Version[2];
    BYTE    rootDirStrtClus[4];     /* root directory cluster */
    BYTE    FSInfoSec[2];           /* 0xffff: no FSINFO, other: FSINFO sector */
    BYTE    bkUpBootSec[2];         /* 0xffff: no back-up, other: back up boot sector number */
    BYTE    reserved[12];
    /* info */
    BYTE    driveNumber;
    BYTE    unused;
    BYTE    extBootSignature;
    BYTE    serialNumber[4];
    BYTE    volumeLabel[11];
    BYTE    fileSystemType[8];      /* "FAT32   " */
    BYTE    loadProgramCode[420];
    BYTE    sig[2];                 /* 0x55, 0xaa */
}    fat32;
typedef struct LNFEntry_t {
    BYTE    LFNSeqNumber;           /* LNF recode sequence number
                                         bit 7        �폜������ 1 �ɂȂ�
                                         bit 6        0: LNF �͑����A1: LNF �̍Ō�̃V�[�P���X
                                         bit 5 �` 0   LNF �̏��Ԃ�\�� (1 �` 63) */
    BYTE    name1st[10];            /* Unicode 5 characters */
    BYTE    attribute;              /* file attribute (always 0x0f) */
    BYTE    reserved;               /* always 0x00 */
    BYTE    checkCodeForShortName;  /* DOS ���̃`�F�b�N�E�R�[�h */
    BYTE    name2nd[12];            /* Unicode 6 characters */
    BYTE    cluster[2];             /* always 0x0000 */
    BYTE    name3rd[4];             /* Unicode 2 characters */
}   LNFEntry;

#endif


#ifdef	DOSEM_PROC
	#define	BUFFCNT	(IbuffSize / 512)
	SimDosSystem	System;			/* System parameters */

	struct{
		XBPB	xBpb;				/* extended BPB */
		BOOL	WriteBusy;			/* write busy status */
		int		WriteBufferNumber;	/* current write buffer number */
		int		AllocPointer;		/* next buffer allocation pointer */
		int		MaxBuffers;			/* Maximum internal buffers */
		BUFF	sysBuff[BUFFCNT];	/* buffer control block */
	}DevInf[MAX_DEVICE];
	//BYTE	BufferMap[BUFFCNT];
	int	LNFRecCnt;
	LNFEntry	LNFFileName[63];	//20091113(Long Name)
	int	sLNFRecCnt;
	LNFEntry	sLNFFileName[63];	//20100322(Long Name)
	char	DosFileName[11+1];
	int		DosNameKind;
	char	findDirPath[80], findpath[80], loadFileName[260], findFileName[260], srcFileName[260];

	//SD�͕�
	BYTE	ClustBuffer[MAX_DEVICE-1][8][8][512];				//32KB*4(MAX_DEVICE)
	BYTE	SD_ClustBuffer[16][8][512];						//64KB

	char	openFilePath[260];
	char	fnddirectory[260];
	char	FilePath2[260];

	short	GetCurrentTime( void );
	short	GetCurrentDate( void );

	IFCB	sFcb;						//20100630
	IFCB	ssFcb;						//20100630


#endif



BOOL	InitializeFileSystem (void);
BOOL	MountMedia (int drive);
BOOL	DisMountMedia (int drive);

int		Get_FCBNumber (void);
BOOL	Close_FCBNumber (int channel);
BOOL	Build_FileName (char *FileName, char *FilePath);
BOOL	Is_FileName (char *FilePath);

BOOL	Fined_File (int Channel, char *FilePath);
BOOL	File_Install (int Channel, char *FilePath);
IFCB	*Get_FCBaddress (int channel);
BOOL	Set_FCB (int Channel, char *FilePath);
BOOL	Close_FCBNumber (int Channel);
int		File_Rewind (IFCB *iFcb);
int		Get_NextCluster (IFCB *iFcb);
int		Extent_Cluster (IFCB *iFcb);
int		Truncate_Cluster (IFCB *iFcb);		/* cluster truncate error */
int		FRead_Data (IFCB *iFcb, unsigned char *buff, int dsize);
int		FWrite_Data (BOOL mode, IFCB *iFcb, unsigned char *buff, int dsize);

BOOL	Read_Data (BYTE *buff, int drive, long Cluster, int offset, int dsize);
BOOL	Read_Data_Dir (BYTE *buff, int drive, long Cluster, int offset, int dsize);
BOOL	Write_Data (BOOL mode, BYTE *buff, int drive, long Cluster, int offset, int dsize);
BOOL	Write_Data_Dir (BOOL mode, BYTE *buff, int drive, long Cluster, int offset, int dsize);
BOOL	Read_System (BYTE *buff, int drive, long Cluster, int offset, int dsize);
BOOL	Write_System (BYTE *buff, int drive, long Cluster, int offset, int dsize);
BOOL	Read_Dir (BYTE *buff, int drive, long Cluster, int offset, int dsize);
BOOL	Write_Dir (BYTE *buff, int drive, long Cluster, int offset);
int		SearchCluster (int drive, long Cluster, int mode);
int		AllocateClusterBuffer (int drive);
int		FlushClusterBuffer (int drive,int buffNo);
BOOL	LoadDirectory (IFCB *iFcb, char *directory, BOOL mode);

void	SetupFCB (IFCB *iFcb, int drive);
void	SetFAT (int FATnumber, long FATdata, int drive);
long	GetFAT (int FATnumber, int drive);
BOOL	Read_Cluster (int drive,int buffNo);
BOOL	Write_Cluster (int drive,int buffNo);
unsigned int	GetNewCluster (int drive);
BOOL	CreateDirectory (IFCB *iFcb, char *DirName, int drive);
BOOL	GetBPB (int drive, XBPB *xBPB);
void	WaitForWriteFinish (void);
long	SearchFATbuffer (long sect, int drive);
long	CnvSectorNumber (long Cluster, int drive);
void	WaitForAnyBufferReady (int drive);
void	WaitForReadEnd (int drive,int bufferNo);
BOOL	WriteIoRequest (int drive);
int		FlushAll (int drive);
BOOL	FindDirectory (FINDSTR *FindBlk, struct find_t *finddata);
BOOL	filecmp (char *Name, char *mask);

/* external functions */
BOOL	ReadBPB (int drive, XBPB *xBPB);
int		Dir_File_Write (int channel, void *buff, int dsize, long pointer);
int		File_Write_Data (BOOL mode, IFCB *iFcb, unsigned char *buff, int dsize);

int shortNameCheckCode(unsigned char* Name);
void	LNFFileBuild(char* name);
void	GetLnfFileName(LNFEntry* LnfFDir,int *NameCnt,char* name);
void	SetFileName2LnfName(char* FileName);
BOOL	Rename_File_Install (int Channel, char *FileName,DIR* sDir);



int		MakeDirectory (char *FileName);
int		ChangeDir (char *FileName);
int		File_Open (char *FileName, int mode);
int		File_Read (int channel, void *buff, int dsize, long pointer);
int		File_Write (int channel, void *buff, int dsize, long pointer);
int		File_Close (int mode,int Channel);
int		Find_First(char *wildspec, unsigned attr, struct find_t *finddata);
int		Find_Next (struct find_t *finddata);
int		DelDir (char *DirName);
int		Delete (char *FileName);
int		FileRename (char *src, char *dist);
int		File_Search (char *FileName,int *size);
int		File_Seek(int channel, int offset, int mode);
