///////////////////////////////////////////////////////////
//	Lan Driver
///////////////////////////////////////////////////////////

#include	<stdio.h>
#include	<string.h>

#include "define.h"
#include "s2440.h"
#include "w5100.h"
#include "socket.h"
#include "bios.h"

extern	void DModeSendMsg( char *ptr );

typedef struct{
   uint8 ip[4];                   // for setting SIP register
   uint8 gw[4];                   // for setting GAR register
   uint8 sn[4];                   // for setting SUBR register
   uint8 mac[6];				  // for setting SHAR register
   int	PortAddr;
}TCP_SET;

   uint8 tx_mem_conf = 0x55;          // for setting TMSR regsiter
   uint8 rx_mem_conf = 0x55;          // for setting RMSR regsiter
   
   TCP_SET	Set;
   TCP_SET w53Inf;
  
   uint8 serverip[4] = {192,168,111,100};              // "TCP SERVER" IP address for loopback_tcpc()

   int	_LanDrvMode;

/* Initialization & Interrupt request routine */


/**
 * "TCP SERVER" loopback program.
 */ 
void     loopback_tcps(SOCKET s, uint16 port, uint8* buf, uint8 mode)
{
   uint16 len;
   
   switch(getSn_SR(s))                // check SOCKET status
   {                                   // ------------
      case SOCK_ESTABLISHED:           // ESTABLISHED?
         if(getSn_IR(s) & Sn_IR_CON)   // check Sn_IR_CON bit
         {
            setSn_IR(s,Sn_IR_CON);     // clear Sn_IR_CON
         }
         if((len=getSn_RX_RSR(s)) > 0) // check the size of received data
         {
            len = recv(s,buf,len);     // recv
            if(len !=send(s,buf,len))  // send
            {
//               printf("%d : Send Fail.len=%d\r\n",s,len);
            }
         }
         break;
                                       // ---------------
   case SOCK_CLOSE_WAIT:               // PASSIVE CLOSED
         disconnect(s);                // disconnect 
         break;
                                       // --------------
   case SOCK_CLOSED:                   // CLOSED
      close(s);                        // close the SOCKET
      socket(s,Sn_MR_TCP,port,mode);   // open the SOCKET  
      break;
                                       // ------------------------------
   case SOCK_INIT:                     // The SOCKET opened with TCP mode
      listen(s);                       // listen to any connection request from "TCP CLIENT"
//      printf("%d : LOOPBACK_TCPS(%d) Started.\r\n",s,port);
      break;
   default:
      break;
   }
}

/**
 * "TCP CLIENT" loopback program.
 */ 
int     tspc_Open(SOCKET s, uint8* addr, uint16 port, uint8 mode)
{
//   uint16 len;
   static uint16 any_port = 1000;
	int	status= 0;

	TimerStart(1,100);	//1s Start
	while(status != 0x03){
	   switch(getSn_SR(s))                   // check SOCKET status
	   {                                      // ------------
		  case SOCK_ESTABLISHED:              // ESTABLISHED?
#ifdef	OLD
			 if(getSn_IR(s) & Sn_IR_CON)      // check Sn_IR_CON bit
			 {
	//            printf("%d : Connect OK\r\n",s);
				setSn_IR(s,Sn_IR_CON);        // clear Sn_IR_CON
			 }
			 if((len=getSn_RX_RSR(s)) > 0)    // check the size of received data
			 {
				len = recv(s,buf,len);        // recv
				if(len !=send(s,buf,len))     // send
				{
	//               printf("%d : Send Fail.len=%d\r\n",s,len);
				}
			 }
#endif
			 status |= 0x02;
			 break;
											  // ---------------
	   case SOCK_CLOSE_WAIT:                  // PASSIVE CLOSED
			 disconnect(s);                   // disconnect 
			 break;
											  // --------------
	   case SOCK_CLOSED:                      // CLOSED
		  close(s);                           // close the SOCKET
		  socket(s,Sn_MR_TCP,any_port++,mode);// open the SOCKET with TCP mode and any source port number
		  status |= 0x01;
		  break;
											  // ------------------------------
	   case SOCK_INIT:                        // The SOCKET opened with TCP mode
		  connect(s, addr, port);             // Try to connect to "TCP SERVER"
		  break;
	   default:
		  break;
	   }
		if(time_flag[1] != 0){	break;	}	//Time Out
	}
	if(status != 0x03){	return(-1);	}
	return(0);
}

/**
 * UDP loopback program.
 */ 
void     loopback_udp(SOCKET s, uint16 port, uint8* buf, uint8 mode)
{
   uint16 len;
   uint8 destip[4];
   uint16 destport;
   
   switch(getSn_SR(s))
   {
                                                         // -------------------------------
      case SOCK_UDP:                                     // 
         if((len=getSn_RX_RSR(s)) > 0)                   // check the size of received data
         {
            len = recvfrom(s,buf,len,destip,&destport);  // receive data from a destination
            if(len !=sendto(s,buf,len,destip,destport))  // send the data to the destination
            {
//               printf("%d : Sendto Fail.len=%d,",s,len);
//               printf("%d.%d.%d.%d(%d)\r\n",destip[0],destip[1],destip[2],destip[3],destport);
            }
         }
         break;
                                                         // -----------------
      case SOCK_CLOSED:                                  // CLOSED
         close(s);                                       // close the SOCKET
         socket(s,Sn_MR_UDP,port,mode);                  // open the SOCKET with UDP mode
         break;
      default:
         break;
   }
}

/**
 * "TCP SERVER" loopback program.
 */ 
int     tcps_Open(SOCKET s, uint16 port)
{
	int	status= 0;

	TimerStart(1,100);	//1s Start
	while(status != 0x03){
		switch(getSn_SR(s))                // check SOCKET status
		{                                   // ------------
		case SOCK_ESTABLISHED:           // ESTABLISHED?
			status |= 0x02;
			break;
								   // ---------------
		case SOCK_CLOSE_WAIT:               // PASSIVE CLOSED
			disconnect(s);
			break;
								   // --------------
		case SOCK_CLOSED:                   // CLOSED
			close(s);                        // close the SOCKET
			socket(s,Sn_MR_TCP,port,0);   // open the SOCKET  
			status |= 0x01;
			break;
								   // ------------------------------
		case SOCK_INIT:                     // The SOCKET opened with TCP mode
			listen(s);                       // listen to any connection request from "TCP CLIENT"
			status |= 0x02;
			break;
			default:
			break;
		}
		if(time_flag[1] != 0){	break;	}	//Time Out
	}
	if(status != 0x03){	return(-1);	}
	return(0);
}

void	LanIntEnable(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 
//	volatile IOP_REG	*pIOPRegs   = (IOP_REG *)IOP_BASE;

	pINTRegs->rSRCPND  = BIT_EINT1;
	if (pINTRegs->rINTPND & BIT_EINT1)
		pINTRegs->rINTPND = BIT_EINT1;
	pINTRegs->rINTMSK &= ~BIT_EINT1;
	
}
uint16	lanRecCnt;
uint8	recBuff[0x2000];
int	W5100IntFlag;
int isReceivedAndEnd; //flag end after receive
int iCommKind; // commmunication kind
uint8	ir_status;
uint8	ir_mask;
unsigned char	DefMacAddr[6]= {0x00,0x08,0xDC,0x00,111,201}; 
unsigned char	DefIpAddr[4]= {192,168,100,100}; 
unsigned char	DefGatewayAddr[4]= {192,168,100,1}; 
unsigned char	DefSubnetAddr[4]= {255,255,255,0}; 
unsigned char	severIpAddr[4]= {192,168,100,101};

void	DefaultAddressSet(void)
{
	//MAC Addr
	memcpy(&Set.mac[0],DefMacAddr,6);
	//IP Addr
	memcpy(&Set.ip[0],severIpAddr,4);
	//Subnet Addr
	memcpy(&Set.sn[0],DefSubnetAddr,4);
	//Gateway
	memcpy(&Set.gw[0],DefGatewayAddr,4);
	//Port
	Set.PortAddr= 9000;

}
	int	SocketNo;
int	W5100Open(void)
{
	int	ret= 0;

	SocketNo= 0;
	DefaultAddressSet();
	iinchip_init();							/* initiate W5300 */
	sysinit(tx_mem_conf,rx_mem_conf);	/* allocate internal TX/RX Memory of W5300 */
	setSHAR(Set.mac);                                      // set source hardware address
	/* configure network information */
	setGAR(Set.gw);                                     // set gateway IP address
	setSUBR(Set.sn);                                    // set subnet mask address
	setSIPR(Set.ip);                                    // set source IP address

	memset(&w53Inf,0,sizeof(w53Inf));
	/* verify network information */
	getSHAR(w53Inf.mac);                                      // get source hardware address 
	getGAR(w53Inf.gw);                                        // get gateway IP address      
	getSUBR(w53Inf.sn);                                       // get subnet mask address     
	getSIPR(w53Inf.ip);                                       // get source IP address       
	
	
	tcps_Open(0, Set.PortAddr);

	if(memcmp(w53Inf.mac,Set.mac,sizeof(Set.mac)) != 0){	ret= -1;	}
	if(memcmp(w53Inf.gw,Set.gw,sizeof(Set.mac)) != 0){	ret= -1;	}
	if(memcmp(w53Inf.sn,Set.sn,sizeof(Set.mac)) != 0){	ret= -1;	}
	if(memcmp(w53Inf.ip,Set.ip,sizeof(Set.mac)) != 0){	ret= -1;	}
	return(ret);
}
int	TcpOpen(void)
{
	return(tcps_Open(0,Set.PortAddr));	//Server Open
}
int	UdpOpen(void)
{
	int	ret;
	ret= socket(2,Sn_MR_UDP,Set.PortAddr,0);                  // open the SOCKET with UDP mode
	if(ret == 1){	return(0);		}						//OK
	return(-1);
}
/************************************************************/
/* LAN Driver												*/
/************************************************************/
void LanDriverInit(void)
{
#ifdef	WIN32
	return;
#endif

	int status;
	
	//ethernet server open
	W5100IntFlag= 0;
	isReceivedAndEnd = 0;
	iCommKind = 0;
	W5100Open();	
	
	IINCHIP_WRITE(Sn_IR(0), (uint8)0x1f);
	setIMR(0x0f);	

	status = IINCHIP_READ(Sn_SR(0));						
	
	while(status != SOCK_ESTABLISHED)
	{
		tcps_Open(0, Set.PortAddr);
		status = IINCHIP_READ(Sn_SR(0));		
	}
	
}


int	LanDriverTsk( void )
{
	uint8 status = 0;		
	
	int	ret= NG;	

	
	LanIntEnable();	
	
		
	switch(W5100IntFlag)
	{
	case 1:					//Disconnect								
		TimerStart(2,100);		//1s Start
		status = IINCHIP_READ(Sn_SR(0));						
		while(status != SOCK_ESTABLISHED)				
		{		
			tcps_Open(0, Set.PortAddr);
			status = IINCHIP_READ(Sn_SR(0));
			
			if(time_flag[2] != 0) //time out
				break; 
		}			
		break;
	case 2:					//Recive	
	
		if(lanRecCnt == 0)
			break;
	
		if(memcmp(recBuff,"Ethernet",lanRecCnt) == 0) //ethernet request
		{
			iCommKind =  1;
			send(0,(unsigned char*)"ABCDEFG012345",13);									
			ret= OK;	
		}
		else if(memcmp(recBuff,"USB",lanRecCnt) == 0) //usb request
		{
			iCommKind = 2;
			//DModeSendMsg("TCP NG\r\n");
		}
		else if(memcmp(recBuff,"Time",lanRecCnt) == 0) //Time request
		{
			iCommKind = 3;
			//DModeSendMsg("TCP NG\r\n");
		}
		else if(memcmp(recBuff,"MAC",lanRecCnt) == 0) //MAC request
		{
			iCommKind = 4;
			//DModeSendMsg("TCP NG\r\n");
		}
		memset(recBuff, 0x00, lanRecCnt);
		break;			
	default:						//exit				
			break;			
		
	}
		
		
	
	return(ret);
}

int	W5100Test(void)
{
#ifdef	WIN32
	return(0);
#endif
	return(LanDriverTsk());
}
extern	void iinchip_irq(void);

int	_LanInterruptProc(void)
{
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rSRCPND  = BIT_EINT1;
	pINTRegs->rINTPND  = BIT_EINT1;

	iinchip_irq();

	pINTRegs->rSRCPND  = BIT_EINT1;
	if (pINTRegs->rINTPND & BIT_EINT1)
		pINTRegs->rINTPND = BIT_EINT1;

	return(0);
}
void	_LanInterruptHandler( void )
{	
    volatile INT_REG    *pINTRegs = (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_EINT1;
	_LanInterruptProc();
	pINTRegs->rINTMSK &= ~BIT_EINT1;
	
}

