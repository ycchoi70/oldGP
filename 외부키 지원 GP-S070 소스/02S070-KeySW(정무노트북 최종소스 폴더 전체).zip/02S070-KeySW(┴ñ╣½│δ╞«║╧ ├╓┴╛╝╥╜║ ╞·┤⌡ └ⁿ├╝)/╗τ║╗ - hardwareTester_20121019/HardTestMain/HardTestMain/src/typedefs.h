/*** Data type definition ***
  /  
 / /
/ / /\
\\\/ /// CLABSYS
 \\ ///  Cyber Lab System
  \\//
   \/

Revision history___
2004-4-28 John
*/ 

#ifndef __TYPEDEFS_H__
#define __TYPEDEFS_H__

typedef unsigned char BYTE;
typedef unsigned short HWORD;
typedef unsigned int WORD;



#ifndef __cplusplus

	typedef int bool; 
#endif // __cplusplus
#endif	//#ifdef__TYPEDEF_H__

