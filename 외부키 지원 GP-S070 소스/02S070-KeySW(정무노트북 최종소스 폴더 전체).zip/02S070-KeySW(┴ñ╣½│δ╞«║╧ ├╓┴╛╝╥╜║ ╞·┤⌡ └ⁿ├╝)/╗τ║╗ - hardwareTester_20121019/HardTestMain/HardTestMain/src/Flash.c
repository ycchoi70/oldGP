#include	<stdio.h>
#include	<string.h>

#include	"define.h"
#include	"typedefs.h"
#include	"rvd.h"
#include	"deviceid.h"
#include	"nand.h"
#include	"flash.h"
#include	"lload.h"


#ifdef	WIN32
void	_ei(void)
{
}
void	_di(void)
{
}
#ifdef	WIN32
unsigned char	wReadBuff[0x100000];
extern	int FpgaWriteMain(char* pFileName);
extern	unsigned char	*DownloadBuff;		//2MB
#endif
void	main()
{
#ifdef	WIN32
	DownloadBuff= wReadBuff;
//	FpgaWriteMain("FPGA.DAT");
	return;
#endif
}
#else
extern	void	_ei(void);
extern	void	_di(void);
#endif
/********************************************************
*   FUNC  : Flash Rom Write                         	*
*	In    :												*
*	Out   : 											*
*   AUTHOR : M.Owashi                                	*
*   DATE  : 1996.8.28                               	*
*   DATE  : 1996.8.28									*
*	Update:97.03.13 kf									*
*********************************************************/
//2012.02.11 Delete
//void	FlashEraze(char *addr, long count)
//{
//	int	block;
//	int	cnt;

//	block= ((int)addr/NAND_PAGE_SIZE)/NAND_PAGE_PER_BLOCK;
//	cnt= NAND_PAGE_SIZE*NAND_PAGE_PER_BLOCK;
//	if((int)addr % cnt){	count-= ((int)addr % cnt);	}
//	else{					count-= cnt;				}
//	NAND_EraseBlock(block++);
//	while(count > 0){
//		NAND_EraseBlock(block);
//		count-= cnt;
//	}

//}
void	FlashWriteRandom(char *addr,char *data, long count)
{
//	int	sector;

//	sector= (int)addr/NAND_PAGE_SIZE;
	NAND_Write_Random((unsigned int)addr,(unsigned char*)data,count);
}
void	FlashReadRandom(char *data,char *addr,long count)
{
//	int	sector;

//	sector= (int)addr/NAND_PAGE_SIZE;
	NAND_Read_Random((unsigned int)addr,(unsigned char*)data,count);
}
void	FlashWriteSeq(char *addr,char *data, long count)
{
//	int	sector;

//	sector= (int)addr/NAND_PAGE_SIZE;
	NAND_Write_Seq((unsigned int)addr,(unsigned char*)data,count);
}
void	FlashReadSeq(char *data,char *addr,long count)
{
//	int	sector;

//	sector= (int)addr/NAND_PAGE_SIZE;
	NAND_Read_Seq((unsigned int)addr,(unsigned char*)data,count);
}

void	FlashRead_ECC(char *data,char *addr,long count)
{
//	int	sector;

//	sector= (int)addr/NAND_PAGE_SIZE;
	NAND_Read_ECC((unsigned int)addr,(unsigned char*)data,count);
}
void	NAND_Map_Check(void)
{
	int	i,j;
	RANDOM_MAP*	BadInf;
	START_MAP* StartBad;

//	NAND_Read_Seq(NAND_MAP_AREA/NAND_PAGE_SIZE,(unsigned char*)&NandBadblockMap,0x400);
	NAND_Read_Seq(NAND_MAP_AREA,(unsigned char*)&NandBadblockMap,0x400);
	if(strcmp(&NandBadblockMap.StartBadblock.pass[0],NAND_BADMAP_PASS) == 0){	return;	}
	//Make Bad Map
	memset(&NandBadblockMap,0xff,sizeof(NandBadblockMap));
	//Start Bad Info
	StartBad= (START_MAP*)&NandBadblockMap.StartBadblock;
//	strcpy(StartBad->pass,NAND_BADMAP_PASS);
	StartBad->StartBadCnt= 0;
	for(i= 0; i < 4096; i++){
		if(NAND_IsBadBlock(i) == 1){
			StartBad->BadNo[StartBad->StartBadCnt++]= i;
		}
		for(j=0;j<100;j++); //wait tWB(100ns)//??????
	}
	//Random Area
	BadInf= (RANDOM_MAP*)&NandBadblockMap.RandomMap;
	BadInf->ChangeBadCnt= 0;
	BadInf->ReserveStartNo= NAND_RESERVED_AREA/NAND_PAGE_SIZE/NAND_PAGE_PER_BLOCK;
//	NAND_Write_Seq(NAND_MAP_AREA/NAND_PAGE_SIZE,(unsigned char*)&NandBadblockMap,0x400);
	NAND_Write_Seq(NAND_MAP_AREA,(unsigned char*)&NandBadblockMap,0x400);
}
void	NAND_Map_SetPassword(void)
{
	START_MAP* StartBad;

//	NAND_Read_Seq(NAND_MAP_AREA/NAND_PAGE_SIZE,(unsigned char*)&NandBadblockMap,0x400);
	NAND_Read_Seq(NAND_MAP_AREA,(unsigned char*)&NandBadblockMap,0x400);
	if(strcmp(&NandBadblockMap.StartBadblock.pass[0],NAND_BADMAP_PASS) == 0){	return;	}

	StartBad= (START_MAP*)&NandBadblockMap.StartBadblock;
	strcpy(StartBad->pass,NAND_BADMAP_PASS);
//	NAND_Write_Seq(NAND_MAP_AREA/NAND_PAGE_SIZE,(unsigned char*)&NandBadblockMap,0x400);
	NAND_Write_Seq(NAND_MAP_AREA,(unsigned char*)&NandBadblockMap,0x400);
}
void	NAND_Map_Clear(void)
{
	memset(&NandBadblockMap,0xff,sizeof(NandBadblockMap));
//	NAND_Write_Seq(NAND_MAP_AREA/NAND_PAGE_SIZE,(unsigned char*)&NandBadblockMap,0x400);
	NAND_Write_Seq(NAND_MAP_AREA,(unsigned char*)&NandBadblockMap,0x400);
}
int	IsNAND_Map(void)
{

//	NAND_Read_Seq(NAND_MAP_AREA/NAND_PAGE_SIZE,(unsigned char*)&NandBadblockMap,0x400);
	NAND_Read_Seq(NAND_MAP_AREA,(unsigned char*)&NandBadblockMap,0x400);
	if(strcmp(&NandBadblockMap.StartBadblock.pass[0],NAND_BADMAP_PASS) == 0){	return(0);	}
	else{																		return(-1);	}
//	return(-1);
}
