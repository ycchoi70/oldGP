/************************************************
 * NAME    : 44BLIB.C				*
 * Version : 17.APR.00				*
 ************************************************/

//  Revision History 
//  Delay()

#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#include "Selib.h"
//#include "Option.h"
#include "define.h"

#include "glplcd.h"
#include "CommBuff.h"
#include "mylib.h"
#include "s2440.h"
#include "Hal_Time.h"


/************************* PORTS ****************************/
void Port_Init(void)
{
	volatile IOP_REG    *pIOPReg;
    pIOPReg = (volatile IOP_REG *)IOP_BASE;
	//ADDR26->ADDR16,ADDR0
	//GPA                FCE      LED GREEN      FRE         FWE         ALE         CLE        CS(5)     LED RED      CS(3)       CS(2)     ADDR
	pIOPReg->rGPACON= (1 << 22) | (0 << 21) | (1 << 20) | (1 << 19) | (1 << 18) | (1 << 17) | (1 << 16) |(0 << 15) | (1 << 14) | (1 << 13) | 0x60f;
	pIOPReg->rGPADAT= 0;
	//GPB              JTAG(TMS)   JTAG(TDO)   PB4(LCD)  TOUT3(BUZZER)     TOUT2(BACKLIGHT)      TOUT1(FPGA)      TOUT0(FPGA)    RESERVE
	//GPB              JTAG(TMS)   JTAG(TDO)   PB4(LCD)  OUT(BUZZER)     TOUT2(BACKLIGHT)      TOUT1(FPGA)      TOUT0(FPGA)    RESERVE
	pIOPReg->rGPBCON= (1 << 14) | (0 << 12) | (1 << 8) | (1 << 6)       |  (2 << 4)           |  (2 << 2)      |  (2 << 0) |     0x3f0c00;
	pIOPReg->rGPBDAT= 0;
	pIOPReg->rGPBUP= 0x00000080;
	//GPC                 VD7        VD6         VD5         VD4         VD3         VD2         VD1         VD0       CS_EXT        
	pIOPReg->rGPCCON= (2 << 30) | (2 << 28) | (2 << 26) | (2 << 24) | (2 << 22) | (2 << 20) | (2 << 18) | (2 << 16) | (1 << 14) | 
	//GPC				 VM       VFRAME      VLINE      VCLK     RESERVE
					  (2 << 8) | (2 << 6) | (2 << 4) | (2 << 2) | 0x3c03;
	pIOPReg->rGPCDAT= 0;
	//GPD               VD23        VD22        VD21        VD20        VD19        VD18        VD17        VD16        VD15     
	pIOPReg->rGPDCON= (2 << 30) | (2 << 28) | (2 << 26) | (2 << 24) | (2 << 22) | (2 << 20) | (2 << 18) | (2 << 16) | (2 << 14) |
	//GPD               VD14        VD13        VD12        VD11      VD10       VD9        VD8     
                      (2 << 12) | (2 << 10) | (2 << 8) | (2 << 6) | (2 << 4) | (2 << 2) | (2 << 0);
	//GPE               IICSDA       IICSCL    IIS, SDCARD RESERVE  
	pIOPReg->rGPECON= (2 << 30) | (2 << 28) | 0xffffff;
	//GPF              FPGA_IN5    FPGA_IN4    FPGA_IN3   FPGA_IN2   FPGA_IN1   FPGA_IN0   EINT1(ETHERNET)     EINT0(FPGA)
	pIOPReg->rGPFCON= (2 << 14) | (2 << 12) | (2 << 10) | (2 << 8) | (2 << 6) | (2 << 4) | (2 << 2)          |   (2 << 0);
	//GPG              NAND STATUS                       TEMP_CS     RUN/STOP   FPGA(TCK)   FPGA(TDI)  FPGA_DOUT1 FPGA_DOUT0  RESERVE
	pIOPReg->rGPGCON= (0 << 30) | (0 << 28) | (0 <<26) |(1 << 20) | (0 << 14) | (1 << 12) | (1 << 10) | (1 << 2) | (1 << 0) | 0xcf03f0;
	pIOPReg->rGPGDAT= 0;
	pIOPReg->rGPGUP= 0x00000460;
	//GPH             FPGA(CLK)    RS422_DIR     CTS1        RTS1        RXD1       TXD1      RXD0       TXD0       RTS0       CTS0      RESERVE
	pIOPReg->rGPHCON= (1 << 18) | (1 << 16) | (3 << 14) | (3 << 12) | (2 << 10) | (2 << 8) | (2 << 6) | (2 << 4) | (2 << 2) | (2 << 0) | 0x300000;
	pIOPReg->rGPHDAT= 0x00000200;
	pIOPReg->rGPHUP= 0x00000700;
	//GPJ             CMOS CAMERA RESERVE
	pIOPReg->rGPJCON= 0x3ffffff;
}

/************************* PWM ****************************/
void	Timer0_Init(int Prescaler,int Devid,int Count,int CmpCnt)
{
    volatile PWM_REG    *pPWMRegs = (PWM_REG *)PWM_BASE;
    unsigned      TCON;
	int	dev;

    //Priscaler
    pPWMRegs->rTCFG0 &= ~0x000000FF;		// Set prescaler 0 to 100 
	pPWMRegs->rTCFG0 |= Prescaler;
	switch(Devid){
	case 2:		dev= 0;		break;
	case 4:		dev= 1;		break;
	case 8:		dev= 2;		break;
	case 16:	dev= 3;		break;
	default:	dev= 0;		break;
	}
	//1/16
    pPWMRegs->rTCFG1 &= ~(0xF << 0);					// Select MUX input 1/16
    pPWMRegs->rTCFG1 |= dev << 0;					// 1/16
	//Count
    pPWMRegs->rTCNTB0= Count;			//FCLK:400000000,PCLK:FCLK/6(66.666MHz)
	pPWMRegs->rTCMPB0= CmpCnt;

    // Start timer in auto reload mode
    TCON = pPWMRegs->rTCON & ~(0x1F << 0);
    pPWMRegs->rTCON = TCON | (0x2 << 0);		//Manual Update for TCNTB0,TCMPB0
    pPWMRegs->rTCON = TCON | (0x9 << 0);		//Interval,Start


}
void	Timer1_Init(int Prescaler,int Devid,int Count,int CmpCnt)
{
    volatile PWM_REG    *pPWMRegs = (PWM_REG *)PWM_BASE;
    unsigned      TCON;
	int	dev;
    
    pPWMRegs->rTCFG0 &= ~0x000000FF;
	pPWMRegs->rTCFG0 |= Prescaler;					// Set prescaler 1 to 100 

	switch(Devid){
	case 2:		dev= 0;		break;
	case 4:		dev= 1;		break;
	case 8:		dev= 2;		break;
	case 16:	dev= 3;		break;
	default:	dev= 0;		break;
	}
    pPWMRegs->rTCFG1 &= ~(0xF << 4);			// Select MUX input 1/16
    pPWMRegs->rTCFG1 |= dev << 4;				// 1/16

    pPWMRegs->rTCNTB1 = Count;			//FCLK:399650000,PCLK:FCLK/6		1ms
	pPWMRegs->rTCMPB1= CmpCnt;

    // Start timer in auto reload mode
    TCON = pPWMRegs->rTCON & ~(0x0F << 8);
    pPWMRegs->rTCON = TCON | (0x2 << 8);
    pPWMRegs->rTCON = TCON | (0x9 << 8);		//Interval,Start

}
void	Timer2_Init(int Prescaler,int Devid,int Count,int CmpCnt)
{
    volatile PWM_REG    *pPWMRegs = (PWM_REG *)PWM_BASE;
    unsigned      TCON;
  	int	dev;
  
    pPWMRegs->rTCFG0 &= ~0x0000FF00;
	pPWMRegs->rTCFG0 |= (Prescaler << 8);		// Set prescaler 1 to 100 
	
	switch(Devid){
	case 2:		dev= 0;		break;
	case 4:		dev= 1;		break;
	case 8:		dev= 2;		break;
	case 16:	dev= 3;		break;
	default:	dev= 0;		break;
	}
    pPWMRegs->rTCFG1 &= ~(0xF << 8);					// Select MUX input 1/16
    pPWMRegs->rTCFG1 |= dev << 8;				// 1/16

    pPWMRegs->rTCNTB2 = Count;			//FCLK:399650000,PCLK:FCLK/6		1ms
	pPWMRegs->rTCMPB2= CmpCnt;

    // Start timer in auto reload mode
    TCON = pPWMRegs->rTCON & ~(0x0F << 12);
    pPWMRegs->rTCON = TCON | (0x2 << 12);
    pPWMRegs->rTCON = TCON | (0x9 << 12);		//Interval,Start

    // unmask for timer2
} // end of Timer4_Init(...)
void	Timer3DefltInit(void)
{
	volatile PWM_REG    *pPWMRegs= (volatile PWM_REG *)PWM_BASE;
//    volatile INT_REG    *pIntRegs = (volatile INT_REG *)INT_BASE; 
    unsigned      TCON;
	int	Cnt;

	Cnt= HAL_CLOCK_TICK/40;
    pPWMRegs->rTCFG0 &= ~0x0000FF00;	// Set prescaler 1 to 100 
	//Prescale=100
    pPWMRegs->rTCFG1  &= ~(0xf << 12);         /* Timer3's Divider Value              */
    pPWMRegs->rTCFG1  |=  (0x3   << 12);         /* 1/16                                 */
    pPWMRegs->rTCNTB3  = Cnt;		/* Interrupt Frequency(1ms)          */
	pPWMRegs->rTCMPB3= Cnt/2;

    // timer
    TCON = pPWMRegs->rTCON & ~(0x0F << 16);
    pPWMRegs->rTCON = TCON | (0x2 << 16);
    pPWMRegs->rTCON = TCON | (0x9 << 16);			//Interval,Start

}
void	ClockOut0(int Pre,int Count,int CmpCnt)
{
	volatile IOP_REG    *pIOPReg= (volatile IOP_REG *)IOP_BASE;

	pIOPReg->rDCKCON &= ~0x00000FF0;
	pIOPReg->rDCKCON |= ((CmpCnt & 0x0f) << 8) | ((Count & 0x0f) << 4);

	pIOPReg->rMISCCR &= ~0x00000070;
	pIOPReg->rMISCCR |=( Pre & 0x07) << 4;
}
void	ClockOut1(int Pre,int Count,int CmpCnt)
{
	volatile IOP_REG    *pIOPReg= (volatile IOP_REG *)IOP_BASE;

	pIOPReg->rDCKCON &= ~0x0FF00000;
	pIOPReg->rDCKCON |= ((CmpCnt & 0x0f) << 24) | ((Count & 0x0f) << 20);

	pIOPReg->rMISCCR &= ~0x00000700;
	pIOPReg->rMISCCR |=( Pre & 0x07) << 8;
}
void	SetBacklight(int Prescaler,int Devid,int Count,int CmpCnt)
{
	Timer2_Init(Prescaler,Devid,Count,CmpCnt);
}
void	SetPwmReg(int kind,int Prescaler,int Devid,int Count,int CmpCnt)
{
	switch(kind){
//	case 0:	Timer0_Init(Prescaler,Devid,Count,CmpCnt);	break;
//	case 1:	Timer1_Init(Prescaler,Devid,Count,CmpCnt);	break;
//	case 2:	Timer2_Init(Prescaler,Devid,Count,CmpCnt);	break;
//	case 3:	Timer3_Init(Prescaler,Devid,Count,CmpCnt);	break;
	case 4:	ClockOut0(Prescaler,Count,CmpCnt);					break;
	case 5:	ClockOut1(Prescaler,Count,CmpCnt);					break;
	}
}
/******************** S3C44B0X EV. BOARD LED **********************/

void Led_Display(int data)
{
}
void	AllTimerStop(void)
{
	volatile PWM_REG    *pPWMRegs= (volatile PWM_REG *)PWM_BASE;
    volatile INT_REG	*pINTregs = (volatile INT_REG *)INT_BASE;

	pPWMRegs->rTCON= 0;
	pINTregs->rSRCPND= 0xffffffff;
	pINTregs->rINTPND= 0xffffffff;
}

/************************* Timer ********************************/

extern	void NAND_Init(void);
extern	void Lcd_Init(void);
void	SysHardInitial(void)
{
#ifdef	WIN32
	return;
#endif
//	MMU_Init();
	//NAND ROM Initialize
	NAND_Init();
	Port_Init();
	Lcd_Init();

	AllTimerStop();
}

