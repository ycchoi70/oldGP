/****************************************************/
/*    FUNC   : SCI1 Program                    */
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 2002.4.10                            */
/*    Update :                                      */
/****************************************************/
#define	RS232C_PC
#include    "define.h"
#include	"Selib.h"
#include	"s2440.h"
#include	"rs232c.h"
#include	"CommBuff.h"


/*********************************/
///////////////////////////////////////////////////////////////////////
//	�O���Q�Ɗ֐�
///////////////////////////////////////////////////////////////////////

/****************************************/
/*	Init(SCI1)                          */
/****************************************/
void	SetSci0Tbl(void)
{
	_Sci0Tbl.ch= RS_PC;
	_Sci0Tbl.iINT_RXD= UART0_INT_RXD;		//(0:1,1:8,2:64)
	_Sci0Tbl.iIOP_TX= UART_IOP_TX0;			//Count(0:2,1:4,2:6)
	_Sci0Tbl.iCLKEN_UART= CLKEN_UART0;	//
	_Sci0Tbl.iIntNo= SYSINTR_COM0;
	_Sci0Tbl.iINTSRC_UART= INTSRC_UART0;
	_Sci0Tbl.pUART= (volatile UART_REG *)UART0_BASE;
	_Sci0Tbl.RecInIdx= 0;
	_Sci0Tbl.RecOutIdx= 0;
	_Sci0Tbl.SndCnt= 0;

}
void	SciOpen(UART_STRUCT* SciTbl)
{
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE; 

	//DISABLE_INTERRUPT(UART_INT_TXD | UART_INT_RXD | UART_INT_ERR);
    pINTRegs->rINTSUBMSK |= ((SciTbl->iINT_RXD << 1) | (SciTbl->iINT_RXD) | (SciTbl->iINT_RXD << 2));
	//ENABLE_INTERRUPT(UART_INT_RXD | UART_INT_ERR);
    pINTRegs->rINTSUBMSK &= ~(SciTbl->iINT_RXD | (SciTbl->iINT_RXD << 2));
//    HAL_InterruptEnable(SciTbl->iIntNo);
}
void	SciClose(UART_STRUCT* SciTbl)
{
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE; 

	//DISABLE_INTERRUPT(UART_INT_TXD | UART_INT_RXD | UART_INT_ERR);
    pINTRegs->rINTSUBMSK |= ((SciTbl->iINT_RXD << 1) | (SciTbl->iINT_RXD) | (SciTbl->iINT_RXD << 2));
//    HAL_InterruptDisable(SciTbl->iIntNo);
}

void	SciTXIntOpen(UART_STRUCT* SciTbl)
{
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE; 
    pINTRegs->rINTSUBMSK &= ~(SciTbl->iINT_RXD << 1);
}
void	SciTXIntClose(UART_STRUCT* SciTbl)
{
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE; 
    pINTRegs->rINTSUBMSK |= (SciTbl->iINT_RXD << 1);
}

void	InitSci(UART_STRUCT* SciTbl,int speed, int ldata, int parity)
{
	unsigned int	mode;
	unsigned int	BoadRate;
	int	SetBoadRate;
	float	fdata;

	volatile IOP_REG	*pIOPRegs   = (IOP_REG *)IOP_BASE;
	volatile CLKPWR_REG *pCLKPWRregs= (volatile CLKPWR_REG*)CLKPWR_BASE;
	pIOPRegs->rGPHCON &= ~((3 << (SciTbl->iIOP_TX*2)) | (3 << ((SciTbl->iIOP_TX+1)*2)));      // Configure GPH2 and GHP3 for UART0 Tx and Rx, respectively.
	pIOPRegs->rGPHCON |=  ((2 << (SciTbl->iIOP_TX*2)) | (2 << ((SciTbl->iIOP_TX+1)*2)));      //
	pIOPRegs->rGPHUP  |=   (1 << SciTbl->iIOP_TX)     | (1 << (SciTbl->iIOP_TX+1));           // Disable pull-up on TXD1 and RXD1.
	pCLKPWRregs->rCLKCON |= SciTbl->iCLKEN_UART;

    SciTbl->pUART->rUFCON  |= (1<<6)|(1<<4)|(1<<2)|(1<<1)|(1<<0);	//TX FIFO(16Byte) : RX FIFO (8Byte) 
    																//TX FIFO Reset : RX FIFO Reset (ON)
    SciTbl->pUART->rUFCON  |= (1<<0);			//FIFO Enable

    SciTbl->pUART->rUMCON  = (1<<0);	        //RTS ON.

	mode= 0;							//Clear
	if(ldata == RS_DATA7){	mode= 0x02;	}		//7Bit
	else{					mode= 0x03;	}		//8Bit
	switch(parity & 0xff){				//Parity
	case RS_NONE:						break;
	case RS_ODD:	mode |= 0x04 << 3;	break;
	case RS_EVEN:	mode |= 0x05 << 3;	break;
	}
	switch((parity & 0xff00) >> 8){		//Stop
	case RS_STOP01:	mode |= 0x00 << 2;	break;
	case RS_STOP02:	mode |= 0x01 << 2;	break;
	}
    SciTbl->pUART->rULCON  = mode;			// 
    SciTbl->pUART->rUCON   = (1<<9)|(1<<8)|(1<<7)|(1<<6)|(1<<2)|(1<<0);      // Rx pulse interrupt, Tx level interrupt, Rx error status interrupt enabled.
	switch(speed){					//Boadrate
	case RS_300:	BoadRate= BAUDRATE_300;		break;
	case RS_600:	BoadRate= BAUDRATE_600;		break;
	case RS_1200:	BoadRate= BAUDRATE_1200;	break;
	case RS_2400:	BoadRate= BAUDRATE_2400;	break;
	case RS_4800:	BoadRate= BAUDRATE_4800;	break;
	case RS_9600:	BoadRate= BAUDRATE_9600;	break;
	case RS_19200:	BoadRate= BAUDRATE_19200;	break;
	case RS_38400:	BoadRate= BAUDRATE_38400;	break;
	case RS_57600:	BoadRate= BAUDRATE_57600;	break;
	case RS_115200:	BoadRate= BAUDRATE_115200;	break;
	}
	fdata= (float)S3C2440X_PCLK;
	fdata= (float)S3C2440X_PCLK/(float)16.0;
	fdata= fdata/BoadRate;
	SetBoadRate= (unsigned int)((S3C2440X_PCLK/16.0)/BoadRate + 0.5- 1);
    SciTbl->pUART->rUBRDIV = SetBoadRate;        // Set up baudrate 
}
void	InitSci0( int speed, int ldata, int parity )
{
	SciClose(&_Sci0Tbl);
	InitSci(&_Sci0Tbl, speed, ldata, parity);
	SciOpen(&_Sci0Tbl);
}
/****************************************************
*   FUNC  : Rts ON/OFF                              *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
void	SioRtsOn(UART_STRUCT* pUart)
{
    pUart->pUART->rUMCON  |= (1<<0);	        //RTS ON.
}
void	Sio0RtsOn(void)
{
	SioRtsOn(&_Sci0Tbl);
}
void	SioRtsOff(UART_STRUCT* pUart)
{
    pUart->pUART->rUMCON  &= ~(1<<0);	        //RTS OFF.
}
void	Sio0RtsOff(void)
{                    
	SioRtsOff(&_Sci0Tbl);
}

/****************************************************
*   FUNC  : Sio1 Error Handler                      *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
int	_SciERProc( UART_STRUCT* SciTbl )
{
	volatile unsigned int	err_status;
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE; 

    pINTRegs->rSUBSRCPND = SciTbl->iINT_RXD << 2;	//ERR
    pINTRegs->rSRCPND = 1 << SciTbl->iINTSRC_UART;
    pINTRegs->rINTPND = 1 << SciTbl->iINTSRC_UART;
	err_status= SciTbl->pUART->rUERSTAT;			//Error Flag OFF
	return(-1);
}
/****************************************************
*   FUNC  : Sio1 Recieve Handler                    *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
void Uart_SendByte(UART_STRUCT* SciTbl,int data)
{
	unsigned int status;

	while(1){ //Wait until THR is empty.
		status= SciTbl->pUART->rUTRSTAT;
		if(status & 0x02){
			break;
		}
	}
	SciTbl->pUART->rUTXH= data;
}		
void Uart_WaitSendByte(UART_STRUCT* SciTbl)
{
	unsigned int status;

	while(1){ //Wait until THR is empty.
		status= SciTbl->pUART->rUTRSTAT;
		if(status & 0x02){
			break;
		}
	}
}
int	_SciRXInterruptProc( UART_STRUCT* SciTbl )
{
	int		ret;
    unsigned char rs_input_data;
	unsigned int  UFSTATE;
	unsigned int  nRxFifo;
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE; 

	ret = -1;								// return= -1;
	while(1){
        UFSTATE = SciTbl->pUART->rUFSTAT;
        nRxFifo = (UFSTATE & (0x3F));
        if ((UFSTATE & (1<<6))!=0)			// Overflow. Use FIFO depth (8);
            nRxFifo = FIFO_DEPTH_RX;

        if (nRxFifo<=0)
            break;

        while (nRxFifo > 0)
        {
            rs_input_data= SciTbl->pUART->rURXH;	// Data Read
//			if((DModeFlag != 0) && (SioEchoFlag != 0)){		//ECHO OUT
//				Uart_SendByte(SciTbl,rs_input_data);
//				Uart_WaitSendByte(SciTbl);					// Tx Ready Wait?
//			}
			SciTbl->RecBuff[SciTbl->RecInIdx++]= rs_input_data;
			SciTbl->RecInIdx &= 0x3ff;				//1024
            nRxFifo--;
        }
	}

    pINTRegs->rSUBSRCPND = SciTbl->iINT_RXD;	//1 << INTSUB_RXD0;
    pINTRegs->rSRCPND = 1 << SciTbl->iINTSRC_UART;
    pINTRegs->rINTPND = 1 << SciTbl->iINTSRC_UART;
	return(ret);
}
int	_SciTXInterruptProc( UART_STRUCT* SciTbl )
{
	int	ret = -1;
	unsigned int  UfState;
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE; 

    pINTRegs->rSUBSRCPND = SciTbl->iINT_RXD << 1;	//INTSUB_TXD0;
    pINTRegs->rSRCPND = 1 << SciTbl->iINTSRC_UART;		//INTSRC_UART0;
    pINTRegs->rINTPND = 1 << SciTbl->iINTSRC_UART;		//INTSRC_UART0;

	while( SciTbl->SndCnt > 0 ) 
	{
        UfState = SciTbl->pUART->rUFSTAT ;
	    if ( (UfState & (1<<14)) == 0 )
	    {
            UfState = ((UfState>>8) & 0x3f); // It is fifo count.
            if (UfState < FIFO_DEPTH_TX-1)
                UfState = FIFO_DEPTH_TX-1 - UfState;

            for(; SciTbl->SndCnt>0 && UfState>0; SciTbl->SndCnt--,UfState--)
            {
			    while(!(SciTbl->pUART->rUTRSTAT & 0x2));
    		    SciTbl->pUART->rUTXH = SciTbl->SndBuff[SciTbl->SndIdx++];
            }
    	}
    	else // FIFO FULL
    	{
    	    break;
    	}
    }

    if (SciTbl->SndCnt > 0){	pINTRegs->rINTSUBMSK &= ~(SciTbl->iINT_RXD << 1);	}		//UART0_INT_TXD
    else{			pINTRegs->rINTSUBMSK |= (SciTbl->iINT_RXD << 1);	ret = 0;		}
	return(ret);
}
void	_Sci0InterruptProc( void )
{
	unsigned int subInt;
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_UART0;
	subInt= pINTRegs->rSUBSRCPND & 0x07;
	if(subInt & 0x01){	_SciRXInterruptProc(&_Sci0Tbl);	}
	if(subInt & 0x02){	_SciTXInterruptProc(&_Sci0Tbl);	}
	if(subInt & 0x04){	_SciERProc(&_Sci0Tbl);			}
	pINTRegs->rINTMSK &= ~BIT_UART0;
}

/************************************************************/
/*	�P�������M												*/
/************************************************************/
int Sio0SendChar( unsigned char ch )
{
	Uart_SendByte(&_Sci0Tbl,ch);
	return( TRUE );
}
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
/************************************************/
/*	RS422 TX Enable								*/
/************************************************/
extern	void	Rs422Enable(int mode);
void	SetSci1Tbl(void)
{
	_Sci1Tbl.ch= RS_PLC;
	_Sci1Tbl.iINT_RXD= UART1_INT_RXD;		//(0:1,1:8,2:64)
	_Sci1Tbl.iIOP_TX= UART_IOP_TX1;			//Count(0:2,1:4,2:6)
	_Sci1Tbl.iCLKEN_UART= CLKEN_UART1;	//
	_Sci1Tbl.iIntNo= SYSINTR_COM1;
	_Sci1Tbl.iINTSRC_UART= INTSRC_UART1;
	_Sci1Tbl.pUART= (volatile UART_REG *)UART1_BASE;
	_Sci1Tbl.RecInIdx= 0;
	_Sci1Tbl.RecOutIdx= 0;
	_Sci1Tbl.SndCnt= 0;
}
void	InitSci1( int speed, int ldata, int parity )
{
#ifdef	WIN32
	return;
#endif
	SciClose(&_Sci1Tbl);
	InitSci(&_Sci1Tbl, speed, ldata, parity);
	SciOpen(&_Sci1Tbl);
}
void	Sio1RtsOn(void)
{
	SioRtsOn(&_Sci1Tbl);
}
void	Sio1RtsOff(void)
{
	SioRtsOff(&_Sci1Tbl);
}
void	_Sci1InterruptProc( void )
{
	unsigned int subInt;
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_UART1;
	subInt= (pINTRegs->rSUBSRCPND & 0x038) >> 3;
	if(subInt & 0x01){	_SciRXInterruptProc(&_Sci1Tbl);	}
	if(subInt & 0x02){	_SciTXInterruptProc(&_Sci1Tbl);	}
	if(subInt & 0x04){	_SciERProc(&_Sci1Tbl);			}
	pINTRegs->rINTMSK &= ~BIT_UART1;
}
/************************************************************/
/*	�P�������M												*/
/************************************************************/
int Sio1SendChar( unsigned char ch )
{
	Uart_SendByte(&_Sci1Tbl,ch);
	return( TRUE );
}
///////////////////////////////////////////////////////////////////////////////////////
void	SetSci2Tbl(void)
{
	_Sci2Tbl.ch= RS_PLC;
	_Sci2Tbl.iINT_RXD= UART2_INT_RXD;		//(0:1,1:8,2:64)
	_Sci2Tbl.iIOP_TX= UART_IOP_TX2;			//Count(0:2,1:4,2:6)
	_Sci2Tbl.iCLKEN_UART= CLKEN_UART2;	//
	_Sci2Tbl.iIntNo= SYSINTR_COM2;
	_Sci2Tbl.iINTSRC_UART= INTSRC_UART2;
	_Sci2Tbl.pUART= (volatile UART_REG *)UART2_BASE;
	_Sci2Tbl.RecInIdx= 0;
	_Sci2Tbl.RecOutIdx= 0;
	_Sci2Tbl.SndCnt= 0;
}
void	InitSci2( int speed, int ldata, int parity )
{
	SciClose(&_Sci2Tbl);
	InitSci(&_Sci2Tbl, speed, ldata, parity);
	SciOpen(&_Sci2Tbl);
}
void	Sio2RtsOn(void)
{
	SioRtsOn(&_Sci2Tbl);
}
void	Sio2RtsOff(void)
{
	SioRtsOff(&_Sci2Tbl);
}
void	_Sci2InterruptProc( void )
{
	unsigned int subInt;
    volatile INT_REG    *pINTRegs= (volatile INT_REG *)INT_BASE; 

	pINTRegs->rINTMSK |= BIT_UART2;
	subInt= (pINTRegs->rSUBSRCPND & 0x01c0) >> 6;
	if(subInt & 0x01){	_SciRXInterruptProc(&_Sci2Tbl);	}
	if(subInt & 0x02){	_SciTXInterruptProc(&_Sci2Tbl);	}
	if(subInt & 0x04){	_SciERProc(&_Sci2Tbl);			}
	pINTRegs->rINTMSK &= ~BIT_UART2;
}
/************************************************************/
/*	�P�������M												*/
/************************************************************/
int Sio2SendChar( unsigned char ch )
{
	Uart_SendByte(&_Sci2Tbl,ch);
	return( TRUE );
}
///////////////////////////////////////////////////////////////////////////////////////
//	Rs-232C Send/Recieve Driver
///////////////////////////////////////////////////////////////////////////////////////
int	IsGetSio0( void )
{
	return(_Sci0Tbl.RecInIdx- _Sci0Tbl.RecOutIdx);
}
int	IsGetSio1( void )
{
	return(_Sci1Tbl.RecInIdx- _Sci1Tbl.RecOutIdx);
}
int	IsGetSio2( void )
{
	return(_Sci2Tbl.RecInIdx- _Sci2Tbl.RecOutIdx);
}

int	GetSio0( void )
{
	int	ret;

	ret= 0;
	if(_Sci0Tbl.RecInIdx != _Sci0Tbl.RecOutIdx){
		ret= _Sci0Tbl.RecBuff[_Sci0Tbl.RecOutIdx++];
		_Sci0Tbl.RecOutIdx &= 0x3ff;		//Buff= 1024
	}
	return( ret );
}
int	GetSio1( void )
{
	int	ret;

	ret= 0;
	if(_Sci1Tbl.RecInIdx != _Sci1Tbl.RecOutIdx){
		ret= _Sci1Tbl.RecBuff[_Sci1Tbl.RecOutIdx++];
		_Sci1Tbl.RecOutIdx &= 0x3ff;		//Buff= 1024
	}
	return( ret );
}
int	GetSio2( void )
{
	int	ret;

	ret= 0;
	if(_Sci2Tbl.RecInIdx != _Sci2Tbl.RecOutIdx){
		ret= _Sci2Tbl.RecBuff[_Sci2Tbl.RecOutIdx++];
		_Sci2Tbl.RecOutIdx &= 0x3ff;		//Buff= 1024
	}
	return( ret );
}

void	ClearSio0Cnt(void)
{
	_Sci0Tbl.RecInIdx= _Sci0Tbl.RecOutIdx= 0;
}
void	ClearSio1Cnt(void)
{
	_Sci1Tbl.RecInIdx= _Sci1Tbl.RecOutIdx= 0;
}
void	ClearSio2Cnt(void)
{
	_Sci2Tbl.RecInIdx= _Sci2Tbl.RecOutIdx= 0;
}
#ifdef	WIN32
void	SetRecData(char data)
{
	_Sci1Tbl.RecBuff[_Sci1Tbl.RecInIdx++]= data;
	_Sci1Tbl.RecInIdx &= 0x3ff;				//1024
}
#endif
/////////////////////// end ////////////////////////////////////////////////////////////




