/****************************************************************
*  Dos file system emulation program	1997,4,22	Ver 1.10	*
*										1997,5,14   Ver 1.20	*
*				Windows-95 mode			1997,8,08   Ver 2.00	*
****************************************************************/
#define	DOSEM_PROC
#include <string.h>
#include <math.h>

#include "glpdos.h"
#include "define.h"
#include "glplcd.h"
#include "commbuff.h"
#include "doscomm.h"
#include "pcmcia.h"

/************************************************/
/* Get Current Date								*/
/* Create: 97.02.25 kf	 Update: 97.02.25 kf	*/
/************************************************/

short	GetCurrentDate( void )
{
    int     d,m,y;
    short   Date;

	y = SystemTime.year;
	m = SystemTime.mon;
	d = SystemTime.day;
	if (y < 90) {	y += 2000;	}
	else {			y += 1900;	}
	y -= 1980;

    Date = (short)((y << 9) + (m << 5) + d);

	return Date;
}

/************************************************/
/* Get Current Time								*/
/* Create: 97.02.25 kf	 Update: 97.02.25 kf	*/
/************************************************/

short	GetCurrentTime( void )
{
	int	s,m,h;
	short	Time;

	/* RTC Time Data	*/
		s = SystemTime.sec;
		m = SystemTime.min;
		h = SystemTime.hour;

	/* Time data */
		Time = (short)((h << 11) + (m << 5) + (s >> 1));

	return	Time;
}


/****************************************************
*  initialize file system							*
****************************************************/

BOOL	InitializeFileSystem (void)
{
	int		i,j;
	
	System.CurrentDrive = 'A';			/* current drive name  C: */

	System.DriveStatus = 0;				/* Installed drive */
	System.NumberOfOpenFiles = 0;		/* current open files */
	System.OpenFlag = 0;				/* current open file status */
	
	/*bpt = Buffer = malloc (MaxBuffers * IbuffSize);*/

	for(j= 0; j < MAX_DEVICE; j++){
		DevInf[j].MaxBuffers = BUFFCNT;				/* Maximum internal buffers */
		for (i=0; i<DevInf[j].MaxBuffers; i++) {
			DevInf[j].sysBuff[i].WriteSequence = 0;
			DevInf[j].sysBuff[i].Status = 0;			/* buffer control block */
		}
		DevInf[j].WriteBusy = FALSE;				/* write busy status */
		DevInf[j].WriteBufferNumber = 0;		/* current write buffer number */
	}
//	System.WriteBusy = FALSE;				/* write busy status */
//	System.WriteBufferNumber = 0;		/* current write buffer number */
	return TRUE;
}


/********************************************************
*  Mount New Media										*
*	Update: Buffer = MemAlloc (IbuffSize)	97.05.01 kf *
*********************************************************/
BOOL	MountMedia (int drive)
{
	BYTE	*bpt;
	long	clusterSize;
	int		i;

	/* set driver entry pointer */
	if (!GetBPB (drive, &DevInf[drive].xBpb)) return FALSE;
	System.DriveStatus |= (1 << drive);			/* Installed drive */
	strcpy (DevInf[drive].xBpb.CurrentPath, "\\");	/* current directory name (root)*/
	DevInf[drive].xBpb.CurrentDirCluster = DevInf[drive].xBpb.StartDir;

	clusterSize = (long)DevInf[drive].xBpb.SectorPerBytes *
				  (long)DevInf[drive].xBpb.ClusterPerSectors;


	if(drive == 4){		//SD Card
		DevInf[drive].MaxBuffers = 0x10000 / clusterSize;		/* Maximum internal buffers */
		bpt = (unsigned char*)&SD_ClustBuffer[drive];
	}else{
		DevInf[drive].MaxBuffers = IbuffSize / clusterSize;		/* Maximum internal buffers */
		bpt = (unsigned char*)&ClustBuffer[drive];
	}
	for (i=0; i<DevInf[drive].MaxBuffers; i++) {
		DevInf[drive].sysBuff[i].pt = bpt;			/* buffer pointer */
		DevInf[drive].sysBuff[i].Status = 0;			/* buffer control block 1997,5,11 */
		bpt += clusterSize;
	}
	DevInf[drive].AllocPointer = DevInf[drive].MaxBuffers-1;	/* next buffer allocation pointer */
	if(DevInf[drive].MaxBuffers == 0){				/* 00.03.05 */
		return FALSE;
	}
	return TRUE;		
}



/****************************************************
* DisMount Media									*
*	Update: MemFree(Buffer)				97.05.01 kf	*
****************************************************/
BOOL	DisMountMedia (int drive)
{
	int		n;

		n = (1 << drive);
		System.DriveStatus &= (~n);		/* reject drive */
/*		FreeMail((char *)Buffer);*/	/*  */
/*		Buffer = 0;	*/		/*  */
		return TRUE;				
}

/****************************************************
* load BPB											*
****************************************************/

BOOL	GetBPB (int drive, XBPB *xBPB)
{
//	long	FatBytes, DirSectors;
	long	DirSectors;

		if (!ReadBPB (drive, xBPB)) return FALSE;
//		FatBytes = xBPB->FatPerSectors * xBPB->SectorPerBytes;
		if (xBPB->Sectors == 0) xBPB->MaxSectors = xBPB->Sectors2;
		else					xBPB->MaxSectors = xBPB->Sectors;

		/*xBPB->StartFat = 1;*/			/* start of FAT sector */
		xBPB->StartFat= xBPB->ReservedSectors+ xBPB->StartSectorOffset;				/* Boot Start Offset Add 20091110 */
		xBPB->StartDir = (xBPB->FatPerSectors * xBPB->AllocFat) + xBPB->StartFat;	/* start of Root Dir sector */
		
		if((xBPB->SectorPerBytes == 0) || (xBPB->ClusterPerSectors == 0)){
			return FALSE;			/* 97.10.3 */
		}
		if(xBPB->FatType == 32){	//20091110
			xBPB->ReservedSectors= (unsigned short)xBPB->StartFat;
			DirSectors= 0;
		}else{
			DirSectors = (((long)xBPB->Dirs << 5) + xBPB->SectorPerBytes-1) / xBPB->SectorPerBytes;
			if(xBPB->StartSectorOffset != 0){
				xBPB->ReservedSectors += (unsigned short)xBPB->StartSectorOffset;
			}
		}
		xBPB->ClusterOffset = xBPB->StartDir + DirSectors - xBPB->ClusterPerSectors * 2;	/* 1st(2) cluster sector offset */

		xBPB->MaxCluster = (xBPB->MaxSectors - DirSectors - xBPB->StartDir) / xBPB->ClusterPerSectors;
		return TRUE;
}

/****************************************************
*  Get Drive Status									*
*	Drive:	Drive Name (exp: "C:")					*
*	total:	total clusters							*
*	free:	free clusters							*
*	csize:	cluster / bytes							*
****************************************************/
int		GetSectorByte( char *drvname )
{
	int		clusterSize;
	int		

	drive = drvname[0] - 'A';

//	return(DevInf[drive].xBpb.SectorPerBytes);
	clusterSize = (int)DevInf[drive].xBpb.SectorPerBytes *
				  (int)DevInf[drive].xBpb.ClusterPerSectors;
	return(clusterSize);
}


/****************************************************
*  Delete Sub directory								*
****************************************************/

int		DelDir (char *DirName)
{
	int		Channel, drive;
	BYTE	FilePath[80], dirbuff[32];
	IFCB	*iFcb;
	long	offset, size;
	BOOL	dir;

	Channel = Get_FCBNumber ();				/* Get File Channel */
	if (Channel == -1) return -1;			/* not enough channel */

	if (!Build_FileName (DirName, (char *)FilePath)) return -3;

	drive = FilePath[0] - 'A';
	//20100331
	if((System.DriveStatus & (1 << drive)) == 0){	return -2;	}			/* Installed drive */

	if ((FilePath[0] == System.CurrentDrive) &&
		(strcmp ((const char *)&FilePath[2], (const char *)DevInf[drive].xBpb.CurrentPath) == 0)) return -2;

	dir = Fined_File (Channel, (char *)FilePath);	/* get directory number */
	if (!dir) return -4;						/* file not found */

	Set_FCB (Channel, (char *)FilePath);		/* setup file control table */
	iFcb = Get_FCBaddress (Channel);
	iFcb->Access = _READ;

	if (iFcb->FileSize != 64) {
		offset = 64;
		for (;;) {
			size = File_Read (Channel, dirbuff, 32, offset);
			if (size != 32) break;
			offset += 32;
			if ((dirbuff[0] != 0xE5) && (dirbuff[0] != 0)) {
				File_Close (0,Channel);
				return -5;
			}
		}
		File_Close (0,Channel);
	}
	return Delete (DirName);
}


/****************************************************
*  Delete file										*
****************************************************/

int		Delete (char *FileName)
{
	int		Channel, cluster, next;
	IFCB	*iFcb;
	//20100319
	int		i;
	int		offset,DirCount;
	unsigned char	dirBuff[32];

	Channel = File_Open (FileName, 2);
	if (Channel < 0) return -1;

	iFcb = Get_FCBaddress (Channel);
	iFcb->Access = _WRITE;
	iFcb->CurrentDirBlock.Name[0] = '\xE5';

	// Logname Delete	20100319 Long Name Delete Add
	if(LNFRecCnt > 0){
		if (iFcb->DirMode) {									/* TRUE: root,  FALSE: sub dir */
			DirCount = (int)DevInf[iFcb->Drive].xBpb.SectorPerBytes / 32;
		}else{
			DirCount = (int)DevInf[iFcb->Drive].xBpb.SectorPerBytes *
					   (int)DevInf[iFcb->Drive].xBpb.ClusterPerSectors / 32;
		}
		for(i= 0; i < LNFRecCnt; i++){
			if (iFcb->DirMode) {									/* TRUE: root,  FALSE: sub dir */
				offset = DevInf[iFcb->Drive].xBpb.SectorPerBytes;	/* 1997,6,23 */
				offset = iFcb->LongStartDir % (offset / 32);
				offset <<= 5;
				Read_Dir (dirBuff, iFcb->Drive, iFcb->LongCurrentCluster, offset, 32);
				dirBuff[0]= '\xE5';
				Write_Dir (dirBuff,iFcb->Drive,iFcb->LongCurrentCluster,offset);
				iFcb->LongStartDir++;
				if((iFcb->LongStartDir % DirCount) == 0){	iFcb->LongCurrentCluster++;		}
			}
			else {													// Sub Dir or FAT32 Dir
				offset = DevInf[iFcb->Drive].xBpb.SectorPerBytes
					   * DevInf[iFcb->Drive].xBpb.ClusterPerSectors;	/* cluster/Sectors */
				offset = iFcb->LongStartDir % (offset / 32);				/* 1997, 6,23 */
				offset <<= 5;											//*32
				Read_Data_Dir (dirBuff, iFcb->Drive, iFcb->LongCurrentCluster, offset, 32);
				dirBuff[0]= '\xE5';
				Write_Data_Dir (TRUE, dirBuff,iFcb->Drive,iFcb->LongCurrentCluster,offset, 32);
				iFcb->LongStartDir++;
				if((iFcb->LongStartDir % DirCount) == 0){
					iFcb->LongCurrentCluster = GetFAT (iFcb->LongCurrentCluster, iFcb->Drive);	/* Current cluster Number */
				}
			}
		}
	}

	cluster = iFcb->BeginCluster;				/* Start of cluster number */
	for (;;) {
		next = GetFAT (cluster, iFcb->Drive);
		SetFAT (cluster, 0, iFcb->Drive);
		if ((unsigned)next == 0xFFFFFFF8) break;
		if ((unsigned)next == 0xFFFFFFFF) break;
		if ((unsigned)next == 0x0FFFFFF8) break;
		if ((unsigned)next == 0x0FFFFFFF) break;
		cluster = next;
	}
	return File_Close (0,Channel);

}


/****************************************************
*  rename file										*
****************************************************/

int		FileRename (char *src, char *dist)
{
	int		i, Channel, Channel1;
	IFCB	*iFcb;
	//20100322
	int		idx;
	int		offset,DirCount;
	unsigned char	dirBuff[32];
	DIR		sDir;
	int	sum;

	Channel = File_Open (src, _OPEN);
	if (Channel < 0) return -1;			//src�����݂��Ȃ�
	//src long Name Save
	sLNFRecCnt= LNFRecCnt;
	memcpy(sLNFFileName,LNFFileName,sizeof(sLNFFileName));

	iFcb = Get_FCBaddress (Channel);
	iFcb->Access = _WRITE;
	memcpy(&sDir,&(iFcb->CurrentDirBlock),sizeof(DIR));

	Channel1 = File_Open (dist, _OPEN);
	if (Channel1 >= 0){					//dist�����݂���
		File_Close (0,Channel);
		File_Close (0,Channel1);
		return -1;
	}

	memcpy (iFcb->CurrentDirBlock.Name, DosFileName, 11);

	sum= shortNameCheckCode((unsigned char*)&DosFileName[0]);
	// Logname Rename	20100322 Long Name Rename Add
	if (iFcb->DirMode) {									/* TRUE: root,  FALSE: sub dir */
		DirCount = (int)DevInf[iFcb->Drive].xBpb.SectorPerBytes / 32;
	}else{
		DirCount = (int)DevInf[iFcb->Drive].xBpb.SectorPerBytes *
				   (int)DevInf[iFcb->Drive].xBpb.ClusterPerSectors / 32;
	}
	for(i= 0,idx= LNFRecCnt- 1; i < sLNFRecCnt; i++){
		LNFFileName[idx].checkCodeForShortName= sum;
		if (iFcb->DirMode) {									/* TRUE: root,  FALSE: sub dir */
			offset = DevInf[iFcb->Drive].xBpb.SectorPerBytes;	/* 1997,6,23 */
			offset = iFcb->LongStartDir % (offset / 32);
			offset <<= 5;
			Read_Dir (dirBuff, iFcb->Drive, iFcb->LongCurrentCluster, offset, 32);
			if(sLNFRecCnt >= LNFRecCnt){								//replace
				if(i < (sLNFRecCnt- LNFRecCnt)){		dirBuff[0]= '\xE5';		}
				else{	memcpy(dirBuff,&LNFFileName[idx--],sizeof(LNFEntry));	}
			}else{
				dirBuff[0]= '\xE5';
			}
			Write_Dir (dirBuff,iFcb->Drive,iFcb->LongCurrentCluster,offset);
			iFcb->LongStartDir++;
			if((iFcb->LongStartDir % DirCount) == 0){	iFcb->LongCurrentCluster++;		}
		}
		else {													// Sub Dir or FAT32 Dir
			offset = DevInf[iFcb->Drive].xBpb.SectorPerBytes
				   * DevInf[iFcb->Drive].xBpb.ClusterPerSectors;	/* cluster/Sectors */
			offset = iFcb->LongStartDir % (offset / 32);				/* 1997, 6,23 */
			offset <<= 5;											//*32
			Read_Data_Dir (dirBuff, iFcb->Drive, iFcb->LongCurrentCluster, offset, 32);
			if(sLNFRecCnt >= LNFRecCnt){								//replace
				if(i < (sLNFRecCnt- LNFRecCnt)){		dirBuff[0]= '\xE5';		}
				else{	memcpy(dirBuff,&LNFFileName[idx--],sizeof(LNFEntry));	}
			}else{
				dirBuff[0]= '\xE5';
			}
			Write_Data_Dir (TRUE, dirBuff,iFcb->Drive,iFcb->LongCurrentCluster,offset, 32);
			iFcb->LongStartDir++;
			if((iFcb->LongStartDir % DirCount) == 0){
				iFcb->LongCurrentCluster = GetFAT (iFcb->LongCurrentCluster, iFcb->Drive);	/* Current cluster Number */
			}
		}
	}
	if(sLNFRecCnt < LNFRecCnt){								//NewName
		iFcb->CurrentDirBlock.Name[0]= '\xE5';
	}
	if (iFcb->DirMode) {									/* TRUE: root,  FALSE: sub dir */
		offset = DevInf[iFcb->Drive].xBpb.SectorPerBytes;	/* 1997,6,23 */
		offset = iFcb->CurrentDir % (offset / 32);
		offset <<= 5;
		Write_Dir ((BYTE*)&(iFcb->CurrentDirBlock),
				   iFcb->Drive,
				   iFcb->CurrentDirCluster,
				   offset);
	}
	else {													// Sub Dir or FAT32 Dir
		offset = DevInf[iFcb->Drive].xBpb.SectorPerBytes
			   * DevInf[iFcb->Drive].xBpb.ClusterPerSectors;	/* cluster/Sectors */
		offset = iFcb->CurrentDir % (offset / 32);				/* 1997, 6,23 */
		offset <<= 5;											//*32
		Write_Data_Dir (TRUE, (BYTE*)&(iFcb->CurrentDirBlock),
					  iFcb->Drive,
					  iFcb->CurrentDirCluster,
					  offset, 32);
	}
	Close_FCBNumber (Channel);
	if(sLNFRecCnt >= LNFRecCnt){
		FlushAll (iFcb->Drive);								/* Flush all cluster or sector */
		return(0);
	}								//Replace
	Channel = Get_FCBNumber ();				/* Get File Channel */
	Rename_File_Install(Channel,dist,&sDir);
	Close_FCBNumber (Channel);		/* reset FCB */
	FlushAll (iFcb->Drive);								/* Flush all cluster or sector */
	return(0);
}



/****************************************************
*  get requested file control block					*
****************************************************/
int		Find_First(char *wildspec, unsigned attr, struct find_t *finddata)
{
//	char	DirPath[80], path[80], FileName[260], *next, *cp;
	char	*next, *cp;
	int		i, j, n, drive, chan;
	IFCB	*iFcb;
	FINDSTR	FindBlk;
	long	lmax;

	strcpy (findpath, wildspec);
	next = findpath;
	for (;;) {
		if ((cp = strchr (next, '\\')) == NULL) break;
		next = ++cp;
	}

	strcpy (findFileName, next);
	*next = 0;
	if (next != findpath) *(--next) = 0;
	if (!Build_FileName (findpath, findDirPath)) return -2;	/* illegal Path name */
	FindBlk.drive = drive = findDirPath[0] - 'A';

	//20100331
	if((System.DriveStatus & (1 << FindBlk.drive)) == 0){	return -2;	}			/* Installed drive */

	FindBlk.DirNo = 0;
	FindBlk.att = (BYTE)attr;

	/* check if root directory */
	if ((n = strlen (findDirPath)) == 3) {				/* 6-->3   97.05.01 ks */
		FindBlk.mode = TRUE;
		if(DevInf[drive].xBpb.FatType == 32){
			FindBlk.cluster = DevInf[drive].xBpb.Dirs;
		}else{
			FindBlk.cluster = DevInf[drive].xBpb.StartDir;
		}
		SetFileName2LnfName(findDirPath);		//20091116
	}
	else {
		cp = &findDirPath[strlen(findDirPath)-1];			/* 1997,5,21 K.S */
		if (*cp == '\\') *cp = 0;					/* 1997,5,21 K.S */
		FindBlk.mode = FALSE;
		/*findDirPath[n - 4] = 0;*/						/* 1997,5,14 k.s */
		SetFileName2LnfName(findDirPath);		//20091116
		chan = File_Open (findDirPath, 2);				/* open Dir file */
		if (chan < 0) return -2;					/* not found directory */
		iFcb = Get_FCBaddress (chan);
		FindBlk.cluster = iFcb->BeginCluster;
		FindBlk.DirMax = (iFcb->FileSize >> 5);	/* 1997,5,14 k.s */
		File_Close (0,chan);
	}

	n = strlen (findFileName);
	cp = findFileName;
	for (i=0; i<11; i++) FindBlk.mask[i] = 0;

	for (i=j=0; i<n; i++) {
		if (*cp == '*') {
			if (j > 8) break;
			j = 8;
		}
		else if (*cp == '?') {
			j++;
		}
		else if (*cp == '.') {
			
		}
		else {
			FindBlk.mask[j++] = *cp;
		}
		cp++;
	}

	memcpy (&finddata->reserved[0], FindBlk.mask, 11);
	finddata->reserved[11] = FindBlk.mode;
	finddata->reserved[12] = (char)FindBlk.drive;
	finddata->reserved[13] = FindBlk.att;
	lmax= FindBlk.DirMax;
	finddata->reserved[20] = lmax / 0x1000000;
	lmax= lmax % 0x1000000;
	finddata->reserved[21] = lmax / 0x10000;
	lmax= lmax % 0x10000;
	finddata->reserved[22] = lmax / 0x100;
	finddata->reserved[23] = lmax % 0x100;
	if (FindDirectory (&FindBlk, finddata)) return 0;
	return -1;
}



/****************************************************
*  get next requested file control block			*
****************************************************/

int		Find_Next (struct find_t *finddata)
{
	FINDSTR	FindBlk;

	memcpy (FindBlk.mask, finddata->reserved, 11);
	FindBlk.mode = finddata->reserved[11];			/* TRUE: root, FALSE: Sub dir */
	FindBlk.drive = (int)finddata->reserved[12];	/* drive number */
	FindBlk.att = finddata->reserved[13];			/* requested attribute */
	FindBlk.DirNo = 0;								/* current dir number */
	FindBlk.DirNo = (finddata->reserved[14] << 8) + finddata->reserved[15];
	FindBlk.cluster = (finddata->reserved[16] << 24) + (finddata->reserved[17] << 16) +
					  (finddata->reserved[18] << 8) + finddata->reserved[19];
	FindBlk.DirMax = (finddata->reserved[20] << 24) + (finddata->reserved[21] << 16) +
					 (finddata->reserved[22] << 8) + finddata->reserved[23];
	
	if (FindDirectory (&FindBlk, finddata)) return 0;
	return -1;
}


/********************************************************
*  Find directory information							*
********************************************************/
void	SetFileName(char *buff,int cnt)
{
	int	i,j,pos;

	pos= 0;
	for(i= 0; i < cnt; i++){
		for(j= 0; j < 13; j++){
			if((buff[i*26+j*2] == 0) && (buff[i*26+j*2+1] == 0)){
				break;
			}
			if(buff[i*26+j*2] != 0){
				buff[pos++]= buff[i*26+j*2];
			}
			if(buff[i*26+j*2+1] != 0){
				buff[pos++]= buff[i*26+j*2+1];
			}
		}
	}
	buff[pos++]= 0;
}
void	GetLnfFileName(LNFEntry* LnfFDir,int *NameCnt,char* name)
{
	int	j,k;

	if(LnfFDir->attribute == 0x0f){		//LNF Name
		(*NameCnt)++;
		//1st
		for(j= ((LnfFDir->LFNSeqNumber & 0x1f)- 1)*13*2,k= 0; k < 5; k++){
			if((LnfFDir->name1st[k*2] == 0) & (LnfFDir->name1st[k*2+1] == 0)){	break;	}
			else{
				name[j++]= LnfFDir->name1st[k*2]; 
				name[j++]= LnfFDir->name1st[k*2+1];
			}
		}
		//2nd
		if(k >= 5){	//
			for(k= 0; k < 6; k++){
				if((LnfFDir->name2nd[k*2] == 0) & (LnfFDir->name2nd[k*2+1] == 0)){	break;	}
				else{
					name[j++]= LnfFDir->name2nd[k*2]; 
					name[j++]= LnfFDir->name2nd[k*2+1];
				}
			}
		}
		//3rd
		if(k >= 6){
			for(k= 0; k < 2; k++){
				if((LnfFDir->name3rd[k*2] == 0) && (LnfFDir->name3rd[k*2+1] == 0)){	break;	}
				else{
					name[j++]= LnfFDir->name3rd[k*2]; 
					name[j++]= LnfFDir->name3rd[k*2+1];
				}
			}
		}
	}
}
void	SetLargSmallName(int flag,char* name)
{
	int	i;
	int	SmallFlag;

	SmallFlag= flag & 0x0f;
	for(i= 0; ; i++){
		if(name[i] == 0){	break;	}
		if(name[i] == '.'){	SmallFlag= flag & 0xf0;	continue;	}
		if(SmallFlag){
			if((name[i] >= 'A') && (name[i] <= 'Z')){	name[i] |= 0x20;	}
		}
	}
}
BOOL	FindDirectory (FINDSTR *FindBlk, struct find_t *finddata)
{
	long	offset, cluster;
	DIR		dirbuff;
//	int		i, j, k, n, drive, DirCount, DirMax;
	int		i, j, k, n, drive, DirCount;
	int		NameCnt;
	
		offset = (FindBlk->DirNo) << 5;
		cluster = FindBlk->cluster;
		drive = FindBlk->drive;

		memset(finddata->name,0,sizeof(finddata->name));
//		if (FindBlk->mode){					/* Root Directory */
		if ((FindBlk->mode) && (DevInf[drive].xBpb.FatType != 32)){					/* Root Directory */
			offset = offset & (long)DevInf[drive].xBpb.SectorPerBytes-1; /* (-1)   97.05.06 kf (Tel:Sugita) */
			DirCount = (long)DevInf[drive].xBpb.SectorPerBytes / 32;
			NameCnt= 0;			//20091113
			for (i=FindBlk->DirNo; i<DevInf[drive].xBpb.Dirs; i++) {
				Read_Dir ((BYTE *)&dirbuff, drive, cluster, offset, 32);
				if (dirbuff.Name[0] == 0) {		/* end of directory entry */
					for (j=0; j<25; j++) finddata->reserved[j] = 0xFF;
					return FALSE;
				}
//				if (filecmp (dirbuff.Name, (char *)FindBlk->mask)) {
				if(dirbuff.Name[0] != 0xe5){		//�폜�}�[�N
					if (dirbuff.Attributes != 0x0f) {				//20091116
						if ((filecmp (dirbuff.Name, (char *)FindBlk->mask)) ||
							(dirbuff.Attributes & FA_DIRECT)){					//Dirctory�͒��o����20091117
							finddata->attrib = dirbuff.Attributes;		/* File Attributes */
							finddata->wr_time = dirbuff.Time;			/* Create time */
							finddata->wr_date = dirbuff.Date;			/* Create Date */
							finddata->size = dirbuff.FileSize;			/* File Size */
							if(NameCnt == 0){			//8.3 Dir
								for (j=0; j<8; j++) {
									if (dirbuff.Name[j] == ' ') break;
									finddata->name[j] = dirbuff.Name[j];
								}
								n = j++;
								for (k=8; k<11; k++) {
									if (dirbuff.Name[k] == ' ') break;
									finddata->name[j++] = dirbuff.Name[k];
								}
								if ((n+1) == j) finddata->name[n] = 0;
								else {
									finddata->name[n] = '.';
									finddata->name[j] = 0;
								}
								SetLargSmallName(dirbuff.dummy,finddata->name);
							}else{
								SetFileName(finddata->name,NameCnt);
							}
							if (((++i) % DirCount) == 0) cluster++;
							finddata->reserved[14] = i / 0x100;
							finddata->reserved[15] = i % 0x100;
							finddata->reserved[16] = cluster / 0x1000000;	/*  */
							cluster= cluster % 0x1000000;
							finddata->reserved[17] = cluster / 0x10000;	/*  */
							cluster= cluster % 0x10000;
							finddata->reserved[18] = cluster / 0x100;	/*  */
							finddata->reserved[19] = cluster % 0x100;	/*  */
							finddata->reserved[24] = dirbuff.dummy;		//20091116 Name Kind Add
							return TRUE;
						}
						NameCnt= 0;
						memset(finddata->name,0,sizeof(finddata->name));
					}else{
						GetLnfFileName((LNFEntry*)&dirbuff,&NameCnt,finddata->name);
					}
				}else{				//20100330
					NameCnt= 0;
					memset(finddata->name,0,sizeof(finddata->name));
				}
//				}
				offset += 32;
				if (((i+1) % DirCount) == 0) {
					cluster++;
					offset = 0;
				}
			}
			for (j=0; j<25; j++) finddata->reserved[j] = 0xFF;
			return FALSE;
		}
		else {										/* sub directory entry */
			DirCount = (long)DevInf[drive].xBpb.SectorPerBytes *
					   (long)DevInf[drive].xBpb.ClusterPerSectors / 32;
			offset = offset & (((long)DevInf[drive].xBpb.SectorPerBytes* 
				(long)DevInf[drive].xBpb.ClusterPerSectors)- 1); /* 00.03.05 */
			NameCnt= 0;
			for (i=FindBlk->DirNo;; i++) {
				Read_System ((BYTE *)&dirbuff, drive, cluster, offset, 32);
				if (((unsigned char)dirbuff.Name[0] != 0) && ((unsigned char)dirbuff.Name[0] != (unsigned char)0xE5)) {
					if ((dirbuff.Attributes != 0x0f) ||							//20091116
						((dirbuff.Name[0] == '.') && (dirbuff.Name[1] == '.'))){	//..��StartCluster=�O
						if ((filecmp (dirbuff.Name, (char *)FindBlk->mask)) ||
							((dirbuff.Name[0] == '.') && (dirbuff.Name[1] == '.')) ||	//..��StartCluster=�O
							(dirbuff.Attributes & FA_DIRECT)){					//Dirctory�͒��o����20091117
							finddata->attrib = dirbuff.Attributes;		/* File Attributes */
							finddata->wr_time = dirbuff.Time;			/* Create time */
							finddata->wr_date = dirbuff.Date;			/* Create Date */
							finddata->size = dirbuff.FileSize;			/* File Size */
							if(NameCnt == 0){
								for (j=0; j<8; j++) {
									if (dirbuff.Name[j] == ' ') break;
									finddata->name[j] = dirbuff.Name[j];
								}
								n = j++;								/* 1997,5,14 k.s */
								for (k=8; k<11; k++) {
									if (dirbuff.Name[k] == ' ') break;  /* j-->k 97.05.06 kf (Tel:Sugita) */
									finddata->name[j++] = dirbuff.Name[k];
								}
								if ((n+1) == j) finddata->name[n] = 0;	/* 1997,5,14 k.s */
								else {
									finddata->name[n] = '.';			/* 1997,5,14 k.s */
									finddata->name[j] = 0;
								}
								SetLargSmallName(dirbuff.dummy,finddata->name);
							}else{
								SetFileName(finddata->name,NameCnt);
							}
							if (((++i) % DirCount) == 0){
								cluster = GetFAT (cluster, drive);
							}
							finddata->reserved[14] = i / 0x100;
							finddata->reserved[15] = i % 0x100;
							finddata->reserved[16] = cluster / 0x1000000;
							cluster= cluster % 0x1000000;
							finddata->reserved[17] = cluster / 0x10000;
							cluster= cluster % 0x10000;
							finddata->reserved[18] = cluster / 0x100;
							finddata->reserved[19] = cluster % 0x100;
							finddata->reserved[24] = dirbuff.dummy;		//20091116 Name Kind Add
							if (((unsigned long)cluster == (unsigned long)0xFFFFFFF8) ||
								 ((unsigned long)cluster == (unsigned long)0xFFFFFFFF) ||
								 ((unsigned long)cluster == (unsigned long)0x0FFFFFF8) ||
								 ((unsigned long)cluster == (unsigned long)0x0FFFFFFF)) {
								for (j=0; j<25; j++) finddata->reserved[j] = (unsigned char)0xFF;
							}
							return TRUE;
						}
						NameCnt= 0;
						memset(finddata->name,0,sizeof(finddata->name));
					}else{
						GetLnfFileName((LNFEntry*)&dirbuff,&NameCnt,finddata->name);
					}
				}else{				//20100330
					NameCnt= 0;
					memset(finddata->name,0,sizeof(finddata->name));
				}
				offset += 32;
				if (((i+1) % DirCount) == 0) {
					cluster = GetFAT (cluster, drive);
					if (((unsigned long)cluster == (unsigned long)0xFFFFFFF8) || ((unsigned long)cluster == (unsigned long)0xFFFFFFFF) ||
						((unsigned long)cluster == (unsigned long)0x0FFFFFF8) || ((unsigned long)cluster == (unsigned long)0x0FFFFFFF)) {
						for (j=0; j<25; j++) finddata->reserved[j] = 0xFF;
						return FALSE;
					}
					offset = 0;
				}
			}
		}

}


/********************************************************
*  compare wildcard file name							*
********************************************************/

BOOL	filecmp (char *Name, char *mask)
{
	int		i;

		if (((BYTE)Name[0] == 0xE5) && ((BYTE)mask[0] != 0xE5)) return FALSE;
		for (i=0; i<11; i++) {
			if ((BYTE)mask[i] != 0) {
				if ((BYTE)Name[i] != (BYTE)mask[i]) return FALSE;
			}
		}
		return TRUE;
}


/********************************************************
*  change default directory								*
********************************************************/

int		ChangeDir (char *FileName)
{
	char	FilePath[128];
	int		n, Channel, drive;
	char*	cp;
	char*	cp1;

		strcpy(findFileName,FileName);
		if ((cp = strchr (findFileName, '..')) != NULL){
			*cp= 0;
			if ((cp = strchr (findFileName, '\\')) != NULL){
				*cp= 0;
			}
			drive = *findFileName - 'A';				/* current drive name */
			strcat(findFileName,DevInf[drive].xBpb.CurrentPath);
			cp= findFileName;
			cp1= NULL;
			for(n= 0; ; n++){
				if ((cp = strchr (cp, '\\')) == NULL){	break;	}
				cp1= cp;
				cp++;
			}
			if(cp1 != NULL){
				*cp1= (char)NULL;
				if(n == 1){	strcat(findFileName,"\\");	}
			}
		}
		n = strlen (findFileName);
		if (n <= 3) {
			if ((n == 1) && (*findFileName == '\\')) {
				drive = System.CurrentDrive - 'A';		/* current drive name */
				DevInf[drive].xBpb.CurrentDirCluster =
										DevInf[drive].xBpb.StartDir;	/* start of Root Dir sector */
				strcpy (DevInf[drive].xBpb.CurrentPath, "\\");
				return 0;
			}
			if (strcmp (&findFileName[1], ":\\") == 0) {
				drive = *findFileName - 'A';				/* current drive name */
				DevInf[drive].xBpb.CurrentDirCluster =
										DevInf[drive].xBpb.StartDir;	/* start of Root Dir sector */
				strcpy (DevInf[drive].xBpb.CurrentPath, "\\");
				return 0;
			}
		}

//		Channel = File_Open (FileName, _OPEN);
		Channel = File_Open (findFileName, _OPEN);
		if (Channel < 0) return Channel;			/* Create Error */

//		if (!Build_FileName (FileName, FilePath)) return -1;
		if (!Build_FileName (findFileName, FilePath)) return -1;
		drive = FilePath[0] - 'A';
		strcpy (DevInf[drive].xBpb.CurrentPath, &FilePath[2]);	/* current directory name */
		File_Close (0,Channel);
		return 0;

}


/********************************************************
*  Make Sub-Directory									*
********************************************************/

int		MakeDirectory (char *FileName)
{
	IFCB	*iFcb;
	int		i, n, Channel, totalDir, drive;
	DIR		subDir[2];
	/*BYTE	DirBuff[32];*/

		Channel = File_Open (FileName, _CREATE);
		if (Channel < 0) return Channel;			/* Create Error */

		for (i=1; i<8; i++) subDir[0].Name[i] = ' ';
		for (i=2; i<8; i++) subDir[1].Name[i] = ' ';
		subDir[0].Name[0] = '.';
		subDir[1].Name[0] = '.';
		subDir[1].Name[1] = '.';
		for (i=0; i<3; i++) subDir[0].Extention[i] = ' ';
		for (i=0; i<3; i++) subDir[1].Extention[i] = ' ';
		
//		for (i=0; i<10; i++){
		iFcb = Get_FCBaddress (Channel);
		for (i=0; i<2; i++){
			subDir[i].dummy = 0;
			subDir[i].msTime= 0;
			subDir[i].VfatTime= (unsigned short)iFcb->CurrentDirBlock.Time;
			subDir[i].VfatDate= (unsigned short)iFcb->CurrentDirBlock.Date;
			subDir[i].AcsDate= (unsigned short)iFcb->CurrentDirBlock.Date;
			subDir[i].StartClusterHigh= 0;
		}
//		for (i=0; i<10; i++) subDir[1].dummy[i] = 0;
		subDir[0].Attributes = 0x30;			/* attribute */
		subDir[1].Attributes = 0x30;			/* attribute */
		subDir[0].FileSize = 0;
		subDir[1].FileSize = 0;

//		iFcb = Get_FCBaddress (Channel);
		subDir[0].Time = (unsigned short)iFcb->CurrentDirBlock.Time;		/* Create time */
		subDir[0].Date = (unsigned short)iFcb->CurrentDirBlock.Date;		/* Create Date */
		subDir[1].Time = (unsigned short)iFcb->CurrentDirBlock.Time;		/* Create time */
		subDir[1].Date = (unsigned short)iFcb->CurrentDirBlock.Date;		/* Create Date */
									/* .��..�����ւ���00.04.14 */
		drive = iFcb->Drive;
		if(DevInf[drive].xBpb.FatType == 32){
			if (iFcb->DirMode) {			/* TRUE: root,  FALSE: sub dir */
				subDir[1].StartClusterHigh= 0;
				subDir[1].StartCluster = 0;
			}else{
				subDir[1].StartClusterHigh= iFcb->StartDirCluster/0x10000;
				subDir[1].StartCluster = iFcb->StartDirCluster%0x10000;
			}
			subDir[0].StartClusterHigh= iFcb->CurrentCluster/0x10000;
			subDir[0].StartCluster = iFcb->CurrentCluster%0x10000;
		}else{
			if (iFcb->DirMode) {			/* TRUE: root,  FALSE: sub dir */
				subDir[1].StartCluster = 0;
			}
			else {
				subDir[1].StartCluster = (unsigned short)iFcb->StartDirCluster;	/* Start of current dir. cluster */
			}
			subDir[0].StartCluster = (unsigned short)iFcb->CurrentCluster;		/* Current cluster Number */
		}
		iFcb->CurrentDirBlock.Attributes = 0x10;			/* File Attributes */
		
		n = Dir_File_Write (Channel, (void *)subDir, 64, 0);
		if (n != 64) {
			File_Close (0,Channel);
			return -1;						/* create error */
		}

		drive = iFcb->Drive;
		totalDir = (long)DevInf[drive].xBpb.SectorPerBytes *
				   (long)DevInf[drive].xBpb.ClusterPerSectors / 32;
		totalDir -= 2;
		memset (subDir, 0, 32);
		for (i=0; i<totalDir; i++) {
			if (FWrite_Data (TRUE, iFcb, (unsigned char *)subDir, 32) != 32) return FALSE;
		}
		iFcb->FileSize = 0;			/* �f�B���N�g���̓T�C�Y�O�Ƃ���00.04.24 */
		File_Close (0,Channel);
		return 0;

}


/********************************************************
*  File open/create										*
*		mode:	_CREATE		1		file create mode	*
*				_OPEN		2		file open mode		*
*				_READ		4		normal read mode	*
*				_WRITE		8		normal write mode	*
*				_UPDATE		0x10	write override mode *
*				_TRUNC		0x20	write truncate mode *
********************************************************/
int		File_Open (char *FileName, int mode)
{
	IFCB	*iFcb;
	int		Channel;
	BOOL	dir;
	int		drive;								// 20100614 add

		Channel = Get_FCBNumber ();				/* Get File Channel */
		if (Channel == -1) return -1;			/* not enough channel */

		if (!Build_FileName (FileName, openFilePath)) return -3;

		dir = Fined_File (Channel, openFilePath);	/* get directory number */
		if (!dir) {								/* file not found */
			if (mode & _CREATE) {				/* create mode ? */
				drive = openFilePath[0] - 'A';											// 20100614 add
				if((System.DriveStatus & (1 << drive)) == 0){	return -1;	}			// 20100614 add
				//File Name 
				if (!File_Install (Channel, openFilePath)) {
					Close_FCBNumber (Channel);	/* reset FCB */
					return -2;
				}
				iFcb = Get_FCBaddress (Channel);
				iFcb->Access = _WRITE;
			}
			else {
				Close_FCBNumber (Channel);		/* reset FCB */
				return -1;						/* file not found */
			}
		}
		else {
			if (mode & _OPEN) {					/* open mode ? */
				Set_FCB (Channel, openFilePath);	/* setup file control table */
				iFcb = Get_FCBaddress (Channel);
				iFcb->Access = _READ;
			}
			else if (mode & _CREATE) {
				Set_FCB (Channel, openFilePath);	/* setup file control table */
				iFcb = Get_FCBaddress (Channel);
//				iFcb->Access = _UPDATE;
				iFcb->Access = _TRUNC;
			}
			else if (mode & _TRUNC) {
				Set_FCB (Channel, openFilePath);	/* setup file control table */
				iFcb = Get_FCBaddress (Channel);
				iFcb->Access = _TRUNC;
			}
			else if (mode & _UPDATE) {
				Set_FCB (Channel, openFilePath);	/* setup file control table */
				iFcb = Get_FCBaddress (Channel);
				iFcb->Access = _UPDATE;
			}
			else {
				Close_FCBNumber (Channel);		/* reset FCB */
				return -99;						/* file found already */
			}
		}

		return Channel;
}

int		File_Search (char *FileName,int *size)
{
	IFCB	*iFcb;
	int		Channel;
	BOOL	dir;

		Channel = Get_FCBNumber ();				/* Get File Channel */
		if (Channel == -1) return -1;			/* not enough channel */

		if (!Build_FileName (FileName, openFilePath)) return -3;

		dir = Fined_File (Channel, openFilePath);	/* get directory number */
		if (!dir) {								/* file not found */
			Close_FCBNumber (Channel);		/* reset FCB */
			return -1;						/* file not found */
		}
		else {
			iFcb = Get_FCBaddress (Channel);
			*size= iFcb->FileSize;
			Close_FCBNumber (Channel);		/* reset FCB */
		}
		return 0;
}


/****************************************************
*  File Data read									*
****************************************************/

int		File_Read (int channel, void *buff, int dsize, long pointer)
{
	IFCB	*iFcb;
	int		rLeng;
	int		err;

		iFcb = Get_FCBaddress (channel);
		if (iFcb == 0) return -1;				/* not channel open */

/* illegal read mode */
		if (!(iFcb->Access & (_READ | _UPDATE | _TRUNC))) return -1;

		if (iFcb->FileSize < pointer) return -2;	/* EOF */
		if (pointer != iFcb->CurrentData) {			/* Current data pointer */
/* seek */
			if (pointer < iFcb->CurrentData) {		/* Back read */
				err = File_Rewind (iFcb);
				if (err != 0) return err;			/* rewind error */
			}

			for (;;) {
				if (pointer < (iFcb->CurrentData + iFcb->ClusterSize)) break;
				iFcb->CurrentData += iFcb->ClusterSize;
				iFcb->RelativeCluster++;			/* Current Releative cluster number */
				err = Get_NextCluster (iFcb);
				if (err != 0) return err;
			}
		}

		rLeng = FRead_Data (iFcb, (unsigned char *)buff, dsize);
		return rLeng;
		
}


/************************************************
*  File Data Write								*
************************************************/

int		Dir_File_Write (int channel, void *buff, int dsize, long pointer)
{
	IFCB	*iFcb;
	int		err, rLeng, drive;
	long	rc, cc;
	BOOL	mode;

	err= 0;
		iFcb = Get_FCBaddress (channel);
		if (iFcb == 0){
			return 0;				/* not channel open */
		}
/* illegal write mode  ? */
//		if (!(mode=(iFcb->Access & (_WRITE | _UPDATE | _TRUNC)))){
		if ((mode=(iFcb->Access & (_WRITE | _UPDATE | _TRUNC))) == 0){
			return 0;
		}
		if (iFcb->FileSize < (pointer+dsize)) {		/* EOF */
													/* File extention */
													/* Cal. current cluster byte address */
			iFcb->CurrentData = iFcb->FileSize - (iFcb->FileSize % iFcb->ClusterSize);
			if (iFcb->CurrentData != iFcb->FileSize) {
				iFcb->CurrentData += iFcb->ClusterSize;
			}
			
			rc = iFcb->RelativeCluster;			/* Current Releative cluster number */
			cc = iFcb->CurrentCluster;			/* Current cluster number */
			for (;;) {
				if ((pointer+dsize) <= (iFcb->FileSize + iFcb->ClusterSize)) break;
				iFcb->FileSize += iFcb->ClusterSize;
				iFcb->RelativeCluster++;			/* Current Releative cluster number */
				err = Extent_Cluster (iFcb);
				if (err != 0){
					return 0;
				}
			}

			iFcb->RelativeCluster = rc;			/* Current Releative cluster number */
			iFcb->CurrentCluster = cc;			/* Current cluster number */
			iFcb->FileSize = pointer + dsize;
			iFcb->CurrentData = pointer;
			mode = FALSE;							/* write new mode */
		}
		else {
			if (pointer < iFcb->CurrentData) {
				err = File_Rewind (iFcb);
				if (err != 0) {
					return 0;				/* rewind error */
				}
			}
			else {
				iFcb->CurrentData = iFcb->CurrentData - (iFcb->CurrentData % iFcb->ClusterSize);
			}

			drive = iFcb->Drive;
			for (;;) {
				if (pointer <= (iFcb->CurrentData + iFcb->ClusterSize)) break;
				iFcb->CurrentData += iFcb->ClusterSize;
				iFcb->RelativeCluster++;			/* Current Releative cluster number */
				iFcb->CurrentCluster = GetFAT (iFcb->CurrentCluster, drive);
				if (err != 0){
					return 0;
				}
			}
			iFcb->CurrentData = pointer;			/* set Data pointer */
			mode = TRUE;							/* write override mode */
		}

		rLeng = FWrite_Data (mode, iFcb, (unsigned char *)buff, dsize);
		return rLeng;
}

int		File_Write (int channel, void *buff, int dsize, long pointer)
{
	IFCB	*iFcb;
	int		err, rLeng, drive;
	long	rc, cc;
	BOOL	mode;

	err= 0;
		iFcb = Get_FCBaddress (channel);
		if (iFcb == 0){
			return 0;				/* not channel open */
		}
/* illegal write mode  ? */
//		if (!(mode=(iFcb->Access & (_WRITE | _UPDATE | _TRUNC)))){
		if ((mode=(iFcb->Access & (_WRITE | _UPDATE | _TRUNC))) == 0){
			return 0;
		}
		if (iFcb->FileSize < (pointer+dsize)) {		/* EOF */
													/* File extention */
													/* Cal. current cluster byte address */
			iFcb->CurrentData = iFcb->FileSize - (iFcb->FileSize % iFcb->ClusterSize);
			if (iFcb->CurrentData != iFcb->FileSize) {
				iFcb->CurrentData += iFcb->ClusterSize;
			}
			
			rc = iFcb->RelativeCluster;			/* Current Releative cluster number */
			cc = iFcb->CurrentCluster;			/* Current cluster number */
			for (;;) {
				if ((pointer+dsize) <= (iFcb->FileSize + iFcb->ClusterSize)) break;
				iFcb->FileSize += iFcb->ClusterSize;
				iFcb->RelativeCluster++;			/* Current Releative cluster number */
				err = Extent_Cluster (iFcb);
				if (err != 0){
					return 0;
				}
			}

			iFcb->RelativeCluster = rc;			/* Current Releative cluster number */
			iFcb->CurrentCluster = cc;			/* Current cluster number */
			iFcb->FileSize = pointer + dsize;
			iFcb->CurrentData = pointer;
			mode = FALSE;							/* write new mode */
		}
		else {
			if (pointer < iFcb->CurrentData) {
				err = File_Rewind (iFcb);
				if (err != 0) {
					return 0;				/* rewind error */
				}
			}
			else {
				iFcb->CurrentData = iFcb->CurrentData - (iFcb->CurrentData % iFcb->ClusterSize);
			}

			drive = iFcb->Drive;
			for (;;) {
				if (pointer <= (iFcb->CurrentData + iFcb->ClusterSize)) break;
				iFcb->CurrentData += iFcb->ClusterSize;
				iFcb->RelativeCluster++;			/* Current Releative cluster number */
				iFcb->CurrentCluster = GetFAT (iFcb->CurrentCluster, drive);
				if (err != 0){
					return 0;
				}
			}
			iFcb->CurrentData = pointer;			/* set Data pointer */
			mode = TRUE;							/* write override mode */
		}

		rLeng = File_Write_Data (mode, iFcb, (unsigned char *)buff, dsize);
//		rLeng = FWrite_Data (mode, iFcb, (unsigned char *)buff, dsize);
		return rLeng;
}

/************************************************
*  File Close									*
************************************************/

int		File_Close (int mode,int Channel)
{
	IFCB	*iFcb;
	long	offset;
	long	ClusterNo, NextCluster;

		iFcb = Get_FCBaddress (Channel);
		if (iFcb->Access & _TRUNC) {								/* if Write open ? */
			ClusterNo = iFcb->CurrentCluster;
			for (;;) {
				NextCluster = GetFAT (ClusterNo, iFcb->Drive);
				SetFAT (ClusterNo, 0, iFcb->Drive);
				if ((unsigned long)NextCluster == (unsigned long)0xFFFFFFF8) break;
				if ((unsigned long)NextCluster == (unsigned long)0xFFFFFFFF) break;		/* 97.10.3 */
				if ((unsigned long)NextCluster == (unsigned long)0x0FFFFFF8) break;		/* 97.10.3 */
				if ((unsigned long)NextCluster == (unsigned long)0x0FFFFFFF) break;		/* 97.10.3 */
				ClusterNo = NextCluster;
			}
//			SetFAT (iFcb->CurrentCluster, 0xFFFFFFF8, iFcb->Drive);
			SetFAT (iFcb->CurrentCluster, 0x0FFFFFFF, iFcb->Drive);
			iFcb->Access = _WRITE;
			iFcb->FileSize = iFcb->CurrentData;						/* File Size */
		}
		if ((iFcb->Access & _WRITE) || (iFcb->Access & _UPDATE)) {	/* if Write open ? */
			iFcb->CurrentDirBlock.Attributes |= 0x20;				/* File Attributes */
			iFcb->CurrentDirBlock.FileSize = iFcb->FileSize;		/* File Size */
			iFcb->CurrentDirBlock.Time = GetCurrentTime();		/* 20100615 add Create time */
			iFcb->CurrentDirBlock.Date = GetCurrentDate();		/* 20100615 add Create Date */
			if (iFcb->DirMode) {
				offset = DevInf[iFcb->Drive].xBpb.SectorPerBytes;	/* 1997,6,23 */
				offset = iFcb->CurrentDir % (offset / 32);
				offset <<= 5;
				Write_Dir ((BYTE*)&(iFcb->CurrentDirBlock),
						   iFcb->Drive,
						   iFcb->CurrentDirCluster,
						   offset);
			}
			else {
				offset = DevInf[iFcb->Drive].xBpb.SectorPerBytes
					   * DevInf[iFcb->Drive].xBpb.ClusterPerSectors;	/* cluster/Sectors */
				offset = iFcb->CurrentDir % (offset / 32);				/* 1997, 6,23 */
				offset <<= 5;
				Write_Data_Dir (TRUE, (BYTE*)&(iFcb->CurrentDirBlock),
//				Write_Data (TRUE, (BYTE*)&(iFcb->CurrentDirBlock),
							  iFcb->Drive,
							  iFcb->CurrentDirCluster,
							  offset, 32);
			}
			FlushAll (iFcb->Drive);								/* Flush all cluster or sector */
		}
		if(mode == 0){
			Close_FCBNumber (Channel);
		}
		return 0;

}


/************************************************
* Get File Channel								*
************************************************/

int		Get_FCBNumber (void)
{
	int		i, bit;

		bit = 1;
		for (i=0; i<MaxOpen; i++) {
			if (!(System.OpenFlag & bit)) {
				System.OpenFlag |= bit;
				System.NumberOfOpenFiles++;	/* current open files */
				return i;
			}
			bit <<= 1;
		}
		return -1;			/* not enough channel */
}


/************************************************
*  Close FCB channel							*
************************************************/

BOOL	Close_FCBNumber (int channel)
{
	int		bit;

		bit = 1 << channel;
		if (System.OpenFlag & bit) {
			System.OpenFlag &= (~bit);
			System.NumberOfOpenFiles--;	/* current open files */
			return TRUE;
		}
		return FALSE;					/* not open channel */
}


/************************************************
*  Generate Full Path name with normalize		*
************************************************/
void	SetFileName8(char* FileName,char* FileName8)
{
	int	i,j;

	for(i= 0; i < 8; i++){
		if((FileName[i] == 0) || (FileName[i] == '.')){	break;	}
		FileName8[i]= FileName[i];
	}
	if(i >= 8){
		for(;;i++){
			if((FileName[i] == 0) || (FileName[i] == '.')){	break;	}
		}
		if(FileName[i] == '.'){
			i++;
			for(j= 0; j < 3; j++,i++){
				if(FileName[i] == 0){	break;	}
				FileName8[8+j]= FileName[i];
			}
		}
	}else{
		if(FileName[i] == '.'){
			i++;
			for(j= 0; j < 3; j++,i++){
				if(FileName[i] == 0){	break;	}
				FileName8[8+j]= FileName[i];
			}
		}
	}
}
int	check83Name(char* name,int *kind)
{
	int	len;
	int	i,j;
	int	flag1,flag2;
	int	flag;

	flag= flag1= flag2= 0;
	len= strlen(name);
	for(i= 0; i < len; i++){
		if(name[i] == '.'){							break;	}
		if((name[i] >= 'a') && (name[i] <= 'z')){ flag2= 1;	}
		if((name[i] >= 'A') && (name[i] <= 'Z')){ flag1= 1;	}
	}
	if(i > 8){							return(-1);	}	//File Name��8�����ȏ�
	if((flag1 == 1) && (flag2 == 1)){	return(-1);	}	//�啶���A������������
	if(flag2 == 1){	flag= 0x08;						}	//����������
	if(name[i] != '.'){					return(0);	}	//Sub Name�Ȃ�
	if(name[i+1] == '.'){				return(0);	}	//..�̏ꍇ
	flag1= flag2= 0;
	for(i++,j= 0; i < len; j++,i++){
		if((name[i] >= 'a') && (name[i] <= 'z')){ flag2= 1;	}
		if((name[i] >= 'A') && (name[i] <= 'Z')){ flag1= 1;	}
	}
	if((j > 3) || ((flag1 == 1) && (flag2 == 1))){	return(-1);	}	//Sub Name���R�����ȏォ�啶��������������
	if(flag2 == 1){	flag |= 0x10;	}
	*kind= flag;
	return(0);
}
void	SetFileName2LnfName(char* FileName)
{
	int	i;
	int	flag= 0;			//20100318

	LNFRecCnt= 0;				//20091116 add
	DosNameKind= 0;				//20091116 add
	if(check83Name(&FileName[0],&DosNameKind) != 0){
		strcpy(srcFileName,&FileName[0]);
		LNFFileBuild(srcFileName);
		flag= 1;			//20100318
	}
	memset(DosFileName,' ',sizeof(DosFileName));
	DosFileName[11]= 0;
	SetFileName8(&FileName[0],DosFileName);		//8.3�쐬
	/* ��������啶���ɕϊ����� */
	for(i=0;DosFileName[i]!='\0';i++){
		if((DosFileName[i] >= 'a') && (DosFileName[i] <= 'z')){
			DosFileName[i]= DosFileName[i]- 'a' + 'A';
		}else{
			DosFileName[i]= DosFileName[i];
		}
	}
	//20100318
	if(flag == 1){
		if(DosFileName[6] != ' '){	DosFileName[6]= '~';	DosFileName[7]= '1';	}
	}
}
BOOL	Build_FileName (char *FileName, char *FilePath)
{
//	int		i;
	int		drive;
//	char	FileName8[16];

/* build full path */
//	LNFRecCnt= 0;				//20091116 add
//	DosNameKind= 0;				//20091116 add
	if (*FileName == '\\') {					/* root path */
		FilePath[0] = System.CurrentDrive;		/* set drive name */
		FilePath[1] = ':';
		FilePath[2] = 0;
		strcat (FilePath, FileName);
	}
	else if (*(FileName+1) != ':') {
		FilePath[0] = System.CurrentDrive;		/* set drive name */
		FilePath[1] = ':';
		FilePath[2] = 0;
		drive = FilePath[0] - 'A';
		if ((drive < 0) || (drive > (MAX_DEVICE- 1))) return FALSE;
		strcat (FilePath, DevInf[drive].xBpb.CurrentPath);
		if (strcmp(DevInf[drive].xBpb.CurrentPath, "\\") != 0) strcat (FilePath, "\\");
		strcat (FilePath, FileName);
	}
	else {
		if (FileName[2] != '\\') {
			FilePath[0] = FileName[0];
			FilePath[1] = FileName[1];
			FilePath[2] = 0;
			drive = FileName[0] - 'A';
			if ((drive < 0) || (drive > MAX_DEVICE-1)) return FALSE;
			strcat (FilePath, DevInf[drive].xBpb.CurrentPath);
			if (strcmp(DevInf[drive].xBpb.CurrentPath, "\\") != 0) strcat (FilePath, "\\");
//			if(check83Name(&FileName[2],&DosNameKind) == 0){
				strcat (FilePath, &FileName[2]);
//			}else{
				//LNF�Ή�
//				strcpy(srcFileName,&FileName[2]);
//				memset(FileName8,0,sizeof(FileName8));
//				SetFileName8(&FileName[2],FileName8);		//8.3�쐬
//				strcat (FilePath, &FileName8[0]);
//				LNFFileBuild(srcFileName);
//			}
		}
		else {
//			if(check83Name(&FileName[3],&DosNameKind) == 0){
				strcpy (FilePath, FileName);	/* full path */
//			}else{
//				strcpy(srcFileName,&FileName[3]);		//FileName=c:xxxxxxx
//				memset(FileName8,0,sizeof(FileName8));
//				SetFileName8(&FileName[3],FileName8);	//8.3�쐬
//				FilePath[0]= FileName[0];
//				FilePath[1]= FileName[1];
//				FilePath[2]= FileName[2];
//				strcpy (&FilePath[3], &FileName8[0]);	/* full path */
//				LNFFileBuild(srcFileName);
//			}
		}
	}
//	if(large == 0){
//		/* ��������啶���ɕϊ����� */
//		for(i=0;FilePath[i]!='\0';i++){
//			if((FilePath[i] >= 'a') && (FilePath[i] <= 'z')){
//				FilePath[i]= FilePath[i]- 'a' + 'A';
//			}else{
//				FilePath[i]= FilePath[i];
//			}
//		}
//	}
	return Is_FileName (FilePath);
		
}


/************************************************************
*  Test legal file name										*
************************************************************/

BOOL	Is_FileName (char *FilePath)
{
	char	*FileName;
	BOOL	dot, dir;
	int		i, leng, letter;

	letter= 0;
		FileName = FilePath;
	/* test for drive name */		
		if (((*FileName & 0xDF) < 'A') || ((*FileName & 0xDF) > 'Z')) {
			if ((*FileName < '0') || (*FileName > '9')) return FALSE;
		}
		FileName++;
		if (*FileName != ':') return FALSE;
		leng = strlen (FilePath);

		FileName++;
		if (*FileName != '\\') return FALSE;
		
		FileName++;
		dir = dot = FALSE;

	/* test for SubDir Name or File Name */

		for (i=3; i<leng; i++) {
			if (*FileName == '\\') {
				if((FileName[1] == '.') && (FileName[2] == '.')){	return TRUE;	}	//..
				if (dir) return FALSE;
				FileName++;
				dot = FALSE;
				letter = 0;
				dir = TRUE;
			}
			else {
				dir = FALSE;
				if (*FileName == '.') {
					if (dot) return FALSE;			/* multiple '.' found */
					dot = TRUE;
					letter = 0;
					FileName++;
				}
				else {
					letter++;
					if (dot) if (letter > 3) return FALSE;
					else     if (letter > 8) return FALSE;
					FileName++;
				}
			}
		}

		return TRUE;				/* normal return */
}

/********************************************************
*  get directory number									*
*														*
*  Purpose:												*
*		Search the directory block, and setup fcb		*
********************************************************/
BOOL	Fined_File (int Channel, char *FileName)
{
//	char	directory[13], FilePath2[80], *FilePath;
	char	*FilePath;
	int		i, n, nLen, drive;
	BOOL	mode;
	IFCB	*iFcb;

		FilePath = FilePath2;
		iFcb = Get_FCBaddress (Channel);
		drive = *FileName - 'A';

		//20100331
		if((System.DriveStatus & (1 << drive)) == 0){	return FALSE;	}			/* Installed drive */



		strcpy (FilePath, FileName+3);

		if(DevInf[drive].xBpb.FatType == 32){		//20091118
			mode = FALSE;
			iFcb->StartDirCluster = DevInf[drive].xBpb.Dirs;	/* start of current dir. cluster number */
			iFcb->BeginCluster= DevInf[drive].xBpb.Dirs;
			iFcb->CurrentCluster = iFcb->BeginCluster;	/* Start of cluster number */
			iFcb->RelativeCluster = 0;			/* Current Releative cluster number */
			iFcb->ClusterSize = (long)DevInf[drive].xBpb.SectorPerBytes *
							(long)DevInf[drive].xBpb.ClusterPerSectors;
			iFcb->CurrentData = 0;				/* Current data pointer */
			iFcb->Access = 0;					/* access mode */
			iFcb->CurrentDirBlock.StartClusterHigh= (unsigned short)(iFcb->BeginCluster/0x10000);		//20091218
			iFcb->CurrentDirBlock.StartCluster= (unsigned short)(iFcb->BeginCluster%0x10000);			//20091218
		}else{
			mode = TRUE;
			iFcb->StartDirCluster = DevInf[drive].xBpb.StartDir;	/* start of current dir. cluster number */
		}
		iFcb->Drive = drive;
		nLen = strlen (FilePath);

//		memset (directory, 0, 12);
		memset (fnddirectory, 0, sizeof(fnddirectory));
		n = 0;
		for (i=0; i<nLen; i++) {
			if (*FilePath == '\\') {
//				if (!LoadDirectory (iFcb, directory, mode)) return FALSE;
				if (!LoadDirectory (iFcb, fnddirectory, mode)) return FALSE;
				SetupFCB (iFcb, drive);
				mode = FALSE;
//				memset (directory, 0, 12);
				memset (fnddirectory, 0, sizeof(fnddirectory));
				n = 0;
				FilePath++;
			}
			else {
//				directory[n++] = *FilePath;
				fnddirectory[n++] = *FilePath;
				FilePath++;
			}
		}
//		if (!LoadDirectory (iFcb, directory, mode)) return FALSE;
		if (!LoadDirectory (iFcb, fnddirectory, mode)) return FALSE;
		SetupFCB (iFcb, drive);
		return TRUE;
}


/********************************************************
*  Create File directory								*
********************************************************/
//void	DirectryChange(DIR *obj, DIR *src)
//{
//	unsigned int	wdata;

//	memcpy(obj->Name,src->Name,22);			/* File Name */
//	wdata = ((src->Time & 0xff00) >> 8) & 0x00ff;
//	wdata += (src->Time & 0x00ff) << 8;
//	obj->Time = (short)wdata;				/* Create time */
//	wdata = ((src->Date & 0xff00) >> 8) & 0x00ff;
//	wdata += (src->Date & 0x00ff) << 8;
//	obj->Date = (short)wdata;				/* Create Date */
//	wdata = ((src->StartCluster & 0xff00) >> 8) & 0x00ff;
//	wdata += (src->StartCluster & 0x00ff) << 8;
//	obj->StartCluster = wdata;		/* Start Cluster number */
//	wdata = ((src->FileSize & 0xff000000) >> 24) & 0x000000ff;
//	wdata += (src->FileSize & 0x00ff0000) >> 8;
//	wdata += (src->FileSize & 0x0000ff00) << 8;
//	wdata += (src->FileSize & 0x000000ff) << 24;
//	obj->FileSize = wdata;			/* File Size */
//}
void	WriteSystemRequest(int drive)
{
	int		i,j;

	for (j=0, i=DevInf[drive].AllocPointer; j<DevInf[drive].MaxBuffers; j++) {
		i++;
		if (i == DevInf[drive].MaxBuffers) i = 0;
		if (DevInf[drive].sysBuff[i].Status == (WRITE_SYSTEM)) {
			Write_Cluster (drive,i);
		}
	}
}
void	SaveLnfSubDir(IFCB* iFcb,int totalDir,int i)
{
	int	LNF_loop;
	int	sum;
	long	offset,nextFAT;
	DIR		SubDir;
	int	drive;
	int	j;

	drive= iFcb->Drive;
	offset = i << 5;
	Read_Data_Dir ((unsigned char *)&SubDir, 
		iFcb->Drive,			/* Drive Number (1-26) */
		iFcb->CurrentCluster,	/* Cluster Number */
		offset,					/* Data offset */
		32);					/* number of read bytes */
	sum= shortNameCheckCode((unsigned char*)&DosFileName[0]);
	for(LNF_loop= 0; LNF_loop < LNFRecCnt; LNF_loop++){
		LNFFileName[LNFRecCnt-LNF_loop-1].checkCodeForShortName= sum;
		memcpy(&SubDir,&LNFFileName[LNFRecCnt-LNF_loop-1],32);
		offset = i << 5;
		if (!Write_Data (TRUE, (BYTE *)&SubDir, drive,
			iFcb->CurrentCluster, offset, 32)){
			return ;
		}
		i++;
		if(i >= totalDir){
			nextFAT = GetFAT (iFcb->CurrentCluster, drive);	/* Current cluster Number */
			if (((unsigned long)nextFAT == (unsigned long)0xFFFFFFF8) ||
				((unsigned long)nextFAT == (unsigned long)0xFFFFFFFF) ||
				((unsigned long)nextFAT == (unsigned long)0x0FFFFFF8) ||
				((unsigned long)nextFAT == (unsigned long)0x0FFFFFFF)) {
				Extent_Cluster (iFcb);
				memset (&SubDir, 0, 32);
				for (j=0; j<totalDir; j++) {
					offset = j << 5;
					if (!Write_Data (FALSE, (BYTE *)&SubDir, drive,
						iFcb->CurrentCluster, offset, 32)){
						return;
					}
				}
				WriteSystemRequest(drive);
//20100630				break;
			}else{						//20100630 Add
				iFcb->CurrentCluster = nextFAT;
			}
			i= 0;							//20100630 Add
		}
	}
}
BOOL	File_Install (int Channel, char *FileName)
{
//	char	directory[13], FilePath2[80], *FilePath;
	char	 *FilePath;
//	int		i, j, k, n, nLen, drive, totalDir, err;
	int		i, j, k, n, nLen, drive, totalDir;
	long	offset, nextFAT;
	IFCB	*iFcb;
//	BOOL	mode, ret;
	BOOL	mode;
	DIR		SubDir;
	unsigned int		StartCluster;
	int		nameCnt;			//20091117
//	IFCB	sFcb;				//20100630 Dell
	int		stotalDir;
	int		si;

/*	unsigned char	SubDirbuf[64];*/

		FilePath = FilePath2;
		iFcb = Get_FCBaddress (Channel);
		drive = *FileName - 'A';
		strcpy (FilePath, FileName+3);

		if(DevInf[drive].xBpb.FatType == 32){		//20091118
			mode = FALSE;
			iFcb->StartDirCluster = DevInf[drive].xBpb.Dirs;	/* start of current dir. cluster number */
			iFcb->BeginCluster= DevInf[drive].xBpb.Dirs;
			iFcb->CurrentCluster = iFcb->BeginCluster;	/* Start of cluster number */
			iFcb->RelativeCluster = 0;			/* Current Releative cluster number */
			iFcb->ClusterSize = (long)DevInf[drive].xBpb.SectorPerBytes *
							(long)DevInf[drive].xBpb.ClusterPerSectors;
			iFcb->CurrentData = 0;				/* Current data pointer */
			iFcb->Access = 0;					/* access mode */
			iFcb->CurrentDirBlock.StartClusterHigh= (unsigned short)(iFcb->BeginCluster/0x10000);		//20091218
			iFcb->CurrentDirBlock.StartCluster= (unsigned short)(iFcb->BeginCluster%0x10000);			//20091218
		}else{
			mode = TRUE;
			iFcb->StartDirCluster = DevInf[drive].xBpb.StartDir;	/* start of current dir. cluster number */
		}
		iFcb->Drive = drive;
		nLen = strlen (FilePath);

		memset (fnddirectory, 0, sizeof(fnddirectory));
		n = 0;
		for (i=0; i<nLen; i++) {
			if (*FilePath == '\\') {
				if (!LoadDirectory (iFcb, fnddirectory, mode)){
					return FALSE;
				}
				SetupFCB (iFcb, drive);
				mode = FALSE;
				memset (fnddirectory, 0, sizeof(fnddirectory));
				n = 0;
				FilePath++;
			}
			else {
				fnddirectory[n++] = *FilePath;
				FilePath++;
			}
		}
		if (mode) {						/* root directory */
//20100318 Del			SetFileName2LnfName(fnddirectory);		//20091116
			if (!CreateDirectory (iFcb, fnddirectory, drive)){
				return FALSE;
			}
		}
		else {
//20100318 Del			SetFileName2LnfName(fnddirectory);		//20091116
			SetupFCB (iFcb, drive);
			totalDir = (long)DevInf[drive].xBpb.SectorPerBytes *
					   (long)DevInf[drive].xBpb.ClusterPerSectors / 32;
			nameCnt= 0;		//20091117
			for (k=0;;) {
				for (i=0; i<totalDir; i++) {
					offset = i << 5;
					/* 051220 Sub Dir ��Read_Data_Dir()���g�p���� */
					Read_Data_Dir ((unsigned char *)&SubDir, 
						iFcb->Drive,			/* Drive Number (1-26) */
						iFcb->CurrentCluster,	/* Cluster Number */
						offset,					/* Data offset */
						32);					/* number of read bytes */

					if (((unsigned char)SubDir.Name[0] == 0) ||
						((unsigned char)SubDir.Name[0] == 0xE5)){
						if(LNFRecCnt != 0){
							if(nameCnt == 0){	//Save Fcb
								memcpy(&sFcb,iFcb,sizeof(IFCB));
								si= i;
								stotalDir= totalDir;
							}
							nameCnt++;
							if(nameCnt < (LNFRecCnt+1)){
								k++;
								continue;
							}

							memcpy(&ssFcb,&sFcb,sizeof(IFCB));		//20100630 Add
							SaveLnfSubDir(&ssFcb,stotalDir,si);		//20100630 Chg
//							strcpy((char*)FileName,DosFileName);
						}
						break;
					}else{					//20100318
						nameCnt= 0;			//20100318
					}						//20100318
					k++;
				}
				if (i != totalDir) break;
				nextFAT = GetFAT (iFcb->CurrentCluster, drive);	/* Current cluster Number */
				if (((unsigned long)nextFAT == (unsigned long)0xFFFFFFF8) ||
					((unsigned long)nextFAT == (unsigned long)0xFFFFFFFF) ||
					((unsigned long)nextFAT == (unsigned long)0x0FFFFFF8) ||
					((unsigned long)nextFAT == (unsigned long)0x0FFFFFFF)) {
					Extent_Cluster (iFcb);
					memset (&SubDir, 0, 32);
					for (j=0; j<totalDir; j++) {
						offset = j << 5;
						if (!Write_Data (FALSE, (BYTE *)&SubDir, drive,
							iFcb->CurrentCluster, offset, 32)){
							return FALSE;
						}
					}
					WriteSystemRequest(drive);
//20100630Del					break;
				}else{									//20100630 Add
					iFcb->CurrentCluster = nextFAT;
				}
			}
/*				iFcb->FileSize += 32;*/
/*			}*/

			iFcb->CurrentData = (long)k << 5;	/* Directory number */
			memset (&SubDir, ' ', 11);
//			for (i=0; i<9; i++) {
//				if (fnddirectory[i] == '.') {
//					if (fnddirectory[i+1] == 0) break;
//					SubDir.Extention[0] = fnddirectory[i+1];
//					if (fnddirectory[i+2] == 0) break;
//					SubDir.Extention[1] = fnddirectory[i+2];
//					if (fnddirectory[i+3] == 0) break;
//					SubDir.Extention[2] = fnddirectory[i+3];
//					break;
//				}
//                if (i == 8) break;
//                SubDir.Name[i] = directory[i];
//			}
			for(i= 0; i < 8; i++){
				SubDir.Name[i] = DosFileName[i];
			}
			for(j= 0; j < 3; j++,i++){
				SubDir.Extention[j] = DosFileName[i];
			}
			
			SubDir.Attributes = 0;				/* File Attributes */
			SubDir.Time = GetCurrentTime();		/* Create time */
			SubDir.Date = GetCurrentDate();		/* Create Date */
			SubDir.dummy = DosNameKind;
			SubDir.msTime= 0;
			SubDir.VfatTime= SubDir.Time;
			SubDir.VfatDate= SubDir.Date;
			SubDir.AcsDate= SubDir.Date;
			if(DevInf[drive].xBpb.FatType == 32){
				StartCluster= GetNewCluster (iFcb->Drive);
				SubDir.StartClusterHigh= (unsigned short)(StartCluster/0x10000);
				SubDir.StartCluster = (unsigned short)(StartCluster%0x10000);
			}else{
				SubDir.StartClusterHigh= 0;
													/* Start Cluster number */
				SubDir.StartCluster = GetNewCluster (iFcb->Drive);
			}
			if (SubDir.StartCluster == 0){
				return FALSE;
			}
//			SetFAT (SubDir.StartCluster, 0xFFFFFFF8L, iFcb->Drive);
			SetFAT (SubDir.StartCluster, 0x0FFFFFFFL, iFcb->Drive);
			SubDir.FileSize = 0;				/* File Size */

			offset = (k % totalDir) << 5;

			if (!Write_Data (TRUE, (BYTE *)&SubDir, drive,
				iFcb->CurrentCluster, offset, 32)){
				return FALSE;
			}
			if(LNFRecCnt != 0){						//20100630 Add
				memcpy(iFcb,&sFcb,sizeof(IFCB));	//20100630 Add
			}										//20100630
			if (!LoadDirectory (iFcb, fnddirectory, FALSE)){
				return FALSE;
			}
		}
		SetupFCB (iFcb, drive);
		return TRUE;
}

//20100322
BOOL	Rename_File_Install (int Channel, char *FileName,DIR* sDir)
{
	char	 *FilePath;
	int		i, j, k, n, nLen, drive, totalDir;
	long	offset, nextFAT;
	IFCB	*iFcb;
	BOOL	mode;
	DIR		SubDir;
	int		nameCnt;			//20091117
//	IFCB	sFcb;				//20100630 Dell
	int		stotalDir;
	int		si;

	FilePath = FilePath2;
	iFcb = Get_FCBaddress (Channel);
	drive = *FileName - 'A';
	strcpy (FilePath, FileName+3);

	if(DevInf[drive].xBpb.FatType == 32){		//20091118
		mode = FALSE;
		iFcb->StartDirCluster = DevInf[drive].xBpb.Dirs;	/* start of current dir. cluster number */
		iFcb->BeginCluster= DevInf[drive].xBpb.Dirs;
		iFcb->CurrentCluster = iFcb->BeginCluster;	/* Start of cluster number */
		iFcb->RelativeCluster = 0;			/* Current Releative cluster number */
		iFcb->ClusterSize = (long)DevInf[drive].xBpb.SectorPerBytes *
						(long)DevInf[drive].xBpb.ClusterPerSectors;
		iFcb->CurrentData = 0;				/* Current data pointer */
		iFcb->Access = 0;					/* access mode */
		iFcb->CurrentDirBlock.StartClusterHigh= (unsigned short)(iFcb->BeginCluster/0x10000);		//20091218
		iFcb->CurrentDirBlock.StartCluster= (unsigned short)(iFcb->BeginCluster%0x10000);			//20091218
	}else{
		mode = TRUE;
		iFcb->StartDirCluster = DevInf[drive].xBpb.StartDir;	/* start of current dir. cluster number */
	}
	iFcb->Drive = drive;
	nLen = strlen (FilePath);

	memset (fnddirectory, 0, sizeof(fnddirectory));
	n = 0;
	for (i=0; i<nLen; i++) {
		if (*FilePath == '\\') {
			if (!LoadDirectory (iFcb, fnddirectory, mode)){
				return FALSE;
			}
			SetupFCB (iFcb, drive);
			mode = FALSE;
			memset (fnddirectory, 0, sizeof(fnddirectory));
			n = 0;
			FilePath++;
		}
		else {
			fnddirectory[n++] = *FilePath;
			FilePath++;
		}
	}
	if (mode) {						/* root directory */
		if (!CreateDirectory (iFcb, fnddirectory, drive)){
			return FALSE;
		}
	}
	else {
		SetupFCB (iFcb, drive);
		totalDir = (long)DevInf[drive].xBpb.SectorPerBytes *
				   (long)DevInf[drive].xBpb.ClusterPerSectors / 32;
		nameCnt= 0;		//20091117
		for (k=0;;) {
			for (i=0; i<totalDir; i++) {
				offset = i << 5;
				/* 051220 Sub Dir ��Read_Data_Dir()���g�p���� */
				Read_Data_Dir ((unsigned char *)&SubDir, 
					iFcb->Drive,			/* Drive Number (1-26) */
					iFcb->CurrentCluster,	/* Cluster Number */
					offset,					/* Data offset */
					32);					/* number of read bytes */

				if (((unsigned char)SubDir.Name[0] == 0) ||
					((unsigned char)SubDir.Name[0] == 0xE5)){
					if(LNFRecCnt != 0){
						if(nameCnt == 0){	//Save Fcb
							memcpy(&sFcb,iFcb,sizeof(IFCB));
							si= i;
							stotalDir= totalDir;
						}
						nameCnt++;
						if(nameCnt < (LNFRecCnt+1)){
							k++;
							continue;
						}
						SaveLnfSubDir(&sFcb,stotalDir,si);
					}
					break;
				}else{					//20100318
					nameCnt= 0;			//20100318
				}						//20100318
				k++;
			}
			if (i != totalDir) break;
			nextFAT = GetFAT (iFcb->CurrentCluster, drive);	/* Current cluster Number */
			if (((unsigned long)nextFAT == (unsigned long)0xFFFFFFF8) ||
				((unsigned long)nextFAT == (unsigned long)0xFFFFFFFF) ||
				((unsigned long)nextFAT == (unsigned long)0x0FFFFFF8) ||
				((unsigned long)nextFAT == (unsigned long)0x0FFFFFFF)) {
				Extent_Cluster (iFcb);
				memset (&SubDir, 0, 32);
				for (j=0; j<totalDir; j++) {
					offset = j << 5;
					if (!Write_Data (FALSE, (BYTE *)&SubDir, drive,
						iFcb->CurrentCluster, offset, 32)){
						return FALSE;
					}
				}
				WriteSystemRequest(drive);
//20100630Del				break;
			}else{						//20100630
				iFcb->CurrentCluster = nextFAT;
			}
		}

		iFcb->CurrentData = (long)k << 5;	/* Directory number */

		memcpy (&SubDir,sDir, sizeof(DIR));

		for(i= 0; i < 8; i++){
			SubDir.Name[i] = DosFileName[i];
		}
		for(j= 0; j < 3; j++,i++){
			SubDir.Extention[j] = DosFileName[i];
		}
		
		offset = (k % totalDir) << 5;

		if (!Write_Data (TRUE, (BYTE *)&SubDir, drive,
			iFcb->CurrentCluster, offset, 32)){
			return FALSE;
		}
	}
	return TRUE;
}


/********************************************************
*  Get FCB address										*
********************************************************/

IFCB	*Get_FCBaddress (int channel)
{
		return &System.iFcb[channel];
}

/********************************************************
*  setup file control table								*
********************************************************/

BOOL	Set_FCB (int Channel, char *FilePath)
{
	IFCB	*iFcb;
	int		bufferNo;
	int	drive;

		iFcb = Get_FCBaddress (Channel);
		if (FilePath[0] != '*') {
			iFcb->Drive = FilePath[0] - 'A';
		}
		else {
			iFcb->Drive = System.CurrentDrive - 'A';
		}
		
		iFcb->FileSize = iFcb->CurrentDirBlock.FileSize;	/* current directory original block */
		drive= iFcb->Drive;
		//20091215 Add
		bufferNo = SearchCluster (drive, iFcb->BeginCluster, 0);
		if(bufferNo == -1){
			bufferNo = AllocateClusterBuffer (iFcb->Drive);
		}
		//////////////////////////////////////////////////
		DevInf[drive].sysBuff[bufferNo].Cluster = iFcb->BeginCluster;		/* Start of cluster number */
		DevInf[drive].sysBuff[bufferNo].Drive = iFcb->Drive;
		DevInf[drive].sysBuff[bufferNo].Mode = 0;							/* k.s */
		WaitForReadEnd (drive,bufferNo);							/* k.s */
		DevInf[drive].sysBuff[bufferNo].Status |= READ_DATA;

		return TRUE;
}


/********************************************************
*  Get Next data cluster number							*
********************************************************/

int		Get_NextCluster (IFCB *iFcb)
{
	long	nextFAT;
	int		drive;

		drive = iFcb->Drive;
		nextFAT = GetFAT (iFcb->CurrentCluster, drive);	/* Current cluster Number */
		iFcb->RelativeCluster++;						/* Current Releative cluster number */
		iFcb->CurrentCluster = nextFAT;
		return 0;
}

/********************************************************
*  Truncate cluster for current data file				*
********************************************************/

int		Truncate_Cluster (IFCB *iFcb)
{
	long	nextFAT;
	int		drive;

		drive = iFcb->Drive;
		for (;;) {
			nextFAT = GetFAT (iFcb->CurrentCluster, drive);	/* Current cluster Number */
			SetFAT (iFcb->CurrentCluster, 0, drive);		/* Reset used FAT */
			iFcb->CurrentCluster = nextFAT;
			if (nextFAT == 0xFFFF) break;					/* end of file */
		}
		return 0;
}


/********************************************************
*  Extent current file cluster (create FAT)				*
********************************************************/

int		Extent_Cluster (IFCB *iFcb)
{
	long	nextFAT, TmpCluster;
	int		i, drive;

		drive = iFcb->Drive;
		nextFAT = GetFAT (iFcb->CurrentCluster, drive);	/* Current cluster Number */
		iFcb->RelativeCluster++;						/* Current Releative cluster number */
		if (((unsigned long)nextFAT >= 0xFFFFFFF8) ||
			((unsigned long)nextFAT >= 0xFFFFFFFF) ||
			((unsigned long)nextFAT >= 0x0FFFFFF8) ||
			((unsigned long)nextFAT >= 0x0FFFFFFF)) {		/* EOF */
			for (i=iFcb->CurrentCluster+1; i<DevInf[drive].xBpb.MaxCluster+2; i++) {
				TmpCluster = GetFAT (i, drive);
				if (TmpCluster == 0) {
					nextFAT = i;
					SetFAT (iFcb->CurrentCluster, nextFAT, drive);
//					SetFAT (nextFAT, 0xFFFFFFF8L, drive);
					SetFAT (nextFAT, 0x0FFFFFFFL, drive);
					iFcb->CurrentCluster = nextFAT;
					return 0;
				}
			}
			return -1;				/*FAT full 1997,8,8*/
		}
		iFcb->CurrentCluster = nextFAT;
		return 0;
}


/****************************************************
*  Seek, File begin pointer							*
****************************************************/

int		File_Rewind (IFCB *iFcb)
{
		iFcb->CurrentCluster = iFcb->BeginCluster;	/* Start of cluster number */
		iFcb->RelativeCluster = 0;					/* Current Releative cluster number */
		return 0;
}

/****************************************************
*  Read Data from file								*
****************************************************/

int		FRead_Data (IFCB *iFcb, BYTE *buff, int dsize)
{
	int		csize, datasize, err, offset, rLen;
	BYTE	*ubuff;
//	BOOL	ret;

		ubuff = buff;
		datasize = dsize;
		rLen = 0;

		if (iFcb->CurrentData >= iFcb->FileSize) return 0;
		offset = iFcb->CurrentData - iFcb->ClusterSize * iFcb->RelativeCluster;
		csize = iFcb->ClusterSize - offset;

		for (;;) {
			if (csize == 0) {
				err = Get_NextCluster (iFcb);		/* get next cluster number */
				if (err != 0) return -1;
				csize = iFcb->ClusterSize;
				offset = 0;
			}

			if (datasize <= csize) {
				if ((iFcb->FileSize - iFcb->ClusterSize * iFcb->RelativeCluster) < csize)
					csize = iFcb->FileSize - iFcb->ClusterSize * iFcb->RelativeCluster - offset;
				if (datasize > csize) datasize = csize;
				//File Size�܂œǂ�20100108
				if ((iFcb->CurrentData+datasize) >= iFcb->FileSize){	datasize= iFcb->FileSize- iFcb->CurrentData;	}
				Read_Data (ubuff, 
						iFcb->Drive,			/* Drive Number (1-26) */
						iFcb->CurrentCluster,	/* Cluster Number */
						offset,					/* Data offset */
						datasize);				/* number of read bytes */
				iFcb->CurrentData += datasize;
				rLen += datasize;
				return rLen;
			}
			//File Size�܂œǂ�20100108
			if ((iFcb->CurrentData+csize) >= iFcb->FileSize){	csize= iFcb->FileSize- iFcb->CurrentData;	}
			Read_Data (ubuff, 
					iFcb->Drive,			/* Drive Number (1-26) */
					iFcb->CurrentCluster,	/* Cluster Number */
					offset,					/* Data offset */
					csize);					/* number of read bytes */
			iFcb->CurrentData += csize;
			/* 050104 �I���ǉ� */
			if (iFcb->CurrentData >= iFcb->FileSize){
				rLen += iFcb->FileSize- (iFcb->CurrentData- csize);
				return rLen;
			}
			datasize -= csize;				/* remain data size */
			ubuff += csize;
			rLen += csize;
			csize = 0;						/* 1997,5,21 K.S */

		}

}


/****************************************************
*  Write Data to File								*
*		mode: TRUE	write override mode				*
*			  FALSE write new mode					*
****************************************************/

int		FWrite_Data (BOOL mode, IFCB *iFcb, unsigned char *buff, int dsize)
{
	int		csize, datasize, err, offset;
	BYTE	*ubuff;
//	BOOL	ret;
//int i;

		ubuff = buff;
		datasize = dsize;

		offset = iFcb->CurrentData - iFcb->ClusterSize * iFcb->RelativeCluster;
		csize = iFcb->ClusterSize - offset;
		if (dsize <= csize) {
			Write_Data (mode, ubuff, 
						iFcb->Drive,			/* Drive Number (1-26) */
						iFcb->CurrentCluster,	/* Cluster Number */
						offset,					/* Data offset */
						datasize);				/* number of read bytes */
			iFcb->CurrentData += datasize;
			return dsize;
		}

		if (csize != 0) {
			Write_Data (mode, ubuff, 
						iFcb->Drive,			/* Drive Number (1-26) */
						iFcb->CurrentCluster,	/* Cluster Number */
						offset,					/* Data offset */
						csize);					/* number of read bytes */
			iFcb->CurrentData += csize;
			datasize -= csize;					/* remain data size */
			ubuff += csize;
		}
		offset = 0;
		csize = iFcb->ClusterSize;

		for (;;) {
			err = Extent_Cluster (iFcb);		/* get next cluster number */
			if (err != 0) return (dsize - datasize);	/*real write bytes 1997,8,8*/

			if (datasize <= csize) {
				csize = datasize;
				Write_Data (mode, ubuff, 
							iFcb->Drive,			/* Drive Number (1-26) */
							iFcb->CurrentCluster,	/* Cluster Number */
							offset,					/* Data offset */
							csize);					/* number of read bytes */
				iFcb->CurrentData += csize;
				return dsize;
			}
	
//			if (iFcb->CurrentCluster == 0x7D4) {
//				i= iFcb->CurrentCluster;
//			}
			Write_Data (mode, ubuff, 
						iFcb->Drive,			/* Drive Number (1-26) */
						iFcb->CurrentCluster,	/* Cluster Number */
						offset,					/* Data offset */
						csize);					/* number of read bytes */
			iFcb->CurrentData += csize;
			datasize -= csize;					/* remain data size */
			ubuff += csize;
		}

}
char	writeBuff[0x8000];
int		File_Write_Data (BOOL mode, IFCB *iFcb, unsigned char *buff, int dsize)
{
	int		csize, datasize, err, offset;
	BYTE	*ubuff;
//	BOOL	ret;
//int i;
	long	sectno;
	unsigned char	*rw_buff;

		ubuff = buff;
		datasize = dsize;

		offset = iFcb->CurrentData - iFcb->ClusterSize * iFcb->RelativeCluster;
		csize = iFcb->ClusterSize - offset;
		if (dsize <= csize) {
			rw_buff= (unsigned char *)&writeBuff[0];
			sectno = CnvSectorNumber (iFcb->CurrentCluster, iFcb->Drive);
			ReadCard (iFcb->Drive,	/* drive Number */
						   sectno,					/* sector number */
						   rw_buff,
						   iFcb->ClusterSize);
			memcpy(&rw_buff[offset],buff,csize);
			//�ŏI�Z�N�^�[�͏������݂��Ȃ�
//			if((System.xBpb[iFcb->Drive].Sectors2+System.xBpb[iFcb->Drive].Sectors) > sectno){
				WriteCard (iFcb->Drive,	/* drive Number */
					   sectno,					/* sector number */
					   rw_buff,
					   iFcb->ClusterSize);
//			}else{
//				FileSectorOver= 1;			/* Over Error 060128 */
//			}
			iFcb->CurrentData += datasize;
			return dsize;
		}

		if (csize != 0) {
			rw_buff= (unsigned char *)&writeBuff[0];
			sectno = CnvSectorNumber (iFcb->CurrentCluster, iFcb->Drive);
			ReadCard (iFcb->Drive,	/* drive Number */
						   sectno,					/* sector number */
						   rw_buff,
						   iFcb->ClusterSize);
			memcpy(&rw_buff[offset],buff,csize);
			//�ŏI�Z�N�^�[�͏������݂��Ȃ�
//			if((System.xBpb[iFcb->Drive].Sectors2+System.xBpb[iFcb->Drive].Sectors) > sectno){
				WriteCard (iFcb->Drive,	/* drive Number */
					   sectno,					/* sector number */
					   rw_buff,
					   iFcb->ClusterSize);
//			}else{
//				FileSectorOver= 1;			/* Over Error 060128 */
//			}
			iFcb->CurrentData += csize;
			datasize -= csize;					/* remain data size */
			ubuff += csize;
		}
		offset = 0;
		csize = iFcb->ClusterSize;

		for (;;) {
			err = Extent_Cluster (iFcb);		/* get next cluster number */
			if (err != 0) return (dsize - datasize);	/*real write bytes 1997,8,8*/

			if (datasize <= csize) {
				sectno = CnvSectorNumber (iFcb->CurrentCluster, iFcb->Drive);
				//�ŏI�Z�N�^�[�͏������݂��Ȃ�
//				if((System.xBpb[iFcb->Drive].Sectors2+System.xBpb[iFcb->Drive].Sectors) > sectno){
					WriteCard (iFcb->Drive,	/* drive Number */
						   sectno,					/* sector number */
						   ubuff,
						   csize);
//				}else{
//					FileSectorOver= 1;			/* Over Error 060128 */
//				}
				iFcb->CurrentData += datasize;
				return dsize;
			}
	
//			if (iFcb->CurrentCluster == 0x7D4) {
//				i= iFcb->CurrentCluster;
//			}
			sectno = CnvSectorNumber (iFcb->CurrentCluster, iFcb->Drive);
			//�ŏI�Z�N�^�[�͏������݂��Ȃ�
//			if((System.xBpb[iFcb->Drive].Sectors2+System.xBpb[iFcb->Drive].Sectors) > sectno){
				WriteCard (iFcb->Drive,	/* drive Number */
					   sectno,					/* sector number */
					   ubuff,
					   csize);
//			}else{
//				FileSectorOver= 1;			/* Over Error 060128 */
//			}
			iFcb->CurrentData += csize;
			datasize -= csize;					/* remain data size */
			ubuff += csize;
		}

}



/********************************************************
* Load directory information to FCB channel Table		*
********************************************************/
int	memcmpNull (char *src, char *obj, int cnt)
{
	int		i;

	for(i = 0; i < cnt; i++){
		if((obj[i] == 0) && (src[i] == ' ')){
			continue;
		}
		if(obj[i] != src[i]){
			break;
		}
	}
	if(i == cnt){
		return(0);
	}else{
		return(-1);
	}
}
//20100318
void	SetLnNameChild(void)
{
	int		i;

	DosFileName[7]++;
	if(DosFileName[7] > '9'){
		DosFileName[7]= 1;
		for(i= 5; i >= 0; i--){ 
			DosFileName[i]++;
			if(DosFileName[i] < 'Z'){
				break;
			}else{
				DosFileName[i]= 'A';
			}
		}
	}
}
BOOL	LoadDirectory (IFCB *iFcb, char *DirName, BOOL mode)
{
	int		i, j, nLen, DirCount, offset, drive;
	BYTE	FileName[12];
//	char	*DirwBuff;
	int		NameCnt= 0;


		memset (FileName, ' ', 11);
		FileName[11]= 0;
/*		memset (FileName, 0, 11);*/
		memset(DosFileName,0,sizeof(DosFileName));
		nLen = strlen (DirName);
		if((nLen == 2) && (DirName[0] == '.') && (DirName[1] == '.')){
			strncpy((char*)FileName,DirName,2);
		}else{
//			for (i=j=0; i<nLen; i++) {
//				if (DirName[i] == '.') {
//					if (DirName[i+1] == 0) break;
//					FileName[8] = DirName[i+1];
//					if (DirName[i+2] == 0) break;
//					FileName[9] = DirName[i+2];
//					if (DirName[i+3] == 0) break;
//					FileName[10] = DirName[i+3];
//					break;
//				}
//				FileName[j] = DirName[i];
//				j++;
//			}
			SetFileName2LnfName(DirName);		//20091116
			strcpy((char*)FileName,DosFileName);		//20091116
//20100318 Del			if(DosFileName[6] != ' '){	DosFileName[6]= '~';	DosFileName[7]= '1';	}
		}
		drive = iFcb->Drive;
		iFcb->DirMode = mode;
		memset(loadFileName,0,sizeof(loadFileName));
		if (mode) {											/* Root Directory */
			iFcb->CurrentDirCluster = iFcb->StartDirCluster;
			DirCount = (long)DevInf[drive].xBpb.SectorPerBytes / 32;
			iFcb->CurrentDir = 0;							/* Directory number */
			iFcb->LongStartDir= 0;								//20100319
			iFcb->LongCurrentCluster= iFcb->CurrentDirCluster;	//20100319
			offset = 0;
			NameCnt= 0;
			for (i=j=0; i<DevInf[drive].xBpb.Dirs; i++) {
				Read_Dir ((BYTE*)&(iFcb->CurrentDirBlock), iFcb->Drive, 
								iFcb->CurrentDirCluster, offset, 32);
				if((iFcb->CurrentDirBlock.Name[0] != 0xe5) && (iFcb->CurrentDirBlock.Name[0] != 0)){
					if (iFcb->CurrentDirBlock.Attributes != 0x0f) {
						if(NameCnt == 0){			//8.3 Dir
							if(LNFRecCnt == 0){		//20091116
								if (memcmp (FileName, &(iFcb->CurrentDirBlock), 11) == 0){
									return TRUE;
								}
							}
						}else{
							if(LNFRecCnt != 0){		//20091116
								SetFileName(loadFileName,NameCnt);
								//20100318 Check Change
								if (strcmp (srcFileName, loadFileName) == 0){
									memcpy(DosFileName, &(iFcb->CurrentDirBlock), 8);
									return TRUE;
								}
								//Dos Name Check 20100318
								if(iFcb->CurrentDirBlock.Name[6] == '~'){
									if (memcmp (DosFileName, &(iFcb->CurrentDirBlock.Name), 8) == 0){
										SetLnNameChild();	//20100318
									}
								}
							}
						}
						NameCnt= 0;
						memset(loadFileName,0,sizeof(loadFileName));
					}else{
						if(NameCnt == 0){									//20100319
							iFcb->LongStartDir= iFcb->CurrentDir;			//20100319
							iFcb->LongCurrentCluster= iFcb->CurrentDirCluster;	//20100319
						}													//20100319
						GetLnfFileName((LNFEntry*)&iFcb->CurrentDirBlock,&NameCnt,loadFileName);
					}
				}else{		//20100330
					NameCnt= 0;
					memset(loadFileName,0,sizeof(loadFileName));
				}
				if (iFcb->CurrentDirBlock.Name[0] == 0){
					break;	/* end of directory */
				}
				offset += 32;
				(iFcb->CurrentDir)++;						/* Directory number */
				j++;
				if (j == DirCount) {
					(iFcb->CurrentDirCluster)++;
					j = offset = 0;
				}
			}
			return FALSE;
		}
		else {									/* sub directory entry */
			iFcb->StartDirCluster = iFcb->CurrentCluster;
			iFcb->CurrentDirCluster = iFcb->StartDirCluster;
			DirCount = (long)DevInf[drive].xBpb.SectorPerBytes *
					   (long)DevInf[drive].xBpb.ClusterPerSectors / 32;
/*9,11		totalDir = iFcb->FileSize  >> 5;*/
			iFcb->CurrentDir = 0;					/* Directory number */
			iFcb->LongStartDir= 0;								//20100319
			iFcb->LongCurrentCluster= iFcb->CurrentDirCluster;	//20100319
			NameCnt= 0;						//20091116
			for (;;) {
				offset = 0;
				for (i=0; i<DirCount; i++) {
/*					Read_Data ((BYTE*)&(iFcb->CurrentDirBlock), iFcb->Drive, */
					/* 051220 */
					Read_Data_Dir ((BYTE*)&(iFcb->CurrentDirBlock), iFcb->Drive, 
									iFcb->CurrentDirCluster, offset, 32);
//DirwBuff= (char*)&(iFcb->CurrentDirBlock);
/*					DirectryChange((DIR *)&(iFcb->CurrentDirBlock), (DIR *)&(iFcb->CurrentDirBlock));*/		/* 99.12.2 */
/*					if (memcmp (FileName, &(iFcb->CurrentDirBlock), 11) == 0) return TRUE;*/
					if((iFcb->CurrentDirBlock.Name[0] != 0xe5) && (iFcb->CurrentDirBlock.Name[0] != 0)){
						if ((iFcb->CurrentDirBlock.Attributes != 0x0f) ||
							((iFcb->CurrentDirBlock.Name[0] == '.') && (iFcb->CurrentDirBlock.Name[1] == '.'))){
							if(NameCnt == 0){			//8.3 Dir
								if(LNFRecCnt == 0){		//20091116
									if (memcmpNull ((char *)FileName, (char *)&(iFcb->CurrentDirBlock), 11) == 0){
										return TRUE;
									}
								}
							}else{
								if(LNFRecCnt != 0){		//20091116
									SetFileName(loadFileName,NameCnt);
									//20100318 Check Change
									if (strcmp (srcFileName, loadFileName) == 0){
										memcpy(DosFileName, &(iFcb->CurrentDirBlock), 8);
										return TRUE;
									}
									//Dos Name Check 20100318
									if(iFcb->CurrentDirBlock.Name[6] == '~'){
										if (memcmp (DosFileName, &(iFcb->CurrentDirBlock.Name), 8) == 0){
											SetLnNameChild();	//20100318
										}
									}
								}
							}
							NameCnt= 0;
							memset(loadFileName,0,sizeof(loadFileName));
						}else{
							if(NameCnt == 0){									//20100319
								iFcb->LongStartDir= iFcb->CurrentDir;			//20100319
								iFcb->LongCurrentCluster= iFcb->CurrentDirCluster;	//20100319
							}													//20100319
							GetLnfFileName((LNFEntry*)&iFcb->CurrentDirBlock,&NameCnt,loadFileName);
						}
					}else{			//20100330
						NameCnt= 0;
						memset(loadFileName,0,sizeof(loadFileName));
					}
					offset += 32;
					(iFcb->CurrentDir)++;			/* Directory number */
/*9,11				if (iFcb->CurrentDir >= totalDir) return FALSE;*/
				}
				if (Get_NextCluster (iFcb) != 0){
					return FALSE;
				}
				if( ((unsigned long)iFcb->CurrentCluster == (unsigned long)0xFFFFFFF8) ||
					((unsigned long)iFcb->CurrentCluster == (unsigned long)0xFFFFFFFF) ||
					((unsigned long)iFcb->CurrentCluster == (unsigned long)0x0FFFFFF8) ||
					((unsigned long)iFcb->CurrentCluster == (unsigned long)0x0FFFFFFF)){
					return FALSE;
				}
				iFcb->CurrentDirCluster = iFcb->CurrentCluster;
			}
		}

}


/********************************************************
* Create Directory Entry and FAT entry					*
********************************************************/
void	SaveLnfDir(IFCB *iFcb,int offset,int DirCount,int j)
{
	int	i;
	int	sum;

	sum= shortNameCheckCode((unsigned char*)&DosFileName[0]);
	for(i= 0; i < LNFRecCnt; i++){
		LNFFileName[LNFRecCnt-i-1].checkCodeForShortName= sum;
		memcpy(&(iFcb->CurrentDirBlock),&LNFFileName[LNFRecCnt-i-1],32);
		Write_Dir ((BYTE*)&(iFcb->CurrentDirBlock), iFcb->Drive, 
				iFcb->CurrentDirCluster, offset);
		offset += 32;
		(iFcb->CurrentDir)++;			/* Directory number */
		j++;
		if (j == DirCount) {
			(iFcb->CurrentDirCluster)++;
			j = 0;						/* 1997,6,24*/
			offset = 0;
		}
	}
}
BOOL	CreateDirectory (IFCB *iFcb, char *DirName, int drive)
{
//	int		i, j, nLen, DirCount, offset, StartCluster;
	int		i, j, DirCount, offset, StartCluster;
	BYTE	FileName[12];
	int		nameCnt;
	IFCB	sFcb;
	int		soffset;
	int		sDirCount;
	int		sj;

//		memset (FileName, ' ', 11);
//		nLen = strlen (DirName);
//		for (i=j=0; i<nLen; i++) {
//			if (DirName[i] == '.') {
//				if (DirName[i+1] == 0) break;
//				FileName[8] = DirName[i+1];
//				if (DirName[i+2] == 0) break;
//				FileName[9] = DirName[i+2];
//				if (DirName[i+3] == 0) break;
//				FileName[10] = DirName[i+3];
//				break;
//			}
//			FileName[j] = DirName[i];
//			j++;
//		}
	strcpy((char*)FileName,DosFileName);

		drive = iFcb->Drive;
		iFcb->DirMode = TRUE;
		iFcb->CurrentDirCluster = iFcb->StartDirCluster;
		DirCount = (long)DevInf[drive].xBpb.SectorPerBytes / 32;
		iFcb->CurrentDir = 0;					/* Directory number */
		iFcb->LongStartDir= 0;								//20100319
		iFcb->LongCurrentCluster= iFcb->CurrentDirCluster;	//20100319
		offset = 0;
		nameCnt= 0;
		for (i=j=0; i<DevInf[drive].xBpb.Dirs; i++) {
			Read_Dir ((BYTE*)&(iFcb->CurrentDirBlock), iFcb->Drive, 
							iFcb->CurrentDirCluster, offset, 32);
			if ((iFcb->CurrentDirBlock.Name[0] == 0) || ((BYTE)iFcb->CurrentDirBlock.Name[0] == 0xE5)) {
				if(LNFRecCnt != 0){
					if(nameCnt == 0){	//Save Fcb
						memcpy(&sFcb,iFcb,sizeof(IFCB));
						soffset= offset;
						sDirCount= DirCount;
						sj= j;
						iFcb->LongStartDir= iFcb->CurrentDir;				//20100319
						iFcb->LongCurrentCluster= iFcb->CurrentDirCluster;	//20100319
					}
					nameCnt++;
					if(nameCnt < (LNFRecCnt+1)){
						offset += 32;
						(iFcb->CurrentDir)++;			/* Directory number */
						j++;
						if (j == DirCount) {
							(iFcb->CurrentDirCluster)++;
							j = 0;						/* 1997,6,24*/
							offset = 0;
						}
						continue;
					}
					SaveLnfDir(&sFcb,soffset,sDirCount,sj);
					strcpy((char*)FileName,DosFileName);
				}
				memcpy (iFcb->CurrentDirBlock.Name, FileName, 11);	/* File Name */
				iFcb->CurrentDirBlock.Attributes = 0;			/* File Attributes */
				iFcb->CurrentDirBlock.Time = GetCurrentTime();	/* Create time */
				iFcb->CurrentDirBlock.Date = GetCurrentDate();	/* Create Date */
				iFcb->CurrentDirBlock.dummy = DosNameKind;		//20091116 add
				iFcb->CurrentDirBlock.msTime= 0;
				iFcb->CurrentDirBlock.VfatTime= (unsigned short)iFcb->CurrentDirBlock.Time;
				iFcb->CurrentDirBlock.VfatDate= (unsigned short)iFcb->CurrentDirBlock.Date;
				iFcb->CurrentDirBlock.AcsDate= (unsigned short)iFcb->CurrentDirBlock.Date;
				if(DevInf[drive].xBpb.FatType == 32){
					StartCluster= GetNewCluster (iFcb->Drive);
					iFcb->CurrentDirBlock.StartClusterHigh= StartCluster/0x10000;
					iFcb->CurrentDirBlock.StartCluster = StartCluster%0x10000;
				}else{
					iFcb->CurrentDirBlock.StartClusterHigh= 0;
																	/* Start Cluster number */
					iFcb->CurrentDirBlock.StartCluster = GetNewCluster (iFcb->Drive);
				}
				if ((iFcb->CurrentDirBlock.StartCluster == 0) &&
				    (iFcb->CurrentDirBlock.StartClusterHigh == 0)){
					return FALSE;
				}
//				SetFAT (iFcb->CurrentDirBlock.StartCluster, 0xFFFFFFF8L, iFcb->Drive);
				SetFAT (iFcb->CurrentDirBlock.StartCluster, 0x0FFFFFFFL, iFcb->Drive);
				iFcb->CurrentDirBlock.FileSize = 0;				/* File Size */
				Write_Dir ((BYTE*)&(iFcb->CurrentDirBlock), iFcb->Drive, 
							iFcb->CurrentDirCluster, offset);
				return TRUE;
			}
			nameCnt= 0;			//20091116
			offset += 32;
			(iFcb->CurrentDir)++;			/* Directory number */
			j++;
			if (j == DirCount) {
				(iFcb->CurrentDirCluster)++;
				j = 0;						/* 1997,6,24*/
				offset = 0;
			}
		}
		return FALSE;
}



/****************************************************
*  Read Data										*
****************************************************/

BOOL	Read_Data (BYTE *buff, int drive, long Cluster, int offset, int dsize)
{
	int		bufferNo;
		
		bufferNo = SearchCluster (drive, Cluster, 0);
		if (bufferNo == -1) {			/* not found current buffer */
			bufferNo = AllocateClusterBuffer (drive);
			DevInf[drive].sysBuff[bufferNo].Cluster = Cluster;
			DevInf[drive].sysBuff[bufferNo].Drive = drive;
			DevInf[drive].sysBuff[bufferNo].Mode = 0;
			WaitForReadEnd (drive,bufferNo);
		}

		DevInf[drive].sysBuff[bufferNo].Mode = 0;
		DevInf[drive].sysBuff[bufferNo].Status |= READ_DATA;
		memcpy (buff, DevInf[drive].sysBuff[bufferNo].pt + offset, dsize);
		return TRUE;
}

BOOL	Read_Data_Dir (BYTE *buff, int drive, long Cluster, int offset, int dsize)
{
	int		bufferNo;
		
		bufferNo = SearchCluster (drive, Cluster, 0);
		if (bufferNo == -1) {			/* not found current buffer */
			bufferNo = AllocateClusterBuffer (drive);
			DevInf[drive].sysBuff[bufferNo].Cluster = Cluster;
			DevInf[drive].sysBuff[bufferNo].Drive = drive;
			DevInf[drive].sysBuff[bufferNo].Mode = 0;
			WaitForReadEnd (drive,bufferNo);
		}

		DevInf[drive].sysBuff[bufferNo].Mode = 0;
		DevInf[drive].sysBuff[bufferNo].Status |= (READ_SYSTEM | READ_DATA);
		memcpy (buff, DevInf[drive].sysBuff[bufferNo].pt + offset, dsize);
		return TRUE;
}

/****************************************************
*  Write Data										*
*	mode:	TRUE	override mode					*
*			FALSE	create mode						*
****************************************************/

BOOL	Write_Data (BOOL mode, BYTE *buff, int drive, long Cluster, int offset, int dsize)
{
	int		bufferNo;
		
		bufferNo = SearchCluster (drive, Cluster, 0);
		if (bufferNo == -1) {			/* not found current buffer */
			bufferNo = AllocateClusterBuffer (drive);
			DevInf[drive].sysBuff[bufferNo].Cluster = Cluster;
			DevInf[drive].sysBuff[bufferNo].Drive = drive;
			DevInf[drive].sysBuff[bufferNo].Mode = 0;
			if (mode) {
				WaitForReadEnd (drive,bufferNo);
			}
			DevInf[drive].sysBuff[bufferNo].WriteSequence = ERASE_REQUEST;
			WriteIoRequest (drive);
		}

		if (DevInf[drive].sysBuff[bufferNo].WriteSequence & WRITE_REQUEST) {
			DevInf[drive].sysBuff[bufferNo].WriteSequence &= (~WRITE_REQUEST);
		}

		if (!(DevInf[drive].sysBuff[bufferNo].WriteSequence & ERASE)) {
			DevInf[drive].sysBuff[bufferNo].WriteSequence = ERASE_REQUEST;
			WriteIoRequest (drive);
		}
		DevInf[drive].sysBuff[bufferNo].Mode = 0;
		DevInf[drive].sysBuff[bufferNo].Status |= WRITE_DATA;
		memcpy (DevInf[drive].sysBuff[bufferNo].pt + offset, buff, dsize);
		return TRUE;
}

BOOL	Write_Data_Dir (BOOL mode, BYTE *buff, int drive, long Cluster, int offset, int dsize)
{
	int		bufferNo;
		
		bufferNo = SearchCluster (drive, Cluster, 0);
		if (bufferNo == -1) {			/* not found current buffer */
			bufferNo = AllocateClusterBuffer (drive);
			DevInf[drive].sysBuff[bufferNo].Cluster = Cluster;
			DevInf[drive].sysBuff[bufferNo].Drive = drive;
			DevInf[drive].sysBuff[bufferNo].Mode = 0;
			if (mode) {
				WaitForReadEnd (drive,bufferNo);
			}
			DevInf[drive].sysBuff[bufferNo].WriteSequence = ERASE_REQUEST;
			WriteIoRequest (drive);
		}

		if (DevInf[drive].sysBuff[bufferNo].WriteSequence & WRITE_REQUEST) {
			DevInf[drive].sysBuff[bufferNo].WriteSequence &= (~WRITE_REQUEST);
		}

		if (!(DevInf[drive].sysBuff[bufferNo].WriteSequence & ERASE)) {
			DevInf[drive].sysBuff[bufferNo].WriteSequence = ERASE_REQUEST;
			WriteIoRequest (drive);
		}
		DevInf[drive].sysBuff[bufferNo].Mode = 0;					//V2138
		DevInf[drive].sysBuff[bufferNo].Status |= WRITE_SYSTEM;	//V2138 WRITE_SYSTEM��t��
		memcpy (DevInf[drive].sysBuff[bufferNo].pt + offset, buff, dsize);
		return TRUE;
}

/****************************************************
*  Read System area									*
****************************************************/

BOOL	Read_System (BYTE *buff, int drive, long Cluster, int offset, int dsize)
{
	int		bufferNo;
		
		bufferNo = SearchCluster (drive, Cluster, 0);
		if (bufferNo == -1) {			/* not found current buffer */
			bufferNo = AllocateClusterBuffer (drive);
			DevInf[drive].sysBuff[bufferNo].Cluster = Cluster;
			DevInf[drive].sysBuff[bufferNo].Drive = drive;
			DevInf[drive].sysBuff[bufferNo].Mode = 0;
			WaitForReadEnd (drive,bufferNo);
		}

		DevInf[drive].sysBuff[bufferNo].Mode = 0;
		DevInf[drive].sysBuff[bufferNo].Status |= READ_SYSTEM;
		memcpy (buff, DevInf[drive].sysBuff[bufferNo].pt + offset, dsize);
		return TRUE;
}


/****************************************************
*  Write System area								*
****************************************************/

BOOL	Write_System (BYTE *buff, int drive, long Cluster, int offset, int dsize)
{
	int		bufferNo;
		
		bufferNo = SearchCluster (drive, Cluster, 0);
		if (bufferNo == -1) {			/* not found current buffer */
			bufferNo = AllocateClusterBuffer (drive);
			DevInf[drive].sysBuff[bufferNo].Cluster = Cluster;
			DevInf[drive].sysBuff[bufferNo].Drive = drive;
			DevInf[drive].sysBuff[bufferNo].Mode = 0;
			WaitForReadEnd (drive,bufferNo);
			DevInf[drive].sysBuff[bufferNo].WriteSequence = ERASE_REQUEST;
			WriteIoRequest (drive);
		}

		if (DevInf[drive].sysBuff[bufferNo].WriteSequence & WRITE_REQUEST) {
			DevInf[drive].sysBuff[bufferNo].WriteSequence &= (~WRITE_REQUEST);
		}

		if (!(DevInf[drive].sysBuff[bufferNo].WriteSequence & ERASE)) {
			DevInf[drive].sysBuff[bufferNo].WriteSequence = ERASE_REQUEST;
			WriteIoRequest (drive);
		}
		DevInf[drive].sysBuff[bufferNo].Mode = 0;
		DevInf[drive].sysBuff[bufferNo].Status |= WRITE_SYSTEM;
		memcpy (DevInf[drive].sysBuff[bufferNo].pt + offset, buff, dsize);
		return TRUE;
}


/****************************************************
*  Read Root Dir Sector								*
****************************************************/

BOOL	Read_Dir (BYTE *buff, int drive, long Cluster, int offset, int dsize)
{
	int		bufferNo;
		
		bufferNo = SearchCluster (drive, Cluster, 1);
		if (bufferNo == -1) {			/* not found current buffer */
			bufferNo = AllocateClusterBuffer (drive);
			DevInf[drive].sysBuff[bufferNo].Cluster = Cluster;
			DevInf[drive].sysBuff[bufferNo].Drive = drive;
			DevInf[drive].sysBuff[bufferNo].Mode = 1;
			WaitForReadEnd (drive,bufferNo);
		}

		DevInf[drive].sysBuff[bufferNo].Mode = 1;
		DevInf[drive].sysBuff[bufferNo].Status |= READ_SYSTEM;
		memcpy (buff, DevInf[drive].sysBuff[bufferNo].pt + offset, dsize);
		return TRUE;
}


/****************************************************
*  Write Root Directory sector						*
****************************************************/
BOOL	Write_Dir (BYTE *buff, int drive, long Cluster, int offset)
{
	int		bufferNo;

		bufferNo = SearchCluster (drive, Cluster, 1);
		if (bufferNo == -1) {			/* not found current buffer */
			bufferNo = AllocateClusterBuffer (drive);
			DevInf[drive].sysBuff[bufferNo].Cluster = Cluster;
			DevInf[drive].sysBuff[bufferNo].Drive = drive;
			DevInf[drive].sysBuff[bufferNo].Mode = 1;
			WaitForReadEnd (drive,bufferNo);
			DevInf[drive].sysBuff[bufferNo].WriteSequence = ERASE_REQUEST;
			WriteIoRequest (drive);
		}

		if (DevInf[drive].sysBuff[bufferNo].WriteSequence & WRITE_REQUEST) {
			DevInf[drive].sysBuff[bufferNo].WriteSequence &= (~WRITE_REQUEST);
		}

		if (!(DevInf[drive].sysBuff[bufferNo].WriteSequence & ERASE)) {
			DevInf[drive].sysBuff[bufferNo].WriteSequence = ERASE_REQUEST;
			WriteIoRequest (drive);
		}
		DevInf[drive].sysBuff[bufferNo].Mode = 1;
		DevInf[drive].sysBuff[bufferNo].Status |= WRITE_SYSTEM;
		memcpy (DevInf[drive].sysBuff[bufferNo].pt + offset, buff, 32);
		return TRUE;
}


/****************************************************
*  Search Cluster data buffer						*
****************************************************/

int		SearchCluster (int drive, long Cluster, int mode)
{
	int		bufferNo;

		for (bufferNo=0; bufferNo<DevInf[drive].MaxBuffers; bufferNo++) {
			if ((DevInf[drive].sysBuff[bufferNo].Cluster == Cluster) &&
				(DevInf[drive].sysBuff[bufferNo].Drive == drive) &&
				(DevInf[drive].sysBuff[bufferNo].Mode == mode) &&
				(DevInf[drive].sysBuff[bufferNo].Status & USED)) return bufferNo;
		}
		return -1;		/* not found, requested cluster */
}


/****************************************************
* Allocate cluster buffer							*
****************************************************/

int		AllocateClusterBuffer (int drive)
{
	int		i, j;
	BOOL	isw;

/* Search Free buffer-control */
	/* 1st Priority */
		for (i=0; i<DevInf[drive].MaxBuffers; i++) {
			if (DevInf[drive].sysBuff[i].Status == 0) {
				DevInf[drive].sysBuff[i].Status = USED;	/* buffer used status & priority */
				DevInf[drive].sysBuff[i].Drive = drive;	/* drive number */
				DevInf[drive].sysBuff[i].Cluster = -1;	/* cluster number */
				DevInf[drive].sysBuff[i].FatMode = 0;		/* not FAT sector */
				return i;					/* buffer number */
			}
		}

	/* 2nd Priority */		
		i = DevInf[drive].AllocPointer;
		for (j=0; j<DevInf[drive].MaxBuffers; j++) {
			i++;
			if (i == DevInf[drive].MaxBuffers) i = 0;
			if (DevInf[drive].sysBuff[i].Status == (READ_DATA)) {
				DevInf[drive].sysBuff[i].Status = USED;	/* buffer used status & priority */
				DevInf[drive].sysBuff[i].Drive = drive;	/* drive number */
				DevInf[drive].sysBuff[i].Cluster = -1;	/* cluster number */
				DevInf[drive].sysBuff[i].FatMode = 0;		/* not FAT sector */
				DevInf[drive].AllocPointer = i;	/* save next search pointer */
				return i;					/* buffer number */
			}
		}

	/* 3rd Priority */
		for (j=0, i=DevInf[drive].AllocPointer; j<DevInf[drive].MaxBuffers; j++) {
			i++;
			if (i == DevInf[drive].MaxBuffers) i = 0;
			if (DevInf[drive].sysBuff[i].Status == (READ_SYSTEM)) {
				DevInf[drive].sysBuff[i].Status = USED;	/* buffer used status & priority */
				DevInf[drive].sysBuff[i].Drive = drive;	/* drive number */
				DevInf[drive].sysBuff[i].Cluster = -1;	/* Cluster number */
				DevInf[drive].sysBuff[i].FatMode = 0;		/* not FAT sector */
				DevInf[drive].AllocPointer = i;	/* save next search pointer */
				return i;					/* buffer number */
			}
		}

	/* 3.5rd Priority */
		for (j=0, i=DevInf[drive].AllocPointer; j<DevInf[drive].MaxBuffers; j++) {
			i++;
			if (i == DevInf[drive].MaxBuffers) i = 0;
			if (DevInf[drive].sysBuff[i].Status == (READ_SYSTEM | READ_DATA)) {
				DevInf[drive].sysBuff[i].Status = USED;	/* buffer used status & priority */
				DevInf[drive].sysBuff[i].Drive = drive;	/* drive number */
				DevInf[drive].sysBuff[i].Cluster = -1;	/* Cluster number */
				DevInf[drive].sysBuff[i].FatMode = 0;		/* not FAT sector */
				DevInf[drive].AllocPointer = i;	/* save next search pointer */
				return i;					/* buffer number */
			}
		}

	/* 4th Priority */
		isw = TRUE;
		for (j=0, i=DevInf[drive].AllocPointer; j<DevInf[drive].MaxBuffers; j++) {
			i++;
			if (i == DevInf[drive].MaxBuffers) i = 0;
			if (DevInf[drive].sysBuff[i].Status == (WRITE_DATA)) {
				DevInf[drive].sysBuff[i].WriteSequence |= WRITE_REQUEST;
				isw = FALSE;
				break;
			}
		}

	/* 5th Priority */
		if (isw) {
			for (j=0, i=DevInf[drive].AllocPointer; j<DevInf[drive].MaxBuffers; j++) {
				i++;
				if (i == DevInf[drive].MaxBuffers) i = 0;
				if (DevInf[drive].sysBuff[i].Status == (WRITE_SYSTEM)) {
					DevInf[drive].sysBuff[i].WriteSequence |= WRITE_REQUEST;
					break;
				}
			}
		}

	/* Wait for buffer ready */
		WaitForAnyBufferReady (drive);
		for (j=0, i=DevInf[drive].AllocPointer; j<DevInf[drive].MaxBuffers; j++) {
			i++;
			if (i == DevInf[drive].MaxBuffers) i = 0;
			if (DevInf[drive].sysBuff[i].Status == (READ_DATA)) {
				DevInf[drive].sysBuff[i].Status = USED;	/* buffer used status & priority */
				DevInf[drive].sysBuff[i].Drive = drive;	/* drive number */
				DevInf[drive].sysBuff[i].Cluster = -1;	/* cluster number */
				DevInf[drive].sysBuff[i].FatMode = 0;		/* not FAT sector */
				DevInf[drive].AllocPointer = i;	/* save next search pointer */
				return i;					/* buffer number */
			}
		}
		
		for (j=0, i=DevInf[drive].AllocPointer; j<DevInf[drive].MaxBuffers; j++) {
			i++;
			if (i == DevInf[drive].MaxBuffers) i = 0;
			if (DevInf[drive].sysBuff[i].Status == (READ_SYSTEM)) {
				DevInf[drive].sysBuff[i].Status = USED;	/* buffer used status & priority */
				DevInf[drive].sysBuff[i].Drive = drive;	/* drive number */
				DevInf[drive].sysBuff[i].Cluster = -1;	/* cluster number */
				DevInf[drive].sysBuff[i].FatMode = 0;		/* not FAT sector */
				DevInf[drive].AllocPointer = i;	/* save next search pointer */
				return i;					/* buffer number */
			}
		}

		return -1;				/* buffer full */
}


/****************************************************
*  Setup Internal FCB table value					*
****************************************************/

void	SetupFCB (IFCB *iFcb, int drive)
{

		iFcb->FileSize = iFcb->CurrentDirBlock.FileSize;	/* file size */
		iFcb->Drive = drive;
		if(DevInf[drive].xBpb.FatType == 32){
			iFcb->BeginCluster = (iFcb->CurrentDirBlock.StartClusterHigh << 16)+ iFcb->CurrentDirBlock.StartCluster;
		}else{
			iFcb->BeginCluster = iFcb->CurrentDirBlock.StartCluster;
		}
		iFcb->CurrentCluster = iFcb->BeginCluster;	/* Start of cluster number */

		iFcb->RelativeCluster = 0;			/* Current Releative cluster number */
		iFcb->ClusterSize = (long)DevInf[drive].xBpb.SectorPerBytes *
							(long)DevInf[drive].xBpb.ClusterPerSectors;
		iFcb->CurrentData = 0;				/* Current data pointer */
		iFcb->Access = 0;					/* access mode */
}


/****************************************************
*  Write FAT data									*
****************************************************/

void	SetFAT (int FATnumber, long FATdata, int drive)
{
	long	sect;
	int		n, offset;
	unsigned char bData;

	n= 0;
		if (FATnumber < 2) return;				/* illegal cluster number */
		switch (DevInf[drive].xBpb.FatType) {
			
		case 12:	offset = FATnumber + (FATnumber >> 1);
					sect = offset / DevInf[drive].xBpb.SectorPerBytes;
					n = SearchFATbuffer (sect, drive);
					offset = offset % DevInf[drive].xBpb.SectorPerBytes;
					if (FATnumber & 1) {
						bData = (BYTE)((DevInf[drive].sysBuff[n].pt[offset] & 0x0F) + ((FATdata & 0x0F) << 4));
						DevInf[drive].sysBuff[n].pt[offset++] = bData;
						if (offset == DevInf[drive].xBpb.SectorPerBytes) {
							offset = 0;
							sect++;
							DevInf[drive].sysBuff[n].Status |= WRITE_SYSTEM;
							n = SearchFATbuffer (sect, drive);
						}
						DevInf[drive].sysBuff[n].Status |= WRITE_SYSTEM;
						DevInf[drive].sysBuff[n].pt[offset] = (BYTE)((FATdata >> 4) & 0xFF);
					}
					else {
						DevInf[drive].sysBuff[n].pt[offset++] = (BYTE)(FATdata & 0xFF);
						if (offset == DevInf[drive].xBpb.SectorPerBytes) {
							offset = 0;
							sect++;
							DevInf[drive].sysBuff[n].Status |= WRITE_SYSTEM;
							n = SearchFATbuffer (sect, drive);
						}
						DevInf[drive].sysBuff[n].Status |= WRITE_SYSTEM;
						bData = (BYTE)((DevInf[drive].sysBuff[n].pt[offset] & 0xF0) + ((FATdata >> 8) & 0x0F));
						DevInf[drive].sysBuff[n].pt[offset] = bData;
					}
					break;

		case 16:	offset = (FATnumber << 1);
					sect = offset / DevInf[drive].xBpb.SectorPerBytes;
					n = SearchFATbuffer (sect, drive);
					offset = offset % DevInf[drive].xBpb.SectorPerBytes;
					DevInf[drive].sysBuff[n].Status |= WRITE_SYSTEM;
					DevInf[drive].sysBuff[n].pt[offset++] = (BYTE)(FATdata & 0xFF);
					DevInf[drive].sysBuff[n].pt[offset] = (BYTE)((FATdata >> 8) & 0xFF);
					break;

		case 32:	offset = (FATnumber << 2);
					sect = offset / DevInf[drive].xBpb.SectorPerBytes;
					n = SearchFATbuffer (sect, drive);
					offset = offset % DevInf[drive].xBpb.SectorPerBytes;
					DevInf[drive].sysBuff[n].Status |= WRITE_SYSTEM;
					DevInf[drive].sysBuff[n].pt[offset++] = (BYTE)(FATdata & 0xFF);
					DevInf[drive].sysBuff[n].pt[offset++] = (BYTE)((FATdata >> 8) & 0xFF);
					DevInf[drive].sysBuff[n].pt[offset++] = (BYTE)((FATdata >> 16) & 0xFF);
					DevInf[drive].sysBuff[n].pt[offset] = (BYTE)((FATdata >> 24) & 0xFF);
					break;
		}

		if (!(DevInf[drive].sysBuff[n].WriteSequence & ERASE)) {
			DevInf[drive].sysBuff[n].WriteSequence = ERASE_REQUEST;
			WriteIoRequest(drive);
		}
		return;
}

/****************************************************
*  Read FAT data									*
****************************************************/
int	tn;
int	tfat;
int	toffset;
long	GetFAT (int FATnumber, int drive)
{
	long	sect;
	unsigned int		n, offset, fat;
	BYTE	temp0, temp1;
	unsigned short	ufat;

	fat= 0;
		if (FATnumber < 2) return -1;
		switch (DevInf[drive].xBpb.FatType) {
			
		case 12:	offset = FATnumber + (FATnumber >> 1);
					sect = offset / DevInf[drive].xBpb.SectorPerBytes;
					n = SearchFATbuffer (sect, drive);
					offset = offset % DevInf[drive].xBpb.SectorPerBytes;
					temp0 = DevInf[drive].sysBuff[n].pt[offset++];
					if (offset == (unsigned int)DevInf[drive].xBpb.SectorPerBytes) {
						offset = 0;
						sect++;
						n = SearchFATbuffer (sect, drive);
					}
					temp1 = DevInf[drive].sysBuff[n].pt[offset];
					if (FATnumber & 1) {
						fat = ((int)temp1 << 4) + ((int)temp0 >> 4);
					}
					else {
						fat = (((int)temp1 << 8) + (int)temp0) & 0xFFF;
					}
					if (fat >= 0xFF8) fat += 0xFFFFF000;
					break;

		case 16:	offset = (FATnumber << 1);
					sect = offset / DevInf[drive].xBpb.SectorPerBytes;
					n = SearchFATbuffer (sect, drive);
					offset = offset % DevInf[drive].xBpb.SectorPerBytes;
					temp0 = DevInf[drive].sysBuff[n].pt[offset++];
					temp1 = DevInf[drive].sysBuff[n].pt[offset];
//V2142					fat = ((int)temp1 << 8) + (int)temp0;
					ufat = (((unsigned int)temp1 << 8) + temp0) & 0xffff;
					fat= ufat;
					if (fat >= 0xFFF8){
						fat += 0xFFFF0000;
					}
					tn = n;
					tfat = fat;
					toffset = offset;
					break;

		case 32:	offset = (FATnumber << 2);
					sect = offset / DevInf[drive].xBpb.SectorPerBytes;
					n = SearchFATbuffer (sect, drive);
					offset = offset % DevInf[drive].xBpb.SectorPerBytes;
					temp0 = DevInf[drive].sysBuff[n].pt[offset++];
					temp1 = DevInf[drive].sysBuff[n].pt[offset++];
					fat = ((unsigned int)temp1 << 8) + (unsigned int)temp0;
					temp0 = DevInf[drive].sysBuff[n].pt[offset++];
					temp1 = DevInf[drive].sysBuff[n].pt[offset];
//					fat = (fat << 16) + ((int)temp1 << 8) + (int)temp0);
					fat = fat + ((unsigned int)temp1 << 24) + ((unsigned int)temp0 << 16);
					break;
		}

		return fat;

}


/****************************************************
*  Search & Pre-Read FAT sector						*
****************************************************/

long	SearchFATbuffer (long sect, int drive)
{
	long	bufferNo, FATsect;

		FATsect = sect + DevInf[drive].xBpb.ReservedSectors;	/* reserved sectors */
		for (bufferNo=0; bufferNo<DevInf[drive].MaxBuffers; bufferNo++) {
			if ((DevInf[drive].sysBuff[bufferNo].Cluster == FATsect) &&
				(DevInf[drive].sysBuff[bufferNo].Drive == drive) &&
				(DevInf[drive].sysBuff[bufferNo].Status != 0) &&
				(DevInf[drive].sysBuff[bufferNo].Mode == 1)) return bufferNo;
		}

		bufferNo = AllocateClusterBuffer (drive);
		DevInf[drive].sysBuff[bufferNo].Cluster = FATsect;
		DevInf[drive].sysBuff[bufferNo].Mode = 1;
		DevInf[drive].sysBuff[bufferNo].FatMode = 1;
		WaitForReadEnd (drive,bufferNo);

		DevInf[drive].sysBuff[bufferNo].Mode = 1;			/* FAT sector mode */
		DevInf[drive].sysBuff[bufferNo].Status |= READ_SYSTEM;
		return bufferNo;					/* not found, requested cluster */
}


/****************************************************
*  Create New Cluster								*
****************************************************/
unsigned int	GetNewCluster (int drive)
{
//	int		NewCluster, i, cnt;
	int		NewCluster, i;
//	int		fat,work;
//	int		FatSector,idx,FATsect;
//	unsigned short *FatBuff;
//	unsigned short *FatBuffAddr;
//	unsigned char *FatBuffAddr12;
//	unsigned long *FatBuffAddr32;
//	long	sect;
//	int		offset;
//	char	temp0,temp1;
	int		nfat;
	int		maxCluster;

//		NewCluster = cnt = 0;						/* 1997,5,12 K.S */
		NewCluster = 0;						/* 1997,5,12 K.S */

		maxCluster = DevInf[drive].xBpb.MaxCluster;
//		FatSector= -1;
//		FatBuff= (unsigned short *)TakeMemory(0x10000);
		switch (DevInf[drive].xBpb.FatType) {
		case 12:
//			for (i=idx=0; i<maxCluster; i++) {
			for (i=0; i<maxCluster; i++) {
#ifdef	LD
				if((FatSector == -1) || (idx >= 0x10000)){
					offset = i + (i >> 1);
					sect = offset / DevInf[drive].xBpb.SectorPerBytes;
					FATsect = sect + DevInf[drive].xBpb.ReservedSectors;	/* reserved sectors */
					ReadCard (drive, FATsect, (unsigned char *)FatBuff, 0x10000);
					idx= 0;
					FatSector= FATsect;
					FatBuffAddr12= (unsigned char *)FatBuff;
				}
				if (i & 1) {
					temp0= *FatBuffAddr12++;
					temp1= *FatBuffAddr12++;
					idx+= 2;
					fat = ((int)temp1 << 4) + ((int)temp0 >> 4);
				}
				else {
					temp0= *FatBuffAddr12++;
					temp1= *FatBuffAddr12;
					idx++;
					fat = (((int)temp1 << 8) + (int)temp0) & 0xFFF;
				}
				if (fat == 0){
					//���ۂ�FAT���m�F����V2138
					nfat= GetFAT (i, drive);
					if(nfat == 0){
//						if (cnt == 0) {
							NewCluster = i;
//						}
//						cnt++;
//						if(cnt == DevInf[drive].xBpb.ClusterPerSectors){
							break;
//						}
//					}else{
//						cnt = 0;
					}
				}
//				else {
//					cnt = 0;
//				}
#else
				nfat= GetFAT (i, drive);
				if(nfat == 0){
					NewCluster = i;
					break;
				}
#endif
			}
			break;
		case 16:
//			for (i=idx=0; i<maxCluster; i++) {
			for (i=0; i<maxCluster; i++) {
#ifdef	OLD
				if((FatSector == -1) || (idx >= 0x8000)){
					offset = i << 1;
					sect = offset / DevInf[drive].xBpb.SectorPerBytes;
					FATsect = sect + DevInf[drive].xBpb.ReservedSectors;	/* reserved sectors */
					ReadCard (drive, FATsect, (unsigned char *)FatBuff, 0x10000);
					idx= 0;
					FatSector= FATsect;
					FatBuffAddr= FatBuff;
				}
				fat= *FatBuffAddr++;
				if (fat == 0) {
					//���ۂ�FAT���m�F����V2138
					nfat= GetFAT (i, drive);
					if(nfat == 0){
//						if (cnt == 0) {
							NewCluster = i;
//						}
//						cnt++;
//						if(cnt == DevInf[drive].xBpb.ClusterPerSectors){
							break;
//						}
//					}else{
//						cnt= 0;
					}
				}
//				else {
//					cnt = 0;
//				}
				idx++;
#else
				nfat= GetFAT (i, drive);
				if(nfat == 0){
					NewCluster = i;
					break;
				}
#endif
			}
			break;
		case 32:
//			for (i=idx=0; i<maxCluster; i++) {
			for (i=0; i<maxCluster; i++) {
#ifdef	OLD
				if((FatSector == -1) || (idx >= 0x4000)){
					offset = i << 1;
					sect = offset / DevInf[drive].xBpb.SectorPerBytes;
//					FATsect = sect + DevInf[drive].xBpb.ReservedSectors;	/* reserved sectors */
					FATsect = sect + DevInf[drive].xBpb.StartFat;
					ReadCard (drive, FATsect, (unsigned char *)FatBuff, 0x10000);
					idx= 0;
					FatSector= FATsect;
					FatBuffAddr32= (unsigned long *)FatBuff;
				}
				fat= *FatBuffAddr32++;
				if (fat == 0) {
					//���ۂ�FAT���m�F����V2138
					nfat= GetFAT (i, drive);
					if(nfat == 0){
//					if (cnt == 0) {
						NewCluster = i;
//					}
//					cnt++;
//					if(cnt == DevInf[drive].xBpb.ClusterPerSectors){
						break;
//					}
					}
				}
//				else {
//					cnt = 0;
//				}
				idx++;
#else
				nfat= GetFAT (i, drive);
				if(nfat == 0){
					NewCluster = i;
					break;
				}
#endif
			}
			break;
		}
//		FreeMail((char *)FatBuff);

//V2138		GetFAT (NewCluster, drive);

		return NewCluster;
}

/****************************************************
*  Read Cluster Data								*
****************************************************/

BOOL	Read_Cluster (int drive,int buffNo)
{
	int		sector;
	long	datasize;

//		drive = sysBuff[buffNo].Drive;	
		if (DevInf[drive].sysBuff[buffNo].Mode == 0) {
			sector = CnvSectorNumber (DevInf[drive].sysBuff[buffNo].Cluster, drive);
			datasize = (long)DevInf[drive].xBpb.SectorPerBytes
					 * (long)DevInf[drive].xBpb.ClusterPerSectors;
			ReadCard (drive, sector, DevInf[drive].sysBuff[buffNo].pt, datasize);
		}
		else {
			ReadCard (drive, DevInf[drive].sysBuff[buffNo].Cluster, DevInf[drive].sysBuff[buffNo].pt, DevInf[drive].xBpb.SectorPerBytes);
		}
		return TRUE;
}


/****************************************************
*  Write Cluster									*
****************************************************/

BOOL	Write_Cluster (int drive, int buffNo)
{
	long	sectno, datasize;
//	int		drive;

//		drive = sysBuff[buffNo].Drive;
		if (DevInf[drive].sysBuff[buffNo].Mode == 0) {
			sectno = CnvSectorNumber (DevInf[drive].sysBuff[buffNo].Cluster, drive);
			datasize = (long)DevInf[drive].xBpb.SectorPerBytes
					 * (long)DevInf[drive].xBpb.ClusterPerSectors;
		}
		else {
			sectno = DevInf[drive].sysBuff[buffNo].Cluster;
			datasize = (long)DevInf[drive].xBpb.SectorPerBytes;
		}
		//�ŏI�Z�N�^�[�͏������݂��Ȃ�
//		if((System.xBpb[sysBuff[buffNo].Drive].Sectors2+System.xBpb[sysBuff[buffNo].Drive].Sectors) > sectno){
			WriteCard (DevInf[drive].sysBuff[buffNo].Drive,	/* drive Number */
				   sectno,					/* sector number */
				   DevInf[drive].sysBuff[buffNo].pt,
				   datasize);
//		}else{
//			FileSectorOver= 1;			/* Over Error 060128 */
//		}

		return TRUE;
}


/****************************************************
* convert Cluster Number to Sector Number			*
****************************************************/
//�f�[�^�̈�̐擪���v�Z����B
long	CnvSectorNumber (long Cluster, int drive)
{
	return (Cluster * (long)DevInf[drive].xBpb.ClusterPerSectors)
			+ DevInf[drive].xBpb.ClusterOffset;
}


/****************************************************
*  flush All buffer									*
****************************************************/

int		FlushAll (int drive)
{
	int		i;

		for (i=0; i<DevInf[drive].MaxBuffers; i++) {
			if ((DevInf[drive].sysBuff[i].Drive == drive) && (DevInf[drive].sysBuff[i].Status & WRITE)) {
				DevInf[drive].sysBuff[i].WriteSequence |= WRITE_REQUEST;
			}
		}
		
		for (;;) {
			WriteIoRequest (drive);
			if (!DevInf[drive].WriteBusy) break;
			WaitForAnyBufferReady (drive);
		}

		return 0;
}


/****************************************************
* Wait for Write Buffer Read (real write end)		*
****************************************************/

void	WaitForAnyBufferReady (int drive)
{
		for (;;) {
			if (WriteIoRequest(drive)) return;
		}
}


/****************************************************
*  Wait for Read End								*
****************************************************/

void WaitForReadEnd (int drive,int bufferNo)
{
	if(bufferNo == -1){
		return;
	}
		DevInf[drive].sysBuff[bufferNo].WriteSequence = READ_REQUEST;
		for (;;) {
			WriteIoRequest (drive);
			if (DevInf[drive].sysBuff[bufferNo].WriteSequence == 0) return;
		}

}


/****************************************************
* Test For Flush End								*
****************************************************/

BOOL	WriteIoRequest (int drive)
{
	int		i, j, buffNo;
	long	sectno, sects;
	BOOL	ret;
	int		Flag;

		Flag = 0;			/* 00.03.09 */
		ret = FALSE;
		if (DevInf[drive].WriteBusy) {
//			if (TestForErasedSectors ()) {
				Flag = 1;			/* 00.03.09 */
				buffNo = DevInf[drive].WriteBufferNumber;		/* current write buffer number */
				if (buffNo < 0) {						/* 2nd FAT */
					buffNo = -buffNo - 1;
					DevInf[drive].sysBuff[buffNo].WriteSequence &= (~ERASE_REQUEST);
					DevInf[drive].sysBuff[buffNo].WriteSequence |= ERASE_END;
					DevInf[drive].WriteBusy = FALSE;
				}
				else {
					if (DevInf[drive].sysBuff[buffNo].FatMode == 1) {			/* erase 2nd FAT sector */
//						drive = DevInf[drive].sysBuff[buffNo].Drive;
						if (DevInf[drive].xBpb.AllocFat != 1) {		/*1997,6,24*/
							DevInf[drive].WriteBufferNumber = -buffNo - 1;	/* current write buffer number */
							sects = DevInf[drive].sysBuff[buffNo].Cluster + DevInf[drive].xBpb.FatPerSectors;
							EraseSectors (drive,		/* drive number */
										  sects,		/* sector Number */
										  1);			/* number of sectors */
							DevInf[drive].WriteBusy = TRUE;
							return ret;
						}
						else {
							DevInf[drive].sysBuff[buffNo].WriteSequence &= (~ERASE_REQUEST);
							DevInf[drive].sysBuff[buffNo].WriteSequence |= ERASE_END;
							DevInf[drive].WriteBusy = FALSE;
						}
					}
					else {
						DevInf[drive].sysBuff[buffNo].WriteSequence &= (~ERASE_REQUEST);
						DevInf[drive].sysBuff[buffNo].WriteSequence |= ERASE_END;
						DevInf[drive].WriteBusy = FALSE;
					}
				}
//			}
		}

		if (!DevInf[drive].WriteBusy) {
			for (i=0; i<DevInf[drive].MaxBuffers; i++) {
				if ((DevInf[drive].sysBuff[i].WriteSequence & (ERASE_END | WRITE_REQUEST)) == (ERASE_END | WRITE_REQUEST)) {
					Flag = 1;			/* 00.03.09 */
					Write_Cluster (drive,i);
					if (DevInf[drive].sysBuff[i].FatMode == 1) {
//						drive = DevInf[drive].sysBuff[i].Drive;
						for (j=1; j<DevInf[drive].xBpb.AllocFat; j++) {	/*1997,6,24*/
							DevInf[drive].sysBuff[i].Cluster += DevInf[drive].xBpb.FatPerSectors;
							Write_Cluster (drive,i);
						}												/*1997,6,24*/
/* ���̕�����FAT�X�^�[�g�ԍ��Ɋ֌W������ 060126 */
						DevInf[drive].sysBuff[i].Cluster -= (DevInf[drive].xBpb.FatPerSectors * (DevInf[drive].xBpb.AllocFat - 1));	/*1997,6,24*/
					}
					DevInf[drive].sysBuff[i].WriteSequence = 0;
					DevInf[drive].sysBuff[i].Status &= ~WRITE;
					ret = TRUE;
				}
			}

			for (i=0; i<DevInf[drive].MaxBuffers; i++) {
				if (DevInf[drive].sysBuff[i].WriteSequence & READ_REQUEST) {
					Flag = 1;			/* 00.03.09 */
					Read_Cluster (drive,i);
					DevInf[drive].sysBuff[i].WriteSequence = 0;
				}
			}

			for (i=0; i<DevInf[drive].MaxBuffers; i++) {
				if (DevInf[drive].sysBuff[i].WriteSequence & ERASE_REQUEST) {
					Flag = 1;			/* 00.03.09 */
					DevInf[drive].WriteBufferNumber = i;		/* current write buffer number */
//					drive = sysBuff[i].Drive;
					if (DevInf[drive].sysBuff[i].Mode == 0) {
						sectno = CnvSectorNumber (DevInf[drive].sysBuff[i].Cluster, drive);
						sects = DevInf[drive].xBpb.ClusterPerSectors;
						EraseSectors (drive,				/* drive number */
									  sectno,				/* sector Number */
									  sects);				/* number of sectors */
					}
					else {
						EraseSectors (drive,				/* drive number */
									  DevInf[drive].sysBuff[i].Cluster,	/* sector Number */
									  1);					/* number of sectors */
					}
					DevInf[drive].WriteBusy = TRUE;
					return ret;
				}
			}
		}
		if(Flag == 0){			/* 00.03.09 */
			return(TRUE);
		}
		return ret;
}


/****************************************************
*  Flush Allocated cluster buffer					*
****************************************************/

int		FlushClusterBuffer (int drive,int buffNo)
{
		DevInf[drive].sysBuff[buffNo].WriteSequence |= WRITE_REQUEST;
		/*WriteIoRequest ();*/
		return 0;
}
/****************************************************
*  LNF Check Code									*
****************************************************/
int shortNameCheckCode(unsigned char* Name)
{
    unsigned char*  p = Name;
    unsigned char*  end = p + 11;
    int             ret = 0;
    while (p < end) ret = (((ret & 1) << 7) | ((ret & 0xfe) >> 1)) + *p++;
    return ret;
}
/****************************************************
*  LNF File Build									*
****************************************************/
unsigned short	GetLNF_FileName(char** name)
{
	unsigned short	ret;

	ret= *(*name)++;
	if(ret >= 0x80){		//2byte code
		ret |= (*(*name)++) << 8;
	}
	return(ret);
}
int	SetLNFFileName(int cnt,char** name,unsigned char* dname)
{
	int	ret;
	int	i;
	unsigned short	nameCode;

	ret= -1;
	for(i= 0; i < cnt; i++){
		nameCode= GetLNF_FileName(name);
		dname[i*2]=	(unsigned char)nameCode;
		dname[i*2+1]=	(unsigned char)(nameCode >> 8);
		if(nameCode == 0){	i++;	break;		}
	}
	if((i < cnt) || ((nameCode == 0) && (i == cnt))){		//20100322
		ret= 0;
		for(; i < cnt; i++){
			dname[i*2]=		0xff;
			dname[i*2+1]=	0xff;
		}
	}
	return(ret);
}
void	LNFFileBuild(char* name)
{
	int	i,ret;

	memset(LNFFileName,0,sizeof(LNFFileName));
	LNFRecCnt= 0;

	while(LNFRecCnt < 63){
		LNFFileName[LNFRecCnt].attribute= 0x0f;
		LNFFileName[LNFRecCnt].LFNSeqNumber= LNFRecCnt+ 1;
		//1st
		ret= SetLNFFileName(5,&name,LNFFileName[LNFRecCnt].name1st);
		if(ret == 0){	//end
			for(i= 0; i < 6; i++){
				LNFFileName[LNFRecCnt].name2nd[i*2]=	0xff;
				LNFFileName[LNFRecCnt].name2nd[i*2+1]=	0xff;
			}
			for(i= 0; i < 2; i++){
				LNFFileName[LNFRecCnt].name3rd[i*2]=	0xff;
				LNFFileName[LNFRecCnt].name3rd[i*2+1]=	0xff;
			}
			break;
		}
		//2nd
		ret= SetLNFFileName(6,&name,LNFFileName[LNFRecCnt].name2nd);
		if(ret == 0){	//end
			for(i= 0; i < 2; i++){
				LNFFileName[LNFRecCnt].name3rd[i*2]=	0xff;
				LNFFileName[LNFRecCnt].name3rd[i*2+1]=	0xff;
			}
			break;
		}
		//3rd
		ret= SetLNFFileName(2,&name,LNFFileName[LNFRecCnt].name3rd);
		if(ret == 0){	//end
			break;
		}
		if(*name == 0){		break;	}			//20100322		
		LNFRecCnt++;
	}
	LNFFileName[LNFRecCnt].LFNSeqNumber|= 0x40;
	LNFRecCnt++;

}
/****************************************************
* File Seek											*
****************************************************/
int	File_Seek(int channel, int offset, int mode)
{
	IFCB	*iFcb;
	int		err;
	long	nextFAT;
	int		drive;

	iFcb = Get_FCBaddress (channel);
	if (iFcb == 0) return -1;				/* not channel open */

	err = File_Rewind (iFcb);
	if (err != 0) return err;			/* rewind error */

	switch(mode){
	case FS_SEEK_SET:
		iFcb->CurrentData= 0;
		break;
	case FS_SEEK_CUR:
		for (;;) {
			if (offset < (iFcb->CurrentData + iFcb->ClusterSize)) break;
			iFcb->CurrentData += iFcb->ClusterSize;
			iFcb->RelativeCluster++;			/* Current Releative cluster number */
			err = Get_NextCluster (iFcb);
			if (err != 0) return err;
		}
		iFcb->CurrentData= offset;
		break;
	case FS_SEEK_END:
		drive = iFcb->Drive;
		for (;;) {
			nextFAT = GetFAT (iFcb->CurrentCluster, drive);	/* Current cluster Number */
			if( ((unsigned long)nextFAT == (unsigned long)0xFFFFFFF8) ||
				((unsigned long)nextFAT == (unsigned long)0xFFFFFFFF) ||
				((unsigned long)nextFAT == (unsigned long)0x0FFFFFF8) ||
				((unsigned long)nextFAT == (unsigned long)0x0FFFFFFF)){	break;	}
			iFcb->RelativeCluster++;						/* Current Releative cluster number */
			iFcb->CurrentCluster = nextFAT;
		}
		iFcb->CurrentData= iFcb->CurrentDirBlock.FileSize;
		break;
	}
	return(err);
}

