#ifndef _UDC_MS_PROTOCOL_H_
#define _UDC_MS_PROTOCOL_H_

#include <types.h>


#define MAX_CBWCB_SIZE 16

// Command Block Wrapper Signature 'USBC'
#define CBW_SIGNATURE               0x43425355
#define CBW_FLAGS_DATA_IN           0x80
#define CBW_FLAGS_DATA_OUT          0x00

// Command Status Wrapper Signature 'USBS'
#define CSW_SIGNATURE               0x53425355
#define CSW_STATUS_GOOD             0x00
#define CSW_STATUS_FAILED           0x01
#define CSW_STATUS_PHASE_ERROR      0x02


// Command Block Wrapper
typedef struct _CBW 
{
    UINT32      dCBWSignature; // 0-3
    UINT32      dCBWTag;    // 4-7
    UINT32      dCBWDataTransferLength; // 8-11
    BYTE        bmCBWFlags; // 12
    BYTE        bCBWLUN:4; // 13
    BYTE        bReserved1:4;
    BYTE        bCBWCBLength:5; // 14
    BYTE        bReserved2:3;
    BYTE        CBWCB[MAX_CBWCB_SIZE]; // 15-30
//}__attribute__ ((packed)) CBW, *PCBW;
}CBW, *PCBW;

// Command Status Wrapper
typedef struct _CSW
{
    UINT32      dCSWSignature; // 0-3
    UINT32      dCSWTag; // 4-7
    UINT32      dCSWDataResidue; // 8-11
    BYTE        bCSWStatus; // 12
//}__attribute__ ((packed)) CSW, *PCSW;
}CSW, *PCSW;


//
//typedef struct
//{
//  unsigned char     bmRequest, bRequest;
//  unsigned short    wValue, wIndex, wLength;
//} SetupPKG, *PSetupPKG;


#endif // _UDC_MS_PROTOCOL_H_

