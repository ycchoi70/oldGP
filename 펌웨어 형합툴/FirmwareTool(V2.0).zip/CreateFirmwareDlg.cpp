// CreateFirmwareDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Environment.h"
#include "FirmwareTool.h"
#include "DirDialog.h"
#include "FirmwareToolDlg.h"
#include "RunDialog.h"
#include "CreateFirmwareDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


ST_FILE_FORMAT g_file_format[] =	{
	{ 0x00010000, "V1.0" }
};

ST_MODEL_INFO g_model[] =			{
	{ 0x8041, "GP-S070 T9D6" },
	{ 0x8042, "GP-S070 T9D7" },
	{ 0x8241, "LP-S070 T9D6" },
	{ 0x8242, "LP-S070 T9D7" }
};

ST_LANGUAGE_INFO g_Lang[] =			{
	{ 0, "KOR"},
	{ 1, "JPN"},
	{ 2, "CHI"},
	{ 3, "ENG"},
	{ 4, "TAI"},
	{ 5, "RUS"},
};

ST_COMPONENT_INFO g_Component[] =	{
	{ 0x8000, "Booter"},
	{ 0x4000, "Loader"},
	{ 0x2000, "Firmware"},
	{ 0x1000, "KeyWindow"},
	{ 0x0800, "Bitmap Font"},
	{ 0x0400, "Vector Font"},
	{ 0x0200,  "National Screen"},
	{ 0x0100,  "English Screen"},
};

/////////////////////////////////////////////////////////////////////////////
// CCreateFirmwareDlg dialog


CCreateFirmwareDlg::CCreateFirmwareDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCreateFirmwareDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCreateFirmwareDlg)
	m_strFwVersion = _T("");
	//}}AFX_DATA_INIT

	m_pFwToolDlg = pParent;
}


void CCreateFirmwareDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCreateFirmwareDlg)
	DDX_Control(pDX, IDC_LIST_COMPONENT, m_listComponent);
	DDX_Control(pDX, IDC_CBO_MODEL, m_cboModel);
	DDX_Control(pDX, IDC_CBO_LANGUAGE, m_cboLanguage);
	DDX_Control(pDX, IDC_CBO_FILE_FORMAT, m_cboFileFormat);
	DDX_Text(pDX, IDC_EDIT_FW_VERSION, m_strFwVersion);
	DDV_MaxChars(pDX, m_strFwVersion, 20);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCreateFirmwareDlg, CDialog)
	//{{AFX_MSG_MAP(CCreateFirmwareDlg)
	ON_BN_CLICKED(IDC_BUTTON_SET_FW_SRC_DIR, OnButtonSetFwSrcDir)
	ON_BN_CLICKED(IDC_BUTTON_SET_SAVE_FILE, OnButtonSetSaveFile)
	ON_BN_CLICKED(IDC_BUTTON_RUN, OnCreateFirmware)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCreateFirmwareDlg message handlers



BOOL CCreateFirmwareDlg::Create(INT sx, INT sy)
{
	CDialog::Create(IDD_CREATE_FIRMWARE_DIALOG, m_pParentWnd);
	SetWindowPos(NULL, sx, sy, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	return TRUE;
}

void CCreateFirmwareDlg::OnButtonSetFwSrcDir() 
{
	CString strFolder;
	GetDlgItemText(IDC_EDIT_FW_SRC_DIR, strFolder);
	CDirDialog dlg(strFolder, NULL, this);
    if(dlg.DoModal() == IDOK)
	{
		SetDlgItemText(IDC_EDIT_FW_SRC_DIR, dlg.GetPath());
	}	
}

void CCreateFirmwareDlg::OnButtonSetSaveFile() 
{
	CString strFileName;
	GetDlgItemText(IDC_EDIT_SAVE_FILE, strFileName);
	CFileDialog dlg(FALSE, NULL, strFileName);
	if(dlg.DoModal() == IDOK)
	{
		SetDlgItemText(IDC_EDIT_SAVE_FILE, dlg.GetPathName());
	}
	
}

BOOL CCreateFirmwareDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitEnvironment();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCreateFirmwareDlg::InitEnvironment()
{
	int index, i;

	// File Format Init
	m_cboFileFormat.ResetContent();
	for(i=0; i<sizeof(g_file_format)/sizeof(ST_FILE_FORMAT); i++)
	{
		index = m_cboFileFormat.AddString(g_file_format[i].strDesc);
		m_cboFileFormat.SetItemData(index, g_file_format[i].dwFileFormat);

#ifdef _DEBUG
		{
			CString szDebug;
			szDebug.Format("--> cboFileFormat :: [%d]\t[%s]\t[%08x]\n", i, g_file_format[i].strDesc, g_file_format[i].dwFileFormat);
			OutputDebugString(szDebug);
		}
#endif
	}
	if(m_cboFileFormat.GetCount()) m_cboFileFormat.SetCurSel(0);


	// Model Code Init
	m_cboModel.ResetContent();
	for(i=0; i<sizeof(g_model)/sizeof(ST_MODEL_INFO); i++)
	{
		index = m_cboModel.AddString(g_model[i].strModel);
		m_cboModel.SetItemData(index, g_model[i].dwModelCode);
		
#ifdef _DEBUG
		{
			CString szDebug;
			szDebug.Format("--> m_cboModel :: [%d]\t[%s]\t[%08x]\n", i, g_model[i].strModel, g_model[i].dwModelCode);
			OutputDebugString(szDebug);
		}
#endif
	}
	if(m_cboModel.GetCount()) m_cboModel.SetCurSel(0);


	// Language Code Init
	m_cboLanguage.ResetContent();
	for(i=0; i<sizeof(g_Lang)/sizeof(ST_LANGUAGE_INFO); i++)
	{
		index = m_cboLanguage.AddString(g_Lang[i].strLang);
		m_cboLanguage.SetItemData(index, g_Lang[i].dwLangCode);
		
#ifdef _DEBUG
		{
			CString szDebug;
			szDebug.Format("--> m_cboLanguage :: [%d]\t[%s]\t[%08x]\n", i, g_Lang[i].strLang, g_Lang[i].dwLangCode);
			OutputDebugString(szDebug);
		}
#endif
	}
	if(m_cboLanguage.GetCount()) m_cboLanguage.SetCurSel(0);

	// Component Info Init
	m_listComponent.ResetContent();
	for(i=0; i<sizeof(g_Component)/sizeof(ST_COMPONENT_INFO); i++)
	{
		index = m_listComponent.AddString(g_Component[i].strComponent);
		m_listComponent.SetItemData(index, g_Component[i].dwBitPos);
		
#ifdef _DEBUG
		{
			CString szDebug;
			szDebug.Format("--> m_listComponent :: [%d]\t[%s]\t[%08x]\n", i, g_Component[i].strComponent, g_Component[i].dwBitPos);
			OutputDebugString(szDebug);
		}
#endif
	}	
}

void CCreateFirmwareDlg::OnCreateFirmware() 
{
	CString source, target;
	ST_FW_INFO fwinfo;

	UpdateData(TRUE);

	memset(&fwinfo, 0x00, sizeof(ST_FW_INFO));

	GetDlgItemText(IDC_EDIT_FW_SRC_DIR, source);
	if(source.IsEmpty())
	{
		AfxMessageBox("Select firmware source directory");
		return;
	}
	GetDlgItemText(IDC_EDIT_SAVE_FILE, target);
	if(target.IsEmpty())
	{
		AfxMessageBox("Select firmware save file name");
		return;
	}

	// file format
	if(m_cboFileFormat.GetCurSel()==CB_ERR)
	{
		AfxMessageBox("Select File Format");
		return;
	}
	fwinfo.dwFileFormat = m_cboFileFormat.GetItemData(m_cboFileFormat.GetCurSel());

	// model code
	if(m_cboModel.GetCurSel() == CB_ERR)
	{
		AfxMessageBox("Select model");
		return;
	}
	fwinfo.dwModelCode = m_cboModel.GetItemData(m_cboModel.GetCurSel());

	// languate
	if(m_cboLanguage.GetCurSel() == CB_ERR)
	{
		AfxMessageBox("Select Language");
		return;
	}
	fwinfo.bLanguage = (BYTE)m_cboLanguage.GetItemData(m_cboLanguage.GetCurSel());

	// version
	if(m_strFwVersion.IsEmpty())
	{
		AfxMessageBox("input firmware version");
		return;
	}
	strcpy(fwinfo.szVersion, (LPCSTR)m_strFwVersion);

	// component
	
	for(int i=0; i<m_listComponent.GetCount(); i++)
	{
		if(m_listComponent.GetCheck(i))
		{
			fwinfo.wComponent |= (WORD)m_listComponent.GetItemData(i);
		}
	}
	if(fwinfo.wComponent == 0)
	{
		AfxMessageBox("select firmware component");
		return;
	}

	CRunDialog dlg(RM_TIE, source, target, &fwinfo, this);
	dlg.DoModal();
}
