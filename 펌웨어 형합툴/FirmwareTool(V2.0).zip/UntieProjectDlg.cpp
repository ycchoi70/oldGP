// UntieProjectDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FirmwareTool.h"
#include "DirDialog.h"
#include "RunDialog.h"
#include "UntieProjectDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUntieProjectDlg dialog


CUntieProjectDlg::CUntieProjectDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUntieProjectDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUntieProjectDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CUntieProjectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUntieProjectDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUntieProjectDlg, CDialog)
	//{{AFX_MSG_MAP(CUntieProjectDlg)
	ON_BN_CLICKED(IDC_BUTTON_SET_UNTIE_PROJECT_PATH, OnButtonSetUntieProjectPath)
	ON_BN_CLICKED(IDC_BUTTON_SET_UNTIE_TARGET_DIR, OnButtonSetUntieTargetDir)
	ON_BN_CLICKED(IDC_BUTTON_UNTIE, OnButtonUntie)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUntieProjectDlg message handlers

BOOL CUntieProjectDlg::Create(INT sx, INT sy)
{
	CDialog::Create(IDD_UNTIE_PROJECT_DIALOG, m_pParentWnd);
	SetWindowPos(NULL, sx, sy, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
	return TRUE;
}

void CUntieProjectDlg::OnButtonSetUntieProjectPath() 
{
	CString strFileName;
	GetDlgItemText(IDC_EDIT_UNTIE_PROJECT_PATH, strFileName);
	CFileDialog dlg(TRUE, NULL, strFileName);
	if(dlg.DoModal() == IDOK)
	{
		SetDlgItemText(IDC_EDIT_UNTIE_PROJECT_PATH, dlg.GetPathName());
	}
}

void CUntieProjectDlg::OnButtonSetUntieTargetDir() 
{
	CString strFolder;
	GetDlgItemText(IDC_EDIT_UNTIE_TARGET_DIR, strFolder);
	CDirDialog dlg(strFolder, NULL, this);
    if(dlg.DoModal() == IDOK)
	{
		SetDlgItemText(IDC_EDIT_UNTIE_TARGET_DIR, dlg.GetPath());
	}	
}

void CUntieProjectDlg::OnButtonUntie() 
{
	CString source, target;
		
	GetDlgItemText(IDC_EDIT_UNTIE_PROJECT_PATH, source);
	if(source.IsEmpty())
	{
		AfxMessageBox("Select source project file");
		return;
	}
	GetDlgItemText(IDC_EDIT_UNTIE_TARGET_DIR, target);
	if(target.IsEmpty())
	{
		AfxMessageBox("Select direcory to untie");
		return;
	}
	
	CRunDialog dlg(RM_UNTIE, source, target, NULL, this);
	dlg.DoModal();
	
}
