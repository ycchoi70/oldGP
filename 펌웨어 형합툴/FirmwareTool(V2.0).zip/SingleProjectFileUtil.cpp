// SingleProjectFileUtil.cpp: implementation of the CSingleProjectFileUtil class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GPByteManipulate.h"
#include "GPFileDirUtility.h"
#include "Environment.h"
#include "SingleProjectFileUtil.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSingleProjectFileUtil::CSingleProjectFileUtil(CWnd *pParentWnd)
{
	// 2010.09.11 by ycchoi
	m_bImport = FALSE;
	m_pParentWnd = pParentWnd;

	// 2011.06.01 by ysNA
	m_bFirmAdd = FALSE;
}

CSingleProjectFileUtil::~CSingleProjectFileUtil()
{

}

/*
	CString srcFolder	: �������Ϸ� Ǯ���� �ִ� ������Ʈ ������ (��: "windowsTemp/128383")
	CString tgtFile		: ����ڰ� ������ ������Ʈ������ ������ ������Ʈ ���ϸ�(��: "D:/MyDoc/myGPPrj.prj")
 */
BOOL CSingleProjectFileUtil::TieSingleGPProjectFile(CString srcFolder, CString tgtFile, UINT iProjectID)
{
	if(!ExistFolder(srcFolder)) return FALSE;
	CopyEtcFiles(srcFolder);

	CFile file;
	if(!file.Open(tgtFile, CFile::modeCreate | CFile::modeReadWrite)) return FALSE;

	m_untiedFolder = srcFolder;

	AddProjectHeadBlock(file, GP_SINGLE_PROJECT_FILE_MAIN_VERSION, GP_SINGLE_PROJECT_FILE_SUB_VERSION, iProjectID);
	BOOL bRet = TieFolder(file, srcFolder);
	AddProjectEndBlock(file);

	file.Close();
	return bRet;
}

BOOL CSingleProjectFileUtil::TieSingleGPFirmwareFile(CString srcFolder, CString tgtFile, ST_FW_INFO *pstFwInfo)
{
	if(srcFolder.ReverseFind('\\') == srcFolder.GetLength()-1)
	{
		srcFolder = srcFolder.Mid(0, srcFolder.GetLength()-1);
	}

	if(!ExistFolder(srcFolder)) return FALSE;
		
	CFile file;
	if(!file.Open(tgtFile, CFile::modeCreate | CFile::modeReadWrite)) return FALSE;
	
	m_untiedFolder = srcFolder;
	
	AddFirmwareHeadBlock(file, pstFwInfo);
	BOOL bRet = TieFolder(file, srcFolder);
	AddProjectEndBlock(file);
	
	file.Close();
	return bRet;
}

/*
	�������� ������Ʈ�� Ǭ �۾��������� proejct����(*.prj)�� ã�Ƽ�
	�� Ȯ���ڸ� ������ ���ϸ��� ���Ѵ�.
	�� �޼ҵ�� ���� ����������Ʈ�� ���� �Ŀ� ���ϸ��� �ٲ� ���
	������ ������Ʈ ���ϸ��� �������� ���� �� �ֱ� ������
	������ ������Ʈ ���ϸ��� ���ϱ� ���ؼ� ����Ѵ�.
*/
VOID CSingleProjectFileUtil::GetProjectFileName(CString workFolder, CString &projectName)
{
	CFileFind finder;	
	CString strWildcard(workFolder);
	strWildcard += _T("\\*.prj");

	projectName = "";
	
	BOOL bWorking = finder.FindFile(strWildcard);
	while(bWorking)
	{
		bWorking = finder.FindNextFile();
		
		if(finder.IsDots())
			continue;
		
		if(finder.IsDirectory())
			continue;
		
		projectName = finder.GetFileName();
		break;
	}
}

/*
	�������� ������Ʈ�� Ǯ� �� ������ �����Ѵ�.

	CString srcFile : �������� ������Ʈ
*/

// 2010.09.11 by ycchoi
// CString CSingleProjectFileUtil::UntieSingleGPProjectFile(CString srcFile, CString &projectName)
CString CSingleProjectFileUtil::UntieSingleGPProjectFile(CString srcFile, CString strTgtDir, CString &projectName, BOOL bImport)
{
	CFile file;

	if(strTgtDir.ReverseFind('\\') == strTgtDir.GetLength()-1)
	{
		strTgtDir = strTgtDir.Mid(0, strTgtDir.GetLength()-1);
	}

	// 2010.09.11 by ycchoi
	m_bImport = bImport;

	m_untiedFolder = _T("");

	do 
	{
		// �������� ����
		if(!file.Open(srcFile, CFile::modeRead)) break;
		// HEAD���� �б�(����Type���)
		UINT nFileType = ReadHeadBlock(file, m_block);
		if(nFileType != GP_TAR_FILE_TYPE_GPPROJECT_HEAD &&
			nFileType != GP_TAR_FILE_TYPE_FIRMWARE_HEAD) break;
		// HEAD������ ��ȿ���� Ȯ��(VERSION ���)
		UINT nVersion = IsValidHeadBlock(m_block);
		if(nVersion == 0) break;
		// �������� ������Ʈ�� Ǯ Folder�� �����Ѵ�.
		// m_untiedFolder = CreateUntieFolder(nFileType, nVersion, m_block);
		m_untiedFolder = strTgtDir;
		// �������� ������Ʈ�� Ǯ�� ����.
		Untie(nFileType, nVersion, m_untiedFolder, file);
	} while(0);

	file.Close();

	// GetProjectFileName(m_untiedFolder, projectName);
	
	return m_untiedFolder;
}

BOOL CSingleProjectFileUtil::ExistFolder(CString strFolder)
{
	HANDLE hFile;
	hFile = CreateFile(strFolder, 0, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, 0);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		return FALSE;
	}
	else
	{
		CloseHandle(hFile);
		return TRUE;
	}
}

BOOL CSingleProjectFileUtil::CopyEtcFiles(CString strFolder)
{
	return TRUE;
}

/*
	���� ����
*/
BOOL CSingleProjectFileUtil::TieFolder(CFile &file, CString strFolder)
{
	CFileFind finder;
	
	CString strWildcard(strFolder);
	strWildcard += _T("\\*.*");

	// 2011.06.01 by ysNA
	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	if(!m_bFirmAdd)
		FirmwareSearch(file, strFolder);
	// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

	BOOL bWorking = finder.FindFile(strWildcard);
	while(bWorking)
	{
		bWorking = finder.FindNextFile();

		if(finder.IsDots())
			continue;

		if(finder.IsDirectory())
		{
			AddFolderBlock(file, finder.GetFilePath());
			if(!TieFolder(file, finder.GetFilePath()))
				return FALSE;
		}
		else
		{
			// 2011.06.01 by ysNA
			if(finder.GetFileName() == GP_S070_T9D6 || finder.GetFileName() == GP_S070_T9D7
				|| finder.GetFileName() == LP_S070_T9D6 || finder.GetFileName() == LP_S070_T9D7)
				continue;

			if(!TieFile(file, finder.GetFilePath()))
				return FALSE;
		}
	}

	return TRUE;
}

/*
	���� ����
*/
BOOL CSingleProjectFileUtil::TieFile(CFile &file, CString strFile)
{
	if(!AddFileHeadBlock(file, strFile)) return FALSE;
	CFile sFile;
	if(!sFile.Open(strFile, CFile::modeRead)) return FALSE;
	int rCnt;
	while(1)
	{
		ClearBlock();
		rCnt = sFile.Read(m_block, 512);
		if(rCnt==0) break;
		file.Write(m_block, 512);
		if(rCnt != 512) break;
	}
	sFile.Close();

	if(m_pParentWnd) m_pParentWnd->SendMessage(WMU_WORK_FILE_NAME_NOTICE, (WPARAM)&strFile);

	return TRUE;
}

/*
	������Ʈ ���� HEAD BLOCK �߰�
*/
BOOL CSingleProjectFileUtil::AddProjectHeadBlock(CFile &file, int mainVer, int subVer, UINT iProjectID)
{
	ClearBlock();

	// HEAD FLAG
	SetStringToByte(0, GP_SINGLE_PROJECT_FILE_FLAG);
	// BLOCK TYPE
	SetIntToByte(TAR_POS_TYPEFLAG, GP_TAR_FILE_TYPE_GPPROJECT_HEAD, 4);
	// VERSION
	SetIntToByte(TAR_POS_VERSION, MAKELONG(GP_SINGLE_PROJECT_FILE_SUB_VERSION, GP_SINGLE_PROJECT_FILE_MAIN_VERSION), 4);
	// PROJECT ID
	SetIntToByte(TAR_POS_PROJECTID, iProjectID, 4);
	// CheckSum
	MakeCheckSum();
	
	// File Write
	file.Write(m_block, 512);

	return TRUE;
}

BOOL CSingleProjectFileUtil::AddFirmwareHeadBlock(CFile &file, ST_FW_INFO *pFwInfo)
{
	ClearBlock();
	
	// HEAD FLAG
	SetStringToByte(0, GP_SINGLE_FIRMWARE_FILE_FLAG);
	// BLOCK TYPE
	SetIntToByte(TAR_POS_TYPEFLAG, GP_TAR_FILE_TYPE_FIRMWARE_HEAD, 4);
	// FILE FORMAT VERSION
	SetIntToByte(TAR_POS_VERSION, pFwInfo->dwFileFormat, 4);
	// MODEL CODE
	SetIntToByte(TAR_POS_FW_MODEL, pFwInfo->dwModelCode, 4);
	// National Language Code
	SetIntToByte(TAR_POS_FW_LANG, pFwInfo->bLanguage, 1);
	// Firmware Version
	SetStringToByte(TAR_POS_FW_VERSION, pFwInfo->szVersion);
	// Firmware Component
	SetIntToByte(TAR_POS_FW_COMPONENT, pFwInfo->wComponent, 2);

	// CheckSum
	MakeCheckSum();
	
	// File Write
	file.Write(m_block, 512);
	
	return TRUE;
}


BOOL CSingleProjectFileUtil::AddProjectEndBlock(CFile &file)
{
	ClearBlock();
		
	// BLOCK TYPE
	SetIntToByte(TAR_POS_TYPEFLAG, GP_TAR_FILE_TYPE_END, 4);
	// CheckSum
	MakeCheckSum();
	
	file.Write(m_block, 512);
	
	return TRUE;
}

/*
	���� HEAD �߰�
*/
BOOL CSingleProjectFileUtil::AddFileHeadBlock(CFile &file, CString strFolder)
{
	ClearBlock();
	
	// folder path( Root path���� ���� path������ �����Ѵ�.)
	// Root path ==> C:\A �̰�,
	// strFolder ==> C:\A\B\C �̸�
	// ����Ǵ� path =====> B\C �̴�.
	int pos = strFolder.Find(m_untiedFolder);
	if(pos<0) return FALSE;
	if(pos+m_untiedFolder.GetLength() >= strFolder.GetLength()) return FALSE;
	SetStringToByte(TAR_POS_FILENAME, strFolder.Mid(pos+m_untiedFolder.GetLength()+1));	
	// BLOCK TYPE
	SetIntToByte(TAR_POS_TYPEFLAG, GP_TAR_FILE_TYPE_FILE, 4);

	// FILE SIZE
	CFile sFile;
	UINT iSize;
	if(!sFile.Open(strFolder, CFile::modeRead)){
		iSize = 0;
	}else{
		iSize = sFile.GetLength();
		sFile.Close();
	}
	SetIntToByte(TAR_POS_FILESIZE, iSize,  4);

	// CheckSum
	MakeCheckSum();
	
	file.Write(m_block, 512);
	
	return TRUE;
}

/*
	Folder Block �߰�
*/
BOOL CSingleProjectFileUtil::AddFolderBlock(CFile &file, CString strFolder)
{
	ClearBlock();
	
	// folder path( Root path���� ���� path������ �����Ѵ�.)
	// Root path ==> C:\A �̰�,
	// strFolder ==> C:\A\B\C �̸�
	// ����Ǵ� path =====> B\C �̴�.
	int pos = strFolder.Find(m_untiedFolder);
	if(pos<0) return FALSE;
	if(pos+m_untiedFolder.GetLength() >= strFolder.GetLength()) return FALSE;
	SetStringToByte(TAR_POS_FILENAME, strFolder.Mid(pos+m_untiedFolder.GetLength()+1));	
	// BLOCK TYPE
	SetIntToByte(TAR_POS_TYPEFLAG, GP_TAR_FILE_TYPE_FOLDER, 4);
	// CheckSum
	MakeCheckSum();
	
	file.Write(m_block, 512);
	
	return TRUE;
}

/*
	�߿��� HEAD ���� �߰�
*/
BOOL CSingleProjectFileUtil::AddFirmwareHeadBlock(CFile &file, int mainVer, int subVer)
{
	ClearBlock();
	
	// HEAD FLAG
	SetStringToByte(TAR_POS_FILENAME, GP_SINGLE_FIRMWARE_FILE_FLAG);
	// BLOCK TYPE
	SetIntToByte(TAR_POS_TYPEFLAG, GP_TAR_FILE_TYPE_FIRMWARE_HEAD, 4);
	// VERSION
	SetIntToByte(TAR_POS_VERSION, MAKELONG(GP_SINGLE_FIRMWARE_FILE_MAIN_VERSION, GP_SINGLE_FIRMWARE_FILE_SUB_VERSION), 4);
	// CheckSum
	MakeCheckSum();
	
	// File Write
	file.Write(m_block, 512);
	
	return TRUE;
}

/*
	������Ʈ HEAD�� �о ����Ÿ���� �����Ѵ�.
*/
UINT CSingleProjectFileUtil::ReadHeadBlock(CFile &file, byte *pBlock)
{
	CGPByteManipulate ByteUtil;
	file.Read(pBlock, 512);
	return (UINT)ByteUtil.ByteToInt(pBlock+TAR_POS_TYPEFLAG, 4);
}

/*
	������Ʈ HEAD ������ ��ȿ�� �������� Ȯ���ϰ�
	��ȿ�� ��쿡�� versio������ �����ش�.
	��ȿ���� ���� ��� 0�� �����Ѵ�.
*/
UINT CSingleProjectFileUtil::IsValidHeadBlock(byte *pBlock)
{
	CGPByteManipulate ByteUtil;

	// HEAD ���� ���ڿ�
	char buf[101];
	ZeroMemory(buf, sizeof(buf));
	memcpy(buf, pBlock, 100);

	// ���� ������
	UINT iType = (UINT)ByteUtil.ByteToInt(pBlock+TAR_POS_TYPEFLAG, 4);

	// ����
	UINT iVersion = (UINT)ByteUtil.ByteToInt(pBlock+TAR_POS_VERSION, 4);

	if(	iType == GP_TAR_FILE_TYPE_GPPROJECT_HEAD && strcmp(buf, GP_SINGLE_PROJECT_FILE_FLAG)==0 ){
		return iVersion;
	}
	else if( iType == GP_TAR_FILE_TYPE_FIRMWARE_HEAD && strcmp(buf, GP_SINGLE_FIRMWARE_FILE_FLAG)==0 ){
		return iVersion;
	}
	else{
		return 0;
	}
}


//DEL CString CSingleProjectFileUtil::CreateUntieFolder(INT fileType, UINT version, byte *pBlick)
//DEL {
//DEL 	// TempDirectory path ���
//DEL 	CString strPath, strTmp;
//DEL 	CGPFileDirUtility Util;
//DEL 	GetTempPath(MAX_PATH+1, strPath.GetBuffer(MAX_PATH+1));
//DEL 	strPath.ReleaseBuffer();
//DEL 
//DEL 	// 2010.09.11 by ycchoi
//DEL 	// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//DEL 	/*
//DEL 	strPath += GP_PROJECT_TEMP_DN;
//DEL 	*/
//DEL 
//DEL 	if(m_bImport)	strPath += GP_PROJECT_IMPORT_TEMP_DN;
//DEL 	else			strPath += GP_PROJECT_TEMP_DN;
//DEL 	// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//DEL 
//DEL 	Util.DeleteDirIncludeSelDir(strPath);
//DEL 	CreateDirectory(strPath, NULL);
//DEL 
//DEL 	if(fileType == GP_TAR_FILE_TYPE_GPPROJECT_HEAD)
//DEL 	{
//DEL 		CGPByteManipulate ByteUtil;
//DEL 
//DEL 		// ProjectID
//DEL 		UINT iPrjID = (UINT)ByteUtil.ByteToInt(pBlick+TAR_POS_PROJECTID, 4);		
//DEL 
//DEL 		// TempDir/ProjcetID Path �����
//DEL 		strTmp.Format("\\%lu", iPrjID);
//DEL 		strPath += strTmp;
//DEL 	}
//DEL 	else if(fileType == GP_TAR_FILE_TYPE_FIRMWARE_HEAD)
//DEL 	{
//DEL 		// TempDir/GPFirmware Path �����
//DEL 		strPath += _T("\\GPFirmware");
//DEL 	}
//DEL 	
//DEL 	if(CreateDirectory(strPath, NULL))	return strPath;
//DEL 	else								return _T("");
//DEL }

/*
	�������� Ǯ��
*/
BOOL CSingleProjectFileUtil::Untie(INT fileType, UINT version, CString tgtFold, CFile &file)
{
	int ifType;
	CString strFile;
	CString strFolder;
	UINT isize;

	while(1)
	{
		ifType = ReadHeadBlock(file, m_block);

		if(ifType == GP_TAR_FILE_TYPE_END)
		{
#ifdef _DEBUG
			{
				OutputDebugString("----->END\n");
			}
#endif
			break;
		}
		else if(ifType == GP_TAR_FILE_TYPE_FOLDER){			
			GetFileName(fileType, version, m_block, strFolder);
			CreateDirectory(m_untiedFolder+"\\"+strFolder, NULL);

#ifdef _DEBUG
			{
				CString szDebug;
				szDebug.Format("----->DIR[%s]\n", m_untiedFolder+"\\"+strFolder);
				OutputDebugString(szDebug);
			}
#endif
		}
		else if(ifType == GP_TAR_FILE_TYPE_FILE){			
			GetFileName(fileType, version, m_block, strFile);
			isize = GetFileSize(fileType, version, m_block);
			UntieFile(fileType, version, file, strFile, isize);

#ifdef _DEBUG
			{
				CString szDebug;
				szDebug.Format("----->FIL[%s]\n", strFile);
				OutputDebugString(szDebug);
			}
#endif
		}
	}

	return TRUE;
}

/*
	HEAD �������� filename�� ��´�.

*/
BOOL CSingleProjectFileUtil::GetFileName(INT fileType, UINT version, byte *pBlock, CString &strFile)
{
	// HEAD ���� ���ڿ�
	LPTSTR pBuf = strFile.GetBuffer(100+1);
	ZeroMemory(pBuf, 100+1);
	memcpy(pBuf, pBlock, 100);
	strFile.ReleaseBuffer();
	return TRUE;
}

UINT CSingleProjectFileUtil::GetFileSize(INT fileType, UINT version, byte *pBlock)
{
	CGPByteManipulate ByteUtil;	
	return (UINT)ByteUtil.ByteToInt(pBlock+TAR_POS_FILESIZE, 4);
}

BOOL CSingleProjectFileUtil::UntieFile(INT fileType, UINT version, CFile &file, CString strFileName, UINT fileSize)
{
	CFile sfile;
	CString strPath;
	UINT iRemainSize, iReadCnt;
	iRemainSize = fileSize;
	
	strPath.Format("%s\\%s", m_untiedFolder, strFileName);
	if(!sfile.Open(strPath, CFile::modeCreate | CFile::modeReadWrite))
	{
#ifdef _DEBUG
		{
			CString szDebug;
			szDebug.Format("[ERROR]Create File Fail[%s]\n", strPath);
			OutputDebugString(szDebug);
		}
#endif
		return FALSE;
	}

	while(iRemainSize)
	{
		ClearBlock();
		iReadCnt = file.Read(m_block, 512);
		if(iRemainSize < iReadCnt) iReadCnt = iRemainSize;
		iRemainSize -= iReadCnt;
		sfile.Write(m_block, iReadCnt);
	}

	/*
	do 
	{
		ClearBlock();
		iReadCnt = file.Read(m_block, 512);
		if(iRemainSize < iReadCnt) iReadCnt = iRemainSize;
		iRemainSize -= iReadCnt;
		sfile.Write(m_block, iReadCnt);
	} while(iRemainSize);
	*/

	sfile.Close();

	if(m_pParentWnd) m_pParentWnd->SendMessage(WMU_WORK_FILE_NAME_NOTICE, (WPARAM)&strPath);

	return TRUE;
}

/*
	���ڿ��� ����Ʈ �迭�� ����
*/
INT	CSingleProjectFileUtil::SetStringToByte(INT iIndex, CString strData)
{
	int len = strData.GetLength();
	
	if( (iIndex + len - 1) < 512 ){
		for(int i = 0; i < len; i++ ){
			m_block[iIndex+i] = strData.GetAt(i);
		}
	}
	
	return len;
}

/*
	�������� ����Ʈ �迭�� ����
*/
VOID CSingleProjectFileUtil::SetIntToByte(INT iIndex, INT iData, INT iCount)
{
	INT	iTemp;
	INT	iShift = iCount - 1;

	if( (iIndex+iCount-1) < 512 ){
		for( int i = 0; i < iCount; i++ ){
			iTemp = iData >> 8 * iShift;
			m_block[iIndex+i] = (iTemp & 0x000000FF);
			iShift--;
		}
	}
}

/*
	�۾��� Block Buf�� �ʱ�ȭ �Ѵ�.
*/
VOID CSingleProjectFileUtil::ClearBlock()
{
	ZeroMemory(m_block, sizeof(m_block));
}

/*
	üũ�� �ۼ�...
*/
VOID CSingleProjectFileUtil::MakeCheckSum()
{
	int		iCheckSum = 0;
	BYTE	bCheckSum = 0;
	
	for( int i = 0; i <= 510; i++ ){
		iCheckSum += m_block[i];
	}
		
	bCheckSum = 0x000000FF & iCheckSum;
	m_block[511] = bCheckSum;
}

// 2011.06.01 by ysNA
BOOL CSingleProjectFileUtil::FirmwareSearch(CFile &file, CString strFolder)
{
	CFileFind finder;
	
	CString strWildcard(strFolder);
	strWildcard += _T("\\*.*");
	
	BOOL bWorking = finder.FindFile(strWildcard);
	while(bWorking)
	{
		bWorking = finder.FindNextFile();
		
		if(finder.IsDots())
			continue;
		
		if(!finder.IsDirectory())
		{
			if(finder.GetFileName() == GP_S070_T9D6 || finder.GetFileName() == GP_S070_T9D7
				|| finder.GetFileName() == LP_S070_T9D6 || finder.GetFileName() == LP_S070_T9D7)
			{
				if(!TieFile(file, finder.GetFilePath()))
					return FALSE;
				
				m_bFirmAdd = TRUE;
				return TRUE;
			}
		}	
	}
	return TRUE;
}
