#if !defined(AFX_UNTIEPROJECTDLG_H__84CC956D_EF2E_4BD0_B8B5_4CB71A1F117E__INCLUDED_)
#define AFX_UNTIEPROJECTDLG_H__84CC956D_EF2E_4BD0_B8B5_4CB71A1F117E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UntieProjectDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUntieProjectDlg dialog

class CUntieProjectDlg : public CDialog
{
// Construction
public:
	BOOL Create(INT sx, INT sy);
	CUntieProjectDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUntieProjectDlg)
	enum { IDD = IDD_UNTIE_PROJECT_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUntieProjectDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUntieProjectDlg)
	afx_msg void OnButtonSetUntieProjectPath();
	afx_msg void OnButtonSetUntieTargetDir();
	afx_msg void OnButtonUntie();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UNTIEPROJECTDLG_H__84CC956D_EF2E_4BD0_B8B5_4CB71A1F117E__INCLUDED_)
