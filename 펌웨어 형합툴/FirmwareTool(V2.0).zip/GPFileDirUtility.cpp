// GPFileDirUtility.cpp: implementation of the CGPFileDirUtility class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GPUnion.h"
#include "GPFileDirUtility.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGPFileDirUtility::CGPFileDirUtility()
{

}

CGPFileDirUtility::~CGPFileDirUtility()
{

}

// ���丮 ����
VOID CGPFileDirUtility::MakeDirectory(CString strPath)
{
	int n	= 0;
	CString strDir;
	
	if( strPath.GetAt( strPath.GetLength() - 1 ) != '\\' ){
		strPath += "\\";
	}

	while( n < strPath.GetLength() ) {
				
		if(strPath[n] == '\\') {
			strDir = strPath.Left(n);
			CreateDirectory(strDir, NULL);
		}
		
		n++;
	}
}
	
// ���� ����
VOID CGPFileDirUtility::DleteFileFromSelDirectory(CString strPath, CString strFile)
{
	CFileFind	ff;
	CString		strFindFile;

	BOOL bFind = ff.FindFile( strPath + strFile );
	while( bFind ){
		bFind = ff.FindNextFile();
		
		if( ff.IsDots() )
			continue;
		
		if( ff.IsDirectory() )
			continue;

		strFindFile = ff.GetFileName();
		DeleteFile( strPath + strFindFile );
	}
}

// ���丮 ����
VOID CGPFileDirUtility::DeleteDirectory( CString strPath )
{
	DleteFileFromSelDirectory( strPath + "\\", "*.*" );
	RemoveDirectory(strPath);
}

// LJS 2002/11/29
VOID CGPFileDirUtility::CopyPanelkitFiles( CString strSource, CString strDestination, CString strFileName)
{
	if( strSource.IsEmpty() || strDestination.IsEmpty() ) {
		return;
	}

	// ���丮 ������ ����....
	if( strSource.GetAt( strSource.GetLength() - 1 ) != '\\' ){
		strSource += '\\';
	}

	if( strDestination.GetAt( strDestination.GetLength() - 1 ) != '\\' ){
		strDestination += '\\';
	}

	//���� ����
	CFileFind	ff;
	CString		strFindFile;
	CString		strSrcFile;
	CString		strDesFile;

	// ���丮 ���� ���� üũ..

	BOOL bFind = ff.FindFile( strSource + "*.*" );

	// �ش��ϴ� ���丮 ����
	if( bFind ){
		MakeDirectory( strDestination );
	}

	while( bFind ){
		bFind = ff.FindNextFile();

		if( ff.IsDots() )
			continue;
		
		if( ff.IsDirectory() )
			continue;

		strFindFile = ff.GetFileName();
		// ������ ���ϸ�
		strSrcFile = strSource + strFindFile;
		if(strFileName == strFindFile) {
			//����� ���ϸ�
			strDesFile = strDestination + strFindFile;
			CopyFile( strSrcFile, strDesFile, FALSE );
		}
	}
}
// ���丮 ����
VOID CGPFileDirUtility::CopyDirectory( CString strSource, CString strDestination)
{
#ifdef _DEBUG
	BOOL bRst;
	CString szDebug;
#endif

	if( strSource.IsEmpty() || strDestination.IsEmpty() ) {
		return;
	}

	// ���丮 ������ ����....
	if( strSource.GetAt( strSource.GetLength() - 1 ) != '\\' ){
		strSource += '\\';
	}

	if( strDestination.GetAt( strDestination.GetLength() - 1 ) != '\\' ){
		strDestination += '\\';
	}

	//���� ����
	CFileFind	ff;
	CString		strFindFile;
	CString		strSrcFile;
	CString		strDesFile;

	// ���丮 ���� ���� üũ..

	BOOL bFind = ff.FindFile( strSource + "*.*" );

	// �ش��ϴ� ���丮 ����
	if( bFind ){
		MakeDirectory( strDestination );
	}

	while( bFind ){
		bFind = ff.FindNextFile();

		if( ff.IsDots() )
			continue;
		
		if( ff.IsDirectory() )
			continue;

		strFindFile = ff.GetFileName();
		// ������ ���ϸ�
		strSrcFile = strSource + strFindFile;

		//����� ���ϸ�
		strDesFile = strDestination + strFindFile;

#ifdef _DEBUG
		{
			bRst = CopyFile( strSrcFile, strDesFile, FALSE );
			szDebug.Format("\tCopyDirectory(%s --> %s (%s))\n", strSrcFile, strDesFile, bRst ? "OK" : "FAIL");
			OutputDebugString(szDebug);
			if(!bRst)
			{
				szDebug.Format("\tCopyDirecotry ErrorCode(%lu)\n", GetLastError());
				OutputDebugString(szDebug);
			}
		}
#else
		CopyFile( strSrcFile, strDesFile, FALSE );
#endif
		
	}
}

// ���丮 ���� ���� üũ...
BOOL CGPFileDirUtility::DirectoryExistCheck( CString strParentDir, CString strFindDir )
{
	CFileFind	ff;
	CString		strDir;
	
	BOOL bFind = ff.FindFile( strParentDir+ "\\" + "*.*" );

	while( bFind ){
		bFind = ff.FindNextFile();

		if( ff.IsDirectory() ){
			strDir = ff.GetFileTitle();
			if( strDir == strFindDir ){
				return TRUE;
			}
		}
	}

	return FALSE;
}

// ���丮 ����( �̸� �ٲپ ���� �ϱ�)
VOID CGPFileDirUtility::RenameCopyDirectory( CString strSource, CString strDestination, CString strReName)
{
	// �ش��ϴ� ���丮 ����
	MakeDirectory( strDestination );

	//���� ����
	CFileFind	ff;
	CString		strFindFile;
	CString		strSrcFile;
	CString		strDesFile;
	int			iPos;

	BOOL bFind = ff.FindFile( strSource + "*.*" );
	while( bFind ){
		bFind = ff.FindNextFile();
		
		if( ff.IsDots() )
			continue;
		
		if( ff.IsDirectory() )
			continue;

		strFindFile = ff.GetFileName();

		iPos = strFindFile.Find('_');
		if( iPos != -1 ){
			strDesFile = strFindFile.Right( strFindFile.GetLength() - iPos );
			strDesFile = strReName + strDesFile;
		}else{
			continue;
		}

		// ������ ���ϸ�
		strSrcFile = strSource + strFindFile;

		//����� ���ϸ�
		strDesFile = strDestination + strDesFile;
		CopyFile( strSrcFile, strDesFile, FALSE );
	}
}

// ã�����ϴ� ���� ����Ʈ�� ����..
VOID CGPFileDirUtility::FindFileList( CString strPath, CString strFindFile, CStringArray& array )
{
	//���� ����
	CFileFind	ff;
	CString		strFindFilePath = strPath + "\\" + strFindFile;
	CString		strFF;
	
	BOOL bFind = ff.FindFile( strFindFilePath );
	while( bFind ){
		bFind = ff.FindNextFile();

		if( ff.IsDots() )
			continue;
		
		if( ff.IsDirectory() )
			continue;

		strFF = ff.GetFileName();
		array.Add( strFF );
	}
}

// ���� ���� ���� üũ
BOOL CGPFileDirUtility::FileExistCheck( CString strFilePath )
{
	CFile	file;
	BOOL	bRet;

	bRet = file.Open( strFilePath, CFile::modeRead );
	if( bRet ){
		file.Close();
	}

	return bRet;
}

// ������ �н� ���
CString CGPFileDirUtility::GetExeModuleDirectory()
{
	char	szFilePath[2048];
	CString	cPath = "";

	memset( szFilePath, 0x00, sizeof(szFilePath) );

	if( GetModuleFileName( (HMODULE)AfxGetInstanceHandle(), (LPTSTR)szFilePath, 2048 ) > 0 )
	{
		CString	sFilePath = szFilePath;
		int iIndex = 0;

		if( (iIndex = sFilePath.ReverseFind('\\')) != -1 ) {
			cPath = sFilePath.Mid(0,iIndex+1);
		}
	}

	return cPath;
}

// �ڱ� �ڽŻ� �ƴ϶� ���� ���丮 ���� ����..
void CGPFileDirUtility::DeleteDirIncludeSelDir(CString strDir)
{
	if( strDir.IsEmpty() )
		return;

	if( strDir.GetLength() <= 3 ){
		return;
	}

	if( strDir.GetAt(1) != ':' && strDir.GetAt(2) != '\\' ){
		return;
	}

	CFileFind*	ff = new CFileFind();
	CString		strTemp;

	BOOL bFind = ff->FindFile( strDir + "\\" + "*.*" );

	while( bFind ){
		bFind = ff->FindNextFile();

		if( ff->IsDots() )
			continue;
		
		if( ff->IsDirectory() ){
			// ���丮�� ��� ..��� ȣ��...
			strTemp	= ff->GetFilePath();
			//DeleteDirectory(strTemp);  ���� ���丮 �� ���丮�� �ִ� ��찡 �־ 
			// ��ġ (����Լ���)
			DeleteDirIncludeSelDir(strTemp);
			continue;
		}

		// ���� ����...
		strTemp = ff->GetFileName();
		DeleteFile( strDir + "\\" + strTemp );
	}
	
	delete ff;

	RemoveDirectory(strDir);
}

// ���� ���丮 ���� ����..
void CGPFileDirUtility::DeleteDirWithoutSelfDir(CString strDir)
{
	if( strDir.IsEmpty() )
		return;

	if( strDir.GetLength() <= 3 ){
		return;
	}

	if( strDir.GetAt(1) != ':' && strDir.GetAt(2) != '\\' ){
		return;
	}

	CFileFind*	ff = new CFileFind();
	CString		strTemp;

	BOOL bFind = ff->FindFile( strDir + "\\" + "*.*" );

	while( bFind ){
		bFind = ff->FindNextFile();

		if( ff->IsDots() )
			continue;
		
		if( ff->IsDirectory() ){
			// ���丮�� ��� ..��� ȣ��...
			strTemp	= ff->GetFilePath();
			DeleteDirectory(strTemp);
			RemoveDirectory(strTemp);
			continue;
		}

		// ���� ����...
		strTemp = ff->GetFileName();
		DeleteFile( strDir + "\\" + strTemp );
	}
	
	delete ff;
}

// ������Ʈ ���� ���� ��� ����..
VOID CGPFileDirUtility::DeleteProjectFile(CString strDir)
{
	if( strDir.IsEmpty() )
		return;

	if( strDir.GetLength() <= 3 ){
		return;
	}

	if( strDir.GetAt(1) != ':' && strDir.GetAt(2) != '\\' ){
		return;
	}

	CFileFind*	ff = new CFileFind();
	CString		strPath;
	CString		strLastDir;
	CString		strUpper;

	BOOL bFind = ff->FindFile( strDir + "\\" + "*.*" );

	while( bFind ){
		bFind = ff->FindNextFile();

		if( ff->IsDots() )
			continue;
		
		if( ff->IsDirectory() ){
			strLastDir = _T("");
			strPath	= ff->GetFilePath();
			GetLastDirectory(strLastDir, strPath);
			strUpper = strLastDir;		strUpper.MakeUpper();
			if( strUpper == "AUXINFO" ){		// ������Ʈ ���� ����..
				DeleteProjectAuxInfo( strPath );
				//RemoveDirectory( strPath );
			}else if( strUpper == "PARTS" ){	// ���� ���̺귯��..
				DeletePartsLibInfo(strPath);
				//RemoveDirectory( strPath );
			}else{								// ���̽� ��ũ��/������ ��ũ��..
				
				CString strTemp = strLastDir;
				strTemp.MakeUpper();
				if( CheckScreenName("BASE", strTemp, 500) ||
					CheckScreenName("WIND", strTemp, 500) ){		// ���̽�/������ ��ũ�� üũ..
					DeleteScreenInfo(strPath, strLastDir);
					//RemoveDirectory( strPath );
				}
			}
		}else{
			// ������Ʈ ��� ���� ����...
			strPath = ff->GetFileName();
			strUpper = strPath;		strUpper.MakeUpper();
			if( strUpper == "GPPROJECT.XML" ){
				DeleteFile( strDir + "\\" + strPath );
			}
		}
	}
	
	delete ff;
}

// ������Ʈ ���� ���� ��� ����..
VOID CGPFileDirUtility::DeleteProjectFileEx(CString strDir)
{
	if( strDir.IsEmpty() )
		return;

	if( strDir.GetLength() <= 3 ){
		return;
	}

	if( strDir.GetAt(1) != ':' && strDir.GetAt(2) != '\\' ){
		return;
	}
	//050621
	int iPos = strDir.ReverseFind('\\');
	CString strDir1 = strDir.Left( iPos );

	int len= strDir.GetLength();
	CString ProjectName = strDir.Right( len- iPos- 1 );

//050621	CString strPrjHeadFile	= GP_PROJECT_FN;	strPrjHeadFile.MakeUpper();
	//CString strPrjHeadFile	= ProjectName + ".prj";	strPrjHeadFile.MakeUpper(); //20060929ksc
   	CString strPrjHeadFile	= ProjectName + ".prj";	strPrjHeadFile.MakeUpper();
	CString	strCommonFile	= GP_COMMON_FN;		strCommonFile.MakeUpper();
	CString	strPartsFile	= GP_PARTSLIB_FN;	strPartsFile.MakeUpper();
	CString	strCommentFile	= GP_COMMENT_FN;	strCommentFile.MakeUpper();

	CFileFind*	ff = new CFileFind();
	CString		strPath;
	CString		strLastDir;
	CString		strUpper;

	BOOL bFind = ff->FindFile( strDir + "\\" + "*.*" );

	while( bFind ){
		bFind = ff->FindNextFile();

		if( ff->IsDots() )
			continue;
		
		if( ff->IsDirectory() ){
			continue;

		}else{
			// ������Ʈ ��� ���� ����...
			strPath = ff->GetFileName();
			strUpper = strPath;		strUpper.MakeUpper();

			// ������Ʈ ��� ����, ���� ����, ���� ����, �ڸ�Ʈ ���� ���� ó��
			if( strUpper == strPrjHeadFile ||
				strUpper == strCommonFile ||
				strUpper == strPartsFile ||
				strUpper == strCommentFile
			){
				DeleteFile( strDir + "\\" + strPath );

			// ���̽�/������ ȭ�� ���� ���� ����
			}else if( CheckScreenName("BASE", strPath, 4) ||
					CheckScreenName("WIND", strPath, 500) )
			{
				DeleteFile( strDir + "\\" + strPath );
			}
		}
	}
	
	delete ff;
}

// ������Ʈ ���� ���� ���丮 ����..
VOID CGPFileDirUtility::DeleteProjectAuxInfo(CString strDir)
{
	CString strFiles[] = {GP_FN_COMMENT, GP_FN_COMMONINFO, GP_FN_PROJECTAUXSET, GP_FN_PROJECTOBSERVESTATUS, GP_FN_ALARMHISTORY_TXT, GP_FN_ALARMFREQUENCY_TXT};

	int iCnt = sizeof(strFiles)/sizeof(CString);
	CString		strTemp;

	for( int i = 0; i < iCnt; i++ ){
		strTemp = strDir + '\\' + strFiles[i];
		DeleteFile(strTemp);
	}

	RemoveDirectory( strDir );
}

// ���� ���̺귯�� ���丮 ����..
VOID CGPFileDirUtility::DeletePartsLibInfo(CString strDir)
{
	CString strImageDir = strDir + '\\' + "image";

	DeleteFile( strDir + '\\' + "PartList.xml" );

	// �̹��� ���� ����..
	DeleteFilesEx( strImageDir, "LIB_", "bmp" );
	RemoveDirectory(strImageDir);

	DeleteFilesEx( strDir, "Parts_", "xml" );
	RemoveDirectory(strDir);
}

// ��ũ�� ���丮 ����..
VOID CGPFileDirUtility::DeleteScreenInfo(CString strDir, CString strPrifix)
{
	CString strImageDir = strDir + '\\' + "image";

	DeleteFile( strDir + '\\' + GP_FN_SCREENAUXSET );
	DeleteFile( strDir + '\\' + GP_FN_SCREENOBSERVESTATUS );

	// �̹��� ���� ����..
	DeleteFilesEx( strImageDir, strPrifix, "bmp" );
	RemoveDirectory(strImageDir);

	DeleteFilesEx( strDir, strPrifix, "xml" );
	RemoveDirectory(strDir);

}

// �̹��� ���� ����..
VOID CGPFileDirUtility::DeleteFilesEx( CString strDir, CString strPrefix, CString strExt )
{
	if( strDir.IsEmpty() )
		return;

	if( strDir.GetLength() <= 3 ){
		return;
	}

	if( strDir.GetAt(1) != ':' && strDir.GetAt(2) != '\\' ){
		return;
	}

	CFileFind*	ff = new CFileFind();
	CString		strPath;

	BOOL bFind = ff->FindFile( strDir + "\\" + strPrefix + "*." + strExt );

	while( bFind ){
		bFind = ff->FindNextFile();

		if( ff->IsDots() )
			continue;
		
		if( ff->IsDirectory() ){
			continue;
		}
		
		// ������Ʈ ��� ���� ����...
		strPath = ff->GetFileName();
		DeleteFile( strDir + "\\" + strPath );
	}
	
	delete ff;
}


// ���丮 �н��� ���� �� �κ��� ���丮 ���..
VOID CGPFileDirUtility::GetLastDirectory(CString& strLastDir, CString strDir)
{
	int pos = strDir.ReverseFind('\\');
	if( pos >= 0 ){
		strLastDir = strDir.Mid( pos + 1 );
	}
}

// ���̽� / ������ ��ũ�� ���丮�� �´��� üũ..
BOOL CGPFileDirUtility::CheckScreenName(CString strPrefix, CString strLastDir, INT iMaxScreenNo)
{
	CString		strTemp;
	CString		strNo;
	int			iNo;

	strTemp = strLastDir.Left(4);
	strTemp.MakeUpper();
	if( strTemp == strPrefix ){
		if( strLastDir.GetLength() == 11 ){
			strNo	= strLastDir.Mid(4, 4);
			iNo		= atoi( strNo );
			if( iNo > 0 && iNo <= iMaxScreenNo ){
				return TRUE;
			}
		}
	}

	return FALSE;
}

VOID CGPFileDirUtility::DeletePanelkitData(CString strDir, CString strFile, CString strFolder)
{
	if( strDir.IsEmpty() )
		return;

	if( strDir.GetLength() <= 3 ){
		return;
	}

	if( strDir.GetAt(1) != ':' && strDir.GetAt(2) != '\\' ){
		return;
	}

	CFileFind*	ff = new CFileFind();
	CString		strPath;
	CString		strLastDir;
	CString		strUpper;

	BOOL bFind = ff->FindFile( strDir + "\\" + "*.*" );

	while( bFind ){
		bFind = ff->FindNextFile();

		if( ff->IsDots() )
			continue;
		
		if( ff->IsDirectory() ){
			strLastDir = _T("");
			strPath	= ff->GetFilePath();
			GetLastDirectory(strLastDir, strPath);
			strUpper = strLastDir;		strUpper.MakeUpper();
			if( strUpper == strFolder ) {	// �ǳ�ŰƮ�� 
				DeleteFilesEx( strDir+"\\"+strFolder, "Pkit", "xml" );
				RemoveDirectory(strDir+"\\"+strFolder);
			}
		}
		else{
			// �ǳ�ŰƮ ���� ����...
			strPath = ff->GetFileName();
			strUpper = strPath;		strUpper.MakeUpper();
			strFile.MakeUpper();
			if( strUpper == strFile ){
				DeleteFile( strDir + "\\" + strPath );
			}
		}
	}
	
	delete ff;

}

// ���丮 ����
VOID CGPFileDirUtility::MoveDirectory(CString strDir, CString strMovePath)
{
	if( strDir.IsEmpty() )
		return;

	if( strDir.GetLength() <= 3 ){
		return;
	}

	if( strDir.GetAt(1) != ':' && strDir.GetAt(2) != '\\' ){
		return;
	}
	
	// �̵���ų ���丮 ����
	MakeDirectory(strMovePath);

	CFileFind*	ff = new CFileFind();
	CString		strPath;
	CString		strLastDir;
	CString		strMovePath1;
	CString		strFindFile;

	BOOL bFind = ff->FindFile( strDir + "\\" + "*.*" );

	while( bFind ){
		bFind = ff->FindNextFile();

		if( ff->IsDots() )
			continue;
		
		// ���丮�� ���
		if( ff->IsDirectory() ){
			strLastDir = ff->GetFileName();
			strPath	= ff->GetFilePath();
			strMovePath1 = strMovePath + "\\" + strLastDir;
			MoveDirectory( strPath, strMovePath1);

		// ������ ���
		}else{
			// ���� ����
			CString strMoveFile1, strMoveFile2;
			strFindFile = ff->GetFileName();
			strMoveFile1 = strDir + "\\" + strFindFile;
			strMoveFile2 = strMovePath + "\\" + strFindFile;
			//MoveFile( strMoveFile1, strMoveFile2 );
			CopyFile( strMoveFile1, strMoveFile2, FALSE );
			DeleteFile(strMoveFile1);
		}
	}
	
	delete ff;

	// ����� ���丮 ����
	RemoveDirectory(strDir);
}

// �������� ���丮�� �ִ� ���� ���� ����
VOID CGPFileDirUtility::DleteTemporary(CString strPath)
{
	CFileFind	ff;
	CString		strFindFile;
	CTime		CurrentTime;
	CTime		CreateTime;
	CString		strCurrentTime;
	CString		strCreateTime;
	long		lCurrentTime;
	long		lCreateTime;
	CString		strFindPath;

	// ���� ��¥ ���
	CurrentTime = CTime::GetCurrentTime();
	strCurrentTime = CurrentTime.Format("%y%m%d");
	lCurrentTime = atol(strCurrentTime);

	BOOL bFind = ff.FindFile( strPath + "\\" + "*.*" );
	while( bFind ){
		bFind = ff.FindNextFile();
		
		if( ff.IsDots() )
			continue;

		// ���丮���� �Ǵ�
		if( ff.IsDirectory() ){
			strFindPath = ff.GetFilePath();
			ff.GetCreationTime(CreateTime);
			strCreateTime = CreateTime.Format("%y%m%d");
			lCreateTime = atol(strCreateTime);

			// ������ ��¥�� ���� ��¥���� ���� ��� ����.
			if( lCurrentTime > lCreateTime ){
				DeleteDirIncludeSelDir( strFindPath ); 	
			}
		}
	}
}