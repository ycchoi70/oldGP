#if !defined(AFX_RUNDIALOG_H__712006FD_6FEF_4EA2_B8B6_1A3BB2D015EC__INCLUDED_)
#define AFX_RUNDIALOG_H__712006FD_6FEF_4EA2_B8B6_1A3BB2D015EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RunDialog.h : header file
//

#include "Environment.h"

/////////////////////////////////////////////////////////////////////////////
// CRunDialog dialog

class CRunDialog : public CDialog
{
// Construction
public:
	CRunDialog(int imode, CString strSrc, CString strTgt, ST_FW_INFO *pFwInfo, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRunDialog)
	enum { IDD = IDD_RUN_DIALOG };
	CEdit	m_edRunFile;
	CString	m_runFileName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRunDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRunDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG

	LRESULT OnReceiveFileName(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()


public:
	INT m_iMode;
	CString m_source;
	CString m_target;
	ST_FW_INFO *m_pFwInfo;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RUNDIALOG_H__712006FD_6FEF_4EA2_B8B6_1A3BB2D015EC__INCLUDED_)
