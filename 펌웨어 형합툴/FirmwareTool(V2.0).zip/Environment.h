#if !defined(ENVIRONMENT_H__INCLUDED_)
#define ENVIRONMENT_H__INCLUDED_

// file format version�� ���� ����ü ����
typedef struct  
{
	DWORD dwFileFormat;
	char  strDesc[10];
}ST_FILE_FORMAT;

/*
ST_FILE_FORMAT g_file_format[] = {{ 0x00010000, "V1.0" }};
*/

// model code�� ���� ����ü ����
typedef struct 
{
	DWORD dwModelCode;
	char  strModel[20];
}ST_MODEL_INFO;

/*
ST_MODEL_INFO g_model[] =	{
								{ 0x8041, "GP-S070 T4D0" },
								{ 0x8042, "GP-S070 T4D1" },
								{ 0x8241, "LP-S070 T4D0" },
								{ 0x8242, "LP-S070 T4D1" }
							};
*/

// language code�� ���� ����ü ����
typedef struct
{
	DWORD dwLangCode;
	char  strLang[10];
}ST_LANGUAGE_INFO;

/*
ST_LANGUAGE_INFO g_Lang[] =	{
								{ 0, "KOR"},
								{ 1, "JPN"},
								{ 2, "CHI"},
								{ 3, "ENG"},
								{ 4, "TAI"},
								{ 5, "RUS"}
							};
*/

// firmware component �� ���� ����ü ����
typedef struct
{
	DWORD dwBitPos;
	char  strComponent[20];
}ST_COMPONENT_INFO;

/*
ST_COMPONENT_INFO g_Component[] =	{
										{ 15, "Booter"},
										{ 14, "Loader"},
										{ 13, "Firmware"},
										{ 12, "KeyWindow"},
										{ 11, "Bitmap Font"},
										{ 10, "Vector Font"},
										{ 9,  "National Screen"},
										{ 8,  "English Screen"},
									};
*/

// firmware head info struct ����
typedef struct
{
	DWORD dwFileFormat;
	DWORD dwModelCode;
	BYTE  bLanguage;
	char  szVersion[20+1];
	WORD  wComponent;
}ST_FW_INFO;

#endif