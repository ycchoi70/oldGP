// GPByteManipulate.cpp: implementation of the CGPByteManipulate class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GPByteManipulate.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGPByteManipulate::CGPByteManipulate()
{

}

CGPByteManipulate::~CGPByteManipulate()
{

}

// ����Ʈ �迭�� ������ ��ȯ..
int	CGPByteManipulate::ByteToInt( BYTE* buf, int size )
{
	int	iRet = 0;
	int	iTemp;
	int	iShift;

	iShift	= size - 1;

	for( int i = 0; i < size; i++ ){
		iTemp = buf[i];
		iTemp = iTemp & 0x000000FF;
		iTemp = iTemp << (iShift*8);
		iRet |= iTemp;
		iShift--;
	}

	return iRet;
}

// ����Ʈ �迭�� ������ ��ȯ..
double	CGPByteManipulate::ByteToDouble( BYTE* buf )
{
	double dRet = 0;
	int temp = 0;
	
	temp = buf[0];
	dRet = (double)temp * (double)0x1000000;
	
	temp = buf[1];
	dRet += (double)temp * (double)0x10000;

	temp = buf[2];
	dRet += (double)temp * (double)0x100;

	temp = buf[3];
	dRet += temp;

	return dRet;
}

// ����Ʈ �迭�� ��ȣ���� ������ ��ȯ..
unsigned int CGPByteManipulate::ByteToUnsignedInt( BYTE* buf )
{
	unsigned int unRet = 0;

	for( int i = 0; i < 4; i++ ){
		unRet = unRet << 8;
		unRet = unRet | (unsigned int)buf[i];	
	}
	
	return unRet;
}

// ����Ʈ �迭�� ��ȣ�ִ� ������ ��ȯ..
int CGPByteManipulate::ByteToSignedInt( BYTE* buf )
{
	int iRet = 0;

	for( int i = 0; i < 4; i++ ){
		iRet = iRet << 8;
		iRet = iRet | (int)buf[i];	
	}
	
	return iRet;
}

CString	CGPByteManipulate::ByteToWordDev( BYTE* buf )
{
	CString strDev = _T("");

	if( buf[0] == 0x50 && buf[1] == 0xA8 ){
		strDev = "D";
	}else if( buf[0] == 0x50 && buf[1] == 0xC2 ){
		strDev = "T";
	}else if( buf[0] == 0x50 && buf[1] == 0xC5 ){
		strDev = "C";
	}else if( buf[0] == 0x5F && buf[1] == 0xC2 ){
		strDev = "TS";
	}else if( buf[0] == 0x5F && buf[1] == 0xC5 ){
		strDev = "CS";
	}else if( buf[0] == 0x5F && buf[1] == 0x02 ){
		strDev = "GD";
	}

	return strDev;
}

CString CGPByteManipulate::ByteToBitDev( BYTE* buf )
{
	CString strDev = _T("");

	if( buf[0] == 0x10 && buf[1] == 0x9C ){
		strDev = "X";
	}else if( buf[0] == 0x10 && buf[1] == 0x9D ){
		strDev = "Y";
	}else if( buf[0] == 0x10 && buf[1] == 0x98 ){
		strDev = "S";
	}else if( buf[0] == 0x10 && buf[1] == 0x90 ){
		strDev = "M";
	}else if( buf[0] == 0x10 && buf[1] == 0xC1 ){
		strDev = "T";
	}else if( buf[0] == 0x10 && buf[1] == 0xC4 ){
		strDev = "C";
	}else if( buf[0] == 0x1F && buf[1] == 0x01 ){
		strDev = "GB";
	}

	return strDev;
}
