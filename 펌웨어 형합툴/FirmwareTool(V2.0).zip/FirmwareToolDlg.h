// FirmwareToolDlg.h : header file
//

#if !defined(AFX_FIRMWARETOOLDLG_H__D8051CA6_BB83_4CB8_9245_2BDE35925D71__INCLUDED_)
#define AFX_FIRMWARETOOLDLG_H__D8051CA6_BB83_4CB8_9245_2BDE35925D71__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFirmwareToolDlg dialog

class CFirmwareToolDlg : public CDialog
{
// Construction
public:
	CFirmwareToolDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CFirmwareToolDlg)
	enum { IDD = IDD_FIRMWARETOOL_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFirmwareToolDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CFirmwareToolDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnRadioCreateFw();
	afx_msg void OnRadioUntieProject();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void ChangePage();
	void CreateSubDialog();

	CDialog *m_pCreateFirmwareDlg;
	CDialog *m_pUntieProjectDlg;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIRMWARETOOLDLG_H__D8051CA6_BB83_4CB8_9245_2BDE35925D71__INCLUDED_)
