#if !defined(AFX_CREATEFIRMWAREDLG_H__C50B60F1_A6B1_4DF8_AD95_3CDC4C0B4018__INCLUDED_)
#define AFX_CREATEFIRMWAREDLG_H__C50B60F1_A6B1_4DF8_AD95_3CDC4C0B4018__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CreateFirmwareDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCreateFirmwareDlg dialog

class CCreateFirmwareDlg : public CDialog
{
// Construction
public:
	BOOL Create(INT sx, INT sy);
	CCreateFirmwareDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCreateFirmwareDlg)
	enum { IDD = IDD_CREATE_FIRMWARE_DIALOG };
	CCheckListBox	m_listComponent;
	CComboBox	m_cboModel;
	CComboBox	m_cboLanguage;
	CComboBox	m_cboFileFormat;
	CString	m_strFwVersion;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCreateFirmwareDlg)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCreateFirmwareDlg)
	afx_msg void OnButtonSetFwSrcDir();
	afx_msg void OnButtonSetSaveFile();
	virtual BOOL OnInitDialog();
	afx_msg void OnCreateFirmware();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void InitEnvironment();

private:
	CWnd *m_pFwToolDlg;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CREATEFIRMWAREDLG_H__C50B60F1_A6B1_4DF8_AD95_3CDC4C0B4018__INCLUDED_)
