//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FirmwareTool.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FIRMWARETOOL_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDD_CREATE_FIRMWARE_DIALOG      130
#define IDD_UNTIE_PROJECT_DIALOG        131
#define IDD_RUN_DIALOG                  132
#define IDC_RADIO_CREATE_FW             1000
#define IDC_EDIT_FW_SRC_DIR             1001
#define IDC_RADIO_UNTIE_PROJECT         1001
#define IDC_BUTTON_SET_FW_SRC_DIR       1002
#define IDC_EDIT_SAVE_FILE              1003
#define IDC_BUTTON_SET_SAVE_FILE        1004
#define IDC_CBO_FILE_FORMAT             1005
#define IDC_CBO_MODEL                   1006
#define IDC_CBO_LANGUAGE                1007
#define IDC_EDIT_FW_VERSION             1008
#define IDC_LIST_COMPONENT              1009
#define IDC_EDIT_UNTIE_PROJECT_PATH     1010
#define IDC_BUTTON_SET_UNTIE_PROJECT_PATH 1011
#define IDC_EDIT_UNTIE_TARGET_DIR       1012
#define IDC_BUTTON_SET_UNTIE_TARGET_DIR 1013
#define IDC_BUTTON_UNTIE                1014
#define IDC_BUTTON_RUN                  1015
#define IDC_EDIT_FILE                   1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
