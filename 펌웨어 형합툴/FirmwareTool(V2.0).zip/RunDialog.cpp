// RunDialog.cpp : implementation file
//

#include "stdafx.h"
#include "FirmwareTool.h"
#include "SingleProjectFileUtil.h"
#include "RunDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


UINT RunThread(LPVOID wndParam);
/////////////////////////////////////////////////////////////////////////////
// CRunDialog dialog


CRunDialog::CRunDialog(int imode, CString strSrc, CString strTgt, ST_FW_INFO *pFwInfo, CWnd* pParent /*=NULL*/)
	: CDialog(CRunDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRunDialog)
	m_runFileName = _T("");
	//}}AFX_DATA_INIT

	m_iMode = imode;
	m_source = strSrc;
	m_target = strTgt;
	m_pFwInfo = pFwInfo;
}


void CRunDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRunDialog)
	DDX_Control(pDX, IDC_EDIT_FILE, m_edRunFile);
	DDX_Text(pDX, IDC_EDIT_FILE, m_runFileName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRunDialog, CDialog)
	//{{AFX_MSG_MAP(CRunDialog)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP

	ON_MESSAGE(WMU_WORK_FILE_NAME_NOTICE, OnReceiveFileName)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRunDialog message handlers

BOOL CRunDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CString szTitle;
	if(m_iMode == RM_TIE)
	{
		szTitle.Format("Create Firmware ...[%s]", m_target);
	}
	else
	{
		szTitle.Format("Untie Project File ...[%s]", m_source);
	}
	SetWindowText(szTitle);

	SetTimer(1, 500, NULL);



	

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CRunDialog::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == 1)
	{
		KillTimer(1);

		CWinThread *pRunThread = AfxBeginThread((AFX_THREADPROC)RunThread, LPVOID(this), THREAD_PRIORITY_NORMAL);
		
		/*
		CSingleProjectFileUtil util(this);
		BOOL bResult;
		
		if(m_iMode == RM_TIE)
		{
			bResult = util.TieSingleGPFirmwareFile(m_source, m_target, m_pFwInfo);
			if(bResult)
			{
				AfxMessageBox("Firmware Create Success!");
			}
			else
			{
				AfxMessageBox("Firmware Create Fail!");
			}
		}
		else
		{
			CString szPrjName;
			util.UntieSingleGPProjectFile(m_source, m_target, szPrjName);			
			AfxMessageBox("Project File Untie Success!");
		}

		EndDialog(0);
		*/
	}
	
	CDialog::OnTimer(nIDEvent);
}


LRESULT CRunDialog::OnReceiveFileName(WPARAM wParam, LPARAM lParam)
{
	CString *pFileName = (CString*)wParam;
	m_runFileName = *pFileName;

#ifdef _DEBUG
	{
		if(m_iMode == RM_TIE)
		{
			CString szDebug;
			szDebug.Format("---> [%s]\n", m_runFileName);
			OutputDebugString(szDebug);
		}		
	}
#endif

	UpdateData(FALSE);
//	m_edRunFile.Invalidate(TRUE);
	return 0;
}


UINT RunThread(LPVOID wndParam)
{
	CRunDialog *pDlg = (CRunDialog*)wndParam;

	CSingleProjectFileUtil util(pDlg);
	BOOL bResult;
	
	if(pDlg->m_iMode == RM_TIE)
	{
		bResult = util.TieSingleGPFirmwareFile(pDlg->m_source, pDlg->m_target, pDlg->m_pFwInfo);
		if(bResult)
		{
			MessageBox(pDlg->m_hWnd, "Firmware Create Success!", "Result", MB_OK);
		}
		else
		{
			MessageBox(pDlg->m_hWnd, "Firmware Create Fail!", "Result", MB_OK);
		}
	}
	else
	{
		CString szPrjName;
		util.UntieSingleGPProjectFile(pDlg->m_source, pDlg->m_target, szPrjName);			
		MessageBox(pDlg->m_hWnd, "Project File Untie Success!", "Result", MB_OK);
	}
	
	// pDlg->EndDialog(0);
	pDlg->PostMessage(WM_CLOSE);

	return 0;
}