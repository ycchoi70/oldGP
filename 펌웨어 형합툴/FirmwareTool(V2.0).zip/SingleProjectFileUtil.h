// SingleProjectFileUtil.h: interface for the CSingleProjectFileUtil class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SINGLEPROJECTFILEUTIL_H__182F250E_3191_497F_8F15_348B5C38FB88__INCLUDED_)
#define AFX_SINGLEPROJECTFILEUTIL_H__182F250E_3191_497F_8F15_348B5C38FB88__INCLUDED_

#include "Environment.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define GP_SINGLE_PROJECT_FILE_MAIN_VERSION		1
#define GP_SINGLE_PROJECT_FILE_SUB_VERSION		0
#define GP_SINGLE_FIRMWARE_FILE_MAIN_VERSION	1
#define GP_SINGLE_FIRMWARE_FILE_SUB_VERSION		0

#define GP_SINGLE_PROJECT_FILE_FLAG				"__AUTONICS GP PROJECT FILE__"
#define GP_SINGLE_FIRMWARE_FILE_FLAG			"__AUTONICS GP FIRMWARE FILE__"

#define GP_TAR_FILE_TYPE_END				0
#define GP_TAR_FILE_TYPE_FILE				1
#define GP_TAR_FILE_TYPE_FOLDER				2
#define GP_TAR_FILE_TYPE_FIRMWARE_HEAD		254
#define GP_TAR_FILE_TYPE_GPPROJECT_HEAD		255

// TAR HEAD���� �ʴ��� offset��
#define TAR_POS_FILENAME			0
#define TAR_POS_TYPEFLAG			100
#define TAR_POS_FILESIZE			104
#define TAR_POS_VERSION				200
#define TAR_POS_PROJECTID			204
#define TAR_POS_CHECKSUM			511

#define TAR_POS_FW_MODEL			204
#define TAR_POS_FW_LANG				208
#define TAR_POS_FW_VERSION			209
#define TAR_POS_FW_COMPONENT		229

// Firmware Update ��� ��Ī
#define GP_S070_T9D6				"GPA_9048.GLP"
#define GP_S070_T9D7				"GPA_9049.GLP"
#define LP_S070_T9D6				"LPA_9248.GLP"
#define LP_S070_T9D7				"LPA_9249.GLP"
		

class CSingleProjectFileUtil  
{
public:
	BOOL FirmwareSearch(CFile &file, CString strFolder);
	BOOL TieSingleGPFirmwareFile(CString srcFolder, CString tgtFile, ST_FW_INFO *pstFwInfo);
	
	CSingleProjectFileUtil(CWnd *pParentWnd=NULL);
	virtual ~CSingleProjectFileUtil();

	// ����
	BOOL TieSingleGPProjectFile(CString srcFolder, CString tgtFile, UINT iProjectID);
	// Ǯ��

	// 2010.09.11 by ycchoi
	// CString UntieSingleGPProjectFile(CString srcFile, CString &projectName);
	CString UntieSingleGPProjectFile(CString srcFile, CString strTgtDir, CString &projectName, BOOL bImport=FALSE);
	

private:
	BOOL AddFirmwareHeadBlock(CFile &file, ST_FW_INFO *pFwInfo);

	// 2010.09.11 by ycchoi
	BOOL	m_bImport;		// ������Ʈ import������ ������Ʈ�� untie�� ��� TRUE. �ƴϸ�, FALSE
							// �Ϲ� ������Ʈ untie�ÿ��� winTemp/GPProject��
							// import ������ ���ؼ� untie�ÿ��� winTemp/GPImport���� �۾��� �Ѵ�.
			
	CString m_untiedFolder;
	CWnd *m_pParentWnd;

	// 2011.06.01 by ysNa
	BOOL	m_bFirmAdd;
	
	// ����Ÿ �Է� ��ƿ
	byte m_block[512];
	VOID ClearBlock();
	INT	SetStringToByte(INT iIndex, CString strData);
	VOID SetIntToByte(INT iIndex, INT iData, INT iCount);
	VOID MakeCheckSum();
	
	// ����
	BOOL AddFirmwareHeadBlock(CFile &file, int mainVer, int subVer);
	BOOL AddFileHeadBlock(CFile &file, CString strFolder);
	BOOL AddFolderBlock(CFile &file, CString strFolder);
	BOOL AddProjectEndBlock(CFile &file);
	BOOL AddProjectHeadBlock(CFile &file, int mainVer, int subVer, UINT iProjectID);
	BOOL TieFile(CFile &file, CString strFile);
	BOOL TieFolder(CFile &file, CString strFolder);
	BOOL CopyEtcFiles(CString strFolder);
	BOOL ExistFolder(CString strFolder);
	VOID GetProjectFileName(CString workFolder, CString &projectName);

	// Ǯ��
	BOOL UntieFile(INT fileType, UINT version, CFile &file, CString strFileName, UINT fileSize);
	UINT GetFileSize(INT fileType, UINT version, byte *pBlock);
	BOOL GetFileName(INT fileType, UINT version, byte *pBlock, CString &strFile);
	BOOL Untie(INT fileType, UINT version, CString tgtFold, CFile &file);
	UINT IsValidHeadBlock(byte *pBlock);
	UINT ReadHeadBlock(CFile &file, byte *pBlock);
};

#endif // !defined(AFX_SINGLEPROJECTFILEUTIL_H__182F250E_3191_497F_8F15_348B5C38FB88__INCLUDED_)
