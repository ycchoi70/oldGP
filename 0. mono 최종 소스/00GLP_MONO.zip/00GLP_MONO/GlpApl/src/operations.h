#ifndef __OPERATIONS_H__
#define __OPERATIONS_H__
#define REGISTER32(x)	*(volatile unsigned int*)x
#define REGISTER16(x)	*(volatile unsigned short*)x
#define REGISTER8(x)	*(volatile unsigned char*)x
#define GETWIDTH(x)	(x&0x0F)
#define GETARCHIT(x) ((x&0xC)>>4)
#endif // __OPERATIONS_H__
