#include	"sgt.h"

#ifdef	SIZE_2480
/* ****************************************************************************** */
/*  �Լ�																			 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �� �� �� : BaseScreenList()													 */
/*  ��    �� : BaseScreen Listǥ��												 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 7�� 2�� (��)												 */
/*  �� �� �� : �� �� �� 														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void		BaseScreenList(int* iScreenNo)
{
	int				iKeyCode;
	short			i;
	short			iNumY;
	short			TLineCnt;			/* �� ���� ��		*/
	short			NowPoint;			/* ���� ȭ�� ����	*/
	short			iScreenNum;
	short			iKeyFlag;
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;
	
	iKeyFlag = 1;
	iUserScreenFlag = 0;
	NowPoint = 0;
	/**************************/
	RepeatInfo.EntryCnt = 2;
	RepeatInfo.RepeatNo[0][0] = (char)KEY_29;
	RepeatInfo.RepeatNo[0][1] = (char)KEY_30;
	RepeatInfo.RepeatNo[1][0] = (char)KEY_59;
	RepeatInfo.RepeatNo[1][1] = (char)KEY_60;
	/**************************/
	DefaultFormDisplay(ARROW_FORM,Dspname[BASE_SCREEN].chTitle[Set.iLang]);
	for(i=0;i<3;i++)
	{
		iNumY = (i*18);
		RectAngleOut(GAMEN_START_X+1,GAMEN_START_Y+24+iNumY,GAMEN_START_X+196,GAMEN_START_Y+40+iNumY,&RECParam);
	}

	TLineCnt = iBaseScreenCnt;
	if(iBaseScreenCnt<3)
		TLineCnt = 3;
	BaseScreenNumDisplay(TLineCnt,NowPoint);

	KerRepeatFlag = 1;		/* 040815 */
	while(*iScreenNo == BASE_SCREEN_NUM)
	{
		while(1)
		{
			/* leesi 040612  iKeyCode = KeyWait();  */
			iKeyCode = iKeyReturn(BASE_SCREEN_NUM);

			if(iKeyFlag == 0 || iKeyCode == PC_DNLOAD_START || 
				iKeyCode == PC_UPLOAD_START || iKeyCode == 0)
				break;
		}
		iKeyFlag = 0;
		iScreenNum		= 0;

		if(( iKeyCode == KEY_01 || iKeyCode == KEY_02  ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_43) ||
			(iKeyCode >= KEY_46 && iKeyCode <= KEY_60))) 
		{
			iKeyFlag = 1;
			NormalBuzzer();	
		}

		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}
		if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 )			/* ����		*/
		{
			*iScreenNo = USER_SCREEN_NUM;
		}
		else if(iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) 		/* ����		*/
		{				
			*iScreenNo = DATA_VIEW_NUM;
		}
		else if(iKeyCode >= KEY_16 && iKeyCode <= KEY_27 )		/*  ȭ��0	*/
		{				
			if(Screen[NowPoint].iNum)			
				iScreenNum = Screen[NowPoint].iNum;
		}
		else if(iKeyCode >= KEY_31 && iKeyCode <= KEY_42 )		 /*  ȭ��1	*/
		{				
			if(Screen[NowPoint+1].iNum)			
				iScreenNum = Screen[NowPoint+1].iNum;
		}
		else if(iKeyCode >= KEY_46 && iKeyCode <= KEY_57 )		 /*  ȭ��2	*/
		{				
			if(Screen[NowPoint+2].iNum)			
				iScreenNum = Screen[NowPoint+2].iNum;
		}
		else if(iKeyCode == KEY_29 || iKeyCode == KEY_30 ) 		/* UP_KEY */
		{				
			if(NowPoint > 0)
			{
				NowPoint--;
				BaseScreenNumDisplay(TLineCnt,NowPoint);
			}
			iKeyFlag = 0;
			KerRepeatFlag = 1;
		}
		else if(iKeyCode == KEY_59 || iKeyCode == KEY_60 )		/* DOWN_KEY	 */
		{				
			if(TLineCnt-NowPoint > 3)
			{
				NowPoint++;
				BaseScreenNumDisplay(TLineCnt,NowPoint);
			}
			iKeyFlag = 0;
			KerRepeatFlag = 1;
		}else if(iKeyCode == KEY_28)  /* ó  �� */ /************************************************************/
		{
			if(NowPoint != 0)
			{
				NowPoint = 0;
				BaseScreenNumDisplay(TLineCnt,NowPoint);
			}
			iKeyFlag = 0;
/*ksc20040624*/ /* ���̽� ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */
/*			KerRepeatFlag = 1;  */
/*ksc20040624*/
		}else if(iKeyCode == KEY_43)  /* ��  �� */
		{
			if(NowPoint != (TLineCnt/2-1) && (TLineCnt/2-1) > 3)
			{
				NowPoint = (TLineCnt/2-1);
				BaseScreenNumDisplay(TLineCnt,NowPoint);
			}
			iKeyFlag = 0;
/*ksc20040624*/ /* ���̽� ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */
/*			KerRepeatFlag = 1;  */
/*ksc20040624*/
		}else if(iKeyCode == KEY_58)  /* ������ */
		{
			
			if(TLineCnt-NowPoint > 3 && TLineCnt > 3)
			{
				NowPoint = TLineCnt-3;
				BaseScreenNumDisplay(TLineCnt,NowPoint);
			}
			iKeyFlag = 0;
/*ksc20040624*/ /* ���̽� ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */
/*			KerRepeatFlag = 1;  */
/*ksc20040624*/
		}/************************************************************/
		else
			iKeyCode= -1;
		iScreenDisp = 0;
		if(iScreenNum > 0)
		{
			iScreenDisp = iScreenNum;
			*iScreenNo = USER_SCREEN_NUM;
			iUserScreenFlag = 1;
		}
	}
	KerRepeatFlag = 0;
	memset(&RepeatInfo,0x00,sizeof(RepeatInfo));
}
/* ****************************************************************************** */
/*  �� �� �� : BaseScreenNumDisplay()											 */
/*  ��    �� : BaseScreen ��ȣ�� ǥ��											 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 7�� 2�� (��)												 */
/*  �� �� �� : �� �� �� 														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void		BaseScreenNumDisplay(int TLineCnt, int iStartNum)
{
	short		i;
	short		j;
	short		iCnt;
	short		iNumY;
	char		ScreenNum[40];
	char		BaseTitle[33];

	iCnt = 0;
	if(iBaseScreenCnt>0)
	{
		for(i=0;i<3;i++)
		{
			iCnt = 0;
			memset(ScreenNum,0x00,sizeof(ScreenNum));
			memset(BaseTitle,0x00,sizeof(BaseTitle));
			iNumY = (i*18);
			AreaClear(2,25+iNumY,195,39+iNumY,0);
			if(Screen[iStartNum+i].chTitle)
				memcpy(BaseTitle,Screen[iStartNum+i].chTitle,32);
			sprintf(ScreenNum,"%3d %s",Screen[iStartNum+i].iNum,BaseTitle);
			if(strlen(ScreenNum)>24)
			{
				memset(ScreenNum+24,0x00,2);
				for(j=0;j<24;j++)
				{
					if(ScreenNum[j]>0x00 && ScreenNum[j]<0x7f)
						iCnt++;
					else
						j++;

				}
				if(iCnt%2 == 1)	/* ������ �ڸ��� 2Byte �����̾... */
				{
					memset(ScreenNum+23,0x00,1);
				}
			}
			DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, ScreenNum, 1, 1, NON_TRANS,T_WHITE,T_BLACK);
			if(iStartNum+i+1 >= iBaseScreenCnt)
				break;
		}
	}
	ScroolBarDisplay(TLineCnt,iStartNum);
	DrawLcdBank1();
}
#endif
