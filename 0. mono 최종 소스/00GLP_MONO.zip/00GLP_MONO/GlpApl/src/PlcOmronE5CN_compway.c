/************************************************/
/*	PLC ����M �v���O����(OMRON E5XX [E5AN/E5EN/E5CN/E5GN] )		*/
/*	2003.5.31									*/
/************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

#define	MAX_RTY_COUNT		3	/* Retry count */

#define	MAX_BITCNT			80	/* �ѹ��� ������ �ִ� �ִ� ��Ʈī��Ʈ, ����� ����*/
#define	MAX_WORDCNT			32	/* �ִ� ���� ī��Ʈ */

#define	MAX_MON_BITCNT_PKG	20	/* ��Ʈ ����� */
#define	MAX_MON_BITCNT		80	/* ��Ʈ ����� */

#define	ONE_MON_WORDCNT		16	/* ����� �ѹ��� ����Ҽ� �ִ� �ִ� ����� */
#define	MAX_MON_WORDCNT		64	/* ����� ��� ������ �ִ� ����� */

#define	MAX_PBITCNT			16  /* ��Ʈ ���� */
#define	MAX_PWORDCNT		16	/* ���� ���� */

#define	MAX_WORD_CONT_CNT	4	/* ���� ���� */
#define	MAX_BIT_CONT_CNT	4	/* ��Ʈ ���� */

#ifndef	WIN32
#pragma	section PlcProc
#endif


	int			gSetNumBit;
	int			gSetNumWord;


/**************************************/
extern	int	Hex2nBin(char *buff,int cnt);
extern	int	Hex2Bin(char *buff);
extern	unsigned int LHexAsToBin(char *buff, int cnt);
extern	void	SendPLCPCData( void );
extern	int	SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode);
extern	int	SendPLC2PCData( int mode );
extern	int	SendPC2PLCData( int mode );
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	int	GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address);
extern	void	RtsOnOffSet(int type,int mode);
#ifdef	WIN32
extern int __cdecl Delay(int);
extern unsigned int __cdecl ReadSignal(int);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	PlcDevInit( void );
extern	unsigned char			GpFont[0x200000];
#else
#define SGN_PLC		0
#endif

/**************************************/


/****************************** for Window **********************/
/********************************************/
/*	�O���֐�								*/
/********************************************/
#ifdef	WIN32
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
void	B_SendPLCPCData( void )
{
	SendPLCPCData();
}
int	B_SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode)
{
	return(SendRecPLC(mode,rData,Cnt,rmode));
}
int	B_SendPLC2PCData( int mode )
{
	return(SendPLC2PCData(mode ));
}
int	B_SendPC2PLCData( int mode )
{
	return(SendPC2PLCData(mode ));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
int	B_GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address)
{
	return(GetDevNamePLCAddr(bFlag,src,obj,DevInfo,Address));
}
void	B_RtsOnOffSet(int type,int mode)
{
	RtsOnOffSet(type,mode);
}
#endif

/********************************************/
/* PLC-Program Title */
#ifdef	WIN32
char Title[32]= {
	"PLCPROC OMRON E5XX"
};
#else
const char Title[32]= {
	"PLCPROC OMRON E5XX"
};
#endif
#ifdef	WIN32
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#endif
/********************************/
/*	E5XX Series					*/
/********************************/
char	*CommTbl[6]={
		"0101",		/*0 �б� */
		"0102",		/*1 ���� */
		"0503",		/*2 ��Ʈ�ѷ� �Ӽ� �б� */
		"0601",		/*3 ��Ʈ�ѷ� ���� �б� */
		"0801",		/*4 ���ں� �׽�Ʈ */
		"3005",		/*5 ���� ���� */
};


const	unsigned char PLCIndexTable[256]={
	/* BIT */
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0xff,0x02,0x03,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x04,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0x05,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x06,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x07,
	/* WORD */
	0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0xff,0x02,0x03,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x04,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0x05,0x06,0x07,0x08,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x09,0x0a,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x0b,0x0c,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0x0d,0x0e,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x0f,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
};



const	int PLCLowHighFlag= 0;				/* 0:L-H,1:H-L */
const	int	PLC_K3P_SereaseByteCnt= 8;
const	DEV_PC_TBL	PLC_K3P_SereaseByte[32]=
	{
		{1,0x10,{'P',  0, 0},0x85,0x00000000,0x0000063f},
		{1,0x18,{'M',  0, 0},0x85,0x00000000,0x0000191f},
		{1,0x1a,{'K',  0, 0},0x85,0x00000000,0x0000031f},
		{1,0x1b,{'F',  0, 0},0x85,0x00000000,0x0000063f},
		{1,0x28,{'L',  0, 0},0x85,0x00000000,0x0000063f},
		{1,0x34,{'T',  0, 0},0x84,0x00000000,0x00000191},
		{1,0x50,{'C',  0, 0},0x84,0x00000000,0x00000255},
		{1,0x7f,{'U','B', 0},0x88,0x00000000,0x00001024},
	};
const	int	PLC_K3P_SereaseWordCnt= 16;
const	DEV_PC_TBL	PLC_K3P_SereaseWord[32]=
	{
		{2,(unsigned char)0x80,{'P',  0, 0},0x84,0x00000000,0x00000063},
		{2,(unsigned char)0x88,{'M',  0, 0},0x84,0x00000000,0x00000191},
		{2,(unsigned char)0x8a,{'K',  0, 0},0x84,0x00000000,0x00000031},
		{2,(unsigned char)0x8b,{'F',  0, 0},0x84,0x00000000,0x00000063},
		{2,(unsigned char)0x98,{'L',  0, 0},0x84,0x00000000,0x00000063},
		{2,(unsigned char)0xa2,{'T',  0, 0},0xc4,0x00000192,0x00000239},
		{2,(unsigned char)0xa3,{'T',  0, 0},0xc4,0x00000240,0x00000255},
		{2,(unsigned char)0xa4,{'T',  0, 0},0xc4,0x00000000,0x00000143},
		{2,(unsigned char)0xa5,{'T',  0, 0},0xc4,0x00000144,0x00000191},
		{2,(unsigned char)0xb0,{'C',  0, 0},0xc4,0x00000000,0x00000191},
		{2,(unsigned char)0xb1,{'C',  0, 0},0xa4,0x00000192,0x00000255},
		{2,(unsigned char)0xc0,{'D',  0, 0},0xa4,0x00000000,0x00005999},
		{2,(unsigned char)0xc1,{'D',  0, 0},0xa4,0x00006000,0x00009999},
		{2,(unsigned char)0xd4,{'S',  0, 0},0xa4,0x00000000,0x00000079},
		{2,(unsigned char)0xd5,{'S',  0, 0},0xa4,0x00000000,0x00000099},
		{2,(unsigned char)0xef,{'U','W', 0},0x88,0x00000000,0x00001024},
	};




const	DEV_TBL bPLCDeviceTbl[16] = {
	{"P" ,0x0000,2},
	{"M" ,0x0000,3},
	{"K" ,0x0000,2},
	{"F" ,0x0000,2},
	{"L" ,0x0000,2},
	{"T" ,0x0000,3},
	{"C" ,0x0000,3},
/*	{"S" ,0x6400,5},*/
	{"GB" ,    0,4},
};
const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"P" ,0x0000,2},
	{"M" ,0x0000,3},
	{"K" ,0x0000,2},
	{"F" ,0x0000,2},
	{"L" ,0x0000,2},
	{"D" ,0x0000,4},
	{"T" ,0x0000,3},
	{"C" ,0x0000,3},
	{"S" ,0x0000,2},
	{"GD" ,    0,4},
};


/************************************/
/* ��M�v���g�R��					*/
/************************************/
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/

int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(data){
	case STX:
	case ENQ:
	case ACK:
	case NAK:
		*RecCnt= 0;			/* �`���X�^�[�g */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 1;
		break;
	default:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		switch(*CommMode){
		case 1:
			if((data == EOT) || (data == ETX)){
				*CommMode = 2;
			}
			break;
		case 2:		/* BCC1 */
			*CommMode = 0;
			ret = 0;	
			break;
		}
		break;
	}
	return(ret);
}




/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	switch(*CommMode){
	case 0:		/* Normal */
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:		/* Thru Mode */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			if((data == EOT) || (data == ETX)){
				*CommMode = 99;
				ret = 0;	/* Pendding Req */
			}
		}else{
			*CommMode = 0;
		}
		break;
	}
	return(ret);
}

/************************************/
/* ���ʏ���							*/
/************************************/
int	Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
void	Bin2Hex(int data,int cnt,char *buff)
{
	int		i;
	unsigned int AndData;

	AndData= 0x000f;
	for(i= 1; i < cnt; i++){
		AndData= AndData << 4;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= Bin2Hex1((data & AndData) >> ((cnt- i- 1)*4));
		AndData = AndData >> 4;
	}
	buff[i]= 0;
}
void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	if(data < 0){			/* - check 041116 */
		
		data *= -1;
		buff[0]= '-';
		for(i= 1; i < cnt+1; i++){								/*cnt+1�̵� ������ */
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}else{
		for(i= 0; i < cnt; i++){
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}
	buff[i]= 0;
}
int	gstrlen(char *buff)
{
	int		i;

	for(i= 0; ; i++){
		if(buff[i] == 0){
			break;
		}
	}
	return(i);
}
void	gmemset(char *buff,int data,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*buff= (char)data;
		buff++;
	}
}
void	gmemcpy(char *obj,char *src,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*obj= *src;
		src++;
		obj++;
	}
}
void	gstrcpy(char *obj,char *src)
{
	int		i;

	for(i= 0; ; i++){
		*obj= *src;
		if(*src == 0){
			break;
		}
		src++;
		obj++;
	}
	*obj= 0;
}
int	gstrcmp(char *src,char *obj)
{
	int		i;
	int		ret;

	ret= NG;
	for(i= 0; ; i++){
		if(src[i] == 0){
			if(obj[i] == 0){
				ret= OK;
			}
			break;
		}
		if(obj[i] == 0){
			break;
		}
		if(src[i] != obj[i]){
			break;
		}
	}
	return(ret);
}
int	gstrncmp(char *src,char *obj,int cnt)
{
	int		i;
	int		ret;

	ret= OK;
	for(i= 0; i < cnt; i++){
		if(src[i] != obj[i]){
			ret= NG;
			break;
		}
	}
	return(ret);
}
void	gstrcat(char *src,char *obj)
{
	int		i;

	for(i= 0; ; i++){
		if(*src == 0){
			break;
		}
		src++;
	}
	for(i= 0; ; i++){
		if(*obj == 0){
			*src= 0;
			break;
		}
		*src= *obj;
		src++;
		obj++;
	}
}
int	gatoi(char *buff)
{
	char	c;
	int	ret;
	int flag;

	ret= 0;
	flag= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){
			break;
		}
		if((c >= '0') && (c <= '9')){
			ret= ret*10;
			ret+= c- '0';
		}else{
			if(c == '+'){
				continue;
			}
			if(c == '-'){
				flag= 1;
				continue;
			}
			break;
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}

unsigned int	Bcd2Asc(int data,int keta,char *buff)
{
	int		i;
	unsigned int	ret;

	ret= 0;
	for(i= 0; i < keta; i++){
		buff[keta- i- 1]= (data & 0x0f) + '0';
		data = data >> 4;
	}
	buff[keta]= 0;
	return(ret);
}

unsigned int	Bin2Bcd(int data)
{
	int		i;
	unsigned int	ret;

	ret= 0;
	for(i= 0; i < 8; i++){
		ret |= (data % 10) << (i*4);
		data = data / 10;
		if(data == 0){
			break;
		}
	}
	return(ret);
}
unsigned int	BcdAddBcd(unsigned int data1,unsigned int data2)
{
	int		i;
	int				flag;
	unsigned int	ret;
	unsigned int	work;

	ret= 0;
	flag= 0;
	for(i= 0; i < 8; i++){
		work= (data1 & 0x0f) + (data2 & 0x0f) + flag;
		flag= work / 10;
		ret |= (work % 10) << (i * 4);
		data1 = data1 >> 4;
		data2 = data2 >> 4;
		if((data1 == 0) && (data2 == 0)){
			if(flag != 0){
				ret |= 1 << ((i+1) * 4);
			}
			break;
		}
	}
	return(ret);
}





/****************************/
/* Make Check SUM For PLC	*/
/* XOR [ Node Num ----> ETX ]
/****************************/
int SetPLCBCC(char *buff,int cnt,unsigned char *OutBuf)
{
	int		i;
	unsigned char bcc;
	OutBuf[0] = STX;
	for(i = 0; i < cnt; i++){
		OutBuf[i+1] = buff[i];
	}
	OutBuf[cnt+1] = ETX;

	bcc = 0;
	for(i = 0; i < cnt+1; i++){
		bcc = bcc ^ OutBuf[i+1];
	}
	/*sprintf((char *)&OutBuf[cnt+1],"%02X",bcc&0x00ff);*/
	Bin2Hex(bcc&0x00ff,1,(char *)&OutBuf[cnt+2]);
	/*OutBuf[cnt+2] = bcc;*/
	return(cnt + 3);
}


/************************************/
/*	PLC Send						*/
/************************************/
int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		i;
	int		ret;
	int		rty_cnt;
	unsigned char bcc;
	unsigned char bcc1;

	PlcCommCnt= SetPLCBCC((char *)combuf,gstrlen(combuf),PlcSendBuff);
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
		ret= B_SendRecPLC(mode,rData,Cnt,rmode);
		if(ret == 0){
			/* DATA->EOT(SUM) */
			bcc= 0;
			for(i = 0; i < *Cnt-2; i++){
				bcc = bcc ^ rData[i+1];
			}
/*			bcc1= (unsigned char)B_Hex2Bin((char *)&rData[*Cnt-1]);	*/
			bcc1= rData[*Cnt-1];
			if(bcc != bcc1){
				ret= NG; /* NG = -1; */
			}
		}
		if(ret == OK){
			break;
		}
	}
	return(ret);
}




int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;

	PlcCommCnt= SetPLCBCC((char *)combuf,gstrlen(combuf),PlcSendBuff);
	ret= B_SendRecPLC(mode,rData,Cnt,rmode);
	return(ret);
}



/********************************************/
/*	Connection Proc							*/
/*	*PlcType:[0]->PlcType					*/
/*	         [1]->MyStation					*/
/*	         [2]->DstStation				*/
/********************************************/
int	Connection( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;
	char	buff[32];


	/* �������̃{�[���[�g */
	if((iConnect & 1) == 0){		/* RS-232C */
#ifdef	WIN32
		SioPCMode= 0;	/* 0 �϶� 9600, 7, 2 */
		SioPCOpenFlag= 1;	
#else
		B_RsModeSet(RS_PC,RS_INIT,RS_9600,RS_DATA8,RS_NONE);	/* ���� ��⿡���� ��ż��� */ 
#endif
	}else{						/* RS-422 */
#ifdef	WIN32
		SioPLCMode= 0;	/* 0 �϶� 9600, 7, 2 */
		SioPLCOpenFlag= 1;	
#else
		B_RsModeSet(RS_PLC,RS_INIT,RS_9600,RS_DATA8,RS_NONE);
#endif
	}
#ifdef	WIN32
	while(1){
		if(SioPLCOpenFlag == 0){
			break;
		}
		B_Delay(10);
	}
#endif
	B_Delay(500);


#ifdef	OLD
	/* PLC Connect Check */
	/* Node Num	+ Sub Add	+ SID	+ Command Text */
	/* 2Byte	+ 2Byte		+ 1Byte	+ 4Byte */
	GrpPLCcombuf[0]= '0';	/* Node Num */
	GrpPLCcombuf[1]= '1';	
	GrpPLCcombuf[2]= '0';	/* Sub Add */
	GrpPLCcombuf[3]= '0';
	GrpPLCcombuf[4]= '0';	/* SID */
	GrpPLCcombuf[5]= '0';	/* Command Text */
	GrpPLCcombuf[6]= '5';	
	GrpPLCcombuf[7]= '0';
	GrpPLCcombuf[8]= '3';
	GrpPLCcombuf[9]= 0;
#endif

	Bin2Hex(*(PlcType+2),2,buff);
	gstrcat(buff,"000");
	gstrcat(buff,CommTbl[2]);
	ret= SendRecPLCWithBCCCont(2,buff,GrpPLCcombuf,&Cnt,0);		

	if((ret == 0) && (GrpPLCcombuf[0] == STX)){
		ret= 1;
	}else{
		ret= 0;
	}
	return(ret);
}


void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	WIN32
#ifndef	OLD
	*PLCByteCnt= (int)GpFont[PLC_DEV_TBLBCT];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC_DEV_TBLBYT];
	*PLCWordCnt= (int)GpFont[PLC_DEV_TBLWCT];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC_DEV_TBLWOR];
	*PLCIndex= (unsigned char *)&GpFont[PLC_DEV_TBLIDX];
#else
	*PLCByteCnt= (int)PLC_K3P_SereaseByteCnt;
	*PLCWordCnt= (int)PLC_K3P_SereaseWordCnt;		/*  */
	*ByteTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseByte[0];
	*WordTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseWord[0];
	*PLCIndex= (unsigned char *)&PLCIndexTable[0];
#endif
#else
#ifndef	OLD
	*PLCByteCnt= *(int *)PLC_DEV_TBLBCT;
	*ByteTbl= (DEV_PC_TBL *)PLC_DEV_TBLBYT;
	*PLCWordCnt= *(int *)PLC_DEV_TBLWCT;		/*  */
	*WordTbl= (DEV_PC_TBL *)PLC_DEV_TBLWOR;
	*PLCIndex= (unsigned char *)PLC_DEV_TBLIDX;
#else
	*PLCByteCnt= (int)PLC_K3P_SereaseByteCnt;
	*PLCWordCnt= (int)PLC_K3P_SereaseWordCnt;		/*  */
	*ByteTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseByte[0];
	*WordTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseWord[0];
	*PLCIndex= (unsigned char *)&PLCIndexTable[0];
#endif
#endif
}


/************************************/
/* Get Device Name					*/
/************************************/
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}


/************************************/
/*	Device & Address Change			*/
/************************************/
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
int	MakePLCDevAddress(int mode, char *pDevice, int Address, char *Device)
{
	int		i;
	int		ret;
	int		OffSet;

	ret = -1;
	/* Device Name */
	if(B_GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&i,&Address) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(gstrcmp(bPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
/*				*DevAddr = OffSet+ Address;*/
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(gstrcmp(wPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
/*				*DevAddr = OffSet+ Address;*/
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}


/************************************/
/*	Device & Address Change			*/
/************************************/
int	plcGetDevAddInf(int bwflag,unsigned char *src,int *Keta,int *LowMax)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			*Keta= ByteTbl[PLCIndex[src[0]]].LowKeta;
			*LowMax= ByteTbl[PLCIndex[src[0]]].LowDeviceMax;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			*Keta= WordTbl[PLCIndex[src[0]]].LowKeta;
			*LowMax= WordTbl[PLCIndex[src[0]]].LowDeviceMax;
			ret= 0;
		}
	}
	return(ret);
}
void	plcChangeAddressUsr(int Digit1,int Digit0, int *Address,int LowMax,int Keta)
{
	int		i;
	unsigned int	work;
	unsigned int	work1;
	unsigned int	work2;

	work= (unsigned int)*Address;
	work1= work%LowMax;				/* 1Keta */
	work2= 0;
	for(i = 0;i < Keta; i++){
		work2 += (work1 % Digit0) << (i*4);
		work1= work1/Digit0;
	}
	work= work/LowMax;
	for(;i < 8; i++){
		if(work == 0){
			break;
		}
		work2 += (work % Digit1) << (i*4);
		work= work/Digit1;
	}
	*Address= work2;
}
/*********************************************************************/
int	plcSetPLCUsrAddr(int DevInfo,int Address,unsigned char idx,int bFlag)
{
	int		ret;
	int		LowMax;
	int		Keta;

	ret= plcGetDevAddInf(bFlag,&idx,&Keta,&LowMax);
	if(ret == 0){
		LowMax++;
		ret= Address;
		switch(DevInfo & 0x0f){
		case 0:		/* 8/8 */
			plcChangeAddressUsr(8,8,&ret,LowMax,Keta);
			break;
		case 1:		/* 8/10 */
			plcChangeAddressUsr(8,10,&ret,LowMax,Keta);
			break;
		case 2:		/* 8/16 */
			plcChangeAddressUsr(8,16,&ret,LowMax,Keta);
			break;
		case 3:		/* 10/8 */
			plcChangeAddressUsr(10,8,&ret,LowMax,Keta);
			break;
		case 4:		/* 10/10 */
			plcChangeAddressUsr(10,10,&ret,LowMax,Keta);
			break;
		case 5:		/* 10/16 */
			plcChangeAddressUsr(10,16,&ret,LowMax,Keta);
			break;
		case 6:		/* 16/8 */
			plcChangeAddressUsr(16,8,&ret,LowMax,Keta);
			break;
		case 7:		/* 16/10 */
			plcChangeAddressUsr(16,10,&ret,LowMax,Keta);
			break;
		case 8:		/* 16/16 */
/*			ChangeAddressUsr(16,16,&ret,LowMax,Keta);*/
			break;
		case 9:		/* 16 */
			plcChangeAddressUsr(10,10,&ret,10,1);
			break;
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt,int StationNo)
{
	int		ret;
	char	Device[4];
	char	buff[8];

	int		BitAdd;
	int		WordAdd;
	int		WordCnt;
	

	ret= MakePLCDevAddress(mode, pDevice, Address, Device);
	if(ret == 0){



#ifdef	OLD
		DstStationNo= pDevice[4];
		combuff[0]= '%';		/* Start */
		combuff[1]= 'E';		/* SA */
		combuff[2]= 'E';		/* SA */
		combuff[3]= '#';		/* Command */
		combuff[4]= 0;
#endif		
		if(mode == 0){			/* Bit */
			if(sCnt == 1){
				Bin2Hex(Address,4,buff);
		
				gstrcpy(combuff,"00");			/* ���� */
				gstrcat(combuff,CommTbl[0]);	/* Command rSS */
				gstrcat(combuff,"01");			/* ���ϼ� */
				gstrcat(combuff,"07");			/* �������� */
				gstrcat(combuff,"%");				
				gstrcat(combuff,Device);		/* �����̸� */ 
				gstrcat(combuff,"X");			/* Type Bit */ 
				gstrcat(combuff,buff);			/* Address */

#ifdef	OLD				
				gstrcat(combuff,CommTbl[0]);	/* RCS */
				gstrcat(combuff,Device);		/* Device Name */
				if(DeviceFlag == 1){
					Bcd2Asc(Address/16,3,buff);
					gstrcat(combuff,buff);
					work= Address % 16;
					Bin2Hex(work,1,buff);
					gstrcat(combuff,buff);
				}else{			/* T,C */
					Bcd2Asc(Address,4,buff);
					gstrcat(combuff,buff);
				}
#endif
			}else{


				WordAdd = Address/16;	/* ���� ��Ʈ ��巹���� ���ι����� 16���� ������ ���� �����ּҰ� �ȴ� */
				BitAdd =  Address%16;	/* ���� ��Ʈ ��巹���� ���ι����� 16���� ���� �������� ��Ʈ���̴� */
				/* ��Ʈ�� ����� �о� ó���ϹǷ� ���� ��Ʈ ��巹���� ���۹����� ���� ���� ��巹���� ���� �����Ƿ� ������ �ʿ��ؼ� */

/*				UsrAddress= plcSetPLCUsrAddr(DevInfo,WordAdd,pDevice[0],mode);*/
				/* ���� Bin Address�� BCD�� ���� */

				WordCnt = Address/16 + sCnt/16 - WordAdd + 1;


				Bin2Hex(StationNo,2,buff);
				gstrcpy(combuff,buff);			/* ���� */
				gstrcat(combuff,CommTbl[0]);	/* Command 0101 */
				gstrcat(combuff,"C0");			/* �������� */
				Bin2dec(Address,4,buff);			/* Data Count */
				gstrcat(combuff,buff);
				Bin2dec(WordCnt,2,buff);			/* Data Count */
				gstrcat(combuff,buff);
				gstrcat(combuff,"00");	
				gstrcat(combuff,"0000");	

#ifdef	OLD
				gstrcat(combuff,CommTbl[4]);	/* RCC */
				gstrcat(combuff,Device);		/* Device Name */
				eAddress= Address;
				if(DeviceFlag == 1){
					Address = Address >> 4;
				}
				Bcd2Asc(Address,4,buff);
				gstrcat(combuff,buff);

				BinAddress += sCnt- 1;
				Address= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				if(DeviceFlag == 1){
					Address = Address >> 4;
				}
				Bcd2Asc(Address,4,buff);
				gstrcat(combuff,buff);
#endif
			}
		}else{

			/*sprintf(combuff,"rM%s00%02X",abuff,sCnt);*/

			Bin2Hex(StationNo,2,buff);
			gstrcpy(combuff,buff);			/* ���� */
			gstrcat(combuff,CommTbl[0]);	/* Command 0101 */
			gstrcat(combuff,"C0");			/* �������� */
			Bin2dec(Address,4,buff);			/* Data Count */
			gstrcat(combuff,buff);
			gstrcat(combuff,"00");	
			gstrcat(combuff,"0000");	
			
			
#ifdef	OLD			
/*Address= Address << 4;*/
			switch(DeviceFlag){
			case 1:					/* WX,WY,WR,WL */
				gstrcat(combuff,CommTbl[4]);	/* RCC */
				gstrcat(combuff,&Device[1]);		/* Device Name */
				Bcd2Asc(Address,4,buff);
				gstrcat(combuff,buff);
				BinAddress += sCnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,4,buff);
				gstrcat(combuff,buff);
				break;
			case 2:					/* SV */
				gstrcat(combuff,CommTbl[8]);	/* RS */
				Bcd2Asc(Address,4,buff);
				gstrcat(combuff,buff);
				BinAddress += sCnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,4,buff);
				gstrcat(combuff,buff);
				break;
			case 3:					/* EV */
				gstrcat(combuff,CommTbl[10]);	/* RK */
				Bcd2Asc(Address,4,buff);
				gstrcat(combuff,buff);
				BinAddress += sCnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,4,buff);
				gstrcat(combuff,buff);
				break;
			case 4:					/* F(FL) */
			case 5:					/* L(LD) */
			case 6:					/* D(DT) */
				gstrcat(combuff,CommTbl[6]);	/* RD */
				combuff[6]= Device[0];		/* Device Name */
				combuff[7]= 0;
				Bcd2Asc(Address,5,buff);
				gstrcat(combuff,buff);
				BinAddress += sCnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,5,buff);
				gstrcat(combuff,buff);
				break;
			case 7:					/* IX,IY,ID */
				gstrcat(combuff,CommTbl[6]);	/* RD */
				gstrcat(combuff,Device);		/* Device Name */
				gstrcat(combuff,"000000000");
				break;
			}
#endif

		}
	}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
const	iAndData[16]={
	0x0001,0x0002,0x0004,0x0008,0x0010,0x0020,0x0040,0x0080,
	0x0100,0x0200,0x0400,0x0800,0x1000,0x2000,0x4000,0x8000,
};
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j,k;
	int		Cnt,dCnt;
	int		wCnt;
	unsigned char	*SaveAddr;
	unsigned short	rdata;
	char	Device[4];
	int		DevInfo;
	int		Address;
	int		UsrAddress;
	
	int		BitAdd;
	int		WordAdd;
	int		WordCnt;

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		Cnt = mp->mext;
		if(Cnt == 1){
			ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PLCbuf,mp->mext*2,(int)mp->mbuf[4]); 

			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				i= gstrlen((char *)PLCbuf);
				ret= SendRecPLCWithBCC(2,(char *)PLCbuf,(unsigned char *)rDataFx,&i,0);
				if((ret == 0) && (rDataFx[0] == 0x06)){		/* $ */
					if(Cnt == 1){
						for(i = 0; i < Cnt; i++){
							if(rDataFx[i+11] == '1'){
								*(unsigned char *)SaveAddr++ = 1;
							}else{
								*(unsigned char *)SaveAddr++ = 0;
							}
						}
					}else{	

						
						if(DeviceFlag == 1){
							ret= mp->mpar & 0x000f;
						}else{
							ret= mp->mpar;
						}
						wCnt= (Cnt+ret-1) / 16 + 1;
						BitAndData= iAndData[ret];
						for(i= 0,j= 0; i < wCnt; i++){
							rdata = B_LHexAsToBin((char *)&rDataFx[i*4+6],2);
							rdata += B_LHexAsToBin((char *)&rDataFx[i*4+6+2],2) << 8;
							for(k= 0;(j < Cnt) & (k < 16); j++, k++){
								if(rdata & BitAndData){
									*(unsigned char *)SaveAddr++ = 1;
								}else{
									*(unsigned char *)SaveAddr++ = 0;
								}
								BitAndData = BitAndData << 1;
								if(BitAndData == 0x10000){
									BitAndData= 0x0001;
								}
							}
						}
						ret= 0;

					}
				}else{
					ret= -1;
				}
			}
		}else{		/* Bit�� Word�� ���� */

			Address= mp->mpar;			/* BCD Address */
			ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);	
			/* BCD Address�� Bin���� ����, &Address�� ���̳ʸ��� ���ϵ� */
			dCnt= mp->mext;
			/* ���� ��Ʈ �� */

			while(1){
				if(dCnt > MAX_BITCNT){
					dCnt -= MAX_BITCNT;
					mp->mext= MAX_BITCNT;
				}else{
					mp->mext= dCnt;
					dCnt = 0;
				}
				
				WordAdd = Address/16;	/* ���� ��Ʈ ��巹���� ���ι����� 16���� ������ ���� �����ּҰ� �ȴ� */
				BitAdd =  Address%16;	/* ���� ��Ʈ ��巹���� ���ι����� 16���� ���� �������� ��Ʈ���̴� */
				/* ��Ʈ�� ����� �о� ó���ϹǷ� ���� ��Ʈ ��巹���� ���۹����� ���� ���� ��巹���� ���� �����Ƿ� ������ �ʿ��ؼ� */

				WordCnt = (Address/16) + (mp->mext/16) - WordAdd + 1;
				/* ���� �о�;ߵ� ���� ī��Ʈ�� */

				Cnt = mp->mext;
				ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PLCbuf,mp->mext*2,(int)mp->mbuf[4]); 

				SaveAddr = (unsigned char *)mp->mptr;
				if(ret == 0){
					if(SendRecPLCWithBCC(2,(char *)PLCbuf,(unsigned char *)rDataFx,&i,0) == 0){
						if(rDataFx[0] != 0x06){
							ret= -1;
							break;
						}else{
							for(i = 0; i < WordCnt*2; i++){
								rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+10]);
							}
							/* �о�� ����Ÿ�� ����Ʈ ������ ���� ī��Ʈ * 2��ŭ ���̳ʸ��� ��ȯ */
							
							BitAndData = iAndData[BitAdd];

							j= 0;
							rdata= (rDataFx[j+1]) + (rDataFx[j]<< 8);
							/* ���� ����Ʈ ��������Ʈ�� �ٲپ ����Ʈ ����Ÿ�� ���� ����Ÿ�� �ٲ� */
							for(i = 0; i < Cnt; i++){
								if(rdata & BitAndData){
									*(unsigned char *)SaveAddr++ = 1;
								}else{
									*(unsigned char *)SaveAddr++ = 0;
								}
								BitAndData <<= 1;
								if(BitAndData > 0x8000){
									BitAndData = 1;
									j++;
									rdata= (rDataFx[j*2+1]) + (rDataFx[j*2]<< 8);
								}
							}
						}
					}else{
						ret = -1;
						break;
					}
				}
				if(dCnt == 0){
					break;
				}
				Address += MAX_BITCNT;
				mp->mptr= (void *)((char *)mp->mptr + MAX_BITCNT);
			}
		}
		break;
	case PLC_WORD:		/* Word Device */
		Address= mp->mpar;
		ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);
		dCnt= mp->mext;
		while(1){
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
		    ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PLCbuf,mp->mext*2,(int)mp->mbuf[4]); 

			Cnt = mp->mext;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				i= gstrlen((char *)PLCbuf);
				ret= SendRecPLCWithBCC(2,(char *)PLCbuf,(unsigned char *)rDataFx,&i,0);
				if((ret == 0) && (rDataFx[0] == 0x06)){		/* $ */

					for(i = 0; i < Cnt*2; i++){
						rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+ 10]);
						/* ���ŵ���Ÿ�� ���� Hexasc ����Ÿ�� ���̳ʸ��� ��ȯ�ؼ� ���� ���ۿ� ���� */
					}
					for(i = 0; i < Cnt; i++){
						*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
						*(unsigned char *)SaveAddr++ = rDataFx[i*2];
						/* ���ŵ���Ÿ�� APL Address�� ������ ������ �ٲپ �־��� */
					}
				
				}else{
					ret= -1;
					break;
				}
			}
			if(dCnt == 0){
				break;
			}
			Address += MAX_WORDCNT;
			UsrAddress= plcSetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);
			mp->mpar= UsrAddress;
			mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
		}
		break;
	}
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;


	char	Device[4];
	char	buff[8];
	int		BinAddress;
	int		DevInfo;

	BinAddress= Address;
	ret= B_GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&DevInfo,&BinAddress);

	ret= MakePLCDevAddress(mode, pDevice, Address, Device);
	if(ret == 0){

	
#ifdef	OLD		

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt, Device);
		DstStationNo= pDevice[4];
		combuff[0]= '%';		/* Start */
		combuff[1]= 'E';		/* SA */
		combuff[2]= 'E';		/* SA */
		combuff[3]= '#';		/* Command */
		combuff[4]= 0;
#endif

		if(mode == 0){		/* BIT */
			if(Cnt == 1){
				
				Bin2Hex(Address,4,buff);
		
				gstrcpy(combuff,"00");			/* ���� */
				gstrcat(combuff,CommTbl[2]);	/* Command rSS */
				gstrcat(combuff,"01");			/* ���ϼ� */
				gstrcat(combuff,"07");			/* �������� */
				gstrcat(combuff,"%");				
				gstrcat(combuff,Device);		/* �����̸� */ 
				gstrcat(combuff,"X");			/* Type Bit */ 
				gstrcat(combuff,buff);			/* Address */
				Bin2Hex(*data & 0xff,2,buff);
				gstrcat(combuff,buff);
			}

#ifdef	OLD			
			if(Cnt == 1){
				gstrcat(combuff,CommTbl[1]);	/* WCS */
				gstrcat(combuff,Device);		/* Device Name */
				Bcd2Asc(Address/16,3,buff);
				gstrcat(combuff,buff);
				work= Address % 16;
				Bin2Hex(work,1,buff);
				gstrcat(combuff,buff);
				for(i= 0; i < Cnt; i++){
					if(data[i] == 0){
						gstrcat(combuff,"0");
					}else{
						gstrcat(combuff,"1");
					}
				}
			}
#endif

		}else{		/* WORD */

			gstrcpy(combuff,"00");			/* ���� */
			gstrcat(combuff,CommTbl[3]);	/* Command rSB */
			gstrcat(combuff,"07");
			gstrcat(combuff,"%");
			gstrcat(combuff,Device);
			gstrcat(combuff,"W");
			Bin2Hex(Address,4,buff);
			gstrcat(combuff,buff);
			Bin2Hex(Cnt,2,buff);
			gstrcat(combuff,buff);	
			for(i= 0; i < Cnt; i++){
				/*sprintf(buff,"%02X",data[i] & 0xff);*/
				Bin2Hex(data[i*2+1] & 0xff,2,buff);
				gstrcat(combuff,buff);
				Bin2Hex(data[i*2] & 0xff,2,buff);
				gstrcat(combuff,buff);
			}
			
#ifdef	OLD			
			switch(DeviceFlag){
			case 1:					/* WX,WY,WR,WL */
				gstrcat(combuff,CommTbl[5]);	/* WCC */
				gstrcat(combuff,&Device[1]);		/* Device Name */
				Bcd2Asc(Address,4,buff);
				gstrcat(combuff,buff);
				BinAddress += Cnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,4,buff);
				gstrcat(combuff,buff);
				break;
			case 2:					/* SV */
				gstrcat(combuff,CommTbl[9]);	/* WS */
				Bcd2Asc(Address,4,buff);
				gstrcat(combuff,buff);
				BinAddress += Cnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,4,buff);
				gstrcat(combuff,buff);
				break;
			case 3:					/* EV */
				gstrcat(combuff,CommTbl[11]);	/* WK */
				Bcd2Asc(Address,4,buff);
				gstrcat(combuff,buff);
				BinAddress += Cnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,4,buff);
				gstrcat(combuff,buff);
				break;
			case 4:					/* F(FL) */
			case 5:					/* L(Ld) */
			case 6:					/* D(DT) */
				gstrcat(combuff,CommTbl[7]);	/* WD */
				combuff[6]= Device[0];		/* Device Name */
				combuff[7]= 0;
				Bcd2Asc(Address,5,buff);
				gstrcat(combuff,buff);
				BinAddress += Cnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,5,buff);
				gstrcat(combuff,buff);
				break;
			case 7:					/* IX,IY,ID */
				gstrcat(combuff,CommTbl[7]);	/* WD */
				gstrcat(combuff,Device);		/* Device Name */
				gstrcat(combuff,"000000000");
				break;
			}
			for(i= 0; i < Cnt*2; i++){
				Bin2Hex(data[i],2,buff);
				gstrcat(combuff,buff);
			}
#endif
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,dCnt;
	char	Device[4];
	int		DevInfo;
	int		Address;
	int		UsrAddress;

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCbuf,(char *)mp->mptr);
		if(ret == 0){
			Cnt= gstrlen((char *)PLCbuf);
			ret= SendRecPLCWithBCC(2,(char *)PLCbuf,rDataFx,&Cnt,0);
		}else if(ret == 1){		/* ����Address */
			ret= -1;
		}
		break;
	case PLC_WORD:		/* Word Device */
		Address= mp->mpar;
		ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);
		dCnt= mp->mext;
		while(1){
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCbuf,(char *)mp->mptr);
			if(ret == 0){
				Cnt= gstrlen((char *)PLCbuf);
				ret= SendRecPLCWithBCC(2,(char *)PLCbuf,rDataFx,&Cnt,0);
			}else if(ret == 1){		/* ����Address */
				ret= -1;
				break;
			}
			if(dCnt == 0){
				break;
			}
			Address += MAX_WORDCNT;
			UsrAddress= plcSetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);
			mp->mpar= UsrAddress;
			mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
		}
		break;
	}
	return(ret);
}
/************************************************/
/*	�O���[�v����								*/
/************************************************/
int	MakePLCGroupAddr(int mode, int First, char *pDevice, int Address, char *combuff)
{
	int		ret;

	char	Device[4];
	char	buff[8];



	ret= MakePLCDevAddress(mode, pDevice, Address, Device);
	if(ret == 0){





		if(First == 0){

#ifdef	OLD			
			DstStationNo= pDevice[4];
			combuff[0]= '%';		/* Start */
			combuff[1]= 'E';		/* SA */
			combuff[2]= 'E';		/* SA */
			combuff[3]= '#';		/* Command */
			combuff[4]= 0;
			if(mode == 0){		/* BIT */
				gstrcat(combuff,CommTbl[12]);	/* MC */
			}else{
				gstrcat(combuff,CommTbl[13]);	/* MD */
			}
#endif

		}
		if(mode == 0){		/* BIT */


			if(First == 0){
				gSetNumBit++;
				gstrcpy(combuff,"00");			/* ���� */
				gstrcat(combuff,CommTbl[4]);	/* Command x */
				Bin2Hex(gSetNumBit,2,buff);		/* ��Ϲ�ȣ */
				gstrcat(combuff,buff);
				gstrcat(combuff,"RSS");	/* ��� ���ɾ� */
/*				gstrcat(combuff,CommTbl[0]);	/* ��� ���ɾ� */
				Bin2dec(First+1,2,buff);		/* ���ϼ� */	
				gstrcat(combuff,buff);
			}




			gstrcat(combuff,"07");			/* �������� */
			gstrcat(combuff,"%");				
			gstrcat(combuff,Device);		/* �����̸� */ 
			gstrcat(combuff,"X");			/* Type Bit */ 
			Bin2Hex(Address,4,buff);			/* Address */	
			gstrcat(combuff,buff);

			Bin2Hex(First+1,2,buff);			/* ���ϼ� */	
			combuff[8] = buff[0];
			combuff[9] = buff[1];
#ifdef	OLD			
			gstrcat(combuff,Device);		/* Device Name */
			if(DeviceFlag == 1){
				Bcd2Asc(Address/16,3,buff);
				gstrcat(combuff,buff);
				work= Address % 16;
				Bin2Hex(work,1,buff);
				gstrcat(combuff,buff);
			}else{			/* T,C */
				Bcd2Asc(Address,4,buff);
				gstrcat(combuff,buff);
			}
#endif

		}else{		/* WORD */

			if(First == 0){
				gSetNumWord++;
				gstrcpy(combuff,"00");			/* ���� */
				gstrcat(combuff,CommTbl[4]);	/* Command x */
				Bin2Hex(gSetNumWord+gSetNumBit,2,buff);		/* ��Ϲ�ȣ */
				gstrcat(combuff,buff);
				gstrcat(combuff,"RSS");	/* ��� ���ɾ� */
/*				gstrcat(combuff,CommTbl[0]);	/* ��� ���ɾ� */
				Bin2dec(First+1,2,buff);		/* ���ϼ� */	
				gstrcat(combuff,buff);
			}

			gstrcat(combuff,"07");			/* �������� */
			gstrcat(combuff,"%");				
			gstrcat(combuff,Device);		/* �����̸� */ 
			gstrcat(combuff,"W");			/* Type Bit */ 
			Bin2Hex(Address,4,buff);			/* Address */	
			gstrcat(combuff,buff);

			Bin2Hex(First+1,2,buff);			/* ���ϼ� */	
			combuff[8] = buff[0];
			combuff[9] = buff[1];			
#ifdef	OLD			
			switch(DeviceFlag){
			case 1:					/* WX,WY,WR,WL */
				gstrcat(combuff,&Device[0]);		/* Device Name */
				Bcd2Asc(Address,4,buff);
				gstrcat(combuff,buff);
				break;
			case 2:					/* SV */
				gstrcat(combuff,"S");	/* WS */
				Bcd2Asc(Address,5,buff);
				gstrcat(combuff,buff);
				break;
			case 3:					/* EV */
				gstrcat(combuff,"K");	/* WK */
				Bcd2Asc(Address,5,buff);
				gstrcat(combuff,buff);
				break;
			case 4:					/* F(FL) */
			case 5:					/* L(Ld) */
			case 6:					/* D(DT) */
				Device[0]= Device[0];		/* Device Name */
				Device[1]= 0;
				gstrcat(combuff,Device);
				Bcd2Asc(Address,5,buff);
				gstrcat(combuff,buff);
				break;
			case 7:					/* IX,IY,ID */
				gstrcat(combuff,&Device[0]);		/* Device Name */
				gstrcat(combuff,"0000");
				break;
			}
#endif
		}
	}
	return(ret);
}
/****************************************/
/*	Monitor Reset�쐬					*/
/****************************************/
void	RestMonitor(void)
{
#ifdef	OLD	
	int		ret;
	int		Cnt;

	PLCbuf[0]= '%';		/* Start */
	PLCbuf[1]= 'E';		/* SA */
	PLCbuf[2]= 'E';		/* SA */
	PLCbuf[3]= '#';		/* Command */
	PLCbuf[4]= 'M';
	PLCbuf[5]= 'C';
	PLCbuf[6]= 'F';
	PLCbuf[7]= 'F';
	PLCbuf[8]= 'F';
	PLCbuf[9]= 'F';
	PLCbuf[10]= 'F';
	PLCbuf[11]= 'F';
	PLCbuf[12]= 0;
	Cnt= 12;
	ret= SendRecPLCWithBCC(2,(char *)PLCbuf,(unsigned char *)PlcSendDevData,&Cnt,0);
	PLCbuf[0]= '%';		/* Start */
	PLCbuf[1]= 'E';		/* SA */
	PLCbuf[2]= 'E';		/* SA */
	PLCbuf[3]= '#';		/* Command */
	PLCbuf[4]= 'M';
	PLCbuf[5]= 'D';
	PLCbuf[6]= 'F';
	PLCbuf[7]= 'F';
	PLCbuf[8]= 'F';
	PLCbuf[9]= 'F';
	PLCbuf[10]= 'F';
	PLCbuf[11]= 'F';
	PLCbuf[12]= 0;
	Cnt= 12;
	ret= SendRecPLCWithBCC(2,(char *)PLCbuf,(unsigned char *)PlcSendDevData,&Cnt,0);
#endif
}
/****************************************/
/*	Bit Monitor�쐬						*/
/****************************************/
void	MakeBitMonitor(void)
{
	int		i,ret;
	int		StartIdx;

	StartIdx= 0;
	/*Bit Device Set*/
	gmemset((char *)GrpPLCcombuf,0,sizeof(GrpPLCcombuf));
	for(i = 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].DevFlag == 0) &&				/* 0:Bit / 1:Word */
			(DeviceDataSys[i].SameDevInf == 0) &&			/* 0:Start Device 1:Same Device, 2:Continue Device, 3:Patten Device */ 
			(DeviceDataSys[i].Continus == 0) &&				/* Continue or Patten */
			(DeviceDataSys[i].DevName[0] != 0x7f) &&		/* DevName[0] : Device Index */
			(DeviceDataSys[i].DevCnt == 1)){				/* Device Count */
			if(MakePLCGroupAddr(DeviceDataSys[i].DevFlag, StartIdx, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, (char *)GrpPLCcombuf) != 0){
				continue;	/* ��������� ��Ʈ ����̽� ��� */
			}
			gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
			DeviceDataSys[i].SameDevInf= -1;
			gDeviceCnt++;
			gDeviceCntBit++;
			StartIdx++;
			if(((gDeviceCntBit % MAX_MON_BITCNT_PKG) == 0) && (gDeviceCntBit != 0)){
				StartIdx= gstrlen((char *)GrpPLCcombuf);
				ret= SendRecPLCWithBCC(2,(char *)GrpPLCcombuf,PLCbuf,&StartIdx,0);
				StartIdx= 0;
				if(gDeviceCntBit >= MAX_MON_BITCNT){
					break;
				}
			}
		}
	}
	if(StartIdx != 0){
		StartIdx= gstrlen((char *)GrpPLCcombuf);
		ret= SendRecPLCWithBCC(2,(char *)GrpPLCcombuf,PLCbuf,&StartIdx,0);
	}
}
/****************************************/
/*	Word Monitor�쐬						*/
/****************************************/
void	MakeWordMonitor(void)
{
	int		i,ret;
	int		StartIdx;
	/*Word MONITOR Device Set*/
	StartIdx= 0;
	gmemset((char *)GrpPLCcombuf,0,sizeof(GrpPLCcombuf));
	for(i = 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].DevFlag == 1) &&
			(DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus == 0) &&
			(DeviceDataSys[i].DevName[0] != (unsigned char)0xef) &&
			(DeviceDataSys[i].DevCnt == 1)){
			if(MakePLCGroupAddr(DeviceDataSys[i].DevFlag, StartIdx, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, (char *)GrpPLCcombuf) != 0){
				continue;
			}
			gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
			DeviceDataSys[i].SameDevInf= -1;
			gDeviceCnt++;
			gDeviceCntWord++;
			StartIdx++;

/* ���� ����� ��� ������ �ִ� ��ϰ����� �ʰ� ������ ����� */
			

			if(StartIdx >= ONE_MON_WORDCNT){

				StartIdx= gstrlen((char *)GrpPLCcombuf);
				ret= SendRecPLCWithBCC(2,(char *)GrpPLCcombuf,PLCbuf,&StartIdx,0);

				StartIdx= 0;
				if(gDeviceCnt+ONE_MON_WORDCNT >= MAX_MON_WORDCNT){				
					break;
				}	
			}
		}
	}
/* ���� ����� ����� ������ �ϳ��� ������ ����� �� */
	if(StartIdx != 0){
		StartIdx= gstrlen((char *)GrpPLCcombuf);
		ret= SendRecPLCWithBCC(2,(char *)GrpPLCcombuf,PLCbuf,&StartIdx,0);
	}
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k,ret;
	int		Address;
	int		MyAddress;
	int		DevInfo;
	char	Device[4];

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);
						MyAddress= DeviceDataSys[i].DevAddress;
						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k,ret;
	int		Address;
	int		MyAddress;
	int		DevInfo;
	char	Device[4];
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);
					MyAddress= DeviceDataSys[i].DevAddress;
					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN								*/
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{
	int		i,j,k,ret;
	int		Address;
	int		MyAddress;
	int		DevInfo;
	char	Device[4];

	for(i= 1; i < Bit_Cnt; i++){	/* BIT Start */
		if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].Patarn == 0) && 
			(DeviceDataSys[i].DevCnt == 1) && (DeviceDataSys[i].Continus == 0)){
			for(j= 0; j < i; j++){
				if((DeviceDataSys[j].SameDevInf == 0) &&
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].Patarn == 0) &&
					(DeviceDataSys[j].DevCnt == 1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);
					MyAddress= DeviceDataSys[i].DevAddress;
					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);
					if(((MyAddress+ DeviceDataSys[j].DevCnt)- Address) < MAX_PBITCNT){
						DeviceDataSys[j].Order= i+1;		/* Next Device */
						DeviceDataSys[j].Continus = (MyAddress+ DeviceDataSys[j].DevCnt)- Address;	/* First */
						DeviceDataSys[j].Patarn= 1;

						DeviceDataSys[i].SameDevInf= 3;
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						DeviceDataSys[i].Patarn= MyAddress- Address+ 1;
						break;
					}
				}else{
					if(((DeviceDataSys[j].SameDevInf == 0) && (DeviceDataSys[j].Patarn != 0)) &&
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);
						MyAddress= DeviceDataSys[i].DevAddress;
						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);
						if(((MyAddress+ DeviceDataSys[j].DevCnt)- Address) < MAX_PBITCNT){
							/* �擪�̓ǂݍ��ݐ����X�V���� */
							DeviceDataSys[j].Continus = (MyAddress+ DeviceDataSys[j].DevCnt)- Address;	/* First */
							k= j;
							while(1){
								if(DeviceDataSys[k].Order == -1){
									break;
								}
								k= DeviceDataSys[k].Order- 1;
							}
							DeviceDataSys[k].Order= i+1;		/* Next Device */

							DeviceDataSys[i].SameDevInf= 3;
							DeviceDataSys[i].Continus= k+ 1;	/* Befor Device */
							DeviceDataSys[i].Patarn= MyAddress- Address+ 1;
							break;
						}
					}
				}
			}
		}
	}
}
/***************************************************/
/*	WORD GROUP-PATARN								*/
/***************************************************/
void	MakeWordPatarn(int Start)
{
	int		i,j,k,ret;
	int		Address;
	int		MyAddress;
	int		DevInfo;
	char	Device[4];

	for(i= Start+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].Patarn == 0) && (DeviceDataSys[i].Continus == 0)){
			for(j= Start; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) && ((DeviceDataSys[j].Order == -1) && (DeviceDataSys[j].Patarn == 0))) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);
					MyAddress= DeviceDataSys[i].DevAddress;
					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);
					if(((MyAddress+ DeviceDataSys[j].DevCnt)- Address) < MAX_PWORDCNT){
						DeviceDataSys[j].Order= i+1;		/* Next Device */
						DeviceDataSys[j].Continus = (MyAddress+ DeviceDataSys[j].DevCnt)- Address;	/* First */
						DeviceDataSys[j].Patarn= 1;

						DeviceDataSys[i].SameDevInf= 3;
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						DeviceDataSys[i].Patarn= MyAddress- Address;
						break;
					}
				}else{
					if(((DeviceDataSys[j].SameDevInf == 0) && (DeviceDataSys[j].Patarn != 0)) &&
						(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);
						MyAddress= DeviceDataSys[i].DevAddress;
						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);
						if(((MyAddress+ DeviceDataSys[j].DevCnt)- Address) < MAX_PWORDCNT){
							/* �擪 */
							DeviceDataSys[j].Continus = (MyAddress+ DeviceDataSys[j].DevCnt)- Address;	/* First */
							k= j;
							while(1){
								if(DeviceDataSys[k].Order == -1){
									break;
								}
								k= DeviceDataSys[k].Order- 1;
							}
							DeviceDataSys[k].Order= i+1;		/* Next Device */

							DeviceDataSys[i].SameDevInf= 3;
							DeviceDataSys[i].Continus= k+ 1;	/* Befor Device */
							DeviceDataSys[i].Patarn= MyAddress- Address;
							break;
						}
					}
				}
			}
		}
	}
}
/***************************************************/
/*	WORD GROUP-PATARN								*/
/***************************************************/
void	ClearBWContinue(void)
{
	int		i,j,idx;

	for(i= 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus != 0)){
			/* Continue */
			if(DeviceDataSys[i].DevFlag == 0){		/* BIT */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_BIT_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}else{									/* WORD */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_WORD_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	�O���[�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Set Group */
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gDeviceCnt= 0;

	gSetNumBit= 0;
	gSetNumWord= 0;

	/* Same Device Check */
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}


	/* Monitor Reset */
	RestMonitor();


	if(BitCnt > 0){
		MakeBitContinue();
	}
	if(WordCnt > 0){
		MakeWordContinue(TotalBitCnt);
	}
	/* Continue MAX Check */
	ClearBWContinue();
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}


	return(0);
}

/************************************/
/*	�O���[�v���[�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int	ret;

	ret= 0;
	return(ret);
}

/************************************/
/*	�X���[���[�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendPLCPCData();
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_19200;
	*DataBit= RS_DATA8;
	*Parity= RS_NONE;
}
int	GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
void	Get_Plc1_Ver(char *name)
{
	gstrcpy(name,"V1.001M");
}
int	Get_Ms_Sel(void)
{
	return(1);				/* 0:Slave,1:Master */
}




#ifdef	WIN32
/********************************************/
/*	�����֐�								*/
/********************************************/
int	PLC_CONNECT(int *PlcType,int iConnect)
{
	return(Connection(PlcType,iConnect));
}
int	GET_PLC_NAME(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	PLC1CHAR_READ(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite(mp,rDataFx,PlcType));
}
int	PLC_MAKE_GROUP(int PlcType)
{
	return(MakeGroupDevPLC(PlcType));
}
int	PLC_GROUP_READ(int PlcType)
{
	return(RecGroupPLCDev(PlcType));
}
int	PLCPCDOWN(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	return(PLCPCDownThrue(data,CommMode,Sio1RecCnt,Sio1RecBuff));
}
void	PLC_THRU_PROC(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	PLCFxThruProc(CommBuff,RecCommCnt,OutBuff,OutCnt,PlcConnectFlag,PlcType);
}
int	GET_PLC_MAX(int bFlag,int idx)
{
	return(GetDevMaxPLC(bFlag,idx));
}
int	GET_PLC_MIN(int bFlag,int idx)
{
	return(GetDevMinPLC(bFlag,idx));
}
int		DEVICE_2_INDEX(int bwflag,char *Name)
{
	return(Device2IndexPLC(bwflag,Name));
}
int		CHECK_PLC_ADDR(int bwflag,char *Name,int *Address1,int *Address2)
{
	return(CheckPLC_Addr(bwflag,Name,Address1,Address2));
}
void	GET_MON_BAUDRATE(int *Speed,int *DataBit,int *Parity)
{
	GetMonBaudrate(Speed,DataBit,Parity);
}
int	GET_SEND_REC_TIME(void)
{
	return(GetSendRecTime());
}
void	GET_PLC1_VER(char *Name)
{
	Get_Plc1_Ver(Name);
}
int	GET_MS_SEL(void)
{
	return(Get_Ms_Sel());
}
#endif
/****************************** END **********************/

