/*************************************************
    FUNC  : Display Program
    Create: 2002.4.28	M.Owash
**************************************************/
#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<math.h>


#include	"mts.h"
#include	"mtscifp.h"
#include	"mail.h"
#include	"taskhed.h"
#include	"define.h"
#include	"CommBuff.h"
#include	"bios.h"
#include	"disp.h"

#ifndef	WIN32
//#pragma	section DISP_PROG
#endif

extern	void    XInc( void );
extern	void    XDec( void );

#ifndef	WIN32
#ifdef	USE_RAM
void    DrawHorizontal( int sx, int ex, int y )
{
    unsigned short  m_DrawPat;
	int	WinNo;
	int	wColor;
	int	wDrawPat;
	int	wPatarnNo;
	int	PatarnBit;

	PatarnBit= sx % 8;
	WinNo= TaskWindowNo[_RunTaskNo];
    __MoveTo( sx, y, DrawPtn[WinNo], DrawMode[WinNo] );
    while( BitAdr[WinNo] > 0 && sx <= ex ) {
        *pGraphicMemory[WinNo]= (unsigned short)(*pGraphicMemory[WinNo] & MaskBit[WinNo] | DrawPat[WinNo]);
        XInc();
        sx++;
    }
	wColor= DrawColor[WinNo];
	wDrawPat= DrawPtn[WinNo];
 	wPatarnNo= 0;
    for( ;sx + 7 <= ex; sx += 8 ) {
		if(PatarnBit == 0){
		    m_DrawPat= ColorPatByte[wColor][wDrawPat][wPatarnNo];
	        *pGraphicMemory[WinNo] = m_DrawPat;
		}else{
		    m_DrawPat= ColorPatByte[wColor][wDrawPat][wPatarnNo] >> PatarnBit;
	        *pGraphicMemory[WinNo] = (*pGraphicMemory[WinNo] & ~LineMaskBit[PatarnBit]) | m_DrawPat;
	        pGraphicMemory[WinNo]++;
		    m_DrawPat= ColorPatByte[wColor][wDrawPat][wPatarnNo] << PatarnBit;
	        *pGraphicMemory[WinNo] = (*pGraphicMemory[WinNo] & LineMaskBit[PatarnBit]) | m_DrawPat;
		}
        pGraphicMemory[WinNo]++;
		wPatarnNo= (wPatarnNo + 1) % 3;
    }
    while( sx <= ex ) {
        *pGraphicMemory[WinNo]= (unsigned short)(*pGraphicMemory[WinNo] & MaskBit[WinNo] | DrawPat[WinNo]);
        *pGraphicMemory[WinNo]|= DrawPat[WinNo];
        XInc();
        sx++;
    }
}
#endif
#endif
