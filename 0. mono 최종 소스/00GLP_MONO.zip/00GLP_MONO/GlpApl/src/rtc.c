/****************************************************/
/*    FUNC   : TVS-8500 RTC Program                */
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 1999.8.10                            */
/*    Update :                                      */
/****************************************************/
#include	"sgt.h"
#include    "mtsschdp.h"
#include    "mtsscid.h"
#include "Selib.h"
#include "S3c44b0x.h"

#define	TIME_ST	6
/************************************/

unsigned char SaveSec;		/* �b���ς��̂��m�F���� */
//int		SecChangFlag;		/* �b���ς������ON */

static	int	RTC_MyTaskNo;

extern	void	PlcTimeSetNowTime(void);

/****************************************************
*   FUNC  : Rtc Initial                             *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
****************************************************/
void	RtcInit(void)
{
//     rTICINT=0xff;		//�P�b?�b�N�ݒ�  
     rTICINT=0xbf;		//�T�O�O���b?�b�N�ݒ�  
}
void	RtcInitWrite(unsigned char rtc_buf[])
{
	rRTCCON|=(1<<0);

	rBCDYEAR= 0x00;
	rBCDMON= 0x01;
	rBCDDAY= 0x01;
	rBCDDATE= 0x01;
	rBCDHOUR= 0x00;
	rBCDMIN= 0x00;
	rBCDSEC= 0x00;

	rRTCCON&=~(1<<0);
	rtc_buf[6]= 0x00;
	rtc_buf[5]= 0x01;
	rtc_buf[4]= 0x01;
	rtc_buf[3]= 0x00;
	rtc_buf[2]= 0x00;
	rtc_buf[1]= 0x00;
	rtc_buf[0]= 0x00;
}
void	RTCWrite(unsigned char rtc_buf[],int rReset)
{
	rRTCCON|=(1<<0);

	rBCDYEAR= rtc_buf[6];
	rBCDMON= rtc_buf[5];
	rBCDDAY= rtc_buf[4];
	rBCDDATE= rtc_buf[3];
	rBCDHOUR= rtc_buf[2];
	rBCDMIN= rtc_buf[1];
	rBCDSEC= rtc_buf[0];

	if(rReset == 1){		//30sReset
		rRTCRST= 0x0b;		//1011
	}

	rRTCCON&=~(1<<0);

} // end of Rtc_Set(...)
void	RTCRead(unsigned char rtc_buf[])
{
	rtc_buf[6]= rBCDYEAR;
	rtc_buf[5]= rBCDMON;
	rtc_buf[4]= rBCDDAY;
	rtc_buf[3]= rBCDDATE;
	rtc_buf[2]= rBCDHOUR;
	rtc_buf[1]= rBCDMIN;
	rtc_buf[0]= rBCDSEC;
}
int	_RtcInterruptProc(void)
{
#ifdef	LP_S044
	if(*GlpSysSignal & GLP_SYS_SIG_1S_PULS){
		*GlpSysSignal &= ~GLP_SYS_SIG_1S_PULS;
	}else{
		*GlpSysSignal |= GLP_SYS_SIG_1S_PULS;
	}
#endif
#ifdef	GP_S044
		InDevArea.UB[11] += CLOCK05;
#endif
#ifdef	GP_S057
		InDevArea.UB[11] += CLOCK05;
#endif
	return(0);
}
#ifdef	WIN32
void _RtcTikHandler(void)
#else
void __irq _RtcTikHandler(void)
#endif
{
	int		Ret;

   rI_ISPC= rI_ISPC | BIT_TICK;				// Clear pending bits     
	Ret = _RtcInterruptProc();
	if(Ret == 0){
   		_PendingRequest( ID_PAddFlag | RTC_MyTaskNo << 16 | 1 );
	}
} // Rtc_Isr(...)
/****************************************************
*   FUNC  : Rtc Drive                               *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
****************************************************/
void    RTCDrv(STTFrm* pSTT )
{
	int		loopCnt;
	T_MAIL	*mp;

	loopCnt= 0;
	ClearFlag();
//	PcStateOn();
	RTC_MyTaskNo = _RunTaskNo;
	while(1){
#ifdef	WIN32
		Delay(100);
#else
		WaitFlag(1);
#endif
		if(((loopCnt++) % 2) == 0){
			mp = (T_MAIL *)TakeMail();
			mp->mcmd = RTC_READ_I;
			SendMail( T_RTCHAND, (char *)mp );
//			InDevArea.UB[10] += CLOCK05;
		}
//		In100MSecCnt++;
//		if((SecChangFlag == 1) && ((In100MSecCnt % 5) == 0)){	/* 0.5S */
//			InDevArea.UB[10] += CLOCK05;
//			SecChangFlag= 0;
//		}
	}
}
/****************************************************
*   FUNC  : Rtc Drive                               *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
****************************************************/
void	SetSysTime( unsigned char *rtc_buf)
{
	SystemTime.year = ((rtc_buf[6] & 0xf0) >> 4) * 10 + (rtc_buf[6] & 0x0f);
	SystemTime.mon = ((rtc_buf[5] & 0x30) >> 4) * 10 + (rtc_buf[5] & 0x0f);
	SystemTime.day = ((rtc_buf[4] & 0x70) >> 4) * 10 + (rtc_buf[4] & 0x0f);
#ifdef	WIN32
	SystemTime.week = rtc_buf[3] & 0x7f- 1;
#else
	SystemTime.week = rtc_buf[3];
#endif
	SystemTime.hour = ((rtc_buf[2] & 0x30) >> 4) * 10 + (rtc_buf[2] & 0x0f);
	SystemTime.min = ((rtc_buf[1] & 0x70) >> 4) * 10 + (rtc_buf[1] & 0x0f);
	SystemTime.sec = ((rtc_buf[0] & 0x70) >> 4) * 10 + (rtc_buf[0] & 0x0f);
}
int	CheckRtc(unsigned char *rtc_buf)
{
	int	ret= OK;
	int	wyear;
	int	wmon;
	int	wday;
	int	wweek;
	int	whour;
	int	wmin;
	int	wsec;

	wyear = ((rtc_buf[6] & 0xf0) >> 4) * 10 + (rtc_buf[6] & 0x0f);
	if(wyear > 99){
		ret= NG;
	}
	wmon = ((rtc_buf[5] & 0x30) >> 4) * 10 + (rtc_buf[5] & 0x0f);
	if((wmon < 1) || (wmon > 12)){
		ret= NG;
	}
	wday = ((rtc_buf[4] & 0x70) >> 4) * 10 + (rtc_buf[4] & 0x0f);
	if((wday < 1) || (wday > 31)){
		ret= NG;
	}
	wweek = rtc_buf[3] & 0x7f- 1;
	if((wweek < 0) || (wweek > 6)){
		ret= NG;
	}
	whour = ((rtc_buf[2] & 0x30) >> 4) * 10 + (rtc_buf[2] & 0x0f);
	if((whour < 0) || (whour > 23)){
		ret= NG;
	}
	wmin = ((rtc_buf[1] & 0x70) >> 4) * 10 + (rtc_buf[1] & 0x0f);
	if((wmin < 0) || (wmin > 59)){
		ret= NG;
	}
	wsec = ((rtc_buf[0] & 0x70) >> 4) * 10 + (rtc_buf[0] & 0x0f);
	if((wsec < 0) || (wsec > 59)){
		ret= NG;
	}
	return(ret);
}
void    RtcHand( STTFrm* pSTT )         /* ���v�h���C�u?�X�N */
{
	T_MAIL	*pMail;
	unsigned char	rtc_buf[10];
	int		Cnt = 0;
	unsigned short*	WUTimeArea;

	memset((char *)&SystemTime, 0, sizeof(SystemTime));
#ifdef	WIN32
	time_t	nTime;
	struct tm *new_time;
#else

/*char	dbuff[32];*/


#endif


	SaveSec= 0;
//	SecChangFlag= 0;
#ifndef	WIN32
	RTCRead(rtc_buf);
	if(CheckRtc(rtc_buf) == NG){
		RtcInitWrite(rtc_buf);
	}
	SetSysTime(rtc_buf);
#endif
	while(1){
		pMail = (T_MAIL *)WaitRequest();
		switch(pMail->mcmd){
		case RTC_READ_I:
#ifndef	WIN32
			Cnt++;
			RTCRead(rtc_buf);
	#ifdef	LP_S044
			if(CheckRtc(rtc_buf) == NG){
				SetPlcTimeError();
			}
	#endif
			SetSysTime(rtc_buf);
//			SecChangFlag= 1;
//			In100MSecCnt= 0;
//			InDevArea.UB[10] += CLOCK05;
			/* �P�b�ɂP��ǂ� */
			CommonArea.BatteryLevel= BatteryRead();
	#ifdef	LP_S044
			if(CommonArea.BatteryLevel < BATT_MIN_REVEL){
				SetLowBattery(ON);
			}else{
				SetLowBattery(OFF);
			}
	#endif
#else
			time(&nTime);
			new_time = localtime(&nTime);
			Cnt++;
			SystemTime.year = new_time->tm_year- 100;
			SystemTime.mon = new_time->tm_mon+ 1;
			SystemTime.day = new_time->tm_mday;
			SystemTime.week = new_time->tm_wday;
			SystemTime.hour = new_time->tm_hour;
			SystemTime.min = new_time->tm_min;
			SystemTime.sec = new_time->tm_sec;
//			SecTimeCnt ++;
#endif
			WUTimeArea= &InDevArea.UW[TIME_ST+0];
			/* In Device Set */
			*WUTimeArea++ = SystemTime.sec;
			*WUTimeArea++ = SystemTime.min;
			*WUTimeArea++ = SystemTime.hour;
			*WUTimeArea++ = SystemTime.day;
			*WUTimeArea++ = SystemTime.mon;
			*WUTimeArea++ = SystemTime.year;
			*WUTimeArea   = SystemTime.week;
			if(CommonArea.SystemDev.Write_Dev.DevName[0] != 0){
				SendTimeAction(10,0,0,0);							
			}
#ifdef	LP_S044		//Pcl Area Set
			PlcTimeSetNowTime();
#endif
			break;
		case RTC_READ:
#ifndef	WIN32
			RTCRead(rtc_buf);
	#ifdef	LP_S044
			if(CheckRtc(rtc_buf) == NG){
				SetPlcTimeError();
			}
	#endif
			SetSysTime(rtc_buf);
#else
			time(&nTime);
			new_time = localtime(&nTime);
			SystemTime.year = new_time->tm_year- 100;
			SystemTime.mon = new_time->tm_mon+ 1;
			SystemTime.day = new_time->tm_mday;
			SystemTime.week = new_time->tm_wday;
			SystemTime.hour = new_time->tm_hour;
			SystemTime.min = new_time->tm_min;
			SystemTime.sec = new_time->tm_sec;
#endif
			pMail->mbuf[0] = (char)SystemTime.year;
			pMail->mbuf[1] = (char)SystemTime.mon;
			pMail->mbuf[2] = (char)SystemTime.day;
			pMail->mbuf[3] = (char)SystemTime.week;
			pMail->mbuf[4] = (char)SystemTime.hour;
			pMail->mbuf[5] = (char)SystemTime.min;
			pMail->mbuf[6] = (char)SystemTime.sec;
			break;
		case RTC_WRITE:
			rtc_buf[6] = (pMail->mbuf[0] / 10 << 4) | (pMail->mbuf[0] % 10);
			rtc_buf[5] = (pMail->mbuf[1] / 10 << 4) | (pMail->mbuf[1] % 10);
			rtc_buf[4] = (pMail->mbuf[2] / 10 << 4) | (pMail->mbuf[2] % 10);
			rtc_buf[3] = pMail->mbuf[3];
			rtc_buf[2] = (pMail->mbuf[4] / 10 << 4) | (pMail->mbuf[4] % 10);
			rtc_buf[1] = (pMail->mbuf[5] / 10 << 4) | (pMail->mbuf[5] % 10);
			rtc_buf[0] = (pMail->mbuf[6] / 10 << 4) | (pMail->mbuf[6] % 10);
#ifndef	WIN32
			RTCWrite(rtc_buf,rtc_buf[7]);
			SetSysTime(rtc_buf);
#endif
			break;
		case PRT_WRITE:
			PrtHand(pMail);
			break;
		case RTC_RUN_LED:
			pMail->minf= RunSWReadProc();
			break;
		}
		ResponseMail((char *)pMail);
	}
}

/* 20080822 30�� �ð� ������ ���� Reset �μ� �߰� GLP�� ��� */
void	DateTimeSet(RTC_DATA *SetTime,int rReset)
{
	int	mbx;
	T_MAIL	*mp;
	unsigned int	OldResp;

	mbx= TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RTC_WRITE;
	mp->mbuf[0] = SetTime->year;
	mp->mbuf[1] = SetTime->mon;
	mp->mbuf[2] = SetTime->day;
	mp->mbuf[3] = SetTime->week;
	mp->mbuf[4] = SetTime->hour;
	mp->mbuf[5] = SetTime->min;
	mp->mbuf[6] = SetTime->sec;
	mp->mbuf[7] = rReset;			//30�bRound
	SendMail(T_RTCHAND,(char *)mp);
	mp= (T_MAIL *)ReceiveMail( mbx );
	ChangeMailResp( (char *)mp, OldResp );
	FreeMail( (char *)mp );
	FreeMbx( mbx );
}
int	CheckDateTime(RTC_DATA *SetData)
{
	//Year
	//mon
	if((SetData->mon < 1) || (SetData->mon > 12)){	return(NG);	}
	//day
	if(DataChecking(SetData) == FALSE){				return(NG);	}
	//Hour
	if((SetData->hour < 0) || (SetData->hour > 23)){	return(NG);	}
	//min
	if((SetData->min < 0) || (SetData->min > 59)){	return(NG);	}
	//sec
	if((SetData->sec < 0) || (SetData->sec > 59)){	return(NG);	}
	//week
	if((SetData->week < 0) || (SetData->week > 7)){	return(NG);	}
	return(OK);
}
#ifdef	LP_S044
int	CheckSendDateTime(RTC_DATA *SetData,int rReset)
{
	int	ret;
	T_MAIL	*mp;

	SetData->week= iNowWeek(SetData);
	ret= CheckDateTime(SetData);
	if(ret == OK){
		mp = (T_MAIL *)TakeMail();
		mp->mcmd = RTC_WRITE;
		mp->mbuf[0] = SetData->year;
		mp->mbuf[1] = SetData->mon;
		mp->mbuf[2] = SetData->day;
		mp->mbuf[3] = SetData->week;
		mp->mbuf[4] = SetData->hour;
		mp->mbuf[5] = SetData->min;
		mp->mbuf[6] = SetData->sec;
		mp->mbuf[7] = rReset;			//30�bRound
		SendMail(T_RTCHAND,(char *)mp);
	}else{
		//RTC SET Error
		*GlpSysSelfTest= GLP_SYS_SELF_RTC;
	}
	return(ret);
}
#endif
