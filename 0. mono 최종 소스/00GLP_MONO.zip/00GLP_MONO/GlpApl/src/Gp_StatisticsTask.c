/********************************************************************************/
/* �� �� �� : Gp_StatisticsTask.cpp												*/
/* ��    �� : StatisticsTask													*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"


/********************************************************************************/
/* �� �� �� : DrawStatistics_Func												*/
/* ��    �� : Statistics ������ �ص��Ͽ� ȭ�鿡 ���						    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 30�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetStatistics_Func(int iDispOrder)
{
	_STATISTICS_EVENT_TBL*	 StatisticsEventTbl;
	StatisticsEventTbl= (_STATISTICS_EVENT_TBL*)TakeMemory(sizeof(_STATISTICS_EVENT_TBL));
	DrawStatistics_Func(0,StatisticsEventTbl,iDispOrder);
	FreeMail((char *)StatisticsEventTbl);
}
int	DrawStatistics_Func(int mode,_STATISTICS_EVENT_TBL* StatisticsEventTbl,int iDispOrder)
{
/*	int					iTagSizeOf;	*/
	int					iOffset;
	int					i;
	int					iDevAddr;
	int					iTemp;
	/*--------------*/
	int					iJutX;
	int					iJutY;
	int					iRadius;
	int					iRadius1;
	short				ishapeSize;
	_ORGGATA_INFO		OrggataInfo;
	unsigned char		*buffer;

	buffer= ScreenTagData[iDispOrder].TagPos;
/*	_STATISTICS_EVENT_TBL*	 StatisticsEventTbl;

	if(CheckMailBox(sizeof(_STATISTICS_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_STATISTICS_EVENT_TBL));
	StatisticsEventTbl= (_STATISTICS_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)StatisticsEventTbl, 0x00, sizeof(_STATISTICS_EVENT_TBL));

/*	iTagSizeOf = 0;	*/
	iOffset = 0;
	iDevAddr = 0;
/*	iTagSizeOf = 0;*/

/*	StatisticsEventTbl = (_STATISTICS_EVENT_TBL*)TakeMemory(sizeof(_STATISTICS_EVENT_TBL));
	memset((char *)StatisticsEventTbl, 0x00, sizeof(_STATISTICS_EVENT_TBL));
*/
/*	iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
	iTagSizeOf += (unsigned int)buffer[1] & 0xff;
*/
/*
	StatisticsEventTbl->sX  = (unsigned int)(buffer[6]  << 0x08);
	StatisticsEventTbl->sX += (unsigned int)buffer[7] & 0xff;

	StatisticsEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
	StatisticsEventTbl->sY += (unsigned int)buffer[9] & 0xff;


	StatisticsEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
	StatisticsEventTbl->eX += (unsigned int)buffer[11] & 0xff;


	StatisticsEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
	StatisticsEventTbl->eY += (unsigned int)buffer[13] & 0xff;	
*/

	iOffset++;
	if((unsigned int)buffer[14] == 0x40){
		StatisticsEventTbl->iGraphType = RECTANGLE_GRAPH;
		StatisticsEventTbl->iDirection = DIRECTION_UP;
	}
	else if((unsigned int)buffer[14] == 0x60){
		StatisticsEventTbl->iGraphType = RECTANGLE_GRAPH;
		StatisticsEventTbl->iDirection = DIRECTION_RIGHT;
	}
	else{
		StatisticsEventTbl->iGraphType = CIRCLE_GRAPH;
	}
		
	StatisticsEventTbl->iFrameColor = (unsigned int)buffer[15];	
	StatisticsEventTbl->iPartitionNo = (unsigned int)buffer[16];
	StatisticsEventTbl->iPlateColor = (unsigned int)buffer[17];

	iOffset = 18;
	if(buffer[iOffset] != 0x00){
		StatisticsEventTbl->iScaleDispChk = CHECKED;
		StatisticsEventTbl->iScaleColor = (unsigned int)buffer[++iOffset];
		StatisticsEventTbl->iScalePnts = (unsigned int)buffer[++iOffset];
	}
	else
	{
		StatisticsEventTbl->iScaleDispChk = UNCHECKED;
		iOffset+=2;
	}

	if(buffer[++iOffset] != 0x00){
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed = CHECKED;
		}
		StatisticsEventTbl->ShapeNo = (unsigned int)buffer[++iOffset];
	}else
	{
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed = UNCHECKED;
		}
		StatisticsEventTbl->ShapeNo = 0;
		iOffset++;
	}
	iOffset++;
	if((unsigned int)buffer[iOffset] < 3)
		StatisticsEventTbl->i1632BitFlag = UNCHECKED;
	else
		StatisticsEventTbl->i1632BitFlag = CHECKED;
	if((unsigned int)buffer[iOffset] == 1 || (unsigned int)buffer[iOffset] == 3)
		StatisticsEventTbl->iSignedFlag = SIGNED;
	else
		StatisticsEventTbl->iSignedFlag = UNSIGNED;
	/*------------------------------------------------------------*/
	iOffset++;
	GetDeviceSet((buffer+iOffset),
				StatisticsEventTbl->cDeviceName,
				&(StatisticsEventTbl->iDeviceNumber));
	iOffset+=4;
	/*-------------------------------------------------------------*/	

	for(i=0;i<StatisticsEventTbl->iPartitionNo;i++){
		StatisticsEventTbl->iPartitionColor[i] = (unsigned int)buffer[++iOffset];
	}
	
	iDevAddr = StatisticsEventTbl->iDeviceNumber;
	StatisticsEventTbl->iRegisterNumber = DeviceCnt;
	iTemp = StatisticsEventTbl->iRegisterNumber; 
	i = 0;

	if(mode == 0){
		ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
/* 060510		while(i<StatisticsEventTbl->iPartitionNo){			*/
			DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;
			DeviceDataHed[DeviceCnt].DevName[0] = StatisticsEventTbl->cDeviceName[0];
			DeviceDataHed[DeviceCnt].DevName[1] = StatisticsEventTbl->cDeviceName[1];
			DeviceDataHed[DeviceCnt].DevAddress = iDevAddr;
			
			if(StatisticsEventTbl->i1632BitFlag == 0){
/* 060510				DeviceDataHed[DeviceCnt].DevCnt = 1;				*/
				DeviceDataHed[DeviceCnt].DevCnt = StatisticsEventTbl->iPartitionNo;				
			}else{
/* 060510				DeviceDataHed[DeviceCnt].DevCnt = 2;				*/
				DeviceDataHed[DeviceCnt].DevCnt = StatisticsEventTbl->iPartitionNo * 2;				
			}
			DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];
			ScreenTagData[iDispOrder].DevCnt+= DeviceDataHed[DeviceCnt].DevCnt*2;
			if(StatisticsEventTbl->i1632BitFlag == 0){				
/* 060920				iDeviceOffset += 2; */
				iDeviceOffset += StatisticsEventTbl->iPartitionNo* 2; 
				iDevAddr++;
			}else{	
/* 060920				iDeviceOffset += 4; */
				iDeviceOffset += StatisticsEventTbl->iPartitionNo*4;
				iDevAddr += 2;
			}
			/* 20020819 choijh add*/
			/* SuperVOffset��StatisticsEventTbl->iPartitionNo�����邽�ߖ��g�p 041204 */
/*			StatisticsEventTbl->SuperVOffset= WatchingDevice(StatisticsEventTbl->cDeviceName, 
											   iDevAddr, 
											   iTemp1,
											   iTemp,
											   WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
			DeviceCnt++;
/*			iDevAddr++;*/
			iTemp++;
			i++;
/*
			iDevAddr = iDeviceAddressReturn(StatisticsEventTbl->cDeviceName, 
						 iDevAddr, StatisticsEventTbl->i1632BitFlag);
*/
/* 060510		}*/
		ishapeSize = 0;
		if(ScreenTagData[iDispOrder].BeShapeUsed == CHECKED){		
			switch(StatisticsEventTbl->ShapeNo){
				case 1:
					ishapeSize = 3;
					break;
				case 2:
				case 6:
					ishapeSize = 4;
					break;
				case 3:
				case 4:
				case 5:
					ishapeSize = 5;
					break;
			}
		}
		/* �޸� �����ý� ���߿� ���� ���� ����.  */
		if(StatisticsEventTbl->iGraphType == CIRCLE_GRAPH){
			ScreenTagData[iDispOrder].uu.Statics.ScalePos= ScalePosCnt;
			OrggataInfo.iColor = T_BLACK;
			OrggataInfo.iScaleColor = StatisticsEventTbl->iScaleColor;

			iRadius = (int)((ScreenTagData[iDispOrder].eY-ishapeSize) - (ScreenTagData[iDispOrder].sY+ishapeSize))/2;
			iRadius1 = (int)((ScreenTagData[iDispOrder].eX-ishapeSize) - (ScreenTagData[iDispOrder].sX+ishapeSize))/2;
			if(iRadius > iRadius1)
				iRadius = iRadius1;
			iRadius-=4;
			iJutX = (int)(ScreenTagData[iDispOrder].eX - ScreenTagData[iDispOrder].sX)/2;
			iJutX = ScreenTagData[iDispOrder].sX + iJutX + ishapeSize;
			iJutY = (int)(ScreenTagData[iDispOrder].eY - ScreenTagData[iDispOrder].sY)/2;
			iJutY = ScreenTagData[iDispOrder].sY + iJutY + ishapeSize;
			DrawOrggataCalc(iJutX,
					iJutY,
					iRadius, 
					0, 
					iRadius, 
					0, 
					iRadius,								
					52,
					0,
					&OrggataInfo);
			for(i=0;i<52;i++){
				ScalePoint[ScalePosCnt][i].x1 = ScalePoin[i].x1;
				ScalePoint[ScalePosCnt][i].y1 = ScalePoin[i].y1;
			}
			ScalePosCnt++;
		}
/* --------------------------------------  */
		StatisticsDispCnt++;
	}
/*	IventTableCnt++;*/
	return(0);
}


/********************************************************************************/
/* �� �� �� : StatisticsDispWatch												*/
/* ��    �� : Statistics�±������� ����  ȭ�鿡 ����� ����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 1�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/

void	StatisticsDispWatch(int iOrder)
{	
	short			k;
	short			j;
	short			iScalepointCnt;
	short			iScalePointChecked;
	int				iChkVal[9];		/* 030605 8->9 */
	long			lDeviceValue[8];	
	unsigned long	ulDeviceValue[8];	
	int				iJutX;
	int				iJutY;
	int				iRadius;
	int				iRadius1;
/*	int				iSum;	*/
/*	int				iTempSum;	*/
	float			iSum;	
	float			iTempSum;	
	short			*iRectangle_Site;
	float			ftemp;
	int				iTemp;	
	float			fPtn;
	float			*fTemp;
	float			iSite;
	int				sX, sY, eX, eY;
	short			iShapeSize;
	_LINE_INFO		LineInfo;
	_RECTANGLE_INFO	RectInfo;
	_ORGGATA_INFO	OrggataInfo;
	_CIRCLE_INFO	CircleInfo;
	_STATISTICS_EVENT_TBL*	 StatisticsEventTbl;
	int				mCnt;
	char			work[8];
	int				ScalePos;
	int				CheckFlag;

/*	StatisticsEventTbl= (_STATISTICS_EVENT_TBL*)IventTable[iOrder];*/
	StatisticsEventTbl= (_STATISTICS_EVENT_TBL*)TakeMemory(sizeof(_STATISTICS_EVENT_TBL));
	DrawStatistics_Func(1,StatisticsEventTbl,iOrder);

	sX = ScreenTagData[iOrder].sX;
	sY = ScreenTagData[iOrder].sY;
	eX = ScreenTagData[iOrder].eX;
	eY = ScreenTagData[iOrder].eY;

	ScalePos= ScreenTagData[iOrder].uu.Statics.ScalePos;

	k					= 0;
	j					= 0;
	iScalepointCnt		= 0;
	iScalePointChecked	= 0;
	iJutX				= 0;
	iJutY				= 0;
	iRadius				= 0;
	iSum				= 0;		
	iTempSum			= 0;		
	ftemp				= 0;
	iSite				= 0;
	iTemp				= 0;

	fTemp = (float*)TakeMemory(53*sizeof(float*));
/*	memset(fTemp, 0x00, 53*sizeof(float*));*/

/*	memset(iChkVal,         0x00, sizeof(iChkVal));*/
/*	memset(lDeviceValue,    0x00, sizeof(lDeviceValue));*/
	
	mCnt= 0;
	for(k=0;k<StatisticsEventTbl->iPartitionNo;k++){
		if(StatisticsEventTbl->i1632BitFlag == 0){
			memcpy(work,&DispDeviceData[ScreenTagData[iOrder].DevOrder+mCnt],2);
			mCnt += 2;
			if(StatisticsEventTbl->iSignedFlag == UNSIGNED)
				lDeviceValue[k]= ChangeChar2Unsinlong(work,BIT16);
			else
				lDeviceValue[k]= ChangeChar2long(work,BIT16);
		}else{
			memcpy(work,&DispDeviceData[ScreenTagData[iOrder].DevOrder+mCnt],4);
			mCnt += 4;
			if(StatisticsEventTbl->iSignedFlag == UNSIGNED)
				lDeviceValue[k]= ChangeChar2Unsinlong(work,BIT32);
			else
				lDeviceValue[k]= ChangeChar2long(work,BIT32);
		}
	}
/* 20080822 */
	if((StatisticsEventTbl->i1632BitFlag != 0) && (StatisticsEventTbl->iSignedFlag == UNSIGNED)){
		for(k=0;k<StatisticsEventTbl->iPartitionNo;k++){
			ulDeviceValue[k] = lDeviceValue[k];
			iSum += (float)ulDeviceValue[k];
		}
		fPtn = (float)iSum/52;
			
		for(k=0;k<=52;k++){
			fTemp[k] = fPtn*(k);
		}

		iChkVal[0]=0;
		for(j=1;j<=StatisticsEventTbl->iPartitionNo;j++){						
			iTempSum += (float)ulDeviceValue[j-1];
			for(k=0;k<=52;k++){
				if((fTemp[k]) >= iTempSum){
					iChkVal[j] = k;
					break;
				}
				else if(iSum == iTempSum){
					iChkVal[j] = 52;
					break;
				}
			}			
		}
	}else{
		for(k=0;k<StatisticsEventTbl->iPartitionNo;k++){
			if(lDeviceValue[k]<0)
				lDeviceValue[k] = lDeviceValue[k] * -1;
			iSum += (float)lDeviceValue[k];
		}
		fPtn = (float)iSum/52;
			
		for(k=0;k<=52;k++){
			fTemp[k] = fPtn*(k);
		}

		iChkVal[0]=0;
		for(j=1;j<=StatisticsEventTbl->iPartitionNo;j++){						
			iTempSum += (float)lDeviceValue[j-1];
			for(k=0;k<=52;k++){
				if((fTemp[k]) >= iTempSum){
					iChkVal[j] = k;
					break;
				}
				else if(iSum == iTempSum){
					iChkVal[j] = 52;
					break;
				}
			}			
		}
	}	
	if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){
		iShapeSize = DrawShape(StatisticsEventTbl->ShapeNo, 
			sX, 
			sY, 
			eX, 
			eY,
			StatisticsEventTbl->iFrameColor,
			StatisticsEventTbl->iPlateColor);
		sX+=iShapeSize;
		sY+=iShapeSize;
		eX-=iShapeSize;
		eY-=iShapeSize;

	}


	if(StatisticsEventTbl->iGraphType == RECTANGLE_GRAPH){
/*		if(iOnSignalStart != OFF){*/
			/* �ܺ�Ʋ�� �׸���. */
		iRectangle_Site = (short*)TakeMemory(53*sizeof(short*));
		memset(iRectangle_Site, 0x00, 53*sizeof(short*));

		if(StatisticsEventTbl->iDirection == DIRECTION_UP){
			if(StatisticsEventTbl->iScaleDispChk == CHECKED)
				sX += 5;
		}
		else{
			if(StatisticsEventTbl->iScaleDispChk == CHECKED)
				eY -= 5;
		}
		RectInfo.iLineStyle = SOLID_LINE;
			RectInfo.iLineColor = T_WHITE;
			RectInfo.iPattern = PAT0;
			RectInfo.iForeColor = T_WHITE;
			RectInfo.iBackColor = BLACK;
			RectAngleOut(sX,
						sY,
						eX, 
						eY,
						&RectInfo);

			if(StatisticsEventTbl->iDirection == DIRECTION_UP){	
				if(StatisticsEventTbl->iScaleDispChk == CHECKED){

					
					iSite = (float)(eY - sY)/(StatisticsEventTbl->iScalePnts-1);
					iTemp = sY;
					LineInfo.iLineStyle = SOLID_LINE;
					LineInfo.iLineColor = StatisticsEventTbl->iScaleColor;								
					
					for(k=0;k<StatisticsEventTbl->iScalePnts;k++){
						LineOut(sX-4, iTemp, sX, iTemp,	&LineInfo);
						iTemp = (int)(sY + (iSite*k));
					}
					LineOut(sX-4 , eY, sX, eY, &LineInfo);
				}
				ftemp = (float)(eY - sY)/52;
				for(k=0;k<=52;k++){
					iRectangle_Site[k] = (int)(eY - ftemp*k);
				}
				if(sY !=iRectangle_Site[52])
					iRectangle_Site[52] = sY;
				for(k=0;k<StatisticsEventTbl->iPartitionNo;k++){
					RectInfo.iLineStyle = SOLID_LINE;
					RectInfo.iLineColor = T_WHITE;
					
					RectInfo.iPattern = PAT8;
					RectInfo.iForeColor = StatisticsEventTbl->iPartitionColor[k];
					RectInfo.iBackColor = StatisticsEventTbl->iPartitionColor[k];

					RectAngleOut(sX,
							iRectangle_Site[iChkVal[k+1]], 
							eX, 
							iRectangle_Site[iChkVal[k]],
							&RectInfo);
				}
			}
			else if(StatisticsEventTbl->iDirection == DIRECTION_RIGHT){
				if(StatisticsEventTbl->iScaleDispChk == CHECKED){


					iSite = (float)(eX - sX)/(StatisticsEventTbl->iScalePnts-1);
					iTemp = sX;

					LineInfo.iLineStyle = SOLID_LINE;
					LineInfo.iLineColor = StatisticsEventTbl->iScaleColor;
					for(k=0;k<StatisticsEventTbl->iScalePnts;k++){
						LineOut(iTemp, eY+4, iTemp, eY, &LineInfo);
								
						iTemp =(int)(sX + (iSite * k));
					}
					LineOut(eX, eY+4, eX, eY, &LineInfo);



				}

				ftemp = (float)(eX - sX)/52;
				for(k=0;k<=52;k++){
					iRectangle_Site[k] = (int)((float)eX - ftemp*k+ 0.5);
				}
				if(sX != iRectangle_Site[52])
					iRectangle_Site[52] = sX;
				for(k=0;k<StatisticsEventTbl->iPartitionNo;k++){
					RectInfo.iLineStyle = SOLID_LINE;
					RectInfo.iLineColor = T_WHITE;
					RectInfo.iPattern = PAT8;
					RectInfo.iForeColor = StatisticsEventTbl->iPartitionColor[k];
					RectInfo.iBackColor = StatisticsEventTbl->iPartitionColor[k];

					RectAngleOut(iRectangle_Site[(52-iChkVal[k])], 
							sY,
							iRectangle_Site[(52-iChkVal[k+1])], 
							eY,
							&RectInfo);
				}
			}
		/*}			*/
			FreeMail((char *)iRectangle_Site);
	}
	else if(StatisticsEventTbl->iGraphType == CIRCLE_GRAPH){
		/*if(iOnSignalStart != OFF){*/
		/*	AreaClear(sX+1, sY+1, eX-1, eY-1, 0);*/
			if(StatisticsEventTbl->iScaleDispChk == CHECKED){
				iScalePointChecked = 1;
				iScalepointCnt = StatisticsEventTbl->iScalePnts;
			}else{
				iScalePointChecked = 0;
				iScalepointCnt = 52;
			}

			iRadius = (int)(eY - sY)/2;
			iRadius1 = (int)(eX - sX)/2;
			if(iRadius > iRadius1)
				iRadius = iRadius1;
			iJutX = (int)(eX - sX)/2;
			iJutX = sX + iJutX;
			iJutY = (int)(eY - sY)/2;
			iJutY = sY + iJutY;
			iRadius-=4;
			if(iScalePointChecked == 1){
				OrggataInfo.iColor = T_BLACK;
				OrggataInfo.iScaleColor = StatisticsEventTbl->iScaleColor;
				DrawOrggata(iJutX,
							iJutY,
							iRadius, 
							0, 
							iRadius, 
							0, 
							iRadius,								
							iScalepointCnt,
							iScalePointChecked,
							&OrggataInfo);

				for(k=0;k<StatisticsEventTbl->iPartitionNo;k++){
					CheckFlag= 0;
					if((StatisticsEventTbl->i1632BitFlag != 0) && (StatisticsEventTbl->iSignedFlag == UNSIGNED)){
						if(ulDeviceValue[k] != 0){
							CheckFlag= 1;
						}
					}else{
						if(lDeviceValue[k] != 0){
							CheckFlag= 1;
						}
					}
					if(CheckFlag != 0){
						if(iChkVal[k+1] == 52)
							iChkVal[k+1] = 0;
						OrggataInfo.iScaleColor = StatisticsEventTbl->iPartitionColor[k];
						OrggataInfo.iColor = StatisticsEventTbl->iPartitionColor[k];
						DrawOrggata(iJutX,
								iJutY,
								iRadius, 
								ScalePoint[ScalePos][iChkVal[k]].x1, 
								-ScalePoint[ScalePos][iChkVal[k]].y1, 
								ScalePoint[ScalePos][iChkVal[k+1]].x1, 
								-ScalePoint[ScalePos][iChkVal[k+1]].y1,								
								0,
								0,
								&OrggataInfo);
					}
				}
			}else{
				OrggataInfo.iColor = T_BLACK;
				OrggataInfo.iScaleColor = StatisticsEventTbl->iScaleColor;

				DrawOrggata(iJutX,
							iJutY,
							iRadius, 
							0, 
							iRadius, 
							0, 
							iRadius,								
							iScalepointCnt,
							iScalePointChecked,
							&OrggataInfo);
				
				for(k=0;k<StatisticsEventTbl->iPartitionNo;k++){

/*
					if(iChkVal[k] == 52)
						iChkVal[k] = 0;
					
					LineInfo.iLineStyle = SOLID_LINE;
					LineInfo.iLineColor = T_WHITE;
					LineOut(iJutX,
							iJutY, 
							iJutX + StatisticsEventTbl->ScalePoint[iChkVal[k]].x1, 
							iJutY + StatisticsEventTbl->ScalePoint[iChkVal[k]].y1, 
							&LineInfo);
*/
/*lsi20040529 ���� */
					CheckFlag= 0;
					if((StatisticsEventTbl->i1632BitFlag != 0) && (StatisticsEventTbl->iSignedFlag == UNSIGNED)){
						if(ulDeviceValue[k] != 0){
							CheckFlag= 1;
						}
					}else{
						if(lDeviceValue[k] != 0){
							CheckFlag= 1;
						}
					}
					if(CheckFlag != 0){
						if(iChkVal[k+1] == 52)
							iChkVal[k+1] = 0;
						

						OrggataInfo.iScaleColor = StatisticsEventTbl->iPartitionColor[k];
						OrggataInfo.iColor = StatisticsEventTbl->iPartitionColor[k];
						DrawOrggata(iJutX,
								iJutY,
								iRadius, 
								ScalePoint[ScalePos][iChkVal[k]].x1, 
								-ScalePoint[ScalePos][iChkVal[k]].y1, 
								ScalePoint[ScalePos][iChkVal[k+1]].x1, 
								-ScalePoint[ScalePos][iChkVal[k+1]].y1,								
								0,
								0,
								&OrggataInfo);
					}
/*lsi20040529*/
							
				}
			}
			//����̉~ 2008.09.04
			CircleInfo.iLineColor= T_WHITE;				/* Circle Line Color */
			CircleInfo.iPattern= P_NONE;				/* Circle Pattern */
			CircleInfo.iForeColor= T_WHITE;				/* Circle Foreground Color */
			CircleInfo.iBackColor= T_BLACK;				/* Circle Background Color */
			DrawCircle(iJutX,iJutY,iRadius,&CircleInfo); 
	/*	}*/
	}	
	FreeMail((char*)fTemp);
	FreeMail((char *)StatisticsEventTbl);
}

