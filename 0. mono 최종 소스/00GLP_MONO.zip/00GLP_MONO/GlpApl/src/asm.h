/*** Assembly algorithm for RVD ***
  /  
 / /
/ / /\
\\\/ /// CLABSYS
 \\ ///  Cyber Lab System
  \\//
   \/

Revision history ___
2004-4-28 John
*/



#ifndef __ASM_H__
#define __ASM_H__

#include "typedefs.h"
unsigned int Verify(unsigned int StartAddr, unsigned int BufferAddr, unsigned int Number);	//OK returns 0, False returns 1
void FixedReadB(unsigned int StartAddr, unsigned int BufferAddr, unsigned int EndAddr);
unsigned int BlockCopy(unsigned int SourceAddress, unsigned int DestinationAddress, unsigned int Number); 
unsigned int Read512ByteFixed( unsigned int FixedAddr, unsigned int Width);
#endif // __ASM_H__
//			x			x
