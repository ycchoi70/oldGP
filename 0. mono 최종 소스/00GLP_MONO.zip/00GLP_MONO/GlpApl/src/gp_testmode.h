void		BaseScreenList(int* iScreenNo);
void		BaseScreenNumDisplay(int TLineCnt, int iStartNum);
