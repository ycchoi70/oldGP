/*****************************************************************************************/
/*	PLC ����M �v���O��?(Sumson N70Plus)	*/
/*	2003.5.31				*/
/************************************************/
/*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		  */
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
/*	2006.09.25 */
/*      �����͹� ���ø� ������ ���� ver 2.6�� �ϰ� ����	  */
/*  2007.01.30 
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����
/*  2007.10.08 
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����		  
/*****************************************************************************************/

#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include	"hook_plcapl.h"

/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V4.0M"
/*****************************************************************************************/

#define	MAX_RTY_COUNT	3

/*#define	LOG*/
#define	MAX_WORDCNT		16
#define	MAX_BITCNT		128
#define	MAX_MON_WORDCNT	79
#define	MAX_MON_BITCNT	79
#define	MAX_PBITCNT		128
#define	MAX_PWORDCNT	10
#define	MAX_WORD_CONT_CNT	4
#define	MAX_BIT_CONT_CNT	4

/*#ifndef	WIN32
#pragma	section PlcProc
#endif
*/

#define	BIT_RD2	0x21
#define	BIT_WT2	0x22
#define	WRD_RD2	0x23
#define	WRD_WT2	0x24
#define	BWD_RD2	0x25
#define	BWD_WT2	0x26
#define	PRG_RD2	0x27

#define	BIT_RD4	0x01
#define	BIT_WT4	0x02
#define	WRD_RD4	0x03
#define	WRD_WT4	0x04
#define	BWD_RD4	0x05
#define	BWD_WT4	0x06
#define	PRG_RD4	0x07

#ifdef	SH_CPU
static	volatile	int	ProtFlag;
static	int	PlcProtLeng;

static	int	Plc70PConnectFlag;
static	int	PlcSendedFlag;
static	unsigned int Time1Char;
static	unsigned int Time1CharPlc;
#endif

#ifdef	LOG
int		logCnt;
char	reclog[512];
char	modlog[512];
#endif


/********************************/
/*	SM Serease					*/
/********************************/
static	const	DEV_TBL bPLCDeviceTbl[16] = {
	{"R" ,0x0000,1},
	{"L" ,0x0800,1},
	{"M" ,0x0C00,1},
	{"K" ,0x1400,1},
	{"F" ,0x1C00,1},
	{"TC",0x1D00,1},
	{"GB" ,    0,4},
};
static	const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"R" ,0x0000,1},
	{"L" ,0x0080,1},
	{"M" ,0x00C0,1},
	{"K" ,0x0140,1},
	{"F" ,0x01C0,1},
	{"W" ,0x0200,1},
	{"PV",0x0B00,1},
	{"SV",0x0A00,1},
	{"SR",0x0C00,1},
	{"GD" ,    0,4},
};


/************************************/
/* ��M�v���g�R��					*/
/************************************/
/****************************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef	PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}

/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_38400;
	*DataBit= RS_DATA8;
	*Parity= RS_NONE;
}

/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;
	unsigned int nowtime;

	nowtime= B_GetNowTime();
	if((nowtime - Time1Char) > 200){
		*CommMode= 0;
	}
	Time1Char= nowtime;

	switch(*CommMode){
	case 0:				/* DA */
		*RecCnt= 0;			/* ?���X??�g */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 1;
		break;
	case 1:				/* SA */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 2;
		break;
	case 2:				/* Command */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 3;
		break;
	case 3:				/* Length */
		RecBuff[(*RecCnt)++] = data;
		PlcProtLeng= data;
		if(PlcProtLeng <= 0){
			*CommMode = 5;
		}else{
			*CommMode = 4;
		}
		break;
	case 4:				/* Data */
		RecBuff[(*RecCnt)++] = data;
		PlcProtLeng--;
		if(PlcProtLeng <= 0){
			*CommMode = 5;
		}
		break;
	case 5:				/* CRC1 */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 6;
		break;
	case 6:				/* CRC2 */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 0;
		ret= 0;
		break;
	}
	return(ret);
}
static	int	Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
static	int SetPLCBCC(char *buff,int cnt)
{
	int		i,j;
	unsigned int _crc16;

	_crc16 = 0xffff;
	for(i = 0; i < cnt; i++){
/*		OutBuf[i] = buff[i];*/
		_crc16= _crc16 ^ (buff[i] & 0x00ff);
		for(j= 0; j < 8; j++){
			if((_crc16 & 0x0001) == 0x0001){
				_crc16= (_crc16 >> 1) ^ 0xa001;
			}else{
				_crc16= _crc16 >> 1;
			}
		}
	}
	buff[cnt] = (unsigned char)_crc16;
	buff[cnt+1] = (unsigned char)(_crc16 >> 8);
	return(cnt + 2);
}
/************************************/
/*	PLC Send						*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	int		i,j;
	unsigned int  _crc16;
	unsigned int  _crc16Rec;
	int		rty_cnt;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,*Cnt);
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
		ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		if(ret == 0){
			_crc16 = 0xffff;
			for(i = 0; i < *Cnt-2; i++){
				_crc16= _crc16 ^ (rData[i] & 0x00ff);
				for(j= 0; j < 8; j++){
					if((_crc16 & 0x0001) == 0x0001){
						_crc16= (_crc16 >> 1) ^ 0xa001;
					}else{
						_crc16= _crc16 >> 1;
					}
				}
			}
			_crc16Rec= (rData[*Cnt-1] << 8) + (rData[*Cnt-2]);
			if(_crc16 != _crc16Rec){
				ret= -1;
			}
			if(ret == OK){
				break;
			}
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}
	return(ret);
}
static	int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	int		i,j;
	unsigned int  _crc16;
	unsigned int  _crc16Rec;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,*Cnt);
	ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	if(ret == 0){
		_crc16 = 0xffff;
		for(i = 0; i < *Cnt-2; i++){
			_crc16= _crc16 ^ (rData[i] & 0x00ff);
			for(j= 0; j < 8; j++){
				if((_crc16 & 0x0001) == 0x0001){
					_crc16= (_crc16 >> 1) ^ 0xa001;
				}else{
					_crc16= _crc16 >> 1;
				}
			}
		}
		_crc16Rec= (rData[*Cnt-1] << 8) + (rData[*Cnt-2]);
		if(_crc16 != _crc16Rec){
			ret= -1;
		}
	}
	return(ret);
}
/********************************************/
static	int	SendCommandPLC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;

	ret= SendRecPLCWithBCC(mode,combuf,rData,Cnt,rmode);
	return(ret);
}
/********************************************/
/*	Connection Proc							*/
/*	*PlcType:[0]->PlcType					*/
/*	         [1]->MyStation					*/
/*	         [2]->DstStation				*/
/********************************************/


static	int	C_Connection( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;
	char	buff[10];
#ifndef	WIN32
	int		Speed;
	int		DataBit;
	int		Parity;
#endif
#ifdef	LOG
	logCnt= 0;
#endif
	ProtFlag= 0;		/* Protocol Flag */
	Time1Char= 0;
	Time1CharPlc= 0;
	Plc70PConnectFlag= 0;
	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */
#ifdef	WIN32
			SioPCMode= 2;
			SioPCOpenFlag= 1;
#else
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PC,RS_INIT,RS_38400,RS_DATA8,RS_NONE); */
#endif
		}else{						/* RS-422 */
#ifdef	WIN32
			SioPLCMode= 2;
			SioPLCOpenFlag= 1;
#else
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE); */
#endif
		}
#ifdef	WIN32
		while(1){
			if(SioPLCOpenFlag == 0){
				break;
			}
			B_Delay(10);
		}
#endif
		B_Delay(100);
	}
	/* PLC Connect Check */
	MyStationNo= PlcType[1];
	DstStationNo= PlcType[2];
	buff[0]= (unsigned char)0xff;	/* DA */
	buff[1]= (unsigned char)PlcType[1];	/* SA */
	buff[2]= (unsigned char)PRG_RD2;		/* Command */
	buff[3]= (unsigned char)0x03;			/* Length */
	buff[4]= (unsigned char)0x00;			/* BASE(L) */
	buff[5]= (unsigned char)0x00;			/* BASE(H) */
	buff[6]= (unsigned char)0x02;			/* BASE(H) */

	Cnt= 7;
	ret= SendRecPLCWithBCCCont(2,(char *)buff,PlcRecBuff,&Cnt,0);
	if(ret < 0){
		return(0);
	}
	DstStationNo= PlcRecBuff[1];		/* �ǔ� */
	ret= 1;
	Plc70PConnectFlag= 1;
	PlcSendedFlag= 0;
	B_gmemset((char *)&PlcThruMonDataCnt[0],0,sizeof(PlcThruMonDataCnt));		/* 2008.09.06 */
	return(ret);
}
/******************************************/
static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif

#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif
}
/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrcmp(bPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrcmp(wPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int		DevAddr;

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	if(ret == 0){
/*		DstStationNo= pDevice[4];*/
		combuff[0]= DstStationNo;		/* DA */
		combuff[1]= MyStationNo;		/* SA */
		if(mode == 0){		/* BIT */
			combuff[2]= BIT_RD2;		/* Command */
			combuff[3]= 0x03;		/* Length */
			combuff[4]= (char)DevAddr;
			combuff[5]= (char)(DevAddr >> 8);
			combuff[6]= sCnt;
		}else{				/* WORD */
			combuff[2]= WRD_RD2;		/* Command */
			combuff[3]= 0x03;		/* Length */
			combuff[4]= (char)DevAddr;
			combuff[5]= (char)(DevAddr >> 8);
			combuff[6]= sCnt;
		}
	}
	return(ret);
}
/************************************/
/* PLC Semafo						*/
/************************************/
static	void	SetPlcSema(void)
{
	while(ProtFlag != 0){
		B_Delay(10);
	}
	ProtFlag= 1;
}
static	void	ReSetPlcSema(void)
{
	ProtFlag= 0;
}
/************************************/
/* PLC Read							*/
/************************************/
static	int	BitReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt,dCnt;
	unsigned char	*SaveAddr;
	int		Address;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_BITCNT){	dCnt -= MAX_BITCNT;	mp->mext= MAX_BITCNT;	}
		else{					mp->mext= dCnt;		dCnt = 0;				}
		ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext);
		if(ret != 0){			break;			}
		Cnt = mp->mext;
		SaveAddr = (unsigned char *)mp->mptr;
		i= 7;
		ret= SendCommandPLC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0);
		if(ret != 0){			break;			}
		for(i = 0; i < Cnt; i++){
			if(rDataFx[i+4] != 0){
				*(unsigned char *)SaveAddr++ = 1;
			}else{
				*(unsigned char *)SaveAddr++ = 0;
			}
		}
		if(dCnt == 0){			break;			}
		Address += MAX_BITCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_BITCNT);
	}
	return(ret);
}
static	int	WordReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt,dCnt;
	unsigned char	*SaveAddr;
	int		Address;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_WORDCNT){	dCnt -= MAX_WORDCNT;	mp->mext= MAX_WORDCNT;	}
		else{					mp->mext= dCnt;			dCnt = 0;				}
		ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext);
		if(ret != 0){			break;			}
		Cnt = mp->mext;
		SaveAddr = (unsigned char *)mp->mptr;
		i= 7;
		ret= SendCommandPLC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0);
		if(ret != 0){			break;			}
		for(i = 0; i < Cnt; i++){
#ifdef	SH_CPU
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+4];
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+5];
#endif
#ifdef	ARM_CPU
#ifdef	WIN32
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+4];
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+5];
#else
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+5];
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+4];
#endif
#endif
		}
		if(dCnt == 0){			break;			}
		Address += MAX_WORDCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
	}
	return(ret);
}
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;

	SetPlcSema();
	switch(mp->mpec){
	case PLC_BIT:		ret= BitReadProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordReadProc(mp,rDataFx,PlcType);		break;
	}
	ReSetPlcSema();
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	int		DevAddr;

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);
	if(ret == 0){
/*		DstStationNo= pDevice[4];*/
		combuff[0]= DstStationNo;		/* DA */
		combuff[1]= MyStationNo;		/* SA */
		if(mode == 0){		/* BIT */
			combuff[2]= BIT_WT2;		/* Command */
			combuff[3]= Cnt+2;			/* Length */
			combuff[4]= (char)DevAddr;
			combuff[5]= (char)(DevAddr >> 8);
			for(i= 0; i < Cnt; i++){
				if(data[i] == 0){
					combuff[6+i]= 0;
				}else{
					combuff[6+i]= (char)0xff;
				}
			}
		}else{		/* WORD */
			combuff[2]= WRD_WT2;		/* Command */
			combuff[3]= Cnt*2+2;		/* Length */
			combuff[4]= (char)DevAddr;
			combuff[5]= (char)(DevAddr >> 8);
/*			for(i= 0; i < Cnt*2; i++){  */
/*				combuff[6+i]= data[i];  */
/*			}  */
			for(i= 0; i < Cnt; i++){
#ifdef	SH_CPU
				combuff[6+i*2]= data[i*2];
				combuff[6+i*2+1]= data[i*2+1];
#endif
#ifdef	ARM_CPU
#ifdef	WIN32
				combuff[6+i*2]= data[i*2];
				combuff[6+i*2+1]= data[i*2+1];
#else
				combuff[6+i*2]= data[i*2+1];
				combuff[6+i*2+1]= data[i*2];
#endif
#endif
			}
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
static	int	BitWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,dCnt;
	int		Address;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_BITCNT){	dCnt -= MAX_BITCNT;	mp->mext= MAX_BITCNT;	}
		else{					mp->mext= dCnt;			dCnt = 0;				}
		ret = MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PlcSendBuff,(char *)mp->mptr);
		if(ret != 0){			break;		}
		Cnt = mp->mext+2+4;
		ret= SendCommandPLC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0);
		if(ret != 0){			break;		}
		if(dCnt == 0){				break;		}
		Address += MAX_BITCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_BITCNT);
	}
	return(ret);
}
static	int	WordWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,dCnt;
	int		Address;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_WORDCNT){	dCnt -= MAX_WORDCNT;	mp->mext= MAX_WORDCNT;	}
		else{					mp->mext= dCnt;			dCnt = 0;				}
		ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PlcSendBuff,(char *)mp->mptr);
		if(ret != 0){			break;		}
		Cnt = mp->mext*2+2+4;
		ret= SendCommandPLC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0);
		if(ret != 0){			break;		}
		if(dCnt == 0){			break;		}
		Address += MAX_WORDCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
	}
	return(ret);
}
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;

	SetPlcSema();
	switch(mp->mpec){
	case PLC_BIT:		ret= BitWriteProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordWriteProc(mp,rDataFx,PlcType);		break;
	}
	ReSetPlcSema();
	return(ret);
}
static	int	C_GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}

/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
/************************************/
/*	Device & Address Change			*/
/************************************/
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;
	unsigned int nowtime;

#ifdef	LOG
	reclog[logCnt]= data;
	modlog[logCnt]= *CommMode;
	logCnt= (logCnt+ 1) & 0xff;
#endif
	nowtime= B_GetNowTime();
	if((nowtime - Time1CharPlc) > 200){
		*CommMode= 0;
	}
	Time1CharPlc= nowtime;

	ret = -1;
	switch(*CommMode){			/* CommMode=0:Normal,1->3:Editor,4->PLC */
	case 0:		/* Normal DA */
		*CommMode = 4;
		*Sio1RecCnt = 0;
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		break;
	case 4:				/* SA */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		*CommMode = 5;
		break;
	case 5:				/* Command */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		*CommMode = 6;
		break;
	case 6:				/* Length */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		PlcProtLeng= data;
		if(PlcProtLeng <= 0){
			*CommMode = 8;
		}else{
			*CommMode = 7;
		}
		break;
	case 7:				/* Data */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		PlcProtLeng--;
		if(PlcProtLeng <= 0){
			*CommMode = 8;
		}
		break;
	case 8:				/* CRC1 */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		*CommMode = 9;
		break;
	case 9:				/* CRC2 */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		*CommMode = 99;
		ret= 0;
		break;
	}
	return(ret);
}
/************************************************/
/*	�O��?�v����								*/
/************************************************/
int	MakePLCgDevAddress(int mode, char *pDevice, int Address, int *DevAddr)
{
	int		i;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(((unsigned char)pDevice[0] == 0x7f) || ((unsigned char)pDevice[0] == 0xef)){		/* UB,UW */
		return(ret);
	}
	/* Device Name */
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrcmp(bPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrcmp(wPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address | 0x4000;
/*				*DevAddr = OffSet+ Address;*/
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
						MyAddress= DeviceDataSys[i].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
					MyAddress= DeviceDataSys[i].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN			   */
/*	2006.03.31 makebitpatarn �ϰ� ����         */
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/*	2006.03.31 makewordpatarn �ϰ� ����        */
/***************************************************/
void	MakeWordPatarn(int Start)
{

}
void	MakeMonitorBW(void)
{
	int		i;
	int		iAddr;

	/* Word Monitor */
	for(i= 0; i< DeviceCntSys; i++){
		if((DeviceDataSys[i].DevFlag == 1)  && (DeviceDataSys[i].DevCnt == 1) && (DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].Continus == 0)){
			if(MakePLCgDevAddress(DeviceDataSys[i].DevFlag, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress,&iAddr) == 0){
				PcThruAllData[4+gDeviceCnt*2]= iAddr;
				PcThruAllData[4+gDeviceCnt*2+1]= iAddr >> 8;
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
				DeviceDataSys[i].SameDevInf= -1;
				gDeviceCnt++;
				gDeviceCntWord++;
				if(gDeviceCnt > MAX_MON_WORDCNT){
					break;
				}
			}
		}
	}
	/* Bit Monitor */
	if(gDeviceCnt < MAX_MON_WORDCNT+1){
		for(i= 0; i< DeviceCntSys; i++){
			if((DeviceDataSys[i].DevFlag == 0) && (DeviceDataSys[i].DevCnt == 1) && (DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].Continus == 0)){
				if(MakePLCgDevAddress(DeviceDataSys[i].DevFlag, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress,&iAddr) == 0){
					PcThruAllData[4+gDeviceCnt*2]= iAddr;
					PcThruAllData[4+gDeviceCnt*2+1]= iAddr >> 8;
					gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
					DeviceDataSys[i].SameDevInf= -1;
					gDeviceCnt++;
					gDeviceCntBit++;
					if(gDeviceCnt > MAX_MON_BITCNT){
						break;
					}
				}
			}
		}
	}
	if(gDeviceCnt != 0){
		PcThruAllData[0]= DstStationNo;		/* DA */
		PcThruAllData[1]= MyStationNo;		/* SA */
		PcThruAllData[2]= BWD_RD2;			/* Command */
		PcThruAllData[3]= gDeviceCnt*2;			/* Length */
	}
}
/***************************************************/
/*	WORD GROUP-PATARN								*/
/***************************************************/
void	ClearBWContinue(void)
{
	int		i,j,idx;

	for(i= 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus != 0)){
			/* Continue */
			if(DeviceDataSys[i].DevFlag == 0){		/* BIT */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_BIT_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}else{									/* WORD */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_WORD_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	�O��?�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Same Device Check */
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	/* Word Device */
	gDeviceCnt= 0;
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	/* Monitor Check */
	if((BitCnt+WordCnt) < MAX_MON_WORDCNT){
		MakeMonitorBW();
		/* �r�b�g�A��?�h�̘A����?�F�b�N���� */
		MakeBitContinue();
		MakeWordContinue(TotalBitCnt);
	}else{
		/* �r�b�g�A��?�h�̘A����?�F�b�N���� */
		MakeBitContinue();
		MakeWordContinue(TotalBitCnt);
		MakeMonitorBW();
	}
	/* Continue MAX Check */
	ClearBWContinue();
	/* �r�b�g�A��?�h�̃p??����?�F�b�N���� */
	/* Bit Patarn */
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	/* Word Patarn */
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}
	return(0);
}
void	SendMonPlc(void)
{
	int		ret;
	int		SendCnt;

	if((PlcSendedFlag == 0) && (PlcThruMonDataCnt[0] != 0)){
		B_gmemcpy((char *)PlcSendBuff,(char *)PlcThruMonBuff[0],PlcThruMonDataCnt[0]);
		PlcSendBuff[0]= DstStationNo;		/* DA */
		PlcSendBuff[1]= MyStationNo;		/* SA */
		PlcSendBuff[2]= PlcSendBuff[2] | 0x20;		/* Command */
		SendCnt= PlcThruMonDataCnt[0]- 2;
		ret= SendRecPLCWithBCCCont(2,(char *)PlcSendBuff,PlcRecBuff,&SendCnt,0);
		if(ret == OK){
			B_gmemcpy((char *)PlcThruRecBuff,(char *)PlcRecBuff,SendCnt);
			PlcThruRecDataCnt[0]= SendCnt;
			PlcSendedFlag= 1;
		}else{
			PlcSendedFlag= 2;
		}
	}
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int		i;
	int		ret;
	int		Cnt;
	int		idx;
	char *SaveAddr;

	SetPlcSema();
	if(gDeviceCnt != 0){
		Cnt= gDeviceCnt*2+ 4;
		B_gmemcpy((char *)PlcSendBuff,(char *)PcThruAllData,Cnt);
		ret= SendCommandPLC(2,(char *)PlcSendBuff,(unsigned char *)PlcRecBuff,&Cnt,0);
		if(ret == 0){
			idx= 0;
			Cnt= 0;
			/* Word */
			for(i= 0; i < gDeviceCntWord; i++){
				SaveAddr= gDeviceAddr[idx];
#ifdef	SH_CPU
				*SaveAddr++ = PlcRecBuff[idx*2+4];
				*SaveAddr= PlcRecBuff[idx*2+5];
#endif
#ifdef	ARM_CPU
#ifdef	Win32
				*SaveAddr++ = PlcRecBuff[idx*2+4];
				*SaveAddr= PlcRecBuff[idx*2+5];
#else
				*SaveAddr++ = PlcRecBuff[idx*2+5];
				*SaveAddr= PlcRecBuff[idx*2+4];
#endif
#endif
				idx++;
			}
			Cnt= idx*2;
			/* Bit */
			for(i= 0; i < gDeviceCntBit; i++){
				SaveAddr= gDeviceAddr[idx];
				if(PlcRecBuff[Cnt+4+i] != 0){
					*SaveAddr= 1;
				}else{
					*SaveAddr= 0;
				}
				idx++;
			}
		}
	}
	SendMonPlc();
	ReSetPlcSema();
	return(0);
}
/************************************/
/*	�X��?��?�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	int		SendCnt;
	unsigned int _crc16;
	unsigned int rec_crc;
	int		i,j;

	_crc16 = 0xffff;
	for(i = 0; i < *RecCommCnt- 2; i++){
		_crc16= _crc16 ^ (CommBuff[i] & 0x00ff);
		for(j= 0; j < 8; j++){
			if((_crc16 & 0x0001) == 0x0001){
				_crc16= (_crc16 >> 1) ^ 0xa001;
			}else{
				_crc16= _crc16 >> 1;
			}
		}
	}
	rec_crc= (unsigned char)CommBuff[*RecCommCnt-2];
	rec_crc += (unsigned char)CommBuff[*RecCommCnt-1] << 8;
	if((Plc70PConnectFlag == 0) || (rec_crc != _crc16)){
		SetPlcSema();
		/* Un Commect */
		PlcSendBuff[0]= CommBuff[1];
		PlcSendBuff[1]= CommBuff[0];
		PlcSendBuff[2]= CommBuff[2] | 0x80;
		PlcSendBuff[3]= 0x01;
		PlcSendBuff[4]= 0x04;		/* Cpu Error */
		SendCnt= SetPLCBCC((char *)PlcSendBuff,5);
		/* Error Send To PC */
		B_SendPLC2PCData( 0,SendCnt,(char *)PlcSendBuff,2000 );
		ReSetPlcSema();
	}else{
		switch(CommBuff[2]){		/* Commnad */
		case 0:						/* 4�i��resp�v�� */
			while(1){
				if(PlcSendedFlag != 0){
					break;
				}
				B_Delay(50);
			}
			SetPlcSema();
			if(PlcSendedFlag == 1){
				B_gmemcpy((char *)PlcSendBuff,(char *)PlcThruRecBuff[0],PlcThruRecDataCnt[0]);
				PlcSendBuff[0]= PlcThruMonBuff[0][1];
				PlcSendBuff[1]= PlcThruMonBuff[0][0];
				PlcSendBuff[2]=	PlcSendBuff[2] & 0x1f | 0x80;
				SendCnt= SetPLCBCC((char *)PlcSendBuff,PlcThruRecDataCnt[0]- 2);
				/* Data Send To PC */
				B_SendPLC2PCData( 0,SendCnt,(char *)PlcSendBuff,2000 );
			}else{
				/* Disconnect */
				PlcSendBuff[0]= CommBuff[1];
				PlcSendBuff[1]= CommBuff[0];
				PlcSendBuff[2]= CommBuff[2] | 0x80;
				PlcSendBuff[3]= 0x01;
				PlcSendBuff[4]= 0x04;		/* Cpu Error */
				SendCnt= SetPLCBCC((char *)PlcSendBuff,5);
				/* Error Send To PC */
				B_SendPLC2PCData( 0,SendCnt,(char *)PlcSendBuff,2000 );
			}
			ReSetPlcSema();
			break;
		default:
			SetPlcSema();
			B_gmemcpy((char *)PlcThruMonBuff[0],CommBuff,*RecCommCnt);
			PlcThruMonDataCnt[0]= *RecCommCnt;
			PlcSendedFlag= 0;

			PlcSendBuff[0]= CommBuff[1];
			PlcSendBuff[1]= CommBuff[0];
			PlcSendBuff[2]= 0x80;
			PlcSendBuff[3]= 0x01;
			PlcSendBuff[4]= 0x00;	/* ACK */
			SendCnt= SetPLCBCC((char *)PlcSendBuff,5);
			/* ACK Send To PC */
			B_SendPLC2PCData( 0,SendCnt,(char *)PlcSendBuff,2000 );
			ReSetPlcSema();
			break;
		}
	}
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
#endif
/*++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(1);
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif


#include	"hook_aplplc.h"
/****************************** END **********************/

