#include	"sgt.h"

#ifdef	GP_S057

extern	void	SendInitTaskPar(int mcod,int mcmd,int mpar,int mext);

	extern	const	KEY_CHECK_DATA EnvKeyTbl[30];
	extern	const	KEY_CHECK_DATA1 EnvKeyTbl1[6];
	extern	_DISPLAY1	*DevDispName;
	extern	KEY_CHECK_DATA1	*DevDispKeyTbl;
	extern	_DISPLAY1 *LDspname;

const char	*KeyCodeData[3][18]={
	{"0","1","2","3","4","5","6","7",0},
	{"0","1","2","3","4","5","6","7","8","9",0},
	{"0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F",0},
};
const char *BS_Str= "BS";

//////////////////////////////////////////////////////////////////////
//	DEVICE	MONITOR													//
//////////////////////////////////////////////////////////////////////
/********************************************************************************/
/*	Device Monitor Menue														*/
/********************************************************************************/
void	MonitoringMode(int *iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iflag;
	int		iTotalCnt;

	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_DEV_MON_SEL,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(MONITORING,iTotalCnt);
	DrawLcdBank1();
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_DEV_MON_SEL-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SELECT_MEMU_NUM;
			EndFlag= 1;
			break;
		case KEY_DEV_MON:
			iflag = iSysSetretCheck(DEVICE_MONITORING_NUM);		/* Password */
			switch(iflag){
			case DOWN_TRANS:		/* DownLoad */
			case UP_TRANS:	/* UPLoad */
				*iScreenNo = iflag;
			default:
				if(iflag == 0)			/* ȭ���̵� ó�� */
				{
					*iScreenNo = DEVICE_MONITORING_NUM;											/*  ����̽� �����		 */
				}else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = MONITORING_NUM;
				}
				break;
			}
			EndFlag= 1;
			break;
		}
	}
}
int	CheckIndev(int idx)
{
	int		ret;
	char	cCodeData[3];

	strcpy(cCodeData,Device_Name[idx]);
	if((memcmp(cCodeData,"UB",2) == 0) || (memcmp(cCodeData,"UW",2) == 0)){
		ret= 1;		/* 040508 */
	}else{
		ret= 0;		/* 040508 */
	}
	return(ret);
}
/* ****************************************************************************** */
/*  �� �� �� : vDeviceDisplay()													 */
/*  ��    �� : DeviceMoniter�� ���� �����͸� Display �ϴ� ��					 */
/*  ��    �� : inowdev(����̽� ���� ����)										 */
/*  ��    �� : 																	 */
/*  �� �� �� : 2002�� 4�� 2�� (ȭ)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void	vDeviceDisplay(short  i, int inowdev)/* �ڵ�Ex,y,m...),��ȣ,�¿���,�� */
{	
/* 071108	char	cCodeData[3];*/
	char	cCodeData[10];
	char	chDsp_buff[30];
/* 071108	char	chDsp_buff1[10];*/
	char	chDsp_buff1[30];
	char	cDev_Rst[3];
/* 071108	char	chCur[6];	*/
	char	chCur[10];
	int		iNum;
	int		iOnOff;
	long	iValue;
	int		iRst;
	int		iSet;
	short	k;
	short	iInfo;
	int	iReturnData;
	int iAdd;
	int	UbUwFlag;		/* 040508 */


	int		iX;
	int		iY;

	/* leesi 0808 */
	_LINE_INFO param;
	_LINE_INFO param_Zero;

	param_Zero.iLineColor = BLACK;
	param_Zero.iLineStyle = NO_LINE;

	param.iLineColor = WHITE;
	param.iLineStyle = SOLID_LINE;
	/* leesi 0808 */
	iInfo	= 0;
	iOnOff	= 0;
	iValue	= 0;
	iRst	= 0;
	iSet	= 0;
	iX		= 0;
	iY		= 0;

	iNum	= BuffDip[i].iDev_NowNum;                   /* DevAddress */
	strcpy(cCodeData,Device_Name[BuffDip[i].cDev_Now]);
	if((memcmp(cCodeData,"UB",2) == 0) || (memcmp(cCodeData,"UW",2) == 0) || (PlcConnectFlag == 1)){
		UbUwFlag= 1;		/* 040508 */
	}else{
		UbUwFlag= 0;		/* 040508 */
	}

	if(BuffDip[i].iDev_Type == 1){						/* Bit */
		iOnOff = (int)iReturn_DevValue(0, inowdev);
	}else if(BuffDip[i].iDev_Type == 2 || BuffDip[i].iDev_Type == 3){	 /* 2:Word,3: Double Word */
		iValue = iReturn_DevValue(1, inowdev);
	}else if(BuffDip[i].iDev_Type == 4){			/* Bit + Word (Reset+ Set)*/
		iOnOff =  iReturn_DevValue(0, inowdev+1);	/* ���� ǥ��  */
		iRst = 0;
		if(RetrunSetVal(BuffDip[i].iDev_NowNum)){
			iSet = iReturn_DevValue(1, inowdev+2);	/* SET value  */
			itoa(iSet,chCur,10);
		}else{
			sprintf(chCur,"******");
		}
		iValue = iReturn_DevValue(1, inowdev);
	}
	
	switch(BuffDip[i].iDev_Type){
	case 4:			/* Bit + Word */
		if(iRst==1 && PlcConnectFlag != 0){/* (iRst==1 || iValue == 0) && PlcConnectFlag != 0 */
			sprintf(cDev_Rst,"��");
		}else{
			sprintf(cDev_Rst,"  ");
		}
		if(BuffDip[2].iDev_NowPoint == 0){
			sprintf(chDsp_buff1,"%s %5d",cCodeData,iNum);	/* ù��° ���� �� */
			if(PlcConnectFlag == 0){
				sprintf(chDsp_buff,"CUR[      ]");	/* ù��° ���� �� PLC ���� �� */
			}else{
				sprintf(chDsp_buff,"CUR[%6d]",iValue);	/* ù��° ���� ��  PLC ���� �� */			
			}
			DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+NLine_2,chDsp_buff1,1,1, TRANS, T_WHITE, T_BLACK);	
			DotTextOut(GAMEN_START_X+108,GAMEN_START_Y+NLine_2,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);

			LineOut(GAMEN_START_X+77, GAMEN_START_Y+33, GAMEN_START_X+81, GAMEN_START_Y+33,&param);			/*  ��ȣǥ�� ����  */
			LineOut(GAMEN_START_X+81, GAMEN_START_Y+26, GAMEN_START_X+81, GAMEN_START_Y+40,&param);
			LineOut(GAMEN_START_X+88, GAMEN_START_Y+26, GAMEN_START_X+88, GAMEN_START_Y+40,&param);
			LineOut(GAMEN_START_X+88, GAMEN_START_Y+33, GAMEN_START_X+92, GAMEN_START_Y+33,&param);			
			if(PlcConnectFlag != 0){
				if(iOnOff!=0){	/* ON ǥ�� */
					for(k=0;k<4;k++)
						LineOut(83+iX+k, 27+iY, 83+iX+k, 39+iY,&param);
				}else{			/* OFF ǥ�� */
					for(k=0;k<4;k++)
						LineOut(83+iX+k, 27+iY, 83+iX+k, 39+iY,&param_Zero);
				}
			}
			if(PlcConnectFlag == 0){
				memset(chCur,0x00,sizeof(chCur));
			}
			sprintf(chDsp_buff1,"RST - (%s)",cDev_Rst);				
			sprintf(chDsp_buff,"SET[%6s]",chCur);				
			DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+NLine_2+18,chDsp_buff1,1,1, TRANS, T_WHITE, T_BLACK);	
			DotTextOut(GAMEN_START_X+108,GAMEN_START_Y+NLine_2+18,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	
		}else{
			sprintf(chDsp_buff1,"RST - (%s)",cDev_Rst);				
			sprintf(chDsp_buff,"SET[%6s]",chCur);		
			DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+NLine_2,chDsp_buff1,1,1, TRANS, T_WHITE, T_BLACK);	
			DotTextOut(GAMEN_START_X+108,GAMEN_START_Y+NLine_2,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	
		}
		break;
	case 2:
	case 3:	 /* Word */
		if(strstr(cCodeData,"16") || strstr(cCodeData,"32")){
			iAdd = BuffDip[i].cDev_Now;
			iInfo = (Device_iType[iAdd]) & 0x000F;
			iReturnData= SetPLCUsrAddr(iInfo,iNum,(unsigned char)DeviceToIndexSet(1,Device_Name[iAdd]),1);

			if(cCodeData[1] == '1' || cCodeData[1] == '3'){
				sprintf(chDsp_buff1,"%c %5X",cCodeData[0],iReturnData);
			}else{
				sprintf(chDsp_buff1,"%c%c%5X",cCodeData[0],cCodeData[1],iReturnData);
			}
		}else{
			iAdd = BuffDip[i].cDev_Now;
			iInfo = (Device_iType[iAdd]) & 0x000F;
			iReturnData= SetPLCUsrAddr(iInfo,iNum,(unsigned char)DeviceToIndexSet(1,Device_Name[iAdd]),1);
			sprintf(chDsp_buff1,"%s %5X",cCodeData,iReturnData);				
		}

		if(BuffDip[i].iDev_Type == 3){		/* 32Bit(word)*/
			if(PlcConnectFlag != 0){
				sprintf(chDsp_buff,"CUR[%11d]",iValue);
			}else{
				if(UbUwFlag == 0){	/* 040508 */
					sprintf(chDsp_buff,"CUR[           ]");
				}else{		/* UB,UW */
					sprintf(chDsp_buff,"CUR[%11d]",iValue);
				}
			}
//			iX = 53;
			iX = 93;
		}else{
			if(PlcConnectFlag != 0){
				sprintf(chDsp_buff,"CUR[%6d]",iValue);
			}else{
				if(UbUwFlag == 0){	/* 040508 */
					sprintf(chDsp_buff,"CUR[      ]");
				}else{		/* UB,UW */
					sprintf(chDsp_buff,"CUR[%6d]",iValue);
				}
			}
			iX = 93;
		}
		iY= (iScreenNum- 1)/2*24;
		DotTextOut(4,(NLine_2+iY),chDsp_buff1,1,1, TRANS, T_WHITE, T_BLACK);	
		DotTextOut(15+iX,(NLine_2+iY),chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	
		break;
	case 1:						/* Bit */
		if(((iScreenNum- 1) % 2) == 0){
			iX = 0;
		}else{
			iX = 160;
		}
		iY= (iScreenNum- 1)/2*24;
		if(iOnOff!=0){	/* ON ǥ�� */
			for(k=0;k<4;k++)
				LineOut(83+iX+k, 27+iY, 83+iX+k, 39+iY,&param);
		}else{			/* OFF ǥ�� */
			for(k=0;k<4;k++){
				LineOut(83+iX+k, 27+iY, 83+iX+k, 39+iY,&param_Zero);
			}
		}
		LineOut(77+iX, 33+iY, 81+iX, 33+iY,&param);			/*  ��ȣǥ�� ����  */
		LineOut(81+iX, 26+iY, 81+iX, 40+iY,&param);
		LineOut(88+iX, 26+iY, 88+iX, 40+iY,&param);
		LineOut(88+iX, 33+iY, 92+iX, 33+iY,&param);

		iAdd = BuffDip[i].cDev_Now;
		iInfo = (Device_iType[iAdd]) & 0x000F;
		iReturnData= SetPLCUsrAddr(iInfo,iNum,(unsigned char)DeviceToIndexSet(0,Device_Name[iAdd]),0);

		sprintf(chDsp_buff,"%s %05X",cCodeData,iReturnData);				
		DotTextOut(6+iX,NLine_2+iY,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
		break;
	}
}
void	SetDevAddrKey(int idx,int *iNowInfo,int *iInfo)
{
	int		i,kind;

	*iInfo= Device_iType[idx] & 0x0f;
	*iNowInfo= 0;		//�W�i
	switch(*iInfo){
	case 0:
		break;
	case 1:
	case 3:
	case 4:
	case 9:
		*iNowInfo= 1;	//�P�O�i
		break;
	case 2:
	case 5:
	case 6:
	case 7:
	case 8:
		*iNowInfo= 2;	//�P�U�i
		break;
	}
	kind= *iNowInfo;
	for(i= 0; ; i++){
		if(KeyCodeData[kind][i] == NULL){
			break;
		}
		DevDispName->chName[0][i+3]= (char*)KeyCodeData[kind][i];
		DevDispName->chName[1][i+3]= (char*)KeyCodeData[kind][i];
		DevDispKeyTbl->KeyData[i+2].code= i;
	}
	//BS
	DevDispName->chName[0][22]= (char *)BS_Str;
	DevDispName->chName[1][22]= (char *)BS_Str;
	DevDispKeyTbl->KeyData[21].code= KEY_BS;
}
void	DisplaDeviceMon(int iPlus,char *chBuffData)
{
	int		i;
	int		inowdev;

	AreaClear(2,24,279,216,0);		/*AreaClear(1,20,238,58,0);*/
	inowdev = 0;
	for(i=0;i<MAX_DEVMON_CNT;i++){
		if(BuffDip[i].cDev_Now != -1){	
			iScreenNum = i+1;
			vDeviceDisplay(i,inowdev);
			BuffDip[i].iDev_Count = inowdev;
			inowdev++;
			/*030808*/
			if(BuffDip[i].iDev_Type == 4)
				inowdev = inowdev + iPlus;
		}
	}
	if(BuffDip[0].cDev_Now != -1)
	{
		if(BuffDip[NowDip.iDev_NowPoint].iDev_Type == 1) /* ���õ� ��ġ�� ����̽� Ÿ���� 1�̸� ��Ʈ */
		{
			AreaRevers(4+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),NLine_2+(((NowDip.iDev_NowPoint)/2)*24),
				95+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),15+NLine_2+(((NowDip.iDev_NowPoint)/2)*24)); 
		}
		else /* �׿� Ÿ���� ���� */
		{
			if(BuffDip[NowDip.iDev_NowPoint].iDev_Type == 3){	//32Bit
				AreaRevers(4+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),NLine_2+(((NowDip.iDev_NowPoint)/2)*24),
					235+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),15+NLine_2+(((NowDip.iDev_NowPoint)/2)*24)); 
			}else{
				AreaRevers(4+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),NLine_2+(((NowDip.iDev_NowPoint)/2)*24),
					195+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),15+NLine_2+(((NowDip.iDev_NowPoint)/2)*24)); 
			}
		}
	}
	for(i=0;i<inowdev;i++){
		if(DeviceDataHed[i].DevFlag == 0){
			memcpy(&chBuffData[i*5],DeviceDataHed[i].DevData,DeviceDataHed[i].DevCnt);
		}else{
			memcpy(&chBuffData[i*5],DeviceDataHed[i].DevData,DeviceDataHed[i].DevCnt*2);
		}
	}
	DrawLcdBank1();
}
int	GetBefPos(int kind)
{
	int	i;
	int	InsertPos;

	InsertPos= 0;
	//�O���󂯂�
	switch(kind){
	case 1:				//BIT
	case 2:
	case 3:
		for(i=MAX_DEVMON_CNT-3;i >= 0;i--){									/* ȭ���ʱ�ȭ ������ ���۸� �������. */
			BuffDip[i+2].iDev_NowPoint = i+3;
			BuffDip[i+2].iDev_NowNum = BuffDip[i].iDev_NowNum;
			BuffDip[i+2].cDev_Now = BuffDip[i].cDev_Now;
			BuffDip[i+2].iDev_Type = BuffDip[i].iDev_Type;
		}
		if(BuffDip[MAX_DEVMON_CNT-2].iDev_Type == 4){

			DeviceMonitorBuffClear(MAX_DEVMON_CNT-2,MAX_DEVMON_CNT);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */
		}
		DeviceMonitorBuffClear(0,2);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */

		break;
	case 4:
		for(i=MAX_DEVMON_CNT-5;i >= 0;i--){									/* ȭ���ʱ�ȭ ������ ���۸� �������. */
			BuffDip[i+4].iDev_NowPoint = i+5;
			BuffDip[i+4].iDev_NowNum = BuffDip[i].iDev_NowNum;
			BuffDip[i+4].cDev_Now = BuffDip[i].cDev_Now;
			BuffDip[i+4].iDev_Type = BuffDip[i].iDev_Type;
		}
		if(BuffDip[MAX_DEVMON_CNT-2].iDev_Type == 4){
			DeviceMonitorBuffClear(MAX_DEVMON_CNT-2,MAX_DEVMON_CNT);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */
		}
		DeviceMonitorBuffClear(0,4);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */

		break;
	}
	return(InsertPos);
}
int	GetInsertPos(int kind)
{
	int	i;
	int	InsertPos;

	InsertPos= 0;
	//�ŏI�s������
	switch(kind){
	case 1:			//Bit
		for(i= 0; i < MAX_DEVMON_CNT; i++){
			if(BuffDip[i].iDev_NowPoint == 0){
				if((i % 2) == 0){
					break;
				}else{
					if(i == (MAX_DEVMON_CNT-1)){
						break;
					}
					if(BuffDip[i+1].iDev_NowPoint == 0){
						break;
					}
				}
			}else{				//�O���a�����f??�Ō����g�p���Ă��Ȃ��ꍇ
				if(BuffDip[i].cDev_Now == -1){
					if((i % 2) == 0){
						break;
					}
					if((i % 2) && (BuffDip[i-1].iDev_Type == 1)){
						break;
					}
				}
			}
		}
		break;
	default:
		for(i= 0; i < MAX_DEVMON_CNT; i++){
//			if(BuffDip[i].iDev_NowPoint == 0){
			if(BuffDip[i].cDev_Now == -1){
				if((i % 2) == 0){
					break;
				}
			}
		}
		break;
	}
	InsertPos= i;
	//?���ʒu���󂯂�
	switch(kind){
	case 1:				//BIT
	case 2:
	case 3:
		if(i >= MAX_DEVMON_CNT){
			for(i= 0; i < MAX_DEVMON_CNT-2; i++){
				BuffDip[i].iDev_NowPoint = i+1;
				BuffDip[i].iDev_NowNum = BuffDip[i+2].iDev_NowNum;
				BuffDip[i].cDev_Now = BuffDip[i+2].cDev_Now;
				BuffDip[i].iDev_Type = BuffDip[i+2].iDev_Type;
			}

			DeviceMonitorBuffClear(MAX_DEVMON_CNT-2,MAX_DEVMON_CNT);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */
			InsertPos= MAX_DEVMON_CNT-2;
		}
		break;
	case 4:
		if(i == MAX_DEVMON_CNT){
			for(i=0;i<MAX_DEVMON_CNT-4;i++){									/* ȭ���ʱ�ȭ ������ ���۸� �������. */
				BuffDip[i].iDev_NowPoint = i+1;
				BuffDip[i].iDev_NowNum = BuffDip[i+4].iDev_NowNum;
				BuffDip[i].cDev_Now = BuffDip[i+4].cDev_Now;
				BuffDip[i].iDev_Type = BuffDip[i+4].iDev_Type;
			}
			DeviceMonitorBuffClear(MAX_DEVMON_CNT-4,MAX_DEVMON_CNT);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */
			InsertPos= MAX_DEVMON_CNT-4;
		}else if(i == MAX_DEVMON_CNT-2){
			if(BuffDip[0].iDev_Type == 4){
				for(i=0;i<MAX_DEVMON_CNT-6;i++){									/* ȭ���ʱ�ȭ ������ ���۸� �������. */
					BuffDip[i].iDev_NowPoint = i+1;
					BuffDip[i].iDev_NowNum = BuffDip[i+2].iDev_NowNum;
					BuffDip[i].cDev_Now = BuffDip[i+2].cDev_Now;
					BuffDip[i].iDev_Type = BuffDip[i+2].iDev_Type;
				}
				DeviceMonitorBuffClear(MAX_DEVMON_CNT-6,MAX_DEVMON_CNT);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */
				InsertPos= MAX_DEVMON_CNT-6;
			}else{
				for(i=0;i<MAX_DEVMON_CNT-2;i++){									/* ȭ���ʱ�ȭ ������ ���۸� �������. */
					BuffDip[i].iDev_NowPoint = i+1;
					BuffDip[i].iDev_NowNum = BuffDip[i+2].iDev_NowNum;
					BuffDip[i].cDev_Now = BuffDip[i+2].cDev_Now;
					BuffDip[i].iDev_Type = BuffDip[i+2].iDev_Type;
				}
				DeviceMonitorBuffClear(MAX_DEVMON_CNT-2,MAX_DEVMON_CNT);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */
				InsertPos= MAX_DEVMON_CNT-2;
			}
		}
		break;
	}
	return(InsertPos);
}
int	SetDeviceDispInfo(char *iNum,char *AddressBuff,int iData,int ErrFlag,int mode,int *devAddr,short *DevName)
{
	char	chType[3];
	int		iUpNum;
	int		iValue;
	int		iTrue;
	int		i;
//	int		j;
	int		iUpDown;
	int		NowPos;

	memset(chType,0,sizeof(chType));
	if((Device_iType[*iNum] & 0x40) != 0){
		iUpNum = 4;				/* 1:Bit 2,3:Word 4:Bit+Word */
	}else if((Device_iType[*iNum] & 0x100) != 0){
		if((Device_iType[*iNum] & 0x200) != 0){
			iUpNum = 3;				
		}else{
			iUpNum = 2;
		}
	}else{
		iUpNum = 1;				/* 1:Bit 2,3:Word 4:Bit+Word */
	}
	iValue		= gatoi(AddressBuff);
	chType[0]= *iNum;
	iUpDown = 0;
	if(iData == 0){
		iUpDown =_DOWN;
	}
	iTrue = vErrorCheck((char *)iNum, AddressBuff,iUpDown);
	if(iTrue == -1){
		if(ErrFlag == 1){						/* �ִ�E��?���� �� �ٽ� �Է� �޴´�. */
			if(iData == 1){						/*  iData==1 �̸�E�޼���E�ڽ��� ��Ÿ����.  */
				iCaptionWindow(Dspname[DEVICE_MONITORING].chName[Set.iLang][7],"");
			}
		}
	}else{		//Address OK
		if((iData == 1) || (iTrue == 2)){
			iValue		= gatoi(AddressBuff);
		}
		if(mode == 0){
			NowPos= GetInsertPos(iUpNum);
			ReturnDeviceName(&(BuffDip[NowPos].cDev_Now), chType, 2);	/* ������ */
			BuffDip[NowPos].iDev_NowNum = iValue;
			BuffDip[NowPos].iDev_NowPoint = NowPos+1;
			BuffDip[NowPos].iDev_Type = iUpNum;
			NowDip.cDev_Now = BuffDip[NowPos].cDev_Now;				/* ȭ��E��?���� ������ ���� */
			NowDip.iDev_NowNum = iValue;						/* ����E������ �Ϳ� ��E?������ ������E�ִ´�. */
			NowDip.iDev_NowPoint = NowPos;							/* ���õǾ�?E��ġ */
			NowDip.iDev_Type = BuffDip[NowPos].iDev_Type;
			switch(iUpNum){
			case 4:											/* BuffDip[].iDev_Type */ /* ����� ��Ʈ�� ���� �ִ� T,C ���� �͵�. */
				//�Q�s?���f�o�C�X�iWORD+BIT�j
				for(i= NowPos+1; i < NowPos+4; i++){
					BuffDip[NowPos].iDev_NowPoint= NowPos+1;
				}
				break;
			case 2:
			case 3:					/* Word�� ��� */
				//WORD DEVICE
				BuffDip[NowPos+1].iDev_NowPoint= NowPos+1;
				break;
			default:
				break;
			}
		}else{
			*devAddr= iValue;
			ReturnDeviceName(DevName, chType, 2);	/* ������ */
		}
	}
	return iTrue;
}
int	DeviceEntry(void)
{
	int	iDevDataPosition;
	int	i,j;
	int	iBitWordFlag;
	int	iPlus;
	char	chDev1Key[10];
	char	DevName[4];

	iPlus= 0;
	/* leesi 5.14 */
	if(BuffDip[0].cDev_Now != -1)
	{
		OnSignal(SGN_PLC,1);
		iDevDataPosition=0;
		DeviceCnt = 0;						/*  */
		memset(DeviceDataHed,0,sizeof(DeviceDataHed));
		/*****03_11_11*************************/
		memset(DeviceData,0x00,sizeof(DeviceData));
		/**************************************/
		j = 0;
		for(i=0;i<MAX_DEVMON_CNT;i++)
		{
			if(BuffDip[i].cDev_Now != -1)
			{	
				if(BuffDip[i].iDev_Type == 1)
					iBitWordFlag = 0;
				else 
					iBitWordFlag = 1;

				memset(chDev1Key, 0x00, sizeof(chDev1Key));
				strcpy(chDev1Key,Device_Name[BuffDip[i].cDev_Now]);
				DeviceDataHed[j].DevName[0] = DeviceToIndexSet(iBitWordFlag,chDev1Key);
				DeviceDataHed[j].DevName[1] = 0;
				DeviceDataHed[j].DevData	= &DeviceData[iDevDataPosition];
				DeviceDataHed[j].DevAddress = ReturnDevAddress(i);
				switch(BuffDip[i].iDev_Type){
					case 1:
						DeviceDataHed[j].DevFlag = DEVICE_BIT;
						DeviceDataHed[j].DevCnt = 1;
						iDevDataPosition++;
						break;
					case 2:		/*  Word */
						DeviceDataHed[j].DevFlag  = DEVICE_WORD;
						DeviceDataHed[j].DevCnt = 1;
						iDevDataPosition += 2;
						break;
					case 3:		/*	Word32  */
						DeviceDataHed[j].DevFlag  = DEVICE_WORD;
						DeviceDataHed[j].DevCnt = 2;
						iDevDataPosition += 4;
						break;

					case 4:
						/*  ����ġ ���� word */
						DeviceDataHed[j].DevFlag  = DEVICE_WORD;
						DeviceDataHed[j].DevCnt = 1;
						iDevDataPosition +=2;
						j++;
						/* ���� ���� bit */
						memset(chDev1Key, 0x00, sizeof(chDev1Key));
						strcpy(chDev1Key,Device_Name[BuffDip[i].cDev_Now]);
						DeviceDataHed[j].DevName[0] = DeviceToIndexSet(0,chDev1Key);
						DeviceDataHed[j].DevName[1] = 0;
						DeviceDataHed[j].DevData	= &DeviceData[iDevDataPosition];
						DeviceDataHed[j].DevAddress = ReturnDevAddress(i);
						
						DeviceDataHed[j].DevFlag	= DEVICE_BIT;
						DeviceDataHed[j].DevCnt		= 1;
						iDevDataPosition++;

						/***********************************/
						memset(DevName,0x00,sizeof(DevName));
						DevName[0] = DeviceToIndexSet(1,chDev1Key);
						j++;
						if(GetDevCntTime(1,DevName, (char *)DeviceDataHed[j].DevName)==0)
						{
							
							/* ����ġ ���� word */
							DeviceDataHed[j].DevName[1] = 0;
							DeviceDataHed[j].DevData	= &DeviceData[iDevDataPosition];
							DeviceDataHed[j].DevAddress = ReturnDevAddress(i);
							DeviceDataHed[j].DevFlag	= DEVICE_WORD;
							DeviceDataHed[j].DevCnt		= 1;
							iDevDataPosition += 2;
						}else
							j--;
						memset(DevName,0x00,sizeof(DevName));
						j++;
						DevName[0] = DeviceToIndexSet(0,chDev1Key);
						if(GetDevCntTime(0,DevName, (char *)DeviceDataHed[j].DevName)==0)
						{
							
							/* RET ���� Bit */
							DeviceDataHed[j].DevName[1] = 0;
							DeviceDataHed[j].DevData	= &DeviceData[iDevDataPosition];
							DeviceDataHed[j].DevAddress = ReturnDevAddress(i);
							DeviceDataHed[j].DevFlag	= DEVICE_BIT;
							DeviceDataHed[j].DevCnt		= 1;
							iDevDataPosition += 1;
						}else
							j--;
						/*************************************/

						iPlus = j;
						BuffDip[i].iPlus= j;
						break;
				}
				j++;

			}
		}
		DeviceCnt = j;
		OffSignal(SGN_PLC,1);
		Delay(100);
		SystemDevNoClearEntry();			/* */
		PlcDevInitRead(0);
		OnSignal(SGN_PLC,1);
	}
	return(iPlus);
}
/* ****************************************************************************** */
/*  ��E��E��E: vUpDisplay()														 */
/*  ��E   �� : UP �� ȭ�� ��ȭ												 */
/*  ��    �� :																	 */
/*  ÁE   �� : 																	 */
/*  �� �� �� : 2002��E4��E8��													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
int	CheckBefDevice(int idx)
{
	int		ret;

	ret= -1;
	if(idx > 0){
		idx--;
		if((BuffDip[idx].cDev_Now != -1) && (BuffDip[idx].iDev_NowPoint != 0)){
			ret= idx;
		}else if(((idx % 2) == 1) && (idx > 0) &&
			(BuffDip[idx-1].iDev_NowPoint != 0)){
			ret= idx-1;
		}
	}
	return(ret);
}
int vUpDisplay(void)
{
	int		iNowValue;
	int		i;
	int		iEscFlag;
	int     iRetVal;
	int		Address1;
	int		Address2;
	int		iDev_Type;
	char	chType[3];
	char	chData[10]; 

	iEscFlag	= 0;
	if(BuffDip[0].iDev_NowPoint != 0)
	{
		memset(chType,0,sizeof(chType));
		iNowValue = NowDip.iDev_NowPoint;
		iNowValue= CheckBefDevice(iNowValue);
		if(iNowValue != -1){
			//�J??���ړ��̂�
			NowDip.cDev_Now = BuffDip[iNowValue].cDev_Now;
			NowDip.iDev_NowNum = BuffDip[iNowValue].iDev_NowNum;
			NowDip.iDev_NowPoint = BuffDip[iNowValue].iDev_NowPoint-1;
			NowDip.iDev_Type = BuffDip[iNowValue].iDev_Type;
		}else{
			iDev_Type= BuffDip[0].iDev_Type;
			ReturnDeviceName(&(BuffDip[0].cDev_Now), chType,1);
			if(iDev_Type == 3){
				Address1= BuffDip[0].iDev_NowNum-2;
			}else if((Device_iType[BuffDip[NowDip.iDev_NowPoint].cDev_Now] & 0x000f) == 0x0009){
				Address1= BuffDip[0].iDev_NowNum-16;
			}else{
				Address1= BuffDip[0].iDev_NowNum-1;
			}
			itoa(Address1,chData,10);
			iRetVal = vErrorCheck(chType,chData,_UP);
			if((Address1 >= 0) && (iRetVal != -1))
			{	//�O�̃f�o�C�X�A�h���X�����݂���
				GetBefPos(iDev_Type);	//?���ʒu���󂯂�
				if(iDev_Type == 1){		//Bit�̏ꍇ�͂Q��?������
					Address2= Address1-1;
					itoa(Address2,chData,10);
					iRetVal = vErrorCheck(chType,chData,_UP);
					if((Address2 >= 0) && (iRetVal != -1)){
						//�Q�O�܂ő��݂���
						ReturnDeviceName(&(BuffDip[1].cDev_Now), chType, 2);	/* ������ */
						BuffDip[1].iDev_NowNum = Address1;
						BuffDip[1].iDev_NowPoint = 2;
						BuffDip[1].iDev_Type = iDev_Type;
						Address1= Address2;
						NowDip.cDev_Now = BuffDip[1].cDev_Now;
						NowDip.iDev_NowNum = BuffDip[1].iDev_NowNum;
						NowDip.iDev_NowPoint = BuffDip[1].iDev_NowPoint-1;
						NowDip.iDev_Type = BuffDip[1].iDev_Type;
					}else{
						NowDip.cDev_Now = BuffDip[0].cDev_Now;
						NowDip.iDev_NowNum = BuffDip[0].iDev_NowNum;
						NowDip.iDev_NowPoint = 0;
						NowDip.iDev_Type = BuffDip[0].iDev_Type;
					}
					ReturnDeviceName(&(BuffDip[0].cDev_Now), chType, 2);	/* ������ */
					BuffDip[0].iDev_NowNum = Address1;
					BuffDip[0].iDev_NowPoint = 1;
					BuffDip[0].iDev_Type = iDev_Type;
				}else{
					ReturnDeviceName(&(BuffDip[0].cDev_Now), chType, 2);	/* ������ */
					BuffDip[0].iDev_NowNum = Address1;
					BuffDip[0].iDev_NowPoint = 1;
					BuffDip[0].iDev_Type = iDev_Type;
					NowDip.cDev_Now = BuffDip[0].cDev_Now;
					NowDip.iDev_NowNum = BuffDip[0].iDev_NowNum;
					NowDip.iDev_NowPoint = BuffDip[0].iDev_NowPoint-1;
					NowDip.iDev_Type = BuffDip[0].iDev_Type;
					switch(iDev_Type){
					case 4:											/* BuffDip[].iDev_Type */ /* ����� ��Ʈ�� ���� �ִ� T,C ���� �͵�. */
						//�Q�s?���f�o�C�X�iWORD+BIT�j
						for(i= 1; i < 4; i++){
							BuffDip[i].iDev_NowPoint= 1;
						}
						break;
					case 2:
					case 3:					/* Word�� ��� */
						//WORD DEVICE
						BuffDip[1].iDev_NowPoint= 1;
						break;
					default:
						break;
					}
				}
			}
		}
	}
	return iEscFlag;
}
/* ****************************************************************************** */
/*  ��E��E��E: vDownDisplay()													 */
/*  ��E   �� : DOWN�� ȭ�� ��ȭ 												 */
/*  ��    �� :																	 */
/*  ÁE   �� : 																	 */
/*  �� �� �� : 2002��E4��E8��													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
int	CheckNextDevice(int idx)
{
	int		ret;

	ret= -1;
	switch(BuffDip[idx-1].iDev_Type){
	case 1:		//Bit
		break;
	case 2:
	case 3:
		idx++;
		break;
	case 4:
		idx++;
		idx++;
		idx++;
		break;
	}
	if(idx < MAX_DEVMON_CNT){ 
		if(BuffDip[idx].iDev_NowPoint != 0){
			if(BuffDip[idx].cDev_Now != -1){
				ret= idx;
			}else{
				if((idx < MAX_DEVMON_CNT-1) && (BuffDip[idx+1].cDev_Now != -1)){
					ret= idx+1;
				}
			}
		}else if(((idx % 2) == 1) && (idx < MAX_DEVMON_CNT-1) &&
			(BuffDip[idx+1].iDev_NowPoint != 0)){
			ret= idx+1;
		}
	}
	return(ret);
}
int vDownDisplay(void)
{
	int		iNowValue;
	char	chType[3];
	char	chData[10]; 
	int		iEscFlag;
//	short	iFlag;

	iEscFlag = 0;
//	iFlag = 0;
	if(BuffDip[0].iDev_NowPoint != 0){
		memset(chType,0,sizeof(chType));
		iNowValue = NowDip.iDev_NowPoint;	//���݂̃J??���ʒu

		iNowValue= CheckNextDevice(iNowValue+1);
		if(iNowValue != -1){
			//�J??���ړ��̂�
			NowDip.cDev_Now = BuffDip[iNowValue].cDev_Now;
			NowDip.iDev_NowNum = BuffDip[iNowValue].iDev_NowNum;
			NowDip.iDev_NowPoint = BuffDip[iNowValue].iDev_NowPoint-1;
			NowDip.iDev_Type = BuffDip[iNowValue].iDev_Type;
		}else{
			ReturnDeviceName(&(BuffDip[NowDip.iDev_NowPoint].cDev_Now), chType,1);
//			itoa(BuffDip[NowDip.iDev_NowPoint].iDev_NowNum+1,chData,10);
			if(BuffDip[NowDip.iDev_NowPoint].iDev_Type==3)
				itoa(BuffDip[NowDip.iDev_NowPoint].iDev_NowNum+2,chData,10);	
			else if((Device_iType[BuffDip[NowDip.iDev_NowPoint].cDev_Now] & 0x000f) == 0x0009)
				itoa(BuffDip[NowDip.iDev_NowPoint].iDev_NowNum+16,chData,10);
			else
				itoa(BuffDip[NowDip.iDev_NowPoint].iDev_NowNum+1,chData,10);
			SetDeviceDispInfo(chType,chData,0,0,0,NULL,NULL);
		}
	}
	return iEscFlag;
}
/********************************************************************************/
/*	Device Data Input															*/
/********************************************************************************/
int	vDeviceDataInput(void)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		ret,i,j;
	int		iNum;
	int		iMax,iMin,iLen;
	int		FirstFlag;
	char	dspbuff[32];
	char	InputStr[16];
	char	WorkStr[16];

	SetWindowNo(SCREEN_1);
	SetStartPos(SCREEN_1,KEYSWITCH_X_OFFSET_DOT,KEYSWITCH_Y_OFFSET_DOT);
	SetWindowInfo(SCREEN_1,0);
	OpenWindow(SCREEN_1,DEV_GAMEN_X_SIZE,DEV_GAMEN_Y_SIZE);
	ClearDispBuff(SCREEN_1);					/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_DEVICE_IN,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DevDispName= (_DISPLAY1 *)TakeMemory(sizeof(_DISPLAY1));
	DevDispKeyTbl= (KEY_CHECK_DATA1 *)TakeMemory(sizeof(KEY_CHECK_DATA1));
	//���̃f??���R�s?����B
	memcpy((char *)DevDispName,&LDspname[3],sizeof(_DISPLAY1));
	memcpy((char *)DevDispKeyTbl,&EnvKeyTbl1[5],sizeof(KEY_CHECK_DATA1));
	//Decimal Key Set
	for(i= 0; ; i++){
		if(KeyCodeData[1][i] == NULL){
			break;
		}
		DevDispName->chName[0][i+3]= (char *)KeyCodeData[1][i];
		DevDispName->chName[1][i+3]= (char *)KeyCodeData[1][i];
		DevDispKeyTbl->KeyData[i+2].code= i;
	}
	//BS
	DevDispName->chName[0][22]= (char *)BS_Str;
	DevDispName->chName[1][22]= (char *)BS_Str;
	DevDispKeyTbl->KeyData[21].code= KEY_BS;

	DispTextData(DEVMON_SELECT,iTotalCnt);
	//Device Data Read
	if(NowDip.iDev_Type == 3){
		iMax = 2147483647;
		iMin = -2147483647;
		iLen = 11;
	}else{
		iMax = 32767;
		iMin = -32768;
		iLen = 6;
	}
	ret = iReturn_DevValue(1, BuffDip[NowDip.iDev_NowPoint].iDev_Count);
	switch(NowDip.iDev_Type){								/*  �� ��ġ�� ��E?�ִ�E��?�ִ´�.  */
		case 2:
		case 4:
			sprintf(InputStr,"%6d",ret);
			break;
		case 3:
			sprintf(InputStr,"%11d",ret);
			break;
		default:
			return 0;	
	}
	
	sprintf(dspbuff,"%s",InputStr);
	DispTextSetItemDataCursor(KEY_SEL_DISP,dspbuff);
	DrawLcdBank1();
	EndFlag= 0;
	ret= 0;
	FirstFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA*)DevDispKeyTbl);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			ret = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			ret = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_CLK_CLR:
			EndFlag= 1;
			break;
		case KEY_CLK_ENT:
			//���̓f??�����o���B
			for(i= 0,j= 0; i < iLen; i++){
				if(InputStr[i] != ' '){
					WorkStr[j++]= InputStr[i];
				}
			}
			WorkStr[j]= 0;
			iNum = gatoi(WorkStr);
			if((iNum > iMax || iNum < iMin) && NowDip.iDev_Type != 3)								/*  ��E��?����E���� �濁E */
			{
				iCaptionWindow(Dspname[SET_FUNTION].chName[Set.iLang][12],"");			/*  ��ư �ϳ��� �޼���E�ڽ�	 */	
				SetWindowNo(SCREEN_1);
				DrawLcdBank1();
			}else{
				switch(NowDip.iDev_Type)								/*  �� ��ġ�� ��E?�ִ�E��?�ִ´�.  */
				{
				case 2:
				case 3:
					iReturn_DevValue(3, iNum);
					break;

				case 4:
					if(iLen==0){										/* ����ġ ������ �濁E*/
						iReturn_DevValue(3, iNum);
					}else{												/* ����ġ ������ �濁E*/
							iReturn_DevValue(5, iNum);
					}
					break;
				}
				EndFlag= 1;
			}
			break;
		case KEY_BS:
			if(FirstFlag != 0){
				for(i= iLen-1; i > 0; i--){
					InputStr[i]= InputStr[i-1];
				}
				InputStr[0]= ' ';
				ClearTextItemData1(KEY_SEL_DISP);
				sprintf(dspbuff,"%s",InputStr);
				DispTextSetItemDataCursor(KEY_SEL_DISP,dspbuff);
				DrawLcdBank1();
			}
			break;
		default:
			if(iKeyCode != KEY_NO_DATA){
				if(FirstFlag == 0){
					FirstFlag= 1;
					memset(InputStr,' ',sizeof(InputStr));
					InputStr[iLen]= 0;
				}
				for(i= 0; i < iLen; i++){
					InputStr[i]= InputStr[i+1];
				}
				InputStr[iLen-1]= Bin2Hex1(iKeyCode);
				ClearTextItemData1(KEY_SEL_DISP);
				sprintf(dspbuff,"%s",InputStr);
				DispTextSetItemDataCursor(KEY_SEL_DISP,dspbuff);
				DrawLcdBank1();
			}
			break;
		}
	}
	FreeMail((char *)DevDispName);
	FreeMail((char *)DevDispKeyTbl);
	CloseWindow(SCREEN_1);
	SetWindowNo(SCREEN_0);
	DrawLcdBank1();
	return(ret);
}
/********************************************************/
/*	IN:	char* chKey:OldDisplay Data						*/
/*		char* chKey1:New Data							*/
/*		int* iSize:Input Length							*/
/********************************************************/
int	iNumInput1(char* chKey,char* chKey1,int* iSize)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		ret,i,j;
	int		iNum;
	int		iMax,iMin,iLen;
	int		FirstFlag;
	char	dspbuff[32];
	char	InputStr[16];
	char	WorkStr[16];

	SetWindowNo(SCREEN_1);
	SetStartPos(SCREEN_1,KEYSWITCH_X_OFFSET_DOT,KEYSWITCH_Y_OFFSET_DOT);
	SetWindowInfo(SCREEN_1,0);
	OpenWindow(SCREEN_1,DEV_GAMEN_X_SIZE,DEV_GAMEN_Y_SIZE);
	ClearDispBuff(SCREEN_1);					/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_DEVICE_IN,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DevDispName= (_DISPLAY1 *)TakeMemory(sizeof(_DISPLAY1));
	DevDispKeyTbl= (KEY_CHECK_DATA1 *)TakeMemory(sizeof(KEY_CHECK_DATA1));
	//���̃f??���R�s?����B
	memcpy((char *)DevDispName,&LDspname[3],sizeof(_DISPLAY1));
	memcpy((char *)DevDispKeyTbl,&EnvKeyTbl1[5],sizeof(KEY_CHECK_DATA1));
	//Decimal Key Set
	for(i= 0; ; i++){
		if(KeyCodeData[1][i] == NULL){
			break;
		}
		DevDispName->chName[0][i+3]= (char *)KeyCodeData[1][i];
		DevDispName->chName[1][i+3]= (char *)KeyCodeData[1][i];
		DevDispKeyTbl->KeyData[i+2].code= i;
	}
	//BS
	DevDispName->chName[0][22]= (char *)BS_Str;
	DevDispName->chName[1][22]= (char *)BS_Str;
	DevDispKeyTbl->KeyData[21].code= KEY_BS;

	DispTextData(DEVMON_SELECT,iTotalCnt);
	if(*iSize == 2){		//GP Station	
		iMax = 31;
		iMin = 0;
	}else{					//PLC Station
		iMax = 255;
		iMin = 0;
	}
	iLen = *iSize;

	strcpy(InputStr,chKey);
	strcpy(dspbuff,chKey);
	DispTextSetItemDataCursor(KEY_SEL_DISP,dspbuff);
	DrawLcdBank1();
	EndFlag= 0;
	ret= 0;
	FirstFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA*)DevDispKeyTbl);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			ret = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			ret = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_CLK_CLR:
/* 20081002 */
			strcpy(InputStr,chKey);
			EndFlag= 1;
			break;
		case KEY_CLK_ENT:
			//���̓f??�����o���B
			for(i= 0,j= 0; i < iLen; i++){
				if(InputStr[i] != ' '){
					WorkStr[j++]= InputStr[i];
				}
			}
			WorkStr[j]= 0;
			iNum = gatoi(WorkStr);
			if((iNum > iMax || iNum < iMin) && NowDip.iDev_Type != 3)								/*  ��E��?����E���� �濁E */
			{
				iCaptionWindow(Dspname[SET_FUNTION].chName[Set.iLang][12],"");			/*  ��ư �ϳ��� �޼���E�ڽ�	 */	
				SetWindowNo(SCREEN_1);
				DrawLcdBank1();
			}else{
/* 20081002 */
//				switch(NowDip.iDev_Type)								/*  �� ��ġ�� ��E?�ִ�E��?�ִ´�.  */
//				{
//				case 2:
//				case 3:
//					iReturn_DevValue(3, iNum);
//					break;

//				case 4:
//					if(iLen==0){										/* ����ġ ������ �濁E*/
//						iReturn_DevValue(3, iNum);
//					}else{												/* ����ġ ������ �濁E*/
//							iReturn_DevValue(5, iNum);
//					}
//					break;
//				}
				EndFlag= 1;
			}
			break;
		case KEY_BS:
			if(FirstFlag != 0){
				for(i= iLen-1; i > 0; i--){
					InputStr[i]= InputStr[i-1];
				}
				InputStr[0]= ' ';
				ClearTextItemData1(KEY_SEL_DISP);
				sprintf(dspbuff,"%s",InputStr);
				DispTextSetItemDataCursor(KEY_SEL_DISP,dspbuff);
				DrawLcdBank1();
			}
			break;
		default:
			if(iKeyCode != KEY_NO_DATA){
				if(FirstFlag == 0){
					FirstFlag= 1;
					memset(InputStr,' ',sizeof(InputStr));
					InputStr[iLen]= 0;
				}
				for(i= 0; i < iLen; i++){
					InputStr[i]= InputStr[i+1];
				}
				InputStr[iLen-1]= Bin2Hex1(iKeyCode);
				ClearTextItemData1(KEY_SEL_DISP);
				sprintf(dspbuff,"%s",InputStr);
				DispTextSetItemDataCursor(KEY_SEL_DISP,dspbuff);
				DrawLcdBank1();
			}
			break;
		}
	}
	FreeMail((char *)DevDispName);
	FreeMail((char *)DevDispKeyTbl);
	CloseWindow(SCREEN_1);
	SetWindowNo(SCREEN_0);
	DrawLcdBank1();
	strcpy(chKey,InputStr);
	return(ret);
}
/********************************************************************************/
/*	Device Address Input														*/
/********************************************************************************/
int	vDeviceAddressInput(int idx,int mode,int *DevAddr,short *DevName)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		ret,i,j;
	int		iNowInfo;
	int		iTrue;
	int		iInfo;
	char	iNum[2];
	char	dspbuff[32];
	char	InputStr[8];
	char	WorkStr[8];

	memset(iNum,0,sizeof(iNum));	
	memset(InputStr,' ',sizeof(InputStr));
	InputStr[5]= 0;
	ClearDispBuff(SCREEN_1);					/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_DEVICE_IN,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	//���̃f??���R�s?����B
	memcpy((char *)DevDispName,&LDspname[3],sizeof(_DISPLAY1));
	memcpy((char *)DevDispKeyTbl,&EnvKeyTbl1[5],sizeof(KEY_CHECK_DATA1));
	//Hex,Decimal,Octal-Key Set
	SetDevAddrKey(idx,&iNowInfo,&iInfo);
	DispTextData(DEVMON_SELECT,iTotalCnt);
	sprintf(dspbuff,"%s         %s",Device_Name[idx],InputStr);		//20081002 Space Delete(1)
	DispTextSetItemDataCursor(KEY_SEL_DISP,dspbuff);
	DrawLcdBank1();
	EndFlag= 0;
	ret= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA*)DevDispKeyTbl);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			ret = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			ret = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_CLK_CLR:
			EndFlag= 1;
			break;
		case KEY_CLK_ENT:
			//���̓f??�����o���B
			for(i= 0,j= 0; i < 5; i++){
				if(InputStr[i] != ' '){
					WorkStr[j++]= InputStr[i];
				}
			}
			WorkStr[j]= 0;
			iTrue = 0;
			if(!(iInfo == 0 || iInfo == 4 || iInfo == 8 || iInfo == 9)){
//				iTrue= shDevInfoTypeChk(WorkStr,iNowInfo);
				iTrue= shDevInfoTypeChk(WorkStr,iInfo);		//20100227, 
			}
			if(iTrue != -1){
				iNum[0]= idx;
				if(mode == 0){	//Dev Moni
					iTrue = SetDeviceDispInfo(&iNum[0],WorkStr,1,1,0,NULL,NULL);/*  1�� �����޼����ڽ��� ǥ���ϱ�����  */
				}else{			//Time Switch
					iTrue = SetDeviceDispInfo(&iNum[0],WorkStr,1,1,1,DevAddr,DevName);/*  1�� �����޼����ڽ��� ǥ���ϱ�����  */
				}
			}
			if(iTrue != -1){
				EndFlag= 1;
			}else{	//�f�o�C�X�G��?�̎�
				SetWindowNo(SCREEN_1);
				DrawLcdBank1();
			}
			break;
		case KEY_BS:
			for(i= 4; i > 0; i--){
				InputStr[i]= InputStr[i-1];
			}
			InputStr[0]= ' ';
			ClearTextItemData1(KEY_SEL_DISP);
			sprintf(dspbuff,"%s         %s",Device_Name[idx],InputStr);
			DispTextSetItemDataCursor(KEY_SEL_DISP,dspbuff);
			DrawLcdBank1();
			break;
		default:
			if(iKeyCode != KEY_NO_DATA){
				for(i= 0; i < 4; i++){
					InputStr[i]= InputStr[i+1];
				}
				InputStr[4]= Bin2Hex1(iKeyCode);
				ClearTextItemData1(KEY_SEL_DISP);
				sprintf(dspbuff,"%s         %s",Device_Name[idx],InputStr);
				DispTextSetItemDataCursor(KEY_SEL_DISP,dspbuff);
				DrawLcdBank1();
			}
			break;
		}
	}
	return(ret);
}
void	SetDevName(void)
{
	int		i,idx;

	//BitDevice
	for(i= 0,idx= 0; (i < 16) && (idx < 10); i++){
		if(Device_iType[i] == 0){
			break;
		}
		if((Device_iType[i] & 0x100) == 0){		//Bit Device
			DevDispName->chName[0][idx+3]= Device_Name[i];
			DevDispName->chName[1][idx+3]= Device_Name[i];
			DevDispKeyTbl->KeyData[idx+2].code= i;
			idx++;
		}
	}
	//Word Device
	for(i= 0,idx= 0; (i < 16) && (idx < 10); i++){
		if(Device_iType[i] == 0){
			break;
		}
		if((Device_iType[i] & 0x100) != 0){		//Bit Device
			DevDispName->chName[0][idx+13]= Device_Name[i];
			DevDispName->chName[1][idx+13]= Device_Name[i];
			DevDispKeyTbl->KeyData[idx+12].code= i;
			idx++;
		}
	}
}
/********************************************************************************/
/*	Device Input																*/
/********************************************************************************/
int	vDeviceInput(int mode,int *DevAddr,short *DevName)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		ret;

	SetWindowNo(SCREEN_1);
	SetStartPos(SCREEN_1,KEYSWITCH_X_OFFSET_DOT,KEYSWITCH_Y_OFFSET_DOT);
	SetWindowInfo(SCREEN_1,0);
	OpenWindow(SCREEN_1,DEV_GAMEN_X_SIZE,DEV_GAMEN_Y_SIZE);
	ClearDispBuff(SCREEN_1);					/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_DEVICE_IN,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DevDispName= (_DISPLAY1 *)TakeMemory(sizeof(_DISPLAY1));
	memcpy((char *)DevDispName,&LDspname[3],sizeof(_DISPLAY1));
	DevDispKeyTbl= (KEY_CHECK_DATA1 *)TakeMemory(sizeof(KEY_CHECK_DATA1));
	memcpy((char *)DevDispKeyTbl,&EnvKeyTbl1[5],sizeof(KEY_CHECK_DATA1));
	SetDevName();
	DispTextData(DEVMON_SELECT,iTotalCnt);
	DrawLcdBank1();
	EndFlag= 0;
	ret= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA*)DevDispKeyTbl);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			ret = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			ret = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_CLK_CLR:
			ret= -1;
			EndFlag= 1;
			break;
		case KEY_CLK_ENT:
//			EndFlag= 1;
			break;
		default:
			if(iKeyCode != KEY_NO_DATA){
				if(mode == 0){		//Device Mon
					ret= vDeviceAddressInput(iKeyCode,0,NULL,NULL);
				}else{
					ret= vDeviceAddressInput(iKeyCode,1,DevAddr,DevName);
				}
			}
			EndFlag= 1;
			break;
		}
	}
	FreeMail((char *)DevDispName);
	FreeMail((char *)DevDispKeyTbl);
	CloseWindow(SCREEN_1);
	SetWindowNo(SCREEN_0);
	DrawLcdBank1();
	return(ret);
}
/********************************************************************************/
/*	Device Monitor																*/
/********************************************************************************/
void	vDeviceMoni(int *iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		iDataTrans;
	int		iPlus;
	char	*chDispBuff;

	KerRepeatFlag = 1;	/* 080117 */
	RepeatInfo.EntryCnt = 2;
	RepeatInfo.RepeatNo[0][0] = (char)31;
	RepeatInfo.RepeatNo[0][1] = (char)32;
	RepeatInfo.RepeatNo[1][0] = (char)191;
	RepeatInfo.RepeatNo[1][1] = (char)192;
	ClearDispBuff(SCREEN_0);					/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_DEV_MON,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(DEVICE_MONITORING,iTotalCnt);
	DrawLcdBank1();
	DeviceTableSet(0);		/* ǥ���� Device Name Set */
	chDispBuff= TakeMemory(5*MAX_DEVMON_CNT);
	iPlus= DeviceEntry();
	DisplaDeviceMon(iPlus,chDispBuff);
	OnSignal(S_ENV,0x0003);			//State Start
	SendInitTaskPar(INI_ENV_DEVMON,1,(unsigned long)chDispBuff,0);
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA*)&EnvKeyTbl1[4]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = MONITORING_NUM;
			EndFlag= 1;
			break;
		case KEY_DEVICE:
			OffSignal(S_ENV,0x0001);			//State End
			iDataTrans = vDeviceInput(0,NULL,NULL);
			if(iDataTrans == DOWN_TRANS || iDataTrans == UP_TRANS){
				*iScreenNo = iDataTrans;
				return;
			}
			iPlus= DeviceEntry();
			DisplaDeviceMon(iPlus,chDispBuff);
			OnSignal(S_ENV,0x0001);			//State Start
			break;
		case KEY_SET:
/*			if(NowDip.iDev_Type != 1){*/
			if(NowDip.iDev_Type > 1){		/* 2008.11.21 */
				if((PlcConnectFlag != 0) ||
					(CheckIndev(NowDip.cDev_Now) == 1)){
					OffSignal(S_ENV,0x0001);			//State End
					vDeviceDataInput();
					OnSignal(S_ENV,0x0001);			//State Start
				}
			}
			break;
		case KEY_ON:
			switch(NowDip.iDev_Type){
			case 1:				
				iReturn_DevValue(2, 1);
				break;
			case 4:
				iReturn_DevValue(4, 1);
				break;
			}
			break;
		case KEY_OFF:
			switch(NowDip.iDev_Type){
			case 1:	
				iReturn_DevValue(2, 0);
				break;
			case 4:
				iReturn_DevValue(4, 0);
				break; 
			}
			break;
		case KEY_UP:
			OffSignal(S_ENV,0x0001);			//State End
			vUpDisplay();
			iPlus= DeviceEntry();
			DisplaDeviceMon(iPlus,chDispBuff);
			OnSignal(S_ENV,0x0001);			//State Start
			break;
		case KEY_DOWN:
			OffSignal(S_ENV,0x0001);			//State End
			vDownDisplay();
			iPlus= DeviceEntry();
			DisplaDeviceMon(iPlus,chDispBuff);
			OnSignal(S_ENV,0x0001);			//State Start
			break;
		}
	}
	FreeMail(chDispBuff);
	OffSignal(S_ENV,0x0003);			//State Start
	Delay(100);
	KerRepeatFlag = 0;	/* 080117 */
	RepeatInfo.EntryCnt = 0;
}
void	DispEnvDeviceMon(T_MAIL *mp)
{
	int		i;
	int		signal;
	int		inowdev;
	char	*chBuffData;
	int		iEscFlag;
	int		SavePlcConnectFlag;
	int		WorkPlcConnectFlag;

	chBuffData= (char *)mp->mpar;
	SetWindowNo(SCREEN_0);
	SavePlcConnectFlag= PlcConnectFlag;
	while(1){
		signal= ReadSignal(S_ENV);
		if((signal & 0x0002) == 0){
			break;
		}
		signal= ReadSignal(S_ENV);
		if((signal & 0x0001) == 0){
			Delay(100);
			continue;
		}
		inowdev = 0;
		WorkPlcConnectFlag= PlcConnectFlag;
		for(i=0;i<MAX_DEVMON_CNT;i++){
			if(BuffDip[i].cDev_Now == -1){
				continue;
			}
			iEscFlag= 0;
			if(SavePlcConnectFlag != WorkPlcConnectFlag){
				iEscFlag = 1;
			}else{
				if(DeviceDataHed[inowdev].DevFlag == 0){
					if(memcmp(&chBuffData[inowdev*5],DeviceDataHed[inowdev].DevData,DeviceDataHed[inowdev].DevCnt) != 0){
						iEscFlag = 1;
					}
				}else{
					if(memcmp(&chBuffData[inowdev*5],DeviceDataHed[inowdev].DevData,DeviceDataHed[inowdev].DevCnt*2) != 0){
						iEscFlag = 1;
					}
				}
			}
			if(iEscFlag == 1){
				//�J??������
				if(NowDip.iDev_NowPoint == i){
					if(BuffDip[NowDip.iDev_NowPoint].iDev_Type == 1){
						AreaClear(4+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),NLine_2+(((NowDip.iDev_NowPoint)/2)*24),
							95+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),15+NLine_2+(((NowDip.iDev_NowPoint)/2)*24),0); 
					}else{
						AreaClear(4+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),NLine_2+(((NowDip.iDev_NowPoint)/2)*24),
							195+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),15+NLine_2+(((NowDip.iDev_NowPoint)/2)*24),0); 
					}
				}
				iScreenNum = i+1;
				vDeviceDisplay(i,inowdev);
				BuffDip[i].iDev_Count = inowdev;
				if(NowDip.iDev_NowPoint == i){
					//�J??��?��
					if(BuffDip[NowDip.iDev_NowPoint].iDev_Type == 1){
						AreaRevers(4+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),NLine_2+(((NowDip.iDev_NowPoint)/2)*24),
							95+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),15+NLine_2+(((NowDip.iDev_NowPoint)/2)*24)); 
					}else{
						AreaRevers(4+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),NLine_2+(((NowDip.iDev_NowPoint)/2)*24),
							195+((NowDip.iDev_NowPoint+1)%2==0 ? 160 : 0),15+NLine_2+(((NowDip.iDev_NowPoint)/2)*24)); 
					}
				}
				if(DeviceDataHed[inowdev].DevFlag == 0){
					memcpy(&chBuffData[inowdev*5],DeviceDataHed[inowdev].DevData,DeviceDataHed[inowdev].DevCnt);
				}else{
					memcpy(&chBuffData[inowdev*5],DeviceDataHed[inowdev].DevData,DeviceDataHed[inowdev].DevCnt*2);
				}
			}
			inowdev++;
			if(BuffDip[i].iDev_Type == 4){
				inowdev = inowdev + BuffDip[i].iPlus;
			}
		}
		DrawLcdBank1();
		Delay(100);
		if(SavePlcConnectFlag != WorkPlcConnectFlag){
			SavePlcConnectFlag= WorkPlcConnectFlag;
		}
	}
}
/********************************************************************************/
/*	Time Data Input																*/
/********************************************************************************/
int	vTimeInput(int kind,char *initdata)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		ret,i,j;
	int		iNum;
	int		iMax,iMin,iLen;
	int		FirstFlag;
	char	dspbuff[32];
	char	InputStr[16];
	char	WorkStr[16];


	SetWindowNo(SCREEN_1);
	SetStartPos(SCREEN_1,KEYSWITCH_X_OFFSET_DOT,KEYSWITCH_Y_OFFSET_DOT);
	SetWindowInfo(SCREEN_1,0);
	OpenWindow(SCREEN_1,DEV_GAMEN_X_SIZE,DEV_GAMEN_Y_SIZE);
	ClearDispBuff(SCREEN_1);					/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_DEVICE_IN,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DevDispName= (_DISPLAY1 *)TakeMemory(sizeof(_DISPLAY1));
	DevDispKeyTbl= (KEY_CHECK_DATA1 *)TakeMemory(sizeof(KEY_CHECK_DATA1));
	//���̃f??���R�s?����B
	memcpy((char *)DevDispName,&LDspname[3],sizeof(_DISPLAY1));
	memcpy((char *)DevDispKeyTbl,&EnvKeyTbl1[5],sizeof(KEY_CHECK_DATA1));
	//Decimal Key Set
	for(i= 0; ; i++){
		if(KeyCodeData[1][i] == NULL){
			break;
		}
		DevDispName->chName[0][i+3]= (char *)KeyCodeData[1][i];
		DevDispName->chName[1][i+3]= (char *)KeyCodeData[1][i];
		DevDispKeyTbl->KeyData[i+2].code= i;
	}
	//BS
	DevDispName->chName[0][22]= (char *)BS_Str;
	DevDispName->chName[1][22]= (char *)BS_Str;
	DevDispKeyTbl->KeyData[21].code= KEY_BS;

	DispTextData(DEVMON_SELECT,iTotalCnt);

	sprintf(InputStr,"%s",initdata);
	DispTextSetItemData(KEY_SEL_DISP,InputStr);
	DrawLcdBank1();
	EndFlag= 0;
	ret= 0;
	FirstFlag= 0;
	if(kind == 0){		//Hour
		iMax= 24;
	}else{
		iMax= 59;
	}
	iMin= 0;
	iLen= 2;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA*)DevDispKeyTbl);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			ret = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			ret = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_CLK_CLR:
			EndFlag= 1;
			break;
		case KEY_CLK_ENT:
			//���̓f??�����o���B
			for(i= 0,j= 0; i < iLen; i++){
				if(InputStr[i] != ' '){
					WorkStr[j++]= InputStr[i];
				}
			}
			WorkStr[j]= 0;
			iNum = gatoi(WorkStr);
			if(iNum > iMax || iNum < iMin){
				iCaptionWindow(Dspname[SET_FUNTION].chName[Set.iLang][12],"");			/*  ��ư �ϳ��� �޼���E�ڽ�	 */	
				SetWindowNo(SCREEN_1);
				DrawLcdBank1();
			}else{
				strncpy(initdata,InputStr,2);
				EndFlag= 1;
			}
			break;
		case KEY_BS:
			if(FirstFlag != 0){
				for(i= iLen-1; i > 0; i--){
					InputStr[i]= InputStr[i-1];
				}
				InputStr[0]= ' ';
				ClearTextItemData1(KEY_SEL_DISP);
				sprintf(dspbuff,"%s",InputStr);
				DispTextSetItemData(KEY_SEL_DISP,dspbuff);
				DrawLcdBank1();
			}
			break;
		default:
			if(iKeyCode != KEY_NO_DATA){
				if(FirstFlag == 0){
					FirstFlag= 1;
					memset(InputStr,' ',sizeof(InputStr));
					InputStr[iLen]= 0;
				}
				for(i= 0; i < iLen; i++){
					InputStr[i]= InputStr[i+1];
				}
				InputStr[iLen-1]= Bin2Hex1(iKeyCode);
				ClearTextItemData1(KEY_SEL_DISP);
				sprintf(dspbuff,"%s",InputStr);
				DispTextSetItemData(KEY_SEL_DISP,dspbuff);
				DrawLcdBank1();
			}
			break;
		}
	}
	FreeMail((char *)DevDispName);
	FreeMail((char *)DevDispKeyTbl);
	CloseWindow(SCREEN_1);
	SetWindowNo(SCREEN_0);
	DrawLcdBank1();
	return(ret);
}
int	TimeSwitxhDevIn(int *DevAddr,short *DevName)
{
	DeviceTableSet(1);		/* ǥ���� Device Name Set */
	return(vDeviceInput(1,DevAddr,DevName));
}
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
#endif
