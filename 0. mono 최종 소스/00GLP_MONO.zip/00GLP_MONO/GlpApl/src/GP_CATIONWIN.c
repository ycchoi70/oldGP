/* ****************************************************************************** */
/*  �� �� ��E: GP_PCDIAGNO.CPP													 */
/*  ��E   �� : PC ���� ó��														 */
/*  �� �� �� : 2002��E2��E20�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��    �� : (��) LC Tech														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

/* ****************************************************************************** */
/*  ��E��E��E: vOutEntWindowDisp()												 */
/*  ��E   �� : ����Ʈ ��� ȭ��E���												 */
/*  ��    �� : chContent : ��� �� ����																	 */
/*  ÁE   �� : iReKeyFlag : 0 : Yes, 1 : No																	 */
/*  �� �� �� : 2002��E2��E20�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 2 Butten Display																	 */
/* ****************************************************************************** */
int		vOutEntWindowDisp(char *chContent)
{	
	int		iKeyCode;
	int		iReKeyFlag = -1;
	short	iLen;
	char	chDsp_buff[35];	

	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT8;
	RECParam.iForeColor = WHITE;
	RECParam.iBackColor = WHITE;

	memset(chDsp_buff, 0x00, sizeof(chDsp_buff));


/*ksc20040514 ������ġ 2dot ���� �ű� */
	
	/* ������E?�ߴ� ��E��?���� */
	AreaClear(GAMEN_START_X+29,GAMEN_START_Y+31,GAMEN_START_X+211,GAMEN_START_Y+71,0);							/*  ���ϴ� �κи��� ������.   */
	
	RectAngleOut(GAMEN_START_X+29,GAMEN_START_Y+31,GAMEN_START_X+211,GAMEN_START_Y+71,&RECParam);					/* ȭ��Ʋ �ۼ�				 */

	RECParam.iLineColor = BLACK;

	sprintf(chDsp_buff, chContent);				
	DotTextOut(GAMEN_START_X+31,GAMEN_START_Y+33,chDsp_buff,1,1, TRANS, T_BLACK, T_WHITE);

#ifdef	SIZE_3224
	iLen = strlen(Dspname[PRINT_OUT].chName[Set.iLang][5]);
	iLen = (short)((149-96) - (iLen*8))/2;
	DotTextOut(GAMEN_START_X+96+iLen,GAMEN_START_Y+54,Dspname[PRINT_OUT].chName[Set.iLang][5],1,1, TRANS, T_BLACK, T_WHITE);	/* �� */
	iLen = strlen(Dspname[PRINT_OUT].chName[Set.iLang][6]);
	iLen = (short)((206-153) - (iLen*8))/2;
	DotTextOut(GAMEN_START_X+153+iLen,GAMEN_START_Y+54,Dspname[PRINT_OUT].chName[Set.iLang][6],1,1, TRANS, T_BLACK, T_WHITE);	/* �ƴϿ� */
#endif
#ifdef	SIZE_2480
	iLen = strlen(Dspname[PRINT_OUT].chName[Set.iLang][2]);
	iLen = (short)((149-96) - (iLen*8))/2;
	DotTextOut(GAMEN_START_X+96+iLen,GAMEN_START_Y+54,Dspname[PRINT_OUT].chName[Set.iLang][2],1,1, TRANS, T_BLACK, T_WHITE);	/* �� */
	iLen = strlen(Dspname[PRINT_OUT].chName[Set.iLang][3]);
	iLen = (short)((206-153) - (iLen*8))/2;
	DotTextOut(GAMEN_START_X+153+iLen,GAMEN_START_Y+54,Dspname[PRINT_OUT].chName[Set.iLang][3],1,1, TRANS, T_BLACK, T_WHITE);	/* �ƴϿ� */
#endif
	RECParam.iPattern	= PAT0;
	RECParam.iLineColor = BLACK;
	RectAngleOut(GAMEN_START_X+96,GAMEN_START_Y+53,GAMEN_START_X+149,GAMEN_START_Y+69,&RECParam);					/* YES ��ư					 */
	RectAngleOut(GAMEN_START_X+153,GAMEN_START_Y+53,GAMEN_START_X+206,GAMEN_START_Y+69,&RECParam);					/* NO ��ư					 */

/*ksc20040514 ������ġ 2dot ���� �ű� */


	iKeyCode = -1;	
	DrawLcdBank1();


	while (iKeyCode == -1) {
		iKeyCode = KeyWait();							/* �Էµ� Ű���� �о��	 */

		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			 iReKeyFlag = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			iReKeyFlag = UP_TRANS;
			break;
		}
		
		/* Ű ���� ó�� */		
/*ksc20040514 ��� Yes,No ��ġ ����ġ ����Ʈ ���� */
		if ((iKeyCode >= 52 && iKeyCode <= 54) || (iKeyCode >= 38 && iKeyCode <= 40)) {						/*  YES					 */
			iReKeyFlag = 0;		
			NormalBuzzer();				/*	Buzzer  */
		} else if ((iKeyCode >= 56 && iKeyCode <= 58) || (iKeyCode >= 41 && iKeyCode <= 43)) {					/*  NO				 */
			NormalBuzzer();				/*	Buzzer  */
			iReKeyFlag = 1;		
		}else
		{
			iKeyCode = -1;
		}/*  end if  */			
/*ksc20040514*/
		
	} /*  end while  */

	return iReKeyFlag;
}
/* *******************************************************************************/
/*  ��E��E��E: iCaptionWindow()													 */
/*  ��E   �� : ����Ʈ ��� ȭ�� ���											 */
/*  ��    �� : chContent : ��� �� ����											 */
/*  ÁE   �� : iReKeyFlag : 0 : Yes, 1 : No										 */
/*  �� �� �� : 2002/02/20														 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��E   ��E: 																	 */
/* *******************************************************************************/
int		iCaptionWindow(char *chContent,char *chContent1)
{	
	int			iKeyCode;
	char		chDsp_buff[40];	
	int			iReKeyFlag;
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = BLACK;
	RECParam.iPattern	= PAT8;
	RECParam.iForeColor = WHITE;
	RECParam.iBackColor = WHITE;
	iReKeyFlag = 0;


	ClearDispBuff(MESSAGE_SCREEN);
#ifdef	SIZE_2480	//2008.09.30
	SetStartPos(MESSAGE_SCREEN, 8, 10);
#endif				//2008.09.30
#ifdef	SIZE_3224	//2008.09.30
	SetStartPos(MESSAGE_SCREEN, 49, 52);
#endif				//2008.09.30

	
	OpenWindow(MESSAGE_SCREEN,222,60);
/*		*/
	memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
	
	/* ������E?�ߴ� ��E��?���� */
	/****/
	ErrorBuzzer();
	/****/
	AreaClear(0,0,222,60,0);							/*  ���ϴ� �κи��� ������. leesi 04/15  */	
	
	RectAngleOut(0,0,222,60,&RECParam);					/* ȭ��Ʋ �ۼ�				 */
	RectAngleOut(167,32,215,52,&RECParam);				/* Ȯ�� ��ư					 */
	vBoxInLine(167,32,215,52);							/* Ȯ�� ��ư					 */

	sprintf(chDsp_buff, chContent);				
	DotTextOut(17,Line_2-10,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);

	memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
	sprintf(chDsp_buff, chContent1);				
	DotTextOut(17,Line_3-10,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);
	memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
	sprintf(chDsp_buff, Dspname[ELSMESSAGE].chName[Set.iLang][0]);				
//	DotTextOut(175,Line_3-8,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);
	DotTextOut(183,Line_3-8,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);

	iKeyCode = -1;	

	DrawLcdBank1();	

	while (iKeyCode == -1) {
		iKeyCode = KeyWait();							/* KeyWait */
		if(iKeyCode ==0)
			iKeyCode = -1;
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			 iReKeyFlag = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			iReKeyFlag = UP_TRANS;
			break;
		}

#ifdef	SIZE_2480	//2008.09.30
		if (iKeyCode >= KEY_42 && iKeyCode <= KEY_44 ) {					/*  END				*/
#endif
#ifdef	SIZE_3224	//2008.09.30
		if (iKeyCode >= 76 && iKeyCode <= 78 ) {					/*  END				*/
#endif
			iKeyCode	= 0;		
			NormalBuzzer();				/*	Buzzer		*/
		}
		else
		{
			iKeyCode = -1;
		}
		if(Key.iCode >= KEY_42 && Key.iCode <= KEY_44)
		{
			iKeyCode	= 0;
			Key.iCode	= 0;
			NormalBuzzer();				/*	Buzzer		*/	
		}
		/*  end if  */		

	} /*  end while  */
	CloseWindow(MESSAGE_SCREEN);/*  ���ϴ� �κи��� ������. leesi 04/15  */	
	SetWindowNo(SCREEN_0);
	return iReKeyFlag;
}
/* ****************************************************************************** */
/*  �� �� �� : iCaptionVerticalWindow()											  */
/*  ��    �� : ���� �޼��� ���													  */
/*  ��    �� : chContent : ��� �� ����											  */
/*  ��    �� : iReKeyFlag : 0 : Yes, 1 : No										  */
/*  �� �� �� : 2002��E2��E20�� (��E												  */
/*  �� �� �� : ȫ �� ��E														  */
/*  ��    �� : 																	  */
/* ****************************************************************************** */
int		iCaptionVerticalWindow(char *chContent,char *chContent1,char *chContent2,char *chContent3,char *chContent4)/**/
{	
	char		chDsp_buff[40];	
	int			iReKeyFlag;
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = BLACK;
	RECParam.iPattern	= PAT8;
	RECParam.iForeColor = WHITE;
	RECParam.iBackColor = WHITE;
	iReKeyFlag = 0;

	SetWinSema();				/* 050428 */

	ClearDispBuff(MESSAGE_SCREEN);
	memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
	
	/****/
	ErrorBuzzer();
	/****/

	if(TateYoko == 0)		/* ���� : 1, ���� : 0  */
	{
#ifdef	SIZE_2480
		SetStartPos(MESSAGE_SCREEN, 8, 10);
		OpenWindow(MESSAGE_SCREEN,222,60);
#endif
#ifdef	SIZE_3224
		SetStartPos(MESSAGE_SCREEN, 49, 52);
		OpenWindow(MESSAGE_SCREEN,222,60);
#endif
		RectAngleOut(GAMEN_START_X+0,GAMEN_START_Y+0,GAMEN_START_X+222,GAMEN_START_Y+60,&RECParam);					/* ȭ��Ʋ �ۼ�				 */
		RectAngleOut(GAMEN_START_X+167,GAMEN_START_Y+32,GAMEN_START_X+215,GAMEN_START_Y+52,&RECParam);				/* Ȯ�� ��ư					 */
		vBoxInLine(GAMEN_START_X+167,GAMEN_START_Y+32,GAMEN_START_X+215,GAMEN_START_Y+52);							/* Ȯ�� ��ư					 */

		sprintf(chDsp_buff, chContent);				
		DotTextOut(GAMEN_START_X+12,GAMEN_START_Y+Line_2-10,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);

		memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
		sprintf(chDsp_buff, "%s%s", chContent1,chContent2);				
		DotTextOut(GAMEN_START_X+12,GAMEN_START_Y+Line_3-10,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);

		memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
//		sprintf(chDsp_buff, Dspname[ELSMESSAGE].chName[Set.iLang][0]);				
//		DotTextOut(GAMEN_START_X+175,GAMEN_START_Y+Line_3-8,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);
/* KSC20070222 */
		sprintf(chDsp_buff, Dspname[ELSMESSAGE].chName[Set.iLang][0]);				
/*		sprintf(chDsp_buff, Dspname[PRINT_OUT].chName[Set.iLang][4]);				*/
/*		DotTextOut(175,Line_3-8,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);		*/
		DotTextOut(GAMEN_START_X+183,GAMEN_START_Y+Line_3-8,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);

	}else
	{
		OpenWindow(MESSAGE_SCREEN,74,138);
		SetStartPos(MESSAGE_SCREEN, 3, 37);
		RectAngleOut(GAMEN_START_X+0,GAMEN_START_Y+0,GAMEN_START_X+77,GAMEN_START_Y+137,&RECParam);					/* ȭ��Ʋ �ۼ�				 */
		RectAngleOut(GAMEN_START_X+38,GAMEN_START_Y+112,GAMEN_START_X+73,GAMEN_START_Y+132,&RECParam);				/* Ȯ�� ��ư					 */
		RectAngleOut(GAMEN_START_X+40,GAMEN_START_Y+114,GAMEN_START_X+71,GAMEN_START_Y+130,&RECParam);				/* Ȯ�� ��ư					 */

		sprintf(chDsp_buff, chContent);				
		DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+5,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);
		memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
		sprintf(chDsp_buff, chContent1);				
		DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+24,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);
		memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
		sprintf(chDsp_buff, chContent2);				
		DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+43,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);
		memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
		sprintf(chDsp_buff, chContent3);				
		DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+62,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);
		memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
		sprintf(chDsp_buff, chContent4);				
		DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+81,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);
		memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
//		sprintf(chDsp_buff, Dspname[ELSMESSAGE].chName[Set.iLang][0]);				
//		DotTextOut(GAMEN_START_X+39,GAMEN_START_Y+114,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);
/* KSC20070222 */
		sprintf(chDsp_buff, Dspname[ELSMESSAGE].chName[Set.iLang][0]);				
/*		sprintf(chDsp_buff, Dspname[PRINT_OUT].chName[Set.iLang][4]);				*/
/*		DotTextOut(39,114,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);	*/
		DotTextOut(GAMEN_START_X+47,GAMEN_START_Y+114,chDsp_buff,1,1, T_FRONT, T_BLACK, T_WHITE);	
	}
	DrawLcdBank1();

	ResetWinSema();		/* 050428 */

	Set.iMessageFlag = 2;
	SetWindowNo(SCREEN_0);
	return iReKeyFlag;
}
/* ****************************************************************************** */
/*  ��E��E��E: vBasicForm_Sec()													 */
/*  ��E   �� : �ڽ� �޼���E													 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E4��E18��													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
void		vBasicForm_Sec(char *chContent)
{
	char	chDsp_buff[24];
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;
	
	/*  ȭ��Ʋ �ۼ�				 */
/*	RectAngleOut(0,0,239,79,&RECParam);	*/				/*  ��E?�ڽ�				 */

	SetWinSema();		/* 050428 */

	RectAngleOut(GAMEN_START_X+0,GAMEN_START_Y+0,GAMEN_START_X+191,GAMEN_START_Y+19,&RECParam);					/*  Ÿ��Ʋ �ڽ�				 */
	RectAngleOut(GAMEN_START_X+191,GAMEN_START_Y+0,GAMEN_X_SIZE-1,19,&RECParam);				/*  end ��ư 				 */


	sprintf(chDsp_buff,chContent);				
	DotTextOut(GAMEN_START_X+3,GAMEN_START_Y+Line_1,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);		

/*	sprintf(chDsp_buff, EndBtn.chEnd[Set.iLang]); 060724 */
	sprintf(chDsp_buff, Dspname[RS232C_SETTING].chTitle[Set.iLang]);
	DotTextOut(GAMEN_START_X+204-(Set.iLang*4),GAMEN_START_Y+Line_1,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

	RectAngleOut(GAMEN_START_X+2,GAMEN_START_Y+2,GAMEN_START_X+189,GAMEN_START_Y+17,&RECParam);					/*  Ÿ��Ʋ �� �ڽ�			 */
	RectAngleOut(GAMEN_START_X+193,GAMEN_START_Y+2,GAMEN_START_X+237,GAMEN_START_Y+17,&RECParam);				/*  end ��ư �� �ڽ�  		 */
	
	DrawLcdBank1();
	ResetWinSema();		/* 050428 */
}

/* *******************************************************************************/
/*  ��E��E��E: vBoxInLine()														 */
/*  ��E   �� : �ڽ��� �׸���													 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E5��E19��													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* *******************************************************************************/
void		vBoxInLine(int sX, int sY, int eX, int eY)
{
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	RectAngleOut(sX+2, sY+2, eX-2, eY-2,&RECParam);
}
/* *******************************************************************************/
/*  ��E��E��E: vNumberInputPan()												 */
/*  ��E   �� : 10��ư�Է�â Display												 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002/05/19													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* *******************************************************************************/
void	vNumberInputPan(int iType)  /* 0 : ����̽� �Է�ȭ���,  1 : �����Է�ȭ��� */
{
	int		isX;
	short	i;
	short	j;
	short	sX;
	short	eX;
	short	sY;
	short	eY;
	short	iAdd;
	char	chDsp_buff[5];

	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	memset(chDsp_buff,0x00,sizeof(chDsp_buff));

	if(iType == 0)
	{
		isX = 0;
		AreaClear(isX,0,isX+163,79,0);
		for(i=0;i<3;i++)
		{
			for(j=0;j<4;j++)
			{	
				sX = isX + 2 + (j*32);
				sY = 22 + (i*19);
				eX = sX + 30;
				eY = sY + 17;
				iAdd = j+(4*i);
				sprintf(chDsp_buff, Device_Name[iAdd]);				
				CenterDisplay(sX,sY,eX,OVER_CODE,chDsp_buff);
			}
		}
	}
	else
	{
		if(iType == 1)
			isX = 0;
		else
			isX = 76;
		AreaClear(isX,0,isX+163,79,0);
		for(i=0;i<3;i++)
		{
			for(j=0;j<4;j++)
			{	
				sX = isX + 2 + (j*32);
				sY = 22 + (i*19);
				eX = sX + 30;
				eY = sY + 17;
				iAdd = j+(4*i);
				if(iAdd<10)
					sprintf(chDsp_buff,"%d",iAdd);				
				else if(iAdd == 10)
					sprintf(chDsp_buff,"-");
				else if(iAdd == 11)
					sprintf(chDsp_buff,"B S");
				CenterDisplay(sX,sY,eX,eY,chDsp_buff);
			}
		}
	}
	CenterDisplay(130+isX,3,160+isX,3,D_CLRBUT);
//	CenterDisplay(130+isX,22,160+isX,33,Dspname[ELSMESSAGE].chName[Set.iLang][1]);
//	CenterDisplay(130+isX,41,160+isX,41,Dspname[ELSMESSAGE].chName[Set.iLang][0]);
/* KSC20070222 */
	CenterDisplay(130+isX,22,160+isX,33,Dspname[ELSMESSAGE].chName[Set.iLang][1]);  /* UP */
/*	DotWriteFont0(1,138+isX,22,(unsigned char *)&TriangleFont[0],T_BLACK,1,1,NON_TRANS,0,0); */			
	CenterDisplay(130+isX,41,160+isX,41,Dspname[ELSMESSAGE].chName[Set.iLang][0]);  /* DOWN */
/*	DotWriteFont0(1,138+isX,41,(unsigned char *)&TriangleFont[32],T_BLACK,1,1,NON_TRANS,0,0);			*/

	
	CenterDisplay(130+isX,60,160+isX,60,D_ENTBUT);

	RectAngleOut(isX,0,isX+163,79,&RECParam);
	RectAngleOut(isX,0,isX+162,78,&RECParam);	
	RectAngleOut(isX+2,2,isX+128,19,&RECParam);
	RectAngleOut(isX+130,2,isX+160,19,&RECParam);
	for(i=0;i<3;i++)
	{
		for(j=0;j<5;j++)
		{	
			sX = isX + 2 + (j*32);
			sY = 21 + (i*19);
			eX = sX + 30;
			eY = sY + 17;
			RectAngleOut(sX,sY,eX,eY,&RECParam);
		}
	}
	DrawLcdBank1();

}
/* *******************************************************************************/
/*  ��E��E��E: vNumberInputPan8()												 */
/*  ��E   �� : 8��ư�Է�â Display												 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2003/11															 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* *******************************************************************************/
void	vNumberInputPan8(void)  
{
	int		isX;
	short	i;
	short	j;
	short	sX;
	short	eX;
	short	sY;
	short	eY;
	short	iAdd;
	char	chDsp_buff[5];

	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	memset(chDsp_buff,0x00,sizeof(chDsp_buff));

		isX = 76;
		AreaClear(GAMEN_START_X+108,GAMEN_START_Y+0,GAMEN_START_X+isX+163,GAMEN_START_Y+79,0);
		for(i=0;i<3;i++)
		{
			for(j=0;j<3;j++)
			{	
				sX = 108 + 2 + (j*32);
				sY = 22 + (i*19);
				eX = sX + 30;
				eY = sY + 17;
				iAdd = j+(3*i);
				if(iAdd<8)
					sprintf(chDsp_buff,"%d",iAdd);				
				else if(iAdd == 8)
					sprintf(chDsp_buff,"B S");
				CenterDisplay(GAMEN_START_X+sX,GAMEN_START_Y+sY,GAMEN_START_X+eX,GAMEN_START_Y+eY,chDsp_buff);
			}
		}

	CenterDisplay(GAMEN_START_X+130+isX,GAMEN_START_Y+3,GAMEN_START_X+160+isX,GAMEN_START_Y+3,D_CLRBUT);
//	CenterDisplay(GAMEN_START_X+130+isX,GAMEN_START_Y+22,GAMEN_START_X+160+isX,GAMEN_START_Y+33,Dspname[ELSMESSAGE].chName[Set.iLang][1]);
//	CenterDisplay(GAMEN_START_X+130+isX,GAMEN_START_Y+41,GAMEN_START_X+160+isX,GAMEN_START_Y+41,Dspname[ELSMESSAGE].chName[Set.iLang][0]);

/* KSC20070222 */
	CenterDisplay(GAMEN_START_X+130+isX,GAMEN_START_Y+GAMEN_START_Y+22,GAMEN_START_X+160+isX,33,Dspname[ELSMESSAGE].chName[Set.iLang][1]);  /* UP */
/*	DotWriteFont0(1,138+isX,22,(unsigned char *)&TriangleFont[0],T_BLACK,1,1,NON_TRANS,0,0);			*/
	CenterDisplay(GAMEN_START_X+130+isX,GAMEN_START_Y+GAMEN_START_Y+41,GAMEN_START_X+160+isX,41,Dspname[ELSMESSAGE].chName[Set.iLang][0]);  /* DOWN */
/*	DotWriteFont0(1,138+isX,41,(unsigned char *)&TriangleFont[32],T_BLACK,1,1,NON_TRANS,0,0);			*/
	
	CenterDisplay(GAMEN_START_X+130+isX,GAMEN_START_Y+60,GAMEN_START_X+160+isX,GAMEN_START_Y+60,D_ENTBUT);

	RectAngleOut(GAMEN_START_X+108,GAMEN_START_Y+0,GAMEN_START_X+isX+163,GAMEN_START_Y+79,&RECParam);
	RectAngleOut(GAMEN_START_X+108,GAMEN_START_Y+0,GAMEN_START_X+isX+162,GAMEN_START_Y+78,&RECParam);	
	RectAngleOut(GAMEN_START_X+110,GAMEN_START_Y+2,GAMEN_START_X+isX+128,GAMEN_START_Y+19,&RECParam);
	RectAngleOut(GAMEN_START_X+isX+130,GAMEN_START_Y+2,GAMEN_START_X+isX+160,GAMEN_START_Y+19,&RECParam);
	for(i=0;i<3;i++)
	{
		for(j=0;j<4;j++)
		{	
			sX = 108 + 2 + (j*32);
			sY = 21 + (i*19);
			eX = sX + 30;
			eY = sY + 17;
			RectAngleOut(GAMEN_START_X+sX,GAMEN_START_Y+sY,GAMEN_START_X+eX,GAMEN_START_Y+eY,&RECParam);
		}
	}
	DrawLcdBank1();	
}
/* *******************************************************************************/
/*  ��E��E��E: vNumberInputPan_16()												 */
/*  ��E   �� : ��ư�Է�â Display												 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E5��E19��													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* *******************************************************************************/
#ifdef	SIZE_2480
void	vNumberInputPan_16(int iType)
{	
	char	chDsp_buff[5];
	short	iSx;
	short	DrowX;
	short	DrowY;
	short	i;
	short	j;
	short	iCnt;
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	if(iType == 0)										/* ����̽� �Է� ȭ��� */
	{
		iSx = 0;
		AreaClear(GAMEN_START_X+0,GAMEN_START_Y+0,GAMEN_START_X+180,GAMEN_START_Y+79,0);							/* ȭ��ũ�⸸ŭ �����				 */	

		sprintf(chDsp_buff, Device_Name[0]);				
		CenterDisplay(GAMEN_START_X+iSx+120,GAMEN_START_Y+Line_1,GAMEN_START_X+iSx+150,GAMEN_START_Y+OVER_CODE,chDsp_buff);
	
		for(i=0;i<3;i++)
		{
			DrowY = 22+(i*20);
			for(j=0;j<5;j++)
			{
				DrowX = iSx + (j*30);
				iCnt = i*5+(j+1);
				sprintf(chDsp_buff, Device_Name[iCnt]);				
				CenterDisplay(GAMEN_START_X+DrowX,GAMEN_START_Y+DrowY,GAMEN_START_X+DrowX+30,GAMEN_START_Y+OVER_CODE,chDsp_buff);
			}
		}		
	}
	else												/* ���� �Է� ȭ��� */
	{
		iSx = 59;
		AreaClear(GAMEN_START_X+59,GAMEN_START_Y+0,GAMEN_X_SIZE-1,GAMEN_Y_SIZE-1,0);							/* ȭ��ũ�⸸ŭ �����				 */	

		sprintf(chDsp_buff, " F");				
		DotTextOut(GAMEN_START_X+182,GAMEN_START_Y+Line_1,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);	
	
		sprintf(chDsp_buff, " A");				
		DotTextOut(GAMEN_START_X+62,GAMEN_START_Y+Line_2,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

		sprintf(chDsp_buff, " B");				
		DotTextOut(GAMEN_START_X+92,GAMEN_START_Y+Line_2,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

		sprintf(chDsp_buff, " C");				
		DotTextOut(GAMEN_START_X+122,GAMEN_START_Y+Line_2,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

		sprintf(chDsp_buff, " D");				
		DotTextOut(GAMEN_START_X+152,GAMEN_START_Y+Line_2,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

		sprintf(chDsp_buff, " E");				
		DotTextOut(GAMEN_START_X+182,GAMEN_START_Y+Line_2,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);


		sprintf(chDsp_buff, " 5");				
		DotTextOut(GAMEN_START_X+62,GAMEN_START_Y+Line_3,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

		sprintf(chDsp_buff, " 6");				
		DotTextOut(GAMEN_START_X+92,GAMEN_START_Y+Line_3,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

		sprintf(chDsp_buff, " 7");				
		DotTextOut(GAMEN_START_X+122,GAMEN_START_Y+Line_3,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

		sprintf(chDsp_buff, " 8");				
		DotTextOut(GAMEN_START_X+152,GAMEN_START_Y+Line_3,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

		sprintf(chDsp_buff, " 9");				
		DotTextOut(GAMEN_START_X+182,GAMEN_START_Y+Line_3,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);
	
		sprintf(chDsp_buff, " 0");				
		DotTextOut(GAMEN_START_X+62,GAMEN_START_Y+Line_4,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

		sprintf(chDsp_buff, " 1");				
		DotTextOut(GAMEN_START_X+92,GAMEN_START_Y+Line_4,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

		sprintf(chDsp_buff, " 2");				
		DotTextOut(GAMEN_START_X+122,GAMEN_START_Y+Line_4,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

		sprintf(chDsp_buff, " 3");				
		DotTextOut(GAMEN_START_X+152,GAMEN_START_Y+Line_4,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

		sprintf(chDsp_buff, " 4");				
		DotTextOut(GAMEN_START_X+182,GAMEN_START_Y+Line_4,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);
	}

	RectAngleOut(GAMEN_START_X+iSx,GAMEN_START_Y+0,GAMEN_START_X+iSx+120,GAMEN_START_Y+19,&RECParam);			/* �Է� ��ư					 */
	RectAngleOut(GAMEN_START_X+iSx+120,GAMEN_START_Y+0,GAMEN_START_X+iSx+150,GAMEN_START_Y+19,&RECParam);		/* F ��ư					 */
	RectAngleOut(GAMEN_START_X+iSx+150,GAMEN_START_Y+0,GAMEN_START_X+iSx+180,GAMEN_START_Y+19,&RECParam);		/* ENT ��ư					 */

	vBoxInLine(GAMEN_START_X+iSx,GAMEN_START_Y+0,GAMEN_START_X+iSx+120,GAMEN_START_Y+19);						/* �Է� ��ư					 */
	vBoxInLine(GAMEN_START_X+iSx+120,GAMEN_START_Y+0,GAMEN_START_X+iSx+150,GAMEN_START_Y+19);					/* F ��ư					 */
	vBoxInLine(GAMEN_START_X+iSx+150,GAMEN_START_Y+0,GAMEN_START_X+iSx+180,GAMEN_START_Y+19);					/* ENT ��ư					 */
	
	for(i=0;i<3;i++)
	{
		DrowY = 19+(i*20);
		for(j=0;j<6;j++)
		{
			DrowX = iSx + (j*30);
			RectAngleOut(GAMEN_START_X+DrowX,GAMEN_START_Y+DrowY,GAMEN_START_X+DrowX+30,GAMEN_START_Y+DrowY+20,&RECParam);	
			vBoxInLine(GAMEN_START_X+DrowX,GAMEN_START_Y+DrowY,GAMEN_START_X+DrowX+30,GAMEN_START_Y+DrowY+20);	
		}
	}
	
	DotTextOut(GAMEN_START_X+iSx+153,GAMEN_START_Y+Line_4,D_ENTBUT,1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+iSx+153,GAMEN_START_Y+Line_1,D_CLRBUT,1,1, NON_TRANS, T_WHITE, T_BLACK);
//	DotTextOut(GAMEN_START_X+iSx+149,GAMEN_START_Y+Line_2,Dspname[ELSMESSAGE].chName[Set.iLang][1],1,1, NON_TRANS, T_WHITE, T_BLACK);				/*  ��Eǥ��  */
//	DotTextOut(GAMEN_START_X+iSx+149,GAMEN_START_Y+Line_3,Dspname[ELSMESSAGE].chName[Set.iLang][0],1,1, NON_TRANS, T_WHITE, T_BLACK);				/*  ��Eǥ��  */		

/* KSC20070222 */
/*	DotTextOut(iSx+149,Line_2,Dspname[LCDCONTRAST].chName[Set.iLang][1],1,1, NON_TRANS, T_WHITE, T_BLACK);	*/			/*  ��Eǥ��  */
	DotTextOut(GAMEN_START_X+iSx+157,GAMEN_START_Y+Line_2,Dspname[ELSMESSAGE].chName[Set.iLang][1],1,1, NON_TRANS, T_WHITE, T_BLACK);				/*  ��Eǥ��  */
/*	DotWriteFont0(1,iSx+149,Line_2,(unsigned char *)&TriangleFont[0],T_BLACK,1,1,NON_TRANS,0,0);			*/
/*	DotTextOut(iSx+149,Line_3,Dspname[LCDCONTRAST].chName[Set.iLang][0],1,1, NON_TRANS, T_WHITE, T_BLACK);	*/			/*  ��Eǥ��  */		
	DotTextOut(GAMEN_START_X+iSx+157,GAMEN_START_Y+Line_3,Dspname[ELSMESSAGE].chName[Set.iLang][0],1,1, NON_TRANS, T_WHITE, T_BLACK);				/*  ��Eǥ��  */		
/*	DotWriteFont0(1,iSx+149,Line_3,(unsigned char *)&TriangleFont[32],T_BLACK,1,1,NON_TRANS,0,0);			*/
}
#endif
/* ****************************************************************************** */
/*  �� �� �� : vLastDataReverse()												 */
/*  ��    �� : Data�� �����̳� �Է��� ��		 */
/*  ��    �� :																	 */
/*  ��    �� : iEscFlag 0 : ESC ����											 */
/*  �� �� �� : 2002�� 5�� 25�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void	vLastDataReverse(int iX, int iLine, char * chData)
{
	int		iLen;
	char	chLastData[5];
	char	chFirstData[14];

	iLen =0;
		memset(chLastData,0x00,sizeof(chLastData));
		memset(chFirstData,0x00,sizeof(chFirstData));

	iLen = strlen(chData);
	if(iLen == 0)
	{
		DotTextOut(GAMEN_START_X+iX-8,GAMEN_START_Y+iLine," ",1,1,TRANS, T_WHITE, T_BLACK);
		AreaRevers(GAMEN_START_X+iX-8,GAMEN_START_Y+iLine,GAMEN_START_X+iX-1,GAMEN_START_Y+iLine+15);
	}
	else if(iLen == 1)
	{
		DotTextOut(GAMEN_START_X+iX,GAMEN_START_Y+iLine," ",1,1,TRANS, T_WHITE, T_BLACK);
		DotTextOut(GAMEN_START_X+iX,GAMEN_START_Y+iLine,chData,1,1,TRANS, T_WHITE, T_BLACK); 
		AreaRevers(GAMEN_START_X+iX,GAMEN_START_Y+iLine,GAMEN_START_X+iX+7,GAMEN_START_Y+iLine+15);
	}
	else
	{
		strncpy(chLastData,(chData+(iLen-1)),1);
		DotTextOut(GAMEN_START_X+iX+(8*(iLen-1)),GAMEN_START_Y+iLine,chLastData,1,1,TRANS, T_WHITE, T_BLACK);
		AreaRevers(GAMEN_START_X+iX+(8*(iLen-1)),GAMEN_START_Y+iLine,GAMEN_START_X+iX+(8*iLen)-1,GAMEN_START_Y+iLine+15);

		strncpy(chFirstData,chData,(iLen-1));
		DotTextOut(GAMEN_START_X+iX,GAMEN_START_Y+iLine,chFirstData,1,1,TRANS, T_WHITE, T_BLACK);
	}

}
/* ****************************************************************************** */
/*  ��E��E��E: iScreenMess()													 */
/*  ��E   �� : �ڽ� �޼���E													 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E4��E15�� (��E												 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
void		iScreenMess(char *chContent, char *chContent1, char *chContent2, char *chContent3, char *chContent4)
{	
	char	chDsp_buff[35];	

	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT8;
	RECParam.iForeColor = WHITE;
	RECParam.iBackColor = WHITE;

	ErrorBuzzer();

	memset(chDsp_buff, 0x00, sizeof(chDsp_buff));

	if(TateYoko == 0)
	{

#ifdef	OLD
		AreaClear(GAMEN_START_X+10,GAMEN_START_Y+20,GAMEN_START_X+215,GAMEN_START_Y+60,0);								/*  ���ϴ� �κи��� Del   */
		RectAngleOut(GAMEN_START_X+10,GAMEN_START_Y+20,GAMEN_START_X+215,GAMEN_START_Y+60,&RECParam);					/*  ȭ��Ʋ �ۼ�				 */

		sprintf(chDsp_buff, chContent1);				
		DotTextOut(GAMEN_START_X+25, GAMEN_START_Y+Line_3, chDsp_buff, 1, 1, T_FRONT, T_BLACK, T_WHITE);

		sprintf(chDsp_buff, chContent);				
		DotTextOut(GAMEN_START_X+25, GAMEN_START_Y+Line_2, chDsp_buff, 1, 1, T_FRONT, T_BLACK, T_WHITE);
#endif

		AreaClear(GAMEN_START_X+(GAMEN_X_SIZE/2)-(210/2),GAMEN_START_Y+(GAMEN_Y_SIZE/4)-8,GAMEN_START_X+(GAMEN_X_SIZE/2)+(210/2),GAMEN_START_Y+(GAMEN_Y_SIZE/4)+40,0);								/*  ���ϴ� �κи��� Del   */
		RectAngleOut(GAMEN_START_X+(GAMEN_X_SIZE/2)-(210/2),GAMEN_START_Y+(GAMEN_Y_SIZE/4)-8,GAMEN_START_X+(GAMEN_X_SIZE/2)+(210/2),GAMEN_START_Y+(GAMEN_Y_SIZE/4)+40,&RECParam);					/*  ȭ��Ʋ �ۼ�				 */

		sprintf(chDsp_buff, chContent);				
		DotTextOut(GAMEN_START_X+(GAMEN_X_SIZE/2)-(210/2)+20, GAMEN_START_Y+(GAMEN_Y_SIZE/4)-2, chDsp_buff, 1, 1, T_FRONT, T_BLACK, T_WHITE);

		sprintf(chDsp_buff, chContent1);				
		DotTextOut(GAMEN_START_X+(GAMEN_X_SIZE/2)-(210/2)+20, GAMEN_START_Y+(GAMEN_Y_SIZE/4)+18, chDsp_buff, 1, 1, T_FRONT, T_BLACK, T_WHITE);



	}else
	{
		AreaClear(GAMEN_START_X+3,GAMEN_START_Y+16,GAMEN_START_X+75,GAMEN_START_Y+152,0);								/*  ���ϴ� �κи��� Del   */
		RectAngleOut(GAMEN_START_X+3,GAMEN_START_Y+16,GAMEN_START_X+75,GAMEN_START_Y+152,&RECParam);					/*  ȭ��Ʋ �ۼ�				 */

		sprintf(chDsp_buff, chContent);				
		DotTextOut(GAMEN_START_X+7, GAMEN_START_Y+26, chDsp_buff, 1, 1, T_FRONT, T_BLACK, T_WHITE);

		memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
		sprintf(chDsp_buff, chContent1);				
		DotTextOut(GAMEN_START_X+7, GAMEN_START_Y+48, chDsp_buff, 1, 1, T_FRONT, T_BLACK, T_WHITE);

		memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
		sprintf(chDsp_buff, chContent2);				
		DotTextOut(GAMEN_START_X+7, GAMEN_START_Y+70, chDsp_buff, 1, 1, T_FRONT, T_BLACK, T_WHITE);

		memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
		sprintf(chDsp_buff, chContent3);				
		DotTextOut(GAMEN_START_X+7, GAMEN_START_Y+92, chDsp_buff, 1, 1, T_FRONT, T_BLACK, T_WHITE);

		memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
		sprintf(chDsp_buff, chContent4);				
		DotTextOut(GAMEN_START_X+7, GAMEN_START_Y+114, chDsp_buff, 1, 1, T_FRONT, T_BLACK, T_WHITE);

	}

}
/* *******************************************************************************/
/*  �� �� �� : DefaultFormDisplay()												 */
/*  ��    �� : �⺻ ȭ��Ʋ�� �׸�												 */
/*  ��    �� : iType	, TitleName														 */
/*  ��    �� : 																	 */
/*  �� �� �� : 2003�� 06�� 26�� 												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
#ifdef	SIZE_2480
void DefaultFormDisplay(short iType, char* TitleName)
{	
	short	Data1;				/* */
	short	Data2;
	short	Data3;
	short	iLen;
	short	i;
	short	j;
	short	k;
	char	Number[2];
	_RECTANGLE_INFO RECParam;
	_LINE_INFO param;

	Data1 = 0;
	Data2 = 0;
	Data3 = 0;
	memset(Number,0x00,2);
	param.iLineColor = WHITE;							/* Line Data Set		*/
	param.iLineStyle = SOLID_LINE;

	RECParam.iLineStyle = SOLID_LINE;					/* Rectangle Data Set	*/
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	Data1 = (iType & 0x01);
	Data2 = (iType & 0x02);
	Data3 = (iType & 0x04);

	if(TitleName == NULL){  /* �ý��� �޼����� ���ڰ� ������ ���� �ʵ��� �� */
		iLen = 20; 
	}else{
		iLen = strlen(TitleName);
	}

	iLen = (short)(156 - (iLen*8))/2;
	
	RectAngleOut(GAMEN_START_X+1,GAMEN_START_Y+1,GAMEN_START_X+39,GAMEN_START_Y+20,&RECParam);					/* ���� ��ư			 */
	RectAngleOut(GAMEN_START_X+41,GAMEN_START_Y+1,GAMEN_START_X+198,GAMEN_START_Y+20,&RECParam);				/* Ÿ��Ʋ�� Ʋ 			 */
	RectAngleOut(GAMEN_START_X+200,GAMEN_START_Y+1,GAMEN_START_X+238,GAMEN_START_Y+20,&RECParam);				/* ���� ��ư			 */

	DotTextOut(GAMEN_START_X+41+iLen,GAMEN_START_Y+3,TitleName,1,1, NON_TRANS, T_WHITE, T_BLACK);	/* Title	*/
	DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+3,Dspname[NO_USE_MESS].chName[Set.iLang][4],1,1, NON_TRANS, T_WHITE, T_BLACK);			/* ���� 	*/
	DotTextOut(GAMEN_START_X+204,GAMEN_START_Y+3,Dspname[NO_USE_MESS].chName[Set.iLang][5],1,1, NON_TRANS, T_WHITE, T_BLACK);			/* ���� 	*/
	k = 0;
	if(Data1 == 1)										/* ȭ���� ���� ���� ���� */
	{
		LineOut(GAMEN_START_X+1, GAMEN_START_Y+22, GAMEN_START_X+238, GAMEN_START_Y+22, &param);
		if(Data2 == 2)
		{
			DotTextOut(GAMEN_START_X+68,GAMEN_START_Y+63,D_CLRBUT,1,1, NON_TRANS, T_WHITE, T_BLACK);
			DotTextOut(GAMEN_START_X+101,GAMEN_START_Y+63,D_ENTBUT,1,1, NON_TRANS, T_WHITE, T_BLACK);
			for(i=0;i<3;i++)
			{
				for(j=0;j<4;j++)
				{
					if(k<10)
					{
						sprintf(Number,"%d",k);
						DotTextOut(GAMEN_START_X+13+(j*32),GAMEN_START_Y+25+(i*19),Number,1,1, NON_TRANS, T_WHITE, T_BLACK);
					}
					RectAngleOut(GAMEN_START_X+1+(j*32),GAMEN_START_Y+24+(i*19),GAMEN_START_X+31+(j*32),GAMEN_START_Y+41+(i*19),&RECParam);		/* ��ư */
					k++;
				}
			}
			RectAngleOut(GAMEN_START_X+129,GAMEN_START_Y+24,GAMEN_START_X+238,GAMEN_START_Y+79,&RECParam);				
		}
	}
	else												/* ȭ���� ���� ���� ���� */
	{
		LineOut(GAMEN_START_X+1, GAMEN_START_Y+22, GAMEN_START_X+198, GAMEN_START_Y+22, &param);
		LineOut(GAMEN_START_X+198, GAMEN_START_Y+23, GAMEN_START_X+198, GAMEN_START_Y+78, &param);
		if(Data3 == 4)									/* ��ư�� ���� ��� */		
		{
//			DotTextOut(GAMEN_START_X+216,GAMEN_START_Y+24,Dspname[ELSMESSAGE].chName[Set.iLang][1],1,1, NON_TRANS, T_WHITE, T_BLACK);  /* UP */
//			DotTextOut(GAMEN_START_X+216,GAMEN_START_Y+61,Dspname[ELSMESSAGE].chName[Set.iLang][0],1,1, NON_TRANS, T_WHITE, T_BLACK);  /* DOWN */

/* KSC20070222 */
/*			DotTextOut(208,24,Dspname[LCDCONTRAST].chName[Set.iLang][1],1,1, NON_TRANS, T_WHITE, T_BLACK);  */ /* UP */
			DotTextOut(GAMEN_START_X+216,GAMEN_START_Y+24,Dspname[ELSMESSAGE].chName[Set.iLang][1],1,1, NON_TRANS, T_WHITE, T_BLACK);  /* UP */
/*			DotWriteFont0(1,217,24,(unsigned char *)&TriangleFont[0],T_BLACK,1,1,NON_TRANS,0,0);		*/	
/*			DotTextOut(208,61,Dspname[LCDCONTRAST].chName[Set.iLang][0],1,1, NON_TRANS, T_WHITE, T_BLACK);  */ /* DOWN */
			DotTextOut(GAMEN_START_X+216,GAMEN_START_Y+61,Dspname[ELSMESSAGE].chName[Set.iLang][0],1,1, NON_TRANS, T_WHITE, T_BLACK);  /* DOWN */
/*			DotWriteFont0(1,217,61,(unsigned char *)&TriangleFont[32],T_BLACK,1,1,NON_TRANS,0,0);		*/	
			
			
			RectAngleOut(GAMEN_START_X+210,GAMEN_START_Y+22,GAMEN_START_X+238,GAMEN_START_Y+41,&RECParam);					/*  �ٱ� ��ư			 */
			RectAngleOut(GAMEN_START_X+212,GAMEN_START_Y+24,GAMEN_START_X+236,GAMEN_START_Y+39,&RECParam);					/*  �� ��ư 			 */
			RectAngleOut(GAMEN_START_X+210,GAMEN_START_Y+59,GAMEN_START_X+238,GAMEN_START_Y+78,&RECParam);					/*  �ٱ� ��ư			 */
			RectAngleOut(GAMEN_START_X+212,GAMEN_START_Y+61,GAMEN_START_X+236,GAMEN_START_Y+76,&RECParam);					/*  �� ��ư 			 */
			RectAngleOut(GAMEN_START_X+200,GAMEN_START_Y+22,GAMEN_START_X+208,GAMEN_START_Y+78,&RECParam);					/*  �� ��ư 			 */
		}
	}

}
#endif
#ifdef	SIZE_2480
/* *******************************************************************************/
/*  �� �� �� : ScroolBarDisplay()												 */
/*  ��    �� : ��ũ�ѹٸ� �׸�													 */
/*  ��    �� : TLineCnt,NowPoint												 */
/*  ��    �� : 																	 */
/*  �� �� �� : 2003�� 06�� 27�� 												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
void ScroolBarDisplay(short TLineCnt, short NowPoint)
{
	short	TDot;
	short	LineVal;
	short	StartData;
	short	EndData;
	short	Tip;
	float	iData;
	_RECTANGLE_INFO RECParam;
	
	RECParam.iLineStyle = SOLID_LINE;					/* Rectangle Data Set	*/
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT8;
	RECParam.iForeColor = WHITE;
	RECParam.iBackColor = WHITE;
	
	TDot = 52;
	if(TDot>TLineCnt)
	{
		if(TLineCnt > 2){
			LineVal		= (short) TDot/TLineCnt;
			Tip			= (short) TDot%TLineCnt;
			StartData	= NowPoint * LineVal;
			EndData		= (LineVal * 3) + StartData + Tip;
		}else
		{
			StartData	= 0;
			EndData		= 52;
		}
	}else
	{
		iData = (float)TDot/TLineCnt;
		StartData = (short)(iData*NowPoint);
		if(StartData > 50)
			StartData = 50;
		EndData = StartData+2;
	}
	AreaClear(GAMEN_START_X+202,GAMEN_START_Y+24,GAMEN_START_X+206,GAMEN_START_Y+76,0);
	RectAngleOut(GAMEN_START_X+202,GAMEN_START_Y+24+StartData,GAMEN_START_X+206,GAMEN_START_Y+24+EndData,&RECParam);	
}
#endif
/* *******************************************************************************/
/*  �� �� �� : EnterCutting()													 */
/*  ��    �� : TEXT���� ������ Ent�� ����.										 */
/*  ��    �� : *strData															 */
/*  ��    �� : 																	 */
/*  �� �� �� : 2003�� 08�� 29�� 												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
void	EnterCutting(char* strData)
{
	short	iLen;
	iLen = strlen(strData);
	if(strData[iLen-2] == 0x0D && strData[iLen-1] == 0x0A)				/* ���ο� ������ ENT�� ����� ó�� */
	{
		strData[iLen-2] = 0x00;
	}
}
/* *******************************************************************************/
/*  �� �� �� : KeyWaitData()													 */
/*  ��    �� : ����ġ ���� �ϱ� ����											 */
/*  ��    �� : iKeyFlag															 */
/*  ��    �� : 																	 */
/*  �� �� �� : 																	 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
int		KeyWaitData(short iKeyFlag, int iType)
{
	int KeyData;
	if(iType == 0xffff)
	{
		while(1)
		{
			KeyData = KeyWait();
			if(KeyData == PC_DNLOAD_START || KeyData == PC_UPLOAD_START || 
				KeyData == 0 || iKeyFlag == 0 ||
				KeyData == PC_UPDOWN_END || KeyData == PC_CONT)
				break;
		}
	}else
	{
		while(1)
		{
			KeyData = iKeyReturn(iType);
			if(KeyData == PC_DNLOAD_START || KeyData == PC_UPLOAD_START 
				|| KeyData == 0 || iKeyFlag == 0 ||
				KeyData == PC_UPDOWN_END || KeyData == PC_CONT)
				break;
		}
	}
	return KeyData;
}
/* *******************************************************************************/
/*  �� �� �� : iScreenExist()													 */
/*  ��    �� : Screen�� ���� Ȯ��												 */
/*  ��    �� : ScreenNum (��ũ����ȣ)											 */
/*  ��    �� : ReturnData (��ũ�� �� = 1, �� = -1 )								 */
/*  �� �� �� : 																	 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
int		iScreenExist(short ScreenNum)
{
	int ReturnData;
	int	i;

	ReturnData = -1;
	if(iBaseScreenCnt>1)
	{
		for(i=0;i<iBaseScreenCnt;i++)
		{
			if(Screen[i].iNum == ScreenNum)
			{
				ReturnData = 1;
				break;
			}
			else if(Screen[i].iNum > ScreenNum)
				break;
		}
	}
	return ReturnData;
}


#ifdef	PASSWORD_NO_CHANGE		/* 20081023 */

#else
/************************************************/
/*	Password Check								*/
/*	2008.10.23									*/
/************************************************/
int	CheckLevelPassword(int idx,char* buff)
{
	unsigned long	iTagCode;
	unsigned long	TagCode;
	char	wbuff[32];

	strcpy(wbuff,buff);
	iTagCode= Encrypt(wbuff);		/* 20081023 Password Change */
	memcpy(wbuff,CommonArea.SystemDev.Password[idx],15);
	wbuff[15]= 0;
	TagCode= gatoi(wbuff);
	return(TagCode- iTagCode);
}
#endif

/* *******************************************************************************/
/*  �� �� �� : iSysSetretCheck()												 */
/*  ��    �� : �ý��� ȭ�鿡 Setret check										 */
/*  ��    �� : ScreenNum (�ý��� ȭ�� ��ȣ)										 */
/*  ��    �� : (��ũ�� �� = 1, �� = -1 )										 */
/*  �� �� �� : 																	 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
int		iSysSetretCheck(int ScreenNum)
{
	int				iPoint;
	int				ReturnData;
	int				i;
	short			iDataFlag;
	DEV_DATA		WriteDev;
	char			cRetVal[2];
	char			swork[16+1];

#ifdef	PASSWORD_NO_CHANGE		/* 20081023 */
	unsigned long	iTagCode;
#else

#endif	

	int				len;
	char chPassData[9];
	int					tmpiPassLevel;

	ReturnData = 0;		/* ���� ������.*/
	if(CommonArea.UtilityLevel[30] == 0x00)
		return ReturnData;

		// 2012.08.06 jmSon ���� ���� 
	if((ScreenNum >= SERIAL_PORT_NUM) && (ScreenNum < BASE_SCREEN_NUM)){			//2012.08.16
		ScreenNum++;													//2012.08.16
	}																	//2012.08.16

	switch(ScreenNum)
	{
		case DEVICE_MONITORING_NUM:
			iPoint = 0;
			break;

		case LANGUAGE_NUM:
			iPoint = 1;
			break;
		case SERIAL_PORT_NUM:
			iPoint = 2;
			break;
		case PLC_SETTING_NUM:
//			iPoint = 3;
			iPoint = 2;
			break;
		case CLOCK_MENU_NUM:
//			iPoint = 4;
			iPoint = 3;
			break;
		case CLEAR_DATA_NUM:
//			iPoint = 5;
			iPoint = 4;
			break;
		case MENU_CALL_KEY_NUM:
//			iPoint = 6;
			iPoint = 5;
			break;
		case BUZZER_NUM:
//			iPoint = 7;
			iPoint = 6;
			break;
		case OPENNING_NUM:
//			iPoint = 8;
			iPoint = 7;
			break;
		case BACKLIGHT_NUM:
//			iPoint = 9;
			iPoint = 8;
			break;
		case BATTERY_NUM:
//			iPoint = 10;
			iPoint = 9;
			break;
		case LCDCONTRAST_NUM:
//			iPoint = 11;
			iPoint = 10;
			break;

		
		case BASE_SCREEN_NUM:
//			iPoint = 12;
			iPoint = 11;
			break;
		case WINDOW_SCREEN_NUM:
//			iPoint = 13;
			iPoint = 12;
			break;
		case COMMENT_SCREEN_NUM:
//			iPoint = 14;
			iPoint = 13;
			break;
		case MEMORY_SIZE_NUM:
//			iPoint = 15;
			iPoint = 14;
			break;

		
		case DATA_TRANSFER_NUM:
//			iPoint = 16;
			iPoint = 15;
			break;
		case TIME_SWITCH_NUM:
//			iPoint = 17;
			iPoint = 16;
			break;
		case PRINT_OUT_NUM:
//			iPoint = 18;
			iPoint = 17;
			break;
	}
	if(((int)CommonArea.UtilityLevel[iPoint])>iPassLevel)
	{

		NormalBuzzer();	/* 050427 */
		memset(chPassData,0x00,sizeof(chPassData));

		vNumberInputPan(2);
		/* PassWord Dispaly 050427 */
		/* �ő僌�x���̃p�X��?�h��?������ */
		memset(swork,0,sizeof(swork));
		for(i=14;i>=0;i--){

#ifdef	PASSWORD_NO_CHANGE		/* 20081023 */
			if(strncmp(CommonArea.SystemDev.Password[i],swork,8)!=0)
			{
				strncpy(swork,CommonArea.SystemDev.Password[i],8);
				swork[8]= 0;
				iTagCode= Encrypt(swork);
				sprintf(swork,"%d",iTagCode);
				break;	
			}
#else
/*			if(strncmp(CommonArea.SystemDev.Password[i],swork,8)!=0)	20081023 */
			if(strncmp(CommonArea.SystemDev.Password[i],swork,15)!=0)
			{
/*				strncpy(swork,CommonArea.SystemDev.Password[i],8);	20081023 */
/*				swork[8]= 0;*/
/*				iTagCode= Encrypt(swork);	*/	/* 20081023 Password Change */
/*				sprintf(swork,"%d",iTagCode);*/	/* 20081023 Password Change */
				strncpy(swork,CommonArea.SystemDev.Password[i],15);
				swork[15]= 0;
				break;	
			}
#endif			
			

		}
		len= strlen(swork);
		DotTextOut(GAMEN_START_X+182-8*(len-1),GAMEN_START_Y+3,swork,1,1, TRANS, T_WHITE, T_BLACK);
		/**********************************************/

		DrawLcdBank1();
		ReturnData = iDevInput10Select(chPassData, 8, 100);	/* ���� ����Ÿ, ����Ÿ�� ���� */
		
		if(ReturnData == DOWN_TRANS)		/* DownLoad	*/
			return ReturnData;
		else if(ReturnData == UP_TRANS)		/* UPLoad	*/
			return ReturnData;
		else if(ReturnData == 1)
			ReturnData = 2;

		if(ReturnData != 2)
		{
			iDataFlag= 0;
			for(i=0;i<15;i++){

#ifdef	PASSWORD_NO_CHANGE		/* 20081023 */
				if(strcmp(CommonArea.SystemDev.Password[i],chPassData)==0)
				{
					tmpiPassLevel = i+1;
					iDataFlag = 1;
					break;	
				}
#else
/*				if(strcmp(CommonArea.SystemDev.Password[i],chPassData)==0)	20081023 */
				if(CheckLevelPassword(i,chPassData) == 0)
				{
					tmpiPassLevel = i+1;
					iDataFlag = 1;
					break;	
				}
#endif	
			}
			if(iDataFlag == 1){
				if(tmpiPassLevel >= ((int)CommonArea.UtilityLevel[iPoint]))
				{
					iPassLevel = tmpiPassLevel;
					WriteDev.DevFlag = 1;	
					WriteDev.DevName[0] = CommonArea.SystemDev.Password_Dev.DevName[0];
					WriteDev.DevName[1] = CommonArea.SystemDev.Password_Dev.DevName[1];
					WriteDev.DevName[2] = 0x00;
					WriteDev.DevAddress = CommonArea.SystemDev.Password_Dev.DevAdd;
					WriteDev.DevCnt = 1;
					WriteDev.DevData = cRetVal;
					memset(cRetVal,0x00,sizeof(cRetVal));
					//061124
//					cRetVal[0] = (char)iPassLevel;
//					cRetVal[1] = 0x00;
					cRetVal[1] = (char)iPassLevel;
					cRetVal[0] = 0x00;
					PLCWrite(&WriteDev); 
					ReturnData = 1;
				}else{
					iDataFlag= 0;
				}
			}
			if(iDataFlag == 0){
				if(CommonArea.SystemDev.DispPassinputchk == 0xFF){
					iCaptionWindow(Dspname[BATTERY].chName[Set.iLang][10],"");
				}else{
					ErrorBuzzer();
				}
				ReturnData = 1;
			}
		}		
	}
	return ReturnData;	/* ReturnData(0:�������� 1:���ȷ����� �������� 2:CLR��ưŬ���� ��Ÿ:UP_TRANS,DOWN_TRANS)*/
}
/* *******************************************************************************/
/*  �� �� �� : iDeviceAddressReturn()											 */
/*  ��    �� : ���� ����̽� �ּҸ� ����										 */
/*  ��    �� : (���� ����̽� �ּ�, �̸�, ��Ʈ����Ÿ��, 16_32Ÿ��)				 */
/*  ��    �� : (���� ����̽� �ּ�)												 */
/*  �� �� �� : 																	 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
int iDeviceAddressReturn( char* cDevName, int iDevAddr, int i1632flag)
{
	int		iret;
	int		DevInfo;
	int		iBWflag;
	int		iADDAddress;
//	int		TimeDevFlag;
	int		iBitflag;
	char	chChName[6];
	char	Device_Name[4];
	int		iType;
//	int		iVal;

	iBitflag = (int)cDevName[0] & 0x00ff;
//	iVal = GetDevName(iBitflag,cDevName,Device_Name,&iType);
	GetDevName(iBitflag,cDevName,Device_Name,&iType);

	if(iBitflag & 0xf0 != 0xf0)
		iBWflag = 0;
	else
		iBWflag = 1;

	if((iType & 0x000f) == 0x0009)
	{
		if(i1632flag == 0)
			iADDAddress = 16;
		else
			iADDAddress = 32;
	}
	else
	{
		if(i1632flag == 0)
			iADDAddress = 1;
		else
			iADDAddress = 2;
	}

//	TimeDevFlag = GetDevNamePLCAddr(iBWflag,(unsigned char *)cDevName,chChName,&DevInfo,&iDevAddr);
	GetDevNamePLCAddr(iBWflag,(unsigned char *)cDevName,chChName,&DevInfo,&iDevAddr);
	iret= SetPLCUsrAddr(DevInfo,iDevAddr+iADDAddress,Device2Index(iBWflag,chChName),iBWflag);
	
	return iret;
}
