/********************************************************************************/
/* �� �� �� : Gp_ClockTask.cpp													*/
/* ��    �� : NumericTask														*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"

/********************************************************************************/
/* �� �� �� : DrawClock_Func													*/
/* ��    �� : Clock ������ �ص��Ͽ� ȭ�鿡 ���								    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 25�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetClock_Func(int iDispOrder)
{
	unsigned char *buffer;
	
	buffer= ScreenTagData[iDispOrder].TagPos;
	if((unsigned int)(buffer[21]) == 0x00){
		ScreenTagData[iDispOrder].BeShapeUsed = UNCHECKED;
	}else{
		ScreenTagData[iDispOrder].BeShapeUsed = CHECKED;
	}
	ClockDispCnt++;
}
int	DrawClock_Func(_CLOCK_EVENT_TBL* ClockEventTbl,int iDispOrder)
{
/*	unsigned int		iTagSizeOf;*/
	unsigned char *buffer;
	
	buffer= ScreenTagData[iDispOrder].TagPos;
/*	_CLOCK_EVENT_TBL*	 ClockEventTbl;*/
/*
	if(CheckMailBox(sizeof(_CLOCK_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_CLOCK_EVENT_TBL));
	ClockEventTbl= (_CLOCK_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)ClockEventTbl, 0x00, sizeof(_CLOCK_EVENT_TBL));

/*	iTagSizeOf  = 0x00;
			
	iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
	iTagSizeOf += (unsigned int)buffer[1] & 0xff;	
	
	ClockEventTbl->sX  = (unsigned int)(buffer[6] << 0x08);
	ClockEventTbl->sX += (unsigned int)buffer[7] & 0xff;

	ClockEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
	ClockEventTbl->sY += (unsigned int)buffer[9] & 0xff;

	ClockEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
	ClockEventTbl->eX += (unsigned int)buffer[11] & 0xff;

	ClockEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
	ClockEventTbl->eY += (unsigned int)buffer[13] & 0xff;	
*/
	ClockEventTbl->iFrameColor = (unsigned int)buffer[14];
	ClockEventTbl->iFontSizeH  = (unsigned int)buffer[15];
	ClockEventTbl->iFontSizeV  = (unsigned int)buffer[16];
	ClockEventTbl->iTextColor  = (unsigned int)buffer[17];
	ClockEventTbl->iPlateColor = (unsigned int)buffer[18];

	ClockEventTbl->iFormatFlag = (unsigned int)buffer[19]; /* Display style 0x01(Date),0x02(time) */
	ClockEventTbl->iFormatTag  = (unsigned int)buffer[20]; 
	/* Data format Data -> 0x01(yy/mm/dd), 0x02(dd/mm/yy), 0x03(mm/dd/yy), 0x04(Type1), 0x05(Type2)   
				   Time -> 0x01(Type1), 0x02(Type2) */

	/* [22]~[27] : DisplayStyle(Date, Time)�� ������ ��������. */
	if((unsigned int)(buffer[21]) == 0x00){
/*
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed = UNCHECKED;
		}
*/
		ClockEventTbl->ShapeNo = 0;
	}
	else{
/*
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed = CHECKED;
		}
*/
		ClockEventTbl->ShapeNo = (unsigned int)(buffer[22]);
	}
	if((unsigned int)buffer[23] != 0)
	{
		ClockEventTbl->iFontSizeH = 0;
		ClockEventTbl->iFontSizeV = 0;		//20101207
	}

/*	ClockDispCnt++;*/
/*	IventTableCnt++;*/

	return(0);
}

void ClockDispWatch(int iOrder)
{
	char*			DispBuffer;
	char			cMonth[4];
	char			cWeek[4];
	int				iFontsX;
	int				iFontsY;
//	int				iNowData;
	int				Font_Color;
	int				Back_Color;
	int				iType;
	short			iShapeSize;
	char			NowTimeBuff[10];

	_CLOCK_EVENT_TBL*	ClockEventTbl;

	iFontsX			= 0;
	iFontsY			= 0;
//	iNowData		= 0;
	Font_Color		= 0;
	Back_Color		= 0;
	iType			= 0;
	iShapeSize		= 0;

/*	ClockEventTbl = (_CLOCK_EVENT_TBL*)IventTable[iOrder];*/
	ClockEventTbl = (_CLOCK_EVENT_TBL*)TakeMemory(sizeof(_CLOCK_EVENT_TBL));
	DrawClock_Func(ClockEventTbl,iOrder);

	memset(cMonth, 0x00, sizeof(cMonth));
	memset(cWeek, 0x00, sizeof(cWeek));
	DispBuffer = (char *)TakeMemory(32);			
		
	if(ClockEventTbl->iFormatFlag == 0x01){
		if(ClockEventTbl->iFormatTag == DDMMYY){
/*			DispBuffer = (char *)TakeMemory(9);*/
			sprintf(DispBuffer, "%02d/%02d/%02d", NowTime.day, NowTime.mon, NowTime.year);
//			iNowData = NowTime.day;
			/* iDelay = 600; */
		}
		else if(ClockEventTbl->iFormatTag == YYMMDD){
/*			DispBuffer = (char *)TakeMemory(9);*/
			sprintf(DispBuffer, "%02d/%02d/%02d", NowTime.year, NowTime.mon, NowTime.day);
//			iNowData = NowTime.day;
			/* iDelay = 600; */
		}
		else if(ClockEventTbl->iFormatTag == MMDDYY){
/*			DispBuffer = (char *)TakeMemory(9);*/
			sprintf(DispBuffer, "%02d/%02d/%02d", NowTime.mon, NowTime.day, NowTime.year);
//			iNowData = NowTime.day;
			/* iDelay = 600; */
		}
		else if(ClockEventTbl->iFormatTag == DATETYPE1){/* 28/MAY/2002(TUE) */
/*			DispBuffer = (char *)TakeMemory(17);*/
			CheckMonth(cMonth, NowTime.mon);
			CheckWeek(cWeek, NowTime.week);
			sprintf(DispBuffer, "%02d/%3s/%04d(%3s)", NowTime.day, cMonth, START_YEAR + NowTime.year, cWeek);
//			iNowData = NowTime.day;
			/* iDelay = 600; */
		}
		else {/* if(ClockEventTbl->iFormatTag == DATETYPE2)28/MAY/2002 */
/*			DispBuffer = (char *)TakeMemory(12);*/
			CheckMonth(cMonth, NowTime.mon);
			sprintf(DispBuffer, "%02d/%3s/%04d", NowTime.day, cMonth, START_YEAR + NowTime.year);
//			iNowData = NowTime.day;
			/* iDelay = 600; */
		}
	}
	else{
		switch(ClockEventTbl->iFormatTag){
		case TIMETYPE1:/* 15:35:59 */
/*			DispBuffer = (char *)TakeMemory(8);*/
			if((0 <= NowTime.hour) && (NowTime.hour <= 9)){
				itoa(NowTime.hour, NowTimeBuff, 10);
				sprintf(DispBuffer, "%2s:%02d:%02d", NowTimeBuff, NowTime.min, NowTime.sec);
			}else{
				sprintf(DispBuffer, "%02d:%02d:%02d", NowTime.hour, NowTime.min, NowTime.sec);
			}
//			iNowData = NowTime.sec;
			/* iDelay = 10; */
			break;
		case TIMETYPE2:	/* 15:34 */
/*			DispBuffer = (char *)TakeMemory(5);*/
			if((0 <= NowTime.hour) && (NowTime.hour <= 9)){
				itoa(NowTime.hour, NowTimeBuff, 10);
				sprintf(DispBuffer, "%2s:%02d", NowTimeBuff, NowTime.min);
			}else{
				sprintf(DispBuffer, "%02d:%02d", NowTime.hour, NowTime.min);
			}
//			iNowData = NowTime.min;
			/* iDelay = 10; */
			break;
		case TIMETYPE3:/* 15:35:59 PM */
/*			DispBuffer = (char *)TakeMemory(16);*/
			if(NowTime.hour >= 12){	/* PM */
				if(NowTime.hour == 12){
					sprintf(DispBuffer, "%02d:%02d:%02d PM", NowTime.hour, NowTime.min, NowTime.sec);
				}else{
					if((22 <= NowTime.hour) && (NowTime.hour <= 23)){
						sprintf(DispBuffer, "%02d:%02d:%02d PM", NowTime.hour-0x0c, NowTime.min, NowTime.sec);
					}else{
						itoa((NowTime.hour-12), NowTimeBuff, 10);
						sprintf(DispBuffer, "%2s:%02d:%02d PM", NowTimeBuff, NowTime.min, NowTime.sec);
					}
				}
			}else{
				if((0 <= NowTime.hour) && (NowTime.hour <= 9)){
					itoa(NowTime.hour, NowTimeBuff, 10);
					sprintf(DispBuffer, "%2s:%02d:%02d AM", NowTimeBuff, NowTime.min, NowTime.sec);
				}else{
					sprintf(DispBuffer, "%02d:%02d:%02d AM", NowTime.hour, NowTime.min, NowTime.sec);
				}
			}
//			iNowData = NowTime.sec;
			/* iDelay = 10; */
			break;
		case TIMETYPE4:	/* 15:34 PM */
/*			DispBuffer = (char *)TakeMemory(16);*/
			if(NowTime.hour >= 12){	/* PM */
				if(NowTime.hour == 12){
					sprintf(DispBuffer, "%02d:%02d PM", NowTime.hour, NowTime.min);
				}else{
					if((22 <= NowTime.hour) && (NowTime.hour <= 23)){
						sprintf(DispBuffer, "%02d:%02d PM", NowTime.hour- 0x0c, NowTime.min);
					}else{
						itoa((NowTime.hour-12), NowTimeBuff, 10);
						sprintf(DispBuffer, "%2s:%02d PM", NowTimeBuff, NowTime.min);
					}
				}
			}else{
				if((0 <= NowTime.hour) && (NowTime.hour <= 9)){
					itoa(NowTime.hour, NowTimeBuff, 10);
					sprintf(DispBuffer, "%2s:%02d AM", NowTimeBuff, NowTime.min);
				}else{
					sprintf(DispBuffer, "%02d:%02d AM", NowTime.hour, NowTime.min);
				}
			}
//			iNowData = NowTime.min;
			/* iDelay = 10; */
			break;
		}
	}

	iFontsX = ScreenTagData[iOrder].sX;
	iFontsY = ScreenTagData[iOrder].sY;

	Font_Color = ClockEventTbl->iTextColor;
	if(Font_Color == 0)
	{
		Back_Color	= WHITE;	
		iType		= T_FRONT;
	}else
	{
		Back_Color = BLACK;
		iType      = T_OR;
	}
	if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){
	iShapeSize =	DrawShape(ClockEventTbl->ShapeNo, 
				ScreenTagData[iOrder].sX, 
				ScreenTagData[iOrder].sY, 
				ScreenTagData[iOrder].eX, 
				ScreenTagData[iOrder].eY,
				ClockEventTbl->iFrameColor,
				ClockEventTbl->iPlateColor);
	iFontsX=iFontsX+iShapeSize;
	iFontsY=iFontsY+iShapeSize;
	}
	DotTextOut(iFontsX, iFontsY,DispBuffer,ClockEventTbl->iFontSizeH,
				ClockEventTbl->iFontSizeV,iType,Font_Color,Back_Color); /*T_FRONT T_OR*/

	FreeMail(DispBuffer);
	FreeMail((char *)ClockEventTbl);
}


void CheckWeek(char* cWeek, int iWeek)
{	
	switch(iWeek){
	case 1:		
		memcpy(cWeek, "MON", 3);
		break;
	case 2:
		memcpy(cWeek, "TUE", 3);
		break;
	case 3:
		memcpy(cWeek, "WED", 3);
		break;
	case 4:
		memcpy(cWeek, "THU", 3);
		break;
	case 5:
		memcpy(cWeek, "FRI", 3);
		break;
	case 6:
		memcpy(cWeek, "SAT", 3);
		break;
	case 0:
		memcpy(cWeek, "SUN", 3);
		break;
	}
}

void CheckMonth(char* cMonth, int iMonth)
{
	switch(iMonth){
	case 1:
		memcpy(cMonth, "JAN", 3);
		break;
	case 2:
		memcpy(cMonth, "FEB", 3);
		break;
	case 3:
		memcpy(cMonth, "MAR", 3);
		break;
	case 4:
		memcpy(cMonth, "APR", 3);
		break;
	case 5:
		memcpy(cMonth, "MAY", 3);
		break;
	case 6:
		memcpy(cMonth, "JUN", 3);
		break;
	case 7:
		memcpy(cMonth, "JUL", 3);
		break;
	case 8:
		memcpy(cMonth, "AUG", 3);
		break;
	case 9:
		memcpy(cMonth, "SEP", 3);
		break;
	case 10:
		memcpy(cMonth, "OCT", 3);
		break;
	case 11:
		memcpy(cMonth, "NOV", 3);
		break;
	case 12:
		memcpy(cMonth, "DEC", 3);		
		break;
	}
}
