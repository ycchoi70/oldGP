
/********************************************/
/*	System Message For All Nation			*/
/********************************************/
#include	"Gpstruct.h"
#ifdef	WIN32
#define	const
#endif

#ifdef	SIZE_2480
extern	volatile	const _DISPLAY DspnameData[];
#ifdef	WIN32
volatile	const DISPLAY_TBL	DspnameTbl=
{
	2,
	{
		(_DISPLAY *)&DspnameData,
	}
};
#endif
#endif

#ifdef	GP_S057
/****************************************************/
/*	GP_S057(320X240)									*/
/****************************************************/
extern	volatile	const _DISPLAY DspnameData[];
extern	volatile	const _DISPLAY1	LargDispName[];
#ifdef	WIN32
volatile	const DISPLAY_TBL	DspnameTbl=
{
	2,
	{
		(_DISPLAY *)&DspnameData,
		(_DISPLAY *)&LargDispName,
	}
};
#endif
#endif



/*****************************************************************************************************************/

volatile	const _DISPLAY DspnameData[] =
/*ksc20040727*/ /* ������ �޴��� ���� */
{

/*****************************************************************************************************************/

	{	/* 0 */							/*0		0 ùȭ�� 0 */
		{"[SELECT MENU]",
#ifdef	KOREA	 
				"[�ý��� �޴� ����]"
#elif	JAPAN	
				"[���j���[�I��]"
#elif	CHINA	
				"[SELECT MENU]"
#elif	TAIWAN
				"[SELECT MENU]"
#elif	ENGLISH	
				"[SELECT MENU]"
#endif
		},
/****************************************/
#ifdef	SIZE_2480  /* 0 */	
		{
				{"MONITORING"		,"SET ENVIRONMENT"	,"DATA VIEW"	,"SET FUNCTION","LP PARAMETER SETTING"	,"","","",""},
#ifdef	KOREA	
				{"����͸� "		,"ȯ�� ���� "		,"������ Ȯ�� "	,"��� ���� "  ,"LP �Ķ��Ÿ ���� "		,"","","",""}
#elif	JAPAN	
				{"���j�^�����O "	 ,"���ݒ� "		 ,"�f�[�^ �\�� "	,"��{�ݒ� "	,"LP PARAMETER SETTING"	 ,"","","",""}
#elif	CHINA	
				{"MONITORING"		,"SET ENVIRONMENT"	,"DATA VIEW"	,"SET FUNCTION","LP PARAMETER SETTING"	,"","","",""}
#elif	TAIWAN	
				{"MONITORING"		,"SET ENVIRONMENT"	,"DATA VIEW"	,"SET FUNCTION","LP PARAMETER SETTING"	,"","","",""}
#elif	ENGLISH	
				{"MONITORING"		,"SET ENVIRONMENT"	,"DATA VIEW"	,"SET FUNCTION","LP PARAMETER SETTING"	,"","","",""}
#endif
		},
#endif
/****************************************/
#ifdef	GP_S057  /* 0 */	
		{
				{"Exit"   ,"[SELECT MENU]"     ,"MONITORING" ,"SET ENVIRONMENT","DATA VIEW"   ,"SET FUNCTION","Menu" },
#ifdef	KOREA	
				{"���� "  ,"[�ý��� �޴� ����]","����͸� "  ,"ȯ�� ���� "     ,"������ Ȯ�� ","��� ���� "  ,"�޴� "}
#elif	JAPAN
				{"�I�� "  ,"[���j���[�I��]"     ,"���j�^�����O","���ݒ� "      ,"�f�[�^�\�� "    ,"��{�ݒ� "    ,"�O�� "}
#elif	CHINA	
				{"Exit"   ,"[SELECT MENU]"     ,"MONITORING" ,"SET ENVIRONMENT","DATA VIEW"   ,"SET FUNCTION","Menu" }
#elif	TAIWAN	
				{"Exit"   ,"[SELECT MENU]"     ,"MONITORING" ,"SET ENVIRONMENT","DATA VIEW"   ,"SET FUNCTION","Menu" }
#elif	ENGLISH	
				{"Exit"   ,"[SELECT MENU]"     ,"MONITORING" ,"SET ENVIRONMENT","DATA VIEW"   ,"SET FUNCTION","Menu" }
#endif
		},
#endif
/****************************************/
	},
/*****************************************************************************************************************/
		
	{	/* 1 */							/*2		1 HPP MODEȭ�� */
		{"[MONITORING]",
#ifdef	KOREA	
				"[����͸�]"
#elif	JAPAN
				"[���j�^�����O]"
#elif	CHINA
				"[MONITORING]"
#elif	TAIWAN
				"[MONITORING]"
#elif	ENGLISH	
				"[MONITORING]"
#endif
		},
/****************************************/
#ifdef	LP_S044 /* 1 */	
		{
				{"DEVICE MONITORING" ,"DON`T MONITORING."          ,"I/O DEVICE MONITORING"	   ,"","","","","","","",""},
#ifdef	KOREA	
				{"����̽� ����͸� ","����͸��� �� �� �����ϴ�. ","����� ����̽� ����͸� ","","","","","","","",""}
#elif	JAPAN	
				{"�f�o�C�X���j�^ "    ,"���j�^�ł��܂��� "           ,"I/O �f�o�C�X ���j�^�����O ","","","","","","","",""}
#elif	CHINA	
				{"DEVICE MONITORING" ,"DON`T MONITORING."          ,"I/O DEVICE MONITORING"	   ,"","","","","","","",""},
#elif	TAIWAN	
				{"DEVICE MONITORING" ,"DON`T MONITORING."          ,"I/O DEVICE MONITORING"	   ,"","","","","","","",""},
#elif	ENGLISH	
				{"DEVICE MONITORING" ,"DON`T MONITORING."          ,"I/O DEVICE MONITORING"	   ,"","","","","","","",""},
#endif
		},
#endif
/****************************************/
#ifdef	GP_S044 /* 1 */	
		{
				{"DEVICE MONITORING" ,"DON`T MONITORING."          ,"","","","","","","","",""},
#ifdef	KOREA	
				{"����̽� ����͸� ","����͸��� �� �� �����ϴ�. ","","","","","","","","",""}
#elif	JAPAN	
				{"�f�o�C�X���j�^ "    ,"���j�^�ł��܂��� "           ,"","","","","","","","",""}
#elif	CHINA	
				{"DEVICE MONITORING" ,"DON`T MONITORING."          ,"","","","","","","","",""}
#elif	TAIWAN	
				{"DEVICE MONITORING" ,"DON`T MONITORING."          ,"","","","","","","","",""}
#elif	ENGLISH	
				{"DEVICE MONITORING" ,"DON`T MONITORING."          ,"","","","","","","","",""}
#endif
		},
#endif
/****************************************/
#ifdef	GP_S057 /* 1 */	
		{
				{"Exit" ,"[MONITORING]" ,"DEVICE MONITOR"  ,"Menu" ,"DON`T MONITOR."           ,"","","","","","","","",""},
#ifdef	KOREA	
				{"���� ","[����͸�]"   ,"����̽� ����� ","�޴� ","����͸� �� �� �����ϴ�. ","","","","","","","","",""}
#elif	JAPAN
				{"�I�� ","[���j�^�����O]","�f�o�C�X���j�^ "  ,"�O�� ","���j�^�ł��܂��� "         ,"","","","","","","","",""}
#elif	CHINA	
				{"Exit" ,"[MONITORING]" ,"DEVICE MONITOR"  ,"Menu" ,"DON`T MONITOR."           ,"","","","","","","","",""}
#elif	TAIWAN	
				{"Exit" ,"[MONITORING]" ,"DEVICE MONITOR"  ,"Menu" ,"DON`T MONITOR."           ,"","","","","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[MONITORING]" ,"DEVICE MONITOR"  ,"Menu" ,"DON`T MONITOR."           ,"","","","","","","","",""}
#endif
		},
#endif
/****************************************/
	},

/*****************************************************************************************************************/
	{	/* 2 */					/* 2-1	2 DEVICE MONITORTȭ�� */
		{"[DEVICE MONITOR]",

#ifdef	KOREA	
				"[����̽� �����]"
#elif	JAPAN
				"[�f�o�C�X���j�^]"
#elif	CHINA
				"[DEVICE MONITOR]"
#elif	TAIWAN
				"[DEVICE MONITOR]"
#elif	ENGLISH	
				"[DEVICE MONITOR]"
#endif
		},
#ifdef	SIZE_2480 /* 2 */
		{
				{"DEV.","SET","ON","OFF","DEVICE ERROR" ,"CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""},
#ifdef	KOREA	
				{"DEV.","SET","ON","OFF","����̽����� ","Ű���尡 �־ �ۼ��� " ,"���� �����ϴ�. " ,"","","",""}
#elif	JAPAN	
				{"DEV.","SET","ON","OFF","DEVICE ERROR" ,"�@�\���g�p�ł��܂��� "     ,"WHILE PROTECTED.","","","",""}
#elif	CHINA	
				{"DEV.","SET","ON","OFF","DEVICE ERROR" ,"CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""}
#elif	TAIWAN	
				{"DEV.","SET","ON","OFF","DEVICE ERROR" ,"CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""}
#elif	ENGLISH	
				{"DEV.","SET","ON","OFF","DEVICE ERROR" ,"CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""}
#endif
		},
#endif
#ifdef	GP_S057 /* 2 */
		{
				{"Exit" ,"[DEVICE MONITOR]" ,"Menu" ,"DEV."  ,"SET","ON","OFF","DEVICE ERROR" ,"CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""},
#ifdef	KOREA	
				{"���� ","[����̽� �����]","�޴� ","DEVICE","SET","ON","OFF","����̽����� ","Ű���尡 �־ �ۼ��� " ," ���� �����ϴ�. ","","","",""}
#elif	JAPAN	
				{"�I�� ","[�f�o�C�X���j�^]"  ,"�O�� ","DEV."  ,"SET","ON","OFF","DEVICE ERROR" ,"�@�\���g�p�ł��܂��� "     ,"WHILE PROTECTED.","","","",""}
#elif	CHINA	
				{"Exit" ,"[DEVICE MONITOR]" ,"Menu" ,"DEV."  ,"SET","ON","OFF","DEVICE ERROR" ,"CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""}
#elif	TAIWAN	
				{"Exit" ,"[DEVICE MONITOR]" ,"Menu" ,"DEV."  ,"SET","ON","OFF","DEVICE ERROR" ,"CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[DEVICE MONITOR]" ,"Menu" ,"DEV."  ,"SET","ON","OFF","DEVICE ERROR" ,"CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""}
#endif
		},
#endif
	},

/*****************************************************************************************************************/
	{	/* 3 */						/* 3	3 ACTIVE STATE MONTORȭ�� */
		{"[DATA VIEW]",
#ifdef	KOREA	
				"[������ Ȯ��]"
#elif	JAPAN
				"[�f�[�^�\��]"
#elif	CHINA
				"[DATA VIEW]"
#elif	TAIWAN
				"[DATA VIEW]"
#elif	ENGLISH	
				"[DATA VIEW]"
#endif
		},
#ifdef	SIZE_2480 /* 3 */
		{
				{"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE"      ,"MODEL & VERSION"    ,"","","","","",""},
#ifdef	KOREA	
				{"�⺻ ȭ�� " ,"������ ȭ�� " ,"�ڸ�Ʈ ","��� �޸� Ȯ�� ","�� �� ���� Ȯ�� " ,"","","","","",""}
#elif	JAPAN	
				{"BASE ��� " ,"WINDOW ��� " ,"COMMENT","�������T�C�Y "    ,"���f�� & �o�[�W���� ","","","","","",""}
#elif	CHINA	
				{"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE"      ,"MODEL & VERSION"    ,"","","","","",""}
#elif	TAIWAN	
				{"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE"      ,"MODEL & VERSION"    ,"","","","","",""}
#elif	ENGLISH	
				{"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE"      ,"MODEL & VERSION"    ,"","","","","",""}
#endif
		},
#endif
#ifdef	GP_S057 /* 3 */
		{
				{"Exit" ,"[DATA VIEW]"  ,"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE"      ,"Menu" ,"MODEL & VERSION"    ,"","","",},
#ifdef	KOREA	
				{"���� ","[������ Ȯ��]","�⺻ ȭ�� " ,"������ ȭ�� " ,"�ڸ�Ʈ ","��� �޸� Ȯ�� ","�޴� ","�� �� ���� Ȯ��"  ,"","","",}
#elif	JAPAN	
				{"�I�� ","[�f�[�^�\��]"    ,"BASE ��� " ,"WINDOW ��� " ,"COMMENT","�������T�C�Y "    ,"�O�� ","���f�� & �o�[�W���� ","","","",}
#elif	CHINA
				{"Exit" ,"[DATA VIEW]"  ,"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE"      ,"Menu" ,"MODEL & VERSION"    ,"","","",}
#elif	TAIWAN
				{"Exit" ,"[DATA VIEW]"  ,"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE"      ,"Menu" ,"MODEL & VERSION"    ,"","","",}
#elif	ENGLISH	
				{"Exit" ,"[DATA VIEW]"  ,"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE"      ,"Menu" ,"MODEL & VERSION"    ,"","","",}
#endif
		},
#endif
	},

/*****************************************************************************************************************/

	{	/* 4 */							/* 3-1	4 PC DIAGNOSISȭ�� */
		{"[BASE SCREEN]",
#ifdef	KOREA	
				"[�⺻ ȭ��]"
#elif	JAPAN
				"[BASE���]"
#elif	CHINA
				"[BASE SCREEN]"
#elif	TAIWAN
				"[BASE SCREEN]"
#elif	ENGLISH	
				"[BASE SCREEN]"
#endif
		},
#ifdef	SIZE_2480 /* 4 */
		{
				{"","","","","","","","","","",""},
#ifdef	KOREA	
				{"","","","","","","","","","",""}
#elif	JAPAN	
				{"","","","","","","","","","",""},				
#elif	CHINA	
				{"","","","","","","","","","",""},				
#elif	TAIWAN	
				{"","","","","","","","","","",""},				
#elif	ENGLISH	
				{"","","","","","","","","","",""}
#endif
		},
#endif
#ifdef	GP_S057 /* 4 */
		{
				{"Exit" ,"[BASE SCREEN]","Menu" ,"","","","","","","","","","","",""},
#ifdef	KOREA	
				{"���� ","[�⺻ ȭ��]"  ,"�޴� ","","","","","","","","","","","",""}
#elif	JAPAN	
				{"�I�� ","[BASE���]"   ,"�O�� ","","","","","","","","","","",""}
#elif	CHINA	
				{"Exit" ,"[BASE SCREEN]","Menu" ,"","","","","","","","","","","",""}
#elif	TAIWAN	
				{"Exit" ,"[BASE SCREEN]","Menu" ,"","","","","","","","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[BASE SCREEN]","Menu" ,"","","","","","","","","","","",""}
#endif
		},
#endif
	},

/*****************************************************************************************************************/

	{	/* 5 */						/* 3-2	5 TEST MODEȭ�� */
		{"[WINDOW SCREEN]",
#ifdef	KOREA	
				"[������ ȭ��]"
#elif	JAPAN
				"[WINDOW ���]"
#elif	CHINA
				"[WINDOW SCREEN]"
#elif	TAIWAN
				"[WINDOW SCREEN]"
#elif	ENGLISH	
				"[WINDOW SCREEN]"
#endif
		},
#ifdef	SIZE_2480 /* 5 */
		{
				{"INVALID ","VALUE..." ,"","","","","","","","",""},
#ifdef	KOREA	
				{"�߸��� " ,"���Դϴ� ","","","","","","","","",""}
#elif	JAPAN	
				{"�s���� " ,"�f�[�^..."  ,"","","","","","","","",""}
#elif	CHINA	
				{"INVALID ","VALUE..." ,"","","","","","","","",""}
#elif	TAIWAN	
				{"INVALID ","VALUE..." ,"","","","","","","","",""}
#elif	ENGLISH	
				{"INVALID ","VALUE..." ,"","","","","","","","",""}
#endif
		},
#endif
#ifdef	GP_S057 /* 5 */
		{
				{"Exit" ,"[WINDOW SCREEN]","Menu" ,"INVALID ","VALUE...""","","","","","","","","",""},
#ifdef	KOREA	
				{"���� ","[������ ȭ��]"  ,"�޴� ","�߸��� " ,"���Դϴ� " ,"","","","","","","","",""}
#elif	JAPAN	
				{"�I�� ","[WINDOW ���]"  ,"�O�� ","�s���� " ,"�f�[�^..."   ,"","","","","","","","",""}
#elif	CHINA	
				{"Exit" ,"[WINDOW SCREEN]","Menu" ,"INVALID ","VALUE...""","","","","","","","","",""}
#elif	TAIWAN	
				{"Exit" ,"[WINDOW SCREEN]","Menu" ,"INVALID ","VALUE...""","","","","","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[WINDOW SCREEN]","Menu" ,"INVALID ","VALUE...""","","","","","","","","",""}
#endif
		},
#endif
	},

/*****************************************************************************************************************/

	{	/* 6 */ 									/* 3-3	6 USER SCRRENȭ��			*/
		{"[COMMENT]",
#ifdef	KOREA	
				"[�ڸ�Ʈ]"
#elif	JAPAN
				"[�R�����g]"
#elif	CHINA
				"[COMMENT]"
#elif	TAIWAN
				"[COMMENT]"
#elif	ENGLISH	
				"[COMMENT]"
#endif
		},
		{
				{"DISPLAY SCREEN IS NOT" ,"AVAILALE ","DISPLAY ","SCREEN ","IS NOT"     ,"AVAILALE ","PLC NO CONNECTION"         ,"PLC ","NO ","CONNECTION",""},
#ifdef	KOREA	
				{"���� ȭ���� �����ϴ�. ",""         ,"���� "   ,"ȭ���� ","�����ϴ� "  ,""         ,"PLC�� ������� �ʾҽ��ϴ� ",""    ,""   ,""          ,""}
#elif	JAPAN	
				{"�\����ʂ�����܂��� "  ,""         ,"�\�� "    ,"��ʂ� ","����܂��� ",""         ,"PLC���ڑ�����Ă��܂��� "  ,""    ,""   ,""          ,""}
#elif	CHINA	
				{"DISPLAY SCREEN IS NOT" ,"AVAILALE ","DISPLAY ","SCREEN ","IS NOT"     ,"AVAILALE ","PLC NO CONNECTION"         ,"PLC ","NO ","CONNECTION",""}
#elif	TAIWAN	
				{"DISPLAY SCREEN IS NOT" ,"AVAILALE ","DISPLAY ","SCREEN ","IS NOT"     ,"AVAILALE ","PLC NO CONNECTION"         ,"PLC ","NO ","CONNECTION",""}
#elif	ENGLISH	
				{"DISPLAY SCREEN IS NOT" ,"AVAILALE ","DISPLAY ","SCREEN ","IS NOT"     ,"AVAILALE ","PLC NO CONNECTION"         ,"PLC ","NO ","CONNECTION",""}
#endif
		},
	},

/*****************************************************************************************************************/

	{	/* 7 */						/* 4		7 OTHER MODEȭ��		*/
		{"[MEMORY SIZE]",
#ifdef	KOREA	
				"[��� �޸� Ȯ��]"
#elif	JAPAN
				"[�������T�C�Y]"
#elif	CHINA
				"[MEMORY SIZE]"
#elif	TAIWAN
				"[MEMORY SIZE]"
#elif	ENGLISH	
				"[MEMORY SIZE]"
#endif
		},
#ifdef	SIZE_2480 /* 7 */
		{
				{"TOTAL MEMORY :","USER AREA    :","AVAILABLE    :","","","","","","","",""},
#ifdef	KOREA	
				{"��ü �޸� :" ,"��� �޸� :" ,"���� �޸� :" ,"","","","","","","",""}
#elif	JAPAN	
				{"�S������ :    ","���[�U   :    " ,"��e��   :    ","","","","","","","",""}
#elif	CHINA	
				{"TOTAL MEMORY :","USER AREA    :","AVAILABLE    :","","","","","","","",""}
#elif	TAIWAN	
				{"TOTAL MEMORY :","USER AREA    :","AVAILABLE    :","","","","","","","",""}
#elif	ENGLISH	
				{"TOTAL MEMORY :","USER AREA    :","AVAILABLE    :","","","","","","","",""}
#endif
		},
#endif
#ifdef	GP_S057 /* 7 */
		{
				{"Exit" ,"[MEMORY SIZE]"     ,"Menu" ,"TOTAL MEMORY :","USER AREA    :","AVAILABLE    :","","","","","","","",""},
#ifdef	KOREA	
				{"���� ","[��� �޸� Ȯ��]","�޴� ","��ü �޸�  :","��� �޸�  :","���� �޸� :" ,"","","","","","","",""}
#elif	JAPAN	
				{"�I�� ","[�������T�C�Y]"    ,"�O�� ","�S������     :","���[�U       :" ,"��e��       :","","","","","","","",""}
#elif	CHINA	
				{"Exit" ,"[MEMORY SIZE]"     ,"Menu" ,"TOTAL MEMORY :","USER AREA    :","AVAILABLE    :","","","","","","","",""}
#elif	TAIWAN	
				{"Exit" ,"[MEMORY SIZE]"     ,"Menu" ,"TOTAL MEMORY :","USER AREA    :","AVAILABLE    :","","","","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[MEMORY SIZE]"     ,"Menu" ,"TOTAL MEMORY :","USER AREA    :","AVAILABLE    :","","","","","","","",""}
#endif
		},
#endif
	},

/*****************************************************************************************************************/
		
	{	/* 8 */			/* 4-1-1~8 8 SET TIME SWITCHȭ�� */
		{"[SET FUNCTION]",
#ifdef	KOREA	
				"[��� ����]"
#elif	JAPAN
				"[FUNCTION �ݒ�]"
#elif	CHINA
				"[SET FUNCTION]"
#elif	TAIWAN
				"[SET FUNCTION]"
#elif	ENGLISH	
				"[SET FUNCTION]"
#endif
		},
		{
				{"DATA TRANSFER","TIME SWITCH" ,"PRINT OUT"	  ,"","SET"      ,"NUMBER"	 ,"IS"       ,"INCORRECT","","SET NUMBER IS INCORRECT.",""},
#ifdef	KOREA	
				{"������ ���� "	,"�ð� ����ġ ","������ ��� ","","�Է��� "  ,"��ġ�� "	 ,"Ʋ���ϴ� ",""         ,"","�Է��� ��ġ�� Ʋ���ϴ� " ,""}
#elif	JAPAN	
				{"�f�[�^�]�� "     ,"TIME�X�C�b�`" ,"�v�����g "   ,"","�ݒ�l�� ","�Ⴂ�܂� ",""         ,""         ,"","�ݒ�l���Ⴂ�܂� "       ,""}
#elif	CHINA	
				{"DATA TRANSFER","TIME SWITCH"	,"PRINT OUT"  ,"","SET "	 ,"NUMBER "  ,"IS "      ,"INCORRECT","","SET NUMBER IS INCORRECT.",""}
#elif	TAIWAN	
				{"DATA TRANSFER","TIME SWITCH"	,"PRINT OUT"  ,"","SET "	 ,"NUMBER "  ,"IS "      ,"INCORRECT","","SET NUMBER IS INCORRECT.",""}
#elif	ENGLISH	
				{"DATA TRANSFER","TIME SWITCH"	,"PRINT OUT"  ,"","SET "	 ,"NUMBER "  ,"IS "      ,"INCORRECT","","SET NUMBER IS INCORRECT.",""}
#endif
		},
	},

/*****************************************************************************************************************/
		
	{	/* 9 */							/* 4-2	9 DATA TRANSFERȭ�� */
		{"[TIME SWITCH]",
#ifdef	KOREA	
				"[�ð� ����ġ]"
#elif	JAPAN
				"[TIME�X�C�b�`]"
#elif	CHINA
				"[TIME SWITCH]"
#elif	TAIWAN
				"[TIME SWITCH]"
#elif	ENGLISH	
				"[TIME SWITCH]"
#endif
		},
#ifdef	SIZE_2480 /* 9 */
		{
				{"SUN","MON","TUE","WED","THU","FRI","SAT","ACT START TIME"	,"ACT END TIME"   ,"SET"  ,""},
#ifdef	KOREA	
				{"�� ","�� ","ȭ ","�� ","�� ","�� ","�� ","���� ���� �ð� ","���� ���� �ð� ","���� ",""}
#elif	JAPAN	
				{"�� ","�� ","�� ","�� ","�� ","�� ","�y ","�X�^�[�g���� "    ,"�I������ "      ,"�ݒ� ",""}
#elif	CHINA	
				{"SUN","MON","TUE","WED","THU","FRI","SAT","ACT START TIME"	,"ACT END TIME"   ,"SET"  ,""},
#elif	TAIWAN	
				{"SUN","MON","TUE","WED","THU","FRI","SAT","ACT START TIME"	,"ACT END TIME"   ,"SET"  ,""},
#elif	ENGLISH	
				{"SUN","MON","TUE","WED","THU","FRI","SAT","ACT START TIME"	,"ACT END TIME"   ,"SET"  ,""},
#endif
		},
#endif
#ifdef	GP_S057 /* 9 */
		{
				{"Exit" ,"[TIME SWITCH]","Menu" ,"  WEEK  " ,"SUN" ,"MON" ,"TUE" ,"WED" ,"THU" ,"FRI" ,"SAT" ,"  ACTION"     ,"START TIME" ,"","END TIME" ,""},
#ifdef	KOREA	
				{"���� ","[�ð� ����ġ]","�޴� ","�������� "," �� "," �� "," ȭ "," �� "," �� "," �� "," �� ","���۽ð����� ","START TIME ","","END TIME ",""}
#elif	JAPAN
				{"�I�� ","[TIME�X�C�b�`]","�O�� ","  �T     "," �� "," �� "," �� "," �� "," �� "," �� "," �y ","  ACTION"     ,"START TIME" ,"","END TIME" ,""},
#elif	CHINA	
				{"Exit" ,"[TIME SWITCH]","Menu" ,"  WEEK  " ,"SUN" ,"MON" ,"TUE" ,"WED" ,"THU" ,"FRI" ,"SAT" ,"  ACTION"     ,"START TIME" ,"","END TIME" ,""},
#elif	TAIWAN
				{"Exit" ,"[TIME SWITCH]","Menu" ,"  WEEK  " ,"SUN" ,"MON" ,"TUE" ,"WED" ,"THU" ,"FRI" ,"SAT" ,"  ACTION"     ,"START TIME" ,"","END TIME" ,""},
#elif	ENGLISH	
				{"Exit" ,"[TIME SWITCH]","Menu" ,"  WEEK  " ,"SUN" ,"MON" ,"TUE" ,"WED" ,"THU" ,"FRI" ,"SAT" ,"  ACTION"     ,"START TIME" ,"","END TIME" ,""},
#endif
		},
#endif
	},

/*****************************************************************************************************************/

	{	/* 10 */						/* 4-3	10 PRINT OUTȭ��			*/
		{"[DATA TRANSFER]",
#ifdef	KOREA	
				"[������ ����]"
#elif	JAPAN
				"[�f�[�^�]��]"
#elif	CHINA
				"[DATA TRANSFER]"
#elif	TAIWAN
				"[DATA TRANSFER]"
#elif	ENGLISH	
				"[DATA TRANSFER]"
#endif
		},
#ifdef	SIZE_2480 /* 10 */
		{
				{"TRANSFER STATE","WAITING...","DOWNLOADING...","UPLOADING...","NO PRINT MODE"          ,"","GP" ,"PC","","",""},
#ifdef	KOREA	
				{"���� ���� "    ,"�� �� �� " ,"�ٿ�ε��� "   ,"���ε��� "   ,"�����͸�尡 �ƴմϴ�. ","","GP" ,"PC","","",""}
#elif	JAPAN	
				{"�]�����[�h "     ,"�҂���� " ,"�_�E�����[�h "   ,"�A�b�v���[�h ","NO PRINT MODE"          ,"","GLP","PC","","",""}
#elif	CHINA	
				{"TRANSFER STATE","WAITING...","DOWNLOADING...","UPLOADING...","NO PRINT MODE"          ,"","GP" ,"PC","","",""}
#elif	TAIWAN	
				{"TRANSFER STATE","WAITING...","DOWNLOADING...","UPLOADING...","NO PRINT MODE"          ,"","GP" ,"PC","","",""}
#elif	ENGLISH	
				{"TRANSFER STATE","WAITING...","DOWNLOADING...","UPLOADING...","NO PRINT MODE"          ,"","GP" ,"PC","","",""}
#endif
		},
#endif
#ifdef	GP_S057 /* 10 */
		{
				{"Exit" ,"[DATA TRANSFER]","Menu" ,"TRANSFER STATE","GP","PC","WAITING...","DOWNLOADING...","UPLOADING...","NO PRINT MODE"          ,"","",""},
#ifdef	KOREA	
				{"���� ","[������ ����]"  ,"�޴� "," ���� ���� "   ,"GP","PC"," �� �� �� "," �ٿ�ε��� "  ," ���ε��� "  ,"�����͸�尡 �ƴմϴ�. ","","",""}
#elif	JAPAN	
				{"�I�� ","[�f�[�^�]��]"      ,"�O�� ","�]�����[�h "     ,"GP","PC"," �҂���� ","�_�E�����[�h "   ,"�A�b�v���[�h ","���[�h���Ⴂ�܂� "       ,"","",""}
#elif	CHINA	
				{"Exit" ,"[DATA TRANSFER]","Menu" ,"TRANSFER STATE","GP","PC","WAITING...","DOWNLOADING...","UPLOADING...","NO PRINT MODE"          ,"","",""}
#elif	TAIWAN	
				{"Exit" ,"[DATA TRANSFER]","Menu" ,"TRANSFER STATE","GP","PC","WAITING...","DOWNLOADING...","UPLOADING...","NO PRINT MODE"          ,"","",""}
#elif	ENGLISH	
				{"Exit" ,"[DATA TRANSFER]","Menu" ,"TRANSFER STATE","GP","PC","WAITING...","DOWNLOADING...","UPLOADING...","NO PRINT MODE"          ,"","",""}
#endif
		},
#endif
	},

/*****************************************************************************************************************/

	{	/* 11 */						/* 4-5	11 SET-UP MODEȭ�� */
		{"[PRINT OUT]",
#ifdef	KOREA	
				"[������ ���]"
#elif	JAPAN
				"[�v�����g]"
#elif	CHINA
				"[PRINT OUT]"
#elif	TAIWAN
				"[PRINT OUT]"
#elif	ENGLISH	
				"[PRINT OUT]"
#endif
		},
#ifdef	SIZE_2480 /* 11 */
		{
				{"ALARM HISTORY" ,"PRINT?"             ,"YES"   ,"NO"      ,"","","","","","",""},
#ifdef	KOREA	
				{"�˶� �����丮 ","��� �Ͻðڽ��ϱ�? "," �� "  ," �ƴϿ� ","","","","","","",""}
#elif	JAPAN	
				{"�A���[������ "   ,"�v�����g�H "        ," �͂� "," ������ ","","","","","","",""}	
#elif	CHINA	
				{"ALARM HISTORY" ,"PRINT?"             ,"YES"   ,"NO"      ,"","","","","","",""}
#elif	TAIWAN	
				{"ALARM HISTORY" ,"PRINT?"             ,"YES"   ,"NO"      ,"","","","","","",""}
#elif	ENGLISH	
				{"ALARM HISTORY" ,"PRINT?"             ,"YES"   ,"NO"      ,"","","","","","",""}
#endif
		},
#endif
#ifdef	GP_S057 /* 11 */
		{
				{"Exit" ,"[PRINT OUT]"  ,"Menu" ,"ALARM HISTORY" ,"PRINT?"             ,"YES"   ,"NO"      ,"" ,"" ,"" ,"" ,"" ,"" ,""},
#ifdef	KOREA	
				{"���� ","[������ ���]","�޴� ","�˶� �����丮 ","��� �Ͻðڽ��ϱ�? "," �� "  ," �ƴϿ� ","" ,"" ,"" ,"" ,"" ,"" ,""}
#elif	JAPAN	
				{"�I�� ","[�v�����g]"   ,"�O�� ","�A���[������ "   ,"�v�����g�H "        ," �͂� "," ������ ","" ,"" ,"" ,"" ,"" ,"" ,""}
#elif	CHINA	
				{"Exit" ,"[PRINT OUT]"  ,"Menu" ,"ALARM HISTORY" ,"PRINT?"             ,"YES"   ,"NO"      ,"" ,"" ,"" ,"" ,"" ,"" ,""}
#elif	TAIWAN	
				{"Exit" ,"[PRINT OUT]"  ,"Menu" ,"ALARM HISTORY" ,"PRINT?"             ,"YES"   ,"NO"      ,"" ,"" ,"" ,"" ,"" ,"" ,""}
#elif	ENGLISH	
				{"Exit" ,"[PRINT OUT]"  ,"Menu" ,"ALARM HISTORY" ,"PRINT?"             ,"YES"   ,"NO"      ,"" ,"" ,"" ,"" ,"" ,"" ,""}
#endif
		},
#endif
	},

/*****************************************************************************************************************/

	{	/* 12 */				/* 4-5-1	12 LANGUAGEȭ�� */
		{"[SET ENVIRONMENT]",
#ifdef	KOREA	
				"[ȯ�� ����]"
#elif	JAPAN	
				"[���ݒ�]"
#elif	CHINA
				"[SET ENVIRONMENT]"
#elif	TAIWAN
				"[SET ENVIRONMENT]"
#elif	ENGLISH	
				"[SET ENVIRONMENT]"
#endif
		},
#ifdef	LP_S044 /* 12 */
		{
				{"LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"CLEAR USER DATA"    ,"MENU CALL KEY"   ,"BUZZER" ,"OPENING"          ,"BACKLIGHT"    ,"BATTERY"  ,"CONTRAST"  },
#ifdef	KOREA	
				{"��� ���� ","PLC ���� "  ,"���� �ð� ","����� ������ ���� ","�޴� ȣ��Ű "    ,"������ ","����� ȭ�� ��ȯ ","�����Ʈ "    ,"���͸� "  ,"ȭ�� ��� "}
#elif	JAPAN	
				{"���� "     ,"PLC �ݒ� "  ,"���v�ݒ� " ,"�f�[�^�폜 "          ,"���j���[�Ăяo�� ","�u�U�[ " ,"�N���{�^�� "        ,"�o�b�N���C�g ","�o�b�e�� ","LCD�P�x "  }
#elif	CHINA	
				{"LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"CLEAR USER DATA"    ,"MENU CALL KEY"   ,"BUZZER" ,"OPENING"          ,"BACKLIGHT"    ,"BATTERY"  ,"CONTRAST"  }
#elif	TAIWAN	
				{"LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"CLEAR USER DATA"    ,"MENU CALL KEY"   ,"BUZZER" ,"OPENING"          ,"BACKLIGHT"    ,"BATTERY"  ,"CONTRAST"  }
#elif	ENGLISH	
				{"LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"CLEAR USER DATA"    ,"MENU CALL KEY"   ,"BUZZER" ,"OPENING"          ,"BACKLIGHT"    ,"BATTERY"  ,"CONTRAST"  }
#endif
		},
#endif
#ifdef	GP_S044 /* 12 */
		{
				{"LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"CLEAR USER DATA"    ,"MENU CALL KEY"   ,"BUZZER" ,"OPENING"          ,"BACKLIGHT"    ,"BATTERY"  ,"CONTRAST"  ,"LATCH DEVICE"},
#ifdef	KOREA	
				{"��� ���� ","PLC ���� "  ,"���� �ð� ","����� ������ ���� ","�޴� ȣ��Ű "    ,"������ ","����� ȭ�� ��ȯ ","�����Ʈ "    ,"���͸� "  ,"ȭ�� ��� ","LATCH DEVICE"}
#elif	JAPAN	
				{"���� "     ,"PLC �ݒ� "  ,"���v�ݒ� " ,"�f�[�^�폜 "          ,"���j���[�Ăяo�� ","�u�U�[ " ,"�N���{�^�� "        ,"�o�b�N���C�g ","�o�b�e�� ","LCD�P�x "  ,"LATCH DEVICE"}
#elif	CHINA	
				{"LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"CLEAR USER DATA"    ,"MENU CALL KEY"   ,"BUZZER" ,"OPENING"          ,"BACKLIGHT"    ,"BATTERY"  ,"CONTRAST"  ,"LATCH DEVICE"}
#elif	TAIWAN	
				{"LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"CLEAR USER DATA"    ,"MENU CALL KEY"   ,"BUZZER" ,"OPENING"          ,"BACKLIGHT"    ,"BATTERY"  ,"CONTRAST"  ,"LATCH DEVICE"}
#elif	ENGLISH	
				{"LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"CLEAR USER DATA"    ,"MENU CALL KEY"   ,"BUZZER" ,"OPENING"          ,"BACKLIGHT"    ,"BATTERY"  ,"CONTRAST"  ,"LATCH DEVICE"}
#endif
		},
#endif
#ifdef	GP_S057 /* 12 */
		{
				{"Exit" ,"[SET ENVIRONMENT]","LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"MENU CALL KEY"   ,"Menu" ,"BUZZER" ,"OPENING"          ,"BACKLIGHT"    ,"BATTERY"  ,"CONTRAST"  ,"CLEAR USER DATA"    ,"LATCH DEVICE","14","15"},
#ifdef	KOREA	
				{"���� ","[ȯ�� ����]"      ,"��� ���� ","PLC ���� "  ,"���� �ð� ","�޴� ȣ��Ű "    ,"�޴� ","������ ","����� ȭ�� ��ȯ ","�����Ʈ "    ,"���͸� "  ,"ȭ�� ��� ","����� ������ ���� ","LATCH DEVICE","14","15"}
#elif	JAPAN	
				{"�I�� ","[���ݒ�]"       ,"���� "     ,"PLC �ݒ� "  ,"���v�ݒ� " ,"���j���[�Ăяo�� ","�O�� ","�u�U�[ " ,"�N���{�^�� "        ,"�o�b�N���C�g ","�o�b�e�� ","LCD�P�x "  ,"�f�[�^�폜 "          ,"LATCH DEVICE","14","15"}
#elif	CHINA	
				{"Exit" ,"[SET ENVIRONMENT]","LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"MENU CALL KEY"   ,"Menu" ,"BUZZER" ,"OPENING"          ,"BACKLIGHT"    ,"BATTERY"  ,"CONTRAST"  ,"CLEAR USER DATA"    ,"LATCH DEVICE","14","15"}
#elif	TAIWAN	
				{"Exit" ,"[SET ENVIRONMENT]","LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"MENU CALL KEY"   ,"Menu" ,"BUZZER" ,"OPENING"          ,"BACKLIGHT"    ,"BATTERY"  ,"CONTRAST"  ,"CLEAR USER DATA"    ,"LATCH DEVICE","14","15"}
#elif	ENGLISH	
				{"Exit" ,"[SET ENVIRONMENT]","LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"MENU CALL KEY"   ,"Menu" ,"BUZZER" ,"OPENING"          ,"BACKLIGHT"    ,"BATTERY"  ,"CONTRAST"  ,"CLEAR USER DATA"    ,"LATCH DEVICE","14","15"}
#endif
		},
#endif
	},

/*****************************************************************************************************************/

	{	/* 13 */							/* 4-5-2 13 PLC TYPEȭ�� */
		{"[CLOCK]",
#ifdef	KOREA	
				"[���� �ð�]"
#elif	JAPAN
				"[���v�ݒ�]"
#elif	CHINA
				"[CLOCK]"
#elif	TAIWAN
				"[CLOCK]"
#elif	ENGLISH	
				"[CLOCK]"
#endif
		},
		{
				{"","","","","","","","","","",""},
#ifdef	KOREA	
				{"","","","","","","","","","",""}
#elif	JAPAN	
				{"","","","","","","","","","",""},				
#elif	CHINA	
				{"","","","","","","","","","",""},				
#elif	TAIWAN	
				{"","","","","","","","","","",""},				
#elif	ENGLISH	
				{"","","","","","","","","","",""}
#endif
		},
	},

/*****************************************************************************************************************/

	{	/* 14 */							/* 4-5-3 14 SERIAL PORTȭ�� */
		{"[LANGUAGE]",
#ifdef	KOREA	
				"[��� ����]"
#elif	JAPAN
				"[����]"
#elif	CHINA
				"[LANGUAGE]"
#elif	TAIWAN
				"[LANGUAGE]"
#elif	ENGLISH	
				"[LANGUAGE]"
#endif
		},
#ifdef	SIZE_2480 /* 14 */
		{
#ifdef	KOREA
				{"LANG ","ASCII " ,"SYSTEM LANG" ,"KOREAN"   ,"ENGLISH","GULIM","DODUM","","","",""}, /* "DON'T USE","USE" */
				{"��� ","�ƽ�Ű ","�ý��� ��� ","�ѱ��� "  ,"ENGLISH","GULIM","DODUM","","","",""}
#elif	JAPAN
				{"LANG ","ASCII " ,"SYSTEM LANG" ,"JAPANESE" ,"ENGLISH","DODUM","DODUM","","","",""}, /* "DON'T USE","USE" */
				{"���� ","�A�X�L�[","�V�X�e������" ,"���{�� "   ,"ENGLISH","DODUM","DODUM","","","",""}
#elif	CHINA	
				{"LANG ","ASCII " ,"SYSTEM LANG" ,"CHINESE"  ,"ENGLISH","DODUM","DODUM","","","",""}, /* "DON'T USE","USE" */
				{"LANG ","ASCII " ,"SYSTEM LANG" ,"CHINESE"  ,"ENGLISH","DODUM","DODUM","","","",""} /* "DON'T USE","USE" */
#elif	TAIWAN	
				{"LANG ","ASCII " ,"SYSTEM LANG" ,"TAIWANESE","ENGLISH","DODUM","DODUM","","","",""}, /* "DON'T USE","USE" */
				{"LANG ","ASCII " ,"SYSTEM LANG" ,"TAIWANESE","ENGLISH","DODUM","DODUM","","","",""} /* "DON'T USE","USE" */
#elif	ENGLISH	
				{"LANG ","ASCII " ,"SYSTEM LANG" ,"ENGLISH"  ,"ENGLISH","DODUM","DODUM","","","",""}, /* "DON'T USE","USE" */
				{"LANG ","ASCII " ,"SYSTEM LANG" ,"ENGLISH"  ,"ENGLISH","DODUM","DODUM","","","",""} /* "DON'T USE","USE" */
#endif
		},
#endif
#ifdef	GP_S057 /* 14 */
		{
#ifdef	KOREA	
				{"Exit" ,"[LANGUAGE]" ,"Menu" ,"LANG ","FONT","LANGUAGE","KOREAN"    ,"ASCII " ,"FONT","","","ENGLISH","KOREAN"    ,"GULIM","DODUM"},
				{"���� ","[��� ����]","�޴� ","��� ","FONT","LANGUAGE","�ѱ��� "   ,"�ƽ�Ű ","FONT","","","ENGLISH","�ѱ��� "   ,"GULIM","DODUM"}
#elif	JAPAN	
				{"Exit" ,"[LANGUAGE]" ,"Menu" ,"LANG ","FONT","LANGUAGE","JAPANESE"  ,"ASCII " ,"FONT","","","ENGLISH","JAPANESE"  ,"DODUM","DODUM"},
				{"�I�� ","[����]"     ,"�O�� ","���� ","FONT","LANGUAGE","���{�� "    ,"ENGLISH","FONT","","","ENGLISH","���{�� "    ,"DODUM","DODUM"}
#elif	CHINA	
				{"Exit" ,"[LANGUAGE]" ,"Menu" ,"LANG ","FONT","LANGUAGE","CHINESE"   ,"ASCII " ,"FONT","","" ,"ENGLISH","CHINESE"  ,"DODUM","DODUM"},
				{"Exit" ,"[LANGUAGE]" ,"Menu" ,"LANG ","FONT","LANGUAGE","CHINESE"   ,"ASCII " ,"FONT","","" ,"ENGLISH","CHINESE"  ,"DODUM","DODUM"}
#elif	TAIWAN	
				{"Exit" ,"[LANGUAGE]" ,"Menu" ,"LANG ","FONT","LANGUAGE","TAIWANESE" ,"ASCII " ,"FONT","","" ,"ENGLISH","TAIWANESE","DODUM","DODUM"},
				{"Exit" ,"[LANGUAGE]" ,"Menu" ,"LANG ","FONT","LANGUAGE","TAIWANESE" ,"ASCII " ,"FONT","","" ,"ENGLISH","TAIWANESE","DODUM","DODUM"}
#elif	ENGLISH	
				{"Exit" ,"[LANGUAGE]" ,"Menu" ,"LANG ","FONT","LANGUAGE","ENGLISH"   ,"ASCII " ,"FONT","","" ,"ENGLISH","ENGLISH"  ,"DODUM","DODUM"},
				{"Exit" ,"[LANGUAGE]" ,"Menu" ,"LANG ","FONT","LANGUAGE","ENGLISH"   ,"ASCII " ,"FONT","","" ,"ENGLISH","ENGLISH"  ,"DODUM","DODUM"}
#endif
		},
#endif
	}, 

/*****************************************************************************************************************/

	{	/* 15 */				/* 4-5-4 15 OPENING SCREENȭ�� */
		{"[BACKLIGHT]",
#ifdef	KOREA	
				"[�����Ʈ]"
#elif	JAPAN
				"[�o�b�N���C�g]"
#elif	CHINA
				"[BACKLIGHT]"
#elif	TAIWAN
				"[BACKLIGHT]"
#elif	ENGLISH	
				"[BACKLIGHT]"
#endif
		},
		{
				{"BACKLIGHT OFF" ,"MIN","","","","","","","","",""},
#ifdef	KOREA	
				{"�����Ʈ �ҵ� ","�� ","","","","","","","","",""}
#elif	JAPAN	
				{"BACKLIGHT OFF" ,"MIN","","","","","","","","",""}
#elif	CHINA	
				{"BACKLIGHT OFF" ,"MIN","","","","","","","","",""}
#elif	TAIWAN	
				{"BACKLIGHT OFF" ,"MIN","","","","","","","","",""}
#elif	ENGLISH	
				{"BACKLIGHT OFF" ,"MIN","","","","","","","","",""}
#endif
		},
	},

/*****************************************************************************************************************/

	{	/* 16 */			/* 4-5-5 16 BATTERY SIZE ȭ�� */
		{"[BATTERY SIZE]",
#ifdef	KOREA	
				"[���͸�]"
#elif	JAPAN
				"[�o�b�e��]"
#elif	CHINA
				"[BATTERY SIZE]"
#elif	TAIWAN
				"[BATTERY SIZE]"
#elif	ENGLISH	
				"[BATTERY SIZE]"
#endif
		},
#ifdef	SIZE_2480 /* 16 */
		{
				{"","","","","","","","","","","PASSWORD IS INCORRECT"  },
#ifdef	KOREA	
				{"","","","","","","","","","","�н����尡 Ʋ�Ƚ��ϴ�. "}
#elif	JAPAN	
				{"","","","","","","","","","","�p�X���[�h���Ⴂ�܂� "   }
#elif	CHINA	
				{"","","","","","","","","","","PASSWORD IS INCORRECT"  }
#elif	TAIWAN	
				{"","","","","","","","","","","PASSWORD IS INCORRECT"  }	
#elif	ENGLISH	
				{"","","","","","","","","","","PASSWORD IS INCORRECT"  }
#endif
		},
#endif
#ifdef	GP_S057 /* 16 */
		{
				{"Exit" ,"[BATTERY SIZE]","Menu" ,"0","100","BATTERY :","","","","","PASSWORD IS INCORRECT" },
#ifdef	KOREA	
				{"���� ","[���͸�]"      ,"�޴� ","0","100","BATTERY :","","","","","�н����尡 Ʋ�Ƚ��ϴ�."}
#elif	JAPAN	
				{"�I�� ","[�o�b�e��]"    ,"�O�� ","0","100","BATTERY :","","","","","�p�X���[�h���Ⴂ�܂� "  }
#elif	CHINA	
				{"Exit" ,"[BATTERY SIZE]","Menu" ,"0","100","BATTERY :","","","","","PASSWORD IS INCORRECT" }
#elif	TAIWAN	
				{"Exit" ,"[BATTERY SIZE]","Menu" ,"0","100","BATTERY :","","","","","PASSWORD IS INCORRECT" }
#elif	ENGLISH	
				{"Exit" ,"[BATTERY SIZE]","Menu" ,"0","100","BATTERY :","","","","","PASSWORD IS INCORRECT" }
#endif
		},
#endif	
	},

/*****************************************************************************************************************/

	{	/* 17 */						/* 4-5-8 17 BUZZERȭ�� */
		{"[BUZZER]",
#ifdef	KOREA	
				"[������]"
#elif	JAPAN
				"[�u�U�[]"
#elif	CHINA
				"[BUZZER]"
#elif	TAIWAN
				"[BUZZER]"
#elif	ENGLISH	
				"[BUZZER]"
#endif
		},
#ifdef	SIZE_2480 /* 17 */
		{
				{"BUZZER ON"   ,"BUZZER OFF"  ,"OFF "     ,"ON "    ,"","","","","","",""},
#ifdef	KOREA	
				{"������ ���� ","������ ���� ","������ ","������ ","","","","","","",""}
#elif	JAPAN
				{"�u�U�[ ON"    ,"�u�U�[ OFF"   ,"�񓮍쒆 ","���쒆 ","","","","","","",""}
#elif	CHINA	
				{"BUZZER ON"   ,"BUZZER OFF"  ,"OFF "     ,"ON "    ,"","","","","","",""}
#elif	TAIWAN	
				{"BUZZER ON"   ,"BUZZER OFF"  ,"OFF "     ,"ON "    ,"","","","","","",""}
#elif	ENGLISH	
				{"BUZZER ON"   ,"BUZZER OFF"  ,"OFF "     ,"ON "    ,"","","","","","",""}
#endif
		},
#endif
#ifdef	GP_S057 /* 17 */
		{
				{"Exit" ,"[BUZZER]","Menu" ,"BUZZER SETTING","BUZZER ON"   ,"BUZZER OFF"  ,"OFF","ON","","","","",""},
#ifdef	KOREA	
				{"���� ","[������]","�޴� ","BUZZER SETTING","������ ���� ","������ ���� ","OFF","ON","","","","",""}
#elif	JAPAN
				{"�I�� ","[�u�U�[]" ,"�O�� ","BUZZER SETTING","�u�U�[ ON"    ,"�u�U�[ OFF"   ,"OFF","ON","","","","",""}
#elif	CHINA	
				{"Exit" ,"[BUZZER]","Menu" ,"BUZZER SETTING","BUZZER ON"   ,"BUZZER OFF"  ,"OFF","ON","","","","",""}
#elif	TAIWAN	
				{"Exit" ,"[BUZZER]","Menu" ,"BUZZER SETTING","BUZZER ON"   ,"BUZZER OFF"  ,"OFF","ON","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[BUZZER]","Menu" ,"BUZZER SETTING","BUZZER ON"   ,"BUZZER OFF"  ,"OFF","ON","","","","",""}
#endif
		},
#endif
	},

/*****************************************************************************************************************/

	{	/* 18 */				/* 4-5-7 18 SET BACKLIGHTȭ�� */
		{"[OPENING TIME]",
#ifdef	KOREA	
				"[����� ȭ�� ��ȯ]"
#elif	JAPAN
				"[�X�^�[�g����]"
#elif	CHINA
				"[OPENING TIME]"
#elif	TAIWAN
				"[OPENING TIME]"
#elif	ENGLISH	
				"[OPENING TIME]"
#endif
		},
		{
				{"OPENING TIME","SEC","","","","","","","","",""},
#ifdef	KOREA	
				{"ȭ�� ��ȯ "  ,"�� ","","","","","","","","",""}
#elif	JAPAN	
				{"�X�^�[�g���� " ,"�b ","","","","","","","","",""}
#elif	CHINA	
				{"OPENING TIME","SEC","","","","","","","","",""}
#elif	TAIWAN	
				{"OPENING TIME","SEC","","","","","","","","",""}
#elif	ENGLISH	
				{"OPENING TIME","SEC","","","","","","","","",""}
#endif
		},
	},

/*****************************************************************************************************************/

	{	/* 19 */   /* ksc20070306 */								/* 4-5-8 19 BUZZERȭ�� */
		{"[PLC SETTING]",
#ifdef	KOREA	
				"[PLC ����]"
#elif	JAPAN
				"[PLC �ݒ�]"
#elif	CHINA
				"[PLC SETTING]"
#elif	TAIWAN
				"[PLC SETTING]"
#elif	ENGLISH	
				"[PLC SETTING]"
#endif
		},
#ifdef	LP_S044 /* 19 */ 
		{
				{"PLC1","PLC2","LP ST.#" ,"CH1 ST.#" ,"NO USE" ,"A PORT","B PORT","","","",""},
#ifdef	KOREA	
				{"PLC1","PLC2","LP ���� ","CH1 ���� ","NO USE" ,"A PORT","B PORT","","","",""}
#elif	JAPAN	
				{"PLC1","PLC2","LP �ǔ� ","CH1 �ǔ� ","���g�p ","A PORT","B PORT","","","",""}
#elif	CHINA	
				{"PLC1","PLC2","LP ST.#" ,"CH1 ST.#" ,"NO USE" ,"A PORT","B PORT","","","",""}
#elif	TAIWAN	
				{"PLC1","PLC2","LP ST.#" ,"CH1 ST.#" ,"NO USE" ,"A PORT","B PORT","","","",""}
#elif	ENGLISH	
				{"PLC1","PLC2","LP ST.#" ,"CH1 ST.#" ,"NO USE" ,"A PORT","B PORT","","","",""}
#endif
		},
#endif
#ifdef	GP_S044 /* 19 */ 
		{
				{"PLC1","PLC2","GP ST.#" ,"CH1 ST.#" ,"NO USE" ,"A PORT","B PORT","","","",""},
#ifdef	KOREA	
				{"PLC1","PLC2","GP ���� ","CH1 ���� ","NO USE" ,"A PORT","B PORT","","","",""}
#elif	JAPAN
				{"PLC1","PLC2","GP �ǔ� ","CH1 �ǔ� ","���g�p ","A PORT","B PORT","","","",""}
#elif	CHINA	
				{"PLC1","PLC2","GP ST.#" ,"CH1 ST.#" ,"NO USE" ,"A PORT","B PORT","","","",""}
#elif	TAIWAN	
				{"PLC1","PLC2","GP ST.#" ,"CH1 ST.#" ,"NO USE" ,"A PORT","B PORT","","","",""}
#elif	ENGLISH	
				{"PLC1","PLC2","GP ST.#" ,"CH1 ST.#" ,"NO USE" ,"A PORT","B PORT","","","",""}
#endif
		},
#endif
#ifdef	GP_S057 /* 19 */ 
		{
				{"PLC1","PLC2","GP ST.#" ,"  CH1 ST.#" ,"NO USE" ,"","","","","",""},
#ifdef	KOREA	
				{"PLC1","PLC2","GP ���� ","  CH1 ���� ","NO USE" ,"","","","","",""}
#elif	JAPAN	
				{"PLC1","PLC2","GP �ǔ� ","  CH1 �ǔ� ","���g�p ","","","","","",""}
#elif	CHINA	
				{"PLC1","PLC2","GP ST.#" ,"  CH1 ST.#" ,"NO USE" ,"","","","","",""}
#elif	TAIWAN	
				{"PLC1","PLC2","GP ST.#" ,"  CH1 ST.#" ,"NO USE" ,"","","","","",""}
#elif	ENGLISH	
				{"PLC1","PLC2","GP ST.#" ,"  CH1 ST.#" ,"NO USE" ,"","","","","",""}
#endif
		},
#endif
	},

/*****************************************************************************************************************/

	{	/* 20 */						/* 4-5-9 20 SERIAL PORT ȭ�� */
		{"[SERIAL PORT]",
#ifdef	KOREA	
				"[�ø��� ��Ʈ]"
#elif	JAPAN
				"[�ʐM�|�[�g]"
#elif	CHINA
				"[SERIAL PORT]"
#elif	TAIWAN
				"[SERIAL PORT]"
#elif	ENGLISH	
				"[SERIAL PORT]"
#endif
		},
		{
				{"CON"  ,"B/R"  ,"DATA"   ,"STOP"     ,"PARITY","F/C "     ,"EDITOR"  ,"PRINTER" ,"BARCODE"  ,"MONITOR","PLC2"},
#ifdef	KOREA	
				{"���� ","�ӵ� ","����Ÿ ","������Ʈ ","�и�Ƽ","�帧���� "," ������ "," ������ "," ���ڵ� " ,"MONITOR","PLC2"}
#elif	JAPAN
				{"�ڑ� ","���x ","�f�[�^"   ,"�X�g�b�v ","PARITY","F/C"      ,"EDITOR"  ,"�v�����^" ,"�o�[�R�[�h ","MONITOR","PLC2"}
#elif	CHINA	
				{"CON"  ,"B/R"  ,"DATA"   ,"STOP"     ,"PARITY","F/C "     ,"EDITOR"  ,"PRINTER" ,"BARCODE"  ,"MONITOR","PLC2"}
#elif	TAIWAN	
				{"CON"  ,"B/R"  ,"DATA"   ,"STOP"     ,"PARITY","F/C "     ,"EDITOR"  ,"PRINTER" ,"BARCODE"  ,"MONITOR","PLC2"}
#elif	ENGLISH	
				{"CON"  ,"B/R"  ,"DATA"   ,"STOP"     ,"PARITY","F/C "     ,"EDITOR"  ,"PRINTER" ,"BARCODE"  ,"MONITOR","PLC2"}
#endif
		},
	},

/*****************************************************************************************************************/

	{	/* 21 */				/* 4-5-10 21 MENU CALL KEY ȭ�� */
		{"[MENU CALL KEY]",
#ifdef	KOREA	
				"[�޴� ȣ��Ű]"
#elif	JAPAN
				"[���j���[�Ăяo��]"
#elif	CHINA
				"[MENU CALL KEY]"
#elif	TAIWAN
				"[MENU CALL KEY]"
#elif	ENGLISH	
				"[MENU CALL KEY]"
#endif
		},
#ifdef	SIZE_2480 /* 21 */
		{
				{"SELECT"    ,"CALL KEY"   ,"","","","","","","","",""},
#ifdef	KOREA	
				{"Ű ��ġ�� ","�����ϼ��� ","","","","","","","","",""}
#elif	JAPAN
				{"�I�� "     ,"CALL KEY"   ,"","","","","","","","",""}
#elif	CHINA	
				{"SELECT"    ,"CALL KEY"   ,"","","","","","","","",""}
#elif	TAIWAN	
				{"SELECT"    ,"CALL KEY"   ,"","","","","","","","",""}
#elif	ENGLISH	
				{"SELECT"    ,"CALL KEY"   ,"","","","","","","","",""}
#endif
		},
#endif

#ifdef	GP_S057 /* 21 */
		{
				{"Exit" ,"[MENU CALL KEY]"  ,"Menu" ,"SELECT CALL KEY"      ,"","","","","","","","","",""},
#ifdef	KOREA	
				{"���� ","[�޴� ȣ��Ű]"    ,"�޴� ","Ű ��ġ�� �����ϼ��� ","","","","","","","","","",""}
#elif	JAPAN	
				{"�I�� ","[���j���[�Ăяo��]","�O�� ","�I�� CALL KEY"        ,"","","","","","","","","",""}
#elif	CHINA	
				{"Exit" ,"[MENU CALL KEY]"  ,"Menu" ,"SELECT CALL KEY"      ,"","","","","","","","","",""}
#elif	TAIWAN	
				{"Exit" ,"[MENU CALL KEY]"  ,"Menu" ,"SELECT CALL KEY"      ,"","","","","","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[MENU CALL KEY]"  ,"Menu" ,"SELECT CALL KEY"      ,"","","","","","","","","",""}
#endif
		},
#endif
	},

/*****************************************************************************************************************/

	{	/* 22 */				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
#ifdef	SIZE_2480	/* 22 */ 
		{"[CLEAR GP DATA]",
#ifdef	KOREA	
				"[GP �ʱ�ȭ]"
#elif	JAPAN
				"[�f�[�^�폜]"
#elif	CHINA
				"[CLEAR GP DATA]"
#elif	TAIWAN
				"[CLEAR GP DATA]"
#elif	ENGLISH	
				"[CLEAR GP DATA]"
#endif
		},
		{
				{"CLEAR GP DATA? "           ,""                             ,"YES"   ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""},
#ifdef	KOREA	
				{"��� ����Ÿ�� �����˴ϴ�. ","�����͸� �ʱ�ȭ�Ͻðڽ��ϱ�? "," �� "  ,"�ƴϿ� " ,"����� ������ ������... ","","","","","",""}
#elif	JAPAN
				{"GP �f�[�^ �폜�H "           ,""                             ," �͂� "," ������ ","�폜��... "              ,"","","","","",""}
#elif	CHINA	
				{"CLEAR GP DATA? "           ,""                             ,"YES"   ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""}
#elif	TAIWAN	
				{"CLEAR GP DATA? "           ,""                             ,"YES"   ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""}
#elif	ENGLISH	
				{"CLEAR GP DATA? "           ,""                             ,"YES"   ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""}
#endif
		},
#endif


#ifdef	GP_S057 /* 22 */ 
		{"[CLEAR USER DATA]",
#ifdef	KOREA	
				"[CLEAR USER DATA]"
#elif	JAPAN
				"[CLEAR USER DATA]"
#elif	CHINA
				"[CLEAR USER DATA]"
#elif	TAIWAN
				"[CLEAR USER DATA]"
#elif	ENGLISH	
				"[CLEAR USER DATA]"
#endif
		},
		{
//				{"USE"  ,"USE"               ,"USE"                       ,"USE"   ,"USE"                          ,"USE"  ,"USE"    ,"","","","","","",""},
				{"Exit" ,"[CLEAR USER DATA]" ,"CLEAR USER DATA? "         ,"Menu"  ,""                             ,"YES"  ,"NO"     ,"","NOW CLEARING....","","","","",""},
#ifdef	KOREA	
				{"���� ","[USER DATA �ʱ�ȭ]","��� ����Ÿ�� �����˴ϴ�. ","�޴� " ,"�����͸� �ʱ�ȭ�Ͻðڽ��ϱ�? ","�� "  ,"�ƴϿ� ","","������.... "     ,"","","","",""}
#elif	JAPAN
				{"�I�� ","[�f�[�^ �폜] "      ,"�f�[�^ �폜�H "              , "�O�� ",""                             ,"�͂� ","������ ","","�폜��.... "     ,"","","","",""}
#elif	CHINA	
				{"Exit" ,"[CLEAR USER DATA]" ,"CLEAR USER DATA? "         ,"Menu"  ,""                             ,"YES"  ,"NO"     ,"","NOW CLEARING....","","","","",""}
#elif	TAIWAN	
				{"Exit" ,"[CLEAR USER DATA]" ,"CLEAR USER DATA? "         ,"Menu"  ,""                             ,"YES"  ,"NO"     ,"","NOW CLEARING....","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[CLEAR USER DATA]" ,"CLEAR USER DATA? "         ,"Menu"  ,""                             ,"YES"  ,"NO"     ,"","NOW CLEARING....","","","","",""}
#endif
		},
#endif
	},

/*****************************************************************************************************************/

	{	/* 23 */			/* 4-5-5 23 CONTRAST ȭ�� *//*			{" �� "," �� "," �� "," �� ","�� ","","","","","",""}, */
		{"[CONTRAST]",
#ifdef	KOREA	
				"[ȭ�� ���]"
#elif	JAPAN
				"[LCD�P�x]"
#elif	CHINA
				"[CONTRAST]"
#elif	TAIWAN
				"[CONTRAST]"
#elif	ENGLISH	
				"[CONTRAST]"
#endif
		},
		{
				{"\xff\x02","\xff\x01","\xff\x03","\xff\x04","\xff\x04","","","","","",""}, 
				{"\xff\x02","\xff\x01","\xff\x03","\xff\x04","\xff\x04","","","","","",""}
		},
	},

/*****************************************************************************************************************/

	{	/* 24 */			/* 24 PLC SETTING */
		{"[CONTRAST]",
#ifdef	KOREA	
				"[ȭ�� ���]"
#elif	JAPAN
				"[LCD�P�x]"
#elif	CHINA
				"[CONTRAST]"
#elif	TAIWAN
				"[CONTRAST]"
#elif	ENGLISH	
				"[CONTRAST]"
#endif
		},
		{
				{" CH1"," CH2","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"},
#ifdef	KOREA	
				{" CH1"," CH2","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"}
#elif	JAPAN
				{" CH1"," CH2","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"}
#elif	CHINA	
				{" CH1"," CH2","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"}
#elif	TAIWAN	
				{" CH1"," CH2","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"}
#elif	ENGLISH	
				{" CH1"," CH2","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"}
#endif
		},
	},

/*****************************************************************************************************************/

	{	/* 25 */						/* 25 RS-232C SETTING */
		{"END",
#ifdef	KOREA	
				"���� "
#elif	JAPAN
				"�I��"
#elif	CHINA
				"END"
#elif	TAIWAN
				"END"
#elif	ENGLISH	
				"END"
#endif
		},
#ifdef	SIZE_2480 /* 25 */
		{
	#ifdef SBD0
				{"UNIVERSAL","MK-200S(CPU)","RS422 ","RS232C"},
				{"UNIVERSAL","MK-200S(CPU)","RS422 ","RS232C"}
	#endif
	#ifdef SBD1
				{"UNIVERSAL","MK-200S(CPU)","RS232C","RS232C"},
				{"UNIVERSAL","MK-200S(CPU)","RS232C","RS232C"}
	#endif
		},
#endif
#ifdef	GP_S057 /* 25 */
		{
	#ifdef SBD0 
				{"UNIVERSAL","MK-200S(CPU)","RS422 ","RS232C","A PORT","B PORT"},
				{"UNIVERSAL","MK-200S(CPU)","RS422 ","RS232C","A PORT","B PORT"}
	#endif
	#ifdef SBD1 
				{"UNIVERSAL","MK-200S(CPU)","RS232C","RS232C","A PORT","B PORT"},
				{"UNIVERSAL","MK-200S(CPU)","RS232C","RS232C","A PORT","B PORT"}
	#endif
		},
#endif
	},

/*****************************************************************************************************************/

	{	/* 26 */						/* 26 NO USER DATA */
		{"[ALARM]",
#ifdef	KOREA	
				"[ALARM]"
#elif	JAPAN
				"[ALARM]"
#elif	CHINA
				"[ALARM]"
#elif	TAIWAN
				"[ALARM]"
#elif	ENGLISH	
				"[ALARM]"
#endif
		},
		{
				{"USER "  ,"SCREEN ","IS NOT "    ,"FOUND","Exit" ,"Menu" },
#ifdef	KOREA	
				{"����� ","ȭ���� ","�����ϴ�. " ,""     ,"���� ","�޴� "}
#elif	JAPAN
				{"���[�U " ,"��ʂ� ","����܂��� ",""     ,"�I�� ","�O�� "},
#elif	CHINA	
				{"USER "  ,"SCREEN ","IS NOT "   ,"FOUND","Exit" ,"Menu" }
#elif	TAIWAN	
				{"USER "  ,"SCREEN ","IS NOT "   ,"FOUND","Exit" ,"Menu" }
#elif	ENGLISH	
				{"USER "  ,"SCREEN ","IS NOT "   ,"FOUND","Exit" ,"Menu" }
#endif
		},
	},

/*****************************************************************************************************************/

	{	/* 27 */	/* 27 MODEL Version */				
		{"[MODEL & VERSION]",
#ifdef	KOREA	
				"[�� �� ���� Ȯ��]"
#elif	JAPAN
				"[���f��&�o�[�W����]"
#elif	CHINA
				"[MODEL & VERSION]"
#elif	TAIWAN
				"[MODEL & VERSION]"
#elif	ENGLISH	
				"[MODEL & VERSION]"
#endif
		},
#ifdef	SIZE_2480 /* 27 */
		{
				{"MODEL NAME  :","F/W VER     :","","","","","","","","",""},
#ifdef	KOREA	
				{"�𵨸�      :","�߿��� ���� :","","","","","","","","",""}
#elif	JAPAN
				{"���f��      :","F/W VER     :","","","","","","","","",""}
#elif	CHINA	
				{"MODEL NAME  :","F/W VER     :","","","","","","","","",""},
#elif	TAIWAN	
				{"MODEL NAME  :","F/W VER     :","","","","","","","","",""},
#elif	ENGLISH	
				{"MODEL NAME  :","F/W VER     :","","","","","","","","",""},
#endif
		},
#endif
#ifdef	GP_S057 /* 27 */
		{
				{"Exit" ,"[MODEL & VERSION]"   ,"Menu" ,"MODEL NAME   :","FIRMWARE VER :","","","","","","","","",""},
#ifdef	KOREA	
				{"���� ","[�� �� ���� Ȯ��]" ,"�޴� ","�𵨸�       :","�߿��� ����  :","","","","","","","","",""},
#elif	JAPAN	
				{"�I�� ","[���f�� & �o�[�W����]","�O�� ","���f��       :","FIRMWARE VER :","","","","","","","","",""}
#elif	CHINA	
				{"Exit" ,"[MODEL & VERSION]"   ,"Menu" ,"MODEL NAME   :","FIRMWARE VER :","","","","","","","","",""}
#elif	TAIWAN	
				{"Exit" ,"[MODEL & VERSION]"   ,"Menu" ,"MODEL NAME   :","FIRMWARE VER :","","","","","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[MODEL & VERSION]"   ,"Menu" ,"MODEL NAME   :","FIRMWARE VER :","","","","","","","","",""}
#endif
		},
#endif
	},

/*****************************************************************************************************************/

#ifdef	SIZE_2480
	{	/* 28 */		/* GLP EXTEN BOARD SELECT	*/
		{"[LP EXT BOARD]",
#ifdef	KOREA	
				"[LP EXT BOARD]"
#elif	JAPAN
				"[LP EXT BOARD]"
#elif	CHINA
				"[LP EXT BOARD]"
#elif	TAIWAN
				"[LP EXT BOARD]"
#elif	ENGLISH	
				"[LP EXT BOARD]"
#endif
		},
		{
				{"Exit" ,"[LP EXT BOARD]","Menu" ,"","","","","","","","","","","",""},
#ifdef	KOREA	
				{"���� ","[LP EXT BOARD]","�޴� ","","","","","","","","","","","",""}
#elif	JAPAN
				{"�I�� ","[LP EXT BOARD]","�O�� ","","","","","","","","","","","",""}
#elif	CHINA
				{"Exit" ,"[LP EXT BOARD]","Menu" ,"","","","","","","","","","","",""}
#elif	TAIWAN
				{"Exit" ,"[LP EXT BOARD]","Menu" ,"","","","","","","","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[LP EXT BOARD]","Menu" ,"","","","","","","","","","","",""}
#endif
		},
	},
#endif

#ifdef	GP_S057
	{	/* 28 */		/* GLP EXTEN BOARD SELECT	*/
		{"[CONTRAST]",
#ifdef	KOREA	
				"[ȭ�� ���]"
#elif	JAPAN
				"[LCD�P�x]"
#elif	CHINA
				"[CONTRAST]"
#elif	TAIWAN
				"[CONTRAST]"
#elif	ENGLISH	
				"[CONTRAST]"
#endif
		},
		{
				{"Exit" ,"[CONTRAST]" ,"Menu" ,"CONTRAST"},
#ifdef	KOREA	
				{"���� ","[ȭ�� ���]","�޴� ","CONTRAST"}
#elif	JAPAN
				{"�I�� ","[LCD�P�x]"  ,"�O�� ","CONTRAST"}
#elif	CHINA
				{"Exit" ,"[CONTRAST]" ,"Menu" ,"CONTRAST"}
#elif	TAIWAN
				{"Exit" ,"[CONTRAST]" ,"Menu" ,"CONTRAST"}
#elif	ENGLISH	
				{"Exit" ,"[CONTRAST]" ,"Menu" ,"CONTRAST"}
#endif
		},
	},
#endif

/*****************************************************************************************************************/

#ifdef	SIZE_2480
	{	/* 29 */			/* EXTERN IO SELECT	*/
		{"[SET PARAMETER]",
#ifdef	KOREA	
				"[�Ķ��Ÿ ����]"
#elif	JAPAN
				"[SET PARAMETER]"
#elif	CHINA
				"[SET PARAMETER]"
#elif	TAIWAN
				"[SET PARAMETER]"
#elif	ENGLISH	
				"[SET PARAMETER]"
#endif
		},
		{
				{"Exit" ,"[SET PARAMETER]","Menu" ,"FILTER","INTERRUPT","4 X 4 KEYPAD"     ,"7 SEGMENT DISPLAY","SYNCHRONOUS SERIAL","PULS","ENCODE","COUNTER","PATARN","","",""},
#ifdef	KOREA	
				{"���� ","[�Ķ��Ÿ ����]","�޴� ","���� " ,"���ͷ�Ʈ ","4 X 4 Ű�е� ����","7 ���׸�Ʈ ���� " ,"���� �ø��� ���� " ,"PULS","ENCODE","COUNTER","PATARN","","",""}
#elif	JAPAN
				{"�I�� ","[SET PARAMETER]","�O�� ","FILTER","INTERRUPT","4 X 4 KEYPAD"     ,"7 SEGMENT DISPLAY","SYNCHRONOUS SERIAL","PULS","ENCODE","COUNTER","PATARN","","",""}
#elif	CHINA
				{"Exit" ,"[SET PARAMETER]","Menu" ,"FILTER","INTERRUPT","4 X 4 KEYPAD"     ,"7 SEGMENT DISPLAY","SYNCHRONOUS SERIAL","PULS","ENCODE","COUNTER","PATARN","","",""}
#elif	TAIWAN
				{"Exit" ,"[SET PARAMETER]","Menu" ,"FILTER","INTERRUPT","4 X 4 KEYPAD"     ,"7 SEGMENT DISPLAY","SYNCHRONOUS SERIAL","PULS","ENCODE","COUNTER","PATARN","","",""}
#elif	ENGLISH	
				{"Exit" ,"[SET PARAMETER]","Menu" ,"FILTER","INTERRUPT","4 X 4 KEYPAD"     ,"7 SEGMENT DISPLAY","SYNCHRONOUS SERIAL","PULS","ENCODE","COUNTER","PATARN","","",""}
#endif
		},
	},
#endif

#ifdef	GP_S057
	{	/* 29 */			/* EXTERN IO SELECT	*/
		{"[COMMENT]",
#ifdef	KOREA	
				"[�ڸ�Ʈ]"
#elif	JAPAN
				"[�R�����g]"
#elif	CHINA
				"[COMMENT]"
#elif	TAIWAN
				"[COMMENT]"
#elif	ENGLISH	
				"[COMMENT]"
#endif
		},
		{
				{"Exit" ,"[COMMENT]","Menu" ,"","","","","","","","","","","",""},
#ifdef	KOREA	
				{"���� ","[�ڸ�Ʈ]" ,"�޴� ","","","","","","","","","","","",""},
#elif	JAPAN
				{"�I�� ","[�R�����g]","�O�� ","","","","","","","","","","","",""}
#elif	CHINA
				{"Exit" ,"[COMMENT]","Menu" ,"","","","","","","","","","","",""},
#elif	TAIWAN
				{"Exit" ,"[COMMENT]","Menu" ,"","","","","","","","","","","",""},
#elif	ENGLISH	
				{"Exit" ,"[COMMENT]","Menu" ,"","","","","","","","","","","",""},
#endif
		},
	},
#endif

/*****************************************************************************************************************/

#ifdef	SIZE_2480
	{	/* 30 */			/* FILTER	*/
		{"[SET FILTER]",
#ifdef	KOREA	
				"[���� ����]"
#elif	JAPAN
				"[SET FILTER]"
#elif	CHINA
				"[SET FILTER]"
#elif	TAIWAN
				"[SET FILTER]"
#elif	ENGLISH	
				"[SET FILTER]"
#endif
		},
		{
				{"Exit" ,"[SET FILTER]","Menu" ,"DEVICE","DEV_CONT","","","","","","","","","",""},
#ifdef	KOREA	
				{"���� ","[���� ����]" ,"�޴� ","DEVICE","DEV_CONT","","","","","","","","","",""}
#elif	JAPAN
				{"�I�� ","[SET FILTER]","�O�� ","DEVICE","DEV_CONT","","","","","","","","","",""}
#elif	CHINA
				{"Exit" ,"[SET FILTER]","Menu" ,"DEVICE","DEV_CONT","","","","","","","","","",""}
#elif	TAIWAN
				{"Exit" ,"[SET FILTER]","Menu" ,"DEVICE","DEV_CONT","","","","","","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[SET FILTER]","Menu" ,"DEVICE","DEV_CONT","","","","","","","","","",""}
#endif
		},
	},
#endif

#ifdef	GP_S057
	{	/* 30 */			/* FILTER	*/
		{"[SET FUNCTION]",
#ifdef	KOREA	
				"[��� ����]"
#elif	JAPAN
				"[FUNCTION �ݒ�]"
#elif	CHINA
				"[SET FUNCTION]"
#elif	TAIWAN
				"[SET FUNCTION]"
#elif	ENGLISH	
				"[SET FUNCTION]"
#endif
		},
		{
				{"Exit" ,"[SET FUNCTION]","Menu" ,"DATA TRANSFER","TIME SWITCH", "PRINT OUT"  ,"","","","","","","",""},
#ifdef	KOREA	
				{"���� ","[��� ����]"   ,"�޴� ","������ ���� ","�ð� ����ġ ","������ ��� ","","","","","","","" ,""},
#elif	JAPAN
				{"�I�� ","[FUNCTION �ݒ�]","�O�� ","�f�[�^�]�� "   ,"TIME�X�C�b�` ","�v�����g ","","","","","","","",""}
#elif	CHINA
				{"Exit" ,"[SET FUNCTION]","Menu" ,"DATA TRANSFER","TIME SWITCH", "PRINT OUT"  ,"","","","","","","",""},
#elif	TAIWAN
				{"Exit" ,"[SET FUNCTION]","Menu" ,"DATA TRANSFER","TIME SWITCH", "PRINT OUT"  ,"","","","","","","",""},
#elif	ENGLISH	
				{"Exit" ,"[SET FUNCTION]","Menu" ,"DATA TRANSFER","TIME SWITCH", "PRINT OUT"  ,"","","","","","","",""},
#endif
		},
	},
#endif

/*****************************************************************************************************************/

#ifdef	SIZE_2480
	{	/* 31 */		/* INTERRUPT	*/
		{"[SET INTERRUPT]",
#ifdef	KOREA	
				"[���ͷ��� ����]"
#elif	JAPAN
				"[SET INTERRUPT]"
#elif	CHINA
				"[SET INTERRUPT]"
#elif	TAIWAN
				"[SET INTERRUPT]"
#elif	ENGLISH	
				"[SET INTERRUPT]"
#endif
		},
		{
				{"Exit" ,"[SET INTERRUPT]","Menu" ,"NO INT"   ,"RISING ","FALLING","DISABLE","","","","","","","",""},
#ifdef	KOREA	
				{"���� ","[���ͷ��� ����]","�޴� ","�������� ","��� "  ,"�ϰ� "  ,"DISABLE","","","","","","","",""}
#elif	JAPAN
				{"�I�� ","[SET INTERRUPT]","�O�� ","NO INT "  ,"RISING ","FALLING","DISABLE","","","","","","","",""}
#elif	CHINA
				{"Exit" ,"[SET INTERRUPT]","Menu" ,"NO INT"   ,"RISING ","FALLING","DISABLE","","","","","","","",""}
#elif	TAIWAN
				{"Exit" ,"[SET INTERRUPT]","Menu" ,"NO INT"   ,"RISING ","FALLING","DISABLE","","","","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[SET INTERRUPT]","Menu" ,"NO INT"   ,"RISING ","FALLING","DISABLE","","","","","","","",""}
#endif
		},
	},
#endif

#ifdef	GP_S057
	{	/* 31 */		/* INTERRUPT	*/
		{"[TIME SWITCH]",
#ifdef	KOREA	
				"[�ð� ����ġ]"
#elif	JAPAN
				"[TIME�X�C�b�`]"
#elif	CHINA
				"[TIME SWITCH]"
#elif	TAIWAN
				"[TIME SWITCH]"
#elif	ENGLISH	
				"[TIME SWITCH]"
#endif
		},
		{
				{"SU" ,"MO" ,"TU" ,"WE" ,"TH" ,"FR" ,"SA" ,"","","",""},
#ifdef	KOREA	
				{"�� ","�� ","ȭ ","�� ","�� ","�� ","�� ","","","",""},
#elif	JAPAN
				{"�� ","�� ","�� ","�� ","�� ","�� ","�y ","","","",""}
#elif	CHINA
				{"SU" ,"MO" ,"TU" ,"WE" ,"TH" ,"FR" ,"SA" ,"","","",""},
#elif	TAIWAN
				{"SU" ,"MO" ,"TU" ,"WE" ,"TH" ,"FR" ,"SA" ,"","","",""},
#elif	ENGLISH	
				{"SU" ,"MO" ,"TU" ,"WE" ,"TH" ,"FR" ,"SA" ,"","","",""},
#endif
		},
	},
#endif


/*****************************************************************************************************************/
#ifdef	SIZE_2480
	{	/* 32 */				/* 10KEY		*/
		{"[SET 4 X 4 KEYPAD]",
#ifdef	KOREA	
				"[4 X 4 Ű�е� ����]"
#elif	JAPAN
				"[SET 4 X 4 KEYPAD]"
#elif	CHINA
				"[SET 4 X 4 KEYPAD]"
#elif	TAIWAN
				"[SET 4 X 4 KEYPAD]"
#elif	ENGLISH	
				"[SET 4 X 4 KEYPAD]"
#endif
		},
		{
				{"Exit" ,"[SET 4 X 4 KEYPAD]" ,"Menu" ,"USE_INF","IN_PORT","OUT_PORT","DISABLE"  ,"ENABLE","X00->X03","X08->X0B","Y00->Y03","Y08->Y0B","","",""},
#ifdef	KOREA	
				{"���� ","[4 X 4 Ű�е� ����]","�޴� ","USE_INF","IN_PORT","OUT_PORT","������ ","��� " ,"X00->X03","X08->X0B","Y00->Y03","Y08->Y0B","","",""}
#elif	JAPAN
				{"�I�� ","[SET 4 X 4 KEYPAD]" ,"�O�� ","USE_INF","IN_PORT","OUT_PORT","DISABLE"  ,"ENABLE","X00->X03","X08->X0B","Y00->Y03","Y08->Y0B","","",""}
#elif	CHINA
				{"Exit" ,"[SET 4 X 4 KEYPAD]" ,"Menu" ,"USE_INF","IN_PORT","OUT_PORT","DISABLE"  ,"ENABLE","X00->X03","X08->X0B","Y00->Y03","Y08->Y0B","","",""}
#elif	TAIWAN
				{"Exit" ,"[SET 4 X 4 KEYPAD]" ,"Menu" ,"USE_INF","IN_PORT","OUT_PORT","DISABLE"  ,"ENABLE","X00->X03","X08->X0B","Y00->Y03","Y08->Y0B","","",""}
#elif	ENGLISH	
				{"Exit" ,"[SET 4 X 4 KEYPAD]" ,"Menu" ,"USE_INF","IN_PORT","OUT_PORT","DISABLE"  ,"ENABLE","X00->X03","X08->X0B","Y00->Y03","Y08->Y0B","","",""}
#endif
		},
	},
#endif
#ifdef	GP_S057 /* 32 */
	{
		{"[LATCH DEVICE]",
#ifdef	KOREA	
				"[��ġ ����̽�]"
#elif	JAPAN
				"[LATCH DEVICE]"
#elif	CHINA
				"[LATCH DEVICE]"
#elif	TAIWAN
				"[LATCH DEVICE]"
#elif	ENGLISH	
				"[LATCH DEVICE]"
#endif
		},
		{
				{"Exit" ,"[LATCH DEVICE] ","Menu ","UW DEVICE LATCH SETTING  ","LATCH ON ","LATCH OFF ","OFF ","ON ","LATCH DEVICE ","","","","","",""},
#ifdef	KOREA	
				{"���� ","[��ġ ����̽�]","�޴� ","UW ����̽��� LATCH ���� ","LATCH ON ","LATCH OFF ","OFF ","ON ","��ġ ����̽� ","","","","","",""},
#elif	JAPAN
				{"Exit" ,"[LATCH DEVICE] ","Menu ","UW DEVICE LATCH SETTING  ","LATCH ON ","LATCH OFF ","OFF ","ON ","LATCH DEVICE ","","","","","",""}
#elif	CHINA
				{"Exit" ,"[LATCH DEVICE] ","Menu ","UW DEVICE LATCH SETTING  ","LATCH ON ","LATCH OFF ","OFF ","ON ","LATCH DEVICE ","","","","","",""},
#elif	TAIWAN
				{"Exit" ,"[LATCH DEVICE] ","Menu ","UW DEVICE LATCH SETTING  ","LATCH ON ","LATCH OFF ","OFF ","ON ","LATCH DEVICE ","","","","","",""},
#elif	ENGLISH	
				{"Exit" ,"[LATCH DEVICE] ","Menu ","UW DEVICE LATCH SETTING  ","LATCH ON ","LATCH OFF ","OFF ","ON ","LATCH DEVICE ","","","","","",""},
#endif
		},
	},
#endif
/*****************************************************************************************************************/
#ifdef	SIZE_2480
	{	/* 33 */				/* 7SEG		*/
		{"[SET 7 SEGMENT]",
#ifdef	KOREA	
				"[7 ���׸�Ʈ ����]"
#elif	JAPAN
				"[SET 7 SEGMENT]"
#elif	CHINA
				"[SET 7 SEGMENT]"
#elif	TAIWAN
				"[SET 7 SEGMENT]"
#elif	ENGLISH	
				"[SET 7 SEGMENT]"
#endif
		},
		{
				{"Exit" ,"[SET 7 SEGMENT]"  ,"Menu" ,"USE_INF","COM_PORT","OUT_PORT","DISABLE"  ,"ENABLE","Y00->Y03","Y08->Y0B","Y00->Y07","Y08->Y0F","","","",""},
#ifdef	KOREA	
				{"���� ","[7 ���׸�Ʈ ����]","�޴� ","USE_INF","COM_PORT","OUT_PORT","������ ","��� " ,"Y00->Y03","Y08->Y0B","Y00->Y07","Y08->Y0F","","","",""}
#elif	JAPAN
				{"�I�� ","[SET 7 SEGMENT]"  ,"�O�� ","USE_INF","COM_PORT","OUT_PORT","DISABLE"  ,"ENABLE","Y00->Y03","Y08->Y0B","Y00->Y07","Y08->Y0F","","","",""}
#elif	CHINA
				{"Exit" ,"[SET 7 SEGMENT]"  ,"Menu" ,"USE_INF","COM_PORT","OUT_PORT","DISABLE"  ,"ENABLE","Y00->Y03","Y08->Y0B","Y00->Y07","Y08->Y0F","","","",""}
#elif	TAIWAN
				{"Exit" ,"[SET 7 SEGMENT]"  ,"Menu" ,"USE_INF","COM_PORT","OUT_PORT","DISABLE"  ,"ENABLE","Y00->Y03","Y08->Y0B","Y00->Y07","Y08->Y0F","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[SET 7 SEGMENT]"  ,"Menu" ,"USE_INF","COM_PORT","OUT_PORT","DISABLE"  ,"ENABLE","Y00->Y03","Y08->Y0B","Y00->Y07","Y08->Y0F","","","",""}
#endif
		},
	},
#endif
#ifdef	GP_S057
	{	/* 33 */		
		{"33",
#ifdef	KOREA	
				""
#elif	JAPAN
				""
#elif	CHINA
				""
#elif	TAIWAN
				""
#elif	ENGLISH	
				""
#endif
		},
		{
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""},
#ifdef	KOREA	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	JAPAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	CHINA
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	TAIWAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	ENGLISH	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#endif
		},
	},
#endif

/*****************************************************************************************************************/
#ifdef	SIZE_2480
	{	/* 34 */				/* SYNC		*/
		{"[SYNCHRONOUS SERIAL]",
#ifdef	KOREA	
				"[���� �ø���]"
#elif	JAPAN
				"[SYNCHRONOUS SERIAL]"
#elif	CHINA
				"[SYNCHRONOUS SERIAL]"
#elif	TAIWAN
				"[SYNCHRONOUS SERIAL]"
#elif	ENGLISH	
				"[SYNCHRONOUS SERIAL]"
#endif
		},
		{
				{"Exit" ,"[SYNCHRONOUS]",     "Menu" ,"USE_INF","OUT_PORT","DATA BIT","COUNT","DEVICE","ADDRESS","DISABLE"  ,"ENABLE","Y04->X06","Y0C->Y0E","DEVICE"},
#ifdef	KOREA
				{"���� ","[���� �ø��� ����]","�޴� ","USE_INF","OUT_PORT","DATA BIT","COUNT","DEVICE","ADDRESS","������ ","���  ","Y04->X06","Y0C->Y0E","DEVICE"}
#elif	JAPAN
				{"�I�� ","[SET SERIAL]"      ,"�O�� ","USE_INF","OUT_PORT","DATA BIT","COUNT","DEVICE","ADDRESS","DISABLE"  ,"ENABLE","Y04->X06","Y0C->Y0E","DEVICE"}
#elif	CHINA
				{"Exit" ,"[SYNCHRONOUS]"     ,"Menu" ,"USE_INF","OUT_PORT","DATA BIT","COUNT","DEVICE","ADDRESS","DISABLE"  ,"ENABLE","Y04->X06","Y0C->Y0E","DEVICE"}
#elif	TAIWAN
				{"Exit" ,"[SYNCHRONOUS]"     ,"Menu" ,"USE_INF","OUT_PORT","DATA BIT","COUNT","DEVICE","ADDRESS","DISABLE"  ,"ENABLE","Y04->X06","Y0C->Y0E","DEVICE"}
#elif	ENGLISH	
				{"Exit" ,"[SYNCHRONOUS]"     ,"Menu" ,"USE_INF","OUT_PORT","DATA BIT","COUNT","DEVICE","ADDRESS","DISABLE"  ,"ENABLE","Y04->X06","Y0C->Y0E","DEVICE"}
#endif
		},
	},
#endif
#ifdef	GP_S057
	{	/* 34 */		
		{"34",
#ifdef	KOREA	
				""
#elif	JAPAN
				""
#elif	CHINA
				""
#elif	TAIWAN
				""
#elif	ENGLISH	
				""
#endif
		},
		{
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""},
#ifdef	KOREA	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	JAPAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	CHINA
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	TAIWAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	ENGLISH	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#endif
		},
	},
#endif
/*****************************************************************************************************************/
#ifdef	SIZE_2480
	{	/* 35 */				/* PULS		*/
		{"[SET PULS]",
#ifdef	KOREA	
				"[SET PULS]"
#elif	JAPAN
				"[SET PULS]"
#elif	CHINA
				"[SET PULS]"
#elif	TAIWAN
				"[SET PULS]"
#elif	ENGLISH	
				"[SET PULS]"
#endif
		},
		{
				{"Exit" ,"[SET PULS]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y07","Y0F","","","","","",""},
#ifdef	KOREA
				{"���� ","[SET PULS]","�޴� ","USE_INF","OUT_PORT","NOT USE","USE    ","Y07","Y0F","","","","","",""}
#elif	JAPAN
				{"�I�� ","[SET PULS]","�O�� ","USE_INF","OUT_PORT","NOT USE","USE    ","Y07","Y0F","","","","","",""}
#elif	CHINA
				{"Exit" ,"[SET PULS]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y07","Y0F","","","","","",""}
#elif	TAIWAN
				{"Exit" ,"[SET PULS]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y07","Y0F","","","","","",""}
#elif	ENGLISH
				{"Exit" ,"[SET PULS]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y07","Y0F","","","","","",""}
#endif
		}
	},
#endif
#ifdef	GP_S057
	{	/* 35 */		
		{"35",
#ifdef	KOREA	
				""
#elif	JAPAN
				""
#elif	CHINA
				""
#elif	TAIWAN
				""
#elif	ENGLISH	
				""
#endif
		},
		{
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""},
#ifdef	KOREA	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	JAPAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	CHINA
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	TAIWAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	ENGLISH	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#endif
		},
	},
#endif
/*****************************************************************************************************************/
#ifdef	SIZE_2480
	{	/* 36 */				/* ENCODE		*/
		{"[SET ENCODE]",
#ifdef	KOREA	
				"[SET ENCODE]"
#elif	JAPAN
				"[SET ENCODE]"
#elif	CHINA
				"[SET ENCODE]"
#elif	TAIWAN
				"[SET ENCODE]"
#elif	ENGLISH	
				"[SET ENCODE]"
#endif
		},
		{
				{"Exit" ,"[SET ENCODE]","Menu" ,"USE_INF","IN_PORT","OUT_PORT","NOT USE","USE    ","X04->X06","X0C->X0E","Y03","Y0B","","","",""},
#ifdef	KOREA	
				{"���� ","[SET ENCODE]","�޴� ","USE_INF","IN_PORT","OUT_PORT","NOT USE","USE    ","X04->X06","X0C->X0E","Y03","Y0B","","","",""}
#elif	JAPAN	
				{"�I�� ","[SET ENCODE]","�O�� ","USE_INF","IN_PORT","OUT_PORT","NOT USE","USE    ","X04->X06","X0C->X0E","Y03","Y0B","","","",""}
#elif	CHINA	
				{"Exit" ,"[SET ENCODE]","Menu" ,"USE_INF","IN_PORT","OUT_PORT","NOT USE","USE    ","X04->X06","X0C->X0E","Y03","Y0B","","","",""}
#elif	TAIWAN	
				{"Exit" ,"[SET ENCODE]","Menu" ,"USE_INF","IN_PORT","OUT_PORT","NOT USE","USE    ","X04->X06","X0C->X0E","Y03","Y0B","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[SET ENCODE]","Menu" ,"USE_INF","IN_PORT","OUT_PORT","NOT USE","USE    ","X04->X06","X0C->X0E","Y03","Y0B","","","",""}
#endif
		}
	},
#endif
#ifdef	GP_S057
	{	/* 36 */		
		{"36",
#ifdef	KOREA	
				""
#elif	JAPAN
				""
#elif	CHINA
				""
#elif	TAIWAN
				""
#elif	ENGLISH	
				""
#endif
		},
		{
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""},
#ifdef	KOREA	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	JAPAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	CHINA
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	TAIWAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	ENGLISH	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#endif
		},
	},
#endif
/*****************************************************************************************************************/
#ifdef	SIZE_2480
	{	/* 37 */				/* COUNT		*/
		{"[SET COUNT]",
#ifdef	KOREA	
				"[SET COUNT]"
#elif	JAPAN
				"[SET COUNT]"
#elif	CHINA
				"[SET COUNT]"
#elif	TAIWAN
				"[SET COUNT]"
#elif	ENGLISH	
				"[SET COUNT]"
#endif
		},
		{
				{"Exit" ,"[SET COUNT]","Menu" ,"USE_INF","IN_PORT","NOT USE","USE    ","X07","X0F","","","","","",""},
#ifdef	KOREA	
				{"���� ","[SET COUNT]","�޴� ","USE_INF","IN_PORT","NOT USE","USE    ","X07","X0F","","","","","",""}
#elif	JAPAN	
				{"�I�� ","[SET COUNT]","�O�� ","USE_INF","IN_PORT","NOT USE","USE    ","X07","X0F","","","","","",""}
#elif	CHINA	
				{"Exit" ,"[SET COUNT]","Menu" ,"USE_INF","IN_PORT","NOT USE","USE    ","X07","X0F","","","","","",""}
#elif	TAIWAN	
				{"Exit" ,"[SET COUNT]","Menu" ,"USE_INF","IN_PORT","NOT USE","USE    ","X07","X0F","","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[SET COUNT]","Menu" ,"USE_INF","IN_PORT","NOT USE","USE    ","X07","X0F","","","","","",""}
#endif
		}
	},
#endif
#ifdef	GP_S057
	{	/* 37 */		
		{"37",
#ifdef	KOREA	
				""
#elif	JAPAN
				""
#elif	CHINA
				""
#elif	TAIWAN
				""
#elif	ENGLISH	
				""
#endif
		},
		{
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""},
#ifdef	KOREA	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	JAPAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	CHINA
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	TAIWAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	ENGLISH	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#endif
		},
	},
#endif
/*****************************************************************************************************************/
#ifdef	SIZE_2480
	{	/* 38 */			/* PATARN		*/
		{"[SET PATARN]",
#ifdef	KOREA	
				"[SET PATARN]"
#elif	JAPAN
				"[SET PATARN]"
#elif	CHINA
				"[SET PATARN]"
#elif	TAIWAN
				"[SET PATARN]"
#elif	ENGLISH	
				"[SET PATARN]"
#endif
		},
		{
				{"Exit" ,"[SET PATARN]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y04->Y07","Y0C->Y0F","","","","","",""},
#ifdef	KOREA	
				{"���� ","[SET PATARN]","�޴� ","USE_INF","OUT_PORT","NOT USE","USE    ","Y04->Y07","Y0C->Y0F","","","","","",""}
#elif	JAPAN
				{"�I�� ","[SET PATARN]","�O�� ","USE_INF","OUT_PORT","NOT USE","USE    ","Y04->Y07","Y0C->Y0F","","","","","",""}
#elif	CHINA	
				{"Exit" ,"[SET PATARN]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y04->Y07","Y0C->Y0F","","","","","",""}
#elif	TAIWAN	
				{"Exit" ,"[SET PATARN]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y04->Y07","Y0C->Y0F","","","","","",""}
#elif	ENGLISH	
				{"Exit" ,"[SET PATARN]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y04->Y07","Y0C->Y0F","","","","","",""}
#endif
		}
	},
#endif
#ifdef	GP_S057
	{	/* 38 */		
		{"38",
#ifdef	KOREA	
				""
#elif	JAPAN
				""
#elif	CHINA
				""
#elif	TAIWAN
				""
#elif	ENGLISH	
				""
#endif
		},
		{
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""},
#ifdef	KOREA	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	JAPAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	CHINA
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	TAIWAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	ENGLISH	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#endif
		},
	},
#endif
/*****************************************************************************************************************/
#ifdef	SIZE_2480
	{	/* 39 */	/* 3	3 ACTIVE STATE MONTORȭ�� */
		{"[CLEAR USER DATA]",
#ifdef	KOREA	
				"[USER DATA �ʱ�ȭ]"
#elif	JAPAN
				"[CLEAR USER DATA]"
#elif	CHINA
				"[CLEAR USER DATA]"
#elif	TAIWAN
				"[CLEAR USER DATA]"
#elif	ENGLISH	
				"[CLEAR USER DATA]"
#endif
		},
		{
				{"CLEAR GP DATA"   ,"CLEAR LP DATA"   ,"","","","","","","","",""},
#ifdef	KOREA	
				{" GP DATA �ʱ�ȭ "," LP DATA �ʱ�ȭ ","","","","","","","","",""}
#elif	JAPAN	
				{"CLEAR GP DATA"   ,"CLEAR LP DATA","","","","","","","","",""}
#elif	CHINA	
				{"CLEAR GP DATA"   ,"CLEAR LP DATA"   ,"","","","","","","","",""}
#elif	TAIWAN	
				{"CLEAR GP DATA"   ,"CLEAR LP DATA"   ,"","","","","","","","",""}
#elif	ENGLISH	
				{"CLEAR GP DATA"   ,"CLEAR LP DATA"   ,"","","","","","","","",""}
#endif
		}
	},
#endif
#ifdef	GP_S057
	{	/* 39 */		
		{"39",
#ifdef	KOREA	
				""
#elif	JAPAN
				""
#elif	CHINA
				""
#elif	TAIWAN
				""
#elif	ENGLISH	
				""
#endif
		},
		{
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""},
#ifdef	KOREA	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	JAPAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	CHINA
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	TAIWAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	ENGLISH	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#endif
		},
	},
#endif
/*****************************************************************************************************************/
#ifdef	SIZE_2480
	{	/* 40 */				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
		{"[CLEAR LP DATA]",
#ifdef	KOREA	
				"[LP �ʱ�ȭ]"
#elif	JAPAN
				"[�f�[�^�폜]"
#elif	CHINA
				"[CLEAR LP DATA]"
#elif	TAIWAN
				"[CLEAR LP DATA]"
#elif	ENGLISH	
				"[CLEAR LP DATA]"
#endif
		},
		{
				{"CLEAR LP DATA? "            ,""                              ,"YES" ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""},
#ifdef	KOREA	
				{" ��� ����Ÿ�� �����˴ϴ�. "," �����͸� �ʱ�ȭ�Ͻðڽ��ϱ�? "," �� "," �ƴϿ� ","����� ������ ������... ","","","","","",""}
#elif	JAPAN	
				{"LP �f�[�^�폜? "              ,""                              ,"YES" ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""}
#elif	CHINA	
				{"CLEAR LP DATA? "            ,""                              ,"YES" ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""}
#elif	TAIWAN	
				{"CLEAR LP DATA? "            ,""                              ,"YES" ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""}
#elif	ENGLISH	
				{"CLEAR LP DATA? "            ,""                              ,"YES" ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""}
#endif
		},
	},
#endif
#ifdef	GP_S057
	{	/* 40 */		
		{"40",
#ifdef	KOREA	
				""
#elif	JAPAN
				""
#elif	CHINA
				""
#elif	TAIWAN
				""
#elif	ENGLISH	
				""
#endif
		},
		{
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""},
#ifdef	KOREA	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	JAPAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	CHINA
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	TAIWAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	ENGLISH	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#endif
		},
	},
#endif
/*****************************************************************************************************************/
#ifdef	SIZE_2480
	{	/* 41 */				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
		{"[I/O MONITORING] ",
#ifdef	KOREA	
				"[����� ����͸�]"
#elif	JAPAN
				"[I/O MONITORING]"
#elif	CHINA
				"[I/O MONITORING]"
#elif	TAIWAN
				"[I/O MONITORING]"
#elif	ENGLISH	
				"[I/O MONITORING]"
#endif
		},
		{
				{"","","","","","","","","","",""},
#ifdef	KOREA	
				{"","","","","","","","","","",""}
#elif	JAPAN	
				{"","","","","","","","","","",""},
#elif	CHINA
				{"","","","","","","","","","",""},
#elif	TAIWAN	
				{"","","","","","","","","","",""},
#elif	ENGLISH	
				{"","","","","","","","","","",""}
#endif
		},
	},
#endif
#ifdef	GP_S057
	{	/* 41 */		
		{"41",
#ifdef	KOREA	
				""
#elif	JAPAN
				""
#elif	CHINA
				""
#elif	TAIWAN
				""
#elif	ENGLISH	
				""
#endif
		},
		{
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""},
#ifdef	KOREA	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	JAPAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	CHINA
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	TAIWAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	ENGLISH	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#endif
		},
	},
#endif
/*****************************************************************************************************************/
#ifdef	SIZE_2480		/* GP_S044�� 28��, LP_S044�� 42�� */ 
	{	/* 42 */				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
		{		
				"[CONNECTION DETAIL]",
#ifdef	KOREA	
				"[���� ��� ��]"
#elif	JAPAN
				"[CONNECTION DETAIL]"
#elif	CHINA
				"[CONNECTION DETAIL]"
#elif	TAIWAN
				"[CONNECTION DETAIL]"
#elif	ENGLISH	
				"[CONNECTION DETAIL]"
#endif
		},
		{
				{"CH1:" ,"CH2:" ,"" ,"" ,"" ,"","","","","",""},
#ifdef	KOREA	
				{"CH1:" ,"CH2:" ,"" ,"" ,"" ,"","","","","",""}
#elif	JAPAN
				{"CH1:" ,"CH2:" ,"" ,"" ,"" ,"","","","","",""}
#elif	CHINA
				{"CH1:" ,"CH2:" ,"" ,"" ,"" ,"","","","","",""}
#elif	TAIWAN
				{"CH1:" ,"CH2:" ,"" ,"" ,"" ,"","","","","",""}
#elif	ENGLISH	
				{"CH1:" ,"CH2:" ,"" ,"" ,"" ,"","","","","",""}
#endif
		},
	},
#endif
#ifdef	GP_S057
	{	/* 42 */		
		{"42",
#ifdef	KOREA	
				""
#elif	JAPAN
				""
#elif	CHINA
				""
#elif	TAIWAN
				""
#elif	ENGLISH	
				""
#endif
		},
		{
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""},
#ifdef	KOREA	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	JAPAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	CHINA
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	TAIWAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	ENGLISH	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#endif
		},
	},
#endif
/*****************************************************************************************************************/
#ifdef	SIZE_2480	/* GP_S044�� 29��, LP_S044�� 43�� */ 
	{	/* 43 */				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */	/* 20091222 */
		{"[LATCH DEVICE]",
#ifdef	KOREA	
				"[LATCH DEVICE]"
#elif	JAPAN
				"[LATCH DEVICE]"
#elif	CHINA
				"[LATCH DEVICE]"
#elif	TAIWAN
				"[LATCH DEVICE]"
#elif	ENGLISH
				"[LATCH DEVICE]"
#endif
		},
		{
				{"LATCH ON ","LATCH OFF ","OFF","ON","","","","","","",""},
#ifdef	KOREA	
				{"LATCH ON ","LATCH OFF ","OFF","ON","","","","","","",""}
#elif	JAPAN	
				{"LATCH ON ","LATCH OFF ","OFF","ON","","","","","","",""}
#elif	CHINA	
				{"LATCH ON ","LATCH OFF ","OFF","ON","","","","","","",""}
#elif	TAIWAN	
				{"LATCH ON ","LATCH OFF ","OFF","ON","","","","","","",""}
#elif	ENGLISH	
				{"LATCH ON ","LATCH OFF ","OFF","ON","","","","","","",""}
#endif
		},
	},
#endif
#ifdef	GP_S057
	{	/* 43 */		
		{"43",
#ifdef	KOREA	
				""
#elif	JAPAN
				""
#elif	CHINA
				""
#elif	TAIWAN
				""
#elif	ENGLISH	
				""
#endif
		},
		{
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""},
#ifdef	KOREA	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	JAPAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	CHINA
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	TAIWAN
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#elif	ENGLISH	
				{"" ,"" ,"" ,"" ,"" ,"" ,"" ,"","","",""}
#endif
		},
	},
#endif
/*****************************************************************************************************************/
};


#ifdef	GP_S057
volatile	const	_DISPLAY1	LargDispName[]=
{
	{	/* 0 */			/* 4-5-5 0 PLC Setting */
		{"[PLC SETTING]",
#ifdef	KOREA	
				"PLC ���� "
#elif	JAPAN
				"[PLC �ݒ�]"
#elif	CHINA
				"[PLC SETTING]"
#elif	TAIWAN
				"[PLC SETTING]"
#elif	ENGLISH
				"[PLC SETTING]"
#endif
		},			
		{
			{"Exit" ,"[PLC SETTING]","Menu" ,
				"CH1 INF","","","","B/R","DATA","   STOP","PARITY","FLOW/C","GP ST.#",
				"CH1 ST.#","","","","","","CH2 INF","","","B/R",
				"DATA","   STOP","PARITY","FLOW/C","","","","","","","","","","",},
#ifdef	KOREA	
			{"���� ","PLC ���� "    ,"�޴� ",
				"CH1 INF","","","","B/R","DATA","   STOP","PARITY","FLOW/C","GP ST.#",
				"CH1 ST.#","","","","","","CH2 INF","","","B/R",
				"DATA","   STOP","PARITY","FLOW/C","","","","","","","","","","",},
#elif	JAPAN
			{"�I�� ","[PLC �ݒ�]"    ,"�O�� ",
				"CH1 INF","","","","B/R","DATA","   STOP","PARITY","FLOW/C","GP ST.#",
				"CH1 ST.#","","","","","","CH2 INF","","","B/R",
				"DATA","   STOP","PARITY","FLOW/C","","","","","","","","","","",},
#elif	CHINA
			{"Exit" ,"[PLC SETTING]","Menu" ,
				"CH1 INF","","","","B/R","DATA","   STOP","PARITY","FLOW/C","GP ST.#",
				"CH1 ST.#","","","","","","CH2 INF","","","B/R",
				"DATA","   STOP","PARITY","FLOW/C","","","","","","","","","","",},
#elif	TAIWAN
			{"Exit" ,"[PLC SETTING]","Menu" ,
				"CH1 INF","","","","B/R","DATA","   STOP","PARITY","FLOW/C","GP ST.#",
				"CH1 ST.#","","","","","","CH2 INF","","","B/R",
				"DATA","   STOP","PARITY","FLOW/C","","","","","","","","","","",},
#elif	ENGLISH
			{"Exit" ,"[PLC SETTING]","Menu" ,
				"CH1 INF","","","","B/R","DATA","   STOP","PARITY","FLOW/C","GP ST.#",
				"CH1 ST.#","","","","","","CH2 INF","","","B/R",
				"DATA","   STOP","PARITY","FLOW/C","","","","","","","","","","",},
#endif
		},
	},
	{	/* 1 */			/* 4-5-2 13 PLC TYPEȭ�� */
		{"[CLOCK]",
#ifdef	KOREA	
				"[���� �ð�]"
#elif	JAPAN
				"[���v�ݒ�]"
#elif	CHINA
				"[CLOCK]"
#elif	TAIWAN
				"[CLOCK]"
#elif	ENGLISH
				"[CLOCK]"
#endif			
		},							
		{
			{"Exit" ,"[CLOCK]"    ,"Menu" ,"","","0","1","2","3","4","5","6","7","8","9","CLR","ENT",""},
#ifdef	KOREA
			{"���� ","[���� �ð�]","�޴� ","","","0","1","2","3","4","5","6","7","8","9","CLR","ENT",""},
#elif	JAPAN
			{"�I�� ","[���v�ݒ�]","�O�� " ,"","","0","1","2","3","4","5","6","7","8","9","CLR","ENT"},
#elif	CHINA
			{"Exit" ,"[CLOCK]"    ,"Menu" ,"","","0","1","2","3","4","5","6","7","8","9","CLR","ENT",""},
#elif	TAIWAN
			{"Exit" ,"[CLOCK]"    ,"Menu" ,"","","0","1","2","3","4","5","6","7","8","9","CLR","ENT",""},
#elif	ENGLISH
			{"Exit" ,"[CLOCK]"    ,"Menu" ,"","","0","1","2","3","4","5","6","7","8","9","CLR","ENT",""},
#endif
		}
	},
	{	/* 2 */				/* 4-5-7 18 SET BACKLIGHTȭ�� */
		{"[OPENING TIME]",
#ifdef	KOREA	
				"[����� ȭ�� ��ȯ]"
#elif	JAPAN
				"[�X�^�[�g����]"
#elif	CHINA
				"[OPENING TIME]"
#elif	TAIWAN
				"[OPENING TIME]"
#elif	ENGLISH
				"[OPENING TIME]"
#endif						
		},				
		{
			{"Exit" ,"[OPENING TIME]"    ,"Menu" ,"0","1","2","3","4","5","6","7","8","9","CLR","ENT","OPENING TIME","SEC",},
#ifdef	KOREA	
			{"���� ","[����� ȭ�� ��ȯ]","�޴� ","0","1","2","3","4","5","6","7","8","9","CLR","ENT","  ȭ�� ��ȯ ","�� ",}
#elif	JAPAN
			{"�I�� ","[�X�^�[�g����]"      ,"�O�� ","0","1","2","3","4","5","6","7","8","9","CLR","ENT","  �X�^�[�g����","�b ",}
#elif	CHINA
			{"Exit" ,"[OPENING TIME]"    ,"Menu" ,"0","1","2","3","4","5","6","7","8","9","CLR","ENT","OPENING TIME","SEC",}
#elif	TAIWAN
			{"Exit" ,"[OPENING TIME]"    ,"Menu" ,"0","1","2","3","4","5","6","7","8","9","CLR","ENT","OPENING TIME","SEC",}
#elif	ENGLISH
			{"Exit" ,"[OPENING TIME]"    ,"Menu" ,"0","1","2","3","4","5","6","7","8","9","CLR","ENT","OPENING TIME","SEC",}
#endif						
		},
	},
	{	/* 3 */				/* 4-5-7 18 SET BACKLIGHTȭ�� */
		{"[OPENING TIME]",
#ifdef	KOREA	
				"[����� ȭ�� ��ȯ]"
#elif	JAPAN
				"[���v�ݒ�]"
#elif	CHINA
				"[OPENING TIME]"
#elif	TAIWAN
				"[OPENING TIME]"
#elif	ENGLISH
				"[OPENING TIME]"
#endif						
		},
		{
			{"CLR","ENT"," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "},
			{"CLR","ENT"," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "},
		},
	},
	{	/* 4 */							/* 4-2	9 DATA TRANSFERȭ�� */
		{"[TIME SWITCH]",
#ifdef	KOREA	
				"[�ð� ����ġ]"
#elif	JAPAN
				"[TIME�X�C�b�`]"
#elif	CHINA
				"[TIME SWITCH]"
#elif	TAIWAN
				"[TIME SWITCH]"
#elif	ENGLISH
				"[TIME SWITCH]"
#endif						
		},
		{
			{"Exit" ,"[TIME SWITCH]"    ,"Menu" ,
				"DEVICE","START","END",
				"1","","","",
				"2","","","",
				"3","","","",
				"4","","","",
				"5","","","",
				"6","","","",
				"7","","","",
				"8","","","",
				"NUM","",""},
#ifdef	KOREA	
			{"���� ","[�ð� ����ġ]","�޴� ",
				"DEVICE","START","END",
				"1","","","",
				"2","","","",
				"3","","","",
				"4","","","",
				"5","","","",
				"6","","","",
				"7","","","",
				"8","","","",
				"NUM","",""},
#elif	JAPAN
			{"�I�� ","[TIME�X�C�b�`]","�O�� ",
				"DEVICE","START","END",
				"1","","","",
				"2","","","",
				"3","","","",
				"4","","","",
				"5","","","",
				"6","","","",
				"7","","","",
				"8","","","",
				"NUM","",""},
#elif	CHINA
			{"Exit" ,"[TIME SWITCH]"    ,"Menu" ,
				"DEVICE","START","END",
				"1","","","",
				"2","","","",
				"3","","","",
				"4","","","",
				"5","","","",
				"6","","","",
				"7","","","",
				"8","","","",
				"NUM","",""},
#elif	TAIWAN
			{"Exit" ,"[TIME SWITCH]"    ,"Menu" ,
				"DEVICE","START","END",
				"1","","","",
				"2","","","",
				"3","","","",
				"4","","","",
				"5","","","",
				"6","","","",
				"7","","","",
				"8","","","",
				"NUM","",""},
#elif	ENGLISH
			{"Exit" ,"[TIME SWITCH]"    ,"Menu" ,
				"DEVICE","START","END",
				"1","","","",
				"2","","","",
				"3","","","",
				"4","","","",
				"5","","","",
				"6","","","",
				"7","","","",
				"8","","","",
				"NUM","",""},
#endif
		},
	},
};
#endif


