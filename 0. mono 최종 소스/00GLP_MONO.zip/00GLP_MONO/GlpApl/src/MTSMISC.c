#include    "Mts.h"
#include    "MtsCorep.h"
#include    "MtsMiscp.h"
#include    <stdio.h>
#include    <stdarg.h>

/********************************************************
*                                                       *
*       �D�揇�ʂ̕ύX                                  *
*                                                       *
*       int     priority( int tn, int np )              *
*                                                       *
*       �����F  �^�X�N�̔ԍ��i�P�[�P�Q�V�j              *
*       �����F  �V�D�揇��                              *
*       ���A���F                                      *
*       �ύX�O��        �D�揇��                        *
*                                                       *
********************************************************/
unsigned    _ChangeTaskPriority( int *pParam )
{
    TcbFrm* pTcb;
    unsigned    OldPriority;

    pTcb= &_Tcb[pParam[0]];
    OldPriority= pTcb->Priority;
    if ( pParam[1] >= 0 && pTcb->WaitQue != 0 ) {
        _OffQue( (TcbFrm*)pTcb->WaitQue, pTcb );
        pTcb->Priority= pParam[1];
        _LinkPriorityTcb( (TcbFrm*)pTcb->WaitQue, pTcb, pTcb->Status & 0x7f );
    }
    return OldPriority;
}
void    Lcdprintf( int Line, int Column, char* pFrm, ... )
{
extern  int __cdecl sprintf(char *, const char *, ...);
    char   Buf[32];
extern	void	DotTextOut(int x,int y,char *addr,int xbai,int ybai,int mode,int Front,int Back);					/* �ؽ�Ʈ ���			 */
#ifdef	WIN32
typedef char *  va_list;
    vsprintf( (char *)Buf, pFrm, (va_list)((&pFrm)+1) );
#else
	va_list	ap;
	va_start(ap,pFrm);
    vsprintf( (char *)Buf, pFrm, ap );
//	Buf[0]= 0;
#endif
	DotTextOut(Column*8,Line*16,Buf,1,1,0,3,0);
}

