/*************************************************
    FUNC  : Display Program(Simuration)
    Create: 2002.4.28	M.Owash
**************************************************/
#include "sgt.h"
#include "graphics.h"


extern	int	CheckHan(int idx);
extern	void	ChangeTateYoko(unsigned char *obj,unsigned char *src,int Xcnt,int Ycnt);

/****************************************************/
/*	Draw Line										*/
/****************************************************/
void    XInc( void )
{

    BitAdr++;
    if( BitAdr >= 8 ){
        BitAdr-= 8;
        pGraphicMemory++;
        DrawPat= (unsigned char)(ColorPat[DrawColor][DrawPtn][LineBit]);
/*		LineBit = (LineBit + 1) % 24;*/
        MaskBit= (unsigned char)(DrawMode == 0 ? MaskPat[0] : 0xff );
    }
    else {
        DrawPat= (unsigned char)(ColorPat[DrawColor]
			[DrawPtn][LineBit] >> BitAdr);
/*		LineBit = (LineBit + 1) % 24;*/
        MaskBit= (unsigned char)(MaskBit>>1 | 0x80 );
    }
}
void    XDec( void )
{

    BitAdr--;
    if( BitAdr < 0 ){
        BitAdr += 8;
        pGraphicMemory--;
        DrawPat= (unsigned char)(ColorPat[DrawColor][DrawPtn][LineBit]>>7);
/*		LineBit = (LineBit + 1) % 24;*/
        MaskBit= (unsigned char)(DrawMode == 0 ? MaskPat[7] : 0xff );
    }
    else{
        DrawPat= (unsigned char)(ColorPat[DrawColor][DrawPtn][LineBit]>>BitAdr);
/*		LineBit = (LineBit + 1) % 24;*/
        MaskBit= (unsigned char)(MaskBit<<1 | 0x0001 );
    }
}
void    YInc( void ){
#ifdef	WIN32
	pGraphicMemory += 40;
#else
	pGraphicMemory += GAMEN_X_SIZE/8;
#endif
    DrawPat= (unsigned char)(ColorPat[DrawColor][DrawPtn][LineBit]>>BitAdr);
}
void    YDec( void ){
#ifdef	WIN32
	pGraphicMemory -= 40;
#else
	pGraphicMemory -= GAMEN_X_SIZE/8;
#endif
    DrawPat= (unsigned char)(ColorPat[DrawColor][DrawPtn][LineBit]>>BitAdr);
}
void	__MoveTo( int sx, int sy, int Pattern, int Mode )
{
	int	WinNo;

	WinNo= TaskWindowNo[_RunTaskNo];
    LastPos.x= (short)sx;
    LastPos.y= (short)sy;
	if( LastPos.x <    0 ){	LastPos.x= 0;	}
	if( LastPos.x >= GAMEN_X_SIZE ){	LastPos.x= GAMEN_X_SIZE-1;	}
	if( LastPos.y <    0 ){	LastPos.y= 0;	}
	if( LastPos.y >= GAMEN_Y_SIZE ){	LastPos.y= GAMEN_Y_SIZE-1;	}
    DrawPtn= Pattern;
	DrawMode= Mode;
    pGraphicMemory= (unsigned char *)&LcdBuff[WinNo][LastPos.y][LastPos.x/8];
/*    BitAdr= sx%8;*/
    BitAdr= sx & 7;
    DrawPat= (unsigned char)(ColorPat[DrawColor][Pattern][LineBit] >> BitAdr);
/*	LineBit = (LineBit + 1) % 24;*/
/*    LineBit = LineBit < 23 ? LineBit + 1 : LineBit -23;*/
    MaskBit= (unsigned char)(Mode == 0 ? MaskPat[BitAdr] : 0xff );
	if(DrawColor != 0){
/*	    *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit | DrawPat);*/
	    *pGraphicMemory= (unsigned char)(*pGraphicMemory | DrawPat);
	}else{
		if(DrawPat == 0){
		    *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit);
		}
	}
}
void    DrawHorizontal( int sx, int ex, int y )
{
    unsigned char  m_DrawPat;
	int	wPatarnNo;
	int	sPatarnBit;
	int	ePatarnBit;
    unsigned char* DrawMst;

	sPatarnBit= sx % 8;
/*    __MoveTo( sx, y, DrawPtn, DrawMode );*/
	wPatarnNo= 0;
	DrawMst= (unsigned char*)(ColorPatByte[DrawColor][DrawPtn]);
	if(BitAdr > 0){
		if((sx / 8) != (ex / 8)){
			m_DrawPat= DrawMst[wPatarnNo] >> sPatarnBit;
			if(DrawColor != 0){
/*				*pGraphicMemory = (*pGraphicMemory & ~LineMaskBit[sPatarnBit]) | m_DrawPat;*/
				*pGraphicMemory = *pGraphicMemory | m_DrawPat;
			}else{
				*pGraphicMemory = *pGraphicMemory & (~LineMaskBit[sPatarnBit] | m_DrawPat);
			}
			pGraphicMemory++;
			sx= (sx / 8 + 1) * 8;
		}else{
			ePatarnBit= (ex+ 1) % 8;
			if(DrawColor != 0){
				if(ePatarnBit != 0){
					m_DrawPat= DrawMst[wPatarnNo] >> sPatarnBit & ~LineMaskBitS[ePatarnBit];
/*					*pGraphicMemory = (*pGraphicMemory & (~LineMaskBit[sPatarnBit] | LineMaskBitS[ePatarnBit])) | m_DrawPat;*/
					*pGraphicMemory = *pGraphicMemory | m_DrawPat;
				}else{
					m_DrawPat= DrawMst[wPatarnNo] >> sPatarnBit;
/*					*pGraphicMemory = (*pGraphicMemory & ~LineMaskBit[sPatarnBit]) | m_DrawPat;*/
					*pGraphicMemory = *pGraphicMemory | m_DrawPat;
				}
			}else{
				if(ePatarnBit != 0){
					m_DrawPat= DrawMst[wPatarnNo] >> sPatarnBit | LineMaskBitS[ePatarnBit];
					*pGraphicMemory = *pGraphicMemory & (~LineMaskBit[sPatarnBit] | m_DrawPat);
				}else{
					m_DrawPat= DrawMst[wPatarnNo] >> sPatarnBit;
					*pGraphicMemory = *pGraphicMemory & (~LineMaskBit[sPatarnBit] | m_DrawPat);
				}
			}
			return;
		}
	}
	for( ;sx + 7 <= ex; sx += 8 ) {
		if(sPatarnBit == 0){
			m_DrawPat= DrawMst[wPatarnNo];
			if(DrawColor != 0){
/*				*pGraphicMemory = m_DrawPat;*/
				*pGraphicMemory |= m_DrawPat;
				pGraphicMemory++;
			}else{
				*pGraphicMemory &= m_DrawPat;
				pGraphicMemory++;
			}
			wPatarnNo= (wPatarnNo + 1) % 3;
		}else{
			m_DrawPat= DrawMst[wPatarnNo] << (8-sPatarnBit);
			wPatarnNo= (wPatarnNo + 1) % 3;
			m_DrawPat |= DrawMst[wPatarnNo] >> sPatarnBit;
			if(DrawColor != 0){
/*				*pGraphicMemory = m_DrawPat;*/
				*pGraphicMemory |= m_DrawPat;
			}else{
				*pGraphicMemory &= m_DrawPat;
			}
			pGraphicMemory++;
		}
	}
	if( sx <= ex ){
		ePatarnBit= ex % 8;
		if(sPatarnBit == 0){
			if(DrawColor != 0){
				m_DrawPat= DrawMst[wPatarnNo] & ~LineMaskBit[ePatarnBit];
/*				*pGraphicMemory = (*pGraphicMemory & LineMaskBit[ePatarnBit]) | m_DrawPat;*/
				*pGraphicMemory = *pGraphicMemory | m_DrawPat;
			}else{
				m_DrawPat= DrawMst[wPatarnNo] | LineMaskBit[ePatarnBit];
				*pGraphicMemory = *pGraphicMemory & m_DrawPat;
			}
		}else{
			m_DrawPat= DrawMst[wPatarnNo] << (8-sPatarnBit);
			wPatarnNo= (wPatarnNo + 1) % 3;
			m_DrawPat |= DrawMst[wPatarnNo] >> sPatarnBit;
			if(DrawColor != 0){
				m_DrawPat &= ~LineMaskBit[ePatarnBit];
/*				*pGraphicMemory = (*pGraphicMemory & LineMaskBit[ePatarnBit]) | m_DrawPat;*/
				*pGraphicMemory = *pGraphicMemory | m_DrawPat;
			}else{
				*pGraphicMemory = *pGraphicMemory & (LineMaskBit[ePatarnBit] | m_DrawPat);
			}
		}
	}
}
void    DrawHorizontalPrn( int sx, int ex, int y )
{
    unsigned char* DrawMst= (unsigned char*)(ColorPat[DrawColor][DrawPtn]);

/*    __MoveTo( x, sy, DrawPtn, DrawMode );*/
    for( ;sx <= ex;  ) {
        DrawPat= (unsigned char)(DrawMst[LineBit]>>BitAdr);
/*		MaskBit= (unsigned char)(DrawMode == 0 ? MaskPat[BitAdr] : 0xff );*/

		if(DrawColor != 0){
/*	        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit | DrawPat);*/
	        *pGraphicMemory= (unsigned char)(*pGraphicMemory | DrawPat);
		}else{
			if(DrawPat == 0){
				MaskBit= MaskPat[sx%8];	/* 060204 */
		        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit);
			}
		}
		LineBit= (LineBit + 1) % 24;
		sx++;
		BitAdr++;
		BitAdr= BitAdr % 8;
		if((sx % 8) == 0){
			pGraphicMemory++;
		}
	}
    LastPos.x= (short)sx;
    LastPos.y= (short)y;
}
void    RDrawHorizontal( int sx, int ex, int y )
{
    unsigned char* DrawMst1;
	int	WinNo;

	WinNo= TaskWindowNo[_RunTaskNo];
	DrawMst1= (unsigned char*)(ColorPat[DrawColor][DrawPtn]);
	for( ;sx >= ex; sx-- ){
		pGraphicMemory= (unsigned char *)&LcdBuff[WinNo][LastPos.y][sx/8];
		BitAdr= sx & 7;
	    DrawPat= (unsigned char)(DrawMst1[LineBit]>>BitAdr);
		MaskBit= (unsigned char)(DrawMode == 0 ? MaskPat[BitAdr] : 0xff );
		if(DrawColor != 0){
/*			*pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit | DrawPat);*/
			*pGraphicMemory= (unsigned char)(*pGraphicMemory | DrawPat);
		}else{
			if(DrawPat == 0){
				*pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit);
			}
		}
	    LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
	}
}
void    RDrawHorizontalPrn( int sx, int ex, int y )
{
    unsigned char* DrawMst= (unsigned char*)(ColorPat[DrawColor][DrawPtn]);

	for( ;sx >= ex; ){
        DrawPat= (unsigned char)(DrawMst[LineBit]>>BitAdr);

		if(DrawColor != 0){
/*	        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit | DrawPat);*/
	        *pGraphicMemory= (unsigned char)(*pGraphicMemory | DrawPat);
		}else{
			if(DrawPat == 0){
				MaskBit= MaskPat[sx%8];	/* 060204 */
		        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit);
			}
		}
		LineBit= (LineBit + 1) % 24;
		sx--;
		BitAdr--;
		if(BitAdr < 0)
			BitAdr= 7;
		if((sx % 8) == 7){
			pGraphicMemory--;
		}
	}
    LastPos.x= (short)sx;
    LastPos.y= (short)y;
}
void    DrawVertical( int x, int sy, int ey )
{
    unsigned char* DrawMst= (unsigned char*)(ColorPat[DrawColor][DrawPtn]);

/*    __MoveTo( x, sy, DrawPtn, DrawMode );*/
    for( ;sy <= ey; sy++ ) {
        DrawPat= (unsigned char)(DrawMst[LineBit]>>BitAdr);
		if(DrawColor != 0){
/*	        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit | DrawPat);*/
	        *pGraphicMemory= (unsigned char)(*pGraphicMemory | DrawPat);
		}else{
			if(DrawPat == 0){
		        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit);
			}
		}
/*        YInc();*/
/*        sy++;*/
#ifdef	WIN32
		pGraphicMemory += 40;
#else
		pGraphicMemory += GAMEN_X_SIZE/8;
#endif
/*		LineBit = (LineBit + 1) % 24;*/
        LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
     }
}
void    DrawVerticalPrn( int x, int sy, int ey )
{
    unsigned char* DrawMst= (unsigned char*)(ColorPat[DrawColor][DrawPtn]);

/*    __MoveTo( x, sy, DrawPtn, DrawMode );*/
    for( ;sy <= ey; sy++ ) {
        DrawPat= (unsigned char)(DrawMst[LineBit]>>BitAdr);
		if(DrawColor != 0){
/*	        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit | DrawPat);*/
	        *pGraphicMemory= (unsigned char)(*pGraphicMemory | DrawPat);
		}else{
			if(DrawPat == 0){
		        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit);
			}
		}
/*        YInc();*/
/*        sy++;*/
#ifdef	WIN32
		pGraphicMemory += 40;
#else
		pGraphicMemory += GAMEN_X_SIZE/8;
#endif
/*		LineBit = (LineBit + 1) % 24;*/
        LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
	}
	LastPos.x= (short)x;
	LastPos.y= (short)ey;
}
void    RDrawVertical( int x, int sy, int ey )
{
    unsigned char* DrawMst= (unsigned char*)(ColorPat[DrawColor][DrawPtn]);

/*    __MoveTo( x, sy, DrawPtn, DrawMode );*/
    for( ;sy >= ey; sy-- ) {
        DrawPat= (unsigned char)(DrawMst[LineBit]>>BitAdr);
		if(DrawColor != 0){
/*	        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit | DrawPat);*/
	        *pGraphicMemory= (unsigned char)(*pGraphicMemory | DrawPat);
		}else{
			if(DrawPat == 0){
		        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit);
			}
		}
#ifdef	WIN32
		pGraphicMemory -= 40;
#else
		pGraphicMemory -= GAMEN_X_SIZE/8;
#endif
/*		LineBit = (LineBit + 1) % 24;*/
        LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
     }
}
void    RDrawVerticalPrn( int x, int sy, int ey )
{
    unsigned char* DrawMst= (unsigned char*)(ColorPat[DrawColor][DrawPtn]);

/*    __MoveTo( x, sy, DrawPtn, DrawMode );*/
    for( ;sy >= ey; sy-- ) {
        DrawPat= (unsigned char)(DrawMst[LineBit]>>BitAdr);
		if(DrawColor != 0){
/*	        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit | DrawPat);*/
	        *pGraphicMemory= (unsigned char)(*pGraphicMemory | DrawPat);
		}else{
			if(DrawPat == 0){
		        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit);
			}
		}
#ifdef	WIN32
		pGraphicMemory -= 40;
#else
		pGraphicMemory -= GAMEN_X_SIZE/8;
#endif
/*		LineBit = (LineBit + 1) % 24;*/
        LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
     }
	LastPos.x= (short)x;
	LastPos.y= (short)ey;
}

void    DrawFnc( int DMst, int DSlave, void (*pMainMoveFnc)(void), void (*pSlaveMoveFnc)(void ) )
{
    int     i;
    int     Dlt;
    int     DMst2;
    int     DSlave2;

    Dlt= 0;
    DSlave2= DSlave + DSlave;
    DMst2= DMst + DMst;
    for( i= 0; i < DMst; i++ ) {
        Dlt -= DSlave2;
        if ( Dlt + DMst < 0 ) {
            (*pSlaveMoveFnc)();
            Dlt += DMst2;
        }
        (*pMainMoveFnc)();
		if(DrawColor != 0){
/*	        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit | DrawPat);*/
	        *pGraphicMemory= (unsigned char)(*pGraphicMemory | DrawPat);
		}else{
			if(DrawPat == 0){
		        *pGraphicMemory= (unsigned char)(*pGraphicMemory & MaskBit);
			}
		}
		LineBit = (LineBit + 1) % 24;
    }
}
/********************************************************************************************/
/*	Text Disp Proc																			*/
/********************************************************************************************/
void	X6SetHan(int mode,int back,unsigned char **LcdPos,unsigned char **FontPos,int i)
{
	unsigned char work1;
	unsigned char work2;

	switch(mode){
	case T_REPLACE:			/* Replace */
		work1 = (*(*LcdPos)) & HanAndPatern681[i];		/* 0x03->0xfe */
		work2= (*(*FontPos)) & 0xfc;
		work2= work2 >> i;
		if(back == 0){
			*(*LcdPos)= work2 | work1;
		}else{
			*(*LcdPos)= (~work2 & HanAndPatern680[i]) | work1;	/* 0xfc->0x03 */
		}
		if(i > 2){			/* ����LCD�A�h���X�� */
			(*LcdPos)++;
			work1 = (*(*LcdPos)) & HanAndPatern1[i- 2];		/* 0xff->0x01 */
			work2= (*(*FontPos)) & 0xfc;
			work2= work2 << (8- i);
			if(back == 0){
				*(*LcdPos)= work2 | work1;
			}else{
				*(*LcdPos)= (~work2 & HanAndPatern680[i]) | work1;	/* 0xfc->0x03 */
			}
		}
		break;
	case T_OR:
		work2= (*(*FontPos)) & 0xfc;
		work2= work2 >> i;
		if(back == 0){
			*(*LcdPos) |= work2;
		}else{
			*(*LcdPos) |= (~work2 & HanAndPatern680[i]);	/* 0xfc->0x03 */
		}
		if(i > 2){			/* ����LCD�A�h���X�� */
			(*LcdPos)++;
			work2= (*(*FontPos)) & 0xfc;
			work2= work2 << (8- i);
			if(back == 0){
				*(*LcdPos) |= work2;
			}else{
				*(*LcdPos) |= (~work2 & HanAndPatern680[i]);	/* 0xfc->0x03 */
			}
		}
		break;
	case T_XOR:
		work1 = (*(*LcdPos)) & HanAndPatern681[i];		/* 0x03->0xfe */
		work2= (*(*FontPos)) & 0xfc;
		if(back == 0){
			work2= work2 >> i;
		}else{
			work2= (~work2) >> i;
		}
		*(*LcdPos) = (((*(*LcdPos)) ^ work2) & HanAndPatern680[i]) | work1;
		if(i > 2){			/* ����LCD�A�h���X�� */
			(*LcdPos)++;
			work1 = (*(*LcdPos)) & HanAndPatern1[i- 2];		/* 0x03->0xfe */
			work2= (*(*FontPos)) & 0xfc;
			if(back == 0){
				work2= work2 << (8- i);
			}else{
				work2= (~work2) << (8- i);
			}
			*(*LcdPos) = (((*(*LcdPos)) ^ work2) & HanAndPatern2[i- 2]) | work1;
		}
		break;
	}
	(*FontPos)++;
}
void	X4SetHan(int mode,int back,unsigned char **LcdPos,unsigned char **FontPos,int i)
{
	unsigned char work1;
	unsigned char work2;

	switch(mode){
	case T_REPLACE:			/* Replace */
		work1 = (*(*LcdPos)) & HanAndPatern481[i];		/* 0x03->0xfe */
		work2= (*(*FontPos)) & 0xf0;
		work2= work2 >> i;
		if(back == 0){
			*(*LcdPos)= (work2 & HanAndPatern480[i]) | work1;
		}else{
			*(*LcdPos)= (~work2 & HanAndPatern480[i]) | work1;	/* 0xfc->0x03 */
		}
		if(i > 4){			/* ����LCD�A�h���X�� */
			(*LcdPos)++;
			work1 = (*(*LcdPos)) & HanAndPatern1[i- 4];		/* 0xff->0x01 */
			work2= (*(*FontPos)) & 0xf0;
			work2= work2 << (8- i);
			if(back == 0){
				*(*LcdPos)= (work2 & HanAndPatern480[i]) | work1;
			}else{
				*(*LcdPos)= (~work2 & HanAndPatern480[i]) | work1;	/* 0xfc->0x03 */
			}
		}
		break;
	case T_OR:
		work2= (*(*FontPos)) & 0xf0;
		work2= work2 >> i;
		if(back == 0){
			*(*LcdPos) |= work2 & HanAndPatern480[i];
		}else{
			*(*LcdPos) |= (~work2 & HanAndPatern480[i]);	/* 0xfc->0x03 */
		}
		if(i > 4){			/* ����LCD�A�h���X�� */
			(*LcdPos)++;
			work2= (*(*FontPos)) & 0xf0;
			work2= work2 << (8- i);
			if(back == 0){
				*(*LcdPos) |= work2 & HanAndPatern00[7-i];
			}else{
				*(*LcdPos) |= (~work2 & HanAndPatern00[7-i]);	/* 0xfc->0x03 */
			}
		}
		break;
	case T_XOR:
		work1 = (*(*LcdPos)) & HanAndPatern481[i];		/* 0x03->0xfe */
		work2= (*(*FontPos)) & 0xf0;
		if(back == 0){
			work2= work2 >> i;
		}else{
			work2= (~work2) >> i;
		}
		*(*LcdPos) = (((*(*LcdPos)) ^ work2) & HanAndPatern480[i]) | work1;
		if(i > 4){			/* ����LCD�A�h���X�� */
			(*LcdPos)++;
			work1 = (*(*LcdPos)) & HanAndPatern1[i- 4];		/* 0x03->0xfe */
			work2= (*(*FontPos)) & 0xf0;
			if(back == 0){
				work2= work2 << (8- i);
			}else{
				work2= (~work2) << (8- i);
			}
			*(*LcdPos) = (((*(*LcdPos)) ^ work2) & HanAndPatern2[i- 4]) | work1;
		}
		break;
	}
	(*FontPos)++;
}

void	XNonSetFont(int mode,int back,unsigned char **LcdPos,unsigned char **FontPos,int i)
{
	switch(mode){
	case T_REPLACE:
		if(back == 0){
			*(*LcdPos) = (*(*LcdPos) & HanAndPatern2[i]) | (*(*FontPos) >> i);
			(*LcdPos)++;
			if(i != 0){
				*(*LcdPos)= (*(*LcdPos) & HanAndPatern1[i]) | (*(*FontPos) << (8-i));
			}
		}else{
			*(*LcdPos) = (*(*LcdPos) & HanAndPatern2[i]) | (~(*(*FontPos) >> i) & HanAndPatern1[i]);
			(*LcdPos)++;
			if(i != 0){
				*(*LcdPos)= (*(*LcdPos) & HanAndPatern1[i]) | (~(*(*FontPos)) << (8-i));
			}
		}
		break;
	case T_OR:
		if(back == 0){
			*(*LcdPos) |= (*(*FontPos) >> i);
			(*LcdPos)++;
			if(i != 0){
				*(*LcdPos) |= ((*(*FontPos) & HanAndPatern3[i]) << (8-i));
			}
		}else{
/*			*(*LcdPos) |= ~(*(*FontPos) >> i);*/
			*(*LcdPos) |= (*(*LcdPos) & HanAndPatern2[i]) & ~(*(*FontPos) >> i);
			(*LcdPos)++;
			if(i != 0){
/*				*(*LcdPos) |= ~((*(*FontPos) & HanAndPatern3[i]) << (8-i));*/
				*(*LcdPos) = (*(*LcdPos) & HanAndPatern1[i]) | ~((*(*LcdPos) & HanAndPatern2[i]) ^ ((*(*FontPos) & HanAndPatern3[i]) << (8-i)));
			}
		}
		break;
	case T_XOR:
		if(back == 0){
			*(*LcdPos) = (*(*LcdPos) & HanAndPatern2[i]) | ((*(*LcdPos) & HanAndPatern1[i]) ^ (*(*FontPos) >> i));
			(*LcdPos)++;
			if(i != 0){
				*(*LcdPos) = (*(*LcdPos) & HanAndPatern1[i]) | ((*(*LcdPos) & HanAndPatern2[i]) ^ ((*(*FontPos) & HanAndPatern3[i]) << (8-i)));
			}
		}else{
			*(*LcdPos) = (*(*LcdPos) & HanAndPatern2[i]) | ~((*(*LcdPos) & HanAndPatern1[i]) ^ (*(*FontPos) >> i));
			(*LcdPos)++;
			if(i != 0){
				*(*LcdPos) = (*(*LcdPos) & HanAndPatern1[i]) | ~((*(*LcdPos) & HanAndPatern2[i]) ^ ((*(*FontPos) & HanAndPatern3[i]) << (8-i)));
			}
		}
		break;
	}
	(*FontPos)++;
}
void	SetFront(unsigned char **LcdPos,unsigned char **FontPos,int Xcnt,int i)
{
	int		idx;
	int		idx1;
	int		j;
	unsigned char	work1;
	unsigned char	work2;

	idx = i % 8;
	if(Xcnt < 8){		/* 6*8 */
		if(idx == 0){
			if(FrontColor == T_BLACK){
				work2 = (*(*LcdPos)) & HanAndPatern681[0];
				*(*LcdPos)= ((*(*LcdPos)) & ~(*(*FontPos)) & HanAndPatern680[0]) | work2;
			}else{
				*(*LcdPos)= (*(*LcdPos)) | (*(*FontPos));
			}
			(*LcdPos)++;
		}else{
			work1 = (*(*FontPos)) >> idx;
			if(FrontColor == T_BLACK){
				work2 = (*(*LcdPos)) & HanAndPatern681[idx];
				*(*LcdPos)= ((*(*LcdPos)) & ~work1 & HanAndPatern680[idx]) | work2;
			}else{
				*(*LcdPos)= (*(*LcdPos)) | work1;
			}
			(*LcdPos)++;
			if(idx > 2){
				work1 = (*(*FontPos)) << (8- idx);
				if(FrontColor == T_BLACK){
					work2 = (*(*LcdPos)) & HanAndPatern1[idx- 2];
					*(*LcdPos)= ((*(*LcdPos)) & ~work1 & HanAndPatern2[idx- 1]) | work2;
				}else{
					*(*LcdPos)= (*(*LcdPos)) | work1;
				}
			}
		}
		(*FontPos)++;
	}else{
		for(j = 0; j < Xcnt/8; j++){
			if(idx == 0){
				if(FrontColor == T_BLACK){
					if(BackColor == T_WHITE){			//2008.08.25
						*(*LcdPos)= ~(*(*FontPos));
					}else{
						*(*LcdPos)= (*(*LcdPos)) & ~(*(*FontPos));
					}
				}else{
					*(*LcdPos)= (*(*LcdPos)) | (*(*FontPos));
				}
				(*LcdPos)++;
			}else{
				work1 = (*(*FontPos)) >> idx;
				if(FrontColor == T_BLACK){
					if(BackColor == T_WHITE){			//2008.08.25
						*(*LcdPos)= (((*(*LcdPos)) & HanAndPatern2[idx]) | HanAndPatern1[idx]) & ~work1;
						
					}else{
						*(*LcdPos)= (*(*LcdPos)) & ~work1;
					}
				}else{
					*(*LcdPos)= (*(*LcdPos)) | work1;
				}
				(*LcdPos)++;
				work1 = (*(*FontPos)) << (8- idx);
				if(FrontColor == T_BLACK){
					if(BackColor == T_WHITE){			//2008.08.25
						*(*LcdPos)= (((*(*LcdPos)) & HanAndPatern1[idx]) | HanAndPatern2[idx]) & ~work1;
					}else{
						*(*LcdPos)= (*(*LcdPos)) & ~work1;
					}
				}else{
					*(*LcdPos)= (*(*LcdPos)) | work1;
				}
			}
			(*FontPos)++;
		}
		idx1= Xcnt % 8;
		if(idx1 != 0){		/* �W�r�b�g�Ŋ���Ȃ��ꍇ(6) */
			if(idx == 0){	/* ���̏ꍇ�͂Ȃ� */
				if(FrontColor == T_BLACK){
					*(*LcdPos)= (*(*LcdPos)) & ~((*(*FontPos)) & HanAndPatern4[idx1]);
				}else{
					*(*LcdPos)= (*(*LcdPos)) | ((*(*FontPos)) & HanAndPatern4[idx1]);
				}
				(*LcdPos)++;
			}else{
				work1 = ((*(*FontPos)) & HanAndPatern4[idx1]) >> idx;
				if(FrontColor == T_BLACK){
					*(*LcdPos)= (*(*LcdPos)) & ~work1;
				}else{
					*(*LcdPos)= (*(*LcdPos)) | work1;
				}
				(*LcdPos)++;
				work1 = ((*(*FontPos)) & HanAndPatern4[idx1]) << (8- idx);
				if(FrontColor == T_BLACK){
					*(*LcdPos)= (*(*LcdPos)) & ~work1;
				}else{
					*(*LcdPos)= (*(*LcdPos)) | work1;
				}
			}
			(*FontPos)++;
		}
	}
}


const struct{
	int	addr;
	int	ByteCnt;
}MitudoFont[6][3]= 
{
	{
		{FONT_HEXA2432,24/8*32},{FONT_HEXA2448,24/8*48},{FONT_HEXA2464,24/8*64},
	},
	{
		{FONT_HEXA3232,32/8*32},{FONT_HEXA3248,32/8*48},{FONT_HEXA3264,32/8*64},
	},
	{
		{0},
	},
	{
		{FONT_HEXA4832,48/8*32},{FONT_HEXA4848,48/8*48},{FONT_HEXA4864,48/8*64},
	},
	{
		{0},
	},
	{
		{FONT_HEXA6432,64/8*32},{FONT_HEXA6448,64/8*48},{FONT_HEXA6464,64/8*64},
	},
}
;

#ifdef	WIN32
unsigned char *SetHanFontPos(int xbai,int ybai,int idx)
{
	unsigned char *ret;
	int		AddrIdx;
	int		ByteCnt;

	AddrIdx= MitudoFont[xbai- 3][ybai-2].addr;
	ByteCnt= MitudoFont[xbai- 3][ybai-2].ByteCnt;
	if(idx == 0x0e){		/* . */
		ret = (unsigned char *)&GpFont[AddrIdx+ 15*ByteCnt];
	}else if(idx < 0x20){	/* 0->9 */
		ret = (unsigned char *)&GpFont[AddrIdx+ (idx- 0x10)*ByteCnt];
	}else{					/* A->F */
		if(idx == 0x26){
			ret = (unsigned char *)&GpFont[AddrIdx+ 16*ByteCnt];
		}else{
			ret = (unsigned char *)&GpFont[AddrIdx+ (idx- 0x21+ 10)*ByteCnt];
		}
	}
	return(ret);
}
#else
unsigned char *SetHanFontPos(int xbai,int ybai,int idx)
{
	unsigned char *ret;
	int		AddrIdx;
	int		ByteCnt;

	AddrIdx= MitudoFont[xbai- 3][ybai-2].addr;
	ByteCnt= MitudoFont[xbai- 3][ybai-2].ByteCnt;
	if(idx == 0x0e){		/* . */
		ret = (unsigned char *)(AddrIdx+ 15*ByteCnt);
	}else if(idx < 0x20){	/* 0->9 */
		ret = (unsigned char *)(AddrIdx+ (idx- 0x10)*ByteCnt);
	}else{					/* A->F */
		if(idx == 0x26){
			ret = (unsigned char *)(AddrIdx+ 16*ByteCnt);
		}else{
			ret = (unsigned char *)(AddrIdx+ (idx- 0x21+ 10)*ByteCnt);
		}
	}
	return(ret);
}
#endif
int	DotWriteFont0(int type,int x,int y,unsigned char *addr,int back,int xbai,int ybai,int mode,int idx,int mitudo)
{
	unsigned char	*LcdPos;
	unsigned char	*FontPos;
	unsigned char	*TateFontPos;
	int		i,j,k;
	int		Xcnt,Ycnt;
	int		WinNo;
	int		mflag;

	WinNo= TaskWindowNo[_RunTaskNo];
	mflag= 0;
	if(type == 0){				/* ASCII(���p����) */
		FontPos = addr;
		if(xbai == 0){								/* 6*8 */
			Xcnt = 6;
			Ycnt = 8;
		}else if((xbai == 1) && (ybai == 0)){		/* 8*8 */
			Xcnt = 8;
			Ycnt = 8;
		}else if((xbai == 1) && (ybai == 1)){		/* 8*16 */
			Xcnt = 8;
			Ycnt = 16;
		}else{
			Xcnt = 8*xbai;
			Ycnt = 16*ybai;
			if((mitudo == 1) && (CheckHan(idx) == 1) && 
				((xbai == 3) || (xbai == 4) || (xbai == 6) || (xbai == 8)) && ((ybai > 1) && (ybai < 5))){
				/* HEX FONT */
				FontPos= SetHanFontPos(xbai,ybai,idx);
			}else{
				FontData= (unsigned char *)TakeMemory(2*8*16*8);
				mflag= 1;
				memset(FontData,0,2*8*16*8);
				BaiFont(addr,xbai,ybai,1);
				FontPos = (unsigned char *)FontData;
			}
		}
	}else{					/* �S�p���� */
		if(xbai == 0){
			Xcnt= 6*2;
			Ycnt= 8;
		}else{
			Xcnt = 16*xbai;
			if(ybai == 0){
				Ycnt= 8;
			}else{
				Ycnt = 16*ybai;
			}
		}
		FontData= (unsigned char *)TakeMemory(2*8*16*8);
		mflag= 1;
		memset(FontData,0,2*8*16*8);
		BaiFont((unsigned char *)addr,xbai,ybai,2);
		FontPos = (unsigned char *)FontData;
	}
	/* �c�^���ϊ��`�F�b�N */
	if(TateYoko != 0){
		TateFontPos= (unsigned char *)TakeMemory(2*8*16*8);
		ChangeTateYoko(TateFontPos,FontPos,Xcnt,Ycnt);
		if(mflag == 1){
			FreeMail((char *)FontData);
		}
		FontData= TateFontPos;
		FontPos= TateFontPos;
		i = Xcnt;
		Xcnt= Ycnt;
		Ycnt= i;
		y-= Ycnt;
		if(y < 0){
			FreeMail((char *)FontData);
			return(-1);
		}
		if(Ycnt == 6){
			memcpy(TateFontPos,(TateFontPos+2),6);
		}
	}else{
		if( (x+ Xcnt) > GAMEN_X_SIZE){
			if(mflag == 1){
				FreeMail((char *)FontData);
			}
			return(-1);
		}
	}
	if(x >= 0){			/* X Address */
		i = x % 8;
		for(j = 0; j < Ycnt; j++){
			LcdPos= (unsigned char *)&LcdBuff[WinNo][y+j][x/8];
			if(mode == T_FRONT){
				SetFront(&LcdPos,&FontPos,Xcnt,i);
			}else{
				if(Xcnt < 8){
					X6SetHan(mode,back,&LcdPos,&FontPos,i);
				}else{
					for(k = 0; k < Xcnt / 8; k++){
						XNonSetFont(mode,back,&LcdPos,&FontPos,i);
					}
					if(Xcnt % 8){
						X4SetHan(mode,back,&LcdPos,&FontPos,i);
					}
				}
			}
		}
	}
	if((TateYoko != 0) || (mflag == 1)){
		FreeMail((char *)FontData);
	}
	if(TateYoko != 0){
		return(Ycnt);
	}else{
		return(Xcnt);
	}
}

/* 20080822  #define	const�� �����Ͽ��⿡ WIN32�� ���� �ʿ䰡 ����. */
const unsigned char	BlackFont[32]={
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
};
const unsigned char	TriangleFont[9][32]={
	{
		0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x00,
		0x03,0x80,0x07,0xc0,0x07,0xc0,0x0f,0xe0,
		0x1f,0xf0,0x1f,0xf0,0x3f,0xf8,0x7f,0xfc,
		0x7f,0xfc,0x00,0x00,0x00,0x00,0x00,0x00, /* �� */
	},
	{
		0x00,0x00,0x00,0x00,0x00,0x00,0x7f,0xfc,
		0x7f,0xfc,0x3f,0xf8,0x1f,0xf0,0x1f,0xf0,
		0x0f,0xe0,0x07,0xc0,0x07,0xc0,0x03,0x80,
		0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00, /* �� */
	},
	{
		0x00,0x00,0x00,0x04,0x00,0x1c,0x00,0x7c,
		0x01,0xfc,0x07,0xfc,0x1f,0xfc,0x7f,0xfc,
		0x1f,0xfc,0x07,0xfc,0x01,0xfc,0x00,0x7c,
		0x00,0x1c,0x00,0x04,0x00,0x00,0x00,0x00, /* �� */
	},
	{
		0x00,0x00,0x10,0x00,0x1c,0x00,0x1f,0x00,
		0x1f,0xc0,0x1f,0xf0,0x1f,0xfc,0x1f,0xff,
		0x1f,0xfc,0x1f,0xf0,0x1f,0xc0,0x1f,0x00,
		0x1c,0x00,0x10,0x00,0x00,0x00,0x00,0x00, /* �� */
	},
	{
		0x00,0x00,0x03,0xc0,0x0f,0xf0,0x1f,0xf8,
		0x3f,0xfc,0x3f,0xfc,0x7f,0xfe,0x7f,0xfe,
		0x7f,0xfe,0x7f,0xfe,0x3f,0xfc,0x3f,0xfc,
		0x1f,0xf8,0x0f,0xf0,0x03,0xc0,0x00,0x00, /* �� */
	},
};

/********************************************/
/*	Font Make								*/
/********************************************/
extern	unsigned char *GetZenkakuFont(unsigned char *buff);
void	DotWriteFont2(int x,int y,unsigned char *addr,int back, int xbai, int ybai, int mode, int mitudo)
{



#ifdef	WIN32
	unsigned char	*FontPos;
	int		i;
	int		XCurPos;
	int		ret;
	int		idx;

	XCurPos = 0;
	for(i = 0; ; i++){
		if(addr[i] == 0){
			break;
		}
		if(addr[i] < 0x80){					/* ���p���� */
			idx= addr[i];
			if(idx < 0x20){					/* �R���g���[���R�[�h */
				//if(Set.LanguageCode== VIECODE){ //2012.08.18 Jm.Son			//del	2012.08.23 user symbol modify
						//VISCII �ڵ�� ��Ʈ�� ������ ���ڸ� ����Ѵ�. 
						FontPos = (unsigned char *)GetZenkakuFont((unsigned char *)&addr[i]);
				//	}else{														//del	2012.08.23 user symbol modify
				//		FontPos= (unsigned char *)&BlackFont[0];				//del	2012.08.23 user symbol modify
				//	}															//del	2012.08.23 user symbol modify
			}else{
				idx -= 0x20;
				if(xbai == 0){								/* 6(x)*8(y) */
					FontPos = (unsigned char *)&GpFont[FONT_ASCII68+ idx*8];
				}else if((xbai == 1) && (ybai == 0)){		/* 8(x)*8(y) */
					FontPos = (unsigned char *)&GpFont[FONT_ASCII88+ idx*8];
				}else{										/* 8(x)*16(y) */
					FontPos = (unsigned char *)&GpFont[FONT_ASCII816+ idx*16];
				}
			}
			if(TateYoko == 0){
				if(addr[0]==0x10){																	//	2012.08.23 user symbol modify
					ret = DotWriteFont0(1,x+XCurPos,y,FontPos,back,xbai,ybai,mode,idx,mitudo);		//	2012.08.23 user symbol modify
					i++;																			//  2012.08.23 user symbol modify
				}else{																				//	2012.08.23 user symbol modify
					ret = DotWriteFont0(0,x+XCurPos,y,FontPos,back,xbai,ybai,mode,idx,mitudo);		//	2012.08.23 user symbol modify
				}																					//	2012.08.23 user symbol modify
			}else{
					ret = DotWriteFont0(0,y,(GAMEN_Y_SIZE- x)-XCurPos,FontPos,back,xbai,ybai,mode,idx,mitudo);
			}
			if(ret < 0){
				return;
			}
			XCurPos += ret;
		}else{						/* �S�p���� */
			if(xbai == 0){			/* 6*8 */
				FontPos = (unsigned char *)BlackFont;
			}else{
				FontPos = (unsigned char *)GetZenkakuFont((unsigned char *)&addr[i]);
			}

			if(TateYoko == 0){
//20100906
//20101118
				if((Set.LanguageCode == RUSCODE) || (Set.LanguageCode == VIECODE)||(Set.LanguageCode == PORCODE)){ // 2012.08.09 Jm.Son
				
					if((addr[i+1] >= 0x01) && (addr[i+1] <= 0x0F)){  
						ret = DotWriteFont0(1,x+XCurPos,y,FontPos,back,xbai,ybai,mode,0,0);
						i++;
					}else{
						ret = DotWriteFont0(0,x+XCurPos,y,FontPos,back,xbai,ybai,mode,idx,mitudo);
					}
				}else{
					ret = DotWriteFont0(1,x+XCurPos,y,FontPos,back,xbai,ybai,mode,0,0);
					i++;
				}

			}else{

				if((Set.LanguageCode == RUSCODE) || (Set.LanguageCode == VIECODE)||(Set.LanguageCode ==PORCODE)){// 2012.08.09 Jm.Son
					if((addr[i+1] >= 0x01) && (addr[i+1] <= 0x0F)){
						ret = DotWriteFont0(1,y,(GAMEN_Y_SIZE- x)-XCurPos,FontPos,back,xbai,ybai,mode,0,0);
						i++;
					}else{
						ret = DotWriteFont0(0,y,(GAMEN_Y_SIZE- x)-XCurPos,FontPos,back,xbai,ybai,mode,idx,mitudo);
					}
				}else{
					ret = DotWriteFont0(1,y,(GAMEN_Y_SIZE- x)-XCurPos,FontPos,back,xbai,ybai,mode,0,0);
					i++;
				}
			}

			if(ret < 0){
				return;
			}
			XCurPos += ret;
		}
	}
#else
	unsigned char	*FontPos;
	int		i;
/*	unsigned short code;*/
	int		XCurPos;
	int		ret;
	int		idx;

	XCurPos = 0;
	for(i = 0; ; i++){
		if(addr[i] == 0){
			break;
		}
		if(addr[i] < 0x80){					/* ���p���� */
			idx= addr[i];
			if(idx < 0x20){
				//if(Set.LanguageCode== VIECODE){											//del	2012.08.23 user symbol modify
					FontPos = (unsigned char *)GetZenkakuFont((unsigned char *)&addr[i]);	
				//}else{																	//del	2012.08.23 user symbol modify
				//	FontPos= (unsigned char *)&BlackFont[0];								//del	2012.08.23 user symbol modify
				//}																			//del	2012.08.23 user symbol modify
			}else{
				idx -= 0x20;
				if(xbai == 0){								/* 6(x)*8(y) */
					FontPos = (unsigned char *)(FONT_ASCII68+ idx*8);
				}else if((xbai == 1) && (ybai == 0)){		/* 8(x)*8(y) */
					FontPos = (unsigned char *)(FONT_ASCII88+ idx*8);
				}else{										/* 8(x)*16(y) */
					FontPos = (unsigned char *)(FONT_ASCII816+ idx*16);
				}
			}
			if(TateYoko == 0){
				if(addr[0]==0x10){																	//	2012.08.23 user symbol modify
					ret = DotWriteFont0(1,x+XCurPos,y,FontPos,back,xbai,ybai,mode,idx,mitudo);		//	2012.08.23 user symbol modify
					i++;																			//  2012.08.23 user symbol modify
				}else{																				//	2012.08.23 user symbol modify
					ret = DotWriteFont0(0,x+XCurPos,y,FontPos,back,xbai,ybai,mode,idx,mitudo);		//	2012.08.23 user symbol modify
				}																					//	2012.08.23 user symbol modify
			}else{
				ret = DotWriteFont0(0,y,(GAMEN_Y_SIZE- x)-XCurPos,FontPos,back,xbai,ybai,mode,idx,mitudo);
			}
			if(ret < 0){
				return;
			}
			XCurPos += ret;
		}else{						/* �S�p���� */
			if(xbai == 0){			/* 6*8 */
				FontPos = (unsigned char *)BlackFont;
			}else{
				FontPos = (unsigned char *)GetZenkakuFont((unsigned char *)&addr[i]);
			}

//			if(TateYoko == 0){
//				ret = DotWriteFont0(1,x+XCurPos,y,FontPos,back,xbai,ybai,mode,0,0);
//			}else{
//				ret = DotWriteFont0(1,y,(GAMEN_Y_SIZE- x)-XCurPos,FontPos,back,xbai,ybai,mode,0,0);
//			}


			if(TateYoko == 0){
//20100906
//20101118
				if((Set.LanguageCode == RUSCODE) || (Set.LanguageCode == VIECODE)||(Set.LanguageCode ==PORCODE)){
					if((addr[i+1] >= 0x01) && (addr[i+1] <= 0x0F)){
						ret = DotWriteFont0(1,x+XCurPos,y,FontPos,back,xbai,ybai,mode,0,0);
						i++;
					}else{
						ret = DotWriteFont0(0,x+XCurPos,y,FontPos,back,xbai,ybai,mode,idx,mitudo);
					}
				}else{
					ret = DotWriteFont0(1,x+XCurPos,y,FontPos,back,xbai,ybai,mode,0,0);
					i++;
				}
			}else{

				if((Set.LanguageCode == RUSCODE) || (Set.LanguageCode == VIECODE)||(Set.LanguageCode ==PORCODE)){
					if((addr[i+1] >= 0x01) && (addr[i+1] <= 0x0F)){
					ret = DotWriteFont0(1,y,(GAMEN_Y_SIZE- x)-XCurPos,FontPos,back,xbai,ybai,mode,0,0);
					i++;
					}else{
						ret = DotWriteFont0(0,y,(GAMEN_Y_SIZE- x)-XCurPos,FontPos,back,xbai,ybai,mode,idx,mitudo);
					}
				}else{
					ret = DotWriteFont0(1,y,(GAMEN_Y_SIZE- x)-XCurPos,FontPos,back,xbai,ybai,mode,0,0);
					i++;
				}
			}



			if(ret < 0){
				return;
			}
			XCurPos += ret;
		}
	}
#endif


}
void	DotWriteFont(int x,int y,unsigned char *addr,int back, int xbai, int ybai, int mode)
{
	DotWriteFont2(x,y,addr,back,xbai,ybai,mode,0);
}
void	PaintPatarn1Line(int sx,int ex,int y,int Paint,int Fcolor,int Bcolor,int mode)
{
	int		j;
	int		AndBit;
	int		*PatarnAddr;
	int		ForeBit;
	int		BackBit;
	int		dAndBit;
	int		idx;
	int		pidx;
	int		fColIdx;
	int		bColIdx;
	unsigned char	*LcdPos;
	int	WinNo;
	int		sxx,yy,eyy;

	WinNo= TaskWindowNo[_RunTaskNo];
	if(Fcolor != 0){
		fColIdx= T_WHITE;
	}else{
		fColIdx= T_BLACK;
	}
	if(Bcolor != 0){
		bColIdx= T_WHITE;
	}else{
		bColIdx= T_BLACK;
	}
	if(TateYoko == 0){
		sxx= sx;
		yy= y;
	}else{
		sxx= y;
		yy= (GAMEN_Y_SIZE-1)- sx;
		eyy= (GAMEN_Y_SIZE-1)- ex;
		if(yy < eyy){
			eyy= (GAMEN_Y_SIZE-1)- sx;
			yy= (GAMEN_Y_SIZE-1)- ex;
		}
	}
	if((TateYoko == 0) || (mode == 0)){
		AndBit= 0x80 >> (sx % 8);
		PatarnAddr= (int *)&PaintPatarn[Paint][y% 8];
		LcdPos= (unsigned char *)&LcdBuff[WinNo][y][sx/8];
		/* �O�̃p�^�[�� */
		for(j = sx; j <= ex; j++){
			idx= j % 8;
			ForeBit= ForColTabl[fColIdx][idx];
			BackBit= ForColTabl[bColIdx][idx];
			dAndBit= AndBitTabl[idx];
			if((j != sx) && (idx == 0)){
				break;
			}
			*LcdPos &= dAndBit;
			if((*PatarnAddr & AndBit) != 0){
				*LcdPos |= ForeBit;
			}else{
				*LcdPos |= BackBit;
			}
			AndBit= AndBit >> 1;
			if(AndBit == 0){
				AndBit= 0x80;
			}
		}
		/* ���ԃp�^�[�� */
		LcdPos++;
		for(; j+7 <= ex; j += 8){
			if(Fcolor != 0){
				if(Bcolor != 0){
					*LcdPos = 0xff;
				}else{
					*LcdPos = *PatarnAddr;
				}
			}else{
				if(Bcolor != 0){
					*LcdPos = ~*PatarnAddr;
				}else{
					*LcdPos = 0;
				}
			}
			LcdPos++;
		}
		/* ��̃p�^�[�� */
		for(; j <= ex; j++){
			idx= j % 8;
			ForeBit= ForColTabl[fColIdx][idx];
			BackBit= ForColTabl[bColIdx][idx];
			dAndBit= AndBitTabl[idx];
			*LcdPos &= dAndBit;
			if((*PatarnAddr & AndBit) != 0){
				*LcdPos |= ForeBit;
			}else{
				*LcdPos |= BackBit;
			}
			AndBit= AndBit >> 1;
			if(AndBit == 0){
				AndBit= 0x80;
			}
		}
	}else{
		LcdPos= (unsigned char *)&LcdBuff[WinNo][yy][sxx/8];
		AndBit= 0x80 >> (sx % 8);
		idx= sxx % 8;
		dAndBit= AndBitTabl[idx];
		pidx= y % 8;
		PatarnAddr= (int *)&PaintPatarn[Paint][pidx];
		/* �O�̃p�^�[�� */
		for(j = sx; j <= ex; j++){
			ForeBit= ForColTabl[fColIdx][idx];
			BackBit= ForColTabl[bColIdx][idx];
			*LcdPos &= dAndBit;
			if((*PatarnAddr & AndBit) != 0){
				*LcdPos |= ForeBit;
			}else{
				*LcdPos |= BackBit;
			}
			AndBit= AndBit >> 1;
			if(AndBit == 0){
				AndBit= 0x80;
			}
			LcdPos -= GAMEN_X_SIZE/8;
		}
	}
}
/*************************************************
*   FUNC   : Put Image Memory                    *
*	In     : 									 *
*	Out    : 									 *
*   AUTHOR :                                     *
*   DATE   : 1996.11.7                           *
**************************************************/
void	PutImage( int ssx, int ssy, int eex, int eey, char *pScrBuff)
{
    int     x;
    int     y;
	int		idx;
	unsigned char data;
	unsigned char* Pos;
	unsigned char* pMem;
	int	WinNo;
	int		lenX;
	int		lenY;
	char *ScrBuff;
	char *mp;
	int sx, sy, ex, ey;

	WinNo= TaskWindowNo[_RunTaskNo];
	FrontColor= T_WHITE;
	BackColor= T_BLACK;
	if(TateYoko == 0){
		ScrBuff= pScrBuff;
		sx= ssx;
		sy= ssy;
		ex= eex;
		ey= eey;
	}else{		/* Tate->Yoko */
		lenX= eex- ssx+ 1;
		if((lenX % 8) == 0){
			lenX /= 8;
		}else{
			lenX = lenX / 8 + 1;
		}
		lenY= eey- ssy+ 1;
		if((lenY % 8) == 0){
			lenY /= 8;
		}else{
			lenY = lenY / 8 + 1;
		}
		mp= (char *)TakeMemory(lenY*lenX*8);
		ChangeTateYoko((unsigned char *)mp,(unsigned char *)pScrBuff,lenX*8,lenY*8);
		ScrBuff= mp+ (8- ((eex- ssx+ 1) % 8))* lenY;
		sx= ssy;
		sy= (GAMEN_Y_SIZE-1)- ssx;
		ex= eey;
		ey= (GAMEN_Y_SIZE-1)- eex;
		if(sx > ex){
			sx= eey;
			ex= ssy;
		}
		if(sy > ey){
			sy= (GAMEN_Y_SIZE-1)- eex;
			ey= (GAMEN_Y_SIZE-1)- ssx;
		}
	}
	SetDispSema();
    for( y= sy; y <= ey; y++ ) {
        Pos= ((unsigned char*)ScrBuff) + ( y - sy ) * ( (ex - sx) / 8 + 1 );
        x= sx;
        pMem= (unsigned char *)&LcdBuff[WinNo][y][x/8];
		idx= x & 0x07;
		if(sx/8 != ex/8){
			if(idx != 0){
				*pMem= (*pMem & ~HanAndPatern1[idx]) | (*Pos >> idx);
				x= (sx/8+1) * 8;
				pMem++;
				while( x + 7 <= ex ) {
					data= *Pos << (8- idx);
					Pos++;
					*pMem= data | (*Pos >> idx);
					pMem++;
					x += 8;
				}
				if( x <= ex ) {
					data= *Pos << (8- idx);
					Pos++;
					data= data | (*Pos >> idx);
					idx= ex & 0x07;
					*pMem= (*pMem & ~HanAndPatern0[idx]) | (data & HanAndPatern0[idx]);
				}
			}else{
				while( x + 7 <= ex ) {
					*pMem= *Pos;
					pMem++;
					Pos++;
					x += 8;
				}
				if( x <= ex ) {
					idx= ex & 0x07;
					*pMem= (*pMem & ~HanAndPatern0[idx]) | (*Pos & HanAndPatern0[idx]);
				}
			}
		}else{
            while( ( x & 0x07 ) != 0 && x <= ex ) {
              *pMem= *pMem & MaskPat[x&0x07] | *Pos & ~MaskPat[x&0x07];
              x++;
            }
		}
    }
	if(TateYoko != 0){
		FreeMail((char *)mp);
	}
	ResetDispSema();
}
/*************************************************
*   FUNC   : Put Image Memory                    *
*	In     : 									 *
*	Out    : 									 *
*   AUTHOR :                                     *
*   DATE   : 1996.11.7                           *
**************************************************/
void	PutImageGp( int ssx, int ssy, int eex, int eey, char *pScrBuff)
{
    int     x;
    int     y;
	int		idx;
	unsigned char data;
	unsigned char AndData;

	int		Cnt;
	unsigned char* Pos;
	unsigned char* pMem;
	int	WinNo;
	char *ScrBuff;
	int sx, sy, ex, ey;

	WinNo= TaskWindowNo[_RunTaskNo];
	FrontColor= T_WHITE;
	BackColor= T_BLACK;
	Cnt= (eex - ssx + 1) / 8;
	if((eex - ssx + 1) % 8){
		Cnt++;
	}
	if(Cnt % 4){
		Cnt=((Cnt / 4)+1)*4;
	}
	ScrBuff= pScrBuff;
	SetDispSema();
	if(TateYoko == 0){
		sx= ssx;
		sy= ssy;
		ex= eex;
		ey= eey;
		for( y= ey; y >= sy; y-- ) {
			Pos= ((unsigned char*)ScrBuff) + ( ey - y ) * Cnt;
			x= sx;
			pMem= (unsigned char *)&LcdBuff[WinNo][y][x/8];
			idx= x & 0x07;
			if(sx/8 != ex/8){
				if(idx != 0){
					*pMem= (*pMem & ~HanAndPatern1[idx]) | (*Pos >> idx);
					x= (sx/8+1) * 8;
					pMem++;
					while( x + 7 <= ex ) {
						data= *Pos << (8- idx);
						Pos++;
						*pMem= data | (*Pos >> idx);
						pMem++;
						x += 8;
					}
					if( x <= ex ) {
						data= *Pos << (8- idx);
						Pos++;
						data= data | (*Pos >> idx);
						idx= ex & 0x07;
						*pMem= (*pMem & ~HanAndPatern0[idx]) | (data & HanAndPatern0[idx]);
					}
				}else{
					while( x + 7 <= ex ) {
						*pMem= *Pos;
						pMem++;
						Pos++;
						x += 8;
					}
					if( x <= ex ) {
						idx= ex & 0x07;
						*pMem= (*pMem & ~HanAndPatern0[idx]) | (*Pos & HanAndPatern0[idx]);
					}
				}
			}else{
	/*			while( ( x & 0x07 ) != 0 && x <= ex ) {*/
				while( x <= ex ) {
				  *pMem= *pMem & MaskPat[x&0x07] | *Pos & ~MaskPat[x&0x07];
				  x++;
				}
			}
		}
	}else{				/* TATE */
		sx= ssy;
		sy= (GAMEN_Y_SIZE-1)- ssx;
		ex= eey;
		ey= (GAMEN_Y_SIZE-1)- eex;
		if(sx > ex){
			sx= eey;
			ex= ssy;
		}
		if(sy > ey){
			sy= (GAMEN_Y_SIZE-1)- eex;
			ey= (GAMEN_Y_SIZE-1)- ssx;
		}
		/* 0->40 */
		for(y= sx; y <= ex; y++){
			Pos= ((unsigned char*)ScrBuff) + ( ex - y ) * Cnt;
			AndData= 0x80;
			idx= y & 0x07;
			/*79->36 */
			for( x= ey; x >= sy; x-- ) {
				pMem= (unsigned char *)&LcdBuff[WinNo][x][y/8];
				*pMem= *pMem & MaskPat[idx];
				if(*Pos & AndData){
					*pMem= *pMem | MaskPat1[idx];
				}
				AndData = AndData >> 1;
				if(AndData == 0){
					Pos++;
					AndData= 0x80;
				}
			}
		}
	}
	ResetDispSema();
}
/*************************************************
*   FUNC   : Get Image Memory                    *
*	In     : 									 *
*	Out    : 									 *
*   AUTHOR :                                     *
*   DATE   : 1996.11.7                           *
**************************************************/
void	GetImage( int sx, int sy, int ex, int ey, char *ScrBuff)
{
	int		i,j;
	int		cnt_x,cnt_y;
	int		start_x;
	int		end_x;
	unsigned char	*g_adr;
	unsigned char	*pos;
	int	WinNo;

	WinNo= TaskWindowNo[_RunTaskNo];
	pos = (unsigned char *)ScrBuff;		/* Unsigned Short Change */
	start_x = sx / 8;				/* X-Start Addr (4 Bit unit) */
	end_x = ex / 8;
	cnt_x = end_x - start_x + 1;	/* X-Dir Byte Count */
	cnt_y = ey - sy + 1;
	for(i = 0; i < cnt_y; i++){
		g_adr = (unsigned char *)&LcdBuff[WinNo][sy + i][0];	/* Y Dir Memory Addr */
		for(j = 0; j < cnt_x; j++){
			pos[i * cnt_x + j] = g_adr[start_x + j];
		}
	}
}
/****************************************************
*  Draw Dot											*
*													*
*****************************************************/
void	Dot(int	x, int y, int Pattern)
{
	int     BitAdr;
	int		MaskBit;
	int		xx,yy;
	unsigned char DrawPat;
	int	WinNo;

	WinNo= TaskWindowNo[_RunTaskNo];
	if(TateYoko == 0){
		xx= x;
		yy= y;
	}else{
		xx= y;
		yy= (GAMEN_Y_SIZE-1)- x;
	}
	if((xx < 0) || (xx > GAMEN_X_SIZE-1)){
		return;
	}
	if((yy < 0) || (yy > (GAMEN_Y_SIZE-1))){
		return;
	}
	if(yy < minY){
		minY= yy;
	}
	if(yy > maxY){
		maxY= yy;
	}
	pGraphicMemory= (unsigned char *)&LcdBuff[WinNo][yy][xx/8];
    BitAdr= xx%8;
	DrawPat= (unsigned char)ForColTabl[DrawColor][BitAdr];
    MaskBit= MaskPat[BitAdr];
    *pGraphicMemory= 
		(unsigned char)(*pGraphicMemory & MaskBit | DrawPat);
}
void	AreaClear(int ssx,int ssy,int eex,int eey,int back)
{
	int		i,j,k,cnt;
	int		sx,sy,ex,ey;
	unsigned char *LcdPos;
	int	WinNo;

	if(TateYoko == 0){
		sx= ssx;
		sy= ssy;
		ex= eex;
		ey= eey;
	}else{
		sx= ssy;
		sy= (GAMEN_Y_SIZE-1)- ssx;
		ex= eey;
		ey= (GAMEN_Y_SIZE-1)- eex;
	}
	if(sx > ex){
		i= sx;
		sx= ex;
		ex= i;
	}
	if(sy > ey){
		i= sy;
		sy= ey;
		ey= i;
	}
	WinNo= TaskWindowNo[_RunTaskNo];
	SetDispSema();
	for(i = sy; i <= ey && i < GAMEN_Y_SIZE; i++){
		k = sx;
		cnt = sx % 8;
		LcdPos= (unsigned char *)&LcdBuff[WinNo][i][k/8];
		if(back == 0){
			if((ex- sx+ 1) > (8- cnt)){
				*LcdPos= *LcdPos & ClearPatarn[cnt];
				k= (sx / 8 + 1)* 8;
				LcdPos= (unsigned char *)&LcdBuff[WinNo][i][k/8];
				for(j = k/ 8; j < ex/ 8; j++, k+= 8){
					*LcdPos = 0;
					LcdPos++;
				}
				if(k <= ex){
					cnt = ex % 8;
					LcdPos= (unsigned char *)&LcdBuff[WinNo][i][ex/8];
					*LcdPos= *LcdPos & ClearPatarn1[0][cnt];
				}
			}else{

				*LcdPos= *LcdPos & ClearPatarn1[cnt][ex- sx];
			}
		}else{
			if((ex- sx+ 1) > (8- cnt)){
				*LcdPos= *LcdPos | ~ClearPatarn[cnt];
				k= (sx / 8 + 1)* 8;
				LcdPos= (unsigned char *)&LcdBuff[WinNo][i][k/8];
				for(j = k/ 8; j < ex/ 8; j++, k+= 8){
					*LcdPos = 0xff;
					LcdPos++;
				}
				if(k <= ex){
					cnt = ex % 8;
					LcdPos= (unsigned char *)&LcdBuff[WinNo][i][ex/8];
					*LcdPos= *LcdPos | ~ClearPatarn1[0][cnt];
				}
			}else{

				*LcdPos= *LcdPos | ~ClearPatarn1[cnt][ex- sx];
			}
		}
	}
	ResetDispSema();
}
void	AreaRevers(int ssx,int ssy,int eex,int eey)
{
	int		i,j,k,cnt;
	int		sx,sy,ex,ey;
	unsigned char *LcdPos;
	unsigned char	data1;
	int	WinNo;


	if(TateYoko == 0){
		sx= ssx;
		sy= ssy;
		ex= eex;
		ey= eey;
	}else{
		sx= ssy;
		sy= (GAMEN_Y_SIZE-1)- ssx;
		ex= eey;
		ey= (GAMEN_Y_SIZE-1)- eex;
		if(ex < sx){
			sx= eey;
			ex= ssy;
		}
		if(ey < sy){
			sy= (GAMEN_Y_SIZE-1)- eex;
			ey= (GAMEN_Y_SIZE-1)- ssx;
		}
	}
	WinNo= TaskWindowNo[_RunTaskNo];
	SetDispSema();
	for(i = sy; i <= ey && i < GAMEN_Y_SIZE; i++){
		k = sx;
		cnt = sx % 8;
		LcdPos= (unsigned char *)&LcdBuff[WinNo][i][k/8];
		if((ex- sx+ 1) > (8- cnt)){
			data1= *LcdPos & ClearPatarn[cnt];
			*LcdPos= (~(*LcdPos & ~ClearPatarn[cnt]) & ~ClearPatarn[cnt]) | data1;
			k= (sx / 8 + 1)* 8;
			LcdPos= (unsigned char *)&LcdBuff[WinNo][i][k/8];
			for(j = k/ 8; j < ex/ 8; j++, k+= 8){
				*LcdPos = ~*LcdPos;
				LcdPos++;
			}
			if(k <= ex){
				cnt = ex % 8;
				LcdPos= (unsigned char *)&LcdBuff[WinNo][i][ex/8];
				data1= *LcdPos & ClearPatarn1[0][cnt];
				*LcdPos= (~(*LcdPos & ~ClearPatarn1[0][cnt]) & ~ClearPatarn1[0][cnt]) | data1;
			}
		}else{
			data1= ~(*LcdPos & ~ClearPatarn1[cnt][ex- sx]) & ~ClearPatarn1[cnt][ex- sx];
			*LcdPos= (*LcdPos & ClearPatarn1[cnt][ex- sx]) | data1;
		}
	}
	ResetDispSema();
}
/************************************************/
/*	Window Move									*/
/************************************************/
void	PutWindow( int sx, int sy, int ex, int ey,int no,int Start,LCD_BUF *lcdb)
{
	int		i;
    int     x;
    int     y;
	int		idx;
	unsigned char data;

	unsigned char* Pos;
	unsigned char* pMem;

    for( y= sy,i= Start; y <= ey; y++, i++ ) {
        Pos= (unsigned char *)&LcdBuff[no][i][0];
        x= sx;
        pMem= (unsigned char *)&lcdb->lbuff[y][x/8];
		idx= x & 0x07;
		if(sx/8 != ex/8){
			if(idx != 0){
				*pMem= *pMem | (*Pos >> idx);
				x= (sx/8+1) * 8;
				pMem++;
				while( x + 7 <= ex ) {
					data= *Pos << (8- idx);
					Pos++;
					*pMem |= data | (*Pos >> idx);
					pMem++;
					x += 8;
				}
				if( x <= ex ) {
					data= *Pos << (8- idx);
					Pos++;
					data= data | (*Pos >> idx);
					idx= ex & 0x07;
					*pMem= *pMem | (data & HanAndPatern0[idx]);
				}
			}else{
				while( x + 7 <= ex ) {
					*pMem |= *Pos;
					pMem++;
					Pos++;
					x += 8;
				}
				if( x <= ex ) {
					idx= ex & 0x07;
					*pMem= *pMem | (*Pos & HanAndPatern0[idx]);
				}
			}
		}else{
            while( ( x & 0x07 ) != 0 && x <= ex ) {
              *pMem= *pMem | (*Pos & ~MaskPat[x&0x07]);
              x++;
            }
		}
    }
}
//2011.09.19 Add/////////////////////////////////////////////////
void	PutWindowRev( int sx, int sy, int ex, int ey,int no,int Start,LCD_BUF *lcdb)
{
	int		i;
    int     x;
    int     y;
	int		idx;
	unsigned char data;

	unsigned char* Pos;
	unsigned char* pMem;

    for( y= sy,i= Start; y <= ey; y++, i++ ) {
        Pos= (unsigned char *)&LcdBuff[no][i][0];
        x= sx;
        pMem= (unsigned char *)&lcdb->lbuff[y][x/8];
		idx= x & 0x07;
		if(sx/8 != ex/8){
			if(idx != 0){
//				*pMem= *pMem | (*Pos >> idx);
				*pMem= *pMem & ~(*Pos >> idx);
				x= (sx/8+1) * 8;
				pMem++;
				while( x + 7 <= ex ) {
					data= *Pos << (8- idx);
					Pos++;
//					*pMem |= data | (*Pos >> idx);
					*pMem &= ~(data | (*Pos >> idx));
					pMem++;
					x += 8;
				}
				if( x <= ex ) {
					data= *Pos << (8- idx);
					Pos++;
					data= data | (*Pos >> idx);
					idx= ex & 0x07;
//					*pMem= *pMem | (data & HanAndPatern0[idx]);
					*pMem= *pMem & ~(data & HanAndPatern0[idx]);
				}
			}else{
				while( x + 7 <= ex ) {
//					*pMem |= *Pos;
					*pMem &= ~*Pos;
					pMem++;
					Pos++;
					x += 8;
				}
				if( x <= ex ) {
					idx= ex & 0x07;
//					*pMem= *pMem | (*Pos & HanAndPatern0[idx]);
					*pMem= *pMem & ~(*Pos & HanAndPatern0[idx]);
				}
			}
		}else{
            while( ( x & 0x07 ) != 0 && x <= ex ) {
//              *pMem= *pMem | (*Pos & ~MaskPat[x&0x07]);
              *pMem= *pMem & ~(*Pos & ~MaskPat[x&0x07]);
              x++;
            }
		}
    }
}
/////////////////////////////////////////////////////////////////////
void	PutWindowReplace( int sx, int sy, int ex, int ey,int no,int Start,LCD_BUF *lcdb)
{
	int		i;
    int     x;
    int     y;
	int		idx;
	unsigned char data;

	unsigned char* Pos;
	unsigned char* pMem;

    for( y= sy,i= Start; y <= ey; y++, i++ ) {
        Pos= (unsigned char *)&LcdBuff[no][i][0];
        x= sx;
        pMem= (unsigned char *)&lcdb->lbuff[y][x/8];
		idx= x & 0x07;
		if(sx/8 != ex/8){
			if(idx != 0){
				*pMem= (*pMem & HanAndPatern2[idx]) | ((*Pos >> idx) & HanAndPatern1[idx]);
				x= (sx/8+1) * 8;
				pMem++;
				while( x + 7 <= ex ) {
					data= *Pos << (8- idx);
					Pos++;
					*pMem = data | (*Pos >> idx);
					pMem++;
					x += 8;
				}
				if( x <= ex ) {
					data= *Pos << (8- idx);
					Pos++;
					data= data | (*Pos >> idx);
					idx= ex & 0x07;
					*pMem= (*pMem & ~HanAndPatern0[idx]) | (data & HanAndPatern0[idx]);
				}
			}else{
				while( x + 7 <= ex ) {
					*pMem = *Pos;
					pMem++;
					Pos++;
					x += 8;
				}
				if( x <= ex ) {
					idx= ex & 0x07;
					*pMem= (*pMem & ~HanAndPatern0[idx]) | (*Pos & HanAndPatern0[idx]);
				}
			}
		}else{
            while( ( x & 0x07 ) != 0 && x <= ex ) {
              *pMem= *pMem | (*Pos & ~MaskPat[x&0x07]);
              x++;
            }
		}
    }
}
/************************************************/
/*	Window Move									*/
/************************************************/
void	DrawLcdBank1(void)
{
	int		i;
	int		ex,ey;
	int		pos;		/* 060926 */
	LCD_BUF*	LcdBufAddr;
	unsigned int	*srcData;
	unsigned int	*objData;
#ifndef	WIN32
	#ifdef	GP_S057
//		int		j;
	#endif
#endif
	int		iBackColor;			//2011.09.19

	SetDispSema();
	memcpy((char *)&LcdBuff[0][0][0],(char *)&LcdBuff[1],sizeof(LcdBuff[0]));
	LcdBufAddr= (LCD_BUF *)&LcdBuff[0];
	for(i= 0; i < 3; i++){
		if(wWidth[i+ 2] > 0){		/* Window1�`4 */
			if((wDspX[i+ 2]+ wWidth[i+ 2]) > GAMEN_X_SIZE-1){
				ex= GAMEN_X_SIZE-1;
			}else{
				ex= wDspX[i+ 2]+ wWidth[i+ 2];
			}
			if((wDspY[i+ 2]+ wHight[i+ 2]) > (GAMEN_Y_SIZE-1)){
				ey= (GAMEN_Y_SIZE-1);
			}else{
				ey= wDspY[i+ 2]+ wHight[i+ 2];
			}
			if(WindowInfo[i+ 2] == 0){		/* AND */
				if(TateYoko == 0){
					PutWindowReplace(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,0,LcdBufAddr);
				}else{
/* 060926					PutWindowReplace(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,wDspY[i+ 2],LcdBufAddr);*/
					pos= wDspY[i+ 2]+ (GAMEN_Y_SIZE- wDspY[i+ 2]- wHight[i+ 2]- 1);		/* 060926 */
					if(pos < 0){
						pos= 0;
					}
					PutWindowReplace(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,pos,LcdBufAddr);
				}
			}else{							/* OR */
				iBackColor= NowBackColor(1);			//2011.09.19
				if( (iBackColor == WHITE) && ((i+ 2) == MSG_WINDOW) ){
					if(TateYoko == 0){
						PutWindowRev(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,0,LcdBufAddr);
					}else{
						PutWindowRev(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,wDspY[i+ 2],LcdBufAddr);
					}
				}else{
					if(TateYoko == 0){
						PutWindow(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,0,LcdBufAddr);
					}else{
						PutWindow(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,wDspY[i+ 2],LcdBufAddr);
					}
				}
			}
		}
	}
#ifndef	WIN32
	if(Set.LcdReverseOn == 0){
/* ȭ�� ǥ�� 3224�� 2480�� �ݴ�� �Ǿ� �ִ� �κ� ����ġ ��Ŵ.
	#ifdef	GP_S057
		objData= (unsigned int *)BaseLcd_Buffer;
		for(i= 0; i < GAMEN_Y_SIZE; i++){
			memcpy(objData,&LcdBuff[0][i][20],20);
			objData += 5;
			memcpy(objData,&LcdBuff[0][i][0],20);
			objData += 5;
		}
	#endif
	#ifdef	LP_S044
*/
		memcpy((char *)BaseLcd_Buffer,(char *)&LcdBuff[0],sizeof(LcdBuff[0]));
/*	#endif
*/
	}else{
		srcData= (unsigned int *)&LcdBuff[0][0][0];
		objData= (unsigned int *)BaseLcd_Buffer;
/*
	#ifdef	GP_S057
		for(i= 0; i < GAMEN_Y_SIZE; i++){
			srcData= (unsigned int *)&LcdBuff[0][i][20];
			for(j= 0; j < 5; j++){
				*objData++= ~*srcData++;
			}
			srcData= (unsigned int *)&LcdBuff[0][i][0];
			for(j= 0; j < 5; j++){
				*objData++= ~*srcData++;
			}
		}
	#endif
	#ifdef	LP_S044
*/
		for(i= 0; i < sizeof(LcdBuff[0])/4; i++){
			*objData++= ~*srcData++;
		}
/*
	#endif
*/
	}
#else
	if(Set.LcdReverseOn != 0){
		objData= (unsigned int *)&LcdBuff[0][0][0];
		srcData= (unsigned int *)&LcdBuff[0][0][0];
		for(i= 0; i < sizeof(LcdBuff[0])/4; i++){
			*objData++= ~*srcData++;
		}
	}
#endif
	ResetDispSema();
	DrawLcd((char *)LcdBufAddr);
}
void	ClearDispBuff(int WinNo)
{

	SetDispSema();
	TaskWindowNo[_RunTaskNo]= WinNo;
	DrawColor = 3;		/* Color Data */
	DrawMode= 0;
	FrontColor= T_WHITE;
	BackColor= T_BLACK;
	memset(&LcdBuff[WinNo], 0, sizeof(LcdBuff[WinNo]));
	ResetDispSema();
}
void	ClearDispBuffBackColor(int WinNo,int Color)
{

	SetDispSema();
	TaskWindowNo[_RunTaskNo]= WinNo;
	DrawColor = 3;		/* Color Data */
	DrawMode= 0;
	FrontColor= T_WHITE;
	BackColor= T_BLACK;
	if(Color == 255){
		memset(&LcdBuff[WinNo], 0xff, sizeof(LcdBuff[WinNo]));
	}else{
		memset(&LcdBuff[WinNo], 0, sizeof(LcdBuff[WinNo]));
	}
	ResetDispSema();
}

