void		vTimeSwitch(int* iScreenNo);
void	vTiemSwiDisp(int* iScreenNo);
int		iTImeSwiRegist(char *chChNo, int iStructNo);
void		vTImeSwiRegistDisp(char *chChNo, int iStructNo);
int iTImeSwiRegistSelect(int iStructNo);
int		iNumInput(char* chKey, int iTime, int iStructNo, int iStartEnd);
int		iNumInputSelect(char* chKey, int* iTimeorg, int iStructNo, int iStartEnd);
void		VDateCall(char* chKey, int iTime, int iStructNo, int iStartEnd);
void	SwitchScrenSetting(void);
int iTimeContrast(int iType);

