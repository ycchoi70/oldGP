/*****************************************************************************************/
/*	PLC ����M �v���O��?(AUTONICS)			  */
/*	2006.03.31 			       		  */
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
/*	2006.09.25 */
/*      �����͹� ���ø� ������ ���� ver 2.6�� �ϰ� ����	  */
/*  2007.01.30 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����		*/
/*  2007.10.08 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����	 		*/ 	  
/*****************************************************************************************/

#include	"define.h"
#include	"GpCommon.h"
#include	"PlcCommBuff.h"
#include	"mail.h"

#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include	"hook_plcapl.h"


/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V3.3M"
/*****************************************************************************************/


#define	MAX_RTY_COUNT	3
#define	BDEVICE_CNT		2
#define	WDEVICE_CNT		2


#ifdef	SH_CPU
static	int	GroopSema;			/* Grooping Semafo */
static	int	PlcSendedFlag;
#endif


static	const	DEV_TBL bPLCDeviceTbl[BDEVICE_CNT] = {
	{"TZ" ,0x00,2},
	{"GB" ,    0,4},
};
static	const	DEV_TBL	wPLCDeviceTbl[WDEVICE_CNT] = {
	{"TZ" ,0x00,2},
	{"GB" ,    0,4},
};



unsigned short CRC;
void CRC16( unsigned char Data )		
{		
	int	i;

	CRC = CRC ^ Data;	

	for( i=0; i<8; ++i )	
	{	
		if( CRC & 0x0001 ) CRC = ( CRC>>1 )^0xA001;
		else CRC >>= 1;
	}	
}		

void MakeCRC( unsigned char * CRC_L, unsigned char * CRC_H, unsigned char * String, int StringLen, unsigned short _StartCRC )		
{		
	int i;	

	CRC = _StartCRC;	

	for( i = 1; i < StringLen; ++i )	CRC16( String[i] );

	* CRC_L =  (unsigned char)( CRC      );	
	* CRC_H =  (unsigned char)( CRC >> 8 );	
}		



/*ksc20040707 ������ ������ �����Ѵ� */
#ifdef	SH_CPU
static	const	char	*DevTbl[12]= {
	"P0","S0"
};
#endif

#ifdef	ARM_CPU
static	const	PLC_CONST	DevTbl[12]= {
	{"P0",1},
	{"S0",1},
};
#endif


/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	if(data < 0){			/* - check 041116 */
		
		data *= -1;
		buff[0]= '-';
		for(i= 1; i < cnt+1; i++){								/*cnt+1�̵� ������ */
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}else{
		for(i= 0; i < cnt; i++){
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}
	buff[i]= 0;
}
static int	C_gatoi(char *buff)
{
	char	c;
	int	ret;
	int flag;

	ret= 0;
	flag= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){
			break;
		}
		if((c >= '0') && (c <= '9')){
			ret= ret*10;
			ret+= c- '0';
		}else{
			if(c == '+'){
				continue;
			}
			if(c == '-'){
				flag= 1;
				continue;
			}
			break;
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}
/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef	PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}

/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_9600;
	*DataBit= RS_DATA8;
	*Parity= ((RS_XONOFF << 16) |(RS_STOP01 << 8) | (RS_NONE << 0));		/* 20090527 */	
}
/*********************************/
/*	PLC Semafor			         */
/*********************************/
static	void	GetGroopSema(void)
{
	unsigned int	NowTime;
	unsigned int	StartTime;

	if(GroopSema == 0){		/* Grooping Sema */
	}else{
		StartTime= B_GetNowTime();
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
			NowTime= B_GetNowTime();
			if((StartTime+ 3000) < NowTime){
				GroopSema= 0;
			}
			B_Delay(10);
		}
	}
	GroopSema++;
}
static	void	ResetGroopSema(void)
{
	GroopSema= 0;
}
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
extern	int		SioPLCDlgCommCnt;
extern	int	Sio0OutCnt;

	int	ret;
	
	ret= -1;
#ifdef	OLD
#ifdef	WIN32
	if(SioPLCDlgCommCnt != 0){
		return(ret);
	}
#else
	if(Sio0OutCnt != 0){
		return(ret);
	}
#endif
#endif

	switch(*CommMode){
/*ksc20040707*/
/* ���� ���ŵ� ����Ÿ�� ���� 
 - ��Ʈ���ڵ�	: RecBuff[0], RecBuff[1]�� ACK, STX �Է�
 - ����Ÿ		: RecBuff[2], RecBuff[3]�� ����,
                  RecBuff[4], RecBuff[5]�� RD,
				  RecBuff[6], RecBuff[7], RecBuff[8], RecBuff[9]�� ����Ÿ,
				  RecBuff[10]�� ETX,
 - �����ڵ�		: RecBuff[11]�� FSC, */ 

	case 0:
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*RecCnt= 0;			/* ?���X??�g */
			RecBuff[(*RecCnt)++] = data;
			*CommMode = 1;
			break;
/*ksc20040716*/
		default:
			break;
		}
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		if((data == EOT) || (data == ETX)){
			*CommMode = 2;
		}
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		*CommMode = 0;
		if((B_gstrncmp((char *)&RecBuff[4],"RD",2) == 0) || (B_gstrncmp((char *)&RecBuff[4],"WD",2) == 0) ||
			(((RecBuff[4] >= '0') && (RecBuff[4] <= '9')) && (RecBuff[5] == 'D'))){
			ret= 0;
		}else{
			*RecCnt= 0;			/* ?���X??�g */
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/


/*ksc20040707*/
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
/* char *buff : �۽��ϰ����ϴ� ����Ÿ ����,
   int cnt    : �۽��ϰ����ϴ� ����Ÿ ��,
   unsigned char *OutBuf : CRC���� �ΰ��� �����۽� ����Ÿ */

static	int SetPLCBCC(char *buff,int cnt)
{

/* �ʱⰪ : *buff = 0, 1, R, X, P, 0 */
/*          cnt = 6									*/
/*			*OutBuf = ?									*/	
	unsigned char	CrcL, CrcH;

/*	buff[0] = STX;				/* �۽Ź��� OutBuf[0] = STX */  
/*	for(i = 0; i < cnt; i++){*/
/*		OutBuf[i+1] = buff[i];*/		/* �۽Ź��� OutBuf[1] = ����, OutBuf[2] = ����, OutBuf[3] = R, OutBuf[4] = X,
												OutBuf[5] = P, OutBuf[6] = 0 */								
/*	}*/
/* 	buff[cnt+1] = ETX;				/* �۽Ź���	OutBuf[7] = ETX */

	MakeCRC(&CrcL,&CrcH,(unsigned char*)buff,cnt-1,0xffff);
	buff[cnt+1]= CrcL;
	buff[cnt+2]= CrcH;

	return(cnt + 3);				/* 9�� ���� */

}



/************************************/
/*	PLC Send						*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret,i;
	int		rty_cnt;
	unsigned char _crc8;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen(&combuf[1]));
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
		ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		if(ret == OK){
			_crc8 = 0;
			for(i = 0; i < *Cnt-1; i++){
				_crc8 = (unsigned int)(_crc8 ^ rData[i]); /* CRC ��� �������� ETX */
 			}
			if(_crc8 != rData[*Cnt-1]){
				ret= -1;
			}
		}
		if(ret == OK){
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
		B_Delay(200);
	}
	return(ret);
}
static	int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen(&combuf[1]));
	ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	return(ret);
}
static	int	C_Connection( int *PlcType,int iConnect )
{
	int		ret;
/*ksc20040714*/

	int		Cnt;
	char	buff[32];

	int		Speed;
	int		DataBit;
	int		Parity;

	PlcSendedFlag= 0;
	PlcThruMonDataCnt[0]= 0;
	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PC,RS_INIT,RS_9600,RS_DATA8,RS_NONE); */ /* RS_PC �� 1�϶� RS-232C */

		}else{						

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PLC,RS_INIT,RS_9600,RS_DATA8,RS_NONE); */ /* RS_PLC �� 0�϶� RS-422 */

		}
#ifdef	WIN32
		while(1){
			if((iConnect & 1) == 0){
				if(SioPCOpenFlag == 0){
					break;
				}
			}else{
				if(SioPLCOpenFlag == 0){
					break;
				}
			}
	/*ksc20040714*/
			B_Delay(300);
		}
#endif
	}
	/* PLC Connect Check *(PlcType+2) ���� ������ �Ѱ� ���� */
	monitorModeFlag= PlcType[4];		/* 20090704 */
	buff[0] = STX;	
	Bin2dec(*(PlcType+2),2,&buff[1]); /*20060223 hsh ���� 10������ ó���ϵ��� ����*/
	buff[3] = 0;
	B_gstrcat(&buff[3],"WX");
	buff[5] = 0x02;
	buff[6] = 0;
	B_gstrcat(&buff[6],"1234567890123456789");
	buff[25] = ETX;
	buff[26] = 0;
	ret= SendRecPLCWithBCCCont(2,buff,PlcRecBuff,&Cnt,0);			/* ret = 1 : OK, ret = 0 : NG */
	ResetGroopSema();

/*ksc20040716*/

	if(ret < 0){
		return(0); 
	}


	/* PLC Connect Check */
	ret= 1;
	return(ret);
/*ksc20040715*/
/*���ؼ��� ���� ������ ������ Ȯ�εǸ� �����޼����� ǥ������ �ʴ´�. 
  ���� ������ ������ �����޼��� ǥ���Ѵ�.
  ret=1�϶� �������� ó�� 	*/
}
/******************************************/
static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif
#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif
}
/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;


	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i,j;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
/*ksc20040713*/
			ret = Address % 16;
			BitAndData = 1;
			for(j = 0; j < ret; j++){
				BitAndData <<= 1;
			}
			ret += sCnt;
			ret = ret / 8 + 1;
			BitRecCnt = ret;
/*ksc20040713*/
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < BDEVICE_CNT; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrncmp(bPLCDeviceTbl[i].Device,Device,2) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ (Address/ 16) * 2;
				ret = Address % 16;
				BitAndData = 1;
				for(j = 0; j < ret; j++){
					BitAndData <<= 1;
				}
				ret += sCnt;
				ret = ret / 8 + 1;
				if((ret % 2) != 0){
					ret++;
				}
				BitRecCnt = ret;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < WDEVICE_CNT; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrncmp(wPLCDeviceTbl[i].Device,Device,2) == 0){	/* mp���� ����ϴ� ����̽��ΰ� Ȯ�� */
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
/* �۽� ������ ���� */
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int		DevAddr;
	char	buff[4];	

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	/* �Ƿ��� ��巹���� ����ϴ� ��巹���ΰ� ���� ret = 0 �϶� ����� */

	
	if(ret == 0){

/*ksc20040707*/
 		if(DevAddr == 0 || DevAddr == 1){
			/*sprintf(combuff,"01RX%s",DevTbl[DevAddr-100]);*/
			Bin2dec(pDevice[4],2,buff);/*20060223 hsh ���� 10������ ó���ϵ��� ����*/
			B_gstrcpy(combuff,buff);
			B_gstrcat(combuff,"RX");
#ifdef	SH_CPU
			B_gstrcat(combuff,(char *)DevTbl[DevAddr]);
#endif
#ifdef	ARM_CPU
			B_gstrcat(combuff,(char *)DevTbl[DevAddr].strData);
#endif
		}else{
			ret= -1; /* �ش� PLC�� 100�� �۽� ��巹���� ������ -1 ���� */ 
		}

	}
	return(ret);
}

/************************************/
/* SetReadData							*/
/************************************/
static	void	SetReadData( unsigned char *SaveAddr, unsigned int data, int Cnt)
{
		int	i;
#ifdef	SH_CPU
	for(i = 0; i < Cnt; i++){
		*(unsigned char *)SaveAddr++ = (unsigned char)(data % 0x100);
		data = data / 0x100;
	}
#endif
#ifdef	ARM_CPU
	for(i = 0; i < Cnt/2; i++){
#ifdef	WIN32	/* �Ʒ��� ������ ����� ���� */ 
		*(unsigned char *)SaveAddr++ = (unsigned char)((data % 0x10000)%0x100);
		*(unsigned char *)SaveAddr++ = (unsigned char)((data % 0x10000)/0x100);
		data = data / 0x10000;
#else 	/* ���� ������ ����� ���� */
		*(unsigned char *)SaveAddr++ = (unsigned char)((data & 0xff00) >> 8);
		*(unsigned char *)SaveAddr++ = (unsigned char)(data & 0x00ff);
		data = data >> 16;
#endif
	}
#endif
}


/************************************/
/* PLC Read							*/
/************************************/
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType, char NoWait)
{
	int		ret;
	int		i;
	int		loop;

	int		Cnt;
	unsigned char	*SaveAddr;
	unsigned int data1;
	char	work[16];
	int		Address;

	if(NoWait == 1){
		GetGroopSema();
	}
	SaveAddr = (unsigned char *)mp->mptr;
	Address= mp->mpar;
	for(loop= 0; loop < (signed)mp->mext; loop++){
		switch(mp->mpec){	/* mp->mpec�� 0�϶� Bit Device, 1�϶� Word Device */
		case PLC_BIT:		/* Bit Device */
			ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],mp->mext);
			Cnt = mp->mext;
			break;
		case PLC_WORD:		/* Word Device */
			/* �۽� ������ ���� */
			ret = MakePLCReadData(1,(char *)mp->mbuf,Address++,(char *)&PlcSendBuff[1],2);
			Cnt = 2;
			break;
		}
		if(ret == 0){	/* PLC���� ����ϴ� ��巹���� ��� 0 ���� */
			if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0) == 0){ /* ����ؼ� ���ϰ��� 0 �϶� ����Ÿ ó�� */ 
/*ksc20040713*/
				for(i = 0; i < 5; i++){
					work[i] = rDataFx[i+8];
				}
				work[i]= 0;
				if(work[0] == ' '){
					work[0]= '+';
				}else{
					work[0]= '-';
				}
				data1= C_gatoi(work);

				SetReadData(SaveAddr,data1,Cnt);
				
/*ksc20040715*/
			}else{
				ret = -1;
				break;
			}					
		}else if(ret == 1){		/* ����Device */
			ret= 0;
			break;
		}else{
			ret= 0;
			break;
		}
	}
	B_Delay(200);
	if(NoWait == 1){
		ResetGroopSema();
	}
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
static	int	ChangeIntData(char *data,int Cnt,int mode)
{
	int		iData;
	int		i;
	union{
		int		iData;
		char	cData[4];
	}rData;
	union{
		short		iData;
		char	cData[2];
	}rData_sort;

	if(Cnt == 1){		/* short */
		B_gmemset((char *)&rData_sort,0,sizeof(rData_sort));
#ifdef	SH_CPU
		if(mode == 1){
#endif
#ifdef	ARM_CPU
		if(mode != 1){
#endif
			for(i= 0; i < Cnt*2 && i < 2; i++){
				rData_sort.cData[1- i]= *data;
				data++;
			}
			iData = rData_sort.iData;

		}else{

			iData = *(short*)data;
		}
	}else{
		B_gmemset((char *)&rData,0,sizeof(rData));
#ifdef	SH_CPU
		if(mode == 1){
#endif
#ifdef	ARM_CPU
		if(mode != 1){
#endif
			for(i= 0; i < Cnt*2 && i < 4; i++){
				rData.cData[3- i]= *data;
				data++;
			}
			iData = rData.iData;
		}else{
			iData = *(int*)data;
		}
	}
	return(iData);
}

/****************************/
/* Make Write Device		*/
/****************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data,int StationNo)
{

	int		ret;
	int		DevAddr;
	int		iData;
	int		i,j,idx;
	char	buff[32];
	
	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);
	if(ret == 0){
		if(DevAddr == 1){
			/*sprintf(combuff,"01WX0%s",DevTbl[DevAddr-100]);*/
			Bin2dec(StationNo,2,buff); /*20060223 hsh ���� 10������ ó���ϵ��� ����*/
			B_gstrcpy(combuff,buff);
			B_gstrcat(combuff,"WX");
#ifdef	SH_CPU
			B_gstrcat(combuff,(char *)DevTbl[DevAddr]);
#endif
#ifdef	ARM_CPU
			B_gstrcat(combuff,(char *)DevTbl[DevAddr].strData);
#endif
/*			iData = ChangeIntData(data,Cnt,mode);	*/

			if(Cnt == 1){
#ifdef SH_CPU				
				iData = (*data&0x00ff)|(*(data+1)<<8);  /* 20090605 hsh */
			
#endif
#ifdef ARM_CPU
				iData = *(short*)data;
#endif
			}else if(Cnt == 2){
				iData = *(int*)data;
			}else{
			}
			/*sprintf(buff,"%06d",*data);*/
			Bin2dec(iData,4,buff);
		
			if((buff[0] == '-') || (buff[0] == '+')){
				combuff[6]= buff[0];
				idx= 1;
			}else{
				combuff[6]= ' ';
 				idx= 0;
			}
			for(i= 7,j= 0;;idx++){
				if(buff[idx] == 0){
					break;
				}
				if(buff[idx] == '.'){
					j= 0;
					continue;
				}
				combuff[i++]= buff[idx];
				j++;
				if(i >= 11){
					break;
				}
			}

			combuff[i++]= 0;
		}else{
			ret= -1;
		}


	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int ret;
	int Cnt;
	unsigned char 	r_data[32];
	unsigned char	w_data[10];
	char	*wAddr;
	int		DevAddr;

	GetGroopSema();
	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)&PlcSendBuff[1],(char *)mp->mptr,(int)mp->mbuf[4]);
		Cnt = mp->mext;
		break;
	case PLC_WORD:		/* Word Device */
		ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)&PlcSendBuff[1],(char *)mp->mptr,(int)mp->mbuf[4]);
		Cnt = mp->mext* 2;
		break;
	}
	if(ret == 0){

		wAddr= (char *)mp->mptr;
		DevAddr= mp->mpar;
		mp->mptr= w_data;
/*		ResetGroopSema(); */	/* 20090605 hsh �׷��� �������� ���� */
		C_PLCCommRead(mp,r_data,PlcType, 0); 
		mp->mpar = DevAddr;
		mp->mptr= wAddr;

		ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)&PlcSendBuff[1],(char *)mp->mptr,(int)mp->mbuf[4]);
		Cnt = mp->mext* 2;
		if((ret == 0) && (B_gstrncmp((char *)&PlcSendBuff[5],(char *)&r_data[6],2) == 0) && (B_gstrncmp((char *)&PlcSendBuff[7],(char *)&r_data[8],5) != 0)){		/* ret = 0 : OK, ret = -1 : NG */ 
			if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){  /* 20090605 hsh mode 3->2�� ���� */
			}else{
				ret = -1;
			}
		}
	}
/*ksc20041119
	else if(ret == 1){		 ����Address ���� address, UB, UW ����̽��϶� ret = 1 ���⼭�� ������� �����Ƿ� �ǹ� ����.
		ret= 0;
	}
ksc20041119*/	
	B_Delay(400); /*20090605 hsh TZ�� ���÷��� ó�� �ð� �ֱ� ���ؼ� ��� �ð� �ø�*/

	ResetGroopSema();
	return(ret);
}
static	int	C_GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}


/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType, 1));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	switch(data){
	case STX:
		*CommMode = 0;
		break;
	case ENQ:
	case ACK:
	case NAK:
	case 0xff:
		return(-1);
	}
	switch(*CommMode){
	case 0:		/* Normal */
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:		/* Thru Mode */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			if((data == EOT) || (data == ETX)){
				*CommMode = 5;
			}
		}else{
			*CommMode = 0;
		}
		break;
	case 5:		/* CRC1 */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			*CommMode = 99;
			ret= 0;
		}else{
			*CommMode = 0;
		}
		break;
	}
	return(ret);
}
/************************************************/
/*	�O��?�v����								*/
/************************************************/
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	return(0);
}
/****************************************/
/*	�O��?�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Same Device Check */
/*	B_gmemset((char *)GrpPLCcombuf, 0, sizeof(GrpPLCcombuf));*/
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	return(0);
}
int	MakeCrC8Check(unsigned char *buff,int cnt)
{
	unsigned char _crc8;
	int		i;

	_crc8 = 0;
	for(i = 0; i < cnt-1; i++){
		_crc8 = (unsigned int)(_crc8 ^ buff[i]); /* BCC ��� STX--ETX */
 	}
	if(_crc8 == buff[cnt-1]){
		return(OK);
	}else{
		return(NG);
	}
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int	ret;
	int	SendCnt;
	int	Cnt;

	if(monitorModeFlag == MONITOR){			/* 20090704 */
		return(0);
	}

	if((PlcSendedFlag == 0) && (PlcThruMonDataCnt[0] != 0)){
		GetGroopSema();
		B_gmemcpy((char *)PlcSendBuff,(char *)PlcThruMonBuff[0],PlcThruMonDataCnt[0]);
		SendCnt= PlcThruMonDataCnt[0];
		ret= C_SendRecPLC(2,PlcRecBuff,&Cnt,0,SendCnt,(char *)PlcSendBuff,2000);
		if(ret == OK){
			if(MakeCrC8Check(PlcRecBuff,Cnt) == OK){
				B_gmemcpy((char *)PlcThruRecBuff,(char *)PlcRecBuff,Cnt);
				PlcThruRecDataCnt[0]= Cnt;
				PlcSendedFlag= 1;
			}else{
				PlcSendedFlag= 2;
			}
		}else{
			PlcSendedFlag= 2;
		}
		ResetGroopSema();
	}
	ret= 0;
	return(ret);
}
/************************************/
/*	�X��?��?�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	GetGroopSema();
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendThruePLC(2,*OutCnt,OutBuff,3000); /*20090706*/
	ResetGroopSema();

#ifdef	OLDSOURCE
	int		i;
	if(MakeCrC8Check((unsigned char *)CommBuff,*RecCommCnt) == NG){
	}else{
		B_gmemcpy((char *)PlcThruMonBuff[0],CommBuff,*RecCommCnt);
		PlcThruMonDataCnt[0]= *RecCommCnt;
		PlcSendedFlag= 0;
		for(i= 0; i < 100; i++){
			if(PlcSendedFlag != 0){
				break;
			}
			B_Delay(50);
		}
		if(PlcSendedFlag == 1){
			/* Rec Data Send to PC */
			B_SendPLC2PCData( 0,PlcThruRecDataCnt[0],(char *)PlcThruRecBuff[0],2000 );
		}
	}
#endif
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
#endif

/*++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType,1));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif
#include	"hook_aplplc.h"
/****************************** END **********************/
