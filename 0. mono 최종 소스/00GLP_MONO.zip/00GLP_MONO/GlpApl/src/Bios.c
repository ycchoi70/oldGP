#include	"sgt.h"
#include "S3c44b0x.h"


/*#define	TBQ(a)	(sizeof(a)/sizeof(a[0]))*/


extern	int		TateYoko;			/* �c�E�� */

/****************************************************/
/*	RTC												*/
/****************************************************/
/****************************************************
*   FUNC  : Rtc Data Write                          *
*	In    :											*
*	Out   : 										*
*   DATE  : 2002.5.11                               *
****************************************************/
#ifndef	WIN32
void	DrawLcd( char* pBitmapBits )
{
}
#endif
void	BackLightOnOff(int mode)
{
#ifndef	WIN32
	if(mode == ON){	rPDATE &= ~BACK_LIGHT;	}
	else{			rPDATE |= BACK_LIGHT;	}
#endif
}

//20080814
void	LCDDisplayEnable(int mode)
{
#ifndef	WIN32

#ifdef	GP_S044
	if(mode == ON){	rPDATF &= ~LCD_DISPLAY;	}
	else{			rPDATF |= LCD_DISPLAY;	}
#endif
#ifdef	LP_S044
	if(mode == ON){	rPDATF &= ~LCD_DISPLAY;	}
	else{			rPDATF |= LCD_DISPLAY;	}
#endif
#ifdef	GP_S057
	if(mode == ON){	rPDATA &= ~LCD_DISPLAY;	}
	else{			rPDATA |= LCD_DISPLAY;	}
#endif
#endif
}

#ifdef  WIN32
#else
typedef struct{
	volatile unsigned *KeyOutDevice;
	unsigned short KeyOutData;
}KEY_PORT_TBL;


struct st_io {                                          /* struct IO    */
     union {                                    /* PUCR1        */
           unsigned int _WORD;                  /*  _BYTE Access */
           struct {                             /*  Bit  Access */
                  unsigned int B31:1;           /*    Bit 7     */
                  unsigned int B30:1;           /*    Bit 7     */
                  unsigned int B29:1;           /*    Bit 7     */
                  unsigned int B28:1;           /*    Bit 7     */
                  unsigned int B27:1;           /*    Bit 7     */
                  unsigned int B26:1;           /*    Bit 7     */
                  unsigned int B25:1;           /*    Bit 7     */
                  unsigned int B24:1;           /*    Bit 7     */
                  unsigned int B23:1;           /*    Bit 7     */
                  unsigned int B22:1;           /*    Bit 7     */
                  unsigned int B21:1;           /*    Bit 7     */
                  unsigned int B20:1;           /*    Bit 7     */
                  unsigned int B19:1;           /*    Bit 7     */
                  unsigned int B18:1;           /*    Bit 7     */
                  unsigned int B17:1;           /*    Bit 7     */
                  unsigned int B16:1;           /*    Bit 7     */
                  unsigned int B15:1;           /*    Bit 7     */
                  unsigned int B14:1;           /*    Bit 7     */
                  unsigned int B13:1;           /*    Bit 7     */
                  unsigned int B12:1;           /*    Bit 7     */
                  unsigned int B11:1;           /*    Bit 7     */
                  unsigned int B10:1;           /*    Bit 7     */
                  unsigned int B9:1;           /*    Bit 7     */
                  unsigned int B8:1;           /*    Bit 7     */
                  unsigned int B7:1;           /*    Bit 7     */
                  unsigned int B6:1;           /*    Bit 6     */
                  unsigned int B5:1;           /*    Bit 5     */
                  unsigned int B4:1;           /*    Bit 4     */
                  unsigned int B3:1;           /*    Bit 3     */
                  unsigned int B2:1;           /*    Bit 2     */
                  unsigned int B1:1;           /*    Bit 1     */
                  unsigned int B0:1;           /*    Bit 0     */
                  }_BIT;                   /*              */
       }DATA;                  /*              */
};

#ifdef	WIN32
	unsigned int	DMYIO_AREA[256];
	unsigned int	*DMYIO_AREA_ADDR[256]={
		&DMYIO_AREA[0],&DMYIO_AREA[1],&DMYIO_AREA[2],&DMYIO_AREA[3],&DMYIO_AREA[4],&DMYIO_AREA[5],&DMYIO_AREA[6],&DMYIO_AREA[7],
		&DMYIO_AREA[8],&DMYIO_AREA[9],&DMYIO_AREA[10],&DMYIO_AREA[11],&DMYIO_AREA[12],&DMYIO_AREA[13],&DMYIO_AREA[14],&DMYIO_AREA[15],
		&DMYIO_AREA[16],&DMYIO_AREA[17],&DMYIO_AREA[18],&DMYIO_AREA[19],&DMYIO_AREA[20],&DMYIO_AREA[21],&DMYIO_AREA[22],&DMYIO_AREA[23],
	};
	#define IO_rPDATB      (*(volatile struct st_io    *)DMYIO_AREA_ADDR[0])   /* IO    Address*/
	#define IO_rPDATF      (*(volatile struct st_io    *)DMYIO_AREA_ADDR[1])   /* IO    Address*/
	#define IO_rPDATG      (*(volatile struct st_io    *)DMYIO_AREA_ADDR[2])   /* IO    Address*/
#else
	#define IO_rPDATB      (*(volatile struct st_io    *)0x1d2000c)   /* IO    Address*/
	#define IO_rPDATF      (*(volatile struct st_io    *)0x1d20038)   /* IO    Address*/
	#define IO_rPDATG      (*(volatile struct st_io    *)0x1d20044)   /* IO    Address*/
#endif


const KEY_PORT_TBL KeyPortTbl[16] = {
	{(volatile	unsigned *)0x1d2000c,0x0010},		//T-Comm0  PORT-B(B4)
	{(volatile	unsigned *)0x1d2000c,0x0020},		//T-Comm1  PORT-B(B5)
	{(volatile	unsigned *)0x1d2000c,0x0040},		//T-Comm2  PORT-B(B6)
	{(volatile	unsigned *)0x1d20038,0x0004},		//T-Comm3  PORT-F(F2)
	{(volatile	unsigned *)0x1d20038,0x0010},		//T-Comm4  PORT-F(F4)
	{(volatile	unsigned *)0x1d20038,0x0008},		//T-Comm5  PORT-F(F3)
	{(volatile	unsigned *)0x1d20044,0x0001},		//T-Comm6  PORT-G(G0)
	{(volatile	unsigned *)0x1d20044,0x0002},		//T-Comm7  PORT-G(G1)
	{(volatile	unsigned *)0x1d20044,0x0004},		//T-Comm8  PORT-G(G2)
	{(volatile	unsigned *)0x1d20044,0x0008},		//T-Comm9  PORT-G(G3)
	{(volatile	unsigned *)0x1d20044,0x0010},		//T-Comm10 PORT-G(G4)
	{(volatile	unsigned *)0x1d20044,0x0020},		//T-Comm11 PORT-G(G5)
	{(volatile	unsigned *)0x1d20044,0x0040},		//T-Comm12 PORT-G(G6)
	{(volatile	unsigned *)0x1d20038,0x0100},		//T-Comm13 PORT-F(F8)
	{(volatile	unsigned *)0x1d20038,0x0080},		//T-Comm14 PORT-F(F7)
	{(volatile	unsigned *)0x1d20038,0x0040},		//T-Comm15 PORT-F(F6)
};


#ifdef	GP_S057
	static	char	ChangeReturn[12]={
//		5,4,3,2,1,0,6,7,8,9,10,11
		5,4,3,2,1,0,6,7,10,9,8,11
	};
#endif
#ifdef	LP_S044
	static	char	ChangeReturn[4]={
		1,0,2,3
	};
#endif
#ifdef	GP_S044
	static	char	ChangeReturn[4]={
		1,0,2,3
	};
#endif
/* 20061117 ksc */
int   ScanKey(void)
{
    int     i,j,k,l;
	int		flag;
	int		dCnt;
	int		retCode;
	unsigned short	InData;
	unsigned short	AndData;
	volatile	unsigned *PortAddr;
	int		loopCnt;


	flag = -1;
	dCnt = 0;

	/* Initial */
	// XXXXXXXXXX11XXXX
	rPDATB |= 0x00000070;		//B4,B5,B6
	// XXXXXXX111X111XX
//	rPDATF |= 0x000001dc;		//F8,F7,F6,F4,F3,F2
	// XXXXXXXXX1111111
	rPDATG |= 0x0000007f;		//G6,G5,G4,G3,G2,G1,G0

	IO_rPDATF.DATA._BIT.B2= 1;
	IO_rPDATF.DATA._BIT.B4= 1;
	IO_rPDATF.DATA._BIT.B3= 1;
	IO_rPDATF.DATA._BIT.B8= 1;
	IO_rPDATF.DATA._BIT.B7= 1;


#ifdef	GP_S057	
	IO_rPDATF.DATA._BIT.B6= 1;
#endif

	retCode= -1;
#ifdef	GP_S057
	loopCnt= 16;
#endif
#ifdef	LP_S044
	loopCnt= 15;
#endif
#ifdef	GP_S044
	loopCnt= 15;
#endif
	for(i = 0; i < loopCnt; i++) {
		/* Comm Out */
//		PortAddr= (volatile unsigned *)KeyPortTbl[i].KeyOutDevice;
//		*PortAddr &= ~KeyPortTbl[i].KeyOutData;
		switch(i){
		case 3:		IO_rPDATF.DATA._BIT.B2= 0;	break;
		case 4:		IO_rPDATF.DATA._BIT.B4= 0;	break;
		case 5:		IO_rPDATF.DATA._BIT.B3= 0;	break;
		case 13:	IO_rPDATF.DATA._BIT.B8= 0;	break;
		case 14:	IO_rPDATF.DATA._BIT.B7= 0;	break;
		case 15:	IO_rPDATF.DATA._BIT.B6= 0;	break;
		default:
			PortAddr= (volatile unsigned *)KeyPortTbl[i].KeyOutDevice;
			*PortAddr &= ~KeyPortTbl[i].KeyOutData;
			break;

		}
		/* Out Delay(50us) */
		for(j= 0; j < 6; j++){			//4->6(2007.04.04)
			for(k = 0; k < 30; k++){
				l = 10;
				l *= l;
			}
		}
#ifdef	GP_S057
		InData= rPDATC & 0x00ff;
		InData |= (rPDATE & 0x00e0) << 3;
		InData |= (rPDATF & 0x0020) << 6;

//		*PortAddr |= KeyPortTbl[i].KeyOutData;
		switch(i){
		case 3:		IO_rPDATF.DATA._BIT.B2= 1;	break;
		case 4:		IO_rPDATF.DATA._BIT.B4= 1;	break;
		case 5:		IO_rPDATF.DATA._BIT.B3= 1;	break;
		case 13:	IO_rPDATF.DATA._BIT.B8= 1;	break;
		case 14:	IO_rPDATF.DATA._BIT.B7= 1;	break;
		case 15:	IO_rPDATF.DATA._BIT.B6= 1;	break;
		default:
			*PortAddr |= KeyPortTbl[i].KeyOutData;
			break;
		}
		
		if(InData != 0){
			AndData= 0x0001;
			for(j= 0; j < 12; j++){
				if(InData & AndData){
					flag = ChangeReturn[j] * 16 + i + 1;
					if(dCnt == 0){	memset(KeyTochDataWork,0,sizeof(KeyTochDataWork));}
					if(retCode == -1){	retCode= flag;	}
					if(dCnt < 8){	KeyTochDataWork[dCnt++] = flag;	}
				}
				AndData = AndData << 1;
			}
		}
#endif
#ifdef	LP_S044
		InData= rPDATC & 0x000f;

//		*PortAddr |= KeyPortTbl[i].KeyOutData;
		switch(i){
		case 3:		IO_rPDATF.DATA._BIT.B2= 1;	break;
		case 4:		IO_rPDATF.DATA._BIT.B4= 1;	break;
		case 5:		IO_rPDATF.DATA._BIT.B3= 1;	break;
		case 13:	IO_rPDATF.DATA._BIT.B8= 1;	break;
		case 14:	IO_rPDATF.DATA._BIT.B7= 1;	break;
		case 15:	IO_rPDATF.DATA._BIT.B6= 1;	break;
		default:
			*PortAddr |= KeyPortTbl[i].KeyOutData;
			break;
		}
		
		if(InData != 0){
			AndData= 0x0001;
			for(j= 0; j < 4; j++){
				if(InData & AndData){

					if(TateYoko == 0){				/* ksc20090523 */
						flag = ChangeReturn[j] * 15 + i + 1;
//						flag = j * 15 + i+ 1;
					}else{
						flag = i * 4 + (3-ChangeReturn[j])+ 1;
					}

					if(dCnt == 0){
						memset(KeyTochDataWork,0,sizeof(KeyTochDataWork));
					}
					if(retCode == -1){	retCode= flag;	}
					if(dCnt < 8){	KeyTochDataWork[dCnt++] = flag;	}
				}
				AndData = AndData << 1;
			}
		}
#endif
#ifdef	GP_S044
		InData= rPDATC & 0x000f;

//		*PortAddr |= KeyPortTbl[i].KeyOutData;
		switch(i){
		case 3:		IO_rPDATF.DATA._BIT.B2= 1;	break;
		case 4:		IO_rPDATF.DATA._BIT.B4= 1;	break;
		case 5:		IO_rPDATF.DATA._BIT.B3= 1;	break;
		case 13:	IO_rPDATF.DATA._BIT.B8= 1;	break;
		case 14:	IO_rPDATF.DATA._BIT.B7= 1;	break;
		case 15:	IO_rPDATF.DATA._BIT.B6= 1;	break;
		default:
			*PortAddr |= KeyPortTbl[i].KeyOutData;
			break;
		}
		
		if(InData != 0){
			AndData= 0x0001;
			for(j= 0; j < 4; j++){
				if(InData & AndData){

					if(TateYoko == 0){				/* ksc20090523 */
						flag = ChangeReturn[j] * 15 + i + 1;
//						flag = j * 15 + i+ 1;
					}else{
						flag = i * 4 + (3-ChangeReturn[j])+ 1;
					}

					if(dCnt == 0){
						memset(KeyTochDataWork,0,sizeof(KeyTochDataWork));
					}
					if(retCode == -1){	retCode= flag;	}
					if(dCnt < 8){	KeyTochDataWork[dCnt++] = flag;	}
				}
				AndData = AndData << 1;
			}
		}
#endif
    }
    return(retCode);
}
#endif
/********************************************************************/
/*                                                                  */
/*      �u�U�[�̃h���C�o�[                                          */
/*                                                                  */
/********************************************************************/
void    BuzOn(void)
{
#ifndef	WIN32
/* 20061117 ksc */
	//OUT INPUT INPUT INPUT TOUT1 TOUT0 RxD0 TxD0 OUT
	// 01,   00,   00,   00,   10,   10,  10,  10, 01
	rPCONE=0x002a9;	
	rTCON=(rTCON&0xfffffff0)|0x0000000d;	// Interval Mode, Inverter Off, Update	
#endif
}

void    BuzOff(void)
{
#ifndef	WIN32
/* 20061117 ksc */
	//OUT INPUT INPUT INPUT TOUT1 OUT RxD0 TxD0 OUT
	// 01,   00,   00,   00,   10, 01,  10,  10, 01
	rPCONE=0x00269;	
	rPDATE=(rPDATE & ~0x08);
#endif
}
/****************************************************
*   FUNC  : AD Read                                 *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
****************************************************/
int	BatteryRead( void )
{
	int	data;

#ifndef	WIN32
//	rADCPSR=20;				// PreScaler for ADC
//	Delay(100);
	rADCCON=0x01|(0x7 << 2);	//AIN7
	Delay(20);
	rADCCON=0x01|(0x7 << 2);	//AIN7
	Delay(20);
	data=rADCDAT&0x03ff;
#else
	data= 0;
#endif
	return(data);
}
int	RunSWReadProc( void )
{
	int	data;

#ifndef	WIN32
//	rADCPSR=20;				// PreScaler for ADC
//	Delay(100);
	rADCCON=0x01|(0x5 << 2);	//AIN5
	Delay(20);
	data=rADCDAT&0x03ff;
	if(data > 0x100){	data = OFF;	}
	else{				data = ON;	}
#else
	extern	int		SimRunSwitch;
	data= SimRunSwitch;
#endif
	return(data);
}
int	RunSWRead( void )
{
	int		ret;
	int	mbx;
	T_MAIL	*mp;
	unsigned int	OldResp;

	mbx= TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RTC_RUN_LED;
	SendMail(T_RTCHAND,(char *)mp);
	mp= (T_MAIL *)ReceiveMail( mbx );
	ret= mp->minf;
	ChangeMailResp( (char *)mp, OldResp );
	FreeMail( (char *)mp );
	FreeMbx( mbx );
	return(ret);
}

/********************************************/
/*	Gp Type Check							*/
/********************************************/
//int	IsGlpType(void)
//{
//	int	ret= NG;
//
//	if(GP_TYPE_CODE == 0x8401){	ret= OK;	}	// GLP TYPE
//	return(ret);
//}
#define	CONTRAST_CLK	0x0400
#define	CONTRAST_DAT	0x0200
#define	CONTRAST_ENBL	0x0100
#define	CNTRAST_CNT		255
#define	CNTRAST_MAX		255
void	Delay200us(int cnt)
{
	volatile	int		j;
	int	i;

	for(i= 0; i < cnt; i++){
		j= 10;
		j= j*5;
	}
}
/****************************************************/
/*	Set Contrast									*/
/****************************************************/
void	SetContrast(int data)
{
#ifndef	WIN32
	volatile	int		i;
	int		anddata;
	int		cdata;

	if(data > CNTRAST_CNT){
		data= CNTRAST_CNT;
	}
/*	cdata= data+60;*/
	cdata= data;
	/* Data Set */
	anddata= 0x80;
/*cdata= 0x55;*/
	for(i= 0; i < 8; i++){
		if(cdata & anddata){	rPDATB |= CONTRAST_DAT;	}		/* 1 OUT */
		else{					rPDATB &= ~CONTRAST_DAT;}		/* 0 OUT */
		/* min500ns Wait */
/* 20061117ksc */
		Delay200us(300);				// 2.5us(30)
		rPDATB |= CONTRAST_CLK;		// 1
		/* min500ns Wait */
		Delay200us(300);
		rPDATB &= ~CONTRAST_CLK;	// 0
		anddata = anddata >> 1;
		/* 5us Wait */
		Delay200us(250);
	}
	/* STB ON */
	rPDATB |= CONTRAST_ENBL;
	Delay200us(300);
	rPDATB &= ~CONTRAST_ENBL;
	Delay200us(300);
#endif
}
void	RunLed(int mode)
{
#ifndef	WIN32
	if(mode == ON){
		rPDATA |= LED_ERROR;
		rPDATA &= ~LED_RUN;
	}else{
		rPDATA |= LED_RUN | LED_ERROR;
	}
#endif
}
void	ErrorLed(int mode)
{
#ifndef	WIN32
	if(mode == ON){
		rPDATA |= LED_RUN;
		rPDATA &= ~LED_ERROR;
	}else{
		rPDATA |= LED_RUN | LED_ERROR;
	}
#endif
}
void	DebugLed(int mode)
{
#ifndef	WIN32
	if(mode == ON){
		rPDATA &= ~(LED_RUN | LED_ERROR);
	}else{
		rPDATA |= LED_RUN | LED_ERROR;
	}
#endif
}
