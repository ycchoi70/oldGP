/* ****************************************************************************** */
/*  �� �� �� : GP_BATTERYDISP.CPP												 */
/*  ��    �� : �嵥�� �뷮 ���÷���											 */
/*  �� �� �� : 2003�� 6�� 13�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

/* ****************************************************************************** */
/*  �� �� �� : vButDispMode()													 */
/*  ��    �� : ���ϴ�� ���� ó��												 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#ifdef	SIZE_2480
#define	BATT_MAX_POS	173
#define	BATT_MIN_POS	0
#define	BATT_WIDTH		109
void		vButDispMode(int* iScreenNo)
{

	int					iKeyCode;	
	int					iData;
	char				DataFormat[8];
	short				NowData;
	_RECTANGLE_INFO		RECParam;
	_RECTANGLE_INFO		RECParam1;

	int					LowFlag,loopCnt;		/* 040508 */


	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	RECParam1.iLineStyle = SOLID_LINE;
	RECParam1.iLineColor = WHITE;
	RECParam1.iPattern	 = PAT8;
	RECParam1.iForeColor = WHITE;
	RECParam1.iBackColor = WHITE;

	ClearDispBuff(SCREEN_0);

	DotTextOut(GAMEN_START_X+12,GAMEN_START_Y+61,"0",1,1,TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+213,GAMEN_START_Y+61,"100",1,1,TRANS, T_WHITE, T_BLACK);

	RectAngleOut(GAMEN_START_X+31,GAMEN_START_Y+60,GAMEN_START_X+208,GAMEN_START_Y+77,&RECParam);
	RectAngleOut(GAMEN_START_X+33,GAMEN_START_Y+62,GAMEN_START_X+206,GAMEN_START_Y+75,&RECParam);

	DefaultFormDisplay(LINE_FORM, Dspname[BATTERY].chTitle[Set.iLang]);

	DrawLcdBank1();

	NowData		= -1;
	loopCnt= 0;		/* 040508 */
	LowFlag= 0;
	while ( *iScreenNo == BATTERY_NUM ) 
	{
/*ksc20040508	*/
		if(CommonArea.BatteryLevel != NowData)
		{

			if(CommonArea.BatteryLevel>=BATT_MAX_REVEL)	 /* 20080822 */
			{
				iData = BATT_MAX_POS;
			}	
			else if((BATT_MIN_REVEL < CommonArea.BatteryLevel) && (CommonArea.BatteryLevel< BATT_MAX_REVEL))
			{
				iData = (int)(((CommonArea.BatteryLevel-BATT_MIN_REVEL)*BATT_MAX_POS)/BATT_WIDTH);
			}
			else
			{
				iData = BATT_MIN_POS;
			}	

			AreaClear(GAMEN_START_X+34,GAMEN_START_Y+63,GAMEN_START_X+205,GAMEN_START_Y+74,0);
			RectAngleOut(GAMEN_START_X+33,GAMEN_START_Y+63,GAMEN_START_X+iData+33,GAMEN_START_Y+74,&RECParam1);
			NowData = CommonArea.BatteryLevel;
			memset(DataFormat,0x00,sizeof(DataFormat));

			AreaClear(GAMEN_START_X+34,GAMEN_START_Y+32,GAMEN_START_X+205,GAMEN_START_Y+49,0);			
			if(CommonArea.BatteryLevel>=BATT_MAX_REVEL)	
			{
				iData = 100;
				sprintf(DataFormat,"%3d%%",iData);
				DotTextOut(GAMEN_START_X+108,GAMEN_START_Y+33,DataFormat,1,1,TRANS, T_WHITE, T_BLACK);	
			}	
			else if((BATT_MIN_REVEL < CommonArea.BatteryLevel) && (CommonArea.BatteryLevel< BATT_MAX_REVEL))
			{
				iData = (int)(((CommonArea.BatteryLevel-BATT_MIN_REVEL)*100)/BATT_WIDTH);
				sprintf(DataFormat,"%3d%%",iData);
				DotTextOut(GAMEN_START_X+108,GAMEN_START_Y+33,DataFormat,1,1,TRANS, T_WHITE, T_BLACK);	
			}
			else
			{
				iData = 0;
			}
			DrawLcdBank1();

		}
		if(CommonArea.BatteryLevel < BATT_MIN_REVEL){
			if((loopCnt % 5) == 0){
				if(LowFlag == 0){
					LowFlag= 1;
					DotTextOut(GAMEN_START_X+90,GAMEN_START_Y+33,"Bat Low",1,1,TRANS, T_WHITE, T_BLACK);
				}else{
					LowFlag= 0;
					DotTextOut(GAMEN_START_X+90,GAMEN_START_Y+33,"       ",1,1,TRANS, T_WHITE, T_BLACK);
				}
				DrawLcdBank1();
			}
		}
		loopCnt++;
/*ksc20040508	*/



		iKeyCode = KeyAccept();								/* �Էµ� Ű���� �о��	 */

		if ((iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) ||
			(iKeyCode == KEY_01 || iKeyCode == KEY_02)) 
		{
/* 20080822 */
			NormalBuzzer();								/*	Buzzer  */
		}
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}
		/* Ű ���� ó�� */				
		if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) 
		{
			*iScreenNo = USER_SCREEN_NUM;
		}else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) 
		{															/*  END				 */
			*iScreenNo = SET_ENVIRONMENT_NUM;
		} else
		{
			iKeyCode = -1;
		}	
		Delay(100);
	} 
	KerRepeatFlag = 0;
	return;
}

#endif

