//Key Kind
#define	KEY_EXIT		0x01
#define	KEY_MENU_END	0x02

#define	DEV_GAMEN_X_SIZE	240
#define	DEV_GAMEN_Y_SIZE	100
//Select Menu
#define	KEY_DEV_MON		0x10
#define	KEY_ENVIRON		0x11
#define	KEY_DATA_VIEW	0x12
#define	KEY_SET_FUNC	0x13
#define	KEY_DEVICE		0x14
#define	KEY_SET			0x15
#define	KEY_ON			0x16
#define	KEY_OFF			0x17
#define	KEY_UP			0x18
#define	KEY_DOWN		0x19
//Select Lang
#define	KEY_ENG			0x10
#define	KEY_FOR			0x11
//Select Env
#define	KEY_LANG		0x10
#define	KEY_PLC			0x11
#define	KEY_CLOCK		0x12
#define	KEY_CLEAR		0x13
#define	KEY_MENU_CALL	0x14
#define	KEY_BUZZER		0x15
#define	KEY_OPENNING	0x16
#define	KEY_BACK		0x17
#define	KEY_BATTERY		0x18
#define	KEY_CONTRAST	0x19
#define	KEY_UWLATCH		0x1a
//Gamen Item No
#define	G_ENV_CLOCK		6
#define	G_ENV_BUZZER	10
#define	G_ENV_OPEN		11
#define	G_ENV_BACK		12
#define	G_ENV_BATTERY	13
//Set Contrast
#define	KEY_LEFT		0x10
#define	KEY_RIGHT		0x11
//PLC Setting
#define	KEY_CH1_PROT	0x10
#define	KEY_CH1_SPEED	0x11
#define	KEY_CH1_XON		0x12
#define	KEY_CH1_DATA	0x13
#define	KEY_CH1_PARTY	0x14
#define	KEY_CH1_STOP	0x15
#define	KEY_CH1_CHANEL	0x16
#define	KEY_CH2_PROT	0x17
#define	KEY_CH2_SPEED	0x18
#define	KEY_CH2_XON		0x19
#define	KEY_CH2_DATA	0x1a
#define	KEY_CH2_PARTY	0x1b
#define	KEY_CH2_STOP	0x1c
#define	KEY_CH2_CHANEL	0x1d
#define	KEY_GP_NO		0x1e
#define	KEY_PLC_NO		0x1f
//Gamen Item No
#define	IDX_PROTOCOL1	8
#define	IDX_PROT1_VER	9
#define	IDX_CONNECT1	10
#define	IDX_CONNECT11	59
#define	IDX_SPEED1		22
#define	IDX_DATA1		23
#define	IDX_STOP1		24
#define	IDX_PARITY1		25
#define	IDX_FLOW1		26
#define	IDX_PROTOCOL2	33
#define	IDX_PROT2_VER	58
#define	IDX_CONNECT2	34
#define	IDX_CONNECT22	60
#define	IDX_SPEED2		44
#define	IDX_DATA2		45
#define	IDX_STOP2		46
#define	IDX_PARITY2		47
#define	IDX_FLOW2		48
#define	IDX_GP_STATIN	56
#define	IDX_PLC_STATIN	57
//CLOCK KEY
#define	KEY_CLK0		0x30
#define	KEY_CLK1		0x31
#define	KEY_CLK2		0x32
#define	KEY_CLK3		0x33
#define	KEY_CLK4		0x34
#define	KEY_CLK5		0x35
#define	KEY_CLK6		0x36
#define	KEY_CLK7		0x37
#define	KEY_CLK8		0x38
#define	KEY_CLK9		0x39
#define	KEY_CLK_CLR		0x10
#define	KEY_CLK_ENT		0x11
#define	KEY_CLK_D01		0x12
#define	KEY_CLK_D02		0x13
#define	KEY_CLK_D03		0x14
#define	KEY_CLK_D04		0x15
#define	KEY_CLK_D05		0x16
#define	KEY_CLK_D06		0x17
#define	KEY_CLK_T01		0x18
#define	KEY_CLK_T02		0x19
#define	KEY_CLK_T03		0x1a
#define	KEY_CLK_T04		0x1b
#define	KEY_CLK_T05		0x1c
#define	KEY_CLK_T06		0x1d
#define	IDX_DATE		8
#define	IDX_TIME		9
#define	YYYYMMDD		0
#define	YYYYDDMM		1
#define	DDYYYYMM		2
#define	DDMMYYYY		3
#define	MMDDYYYY		4
#define	MMYYYYDD		5
//USER CLEAR
#define	KEY_YES			0x10
#define	KEY_NO			0x11

#define	KEY_LEFT_TOP	0x10
#define	KEY_RIGHT_TOP	0x11
#define	KEY_LET_BOT		0x12
#define	KEY_RIGHT_BOT	0x13

#define	IDX_LEFT_RIGHT	8
#define	IDX_LEFT_TOP_R	9
#define	IDX_LEFT_TOP_C	10
#define	IDX_RGHT_TOP_R	13
#define	IDX_RGHT_TOP_C	14
#define	IDX_LEFT_BOT_R	11
#define	IDX_LEFT_BOT_C	12
#define	IDX_RGHT_BOT_R	15
#define	IDX_RGHT_BOT_C	16
//BUZZER
#define	KEY_BUZ_ON		0x10
#define	KEY_BUZ_OFF		0x11
//OPENNING
#define	IDX_SET_OPEN	39
#define	IDX_SET_TITLE	1
//BATTERY
#define	IDX_SET_BATT	11
#define	IDX_BAT_MAX_BAR	7
#define	IDX_BAT_NOW_BAR	10
//CONSTRAST
#define	IDX_MAX_BAR		7
#define	IDX_NOW_BAR		8
#define	IDX_BAR_TEXT	9
//Device MON
#define	KEY_NO_DATA		0xff
#define	KEY_SEL_DISP	38
#define	KEY_BS			0x12
//DATA VIEW
#define	KEY_BASE_SCREEN		0x10
#define	KEY_WINDOW_SCREEN	0x11
#define	KEY_COMMENT_SCREEN	0x12
#define	KEY_MEMORY_SIZE		0x13
#define	KEY_VER_NUM			0x14
//Base Screen
#define	KEY_LINE1		0x0e
#define	KEY_LINE2		0x0f
#define	KEY_LINE3		0x10
#define	KEY_LINE4		0x11
#define	KEY_LINE5		0x12
#define	KEY_LINE6		0x13
#define	KEY_LINE7		0x14
#define	KEY_LINE8		0x15
#define	KEY_LINE9		0x16
#define	KEY_LINE10		0x17
//TimeSW Screen
#define	KEY_DEV1		0x10
#define	KEY_DEV2		0x11
#define	KEY_DEV3		0x12
#define	KEY_DEV4		0x13
#define	KEY_DEV5		0x14
#define	KEY_DEV6		0x15
#define	KEY_DEV7		0x16
#define	KEY_DEV8		0x17
#define	KEY_DEVL1		0x18
#define	KEY_DEVL2		0x19
#define	KEY_DEVL3		0x1a
#define	KEY_DEVL4		0x1b
#define	KEY_DEVL5		0x1c
#define	KEY_DEVL6		0x1d
#define	KEY_DEVL7		0x1e
#define	KEY_DEVL8		0x1f
//TimeSW Screen
#define	KEY_SUN			0x10
#define	KEY_MON			0x11
#define	KEY_THE			0x12
#define	KEY_WED			0x13
#define	KEY_THU			0x14
#define	KEY_FRI			0x15
#define	KEY_SAT			0x16
#define	KEY_START_H		0x17
#define	KEY_START_M		0x18
#define	KEY_START_S		0x19
#define	KEY_END_H		0x1a
#define	KEY_END_M		0x1b
#define	KEY_END_S		0x1c
//Gamen No
#define	G_MENU_SEL		1001
#define	G_DEV_MON_SEL	1002
#define	G_DEV_MON		1003
#define	G_DEVICE_IN		1004

#define	G_ENVIRONMENT_MENU	1009
#define	G_LANGUAGE			1010
#define	G_PLC_SETTING		1011
#define	G_CLOCK_MENU		1012
#define	G_CLEAR_DATA		1013
#define	G_MENU_CALL_KEY		1014
#define	G_BUZZER			1015
#define	G_OPENNING			1016
#define	G_BACKLIGHT			1017
#define	G_BATTERY			1018
#define	G_LCDCONTRAST		1019
#define	G_DATA_VIEW			1020
#define	G_BASE_SCREEN		1021
//#define	G_WINDOW_SCREEN		1022
#define	G_COMMENT_SCREEN	1022
#define	G_MEMORY_SIZE		1024
#define	G_GP_MODEL			1025
#define	G_SET_FUNTION		1026
#define	G_DATA_TRANSFER		1027
#define	G_TIME_SWITCH		1028
#define	G_TIME_SWITCH_ACT	1029
#define	G_PRINT_OUT			1030
//
#define	LANG_ENG			0
#define	LANG_FOR			1

//Device Monitor
#define	MAX_DEVMON_CNT		16

typedef struct{
	int	cnt;
	struct{
		int	startX;
		int	startY;
		int	endX;
		int	endY;
		int	code;
	}KeyData[7];
}KEY_CHECK_DATA;

typedef struct{
	int	cnt;
	struct{
		int	startX;
		int	startY;
		int	endX;
		int	endY;
		int	code;
	}KeyData[30];
}KEY_CHECK_DATA1;



void	DispTextSetItemData(int idx,char *textbuff);
void	DispTextSetItemDataCursor(int idx,char *textbuff);
void	DispTextSetItemCenter(int idx,char *textbuff);
void	ClearTextItemData(int idx);
void	DispEnvState(T_MAIL *mp);
void	DateTimeDisp(int iFocusFlag,RTC_DATA *DispTime);
void	DispBatterySet(void);
void	DispTextData(int mesNo,int iTotalCnt);
int	EndvKeyCheck(KEY_CHECK_DATA *pEnvKeyTbl);
void	ClearTextItemData1(int idx);
void	DispEnvDeviceMon(T_MAIL *mp);












