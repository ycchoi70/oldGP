/************************************/
/*	PC ����M �v���O����			*/
/************************************/
#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>

#include	"define.h"
#include	"mts.h"
#include	"mtscifp.h"
#include	"mail.h"
#include	"taskhed.h"
#include	"CommBuff.h"
#include	"bios.h"


extern	void	SetPCBaudrate(void);
void	PcHand( STTFrm* pSTT )
{
	T_MAIL	*mp;

	CommMode = 0;
	CommCnt = 0;
	CommKind = 0;
	SendRecMode = 0;		/* Normal Rec Mode */
	PcUpDownMode= 0;		/* DownLoad Mode */
//	RsModeSet(RS_PC,RS_INIT,RS_9600,7,RS_EVEN);
	SetPCBaudrate();
	while(1){
		mp = (T_MAIL *)WaitRequest();

		ResponseMail((char *)mp);
	}
}
#ifndef	WIN32
char	*itoa(int data, char *buff, int p)
{
	int		i,j;
	int		wData;
	char	work[32];

	if(data < 0){
		wData = data * -1;
	}else{
		wData = data;
	}
	for(i = 0; ; i++){
		work[i] = wData % p;
		wData /= p;
		if(wData == 0){
			break;
		}
	}
	j = 0;
	if(data < 0){
		buff[j++] = '-';
	}
	for(; i >= 0; i--){
		buff[j++] = work[i] | '0';
	}
	buff[j] = 0;
	return(buff);
}
#endif
