/********************************/
/*	����ԍ���`       			*/
/*  1999.8.10                   */
/********************************/
/*	Driver & Handler			*/

#define	T_KEY	        0x01
#define	T_SIO0DRV		0x02
#define	T_SIO1DRV		0x03
#define	T_RTCDRV		0x04
#define	T_SIO0RCV		0x05
#define	T_SIO1RCV		0x06
#define	T_BZRDRV		0x07

#define T_KEYHAND       0x08
#define T_RTCHAND       0x09
#define T_PLCHAND		0x0a
#define T_PLCHAND2		0x0b
#define	T_PCKANSI		0x0c
#define	T_PLCKANSI		0x0d
#define	T_FLTKANSI		0x0e
#define T_MSG_TASK		0x0f


#define	T_INITASK	    0x10
#define	T_SETTASK       0x11
#define	T_DISPANALYSIS	0x12

#define T_PROJECT		0x13
#define T_CLASSIFICATION 0x14
#define T_T_KEY_WATCH	0x15

#define	T_PLC2KANSI		0x16
/*#define T_FILE_TASK		0x16*/


#define	T_OBSERV		0x17
#define	T_TIME_ST		0x18
#define	T_TIME_PROC		0x19

/*#define	T_ALARMDETAIL	0x1a*/
#define	T_DISP_TASK		0x1a
#define	T_DEBUG			0x1b
#define	T_PLCCON		0x1c

/* GLP Task */
#define	T_PLCMAIN		0x1d
#define	T_PLCTINT_TASK	0x1e
#define	T_PLCINTTASK	0x1f
/*
#define	T_TASK4     	0x33
*/

/************************************/
/*  �V�O�i��                        */
/************************************/
#define SGN_PLC		0
#define	S_KEY       1
#define S_BUZ       2
#define S_PROJECT	3
#define S_SCREEN	4
#define	SGN_PLC_PRC	5
#define	S_ENV		6
/************************************/
/*  �Z�}�t�H                        */
/************************************/
#define SMF_DISP	0
#define SMF_WIN		1
#define SMF_SEND	2
/***********************************/
#define	INI_COMMENT			0
#define	INI_DETAIL_ALARM	1
#define	INI_ENV_STATE		2
#define	INI_NUMIN_BIT		3
#define	INI_ASCIN_BIT		4
#define	INI_ENV_DEVMON		5
/**********************************/
#define	WIN_BASE_DATA		0
#define	FLOAT_DATA			1
