/*****************************************************************************************/
/*	PLC ����M �v���O��?(LG-K3P-07AS)		  */
/*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		  */
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
/*	2006.09.25 */
/*      �����͹� ���ø� ������ ���� ver 2.7�� �ϰ� ����	  */
/*  20061023 ���Ϲ��� �������� ��Ƽ���ӽ� ��ε��ɽ��ý� �������� ���� ���� ���� V2.7S  */ 
/*  20061025ksc  */ 
/*	     ������ �۽Ž��� ������ �ð� �߰� 30ms V2.7S  - �ٽ� ����  */ 
/* 		 3�� ���� 4�� ���� ���� �����ϵ��� ����  V2.7S		 */
/*       ���Ϲ����� ��� �ӵ� ������ ���������� �ܳؼǿ��� ���� ������ ���� */
/*		 RTU�� ���� �ð��� �ӵ��� ���� �޸� �����ϵ��� ����. �ӵ������� �������� ���� Plchand ���� */ 
/*  2007.01.30 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����		*/
/*  2007.10.08 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����	 		*/ 
/*  2009.05.13																*/
/*		���� ��ƾ ����	ver 3.1S�� ���� 									*/
/*  2010.08.23																*/
/*		�б� �ּ� ���� ��ƾ ����	ver 3.3S�� ���� 									*/
/*****************************************************************************************/




#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

#ifdef PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include  "hook_plcapl.h"

/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0100
#define	VERSION_SET	"V3.5S"
/*****************************************************************************************/





#define	UNVERS_WRITE_START	15
#define	UNVERS_WRITE_END	59999
#define	UNVERS_READ_START	0
#define	UNVERS_READ_END		59999  // 6047
#define	UNVERS_ERR_FNC		0x01
#define	UNVERS_ERR_ADR		0x02
#define	UNVERS_ERR_DAT		0x03

#define UNVERS_UB_W_START   240 // ub150
#define UNVERS_UB_END		96767	 //ub6047f
#define UNVERS_UW_END		6047     //uw6047

#define	MDBUS_READ_COIL_STATUS				0x01
#define	MDBUS_READ_INPUT_STATUS				0x02
#define	MDBUS_READ_HOLDING_REG				0x03
#define	MDBUS_READ_INPUT_REG				0x04
#define	MDBUS_FORCE_SINGLE_COIL				0x05
#define	MDBUS_PRESET_SINGLE_REG				0x06
#define	MDBUS_DIAGNOSTICS					0x08
#define	MDBUS_FETCH_COMM_EVENT_CNT			0x0B
#define	MDBUS_FETCH_COMM_EVENT_LOG			0x0C
#define	MDBUS_FORCE_MULTIPLE_COILS			0x0F
#define	MDBUS_PRESET_MULTIPLE_REG			0x10

/****************************** for Window **********************/
#ifdef	SH_CPU
static	int	SUnvPlcRecCnt;
static	int	SUnvPlcRecCmd;
static	unsigned	int	Port_TimeoutCnt;		/* 20060203 */
static	int	Pro_Speed;			/* 20061025ksc */
static	unsigned int Plc_sync_time;				/* 20061025ksc */ 
#endif

/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif

}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_38400;
	*DataBit= RS_DATA8;
	*Parity= ((RS_XONOFF << 16) |(RS_STOP01 << 8) | (RS_NONE << 0));		/* 20090527 */	
}
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/

static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret;

	ret = -1;


/* 20060202 */
	if(Port_TimeoutCnt != 0){
		if(Plc_sync_time < (B_GetNowTime() - Port_TimeoutCnt)){   /* 20061025ksc */ 
			*CommMode =0;
			*RecCnt = 0;
		}
	}
	Port_TimeoutCnt = B_GetNowTime();		
	
	
	switch(*CommMode){
	case 0:		/* Idle */
		*CommMode = 1;
		*RecCnt = 0;
		RecBuff[(*RecCnt)++] = data;		/* Slave Address */
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		SUnvPlcRecCnt= 6;
		SUnvPlcRecCmd= data;					/* Command */
		switch(SUnvPlcRecCmd){
		case 0x01:
		case 0x02:
		case 0x03:
		case 0x04:
		case 0x05:
		case 0x06:
			SUnvPlcRecCnt= 6;
			break;
		case 0x07:
		case 0x0b:
		case 0x0c:
			SUnvPlcRecCnt= 2;
			break;
		case 0x0f:	/* �A��DO */
			SUnvPlcRecCnt= 5;
			break;
		case 0x10:	/* �A���ێ����W�X? */
			SUnvPlcRecCnt= 5;
			break;
		case 0x11:	/*  */
			SUnvPlcRecCnt= 2;
			break;
		default:
			SUnvPlcRecCnt= 6;
			break;
		}
		*CommMode = 2;
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		SUnvPlcRecCnt--;
		if(SUnvPlcRecCnt <= 0){
			if((SUnvPlcRecCmd == 0x0f) || (SUnvPlcRecCmd == 0x10)){
				SUnvPlcRecCnt= data+ 2;		/* Write Cnt + CRC */
				*CommMode = 3;
			}else{
				ret= 0;		/* Command End */
				Port_TimeoutCnt = 0;	/* 20060203 */
			}
		}
		break;
	case 3:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		SUnvPlcRecCnt--;
		if(SUnvPlcRecCnt <= 0){
			ret= 0;		/* Command End */
			Port_TimeoutCnt = 0;	/* 20060203 */
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/

static	void	C_SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif

#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif

}
/******************************************/
/************************************/
/*	Device & Address Change			*/
/************************************/
static	int	plcGetDevAddInf(int bwflag,unsigned char src,int *Keta,int *LowMax)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	C_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bwflag == 0){	/* Bit */
		if(PLCIndex[src] != 0xff){
			*Keta= ByteTbl[PLCIndex[src]].LowKeta;
			*LowMax= ByteTbl[PLCIndex[src]].LowDeviceMax;
			ret= 0;
		}
	}else{
		if(PLCIndex[src] != 0xff){
			*Keta= WordTbl[PLCIndex[src]].LowKeta;
			*LowMax= WordTbl[PLCIndex[src]].LowDeviceMax;
			ret= 0;
		}
	}
	return(ret);
}
static	void	plcChangeAddressUsr(int Digit1,int Digit0, int *Address,int LowMax,int Keta)
{
	int		i;
	unsigned int	work;
	unsigned int	work1;
	unsigned int	work2;

	work= (unsigned int)*Address;
	work1= work%LowMax;				/* 1Keta */
	work2= 0;
	for(i = 0;i < Keta; i++){
		work2 += (work1 % Digit0) << (i*4);
		work1= work1/Digit0;
	}
	work= work/LowMax;
	for(;i < 8; i++){
		if(work == 0){
			break;
		}
		work2 += (work % Digit1) << (i*4);
		work= work/Digit1;
	}
	*Address= work2;
}
/*********************************************************************/
static	int	plcSetPLCUsrAddr(int DevInfo,int Address,unsigned char idx,int bFlag)
{
	int		ret;
	int		LowMax;
	int		Keta;

	ret= plcGetDevAddInf(bFlag,idx,&Keta,&LowMax);
	if(ret == 0){
		LowMax++;
		ret= Address;
		switch(DevInfo & 0x0f){
		case 0:		/* 8/8 */
			plcChangeAddressUsr(8,8,&ret,LowMax,Keta);
			break;
		case 1:		/* 8/10 */
			plcChangeAddressUsr(8,10,&ret,LowMax,Keta);
			break;
		case 2:		/* 8/16 */
			plcChangeAddressUsr(8,16,&ret,LowMax,Keta);
			break;
		case 3:		/* 10/8 */
			plcChangeAddressUsr(10,8,&ret,LowMax,Keta);
			break;
		case 4:		/* 10/10 */
			plcChangeAddressUsr(10,10,&ret,LowMax,Keta);
			break;
		case 5:		/* 10/16 */
			plcChangeAddressUsr(10,16,&ret,LowMax,Keta);
			break;
		case 6:		/* 16/8 */
			plcChangeAddressUsr(16,8,&ret,LowMax,Keta);
			break;
		case 7:		/* 16/10 */
			plcChangeAddressUsr(16,10,&ret,LowMax,Keta);
			break;
		case 8:		/* 16/16 */
/*			ChangeAddressUsr(16,16,&ret,LowMax,Keta);*/
			break;
		case 9:		/* 16 */
			plcChangeAddressUsr(10,10,&ret,10,1);
			break;
		}
	}
	return(ret);
}

static int C_CheckDevice_Addr(int bwflag,char *DevName,unsigned int *Address1,unsigned int *Address2)
{
	int		i;
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;
	unsigned int		Max,Min;

	C_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	Max= 0;
	Min= 99999999;		//070827 999999->99999999
	if(bwflag == 0){	/* Bit */
		*Address1 = plcSetPLCUsrAddr(ByteTbl[PLCIndex[0x7F]].DevInfo, *Address1, 0x7F, bwflag);
		*Address2 = plcSetPLCUsrAddr(ByteTbl[PLCIndex[0x7F]].DevInfo, *Address2, 0x7F, bwflag);
		for(i= 0; i< PLCByteCnt; i++){
			if(B_gstrcmp(ByteTbl->DevName,DevName) == 0){
				if((*Address1 >= ByteTbl->DeviceMin) && (*Address1 <= ByteTbl->DeviceMax)&&(*Address2 <=ByteTbl->DeviceMax)){
					ret= 0;
				}else{
					if((ByteTbl->DeviceMin > *Address1) && (ByteTbl->DeviceMin < Min)){
						Min= ByteTbl->DeviceMin;
					}
					if((ByteTbl->DeviceMax < *Address1) && (ByteTbl->DeviceMax > Max)){
						Max= ByteTbl->DeviceMax;
					}
				}
			}
			ByteTbl++;
		}
	}else{
		*Address1 = plcSetPLCUsrAddr(WordTbl[PLCIndex[0xEF]].DevInfo, *Address1, 0xEF, bwflag);
		*Address2 = plcSetPLCUsrAddr(WordTbl[PLCIndex[0xEF]].DevInfo, *Address2, 0xEF, bwflag);
		for(i= 0; i< PLCWordCnt; i++){
			if(B_gstrcmp(WordTbl->DevName,DevName) == 0){
				if((*Address1 >= WordTbl->DeviceMin) && (*Address1 <= WordTbl->DeviceMax)&&(*Address2 <= WordTbl->DeviceMax)){
					ret= 0;
				}else{
					if((WordTbl->DeviceMin > *Address1) && (WordTbl->DeviceMin < Min)){
						Min= WordTbl->DeviceMin;
					}
					if((WordTbl->DeviceMax < *Address1) && (WordTbl->DeviceMax > Max)){
						Max= WordTbl->DeviceMax;
					}
				}
			}
			WordTbl++;
		}
	}
	*Address1= Max;
	*Address2= Min;
	return(ret);
}
/************************************/
/* ���ʏ���							*/
/************************************/
/* Table of CRC values for high.order byte */
static	const	unsigned char SUnv_auchCRCHi[] = {
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
} ;
/* Table of CRC values for low.order byte */
static	const	unsigned char SUnv_auchCRCLo[] = {
    0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 
    0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 
    0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 
    0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, 0x11, 0xD1, 0xD0, 0x10, 
    0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 
    0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 
    0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 
    0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, 0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 
    0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 
    0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 
    0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 
    0xB4, 0x74, 0x75, 0xB5, 0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 
    0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 
    0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 
    0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
    0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80, 0x40
} ;
static	unsigned short SUnv_crc16(unsigned char *puchMsg, int usDataLen)
{
    unsigned char uchCRCHi = 0xFF ; /* high byte of CRC initialized */
    unsigned char uchCRCLo = 0xFF ; /* low byte of CRC initialized */
    int uIndex ; /* will index into CRC lookup table */
	if(usDataLen <= 0){	return(0); }		/* 20090527 */
    while (usDataLen--) /* pass through message buffer */
    {
        uIndex = uchCRCHi ^ *puchMsg++ ; /* calculate the CRC */
        uchCRCHi = uchCRCLo ^ SUnv_auchCRCHi[uIndex] ;
        uchCRCLo = SUnv_auchCRCLo[uIndex] ;
    }
    return (uchCRCHi << 8 | uchCRCLo) ;
}

static	const	struct{
		int	sadd;		//�w��A�h���X���P�O�O�O�Ŋ������l�iUW�j
		int	oadd;		//���ۂ̃A�h���XUW[NNNN}
	}ChgUWTbl[66]={
		{ 0,    0},{ 1, 1000},{ 2, 2000},{ 3, 3000},{ 4, 4000},
		{ 5, 5000},{ 6, 6000},{ 7, 7000},{ 8, 7300},{ 9,   -1},
		{10, 7600},{11, 7700},{12,   -1},{13, 8000},{14,   -1},
		{15, 8300},{16, 8400},{17,   -1},{18, 8700},{19,   -1},
		{20, 9000},{21,10000},{22,11000},{23,12000},{24,13000},
		{25,14000},{26,15000},{27,16000},{28,17000},{29,18000},
		{30,   -1},{31,   -1},{32,   -1},{33,   -1},{34,   -1},
		{35,   -1},{36,19500},{37,   -1},{38,20000},{39,   -1},
		{40,21000},{41,22000},{42,23000},{43,24000},{44,25000},
		{45,26000},{46,27000},{47,28000},{48,29000},{49,30000},
		{50,   -1},{51,   -1},{52,   -1},{53,   -1},{54,   -1},
		{55,   -1},{56,   -1},{57,   -1},{58,   -1},{59,   -1},
		{60,31000},{61,32000},{62,   -1},{63,   -1},{64,   -1},
		{65,   -1},
	};

static	int	ChangeUWAddr(int bit_word,unsigned long* address)
{
	int	idx;
	int	ret;

	ret= NG;
	if(bit_word == PLC_BIT){
		idx= (*address/16000);
		if(ChgUWTbl[idx].oadd != -1){
			*address= (*address % 16000)+ (ChgUWTbl[idx].oadd << 4);
			ret= OK;
		}
	}else{
		idx= (*address/1000);
		if(ChgUWTbl[idx].oadd != -1){
			*address= (*address % 1000)+ ChgUWTbl[idx].oadd;
			ret= OK;
		}
	}
	return(ret);
}
/****************************************************************/
/*	FUNC    :�ėp�ʐM�i���R?�h�����j							*/
/*	����	:char *RecBuff:��M�o�b�t?							*/
/*			:int RecCnt:��M�����O�X							*/
/*			:char *SndBuff:���M�o�b�t?							*/
/*			:int *SndCnt:���M�����O�X							*/
/*			   STX,DATA,ETX,SUM									*/
/*			   STX,DATA,CR										*/
/****************************************************************/
static	void	SUniversalError(unsigned char *RecBuff,char *SndBuff,int *SndCnt,int Code)
{
	int		idx;
	unsigned short	_crc16;

	idx= 0;
	SndBuff[idx++]= RecBuff[0];	/* �ǔ� */
	SndBuff[idx++]= RecBuff[1];	/* Command */
	SndBuff[idx++]= Code  | 0x80;		/* Code */
	_crc16= SUnv_crc16((unsigned char *)SndBuff,idx);
	SndBuff[idx++]= (char)(_crc16 >> 8);
	SndBuff[idx++]= (char)_crc16;
	*SndCnt= idx;
}
static	void	SUniversalRead(unsigned char *RecBuff,char *SndBuff,int *SndCnt,int mode)
{
	int		Cnt;
	int		i,idx;
	unsigned int		didx, uwAddr, ubAddr;
	unsigned int		address;
	unsigned short	_crc16;

//////////////////////////////////////////////////////////////
	unsigned int Realaddress, REndaddress;
	int AddrCheck;
	int EndAddrCheck;

	char sendBuff;
	int CmpBit,tBit;
	int ret;

	idx= 0;
	SndBuff[idx++]= RecBuff[0];	/* �ǔ� */
	SndBuff[idx++]= RecBuff[1];	/* Command */


	switch(RecBuff[1]){
	case	MDBUS_READ_COIL_STATUS:
	case	MDBUS_READ_INPUT_STATUS:
		address= (RecBuff[2] << 8) + RecBuff[3];
		Cnt= (RecBuff[4] << 8) + RecBuff[5];
		SndBuff[idx++]= (Cnt-1)/8+1;	 //Count 
		
		
		ret = NG;
		REndaddress= address + Cnt -1;
		Realaddress = REndaddress;
		EndAddrCheck = ChangeUWAddr(PLC_BIT, (unsigned long*)&Realaddress);
		Realaddress = address;
		AddrCheck = ChangeUWAddr(PLC_BIT, (unsigned long*)&Realaddress);
//		if(C_CheckDevice_Addr(0,"UB",&address,&REndaddress)==OK)
		if((address >= UNVERS_READ_START) && (address <= UNVERS_UB_END) && (REndaddress <= UNVERS_UB_END))
		{
			if(EndAddrCheck==0 && AddrCheck==0)
			{
				uwAddr = Realaddress>>4;
				ubAddr = Realaddress &0x0f;
				sendBuff=0x00;
				//���� �� ��Ʈ 
				CmpBit = 0x01 << ubAddr;
				for(i=1; i<=Cnt; i++)
				{
					tBit=0x00;
					if((InDevArea.UW[uwAddr+(ubAddr/16)] & CmpBit)!=0)
					{
						tBit=0x01;
					}
					ubAddr++;
					CmpBit<<=1;

					sendBuff = sendBuff | (tBit<<(i-1)%8);
					if( i % 8==0 || i == Cnt)
					{
						SndBuff[idx++]=sendBuff;
						sendBuff=0x00;
					}
					
					if(CmpBit==0x10000){CmpBit=0x01;}
				}
				_crc16= SUnv_crc16((unsigned char *)SndBuff,idx);
				SndBuff[idx++]= (char)(_crc16 >> 8);
				SndBuff[idx++]= (char)_crc16;
				*SndCnt= idx;
				break;
			}else{
				SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
			}
		}else{
			SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}
		if(ret == NG)
		{
			SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}
		break;
	case MDBUS_READ_HOLDING_REG:
	case MDBUS_READ_INPUT_REG:
		address= (RecBuff[2] << 8) + RecBuff[3];
		Cnt= (RecBuff[4] << 8) + RecBuff[5];
		SndBuff[idx++]= Cnt*2;	 //Count 

//		for(i=0; i < 256; i++){
//			if(PLCIndex[i]==0x0a){
//				bitIndex = i;
//				break;
//			}			
//		}


		didx= address;
		REndaddress= address+ Cnt - 1;
		
		// Address Check
		Realaddress = REndaddress;
		EndAddrCheck = ChangeUWAddr(PLC_WORD, (unsigned long*)&Realaddress);

		Realaddress = address;
		AddrCheck = ChangeUWAddr(PLC_WORD, (unsigned long*)&Realaddress);

		//
//		didx = plcSetPLCUsrAddr(WordTbl[PLCIndex[bitIndex]].DevInfo, address, bitIndex, mode);
//		REndaddress = plcSetPLCUsrAddr(WordTbl[PLCIndex[bitIndex]].DevInfo, REndaddress, bitIndex,mode);	
//		didx = plcSetPLCUsrAddr(WordTbl[PLCIndex[0xef]].DevInfo, address, 0xef, 1);
//		Endaddress = plcSetPLCUsrAddr(WordTbl[PLCIndex[0xef]].DevInfo, REndaddress, 0xef,1);	

		ret = NG;

//			if(C_CheckDevice_Addr(1,"UW",&address, &REndaddress)==OK){
		//if((WordTbl[i].DeviceMin <= didx) && (WordTbl[i].DeviceMax > Endaddress) && (WordTbl[i].DeviceMax > didx) && (didx <= Endaddress)){
		//if((address >= UNVERS_READ_START) && (address <= UNVERS_READ_END) && (Endaddress <= UNVERS_READ_END)){
		if( (address >= UNVERS_READ_START) && (address <= UNVERS_UW_END) && (REndaddress <= UNVERS_UW_END)){
			if(EndAddrCheck==0 && AddrCheck==0)
			{
				for(i= 0; i < Cnt; i++){
#ifdef	SH_CPU
					SndBuff[idx++]= (char)InDevArea.UW[Realaddress];
					SndBuff[idx++]= (char)(InDevArea.UW[Realaddress++] >> 8);
#endif
#ifdef	ARM_CPU
					SndBuff[idx++]= (char)(InDevArea.UW[Realaddress] >> 8);
					SndBuff[idx++]= (char)InDevArea.UW[Realaddress++];
#endif
				}
				_crc16= SUnv_crc16((unsigned char *)SndBuff,idx);
				SndBuff[idx++]= (char)(_crc16 >> 8);
				SndBuff[idx++]= (char)_crc16;
				*SndCnt= idx;
				ret = OK;
				break;
			}
		}
		if(ret == NG){
				SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}
		break;
	}
}

static const struct{
	int	start;
	int	end;
}DiDevTbl[]={
	{Device_Length_V_ST,Device_Length_V_ST+Device_Length_V},
	{Device_Length_F_ST,Device_Length_F_ST+Device_Length_F},
	{0x0000,0x0010}, /* 20080822  UW0 - UW15 */
};
static int	CheckPlcDevAccess(int StartAddr,int EndAddr)
{
	int		i;
	int	ret= OK;

	for(i= 0; i < TBQ(DiDevTbl); i++){
		if(StartAddr < DiDevTbl[i].start){
			if(EndAddr >= DiDevTbl[i].start){
				ret= NG;
				break;
			}
		}else{
			if(StartAddr <= DiDevTbl[i].end){
				ret= NG;
				break;
			}
		}
	}
	return(ret);
}

static	void	SUniversalWrite(unsigned char *RecBuff,int RecCnt,char *SndBuff,int *SndCnt,int mode)
{
	int		Cnt,i;
	int		idx;
	unsigned int		didx;
	unsigned int		address, REndaddress, Realaddress;
	unsigned int		Endaddress;
	unsigned short	_crc16;

	/**************************************************/
	int AddrCheck;
	int EndAddrCheck;
	int ret;

	int PLCByteCnt;
	int PLCWordCnt;
	DEV_PC_TBL *ByteTbl;
	DEV_PC_TBL *WordTbl;
	unsigned char *PLCIndex;
	int uwAddr,ubAddr;
	int CmpBit;

	C_SetPLCDevAddr(&PLCByteCnt, &PLCWordCnt, &ByteTbl, &WordTbl, &PLCIndex);  // ����̽� ���̺� ����
	
	switch(RecBuff[1]){
	case MDBUS_FORCE_SINGLE_COIL:
		idx= 0;
		SndBuff[idx++]= RecBuff[0];	/* ���� */
		SndBuff[idx++]= RecBuff[1];	/* Command */

		address= (RecBuff[2] << 8) + RecBuff[3];
		SndBuff[idx++]= RecBuff[2]; /* ���� �ּ� Hi */
		SndBuff[idx++]= RecBuff[3]; /* ���� �ּ� Lo */

		//Address������A�h���X�ɂ���B
		Realaddress = address;
		AddrCheck = ChangeUWAddr(PLC_BIT,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */

	
//		if(C_CheckDevice_Addr(0,"UB",&address, &Endaddress)==0){
		if((address >= UNVERS_UB_W_START) && (address <= UNVERS_UB_END)){
			if(AddrCheck == 0){
#ifdef LP_S044
				if(CheckPlcDevAccess(Realaddress,Realaddress) == OK){
#else
					if(OK){
#endif
					uwAddr = Realaddress >>4;
					ubAddr = Realaddress & 0x0f;

					CmpBit = 0x01 << ubAddr;
					
					if(RecBuff[4]==0xff){
						InDevArea.UW[uwAddr]=InDevArea.UW[uwAddr] | CmpBit;
					}else{
						InDevArea.UW[uwAddr]=InDevArea.UW[uwAddr] &(~CmpBit);
					}
					
					SndBuff[idx++]= RecBuff[4];	/* Register Cnt */
					SndBuff[idx++]= RecBuff[5];	/*  */
					_crc16= SUnv_crc16((unsigned char *)SndBuff,idx);
					SndBuff[idx++]= (char)(_crc16 >> 8);
					SndBuff[idx++]= (char)_crc16;
					*SndCnt= idx;
					break;
				}else{
					SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
				}
			}else{
				SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
			}
		}else{
			SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}
		break;

	case MDBUS_FORCE_MULTIPLE_COILS:
		idx= 0;
		SndBuff[idx++]= RecBuff[0];	/* ���� */
		SndBuff[idx++]= RecBuff[1];	/* Command */

		address= (RecBuff[2] << 8) + RecBuff[3];
		SndBuff[idx++]= RecBuff[2]; /* ���� �ּ� Hi */
		SndBuff[idx++]= RecBuff[3]; /* ���� �ּ� Lo */

		Cnt = (RecBuff[4]<<8)+RecBuff[5];
		SndBuff[idx++]= RecBuff[4]; // bit Count Hi
		SndBuff[idx++]= RecBuff[5]; // bit Count Low

		//Address������A�h���X�ɂ���B
		Endaddress= address+ Cnt;

		Realaddress = Endaddress;
		EndAddrCheck = ChangeUWAddr(PLC_BIT,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */		

		Realaddress = address;
		AddrCheck = ChangeUWAddr(PLC_BIT,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */

		//if(C_CheckDevice_Addr(0,"UB",&address, &Endaddress)==0){
		if((address >= UNVERS_UB_W_START) && (address <= UNVERS_UB_END) && (Endaddress <= UNVERS_UB_END)){
			if(AddrCheck == 0 && EndAddrCheck == 0){
				Endaddress = Realaddress + Cnt -1;
#ifdef LP_S044
				if(CheckPlcDevAccess((Realaddress>>4),(Endaddress>>4)) == OK){
#endif
				uwAddr = Realaddress >>4;  
					ubAddr = Realaddress & 0x0f;

					CmpBit = 0x01 << ubAddr;
					
					for(i=0; i<Cnt; i++)
					{
						if((RecBuff[7+i/8]&(0x01<<(i%8)))==0x00){
							InDevArea.UW[uwAddr]&=~CmpBit;
						}else{
							InDevArea.UW[uwAddr]|=CmpBit;
						}
						CmpBit<<=0x01;
						if(CmpBit== 0x10000){
							CmpBit=0x01;
							uwAddr++;
						}
					}	
					_crc16= SUnv_crc16((unsigned char *)SndBuff,idx);
					SndBuff[idx++]= (char)(_crc16 >> 8);
					SndBuff[idx++]= (char)_crc16;
					*SndCnt= idx;
					break;
#ifdef LP_S044
				}else{
					SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
				}
#endif
			}else{
				SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
			}
		}else{
			SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}

		break;
	case MDBUS_PRESET_MULTIPLE_REG:			/* Preset Multiple Registers */
		address= (RecBuff[2] << 8) + RecBuff[3];
		Cnt= ((RecBuff[4] << 8) + RecBuff[5])* 2;
		idx= 7;
		REndaddress= address+ (Cnt/2 - 1);
		ret = NG;
		
//		for(i=0; i < 256; i++){
//			if(PLCIndex[i]==0x0d){
//				bitIndex = i;
//				break;
//			}			
//		}

		didx = REndaddress;
		EndAddrCheck= ChangeUWAddr(PLC_WORD, (unsigned long*)&didx); /* ��������̽��� ���� ����̽��� ��ȯ */

		didx = address;
		AddrCheck = ChangeUWAddr(PLC_WORD, (unsigned long*)&didx); /* ��������̽��� ���� ����̽��� ��ȯ */

		ret=NG;
		if((address >= UNVERS_WRITE_START) && (address <= UNVERS_UW_END) && (REndaddress <= UNVERS_UW_END))
		//		if(C_CheckDevice_Addr(1,"UW",&address, &REndaddress)==0)
		{
			if((AddrCheck==0)&&(EndAddrCheck==0)){
				REndaddress = didx+(Cnt/2-1);
				if(CheckPlcDevAccess(didx, REndaddress)==OK){
					for(i= 0; i < Cnt/2; i++){
#ifdef	SH_CPU
						InDevArea.UW[didx]= RecBuff[idx++];
						InDevArea.UW[didx++] += RecBuff[idx++] << 8;
#endif
#ifdef	ARM_CPU /*2009 05 13*/
						InDevArea.UW[didx]= RecBuff[idx++] << 8;
						InDevArea.UW[didx++] += RecBuff[idx++]; 				
#endif
					}
					idx= 0;
					SndBuff[idx++]= RecBuff[0];	/* �ǔ� */
					SndBuff[idx++]= RecBuff[1];	/* Command */
					SndBuff[idx++]= RecBuff[2];	/* Start Addr */
					SndBuff[idx++]= RecBuff[3];	/*  */
					SndBuff[idx++]= RecBuff[4];	/* Register Cnt */
					SndBuff[idx++]= RecBuff[5];	/*  */
					_crc16= SUnv_crc16((unsigned char *)SndBuff,idx);
					SndBuff[idx++]= (char)(_crc16 >> 8);
					SndBuff[idx++]= (char)_crc16;
					*SndCnt= idx;
					ret = OK;
					break;
				}else{
					SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
				}
			}else{
				SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
			}
		}
		if(ret==NG){
				SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}
		break;
	}
}
/*ksc 20050307 */
static	void	SUniversalBroadWrite(unsigned char *RecBuff,int RecCnt,char *SndBuff,int *SndCnt,int mode)
{
	int		Cnt,i;
	int		idx;
	int		didx;
	unsigned int	address;
	unsigned int	Endaddress;
	int EndAddrCheck, AddrCheck, Realaddress;
	int CmpBit;
	int uwAddr, ubAddr;

	switch(RecBuff[1]){
		case MDBUS_FORCE_MULTIPLE_COILS:
		address= (RecBuff[2] << 8) + RecBuff[3];

		Cnt = (RecBuff[4]<<8)+RecBuff[5];

		//Address������A�h���X�ɂ���B
		Endaddress= address+ Cnt;

		Realaddress = Endaddress;
		EndAddrCheck = ChangeUWAddr(PLC_BIT,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */		

		Realaddress = address;
		AddrCheck = ChangeUWAddr(PLC_BIT,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */

//		if(C_CheckDevice_Addr(0,"UB",&address, &Endaddress)==0){
		if((address >= UNVERS_UB_W_START) && (address <= UNVERS_UB_END) && (Endaddress <= UNVERS_UB_END)){
			if(AddrCheck == 0 && EndAddrCheck == 0){
				Endaddress = Realaddress + Cnt -1;
				if(CheckPlcDevAccess((Realaddress>>4),(Endaddress>>4)) == OK){
				uwAddr = Realaddress >>4;  
					ubAddr = Realaddress & 0x0f;

					CmpBit = 0x01 << ubAddr;
					
					for(i=0; i<Cnt; i++)
					{
						if((RecBuff[7+i/8]&(0x01<<(i%8)))==0x00){
							InDevArea.UW[uwAddr]&=~CmpBit;
						}else{
							InDevArea.UW[uwAddr]|=CmpBit;
						}
						CmpBit<<=0x01;
						if(CmpBit== 0x10000){
							CmpBit=0x01;
							uwAddr++;
						}
					}	
					*SndCnt= 0;
					break;
				}
			}
		}
		break;
	case MDBUS_PRESET_MULTIPLE_REG:			/* Preset Multiple Registers */
		address= (RecBuff[2] << 8) + RecBuff[3];
		Cnt= ((RecBuff[4] << 8) + RecBuff[5])* 2;
		idx= 7;
		Endaddress= address+ (Cnt/2 - 1);
		Realaddress = Endaddress;
		EndAddrCheck = ChangeUWAddr(PLC_WORD,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */		

		Realaddress = address;
		AddrCheck = ChangeUWAddr(PLC_WORD,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */

//		if(C_CheckDevice_Addr(1,"UW",&address, &Endaddress)==0){
		if((address >= UNVERS_WRITE_START) && (address <= UNVERS_UW_END) && (Endaddress <= UNVERS_UW_END)){
			
			if((AddrCheck==0)&&(EndAddrCheck==0)){
			didx= Realaddress;
			for(i= 0; i < Cnt/2; i++){
				if(CheckPlcDevAccess(didx, didx+(Cnt/2-1))==OK){
#ifdef	SH_CPU
					InDevArea.UW[didx]= RecBuff[idx++];
					InDevArea.UW[didx++] += RecBuff[idx++] << 8;
#endif
#ifdef	ARM_CPU /*2009 05 13*/
					InDevArea.UW[didx]= RecBuff[idx++] << 8;
					InDevArea.UW[didx++] += RecBuff[idx++]; 				
#endif
				}
			}
			}

		}
		*SndCnt= 0; /* *SndCnt = 0 No response */
		break;
	}
}
/*ksc 20050307 */

static	int	SHanyouComm(char	*RecBuff,int RecCnt,char *SndBuff,int *SndCnt)
{
	int		ret;
	unsigned short	_crc16;
	unsigned short	sum1;
	unsigned char work;

	ret = 0;
	*SndCnt= 0;		/* 20061023 */	
	/* Check SUM Check */
	_crc16= SUnv_crc16((unsigned char *)RecBuff,RecCnt- 2);
	work= (unsigned char)RecBuff[RecCnt- 2];
	sum1= (work << 8)+ (unsigned char)RecBuff[RecCnt- 1];
	if(_crc16 != sum1){
		ret= -1;
	}
	if((Set.iGPSta != RecBuff[0]) && (RecBuff[0] != 0)){ 	/* Address = 0 ok Broadcast */
		ret= -2;	
	}
	if(ret == 0){			/* ��MOK */
		switch(RecBuff[1]){
		case MDBUS_READ_COIL_STATUS:		
		case MDBUS_READ_INPUT_STATUS:
		case MDBUS_READ_HOLDING_REG:		/* Read Holding Reg */
		case MDBUS_READ_INPUT_REG:
			if(RecBuff[0] != 0){	/* 20061023 */
				SUniversalRead((unsigned char *)RecBuff,SndBuff,SndCnt,0);
			}
			break;

		case MDBUS_FORCE_SINGLE_COIL:
		case MDBUS_FORCE_MULTIPLE_COILS:
		case MDBUS_PRESET_MULTIPLE_REG:		/* Multiple Regs */
		
			if(RecBuff[0] != 0){
				SUniversalWrite((unsigned char *)RecBuff,RecCnt,SndBuff,SndCnt,0);
			}else{
				SUniversalBroadWrite((unsigned char *)RecBuff,RecCnt,SndBuff,SndCnt,0);
			}
			break;

		default:
			if(RecBuff[0] != 0){	/* 20061023 */
				SUniversalError((unsigned char *)RecBuff,SndBuff,SndCnt,UNVERS_ERR_FNC);
			}		
			break;
		}
	}else{
		if(ret == -1){
/*			SUniversalError((unsigned char *)RecBuff,SndBuff,SndCnt,UNVERS_ERR_DAT); 20061023 */
		}else{
			*SndCnt= 0;
		}
	}
	return(ret);
}
/********************************************************/
static	int	C_Connection( int *PlcType, int iConnect ) /* 20061025ksc */ 
{
	int		ret;

#ifdef	SH_CPU
	Port_TimeoutCnt = 0;	/* 20060203 */

	Pro_Speed = PlcType[3];			/* 20061025ksc */ 

	switch(Pro_Speed){		
	case 0:						/* 300bps */
		Plc_sync_time = 50;
		break;
	case 1:						/* 600bps */
		Plc_sync_time = 30;
		break;
	case 2:						/* 1200bps */
	case 3:						/* 2400bps */
	case 4:						/* 4800bps */
	case 5:						/* 9600bps */
	case 6:						/* 19200bps */
	case 7:						/* 38400bps */
	case 8:						/* 57600bps */
	case 9:						/* 115200bps */
		Plc_sync_time = 20;
		break;
	default:
		Plc_sync_time = 50;
		break;
	}
#endif
#ifdef	ARM_CPU
	Port_TimeoutCnt = 0;	/* 20060203 */

	Pro_Speed = PlcType[3];			/* 20061025ksc */ 

	switch(Pro_Speed){		
	case 0:						/* 300bps */
		Plc_sync_time = 280;	/* ������ ���� �ð� 120ms = [ 33.3ms * 3(3���ں�) + 10ms(����Ÿ�̸�) ] �̽ð����ٴ� ū �ð����� ���� */
		break;
	case 1:						/* 600bps */
		Plc_sync_time = 150;
		break;
	case 2:						/* 1200bps */
		Plc_sync_time = 80;
		break;
	case 3:						/* 2400bps */
		Plc_sync_time = 50;
		break;
	case 4:						/* 4800bps */
		Plc_sync_time = 20;
		break;
	case 5:						/* 9600bps */
		Plc_sync_time = 20;
		break;
	case 6:						/* 19200bps */
		Plc_sync_time = 20;
		break;
	case 7:						/* 38400bps */
		Plc_sync_time = 20;
		break;
	case 8:						/* 57600bps */
		Plc_sync_time = 20;
		break;
	case 9:						/* 115200bps */
		Plc_sync_time = 20;
		break;
	default:
		Plc_sync_time = 20;
		break;
	}
#endif




	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */
#ifdef	TEST			 /* 20061025ksc */ 
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);  */

		}else{						/* RS-422 */

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE); */

		}
#ifdef	WIN32
		while(1){
			if(SioPLCOpenFlag == 0){
				break;
			}
			B_Delay(10);
		}
#endif
		B_Delay(500);
#endif
	}
	ret= 1;
	return(ret);
}

/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	C_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/************************************/
/* PLC Read							*/
/************************************/
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(0);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/************************************/
/* PLC Write						*/
/************************************/
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(0);
}
static	int	C_GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}


/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType, int iConnect) 
{
	return(C_Connection(PlcType, iConnect)); 
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	C_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	C_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	return(ret);
}
/************************************************/
/*	�O��?�v����								*/
/************************************************/
/****************************************/
/*	�O��?�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	return(0);
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	return(0);
}
/************************************/
/*	�X��?��?�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	int	PlcCommCnt;
/*	B_Delay(30); *//* 20061025ksc */
	SHanyouComm((char *)CommBuff,*RecCommCnt,(char *)PlcSendBuff,&PlcCommCnt);
	if(PlcCommCnt != 0){
		B_SendPC2PLCData(0,PlcCommCnt,(char *)PlcSendBuff,3000);
	}
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	C_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
#endif
/*++++++++++++++++++++++++++++++++++++*/
#ifdef PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif

#include  "hook_aplplc.h"

/****************************** END **********************/
