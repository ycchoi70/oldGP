void		vBackLightSet(int* iScreenNo);
