/********************************************************************************/
/* �� �� �� : Gp_PartTask.cpp													*/
/* ��    �� : NumericTask														*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 2002�� 6��4�� (ȭ) ����											*/
/********************************************************************************/
#include	"sgt.h"

/********************************************************************************/
/* �� �� �� : DrawParts_Task													*/
/* ��    �� : Parts ������ �ص��Ͽ� ȭ�鿡 ���								    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 2002�� 6��4�� (ȭ) ����											*/
/********************************************************************************/
void	SetParts_Func(int iDispOrder)
{
	_PARTS_EVENT_TBL*	 partsDispEventTbl;
	partsDispEventTbl= (_PARTS_EVENT_TBL*)TakeMemory(sizeof(_PARTS_EVENT_TBL));
	DrawParts_Func(0,partsDispEventTbl,iDispOrder);
	FreeMail((char *)partsDispEventTbl);
}
int DrawParts_Func(int mode,_PARTS_EVENT_TBL* partsDispEventTbl,int iDispOrder)
{
/*	unsigned int		iTagSizeOf;*/
	int					iOffset;
	unsigned char		*buffer;
/*	_PARTS_EVENT_TBL*	 partsDispEventTbl;*/
	buffer= ScreenTagData[iDispOrder].TagPos;
/*
	if(CheckMailBox(sizeof(_PARTS_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_PARTS_EVENT_TBL));
	partsDispEventTbl= (_PARTS_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)partsDispEventTbl, 0x00, sizeof(_PARTS_EVENT_TBL));
/*	
	iTagSizeOf = 0x00;
	iTagSizeOf  = (unsigned int)(buffer[0] << 0x08);
	iTagSizeOf += (unsigned int)buffer[1] & 0xff;
*/
/*	partsDispEventTbl->BeShapeUsed = 0;*/	  /* And: 1, Or: 0�� ���� Ŭ����. */
/*	partsDispEventTbl->sX  = (unsigned int)(buffer[6]  << 0x08);
	partsDispEventTbl->sX += (unsigned int)buffer[7] & 0xff;

	partsDispEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
	partsDispEventTbl->sY += (unsigned int)buffer[9] & 0xff;

	partsDispEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
	partsDispEventTbl->eX += (unsigned int)buffer[11] & 0xff;

	partsDispEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
	partsDispEventTbl->eY += (unsigned int)buffer[13] & 0xff;	
	partsDispEventTbl->dsX= partsDispEventTbl->sX;
	partsDispEventTbl->dsY= partsDispEventTbl->sY;
	partsDispEventTbl->deX= partsDispEventTbl->eX;
	partsDispEventTbl->deY= partsDispEventTbl->eY;
*/
	/* 060926 */
	ScreenTagData[iDispOrder].sX  = (unsigned int)(buffer[6]  << 0x08);
	ScreenTagData[iDispOrder].sX += (unsigned int)buffer[7] & 0xff;

	ScreenTagData[iDispOrder].sY  = (unsigned int)(buffer[8] << 0x08);
	ScreenTagData[iDispOrder].sY += (unsigned int)buffer[9] & 0xff;

	ScreenTagData[iDispOrder].eX  = (unsigned int)(buffer[10] << 0x08);
	ScreenTagData[iDispOrder].eX += (unsigned int)buffer[11] & 0xff;

	ScreenTagData[iDispOrder].eY  = (unsigned int)(buffer[12] << 0x08);
	ScreenTagData[iDispOrder].eY += (unsigned int)buffer[13] & 0xff;	


	if((unsigned int)buffer[14] == 0x00){
		partsDispEventTbl->iPositionInfo = TOP_LEFT;
	}
	else{
		partsDispEventTbl->iPositionInfo = CENTER;
	}
	partsDispEventTbl->iBitWordFlag = (unsigned int)buffer[15];  /* 0x01(Word), 0x02(Bit), 0x03(Fixed) */

	if(partsDispEventTbl->iBitWordFlag != 3){/* Bit or Word�� ��� */
		if(mode == 0){
			/*------------------------------------------------------------*/
			GetDeviceSet((buffer+16),
						partsDispEventTbl->cDeviceName,
						&(partsDispEventTbl->iDeviceNumber));
			/*-------------------------------------------------------------*/		
		}
	}
	iOffset = 21;
	partsDispEventTbl->iType = buffer[iOffset]; /* iType 0x00(device,part),0x01(device,Mark),0x02(Fixed,Mark),0x03(Fixed,Part) */
	switch(partsDispEventTbl->iType){
		case 0:
			iOffset+=3;
			partsDispEventTbl->BitOnNo		= (unsigned int)(buffer[iOffset] << 0x08);
			partsDispEventTbl->BitOnNo		+= (unsigned int)(buffer[++iOffset] & 0xff);
			partsDispEventTbl->BitOffNo		= (unsigned int)(buffer[++iOffset] << 0x08);
			partsDispEventTbl->BitOffNo		+= (unsigned int)(buffer[++iOffset] & 0xff);
			break;
		case 1:
			iOffset++;
			partsDispEventTbl->BitOnColor	= (unsigned int)buffer[iOffset];
			partsDispEventTbl->BitOffColor	= (unsigned int)buffer[++iOffset];					
			partsDispEventTbl->iMarkNo		= (unsigned int)(buffer[++iOffset] << 0x08);
			partsDispEventTbl->iMarkNo		+= (unsigned int)(buffer[++iOffset] & 0xff);
			break;
		case 2:
			iOffset++;
			partsDispEventTbl->iFixedColor	= (unsigned int)buffer[iOffset];
			iOffset+=2;
			partsDispEventTbl->iPartsSwitchingNo	= (unsigned int)(buffer[iOffset] << 0x08);
			partsDispEventTbl->iPartsSwitchingNo	+= (unsigned int)(buffer[++iOffset] & 0xff);
			break;
		case 3:
			iOffset+=3;
			partsDispEventTbl->iPartsSwitchingNo	= (unsigned int)(buffer[iOffset] << 0x08);
			partsDispEventTbl->iPartsSwitchingNo	+= (unsigned int)(buffer[++iOffset] & 0xff);
			break;	
	}
	iOffset = 28;
	if(partsDispEventTbl->iBitWordFlag == 1){	/* Word */
		partsDispEventTbl->iStartNo = (short)(buffer[iOffset] << 0x08);
		partsDispEventTbl->iStartNo += (short)(buffer[++iOffset] & 0xff);

		partsDispEventTbl->iPreComment  = (unsigned int)(buffer[++iOffset] << 0x08);
		partsDispEventTbl->iPreComment += (unsigned int)(buffer[++iOffset] & 0xff);
	}
	if(mode == 0){
		if(partsDispEventTbl->iBitWordFlag == 0x02){ 
			if(mode == 0){
				DeviceDataHed[DeviceCnt].DevFlag = DEVICE_BIT;/* Bit */
				DeviceDataHed[DeviceCnt].DevName[0] = partsDispEventTbl->cDeviceName[0];
				DeviceDataHed[DeviceCnt].DevName[1] = partsDispEventTbl->cDeviceName[1];
				DeviceDataHed[DeviceCnt].DevAddress = partsDispEventTbl->iDeviceNumber;
				DeviceDataHed[DeviceCnt].DevCnt = 1;				
				DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];
/*			partsDispEventTbl->iRegisterNumber = DeviceCnt;*/
			/* 20020819 choijh add*/
/*			partsDispEventTbl->SuperVOffset= WatchingDevice(partsDispEventTbl->cDeviceName, 
											partsDispEventTbl->iDeviceNumber,
											0,
											partsDispEventTbl->iRegisterNumber,
											BIT,DeviceDataHed[DeviceCnt].DevCnt);
*/
				ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
				ScreenTagData[iDispOrder].DevCnt= DeviceDataHed[DeviceCnt].DevCnt;
				iDeviceOffset++;
				DeviceCnt++;
			}
		}
		else if(partsDispEventTbl->iBitWordFlag == 0x01){
			if(mode == 0){
				DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */			
				DeviceDataHed[DeviceCnt].DevName[0] = partsDispEventTbl->cDeviceName[0];
				DeviceDataHed[DeviceCnt].DevName[1] = partsDispEventTbl->cDeviceName[1];
				DeviceDataHed[DeviceCnt].DevAddress = partsDispEventTbl->iDeviceNumber;
				DeviceDataHed[DeviceCnt].DevCnt = 1;			
				DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];			
/*				partsDispEventTbl->iRegisterNumber = DeviceCnt;*/
			/* 20020819 choijh add*/
/*				partsDispEventTbl->SuperVOffset= WatchingDevice(partsDispEventTbl->cDeviceName, 
											partsDispEventTbl->iDeviceNumber,
											0,
											partsDispEventTbl->iRegisterNumber,
											WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
				ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
				ScreenTagData[iDispOrder].DevCnt= DeviceDataHed[DeviceCnt].DevCnt*2;
				iDeviceOffset+=2;
				DeviceCnt++;
			}
		}
		if(mode == 0){
			PartDispCnt++;
		}
	}
/*	IventTableCnt++;*/

	return(0);
}

/********************************************************************************/
/* �� �� �� : PartsDispWatch													*/
/* ��    �� : Parts�±������� ����  ȭ�鿡 ����� ����Ѵ�.						*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 4�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/* (1) Parts����ġ�� ���� Fixed�� ��� �׶��� Parts SwitchNo���� ���õ� Parts   */
/*	   ������ ���̵��̴�.														*/
/* (2) Mark������ Checked���� ���, Parts SwitchNo���� Type No���� ��ġ�ؾ� �Ѵ�*/
/* (3) Basic Tab���� Fixed�� Color����Mark�� ��츸 �ش��Ѵ�.					*/
/* (4) �ٿ�ε� �Ǵ� Parts Disp�� Parts�� Mark 2���� ������ ������ Parts�� ��� */
/*     �Ϲ����� �̹������̸� Mark������ ���, �����±��������� �������� �ٿ�ȴ�*/ 
/********************************************************************************/
void PartsDispWatch(int iOrder){
//	int				i;
	int				iDeviceValue;
	int				iPartsNo;
	int				iColor;
	int				iNumber;
	_PARTS_EVENT_TBL*	 partsDispEventTbl;
	char			cDeviceVal[8];

/*	partsDispEventTbl= (_PARTS_EVENT_TBL*)IventTable[iOrder];*/
	partsDispEventTbl= (_PARTS_EVENT_TBL*)TakeMemory(sizeof(_PARTS_EVENT_TBL));
	DrawParts_Func(1,partsDispEventTbl,iOrder);

	iDeviceValue = 0;

//	i = iOrder;

	iColor = -1;
/*	if(iOnSignalStart == ON){*/
		/* 2:Bit */
		if(partsDispEventTbl->iBitWordFlag == 2){
/*			iDeviceValue = partsDispEventTbl->iBefDevVal;*/
			iDeviceValue = DispDeviceData[ScreenTagData[iOrder].DevOrder];
			if(iDeviceValue == 0){/* OFF */
				if(partsDispEventTbl->iType==0x01)
				{
					iColor = partsDispEventTbl->BitOffColor;
					iNumber = partsDispEventTbl->iMarkNo;
				}else
				{
					iNumber = partsDispEventTbl->BitOffNo;
				}
/* 060926				vPartDataSet(iNumber,iOrder,0,iColor);*/			/* Mark �϶��� ����ȭ ������ ������ �Ķ����(iColor)�� ����. */
				vPartDataSet(ScreenTagData[iOrder].sX,ScreenTagData[iOrder].sY,ScreenTagData[iOrder].eX,ScreenTagData[iOrder].eY,
								iNumber,iOrder,0,iColor);			/* Mark �϶��� ����ȭ ������ ������ �Ķ����(iColor)�� ����. */
			}
			else if(iDeviceValue == 1){/* ON */
				if(partsDispEventTbl->iType==0x01)
				{
					iColor = partsDispEventTbl->BitOnColor;
					iNumber = partsDispEventTbl->iMarkNo;
				}else
				{
					iNumber = partsDispEventTbl->BitOnNo;
				}
/* 060926				vPartDataSet(iNumber,iOrder,0,iColor);*/
				vPartDataSet(ScreenTagData[iOrder].sX,ScreenTagData[iOrder].sY,ScreenTagData[iOrder].eX,ScreenTagData[iOrder].eY,
								iNumber,iOrder,0,iColor);
			}
		}
		/* 3:Fixed */
		else if(partsDispEventTbl->iBitWordFlag == 3){
			if(partsDispEventTbl->iType==0x02)
				iColor = partsDispEventTbl->iFixedColor;
/* 060926			vPartDataSet(partsDispEventTbl->iPartsSwitchingNo,iOrder,0,iColor);*/
			vPartDataSet(ScreenTagData[iOrder].sX,ScreenTagData[iOrder].sY,ScreenTagData[iOrder].eX,ScreenTagData[iOrder].eY,
						partsDispEventTbl->iPartsSwitchingNo,iOrder,0,iColor);
		}
		/* 1:Word */
		else if(partsDispEventTbl->iBitWordFlag == 1){
			iDeviceValue = partsDispEventTbl->iBefDevVal;
			memcpy(cDeviceVal, &DispDeviceData[ScreenTagData[iOrder].DevOrder], ScreenTagData[iOrder].DevCnt);
			iDeviceValue= ChangeChar2long(cDeviceVal,BIT16);
			iPartsNo = iDeviceValue + partsDispEventTbl->iStartNo;
			if(iPartsNo > 0)
/* 060926				vPartDataSet(iPartsNo,iOrder,0,iColor);*/
				vPartDataSet(ScreenTagData[iOrder].sX,ScreenTagData[iOrder].sY,ScreenTagData[iOrder].eX,ScreenTagData[iOrder].eY,
							iPartsNo,iOrder,0,iColor);
		}
/*	}*/
/*	Delay(10);	*/
	FreeMail((char *)partsDispEventTbl);
}
int	GetPartsPosInfo(int iOrder)
{
	int				iPositionInfo;
	unsigned char *buffer;

	buffer= ScreenTagData[iOrder].TagPos;
	if((unsigned int)buffer[14] == 0x00){
		iPositionInfo = TOP_LEFT;
	}
	else{
		iPositionInfo = CENTER;
	}
	return(iPositionInfo);
}
/********************************************************************************/
/* �� �� �� : vPartDataSet														*/
/* ��    �� : Partsȭ�Ͽ��� ��ȣ�� �´� PartsData�� �ҷ���.						*/
/* ��    �� : iType(0 : PartDisplay, 1 : LampDisplay, 2 : Touchswitch)			*/
/* ��    �� :																	*/
/* �� �� �� :																	*/
/* �� �� �� :  																	*/
/* ��    �� : 																	*/
/********************************************************************************/
/* 060926 void vPartDataSet(int iNum, int iOrder, short iType, int iColor)*/
void vPartDataSet(int sX,int sY,int eX,int eY, int iNum, int iOrder, short iType, int iColor)
{
	int				i;
	int				iPartsID;
	int				iMoveX;
	int				iMoveY;
//	int				iDeviceValue;
/*	int				sX, sY, eX, eY; 060926 */
	short			iDataY = 0;
	short			iDataX = 0;
	int				ipos	= 0;
	int				isize	= 0; 
	int				iX		= 0;
	int				iY		= 0;
//	int				iHedCnt = 0;
	int				iCnt;
	short			iPosition;
	char			*cData;
	char			cPartName[10];	
	short			YMax;
	short			XMax;

/*
	_PARTS_EVENT_TBL*	 partsDispEventTbl;
	_LAMP_EVENT_TBL*	 LampDispEventTbl;
	_TOUCHSWICH_EVENT_TBL*	 TouchSwitchEventTbl;

*/



//	iDeviceValue = 0;
	iCnt = 0;
	i = iOrder;
	if(iType==0){			/*	PART	*/
/*		partsDispEventTbl= (_PARTS_EVENT_TBL*)IventTable[iOrder];*/
/* 060926		sX = ScreenTagData[iOrder].sX;
		sY = ScreenTagData[iOrder].sY;
		eX = ScreenTagData[iOrder].eX;
		eY = ScreenTagData[iOrder].eY;
*/
/*		iPosition = partsDispEventTbl->iPositionInfo;*/
		iPosition= GetPartsPosInfo(iOrder);
	}else if(iType==1){		/*	LAMP	*/
/*		LampDispEventTbl= (_LAMP_EVENT_TBL*)IventTable[iOrder];*/
/* 060926 		sX = ScreenTagData[iOrder].sX;
		sY = ScreenTagData[iOrder].sY; 
		eX = ScreenTagData[iOrder].eX;
		eY = ScreenTagData[iOrder].eY;
*/
		iPosition = 100;
	}else if(iType==2){		/*	TOUCH	*/
/*		TouchSwitchEventTbl= (_TOUCHSWICH_EVENT_TBL*)IventTable[iOrder];*/
/* 060926 		sX = ScreenTagData[iOrder].sX;
		sY = ScreenTagData[iOrder].sY; 
		eX = ScreenTagData[iOrder].eX;
		eY = ScreenTagData[iOrder].eY; 
*/
		iPosition = 100;
	}
/*	iNum--;*/
	memset(cPartName, 0x00, sizeof(cPartName));/* Comment Data ���� �̸��� ���� ���� */
	strcpy(cPartName, "PARTS.GP");

	if(mfileserch(cPartName,&ipos,&isize) == OK && PartsAnal_Task(iNum)){
		iPartsID = iNum;


		iX =  (unsigned int)(*(iPartPoint)) << 8;
		iX += (unsigned int)(*(iPartPoint+1)) & 0xff;
		iY =  (unsigned int)(*(iPartPoint+2)) << 8;
		iY += (unsigned int)(*(iPartPoint+3)) & 0xff;

		iCnt  = (unsigned int)(*(iPartPoint+4)) << 0x18;
		iCnt += (unsigned int)((*(iPartPoint+5)) & 0xff) << 0x10;
		iCnt += (unsigned int)((*(iPartPoint+6)) & 0xff) << 0x08;
		iCnt += (unsigned int)((*(iPartPoint+7)) & 0xff);


		cData = (char*)iCnt + ipos + 6;

		if(iPosition == TOP_LEFT){
			iMoveX = 0;
			iMoveY = 0;
		}
		else if(iPosition == CENTER){
			/* ��ǥ�� ��߾���� �̵��Ѵ�. */
			iMoveX = (int)iX/2;
			iMoveY = (int)iY/2;
			if(iType!=0){
				iMoveX = (((eX-sX)/2)-iMoveX);
				iMoveY = (((eY-sY)/2)-iMoveY);
				if(iMoveX>0)
					iMoveX = iMoveX * -1;
				if(iMoveY>0)
					iMoveY = iMoveY * -1;
			}	
			sX = ((eX-sX)/2)+sX;
			sY = ((eY-sY)/2)+sY;
		}else
		{
			iDataY = eY-sY;
			iDataX = eX-sX;
			if(iX < iDataX)
			{
				iMoveX = (iDataX - iX)/2;
				iMoveX=iMoveX*-1;
			}else
				iMoveX = 0;
			if(iY < iDataY)
			{
				iMoveY = (iDataY - iY)/2;
				iMoveY=iMoveY*-1;
			}else
				iMoveY = 0;

		}
/*		if(iType==0){
			AreaClear(partsDispEventTbl[i]->dsX,
					partsDispEventTbl[i]->dsY,
					partsDispEventTbl[i]->deX,
					partsDispEventTbl[i]->deY, */
/*					0);*/ /* �ڸ��� ����. */
/*		}*/

		if(TateYoko==0)		/* 03/12/10 leesi */
		{					/* ���� ���ο� ���� �ִ� X,Y ����� �ٸ��� ���� */
			YMax = (GAMEN_Y_SIZE-1);
			XMax = GAMEN_X_SIZE-1;
		}else
		{
			YMax = GAMEN_X_SIZE-1;
			XMax = (GAMEN_Y_SIZE-1);
		}
/****************************************/
		iX--;
		iY--;

		if((sX - iMoveX) >= 0 && (sY - iMoveY) >= 0 &&
			(sX + iX - iMoveX) <= XMax &&
			(sY + iY - iMoveY) <= YMax)
		{
/****************************************/
		TagPartsDisp(cData,
					 sX - iMoveX,
					 sY - iMoveY, 
					 sX + iX - iMoveX+ 1,		//2011.09.19
					 sY + iY - iMoveY+ 1,		//2011.09.19
					 iPartsID, 
					 i,iType,iColor);
/****************************************/
		}
/****************************************/
	}
}
/********************************************************************************/
/* �� �� �� : TagPartsDisp														*/
/* ��    �� : Tag Parts������ ���� ȭ�鿡 ����� ����Ѵ�.						*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 4�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/ /* type : 0-Part 1-Lamp 2-TouchSwitch  */
void TagPartsDisp(char* cPartsBuff, int sX, int sY, int eX, int eY, int iPartsDataNo, int iTagEventNo, int iType, int iColor)
{
	
	short				i;
	unsigned int		iTagSizeOf;
	unsigned char		*cTagBuffer;
	unsigned int		iOffset;
	int					iTagAddr[50];
	short				iCnt;
	int					iXNum;
	int					iYNum;
	int					iSize;
	char*				cImgBuffer;
	_PARTS_EVENT_TBL*	partsDispEventTbl;
	_RECTANGLE_INFO		RECParam;



	memset(iTagAddr, 0x00, sizeof(iTagAddr));

	iTagSizeOf = (unsigned int)(cPartsBuff[2] << 0x08);
	iTagSizeOf += (unsigned int)cPartsBuff[3] & 0xff;

	cTagBuffer =(unsigned char*)TakeMemory(iTagSizeOf+1);	
	memset(cTagBuffer, 0x00, iTagSizeOf+1);
	iOffset = 6;
	iCnt = (unsigned int)(cPartsBuff[4] << 0x08);
	iCnt += (unsigned int)cPartsBuff[5] & 0xff;

	for(i=0;i < iCnt; i++)
	{
		iTagAddr[i]  = (unsigned int)cPartsBuff[iOffset]   << 0x18;
		iTagAddr[i] += (unsigned int)(cPartsBuff[++iOffset] & 0xffffff) << 0x10; 
		iTagAddr[i] += (unsigned int)(cPartsBuff[++iOffset] & 0xffff) << 0x08;
		iTagAddr[i] += (unsigned int)cPartsBuff[++iOffset] & 0xff;

		iTagAddr[i] += 10;

		iOffset++;
	}
	if(iType == 0){
/*		partsDispEventTbl= (_PARTS_EVENT_TBL*)IventTable[iTagEventNo];*/
		partsDispEventTbl= (_PARTS_EVENT_TBL*)TakeMemory(sizeof(_PARTS_EVENT_TBL));
		DrawParts_Func(1,partsDispEventTbl,iTagEventNo);
	}

	for(i=0;i < iCnt;i++){

		if((unsigned int)cPartsBuff[iTagAddr[i]] == 0x01){		/* �� */

			memcpy(cTagBuffer, cPartsBuff + iTagAddr[i], 19);

			iXNum = cTagBuffer[6]<<8;				/* Start X Point */
			iXNum += (cTagBuffer[7] & 0xff); 
			iXNum += sX;
			cTagBuffer[6] = (iXNum & 0xff00) >> 8;
			cTagBuffer[7] = (iXNum & 0xff);

			iYNum = cTagBuffer[8]<<8;				/* Start Y Point */
			iYNum += (cTagBuffer[9] & 0xff); 
			iYNum += sY;
			cTagBuffer[8] = (iYNum & 0xff00) >> 8;
			cTagBuffer[9] = (iYNum & 0xff);

			iXNum = cTagBuffer[10]<<8;				/* End X Point */
			iXNum += (cTagBuffer[11] & 0xff); 
			iXNum += sX;
			cTagBuffer[10] = (iXNum & 0xff00) >> 8;
			cTagBuffer[11] = (iXNum & 0xff);

			iYNum = cTagBuffer[12]<<8;				/* End Y Point */
			iYNum += (cTagBuffer[13] & 0xff); 
			iYNum += sY;
			cTagBuffer[12] = (iYNum & 0xff00) >> 8;
			cTagBuffer[13] = (iYNum & 0xff);



			if(iType == 0){
				if(ScreenTagData[iTagEventNo].sX > (short int)cTagBuffer[7])
				{
						ScreenTagData[iTagEventNo].sX = (short int)cTagBuffer[7];
				}				
				if(	ScreenTagData[iTagEventNo].sY > (short int)cTagBuffer[9])
				{
						ScreenTagData[iTagEventNo].sY = (short int)cTagBuffer[9];
				}
				if(	ScreenTagData[iTagEventNo].eX < (short int)cTagBuffer[11])
				{
						ScreenTagData[iTagEventNo].eX = (short int)cTagBuffer[11];
				}
				if(	ScreenTagData[iTagEventNo].eY < (short int)cTagBuffer[13])
				{
						ScreenTagData[iTagEventNo].eY = (short int)cTagBuffer[13];
				}
			}
/*			if(partsDispEventTbl->iPositionInfo == CENTER){

			}*/

			DrawLine_Func(19,cTagBuffer, iColor);
		}
		
		else if((unsigned int)cPartsBuff[iTagAddr[i]] == 0x03){	/* �簢��  */
			memcpy(cTagBuffer, cPartsBuff + iTagAddr[i], 23);

			if(iType == 0)			/* PART MARK,FIXED �� ó�� 03/12/10 */
			{
				if(partsDispEventTbl->iType == 1 || partsDispEventTbl->iType == 2) /* MARK FIXED */
				{
					cTagBuffer[5] = iColor;
					cTagBuffer[7] = iColor;
				/*	cTagBuffer[8]	= 8;  */
				}
			}

			iXNum = cTagBuffer[9]<<8;				/* Start X Point */
			iXNum += (cTagBuffer[10] & 0xff); 
			iXNum += sX;
			cTagBuffer[9] = (iXNum & 0xff00) >> 8;
			cTagBuffer[10] = (iXNum & 0xff);

			iYNum = cTagBuffer[11]<<8;				/* Start Y Point */
			iYNum += (cTagBuffer[12] & 0xff); 
			iYNum += sY;
			cTagBuffer[11] = (iYNum & 0xff00) >> 8;
			cTagBuffer[12] = (iYNum & 0xff);

			iXNum = cTagBuffer[13]<<8;				/* End X Point */
			iXNum += (cTagBuffer[14] & 0xff); 
			iXNum += sX;
			cTagBuffer[13] = (iXNum & 0xff00) >> 8;
			cTagBuffer[14] = (iXNum & 0xff);

			iYNum = cTagBuffer[15]<<8;				/* End Y Point */
			iYNum += (cTagBuffer[16] & 0xff); 
			iYNum += sY;
			cTagBuffer[15] = (iYNum & 0xff00) >> 8;
			cTagBuffer[16] = (iYNum & 0xff);

			if(iType == 0){
				if(ScreenTagData[iTagEventNo].sX > (short int)cTagBuffer[10])
				{
						ScreenTagData[iTagEventNo].sX = (short int)cTagBuffer[10];
				}				
				if(	ScreenTagData[iTagEventNo].sY > (short int)cTagBuffer[12])
				{
						ScreenTagData[iTagEventNo].sY = (short int)cTagBuffer[12];
				}
				if(	ScreenTagData[iTagEventNo].eX < (short int)cTagBuffer[14])
				{
						ScreenTagData[iTagEventNo].eX = (short int)cTagBuffer[14];
				}
				if(	ScreenTagData[iTagEventNo].eY < (short int)cTagBuffer[16])
				{
						ScreenTagData[iTagEventNo].eY = (short int)cTagBuffer[16];
				}
			}

/*			if(partsDispEventTbl->iPositionInfo == CENTER){

			}*/
			DrawRect_Func(23,cTagBuffer, iColor);
		}
		
		else if((unsigned int)cPartsBuff[iTagAddr[i]] == 0x06){	/* �� */
			memcpy(cTagBuffer, cPartsBuff + iTagAddr[i], 23);

		if(iType == 0)			/* PART MARK,FIXED �� ó�� 03/12/10 */
			{
				if(partsDispEventTbl->iType == 1 || partsDispEventTbl->iType == 2) /* MARK FIXED */
				{
					cTagBuffer[5] = iColor;
					cTagBuffer[6] = iColor;
					/*cTagBuffer[7]	= 8;*/
				}
			}	
			iXNum = cTagBuffer[8]<<8;				/* Start X Point */
			iXNum += (cTagBuffer[9] & 0xff); 
			iXNum += sX;
			cTagBuffer[8] = (iXNum & 0xff00) >> 8;
			cTagBuffer[9] = (iXNum & 0xff);

			iYNum = cTagBuffer[10]<<8;				/* Start Y Point */
			iYNum += (cTagBuffer[11] & 0xff); 
			iYNum += sY;
			cTagBuffer[10] = (iYNum & 0xff00) >> 8;
			cTagBuffer[11] = (iYNum & 0xff);

			iXNum = cTagBuffer[12]<<8;				/* End X Point */
			iXNum += (cTagBuffer[13] & 0xff); 
			iXNum += sX;
			cTagBuffer[12] = (iXNum & 0xff00) >> 8;
			cTagBuffer[13] = (iXNum & 0xff);

			iYNum = cTagBuffer[14]<<8;				/* End Y Point */
			iYNum += (cTagBuffer[15] & 0xff); 
			iYNum += sY;
			cTagBuffer[14] = (iYNum & 0xff00) >> 8;
			cTagBuffer[15] = (iYNum & 0xff);

			
			if(iType == 0){
				if(ScreenTagData[iTagEventNo].sX > (short int)cTagBuffer[9])
				{
						ScreenTagData[iTagEventNo].sX = (short int)cTagBuffer[9];
				}				
				if(	ScreenTagData[iTagEventNo].sY > (short int)cTagBuffer[11])
				{
						ScreenTagData[iTagEventNo].sY = (short int)cTagBuffer[11];
				}
				if(	ScreenTagData[iTagEventNo].eX < (short int)cTagBuffer[13])
				{
						ScreenTagData[iTagEventNo].eX = (short int)cTagBuffer[13];
				}
				if(	ScreenTagData[iTagEventNo].eY < (short int)cTagBuffer[15])
				{
						ScreenTagData[iTagEventNo].eY = (short int)cTagBuffer[15];
				}
			}
/*			if(partsDispEventTbl->iPositionInfo == CENTER){

			}*/
			DrawCircle_Func(23, cTagBuffer, iColor);
		}else if((unsigned int)cPartsBuff[iTagAddr[i]] == 0x09){	/* Text */
			
			if(i == (iCnt-1) || iCnt == 1){
				iSize = (iTagSizeOf-iTagAddr[i]);
				memcpy(cTagBuffer, cPartsBuff + iTagAddr[i], iSize);
			
			}else
			{
				iSize = (iTagAddr[i+1]-iTagAddr[i]);
				memcpy(cTagBuffer, cPartsBuff + iTagAddr[i], iSize);
			}
			iXNum = cTagBuffer[9]<<8;				/* Start X Point */
			iXNum += (cTagBuffer[10] & 0xff); 
			iXNum += sX;
			cTagBuffer[9] = (iXNum & 0xff00) >> 8;
			cTagBuffer[10] = (iXNum & 0xff);

			iYNum = cTagBuffer[11]<<8;				/* Start Y Point */
			iYNum += (cTagBuffer[12] & 0xff); 
			iYNum += sY;
			cTagBuffer[11] = (iYNum & 0xff00) >> 8;
			cTagBuffer[12] = (iYNum & 0xff);

			iXNum = cTagBuffer[13]<<8;				/* End X Point */
			iXNum += (cTagBuffer[14] & 0xff); 
			iXNum += sX;
			cTagBuffer[13] = (iXNum & 0xff00) >> 8;
			cTagBuffer[14] = (iXNum & 0xff);

			iYNum = cTagBuffer[15]<<8;				/* End Y Point */
			iYNum += (cTagBuffer[16] & 0xff); 
			iYNum += sY;
			cTagBuffer[15] = (iYNum & 0xff00) >> 8;
			cTagBuffer[16] = (iYNum & 0xff);
			
			if(iType == 0){
				if(ScreenTagData[iTagEventNo].sX > (short int)cTagBuffer[10])
				{
						ScreenTagData[iTagEventNo].sX = (short int)cTagBuffer[10];
				}				
				if(	ScreenTagData[iTagEventNo].sY > (short int)cTagBuffer[12])
				{
						ScreenTagData[iTagEventNo].sY = (short int)cTagBuffer[12];
				}
				if(	ScreenTagData[iTagEventNo].eX < (short int)cTagBuffer[14])
				{
						ScreenTagData[iTagEventNo].eX = (short int)cTagBuffer[14];
				}
				if(	ScreenTagData[iTagEventNo].eY < (short int)cTagBuffer[16])
				{
						ScreenTagData[iTagEventNo].eY = (short int)cTagBuffer[16];
				}
			}
/*			if(partsDispEventTbl->iPositionInfo == CENTER){

			}*/
			DrawText_Func(iSize, cTagBuffer, iColor);
		}else if((unsigned int)cPartsBuff[iTagAddr[i]] == 0x0A)	{	/*	IMAGE */

			if(iTagSizeOf > 0){	
				if(iColor == -1 || iColor == 255)
				{
					iSize = (iTagSizeOf-iTagAddr[i]);
					cImgBuffer = (char*)TakeMemory(iSize);
					memset(cImgBuffer, 0x00, iSize);

					memcpy(cImgBuffer, (cPartsBuff+iTagAddr[i]+76), (iSize - (76)));
					PutImageGp(sX, sY, eX, eY, (char *)cImgBuffer);

					FreeMail((char*)cImgBuffer);
				}else
				{
					RECParam.iLineColor = iColor;
					RECParam.iBackColor = iColor;
					RECParam.iLineStyle	= 1;
					RECParam.iForeColor = iColor;
					RECParam.iPattern	= PAT8;
					RectAngleOut(sX, sY, eX, eY, &RECParam);
				}
				if(iType == 0){		
/*					partsDispEventTbl= (_PARTS_EVENT_TBL*)IventTable[iTagEventNo];*/
					/*XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
					ScreenTagData[iTagEventNo].sX = (short int)sX;
					ScreenTagData[iTagEventNo].sY = (short int)sY;
					ScreenTagData[iTagEventNo].eX = (short int)eX;
					ScreenTagData[iTagEventNo].eY = (short int)eY;
				}

			}

		}
	}
	FreeMail((char*)cTagBuffer);
	if(iType == 0){
		FreeMail((char *)partsDispEventTbl);
	}
}
/********************************************************************************/
/* �� �� �� : PartsAnalTask														*/
/* ��    �� : Parts������ �м�												    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 4�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
int	PartsAnal_Task(int iNum)
{

	int				ipos;
	int				isize; 
	int				iTotalCnt;
	int				i;
	int				iPartsNum;
	short			iValue;
	unsigned int	iOffset;

	char			*cPartDataBuffer;
	char			cPartName[12];/* part Data ���� �̸��� ���� ���� */

	memset(cPartName, 0x00, sizeof(cPartName));/* Comment Data ���� �̸��� ���� ���� */
	strcpy(cPartName, "PARTS.GP");
	ipos	= 0;
	isize	= 0; 
	iValue	= 0;
	if(mfileserch(cPartName,&ipos,&isize) == OK){
/*		cPartDataBuffer=(char *)TakeMemory(isize + 1);
		memset(cPartDataBuffer,0x00,isize + 1);

		memcpy(cPartDataBuffer,(char *)ipos,isize);
*/
		cPartDataBuffer = (char*)ipos;
		iTotalCnt  = (int)(cPartDataBuffer[8] << 0x08);			/* parts ���� */
		iTotalCnt += (int)cPartDataBuffer[9] & 0xff;

		iOffset = 10;

		for(i=0;i < iTotalCnt;i++){
			iPartsNum = (unsigned int)(cPartDataBuffer[iOffset] << 0x08);
			iOffset++;
			iPartsNum += (unsigned int)cPartDataBuffer[iOffset] & 0xff;
			iOffset++;
			if(iPartsNum == iNum)
			{
				iPartPoint = (char*)iOffset + ipos + 1;
				iValue = 1;
				break;
			}
			iOffset+=9;
		}
	/*	FreeMail((char *)cPartDataBuffer);*/
	}
	return iValue;
}
