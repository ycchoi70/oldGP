/*************************************************
    FUNC  : Display Program
    Create: 2002.4.28	M.Owash
**************************************************/
//#include	"cpu7014.h"
#define	DISP_PROC
#include	"sgt.h"
#include	"graphics.h"

void    DrawHorizontal( int sx, int ex, int y );
void    DrawVertical( int x, int sy, int ey );
void    DrawFnc( int DMst, int DSlave, void (*pMainMoveFnc)(void), void (*pSlaveMoveFnc)(void ) );

extern	void    XInc( void );
extern	void    YInc( void );
extern	void    XDec( void );
extern	void    YDec( void );
extern	void	__MoveTo( int sx, int sy, int Pattern, int Mode );
extern	void	DotWriteFont2(int x,int y,unsigned char *addr,int back, int xbai, int ybai, int mode, int mitudo);
extern	void	PaintPatarn1Line(int sx,int ex,int y,int Paint,int Fcolor,int Bcolor,int mode);
extern	void	PaintPatarn1LineY(int x,int sy,int ey,int Paint,int Fcolor,int Bcolor);
extern	void	Dot(int	x, int y, int Pattern);
extern	int		vCommentDataSet(int iNum, char *cDataBuffer, int *iColor, int *iLen);
extern	void    RDrawHorizontal( int sx, int ex, int y );
extern	void    RDrawVertical( int x, int sy, int ey );

extern	_SETUP			Set;					/* set value save struct */

extern unsigned char	BlackFont[32];

/* KSC20070222 */
	extern unsigned char	TriangleFont[9][32];

/************************************************/
/*	Font Load For Simulater						*/
/************************************************/
void	FontSet(void)
{
	memset(LcdBuff, 0, sizeof(LcdBuff));
	memset(wWidth, 0, sizeof(wWidth));		/* Window Initialize */
	memset(WindowInfo,0,sizeof(WindowInfo));
#ifndef	WIN32
	memset((char *)BaseLcd_Buffer,0,sizeof(LcdBuff[0]));
#endif
}
/****************************************************/
/*	Semafo for Disp									*/
/****************************************************/
void	InitSendSema( void )
{
	Iop( SMF_SEND, 1 );
}
void	SetSendSema( void )
{
	Pop( SMF_SEND );
}
void	ResetSendSema( void )
{
	Vop( SMF_SEND );
}
void	InitWinSema( void )
{
	Iop( SMF_WIN, 1 );
}
void	SetWinSema( void )
{
	Pop( SMF_WIN );
}
void	ResetWinSema( void )
{
	Vop( SMF_WIN );
}
void	InitDispSema( void )
{
	Iop( SMF_DISP, 1 );
//	LcdBkFlag= 0;
}
void	SetDispSema( void )
{
	Pop( SMF_DISP );
}
void	ResetDispSema( void )
{
	Vop( SMF_DISP );
}
int	CheckHan(int idx)
{
	if((idx >= 0x10) && (idx <= 0x19)){
		return(1);
	}else if((idx >= 0x20) && (idx <= 0x26)){
		return(1);
	}else if(idx == 0x0e){
		return(1);
	}
	return(0);
}

/********************************************************/
/*	Font Change Tate/Yoko								*/
/********************************************************/
void	ChangeTateYoko(unsigned char *obj,unsigned char *src,int Xcnt,int Ycnt)
{
	int		i,j;
	int		AndData;
	int		OrData;
	int		Cnt0;
	int		Cnt;
	unsigned char *FontPos;

	if(Xcnt < 8){
		Xcnt= 8;
	}
	memset(obj, 0, Xcnt/8* Ycnt);
	Cnt0= (Xcnt- 1)/8;
	Cnt= Cnt0;
	AndData= 0x01;
	OrData= 0x80;
	FontPos= (unsigned char *)((int)src + Cnt);
	for(i = Xcnt- 1; i >= 0; i--){
		for(j = 0; j < Ycnt; j++){
			if((*FontPos & AndData) != 0){
				*obj |= OrData;
			}
			OrData = OrData >> 1;
			if(OrData == 0){
				OrData = 0x80;
				obj++;
			}
			FontPos += (Cnt0+ 1);
		}
		AndData = AndData << 1;
		if(AndData > 0x80){
			Cnt--;
			if(Cnt < 0){
				break;
			}
			AndData = 0x01;
		}
		FontPos= (unsigned char *)((int)src + Cnt);
	}
}

/************************************************/
/*	CommonProc									*/
/************************************************/
void	__LineTo(int ex,int ey,int mode )
{
    int     Dx;
    int     Dy;
    int     DMst;
    int     DSlave;
    void    (*pXMoveFnc)(void);
    void    (*pYMoveFnc)(void);
    void    (*pMainMoveFnc)(void);
    void    (*pSlaveMoveFnc)(void);
	
	if( ex <    0 ){	ex=   0;	}
	if( ex >= GAMEN_X_SIZE ){	ex= GAMEN_X_SIZE-1;	}
	if( ey <    0 ){	ey=   0;	}
	if( ey >= GAMEN_Y_SIZE ){	ey= GAMEN_Y_SIZE-1;	}


    Dx= ex- LastPos.x;
    Dy= ey- LastPos.y;
    if( Dy == 0 ){
        if( Dx == 0 ){ return; }
        if( Dx > 0 ){	DrawHorizontal( LastPos.x, ex, ey );	}
		else if(mode == 0){
			DMst= LastPos.x;
		    __MoveTo( ex, ey, DrawPtn, DrawMode );
			DrawHorizontal( ex, DMst, ey );	
		}else{
			RDrawHorizontal( LastPos.x, ex, ey );	
		}
    } else if( Dx == 0 ){
        if( Dy == 0 ){ return; }
        if( Dy > 0 ){	DrawVertical( ex,LastPos.y, ey );	}
        else if(mode == 0){
			DMst= LastPos.y;
		    __MoveTo( ex, ey, DrawPtn, DrawMode );
			DrawVertical( ex, ey, DMst );	
		}else{
			RDrawVertical(ex,LastPos.y, ey );
		}
	} else {
        pXMoveFnc= XInc;
        pYMoveFnc= YInc;
        if( Dx < 0 ){	Dx= -Dx;	pXMoveFnc= XDec;	}
        if( Dy < 0 ){	Dy= -Dy;	pYMoveFnc= YDec;	}
        if( Dx >= Dy ){
            pMainMoveFnc = pXMoveFnc;
            pSlaveMoveFnc= pYMoveFnc;
            DMst= Dx;
            DSlave= Dy;
        }
        else{
            pMainMoveFnc = pYMoveFnc;
            pSlaveMoveFnc= pXMoveFnc;
            DMst= Dy;
            DSlave= Dx;
        }
        DrawFnc( DMst, DSlave, pMainMoveFnc, pSlaveMoveFnc );
    }
/*    __MoveTo( ex, ey, DrawPtn, DrawMode );*/
}
extern	void    DrawHorizontalPrn( int sx, int ex, int y );
extern	void    RDrawHorizontalPrn( int sx, int ex, int y );
extern	void    DrawVerticalPrn( int x, int sy, int ey );
extern	void    RDrawVerticalPrn( int x, int sy, int ey );
void	__LineToPrn(int ex,int ey,int mode )
{
    int     Dx;
    int     Dy;
    int     DMst;
    int     DSlave;
    void    (*pXMoveFnc)(void);
    void    (*pYMoveFnc)(void);
    void    (*pMainMoveFnc)(void);
    void    (*pSlaveMoveFnc)(void);
	
	if( ex <    0 ){	ex=   0;	}
	if( ex >= GAMEN_X_SIZE ){	ex= GAMEN_X_SIZE-1;	}
	if( ey <    0 ){	ey=   0;	}
	if( ey >= GAMEN_Y_SIZE ){	ey= GAMEN_Y_SIZE-1;	}


    Dx= ex- LastPos.x;
    Dy= ey- LastPos.y;
    if( Dy == 0 ){
        if( Dx == 0 ){ return; }
        if( Dx > 0 ){
			DrawHorizontalPrn( LastPos.x, ex, ey );
		}
		else if(mode == 0){
			DMst= LastPos.x;
		    __MoveTo( ex, ey, DrawPtn, DrawMode );
			DrawHorizontalPrn( ex, DMst, ey );	
		}else{
			RDrawHorizontalPrn( LastPos.x, ex, ey );	
		}
    } else if( Dx == 0 ){
        if( Dy == 0 ){ return; }
        if( Dy > 0 ){
			DrawVerticalPrn( ex,LastPos.y, ey );
		}
        else if(mode == 0){
			DMst= LastPos.y;
		    __MoveTo( ex, ey, DrawPtn, DrawMode );
			DrawVerticalPrn( ex, ey, DMst );	
		}else{
			RDrawVerticalPrn(ex,LastPos.y- 1, ey );
		}
	} else {
        pXMoveFnc= XInc;
        pYMoveFnc= YInc;
        if( Dx < 0 ){	Dx= -Dx;	pXMoveFnc= XDec;	}
        if( Dy < 0 ){	Dy= -Dy;	pYMoveFnc= YDec;	}
        if( Dx >= Dy ){
            pMainMoveFnc = pXMoveFnc;
            pSlaveMoveFnc= pYMoveFnc;
            DMst= Dx;
            DSlave= Dy;
        }
        else{
            pMainMoveFnc = pYMoveFnc;
            pSlaveMoveFnc= pXMoveFnc;
            DMst= Dy;
            DSlave= Dx;
        }
        DrawFnc( DMst, DSlave, pMainMoveFnc, pSlaveMoveFnc );
		LastPos.x= (short)ex;
		LastPos.y= (short)ey;
    }
/*    __MoveTo( ex, ey, DrawPtn, DrawMode );*/
}
void	LineOut(int sx,int sy,int ex,int ey,_LINE_INFO *param)
{
	int	ssx,ssy,eex,eey;
/*char	dsp_buf[32];*/


	SetDispSema();
	if(param->iLineColor != 0){
		DrawColor= T_WHITE;
	}else{
		DrawColor= T_BLACK;
	}
	if(TateYoko == 0){
		ssx= sx;
		ssy= sy;
		eex= ex;
		eey= ey;
	}else{
		ssx= sy;
		ssy= (GAMEN_Y_SIZE-1)- sx;
		eex= ey;
		eey= (GAMEN_Y_SIZE-1)- ex;
	}
	LineBit = 0;
	__MoveTo( ssx, ssy, param->iLineStyle, 0 );
	__LineTo( eex, eey, 0 );
	__MoveTo( eex, eey, param->iLineStyle, 0 );
	ResetDispSema();
/*
sprintf(dsp_buf,"SX=%03d,SY=%03d,EX=%03d,EY=%03d",sx,sy,ex,ey);
DotTextOut(0,0,dsp_buf,1,1,T_REPLACE,3,0);
DrawLcdBank1();
Delay(2000);
*/
}


/****************************************************
*   FUNC  : Text Out                                *
*	In    :x,y=Start Position						*
*          addr:Char String Address                 *
*          front:Char Color(0:Light,1:Dark)         *
*          back:Char Back Color(0:Light,1:Dark)     *
*          onoff:Back Color On/Off(0:Off,1:On)      *
*	Out   : 										*
*   AUTHOR : M.Owashi                                *
*   DATE  : 1996.8.28                               *
*	Update:97.04.10 kf								*
****************************************************/
/****************************************************/
/*   FUNC  : BaiFont                                */
/*	In    :											*/
/****************************************************/
unsigned char	GetData(unsigned char *buff)
{
	unsigned char data;

	data= *buff;
	data |= buff[2];
	return(data);
}
void	BaiFont(unsigned char *fBuff,int xbai,int ybai,int cnt)
{
	int	i,j,k;
	int	AndData;
	int	OrData;
	unsigned char *foBuff;
	unsigned char *sfoBuff;
	unsigned char fData;

	foBuff = FontData;
	for(i = 0; i < 16; i++){
		switch(xbai){
		case 1:
			OrData = 0x80;
			break;
		case 2:
			OrData = 0xc0;
			break;
		case 3:
			OrData = 0xe0;
			break;
		case 4:
			OrData = 0xf0;
			break;
		case 5:
			OrData = 0xf8;
			break;
		case 6:
			OrData = 0xfc;
			break;
		case 7:
			OrData = 0xfe;
			break;
		case 8:
			OrData = 0xff;
			break;
		}
		sfoBuff = foBuff;
		for(k = 0; k < cnt; k++){
			if(xbai > 1){
				AndData = 0x80;
				for(j = 0; j < 8; j++){
					if((cnt == 2) & (ybai == 0)){
						fData= GetData(fBuff);
					}else{
						fData= *fBuff;
					}
					if(fData & AndData){
						switch(xbai){
						case 2:
							*foBuff |= OrData;
							OrData >>= 2;
							if(OrData == 0){
								OrData = 0xc0;
								foBuff++;
							}
							break;
						case 3:
							*foBuff |= OrData;
							if(OrData == 3){
								foBuff++;
								*foBuff |= 0x80;
								OrData = 0x70;
							}else if(OrData == 1){
								foBuff++;
								*foBuff |= 0xc0;
								OrData = 0x38;
							}else{
								OrData >>= 3;
								if(OrData == 0){
									foBuff++;
									OrData = 0xe0;
								}
							}
							break;
						case 4:
							*foBuff |= OrData;
							if((j % 2) == 0){
								OrData = 0x0f;
							}else{
								OrData = 0xf0;
								foBuff++;
							}
							break;
						case 5:
							switch(j % 8){
							case 0:
								*foBuff |= 0xf8;
								break;
							case 1:
								*foBuff |= 0x07;
								foBuff++;
								*foBuff |= 0xc0;
								break;
							case 2:
								*foBuff |= 0x3e;
								break;
							case 3:
								*foBuff |= 0x01;
								foBuff++;
								*foBuff |= 0xf0;
								break;
							case 4:
								*foBuff |= 0x0f;
								foBuff++;
								*foBuff |= 0x80;
								break;
							case 5:
								*foBuff |= 0x7c;
								break;
							case 6:
								*foBuff |= 0x03;
								foBuff++;
								*foBuff |= 0xe0;
								break;
							case 7:
								*foBuff |= 0x1f;
								foBuff++;
								break;
							}
							break;
						case 6:
							switch(j % 4){
							case 0:
								*foBuff |= 0xfc;
								break;
							case 1:
								*foBuff |= 0x03;
								foBuff++;
								*foBuff |= 0xf0;
								break;
							case 2:
								*foBuff |= 0x0f;
								foBuff++;
								*foBuff |= 0xc0;
								break;
							case 3:
								*foBuff |= 0x3f;
								foBuff++;
								break;
							}
							break;
						case 7:
							switch(j % 8){
							case 0:
								*foBuff |= 0xfe;
								break;
							case 1:
								*foBuff |= 0x01;
								foBuff++;
								*foBuff |= 0xfc;
								break;
							case 2:
								*foBuff |= 0x03;
								foBuff++;
								*foBuff |= 0xf8;
								break;
							case 3:
								*foBuff |= 0x07;
								foBuff++;
								*foBuff |= 0xf0;
								break;
							case 4:
								*foBuff |= 0x0f;
								foBuff++;
								*foBuff |= 0xe0;
								break;
							case 5:
								*foBuff |= 0x1f;
								foBuff++;
								*foBuff |= 0xc0;
								break;
							case 6:
								*foBuff |= 0x3f;
								foBuff++;
								*foBuff |= 0x80;
								break;
							case 7:
								*foBuff |= 0x7f;
								foBuff++;
								break;
							}
							break;
						case 8:
							*foBuff |= 0xff;
							foBuff++;
							break;
						}
					}else{
						switch(xbai){
						case 2:
							OrData >>= 2;
							if(OrData == 0){
								OrData = 0xc0;
								foBuff++;
							}
							break;
						case 3:
							if(OrData == 3){
								foBuff++;
								OrData = 0x70;
							}else if(OrData == 1){
								foBuff++;
								OrData = 0x38;
							}else{
								OrData >>= 3;
								if(OrData == 0){
									foBuff++;
									OrData = 0xe0;
								}
							}
							break;
						case 4:
							if((j % 2) == 0){
								OrData = 0x0f;
							}else{
								OrData = 0xf0;
								foBuff++;
							}
							break;
						case 5:
							switch(j % 8){
							case 0:
							case 2:
							case 5:
								break;
							case 1:
							case 3:
							case 4:
							case 6:
							case 7:
								foBuff++;
								break;
							}
							break;
						case 6:
							switch(j % 4){
							case 0:
								break;
							case 1:
								foBuff++;
								break;
							case 2:
								foBuff++;
								break;
							case 3:
								foBuff++;
								break;
							}
							break;
						case 7:
							switch(j % 8){
							case 0:
								break;
							case 1:
							case 2:
							case 3:
							case 4:
							case 5:
							case 6:
							case 7:
								foBuff++;
								break;
							}
							break;
						case 8:
							foBuff++;
							break;
						}
					}
					AndData >>= 1;
				}
			}else{
				if((cnt == 2) & (ybai == 0)){
					fData= GetData(fBuff);
				}else{
					fData= *fBuff;
				}
				*foBuff++ = fData;
			}
			fBuff++;
		}		/* YOKO End */
		if(ybai == 0){
			if(cnt == 2){		/* �S�p�O�D�T�Ή� */
				fBuff += 2;
			}
		}else{
			for(k = 0; k < xbai*cnt*(ybai-1); k++){
				*foBuff++ = *sfoBuff++;
			}
		}
	}
}

unsigned char *GetCommSymbol(unsigned char c)
{
	unsigned char *FontPos;

	if(c == 0x01){ /* �� 0xff01 */  
		FontPos = (unsigned char *)&TriangleFont[0]; 
	}else if(c == 0x02){ /* �� 0xff02 */
		FontPos = (unsigned char *)&TriangleFont[1];
	}else if(c == 0x03){ /* �� 0xff03 */
		FontPos = (unsigned char *)&TriangleFont[2];
	}else if(c == 0x04){ /* �� 0xff04 */
		FontPos = (unsigned char *)&TriangleFont[3];
	}else if(c == 0x05){ /* �� 0xff05 */
		FontPos = (unsigned char *)&TriangleFont[4];
	}else if(c == 0x06){
		FontPos = (unsigned char *)&TriangleFont[0];
	}else if(c == 0x07){
		FontPos = (unsigned char *)&TriangleFont[0];
	}else if(c == 0x08){
		FontPos = (unsigned char *)&TriangleFont[0];
	}else if(c == 0x09){
		FontPos = (unsigned char *)&TriangleFont[0];
	}else{
		FontPos = (unsigned char *)&BlackFont[0];
	}
	return(FontPos);
}


/* 20060513 */
/****************************************/
/*	Korean Font rom address read			*/
/****************************************/
#ifdef	NEWFONT		/* 20060617 */
unsigned char *GetKorFontAddr(unsigned char *buff)
{
	unsigned char *FontPos;
	unsigned short code;

	if((buff[0] >= 0xA1) && (buff[0] <= 0xAF))		/* Symbol */
	{
		code = (buff[0] - 0xA1) * 0x5E;
		code += (buff[1] - 0xA1);
	}
	else if((buff[0] >= 0xB0) && (buff[0] <= 0xC9))	/* Hangle16 */
	{
		code = (buff[0] - 0xB0) * 0x5E;
		code += (buff[1] - 0xA1);
		code += 0x468;		/* font file symbol size add */
	}
	else if((buff[0] >= 0xCA) && (buff[0] <= 0xFE)){
		code = (buff[0] - 0xCA) * 0x5E;
		code += (buff[1] - 0xA1);
		code += 0xD96;		/* font file symbol + Hangle16 size add */
	}else if(buff[0] == 0x10)		/* USER Symbol */ /* 2012.08.23 [ 0xFF ->0x10] */
	{
		FontPos= GetCommSymbol(buff[1]);
		return(FontPos);
	}else 
	{
		FontPos = (unsigned char *)&BlackFont[0];
		return(FontPos);
	}
#ifdef	WIN32
	FontPos = (unsigned char *)&GpFont[(FONT_NATION + code * 32)];
#else
	FontPos = (unsigned char *)(FONT_NATION + code * 32);
#endif

	return(FontPos);
}	

#else

unsigned char *GetKorFontAddr(unsigned char *buff)
{
	unsigned char *FontPos;
	unsigned short code;


	if((buff[0] >= 0xA1) && (buff[0] <= 0xAF))		/* Symbol */
	{
		code = (buff[0] - 0xA1) * 0x5E;
		code += (buff[1] - 0xA1);
	}
	else if((buff[0] >= 0xB0) && (buff[0] <= 0xC9))	/* Hangle16 */
	{
		code = (buff[0] - 0xB0) * 0x5E;
		code += (buff[1] - 0xA1);
		code += 0x800;		/* font file symbol size add */
	}
	else if((buff[0] >= 0xCA) && (buff[0] <= 0xFF)){
		code = (buff[0] - 0xCA) * 0x5E;
		code += (buff[1] - 0xA1);
		code += 0xF5C;		/* font file symbol + Hangle16 size add */
	}
	else {
		FontPos = (unsigned char *)&BlackFont[0];
		return(FontPos);
	}
#ifdef	WIN32
	FontPos = (unsigned char *)&GpFont[(FONT_NATION + code * 32)];
#else
	FontPos = (unsigned char *)(FONT_NATION + code * 32);
#endif

	return(FontPos);
}	

#endif

/****************************************/
/*	Japan Font rom address read			*/
/****************************************/

unsigned char *GetJpnFontAddr(unsigned char *buff)
{
	unsigned char *FontPos;
	unsigned short code;


	/* s-jis font table line [ 0x81 - 0xff ] and colume [ 0x40 - 0xfc ]  */

	if(0x81 <= buff[0] && buff[0] <= 0x84){			/* start line = 81 - 81 = 0, end line = 84 - 81 = 3 */
		code = (buff[0] - 0x81) * 0xbd;
	}else if(0x87 <= buff[0] && buff[0] <= 0x9F){	/* start line = 87 - 83 = 4, end line = 9f - 83 = 1c */
		code = (buff[0] - 0x83) * 0xbd;
	}else if(0xE0 <= buff[0] && buff[0] <= 0xEA){	/* start line = e0 - c3 = 1d, end line = ea - c3 = 27 */
		code = (buff[0] - 0xC3) * 0xbd;
	}else if(0xFA <= buff[0] && buff[0] <= 0xFE){	/* FF-> FE 070301 *//* start line = fa - d2 = 28, end line = ff - d2 = 3c */
		code = (buff[0] - 0xD2) * 0xbd;
	}else if((0x00<=buff[0]) && (buff[0]<= 0x1F))		/* USER Symbol */ 
	{
		if(buff[0]==0x10){							/* 2012.08.23 [ 0xFF ->0x10] */
			FontPos= GetCommSymbol(buff[1]);
			return(FontPos);
		}
		else{
			FontPos= (unsigned char *)&BlackFont[0];
			return(FontPos);
		}
	}else{
		FontPos = (unsigned char *)&BlackFont[0];
		return(FontPos);
	}
	code += buff[1] - 0x40;  				
/*	code = code * 32;*/
#ifdef	WIN32
	FontPos = (unsigned char *)&GpFont[(FONT_NATION + code * 32)];
#else
	FontPos = (unsigned char *)(FONT_NATION + code * 32);
#endif

	return(FontPos);
}

/****************************************/
/*	Chinese Font rom address read			*/
/****************************************/

unsigned char *GetChiFontAddr(unsigned char *buff)
{
	unsigned char *FontPos;
	unsigned short code;

	if((buff[0] >= 0xA1) && (buff[0] <= 0xAF))		/* Symbol  0xA1A1 - 0xA9EF */
	{
		code = (buff[0] - 0xA1) * 0x5E;
		code += (buff[1] - 0xA1);
	}
	else if((buff[0] >= 0xB0) && (buff[0] <= 0xFE))	/* Hanja  0xB0A1 - 0xF7FE */
	{
		code = (buff[0] - 0xB0) * 0x5E;
		code += (buff[1] - 0xA1);
		code += 0x34E;		/* font file symbol size add */
	}else if(buff[0] == 0x10)		/* USER Symbol */ //2012.08.23 [ 0xFF ->0x10] 
	{
		FontPos= GetCommSymbol(buff[1]);
		return(FontPos);
	}else{
		FontPos = (unsigned char *)&BlackFont[0];
		return(FontPos);
	}
#ifdef	WIN32
	FontPos = (unsigned char *)&GpFont[(FONT_NATION + code * 32)];
#else
	FontPos = (unsigned char *)(FONT_NATION + code * 32);
#endif
	return(FontPos);
}	
/****************************************/
/*	English Font rom address read			*/
/****************************************/

unsigned char *GetEngFontAddr(unsigned char *buff)
{
	unsigned char *FontPos;

	if(buff[0] == 0x10)		/* USER Symbol */ //2012.08.23 [ 0xFF ->0x10] 
	{
		FontPos= GetCommSymbol(buff[1]);
		return(FontPos);
	
	}else {
		FontPos = (unsigned char *)&BlackFont[0];
		return(FontPos);
	}
}	

/****************************************/
/*	Taiwan Font rom address read			*/
/****************************************/

unsigned char *GetTaiFontAddr(unsigned char *buff)
{
	unsigned char *FontPos;
	unsigned short code;

	if((buff[0] >= 0xA1) && (buff[0] <= 0xC8))		/* 0xA140 - 0xC7FE [0xA140 - 0xC8FE] */
	{
		code = (buff[0] - 0xA1) * 0xBF;
		code += (buff[1] - 0x40);
	}
	else if((buff[0] >= 0xC9) && (buff[0] <= 0xFE))	/* 0xC940 - 0xF9d5 [0xC940 - 0xFFFE] */
	{
		code = (buff[0] - 0xB0) * 0xBF;
		code += (buff[1] - 0x40);
		code += 0x1D19;		/* font file 0xa140 - 0xc7fe size add */
	}else if(buff[0] == 0x10)		/* USER Symbol */ //2012.08.23
	{
		FontPos= GetCommSymbol(buff[1]);
		return(FontPos);
	
	}else {
		FontPos = (unsigned char *)&BlackFont[0];
		return(FontPos);
	}
#ifdef	WIN32
	FontPos = (unsigned char *)&GpFont[(FONT_NATION + code * 32)];
#else
	FontPos = (unsigned char *)(FONT_NATION + code * 32);
#endif

	return(FontPos);
}	

/****************************************/
/*	Russian Font rom address read			*/
/****************************************/

unsigned char *GetRusFontAddr(unsigned char *buff)
{
	unsigned char *FontPos;
	unsigned short code;
//20100906
	if((buff[0] >= 0x80) && (buff[0] <= 0xFF))			//2012.08.23	
	{
		code = buff[0]-0x80;

	}else if(buff[0] == 0x10) {							//2012.08.23   

		if((buff[1] >= 0x01) && (buff[1] <= 0x0F)){		/* USER Symbol */
			FontPos= GetCommSymbol(buff[1]);
			return(FontPos);
		}else{
			code = buff[0]-0x80;
		}

	}else {
		FontPos = (unsigned char *)&BlackFont[0];
		return(FontPos);
	}
#ifdef	WIN32
	FontPos = (unsigned char *)&GpFont[(FONT_NATION + code * 16)];
#else
	FontPos = (unsigned char *)(FONT_NATION + code * 16);
#endif

	return(FontPos);
}	

/****************************************/
/*	Vietnam Font rom address read			*/
/****************************************/

unsigned char *GetVieFontAddr(unsigned char *buff)
{
	unsigned char *FontPos;
	unsigned short code;
	//2012.08.18 
	if((buff[0]>=0x00)&& (buff[0]<0x20) )
	{ //VISCII �ڵ�� ��Ʈ�� ������ ���ڸ� ����Ѵ�. 
		if(buff[0]==0x10){
			if((buff[1] >= 0x01) && (buff[1] <= 0x0F)){		/* USER Symbol */
				FontPos= GetCommSymbol(buff[1]);
				return(FontPos);
			}
		}else{
			code = buff[0];
		}
	}
	else if((buff[0] >= 0x80) && (buff[0] <= 0xFF))		
	{
		code = buff[0]-0x60;

	}else{
		FontPos = (unsigned char *)&BlackFont[0];
		return(FontPos);
	}
#ifdef	WIN32
	FontPos = (unsigned char *)&GpFont[(FONT_NATION + code * 16)];
#else
	FontPos = (unsigned char *)(FONT_NATION + code * 16);
#endif

	return(FontPos);
}	

/****************************************/
/*	Portugal Font rom address read			*/
/****************************************/

unsigned char *GetPorFontAddr(unsigned char *buff)
{
	unsigned char *FontPos;
	unsigned short code;
//20100906
	if((buff[0] >= 0x80) && (buff[0] <= 0xFF))			//2012.08.23		
	{
		code = buff[0]-0x80;

	}else if(buff[0] == 0x10) {							//2012.08.23 

		if((buff[1] >= 0x01) && (buff[1] <= 0x0F)){		/* USER Symbol */
			FontPos= GetCommSymbol(buff[1]);
			return(FontPos);
		}else{
			code = buff[0]-0x80;
		}

	}else {
		FontPos = (unsigned char *)&BlackFont[0];
		return(FontPos);
	}
#ifdef	WIN32
	FontPos = (unsigned char *)&GpFont[(FONT_NATION + code * 16)];
#else
	FontPos = (unsigned char *)(FONT_NATION + code * 16);
#endif

	return(FontPos);
}	
/****************************************/
/*	�؍���/��?��Offset�v�Z				*/
/****************************************/
unsigned char *GetZenkakuFont(unsigned char *buff)
{
	unsigned char *FontAddr;
	extern	unsigned char	BlackFont[32];


	switch(Set.LanguageCode){	

		case JPNCODE:
			FontAddr = GetJpnFontAddr(buff);  /* Japan s-jis */
			break;
		case CHICODE:
			FontAddr =  GetChiFontAddr(buff); /* Chinese GB2312 */
			break;
		case ENGCODE:
			FontAddr =  GetEngFontAddr(buff); /* ENGLISH ���� */
			break;
		case TWICODE:
			FontAddr =  GetTaiFontAddr(buff); /* chinese TAIWAN big5 */
			break;
		case RUSCODE:
			FontAddr =  GetRusFontAddr(buff); /* Russian Ascii 0x80 - 0xff */
			break;
		case VIECODE: // Vietnam 2012.08.07
			FontAddr =  GetVieFontAddr(buff); /* Vietnam Ascii  */
			break;
		case PORCODE: // Portugal 2012.08.07
			FontAddr =  GetPorFontAddr(buff); /* Portugal Ascii  */
			break;
		case KORCODE:
		default:
			FontAddr =  GetKorFontAddr(buff); /* Korean KS5601 */
			break;
	}

	return(FontAddr);

}

/**********************************************/
void	DotTextOut(int x,int y,char *addr,int xbai,int ybai,int mode,int Front,int Back)
{
	SetDispSema();
	FrontColor= Front;
	BackColor= Back;
	DotWriteFont2(x, y, (unsigned char *)addr, Back, xbai, ybai, mode, 0);
	ResetDispSema();
}
void	DotTextOut2(int x,int y,char *addr,int xbai,int ybai,int mode,int Front,int Back)
{
	SetDispSema();
	FrontColor= Front;
	BackColor= Back;
	DotWriteFont2(x, y, (unsigned char *)addr, Back, xbai, ybai, mode, 1);
	ResetDispSema();
}

/****************************************************
*   FUNC  : Rect Angle Out                          *
*	In    :sx,sy=Start Position						*
*	       ex,ey=Start Position						*
*          patarn:Line Patarn                       *
*	Out   : 										*
*   AUTHOR : M.Owashi                                *
*   DATE  : 1996.8.28                               *
****************************************************/
void	RectAngleOut(int sx,int sy,int ex,int ey,_RECTANGLE_INFO *param)
{
	int	i;
	int	ssx,ssy,eex,eey;

	SetDispSema();
	if(param->iLineColor != 0){
		DrawColor= T_WHITE;
	}else{
		DrawColor= T_BLACK;
	}

	if(TateYoko == 0){
		ssx= sx;
		ssy= sy;
		eex= ex;
		eey= ey;
	}else{
		ssx= sy;
		ssy= (GAMEN_Y_SIZE-1)- sx;
		eex= ey;
		eey= (GAMEN_Y_SIZE-1)- ex;
		if(ssx > eex){
			ssx= ey;
			eex= sy;
		}
		if(ssy > eey){
			ssy= (GAMEN_Y_SIZE-1)- ex;
			eey= (GAMEN_Y_SIZE-1)- sx;
		}
	}
	LineBit= 0;
	if((sx == ex) || (sy == ey)){
		__MoveTo(ssx,ssy,param->iLineStyle,0);	/* Top line		*/
		__LineTo(eex,eey,0);	/* Right line 	*/
	}else{
		if(param->iLineStyle > 1){
			__MoveTo(ssx,ssy,param->iLineStyle,0);	/* Top line		*/
			__LineTo(eex,ssy,0);	/* Right line 	*/
			LineBit= ((eex- ssx+ 1)) % 24;
			__MoveTo(eex,ssy+1,param->iLineStyle,0);	/* Top line		*/
			__LineTo(eex,eey,0);	/* Bottom line	*/
			__MoveTo(eex- 1,eey,param->iLineStyle,0);	/* Top line		*/
			__LineTo(ssx,eey,1);	/* Left line	*/
			__MoveTo(ssx,eey-1,param->iLineStyle,0);	/* Top line		*/
			__LineTo(ssx,ssy+ 1,1);	/* Top line		*/
		}else{
			__MoveTo(ssx,ssy,param->iLineStyle,0);	/* Top line		*/
			__LineTo(eex,ssy,0);	/* Right line 	*/
			__MoveTo(eex,ssy+1,param->iLineStyle,0);	/* Top line		*/
			__LineTo(eex,eey,0);	/* Bottom line	*/
			__MoveTo(eex- 1,eey,param->iLineStyle,0);	/* Top line		*/
			__LineTo(ssx,eey,0);	/* Left line	*/
			__MoveTo(ssx,eey-1,param->iLineStyle,0);	/* Top line		*/
			__LineTo(ssx,ssy+ 1,0);	/* Top line		*/
		}
		if(TateYoko != 0){
			ssx= sx;
			ssy= sy;
			eex= ex;
			eey= ey;
		}
		ssx ++;
		ssy ++;
		eex --;
		/*ey --;*/
		if(param->iPattern == P_NONE){
		}else{
			for(i = ssy; i < eey; i++){
				PaintPatarn1Line(ssx,eex,i,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
			}
		}
	}
	ResetDispSema();
}

void	DrawCircle(int x0, int y0, int r, _CIRCLE_INFO *param)
{
	/*(�P�O�C�O�j��茴?�𒆐S�ɂS�T�x�܂ł̍����?�ʂ��Ԃ���B*/
	int		x = r;
	int		y = 0;
	int		s2d = 3;		/*���Q���͂Q������ێ�*/
	int		x2 = 2*x;		/*�ȉ��̉��Z��2?�ł��Ɠs�����悢*/
	int		y2 = 2*y;		/*�ȉ��̉��Z��2?�ł��Ɠs�����悢*/
	int		px0,py0;
	int		sy0,sy1,sy2,sy;

	SetDispSema();
	if(param->iLineColor != 0){
		DrawColor= T_WHITE;
	}else{
		DrawColor= T_BLACK;
	}
	minY= GAMEN_Y_SIZE-1;
	maxY= 0;
	LineBit = 0;
	if(TateYoko == 0){
		px0= x0;
		py0= y0;
	}else{
/*		px0= y0;*/
/*		py0= 79- x0;*/
		px0= x0;
		py0= y0;
	}
	sy0= sy1= sy2= -1;

	while(x >= y){
		Dot(x+ x0,y+ y0,1);		/*�����Ńh�b�g��*/
		Dot(-(x)+ x0,y+ y0,1);		/*�����Ńh�b�g��*/
		Dot(-(x)+ x0,-(y)+ y0,1);		/*�����Ńh�b�g��*/
		Dot(x+ x0,-(y)+ y0,1);		/*�����Ńh�b�g��*/

		if(param->iPattern == P_NONE){
		}else{
			if(x > 0){
				if(sy0 != y){
					sy0= y;
					PaintPatarn1Line(-(x)+ px0+ 1,x+ px0- 1,y+ py0,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
					PaintPatarn1Line(-(x)+ px0+ 1,x+ px0- 1,-(y)+ py0,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
				}
			}
		}

		Dot(y+ x0,x+ y0,1);		/*�����Ńh�b�g��*/
		Dot(-(y)+ x0,x+ y0,1);		/*�����Ńh�b�g��*/
		Dot(-(y)+ x0,-(x)+ y0,1);		/*�����Ńh�b�g��*/
		Dot(y+ x0,-(x)+ y0,1);		/*�����Ńh�b�g��*/
		if(param->iPattern == P_NONE){
		}else{
			if(y > 0){
				sy= x+ py0;
				if((sy1 != sy) && (x != r)){
					sy1= sy;
					PaintPatarn1Line(-(y)+ px0+ 1,y+ px0- 1,sy,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
				}
				sy= -(x)+ py0;
				if((sy2 != sy) && (x != r)){
					sy2= sy;
					PaintPatarn1Line(-(y)+ px0+ 1,y+ px0- 1,sy,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
				}
			}else{
				sy1= x+ py0;
				sy2= -(x)+ py0;
			}
		}

		LineBit = (LineBit + 1) % 16;
		if((s2d + 2*y2 - x2) >= 0){
			s2d += -2*(x2+1);	/*�덷�̂Q?�����Z*/
			x--;
			x2 -= 2;
		}
		s2d += 2 * (y2 + 1);
		y++;
		y2 += 2;
	}
	ResetDispSema();
}
void	DrawDaenProc(int x0, int y0, int x00, int y00, _CIRCLE_INFO *param)
{
	/*(�P�O�C�O�j��茴?�𒆐S�ɂS�T�x�܂ł̍����?�ʂ��Ԃ���B*/
	int		x;
	int		y;
	int		s2d;		/*���Q���͂Q������ێ�*/
	int		x2;		/*�ȉ��̉��Z��2?�ł��Ɠs�����悢*/
	int		y2;		/*�ȉ��̉��Z��2?�ł��Ɠs�����悢*/
	int		px0,py0;
	int		sy0,sy1,sy2,sy;
	int		yyyyy;
	int		xxxxx;
	double	xy;

	SetDispSema();
	if(x00 > y00){
		x = x00;
		xy= (double)y00/(double)x00;
/*		xy= 65536 * y00/ x00;*/
	}else{
		x = y00;
		xy= (double)x00/(double)y00;
/*		xy= 65536 * x00/ y00;*/
	}
	y = 0;
	s2d = 3;		/*���Q���͂Q������ێ�*/
	x2 = 2*x;		/*�ȉ��̉��Z��2?�ł��Ɠs�����悢*/
	y2 = 2*y;		/*�ȉ��̉��Z��2?�ł��Ɠs�����悢*/

	if(param->iLineColor != 0){
		DrawColor= T_WHITE;
	}else{
		DrawColor= T_BLACK;
	}
	minY= GAMEN_Y_SIZE-1;
	maxY= 0;
	LineBit = 0;
	if(TateYoko == 0){
		px0= x0;
		py0= y0;
	}else{
/*		px0= y0;*/
/*		py0= 79- x0;*/
		px0= x0;
		py0= y0;
	}
	sy0= sy1= sy2= -1;

	while(x >= y){
		yyyyy= (int)(y*xy);
		xxxxx= (int)(x*xy);
		if(x00 > y00){
			Dot(x+ x0,yyyyy+ y0,1);		/*�����Ńh�b�g��*/
			Dot(-(x)+ x0,yyyyy+ y0,1);		/*�����Ńh�b�g��*/
			Dot(-(x)+ x0,-(yyyyy)+ y0,1);		/*�����Ńh�b�g��*/
			Dot(x+ x0,-(yyyyy)+ y0,1);		/*�����Ńh�b�g��*/

			if(param->iPattern == P_NONE){
			}else{
				if(x > 0){
					if(sy0 != yyyyy){
						sy0= yyyyy;
						PaintPatarn1Line(-(x)+ px0+ 1,x+ px0- 1,yyyyy+ py0,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
						PaintPatarn1Line(-(x)+ px0+ 1,x+ px0- 1,-(yyyyy)+ py0,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
					}
				}
			}

			Dot(y+ x0,xxxxx+ y0,1);		/*�����Ńh�b�g��*/
			Dot(-(y)+ x0,xxxxx+ y0,1);		/*�����Ńh�b�g��*/
			Dot(-(y)+ x0,-(xxxxx)+ y0,1);		/*�����Ńh�b�g��*/
			Dot(y+ x0,-(xxxxx)+ y0,1);		/*�����Ńh�b�g��*/
			if(param->iPattern == P_NONE){
			}else{
				if(y > 0){
					sy= xxxxx+ py0;
					if((sy1 != sy) && (xxxxx != y00)){
						sy1= sy;
						PaintPatarn1Line(-(y)+ px0+ 1,y+ px0- 1,sy,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
					}
					sy= -(xxxxx)+ py0;
					if((sy2 != sy) && (xxxxx != y00)){
						sy2= sy;
						PaintPatarn1Line(-(y)+ px0+ 1,y+ px0- 1,sy,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
					}
				}else{
					sy1= xxxxx+ py0;
					sy2= -(xxxxx)+ py0;
				}
			}
		}else{
			Dot(yyyyy+ x0,x+ y0,1);		/*�����Ńh�b�g��*/
			Dot(-(yyyyy)+ x0,x+ y0,1);		/*�����Ńh�b�g��*/
			Dot(-(yyyyy)+ x0,-(x)+ y0,1);		/*�����Ńh�b�g��*/
			Dot(yyyyy+ x0,-(x)+ y0,1);		/*�����Ńh�b�g��*/

			if(param->iPattern == P_NONE){
			}else{
				if(yyyyy > 0){
					if((sy0 != x) && (x < y00)){
						sy0= x;
						PaintPatarn1Line(-(yyyyy)+ px0+ 1,yyyyy+ px0- 1,x+ py0,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
						PaintPatarn1Line(-(yyyyy)+ px0+ 1,yyyyy+ px0- 1,-(x)+ py0,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
					}
				}
			}
			Dot(xxxxx+ x0,y+ y0,1);		/*�����Ńh�b�g��*/
			Dot(-(xxxxx)+ x0,y+ y0,1);		/*�����Ńh�b�g��*/
			Dot(-(xxxxx)+ x0,-(y)+ y0,1);		/*�����Ńh�b�g��*/
			Dot(xxxxx+ x0,-(y)+ y0,1);		/*�����Ńh�b�g��*/
			if(param->iPattern == P_NONE){
			}else{
				if(xxxxx > 0){
					sy= y+ py0;
					if(y != y00){
						PaintPatarn1Line(-(xxxxx)+ px0+ 1,xxxxx+ px0- 1,sy,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
					}
					sy= -(y)+ py0;
					if(y != y00){
						PaintPatarn1Line(-(xxxxx)+ px0+ 1,xxxxx+ px0- 1,sy,param->iPattern- 1,param->iForeColor,param->iBackColor,1);
					}
				}
			}
		}
		LineBit = (LineBit + 1) % 16;
		if((s2d + 2*y2 - x2) >= 0){
			s2d += -2*(x2+1);	/*�덷�̂Q?�����Z*/
			x--;
			x2 -= 2;
		}
		s2d += 2 * (y2 + 1);
		y++;
		y2 += 2;
	}
	ResetDispSema();
}
void	DrawDaen(int x0, int y0, int x,int y, _CIRCLE_INFO *param)
{
	if(x == y){
		DrawCircle(x0,y0,x,param);
	}else{
		DrawDaenProc(x0,y0,x,y,param);
	}
}
int	DemensionCheck1(int x1,int y1,int xy)
{
	int	dFlag;

	/* ��?��?�F�b�N */
	if(x1 == 0){
		if(y1 > 0){
			dFlag= 2;
		}else{
			dFlag= 6;
		}
	}else if(y1 == 0){
		if(x1 > 0){
			dFlag= 0;
		}else{
			dFlag= 4;
		}
	}else if(x1 > xy){			/* 0,7 */
		if(y1 < 0){
			dFlag= 7;
		}else{
			dFlag= 0;
		}
	}else if(x1 == xy){
		if(y1 > 0){
			dFlag= 1;
		}else{
			dFlag= 7;
		}
	}else if(x1 > 0){
		if(y1 < 0){
			dFlag= 6;
		}else{
			dFlag= 1;
		}
	}else if(abs(x1) > xy){
		if(y1 < 0){
			dFlag= 4;
		}else{
			dFlag= 3;
		}
	}else if(abs(x1) == xy){
		if(y1 > 0){
			dFlag= 3;
		}else{
			dFlag= 5;
		}
	}else{
		if(y1 < 0){
			dFlag= 5;
		}else{
			dFlag= 2;
		}
	}
	return(dFlag);
}
int	DemensionCheck2(int x1,int y1,double xy)
{
	int	dFlag;

	/* ��?��?�F�b�N */
	if(x1 == 0){
		if(y1 > 0){
			dFlag= 1;
		}else{
			dFlag= 5;
		}
	}else if(y1 == 0){
		if(x1 > 0){
			dFlag= 7;
		}else{
			dFlag= 3;
		}
	}else if(x1 > xy){			/* 0,7 */
		if(y1 < 0){
			dFlag= 7;
		}else{
			dFlag= 0;
		}
	}else if(x1 == xy){
		if(y1 > 0){
			dFlag= 0;
		}else{
			dFlag= 6;
		}
	}else if(x1 > 0){
		if(y1 < 0){
			dFlag= 6;
		}else{
			dFlag= 1;
		}
	}else if(abs(x1) > xy){
		if(y1 < 0){
			dFlag= 4;
		}else{
			dFlag= 3;
		}
	}else if(abs(x1) == xy){
		if(y1 > 0){
			dFlag= 2;
		}else{
			dFlag= 4;
		}
	}else{
		if(y1 < 0){
			dFlag= 5;
		}else{
			dFlag= 2;
		}
	}
	return(dFlag);
}
/********************************************/
/*	OOGIGATA								*/
/********************************************/
/* Side y > 0 */
int	CheckDraw01(int DrawFlag1,int DrawFlag2,int x,int y)
{
	int		ret;

	ret = -1;
	switch(DrawFlag1){
	case 1:			/* ��������?�� */
		ret = 0;
		break;
	case 2:			/* Single */
		switch(DrawFlag2){
		case 1:		/* X1-CCW */
			if((x <= x111) && (y >= y111)){
				ret = 0;
			}
			break;
		case 2:		/* X2-CW */
			if((x >= x222) && (y <= y222)){
				ret = 0;
			}
			break;
		}
		break;
	case 3:
		if(DrawFlag2 == 4){			/* In */
			if((x <= x111) && (x >= x222)){
				if((y >= y111) && (y <= y222)){
					ret = 0;
				}
			}
		}else{						/* Out */
			if((x <= x111) || (x >= x222)){
				if((y >= y111) || (y <= y222)){
					ret = 0;
				}
			}
		}
		break;
	}
	return(ret);
}
int	CheckDraw23(int DrawFlag1,int DrawFlag2,int x,int y)
{
	int		ret;

	ret = -1;
	switch(DrawFlag1){
	case 1:			/* ��������?�� */
		ret = 0;
		break;
	case 2:			/* Single */
		switch(DrawFlag2){
		case 1:		/* X1-CCW */
			if((x <= x111) && (y <= y111)){
				ret = 0;
			}
			break;
		case 2:		/* X2-CW */
			if((x >= x222) && (y >= y222)){
				ret = 0;
			}
			break;
		}
		break;
	case 3:
		if(DrawFlag2 == 4){			/* In */
			if((x <= x111) && (x >= x222)){
				if((y <= y111) && (y >= y222)){
					ret = 0;
				}
			}
		}else{						/* Out */
			if((x <= x111) || (x >= x222)){
				if((y <= y111) || (y >= y222)){
					ret = 0;
				}
			}
		}
		break;
	}
	return(ret);
}
int	CheckDraw45(int DrawFlag1,int DrawFlag2,int x,int y)
{
	int		ret;

	ret = -1;
	switch(DrawFlag1){
	case 1:			/* ��������?�� */
		ret = 0;
		break;
	case 2:			/* Single */
		switch(DrawFlag2){
		case 1:		/* X1-CCR */
			if((x >= x111) && (y <= y111)){
				ret = 0;
			}
			break;
		case 2:		/* X2-CW */
			if((x <= x222) && (y >= y222)){
				ret = 0;
			}
			break;
		}
		break;
	case 3:
		if(DrawFlag2 == 4){			/* In */
			if((x >= x111) && (x <= x222)){
				if((y <= y111) && (y >= y222)){
					ret = 0;
				}
			}
		}else{						/* Out */
			if((x >= x111) || (x <= x222)){
				if((y <= y111) || (y >= y222)){
					ret = 0;
				}
			}
		}
		break;
	}
	return(ret);
}
int	CheckDraw67(int DrawFlag1,int DrawFlag2,int x,int y)
{
	int		ret;

	ret = -1;
	switch(DrawFlag1){
	case 1:			/* ��������?�� */
		ret = 0;
		break;
	case 2:			/* Single */
		switch(DrawFlag2){
		case 1:		/* X1-CCW */
			if((x >= x111) && (y >= y111)){
					ret = 0;
			}
			break;
		case 2:		/* X2-CW */
			if((x <= x222) && (y <= y222)){
				ret = 0;
			}
			break;
		}
		break;
	case 3:
		if(DrawFlag2 == 4){			/* In */
			if((x >= x111) && (x <= x222)){
				if((y >= y111) && (y <= y222)){
					ret = 0;
				}
			}
		}else{						/* Out */
			if((x >= x111) || (x <= x222)){
				if((y >= y111) || (y <= y222)){
					ret = 0;
				}
			}
		}
		break;
	}
	return(ret);
}
/* sx,sy:Center */
/* ex,ey:Cicle Point */
void	LineOutNoSema(int sx,int sy,int ex,int ey,_LINE_INFO *param)
{
	int	ssx,ssy,eex,eey;
	int	BackUp;

	BackUp= DrawColor;
	if(param->iLineColor != 0){
		DrawColor= T_WHITE;
	}else{
		DrawColor= T_BLACK;
	}
	if(TateYoko == 0){
		ssx= sx+ x000;
		ssy= sy+ y000;
		eex= ex+ x000;
		eey= ey+ y000;
	}else{
		ssx= sy+ y000;
		ssy= (GAMEN_Y_SIZE-1)- (sx+ x000);
		eex= ey+ y000;
		eey= (GAMEN_Y_SIZE-1)- (ex+ x000);
	}
	if((ssx < 0) || (eex < 0) || (ssx > GAMEN_X_SIZE-1) || (eex > GAMEN_X_SIZE-1) ||
		(ssy < 0) || (eey < 0) || (ssy > GAMEN_Y_SIZE-1) || (eey > GAMEN_Y_SIZE-1)){
		LineBit = 0;
		DrawColor= BackUp;
	}else{
		LineBit = 0;
		__MoveTo( ssx, ssy, param->iLineStyle, 0 );
		__LineTo( eex, eey,0 );
		DrawColor= BackUp;
	}
}
void	PaintPatarn1LineXY0(int sx,int sy,int ex,int ey,int color)
{
	int		lx;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}

	switch(DrawFlag[0][0]){
	case 1:		/* All Write */
		LineOutNoSema( ex, ey, ey, ey, &param );
		break;
	case 2:		/* Single */
		switch(DrawFlag[0][1]){
		case 1:	/* 1-CCW */
			LineOutNoSema( ex, ey, ey, ey, &param );
			if(SaveStart[0] > ey){
				SaveStart[0]= ey;
			}
			break;
		case 2:	/* 2-CW */
			lx= (int)((ey- Para_b2) / Para_a2);
			LineOutNoSema( ex, ey, lx, ey, &param );
			break;
		}
		break;
	case 3:		/* Double */
		if(DrawFlag[0][1] == 4){		/* In */
			lx= (int)((ey- Para_b2) / Para_a2);
			LineOutNoSema( ex, ey, lx, ey, &param );
			if(SaveStart[0] > ey){
				SaveStart[0]= ey;
			}
		}else{							/* Out */
			if((ey >= y111) && (ex <= x111)){
				LineOutNoSema( ex, ey, ey, ey, &param );
				if(SaveStart[0] > ey){
					SaveStart[0]= ey;
				}
			}else if((ey <= y222) && (ex >= x222)){
				lx= (int)((ey- Para_b2) / Para_a2);
				LineOutNoSema( ex, ey, lx, ey, &param );
			}
		}
		break;
	}
}
void	PaintPatarn1LineXY1(int sx,int sy,int ex,int ey,int color)
{
	int		ly;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}

	switch(DrawFlag[1][0]){
	case 1:		/* Write */
		LineOutNoSema( ex, ey, ex, ex, &param );
		break;
	case 2:		/* Single */
		switch(DrawFlag[1][1]){
		case 1:		/* X1-Left */
			ly= (int)(Para_a1*ex+ Para_b1);
			LineOutNoSema( ex, ey, ex, ly, &param );
			break;
		case 2:
			LineOutNoSema( ex, ey, ex, ex, &param );
			if(SaveStart[1] > ex){
				SaveStart[1]= ex;
			}
			break;
		}
		break;
	case 3:		/* Double */
		if(DrawFlag[1][1] == 4){		/* In */
			ly= (int)(Para_a1*ex+ Para_b1);
			LineOutNoSema( ex, ey, ex, ly, &param );
			if(SaveStart[1] > ex){
				SaveStart[1]= ex;
			}
		}else{							/* Out */
			if((ey >= y111) && (ex <= x111)){
				ly= (int)(Para_a1*ex+ Para_b1);
				LineOutNoSema( ex, ey, ex, ly, &param );
			}else if((ey <= y222) && (ex >= x222)){
				LineOutNoSema( ex, ey, ex, ex, &param );
				if(SaveStart[1] > ex){
					SaveStart[1]= ex;
				}
			}
		}
		break;
	}
}
void	PaintPatarn1LineXY2(int sx,int sy,int ex,int ey,int color)
{
	int		ly;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}

	switch(DrawFlag[2][0]){
	case 1:		/* Write */
		LineOutNoSema( ex, ey, ex, -ex, &param );
		break;
	case 2:		/* Single */
		switch(DrawFlag[2][1]){
		case 1:		/* X1-Left */
			LineOutNoSema( ex, ey, ex, -ex, &param );
			if(SaveStart[2] < ex){
				SaveStart[2]= ex;
			}
			break;
		case 2:
			ly= (int)(Para_a2*ex+ Para_b2);
			LineOutNoSema( ex, ey, ex, ly, &param );
			break;
		}
		break;
	case 3:		/* Double */
		if(DrawFlag[2][1] == 4){		/* In */
			ly= (int)(Para_a2*ex+ Para_b2);
			LineOutNoSema( ex, ey, ex, ly, &param );
			if(SaveStart[2] < ex){
				SaveStart[2]= ex;
			}
		}else{							/* Out */
			if((ey >= y222) && (ex > x222)){
				ly= (int)(Para_a2*ex+ Para_b2);
				LineOutNoSema( ex, ey, ex, ly, &param );
			}else if((ey <= y111) & (ex <= x111)){
				LineOutNoSema( ex, ey, ex, -ex, &param );
				if(SaveStart[2] < ex){
					SaveStart[2]= ex;
				}
			}
		}
		break;
	}
}
void	PaintPatarn1LineXY3(int sx,int sy,int ex,int ey,int color)
{
	int		lx;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	switch(DrawFlag[3][0]){
	case 1:		/* Write */
		LineOutNoSema( ex, ey, -ey, ey, &param );
		break;
	case 2:		/* Single */
		switch(DrawFlag[3][1]){
		case 1:
			lx= (int)((ey- Para_b1) / Para_a1);
			LineOutNoSema( ex, ey, lx, ey, &param );
			break;
		case 2:
			LineOutNoSema( ex, ey, -ey, ey, &param );
			if(SaveStart[3] > ey){
				SaveStart[3]= ey;
			}
			break;
		}
		break;
	case 3:		/* Double */
		if(DrawFlag[3][1] == 4){		/* In */
			lx= (int)((ey- Para_b1) / Para_a1);
			LineOutNoSema( ex, ey, lx, ey, &param );
			if(SaveStart[3] > ey){
				SaveStart[3]= ey;
			}
		}else{							/* Out */
			if((ey >= y222) && (ex >= x222)){
				LineOutNoSema( ex, ey, -ey, ey, &param );
				if(SaveStart[3] > ey){
					SaveStart[3]= ey;
				}
			}else if((ey <= y111) && (ex <= x111)){
				lx= (int)((ey- Para_b1) / Para_a1);
				LineOutNoSema( ex, ey, lx, ey, &param );
			}
		}
		break;
	}
}
void	PaintPatarn1LineXY4(int sx,int sy,int ex,int ey,int color)
{
	int		lx;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	switch(DrawFlag[4][0]){
	case 1:		/* Write */
		LineOutNoSema( ex, ey, ey, ey, &param );
		break;
	case 2:		/* Single */
		switch(DrawFlag[4][1]){
		case 1:
			LineOutNoSema( ex, ey, ey, ey, &param );
			if(SaveStart[4] < ey){
				SaveStart[4]= ey;
			}
			break;
		case 2:
			lx= (int)((ey- Para_b2) / Para_a2);
			LineOutNoSema( ex, ey, lx, ey, &param );
			break;
		}
		break;
	case 3:		/* Double */
		if(DrawFlag[4][1] == 4){		/* In */
			lx= (int)((ey- Para_b2) / Para_a2);
			LineOutNoSema( ex, ey, lx, ey, &param );
			if(SaveStart[4] < ey){
				SaveStart[4]= ey;
			}
		}else{							/* Out */
			if((ey >= y222) && (ex <= x222)){
				lx= (int)((ey- Para_b2) / Para_a2);
				LineOutNoSema( ex, ey, lx, ey, &param );
			}else if((ey <= y111) && (ex >= x111)){
				LineOutNoSema( ex, ey, ey, ey, &param );
				if(SaveStart[4] < ey){
					SaveStart[4]= ey;
				}
			}
		}
		break;
	}
}
void	PaintPatarn1LineXY5(int sx,int sy,int ex,int ey,int color)
{
	int		ly;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	switch(DrawFlag[5][0]){
	case 1:		/* Write */
		LineOutNoSema( ex, ey, ex, ex, &param );
		break;
	case 2:		/* Single */
		switch(DrawFlag[5][1]){
		case 1:		/* X1-Right */
			ly= (int)(Para_a1*ex+ Para_b1);
			LineOutNoSema( ex, ey, ex, ly, &param );
			break;
		case 2:		/* X1-Left */
			LineOutNoSema( ex, ey, ex, ex, &param );
			if(SaveStart[5] < ex){
				SaveStart[5]= ex;
			}
			break;
		}
		break;
	case 3:		/* Double */
		if(DrawFlag[5][1] == 4){		/* In */
			ly= (int)(Para_a1*ex+ Para_b1);
			LineOutNoSema( ex, ey, ex, ly, &param );
			if(SaveStart[5] < ex){
				SaveStart[5]= ex;
			}
		}else{							/* Out */
			if((ey >= y222) && (ex <= x222)){
				LineOutNoSema( ex, ey, ex, ex, &param );
				if(SaveStart[5] < ex){
					SaveStart[5]= ex;
				}
			}else if((ey <= y111) && (ex >= x111)){
				ly= (int)(Para_a1*ex+ Para_b1);
				LineOutNoSema( ex, ey, ex, ly, &param );
			}
		}
		break;
	}
}
void	PaintPatarn1LineXY6(int sx,int sy,int ex,int ey,int color)
{
	int		ly;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	switch(DrawFlag[6][0]){
	case 1:		/* Write */
		LineOutNoSema( ex, ey, ex, -ex, &param );
		break;
	case 2:		/* Single */
		switch(DrawFlag[6][1]){
		case 1:		/* X1-CCW */
			LineOutNoSema( ex, ey, ex, -ex, &param );
			if(SaveStart[6] > ex){
				SaveStart[6]= ex;
			}
			break;
		case 2:		/* X1-CW */
			ly= (int)(Para_a2*ex+ Para_b2);
			LineOutNoSema( ex, ey, ex, ly, &param );
			break;
		}
		break;
	case 3:		/* Double */
		if(DrawFlag[6][1] == 4){		/* In */
			ly= (int)(Para_a2*ex+ Para_b2);
			LineOutNoSema( ex, ey, ex, ly, &param );
			if(SaveStart[6] > ex){
				SaveStart[6]= ex;
			}
		}else{							/* Out */
			if((ey >= y111) && (ex >= x111)){
				LineOutNoSema( ex, ey, ex, -ex, &param );
				if(SaveStart[6] > ex){
					SaveStart[6]= ex;
				}
			}else if((ey <= y222) && (ex <= x222)){
				ly= (int)(Para_a2*ex+ Para_b2);
				LineOutNoSema( ex, ey, ex, ly, &param );
			}
		}
		break;
	}
}
void	PaintPatarn1LineXY7(int sx,int sy,int ex,int ey,int color)
{
	int		lx;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	switch(DrawFlag[7][0]){
	case 1:		/* All Write */
		LineOutNoSema( ex, ey, -ey, ey, &param );
		break;
	case 2:		/* Single */
		switch(DrawFlag[7][1]){
		case 1:	/* 1-left */
			lx= (int)((ey- Para_b1) / Para_a1);
			LineOutNoSema( ex, ey, lx, ey, &param );
			break;
		case 2:	/* 2-right */
			LineOutNoSema( ex, ey, -ey, ey, &param );
			if(SaveStart[7] < ey){
				SaveStart[7]= ey;
			}
			break;
		}
		break;
	case 3:		/* Double */
		if(DrawFlag[7][1] == 4){		/* In */
			lx= (int)((ey- Para_b1) / Para_a1);
			LineOutNoSema( ex, ey, lx, ey, &param );
			if(SaveStart[7] < ey){
				SaveStart[7]= ey;
			}
		}else{							/* Out */
			if((ey >= y111) && (ex >= x111)) {
				lx= (int)((ey- Para_b1) / Para_a1);
				LineOutNoSema( ex, ey, lx, ey, &param );
			}else if((ey < y222) && (ex <= x222)){
				LineOutNoSema( ex, ey, -ey, ey, &param );
				if(SaveStart[7] < ey){
					SaveStart[7]= ey;
				}
			}
		}
		break;
	}
}
/************************************************/
/* Remain Pain									*/
/************************************************/
void	CheckRemain0( int color )
{
	int		iii;
	int		dx,dx1;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	if(DrawFlag[0][0] == 2){	/* Single */
		if(DrawFlag[0][1] == 1){	/* 1-CCW */
			if(SaveStart[0] > y111+1){
				dx1= SaveStart[0]-1;
				dx= x111;
				LineOutNoSema( dx, dx1, dx1, dx1, &param );
			}
			for(iii= y111; iii >= 0; iii--){
				dx= (int)((iii- Para_b1) / Para_a1);
				LineOutNoSema( dx, iii, iii, iii, &param );
			}
		}
	}else{						/* Double */
		if(SaveStart[0] > y111+1){
			dx1= SaveStart[0]-1;
			dx= x111;
			LineOutNoSema( dx, dx1, dx1, dx1, &param );
		}
		if(DrawFlag[0][1] == 4){	/* In */
			for(iii= y111; iii >= 0; iii--){
				dx= (int)((iii- Para_b1) / Para_a1);
				dx1= (int)((iii- Para_b2) / Para_a2);
				LineOutNoSema( dx, iii, dx1, iii, &param );
			}
		}else{					/* Out(1-Left) */
			for(iii= y111; iii >= 0; iii--){
				dx= (int)((iii- Para_b1) / Para_a1);
				LineOutNoSema( iii, iii, dx, iii, &param );
			}
		}
	}
}
void	CheckRemain1( int color )
{
	int		iii;
	int		dy,dy1;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	if(DrawFlag[1][0] == 2){	/* Single */
		if(DrawFlag[1][1] == 2){	/* 2-CW */
			if(SaveStart[1] > x222+1){
				dy1= SaveStart[1]-1;
				dy= y222;
				LineOutNoSema( dy1, dy, dy1, dy1, &param );
			}
			for(iii= x222; iii >= 0; iii--){
				dy= (int)(Para_a2 * iii + Para_b2);
				LineOutNoSema( iii, dy, iii, iii, &param );
			}
		}
	}else{						/* Double */
		if(SaveStart[1] > x222+1){
			dy1= SaveStart[1]-1;
			dy= y111;
			LineOutNoSema( dy1, dy, dy1, dy1, &param );
		}
		if(DrawFlag[1][1] == 4){	/* In */
			for(iii= x222; iii >= 0; iii--){
				dy= (int)(Para_a2 * iii + Para_b2);
				dy1= (int)(Para_a1 * iii + Para_b1);
				LineOutNoSema( iii, dy, iii, dy1, &param );
			}
		}else{					/* Out */
			for(iii= x222; iii >= 0; iii--){
				dy= (int)(Para_a2 * iii + Para_b2);
				LineOutNoSema( iii, dy, iii, iii, &param );
			}
		}
	}
}
void	CheckRemain2( int color )
{
	int		iii;
	int		dy,dy1;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	if(DrawFlag[2][0] == 2){	/* Single */
		if(DrawFlag[2][1] == 1){	/* 1-CCW */
			if(SaveStart[2] < x111-1){
				dy1= SaveStart[2]+1;
				dy= y111;
				LineOutNoSema( dy1, dy, dy1, dy1, &param );
			}
			for(iii= x111; iii <= 0; iii++){
				dy= (int)(Para_a1 * iii + Para_b1);
				LineOutNoSema( iii, dy, iii, -iii, &param );
			}
		}
	}else{						/* Double */
		if(SaveStart[2] < x111-1){
			dy1= SaveStart[2]+1;
			dy= y111;
			LineOutNoSema( dy1, dy, dy1, dy1, &param );
		}
		if(DrawFlag[2][1] == 4){	/* In */
			for(iii= x111; iii <= 0; iii++){
				dy= (int)(Para_a1 * iii + Para_b1);
				dy1= (int)(Para_a2 * iii + Para_b2);
				LineOutNoSema( iii, dy, iii, dy1, &param );
			}
		}else{				/* Out */
			for(iii= x111; iii <= 0; iii++){
				dy= (int)(Para_a1 * iii + Para_b1);
				LineOutNoSema( iii, dy, iii, -iii, &param );
			}
		}
	}
}
void	CheckRemain3( int color )
{
	int		iii;
	int		dx,dx1;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	if(DrawFlag[3][0] == 2){	/* Single */
		if(DrawFlag[3][1] == 2){		/* 2-CW */
			if(SaveStart[3] > y222+1){
				dx1= SaveStart[3]-1;
				dx= x222;
				LineOutNoSema( dx, dx1, dx1, dx1, &param );
			}
			for(iii= y222; iii >= 0; iii--){
				dx= (int)((iii- Para_b2) / Para_a2);
				LineOutNoSema( dx, iii, -iii, iii, &param );
			}
		}
	}else{						/* Double */
		if(SaveStart[3] > y222+1){
			dx1= SaveStart[3]-1;
			dx= x222;
			LineOutNoSema( dx, dx1, dx1, dx1, &param );
		}
		if(DrawFlag[3][1] == 4){	/* In */
			for(iii= y222; iii >= 0; iii--){
				dx= (int)((iii- Para_b2) / Para_a2);
				dx1= (int)((iii- Para_b1) / Para_a1);
				LineOutNoSema( dx, iii, dx1, iii, &param );
			}
		}else{					/* Out(1-Left) */
			for(iii= y222; iii >= 0; iii--){
				dx= (int)((iii- Para_b2) / Para_a2);
				LineOutNoSema( dx, iii, -iii, iii, &param );
			}
		}
	}
}
void	CheckRemain4( int color )
{
	int		iii;
	int		dx,dx1;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	if(DrawFlag[4][0] == 2){	/* Single */
		if(DrawFlag[4][1] == 1){	/* 1-CCW */
			if(SaveStart[4] < y111-1){
				dx1= SaveStart[4]+1;
				dx= x111;
				LineOutNoSema( dx, dx1, dx1, dx1, &param );
			}
			for(iii= y111; iii <= 0; iii++){
				dx= (int)((iii- Para_b1) / Para_a1);
				LineOutNoSema( dx, iii, iii, iii, &param );
			}
		}
	}else{						/* Double */
		if(SaveStart[4] < y222-1){
			dx1= SaveStart[4]+1;
			dx= x222;
			LineOutNoSema( dx, dx1, dx1, dx1, &param );
		}
		if(DrawFlag[4][1] == 4){	/* In */
			for(iii= y111; iii <= 0; iii++){
				dx= (int)((iii- Para_b1) / Para_a1);
				dx1= (int)((iii- Para_b2) / Para_a2);
				LineOutNoSema( dx, iii, dx1, iii, &param );
			}
		}else{					/* Out(1-right) */
			for(iii= y111; iii <= 0; iii++){
				dx= (int)((iii- Para_b1) / Para_a1);
				LineOutNoSema( dx, iii, iii, iii, &param );
			}
		}
	}
}
void	CheckRemain5( int color )
{
	int		iii;
	int		dy,dy1;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	if(DrawFlag[5][0] == 2){	/* Single */
		if(DrawFlag[5][1] == 2){	/* 2-CW */
			if(SaveStart[5] < x222-1){
				dy1= SaveStart[5]+1;
				dy= y222;
				LineOutNoSema( dy1, dy, dy1, dy1, &param );
			}
			for(iii= x222; iii <= 0; iii++){
				dy= (int)(Para_a2 * iii + Para_b2);
				LineOutNoSema( iii, dy, iii, iii, &param );
			}
		}
	}else{						/* Double */
		if(SaveStart[5] < x222-1){
			dy1= SaveStart[5]+1;
			dy= y222;
			LineOutNoSema( dy1, dy, dy1, dy1, &param );
		}
		if(DrawFlag[5][1] == 4){	/* In */
			for(iii= x222; iii <= 0; iii++){
				dy= (int)(Para_a2 * iii + Para_b2);
				dy1= (int)(Para_a1 * iii + Para_b1);
				LineOutNoSema( iii, dy, iii, dy1, &param );
			}
		}else{				/* Out */
			for(iii= x222; iii <= 0; iii++){
				dy= (int)(Para_a2 * iii + Para_b2);
				LineOutNoSema( iii, dy, iii, iii, &param );
			}
		}
	}
}
void	CheckRemain6( int color )
{
	int		iii;
	int		dy,dy1;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	if(DrawFlag[6][0] == 2){	/* Single */
		if(DrawFlag[6][1] == 1){	/* 1-CCW */
			if(SaveStart[6] > x111+1){
				dy1= SaveStart[6]-1;
				dy= y111;
				LineOutNoSema( dy1, dy, dy1, dy1, &param );
			}
			for(iii= x111; iii >= 0; iii--){
				dy= (int)(Para_a1 * iii + Para_b1);
				LineOutNoSema( iii, dy, iii, -iii, &param );
			}
		}
	}else{						/* Double */
		if(SaveStart[6] > x111+1){
			dy1= SaveStart[6]-1;
			dy= y111;
			LineOutNoSema( dy1, dy, dy1, dy1, &param );
		}
		if(DrawFlag[6][1] == 4){	/* In */
			for(iii= x111; iii >= 0; iii--){
				dy= (int)(Para_a1 * iii + Para_b1);
				dy1= (int)(Para_a2 * iii + Para_b2);
				LineOutNoSema( iii, dy, iii, dy1, &param );
			}
		}else{					/* Out */
			for(iii= x111; iii >= 0; iii--){
				dy= (int)(Para_a1 * iii + Para_b1);
				LineOutNoSema( iii, dy, iii, -iii, &param );
			}
		}
	}
}
void	CheckRemain7( int color )
{
	int		iii;
	int		dx,dx1;
	_LINE_INFO param;

	param.iLineStyle= 1;
	if(color != 0){
		param.iLineColor= T_WHITE;
	}else{
		param.iLineColor= T_BLACK;
	}
	if(DrawFlag[7][0] == 2){	/* Single */
		if(DrawFlag[7][1] == 2){		/* 2-CW */
			if(SaveStart[7] < y222-1){
				dx1= SaveStart[7]+1;
				dx= x222;
				LineOutNoSema( dx, dx1, dx1, dx1, &param );
			}
			for(iii= y222; iii <= 0; iii++){
				dx= (int)((iii- Para_b2) / Para_a2);
				LineOutNoSema( dx, iii, -iii, iii, &param );
			}
		}
	}else{						/* Double */
		if(SaveStart[7] < y222-1){
			dx1= SaveStart[7]+1;
			dx= x222;
			LineOutNoSema( dx, dx1, dx1, dx1, &param );
		}
		if(DrawFlag[7][1] == 4){	/* In */
			for(iii= y222; iii <= 0; iii++){
				dx= (int)((iii- Para_b2) / Para_a2);
				dx1= (int)((iii- Para_b1) / Para_a1);
				LineOutNoSema( dx, iii, dx1, iii, &param );
			}
		}else{					/* Out(1-right) */
			for(iii= y222; iii <= 0; iii++){
				dx= (int)((iii- Para_b2) / Para_a2);
				LineOutNoSema( dx, iii, -iii, iii, &param );
			}
		}
	}
}
void	CheckRemain(int color)
{
	int		idx;

	for(idx= 0; idx < 8; idx++){
		if(DrawFlag[idx][0] > 1){
			switch(idx){
			case 0:
				CheckRemain0(color);
				break;
			case 1:
				CheckRemain1(color);
				break;
			case 2:
				CheckRemain2(color);
				break;
			case 3:
				CheckRemain3(color);
				break;
			case 4:
				CheckRemain4(color);
				break;
			case 5:
				CheckRemain5(color);
				break;
			case 6:
				CheckRemain6(color);
				break;
			case 7:
				CheckRemain7(color);
				break;
			}
		}
	}
}
int	Round(double data)
{
	if(data < 0){
		return((int)(data - 0.5));
	}else{
		return((int)(data + 0.5));
	}
}
/********************************************************/
/*	In		x0,y0:	���S?���W							*/
/*			r:      ���a								*/
/*			x1,y1:	START�ʒu���W�i���΍��W�j			*/
/*			x20,y20	END�ʒu���W�i���΍��W�j				*/
/*			Scale:	Scale Position(0:OFF,else:			*/
/*			iSel:	Scale Display						*/
/*			_ORGGATA_INFO:	?���X?�C��				*/
/********************************************************/
void	DrawOrggataProc(int x0, int y0, int r, int x1, int y1, int x20, int y20,int Scale, int iSel,_ORGGATA_INFO *param,int DrawOn)
{
	/*(�P�O�C�O�j��茴?�𒆐S�ɂS�T�x�܂ł̍����?�ʂ��Ԃ���B*/
	int		x = r;
	int		y = 0;
	int		s2d = 3;		/*���Q���͂Q������ێ�*/
	int		x2 = 2*x;		/*�ȉ��̉��Z��2?�ł��Ɠs�����悢*/
	int		y2 = 2*y;		/*�ȉ��̉��Z��2?�ł��Ɠs�����悢*/
	int		i;
	int		dFlag1,dFlag2;
	int		xy;
	double	Sita;
	double	bx1,by1;
	double	bx2,by2;
	double	Temp;
	double	CosSeta;
	double	SinSeta;
	_LINE_INFO param1;
	int		idx;
	int		sCount;

	SetDispSema();
	if(TateYoko == 0){
		x000= x0;
		y000= y0;
		SaveStart[0]= GAMEN_Y_SIZE;
		SaveStart[1]= GAMEN_X_SIZE;
		SaveStart[2]= -GAMEN_X_SIZE;
		SaveStart[3]= GAMEN_Y_SIZE;
		SaveStart[4]= -GAMEN_Y_SIZE;
		SaveStart[5]= -GAMEN_X_SIZE;
		SaveStart[6]= GAMEN_X_SIZE;
		SaveStart[7]= -GAMEN_Y_SIZE;
	}else{
		x000= x0;
		y000= y0;
		SaveStart[0]= GAMEN_X_SIZE;
		SaveStart[1]= GAMEN_Y_SIZE;
		SaveStart[2]= -GAMEN_Y_SIZE;
		SaveStart[3]= GAMEN_X_SIZE;
		SaveStart[4]= -GAMEN_X_SIZE;
		SaveStart[5]= -GAMEN_Y_SIZE;
		SaveStart[6]= GAMEN_Y_SIZE;
		SaveStart[7]= -GAMEN_X_SIZE;
	}
	x111= x1;
	y111= y1;
	x222= x20;
	y222= y20;
	rrrr= r;
	if(param->iScaleColor != 0){
		DrawColor= T_WHITE;
	}else{
		DrawColor= T_BLACK;
	}
	memset(DrawFlag,0,sizeof(DrawFlag));
	xy = (int)(sqrt(r*r/2)+ 0.5);
	/* Start Pos Dimension */
	dFlag1= DemensionCheck1(x1,y1,xy);
	/* End Pos Dimension */
	dFlag2= DemensionCheck2(x20,y20,xy);
	for(i = 0; i < 8; i++){
		if(dFlag1 == dFlag2){		/* X1,X2=Same Dimnsion */
			if(i == dFlag1){
				if((y1 >= 0) && (y20 >= 0)){
					if(x1 == x20){
						if((x1 >= 0) && (x20 >= 0)){
							if(y20 > y1){
								DrawFlag[i][0] = 3;	/* Double */
								DrawFlag[i][1] = 4;	/* In */
							}else{
								DrawFlag[i][0] = 3;	/* Double */
								DrawFlag[i][1] = 5;	/* Out */
							}
						}else{
							if(y20 < y1){
								DrawFlag[i][0] = 3;	/* Double */
								DrawFlag[i][1] = 4;	/* In */
							}else{
								DrawFlag[i][0] = 3;	/* Double */
								DrawFlag[i][1] = 5;	/* Out */
							}
						}
					}else{
						if(y1 == y20){
							if(x1 > x20){
								DrawFlag[i][0] = 3;	/* Double */
								DrawFlag[i][1] = 4;	/* In */
							}else{
								DrawFlag[i][0] = 3;	/* Double */
								DrawFlag[i][1] = 5;	/* Out */
							}
						}else{
							if((x1 >= 0) && (x20 >= 0)){
								if(y1 <= y20){
									DrawFlag[i][0] = 3;	/* Double */
									DrawFlag[i][1] = 4;	/* In */
								}else{
									DrawFlag[i][0] = 3;	/* Double */
									DrawFlag[i][1] = 5;	/* Out */
								}
							}else{
								if(y1 >= y20){
									DrawFlag[i][0] = 3;	/* Double */
									DrawFlag[i][1] = 4;	/* In */
								}else{
									DrawFlag[i][0] = 3;	/* Double */
									DrawFlag[i][1] = 5;	/* Out */
								}
							}
						}
					}
				}else{
					if(x1 == x20){
						if((x1 >= 0) && (x2 >= 0)){
							if(y1 < y20){
								DrawFlag[i][0] = 3;	/* Double */
								DrawFlag[i][1] = 4;	/* In */
							}else{
								DrawFlag[i][0] = 3;	/* Double */
								DrawFlag[i][1] = 5;	/* Out */
							}
						}else{
							if(y1> y20){
								DrawFlag[i][0] = 3;	/* Double */
								DrawFlag[i][1] = 4;	/* In */
							}else{
								DrawFlag[i][0] = 3;	/* Double */
								DrawFlag[i][1] = 5;	/* Out */
							}
						}
					}else{
						if(x1 < x20){
							DrawFlag[i][0] = 3;	/* Double */
							DrawFlag[i][1] = 4;	/* In */
						}else{
							DrawFlag[i][0] = 3;	/* Double */
							DrawFlag[i][1] = 5;	/* Out */
						}
					}
				}
			}else{		/* �w��̊O */
				if((x1 >= 0) && (x20 >= 0)){	/* 0,1,6,7 */
					if(y20 == y1){
						if(y20 >= 0){
							if(x1 > x20){		/* IN */
								DrawFlag[i][0] = 0;	/* Draw */
							}else{
								DrawFlag[i][0] = 1;	/* Draw */
							}
						}else{
							if(x1 < x20){		/* IN */
								DrawFlag[i][0] = 0;	/* Draw */
							}else{
								DrawFlag[i][0] = 1;	/* Draw */
							}
						}
					}else{
						if(y20 > y1){			/* IN */
							DrawFlag[i][0] = 0;	/* Draw */
						}else{
							DrawFlag[i][0] = 1;	/* Draw */
						}
					}
				}else{
					if(y20 == y1){
						if(y20 >= 0){
							if(x1 > x20){		/* IN */
								DrawFlag[i][0] = 0;	/* Draw */
							}else{
								DrawFlag[i][0] = 1;	/* Draw */
							}
						}else{
							if(x1 < x20){		/* IN */
								DrawFlag[i][0] = 0;	/* Draw */
							}else{
								DrawFlag[i][0] = 1;	/* Draw */
							}
						}
					}else{
						if(y20 < y1){			/* IN */
							DrawFlag[i][0] = 0;	/* Draw */
						}else{
							DrawFlag[i][0] = 1;	/* Draw */
						}
					}
				}
			}
		}else{
			if(i == dFlag1){
				DrawFlag[i][0] = 2;	/* Single */
				DrawFlag[i][1] = 1;	/* X1-CCW */
			}else if(i == dFlag2){
				DrawFlag[i][0] = 2;	/* Single */
				DrawFlag[i][1] = 2;	/* X2-CW */
			}else{
				if(dFlag1 < dFlag2){
					if((i > dFlag1) && (i < dFlag2)){
						DrawFlag[i][0] = 1;	/* Draw */
					}else{
						DrawFlag[i][0] = 0;	/* Un Draw */
					}
				}else{
					if(i < dFlag2){
						idx= i+ 8;
					}else{
						idx= i;
					}
					if((idx > dFlag1) || (idx < dFlag2)){
						DrawFlag[i][0] = 1;	/* Draw */
					}else{
						DrawFlag[i][0] = 0;	/* Un Draw */
					}
				}
			}
		}
	}
	if(x1 != 0){
		Para_a1= (double)y1 / (double)x1;
	}else{
		Para_a1= 0;
	}
	Para_b1= 0;
	if(x20 != 0){
		Para_a2= (double)y20 / (double)x20;
	}else{
		Para_a2= 0;
	}
	Para_b2= 0;
	while(x > y){
		if(DrawOn != 0){
			/* 0 Dimension */
			if(CheckDraw01(DrawFlag[0][0],DrawFlag[0][1],x,y) == 0){
				PaintPatarn1LineXY0(y,y,x,y,param->iColor);
				Dot(x+ x0,y+ y0,1);		/*�����Ńh�b�g��*/
			}
			/* 3 Dimension */
			if(CheckDraw23(DrawFlag[3][0],DrawFlag[3][1],-(x),y) == 0){
				PaintPatarn1LineXY3(y,y,-(x),y,param->iColor);
				Dot(-(x)+ x0,y+ y0,1);		/*�����Ńh�b�g��*/
			}
			/* 4 Dimension */
			if(CheckDraw45(DrawFlag[4][0],DrawFlag[4][1],-(x),-(y)) == 0){
				PaintPatarn1LineXY4(-(y),-(y),-(x),-(y),param->iColor);
				Dot(-(x)+ x0,-(y)+ y0,1);		/*�����Ńh�b�g��*/
			}
			/* 7 Dimension */
			if(CheckDraw67(DrawFlag[7][0],DrawFlag[7][1],x,-(y)) == 0){
				PaintPatarn1LineXY7(-(y),-(y),x,-(y),param->iColor);
				Dot(x+ x0,-(y)+ y0,1);		/*�����Ńh�b�g��*/
			}
			/* 1 Dimension */
			if(CheckDraw01(DrawFlag[1][0],DrawFlag[1][1],y,x) == 0){
				PaintPatarn1LineXY1(y,y,y,x,param->iColor);
				Dot(y+ x0,x+ y0,1);		/*�����Ńh�b�g��*/
			}
			/* 2 Dimension */
			if(CheckDraw23(DrawFlag[2][0],DrawFlag[2][1],-(y),x) == 0){
				PaintPatarn1LineXY2(-(y),-(y),-(y),x,param->iColor);
				Dot(-(y)+ x0,x+ y0,1);		/*�����Ńh�b�g��*/
			}
			/* 5 Dimension */
			if(CheckDraw45(DrawFlag[5][0],DrawFlag[5][1],-(y),-(x)) == 0){
				PaintPatarn1LineXY5(-(y),-(y),-(y),-(x),param->iColor);
				Dot(-(y)+ x0,-(x)+ y0,1);		/*�����Ńh�b�g��*/
			}
			/* 6 Dimension */
			if(CheckDraw67(DrawFlag[6][0],DrawFlag[6][1],y,-(x)) == 0){
				PaintPatarn1LineXY6(y,y,y,-(x),param->iColor);
				Dot(y+ x0,-(x)+ y0,1);		/*�����Ńh�b�g��*/
			}
		}
		if((s2d + 2*y2 - x2) >= 0){
			s2d += -2*(x2+1);	/*�덷�̂Q?�����Z*/
			x--;
			x2 -= 2;
		}
		s2d += 2 * (y2 + 1);
		y++;
		y2 += 2;
	}
	/********************************************/
	/* Last Point Draw							*/
	/********************************************/
	y= x;
	if(DrawOn != 0){
		/* 0 Dimension */
		if(CheckDraw01(DrawFlag[0][0],DrawFlag[0][1],x,y) == 0){
			PaintPatarn1LineXY0(y,y,x,y,param->iColor);
			Dot(x+ x0,y+ y0,1);		/*�����Ńh�b�g��*/
		}
		/* 3 Dimension */
		if(CheckDraw23(DrawFlag[3][0],DrawFlag[3][1],-(x),y) == 0){
			PaintPatarn1LineXY3(y,y,-(x),y,param->iColor);
			Dot(-(x)+ x0,y+ y0,1);		/*�����Ńh�b�g��*/
		}
		/* 4 Dimension */
		if(CheckDraw45(DrawFlag[4][0],DrawFlag[4][1],-(x),-(y)) == 0){
			PaintPatarn1LineXY4(-(y),-(y),-(x),-(y),param->iColor);
			Dot(-(x)+ x0,-(y)+ y0,1);		/*�����Ńh�b�g��*/
		}
		/* 7 Dimension */
		if(CheckDraw67(DrawFlag[7][0],DrawFlag[7][1],x,-(y)) == 0){
			PaintPatarn1LineXY7(-(y),-(y),x,-(y),param->iColor);
			Dot(x+ x0,-(y)+ y0,1);		/*�����Ńh�b�g��*/
		}
		/* 1 Dimension */
		if(CheckDraw01(DrawFlag[1][0],DrawFlag[1][1],y,x) == 0){
			PaintPatarn1LineXY1(y,y,y,x,param->iColor);
			Dot(y+ x0,x+ y0,1);		/*�����Ńh�b�g��*/
		}
		/* 2 Dimension */
		if(CheckDraw23(DrawFlag[2][0],DrawFlag[2][1],-(y),x) == 0){
			PaintPatarn1LineXY2(-(y),-(y),-(y),x,param->iColor);
			Dot(-(y)+ x0,x+ y0,1);		/*�����Ńh�b�g��*/
		}
		/* 5 Dimension */
		if(CheckDraw45(DrawFlag[5][0],DrawFlag[5][1],-(y),-(x)) == 0){
			PaintPatarn1LineXY5(-(y),-(y),-(y),-(x),param->iColor);
			Dot(-(y)+ x0,-(x)+ y0,1);		/*�����Ńh�b�g��*/
		}
		/* 6 Dimension */
		if(CheckDraw67(DrawFlag[6][0],DrawFlag[6][1],y,-(x)) == 0){
			PaintPatarn1LineXY6(y,y,y,-(x),param->iColor);
			Dot(y+ x0,-(x)+ y0,1);		/*�����Ńh�b�g��*/
		}
	}
	/* Paint Check */
	if(DrawOn != 0){
		CheckRemain(param->iColor);
	}
	ResetDispSema();
	if(Scale > 0){
        double c= (double)x1 / (double)r;
        double s= (double)y1 / (double)r;
        Sita= atan2((c*y20- s*x20),(c*x20+s*y20));
        if(Sita < 0){
            Sita= 2*3.141592465+ Sita;
        }
	}else{
		Sita= 1;
	}
	if(Sita != 0){
		if(DrawOn != 0){
			param1.iLineStyle= 1;
			param1.iLineColor= param->iScaleColor;
			LineOut(x0, y0, x1 + x0,y1 + y0,&param1);
			LineOut(x0, y0, x20 + x0,y20 + y0,&param1);
		}
	}
	if(Scale > 1){
		SetDispSema();
		if(Sita == 0){
			Sita= 2*3.141592465;
			sCount= Scale- 1;
			Sita= Sita / Scale;
		}else{
			sCount= Scale- 2;
			Sita= Sita / (Scale- 1);
		}
		CosSeta= cos(Sita);
		SinSeta= sin(Sita);
		bx1= x1;
		by1= y1;
		ScalePoin[0].x1= Round(bx1);
		ScalePoin[0].y1= Round(by1);
		bx2= (double)bx1+ (double)(bx1*4/r);
		by2= (double)by1+ (double)(by1*4/r);
		ScalePoin[0].x2= Round(bx2);
		ScalePoin[0].y2= Round(by2);
		for(i = 0; i < sCount; i++){
			Temp= bx1*CosSeta- by1*SinSeta; 
			by1= by1*CosSeta+ bx1*SinSeta;
			bx1= Temp;
			ScalePoin[i+1].x1= Round(bx1);
			ScalePoin[i+1].y1= Round(by1);
			Temp= bx2*CosSeta- by2*SinSeta; 
			by2= by2*CosSeta+ bx2*SinSeta;
			bx2= Temp;
			ScalePoin[i+1].x2= Round(bx2);
			ScalePoin[i+1].y2= Round(by2);
		}
		if(sCount == (Scale- 2)){
			/* �Ō�͂��킹�� */
			ScalePoin[i+1].x1= x20;
			ScalePoin[i+1].y1= y20;
			ScalePoin[i+1].x2= Round((double)x20+ (double)(x20*4/r));
			ScalePoin[i+1].y2= Round((double)y20+ (double)(y20*4/r));
		}
		ResetDispSema();
		if(iSel == 1){
			if(DrawOn != 0){
				param1.iLineStyle= 1;
				param1.iLineColor= param->iScaleColor;
				for(i = 0; i < Scale; i++){
					LineOut(ScalePoin[i].x1+ x0, ScalePoin[i].y1+ y0, 
						ScalePoin[i].x2 + x0,ScalePoin[i].y2 + y0,&param1);
				}
			}
		}
	}
}
void	DrawOrggata(int x0, int y0, int r, int x1, int y1, int x20, int y20,int Scale, int iSel,_ORGGATA_INFO *param)
{
	DrawOrggataProc(x0, y0, r, x1, -y1, x20, -y20, Scale, iSel, param, 1);
}
/* �X�P?���̌v�Z�����s�� */
void	DrawOrggataCalc(int x0, int y0, int r, int x1, int y1, int x20, int y20,int Scale, int iSel,_ORGGATA_INFO *param)
{
	DrawOrggataProc(x0, y0, r, x1, -y1, x20, -y20, Scale, iSel, param, 0);
}

/************************************************/
/*	Window Setting								*/
/************************************************/
void	SetWindowNo(int WinNo)
{
	TaskWindowNo[_RunTaskNo]= WinNo;
	DrawColor = 3;		/* Color Data */
	DrawMode= 0;
	FrontColor= T_WHITE;
	BackColor= T_BLACK;
}
void	SetWindowInfo(int WinNo,int Info)
{
	WindowInfo[WinNo]= Info;
}
void	SetStartPos(int no, int x, int y)
{
	int		xx,yy;

	if(TateYoko == 0){
		xx= x;
		yy= y;
	}else{
		xx= y;
/* 080926		yy= ((GAMEN_Y_SIZE-1)- x)- (wHight[no]- 1); */
		yy= GAMEN_Y_SIZE- x- wHight[no]- 1;
		if(yy < 0){
			yy= 0;
		}
	}
	if(xx >= GAMEN_X_SIZE){
		xx= GAMEN_X_SIZE-1;
	}
	if(yy >= GAMEN_Y_SIZE){
		yy= GAMEN_Y_SIZE-1;
	}
	wDspX[no]= xx;
	wDspY[no]= yy;
}
void	OpenWindow(int no, int width, int hight)
{
	int	ww,hh;

	if(TateYoko == 0){
		ww= width;
		hh= hight;
	}else{
		ww= hight;
		hh= width;
	}
	if(ww >= GAMEN_X_SIZE){
		ww= GAMEN_X_SIZE;
	}
	if(hh >= GAMEN_Y_SIZE){
		hh= GAMEN_Y_SIZE;
	}
	wWidth[no]= ww;
	wHight[no]= hh;
}
void	CloseWindow(int no)
{
	wWidth[no]= -1;
	wHight[no]= -1;
	if(no == 3)
		Set.iMessageFlag = 0;
}
void	DrawEnd( void )
{
//	int	WinNo;

//	WinNo= TaskWindowNo[_RunTaskNo];
}
void	ObjectStart(void)
{
//	int	WinNo;

//	WinNo= TaskWindowNo[_RunTaskNo];
}
/********************************************/
/*	Message Task							*/
/********************************************/
int		MsgXbai,MsgYbai;
int		MsgWidth;
int		MsgHeight;
int		MessageCnt;
int		NowMessageIdx;
int		NowMessageFlag;
int		NowMessageXCnt;
int		MessageCloseFlag;
/*ksc20040727_owashi*/
int		MessageOpenFlag;		/* 040726 */
/*ksc20040727_owashi*/
int		MessageNo;
int		NowOnDevCnt;
int		FloatingMessOn;
int		FloatOpenFlag;
#define	ONDEV_FLOAT_CNT	256		/* 2008.05. 23 */
unsigned char	NowOnDevNo[ONDEV_FLOAT_CNT];
unsigned char	NowMessageData[512+1];
unsigned char	Now1LineMessage[42];
/************************************/
/*	�P�s�̃f??�����				*/
/************************************/
int	MakeFloat1Line(int idx)
{
	int		i,j;

	/* Start Char Set */
	for(i= 0,j= 0; i < 512; i++){
		if(NowMessageData[i] == 0){
			break;
		}
		if(i == idx){
			break;
		}
		if(i > idx){
			Now1LineMessage[j++]= ' ';
			break;
		}
		if(NowMessageData[i] >= 0x80){
			i++;
		}
	}
	for(;i < 512; i++){
		if(NowMessageData[i] == 0){
			break;
		}
		if(NowMessageData[i] >= 0x80){
			if(j < MAX_FLOAT_CNT){
				Now1LineMessage[j++]= NowMessageData[i++];
				Now1LineMessage[j++]= NowMessageData[i];
			}else{
				break;
			}
		}else{
			if(j < MAX_FLOAT_CNT+ 1){
				Now1LineMessage[j++]= NowMessageData[i];
			}
		}
	}
	Now1LineMessage[j++]= 0;
	return(j);
}
extern	void	WindowDisplay_Task_Send(int mode, int p1, int p2, int p3, int p4);
/************************************/
/*	floating?alarm����				*/
/*  Message Window�̏���			*/
/************************************/
void	FloatState( STTFrm* pSTT )
{
	int		i,Cnt;
	int		iColor;
	int		x;
	int		idx;
	T_MAIL *mp;
	int		ChrCnt;

	ClearDispBuff(MSG_WINDOW);
	mp = (T_MAIL *)WaitRequest();
	ResponseMail((char *)mp);
	while(1){
		if(CommonArea.PcUpDownMode == 0){
			if(	MessageCloseFlag != 0){
				MessageCloseFlag= 0;
				MessageCnt= 0;
				NowMessageIdx= 0;
				NowMessageXCnt= 0;
				NowMessageFlag= 0;
				if(MsgHeight > 0){
					SetWinSema();
					AreaClear(0,0,MsgWidth- 1,MsgHeight- 1,0);
					if(FloatingMessOn != 0){
						DrawLcdBank1();
						FloatingMessOn= 0;
					}
					ResetWinSema();
				}
			}
	/*ksc20040727_owashi*/
			/* Open Proc 040726 */
			if(MessageOpenFlag != 0){
				MessageOpenFlag= 0;
				if(NowOnDevCnt != 0){
					memset(NowMessageData,0,sizeof(NowMessageData));
					Cnt= 512;
					vCommentDataSet(CommonArea.SystemDev.CommentStartNo+ NowOnDevNo[0],(char *)NowMessageData,&iColor,(int *)&Cnt);
					NowMessageIdx= 0;
					MessageCnt= 1;
				}
			}		
	/*ksc20040727_owashi*/		
			if((MessageCnt != 0) &&(FloatOpenFlag == 1)){		/* Message ON */
				if(NowMessageFlag == 0){
					NowMessageXCnt= 0;
					NowMessageFlag= 1;
				}
				if(TateYoko == 0){
					switch(MsgXbai){
					case 1:		ChrCnt= GAMEN_X_SIZE/8;		break;
					case 2:		ChrCnt= GAMEN_X_SIZE/16;	break;
					case 3:		ChrCnt= GAMEN_X_SIZE/24;	break;
//					case 4:		ChrCnt= GAMEN_X_SIZE/34;	break;		//2011.09.08 Del
					case 4:		ChrCnt= GAMEN_X_SIZE/32;	break;		//2011.09.08 Add
					default:	ChrCnt= GAMEN_X_SIZE/8;		break;
					}
				}else{
					switch(MsgXbai){
					case 1:		ChrCnt= GAMEN_Y_SIZE/8;		break;
					case 2:		ChrCnt= GAMEN_Y_SIZE/16;	break;
					case 3:		ChrCnt= GAMEN_Y_SIZE/24;	break;
//					case 4:		ChrCnt= GAMEN_Y_SIZE/34;	break;		//2011.09.08 Del
					case 4:		ChrCnt= GAMEN_Y_SIZE/32;	break;		//2011.09.08 Add
					default:	ChrCnt= GAMEN_Y_SIZE/8;		break;
					}
				}
				if(NowMessageXCnt > (ChrCnt- 1)){
					x= 0;
					idx= NowMessageXCnt- (ChrCnt- 1);
				}else{
					x= ((ChrCnt- 1)- NowMessageXCnt)* 8* MsgXbai;
					idx= 0;
				}
				SetWinSema();
				if(NowMessageData[idx] != 0){
					AreaClear(0,0,MsgWidth- 1,MsgHeight- 1,0);
					MakeFloat1Line(idx);
					DotTextOut(x,0,(char *)Now1LineMessage,
						MsgXbai,MsgYbai,T_REPLACE,0,0);
					if(NowMessageData[idx] >= 0x80){	/* ���� */
	/*					NowMessageXCnt++;*/
					}
					NowMessageXCnt++;
					if(NowMessageXCnt > (ChrCnt- 1)){
						x= 0;
						idx= NowMessageXCnt- (ChrCnt- 1);
					}else{
						x= ((ChrCnt- 1)- NowMessageXCnt)* 8* MsgXbai;
						idx= 0;
					}
				}
				if(NowMessageData[idx] == 0){
					NowMessageXCnt= 0;
					i= NowMessageIdx+ 1;
					if(i >= NowOnDevCnt){
						i= 0;
					}
					Cnt= 0;
					if(NowOnDevCnt != 0){
						memset(NowMessageData,0,sizeof(NowMessageData));
						Cnt= 512;
						vCommentDataSet(CommonArea.SystemDev.CommentStartNo+ NowOnDevNo[i],(char *)NowMessageData,&iColor,(int *)&Cnt);
						NowMessageIdx= i;
					}
					if(Cnt == 0){		/* Message OFF */
						MessageCloseFlag= 1;
						MessageCnt= 0;
						NowMessageFlag= 0;
					}
				}
				ResetWinSema();		/* 2008.05.23 */
/* V202				DrawLcdBank1();*/
				WindowDisplay_Task_Send(FLOAT_DATA,0,0,0,0);
//				ResetWinSema();
			}
			switch(MsgXbai){
			case 1:
				Delay(300);
				break;
			case 2:
				Delay(450);
				break;
			case 3:					//2011.09.08 Add
				Delay(450);			//2011.09.08 Add
				break;				//2011.09.08 Add
			case 4:
				Delay(600);
				break;
			default:
				Delay(150);
				break;
			}
		}else{
			Delay(500);
		}
	}
}
void	MsgTask( STTFrm* pSTT )
{
	T_MAIL *mp;
	int		i;
	int		iColor;
	int		Cnt;

	Delay(500);
	MessageCnt= 0;
	NowMessageXCnt= 0;
	MessageCloseFlag= 0;
/*ksc20040727_owashi*/	
	MessageOpenFlag= 0;/* 040726 */	
/*ksc20040727_owashi*/	
	NowMessageFlag= 0;
	NowOnDevCnt= 0;
	mp= (T_MAIL *)TakeMail();
	SendMail(T_FLTKANSI,(char *)mp);
	SetWindowNo(MSG_WINDOW);		/* 050620 */
/*	ClearDispBuff(MSG_WINDOW);*/
	SetWindowInfo(MSG_WINDOW,1);
	FloatingMessOn= 0;
	FloatOpenFlag= 0;
	while(1)
	{
		mp = (T_MAIL *)WaitRequest();
		mp->minf= 0;
		switch(mp->mcmd){
		case 0:			/* Close */
			CloseWindow(MSG_WINDOW);			/* Message Window */
			MessageCloseFlag= 1;
			if(MsgHeight > 0){
				AreaClear(0,0,MsgWidth- 1,MsgHeight- 1,0);
			}
			FloatOpenFlag= 0;
			break;
		case 1:			/* Message Open */
			MsgXbai= mp->mcod;
			MsgYbai= mp->mpec;
			switch(mp->mpec){		/* Y����?�� */
			case 1:
				MsgHeight= 16;
				break;
			case 2:
				MsgHeight= 32;
				break;
			case 3:
				MsgHeight= 48;
				break;
			case 4:
				MsgHeight= 64;
				break;
			default:
				MsgHeight= 16;
				break;
			}
			if(TateYoko == 0){
				MsgWidth= GAMEN_X_SIZE;
				OpenWindow(MSG_WINDOW, MsgWidth, MsgHeight);
				SetStartPos(MSG_WINDOW,0,GAMEN_Y_SIZE- MsgHeight);
			}else{
				MsgWidth= GAMEN_Y_SIZE;
				OpenWindow(MSG_WINDOW, MsgWidth, MsgHeight);
				SetStartPos(MSG_WINDOW,0,GAMEN_X_SIZE- MsgHeight);
			}
			if(NowOnDevCnt != 0){
				if((CommonArea.SystemDev.fAlarm_Dev.DevCnt == 0) ||
					(CommonArea.SystemDev.fAlarm_Dev.DevName[0] == 0)){	/* Floating �Ȃ� 060202 */
					NowOnDevCnt= 0;
				}else{
					memset(NowMessageData,0,sizeof(NowMessageData));
					Cnt= 512;
					vCommentDataSet(CommonArea.SystemDev.CommentStartNo+ NowOnDevNo[0],(char *)NowMessageData,&iColor,(int *)&Cnt);
					NowMessageIdx= 0;
					MessageCnt= 1;
				}
			}
/*ksc20040727_owashi*/
			MessageOpenFlag= 1;/* 040726 */
/*ksc20040727_owashi*/			
			FloatOpenFlag= 1;
			break;
		case 2:			/* Message Entry */
			for(i= 0; i < NowOnDevCnt; i++){
				if(NowOnDevNo[i] == mp->mcod){
					break;
				}
			}
//			if(i >= NowOnDevCnt){
			/* Max Check Add 2008.05.23 */
			if((i >= NowOnDevCnt) && (NowOnDevCnt < ONDEV_FLOAT_CNT)){
				if(FloatOpenFlag == 1){
/* 20080822 �÷��� �˶� ��ġ�� ������ ������ ǥ������ �ʴ� �ܿ찡 �߻��ؼ� ���� */
					while(1){		// Close ���ɐݒ肪���邽�� 20080814
						if(MessageCloseFlag == 0){
							break;
						}
						Delay(20);
					}
					memset(NowMessageData,0,sizeof(NowMessageData));
					memcpy((char *)&NowMessageData, mp->mbuf, mp->mext);
					NowMessageIdx= 0;
					MessageCnt= 1;
					NowMessageXCnt= 0;
				}
				/* Message Table Entry */
				for(i= NowOnDevCnt; i > 0; i--){
					NowOnDevNo[i]= NowOnDevNo[i-1];
				}
				NowOnDevNo[0]= (unsigned char)mp->mcod;
				NowOnDevCnt++;
			}
			break;
		case 3:			/* Message Del */
			if(NowOnDevNo[NowMessageIdx] == mp->mcod){
				Cnt= 0;
				i= NowMessageIdx+ 1;
				if(i >= NowOnDevCnt){
					i= 0;
				}
				if(NowOnDevCnt > 1){
					if(i >= NowOnDevCnt){
						i= 0;
					}
					if(NowOnDevCnt != 0){
						memset(NowMessageData,0,sizeof(NowMessageData));
						Cnt= 512;
						vCommentDataSet(CommonArea.SystemDev.CommentStartNo+ NowOnDevNo[i],(char *)NowMessageData,&iColor,(int *)&Cnt);
						if(i != 0){
							NowMessageIdx= i- 1;
						}else{
							NowMessageIdx= i;
						}
					}
				}
				if(Cnt == 0){		/* Message OFF */
					MessageCloseFlag= 1;
					MessageCnt= 0;
					NowMessageFlag= 0;
					FloatingMessOn= 1;
				}
			}
			/* Message Table Delete */
			for(i= 0; i < NowOnDevCnt; i++){
				if(NowOnDevNo[i] == mp->mcod){
					break;
				}
			}
			if(i < NowOnDevCnt){
				for(; i < NowOnDevCnt; i++){
					NowOnDevNo[i]= NowOnDevNo[i+1];
				}
				NowOnDevCnt--;
			}
			break;
		}
		ResponseMail((char *)mp);
	}
}
/************************************************/
/*	64Bit Caluc									*/
/************************************************/
char	culBuff[32+2];
char	culBuff1[32+2];
char	culBuff2[32+2];
char	*Culc64U(int mode,unsigned int para1,unsigned int para2)
{
	int		i,idx1,idx2,j,k;
	int		work,work2;
	char	*ret;

	memset(culBuff,0,sizeof(culBuff));
	memset(culBuff1,0,sizeof(culBuff1));
	memset(culBuff2,0,sizeof(culBuff2));
	for(i= 0,idx1= 31,idx2= 31; ; i++){
		if((para1 == 0) && (para2 == 0)){
			break;
		}
		if(para1 != 0){
			culBuff1[idx1--]= para1 % 10;
			para1 /= 10;
		}
		if(para2 != 0){
			culBuff2[idx2--]= para2 % 10;
			para2 /= 10;
		}
	}
	switch(mode){
	case 0:		/* Mult */
		for(j= 31; j > idx2; j--){
			work2= 0;
			for(k= 31,i= j; k > idx1; k--){
				work= culBuff2[j]* culBuff1[k]+ work2;
				culBuff[i--]+= work % 10;
				work2= work / 10;
			}
			culBuff[i]= work2;
		}
		break;
	case 1:				/* Add */
		j= idx1;
		if(idx1 > idx2){
			j= idx2;
		}
		work2= 0;
		for(i= 31; i > j; i--){
			work= culBuff2[i]+ culBuff1[i]+ work2;
			culBuff[i]+= work % 10;
			work2= work / 10;
		}
		culBuff[i]= work2;
		break;
	case 2:				/* Minus */
		j= idx1;
		if(idx1 > idx2){
			j= idx2;
		}
		work2= 0;
		for(i= 31; i > j; i--){
			if(culBuff1[i] < (culBuff2[i]+ work2)){
				culBuff[i]= (culBuff1[i]+10)- (culBuff2[i]+ work2);
				work2= 1;
			}else{
				culBuff[i]= culBuff1[i]- (culBuff2[i]+ work2);
				work2= 0;
			}
		}
		break;
	}
	for(i = 0; i < 32; i++){
		if(culBuff[i] != 0){
			break;
		}
	}
	ret= &culBuff[i];
	for(; i < 32; i++){
		culBuff[i] |= 0x30;
	}
	return(ret);
}
char	*Culc64S(int mode,int para1,int para2)
{
	int		flag;
	unsigned int p1,p2;
	char	*pos;

	flag= 0;
	p1= para1;
	if(para1 < 0){
		p1 = (unsigned int)(para1*(-1));
		flag++;
	}
	p2= para2;
	if(para2 < 0){
		p2 = (unsigned int)(para2*(-1));
		flag++;
	}
	if(mode == 0){	/* Mult */
		pos= Culc64U(mode,p1,p2);
		if(flag == 1){		/* Minus */
			pos--;
			*pos= '-';
		}
	}else{			/* Add */
		switch(flag){
		case 0:		/* +,+ */
			pos= Culc64U(1,p1,p2);
			break;
		case 1:		/* +,- */
			if(p1 > p2){
				pos= Culc64U(2,p1,p2);
				if(para1 < 0){
					pos--;
					*pos= '-';
				}
			}else{
				pos= Culc64U(2,p2,p1);
				if(para2 < 0){
					pos--;
					*pos= '-';
				}
			}
			break;
		case 2:		/* -,- */
			pos= Culc64U(1,p1,p2);
			pos--;
			*pos= '-';
			break;
		}
	}
	return(pos);
}
int	int32Check(char *buff)
{
	int		ret;
	int		len;
	char	*pos;

	pos= buff;
	len = strlen(buff);
	if((buff[0] == '-') || (buff[0] == '+')){
		pos++;
		len--;
	}
	if(len < 10){ 
		ret= OK;
	}else if(len > 10){
		ret= NG;
	}else{
		if(buff[0] == '-'){
			ret= strcmp("2147483648",buff);
		}else{
			ret= strcmp("2147483647",buff);
		}
		if(ret == 1){
			ret= OK;
		}
	}
	return(ret);
}
int	uint32Check(char *buff)
{
	int		ret;
	int		len;
//	char	*pos;

//	pos= buff;
	len = strlen(buff);
	if(len < 10){ 
		ret= OK;
	}else if(len > 10){
		ret= NG;
	}else{
		ret= strcmp("4294967295",buff);
		if(ret == 1){
			ret= OK;
		}
	}
	return(ret);
}
int	Culc_X,Culc_Y;
void	CulcXInc(void)
{
	Culc_X++;
}
void	CulcXDec(void)
{
	Culc_X--;
}
void	CulcYInc(void)
{
	Culc_Y++;
}
void	CulcYDec(void)
{
	Culc_Y--;
}
void    CulcPoint( int DMst, int DSlave, void (*pMainMoveFnc)(void), void (*pSlaveMoveFnc)(void ),char *buff )
{
    int     i;
    int     Dlt;
    int     DMst2;
    int     DSlave2;

    Dlt= 0;
    DSlave2= DSlave + DSlave;
    DMst2= DMst + DMst;
    for( i= 0; i < DMst; i++ ) {
		buff[i*2]= Culc_X;
		buff[i*2+1]= Culc_Y;
        Dlt -= DSlave2;
        if ( Dlt + DMst < 0 ) {
            (*pSlaveMoveFnc)();
            Dlt += DMst2;
        }
        (*pMainMoveFnc)();
    }
	buff[i*2]= Culc_X;
	buff[i*2+1]= Culc_Y;
}
void	CalcAddrLine(int sx,int sy,int ex,int ey,char *buff)
{
    int     Dx;
    int     Dy;
    int     DMst;
    int     DSlave;
    void    (*pXMoveFnc)(void);
    void    (*pYMoveFnc)(void);
    void    (*pMainMoveFnc)(void);
    void    (*pSlaveMoveFnc)(void);

	Culc_X= sx;
	Culc_Y= sy;

    Dx= ex- sx;
    Dy= ey- sy;
    pXMoveFnc= CulcXInc;
    pYMoveFnc= CulcYInc;
    if( Dx < 0 ){	Dx= -Dx;	pXMoveFnc= CulcXDec;	}
    if( Dy < 0 ){	Dy= -Dy;	pYMoveFnc= CulcYDec;	}
    if( Dx >= Dy ){
        pMainMoveFnc = pXMoveFnc;
        pSlaveMoveFnc= pYMoveFnc;
        DMst= Dx;
        DSlave= Dy;
    }
    else{
        pMainMoveFnc = pYMoveFnc;
        pSlaveMoveFnc= pXMoveFnc;
        DMst= Dy;
        DSlave= Dx;
    }
    CulcPoint( DMst, DSlave, pMainMoveFnc, pSlaveMoveFnc,buff );
}
/***************************END******************/
