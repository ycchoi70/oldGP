void		MemorySizeDisp(int* iScreenNo);
void		vUwLatchSetDisp(int* iScreenNo);		/* 20091222 */


