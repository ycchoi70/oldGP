/*****************************************/
/*	PLC Common Buffer Area               */
/*****************************************/
#define	RS_TIMEOUT	-1
#define	RS_SUM_ERR	-2

#ifdef	DEFULT_PLC
	/* Device �Ď��̈� */
	int			gDeviceCnt;
	int			gDeviceCntBit;
	int			gDeviceCntWord;
	int			DeviceCnt;
	DEV_DATA	DeviceDataHed[MAX_DEV_CNT];  /* Apli */
	char		DeviceData[MAX_DEV_CNT*4];
	char		SaveDeviceData[MAX_DEV_CNT*4];
	char		DispDeviceData[MAX_DEV_CNT*4];
	int			DeviceCntSys;
	DEV_DATA	DeviceDataSys[MAX_DEV_CNT];  /* System  */
	char		gDeviceFlag[128];  /* [32] */
	char		*gDeviceAddr[128]; /* [32] */

	int		CodeCnt;
	int		SndCodeCnt;

#else
	/* Device �Ď��̈� */
	extern	int			gDeviceCnt;
	extern	int			gDeviceCntBit;
	extern	int			gDeviceCntWord;
	extern	char		gDeviceFlag[80];  /* [32] */
	extern	char		*gDeviceAddr[80]; /* [32] */
	extern	int			DeviceCnt;
	extern	DEV_DATA	DeviceDataHed[MAX_DEV_CNT];  /* Apli */
	extern	char		DeviceData[MAX_DEV_CNT*4];
	extern	char		SaveDeviceData[MAX_DEV_CNT*4];
	extern	char		DispDeviceData[MAX_DEV_CNT*4];
	extern	int			DeviceCntSys;
	extern	DEV_DATA	DeviceDataSys[MAX_DEV_CNT];  /* System  */

	extern	int		CodeCnt;
	extern	int		SndCodeCnt;

#endif
