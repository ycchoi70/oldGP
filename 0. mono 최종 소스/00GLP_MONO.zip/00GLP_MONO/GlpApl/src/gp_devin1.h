int		vDevInput1(char *chKey, int iSize);
int		iDevInput1Select(short* iNum);
int		iDevInputKey2Select(short* iNum);

