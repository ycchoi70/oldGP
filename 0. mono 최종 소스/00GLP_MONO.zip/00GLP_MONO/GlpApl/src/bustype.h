/*** Flash device Bus wiring definitions for RVD ***
  /  
 / /
/ / /\
\\\/ /// CLABSYS
 \\ ///  Cyber Lab System
  \\//
   \/

Revision history___
2004-12-09 John
*/

#ifndef __BUSTYPE_H__
#define __BUSTYPE_H__//    ________ Double bit
//                        /  
#define BUS8       (0x0|0x0<<4)
#define BUS88      (0x1|0x1<<4)
#define BUS16      (0x1|0x0<<4)
#define BUS1616    (0x2|0x1<<4)
#define BUS32      (0x2|0x0<<4)
//                    \____________Bus Width
//
#endif 	//#ifndef __BUSTYPE_H__
