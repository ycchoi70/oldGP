void	SetPanel_Func(int iDispOrder);
int	DrawPanel_Func(int mode,_PANEL_METER_EVENT_TBL* PanelMeterEventTbl,int iDispOrder);
void	PanelMeterDispWatch(int iOrder);
