/************************************************/
/*	PLC ����M �v���O����(Sumson N70Plus)		*/
/*	2003.5.31									*/
/************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

/*#define	PLC_TYPE2	1*/
#define	MAX_RTY_COUNT	3
#define	MAX_WORDCNT		5
#define	MAX_WR_WORDCNT	20

#ifndef	WIN32
#pragma	section PlcProc2
#endif

#define	MAX_PLC_STATION	32
#define	MAX_PLC_ERR		10

/**************************************/
extern	int	Hex2nBin(char *buff,int cnt);
extern	int	Hex2Bin(char *buff);
extern	unsigned int LHexAsToBin(char *buff, int cnt);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	int	GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address);
extern	void	RtsOnOffSet(int type,int mode);
#ifdef	WIN32
extern int __cdecl Delay(int);
extern unsigned int __cdecl ReadSignal(int);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	PlcDevInit( void );
extern	unsigned char			GpFont[0x200000];
#else
#define SGN_PLC		0
#endif
extern	int	SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode);

/****************************************************************/
/*	Station Connect Area										*/
/****************************************************************/
int		Plc2_DeviceFlag;						/* Device Check Flag */
int		Plc2_BitRecCnt;
int		Plc2_BitAndData;
char	StationInf[MAX_PLC_STATION];
/****************************** for Window **********************/
/********************************************/
/*	�O���֐�								*/
/********************************************/
#ifdef	PLC_TYPE2
#ifdef	WIN32
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
#endif
#else
extern	int	B_Hex2nBin(char *buff,int cnt);
extern	int	B_Hex2Bin(char *buff);
extern	unsigned int B_LHexAsToBin(char *buff, int cnt);
extern	int	B_Delay(int p);
extern	int	B_ReadSignal(int p);
extern	void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
#endif
#ifdef	WIN32
int	B_SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode)
{
	return(SendRecPLC2(mode,rData,Cnt,rmode));
}
#endif

/********************************************/
/* PLC-Program Title */
#ifdef	WIN32
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#endif
/********************************/
/*	FX Serease					*/
/********************************/
char	*PLC2_CommTbl[16]={
		"RCS",		/* X,Y,R,L,T,C */
		"WCS",		/* X,Y,R,L,T,C */
		"RCP",		/* X,Y,R,L,T,C */
		"WCP",		/* X,Y,R,L,T,C */
		"RCC",		/* X,Y,R,L,T,C */
		"WCC",		/* Y,R,L */
		"RD",		/* DT,FL,Ld,I */
		"WD",		/* DT,FL,Ld,I */
		"RS",		/* S(TC) */
		"WS",		/* S(TC) */
		"RK",		/* K(TC) */
		"WK",		/* K(TC) */
};

const	DEV_TBL PLC2bPLCDeviceTbl[16] = {
	{"X" ,0x0000,1},
	{"Y" ,0x0000,1},
	{"R" ,0x0000,1},
	{"L" ,0x0000,1},
	{"T" ,0x0000,2},
	{"C" ,0x0000,2},
	{"GB" ,    0,9},
};
const	DEV_TBL	PLC2wPLCDeviceTbl[16] = {
	{"WX",0x0000,1},		/* X */
	{"WY",0x0000,1},		/* Y */
	{"WR",0x0000,1},		/* R */
	{"WL",0x0000,1},		/* L */
	{"SV",0x0000,2},		/* S */
	{"EV",0x0000,3},		/* K */
	{"FL",0x0000,4},		/* F */
	{"LD",0x0000,5},		/* L */
	{"DT",0x0000,6},		/* D */
	{"D", 0x0000,6},		/* D For PLC2 MONITOR */
	{"IX",0x0000,7},		/* IX */
	{"IY",0x0000,7},		/* IY */
	{"ID",0x0000,7},		/* ID */
	{"GD",     0,9},
};
/************************************/
/* ��M�v���g�R��					*/
/************************************/
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(*CommMode){
	case 0:				/*  */
		if(data == 0x25){		/* % */
			*RecCnt= 0;			/* �`���X�^�[�g */
			RecBuff[(*RecCnt)++] = data;
			*CommMode = 1;
		}
		break;
	case 1:				/* Data Recieve */
		if(*RecCnt < 1024){
			RecBuff[(*RecCnt)++] = data;
		}
		if(data == 0x0d){		/* CR */
			*CommMode = 0;
			ret= 0;
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/

/************************************/
/* ���ʏ���							*/
/************************************/
#ifdef	PLC_TYPE2
int	Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
void	Bin2Hex(int data,int cnt,char *buff)
{
	int		i;
	unsigned int AndData;

	AndData= 0x000f;
	for(i= 1; i < cnt; i++){
		AndData= AndData << 4;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= Bin2Hex1((data & AndData) >> ((cnt- i- 1)*4));
		AndData = AndData >> 4;
	}
	buff[i]= 0;
}
void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= '0'+ ((data / AndData) % 10);
		data= data % AndData;
		AndData = AndData / 10;
	}
	buff[i]= 0;
}
int	gstrlen(char *buff)
{
	int		i;

	for(i= 0; ; i++){
		if(buff[i] == 0){
			break;
		}
	}
	return(i);
}
void	gmemset(char *buff,int data,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*buff= (char)data;
		buff++;
	}
}
void	gmemcpy(char *obj,char *src,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*obj= *src;
		src++;
		obj++;
	}
}
void	gstrcpy(char *obj,char *src)
{
	int		i;

	for(i= 0; ; i++){
		*obj= *src;
		if(*src == 0){
			break;
		}
		src++;
		obj++;
	}
	*obj= 0;
}
int	gstrcmp(char *src,char *obj)
{
	int		i;
	int		ret;

	ret= NG;
	for(i= 0; ; i++){
		if(src[i] == 0){
			if(obj[i] == 0){
				ret= OK;
			}
			break;
		}
		if(obj[i] == 0){
			break;
		}
		if(src[i] != obj[i]){
			break;
		}
	}
	return(ret);
}
int	gstrncmp(char *src,char *obj,int cnt)
{
	int		i;
	int		ret;

	ret= OK;
	for(i= 0; i < cnt; i++){
		if(src[i] != obj[i]){
			ret= NG;
			break;
		}
	}
	return(ret);
}
void	gstrcat(char *src,char *obj)
{
	int		i;

	for(i= 0; ; i++){
		if(*src == 0){
			break;
		}
		src++;
	}
	for(i= 0; ; i++){
		if(*obj == 0){
			*src= 0;
			break;
		}
		*src= *obj;
		src++;
		obj++;
	}
}
unsigned int	Bin2Bcd(int data)
{
	int		i;
	unsigned int	ret;

	ret= 0;
	for(i= 0; i < 8; i++){
		ret |= (data % 10) << (i*4);
		data = data / 10;
		if(data == 0){
			break;
		}
	}
	return(ret);
}
unsigned int	BcdAddBcd(unsigned int data1,unsigned int data2)
{
	int		i;
	int				flag;
	unsigned int	ret;
	unsigned int	work;

	ret= 0;
	flag= 0;
	for(i= 0; i < 8; i++){
		work= (data1 & 0x0f) + (data2 & 0x0f) + flag;
		flag= work / 10;
		ret |= (work % 10) << (i * 4);
		data1 = data1 >> 4;
		data2 = data2 >> 4;
		if((data1 == 0) && (data2 == 0)){
			break;
		}
	}
	return(ret);
}
unsigned int	Bcd2Asc(int data,int keta,char *buff)
{
	int		i;
	unsigned int	ret;

	ret= 0;
	for(i= 0; i < keta; i++){
		buff[keta- i- 1]= (data & 0x0f) + '0';
		data = data >> 4;
	}
	buff[keta]= 0;
	return(ret);
}
#else
extern	int	Bin2Hex1(int data);
extern	void	Bin2Hex(int data,int cnt,char *buff);
extern	void	Bin2dec(int data,int cnt,char *buff);
extern	int	gstrlen(char *buff);
extern	void	gmemset(char *buff,int data,int cnt);
extern	void	gmemcpy(char *obj,char *src,int cnt);
extern	void	gstrcpy(char *obj,char *src);
extern	int	gstrcmp(char *src,char *obj);
extern	int	gstrncmp(char *src,char *obj,int cnt);
extern	void	gstrcat(char *src,char *obj);
extern	unsigned int	Bin2Bcd(int data);
extern	unsigned int	BcdAddBcd(unsigned int data1,unsigned int data2);
extern	unsigned int	Bcd2Asc(int data,int keta,char *buff);
#endif
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
int PLC2_SetPLCBCC(char *buff,int cnt,unsigned char *OutBuf)
{
	int		i;
	unsigned int sum;
	char	work[2];

	sum= 0;
	for(i = 0; i < cnt; i++){
		OutBuf[i] = buff[i];
		sum = sum ^ buff[i];
	}
	Bin2Hex(sum,2,work);
	OutBuf[cnt] = work[0];
	OutBuf[cnt+1] = work[1];
	OutBuf[cnt+2] = 0x0d;
	return(cnt + 3);
}
/************************************/
/*	PLC Send						*/
/************************************/
int	PLC2_SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	int		i;
	unsigned int  sum;
	unsigned int  sum1;
	int		rty_cnt;


	PcThruByteCnt= PLC2_SetPLCBCC((char *)combuf,*Cnt,PcThruRecDataWork);
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
		ret= B_SendRecPLC2(mode,rData,Cnt,rmode);
		if(ret == 0){
			sum = 0;
			for(i = 0; i < *Cnt-3; i++){
				sum= sum ^ rData[i];
			}
			sum1= B_Hex2Bin((char *)&rData[i]);
			if(sum != sum1){
				ret= -1;
			}
		}else{
			break;
		}
		if(ret == OK){
			break;
		}
	}
	return(ret);
}
/********************************************/
/*	Connection Proc							*/
/*	*PlcType:[0]->PlcType					*/
/*	         [1]->MyStation					*/
/*	         [2]->DstStation				*/
/********************************************/
int	Connection2( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;

	/* �������̃{�[���[�g */
	if((iConnect & 1) == 0){		/* RS-232C */
#ifdef	WIN32
		SioPCMode= 2;
		SioPCOpenFlag= 1;
#else
		B_RsModeSet(RS_PLC,RS_INIT,RS_19200,RS_DATA8,RS_ODD);
#endif
	}else{						/* RS-422 */
#ifdef	WIN32
		SioPLCMode= 2;
		SioPLCOpenFlag= 1;
#else
		B_RsModeSet(RS_PC,RS_INIT,RS_19200,RS_DATA8,RS_ODD);
#endif
	}
#ifdef	WIN32
	while(1){
		if(SioPLCOpenFlag == 0){
			break;
		}
		B_Delay(10);
	}
#endif
	B_Delay(500);

	/* PLC Connect Check */
	MyStationNo= PlcType[1];
	DstStationNo= PlcType[2];
	gmemset((char *)PcThruRecDataWork, 0, sizeof(PcThruRecDataWork));
	PcThruRecDataWork[0]= '%';			/*  */
	PcThruRecDataWork[1]= 'E';			/* S-H */
	PcThruRecDataWork[2]= 'E';			/* S-L */
	PcThruRecDataWork[3]= '#';			/* Command */
	PcThruRecDataWork[4]= 'R';			/* Command */
	PcThruRecDataWork[5]= 'T';			/* Command */

	Cnt= gstrlen((char *)PcThruRecDataWork);
	ret= PLC2_SendRecPLCWithBCC(2,(char *)PcThruRecDataWork,PcThruRecDataWork,&Cnt,0);
	if((ret == 0) && (PcThruRecDataWork[3] == 0x24)){	/* $ */
		ret= 1;
	}else{
		ret= 1;
	}
/*	Station Inf Clear */
	gmemset(StationInf,0,sizeof(StationInf));
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
int	PLC2MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt,char *Device)
{
	int		i;
	int		ret;
	int		OffSet;

	ret = -1;
	if(mode == 0){			/* Bit Device */
		if(pDevice[0] == 'G'){		/* IN DEVICE */
		}else{
			Plc2_DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(PLC2bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(gstrcmp(PLC2bPLCDeviceTbl[i].Device,pDevice) == 0){
					Plc2_DeviceFlag= PLC2bPLCDeviceTbl[i].flag;
					OffSet= PLC2bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(Plc2_DeviceFlag > 0){
				*DevAddr = OffSet+ Address;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(pDevice[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			Plc2_DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(PLC2wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(gstrcmp(PLC2wPLCDeviceTbl[i].Device,pDevice) == 0){
					Plc2_DeviceFlag= PLC2wPLCDeviceTbl[i].flag;
					OffSet= PLC2wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(Plc2_DeviceFlag > 0){
				*DevAddr = OffSet+ Address;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
void	PLC2_ChangeAddressUsr(int Digit1,int Digit0, int *Address,int LowMax,int Keta)
{
	int		i;
	unsigned int	work;
	unsigned int	work1;
	unsigned int	work2;

	work= (unsigned int)*Address;
	work1= work%LowMax;				/* 1Keta */
	work2= 0;
	for(i = 0;i < Keta; i++){
		work2 += (work1 % Digit0) << (i*4);
		work1= work1/Digit0;
	}
	work= work/LowMax;
	for(;i < 8; i++){
		if(work == 0){
			break;
		}
		work2 += (work % Digit1) << (i*4);
		work= work/Digit1;
	}
	*Address= work2;
}
/****************************/
/* Make Read Device			*/
/****************************/
int	PLC2MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int		DevAddr;
	int		work;
	char	Device[4];
	char	buff[8];

	Device[0]= pDevice[0];
	ret= PLC2MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt,Device);
	if(ret == 0){
		DstStationNo= pDevice[4];
		combuff[0]= '%';		/* Start */
		combuff[1]= 'E';		/* SA */
		combuff[2]= 'E';		/* SA */
		combuff[3]= '#';		/* Command */
		combuff[4]= 0;
		if(mode == 0){			/* Bit */
			if(sCnt == 1){
				gstrcat(combuff,PLC2_CommTbl[0]);	/* RCS */
				gstrcat(combuff,Device);		/* Device Name */
				Bin2dec(Address/16,3,buff);
				gstrcat(combuff,buff);
				work= Address % 16;
				Bin2Hex(work,1,buff);
				gstrcat(combuff,buff);
			}else{
				gstrcat(combuff,PLC2_CommTbl[4]);	/* RCC */
				gstrcat(combuff,Device);		/* Device Name */
				if(Plc2_DeviceFlag == 1){
					DevAddr= Address & 0x000f;
					Address = Address >> 4;
				}else{							/* T,C */
					DevAddr= 0;
				}
				Bin2dec(Address,4,buff);
				gstrcat(combuff,buff);
				DevAddr= sCnt- 1;
				DevAddr= Address+ DevAddr;
				Bin2dec(DevAddr,4,buff);
				gstrcat(combuff,buff);
			}
		}else{
			switch(Plc2_DeviceFlag){
			case 4:					/* F(FL) */
			case 5:					/* L(LD) */
			case 6:					/* D(DT) */
				gstrcat(combuff,PLC2_CommTbl[6]);	/* RD */
				combuff[6]= Device[0];		/* Device Name */
				combuff[7]= 0;
				DevAddr= Address;
				PLC2_ChangeAddressUsr(10,10,&DevAddr,10,1);
				Bcd2Asc(DevAddr,5,buff);
				gstrcat(combuff,buff);
				DevAddr= sCnt- 1;
				DevAddr= Address+DevAddr;
				PLC2_ChangeAddressUsr(10,10,&DevAddr,10,1);
				Bcd2Asc(DevAddr,5,buff);
				gstrcat(combuff,buff);
				break;
			}

		}
	}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
const	PLC2iAndData[16]={
	0x0001,0x0002,0x0004,0x0008,0x0010,0x0020,0x0040,0x0080,
	0x0100,0x0200,0x0400,0x0800,0x1000,0x2000,0x4000,0x8000,
};
/************************************/
/* Station Check 					*/
/************************************/
int	CeckStation(void)
{
	int		i,ret;

	ret= OK;
	for(i= 0; i < MAX_PLC_STATION; i++){
		if(StationInf[i] > MAX_PLC_ERR){
			ret= NG;
			break;
		}
	}
	return(ret);
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt,dCnt;
	unsigned char	*SaveAddr;
	int		EndFlag;

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = PLC2MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PcThruRecData,mp->mext);
		Cnt = mp->mext;
		break;
	case PLC_WORD:		/* Word Device */
		EndFlag= 0;
		while(EndFlag == 0){
			if(mp->mext > MAX_WORDCNT){
				dCnt= MAX_WORDCNT;
				mp->mext -= MAX_WORDCNT;
			}else{
				dCnt= mp->mext;
				mp->mext= 0;
			}
			ret = PLC2MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PcThruRecData,dCnt);
			Cnt = dCnt*2;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				i= gstrlen((char *)PcThruRecData);
				if(StationInf[mp->mbuf[4]] == 0){		/* Error Count Up */
					ret= PLC2_SendRecPLCWithBCC(2,(char *)PcThruRecData,(unsigned char *)rDataFx,&i,0);
					if((ret == 0) && (rDataFx[3] == 0x24)){		/* $ */
						for(i = 0; i < Cnt; i++){
							*(unsigned char *)SaveAddr++ = B_Hex2Bin((char *)&rDataFx[i*2+6]);
						}
						if(mp->mext > 0){
							mp->mpar+= MAX_WORDCNT;
							mp->mptr= (void *)((char *)mp->mptr + Cnt);
						}else{
							EndFlag= 1;
						}
					}else{
						/************************************************/
						/*	Station Check								*/
						/************************************************/
						StationInf[mp->mbuf[4]]++;		/* Error Count Up */
						ret= 0;
						EndFlag= 1;
						/************************************************/
					}
				}else{
					/************************************************/
					/*	Station Check								*/
					/************************************************/
					StationInf[mp->mbuf[4]]++;		/* Error Count Up */
					if(CeckStation() == OK){
						ret= 0;
					}else{
						ret = -1;
					}
					EndFlag= 1;
					/************************************************/
				}
			}
		}
		break;
	}
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
int	PLC2MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	int		work;
	int		DevAddr;
	char	Device[4];
	char	buff[8];

	Device[0]= pDevice[0];
	ret= PLC2MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt,Device);
	if(ret == 0){
		DstStationNo= pDevice[4];
		combuff[0]= '%';		/* Start */
		combuff[1]= 'E';		/* SA */
		combuff[2]= 'E';		/* SA */
		combuff[3]= '#';		/* Command */
		combuff[4]= 0;
		if(mode == 0){		/* BIT */
			if(Cnt == 1){
				gstrcat(combuff,PLC2_CommTbl[1]);	/* WCS */
				gstrcat(combuff,Device);		/* Device Name */
				Bin2dec(Address/16,3,buff);
				gstrcat(combuff,buff);
				work= Address % 16;
				Bin2Hex(work,1,buff);
				gstrcat(combuff,buff);
				for(i= 0; i < Cnt; i++){
					if(data[i] == 0){
						gstrcat(combuff,"0");
					}else{
						gstrcat(combuff,"1");
					}
				}
			}else if(Cnt < 9){
				gstrcat(combuff,PLC2_CommTbl[3]);	/* WCP */
				Bin2Hex(Cnt,1,buff);
				gstrcat(combuff,buff);
				gstrcat(combuff,Device);		/* Device Name */
				Bin2dec(Address/16,3,buff);
				gstrcat(combuff,buff);
				work= Address % 16;
				Bin2Hex(work,1,buff);
				gstrcat(combuff,buff);
				for(i= 0; i < Cnt; i++){
					if(data[i] == 0){
						gstrcat(combuff,"0");
					}else{
						gstrcat(combuff,"1");
					}
				}
			}else{
			}
		}else{		/* WORD */
			switch(Plc2_DeviceFlag){
			case 4:					/* F(FL) */
			case 5:					/* L(Ld) */
			case 6:					/* D(DT) */
				gstrcat(combuff,PLC2_CommTbl[7]);	/* WD */
				combuff[6]= Device[0];		/* Device Name */
				combuff[7]= 0;
				DevAddr= Address;
				PLC2_ChangeAddressUsr(10,10,&DevAddr,10,1);
				Bcd2Asc(DevAddr,5,buff);
				gstrcat(combuff,buff);
				DevAddr= Cnt- 1;
				DevAddr= Address+DevAddr;
				PLC2_ChangeAddressUsr(10,10,&DevAddr,10,1);
				Bcd2Asc(DevAddr,5,buff);
				gstrcat(combuff,buff);
				break;
			case 7:					/* IX,IY,ID */
				gstrcat(combuff,PLC2_CommTbl[7]);	/* WD */
				gstrcat(combuff,Device);		/* Device Name */
				gstrcat(combuff,"000000000");
				break;
			}
			for(i= 0; i < Cnt*2; i++){
				Bin2Hex(data[i],2,buff);
				gstrcat(combuff,buff);
			}
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,dCnt;
	int		EndFlag;

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = PLC2MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PcThruRecData,(char *)mp->mptr);
		break;
	case PLC_WORD:		/* Word Device */
		EndFlag= 0;
		while(EndFlag == 0){
			if(mp->mext > MAX_WR_WORDCNT){
				dCnt= MAX_WR_WORDCNT;
				mp->mext -= MAX_WR_WORDCNT;
			}else{
				dCnt= mp->mext;
				mp->mext= 0;
			}
			ret = PLC2MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,dCnt,(char *)PcThruRecData,(char *)mp->mptr);
			if(ret == 0){
				Cnt= gstrlen((char *)PcThruRecData);
				if(StationInf[mp->mbuf[4]] == 0){		/* Error Count Up */
					ret= PLC2_SendRecPLCWithBCC(2,(char *)PcThruRecData,rDataFx,&Cnt,0);
					if(ret == -1){
						/************************************************/
						/*	Station Check								*/
						/************************************************/
						StationInf[mp->mbuf[4]]++;		/* Error Count Up */
						ret= 0;
						EndFlag= 1;
						/************************************************/
					}else{
						if(mp->mext > 0){
							mp->mpar+= MAX_WR_WORDCNT;
							mp->mptr= (void *)((char *)mp->mptr + dCnt*2);
						}else{
							EndFlag= 1;
						}
					}
				}else{
					/************************************************/
					/*	Station Check								*/
					/************************************************/
					StationInf[mp->mbuf[4]]++;		/* Error Count Up */
					if(CeckStation() == OK){
						ret= 0;
					}else{
						ret = -1;
					}
					EndFlag= 1;
					/************************************************/
				}
			}
		}
		break;
	}
	return(ret);
}
int	GetSendRecTime2(void)
{
	return(0);				/* 0ms */
}
void	Get_Plc2_Ver(char *name)
{
	gstrcpy(name,"V1.30");
}
#ifdef	WIN32
/********************************************/
/*	�����֐�								*/
/********************************************/
int	PLC_CONNECT2(int *PlcType,int iConnect)
{
	return(Connection2(PlcType,iConnect));
}
int	PLC1CHAR_READ2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc2(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead2(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite2(mp,rDataFx,PlcType));
}
int	GET_SEND_REC_TIME2(void)
{
	return(GetSendRecTime2());
}
void	GET_PLC2_VER(char *Name)
{
	Get_Plc2_Ver(Name);
}
#endif
/****************************** END **********************/