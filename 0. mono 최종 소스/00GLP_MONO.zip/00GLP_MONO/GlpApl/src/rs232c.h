void	Rs422Enable(int mode);
void	InitSci0( int borate, int ldata, int parity );
void	Sio0RtsOn(void);
void	Sio0RtsOff(void);
int	_Sci0ERProc( void );
#ifdef	WIN32
void	_Sci0ERInterruptHandler( void );
void	_Sci0RXInterruptHandler( void );
void	_Sci0TXInterruptHandler( void );
#else
void	__irq _Sci0ERInterruptHandler( void );
void	__irq _Sci0RXInterruptHandler( void );
void	__irq _Sci0TXInterruptHandler( void );
#endif
int	_Sci0RXInterruptProc( void );
int		_Sci0TXInterruptProc( void );
void	Rs232_0cBordrateOrgSet( void );
int Sio0SendChar( unsigned char ch );
void	Sio0RecDrv( STTFrm* pSTT );
void	Sio0Drv( STTFrm* pSTT );
void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
void	RtsOnOffSet(int type,int mode);
