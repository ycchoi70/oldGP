/*****************************************************************************************/
/*	PLC ����M �v���O��?(AUTONICS)		*/
/*	2003.5.31				*/
/************************************************/
/*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		  */
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
/*	2006.09.25 */
/*      �����͹� ���ø� ������ ���� ver 2.6�� �ϰ� ����	  */
/*  2007.01.30 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����		*/
/*  2007.10.08 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����	 		*/ 
/*****************************************************************************************/

#include	"define.h"
#include	"GpCommon.h"
#include	"PlcCommBuff.h"
#include	"mail.h"
#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include "hook_plcapl.h"

/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V3.5M"
/*****************************************************************************************/


#define POLYNORMIAL 0xA001
#define	MAX_RTY_COUNT	3
#define	MAX_WORDCNT		32
#define MAX_BITCNT		40


#define	PLC_DATA	RS_DATA8
#define PLC_PARITY	RS_NONE 
#define PLC_STOP	RS_STOP01 
#define PLC_FLOW	RS_XONOFF 

#define STX		0x02
#define ETX		0x03
#define ENQ		0x05
#define ACK		0x06
#define DLE		0x10
#define NAK		0x15



#ifdef	SH_CPU		/* ���� */
/*ksc20040707*/
/****************************************************************/
/*	Station Connect Area										*/
/****************************************************************/
static	int	PlcRecCnt;
static	int	PlcRecCmd;
static	int	GroopSema;			/* Grooping Semafo */
static	unsigned	int	Port_TimeoutCnt;		/* 20060203 */
static	int	Pro_Speed;			/* 20061025ksc */
static	unsigned int Plc_sync_time;				/* 20061025ksc */ 
#endif



#ifdef	SH_CPU
static unsigned char TNSW_high;
static unsigned char TNSW_low;
static	char DLEPlus;
static unsigned char DataRecCnt;
static unsigned char CheckDevice;
static unsigned char CheckAddr;
static unsigned char TNSWCheck;
#endif

/* Device Type GP Code Define */
#define	_bO		0x14
#define _bI		0x10
#define _bS		0x20
#define _bB		0x18
#define _bT		0x32
#define _bC		0x50

#define _wO		0x84
#define _wI		0x80
#define _wS		0x90
#define _wB		0xB1
#define _wTS	0xAA	// Timer.Set Value(Preset Value)
#define _wTP	0xA2	// Timer.Present Value(Accumulate Value)
#define _wCS	0xB8	// Count.Set Value(Preset Value)
#define _wCP	0xB0	// Count.Present Value(Accumulate Value)
#define _wN		0xC0

static	const	DEV_CODE_TBL bPLCDeviceTbl[16] = {
	{"O",	_bO,	0x8B00,2},		// Output
	{"I",	_bI,	0x8C01,2},		// Input
	{"S2",	_bS,	0x8402,2},		// Status
	{"B3",	_bB,	0x8503,2},		// Bin
//	{"N7",	_bN,	0x8907,2},		// Interger
	{"T",	_bT,	0x8604,2},		// Timer
	{"C",	_bC,	0x8705,2},		// Counter
//	{"T4",	0x00,	0x8604,2},		// Timer.DN
//	{"C5",	0x00,	0x8705,2},		// Counter.DN
//	{"R6",	0x8806,2},		// Control
	{0	 ,	0x00,	0x0000,4},
};
static	const	DEV_CODE_TBL	wPLCDeviceTbl[16] = {
	{"O",	_wO,	0x8B00,2},
	{"I",	_wI,	0x8C01,2},
	{"S2",	_wS,	0x8402,2},
	{"B3",	_wB,	0x8503,2},
	{"N7",	_wN,	0x8907,2},
	{"TP",	_wTP,	0x8604,2},
	{"TS",	_wTS,	0x8604,2},
	{"CP",	_wCP,	0x8705,2},
	{"CS",	_wCS,	0x8705,2},
//	{"R6",	0x00,	0x8806,2},
	{ 0,	0x00,	0x0000,4},
};

/* Device Type Define */
#define _O	0x8B
#define _I	0x8C
#define _S	0x84
#define _B	0x85
#define _T	0x86
#define _C	0x87
#define _R	0x88
#define _N	0x89
#define _F	0x8A

static int _localStation;	/* GP/LP �ڽ��� ���� */
static char _dlechk[512];	/* frame�� dle �ߺ�ó���� buffer */

/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef  PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= PLC_SPEED;
	*DataBit= PLC_DATA;
	*Parity= ((PLC_FLOW << 16) |(PLC_STOP << 8) | (PLC_PARITY << 0));		/* 20090527 */	
}

/****************************************************/
/*	File No, Element, Sub.Element�� 0~254������		*/
/*	����Ѵ�. 255�̻��ΰ��, �ش� ���� 0xff��		*/
/*	�����ϰ� ���� 2byte�� ���� ũ�⸦ ����.			*/
/*	�ش� ����� max�� 0xff�� �����ϰ� �ش��Ұ���	*/
/*	0xff�̸� ���� 2byte�� 0xff, 0x00���� �����Ѵ�.	*/
/*													*/
/*	char *buf : ó���� buff							*/
/*	int *Idx : FileNo, El, S.El�� �Է��� ���� index	*/
/*				��ġ���� �����ϰ� �ִ� index����	*/
/*				point								*/
/****************************************************/
static void CheckElementRange(char *buf, int *Idx)
{
	if(buf[(*Idx)-1] == (char)0xff)
	{
		buf[(*Idx)++] = 0xff;
		buf[(*Idx)++] = 0;
	}
}

/****************************************************/
/*	Data Area���� DLE Check							*/
/*	��������ӿ��� DLESTX~DLEETX ������ ����Ÿ��	*/
/*	DLE ���� �ߺ�ó���Ѵ�.							*/
/*													*/
/*	char *buf : DLE �ߺ�ó���� buff					*/
/*	int len : �ۼ��� ��ü frame lenght				*/
/*	int ds : DLE �ߺ�ó���� buf�� ���� index		*/
/*	int es : DLE �ߺ�ó���� buf�� ������ index		*/
/****************************************************/
static int CheckDLE(char *buf, int len, int ds, int de)
{
	int sidx, tidx;

	B_gmemcpy(_dlechk, buf, len);

	for(sidx=ds, tidx=ds; sidx<len; sidx++)
	{
		if(sidx <= de && _dlechk[sidx] == DLE)
		{
			buf[tidx++] = DLE;
			buf[tidx++] = DLE;
		}
		else
		{
			buf[tidx++] = _dlechk[sidx];
		}		
	}

	return tidx;
}

/*********************************/
/*	PLC Semafor			         */
/*********************************/
static	void	GetGroopSema(void)
{
	unsigned int	NowTime;
	unsigned int	StartTime;

	if(GroopSema == 0){		/* Grooping Sema */
	}else{
		StartTime= B_GetNowTime();
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
			NowTime= B_GetNowTime();
			if((StartTime+ 2000) < NowTime){
				GroopSema= 0;
			}
			B_Delay(10);
		}
	}
	GroopSema++;
}
static	void	ResetGroopSema(void)
{
	GroopSema= 0;
}
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{

	int	ret;
	ret= -1;
	
	if(*RecCnt >= PLC_BUF_MAX){
		*CommMode = 0;
		*RecCnt = 0;
		B_gmemset((char*)RecBuff, 0x00, PLC_BUF_MAX);
	}
	switch(*CommMode){

	case 0:
		*RecCnt= 0;			
		RecBuff[(*RecCnt)++] = data;
		if(data==DLE){
			*CommMode = 1;
		}
		else{
			*CommMode = 0;
		}
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		if(data==ACK){
			*CommMode = 2;
		}
		else{
			*CommMode = 0;
		}
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		if(data==DLE){
			*CommMode = 3;
		}
		break;
	case 3:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		if(data==ETX){
			*CommMode = 4;
		}else{
			*CommMode = 2;
		}
		break;
	case 4:		//CRC1
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		*CommMode = 5;
		break;
	case 5:		//CRC2
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		*CommMode = 0;
		ret= 0;
		break;
	}

	
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/


/*ksc20040707*/
/****************************/
/* Make Check SUM For PLC	*/
/****************************/


static unsigned short crc16(unsigned char *puchMsg, int usDataLen){ 
	int i;
	unsigned short crc, flag;
	crc = 0x0000;
	*puchMsg++;
	*puchMsg++;
	*puchMsg++;
	*puchMsg++;
	usDataLen=usDataLen-5;
	if(usDataLen <= 0){	return(0);}		/* 20090527 */
	while(usDataLen--){
		if(*puchMsg == 0x10 && usDataLen==0){
			*puchMsg++;
		}
		if(*puchMsg == 0x10 && *(puchMsg+1) == 0x10){
			*puchMsg++;
			usDataLen--;
		}
		crc ^= *puchMsg++;
		for (i=0; i<8; i++){
			flag = crc & 0x0001;
			crc >>= 1;
			if(flag) crc ^= POLYNORMIAL;
		}
	}
	return crc;
}


static	int SetPLCBCC(char *buff,int cnt)
{

	unsigned short _crc16;
  
	DataRecCnt = buff[11];
	TNSWCheck=buff[9];
	_crc16 = crc16((unsigned char *)buff, cnt);
	buff[cnt] = (unsigned char)((_crc16>>0) & 0x00ff); 
	buff[cnt+1] = (unsigned char)((_crc16>>8) & 0x00ff); /* write_comm(data, 8);*/
	return(cnt + 2);
    
}	



/************************************/
/*	PLC Send						*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	unsigned short _crc16;
	unsigned short cal16;
	int		rty_cnt;
	int		SendCnt;
    char rDatax;

	SendCnt= SetPLCBCC((char *)combuf,*Cnt);
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT/*2000*/; rty_cnt++){
		ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
			
		rDatax=rData[9];
		if(ret == 0 && combuf[9] ==rDatax){  /* ���� �����̸鼭 ���� �ڵ尡 �ƴ� ��쿡 crc üũ */
			ret=0;
			cal16= (rData[*Cnt- 1] << 8) + rData[*Cnt- 2];
			_crc16= crc16((unsigned char *)rData,*Cnt-2);
			if(cal16 != _crc16){
				ret= -1;/* -1*/
			}
		}else {
			ret= -1;/* -1*/
			TNSW_low=TNSW_low+4;
			if(TNSW_low==0x10){
				TNSW_low=TNSW_low+4;
			}
			rData[9]=TNSW_low;
			SendCnt= SetPLCBCC((char *)combuf,*Cnt);
		}
		if(ret == OK){
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}
	return(ret);
}
static	int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	unsigned short _crc16;
	unsigned short cal16;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,*Cnt);
	ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	if(ret == 0){
		cal16= (rData[*Cnt- 1] << 8) + rData[*Cnt- 2];
		_crc16= crc16((unsigned char *)rData,*Cnt-2);
		if(cal16 != _crc16){
			ret= -1;/* -1*/
		}
	}
	return(ret);
}



static	int	C_Connection( int *PlcType,int iConnect )
{
	int		ret;
/*ksc20040714*/
	int		Cnt;
	char	buff[32];

	int		Speed;
	int		DataBit;
	int		Parity;
    TNSW_low = TNSW_low+4;
	if(TNSW_low==0x10){
		TNSW_low=TNSW_low+4;
	}
 
	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */	
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
		}else{						

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
		}
#ifdef	WIN32
		while(1){
			if((iConnect & 1) == 0){
				if(SioPCOpenFlag == 0){
					break;
				}
			}else{
				if(SioPLCOpenFlag == 0){
					break;
				}
			}
	/*ksc20040714*/
			B_Delay(10);
		}
#else

	/*ksc20040714*/
		B_Delay(100);
#endif
	}
	/* PLC Connect Check *(PlcType+2) ���� ������ �Ѱ� ���� */
	monitorModeFlag= PlcType[4];		/* 20090704 */

	/* GP/LP ���� ���� ���� */
	_localStation = PlcType[1];
	
    
	buff[0]= DLE;
	buff[1]= ACK;
	buff[2]= DLE;
	buff[3]= STX;
	buff[4]= PlcType[2];			/* DST						*/
    buff[5]= _localStation;			/* SRC						*/
    buff[6]= 0x06;					/* CMD : diagnostic status	*/
	buff[7]= 0x00;					/* STS						*/
	buff[8]= 0x00;					/* TNSW_high				*/
	buff[9]= TNSW_low;				/* TNSW_low					*/
	buff[10]= 0x03;					/* FUC : diagnostic status	*/
	buff[11]= DLE;
	buff[12]= ETX;
	Cnt= 13;

	ret= SendRecPLCWithBCCCont(2,buff,PlcRecBuff,&Cnt,0);		


	ResetGroopSema();	

	if(ret < 0){
		return(0);
	}

	/* PLC Connect Check */
	ret= 1;
	return(ret);
}
/******************************************/
static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif
#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif

}
/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;


	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
/*ksc20040713*/
			/*
			ret = Address % 16;
			BitAndData = 1;
			for(j = 0; j < ret; j++){
				BitAndData <<= 1;
			}
			ret += sCnt;
			ret = ret / 8 + 1;
			BitRecCnt = ret;
			*/
/*ksc20040713*/
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
//				if(B_gstrncmp(bPLCDeviceTbl[i].Device,Device,2) == 0){
				if(bPLCDeviceTbl[i].DevCode == pDevice[0])
				{
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				CheckDevice=OffSet/0x100;
				pDevice[0]=OffSet/0x100;	
				pDevice[1]=OffSet%0x100;
				ret=0;
		
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
//				if(B_gstrncmp(wPLCDeviceTbl[i].Device,Device,2) == 0){
				if(wPLCDeviceTbl[i].DevCode == pDevice[0])
				{	
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				CheckDevice=Device[1];
				pDevice[0]=OffSet/0x100;	
				pDevice[1]=OffSet%0x100;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
/* �۽� ������ ���� */
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt,int StationNo, int *frmSize)
{
	int		ret;
	int		DevAddr,MonitorBit;
	int		sDataIdx, eDataIdx, idx;
//	unsigned char offset[2];

	idx =0;	
	
	TNSW_low = TNSW_low+4;
	if(TNSW_low==0x10){
		TNSW_low=TNSW_low+4;
	}
	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);

	DevAddr	=Address/0x10;
	MonitorBit=(Address%0x10)+sCnt ;
	
	if(ret==0) 
	{
		//DLEPlus=0;
		combuff[idx++]= DLE;
		combuff[idx++]= ACK;
		combuff[idx++]= DLE;
		combuff[idx++]= STX;
		sDataIdx = idx;
		combuff[idx++]= StationNo;			/* DST					*/
	    combuff[idx++]= _localStation;		/* SRC					*/
		combuff[idx++]= 0x0F;				/* CMD					*/
		combuff[idx++]= 0x00;				/* STS					*/
		combuff[idx++]= 0x00;				/* TNSW_high			*/	
		combuff[idx++]= TNSW_low;			/* TNSW_low				*/
		combuff[idx++]= (char)0xA2;			/* FNC(0xA1 / 0xA2):protected typed logical read with three address fileds		*/
											/*  WORD Read Command															*/
											/*	case1) sub element �̻��� : 0x0F + 0xA1									*/
											/*		--> FileNo + Type + Element												*/
											/*	case2) sub element ����	: 0x0F + 0xA2									*/
											/*		--> FileNo + Type + Element	+ Sub Element								*/

		switch(pDevice[0])
		{
		case _T:
		case _C:
			combuff[idx++] = sCnt * 0x06; /*byte Count */
			break;
		default:
			if(mode==0)
			{
				/* ���� byte �� ��� */
				combuff[idx++]=((MonitorBit % 0x10 == 0)? MonitorBit /0x10 : MonitorBit/0x10+1)*2;
			}
			else
			{
				combuff[idx++]= sCnt *0x02;
			}
			break;
		}
		combuff[idx++]= pDevice[1];			/* File No			*/
		combuff[idx++]= pDevice[0];			/* File Type		*/

		if(mode==0){
			switch(pDevice[0]){
			case _T:
			case _C:
				combuff[idx++]=Address;
				break;
			case _O:
			case _I:
				combuff[idx++]=Address/0x1000;
				break;
			case _S:
			case _B:
				combuff[idx++]=DevAddr;
				break;
			}
		}
		else								/* Else No / word		*/
		{
			switch(pDevice[0])
			{
			case _T:
			case _C:
			case _S:
			case _B:
			case _N:
				combuff[idx++]=Address;
				break;
			case _O:
			case _I:
				combuff[idx++]=Address/0x100;
				break;
			}
		}

		/*element no 255(0xff)�� ��� ó�� */
		CheckElementRange(combuff, &idx);

		if(mode ==0)						
		{									/*  S/Ele No / bit	*/
			switch(pDevice[0])
			{
			case _T:
			case _C:
			case _S:
			case _B:
				combuff[idx++]=0x00;
				break;
			case _O:
			case _I:
				combuff[idx++]=DevAddr%0x100;
				break;
			}
		}
		else
		{									/*  S/Ele No / word	*/
			switch(pDevice[0])
			{
			case _T:
			case _C:
			case _S:
			case _B:
			case _N:
				combuff[idx++]=0x00;
				break;
			case _O:
			case _I:
				combuff[idx++]=Address%0x100;
				break;
			}
		}
		
		/*element no 255(0xff)�� ��� ó�� */
		CheckElementRange(combuff, &idx);

		eDataIdx = idx-1;

		combuff[idx++]=DLE;
		combuff[idx++]=ETX;

		*frmSize = CheckDLE(combuff, idx, sDataIdx, eDataIdx);
		}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
static	int	BitReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j,k,CmpbitUp;
	int		sCnt,Tempj;
	int		Cnt,dCnt, bitCnt;

	unsigned char	*SaveAddr;
	int		Address;
	int		wordVal;
	int		EndFlag;

	int		CmpBit;
	GetGroopSema();
	Address= mp->mpar;
	dCnt= mp->mext; 	
	EndFlag= 0;
	while(EndFlag == 0)
	{
		if(dCnt > MAX_BITCNT){
			dCnt -= MAX_BITCNT;
			mp->mext = MAX_BITCNT;
		}else{
			mp->mext= dCnt;
			dCnt =0;
		}

		ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext,(int)mp->mbuf[4], &sCnt);
		Cnt = mp->mext;
		SaveAddr = (unsigned char *)mp->mptr;
		if(ret == 0)
		{
			if(SendRecPLCWithBCC(2,(char*)PlcSendBuff, (unsigned char *)rDataFx, &sCnt,0)==0){
				// Data �����߿��� DLEDLE������ DLE�� ����
				for(j=10; j<sCnt; j++){
					if(rDataFx[j]==DLE){
						Tempj = j;
						if(rDataFx[j+1]!=ETX){
							for(k=Tempj; k<sCnt; k++){
								rDataFx[k+1] = rDataFx[k+2];
							}
						}
					}
				}

				/* ù��° Read Data�� Mask Data �����*/
				CmpBit = 1;
				bitCnt = Address % 0x10;
				for(CmpbitUp=0; CmpbitUp< bitCnt; CmpbitUp++){
					CmpBit <<=1;
				}

				wordVal = rDataFx[10]+(rDataFx[11]*0x100);

				for(i=0,j=12; i<Cnt; i++)
				{
					if(CheckDevice == _T || CheckDevice ==_C)			// TDN, CDN
					{
						if((rDataFx[11+(i*6)]&0x20)==0)
						{
							*(unsigned char *)SaveAddr =0;
							SaveAddr++;
						}
						else
						{
							*(unsigned char *)SaveAddr =1;
							SaveAddr++;
						}
					}
					else
					{
						if((wordVal & CmpBit) == 0)
						{
							*(unsigned char *)SaveAddr =0;
							SaveAddr++;
						}
						else
						{
							*(unsigned char *)SaveAddr =1;
							SaveAddr++;
						}
						CmpBit <<=1;

						if(CmpBit > 0x8000)
						{
							CmpBit =1;
							wordVal = rDataFx[j]+(rDataFx[j+1]*0x100);
							j+=2;
						}
					}
				}
				if(dCnt == 0)
				{
					ret =0;
					EndFlag =1;
					break;
				}
				Address += MAX_BITCNT;
				mp->mpar = Address;
				mp->mptr = SaveAddr;
			}else{
				ret= -1;	
				return(ret);	
			}
		}else{
			ret =-1;
			EndFlag=1;
		}
	}
	return(ret);
}
static	int	WordReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j,k;
	int		sCnt,Tempj;
	int		Cnt,dCnt;
	unsigned char	*SaveAddr;
	int		Address;
	int		EndFlag;
	
	GetGroopSema();
	Address= mp->mpar;
	dCnt= mp->mext;	
	EndFlag= 0;
	
	while(EndFlag == 0){
		if(dCnt > MAX_WORDCNT){
			dCnt -= MAX_WORDCNT;
			mp->mext= MAX_WORDCNT;
		}else{
			mp->mext= dCnt;
			dCnt = 0;
		}
		
		ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext,(int)mp->mbuf[4], &sCnt); 
		Cnt = mp->mext;
		SaveAddr = (unsigned char *)mp->mptr;
		if(ret == 0){
			if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&sCnt,0) == 0)
			{ 
				if(PlcSendBuff[9] == rDataFx[9])
				{
					for(j=10; j<sCnt; j++){
						if(rDataFx[j]==0x10){ 
								Tempj=j;
								if(rDataFx[j+1]!=0x03){	
									for(k=Tempj; k<sCnt; k++){
										rDataFx[k+1]=rDataFx[k+2];
									}
								}
							}
					}
					for(i = 0; i < Cnt; i++)
					{
#ifdef	SH_CPU
						switch(mp->mbuf[0])
						{
						case _wTS:		/*Set(Preset) Value */
						case _wCS:
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*6+12];
							SaveAddr++;
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*6+12+1];
							SaveAddr++;
							break;
						case _wTP:		/*Present(Accumulated) Value */
						case _wCP:
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*6+14];
							SaveAddr++;
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*6+14+1];
							SaveAddr++;
							break;
						default:
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*2+10];
							SaveAddr++;
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*2+10+1];
							SaveAddr++;
							break;
						}
#endif
#ifdef	ARM_CPU
#ifdef	WIN32
						switch(mp->mbuf[0])
						{
						case _wTS:		/*Set(Preset) Value */
						case _wCS:
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*6+12];
							SaveAddr++;
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*6+12+1];
							SaveAddr++;
							break;
						case _wTP:		/*Present(Accumulated) Value */
						case _wCP:
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*6+14];
							SaveAddr++;
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*6+14+1];
							SaveAddr++;
							break;
						default:
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*2+10];
							SaveAddr++;
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*2+10+1];
							SaveAddr++;
							break;
						}
#else
						switch(mp->mbuf[0])
						{
						case _wTS:		/*Set(Preset) Value */
						case _wCS:
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*6+12+1];
							SaveAddr++;
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*6+12];
							SaveAddr++;
							break;
						case _wTP:		/*Present(Accumulated) Value */
						case _wCP:
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*6+14+1];
							SaveAddr++;
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*6+14];
							SaveAddr++;
							break;
						default:
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*2+10+1];
							SaveAddr++;
							*(unsigned char *)SaveAddr=(unsigned char)rDataFx[i*2+10];
							SaveAddr++;
							break;
						}
#endif
#endif
					}
				}
				if(dCnt == 0){
					EndFlag= 1;
					break;
				}
			
				Address += MAX_WORDCNT;
				mp->mpar= Address;
				mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
			}else{
				ret = -1;
				EndFlag= 1;
			}					
		}else{
			ret= 0;
			EndFlag= 1;
		}
	}
	return(ret);
}
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	switch(mp->mpec){
	case PLC_BIT:		ret= BitReadProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordReadProc(mp,rDataFx,PlcType);		break;
	}	
	ResetGroopSema();
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
static	int	ChangeIntData(char *data,int Cnt,int mode)
{
	int		iData;
	int		i;
	union{
		int		iData;
		char	cData[4];
	}rData;

	B_gmemset((char *)&rData,0,sizeof(rData));
	if(mode == 1){
		for(i= 0; i < Cnt*2 && i < 4; i++){
			rData.cData[3- i]= *data;
			data++;
		}
		iData = rData.iData;
	}else{
		iData = *data;
	}
	return(iData);
}
/****************************/
/* Make Write Device		*/
/****************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data,int StationNo, int *frmSize)
{
	
	int		ret,Shiftdata,TempData_1,TempData_2;
	int		sDataIdx, eDataIdx, Idx;

	Idx = 0;
  
	TNSW_low=TNSW_low+4;
	if(TNSW_low==0x10){
	   TNSW_low=TNSW_low+4;
	 }
	ret = 0;
	CheckAddr = pDevice[0];

	if(mode == 0){	/* Bit */
		TempData_1=1;
		TempData_2=*data;
		combuff[Idx++]= DLE;
		combuff[Idx++]= ACK;
		combuff[Idx++]= DLE;
		combuff[Idx++]= STX;
		sDataIdx = Idx;
		combuff[Idx++]= StationNo;			/*	TGT			*/
		combuff[Idx++]= _localStation;		/*	SRC			*/
		combuff[Idx++]= 0x0F;				/*	CMD			*/
		combuff[Idx++]= 0x00;				/*	STS			*/
		combuff[Idx++]= 0x00;				/*	TNSW_high	*/
		combuff[Idx++]= TNSW_low;			/*	TNSW_low	*/
		combuff[Idx++]= (char)0xAB;			/*	FNC			*/
											/*  BIT Write Command 0x0F + 0xAB	*/
											/*	format : FileNo + Type + Element + SubElement + Value Mask(2byte) + Value(2byte) */
		combuff[Idx++]= 0x02;				/*	byte Count	*/
		switch(CheckAddr)
		{
		case _bO:							/*	O			*/
			combuff[Idx++]=0x00;               /*	file no		*/
			combuff[Idx++]=(char)_O;			/*	device type	*/
			break;
		case _bI:							/*	I			*/
			combuff[Idx++]=0x01;               /*	file no		*/
			combuff[Idx++]=(char)_I;			/*	device type	*/
			break;
		case _bS:							/*	S			*/
			combuff[Idx++]=0x02;               /*	file no		*/
			combuff[Idx++]=(char)_S;			/*	device type	*/
			break;
		case _bB:							/*	B			*/
			combuff[Idx++]=0x03;               /*	file no		*/
			combuff[Idx++]=(char)_B;			/*	device type	*/
			break;
		case _bT:							/*	T			*/
			combuff[Idx++]=0x04;               /*	file no		*/
			combuff[Idx++]=(char)_T;			/*	device type	*/
			break;
		case _bC:							/*	C			*/
			combuff[Idx++]=0x05;				/*	file no		*/
			combuff[Idx++]=(char)_C;			/*	device type	*/
			break;
		}
		
		switch(CheckAddr)					/*	Element	NO	*/
		{
		case _bO:							/*	O			*/
		case _bI:							/*	I			*/
			combuff[Idx++]=Address/0x1000;
			break;
		case _bS:							/*	S			*/
		case _bB:							/*	B			*/
			combuff[Idx++]=Address/0x10;
			break;
		case _bT:							/*	T			*/
		case _bC:							/*	C			*/
			combuff[Idx++]=Address;
			break;
		}

		/* element no 255(0xff)�� ��� ó�� */
		CheckElementRange(combuff, &Idx);

		switch(CheckAddr)					/*	Sub.Element No */
		{
		case _bO:							/*	O			*/
		case _bI:							/*	I			*/
			combuff[Idx++] = (Address/0x10)%0x100;
			break;
		case _bS:							/*	S			*/
		case _bB:							/*	B			*/
		case _bT:							/*	T			*/
		case _bC:							/*	C			*/
			combuff[Idx++]=0;
			break;
		}

		/* sub element no 255(0xff)�� ��� ó�� */
		CheckElementRange(combuff, &Idx);

#ifdef SH_CPU
		if(combuff[13]==(char)_T || combuff[13]==(char)_C)
		{
			combuff[Idx++]=0x00;
			combuff[Idx++]=0x20;
			combuff[Idx++]=0x00;
			combuff[Idx++]=*(data+Cnt)*0x20;
		}
		else
		{
			Shiftdata = Address % 0x10;

			TempData_1<<=Shiftdata;			/* bit device location*/
			TempData_2<<=Shiftdata;			/* bit device On, Off status */

			combuff[Idx++]=TempData_1%0x100;
			combuff[Idx++]=TempData_1/0x100;
			combuff[Idx++]=TempData_2%0x100;
			combuff[Idx++]=TempData_2/0x100;

		}
/*
		if (combuff[13]== (char)-122 || combuff[13]== (char)-121){
			combuff[16+DLEPlus]=0x00;
			combuff[17+DLEPlus]=0x20;
			combuff[18+DLEPlus]=0x00;
			combuff[19+DLEPlus]=*(data+Cnt) * 0x20;
		}
		else{
			combuff[16+DLEPlus]=TempData_1%0x100;
			if(combuff[16+DLEPlus]==0x10){
				combuff[17+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[17+DLEPlus]=TempData_1/0x100;
			if(combuff[17+DLEPlus]==0x10){
				combuff[18+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[18+DLEPlus]=TempData_2%0x100;
			if(combuff[18+DLEPlus]==0x10){
				combuff[19+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[19+DLEPlus]=TempData_2/0x100;
			if(combuff[19+DLEPlus]==0x10){
				combuff[20+DLEPlus]=0x10;
				DLEPlus++;
			}
		}
*/
#endif
#ifdef ARM_CPU
#ifdef WIN32													/*	Data Set	*/
		if(combuff[13]==(char)_T || combuff[13]==(char)_C)
		{
			combuff[Idx++]=0x00;
			combuff[Idx++]=0x20;
			combuff[Idx++]=0x00;
			combuff[Idx++]=*(data+Cnt)*0x20;
		}
		else
		{
			Shiftdata = Address % 0x10;

			TempData_1<<=Shiftdata;			/* bit device location*/
			TempData_2<<=Shiftdata;			/* bit device On, Off status */

			combuff[Idx++]=TempData_1%0x100;
			combuff[Idx++]=TempData_1/0x100;
			combuff[Idx++]=TempData_2%0x100;
			combuff[Idx++]=TempData_2/0x100;

		}
#else 
		if(combuff[13]==(char)_T || combuff[13]==(char)_C)
		{
			combuff[Idx++]=0x00;
			combuff[Idx++]=0x20;
			combuff[Idx++]=0x00;
			combuff[Idx++]=*(data+Cnt)*0x20;
		}
		else
		{
			Shiftdata = Address % 0x10;

			TempData_1<<=Shiftdata;			/* bit device location*/
			TempData_2<<=Shiftdata;			/* bit device On, Off status */

			combuff[Idx++]=TempData_1%0x100;
			combuff[Idx++]=TempData_1/0x100;
			combuff[Idx++]=TempData_2%0x100;
			combuff[Idx++]=TempData_2/0x100;

		}
/*
		if (combuff[13]== (char)-122 || combuff[13]== (char)-121){
			combuff[16+DLEPlus]=0x00;
			combuff[17+DLEPlus]=0x20;
			combuff[18+DLEPlus]=0x00;
			combuff[19+DLEPlus]=*(data+Cnt) * 0x20;
		}
		else{
			combuff[16+DLEPlus]=TempData_1%0x100;
			if(combuff[16+DLEPlus]==0x10){
				combuff[17+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[17+DLEPlus]=TempData_1/0x100;
			if(combuff[17+DLEPlus]==0x10){
				combuff[18+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[18+DLEPlus]=TempData_2%0x100;
			if(combuff[18+DLEPlus]==0x10){
				combuff[19+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[19+DLEPlus]=TempData_2/0x100;
			if(combuff[19+DLEPlus]==0x10){
				combuff[20+DLEPlus]=0x10;
				DLEPlus++;
			}
		}
*/
#endif
#endif
		eDataIdx = Idx-1;

		combuff[Idx++]= DLE;
		combuff[Idx++]= ETX;
		
	}
	else
	{								/* Word */
		combuff[Idx++]= DLE;
		combuff[Idx++]= ACK;
		combuff[Idx++]= DLE;
		combuff[Idx++]= STX;
		sDataIdx = Idx;
		combuff[Idx++]= StationNo;
		combuff[Idx++]= _localStation;
		combuff[Idx++]= 0x0F;
		combuff[Idx++]= 0x00;
		combuff[Idx++]= 0x00;/*TNSW_high*/
		combuff[Idx++]= TNSW_low;
		combuff[Idx++]= (char)0xAA;				/*  Word Write Command 0x0F + 0xAA	*/
												/*	format : FileNo + Type + Element + SubElement + Value(2byte) */
		switch(CheckAddr){
		case _wO:				//O
			combuff[Idx++]= 0x02;			/*	byte count	*/
			combuff[Idx++]= 0x00;			/*	file no		*/
			combuff[Idx++]= (char)_O;				/*	type		*/
			combuff[Idx++]= Address/0x100;	/*	element		*/
            CheckElementRange(combuff, &Idx);
			combuff[Idx++]=Address%0x100;	/*	sub element*/
			CheckElementRange(combuff, &Idx);
			break;
		case _wI:				//I
			combuff[Idx++]= 0x02;			/*	byte count	*/
			combuff[Idx++]= 0x01;			/*	file no		*/	
			combuff[Idx++]= (char)_I;
			combuff[Idx++]= Address/0x100;
			CheckElementRange(combuff, &Idx);
            combuff[Idx++]= Address%0x100;
			CheckElementRange(combuff, &Idx);
			break;
		case _wS:			/*S2 write*/ 
			combuff[Idx++]= 0x02;			/*	byte count	*/
			combuff[Idx++]= 0x02;			/*	file no		*/	
			combuff[Idx++]= (char)_S;
			combuff[Idx++]= Address;
			CheckElementRange(combuff, &Idx);
            combuff[Idx++]= 0x00;
			break;
		case _wB:
			combuff[Idx++]= 0x02;			/*	byte count	*/
			combuff[Idx++]= 0x03;			/*	file no		*/	
			combuff[Idx++]= (char)_B;
			combuff[Idx++]= Address;
			CheckElementRange(combuff, &Idx);
            combuff[Idx++]= 0x00;
			break;
		case _wN: 
			/*N7 write*/
			combuff[Idx++]= 0x02;			/*	byte count	*/
			combuff[Idx++]= 0x07;			/*	file no		*/	
			combuff[Idx++]= (char)_N;
			combuff[Idx++]= Address;
			CheckElementRange(combuff, &Idx);
            combuff[Idx++]= 0x00;
			break;
		case _wTS:
			combuff[Idx++]= 0x02;			/*	byte count	*/
			combuff[Idx++]= 0x04;			/*	file no		*/	
			combuff[Idx++]= (char)_T;
			combuff[Idx++]= Address;
			CheckElementRange(combuff, &Idx);
            combuff[Idx++]= 0x01;
			break;
		case _wTP:
  			combuff[Idx++]= 0x02;			/*	byte count	*/
			combuff[Idx++]= 0x04;			/*	file no		*/	
			combuff[Idx++]= (char)_T;
			combuff[Idx++]= Address;
			CheckElementRange(combuff, &Idx);
            combuff[Idx++]= 0x02;
			break;
		case _wCS:
			combuff[Idx++]= 0x02;			/*	byte count	*/
			combuff[Idx++]= 0x05;			/*	file no		*/	
			combuff[Idx++]= (char)_C;
			combuff[Idx++]= Address;
			CheckElementRange(combuff, &Idx);
            combuff[Idx++]= 0x01;
			break;
		case _wCP:
			combuff[Idx++]= 0x02;			/*	byte count	*/
			combuff[Idx++]= 0x05;			/*	file no		*/	
			combuff[Idx++]= (char)_C;
			combuff[Idx++]= Address;
			CheckElementRange(combuff, &Idx);
            combuff[Idx++]= 0x02;
			break;
		}

#ifdef SH_CPU
		combuff[Idx++] = *(data+(Cnt*2));
		combuff[Idx++] = *(data+1+(Cnt*2));
#endif
#ifdef ARM_CPU
#ifdef WIN32
		combuff[Idx++] = *(data+(Cnt*2));
		combuff[Idx++] = *(data+1+(Cnt*2));
#else
		combuff[Idx++] = *(data+1+(Cnt*2));
		combuff[Idx++] = *(data+(Cnt*2));
#endif
#endif
		eDataIdx = Idx -1;
		combuff[Idx++]=DLE;
		combuff[Idx++]=ETX;
	}
	*frmSize = CheckDLE(combuff, Idx, sDataIdx, eDataIdx);
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
static	int	BitWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;
	int		ReCnt;
	int     Address,DeviceCount;
	
	ret = 0;
	ReCnt=mp->mext;
	DeviceCount=0;
	Address= mp->mpar;
	GetGroopSema();
	while(ReCnt!=0){
		ret = MakePLCWriteData(0,(char *)mp->mbuf,Address,DeviceCount,(char *)PlcSendBuff,(char *)mp->mptr,(int)mp->mbuf[4], &Cnt);
		if(ret == 0){
		 	if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){
			}else{
				ret = -1;
			}
		}else if(ret == 1){		/* ����Address */
			ret= 0;
		}
		ReCnt--;
		Address++;
		DeviceCount++;
	}
	return(ret);
}
static	int	WordWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;
	int		ReCnt;
	int     Address,DeviceCount;
	ret = 0;

	ReCnt=mp->mext;
	DeviceCount=0;
	Address= mp->mpar;
	GetGroopSema();
		while(ReCnt!=0){
			ret = MakePLCWriteData(1,(char *)mp->mbuf,Address,DeviceCount,(char *)PlcSendBuff,(char *)mp->mptr,(int)mp->mbuf[4],&Cnt);
			if(ret == 0){
				if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){}
				else{
					ret = -1;
				}
			}else if(ret == 1){		/* ����Address */
				ret= 0;
			}
			ReCnt--;
			Address++;
			DeviceCount++;
		}

	return(ret);
}
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	switch(mp->mpec){
	case PLC_BIT:		ret= BitWriteProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordWriteProc(mp,rDataFx,PlcType);		break;
	}
	ResetGroopSema();
	return(ret);
}
static	int	C_GetSendRecTime(void)
{
	return(5);				/* 1ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}


/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;
	ret= -1;

	if(Port_TimeoutCnt != 0){
		if(500 < (B_GetNowTime() - Port_TimeoutCnt)){   /* 20061025ksc */ 
			*CommMode =0;
			*Sio1RecCnt = 0;
		}
	}
	Port_TimeoutCnt = B_GetNowTime();		

	if(*Sio1RecCnt >= PLC_BUF_MAX){
		*CommMode = 0;
		*Sio1RecCnt = 0;
		B_gmemset((char*)Sio1RecBuff, 0x00, PLC_BUF_MAX);
	}
	switch(*CommMode){

	case 0:						//Start
		*Sio1RecCnt= 0;			
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		if(data==DLE){							//DLE
			*CommMode = 4;
		}
		else{
			*CommMode = 0;
		}
		break;
	case 4:
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		if((data==STX) || (data==ACK)){			//DLE STX
			*CommMode = 5;
		}
		else{
			*CommMode = 0;
		}
		break;
	case 5:
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		if(data == DLE){
			*CommMode = 6;
		}
		break;
	case 6:
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		if(data == ETX){
			*CommMode = 7;			//DLE ETX
		}else{
			*CommMode = 5;			
		}
		break;
	case 7:			//CRC1
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		*CommMode = 8;			//goto CRC2
		break;
	case 8:			//CRC2
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		*CommMode = 99;			//END
		ret= 0;
		break;
	}

	
	return(ret);

}
/************************************************/
/*	�O��?�v����								*/
/************************************************/
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	return(0);
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if(DeviceDataSys[i].SameDevInf == 0){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
						MyAddress= DeviceDataSys[i].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Before Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
					MyAddress= DeviceDataSys[i].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Before Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN			   */									
/*	2006.03.31 makebitpatarn �ϰ� ����         */
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/*	2006.03.31 makewordpatarn �ϰ� ����        */							
/***************************************************/
void	MakeWordPatarn(int Start)
{

}
/****************************************/
/*	�O��?�v�쐬			*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Same Device Check */
/*	gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));*/
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	/* �r�b�g�A��?�h�̘A����?�F�b�N���� */
	MakeBitContinue();
	MakeWordContinue(TotalBitCnt);
	/* �r�b�g�A��?�h�̃p??����?�F�b�N���� */
	/* Bit Patarn */
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	/* Word Patarn */
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}

	return(0);
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int	ret;

	ret= 0;
	return(ret);
}
/************************************/
/*	�X��?��?�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	int	ret;
	int	i;

	GetGroopSema();
//	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
//	*OutCnt= *RecCommCnt;
//	B_SendThruePLC(2,*OutCnt,OutBuff,1000); /*20090706*/
	if((CommBuff[0] == DLE) && (CommBuff[1] == STX)){
		for(i= *RecCommCnt- 1; i >= 0; i--){
			CommBuff[i+2]= CommBuff[i];
		}
		CommBuff[0]= DLE;
		CommBuff[1]= ACK;
		*RecCommCnt= *RecCommCnt+2;
	}
	*OutCnt= *RecCommCnt;
	B_gmemcpy((char *)OutBuff,CommBuff,*RecCommCnt);
	ret= C_SendRecPLC(2,(unsigned char*)CommBuff,RecCommCnt,0,*OutCnt,OutBuff,1000);		/* Send PLC & Recieve(ACK & Data) */
	if(ret == 0){
		B_gmemcpy((char *)OutBuff,(char *)CommBuff,*RecCommCnt);
		*OutCnt= *RecCommCnt;
		B_SendPLC2PCData(0,*OutCnt,OutBuff,1000);		/*  */
	}
	ResetGroopSema();

#ifdef	OLDSOURCE
#endif
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
#endif
/*++++++++++++++++++++++++++++++++++++*/
#ifdef PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif


#include  "hook_aplplc.h"
/****************************** END **********************/
