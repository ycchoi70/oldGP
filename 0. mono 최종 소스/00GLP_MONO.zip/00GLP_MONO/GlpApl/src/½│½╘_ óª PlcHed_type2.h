/********************************************************/
/*	PLC �g�p�O���֐�									*/
/********************************************************/
/**************************************/
extern	int		Hex2nBin(char *buff,int cnt);
extern	int		Hex2Bin(char *buff);
extern	unsigned int LHexAsToBin(char *buff, int cnt);
extern	void	SendPLCPCData( void );
extern	int	SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut);
extern	int		SendPC2PLCData2( int mode,int cnt,char *buff,int TimeOut );
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	int		GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address);
extern	void	RtsOnOffSet(int type,int mode);
extern	int		SetPLCUsrAddr(int DevInfo,int Address,unsigned char idx,int bFlag);
extern	int		SendPLC2PCData( int mode,int cnt,char *buff,int TimeOut );
extern	void	SendPLCGroup(void);
extern	void	Rs422Enable(int mode);
extern	int		SendThruePLC(int mode,int cnt,char *sBuff,int TimeOut);
extern	void	Bin2Hex(int data,int cnt,char *buff);
extern	void	Bin2dec(int data,int cnt,char *buff);
extern	int	gstrlen(char *buff);
extern	void	gmemset(char *buff,int data,int cnt);
extern	void	gmemcpy(char *obj,char *src,int cnt);
extern	void	gstrcpy(char *obj,char *src);
extern	int	gstrcmp(char *src,char *obj);
extern	int	gstrncmp(char *src,char *obj,int cnt);
extern	void	gstrcat(char *src,char *obj);
extern	int	gatoi(char *buff);



#ifdef	WIN32
extern int __cdecl Delay(int);
extern unsigned int __cdecl ReadSignal(int);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	PlcDevInit( void );
extern	unsigned char			GpFont[0x200000];
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		PLCPortOpen;
extern	int		PCPortOpen;
extern	int		SioPCOpenFlag;
extern	int		SioPLCOpenFlag;
#else
#define SGN_PLC		0
#endif


/**************************************/

extern	_SETUP		Set;					/* ������ ����E����ü						*/
/********************************************************/
/*	PLC ���[�N�w�b�_�[									*/
/********************************************************/
#ifdef	PLCTYPE_ELSE2
	int		MyStationNo;
	int		DstStationNo;
	int		MyStationNo2;
	int		DstStationNo2;

	int		DeviceFlag;						/* Device Check Flag */
	int		BitRecCnt;
	int		BitAndData;

	unsigned char	PlcSendBuff[512];
	unsigned char	PcThruWData[512];
	unsigned char	PcThruBData[512];
	unsigned char	PcThruAllData[1024];
	unsigned char	PcThruRecData[512];
	unsigned char	PlcSendDevData[512];
#else
	extern	int		MyStationNo;
	extern	int		DstStationNo;
	extern	int		MyStationNo2;
	extern	int		DstStationNo2;

	extern	int		DeviceFlag;						/* Device Check Flag */
	extern	int		BitRecCnt;
	extern	int		BitAndData;

	extern	unsigned char	PlcSendBuff[512];
	extern	unsigned char PcThruWData[512];
	extern	unsigned char PcThruBData[512];
	extern	unsigned char PcThruAllData[1024];
	extern	unsigned char PcThruRecData[512];
	extern	unsigned char PlcSendDevData[512];
#endif
