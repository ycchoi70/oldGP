/************************************************
 * NAME    : 44BLIB.C				*
 * Version : 17.APR.00				*
 ************************************************/

//  Revision History 
//  Delay()

#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#include "sgt.h"
#include "S3c44b0x.h"
#include "Selib.h"
#include "Option.h"
#include "bios.h"

extern	unsigned int	IntMaskData;
extern	void	RtcInit(void);

/************************* PORTS ****************************/

void Port_Init(void)
{
		//PORT A GROUP
	    //OUT OUT
		//RUN ERR ADDR22 ADDR21 ADDR20 ADDR19 ADDR18 ADDR17 ADDR16 ADDR0		      
//rPCONA    0,  0,     1,     1,     1,     1,     1,     1,     1,    1,
//rPDATA    1,  1,     0,     0,     0,     0,     0,     0,     0,    0, 
		rPCONA=0x0ff;
		rPDATA=0x300;		         //0�϶� ON, 1�϶� OFF -- �ʱⰪ�� OFF

		//PORT B GROUP
		//    OUT     OUT     OUT         OUT   OUT   OUT
        //Conrast Conrast Conrast nGCS2 TCom2 TCom1 TCom0 nSRAS nSCAS SCLK SCKE
//rPCONB        0,      0,      0,    1,    0,    0,    0,    1,    1,   1,   1, 
//rPDATB        0,      0,      0,    0,    1,    1,    1,    0,    0,   0,   0, 
		rPCONB=0x08f;
		rPDATB=0x070;		

		//PORT C GROUP
		//                                   OUT  OUT INPUT INPUT INPUT INPUT INPUT INPUT INPUT INPUT
		//nCTS0 nRTS0 RxD1 TxD1 nCTS1 nRTS1 DIR0 DIR1 TRet7 TRet6 TRet5 TRet4 TRet3 TRet2 TRet1 TRet0
//rPCONC     11,   11,  11,  11,   11,   11,  01,  01,   00,   00,   00,   00,   00,   00,   00,   00,
//rPDATC      0,    0,   0,   0,    0,    0,   0,   0,    0,    0,    0,    0,    0,    0,    0,    0,
        //No Pull-up ( ����� ȸ�ο��� Pull up, TRet�� Pull-up �ϸ� �ȵ� )             		                 
//rPUPC       1,    1,   1,   1,    1,    1,   1,   1,    1,    1,   1,   1,    1,    1,   1,   1,  1,
		rPCONC=0xfff50000;
		rPDATC=0x0000;    
		rPUPC=0xffff;


		//PORT D GROUP
		//VFRAME VM VLINE VCLK VD3 VD2 VD1 VD0
//rPCOND      10,10,   10,	10, 10,	10, 10,	10,  
		//No Pull-up ( In/Out �� ������ ����� ���ÿ��� Pull-up�� �Һ��������� ������ ) 
//rPDATD       1, 1,    1,   1,  1,  1,  1,  1,
		rPCOND=0xaaaa;	
		rPDATD=0xff;
		rPUPD=0xff;

		//                 INPUT INPUT INPUT   Clk  OUT                 OUT
		//Reserved(ENDIAN) TRet8 TRet9 TRet10 TOUT1 Buz RxD0 TxD0 BackLight
//rPCONE                00,	  00,   00,    00,   10, 01,  10,  10,       01,
//rPDATE                No,    0,    0,     0,    0,  0,   0,   0,        1, 
        //No Pull-up
//rPUPE                        1,    1,     1,    1,  1,   1,   1,        1,    		
	    rPCONE=0x00269;	
		rPDATE=0x001;		//Common Data(default 1)
		rPUPE=0xff;

		//PORT F GROUP
		//   OUT    OUT    OUT  INPUT   OUT   OUT   OUT IICSDA IICSCL
		//Tcom13 Tcom14 Tcom15 TRet11 Tcom4 Tcom5 Tcom3 IICSDA IICSCL
//rPCONF     001,   001,   001,   000,   01,   01,   01,    10,    10
//rPDATF       1,     1,     1,     0,    1,    1,    1,     0,     0,    
        //No Pull-up		
//rPUPF        1,     1,     1,     1,    1,    1,    1,     1,     1,    		
		rPCONF=0x9215a;
		rPDATF=0x1dc;		//Common Data(default 1)
		rPUPF=0xff;

		//PORT G GROUP
		//R/W-Int Tcom12 Tcom11 Tcom10 Tcom9 Tcom8 Tcom7 Tcom6
		//   EINT    OUT    OUT    OUT   OUT   OUT   OUT   OUT
//rPCONG       11,    01,    01,    01,   01,   01,   01,   01,
//rPDATG        0,     1,     1,     1,    1,    1,    1,    1,
        //No Pull-up
//rPUPG         1,     1,     1,     1,    1,    1,    1,    1,
//		rPCONG=0xd555;
		rPCONG=0xd555;
		rPDATG=0x7f;		//Common Data(default 1)
		rPUPG=0xff;		//Common Data(default 1)
//		EXTINT
		// EINT7  EINT6  EINT5  EINT4  EINT3  EINT2  EINT1  EINT0
		//0  010 0  000 0  000 0  000 0  000 0  000 0  000 0  000
		//Fall-Int
		rEXTINT= 0x20000000;

//A/D Prescaler Set
		rADCPSR=20;				// PreScaler for ADC

//Non Cash Area(Flash Data Area)
		rNCACHBE0= (0x200 << 16) | 0x00b0;	//B0000->200000(UnCash)

#ifdef	LP_S044
//Non Cash Area(GLP IO)
		rNCACHBE1= (0xe010 << 16) | 0xe000;
#endif

}


/************************* UART ****************************/

//static int whichUart=0;

//void Uart_Init(int mclk,int baud)
//{
//    int i;
//    if(mclk==0) mclk=MCLK;
    
//UART0
//    rUFCON0=0x0;     	// FIFO Disable
//    rUMCON0=0x1;		//RTS-ON    
    
/*    rULCON0=0x3;*/     	//Normal,No parity,1 stop,8 bit
//    rULCON0=0x2b;     	//Normal,Even parity,1 stop,8 bit
//    rUCON0=0x245;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
//    rUBRDIV0=( (int)(mclk/16./baud + 0.5) -1 );

//UART1
//#ifdef	OLD
//    rUFCON1=0x57;	// FIFO Enable	
//    rUMCON1=0x0;
    
//    rULCON1=0x3;	//Normal,No parity,1 stop,8 bit
//    rUCON1=0x2c5;
//    rUBRDIV1=( (int)(mclk/16./baud + 0.5) -1 );
//#endif
//    for(i=0;i<100;i++);
//}

void	Usrt0TxMode(int mode)
{
	if(mode == 0){
//	    rUCON0=0x245;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
	    rUCON0=0x0c1;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
	}else{
//	    rUCON0=0x041;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
	    rUCON0=0x2c5;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
	}
}
void	Usrt1TxMode(int mode)
{
	if(mode == 0){
//	    rUCON1=0x245;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
	    rUCON1=0x0c1;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
	}else{
//	    rUCON1=0x041;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
	    rUCON1=0x2c5;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
	}
}
//void Uart_Select(int ch)
//{
//    whichUart=ch;
//}


void Uart_SendByte0(int data)
{
	while(!(rUTRSTAT0 & 0x2)); //Wait until THR is empty.
//	while((rUFSTAT0 & 0x200)); //Wait until THR is empty.
	WrUTXH0(data);
}		
void Uart_SendByte1(int data)
{
	while(!(rUTRSTAT1 & 0x2)); //Wait until THR is empty.
//	while((rUFSTAT1 & 0x200)); //Wait until THR is empty.
	WrUTXH1(data);
}		



/******************** S3C44B0X EV. BOARD LED **********************/

void Led_Display(int data)
{
    rPDATC=(rPDATC&0x7f0) | (data & 0x00f);
}

/************************* Timer ********************************/
//BUZZER,I/O-CLOCK
void Timer01_Init(void)
{
     rTCFG0=(rTCFG0&0xffffff00)|2;			// Prescaler=1/128 for Timer0
     rTCFG1=(rTCFG1&0xfffffff0)|0x00;			// Mux=1/2 for Timer0
     rTCNTB0=4000-1;						// (1/Timer0=1/(66.0000/8/2) ) * (rTCNTB0-1) = 2ms 
     rTCMPB0=rTCNTB0/3-1;

     //rTCNTB1=5-1;							// (1/Timer1=1/(66.0000/8/2) ) * (rTCNTB1-1) = 1us 
     rTCNTB1=88;							// (1/Timer1=1/(66.0000/8/2) ) * (rTCNTB1-1) = 1us 
     rTCMPB1=rTCNTB1/2;

//     rTCNTB1=  37038,  rTCMPB1= 18519  :  100Hz, 10mS, Duty = 50 %
//     rTCNTB1= 1850,  rTCMPB1= 925  :  2KHz, 500uS, Duty = 50 %
//     rTCNTB1= 739,  rTCMPB1= 370  :  5KHz, 200uS, Duty = 50 %
//     rTCNTB1= 368,  rTCMPB1= 184  :  10KHz, 100uS, Duty = 50 %
//     rTCNTB1= 184,  rTCMPB1= 92  :  20KHz, 50uS, Duty = 50 %
//     rTCNTB1= 92,  rTCMPB1= 46  :  40KHz, 25uS, Duty = 50 %
//     rTCNTB1= 45,  rTCMPB1= 22  :  80KHz, 12.5uS, Duty = 50 %
//     rTCNTB1= 22,  rTCMPB1= 11  :  160KHz, 25uS, Duty = 50 %
//     rTCNTB1= 11,  rTCMPB1= 5  :  320KHz, 25uS, Duty = 50 %
//     rTCNTB1= 3,  rTCMPB1= 1  :  640KHz, 25uS, Duty = 50 %

     rTCON|=0x0202;     
     rTCON=(rTCON&0xfffff0f0)|0x0909;			// Interval Mode, Inverter Off, Update	
} // end of Timer01_Init(...)
//Timer(T)	
void Timer3_Init(void)
{
//     rTCFG0=(rTCFG0&0xffff00ff)|(128<<8);	// Prescaler=1/128 for Timer2,Timer3
     rTCFG0=(rTCFG0&0xffff00ff)|(1<<8);	// Prescaler=1/128 for Timer2,Timer3
//     rTCFG0=(rTCFG0&0xffff00ff)|(2<<8);	// Prescaler=1/128 for Timer2,Timer3
     rTCFG1=(rTCFG1&0xffff00ff)|0x00;	// Mux=1/2 for Timer2,Timer3
//2008.04.08
//     rTCNTB3=2578-1;						// Timer3=10ms(66.0000/128/2*1000)
//     rTCNTB3=258-1;						// Timer3=1ms(66.0000/128/2*1000)
//     rTCNTB3=10430;						// Timer3=1ms(66.0000/128/2*1000)
     rTCNTB3=16667;						// Timer3=1ms(66.0000/128/2*1000)
     rTCMPB3=rTCNTB3/2;
										// Low=rTCNTB3-rTCMPB3
// time 1ms Setting  2009.10.22.


     rTCON|=0x00020000;						// Timer3(Update TCNTB3)     
     rTCON=(rTCON&0xfff0ffff)|0x00090000;	// Interval Mode, Inverter Off, Update	
	
} // end of Timer3_Init(...)	
//Interpreter,System Clock
void Timer45_Init(void)
{
     rTCFG0=(rTCFG0&0xff00ffff)|(128<<16);	// Prescaler=1/128 for Timer4,Timer5
     rTCFG1=(rTCFG1&0xff00ffff)|0x00;	// Mux=1/2 for Timer4,Timer5
     rTCNTB4=258-1;						// Timer4=1ms(66.0000/128/2*1000) 
//     rTCNTB4=516-1;						// Timer4=2ms(66.0000/128/2*1000) 
//     rTCMPB4=rTCNTB4-1;

     rTCNTB5=2578-1;					// Timer5=10ms(66.0000/128/2*10000)
//     rTCNTB5=258-1;					// Timer5=1ms(66.0000/128/2*10000)

     rTCON|=0x02200000;						// Timer4,Timer5(Update TCNTB4,5)     
     rTCON=(rTCON&0xf00fffff)|0x05900000;	// Interval Mode, Inverter Off, Update	
	
} // end of Timer45_Init(...)
unsigned char Uart0_RxInt(void)
{
	unsigned char	data;

    data= RdURXH0();
	return(data);
}
unsigned char Uart1_RxInt(void)
{
	unsigned char	data;

    data= RdURXH1();
	return(data);
}
#ifndef	WIN32
extern	void __irq _SystemClockInterruptHandler(void);
extern	void __irq _Sci0RXInterruptHandler( void );
extern	void __irq _Sci0TXInterruptHandler( void );
extern	void __irq _Sci1RXInterruptHandler( void );
extern	void __irq _Sci1ERInterruptHandler( void );
extern	void __irq _Sci1TXInterruptHandler( void );
extern	void __irq _PlcInterruptHandler( void );
extern	void __irq _RtcTikHandler(void);
extern	void __irq _PlcTimerInterruptHandler(void);
extern	void __irq _IoInterruptHandler(void);
#else
extern	void _SystemClockInterruptHandler(void);
extern	void _Sci0RXInterruptHandler( void );
extern	void _Sci0TXInterruptHandler( void );
extern	void _Sci1RXInterruptHandler( void );
extern	void _Sci1ERInterruptHandler( void );
extern	void _Sci1TXInterruptHandler( void );
extern	void _PlcInterruptHandler( void );
extern	void _RtcTikHandler(void);
extern	void _PlcTimerInterruptHandler(void);
extern	void _IoInterruptHandler(void);
#endif
void	ClearPlcTime(void);
void Isr_Init(void)
{
    rINTCON=0x5;    //Non-vectored,IRQ enable,FIQ disable 
    rINTMOD=0x0;    //All=IRQ mode

	RtcInit();

    pISR_TIMER5=(unsigned)_SystemClockInterruptHandler;		// Timer5 Match ISR(Interrupt Service Routine)
    pISR_URXD0=(unsigned)_Sci0RXInterruptHandler;
	pISR_UTXD0= (unsigned)_Sci0TXInterruptHandler;
    pISR_URXD1=(unsigned)_Sci1RXInterruptHandler;
	pISR_UTXD1= (unsigned)_Sci1TXInterruptHandler;
	pISR_UERR01= (unsigned)_Sci1ERInterruptHandler;
    pISR_TICK=(unsigned)_RtcTikHandler;		
#ifdef	LP_S044

	ClearPlcTime();
	pISR_TIMER4= (unsigned)_PlcInterruptHandler;			// Plc Task Int(1ms)
	pISR_TIMER3= (unsigned)_PlcTimerInterruptHandler;		// Plx Timer Int(10ms)
	pISR_EINT4567= (unsigned)_IoInterruptHandler;
//		IntMaskData= (BIT_EINT4567|BIT_TICK|BIT_TIMER3|BIT_TIMER4|BIT_TIMER5|BIT_URXD0|BIT_URXD1|BIT_UERR01|BIT_GLOBAL);
	IntMaskData= (BIT_TICK|BIT_TIMER3|BIT_TIMER4|BIT_TIMER5|BIT_URXD0|BIT_URXD1|BIT_UERR01|BIT_GLOBAL);
#endif
#ifdef	GP_S044
	IntMaskData= (BIT_TICK|BIT_TIMER5|BIT_URXD0|BIT_URXD1|BIT_UERR01|BIT_GLOBAL);
#endif
#ifdef	GP_S057
	IntMaskData= (BIT_TICK|BIT_TIMER5|BIT_URXD0|BIT_URXD1|BIT_UERR01|BIT_GLOBAL);
#endif
//	IntMaskData= (BIT_TIMER0|BIT_URXD0|BIT_GLOBAL);
    rINTMSK=~IntMaskData;

} // end of Isr_Init(...)
void	SetIntMask(int MskData)		//Mask Off
{
	IntMaskData |= MskData;
    rINTMSK=~IntMaskData;
}
void	ReSetIntMask(int MskData)	//Mask On
{
	IntMaskData &= ~MskData;
    rINTMSK=~IntMaskData;
}
/************************* PLL ********************************/
void ChangePllValue(int mdiv,int pdiv,int sdiv)
{
    rPLLCON=(mdiv<<12)|(pdiv<<4)|sdiv;
}
unsigned int	GetCountTimer4(void)
{
	return(rTCNTO4);
}

/************************* General Library **********************/

void Cache_Flush(void)
{
    int i,saveSyscfg;
    
    saveSyscfg=rSYSCFG;

    rSYSCFG=SYSCFG_0KB; 		      
    for(i=0x10004000;i<0x10004800;i+=16)    
    {					   
	*((int *)i)=0x0;		   
    }
    rSYSCFG=saveSyscfg; 			    
}

extern	void Lcd_Init(void);
extern	void Rtc_Set(char hour, char min, char sec);
//I2C Contorol
void	I2CInit(void)
{
	//Control
	rIISCON= 0;
	//Mode
	rIISMOD= 0;

}

void	HardInitial(void)
{
	ChangePllValue(0x0c, 0x84, 0x00);		// Fin=20.000MHz, Fout=66.0000MHz=(x*1.8432)MHz    
	rSYSCFG=CACHECFG;   
	Port_Init();    				// Init I/O Ports
	Timer01_Init();					//BUZER,I/O
	Timer3_Init();					//TIMER(T0?)
	Timer45_Init();					//INTERPRETER,SystemClock

	Lcd_Init();					//LCD Initialize
//	Rtc_Set(14,0,0);			//Rtc Initialize

	Isr_Init();					// Init Interrupts    
	
}
