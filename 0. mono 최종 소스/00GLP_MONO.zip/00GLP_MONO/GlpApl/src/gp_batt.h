void		vButDispMode(int* iScreenNo);
