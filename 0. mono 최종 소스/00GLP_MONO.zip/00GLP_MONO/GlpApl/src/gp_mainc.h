void		vMainCallSet(int* iScreenNo);
int iMainCallSetValue(int iKeyVal);
