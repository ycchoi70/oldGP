void	SetBarGraph_Func(int iDispOrder);
int	DrawBarGraph_Func(int mode,_BARGRAPH_EVENT_TBL* BarGraphEventTbl,int iDispOrder);
void	BarGraphDispWatch(int iOrder);
