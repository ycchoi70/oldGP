/****************************************/
/*	PLC Backup Area						*/
/****************************************/
#include	"sgt.h"
	/* PLC Data Area */
	PLC_DATA_SRAM	PlcDataSram;
