/********************************************************************************/
/* �� �� �� : Gp_AlarmListTask.cpp												*/
/* ��    �� : NumericTask														*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"

/********************************************************************************/
/* �� �� �� : DrawAList_Task													*/
/* ��    �� : Alarm List ������ �ص��Ͽ� ȭ�鿡 ���						    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetAlarmList_Func(int iDispOrder)
{
	_ALARM_LIST_EVENT_TBL*	 AlarmListEventTbl;
	AlarmListEventTbl= (_ALARM_LIST_EVENT_TBL*)TakeMemory(sizeof(_ALARM_LIST_EVENT_TBL));
	DrawAlarmList_Func(0,AlarmListEventTbl,iDispOrder);
	FreeMail((char *)AlarmListEventTbl);
}
int DrawAlarmList_Func(int mode,_ALARM_LIST_EVENT_TBL* AlarmListEventTbl, int iDispOrder)
{
/*	int					iTagSizeOf;*/
	int					iOffset;
	int					i;
	int					iDevAddress;
	unsigned char		*buffer;
	
	buffer= ScreenTagData[iDispOrder].TagPos;
	/*	_ALARM_LIST_EVENT_TBL*	 AlarmListEventTbl;*/

	iOffset		= 0;
	i			= 0;

/*
	if(CheckMailBox(sizeof(_ALARM_LIST_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_ALARM_LIST_EVENT_TBL));
	AlarmListEventTbl= (_ALARM_LIST_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)AlarmListEventTbl, 0x00, sizeof(_ALARM_LIST_EVENT_TBL));
	if(mode == 0){
		iAlarmListDisCnt = 0;
		iPositionVal	= 0;	/* AlarmList �� �����ؾ� �� ��ġ��	*/
		iAlarmOnOff		= 0;	/* AlarmList �� ���� OnOff ��		*/
	}
/*	AlarmListEventTbl = (_ALARM_LIST_EVENT_TBL*)TakeMemory(sizeof(_ALARM_LIST_EVENT_TBL));	
	memset((char *)AlarmListEventTbl, 0x00, sizeof(_ALARM_LIST_EVENT_TBL));
*/
/*	iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
	iTagSizeOf += (unsigned int)buffer[1] & 0xff;	
*/	
	/* 20020808 choijh add */
/*
	AlarmListEventTbl->sX  = (unsigned int)(buffer[6] << 0x08);
	AlarmListEventTbl->sX += (unsigned int)buffer[7] & 0xff;

	AlarmListEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
	AlarmListEventTbl->sY += (unsigned int)buffer[9] & 0xff;

	AlarmListEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
	AlarmListEventTbl->eX += (unsigned int)buffer[11] & 0xff;

	AlarmListEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
	AlarmListEventTbl->eY += (unsigned int)buffer[13] & 0xff;	
*/
	AlarmListEventTbl->iFontSizeH	= (unsigned int)buffer[14];
	AlarmListEventTbl->iFontSizeV	= (unsigned int)buffer[15];
	AlarmListEventTbl->iFrameColor	= (unsigned int)buffer[16];
	AlarmListEventTbl->iPlateColor	= (unsigned int)buffer[17];
	AlarmListEventTbl->iNumber		= (unsigned int)buffer[18];
	AlarmListEventTbl->iSort		= (unsigned int)buffer[19];
	AlarmListEventTbl->iDevicePnt	= (unsigned int)(buffer[20] << 0x08);
	AlarmListEventTbl->iDevicePnt	+= (unsigned int)buffer[21] & 0xff;
	AlarmListEventTbl->iCommentStartNo = (unsigned int)(buffer[22] << 0x08);
	AlarmListEventTbl->iCommentStartNo += (unsigned int)buffer[23] & 0xff;

	CommonArea.SystemDev.lAlarm_Dev.DevCnt = AlarmListEventTbl->iDevicePnt;
	iOffset = 24;
	/*------------------------------------------------------------*/
	if(mode == 0){
		GetDeviceSet((buffer+iOffset),
					CommonArea.SystemDev.lAlarm_Dev.DevName,
					&(iDevAddress));
		CommonArea.SystemDev.lAlarm_Dev.DevAdd = iDevAddress;
	}
	/*-------------------------------------------------------------*/
	iOffset += 5;
	AlarmListEventTbl->iDetailDispChecked = (unsigned int)buffer[iOffset];
	iOffset++;
	if((buffer[iOffset] & 0x01) == 0x01){
		AlarmListEventTbl->iStoreMemoryFlag	= CHECKED;
		if(mode == 0){
			memset(CommonArea.SystemDev.lAlarm_Dev.DevName,0x00,3);
			CommonArea.SystemDev.lAlarm_Dev.DevAdd = 0;
			for(i=0;i<16;i++){
				if(iStoreScreenNum[i] == iNowScreenNum){
					AlarmListEventTbl->iStoreMemoryVal = i; /* StoreMemory Point Val*/
					ScreenTagData[iDispOrder].uu.AlarmList.StoreMemNo= i;	/* 060921 */
				}
			}
		}
	}else{
		AlarmListEventTbl->iStoreMemoryFlag	= UNCHECKED;
	}
	if((buffer[iOffset] & 0x02) == 0x02){
		AlarmListEventTbl->iScrollOnFlag 	= CHECKED;
	}else{
		AlarmListEventTbl->iScrollOnFlag 	= UNCHECKED;
	}
	if((buffer[iOffset] & 0x04) == 0x04){
		AlarmListEventTbl->iDisplayDateFlag = CHECKED;
	}else{
		AlarmListEventTbl->iDisplayDateFlag = UNCHECKED;
	}
	iOffset++;
	if((unsigned int)buffer[iOffset] != 0x00){
/*		AlarmListEventTbl->BeShapeUsed = CHECKED;*/
		AlarmListEventTbl->ShapeNo = (unsigned int)buffer[++iOffset];
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed= CHECKED;
		}
	}
	else{
/*		AlarmListEventTbl->BeShapeUsed = UNCHECKED;*/
		AlarmListEventTbl->ShapeNo = 0;
		iOffset++;
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed= UNCHECKED;
		}
	}
	iOffset++;
	if((unsigned int)buffer[iOffset] != 0){ 
		AlarmListEventTbl->iFontSizeH = 0;
		AlarmListEventTbl->iFontSizeV = 0;	//20101207
	}
	AlarmListEventTbl->iDevicePointers	= (unsigned int)(buffer[++iOffset] << 0x08);
	AlarmListEventTbl->iDevicePointers += (unsigned int)buffer[++iOffset] & 0xff;
	AlarmListEventTbl->iStorgeChecked	= (unsigned int)buffer[++iOffset];
	if(AlarmListEventTbl->iStorgeChecked != 0){
		iOffset++;
		if(AlarmListEventTbl->iStoreMemoryFlag	!= CHECKED){
			/*------------------------------------------------------------*/
			if(mode == 0){
				GetDeviceSet((buffer+iOffset),
							CommonArea.SystemDev.lAlarmCnt_Dev.DevName,
							&(iDevAddress));
				CommonArea.SystemDev.lAlarmCnt_Dev.DevAdd = iDevAddress;
			}
			/*-------------------------------------------------------------*/
		}
	}
	if(mode == 0){
		AlarmListDispCnt++;
	}
/*	IventTableCnt++;*/
	return(0);
}
/********************************************************************************/
/* �� �� �� : GetLineCnt														*/
/* ��    �� : Alarm List Format Size�� �´� Line �� ���					    */
/* ��    �� : 																	*/
/* ��    �� :																	*/
/* �� �� �� : 2003�� 3�� 11�� (ȭ)(������)										*/
/* �� �� �� : �� �� ��															*/
/* ��    �� : 																	*/
/********************************************************************************/
int	 GetLineCnt(int iFontSizeH, int iFontSizeV, int sY,  int eY)
{
	int iTemp;
	int i;
	int RetVal;

	iTemp = 0;
	i = eY+1 - sY;

	switch(iFontSizeV){
	case 0:
	case 5:
		iTemp = 8;
		break;
	case 2:
		iTemp = 32;
		break;
	case 3:
		iTemp = 48;
		break;
	case 4:
		iTemp = 64;
		break;
	case 1:
	default:
		iTemp = 16;
		break;
	}
	RetVal = (int)i/iTemp;
	return RetVal;
}
/********************************************************************************/
/* �� �� �� : AlarmListDispWatch												*/
/* ��    �� : Alarm List�� sort�� ���߾ ȭ�鿡 ���						    */
/* ��    �� : iOrder																	*/
/* ��    �� :																	*/
/* �� �� �� : 2003�� 3�� 11�� (ȭ)(������)										*/
/* �� �� �� : �� �� ��															*/
/* ��    �� : 																	*/
/********************************************************************************/
void AlarmListDispWatch(int iOrder)
{
/*	T_MAIL			*mp;*/
	int				j, x;
	int				sX;
	int				sY;
	int				eX;
	int				eY;
	int				iCnt;
	char*			cCommentBuffer;			/* Comment����� */	
	char*			cDispBuffer;			/* ��¿���� */	
	int				iFontSizeV;
	int				iFontSizeH;
	int				iDispLine;
	int				Back_Color;	
	int				T_Type;
	int				iNum;
	char			cRetVal[3];
	DEV_DATA		AlarmListWriteDev;
	char			cCommentName[12];
	short			iDisplayCnt[256];		/* Shot�� ����... */
	short			iBuffer;
	short			iCommentNo;
	int				iLen;
	int				iColor;
	short			iStoreMemory;
	short			iTotalCnt;
	short			iShapeSize;
	_ALARM_LIST_EVENT_TBL*	 AlarmListEventTbl;
	int				iwColor,iwBack;

/*	AlarmListEventTbl= (_ALARM_LIST_EVENT_TBL*)IventTable[iOrder];*/
	AlarmListEventTbl= (_ALARM_LIST_EVENT_TBL*)TakeMemory(sizeof(_ALARM_LIST_EVENT_TBL));
	DrawAlarmList_Func(1,AlarmListEventTbl,iOrder);
	sX			= 0;
	sY			= 0;
	eX			= 0;
	eY			= 0;
	iCnt		= 0;
	iLen		= 0;
	iShapeSize	= 0;

	cCommentBuffer = (char *)TakeMemory(41);
	memset(cCommentBuffer, 0x00, 41);
	memset(cCommentName, 0x00, sizeof(cCommentName));
	memset(cRetVal,0x00,sizeof(cRetVal));
	iFontSizeV = AlarmListEventTbl->iFontSizeV;
	iFontSizeH = AlarmListEventTbl->iFontSizeH;
	sX = ScreenTagData[iOrder].sX;
	sY = ScreenTagData[iOrder].sY;
	eX = ScreenTagData[iOrder].eX;
	eY = ScreenTagData[iOrder].eY;

	iCommentNo = AlarmListEventTbl->iCommentStartNo-1;
/*	if(iOnSignalStart == ON){*/
		if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){
			iShapeSize = DrawShape(AlarmListEventTbl->ShapeNo, 
				sX, 
				sY, 
				ScreenTagData[iOrder].eX, 
				ScreenTagData[iOrder].eY, 
				AlarmListEventTbl->iFrameColor,
				AlarmListEventTbl->iPlateColor);
			sX=sX+iShapeSize;
			sY=sY+iShapeSize;
		}

		iDispLine = GetLineCnt(iFontSizeH, iFontSizeV, sY, (eY-iShapeSize)); /* Display �Ҽ� �ִ� Line �� */  

		for(j=0;j<256;j++)
			iDisplayCnt[j] = -1;
		iCnt = 0;			/* ON �� AlarmList�� ����.(Comment Data�� �����ϴ�) */
		if(AlarmListEventTbl->iStoreMemoryFlag == UNCHECKED){
			switch(AlarmListEventTbl->iSort){					/* Sort Format�� ���߾ Display Setting */
				case ASCENDING:										/* Device ���� */
					for(j=0;j<AlarmListEventTbl->iDevicePnt;j++){
						if(CommonArea.AlarmListRec[j].OnOff == 1 && iCommentPointOnOff(j+iCommentNo+1)  > -1){	/* AlarmList On Data ��	*/
							iDisplayCnt[iCnt] = j;						/* On �϶� ��ġ ��			*/
							iCnt++;
						}
					}
					break;
				case DESCENDNIG:							/* Devicd ������ */
					for(j=(AlarmListEventTbl->iDevicePnt)-1;j>=0;j--){
						if(CommonArea.AlarmListRec[j].OnOff == 1 && iCommentPointOnOff(j+iCommentNo+1)  > -1){	/* AlarmList On Data ��	*/
							iDisplayCnt[iCnt] = j;						/* On �϶� ��ġ ��			*/
							iCnt++;
						}
					}
					break;		
				case OLDEST:								/* ���� On�� Data ������ */
					for(j=0;j<AlarmListEventTbl->iDevicePnt;j++){
						if(CommonArea.AlarmListRec[j].OnOff == 1 && iCommentPointOnOff(j+iCommentNo+1)  > -1){	/* AlarmList On Data ��	*/
							iDisplayCnt[iCnt] = j;						/* On �϶� ��ġ ��			*/
							iCnt++;
						}
					}	
					if(iCnt > 1){
						for(j=0;j<iCnt-1;j++){
							for(x=1+j;x<iCnt;x++){
								if(CommonArea.AlarmListRec[iDisplayCnt[j]].DateTime > CommonArea.AlarmListRec[iDisplayCnt[x]].DateTime){
									iBuffer = iDisplayCnt[j];
									iDisplayCnt[j] = iDisplayCnt[x];
									iDisplayCnt[x] = iBuffer;
								}
							}
						}
					}
					break;
				case LATEST:								/* ���߿� On�� Data ������ */
					for(j=0;j<AlarmListEventTbl->iDevicePnt;j++){
						if(CommonArea.AlarmListRec[j].OnOff == 1 && iCommentPointOnOff(j+iCommentNo+1)  > -1){	/* AlarmList On Data ��	*/
							iDisplayCnt[iCnt] = j;						/* On �϶� ��ġ ��			*/
							iCnt++;
						}
					}	
					if(iCnt > 1){
						for(j=0;j<iCnt-1;j++){
							for(x=1+j;x<iCnt;x++){
								if(CommonArea.AlarmListRec[iDisplayCnt[j]].DateTime < CommonArea.AlarmListRec[iDisplayCnt[x]].DateTime){
									iBuffer = iDisplayCnt[j];
									iDisplayCnt[j] = iDisplayCnt[x];
									iDisplayCnt[x] = iBuffer;
								}
							}
						}
					}
					break;		
			}
			iTotalCnt = CommonArea.AlarmlistTotalCnt;
		}else{
/* 060921			iStoreMemory = AlarmListEventTbl->iStoreMemoryVal;*/
			iStoreMemory= ScreenTagData[iOrder].uu.AlarmList.StoreMemNo;	/* 060921 */
			switch(AlarmListEventTbl->iSort){					/* Sort Format�� ���߾ Display Setting */
				case ASCENDING:										/* Device ���� */
					for(j=0;j<AlarmListEventTbl->iDevicePnt;j++){
						if(CommonArea.StordMem[iStoreMemory].Alarm.StoreAlarmListRec[j].OnOff == 1 && iCommentPointOnOff(j+iCommentNo+1)  > -1){	/* AlarmList On Data ��	*/
							iDisplayCnt[iCnt] = j;						/* On �϶� ��ġ ��			*/
							iCnt++;
						}
					}
					break;
				case DESCENDNIG:							/* Devicd ������ */
					for(j=(AlarmListEventTbl->iDevicePnt)-1;j>=0;j--){
						if(CommonArea.StordMem[iStoreMemory].Alarm.StoreAlarmListRec[j].OnOff == 1 &&
							iCommentPointOnOff(j+iCommentNo+1)  > -1){	/* AlarmList On Data ��	*/
							iDisplayCnt[iCnt] = j;						/* On �϶� ��ġ ��			*/
							iCnt++;
						}
					}
					break;		
				case OLDEST:								/* ���� On�� Data ������ */
					for(j=0;j<AlarmListEventTbl->iDevicePnt;j++){
						if(CommonArea.StordMem[iStoreMemory].Alarm.StoreAlarmListRec[j].OnOff == 1 && 
							iCommentPointOnOff(j+iCommentNo+1)  > -1){	/* AlarmList On Data ��	*/
							iDisplayCnt[iCnt] = j;						/* On �϶� ��ġ ��			*/
							iCnt++;
						}
					}	
					if(iCnt > 1){
						for(j=0;j<iCnt-1;j++){
							for(x=1+j;x<iCnt;x++){
								if(CommonArea.StordMem[iStoreMemory].Alarm.StoreAlarmListRec[iDisplayCnt[j]].DateTime > CommonArea.StordMem[iStoreMemory].Alarm.StoreAlarmListRec[iDisplayCnt[x]].DateTime){
									iBuffer = iDisplayCnt[j];
									iDisplayCnt[j] = iDisplayCnt[x];
									iDisplayCnt[x] = iBuffer;
								}
							}
						}
					}
					break;
				case LATEST:								/* ���߿� On�� Data ������ */
					for(j=0;j<AlarmListEventTbl->iDevicePnt;j++){
						if(CommonArea.StordMem[iStoreMemory].Alarm.StoreAlarmListRec[j].OnOff == 1 &&
							iCommentPointOnOff(j+iCommentNo+1)  > -1){	/* AlarmList On Data ��	*/
							iDisplayCnt[iCnt] = j;						/* On �϶� ��ġ ��			*/
							iCnt++;
						}
					}	
					if(iCnt > 1){
						for(j=0;j<iCnt-1;j++){
							for(x=1+j;x<iCnt;x++){
								if(CommonArea.StordMem[iStoreMemory].Alarm.StoreAlarmListRec[iDisplayCnt[j]].DateTime < CommonArea.StordMem[iStoreMemory].Alarm.StoreAlarmListRec[iDisplayCnt[x]].DateTime){
									iBuffer = iDisplayCnt[j];
									iDisplayCnt[j] = iDisplayCnt[x];
									iDisplayCnt[x] = iBuffer;
								}
							}
						}
					}
					break;		
			}
			iTotalCnt = CommonArea.StordMem[iStoreMemory].Alarm.TotalCnt;
		}
		iCommentNo++;

		/* TouchKey --------------------------------- */
		if(iMainKeyCode >= C_AP){
			if(AlarmListEventTbl->iNumber != SINGLE ){
				/* 0: Comment Window */  
				switch(iMainKeyCode){ 
					/* ����ǥ�� */	
					case C_AP:
						iAlarmOnOff = 1;
						iPositionVal = 0;
						break;
					/* �����Ұ� */
					case C_DAP:
						iAlarmOnOff = 0;
						iPositionVal = 0;
						break;
					/* ��������� �̵� */
					case UP_DISP:
						if(AlarmListEventTbl->iScrollOnFlag == CHECKED)
						{
							if(iPositionVal == 0 && iAlarmListDisCnt > 0 && iAlarmOnOff == 1)
								iAlarmListDisCnt--;
							
							if((iPositionVal > 0) && iAlarmOnOff == 1)
								iPositionVal--;
						}
						break;
					/* ��������� �̵� */
					case DOWN_DISP:
						if(AlarmListEventTbl->iScrollOnFlag == CHECKED)
						{						
							if(iPositionVal == (iDispLine-1) && 
								iAlarmListDisCnt < (iTotalCnt-iDispLine) && 
								iAlarmOnOff == 1)
									iAlarmListDisCnt++;
							
							if(((iPositionVal+1) < iCnt) && iAlarmOnOff == 1 && ((iPositionVal+1) < iDispLine))
								iPositionVal++;
						}
						break;
					/* Detailed display	*/
					case DETAIL:
						if(AlarmListEventTbl->iDetailDispChecked != 0x00 && iAlarmOnOff == 1){
							iNum = AlarmListEventTbl->iDevicePointers + iDisplayCnt[iPositionVal+iAlarmListDisCnt];

							if(AlarmListEventTbl->iDetailDispChecked == 1 && ComWinKey.iVal == 0)			/* Comment Window display */
							{
								if(iCommentPointOnOff(iNum)  > -1)
								{
									SendInitTask(INI_COMMENT,iNum);
								}
							}
							else if(AlarmListEventTbl->iDetailDispChecked == 2)		/* Base screen ȭ�� �̵� */
							{
								if(CheckSecurityLevel(iNum) == 0){
									AlarmListWriteDev.DevFlag = 1;	
									AlarmListWriteDev.DevName[0] = CommonArea.SystemDev.Switch_Base_DevName[0];
									AlarmListWriteDev.DevName[1] = CommonArea.SystemDev.Switch_Base_DevName[1];
									AlarmListWriteDev.DevName[2] = 0x00;
									AlarmListWriteDev.DevAddress = CommonArea.SystemDev.Switch_Base_DevAdd;
									AlarmListWriteDev.DevCnt = 1;
									AlarmListWriteDev.DevData = cRetVal;
									memset(cRetVal,0x00,sizeof(cRetVal));
									//061124
//									cRetVal[1] = (iNum >> 8) & 0xff;
//									cRetVal[0] = iNum & 0xff;
									cRetVal[0] = (iNum >> 8) & 0xff;
									cRetVal[1] = iNum & 0xff;
									iPreviousScreenNum = iNowScreenNum;
									PLCWrite(&AlarmListWriteDev);
								}else{	/* Password Input 050425 */
									PassWordSettingFg= iNum;
									PassWordSettingChg= 1;
								}
							}
						}
						break;
					/* */
					case RESET:

						break;
				}
				iMainKeyCode = 0x0000;
			}
		}
		/* -------------------------------------------------------------------- */
		/* �� ���� ����ϰ��� �� ��� */
		if(iTotalCnt>0){
			if(AlarmListEventTbl->iNumber == SINGLE){
				if(iDisplayCnt[0] != -1){

					iLen = 40;
					vCommentDataSet(iDisplayCnt[0]+iCommentNo, cCommentBuffer, &iColor, &iLen);
					if(iLen > 40)
						iLen = 40;

					if(AlarmListEventTbl->iDisplayDateFlag == CHECKED){
						cDispBuffer = (char*)TakeMemory(iLen + 21);		/* DataTime -> 20 Null -> 1 */
						memset(cDispBuffer, 0x00, iLen + 21);
							if(AlarmListEventTbl->iStoreMemoryFlag == UNCHECKED)
								vAlarmHistoryTimeSetting((_ALARM_HISTORY_EVENT_TBL*)NULL,cDispBuffer,2,0,iDisplayCnt[0]); /* */
							else
								vAlarmHistoryTimeSetting((_ALARM_HISTORY_EVENT_TBL*)NULL,cDispBuffer,3,iStoreMemory,iDisplayCnt[0]); /* */				
							strncat(cDispBuffer, cCommentBuffer, iLen);

					}else{
						cDispBuffer = (char*)TakeMemory(iLen + 1);
						memset(cDispBuffer, 0x00, iLen + 1);
						strncpy(cDispBuffer, cCommentBuffer, iLen);
					}

					TextSizeCut((ScreenTagData[iOrder].eX - ScreenTagData[iOrder].sX),
						AlarmListEventTbl->ShapeNo,
						AlarmListEventTbl->iFontSizeH,
						AlarmListEventTbl->iFontSizeV,
						cDispBuffer);					
					/* leesi 02/08/26 */
					if(iColor == 0){
						Back_Color	= WHITE;	
						T_Type		= T_FRONT;
					}else{
						Back_Color = BLACK;
						T_Type      = T_OR;
					}

					DotTextOut(sX,
						sY, 
						cDispBuffer, 
						AlarmListEventTbl->iFontSizeH, 
						AlarmListEventTbl->iFontSizeV, 
						T_Type,
						iColor,
						Back_Color);
					FreeMail((char*)cDispBuffer);
				}		
			}
			/* ���� �� ����ϰ��� �� ��� */
			else if(AlarmListEventTbl->iNumber == PLURAL){
				if(iDisplayCnt[0] != -1){
					x = 0;
					if(iCnt>0 && iCnt<=iAlarmListDisCnt+iPositionVal && iAlarmOnOff==1)
					{
						while(iCnt<=iAlarmListDisCnt+iPositionVal)
						{
							if(iPositionVal==0 && iAlarmListDisCnt > 0){
								iAlarmListDisCnt--;
							}
							else{
								iPositionVal--;
							}
						}
					}
					for(j=iAlarmListDisCnt;j<iCnt;j++){

						iLen = 40;
						vCommentDataSet(iDisplayCnt[j]+iCommentNo, cCommentBuffer, &iColor, &iLen);
						if(iLen > 40)
							iLen = 40;

						if(AlarmListEventTbl->iDisplayDateFlag == CHECKED){
							cDispBuffer = (char*)TakeMemory(iLen + 21);		/* DataTime -> 20 Null -> 1 */
							memset(cDispBuffer, 0x00, iLen + 1 + 20);
							if(AlarmListEventTbl->iStoreMemoryFlag == UNCHECKED)
								vAlarmHistoryTimeSetting((_ALARM_HISTORY_EVENT_TBL*)NULL,cDispBuffer,2,0,iDisplayCnt[j]); /* */
							else
								vAlarmHistoryTimeSetting((_ALARM_HISTORY_EVENT_TBL*)NULL,cDispBuffer,3,iStoreMemory,iDisplayCnt[j]); /* */
							strncat(cDispBuffer, cCommentBuffer, iLen);
						}else{
							cDispBuffer = (char*)TakeMemory(iLen + 1);
							memset(cDispBuffer, 0x00, iLen + 1);
							strncpy(cDispBuffer, cCommentBuffer, iLen);
						}
		
						TextSizeCut(ScreenTagData[iOrder].eX - ScreenTagData[iOrder].sX,
							AlarmListEventTbl->ShapeNo,
							AlarmListEventTbl->iFontSizeH,
							AlarmListEventTbl->iFontSizeV,
							cDispBuffer);
						if(x<iDispLine){
							/* leesi02/08/26 */
							if(iColor == 0){
								Back_Color	= WHITE;	
								T_Type		= T_FRONT;
							}else{
								Back_Color = BLACK;
								T_Type      = T_OR;
							}
							/* 040606 */
							if(AlarmListEventTbl->iFontSizeH == 0 || AlarmListEventTbl->iFontSizeV == 0){
								eY = (sY + 8)-1;
							}else{
								eY = (sY + (AlarmListEventTbl->iFontSizeV*16))-1;
							}
/* 050426							AreaClear(sX,sY,eX-iShapeSize,eY,Back_Color);*/
							/**************************/
							DotTextOut(sX,
								sY, 
								cDispBuffer, 
								AlarmListEventTbl->iFontSizeH, 
								AlarmListEventTbl->iFontSizeV, 
								T_Type,
								iColor,
								Back_Color);
							if(iAlarmOnOff == 1 && iPositionVal == x)
							{

								if(AlarmListEventTbl->iFontSizeH == 0 || AlarmListEventTbl->iFontSizeV == 0){
									eY = (sY + 8)-1;
								}else{
									eY = (sY + (AlarmListEventTbl->iFontSizeV*16))-1;
								}
								/* Cursor Pos Revers */
								AreaRevers(sX,sY,eX-iShapeSize,eY);
								if(AlarmListEventTbl->iPlateColor == iColor){
									if(iColor == 0){
										iwColor= BLACK;
										iwBack= WHITE;
									}else{
										iwColor= WHITE;
										iwBack= BLACK;
									}
									T_Type      = T_FRONT;
									DotTextOut(sX,
										sY, 
										cDispBuffer, 
										AlarmListEventTbl->iFontSizeH, 
										AlarmListEventTbl->iFontSizeV, 
										T_Type,
										iwColor,
										iwBack);
								}
							}
							x++;
						}
						FreeMail((char*)cDispBuffer);
						
						switch(AlarmListEventTbl->iFontSizeV){
							case 0:
							case 5:
								sY += 8;
								break;
							case 2:
								sY += 32;
								break;
							case 3:
								sY += 48;
								break;
							case 4:
								sY += 64;
								break;
							case 1:
							default:
								sY += 16;
								break;
						}
					}

				}
			}
		}
/*	}	*/
	FreeMail((char*)cCommentBuffer);
	FreeMail((char *)AlarmListEventTbl);
}
void	TextSizeCut(int iLen, short ShapeNo, short XDot,short YDot, char* cBuffer)
{
	int		iPoint;
	char*	LineData;
	short	i;
	short	iCnt;

	iLen++;
	switch(ShapeNo)
	{
		case 1:
			iLen -= 6;		/* 3 */
			break;
		case 2:
		case 6:
			iLen -= 8;		/* 4 */
			break;
		case 3:
		case 4:
		case 5:
			iLen -= 10;	/* 5 */
			break;
	}
	if(XDot == 0 && YDot == 0){
		iLen = iLen / 6;
	}else if(XDot == 0 || YDot ==0){
		iLen = iLen / 8;
	}else{
		iLen = iLen / (XDot * 8);
	}
	LineData = strchr(cBuffer,0x0D);
	if(((int)LineData) != 0){
		iPoint = ((int)LineData)-((int)cBuffer);
		if(iPoint<iLen)
			iLen = iPoint;
	}
	iPoint = (strlen(cBuffer)-iLen);
	if(iPoint>0)
	{
		iCnt=0;
		memset(cBuffer+iLen,0x00,iPoint);
		for(i=0;i<iLen;i++)
		{
			if((unsigned char)cBuffer[i] < 0x7f && 0x00 < (unsigned char)cBuffer[i])
			{
				iCnt++;
			}
		}
		if(iCnt%2 != iLen%2)
			cBuffer[iLen-1] = 0x00;

	}
}
