/************************************************/
/*	PLC ����M �v���O����(AUTONICS)				*/
/*	2003.5.31									*/
/************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"PlcCommBuff.h"
#include	"mail.h"

/*#define	PLC_TYPE2	1*/

#define	THD 1

#ifndef	WIN32
#pragma	section PlcProc2
#endif



/**************************************/
extern	int	Hex2nBin(char *buff,int cnt);
extern	int	Hex2Bin(char *buff);
extern	unsigned int LHexAsToBin(char *buff, int cnt);
#ifdef	WIN32
extern int __cdecl Delay(int);
extern unsigned int __cdecl ReadSignal(int);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	unsigned char			GpFont[0x200000];
extern	int	SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode);
extern	int	SendPC2PLCData2( int mode );
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#else
#define SGN_PLC		0
#endif

/*ksc20040707*/
int PLC2_DeviceLHFlag;		/* 0�϶� D100 ����̽�, 1�϶� D101 ����̽� 
						   D100���� ��Ž� D100[����], D101[�µ�]
                           D101��   ��Ž� D100[�µ�], D101[����] */
int	PlcRecCnt2;
int	PlcRecCmd2;

/**************************************/


/****************************** for Window **********************/
/********************************************/
/*	�O���֐�								*/
/********************************************/
#ifdef	PLC_TYPE2
#ifdef	WIN32
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
#endif
#else
extern	int	B_Hex2nBin(char *buff,int cnt);
extern	int	B_Hex2Bin(char *buff);
extern	unsigned int B_LHexAsToBin(char *buff, int cnt);
extern	int	B_Delay(int p);
extern	int	B_ReadSignal(int p);
extern	void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	B_PlcDevInit(void);
#endif
#ifdef	WIN32
int	B_SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode)
{
	return(SendRecPLC2(mode,rData,Cnt,rmode));
}
int	B_SendPC2PLCData2( int mode )
{
	return(SendPC2PLCData2(mode ));
}
#endif

#ifdef	WIN32
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#endif
/********************************/
/*	FX Serease					*/
/********************************/
const unsigned char PLC2_CRC8[256]={
   0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41,
   0x9d, 0xc3, 0x21, 0x7f, 0xfc, 0xa2, 0x40, 0x1e, 0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc,
   0x23, 0x7d, 0x9f, 0xc1, 0x42, 0x1c, 0xfe, 0xa0, 0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62,
   0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81, 0x63, 0x3d, 0x7c, 0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff,
   0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5, 0x84, 0xda, 0x38, 0x66, 0xe5, 0xbb, 0x59, 0x07,
   0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58, 0x19, 0x47, 0xa5, 0xfb, 0x78, 0x26, 0xc4, 0x9a,
   0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6, 0xa7, 0xf9, 0x1b, 0x45, 0xc6, 0x98, 0x7a, 0x24,
   0xf8, 0xa6, 0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b, 0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05, 0xe7, 0xb9,
   0x8c, 0xd2, 0x30, 0x6e, 0xed, 0xb3, 0x51, 0x0f, 0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd,
   0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc, 0x92, 0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50,
   0xaf, 0xf1, 0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c, 0x6d, 0x33, 0xd1, 0x8f, 0x0c, 0x52, 0xb0, 0xee,
   0x32, 0x6c, 0x8e, 0xd0, 0x53, 0x0d, 0xef, 0xb1, 0xf0, 0xae, 0x4c, 0x12, 0x91, 0xcf, 0x2d, 0x73,
   0xca, 0x94, 0x76, 0x28, 0xab, 0xf5, 0x17, 0x49, 0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b,
   0x57, 0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4, 0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16,
   0xe9, 0xb7, 0x55, 0x0b, 0x88, 0xd6, 0x34, 0x6a, 0x2b, 0x75, 0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8,
   0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b, 0xa9, 0xf7, 0xb6, 0xe8, 0x0a, 0x54, 0xd7, 0x89, 0x6b, 0x35
};

/* Table of CRC values for high.order byte */
unsigned char PLC2_auchCRCHi[] = {
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
} ;
/* Table of CRC values for low.order byte */
unsigned char PLC2_auchCRCLo[] = {
    0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 
    0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 
    0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 
    0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, 0x11, 0xD1, 0xD0, 0x10, 
    0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 
    0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 
    0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 
    0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, 0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 
    0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 
    0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 
    0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 
    0xB4, 0x74, 0x75, 0xB5, 0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 
    0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 
    0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 
    0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
    0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80, 0x40
} ;


const	char	*PLC2_DevTbl[12]= {
	"P0"
};



/************************************/
/* ���ʏ���							*/
/************************************/
#ifdef	PLC_TYPE2
int	Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
void	Bin2Hex(int data,int cnt,char *buff)
{
	int		i;
	unsigned int AndData;

	AndData= 0x000f;
	for(i= 1; i < cnt; i++){
		AndData= AndData << 4;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= Bin2Hex1((data & AndData) >> ((cnt- i- 1)*4));
		AndData = AndData >> 4;
	}
	buff[i]= 0;
}
void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= '0'+ ((data / AndData) % 10);
		data= data % AndData;
		AndData = AndData / 10;
	}
	buff[i]= 0;
}
int	gstrlen(char *buff)
{
	int		i;

	for(i= 0; ; i++){
		if(buff[i] == 0){
			break;
		}
	}
	return(i);
}
void	gmemset(char *buff,int data,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*buff= (char)data;
		buff++;
	}
}
void	gmemcpy(char *obj,char *src,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*obj= *src;
		src++;
		obj++;
	}
}
void	gstrcpy(char *obj,char *src)
{
	int		i;

	for(i= 0; ; i++){
		*obj= *src;
		if(*src == 0){
			break;
		}
		src++;
		obj++;
	}
	*obj= 0;
}
int	gstrcmp(char *src,char *obj)
{
	int		i;
	int		ret;

	ret= NG;
	for(i= 0; ; i++){
		if(src[i] == 0){
			if(obj[i] == 0){
				ret= OK;
			}
			break;
		}
		if(obj[i] == 0){
			break;
		}
		if(src[i] != obj[i]){
			break;
		}
	}
	return(ret);
}
int	gstrncmp(char *src,char *obj,int cnt)
{
	int		i;
	int		ret;

	ret= OK;
	for(i= 0; i < cnt; i++){
		if(src[i] != obj[i]){
			ret= NG;
			break;
		}
	}
	return(ret);
}
void	gstrcat(char *src,char *obj)
{
	int		i;

	for(i= 0; ; i++){
		if(*src == 0){
			break;
		}
		src++;
	}
	for(i= 0; ; i++){
		if(*obj == 0){
			*src= 0;
			break;
		}
		*src= *obj;
		src++;
		obj++;
	}
}
int	gatoi(char *buff)
{
	char	c;
	int	ret;
	int flag;

	ret= 0;
	flag= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){
			break;
		}
		if((c >= '0') && (c <= '9')){
			ret= ret*10;
			ret+= c- '0';
		}else{
			if(c == '+'){
				continue;
			}
			if(c == '-'){
				flag= 1;
				continue;
			}
			break;
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}
#else
extern	int	Bin2Hex1(int data);
extern	void	Bin2Hex(int data,int cnt,char *buff);
extern	void	Bin2dec(int data,int cnt,char *buff);
extern	int	gstrlen(char *buff);
extern	void	gmemset(char *buff,int data,int cnt);
extern	void	gmemcpy(char *obj,char *src,int cnt);
extern	void	gstrcpy(char *obj,char *src);
extern	int	gstrcmp(char *src,char *obj);
extern	int	gstrncmp(char *src,char *obj,int cnt);
extern	void	gstrcat(char *src,char *obj);
extern	int	gatoi(char *buff);
#endif
/************************************/
/* ��M�v���g�R��					*/
/************************************/
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
extern	int		SioPLCDlgCommCnt;
extern	int	Sio0OutCnt;

	int	ret;
	
	ret= -1;

	switch(*CommMode){
/*ksc20040707*/
/* ���� ���ŵ� ����Ÿ�� ���� 
 - ��Ʈ���ڵ�	: RecBuff[0], RecBuff[1]�� ACK, STX �Է�
 - ����Ÿ		: RecBuff[2], RecBuff[3]�� ����,
                  RecBuff[4], RecBuff[5]�� RD,
				  RecBuff[6], RecBuff[7], RecBuff[8], RecBuff[9]�� ����Ÿ,
				  RecBuff[10]�� ETX,
 - �����ڵ�		: RecBuff[11]�� FSC, */ 

	case 0:
		*RecCnt= 0;			/* �`���X�^�[�g */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 1;
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		PlcRecCnt2= 6;
		PlcRecCmd2= data;
		*CommMode = 2;
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		switch(PlcRecCmd2){
		case 0x01:
		case 0x02:
		case 0x03:
		case 0x04:
			PlcRecCnt2= data+2;
			break;
		case 0x05:
		case 0x06:
		case 0x08:
			PlcRecCnt2= 5;
			break;
		default:
			PlcRecCnt2= 2;
			break;
		}
		*CommMode = 3;
		break;
	case 3:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		PlcRecCnt2--;
		if(PlcRecCnt2 <= 0){
			ret= 0;
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/


/*ksc20040707*/
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
/* char *buff : �۽��ϰ����ϴ� ����Ÿ ����,
   int cnt    : �۽��ϰ����ϴ� ����Ÿ ��,
   unsigned char *OutBuf : CRC���� �ΰ��� �����۽� ����Ÿ */

unsigned short PLC2_crc16(unsigned char *puchMsg, int usDataLen)
{
    unsigned char uchCRCHi = 0xFF ; /* high byte of CRC initialized */
    unsigned char uchCRCLo = 0xFF ; /* low byte of CRC initialized */
    int uIndex ; /* will index into CRC lookup table */
    while (usDataLen--) /* pass through message buffer */
    {
        uIndex = uchCRCHi ^ *puchMsg++ ; /* calculate the CRC */
        uchCRCHi = uchCRCLo ^ PLC2_auchCRCHi[uIndex] ;
        uchCRCLo = PLC2_auchCRCLo[uIndex] ;
    }
    return (uchCRCHi << 8 | uchCRCLo) ;
}

int PLC2_SetPLCBCC(char *buff,int cnt,unsigned char *OutBuf)
{

	int		i;
	unsigned short _crc16;

	for(i = 0; i < cnt; i++){
		OutBuf[i] = buff[i];		/* �۽Ź��� OutBuf[1] = ����, OutBuf[2] = ����, OutBuf[3] = R, OutBuf[4] = X,
										OutBuf[5] = 0, OutBuf[6] = P, OutBuf[7] = 0, 
												OutBuf[8] = +, OutBuf[9] = 0, OutBuf[10] = 0, 
											    OutBuf[11] = 0, OutBuf[12] = 0, OutBuf[13] = 0, 
												OutBuf[14] = 0, OutBuf[15] = 0 */
	}
	_crc16= PLC2_crc16(OutBuf,cnt);
	OutBuf[cnt]= _crc16/0x100;
	OutBuf[cnt+1]= _crc16%0x100;
	return(cnt + 2);				/* 18�� ���� */

}



/************************************/
/*	PLC Send						*/
/************************************/
int	PLC2_SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	unsigned short _crc16;
	unsigned short cal16;

	PcThruByteCnt= PLC2_SetPLCBCC((char *)combuf,*Cnt,PcThruRecDataWork);
	ret= B_SendRecPLC2(mode,rData,Cnt,rmode);
	cal16= (rData[*Cnt- 2] << 8) + rData[*Cnt- 1];
	_crc16= PLC2_crc16(rData,*Cnt- 2);
	if(cal16 != _crc16){
		ret= -1;
	}
	return(ret);
}


int	Connection2( int *PlcType,int iConnect )
{
	int		ret;
/*ksc20040714*/
	int		Cnt;
	char	buff[32];

	/* �������̃{�[���[�g */
	if((iConnect & 1) == 0){		
#ifdef	WIN32
		SioPCMode= 3;
		SioPCOpenFlag= 1;
#else
		B_RsModeSet(RS_PLC,RS_INIT,RS_9600,RS_DATA8,RS_NONE); /* RS_PC �� 1�϶� RS-232C */
#endif
	}else{						
#ifdef	WIN32
		SioPLCMode= 3;
		SioPLCOpenFlag= 1;
#else
		B_RsModeSet(RS_PC,RS_INIT,RS_9600,RS_DATA8,RS_NONE); /* RS_PLC �� 0�϶� RS-422 */
#endif
	}
#ifdef	WIN32
	while(1){
		if((iConnect & 1) == 0){
			if(SioPCOpenFlag == 0){
				break;
			}
		}else{
			if(SioPLCOpenFlag == 0){
				break;
			}
		}
/*ksc20040714*/
		B_Delay(300);
	}
#else

/*ksc20040714*/
	B_Delay(300);
#endif

	/* PLC Connect Check *(PlcType+2) ���� ������ �Ѱ� ���� */


	buff[0]= *(PlcType+2);		/* Stattion */
	buff[1]= 0x04;				/* Read Inpu Reg */
	buff[2]= 0x00;				/* H-Addr */
	buff[3]= 0x68;				/* L-Addr */
	buff[4]= 0x00;				/* H-Cnt */
	buff[5]= 0x03;				/* L-Cnt */

	Cnt= 6;
	ret= PLC2_SendRecPLCWithBCC(2,buff,PcThruRecDataWork,&Cnt,0);		
/*ksc20040817

ret�� 0�϶� ���� ����
      -1�϶� Ÿ�Ӿƿ��� ����
	
/*ksc20040716*/	
/*ksc20040716	
	if(GrpPLCcombuf[0] != 0x06){
		ret= -1;
	}
/*ksc20040716*/
	if(ret < 0){
		return(0);
	}

	/* PLC Connect Check */
	ret= 1;
	return(ret);
/*ksc20040715*/
/*���ؼ��� ���� ������ ������ Ȯ�εǸ� �����޼����� ǥ������ �ʴ´�. 
  ���� ������ ������ �����޼��� ǥ���Ѵ�.
  ret=1�϶� �������� ó�� 	*/
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
/****************************/
/* Make Read Device			*/
/****************************/
/* �۽� ������ ���� */
int	PLC2_MakePLCReadData(int mode, char *pDevice, int DevAddr, char *combuff, int sCnt,int StationNo)
{
	int		ret;
	char	Kyoku[3];

	Bin2dec(pDevice[4],2,Kyoku);
	ret= 0;

	if(ret == 0){
		if((DevAddr >= 0x30001) && (DevAddr <= 0x30125)){
			DevAddr -= 0x30001;
			combuff[0]= StationNo;
			combuff[1]= 0x04;
			combuff[2]= DevAddr/0x100;
			combuff[3]= DevAddr%0x100;
			combuff[4]= sCnt/0x100;
			combuff[5]= sCnt%0x100;
		}else{
			ret= -1; /* �ش� PLC�� 100�� �۽� ��巹���� ������ -1 ���� */ 
		}

	}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		sCnt;
	int		Cnt;
	int		rCnt;
	unsigned char	*SaveAddr;

	switch(mp->mpec){	/* mp->mpec�� 0�϶� Bit Device, 1�϶� Word Device */
	case PLC_BIT:		/* Bit Device */
		ret = PLC2_MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PcThruRecData,mp->mext,(int)mp->mbuf[4]);
		Cnt = mp->mext;
		rCnt = BitRecCnt;
		break;
	case PLC_WORD:		/* Word Device */
		/* �۽� ������ ���� */
		ret = PLC2_MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PcThruRecData,mp->mext,(int)mp->mbuf[4]); 
		Cnt = mp->mext* 2;
		rCnt = mp->mext* 2;
		sCnt= 6;
		break;
	}
	SaveAddr = (unsigned char *)mp->mptr;
	if(ret == 0){	/* PLC���� ����ϴ� ��巹���� ��� 0 ���� */

		if(PLC2_SendRecPLCWithBCC(2,(char *)PcThruRecData,(unsigned char *)rDataFx,&sCnt,0) == 0){ /* ����ؼ� ���ϰ��� 0 �϶� ����Ÿ ó�� */ 
			for(i = 0; i < Cnt/2; i++){
				*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+3+1];
				SaveAddr++;
				*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+3];
				SaveAddr++;
			}
		}else{
			ret = -1;
		}					
	}else if(ret == 1){		/* ����Device */
		ret= 0;

	}else{
		ret= 0;

	}
	B_Delay(100);
	return(ret);
}
/****************************/
/* Make Write Device		*/
/****************************/
int	PLC2_MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data,int StationNo)
{
	return(-1);
}
/************************************/
/* PLC Write						*/
/************************************/
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = PLC2_MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCbuf,(char *)mp->mptr,(int)mp->mbuf[4]);
		Cnt = mp->mext;
		break;
	case PLC_WORD:		/* Word Device */
		ret = PLC2_MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCbuf,(char *)mp->mptr,(int)mp->mbuf[4]);
		if(DeviceFlag == 2){		/* TS,CS */
			Cnt = mp->mext* 4;
		}else{
			Cnt = mp->mext* 2;
		}
		break;
	}
	if(ret == 0){
		if(PLC2_SendRecPLCWithBCC(1,(char *)PLCbuf,rDataFx,&Cnt,0) == 0){
		}else{
			ret = -1;
		}
	}else if(ret == 1){		/* ����Address */
		ret= 0;
	}
	return(ret);
}
int	GetSendRecTime2(void)
{
	return(5);				/* 1ms */
}
void	Get_Plc2_Ver(char *name)
{
	gstrcpy(name,"V1.10");
}
#ifdef	WIN32
/********************************************/
/*	�����֐�								*/
/********************************************/
int	PLC_CONNECT2(int *PlcType,int iConnect)
{
	return(Connection2(PlcType,iConnect));
}
int	PLC1CHAR_READ2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc2(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead2(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite2(mp,rDataFx,PlcType));
}

int	GET_SEND_REC_TIME2(void)
{
	return(GetSendRecTime2());
}
void	GET_PLC2_VER(char *Name)
{
	Get_Plc2_Ver(Name);
}
#endif
/****************************** END **********************/