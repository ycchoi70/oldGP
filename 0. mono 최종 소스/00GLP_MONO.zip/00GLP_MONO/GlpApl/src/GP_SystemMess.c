#include "define.h"
/********************************************/
/*	System Message For Koria				*/
/********************************************/

#ifdef	OLD

#ifdef	WIN32

#ifdef	KOREA
#include	"GP_SystemMessKor.cpp"
#endif

#ifdef	JAPAN
#include	"GP_SystemMessJpn.cpp"
#endif

#ifdef	CHINA
#include	"GP_SystemMessChi.cpp"
#endif

#ifdef	TAIWAN
#include	"GP_SystemMessTai.cpp"
#endif

#ifdef	ENGLISH
#include	"GP_SystemMessEng.cpp"
#endif

#ifdef	RUSSIAN
#include	"GP_SystemMessRus.cpp"
#endif



#else

#ifdef	KOREA
#include	"GP_SystemMessKor.c"
#endif

#ifdef	JAPAN
#include	"GP_SystemMessJpn.c"
#endif

#ifdef	CHINA
#include	"GP_SystemMessChi.c"
#endif

#ifdef	TAIWAN
#include	"GP_SystemMessTai.c"
#endif

#ifdef	ENGLISH
#include	"GP_SystemMessEng.c"
#endif

#ifdef	RUSSIAN
#include	"GP_SystemMessRus.c"
#endif

#endif

#else


#ifdef	WIN32

#include	"GP_SystemMessAll.cpp"

#else

#include	"GP_SystemMessAll.c"

#endif
#endif
