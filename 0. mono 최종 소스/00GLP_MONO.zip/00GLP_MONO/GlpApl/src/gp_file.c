/********************************************************************************/
/* �� �� ��E: Sgt.cpp															*/
/* ��E   �� : ���� TASK ��?E												*/
/* �� �� �� : 2002��E2��E7�� (��E												*/
/* �� �� �� : ȫ �� ��E														*/
/* ��    �� : (��) LC Tech														*/
/* ��E   ��E: 																	*/
/********************************************************************************/
#include	"sgt.h"

/********************************************************************************/
/* �� �� �� : FileTask															*/
/* ��    �� : PC���� ������ �±����������� �ص���								*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 11�� 													*/
/* �� �� �� : �� �� ȣ (���� : �̼���) 															*/
/* ��    Ÿ :																	*/
/*			 ������������ ���� ��E�ִ� ����ũ��E: 1024Bytes						*/
/********************************************************************************/
/********************************************/
/*?LINE									*/
/********************************************/
int	TagCode_01(int iScreenNo,unsigned char *TagBuffer,int mode,int iBackColor)
{
	ScreenTagData[iDispOrder].cObjects	= LINE;
	ScreenTagData[iDispOrder].iWindowNo	= iScreenNo;
	ScreenTagData[iDispOrder].TagPos= TagBuffer;
	ScreenTagData[iDispOrder].sX  = (short)(*(TagBuffer+6) << 0x08);		/* Line Start X Point */
	ScreenTagData[iDispOrder].sX += (short)(*(TagBuffer+7));
	ScreenTagData[iDispOrder].sY  = (short)(*(TagBuffer+8) << 0x08);		/* Line Start Y Point */
	ScreenTagData[iDispOrder].sY += (short)(*(TagBuffer+9));
	ScreenTagData[iDispOrder].eX  = (short)(*(TagBuffer+10) << 0x08);		/* Line End X Point */
	ScreenTagData[iDispOrder].eX += (short)(*(TagBuffer+11));
	ScreenTagData[iDispOrder].eY  = (short)(*(TagBuffer+12) << 0x08);		/* Line End Y Point */
	ScreenTagData[iDispOrder].eY += (short)(*(TagBuffer+13));
	ScreenTagData[iDispOrder].BeShapeUsed= 0;
	iFigureCnt++;
	return(0);
}
/********************************************/
/*?Text									*/
/********************************************/
int	TagCode_09(int iScreenNo,unsigned char *TagBuffer,int iPos,int iFilePointer,int TagPos,int mode,int iBackColor)
{
	ScreenTagData[iDispOrder].cObjects	= TEXT_DISP;
	ScreenTagData[iDispOrder].iWindowNo	= iScreenNo;
	ScreenTagData[iDispOrder].TagPos= TagBuffer;
	ScreenTagData[iDispOrder].sX  = (short)(*(TagBuffer+9) << 0x08);		/* Line Start X Point */
	ScreenTagData[iDispOrder].sX += (short)(*(TagBuffer+10));
	ScreenTagData[iDispOrder].sY  = (short)(*(TagBuffer+11) << 0x08);		/* Line Start Y Point */
	ScreenTagData[iDispOrder].sY += (short)(*(TagBuffer+12));
	ScreenTagData[iDispOrder].eX  = (short)(*(TagBuffer+13) << 0x08);		/* Line End X Point */
	ScreenTagData[iDispOrder].eX += (short)(*(TagBuffer+14));
	ScreenTagData[iDispOrder].eY  = (short)(*(TagBuffer+15) << 0x08);		/* Line End Y Point */
	ScreenTagData[iDispOrder].eY += (short)(*(TagBuffer+16));
	ScreenTagData[iDispOrder].BeShapeUsed= 0;
	iFigureCnt++;
	return(0);
}
/********************************************/
/*?REct Angle								*/
/********************************************/
int	TagCode_03(int iScreenNo,unsigned char *TagBuffer,int mode,int iBackColor)
{
	ScreenTagData[iDispOrder].cObjects	= RECTANGLE;
	ScreenTagData[iDispOrder].iWindowNo	= iScreenNo;
	ScreenTagData[iDispOrder].TagPos= TagBuffer;
	ScreenTagData[iDispOrder].sX  = (short)(*(TagBuffer+9) << 0x08);		/* Line Start X Point */
	ScreenTagData[iDispOrder].sX += (short)(*(TagBuffer+10));
	ScreenTagData[iDispOrder].sY  = (short)(*(TagBuffer+11) << 0x08);		/* Line Start Y Point */
	ScreenTagData[iDispOrder].sY += (short)(*(TagBuffer+12));
	ScreenTagData[iDispOrder].eX  = (short)(*(TagBuffer+13) << 0x08);		/* Line End X Point */
	ScreenTagData[iDispOrder].eX += (short)(*(TagBuffer+14));
	ScreenTagData[iDispOrder].eY  = (short)(*(TagBuffer+15) << 0x08);		/* Line End Y Point */
	ScreenTagData[iDispOrder].eY += (short)(*(TagBuffer+16));
	ScreenTagData[iDispOrder].BeShapeUsed= 0;
	iFigureCnt++;
	return(0);
}
/********************************************/
/*?Circle									*/
/********************************************/
int	TagCode_06(int iScreenNo,unsigned char *TagBuffer)
{
	ScreenTagData[iDispOrder].cObjects	= CIRCLE;
	ScreenTagData[iDispOrder].iWindowNo	= iScreenNo;
	ScreenTagData[iDispOrder].TagPos= TagBuffer;
	ScreenTagData[iDispOrder].sX  = (short)(*(TagBuffer+8) << 0x08);		/* Line Start X Point */
	ScreenTagData[iDispOrder].sX += (short)(*(TagBuffer+9));
	ScreenTagData[iDispOrder].sY  = (short)(*(TagBuffer+10) << 0x08);		/* Line Start Y Point */
	ScreenTagData[iDispOrder].sY += (short)(*(TagBuffer+11));
	ScreenTagData[iDispOrder].eX  = (short)(*(TagBuffer+12) << 0x08);		/* Line End X Point */
	ScreenTagData[iDispOrder].eX += (short)(*(TagBuffer+13));
	ScreenTagData[iDispOrder].eY  = (short)(*(TagBuffer+14) << 0x08);		/* Line End Y Point */
	ScreenTagData[iDispOrder].eY += (short)(*(TagBuffer+15));
	ScreenTagData[iDispOrder].BeShapeUsed= 0;
	iFigureCnt++;
	return(0);
}
int	TagCode_0A_0B(int iScreenNo,unsigned char *TagBuffer,int iPos,int iFilePointer,int TagPos)
{
	ScreenTagData[iDispOrder].cObjects	= BITMAP_DATA;
	ScreenTagData[iDispOrder].iWindowNo	= iScreenNo;
	ScreenTagData[iDispOrder].TagPos= TagBuffer;
	ScreenTagData[iDispOrder].sX  = (short)(*(TagBuffer+6) << 0x08);		/* Line Start X Point */
	ScreenTagData[iDispOrder].sX += (short)(*(TagBuffer+7));
	ScreenTagData[iDispOrder].sY  = (short)(*(TagBuffer+8) << 0x08);		/* Line Start Y Point */
	ScreenTagData[iDispOrder].sY += (short)(*(TagBuffer+9));
	ScreenTagData[iDispOrder].eX  = (short)(*(TagBuffer+10) << 0x08);		/* Line End X Point */
	ScreenTagData[iDispOrder].eX += (short)(*(TagBuffer+11));
	ScreenTagData[iDispOrder].eY  = (short)(*(TagBuffer+12) << 0x08);		/* Line End Y Point */
	ScreenTagData[iDispOrder].eY += (short)(*(TagBuffer+13));
	ScreenTagData[iDispOrder].BeShapeUsed= 0;
	iFigureCnt++;
	return(0);
}
int	SetTagInfo(int iScreenNo,int iTagCode,int iDispOrder,unsigned char *TagBuffer,int mode,int iBackColor)
{
	int		ret;

	ret= 0;
	ScreenTagData[iDispOrder].iWindowNo	= iScreenNo;
	ScreenTagData[iDispOrder].TagPos= TagBuffer;
	ScreenTagData[iDispOrder].sX  = (short)(*(TagBuffer+6) << 0x08);		/* Line Start X Point */
	ScreenTagData[iDispOrder].sX += (short)(*(TagBuffer+7));
	ScreenTagData[iDispOrder].sY  = (short)(*(TagBuffer+8) << 0x08);		/* Line Start Y Point */
	ScreenTagData[iDispOrder].sY += (short)(*(TagBuffer+9));
	ScreenTagData[iDispOrder].eX  = (short)(*(TagBuffer+10) << 0x08);		/* Line End X Point */
	ScreenTagData[iDispOrder].eX += (short)(*(TagBuffer+11));
	ScreenTagData[iDispOrder].eY  = (short)(*(TagBuffer+12) << 0x08);		/* Line End Y Point */
	ScreenTagData[iDispOrder].eY += (short)(*(TagBuffer+13));
	ScreenTagData[iDispOrder].BeShapeUsed= UNCHECKED;
	ScreenTagData[iDispOrder].DevCnt= 0;
	switch(iTagCode){
	case 0x64 :		/* Numeric Data���		*/
		ScreenTagData[iDispOrder].cObjects	= NUMERICAL_DISPLAY;
/*		ret= DrawNumeric_Func(iDispOrder, TagBuffer );*/
		SetNumeric_Func(iDispOrder);
		break;
	case 0x65 :		/* ASCII Data���		*/
		ScreenTagData[iDispOrder].cObjects	= ASCII_DISPLAY;
/*		ret= DrawAscii_Func(iDispOrder, TagBuffer );*/
		SetAscii_Func(iDispOrder);
		break;
	case 0x68 :		/* Clock Data���		*/
		ScreenTagData[iDispOrder].cObjects	= CLOCK;
/*		ret= DrawClock_Func(iDispOrder, TagBuffer );*/
		SetClock_Func(iDispOrder);

		break;
	case 0x6E:		/* Comment Data��� */
		ScreenTagData[iDispOrder].cObjects	= COMMENT;
/*		ret= DrawComment_Func(iDispOrder, TagBuffer );*/
		SetComment_Func(iDispOrder);
		break;
	case 0x70:		/* Alarm List Data��� */
		ScreenTagData[iDispOrder].cObjects	= ALARM_LIST;
/*		ret= DrawAlarmList_Func(iDispOrder, TagBuffer );*/
		SetAlarmList_Func(iDispOrder);
		break;
	case 0x72:		/* Alarm History Data��� */
		ScreenTagData[iDispOrder].cObjects	= ALARM_HISTORY;
/*		ret= DrawAlarmHistory_Func(iDispOrder, TagBuffer );*/
		SetAlarmHistory_Func(iDispOrder);
		break;
	case 0x78:		/* Part Data��� */
		ScreenTagData[iDispOrder].cObjects	= PART_DISPLAY;
/*		ret= DrawParts_Func(iDispOrder, TagBuffer );*/
		SetParts_Func(iDispOrder);
		break;
	case 0x7A:		/* Lamp Data��� */
		ScreenTagData[iDispOrder].cObjects	= LAMP;
/*		ret= DrawLamp_Func(iDispOrder, TagBuffer );*/
		SetLamp_Func(iDispOrder);
		break;
	case 0x7B:		/* Panel Meter Data��� */
		ScreenTagData[iDispOrder].cObjects	= PANELMETER;
/*		ret= DrawPanel_Func(iDispOrder, TagBuffer );*/
		SetPanel_Func(iDispOrder);
		break;
	case 0x82:		/* Trend Graph Data��� */
		ScreenTagData[iDispOrder].cObjects	= TREND_GRAPH;
/*		ret= DrawTrendGraph_Func(iDispOrder, TagBuffer );*/
		SetTrendGraph_Func(iDispOrder);
		break;
	case 0x84:		/* Bar Graph Data��� */
		ScreenTagData[iDispOrder].cObjects	= BAR_GRAPH;
/*		ret= DrawBarGraph_Func(iDispOrder);*/
		SetBarGraph_Func(iDispOrder);
		break;
	case 0x85:		/* Statistics Data��� */
		ScreenTagData[iDispOrder].cObjects	= STATISTICS;
/*		ret= DrawStatistics_Func(iDispOrder, TagBuffer );*/
		SetStatistics_Func(iDispOrder);
		break;
	case 0x87:		/* Line Graph Data��� */
		ScreenTagData[iDispOrder].cObjects	= LINE_GRAPH;
/*		ret= DrawLineGraph_Func(iDispOrder, TagBuffer );*/
		SetLineGraph_Func(iDispOrder);
		break;
	case 0x8C:		/* Touch Switch Data��� */
		ScreenTagData[iDispOrder].cObjects	= TOUCH_SWITCH;
/*		ret= DrawTouchSwitch_Func(iDispOrder, TagBuffer, mode, iBackColor );*/
		SetTouchSwitch_Func(iDispOrder,mode,iBackColor);
		break;
	case 0x96:		/* Numeric Input Data��� */
		ScreenTagData[iDispOrder].cObjects	= NUMERICAL_INPUT;
/*		ret= DrawNumericInput_Func(iDispOrder, TagBuffer );*/
		SetNumericInput_Func(iDispOrder);
		break;
	case 0x97:		/* Ascii Input Data��� */
		ScreenTagData[iDispOrder].cObjects	= ASCII_INPUT;
/*		ret= DrawAsciiInput_Func(iDispOrder, TagBuffer );*/
		SetAsciiInput_Func(iDispOrder);
		break;
	} /* end switch */
	return(ret);
}
/************************************************************/
/*	?�O���ݒ�											*/
/*	int iScreenNo:?����ʔԍ�								*/
/*	unsigned char *cTagBuf:Base��ʃt?�C���擪�A�h���X		*/
/*	int *ipOffset:Base�t?�C����?�O���ʒu�A�h���X			*/
/*	int *iLastTag:											*/
/*	int iFilePointer:										*/
/*	int *iLastTagFlag:										*/
/*	int *iObjectSel:										*/
/*	int iPos:												*/
/*	int mode:												*/
/*	int iBackColor:											*/
/************************************************************/
void	MakeTaginfo(int iScreenNo,unsigned char *cTagBuf,int *ipOffset,
			int *iLastTag,int iFilePointer,int *iLastTagFlag,int *iObjectSel,int iPos,int mode,int iBackColor)
{
	unsigned char*			TagBuffer;/* ������ �±������� ���� ���� */
	int						iTotalCnt;
	int						i,l;
	unsigned int			iTagCode;
//	int						iLast;
	int						iTextSize, iTextOffset;
	int						iImageSize;
	int						iObjTagSize;
	int						iOffset;
	int						ret;
	unsigned char			*FlashTagPos;
	int						TagPos;		/* Tag Start Pos */

	iOffset= *ipOffset;

	/* Base Gamen Taginfo Aggress Save */
	if(TagFileCnt < 8){	/* for 8 Gamen */
		TagFileInfo[TagFileCnt].iScreenNo= iScreenNo;
		TagFileInfo[TagFileCnt].iOffset= iOffset;
		TagFileInfo[TagFileCnt].cTagBuf= cTagBuf;
		TagFileInfo[TagFileCnt].iFilePointer= iFilePointer;
		TagFileInfo[TagFileCnt].iPos= iPos;
		TagFileCnt++;
	}
	iTotalCnt  = (int)(*(cTagBuf+iOffset) << 0x08);
	iTotalCnt += (int)(*(cTagBuf+(++iOffset)));
/*
	if(iTotalCnt > 512){
		iTotalCnt= 512;
	}
*/
	/* Tag Start Pos */
	iOffset++;
	FlashTagPos= (unsigned char *)(cTagBuf+iOffset);
	/* �ŏ��̐��l�����o�� */
	TagPos  = (int)(*FlashTagPos << 0x18);
	FlashTagPos++;
	TagPos += (int)(*FlashTagPos << 0x10);
	FlashTagPos++;
	TagPos += (int)(*FlashTagPos << 0x08);
	FlashTagPos++;
	TagPos += (int)(*FlashTagPos);
	FlashTagPos++;

	l = 0;
	*iLastTag = OFF;
	for(i= 0; i < iTotalCnt; i++){
		/* �ő�?�O���𒴂�����?�F�b�N���� */
		if(iDispOrder >= MAX_TAG_NO){
			break;
		}
		if(i == iTotalCnt - 1){
			TagBuffer= (unsigned char *)(cTagBuf+(iFilePointer+TagPos));
			iOffset = iFilePointer + TagPos;
			*iLastTagFlag = ON;
		}else{
			TagBuffer= (unsigned char *)(cTagBuf+(iFilePointer+TagPos));
			iOffset = iFilePointer + TagPos;
			*iLastTagFlag = OFF;
		} /* end if */

		iTagCode = (unsigned int)TagBuffer[0];
		ret = -1;
		switch(iTagCode){
		case 0x01:		/* �������  Line */
			*iObjectSel = FIGURE;
			TagBuffer= (unsigned char *)(cTagBuf+(iFilePointer+TagPos));
			if(*iLastTagFlag == ON){
				iOffset = iFilePointer + TagPos + 14;
			}
//			iLast = TagBuffer[14];
			/*---------------------------------------------*/
			ret= TagCode_01(iScreenNo,TagBuffer,mode,iBackColor);
			break;

		case 0x09:/* �ؽ�Ʈ���	text */
			*iObjectSel = FIGURE;
			if(*iLastTagFlag == ON){
				iTextSize= iTextOffset = 0;
				if((unsigned char)(*(cTagBuf+iFilePointer+TagPos+21)) == 0x01) {/* Text Line cnt */
					iTextSize  = (unsigned int)(*(cTagBuf+iFilePointer+TagPos+17) << 0x08);
					iTextSize += (unsigned int)(*(cTagBuf+iFilePointer+TagPos+18));
					iTextOffset = 25;
					iTextOffset += iTextSize;
					TagBuffer= (unsigned char *)(cTagBuf+iFilePointer+TagPos);
					iOffset = iFilePointer + (int)TagPos + iTextOffset;
				}else{/* ������ �ִ� ���  */
					iTextOffset += 21;
					while(l < (unsigned char)(*(cTagBuf+iFilePointer+TagPos+21))){
						iTextOffset+=3; 
						iTextSize  = (unsigned int)(*(cTagBuf+iFilePointer+TagPos+iTextOffset) << 0x08);
						iTextOffset++;
						iTextSize += (unsigned int)(*(cTagBuf+iFilePointer+TagPos+iTextOffset));	
						iTextOffset += iTextSize;
						l++;				
					}
					l = 0;
					iTextOffset++;
					TagBuffer= (unsigned char *)(cTagBuf+iFilePointer+TagPos);
					iOffset = iFilePointer + TagPos + iTextOffset;
				}
//				iLast = TagBuffer[iTextOffset];
			}else{
				TagBuffer= (unsigned char *)(cTagBuf+iFilePointer+TagPos);
			}
			/*----------���------------------------------------*/
			ret= TagCode_09(iScreenNo,TagBuffer,iPos,iFilePointer,TagPos,mode,iBackColor);
			break;

		case 0x03:/* �簢�����  rectangle */
			*iObjectSel = FIGURE;					
			TagBuffer= (unsigned char *)(cTagBuf+iFilePointer+TagPos);
//			iLast = TagBuffer[17];
			if(*iLastTagFlag == ON){
				iOffset = iFilePointer + TagPos + 17;
			}
			/*------------------------------------------*/
			ret= TagCode_03(iScreenNo,TagBuffer,mode,iBackColor);
			break;
					
		case 0x06:/* �� ���  circle */
			*iObjectSel = FIGURE;
			TagBuffer= (unsigned char *)(cTagBuf+iFilePointer+TagPos);
//			iLast = TagBuffer[16];
			if(*iLastTagFlag == ON){
				iOffset = iFilePointer + TagPos + 16;
			}
			ret= TagCode_06(iScreenNo,TagBuffer);
			break;

		case 0x0A:/* �̹������ BMP */		
		case 0x0B:/* �̹������ DXF */
			*iObjectSel = FIGURE;
			if(*iLastTagFlag == ON){
				iImageSize  = (unsigned int)(*(cTagBuf+iFilePointer+TagPos+4) << 0x08);
				iImageSize += (unsigned int)(*(cTagBuf+iFilePointer+TagPos+5));
				iImageSize -= 2;
//				iLast = (unsigned char)(*(cTagBuf+iFilePointer+TagPos+iImageSize));
				iOffset = iFilePointer + TagPos + iImageSize;
				TagBuffer= (unsigned char *)(cTagBuf+iFilePointer+TagPos);
			}else{
				TagBuffer= (unsigned char *)(cTagBuf+iFilePointer+TagPos);
			}
			/*----------���------------------------------------*/
			ret= TagCode_0A_0B(iScreenNo,TagBuffer,iPos,iFilePointer,TagPos);
			break;

		case 0x64:		/* Numeric Data			���	*/
		case 0x65:		/* ASCII Data			���	*/
		case 0x68:		/* Clock Data			���	*/
		case 0x6E:		/* Comment Data			���	*/
		case 0x70:		/* Alarm List Data		���	*/
		case 0x72:		/* Alarm History Data	���	*/
		case 0x78:		/* Part Data			���	*/
		case 0x7A:		/* Lamp Data			���	*/
		case 0x7B:		/* Panel Meter Data		���	*/
		case 0x82:		/* Trend Graph Data		���	*/
		case 0x84:		/* Bar Graph Data		���	*/
		case 0x85:		/* Statistics Data		���	*/
		case 0x87:		/* Line Graph Data		���	*/
		case 0x8C:		/* Touch Switch Data	���	*/
		case 0x96:		/* Numeric Input Data	���	*/
		case 0x97:		/* Ascii Input Data		���	*/
/*			if(*iObjectSel == FIGURE){
				ObjectStart();
			}
*/
			*iObjectSel = OBJECT;
			iOffset -= 2;
			if(*iLastTagFlag == OFF){
				TagBuffer= (unsigned char *)(cTagBuf+iFilePointer+TagPos-2);
			}else{
				iObjTagSize  = (int)(*(cTagBuf+iOffset) << 8);
				iOffset++;
				iObjTagSize += (int)(*(cTagBuf+iOffset));
				TagBuffer= (unsigned char *)(cTagBuf+iFilePointer+TagPos-2);
//				iLast = (*(cTagBuf+iOffset+iObjTagSize-1));
				*iLastTag = ON;
			}
			if(DeviceCnt < (MAX_DEV_CNT- 10)){
				ret= SetTagInfo(iScreenNo,iTagCode,iDispOrder,TagBuffer,mode,iBackColor);
			}
			break;
		} /* end switch */
		if(ret == 0){
			iDispOrder++;
		}
		if(SwitchingScreenDevice.iBaseScreenFlag==1){
			break;

		}
		/* ����TAG�ʒu�����o�� */
		TagPos  = (int)(*FlashTagPos << 0x18);
		FlashTagPos++;
		TagPos += (int)(*FlashTagPos << 0x10);
		FlashTagPos++;
		TagPos += (int)(*FlashTagPos << 0x08);
		FlashTagPos++;
		TagPos += (int)(*FlashTagPos);
		FlashTagPos++;
	} /* end while */
	if(iTotalCnt <= 0){
		SetWinSema();
		ClearDispBuff(iScreenNo);
		DrawLcdBank1();
		ResetWinSema();
	}

	*ipOffset= iOffset;
}
void	SetScreenSize(int iPassFlag,int iSizePx,int iSizePy,int i)
{
		if(TateYoko == 0){ 
			if(((GAMEN_Y_SIZE-1)-Screen[iScreenPosition].KeyWinSy+ 1)<iSizePy || Screen[i].KeyWinFlag == 0x00){
#ifdef	SIZE_3224
				iWinStartPy = GAMEN_Y_SIZE/2 - iSizePy/2 -1; //20080818
#endif
#ifdef	SIZE_2480
				iWinStartPy = GAMEN_Y_SIZE - iSizePy- 1;
#endif
				iWinEndPy = iWinStartPy + iSizePy;
			}else{
				iWinStartPy = Screen[iScreenPosition].KeyWinSy;
				iWinEndPy = iWinStartPy + iSizePy;
			}

			if(((GAMEN_X_SIZE-1)-Screen[iScreenPosition].KeyWinSx+ 1)<iSizePx || Screen[i].KeyWinFlag == 0x00){
#ifdef	SIZE_3224
				iWinStartPx = GAMEN_X_SIZE/2 - iSizePx/2 -1; //20080818
#endif
#ifdef	SIZE_2480
				iWinStartPx = GAMEN_X_SIZE - iSizePx- 1;
#endif
				
				iWinEndPx = iWinStartPx + iSizePx;
			}else{
				iWinStartPx = Screen[iScreenPosition].KeyWinSx;
				iWinEndPx = iWinStartPx + iSizePx;
			}
		}else{
			if(((GAMEN_X_SIZE-1)-Screen[iScreenPosition].KeyWinSy+ 1)<iSizePy || Screen[i].KeyWinFlag == 0x00){
				iWinStartPy = GAMEN_X_SIZE - iSizePy- 1;
				iWinEndPy = iWinStartPy + iSizePy;
			}else{
				iWinStartPy = Screen[iScreenPosition].KeyWinSy;
				iWinEndPy = iWinStartPy + iSizePy;
			}

			if(((GAMEN_Y_SIZE-1)-Screen[iScreenPosition].KeyWinSx+ 1)<iSizePx || Screen[i].KeyWinFlag == 0x00){
				iWinStartPx = GAMEN_Y_SIZE - iSizePx- 1;
				iWinEndPx = iWinStartPx + iSizePx;
			}else{
				iWinStartPx = Screen[iScreenPosition].KeyWinSx;
				iWinEndPx = iWinStartPx + iSizePx;
			}
		}				
}
int	CheckSecurityLevel(int iScreenNow)
{
	int			i,idx;

	for(i=0;i<iBaseScreenCnt;i++)
	{
		if(iScreenNow == Screen[i].iNum)
		{
			idx = i;
			break;
		}
	}
	if(iPassLevel < Screen[idx].iSecurity){
		return(-1);
	}else{
		return(0);
	}
}
/****************************************************************************/
/*	File Read And Info Set													*/
/****************************************************************************/
void	FileTask( int mode )
{
	T_MAIL					*Regmp;
	int						i, l, j;
	int						iSum;
	int						iTotalCnt;
/*	unsigned int			iTagCode; 20081029 *//* �±ױ����ڵ� */
	int						iObjectSel;/* 1 : figure    2 : object */
	unsigned short			iType;
	int						iLastTagFlag;
	int						iFilePointer;
	int						iOffset;
	int						iSize;
	int						iPos;
	int						iLastTag;
	unsigned char			*cTagBuf;
	char					*cScreenDisp;
	char					*cScreenBuff;
	int						iNowScreen;
	char					cFileName[12];		/* Comment Data ���� �̸��� ���� ���� */
	short					ret;
	int						iScreenNo;
	int						iSizePx;
	int						iSizePy;
	int						iOverScreenCnt;		/* Overlap�� ���� ȭ���� �׸��� ���� ī����. */
	int						iOverlap[8];
	short					iOverFlag;
//	short					BuffFlag;
	short					iScreenNow;
	_RECTANGLE_INFO			RECParam;
	char	swork[16+1];
	int						iBackColor;
	int						iBaseNoTemp;			/* 050617 */
#ifdef	OLD
	int						Checkaddr;				// 2008.08.14
#endif
	int	StartXAddr;
	int	StartYAddr;

	int		Speed;
	int		DataBit;
	int		Parity;

	int		EditSerealSetFlag = FALSE;				/* 20090610 */

	/*****03_11_11*************************/
	if(DeviceCnt==0){
		memset(DeviceData,0x00,sizeof(DeviceData));
		memset(DispDeviceData,0x00,sizeof(DispDeviceData));
	}
	Set.LcdReverseOn = 0;
	OffSignal(S_PROJECT,1);
	OffSignal(SGN_PLC,1);

	if(iUserScreenFlag == 0 && iOverFlagNum == 0 && mode == 0 && iTransFlag != 1){
		OffSignal(S_PROJECT,1);
		vScreenDataSet();				/* leesi 02.05.22 */
	}
	if(pcFileCnt != 0 || (iUserScreenFlag == 2 && iWinScreenCnt > 0)){			/* LCTech(kwak)20020702 if(pcFileCnt != 0) */	
		SwitchingScreenDevice.iBaseScreenFlag = 0;
		/*	�ӽ÷� ������ �Է� */
		iOverFlagNum		= 0;		/* Overlap�� ȭ���� ����. */
		iOverScreenCnt		= 0;
/* 060926		iDeviceOffset		= 0;*/
		iNowScreen			= 0;		/* ���� ���÷��� �ؾ� �ϴ� ȭ���� ��ũ�� Number*/
		iTouchFlag			= 0;
		i					= 0;
		iTotalCnt			= 0;
/*		iTagCode			= 0;	20081029 */
		iObjectSel			= 0;
		iType				= 0;
		iFilePointer		= 0;
		iOffset				= 0;
		iOnSignalStart		= OFF;
		iLastTagFlag		= 0;
		iDispOrder			= 0;
		iPassPoint			= -1;	/* 030513  */
		iWinStartPx			= 0;
		iWinStartPy			= 0;
		iWinEndPx			= 0;
		iWinEndPy			= 0;
		
		InputDisplay.iFlag	= 0;			/* Cursor flag */
		ret					= 0;
		CommonArea.KeyWindow.iFlagData	= 0;
		iType = mode;

		if((DeviceCnt==0 || Key.iCode == PC_DNLOAD_END) && iTransFlag != 1){	


			OffSignal(S_PROJECT,1);
			CommonFileSet();
			if(iFirstScreen == 1){

				EditSerealSetFlag = ProjectSet();		/* 20090610 */

				if(Key.iCode == PC_DNLOAD_END){	 /* ksc20090516 */

					if(ProtocolDownloadFlag == 1)		/* �������� �ٿ�ε� �÷��� 20090610 */ 
					{
						if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
							if(EditSerealSetFlag == FALSE)	/* 20090610 */
							{

								//20111018
								Speed= ((int)(unsigned char)Set.cPlcTypeCode[2] << 8)+(unsigned char)Set.cPlcTypeCode[3]; /* 20111017 */
								DataBit= (int)(unsigned char)Set.cPlcTypeCode[4]; /* 20111017 */
								Parity= (int)(unsigned char)Set.cPlcTypeCode[5]; /* 20111017 */
								
								GET_MON_BAUDRATE(&Speed,&DataBit,&Parity);

								Set.Ch1_Serial_Param[ELSE_PLC].iSpeed=Speed;
								Set.Ch1_Serial_Param[ELSE_PLC].iData1=DataBit;
								Set.Ch1_Serial_Param[ELSE_PLC].iParity=Parity & 0xff;			/* 20090527 */
								Set.Ch1_Serial_Param[ELSE_PLC].iData2= (Parity >> 16) & 0xff;	/* 20090527 *//* 0:XON/XOF,1:DSR/DTR */ 
								Set.Ch1_Serial_Param[ELSE_PLC].iStop= (Parity >> 8) & 0xff;		/* 20090527 */		
							}								
						}								

						if(IsPlc2Protocol() == OK){	/* 2008.12.10 */

							//20111018
							Speed= ((int)(unsigned char)Set.cPlcTypeCode2[0] << 8)+(unsigned char)Set.cPlcTypeCode2[1]; /* 20111017 */
							DataBit= (int)(unsigned char)Set.cPlcTypeCode2[2]; /* 20111017 */
							Parity= (int)(unsigned char)Set.cPlcTypeCode2[3]; /* 20111017 */


							GET_MON_BAUDRATE2(&Speed,&DataBit,&Parity);

							Set.Ch2_Serial_Param[PLCTYPE2].iSpeed=Speed;
							Set.Ch2_Serial_Param[PLCTYPE2].iData1=DataBit;
							Set.Ch2_Serial_Param[PLCTYPE2].iParity=Parity & 0xff;			 /* 20090527 */
							Set.Ch2_Serial_Param[PLCTYPE2].iData2= (Parity >> 16) & 0xff;	 /* 20090527 */		/* 0:XON/XOF,1:DSR/DTR */
							Set.Ch2_Serial_Param[PLCTYPE2].iStop= (Parity >> 8) & 0xff;		 /* 20090527 */			
						}

			
						if(Set.Ch1_iKind == EDITER){
							Set.Ch2_iKind = PLCTYPE2;
						}else{
							Set.Ch1_iKind = ELSE_PLC;
						}

					}
					PlcConnectFlag = 0;				/* ksc20090525 */
					memset(&PlcConnectFlag2[0],0,sizeof(PlcConnectFlag2));				/* ksc20090525 */

					mWriteSettei();

				}

				iFirstScreen = 2;
			}
			iTransFlag	= 1;
		}

		if(iUserScreenFlag == 0 && iOverFlagNum == 0 && iType == 0){

			if(PassWordSettingFg != 0){		/* Password Touch 050426 */
				iScreenNow= PassWordSettingFg;
			}else{
				//061224
#ifdef	WIN32
				iScreenNow =  (CommonArea.SwitchingData[0] & 0xff) << 8;
				iScreenNow += (CommonArea.SwitchingData[0] & 0xff00) >> 8;
#else
				iScreenNow = CommonArea.SwitchingData[0];
#endif
			}
			/******** Screen ObserveSet ********/
			if(iScreenNow <= USER_SCREEN_NUM)
				iScreenNow = SELECT_MEMU_NUM;

			/***********************************/
			Observe_ScreenSet(iScreenNow);
			/***********************************/

			for(i=0;i<iBaseScreenCnt;i++)
			{
				if(iScreenNow == Screen[i].iNum)
				{
					iPassPoint = i;
					break;
				}
			}
		}
		if(iPassPoint<0){
			iPassPoint= 0;		/* Initialize 030702 */
			//061124
#ifdef	WIN32
			iScreenNo =  (CommonArea.SwitchingData[0] & 0xff) << 8;
			iScreenNo += (CommonArea.SwitchingData[0] & 0xff00) >> 8;
#else
			iScreenNo = CommonArea.SwitchingData[0];
#endif
			for(l=0;l<iBaseScreenCnt;l++){

				if(iScreenNo == Screen[l].iNum)
				{
					iPassPoint = l;
					break;
				}
			}
			iScreenNo=0;
		}
/******************************Pass***************************************/
		if(iType == 0){
			if((((iPassLevel < Screen[iPassPoint].iSecurity) && (iUserScreenFlag == 0)) ||
				iPassFlag == 2 || iPassFlag == 3) || (PassWordSettingChg != 0))			/* Password Input 050411 */
			{
				PassWordSettingChg= 0;				/* Password Input 050411 */
				CommonArea.KeyWindow.iKeyType = KEY_DECIMAL;
				CommonArea.KeyWindow.iFlagData = 1;			/**************/
				iType = 1;
				memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
				InputDisplay.iFirstflag = 0;
				/* �ő僌�x���̃p�X��?�h��?������ */
				memset(swork,0,sizeof(swork));
				for(i=14;i>=0;i--){
#ifdef	PASSWORD_NO_CHANGE		/* 20081023 */
					if(strncmp(CommonArea.SystemDev.Password[i],swork,8)!=0)
					{
						strncpy(swork,CommonArea.SystemDev.Password[i],8);
						swork[8]= 0;
						iTagCode= Encrypt(swork);
						sprintf(swork,"%d",iTagCode);
						strcpy(InputDisplay.cInputDispBuff,swork);
						break;	
					}
#else
/*					if(strncmp(CommonArea.SystemDev.Password[i],swork,8)!=0)	20081023 */
					if(strncmp(CommonArea.SystemDev.Password[i],swork,15)!=0)
					{
/*						strncpy(swork,CommonArea.SystemDev.Password[i],8);*/
/*						swork[8]= 0;*/
/*						iTagCode= Encrypt(swork);*/		/* 20081023 Password Change */
/*						sprintf(swork,"%d",iTagCode);*/	/* 20081023 Password Change */
						strncpy(swork,CommonArea.SystemDev.Password[i],15);
						swork[15]= 0;
						strcpy(InputDisplay.cInputDispBuff,swork);
						break;	
					}
#endif				
				}
				if(iPassFlag == 0)	/*	iPassFlag (1: From Base ó���� Check�� ��, 2:FF68 Code Touch Cloc	*/
					iPassFlag = 1;					
			}else{
				iPassFlag = 0;
			}
		}else{
			iPassFlag = 0;
		}
/*************************************************************************/
//		BuffFlag = 0;
		TateYoko = CommonArea.ProjectAuxSet.DispFormat;		/* 060926 */
		if(iType == 0){	/* Base file �� ���  */
			/* Window Or Base */
			vFreemeilAll();	
			SetWindowNo(SCREEN_0);
			SetStartPos((SCREEN_0 + iOverScreenCnt),0,0);
			OpenWindow((SCREEN_0 + iOverScreenCnt),GAMEN_X_SIZE,GAMEN_Y_SIZE);
			iScreenNo = SCREEN_0 + iOverScreenCnt;

RETURN_POINT:
			if(iOverFlagNum && iScreenDisp == 0){
				iNowScreen = iOverlap[iOverScreenCnt]; /* ���� �������� ȭ�� �ѹ�. */
			}

			memset(cFileName, 0x00, sizeof(cFileName));
			TateYoko = CommonArea.ProjectAuxSet.DispFormat;
			iBaseNoTemp= 0;						/* 0:OK,1:NG */
			if(iOverFlagNum == 0){
				if(iScreenDisp == 0){
					//061224
#ifdef	WIN32
					iNowScreenNum = (CommonArea.SwitchingData[0]& 0xff) <<8;
					iNowScreenNum += (CommonArea.SwitchingData[0] & 0xff00) >> 8;
#else
					iNowScreenNum = CommonArea.SwitchingData[0];
#endif
					iSwitch_ScreenNum1 = -1;
					if(strlen(CommonArea.SystemDev.Switch_Over1_DevName) != 0){
						//061124
#ifdef	WIN32
						iSwitch_ScreenNum1 = (CommonArea.SwitchingData[1] & 0xff) << 8;
						iSwitch_ScreenNum1 += (CommonArea.SwitchingData[1] & 0xff00) >> 8;
#else
						iSwitch_ScreenNum1 = CommonArea.SwitchingData[1];
#endif
					}
					iSwitch_ScreenNum2 = -1;
					if(strlen(CommonArea.SystemDev.Switch_Over2_DevName) != 0){
						//061124
#ifdef	WIN32
						iSwitch_ScreenNum2 = (CommonArea.SwitchingData[2] & 0xff) << 8;
						iSwitch_ScreenNum2 += (CommonArea.SwitchingData[2] & 0xff00) >> 8;
#else
						iSwitch_ScreenNum2 = CommonArea.SwitchingData[2];
#endif
					}

				}else{
					/*DeviceCnt = 1;*/
					iNowScreenNum = iScreenDisp;
				}
				if(iNowScreenNum <= 0){
					iNowScreenNum=1;
					iBaseNoTemp= 1;						/* 0:OK,1:NG */
				}
				iNowScreen = iNowScreenNum;

			}
			if(iUserScreenFlag == 2){
				/* Window Gamen */
				sprintf(cPcTempFileName,"WIN%05d.gp",iNowScreen);
			}else{
				/* Base Gamen */
				sprintf(cPcTempFileName,"Bas%05d.gp",iNowScreen);
			}
			ret = mfileserch(cPcTempFileName, &iPos, &iSize);
			if(ret != OK){
				SetWinSema();
				ClearDispBuff(SCREEN_0);
				if(TateYoko == 0){
					if(iOverScreenCnt==0){
						if(iBaseNoTemp == 0){	/* 050617 */
							cScreenBuff = (char *)TakeMemory(strlen(Dspname[COMMENT_SCREEN].chName[Set.iLang][1]));
							cScreenDisp = (char *)TakeMemory(20);
							memset(cScreenDisp, 0x00, 20);
							sprintf(cScreenDisp,"%s(No.%d)",Dspname[COMMENT_SCREEN].chName[Set.iLang][1],iNowScreen);
							iScreenMess(Dspname[COMMENT_SCREEN].chName[Set.iLang][0],cScreenDisp,"","","");	
							FreeMail((char *)cScreenDisp);
							FreeMail((char *)cScreenBuff);
						}
					}else{
						ret = 50;	/* ���������� ���� �������� ���� ��� ���� �������� �׸��� ���� �÷��� */
					}
				}else{
					if(iOverScreenCnt==0){
						if(iBaseNoTemp == 0){	/* 050617 */
							cScreenDisp = (char *)TakeMemory(20);
							memset(cScreenDisp, 0x00, 20);
							sprintf(cScreenDisp,"(No.%d)",iNowScreen);
							iScreenMess(Dspname[COMMENT_SCREEN].chName[Set.iLang][2],
										Dspname[COMMENT_SCREEN].chName[Set.iLang][3],
										Dspname[COMMENT_SCREEN].chName[Set.iLang][4],
										Dspname[COMMENT_SCREEN].chName[Set.iLang][5],cScreenDisp);	
							FreeMail((char *)cScreenDisp);
						}
					}else{
						ret = 50;	/* ���������� ���� �������� ���� ��� ���� �������� �׸��� ���� �÷��� */
					}
				}
				if(ret != 50){
					DrawLcdBank1();
				}
				ResetWinSema();
			}else{
				cTagBuf=(unsigned char *)iPos;
				if(iOverFlagNum == 0 && iScreenDisp == 0){

					iSum = ((int)cTagBuf[8]*256)+(int)cTagBuf[9]+53;
					iScreenPosition = cTagBuf[++iSum];	/* Title Size */
					iSum+=iScreenPosition+30;		/* 29 */
					iOverFlagNum = cTagBuf[++iSum];
					iScreenPosition = 0;
					for(l=0;l<iBaseScreenCnt;l++){
						if(iNowScreen == Screen[l].iNum){
							iScreenPosition = l;
							break;
						}
					}		
					if(iOverFlagNum != 0 || (iSwitch_ScreenNum2 > 0 || iSwitch_ScreenNum1 > 0)){
						iSum++;											//20091221
						for(i=0;iOverFlagNum>i;i++){
							iOverlap[i] = ((int)cTagBuf[iSum++]) << 8 ;	//20091221
							iOverlap[i]	|= cTagBuf[iSum++];
						}
						iOverlap[i] = iNowScreen;
						if(iSwitch_ScreenNum1 > 0){
							iOverFlag = 0;
							for(j=0;iOverFlagNum>j;j++){
								if(iOverlap[j]==iSwitch_ScreenNum1){
									iOverFlag = 1;
									break;
								}
							}
							if(iOverFlag == 0){
								iOverFlagNum++;
								i++;
								iOverlap[i] = iSwitch_ScreenNum1;
							}
						}
						if(iSwitch_ScreenNum2 > 0){
							iOverFlag = 0;
							for(j=0;iOverFlagNum>j;j++){
								if(iOverlap[j]==iSwitch_ScreenNum2){
									iOverFlag = 1;
									break;
								}
							}
							if(iOverFlag == 0){
								iOverFlagNum++;
								i++;
								iOverlap[i] = iSwitch_ScreenNum2;
							}
						}
						goto RETURN_POINT;
					}

				}else{	/* ������ �� ��� */
					for(l=0;l<iBaseScreenCnt;l++){
						if(iNowScreen == Screen[l].iNum){
							iPassPoint = l;
							break;
						}
					}
					if(iPassLevel < Screen[iPassPoint].iSecurity){
						ret = 100;
					}
				}
			}
			if(iLastTagFlag != ON || iOverFlagNum != 0){
				iFilePointer	= 10;	
				iOffset			= 10;		
			}
		}else if(iType == 1){	/* Window File�� ���. */
			/* Key-Window Or Password */
			iScreenNo = SCREEN_1;
			vWindowFreemeil(); /* Window���� ���� �޸� ����. */
			SwitchingScreenDevice.iBaseScreenFlag = 0;

			ClockDispCnt		= ClockDispCnt1;
			CommentDispCnt		= CommentDispCnt1;		/* CommentDisplayTag Counter		*/
			AlarmHistoryDispCnt	= AlarmHistoryDispCnt1;	/* AlarmHistoryDisplayTag Counter	*/
			AlarmListDispCnt	= AlarmListDispCnt1;	/* AlarmListDisplayTag Counter		*/
			PartDispCnt			= PartDispCnt1;			/* PartDisplayTag Counter			*/
			LampDispCnt			= LampDispCnt1;			/* LampDisplayTag Counter			*/
			PanelMeterDispCnt	= PanelMeterDispCnt1;	/* PanelMeterTag Counter			*/
			TrendGraphDispCnt	= TrendGraphDispCnt1;	/* TrendGraphDisplayTag Counter		*/
			LineGraphDispCnt	= LineGraphDispCnt1;	/* LineGraphDisplayTag Counter		*/
			BarGraphDispCnt		= BarGraphDispCnt1;		/* BarGraphDisplayTag Counter		*/
			StatisticsDispCnt	= StatisticsDispCnt1;	/* StatisticsDisplayTag Counter		*/
			ScalePosCnt         = ScalePosCnt1;
			TouchSwitchDispCnt	= TouchSwitchDispCnt1;	/* TouchSwitchDisplayTag Counter	*/
			NumericInputCnt		= NumericInputCnt1;		/* NumericInputTag Counter			*/
			AsciiInputCnt		= AsciiInputCnt1;		/* AsciiInputisplayTag Counter		*/	
			iDeviceSearchCnt	= iDeviceSearchCnt1;
			DeviceCnt			= DeviceCnt1;
/*			IventTableCnt		= IventTableCnt1;*/
			if(CommonArea.KeyWindow.iDefault == 0 || CommonArea.KeyWindow.iFlagData == 1){
				CommonArea.KeyWindow.iFlagData = 1;
				iSize = 2048;
				cTagBuf=(unsigned char *)GetKeyWinAddr(CommonArea.KeyWindow.iKeyType);
#ifdef	SIZE_2480
				if(TateYoko == 0){
					if(CommonArea.KeyWindow.iKeyType == KEY_BINARY ||
						CommonArea.KeyWindow.iKeyType == KEY_OCTAL)
						iSizePx = 132;
					else if(CommonArea.KeyWindow.iKeyType == KEY_DECIMAL)
						iSizePx = 162;
					else if(CommonArea.KeyWindow.iKeyType == KEY_HEX ||
						CommonArea.KeyWindow.iKeyType == KEY_REAL ||
						CommonArea.KeyWindow.iKeyType == KEY_ASCII)
						iSizePx = 196;
					iSizePy = (WINDOW_Y_SIZE-1);
				}else{
					if(CommonArea.KeyWindow.iKeyType == KEY_BINARY)
						iSizePy = 132;
					else if(CommonArea.KeyWindow.iKeyType == KEY_OCTAL)
						iSizePy = 135;
					else if(CommonArea.KeyWindow.iKeyType == KEY_DECIMAL)
						iSizePy = 169;
					else if(CommonArea.KeyWindow.iKeyType == KEY_HEX)
						iSizePy = 215;
					else if(CommonArea.KeyWindow.iKeyType == KEY_REAL)
						iSizePy = 201;
					else if(CommonArea.KeyWindow.iKeyType == KEY_ASCII)
						iSizePy = 203;
					iSizePx = (WINDOW_Y_SIZE-1);
				}
#endif
#ifdef	SIZE_3224
				if(TateYoko == 0){
					if(CommonArea.KeyWindow.iKeyType == KEY_BINARY ||
						CommonArea.KeyWindow.iKeyType == KEY_OCTAL)
						iSizePx = 161;
					else if(CommonArea.KeyWindow.iKeyType == KEY_DECIMAL)
						iSizePx = 201;
					else if(CommonArea.KeyWindow.iKeyType == KEY_HEX ||
						CommonArea.KeyWindow.iKeyType == KEY_REAL ||
						CommonArea.KeyWindow.iKeyType == KEY_ASCII)
						iSizePx = 241;
					iSizePy = (WINDOW_Y_SIZE-1);
				}else{
					if(CommonArea.KeyWindow.iKeyType == KEY_BINARY)
						iSizePy = 132;
					else if(CommonArea.KeyWindow.iKeyType == KEY_OCTAL)
						iSizePy = 135;
					else if(CommonArea.KeyWindow.iKeyType == KEY_DECIMAL)
						iSizePy = 169;
					else if(CommonArea.KeyWindow.iKeyType == KEY_HEX)
						iSizePy = 215;
					else if(CommonArea.KeyWindow.iKeyType == KEY_REAL)
						iSizePy = 201;
					else if(CommonArea.KeyWindow.iKeyType == KEY_ASCII)
						iSizePy = 203;
					iSizePx = (WINDOW_Y_SIZE-1);
				}
#endif
				OpenWindow(iScreenNo,iSizePx,iSizePy);
				ClearDispBuff(iScreenNo);
				iTouchFlag = 1;
				/* 060203 */
				i= iScreenPosition;
			}else{
				if(CommonArea.KeyWindow.iKeyType == KEY_DECIMAL)
					iNowScreen = CommonArea.KeyWindow.iDecNo;
				else if(CommonArea.KeyWindow.iKeyType == KEY_HEX)
					iNowScreen = CommonArea.KeyWindow.iHexNo;
				else if(CommonArea.KeyWindow.iKeyType == KEY_ASCII)
					iNowScreen = CommonArea.KeyWindow.iAsciiNo;
				else
					iNowScreen = 0;
				sprintf(cPcTempFileName,"WIN%05d.gp ",iNowScreen);
				ret = mfileserch(cPcTempFileName, &iPos, &iSize);
				if(ret != OK || iNowScreen == 0){
					CommonArea.KeyWindow.iFlagData = 1;
					iSize = 2048;
					cTagBuf = (unsigned char*) GetKeyWinAddr(CommonArea.KeyWindow.iKeyType);

					if(TateYoko == 0){
						if(CommonArea.KeyWindow.iKeyType == KEY_BINARY ||
							CommonArea.KeyWindow.iKeyType == KEY_OCTAL)
							iSizePx = 132;
						else if(CommonArea.KeyWindow.iKeyType == KEY_DECIMAL)
							iSizePx = 162;
						else if(CommonArea.KeyWindow.iKeyType == KEY_HEX ||
							CommonArea.KeyWindow.iKeyType == KEY_REAL ||
							CommonArea.KeyWindow.iKeyType == KEY_ASCII)
							iSizePx = 196;
						iSizePy = (GAMEN_Y_SIZE-1);
					}else{
						if(CommonArea.KeyWindow.iKeyType == KEY_BINARY)
							iSizePy = 132;
						else if(CommonArea.KeyWindow.iKeyType == KEY_OCTAL)
							iSizePy = 135;
						else if(CommonArea.KeyWindow.iKeyType == KEY_DECIMAL)
							iSizePy = 169;
						else if(CommonArea.KeyWindow.iKeyType == KEY_HEX)
							iSizePy = 215;
						else if(CommonArea.KeyWindow.iKeyType == KEY_REAL)
							iSizePy = 201;
						else if(CommonArea.KeyWindow.iKeyType == KEY_ASCII)
							iSizePy = 203;
						iSizePx = (GAMEN_Y_SIZE-1);
					}
					iTouchFlag = 1;
					ret = OK;
				}else{
					cTagBuf=(unsigned char *)iPos;
					iSum = ((int)cTagBuf[8]*256)+(int)cTagBuf[9]+73+8;

					iSizePx = ((int)cTagBuf[iSum])*256;
					iSum++;
					iSizePx += (int)cTagBuf[iSum];
					iSum++;
					iSizePy = ((int)cTagBuf[iSum])*256;
					iSum++;
					iSizePy += (int)cTagBuf[iSum];
				}
				OpenWindow(iScreenNo,iSizePx,iSizePy);
				ClearDispBuff(iScreenNo);
				/* 060920 */
				i= iScreenPosition;
			}
			/* Screen Size Set */
			SetScreenSize(iPassFlag,iSizePx,iSizePy,i);
			if(iLastTagFlag != ON){
				iFilePointer = 10;	/* iFilePointer = 11; */
				iOffset = 10;		/* iOffset = 11; */
			}
			iDispOrder = iGlobleOrder;
//20080818 - �±� ���� ǥ�� ����
#ifdef	OLD
			Checkaddr= KeyWinCheck_ey / TOUCH_Y_SIZE;
			if(KeyWinCheck_ey % TOUCH_Y_SIZE){
				Checkaddr++;
			}
			Checkaddr *= TOUCH_Y_SIZE;
			if(Checkaddr < (GAMEN_Y_SIZE- iSizePy)){	iWinStartPy= Checkaddr;					}
			else{
				if(KeyWinCheck_sy > iSizePy){			iWinStartPy= KeyWinCheck_sy- iSizePy;	}
				else{									iWinStartPy= Checkaddr- iSizePy- 1;		}
			}
			Checkaddr= KeyWinCheck_ex / TOUCH_X_SIZE;
			if(KeyWinCheck_ex % TOUCH_X_SIZE){
				Checkaddr++;
			}
			Checkaddr *= TOUCH_X_SIZE;
			if(Checkaddr < (GAMEN_X_SIZE- iSizePx)){	iWinStartPx= Checkaddr;					}
			else{
				if(KeyWinCheck_sx > iSizePx){			iWinStartPx= KeyWinCheck_sx- iSizePx;	}
				else{									iWinStartPx= GAMEN_X_SIZE- iSizePx- 1;		}
			}
			iWinEndPx= iWinStartPx+ iSizePx;
			iWinEndPy= iWinStartPy+ iSizePy;
#endif
		}
		SetStartPos(iScreenNo ,iWinStartPx,iWinStartPy);
		if(ret == OK){
			/* 050426 */
			iBackColor= 0;
			if((mode != 0) || (iPassFlag != 0)){
				iBackColor= NowBackColor(iNowScreenNum);
			}
			/* TAG Info */
			if((mode == 0) && (iPassFlag != 0)){	/* PassWord */
				MakeTaginfo(iScreenNo,cTagBuf,&iOffset,&iLastTag,iFilePointer,&iLastTagFlag,&iObjectSel,iPos,1,iBackColor);
			}else{
				MakeTaginfo(iScreenNo,cTagBuf,&iOffset,&iLastTag,iFilePointer,&iLastTagFlag,&iObjectSel,iPos,mode,iBackColor);
			}
		}
		if(iType==0){
			iGlobleOrder = iDispOrder;	/* Tag�� ���� */
			ClockDispCnt1		= ClockDispCnt;
			CommentDispCnt1		= CommentDispCnt;		/* CommentDisplayTag Counter */
			AlarmHistoryDispCnt1= AlarmHistoryDispCnt;	/* AlarmHistoryDisplayTag Counter */
			AlarmListDispCnt1	= AlarmListDispCnt;		/* AlarmListDisplayTag Counter */
			PartDispCnt1		= PartDispCnt;			/* PartDisplayTag Counter */
			LampDispCnt1		= LampDispCnt;			/* LampDisplayTag Counter */
			PanelMeterDispCnt1	= PanelMeterDispCnt;	/* PanelMeterTag Counter */
			TrendGraphDispCnt1	= TrendGraphDispCnt;	/* TrendGraphDisplayTag Counter */
			LineGraphDispCnt1	= LineGraphDispCnt;		/* LineGraphDisplayTag Counter */
			BarGraphDispCnt1	= BarGraphDispCnt;		/* BarGraphDisplayTag Counter */
			StatisticsDispCnt1	= StatisticsDispCnt;	/* StatisticsDisplayTag Counter */
			ScalePosCnt1        = ScalePosCnt;
			TouchSwitchDispCnt1	= TouchSwitchDispCnt;	/* TouchSwitchDisplayTag Counter */
			NumericInputCnt1	= NumericInputCnt;		/* NumericInputTag Counter */
			AsciiInputCnt1		= AsciiInputCnt;		/* AsciiInputisplayTag Counter */	
			iDeviceSearchCnt1	= iDeviceSearchCnt;
			DeviceCnt1			= DeviceCnt;
/*			IventTableCnt1		= IventTableCnt;*/
		}else if(iType ==1){

		}

		if((iOverFlagNum > iOverScreenCnt) && (ret == OK || ret == 100 || ret == 50) && iScreenDisp == 0 && iOverFlagNum > 0){
			iOverScreenCnt++;
			goto RETURN_POINT;
		}
	}else{
		/****************************** ȭ�� DATA�� ���� �� �޼��� ǥ�� ***********************/
		TateYoko	= 0;
		iScreenNo	= 0;		/* Dumy******** */
		SetWinSema();
		ClearDispBuff(SCREEN_0);
		RECParam.iLineStyle = SOLID_LINE;
		RECParam.iLineColor = WHITE;
		RECParam.iPattern	= PAT8;
		RECParam.iForeColor = WHITE;
		RECParam.iBackColor = WHITE;
		if(TateYoko == 0){
			// User data nothing message
			cScreenBuff = (char*)TakeMemory(30);
			memset(cScreenBuff,0x00,30);
			sprintf(cScreenBuff,"%s%s%s%s", Dspname[NO_USE_MESS].chName[Set.iLang][0],
											Dspname[NO_USE_MESS].chName[Set.iLang][1],
											Dspname[NO_USE_MESS].chName[Set.iLang][2],
											Dspname[NO_USE_MESS].chName[Set.iLang][3]);
//			StartXAddr= (GAMEN_X_SIZE- strlen(cScreenBuff)*8)/2;
//			StartYAddr= (GAMEN_Y_SIZE- 16)/2;
//			RectAngleOut(16,14,223,40,&RECParam);
//			DotTextOut(25,19,cScreenBuff,1,1, TRANS, T_BLACK, T_WHITE);
//			RectAngleOut(StartXAddr-9,StartYAddr-5,StartXAddr+strlen(cScreenBuff)*8+9,StartYAddr+21,&RECParam);
//			DotTextOut(StartXAddr,StartYAddr,cScreenBuff,1,1, TRANS, T_BLACK, T_WHITE);
//20080819
			StartXAddr= (GAMEN_X_SIZE/2) - (strlen(cScreenBuff)*8)/2;
			StartYAddr= GAMEN_Y_SIZE/4;

			RectAngleOut(StartXAddr-9,StartYAddr-5,StartXAddr+strlen(cScreenBuff)*8+9,StartYAddr+21,&RECParam);
			DotTextOut(StartXAddr,StartYAddr,cScreenBuff,1,1, TRANS, T_BLACK, T_WHITE);

			/*	"USER SCREEN IS NOT FOUND" DISPLAY ����� ȭ���� �����ϴ�. 	*/
			FreeMail((char *)cScreenBuff);
		}else{
#ifdef	SIZE_2480	
			RectAngleOut(GAMEN_START_X+5,GAMEN_START_Y+26,GAMEN_START_X+74,GAMEN_START_Y+133,&RECParam);
			DotTextOut(GAMEN_START_X+8,GAMEN_START_Y+33,Dspname[NO_USE_MESS].chName[Set.iLang][0],1,1, TRANS, T_BLACK, T_WHITE);
			DotTextOut(GAMEN_START_X+8,GAMEN_START_Y+53,Dspname[NO_USE_MESS].chName[Set.iLang][1],1,1, TRANS, T_BLACK, T_WHITE);
			DotTextOut(GAMEN_START_X+8,GAMEN_START_Y+73,Dspname[NO_USE_MESS].chName[Set.iLang][2],1,1, TRANS, T_BLACK, T_WHITE);
			DotTextOut(GAMEN_START_X+8,GAMEN_START_Y+93,Dspname[NO_USE_MESS].chName[Set.iLang][3],1,1, TRANS, T_BLACK, T_WHITE);
#endif
		}
		SetStartPos(iScreenNo,0,0);
		DrawLcdBank1();
		ResetWinSema();
		/**************************************************************************************/
		if(Screen[0].iNum != 0){
			for(i = 0; i<512 ; i++){
				Screen[i].iNum = 0x00;
				Screen[i].chTitle = 0x00;
			}
			iBaseScreenCnt = 0;
		}
	}/* end if */
/* 060920	if((mode == 1) || (iPassFlag != 0)){*/
	if(iPassFlag != 0){
	}else{
		if(iFirstScreen == 2){
			SystemDevEntry();
			iFirstScreen = 0;
		}else{
			SystemDevNoClearEntry();
		}

/* 20080822 ȭ�� ǥ�ý� ����Ÿ�� �о�ͼ� ǥ���ϵ��� ó���� */		
/* ���� �ڸ�Ʈ ó���ϸ� 0ǥ���� ���� ����Ÿ ǥ���� */
		if(((mode == 0) || (mode == 1)) && (iPassFlag == 0)){		/* 050420 */
			PlcDevInitRead(0);
		}
	}
	OnSignal(SGN_PLC,1);
	OnSignal(S_PROJECT,1);
	
	if((ret != OK || iTotalCnt == 0 || iObjectSel == FIGURE || iLastTag == ON) && 
		(pcFileCnt != 0 || (iUserScreenFlag == 2 && iWinScreenCnt > 0))){
		if((CommonArea.ProjectAuxSet.DispCursorWindow == 0x00) && (mode == 0)){		/* 070209 mode �ǉ� */
			InputDisplay.iKeyOnOff = 0;
		}
		iOnSignalStart = ON;
		Regmp = (T_MAIL *)TakeMail();
		Regmp->mpec = iScreenNo;
		SendMail(T_CLASSIFICATION,(char *)Regmp);
	}
}

