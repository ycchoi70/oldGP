void		ModelVerDisp(int* iScreenNo);
void		vContypeDisplay(int* iScreenNo);
