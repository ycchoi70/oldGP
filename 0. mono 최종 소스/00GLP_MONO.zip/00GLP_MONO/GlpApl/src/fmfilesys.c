/******************************************************************************
*                         (�L)�R?�e�b�N 2001,2002                          
*******************************************************************************
* System             :FlashRom Filesystem                                  
* FileName           :Gb_fmfilesys.c                                       
* Summary            :�t���b�V���t?�C���V�X�e?�֘A��?���s���܂��B          
* Programmer         :�S�ωp                                               
* Create Date        :2002/02/26                                           
******************************************************************************/
/*
|-----------------------------------------------------------------------------|
| Sector N0     |                Area                          | Cluster No   |
|-----------------------------------------------------------------------------|
|  0            | FE  |                                                       |
|---------------|-----|--  FAT                                                |
|  .            |                                                             |
|  .            |                                                             |
|---------------|                                                             |
|  1            |                                                             |
|-----------------------------------------------------------------------------|
|  2            | ROOT DIRECTORY                                              |
|---------------|                                                             |
|  .            |                                                             |
|  .            |                                                             |
|---------------|                                                             |
|  13           |                                                             |
|---------------|-------------------------------------------------------------|
|   2           | DATA                                        |      1        |
|---------------|                                             |---------------|
|   3           |                                             |      2        |
|---------------|                                             |---------------|
|  .            |                                             |      .        |
|  .            |                                             |      .        |
|               |                                             |               |
|---------------|                                             |---------------|
|  N(991)       |                                             |   N-15(976)   |
|-----------------------------------------------------------------------------|
*/
#include	"sgt.h"



/*#define	REWRITE	1*/			//�t?�C���������݂������C�g��?�h�ŏ���

extern	int		TateYoko;


#define NO_DIR_SECT (GP_TOTAL_SECT/(SECT_SIZE/sizeof(struct dir)))       /*  16  */
#define NO_PLC_DIR_SECT (PLC_TOTAL_SECT/(SECT_SIZE/sizeof(struct dir)))       /*  16  */

volatile unsigned char  *gfmbuf;			/*�t���b�V���������̈�  */
volatile unsigned short *fatbuf;         /*FAT�̈�              */
volatile unsigned char  *dirbuf;			/*��?�g�f�B���N�g���̈�*/
volatile unsigned short *fat_dt;

volatile unsigned char  *gfmbuf2;		/*�t���b�V���������̈�  */
volatile unsigned short *fatbuf2;        /*FAT�̈�              */
volatile unsigned char  *dirbuf2;		/*��?�g�f�B���N�g���̈�*/
volatile unsigned short *fat_dt2;

int		RewriteFlag;
//extern  _SETUP		Set;					/* ������ ����E����ü						*/
void	Vmemcpy(volatile char *obj,volatile char *src,int cnt)
{
#ifdef	WIN32
	 memcpy((char *)obj,(char*)src,cnt);
#else
	int	i;

	for(i= 0; i < cnt; i++){
		*obj++ = *src++;
	}
#endif
}
int	Vmemcmp(volatile char *obj,volatile char *src,int cnt)
{
#ifdef	WIN32
	return(memcmp((char *)obj,(char *)src,cnt));
#else
	int	i,ret;

	ret= 0;
	for(i= 0; i < cnt; i++){
		if(*obj++ != *src++){
			ret= 1;
			break;
		}
	}
	return(ret);
#endif
}
/******************************************************************************
'Procedure          :FM_init
'Summary            :����������
'Parameters         :�Ȃ�
'Return Value       :�Ȃ�
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
void FM_init()
{
#ifdef	WIN32
	gfmbuf=  (volatile unsigned char*)&GpFont[F_FILE_AREA];
	dirbuf=  (volatile unsigned char  *)&GpFont[F_DIR_AREA];	/* + Settei Area */
	fatbuf=  (volatile unsigned short *)&GpFont[F_FAT_AREA];
	gfmbuf2= (volatile unsigned char*)&GpFont[F_FILE_AREA2];
	dirbuf2= (volatile unsigned char  *)&GpFont[F_DIR_AREA2];	/* + Settei Area */
	fatbuf2= (volatile unsigned short *)&GpFont[F_FAT_AREA2];
#else
	gfmbuf=  (volatile unsigned char*)F_FILE_AREA;
	dirbuf=  (volatile unsigned char  *)F_DIR_AREA;	/* + Settei Area */
	fatbuf=  (volatile unsigned short *)F_FAT_AREA;
	gfmbuf2= (volatile unsigned char*)F_FILE_AREA2;
	dirbuf2= (volatile unsigned char  *)F_DIR_AREA2;	/* + Settei Area */
	fatbuf2= (volatile unsigned short *)F_FAT_AREA2;
#endif
}
/******************************************************************************
'Procedure          :FM_read1sect
'Summary            :1�����ǂݍ��ݏ���
'Parameters         :���΃Z�N?�ԍ�,�R�s?��̃o�b�t?
'Return Value       :OK(0),GP_ERROR (-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
short  FM_read1sect(long pos,char buf[])
{
	if(pos < 0 || pos > GP_TOTAL_SECT ){
		return(GP_ERROR);
	}
	Vmemcpy((volatile char*)buf,(volatile char*)&gfmbuf[pos*SECT_SIZE],SECT_SIZE);
	return(OK);
}
short  FM_read1sect2(long pos,char buf[])
{
	if(pos < 0 || pos > PLC_TOTAL_SECT ){
		return(GP_ERROR);
	}
	Vmemcpy((volatile char*)buf,(volatile char*)&gfmbuf2[pos*SECT_SIZE],SECT_SIZE);
	return(OK);
}
/******************************************************************************
'Procedure          :FM_write1sect
'Summary            :1���������ݏ���
'Parameters         :���΃Z�N?�ԍ�,�R�s?���̃o�b�t?
'Return Value       :OK(0),GP_ERROR (-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
short  FM_write1sect(long pos,char buf[])
{
	if(pos < 0 || pos > GP_TOTAL_SECT ){
		return(GP_ERROR );
	}
#ifdef	WIN32
	memcpy((char*)&gfmbuf[pos*SECT_SIZE],buf,SECT_SIZE);
#else
	RamFlashWrite((short *)&gfmbuf[pos*SECT_SIZE],(short *)buf,SECT_SIZE);
#endif
	return(OK);
}
short  FM_write1sect2(long pos,char buf[])
{
	if(pos < 0 || pos > PLC_TOTAL_SECT ){
		return(GP_ERROR );
	}
#ifdef	WIN32
	memcpy((char*)&gfmbuf2[pos*SECT_SIZE],buf,SECT_SIZE);
#else
	RamFlashWrite((short *)&gfmbuf2[pos*SECT_SIZE],(short *)buf,SECT_SIZE);
#endif
	return(OK);
}
/******************************************************************************
'Procedure          :FM_search_dir
'Summary            :�ިڸ�ػ������
'Parameters         :�t?�C����?�g���q,�t?�C����?�C��?
'Return Value       :OK(0),NOTFOUND(1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
short  FM_search_dir(char name[],I_FILE *id)
{
    int sect;
    int pos;
    volatile struct dir *dir;

    for(sect = 0; sect < NO_DIR_SECT; sect++) {
        for(pos = 0; pos < SECT_SIZE; pos += sizeof(struct dir)) {
            dir = (volatile struct dir *)&(dirbuf[sect*SECT_SIZE+pos]);
            if(Vmemcmp((volatile char*)name,(volatile char*)dir->name_ext,8+3)==0  && (dir->attr & 0x18)==0) {
              /* ���������ꍇ���𓾂� */
              id->dir_sect = sect+DIR_BASE; /* ���΃Z�N?�ԍ�*/
              id->dir_pos = pos;            /* �Z�N?���̃f�B���N�g���̈ʒu*/
              id->attr = dir->attr;         /* �t?�C������*/
              id->size = dir->f_size;       /* �t?�C���T�C�Y*/
              id->top_cluster = dir->f_top; /* �J�n�N���X?*/
                                            /* ����*/
              if(id->mode == MODE_READ){
                id->time = dir->time;
                id->date = dir->date;
              }
              return(OK);
            }
        }
    }
    return(NOTFOUND);
}
short  FM_search_dir2(char name[],I_FILE *id)
{
    int sect;
    int pos;
    volatile struct dir *dir;

    for(sect = 0; sect < NO_PLC_DIR_SECT; sect++) {
        for(pos = 0; pos < SECT_SIZE; pos += sizeof(struct dir)) {
            dir = (volatile struct dir *)&(dirbuf2[sect*SECT_SIZE+pos]);
            if(Vmemcmp((volatile char*)name,(volatile char*)dir->name_ext,8+3)==0  && (dir->attr & 0x18)==0) {
              /* ���������ꍇ���𓾂� */
              id->dir_sect = sect+DIR_BASE; /* ���΃Z�N?�ԍ�*/
              id->dir_pos = pos;            /* �Z�N?���̃f�B���N�g���̈ʒu*/
              id->attr = dir->attr;         /* �t?�C������*/
              id->size = dir->f_size;       /* �t?�C���T�C�Y*/
              id->top_cluster = dir->f_top; /* �J�n�N���X?*/
                                            /* ����*/
              if(id->mode == MODE_READ){
                id->time = dir->time;
                id->date = dir->date;
              }
              return(OK);
            }
        }
    }
    return(NOTFOUND);
}
short  FM_find_dir(char name[],I_FILE *id,int FirstSec,int FirstPos)
{
    int sect;
    int pos;
    volatile struct dir *dir;
	int		i,j;

	sect= FirstSec;
	pos= FirstPos;
    for(; sect < NO_DIR_SECT; sect++) {
        for(; pos < SECT_SIZE; pos += sizeof(struct dir)) {
            dir = (volatile struct dir *)&(dirbuf[sect*SECT_SIZE+pos]);
			for(i = 0; i < 8+3; i++){
				if(name[i] == '?'){
					continue;
				}
				if(name[i] != dir->name_ext[i]){
					break;
				}
			}
            if((i == 8+3)  && ((dir->attr & 0x18)==0)) {
              /* ���������ꍇ���𓾂� */
              id->dir_sect = sect; /* ���΃Z�N?�ԍ�*/
              id->dir_pos = pos;            /* �Z�N?���̃f�B���N�g���̈ʒu*/
              id->attr = dir->attr;         /* �t?�C������*/
              id->size = dir->f_size;       /* �t?�C���T�C�Y*/
              id->top_cluster = dir->f_top; /* �J�n�N���X?*/
                                            /* ����*/
	          id->time = dir->time;
		      id->date = dir->date;
			  for(i= 0; i < 8; i++){
				  id->name[i]= dir->name_ext[i];
			  }
			  id->name[i++]= '.';
			  for(j= 0; j < 3; j++){
				  id->name[i++]= dir->name_ext[8+ j];
			  }
              return(OK);
            }
        }
		pos= 0;
    }
    return(NOTFOUND);
}
short  FM_find_dir2(char name[],I_FILE *id,int FirstSec,int FirstPos)
{
    int sect;
    int pos;
    volatile struct dir *dir;
	int		i,j;

	sect= FirstSec;
	pos= FirstPos;
    for(; sect < NO_PLC_DIR_SECT; sect++) {
        for(; pos < SECT_SIZE; pos += sizeof(struct dir)) {
            dir = (volatile struct dir *)&(dirbuf2[sect*SECT_SIZE+pos]);
			for(i = 0; i < 8+3; i++){
				if(name[i] == '?'){
					continue;
				}
				if(name[i] != dir->name_ext[i]){
					break;
				}
			}
            if((i == 8+3)  && ((dir->attr & 0x18)==0)) {
              /* ���������ꍇ���𓾂� */
              id->dir_sect = sect; /* ���΃Z�N?�ԍ�*/
              id->dir_pos = pos;            /* �Z�N?���̃f�B���N�g���̈ʒu*/
              id->attr = dir->attr;         /* �t?�C������*/
              id->size = dir->f_size;       /* �t?�C���T�C�Y*/
              id->top_cluster = dir->f_top; /* �J�n�N���X?*/
                                            /* ����*/
	          id->time = dir->time;
		      id->date = dir->date;
			  for(i= 0; i < 8; i++){
				  id->name[i]= dir->name_ext[i];
			  }
			  id->name[i++]= '.';
			  for(j= 0; j < 3; j++){
				  id->name[i++]= dir->name_ext[8+ j];
			  }
              return(OK);
            }
        }
		pos= 0;
    }
    return(NOTFOUND);
}
/******************************************************************************
'Procedure          :FM_search_new_dir
'Summary            :���ިڸ�ذ�̈�̌����A�����ݏ���
'Parameters         :�t?�C����?�C��?
'Return Value       :OK(0),ERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
short  FM_search_new_dir(I_FILE *id)
{
    int sect;
    int pos;
    volatile struct dir *dir;
    unsigned char c;

    for(sect=0; sect<NO_DIR_SECT; sect++) {
        for(pos=0; pos<SECT_SIZE; pos+=sizeof(struct dir)) {
            dir=(volatile struct dir *)&(dirbuf[sect*SECT_SIZE+pos]);
            c=dir->name_ext[0];
            if(c == DELETED) {
                id->dir_sect=sect+DIR_BASE; /* ���΃Z�N?�ԍ�*/
                id->dir_pos =pos;           /* �Z�N?���̃f�B���N�g���̈ʒu*/
				return(OK);
            }
        }
    }
    return(GP_ERROR );
}
short  FM_search_new_dir2(I_FILE *id)
{
    int sect;
    int pos;
    volatile struct dir *dir;
    unsigned char c;

    for(sect=0; sect<NO_PLC_DIR_SECT; sect++) {
        for(pos=0; pos<SECT_SIZE; pos+=sizeof(struct dir)) {
            dir=(volatile struct dir *)&(dirbuf2[sect*SECT_SIZE+pos]);
            c=dir->name_ext[0];
            if(c == DELETED) {
                id->dir_sect=sect+DIR_BASE; /* ���΃Z�N?�ԍ�*/
                id->dir_pos =pos;           /* �Z�N?���̃f�B���N�g���̈ʒu*/
				return(OK);
            }
        }
    }
    return(GP_ERROR );
}
/******************************************************************************
'Procedure          :FM_put_fat
'Summary            :FAT�����ݏ���
'Parameters         :�Ȃ�
'Return Value       :�Ȃ�
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
void  FM_put_fat()
{
    unsigned short  dln;

	dln= 0xfffe;
#ifdef	WIN32
	*fat_dt= dln;
#else
	RamFlashWrite((short *)fat_dt,(short *)&dln,2);
#endif
}
void  FM_put_fat2()
{
    unsigned short  dln;

	dln= 0xfffe;
#ifdef	WIN32
	*fat_dt2= dln;
#else
	RamFlashWrite((short *)fat_dt2,(short *)&dln,2);
#endif
}
/******************************************************************************
'Procedure          :FM_put_dir
'Summary            :DIR�������ݏ���
'Parameters         :�t?�C����?�C��?
'Return Value       :OK(0),ERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
short  FM_put_dir(I_FILE *id)
{
    struct dir  dir;
#ifndef	WIN32
	unsigned char *mp;
#endif

/*    dir = (struct dir *)&(dirbuf[id->dir_sect-DIR_BASE+id->dir_pos]);*/
    memcpy(dir.name_ext,id->name,8+3); /* �t?�C����?�g���q*/
    dir.attr = (unsigned char)(ATTR_ARC | id->attr); /* ����*/

    dir.time = id->time; /* ����*/
    dir.date = id->date; /* ����*/

    dir.f_top = (unsigned short)id->top_cluster; /* �J�n�N���X?*/
    dir.f_size = (unsigned long)id->size; /* �t?�C���T�C�Y*/
#ifdef	WIN32
    memcpy((char*)&dirbuf[id->dir_sect*SECT_SIZE+id->dir_pos],(char *)&dir,sizeof(struct dir));
#else
	if(RewriteFlag != 0){		/* Dir Area Rewrite Flag */
		mp= (unsigned char *)TakeMemory(0x8000);
		Vmemcpy((volatile char*)mp,(volatile char *)GP_FILE_DIR,0x8000);
		Vmemcpy((volatile char*)&mp[0],(volatile char*)dirbuf,GP_FILE_DIR_SIZE);
	    Vmemcpy((volatile char*)&mp[id->dir_sect*SECT_SIZE+id->dir_pos],(volatile char*)&dir,sizeof(struct dir));
		RamFlashEraze((short *)dirbuf);
	    RamFlashWrite((short *)dirbuf,(short *)mp,0x8000);
		FreeMail((char *)mp);
		RewriteFlag= 0;
	}else{
	    RamFlashWrite((short *)&dirbuf[id->dir_sect*SECT_SIZE+id->dir_pos],(short *)&dir,sizeof(struct dir));
	}
#endif
    return(OK);
}
int	dFlashErr;
short  FM_put_dir2(I_FILE *id)
{
    struct dir  dir;
#ifndef	WIN32
	unsigned char *mp;
	int	start_pos;
		int	i;
		volatile unsigned short*	chkAddr;
		volatile unsigned short	chkdata;
#endif

/*    dir = (struct dir *)&(dirbuf[id->dir_sect-DIR_BASE+id->dir_pos]);*/
    memcpy(dir.name_ext,id->name,8+3); /* �t?�C����?�g���q*/
    dir.attr = (unsigned char)(ATTR_ARC | id->attr); /* ����*/

    dir.time = id->time; /* ����*/
    dir.date = id->date; /* ����*/

    dir.f_top = (unsigned short)id->top_cluster; /* �J�n�N���X?*/
    dir.f_size = (unsigned long)id->size; /* �t?�C���T�C�Y*/
#ifdef	WIN32
    Vmemcpy((volatile char*)&dirbuf2[id->dir_sect*SECT_SIZE+id->dir_pos],(volatile char*)&dir,sizeof(struct dir));
#else
	if(RewriteFlag != 0){		/* Dir Area Rewrite Flag */
		mp= (unsigned char *)TakeMemory(0x8000);
		Vmemcpy((volatile char*)&mp[0],(volatile char*)GP_FILE_DIR,0x8000);
		start_pos= PLC_FILE_DIR-GP_FILE_DIR;
		Vmemcpy((volatile char*)&mp[start_pos],(volatile char*)dirbuf2,PLC_FILE_DIR_SIZE);
	    Vmemcpy((volatile char*)&mp[id->dir_sect*SECT_SIZE+id->dir_pos+ start_pos],(volatile char*)&dir,sizeof(struct dir));
		RamFlashEraze((short *)GP_FILE_DIR);
	    RamFlashWrite((short *)GP_FILE_DIR,(short *)mp,0x8000);
		FreeMail((char *)mp);
		RewriteFlag= 0;
	}else{
		chkAddr= (unsigned short*)&dirbuf2[id->dir_sect*SECT_SIZE+id->dir_pos];
		dFlashErr= 0;
		for(i= 0; i < 16; i++){
			chkdata= *chkAddr++;
			if(chkdata != (unsigned short)0xffff){
				dFlashErr= 1;
				break;
			}
		}
		if(dFlashErr == 1){
			dFlashErr= 2;
			return NG;
		}
	    RamFlashWrite((short *)&dirbuf2[id->dir_sect*SECT_SIZE+id->dir_pos],(short *)&dir,sizeof(struct dir));
	}
#endif
    return(OK);
}
/******************************************************************************
'Procedure          :FM_next_sector
'Summary            :���̾�����������
'Parameters         :�t?�C����?�C��?
'Return Value       :OK(0),ERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
short  FM_next_sector(I_FILE *id,int mode)
{
    long next;
#ifndef	WIN32			/* 060812 */
	unsigned short	snext;
#endif
    long tmp;
    unsigned short *fat_tp;

    id->readf = 0;/* �ǂݏo�����f??�̎��P*/

    if(id->current == (unsigned long)-1) {
        /* open�������� */
        if(id->top_cluster != 0xffffffff) {
            /* �̈悪�m�ۂ���Ă��� */
            id->current = id->top_cluster;
            id->pos = 0;
        }else{
            /* �̈悪�m�ۂ���Ă��Ȃ� */
                /* ��FAT�̈挟��*/
            for(next = 0; next < (GP_TOTAL_CLAST); next++) {
                fat_dt=(unsigned short *)&fatbuf[next];
                if(*fat_dt == 0xffff){
	                break;
				}
            }
            if(next == (GP_TOTAL_CLAST)){
				return(GP_ERROR );
			}

            id->top_cluster = next; /* �J�n�N���X?*/
            id->current = next;     /* ���݂̃N���X?�ʒu*/
            id->pos = 0;            /* ���ݓǂ݂������̐��?�W�V����*/
            id->readf = 1;          /* �ǂݏo�����f??�̎��P*/
        }
    }else{
        /* current�̎������邩���ׂ� */
        tmp = id->current;
        fat_dt=(unsigned short *)&(fatbuf[tmp]);
        next=*fat_dt;

        if(next<(GP_TOTAL_CLAST)) {
            /* current�̎������� */
            id->current=next;
        }else{
            /*???????????????????????????????????????????????????????????????*/
            /* current�̎����Ȃ� */
            for(next=tmp;next<(GP_TOTAL_CLAST);next++){
                fat_tp=(unsigned short *)&(fatbuf[next]);
                if(*fat_tp == 0xffff){
					fat_tp++;
					next++;
			        break;
				}
            }
            if(next==(GP_TOTAL_CLAST)){
				return(GP_ERROR );
			}
			if(mode == 0){		/* Write */
#ifdef	WIN32
	            *fat_dt=(unsigned short)next;
#else
				snext= (unsigned short)next;		/* 060812 */
	            RamFlashWrite((short *)fat_dt,(short *)&snext,2);
#endif
			}
            id->current=next;
            id->readf=1;
			fat_dt= fat_tp;		/* �Ō�̃Z�N?�ɏ������ނ��� */
            /*???????????????????????????????????????????????????????????????*/
        }
    }
    return(0);
}
short  FM_next_sector2(I_FILE *id,int mode)
{
    long next;
#ifndef	WIN32			/* 060812 */
	unsigned short	snext;
#endif
    long tmp;
    unsigned short *fat_tp;

    id->readf = 0;/* �ǂݏo�����f??�̎��P*/

    if(id->current == (unsigned long)-1) {
        /* open�������� */
        if(id->top_cluster != 0xffffffff) {
            /* �̈悪�m�ۂ���Ă��� */
            id->current = id->top_cluster;
            id->pos = 0;
        }else{
            /* �̈悪�m�ۂ���Ă��Ȃ� */
                /* ��FAT�̈挟��*/
            for(next = 0; next < (PLC_TOTAL_CLAST); next++) {
                fat_dt2=(unsigned short *)&fatbuf2[next];
                if(*fat_dt2 == 0xffff){
	                break;
				}
            }
            if(next == (PLC_TOTAL_CLAST)){
				return(GP_ERROR );
			}

            id->top_cluster = next; /* �J�n�N���X?*/
            id->current = next;     /* ���݂̃N���X?�ʒu*/
            id->pos = 0;            /* ���ݓǂ݂������̐��?�W�V����*/
            id->readf = 1;          /* �ǂݏo�����f??�̎��P*/
        }
    }else{
        /* current�̎������邩���ׂ� */
        tmp = id->current;
        fat_dt2=(unsigned short *)&(fatbuf2[tmp]);
        next=*fat_dt2;

        if(next<(PLC_TOTAL_CLAST)) {
            /* current�̎������� */
            id->current=next;
        }else{
            /*???????????????????????????????????????????????????????????????*/
            /* current�̎����Ȃ� */
            for(next=tmp;next<(PLC_TOTAL_CLAST);next++){
                fat_tp=(unsigned short *)&(fatbuf2[next]);
                if(*fat_tp == 0xffff){
					fat_tp++;
					next++;
			        break;
				}
            }
            if(next==(PLC_TOTAL_CLAST)){
				return(GP_ERROR );
			}
			if(mode == 0){		/* Write */
#ifdef	WIN32
	            *fat_dt2=(unsigned short)next;
#else
				snext= (unsigned short)next;		/* 060812 */
	            RamFlashWrite((short *)fat_dt2,(short *)&snext,2);
#endif
			}
            id->current=next;
            id->readf=1;
			fat_dt2= fat_tp;		/* �Ō�̃Z�N?�ɏ������ނ��� */
            /*???????????????????????????????????????????????????????????????*/
        }
    }
    return(0);
}
/******************************************************************************
'Procedure          :FM_GetFileInfo
'Summary            :̧�ُ��ǂݍ��ݏ���
'Parameters         :�t?�C����?�g���q�A���?�W�V�����A�����A�T�C�Y
'Return Value       :OK(0),NOTFOUND(1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
short  FM_GetFileInfo(int devno,char name[],long *sectp,short *attr,long *size)
{
    int   i,j;
    int sect;
    int pos;
    struct dir *dir;
    char  nbuf[12];
	char	wName[32];

    memset(nbuf,' ',sizeof(nbuf));
    memset(wName,' ',sizeof(wName));

    /* ��������啶���ɕϊ����� */
    for(i=0;(name[i]!='\0') && (i < 32);i++){
/*        name[i]=(char)toupper(name[i]);*/
		if((name[i] >= 'a') && (name[i] <= 'z')){
			wName[i]= name[i]- 'a' + 'A';
		}else{
			wName[i]= name[i];
		}
    }

    for(i = 0,j = 0; (i < 12) && (j < 11); i++){
        if(wName[i] == '\0'){
	      break;
		}
        if(wName[i] == '.'){
            j = 8;
            continue;
        }
        nbuf[j++] = wName[i];
    }
	if(devno == 0){		/* Drive A */
		for(sect = 0; sect < NO_DIR_SECT; sect++) {
			for(pos = 0; pos < SECT_SIZE; pos += sizeof(struct dir)) {
				dir = (struct dir *)&(dirbuf[sect*SECT_SIZE+pos]);
				if(memcmp(nbuf,dir->name_ext,8+3)==0  && (dir->attr & 0x18) == 0) {
					if(sectp != NULL) *sectp = (long)(dir->f_top+ CLAST_BASE)*SECT_SIZE;
					if(attr !=NULL) *attr = dir->attr;
					if(size !=NULL) *size = dir->f_size;
					return(OK);
				}
			}
		}
	}else{
		for(sect = 0; sect < NO_PLC_DIR_SECT; sect++) {
			for(pos = 0; pos < SECT_SIZE; pos += sizeof(struct dir)) {
				dir = (struct dir *)&(dirbuf2[sect*SECT_SIZE+pos]);
				if(memcmp(nbuf,dir->name_ext,8+3)==0  && (dir->attr & 0x18) == 0) {
					if(sectp != NULL) *sectp = (long)(dir->f_top+ CLAST_BASE)*SECT_SIZE;
					if(attr !=NULL) *attr = dir->attr;
					if(size !=NULL) *size = dir->f_size;
					return(OK);
				}
			}
		}
	}
    return(NOTFOUND);
}
/******************************************************************************
'Procedure          :FM_GetDiskSpace
'Summary            :�ި���?��e�ʓǂݍ��ݏ���
'Parameters         :�󂫃N���X?���A�Z�N?�T�C�Y�A�S�N���X?��
'Return Value       :OK(0),ERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
short FM_GetDiskSpace(int devno,short *bx,short *cx,short *dx)
{
    long remain;
    long next;
    unsigned short *fat_dt;
    long lret=0;

	if(devno == 0){
		for(next = 0; next < (GP_TOTAL_CLAST); next++) {
			fat_dt=(unsigned short *)&(fatbuf[next]);
			if((*fat_dt & 0xffff) == 0)   lret++;
		}
		remain = lret*SECT_SIZE;

		*bx = (short)(remain / SECT_SIZE);
		*cx = SECT_SIZE;
		*dx = GP_TOTAL_CLAST;
	}else{
		for(next = 0; next < (PLC_TOTAL_CLAST); next++) {
			fat_dt2=(unsigned short *)&(fatbuf2[next]);
			if((*fat_dt2 & 0xffff) == 0)   lret++;
		}
		remain = lret*SECT_SIZE;

		*bx = (short)(remain / SECT_SIZE);
		*cx = SECT_SIZE;
		*dx = PLC_TOTAL_CLAST;
	}
    if(remain < 0){
        return(GP_ERROR );
    }else{
        return(OK);
    }
}

/******************************************************************************
'Procedure          :FM_Open
'Summary            :̧�ٵ���?��?
'Parameters         :�t?�C����?�C��?
'Return Value       :OK(0),ERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
short FM_Open(I_FILE *id)
{
    short ret;
#ifndef	WIN32
	short *mp;
#endif

	RewriteFlag= 0;		/* Dir Area Rewrite Flag */
    /* �f�B���N�g����񌟍�*/
    ret=FM_search_dir((char *)id->name,id);
    if(ret==GP_ERROR ) {
        return(GP_ERROR);
    }
    if(ret==NOTFOUND) {
        if(id->mode==MODE_READ) {
            return(GP_ERROR );
        }
        /* create file */
        id->top_cluster=(unsigned long)-1;
        id->size       =0;
        id->attr       =ATTR_ARC;
        /* �󂫃f�B���N�g���̈挟���A�쐬*/
        if(FM_search_new_dir(id)) {
            return(GP_ERROR );
        }
    }else{
        if(id->mode==MODE_WRITE) {
#ifdef	WIN32
		    memset((char *)&dirbuf[id->dir_sect*SECT_SIZE+id->dir_pos],0x00,sizeof(struct dir));
#else
			mp= (short *)TakeMemory(sizeof(struct dir));
			memset(mp,0x00,sizeof(struct dir));
		    RamFlashWrite((short *)&dirbuf[id->dir_sect*SECT_SIZE+id->dir_pos],mp,sizeof(struct dir));
			FreeMail((char *)mp);
#endif
			/* create file */
			id->top_cluster=(unsigned long)-1;
			id->size       =0;
			id->attr       =ATTR_ARC;
			/* �󂫃f�B���N�g���̈挟���A�쐬*/
			if(FM_search_new_dir(id)) {
				return(GP_ERROR );
			}
//			RewriteFlag= 1;		/* Dir Area Rewrite Flag */
        }
	}
    /* ��?�h�I����?�t?�C��*/
    if(id->mode!=MODE_READ && (id->attr&1)) {
        return(GP_ERROR );
    }
    id->data    =0;/* �ǂݏ���?�C��?               */
    id->pos     =0;/* ���ݓǂ݂������̐��?�W�V���� */
    id->current =(unsigned long)-1;/* ���݂̃N���X?�ʒu             */
    return(OK);
}
short FM_Open2(I_FILE *id)
{
    short ret;
#ifdef	WIN32
	unsigned short	FatNo;
	unsigned short	FatNo1;
#endif
#ifndef	WIN32
	unsigned short *mp;
//	char *mp_data;
//	int	strpos;
//	unsigned short	sFatNo;
//	unsigned short	*FatData;
#endif

	RewriteFlag= 0;		/* Dir Area Rewrite Flag */
    /* �f�B���N�g����񌟍�*/
    ret=FM_search_dir2((char *)id->name,id);
    if(ret==GP_ERROR ) {
        return(GP_ERROR);
    }
    if(ret==NOTFOUND) {
        if(id->mode==MODE_READ) {
            return(GP_ERROR );
        }
        /* create file */
        id->top_cluster=(unsigned long)-1;
        id->size       =0;
        id->attr       =ATTR_ARC;
        /* �󂫃f�B���N�g���̈挟���A�쐬*/
        if(FM_search_new_dir2(id)) {
            return(GP_ERROR );
        }
    }else{
        if(id->mode==MODE_WRITE) {
#ifdef	WIN32
		/* FAT ���� */
		FatNo= (unsigned short)id->top_cluster;
		if(FatNo != 0xffff){
			while(1){
				if(fatbuf2[FatNo] == 0xfffe){
					fatbuf2[FatNo]= 0xffff;
					break;
				}
				if(fatbuf2[FatNo] == 0xffff){
					break;
				}
				FatNo1= fatbuf2[FatNo];
				fatbuf2[FatNo]= 0xffff;
				FatNo= FatNo1;
			}
		}
		/* DIR ���� */
		memset((char*)&dirbuf2[id->dir_sect*SECT_SIZE+id->dir_pos],0xFF,sizeof(struct dir));
//		    memset(&dirbuf2[id->dir_sect*SECT_SIZE+id->dir_pos],0x00,sizeof(struct dir));
#else
#ifdef	XXXXX
			//Data ���� */
			mp_data= (char *)TakeMemory(0x10000);
			FatNo= (unsigned short)id->top_cluster;
			sFatNo= FatNo/128;		//Start Block
			memcpy(mp_data,(char *)(sFatNo*0x10000+PLC_USER_DATA),0x10000);
			FatData= (unsigned short *)PLC_FAT_DIR;
			while(1){
				if((FatNo/128) != sFatNo){
					RamFlashEraze((short *)(sFatNo*0x10000+PLC_USER_DATA));
					RamFlashWrite((short *)(sFatNo*0x10000+PLC_USER_DATA),(short *)mp_data,0x10000);
					sFatNo= FatNo/128;		//Start Block
					memcpy(mp_data,(char *)(sFatNo*0x10000+PLC_USER_DATA),0x10000);
				}
				memset(&mp_data[(FatNo%128)*SECT_SIZE],0xff,SECT_SIZE);
				if((FatData[FatNo] == 0xfffe) || (FatData[FatNo] == 0xffff)){
					break;
				}
				FatNo= FatData[FatNo];
			}
			RamFlashEraze((short *)(sFatNo*0x10000+PLC_USER_DATA));
			RamFlashWrite((short *)(sFatNo*0x10000+PLC_USER_DATA),(short *)mp_data,0x10000);
			FreeMail((char *)mp_data);
			/* FAT ���� */
			mp= (unsigned short *)TakeMemory(0x2000);
			memcpy(mp,(char *)GP_FAT_DIR,0x2000);
			strpos= 0x0800;
			FatNo= (unsigned short)id->top_cluster;
			if(FatNo != 0xffff){
				while(1){
					if((mp[FatNo+strpos] == 0xfffe) || (mp[FatNo+strpos] == 0xffff)){
						mp[FatNo+strpos]= (unsigned short)0xffff;
						break;
					}
					FatNo1= mp[FatNo+strpos];
					mp[FatNo+strpos]= (unsigned short)0xffff;
					FatNo= FatNo1;
				}
			}
			RamFlashEraze((short *)GP_FAT_DIR);
		    RamFlashWrite((short *)GP_FAT_DIR,(short *)mp,0x2000);
			FreeMail((char *)mp);
			/* DIR ���� */
			mp_data= (char *)TakeMemory(0x8000);
			memcpy(mp_data,(char *)GP_FILE_DIR,0x8000);
			strpos= 0x6000;
			memset(&mp[id->dir_sect*SECT_SIZE+id->dir_pos+strpos],0xff,sizeof(struct dir));
			RamFlashEraze((short *)GP_FILE_DIR);
		    RamFlashWrite((short *)GP_FILE_DIR,(short *)mp,0x8000);
			FreeMail((char *)mp_data);
#else
			mp= (unsigned short *)TakeMemory(sizeof(struct dir));
			memset(mp,0x00,sizeof(struct dir));
		    RamFlashWrite((short *)&dirbuf2[id->dir_sect*SECT_SIZE+id->dir_pos],(short *)mp,sizeof(struct dir));
			FreeMail((char *)mp);
#endif
#endif
			/* create file */
			id->top_cluster=(unsigned long)-1;
			id->size       =0;
			id->attr       =ATTR_ARC;
			/* �󂫃f�B���N�g���̈挟���A�쐬*/
			if(FM_search_new_dir2(id)) {
				return(GP_ERROR );
			}
//			RewriteFlag= 1;		/* Dir Area Rewrite Flag */
        }
	}
    /* ��?�h�I����?�t?�C��*/
    if(id->mode!=MODE_READ && (id->attr&1)) {
        return(GP_ERROR );
    }
    id->data    =0;/* �ǂݏ���?�C��?               */
    id->pos     =0;/* ���ݓǂ݂������̐��?�W�V���� */
    id->current =(unsigned long)-1;/* ���݂̃N���X?�ʒu             */
    return(OK);
}

/******************************************************************************
'Procedure          :FM_WriteHandle
'Summary            :�ް��������ݏ���
'Parameters         :�f??�o�b�t?�A�T�C�Y�A�t?�C����?�C��?
'Return Value       :�������񂾍ő�?�ڐ�(retval),GP_ERROR (-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int FM_WriteHandle(char buf[],unsigned int cnt,I_FILE *id)
{
    unsigned short  retval=0;
    unsigned short  dln;
	int	ret=0;

    while(cnt>0){
      if(id->data==0) {
        /* �o�b�t?�̐擪�Ȃ̂Ŏ��̃Z�N?��p�ӂ��� */
/*        if(FM_next_sector(id,0))  break;*/
        ret= FM_next_sector(id,0);
        if(ret)  break;
        if(id->readf==0) {
          if(FM_read1sect(id->current+CLAST_BASE,(char *)id->dtbuf)) {
            return(GP_ERROR );
          }
        }
      }
      id->readf=0;
      /* �Z�N?�̋󂫗̈�*/
      dln=(SECT_SIZE)-(id->data);
      if(cnt<dln) {
        memcpy(&id->dtbuf[id->data],buf,cnt);
        id->data+=cnt;
        id->pos+=cnt;
        retval+=cnt;
        cnt=0;
      }else{
        memcpy(&id->dtbuf[id->data],buf,dln);
        id->data=0;
        id->pos+=dln;
        buf+=dln;
        retval+=dln;
        cnt-=dln;
        if(FM_write1sect(id->current+CLAST_BASE,(char *)id->dtbuf)){
			return(GP_ERROR );
		}
      }

      if(id->pos >id->size){
        id->size=id->pos;
      }
    }
	if(ret){			/* GP_ERROR 030927 */
		return(ret);
	}
    return(retval);
}
int FM_WriteHandle2(char buf[],unsigned int cnt,I_FILE *id)
{
    unsigned short  retval=0;
    unsigned short  dln;
	int	ret=0;

    while(cnt>0){
      if(id->data==0) {
        /* �o�b�t?�̐擪�Ȃ̂Ŏ��̃Z�N?��p�ӂ��� */
/*        if(FM_next_sector(id,0))  break;*/
        ret= FM_next_sector2(id,0);
        if(ret)  break;
        if(id->readf==0) {
          if(FM_read1sect2(id->current+CLAST_BASE,(char *)id->dtbuf)) {
            return(GP_ERROR );
          }
        }
      }
      id->readf=0;
      /* �Z�N?�̋󂫗̈�*/
      dln=(SECT_SIZE)-(id->data);
      if(cnt<dln) {
        memcpy(&id->dtbuf[id->data],buf,cnt);
        id->data+=cnt;
        id->pos+=cnt;
        retval+=cnt;
        cnt=0;
      }else{
        memcpy(&id->dtbuf[id->data],buf,dln);
        id->data=0;
        id->pos+=dln;
        buf+=dln;
        retval+=dln;
        cnt-=dln;
        if(FM_write1sect2(id->current+CLAST_BASE,(char *)id->dtbuf)){
			return(GP_ERROR );
		}
      }

      if(id->pos >id->size){
        id->size=id->pos;
      }
    }
	if(ret){			/* GP_ERROR 030927 */
		return(ret);
	}
    return(retval);
}
/******************************************************************************
'Procedure          :FM_ReadHandle
'Summary            :�ް��ǂݍ��ݏ���
'Parameters         :�f??�o�b�t?�A�T�C�Y�A�t?�C����?�C��?
'Return Value       :�ǂݍ��񂾍ő�?�ڐ�(retval),GP_ERROR (-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int FM_ReadHandle(char buf[],unsigned int cnt,I_FILE *id)
{
    int  retval=0;
    unsigned short  dln;
    /* ���ݓǂ݂������̐��?�W�V����+�Ǎ��ރT�C�Y */
    if(id->pos + cnt > id->size){
        cnt = (unsigned short)(id->size - id->pos);
    }
    while(cnt > 0){
        if(id->data == 0) {
            /* �o�b�t?�̐擪�Ȃ̂Ŏ��̃Z�N?��p�ӂ��� */
            if(FM_next_sector(id,1))  break;
            if(id->readf == 0) {
                if(FM_read1sect(id->current+CLAST_BASE,(char *)id->dtbuf)) {
                    return(GP_ERROR );
                }
               id->readf = 1;
            }
        }
        dln = (SECT_SIZE) - (id->data);
        if(cnt < dln) {
            memcpy(buf,&id->dtbuf[id->data],cnt);
            id->data += cnt;
            id->pos += cnt;
            retval += cnt;
            cnt = 0;
        }else{
            memcpy(buf,&id->dtbuf[id->data],dln);
            id->data = 0;
            id->pos += dln;
            buf += dln;
            retval += dln;
            cnt -= dln;
        }
    }
    return(retval);
}
int FM_ReadHandle2(char buf[],unsigned int cnt,I_FILE *id)
{
    int  retval=0;
    unsigned short  dln;
    /* ���ݓǂ݂������̐��?�W�V����+�Ǎ��ރT�C�Y */
    if(id->pos + cnt > id->size){
        cnt = (unsigned short)(id->size - id->pos);
    }
    while(cnt > 0){
        if(id->data == 0) {
            /* �o�b�t?�̐擪�Ȃ̂Ŏ��̃Z�N?��p�ӂ��� */
            if(FM_next_sector2(id,1))  break;
            if(id->readf == 0) {
                if(FM_read1sect2(id->current+CLAST_BASE,(char *)id->dtbuf)) {
                    return(GP_ERROR );
                }
               id->readf = 1;
            }
        }
        dln = (SECT_SIZE) - (id->data);
        if(cnt < dln) {
            memcpy(buf,&id->dtbuf[id->data],cnt);
            id->data += cnt;
            id->pos += cnt;
            retval += cnt;
            cnt = 0;
        }else{
            memcpy(buf,&id->dtbuf[id->data],dln);
            id->data = 0;
            id->pos += dln;
            buf += dln;
            retval += dln;
            cnt -= dln;
        }
    }
    return(retval);
}

/******************************************************************************
'Procedure          :FM_MoveFilePointer
'Summary            :̧���߲����ړ�����
'Parameters         :origin ����̃o�C�g���A�����ʒu�A�t?�C����?�C��?
'Return Value       :OK(0),GP_ERROR (-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
long FM_MoveFilePointer(long offset,short origin,I_FILE *id)
{
    long            addr;
    long            pos;

    if(id->mode != MODE_READ) {
        if(id->data != 0 && id->readf == 0 && id->current != 0) {
            if(FM_write1sect(id->current+CLAST_BASE,(char *)id->dtbuf)) return(GP_ERROR );
        }
        if(FM_put_dir(id) < 0)    return(GP_ERROR );
    }
    switch(origin) {
        case M_SEEK_SET: addr = offset;              break;
        case M_SEEK_CUR: addr = offset+id->pos;      break;
        case M_SEEK_END: addr = id->size - offset;   break;
        default      : return(GP_ERROR );
    }
    if(addr < 0) return(GP_ERROR );
    if(id->mode == MODE_READ) {
        if(id->size < (unsigned long)addr)    return(GP_ERROR );
    }
    id->current = 0; /* ���݂̃N���X?�ʒu*/
    id->data = 0;    /* �ǂݏ���?�C��?*/
    /*-----------------------------------------------------------------------*/
    /*???????????????????????????????????????????????????????????????????????*/
    /*-----------------------------------------------------------------------*/
    if(addr > 0) {
        if(FM_next_sector(id,1))  return(GP_ERROR );
        for(pos = addr; pos > SECT_SIZE; pos -= SECT_SIZE) {
            if(FM_next_sector(id,1))  return(GP_ERROR );
        }
        if(FM_read1sect(id->current + CLAST_BASE,(char *)id->dtbuf)) return(GP_ERROR );
        id->readf = 1;
        id->data = (unsigned short)pos;
        if(addr > (long)id->size)    id->size = addr;
    }
    /*-----------------------------------------------------------------------*/
    id->pos  = addr;
    return(addr);
}
long FM_MoveFilePointer2(long offset,short origin,I_FILE *id)
{
    long            addr;
    long            pos;

    if(id->mode != MODE_READ) {
        if(id->data != 0 && id->readf == 0 && id->current != 0) {
            if(FM_write1sect2(id->current+CLAST_BASE,(char *)id->dtbuf)) return(GP_ERROR );
        }
        if(FM_put_dir2(id) < 0)    return(GP_ERROR );
    }
    switch(origin) {
        case M_SEEK_SET: addr = offset;              break;
        case M_SEEK_CUR: addr = offset+id->pos;      break;
        case M_SEEK_END: addr = id->size - offset;   break;
        default      : return(GP_ERROR );
    }
    if(addr < 0) return(GP_ERROR );
    if(id->mode == MODE_READ) {
        if(id->size < (unsigned long)addr)    return(GP_ERROR );
    }
    id->current = 0; /* ���݂̃N���X?�ʒu*/
    id->data = 0;    /* �ǂݏ���?�C��?*/
    /*-----------------------------------------------------------------------*/
    /*???????????????????????????????????????????????????????????????????????*/
    /*-----------------------------------------------------------------------*/
    if(addr > 0) {
        if(FM_next_sector2(id,1))  return(GP_ERROR );
        for(pos = addr; pos > SECT_SIZE; pos -= SECT_SIZE) {
            if(FM_next_sector2(id,1))  return(GP_ERROR );
        }
        if(FM_read1sect2(id->current + CLAST_BASE,(char *)id->dtbuf)) return(GP_ERROR );
        id->readf = 1;
        id->data = (unsigned short)pos;
        if(addr > (long)id->size)    id->size = addr;
    }
    /*-----------------------------------------------------------------------*/
    id->pos  = addr;
    return(addr);
}
/******************************************************************************
'Procedure          :FM_Close
'Summary            :̧�ٸ۰�?��?
'Parameters         :�t?�C����?�C��?
'Return Value       :OK(0),GP_ERROR (-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
short FM_Close(I_FILE *id)
{
    short ret;

    if(id->mode!=MODE_READ) {
        if(id->data!=0 && id->readf==0 && id->current!=0xffffffff) {
            if(FM_write1sect(id->current+CLAST_BASE,(char *)id->dtbuf)) {
                return(GP_ERROR );
            }
        }
        ret=FM_put_dir(id);
        if((ret==0) && (id->size != 0)){
            FM_put_fat();
        }
    } else{
        ret=0;
    }
    return(OK);
}
short FM_Close2(I_FILE *id)
{
    short ret;

    if(id->mode!=MODE_READ) {
        if(id->data!=0 && id->readf==0 && id->current!=0xffffffff) {
            if(FM_write1sect2(id->current+CLAST_BASE,(char *)id->dtbuf)) {
                return(GP_ERROR );
            }
        }
        ret=FM_put_dir2(id);
        if((ret==0) && (id->size != 0)){
            FM_put_fat2();
        }
    } else{
        ret=0;
    }
    return(OK);
}
/******************************************************************************
'Procedure          :FM_fmt_write
'Summary            :̫��?�������ݏ���
'Parameters         :�Ȃ�
'Return Value       :OK(0),GP_ERROR (-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int FM_fmt_write()
{
	int		i;
	int		FileDataAddr;

#ifndef	WIN32
	char	*mp;

	FileDataAddr= F_FILE_AREA;
	for(i=0;i<GP_USER_DATA_BLOCK;i++){
		RamFlashEraze((short *)(FileDataAddr));
		FileDataAddr += 0x10000;
	}
	//DIR,FAT�������u���b�N
	mp= TakeMemory(0x8000);		//32KB
	memcpy(mp,(char *)GP_FILE_DIR,0x8000);
	/* DIR�̈���� */
	memset(&mp[0],0xff,GP_FILE_DIR_SIZE);
	RamFlashEraze((short *)(GP_FILE_DIR));
	RamFlashWrite((short *)PLC_FILE_DIR,(short *)&mp[PLC_FILE_DIR-GP_FILE_DIR],PLC_FILE_DIR_SIZE);
	/* FAT�̈���� */
	memcpy(mp,(char *)GP_FAT_DIR,0x2000);
	memset(&mp[0],0xff,GP_FAT_DIR_SIZE);
	RamFlashEraze((short *)(GP_FAT_DIR));
	RamFlashWrite((short *)PLC_FAT_DIR,(short *)&mp[PLC_FAT_DIR-GP_FAT_DIR],PLC_FAT_DIR_SIZE);
	FreeMail(mp);
#else
	FileDataAddr= F_FILE_AREA;
	for(i = 0; i < GP_USER_DATA_BLOCK; i++){
		memset(&GpFont[FileDataAddr],0xff,0x10000);
		FileDataAddr += 0x10000;
	}
	/* DIR�̈���� */
	memset(&GpFont[F_DIR_AREA], 0xff, GP_FILE_DIR_SIZE);
	/* FAT�̈���� */
	memset(&GpFont[F_FAT_AREA], 0xff, GP_FAT_DIR_SIZE);
#endif
    return(OK);
}
int FM_fmt_write2()
{
	int		i;
	int		FileDataAddr;

#ifndef	WIN32
	char	*mp;

	FileDataAddr= F_FILE_AREA2;
	for(i=0;i<PLC_USER_DATA_BLOCK;i++){
		RamFlashEraze((short *)(FileDataAddr));
		FileDataAddr += 0x10000;
	}
	//DIR,FAT�������u���b�N
	mp= TakeMemory(0x8000);
	Vmemcpy((volatile char*)&mp[0],(volatile char*)GP_FILE_DIR,0x8000);
	/* DIR�̈���� */
	memset(&mp[PLC_FILE_DIR- GP_FILE_DIR],0xff,PLC_FILE_DIR_SIZE);
	RamFlashEraze((short *)(GP_FILE_DIR));
//	Delay(100);
	RamFlashWrite((short *)GP_FILE_DIR,(short *)mp,GP_FILE_DIR_SIZE);
	/* FAT�̈���� */
	Vmemcpy((volatile char*)&mp[0],(volatile char*)GP_FAT_DIR,0x2000);
	memset(&mp[PLC_FAT_DIR- GP_FAT_DIR],0xff,PLC_FAT_DIR_SIZE);
	RamFlashEraze((short *)(GP_FAT_DIR));
//	Delay(100);
	RamFlashWrite((short *)GP_FAT_DIR,(short *)mp,GP_FAT_DIR_SIZE);
	FreeMail(mp);
#else
	FileDataAddr= F_FILE_AREA2;
	for(i = 0; i < PLC_USER_DATA_BLOCK; i++){
		memset(&GpFont[FileDataAddr],0xff,0x10000);
		FileDataAddr += 0x10000;
	}
	/* DIR�̈���� */
	memset(&GpFont[F_DIR_AREA2], 0xff, PLC_FILE_DIR_SIZE);
	/* FAT�̈���� */
	memset(&GpFont[F_FAT_AREA2], 0xff, PLC_FAT_DIR_SIZE);
#endif
    return(OK);
}
int	SetMemAddr(int sectp)
{
#ifndef	WIN32
		return(sectp + F_FILE_AREA);
#else
		return(sectp + (int)&gfmbuf[0]);
#endif
}
int	SetMemAddr2(int sectp)
{
#ifndef	WIN32
		return(sectp + F_FILE_AREA2);
#else
		return(sectp + (int)&gfmbuf2[0]);
#endif
}
char*	GetPlcPassAddr(void)
{
#ifdef	WIN32
	return((char*)&GpFont[F_PLC_SETTEIFILE_AREA]);
#else
	return((char*)PLC_SETTING_AREA);
#endif
}
//20100806 add
char*	GetLcdTypeAddr(void)
{
#ifdef	WIN32
	return((char*)&GpFont[F_LCD_TYPE_SETTING_AREA]);
#else
	return((char*)LCD_TYPE_SETTING_AREA);
#endif
}

void	mWritePlcPass( char* pass )
{
	char	*buff;

	buff= TakeMemory(0x2000);		//8KB

#ifdef	WIN32
	unsigned char *obj;
	int		i;

	obj= (unsigned char *)&GpFont[F_PLC_SETTEIFILE_AREA];
	for(i = 0; i < PLC_PASS_CNT; i++){
		*obj++ = *pass++;
	}

#else
	memset(buff,0xff,0x2000);
	memcpy(buff,(char *)&Set,sizeof(Set));
	memcpy(&buff[0x1000],pass,16);

	//20100806 add
	memcpy(&buff[0x1800],(char *)LCD_TYPE_SETTING_AREA,LCD_TYPE_SETTING_AREA_SIZE);

	RamFlashEraze((short *)F_SETTEIFILE_AREA);
	RamFlashWrite((short *)F_SETTEIFILE_AREA,(short *)buff,0x2000);
#endif
	FreeMail(buff);
}
void	mWriteSettei( void )
{
	char	*buff;

	buff= TakeMemory(0x2000);		//8KB

#ifdef	WIN32
	unsigned short *obj;
	unsigned short *src;
	int		i;

	obj= (unsigned short *)&GpFont[F_SETTEIFILE_AREA];
	src= (unsigned short *)&Set;
	for(i = 0; i < sizeof(Set)/ 2; i++){
		*obj++ = *src++;
	}

#else
	memset(buff,0xff,0x2000);
	memcpy(buff,(char *)&Set,sizeof(Set));
	memcpy(&buff[0x1000],(char *)PLC_SETTING_AREA,PLC_PASS_CNT);

	//20100806 add
	memcpy(&buff[0x1800],(char *)LCD_TYPE_SETTING_AREA,LCD_TYPE_SETTING_AREA_SIZE);

	RamFlashEraze((short *)F_SETTEIFILE_AREA);
	RamFlashWrite((short *)F_SETTEIFILE_AREA,(short *)buff,0x2000);
#endif
	FreeMail(buff);
}
/* Init Setting */
void	initSet( void )
{
	mformat();
	memset(&Set,0,sizeof(_SETUP));
	strncpy(Set.System,dVersion,6);

/* 20080822 GP�� ���� Ʋ�� �κ� Ȯ�� */
	Set.iDstSta= 0x01;					
	Set.iGPSta= 0x00;					

	Set.iLang=1;	/*  0:English, 1:DownLoad Lang */										

	Set.iBackLightTime = 1;
	Set.iTitleDispTime = 5;
	Set.iCallKey = 0x01;
	Set.iLcdvalue = lcd_contrast;								/* ���߿� ��������...  */
	/* CH1 Default */
	Set.Ch1_iConnect= CH_CH0;			/* 0:SIO0,1:SIO1 */

/* 20060623 */
	Set.Ch1_iKind= UNIVERSAL;		/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed= RS_38400;			/* 9600 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity= RS_NONE;			/* 0:NONE,1:ODD,2:EVEN */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop= RS_STOP01;

	Set.Ch1_iKind= ELSE_PLC;		/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed= RS_38400;			/* 9600 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity= RS_NONE;			/* 0:NONE,1:ODD,2:EVEN */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop= RS_STOP01;
	
	Set.Ch1_iKind= DEFAULT_PLC;		/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed= RS_38400;			/* 9600 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity= RS_NONE;			/* 0:NONE,1:ODD,2:EVEN */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop= RS_STOP01;

	Set.Ch1_iKind= EDITER;		/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
//	if(IsGlpType() == OK){		//GLP TYPE
		Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed= RS_115200;			/* 9600 */
		Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity= RS_EVEN;			/* 0:NONE,1:ODD,2:EVEN */
		Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
		Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
		Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop= RS_STOP01;
//	}else{
//		Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed= RS_9600;			/* 9600 */
//		Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity= RS_EVEN;			/* 0:NONE,1:ODD,2:EVEN */
//		Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1= RS_DATA7;			/* 0:7,1:8 */
//		Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
//		Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop= RS_STOP01;
//	}

	Set.Ch1_iKind= PRINTER;		/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed= RS_9600;			/* 9600 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity= RS_NONE;			/* 0:NONE,1:ODD,2:EVEN */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop= RS_STOP01;

	Set.Ch1_iKind= BAR_CODE;		/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed= RS_9600;			/* 9600 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity= RS_NONE;			/* 0:NONE,1:ODD,2:EVEN */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop= RS_STOP01;

	Set.Ch1_iKind= MONITOR;		/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed= RS_38400;			/* 9600 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity= RS_NONE;			/* 0:NONE,1:ODD,2:EVEN */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop= RS_STOP01;

	Set.Ch1_iKind= UNIVERSAL;		/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed= RS_38400;			/* 0:300, 1:600, 2:1200, 3:2400, 4:4800, 5:9600, 6:19200 7:38400bps 8:57600bps 9:115200bps */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity= RS_NONE;			/* 0:NONE,1:ODD,2:EVEN */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
	Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop= RS_STOP01;

	/* CH0 Default */
	Set.Ch2_iConnect= CH_CH1;			/* 0:SIO0,1:SIO1 */

	Set.Ch2_iKind= PLCTYPE2;	/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed= RS_9600;			/* 9600 */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity= RS_NONE;			/* 0:NONE,1:ODD,2:EVEN */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop= RS_STOP01;

	Set.Ch2_iKind= PRINTER;	/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed= RS_9600;			/* 9600 */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity= RS_NONE;			/* 0:NONE,1:ODD,2:EVEN */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop= RS_STOP01;

	Set.Ch2_iKind= BAR_CODE;	/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed= RS_9600;			/* 9600 */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity= RS_NONE;			/* 0:NONE,1:ODD,2:EVEN */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop= RS_STOP01;

	Set.Ch2_iKind= MONITOR;	/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed= RS_38400;			/* 9600 */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity= RS_NONE;			/* 0:NONE,1:ODD,2:EVEN */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
	Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop= RS_STOP01;

	Set.Ch2_iKind= EDITER;	/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
//	if(IsGlpType() == OK){		//GLP TYPE
		Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed= RS_115200;			/* 115200 */
		Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity= RS_EVEN;			/* 0:NONE,1:ODD,2:EVEN */
		Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1= RS_DATA8;			/* 0:7,1:8 */
		Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
		Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop= RS_STOP01;
//	}else{
//		Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed= RS_9600;			/* 9600 */
//		Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity= RS_EVEN;			/* 0:NONE,1:ODD,2:EVEN */
//		Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1= RS_DATA7;			/* 0:7,1:8 */
//		Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2= RS_XONOFF;			/* 0:XON/XOF,1:DSR/DTR */
//		Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop= RS_STOP01;
//	}
/*	Set.iConnect= 1;*/		/* 0:RS-232C,1:RS-422 */
/*	Set.iPlcType= 1;*/		/* 0:Universal,1:Fx-Seriase,2:Els */
	Set.LcdReverseOn= 0;

	/* KOREA CHINA JAPAN TAIWAN */
#ifdef	KOREA
	Set.LanguageCode= KORCODE;	/* 0:Korean,1:Japanese,2:Chines,3:English,4:Taiwan */
	Set.FontCode= 1;		/* 1:JINDODUM,2:JINBATANG, 3:GULIM, 4:SEGULIM, 5:DODUM */
#endif
#ifdef	JAPAN
	Set.LanguageCode= JPNCODE;	/* 0:Korean,1:Japanese,2:Chines,3:English,4:Taiwan */
	Set.FontCode= 1;		/* 1:DODUM */
#endif
#ifdef	CHINA
	Set.LanguageCode= CHICODE;	/* 0:Korean,1:Japanese,2:Chines,3:English,4:Taiwan */
	Set.FontCode= 1;		/* 1:DODUM */
#endif
#ifdef	ENGLISH
	Set.LanguageCode= ENGCODE;	/* 0:Korean,1:Japanese,2:Chines,3:English,4:Taiwan */
	Set.FontCode= 1;		/* 1:DODUM,2:GULIM,3:BATANG,4:NEW DODUM,5:NEW GULIM,6:NEW BATANG,7:COUNT */
#endif
#ifdef	TAIWAN
	Set.LanguageCode= TWICODE;	/* 0:Korean,1:Japanese,2:Chines,3:English,4:Taiwan */
	Set.FontCode= 1;		/* 1:DODUM */
#endif
#ifdef	RUSSIAN
	Set.LanguageCode= RUSCODE;	/* 0:Korean,1:Japanese,2:Chines,3:English,4:Taiwan */
	Set.FontCode= 1;		/* 1:DODUM */
#endif
#ifdef	VIETNAM
	Set.LanguageCode= VIECODE;	/* 0:Korean,1:Japanese,2:Chines,3:English,4:Taiwan */
	Set.FontCode= 1;		/* 1:DODUM */
#endif
#ifdef	PORTUGAL
	Set.LanguageCode= PORCODE;	/* 0:Korean,1:Japanese,2:Chines,3:English,4:Taiwan */
	Set.FontCode= 1;		/* 1:DODUM */
#endif



	Set.eFontCode= 1;		/* 1:DODUM,2:GULIM,3:BATANG,4:NEW DODUM,5:NEW GULIM,6:NEW BATANG,7:COUNT */
	Set.iBuzzer= 1;
	Set.OpenBaseNo= 0;		/* Start Gamen Default */
	Set.iuwLatch= 0;		//20091222
#ifdef	LP_S044
	mformat2();				/* �t?�C���V�X�e?�̏����� */
	PlcDataSram.ParamTableCnt= 0;
#ifdef	WIN32
	memset(&GpFont[PLC_PARAM_FILE],0,4);
#else
	//�����O�X���O�ɂ���B
	RamFlashWrite((short *)PLC_PARAM_FILE,(short *)&PlcDataSram.ParamTableCnt,4);
#endif
	SetPlcStationNo();		//Station No Setting
	/* Program Clear */
	PlcDataSram.CodeTableCnt= 0;
	PlcDataSram.Load_Count= 0;
	PlcDataSram.CodeTableSum= 0;
#endif
}
// 070528
int	CheckPlcTypeCode(void)
{
	int		i;

	for(i= 0; i < 4; i++){
		if(Set.cPlcTypeCode[i+2] != 0){	break;	}
	}
	if(i < 4){	return(OK);	}
	return(NG);
}
void	mReadSettei( void )
{
	unsigned short *obj;
	volatile unsigned short *src;
	int		i;
	int	iTypeCnt;
	int		EditFlag;

	EditFlag= 0;
#ifdef	WIN32
	src= (volatile unsigned short *)&GpFont[F_SETTEIFILE_AREA];
#else
	src= (volatile unsigned short *)F_SETTEIFILE_AREA;
#endif
	obj= (unsigned short *)&Set;
	if(strncmp((char *)src,dVersion,6) == 0){
		src= (unsigned short *)CommonArea.System;
		if(strncmp((char *)src,dVersion,6) == 0){
#ifdef	WIN32
			src= (volatile unsigned short *)&GpFont[F_SETTEIFILE_AREA];
#else
			src= (volatile unsigned short *)F_SETTEIFILE_AREA;
#endif
/* ksc20050804 Setting Value Loading - ���� */
/*-------------------------------------------------------------------------------------*/
			for(i = 0; i < sizeof(Set)/ 2; i++){
				*obj++ = *src++;						
			}
/*-------------------------------------------------------------------------------------*/
		}else{
			memset(&CommonArea,0,sizeof(CommonArea));
			strncpy(CommonArea.System,dVersion,6);
			initSet();
			mWriteSettei();
			EditFlag= 1;
		}
	}else{
		memset(&CommonArea,0,sizeof(CommonArea));
		strncpy(CommonArea.System,dVersion,6);
		initSet();
		mWriteSettei();
		EditFlag= 1;
	}
//Protocol Check 
	if(EditFlag == 0){
	/* Protocol is not 050309 */
//070528		if(strlen(Set.cPlcTypeAdd)){
		iTypeCnt= 0;	/* 2008.09.26 */
		if(CheckPlcTypeCode() == OK){
			iTypeCnt = 2;
		}
#ifdef	WIN32
		if(((iTypeCnt == 2) &&			/* 20080822 ���� �׽�Ʈ �ʿ� */
		(memcmp((char *)&GpFont[PLC1_PROTOCOL],PLC1STATUS,7) != 0)) ||
		((CommonArea.PlcType2.AuxPlcUserFlag != 0) && 
		(memcmp((char *)&GpFont[PLC2_PROTOCOL],PLC2STATUS,8) != 0))){
			memset(&CommonArea,0,sizeof(CommonArea));
			strncpy(CommonArea.System,dVersion,6);
			initSet();
			mWriteSettei();
			return;
		}
#else
		if(((iTypeCnt == 2) &&			/* 20080822 ���� �׽�Ʈ �ʿ� */
		(memcmp((char *)PLC1_PROTOCOL,PLC1STATUS,7) != 0)) ||
		((CommonArea.PlcType2.AuxPlcUserFlag != 0) && 
		(memcmp((char *)PLC2_PROTOCOL,PLC2STATUS,8) != 0))){
			memset(&CommonArea,0,sizeof(CommonArea));
			strncpy(CommonArea.System,dVersion,6);
			initSet();
			mWriteSettei();
			return;
		}
#endif
	}
/*	Set.iBuzzer = 1;*/
}
void	mBaseClear( void )
{
	char *mp;
	int		i;
	struct  dir *wDir;

	mp= (char *)TakeMemory(0x10000);
	Vmemcpy((volatile char*)mp,(volatile char*)dirbuf,0x10000);
	wDir= (struct  dir *)mp;
	for(i = 0; i < GP_FILE_DIR_SIZE/32; i++){
		if(memcmp(wDir->name_ext,"BAS",3) == 0){
			memcpy(wDir,wDir+1,((GP_FILE_DIR_SIZE/32)-i-1)*32);
			memset((mp+(GP_FILE_DIR_SIZE-32)),0xff,32);
		}
		wDir++;
	}
#ifdef	WIN32
	Vmemcpy((volatile char*)dirbuf,(volatile char*)mp,GP_FILE_DIR_SIZE);
#else
	RamFlashEraze((short *)F_DIR_AREA);
	RamFlashWrite((short *)F_DIR_AREA,(short *)mp,0x10000);
#endif
	FreeMail(mp);
}
char *DeleteFileOpen( void )
{
	char *mp;
	mp= (char *)TakeMemory(0x10000);
#ifdef	WIN32
	memcpy(mp,(char *)&GpFont[GP_FILE_DIR],0x10000);
#else
	memcpy(mp,(char *)GP_FILE_DIR,0x10000);
#endif
	return(mp);
}
char *DeleteFileOpen2( void )
{
	char *mp;
	mp= (char *)TakeMemory(0x10000);
#ifdef	WIN32
	memcpy(mp,(char *)&GpFont[GP_FILE_DIR],0x10000);
#else
	memcpy(mp,(char *)GP_FILE_DIR,0x10000);
#endif
	return(mp);
}
void	DeleteFile( char *Name, char *mp )
{
	struct  dir *wDir;
	int		i;

	wDir= (struct  dir *)mp;
	for(i = 0; i < GP_FILE_DIR_SIZE/32; i++){
		if(memcmp(wDir->name_ext,Name,11) == 0){
			memcpy(wDir,wDir+1,((GP_FILE_DIR_SIZE/32)-i-1)*32);
			memset((mp+(GP_FILE_DIR_SIZE-32)),0xff,32);
			break;
		}
		wDir++;
	}
}
void	DeleteFile2( char *Name, char *mp )
{
	struct  dir *wDir;
	int		i;
	int		startpos;

	startpos= PLC_FILE_DIR- GP_FILE_DIR;
	wDir= (struct  dir *)(mp+startpos);
	for(i = 0; i < PLC_FILE_DIR_SIZE/32; i++){
		if(memcmp(wDir->name_ext,Name,11) == 0){
			memcpy(wDir,wDir+1,((PLC_FILE_DIR_SIZE/32)-i-1)*32);
			memset((mp+(PLC_FILE_DIR_SIZE-32)+startpos),0xff,32);
			break;
		}
		wDir++;
	}
}
void	DeleteFileClose( char *mp )
{
#ifdef	WIN32
//	Vmemcpy((volatile char*)dirbuf,(volatile char*)mp,0x10000);
	Vmemcpy((volatile char*)dirbuf,(volatile char*)mp,0x8000);		//2008.12.07
#else
	RamFlashEraze((short *)F_DIR_AREA);
//	RamFlashWrite((short *)F_DIR_AREA,(short *)mp,0x10000);
	RamFlashWrite((short *)F_DIR_AREA,(short *)mp,0x8000);			//2008.12.17
#endif
	FreeMail(mp);
}
void	DeleteFileClose2( char *mp )
{
#ifdef	WIN32
//	memcpy(&GpFont[GP_FILE_DIR],mp,0x10000);
	memcpy(&GpFont[GP_FILE_DIR],mp,0x8000);							//2008.12.07
#else
	RamFlashEraze((short *)F_DIR_AREA);
//	RamFlashWrite((short *)F_DIR_AREA,(short *)mp,0x10000);
	RamFlashWrite((short *)F_DIR_AREA,(short *)mp,0x8000);			//2008.12.07
#endif
	FreeMail(mp);
}
int	CheckUserArea( void )
{
	int		i;
	volatile unsigned short *wfat;          /*FAT�̈�              */

	wfat= fatbuf;          /*FAT�̈�              */
	wfat++;
	wfat++;
	for(i= 0; i < GP_TOTAL_SECT; i++){
		if(*wfat++ == (unsigned short)0xffff){
			break;
		}
	}
	return(i);
}
int	CheckNoUseArea( void )
{
	int		i;
	volatile unsigned short *wfat;          /*FAT�̈�              */

	wfat= fatbuf;          /*FAT�̈�              */
	wfat++;
	wfat++;
	for(i= 0; i < GP_TOTAL_SECT; i++){
		if(*wfat++ == (unsigned short)0xffff){
			break;
		}
	}
	return(GP_TOTAL_SECT- i);
}
unsigned char *GetKeyWinAddr(int kind)
{
	unsigned char *ret;
	unsigned short *index_key;

/* 20060512 */
#ifdef	WIN32
	index_key = (unsigned short *)(&GpFont[KEY_WINDOW]);

	if(TateYoko == 0){
		ret= (unsigned char *)index_key[kind - 1];
	}else{
		ret= (unsigned char *)index_key[kind + 5];
	}

	ret = (unsigned char *)((unsigned int)ret + (unsigned int)&GpFont[KEY_WINDOW]);
#else
/* 20060512 */
	unsigned short work;
	index_key = (unsigned short *)KEY_WINDOW;

	if(TateYoko == 0){
		work = index_key[kind - 1];
	}else{
		work = index_key[kind + 5];
	}
	ret = (unsigned char *) (((work & 0xff) << 8 ) | ((work & 0xff00) >> 8 ));
	ret = ret + KEY_WINDOW;

#endif
	return(ret);
}
int	GetUsrArea(void)
{
	int	cnt;

	cnt= CheckUserArea();
	return((GP_TOTAL_SECT- cnt)*512);
}
int	GetUserFileArea(void)
{
	return(GP_TOTAL_SECT*512);
}
/*********************************** END OF FILE *****************************/

