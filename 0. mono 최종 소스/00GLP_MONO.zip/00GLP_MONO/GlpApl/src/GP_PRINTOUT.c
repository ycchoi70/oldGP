/* ****************************************************************************** */
/*  �� �� �� : GP_PRINTOUT.CPP													 */
/*  ��    �� : ������ ���(�˸�����Ʈ���)										 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

#ifdef	SIZE_2480
/* ****************************************************************************** */
/*  �Լ�																			 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �� �� �� : vPrintOut()														 */
/*  ��    �� : ������ ��� ó��													 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 2�� 15�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
int		vPrintOut(int* iScreenNo){	
	int	iPrintFlag;

	iPrintFlag = 0;
	while ( *iScreenNo == PRINT_OUT_NUM && iPrintFlag == 0) {
		ClearDispBuff(SCREEN_0);								/*  ���÷��� ���� �ʱ�ȭ	 */
/*
		DotTextOut(2,Line_2,Dspname[PRINT_OUT].chName[Set.iLang][0],1,1, TRANS, T_WHITE, T_BLACK);
*/
/*ksc20040514 �˶������丮 ���� ��ġ ���� */
#ifdef	SIZE_3224
		DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+3+Line_2,Dspname[PRINT_OUT].chName[Set.iLang][3],1,1, TRANS, T_WHITE, T_BLACK);
#endif
#ifdef	SIZE_2480
		DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+3+Line_2,Dspname[PRINT_OUT].chName[Set.iLang][0],1,1, TRANS, T_WHITE, T_BLACK);
#endif
/*ksc20040514*/

		DefaultFormDisplay(LINE_FORM, Dspname[PRINT_OUT].chTitle[Set.iLang]);
		DrawLcdBank1();
		iPrintFlag = iPrintOutSelect(iScreenNo);						/*  ���� ó��			 */
	} /*  end while  */

	return iPrintFlag;
}
/* ****************************************************************************** */
/*  �� �� �� : iPrintOutSelect()													 */
/*  ��    �� : ȭ�� ���ý� ó��													 */
/*  ��    �� :																	 */
/*  ��    �� : iEscFlag 0 : ESC ����	1: ������ ��� ����							 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
int	iPrintOutSelect(int* iScreenNo)
{

	int				iKeyCode;
	int				iKeyFlag;			/* ��� Ȯ��â���� ��ȯ�� �� 0:YES,1:NO	 */
	int				iPrintFlag;			/* 1:����Ʈ 2:����Ʈ��� */
	char			chContent[30];
	short			iKeyFlag1;
	_RECTANGLE_INFO RECParam;

	iKeyFlag1 = 1;
	iKeyCode	= -1;
	iKeyFlag	= -1;			/* ��� Ȯ��â���� ��ȯ�� �� 0:YES,1:NO	 */
	iPrintFlag	= 0;			/* 1:����Ʈ 2:����Ʈ��� */

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	while (*iScreenNo == PRINT_OUT_NUM && iPrintFlag == 0) {
		iKeyCode = KeyWaitData(iKeyFlag1, PRINT_OUT_NUM);							/* �Էµ� Ű���� �о��	 */
		iKeyFlag1 = 0;
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}
		/* Ű ���� ó�� */		
		if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) {			/*  ����					 */			
			*iScreenNo = USER_SCREEN_NUM;								/* ����Ʈó�� ����		 */
			NormalBuzzer();				/*	Buzzer  */
		
		}else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) {		/*  END					 */			
			
			/* ����Ʈ ��� ��� */
			*iScreenNo = SET_FUNTION_NUM;								/* ����Ʈó�� ����		 */
			NormalBuzzer();				/*	Buzzer  */

		} else if (iKeyCode >= KEY_16 && iKeyCode <= KEY_30 ) {	/*  Alarm history ����	 */
			/* ��� Ȯ�� â ��� */		
			NormalBuzzer();				/*	Buzzer  */
			memset(chContent, 0x00, sizeof(chContent));
			sprintf(chContent, Dspname[PRINT_OUT].chName[Set.iLang][1]);

			iKeyFlag = vOutEntWindowDisp(chContent);

			if(iKeyFlag == DOWN_TRANS || iKeyFlag == UP_TRANS)
			{
				*iScreenNo = iKeyFlag;
				break;
			}
			if (iKeyFlag == 0) {								
				
				/* 2002.02.20 hongsw ����Ʈ Ÿ��ũ ȣ�� �߰� */				
				/*  ����Ʈ�� ��� ����  */				
				iPrintFlag = 1;							/* ����Ʈ ���� */
				*iScreenNo = PRINT_OUT_NUM;

				
/* --------------------------------	*/

/*				if(CommonArea.EntryCnt>0 && Set.Ch1_iKind == PRINTER){  */
				if(CheckPrintMode() == 0){

					/*	Message Display		*/
					AreaClear(GAMEN_START_X+8,GAMEN_START_Y+10,GAMEN_START_X+230,GAMEN_START_Y+70,0);							/*  ���ϴ� �κи��� ������.   */
					RectAngleOut(GAMEN_START_X+8,GAMEN_START_Y+10,GAMEN_START_X+230,GAMEN_START_Y+70,&RECParam);					/* ȭ��Ʋ �ۼ�				 */
#ifdef	SIZE_3224
					DotTextOut(GAMEN_START_X+10,GAMEN_START_Y+Line_2,Dspname[DATA_TRANSFER].chName[Set.iLang][8],1,1, TRANS, T_WHITE, T_BLACK);
#endif
#ifdef	SIZE_2480
					DotTextOut(GAMEN_START_X+10,GAMEN_START_Y+Line_2,Dspname[DATA_TRANSFER].chName[Set.iLang][3],1,1, TRANS, T_WHITE, T_BLACK);
#endif
					DrawLcdBank1();
					/*----------------------*/
					PrintDataDisplay();
/*				}else if(Set.Ch1_iKind != PRINTER){ */
				}else if((Set.Ch1_iKind != PRINTER) && (Set.Ch2_iKind != PRINTER)){
#ifdef	SIZE_3224
					iCaptionWindow(Dspname[DATA_TRANSFER].chName[Set.iLang][9],"");
#endif
#ifdef	SIZE_2480
					iCaptionWindow(Dspname[DATA_TRANSFER].chName[Set.iLang][4],"");
#endif
				}
/* --------------------------------	*/
			} else {
				iPrintFlag = 2;							/* ����Ʈ ��� */
				*iScreenNo = PRINT_OUT_NUM;
			} /* end if */

		} /*  end if  */			
		DrawLcdBank1();
		
	} /*  end while  */	

	return iPrintFlag;
}
#endif
int	CheckPrintMode(void)
{
	if((CommonArea.EntryCnt > 0) && 
		((Set.Ch1_iKind == PRINTER) || (Set.Ch2_iKind == PRINTER))){
		return 0;
	}else{
		return -1;
	}
}
int PrintDataDisplay(void)
{
	int				isize;
	int				i;
	short			iNowPageNo;
	short			iyear;
	short			imon;	
	short			iday;
	short			ihour;
	short			imin;
	short			isec;
	short			iLine;			/* Now Display Line*/
	short			iPosition;
	short			inyear;
	short			inmon;
	short			inday;
	short			inhour;
	short			inmin;
	short			insec;
	short			iReturn;
	unsigned int	iDataBuffer;
	int				iLen;
	int				iColor;
	char*			buff;
	char*			PrintPage;
	char*			cTempBuffer;
	int				mbx;
	unsigned int	OldResp;
	T_MAIL			*mp;
	iReturn = -1;
/*	if(CommonArea.EntryCnt>0 && Set.Ch1_iKind == PRINTER) */
/*	{  */
	if(CheckPrintMode() == 0){
		buff = (char*) TakeMemory(81);
		PrintPage = (char*) TakeMemory(5300);
		cTempBuffer = (char*) TakeMemory(512+1);
		iNowPageNo = 1;
		iPosition = 0;
		inyear = SystemTime.year+START_YEAR;
		inmon = SystemTime.mon;
		inday = SystemTime.day;
		inhour = SystemTime.hour;
		inmin = SystemTime.min;
		insec = SystemTime.sec;

		while(1){
			iLine = 0;
			memset(PrintPage,0x00,5300);
			sprintf(buff,"%4d/%02d/%02d %02d:%02d:%02d                                                                  %2d\x0D\n",
					inyear,inmon,inday,inhour,inmin,insec,iNowPageNo);			
			strcat(PrintPage,buff);
			if(iNowPageNo==1){
				sprintf(buff,"               -------------------------------------------------- \x0D\n");
				strcat(PrintPage,buff);
				sprintf(buff,"               |                                                |\x0D\n");
				strcat(PrintPage,buff);
				sprintf(buff,"               |               Alarm Histroy List               |\x0D\n");							
				strcat(PrintPage,buff);
				sprintf(buff,"               |                                                |\x0D\n");
				strcat(PrintPage,buff);
				sprintf(buff,"               -------------------------------------------------- \x0D\n\x0D\n");
				strcat(PrintPage,buff);
				iLine = 7;
			}

			sprintf(buff,"               NO         DATE         TIME         MESSAGE\x0D\n");
			strcat(PrintPage,buff);
			iLine++;

			for(i=0+iPosition; i<CommonArea.EntryCnt;i++)
			{

				iDataBuffer = CommonArea.AlarmHistRec[i].sDateTime;
				isec		= (short)iDataBuffer & 0x0000003F;
				iDataBuffer = iDataBuffer >> 6;
				imin		= (short)iDataBuffer & 0x0000003F;
				iDataBuffer = iDataBuffer >> 6;
				ihour		= (short)iDataBuffer & 0x0000001F;
				iDataBuffer = iDataBuffer >> 5;
				iday		= (short)iDataBuffer & 0x0000001F;
				iDataBuffer = iDataBuffer >> 5;
				imon		= (short)iDataBuffer & 0x0000000F;
				iDataBuffer = iDataBuffer >> 4;
				iyear		= (short)iDataBuffer & 0x0000003F;
				iLen	=	25;
				memset(buff,0x00,81);
				memset(cTempBuffer,0x00,21);
				vCommentDataSet(CommonArea.AlarmHistRec[i].DevNo+1,cTempBuffer,&iColor,&iLen);

				sprintf(buff,"             %4d     %4d-%02d-%02d     %02d:%02d:%02d   %s \x0D\n",
						i, iyear,imon,iday,ihour,imin,isec,cTempBuffer);
				strcat(PrintPage,buff);
				iLine++;
				if(iLine>=66)
					break;
			}	
			iPosition = i;

			isize = strlen(PrintPage);
			mbx= TakeMbx();
			mp = (T_MAIL *)TakeMail();
			OldResp = ChangeMailResp( (char *)mp, mbx );

			mp->mext = (unsigned long)isize;		/* �������� ����	*/
			mp->mptr = PrintPage;				/* �������� ��ġ��	*/

			mp->mcmd = PRT_WRITE;
			SendMail(T_RTCHAND,(char *)mp);
			mp= (T_MAIL *)ReceiveMail( mbx );
			ChangeMailResp( (char *)mp, OldResp );
			FreeMail( (char *)mp );
			FreeMbx( mbx );

			iNowPageNo++;
			if(iPosition>=CommonArea.EntryCnt)
				break;
		}
		FreeMail((char*)buff);
		FreeMail((char*)PrintPage);
		FreeMail((char*)cTempBuffer);
		iReturn = 0;
	}
	return	iReturn;
}
