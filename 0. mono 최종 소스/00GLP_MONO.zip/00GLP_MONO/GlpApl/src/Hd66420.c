/**********************************/
/*	HD66420 Control Soft          */
/**********************************/
//#include	"cpu7014.h"
#include	"Hd66420.h"
#include	"define.h"
#include	"commbuff.h"
#include	"bios.h"
#include "gpstruct.h"

extern  _SETUP		Set;					/* ������ ����E����ü						*/
int		LcdDrawMode;
int		LcdLineCnt;
int		RefleshFlag;
#ifdef	WIN32
extern	char	LcdBuff[6][GAMEN_Y_SIZE][320/8];
#else
extern	unsigned short	LcdBuff[6][GAMEN_Y_SIZE][GAMEN_X_SIZE/8];
#endif
extern	void	Cmt0IntClear();

unsigned short	*CurrentLcdBuff;

void	LCD_DataOutM(int RegNo,int Data)
{
	*(unsigned char *)LCD_CONT1M = (unsigned char)RegNo;
	*(unsigned char *)LCD_CONT2M = (unsigned char)Data;
}
unsigned char LCD_DataInM(int RegNo)
{
	unsigned char data;

	*(unsigned char *)LCD_CONT1M = (unsigned char)RegNo;
	data = *(unsigned char *)LCD_CONT2M;
	return(data);
}
void	LCD_DataOutS(int RegNo,int Data)
{
	*(unsigned char *)LCD_CONT1S = (unsigned char)RegNo;
	*(unsigned char *)LCD_CONT2S = (unsigned char)Data;
}
unsigned char LCD_DataInS(int RegNo)
{
	unsigned char data;

	*(unsigned char *)LCD_CONT1S = (unsigned char)RegNo;
	data = *(unsigned char *)LCD_CONT2S;
	return(data);
}
void	LCD_Clear()
{
	int		i,j;

	LcdDrawMode= 0;
	LcdLineCnt= 0;
	RefleshFlag= 0;
	LCD_DataOutM(LCD_R0,0x08);		/* OP-AMP ON */
	LCD_DataOutS(LCD_R0,0x08);		/* OP-AMP ON */
	LCD_DataOutM(LCD_R1,0x12);		/* GRAY=1,INC=1 */
	LCD_DataOutS(LCD_R1,0x12);		/* GRAY=1,INC=1 */
	for(i = 0; i < 80; i++){
		LCD_DataOutM(LCD_R3,i);		/* Y-Address */
		LCD_DataOutS(LCD_R3,i);		/* Y-Address */
		LCD_DataOutM(LCD_R2,0);		/* X-Address */
		LCD_DataOutS(LCD_R2,0);		/* X-Address */
		*(unsigned char *)LCD_CONT1M = (unsigned char)0x04;
		*(unsigned char *)LCD_CONT1S = (unsigned char)0x04;
		for(j = 0; j < 40; j++){
			if(Set.LcdReverseOn == 0){
				*(unsigned char *)LCD_CONT2M = (unsigned char)0x00;
				*(unsigned char *)LCD_CONT2S = (unsigned char)0x00;
			}else{
				*(unsigned char *)LCD_CONT2M = (unsigned char)0xff;
				*(unsigned char *)LCD_CONT2S = (unsigned char)0xff;
			}
		}
	}
	LCD_DataOutM(LCD_R0,0x48);		/* DSP=1,OP-AMP ON */
	LCD_DataOutS(LCD_R0,0x48);		/* DSP=1,OP-AMP ON */
	LCD_DataOutS(LCD_R16,0x0e);		/* Contrast */
}
#ifndef	WIN32
void	DrawLcd( char* pBitmapBits )
{
	return;
}
#endif
void	DrawLcdAll( char* pBitmapBits )
{
	int		i,j;

	if(LcdDrawMode == 0){
		return;
	}
/*	SetDispSema();*/
	for(i = 0; i < 80; i++){
		LCD_DataOutS(LCD_R3,i);		/* Y-Address */
		LCD_DataOutS(LCD_R2,10);		/* X-Address */
		*(unsigned char *)LCD_CONT1S = (unsigned char)0x04;
		for(j = 0; j < 30; j++){
			if(Set.LcdReverseOn == 0){
				*(unsigned char *)LCD_CONT2S = (unsigned char)(*pBitmapBits++);
			}else{
				*(unsigned char *)LCD_CONT2S = (unsigned char)~(*pBitmapBits++);
			}
		}
		LCD_DataOutM(LCD_R3,i);		/* Y-Address */
		LCD_DataOutM(LCD_R2,0);		/* X-Address */
		*(unsigned char *)LCD_CONT1M = (unsigned char)0x04;
		for(j = 0; j < 30; j++){
			if(Set.LcdReverseOn == 0){
				*(unsigned char *)LCD_CONT2M = (unsigned char)(*pBitmapBits++);
			}else{
				*(unsigned char *)LCD_CONT2M = (unsigned char)~(*pBitmapBits++);
			}
		}
	}
/*	ResetDispSema();*/
}
void	SetContrast(int data)
{
	data = data * 2;
	if((data >= 32) || (data < 0)){
		data = 0x0e;
	}
	LCD_DataOutM(LCD_R0,0x48);		/* DSP=1,OP-AMP ON */
	LCD_DataOutS(LCD_R0,0x48);		/* DSP=1,OP-AMP ON */
	LCD_DataOutS(LCD_R16,data);		/* Contrast */
}
void	SetMemoryData(unsigned short *dataAddr)
{
	int		x,y;
	int		OffSet;
	char	*OffAddr;


	if(LcdDrawMode == 0){
		return;
	}

	OffAddr= (char *)dataAddr;
	OffSet= (int)dataAddr- (int)LcdBuff;
	x= OffSet % 60;
	y= OffSet / 60;

	if(x < 30){		/* Slave */
		LCD_DataOutS(LCD_R3,y);		/* Y-Address */
		LCD_DataOutS(LCD_R2,10+ x);		/* X-Address */
		*(unsigned char *)LCD_CONT1S = (unsigned char)0x04;
		if(Set.LcdReverseOn == 0){
			*(unsigned char *)LCD_CONT2S = (unsigned char)*OffAddr++;
			*(unsigned char *)LCD_CONT2S = (unsigned char)*OffAddr;
		}else{
			*(unsigned char *)LCD_CONT2S = (unsigned char)~*OffAddr++;
			*(unsigned char *)LCD_CONT2S = (unsigned char)~*OffAddr;
		}
	}else{			/* Master */
		LCD_DataOutM(LCD_R3,y);		/* Y-Address */
		LCD_DataOutM(LCD_R2,x- 30);		/* X-Address */
		*(unsigned char *)LCD_CONT1M = (unsigned char)0x04;
		if(Set.LcdReverseOn == 0){
			*(unsigned char *)LCD_CONT2M = (unsigned char)*OffAddr++;
			*(unsigned char *)LCD_CONT2M = (unsigned char)*OffAddr;
		}else{
			*(unsigned char *)LCD_CONT2M = (unsigned char)~*OffAddr++;
			*(unsigned char *)LCD_CONT2M = (unsigned char)~*OffAddr;
		}
	}
}

void	DrawLcdBank( unsigned short *buff )
{
#ifdef	OLD
	di();
	LcdLineCnt= 0;
	CurrentLcdBuff= buff;
	ei();
	return;
#else
	int		i,j;
	char*	pBitmapBits;

/*	pBitmapBits= (char *)&LcdBuff[0][0][0];*/
	pBitmapBits= (char *)buff;
/*	SetDispSema();*/
	for(i = 0; i < 80; i++){
		LCD_DataOutS(LCD_R3,i);		/* Y-Address */
		LCD_DataOutS(LCD_R2,10);		/* X-Address */
		*(unsigned char *)LCD_CONT1S = (unsigned char)0x04;
		for(j = 0; j < 30; j++){
			if(Set.LcdReverseOn == 0){
				*(unsigned char *)LCD_CONT2S = (unsigned char)(*pBitmapBits++);
			}else{
				*(unsigned char *)LCD_CONT2S = (unsigned char)~(*pBitmapBits++);
			}
		}
		LCD_DataOutM(LCD_R3,i);		/* Y-Address */
		LCD_DataOutM(LCD_R2,0);		/* X-Address */
		*(unsigned char *)LCD_CONT1M = (unsigned char)0x04;
		for(j = 0; j < 30; j++){
			if(Set.LcdReverseOn == 0){
				*(unsigned char *)LCD_CONT2M = (unsigned char)(*pBitmapBits++);
			}else{
				*(unsigned char *)LCD_CONT2M = (unsigned char)~(*pBitmapBits++);
			}
		}
	}
/*	ResetDispSema();*/
#endif
}
void	SetDrawLcdMode(int mode)
{
	LcdDrawMode= mode;
}
#ifndef	WIN32
#pragma interrupt  ( _Hd66420Handler )
#endif
void	_Hd66420Handler( void )
{
#ifndef	OLD
	int		j;
	unsigned char	*m_pBitmapBits;

	/* �X�L�����r���ŏ������ݖ��߂����� */
	if(LcdLineCnt < 80){
		m_pBitmapBits= (unsigned char *)(CurrentLcdBuff+ LcdLineCnt*30);
		LCD_DataOutS(LCD_R3,LcdLineCnt);		/* Y-Address */
		LCD_DataOutS(LCD_R2,10);		/* X-Address */
		*(unsigned char *)LCD_CONT1S = (unsigned char)0x04;
		for(j = 0; j < 30; j++){
			if(Set.LcdReverseOn == 0){
				*(unsigned char *)LCD_CONT2S = (unsigned char)(*m_pBitmapBits++);
			}else{
				*(unsigned char *)LCD_CONT2S = (unsigned char)~(*m_pBitmapBits++);
			}
		}
		LCD_DataOutM(LCD_R3,LcdLineCnt);		/* Y-Address */
		LCD_DataOutM(LCD_R2,0);		/* X-Address */
		*(unsigned char *)LCD_CONT1M = (unsigned char)0x04;
		for(j = 0; j < 30; j++){
			if(Set.LcdReverseOn == 0){
				*(unsigned char *)LCD_CONT2M = (unsigned char)(*m_pBitmapBits++);
			}else{
				*(unsigned char *)LCD_CONT2M = (unsigned char)~(*m_pBitmapBits++);
			}
		}
		LcdLineCnt++;
	}
#endif
	Cmt0IntClear();
}
void	LcdStart( void )
{
#ifdef	WIN32
#else
	LcdLineCnt= 0;
	CurrentLcdBuff= &LcdBuff[0][0][0];
	*(unsigned short *)CPU_IPRG = 0x000d;		/* CMT ff->ef 030314 */
	*(unsigned short *)CPU_CMSTR = 0x0002;		/* CMT1,0 Start */
#endif
}
void	BackLightOnOff(int mode)
{
#ifndef	WIN32
	if(mode == 0){		/* OFF */
		PortB |= 0x04;
	}else{
		PortB &= ~0x04;
	}
	*(unsigned short *)CPU_PBIOR = PortB;
#endif
}

