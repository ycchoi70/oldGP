/* ****************************************************************************** */
/*  �� �� �� : GP_LCDCONTRAST.CPP												 */
/*  ��    �� : ���ϴ�� ����														 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

/* ****************************************************************************** */
/*  �Լ� ������ Ÿ�� ����														 */
/* ****************************************************************************** */

/* ****************************************************************************** */
/*  �� �� �� : vButDispMode()													 */
/*  ��    �� : ���ϴ�� ���� ó��												 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
//#define	CONST_OFFSET	34
//#define	MAX_CONT		32
#ifdef	SIZE_2480
void	vLcdContSetDisp(int* iScreenNo)
{

	int					iKeyCode;	
	int					iData;
	char				DataFormat[8];
//	short				NowData;
	short				KeyFlag;
	short				iOldData;
	short				convertData;
	_RECTANGLE_INFO		RECParam;
	_RECTANGLE_INFO		RECParam1;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	RECParam1.iLineStyle = SOLID_LINE;
	RECParam1.iLineColor = WHITE;
	RECParam1.iPattern	 = PAT8;
	RECParam1.iForeColor = WHITE;
	RECParam1.iBackColor = WHITE;

	ClearDispBuff(SCREEN_0);

/*	DotTextOut(12,61,"0",1,1,TRANS, T_WHITE, T_BLACK);
	DotTextOut(213,61,"100",1,1,TRANS, T_WHITE, T_BLACK);*/

//	DotTextOut(GAMEN_START_X+3,GAMEN_START_Y+61,Dspname[ELSMESSAGE].chName[Set.iLang][2],1,1,TRANS, T_WHITE, T_BLACK);
//	DotTextOut(GAMEN_START_X+205,GAMEN_START_Y+61,Dspname[ELSMESSAGE].chName[Set.iLang][3],1,1,TRANS, T_WHITE, T_BLACK);

/* KSC20070222 */
/*	DotTextOut(3,61,Dspname[LCDCONTRAST].chName[Set.iLang][2],1,1,TRANS, T_WHITE, T_BLACK);    */ /* LEFT */
	DotTextOut(GAMEN_START_X+11,GAMEN_START_Y+61,Dspname[ELSMESSAGE].chName[Set.iLang][2],1,1,TRANS, T_WHITE, T_BLACK);    /* LEFT */
/*	DotWriteFont0(1,11,61,(unsigned char *)&TriangleFont[64],T_BLACK,1,1,NON_TRANS,0,0);	*/		
/*	DotTextOut(205,61,Dspname[LCDCONTRAST].chName[Set.iLang][3],1,1,TRANS, T_WHITE, T_BLACK);   */ /* RIGHT */
	DotTextOut(GAMEN_START_X+213,GAMEN_START_Y+61,Dspname[ELSMESSAGE].chName[Set.iLang][3],1,1,TRANS, T_WHITE, T_BLACK);   /* RIGHT */
/*	DotWriteFont0(1,213,61,(unsigned char *)&TriangleFont[96],T_BLACK,1,1,NON_TRANS,0,0);	*/		

	
	RectAngleOut(GAMEN_START_X+1,GAMEN_START_Y+58,GAMEN_START_X+35,GAMEN_START_Y+78,&RECParam);						/* ��� ���� ��ư			 */	
	RectAngleOut(GAMEN_START_X+204,GAMEN_START_Y+58,GAMEN_START_X+238,GAMEN_START_Y+78,&RECParam);					/* ��� ���� ��ư		 */	

	RectAngleOut(GAMEN_START_X+37,GAMEN_START_Y+58,GAMEN_START_X+202,GAMEN_START_Y+78,&RECParam);
	RectAngleOut(GAMEN_START_X+39,GAMEN_START_Y+60,GAMEN_START_X+200,GAMEN_START_Y+76,&RECParam);

	DefaultFormDisplay(LINE_FORM, Dspname[ELSMESSAGE].chTitle[Set.iLang]);

	DrawLcdBank1();
	iOldData = Set.iLcdvalue;
	
//	NowData		= -1;
	KeyFlag		= 1;
/**** Repeat On */
	KerRepeatFlag= 1;
	RepeatInfo.EntryCnt = 2;
	RepeatInfo.RepeatNo[0][0] = (char)KEY_46;
	RepeatInfo.RepeatNo[0][1] = (char)KEY_47;
	RepeatInfo.RepeatNo[1][0] = (char)KEY_59;
	RepeatInfo.RepeatNo[1][1] = (char)KEY_60;
/****************/
	while ( *iScreenNo == LCDCONTRAST_NUM ) 
	{
#ifndef WIN32
		if(KeyFlag == 1){

//			SetContrast(Set.iLcdvalue);			/* �֤����� display */
			//20100806			
			if((Set.iLcdvalue < (lcd_contrast-(max_contrast/2))) ||
				(Set.iLcdvalue > (lcd_contrast+(max_contrast/2)))){
				SetContrast(lcd_contrast);				/* �֤����� display */
			}else{
				SetContrast(Set.iLcdvalue);				/* �֤����� display */
			}		
		}
#endif
/*		iData = Set.iLcdvalue*22;*/
		convertData = Set.iLcdvalue - contrast_offset ;
		if(convertData < 0){
			convertData= 0;
			Set.iLcdvalue= contrast_offset;
		}
		if(convertData > max_contrast){
			convertData= max_contrast;
			Set.iLcdvalue= convertData+contrast_offset;
		}
		iData = convertData*5;
		AreaClear(GAMEN_START_X+40,GAMEN_START_Y+61,GAMEN_START_X+199,GAMEN_START_Y+75,0);
		RectAngleOut(GAMEN_START_X+39,GAMEN_START_Y+61,GAMEN_START_X+iData+39,GAMEN_START_Y+75,&RECParam1);

		memset(DataFormat,0x00,sizeof(DataFormat));
/*		sprintf(DataFormat,"%d / 8",Set.iLcdvalue);*/
/*ksc20040727*/
		sprintf(DataFormat,"%2d / %2d",convertData, max_contrast);
/*ksc20040727*/
		DotTextOut(GAMEN_START_X+91,GAMEN_START_Y+33,DataFormat,1,1,TRANS, T_WHITE, T_BLACK);
		DrawLcdBank1();


	/*	iKeyCode = KeyAccept();	*/							/* �Էµ� Ű���� �о��	 */

/* 040117 		iKeyCode = KeyWaitData(KeyFlag);*/								/* �Էµ� Ű���� �о��	 */
/* 040611		iKeyCode = KeyWait();		*/
		iKeyCode = iKeyReturn(LCDCONTRAST_NUM);

		KeyFlag = 0;
		
		if ((iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) ||
			(iKeyCode == KEY_01 || iKeyCode == KEY_02)) 
		{
			KeyFlag		= 1;
			NormalBuzzer();								/*	Buzzer  */
		}
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}
		/* Ű ���� ó�� */				
		if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) 
		{
			*iScreenNo = USER_SCREEN_NUM;
		}else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) 
		{															/*  END				 */
			*iScreenNo = SET_ENVIRONMENT_NUM;
		}else if (iKeyCode == KEY_46 || iKeyCode == KEY_47 ) 
		{															/*  <-				 */
			if(convertData > 0)
			{
				NormalBuzzer();	
				Set.iLcdvalue--;
			}else
				ErrorBuzzer();
			KeyFlag = 1;
		}else if (iKeyCode == KEY_59 || iKeyCode == KEY_60 ) 
		{															/*  ->				 */
/*			if(Set.iLcdvalue < 8)*/
			if(convertData < max_contrast)
			{
				NormalBuzzer();	
				Set.iLcdvalue++;
			}else
				ErrorBuzzer();
			KeyFlag = 1;
		} else
		{
			iKeyCode = -1;
		}	
	} 
	if(iOldData != Set.iLcdvalue)
	{
		mWriteSettei();
	}
	KerRepeatFlag = 0;
	return;
}
#endif
/*************************************************************/
/* 040611 leesi												 */
/*
#define		USER_SCREEN_NUM				0
#define		SELECT_MEMU_NUM				1	

#define		MONITORING_NUM				2
#define		DEVICE_MONITORING_NUM		3

#define		DATA_VIEW_NUM				1
#define		BASE_SCREEN_NUM				1
#define		WINDOW_SCREEN_NUM			1
#define		COMMENT_SCREEN_NUM			14
#define		MEMORY_SIZE_NUM				12

#define		SET_FUNTION_NUM				1
#define		DATA_TRANSFER_NUM			12
#define		TIME_SWITCH_NUM				15
(((#define		TIME_SWITCH_NUM ))))    16
#define		PRINT_OUT_NUM				2

#define		SET_ENVIRONMENT_NUM			1
#define		LANGUAGE_NUM				4
#define		SERIAL_PORT_NUM				5
#define		PLC_SETTING_NUM				6
#define		CLOCK_MENU_NUM				7
#define		CLEAR_DATA_NUM				8
#define		MENU_CALL_KEY_NUM			9
#define		BUZZER_NUM					10
#define		OPENNING_NUM				11
#define		BACKLIGHT_NUM				12
#define		BATTERY_NUM					11
#define		LCDCONTRAST_NUM				13
*/
extern	int		KeyAccept( void );
int	iScreenData[16][2] = {{0x3003fffb,0x3ffc7ffb},{0x3003ffff,0x00000000},
						  {0x30038003,0x00007ffb},{0x30038000,0x0000007f},
						  {0x30038f1f,0x07038e1f},{0x30038fff,0x07ff8603},
						  {0x3003ff80,0x3fdf7f9e},{0x30038000,0x07380e70},
						  {0x30038183,0x00000183},{0x30038000,0x1fbf0000},
						  {0x3003ff80,0x3fc07f9c},{0x30038000,0x00000000},
						  {0x30038000,0x00006003},{0x30038003,0x00000003},
						  {0x3003ffff,0x3fff8000},{0x3003ffff,0x3f8fff1f}};

int iKeyReturn(int itype)
{
	int		i;
	int		iReKey= 0;
	int		iKeyCode;
	int		iData;
	short	icnt;
	short	iflag;
	short	iScreenType= 0;

	iKeyCode = KeyWait();

	if((iKeyCode == 1 || iKeyCode == 2 ||		//Exit
	  (iKeyCode >= 13 && iKeyCode <= 15) ||		//Menue
	   iKeyCode == 0 || iKeyCode == PC_DNLOAD_START ||
	   iKeyCode == PC_UPLOAD_START))	/* ��� ȭ�鿡�� ������ �ִ� Ű */
	{
		return iKeyCode;
	}

	/************************/
	if(iKeyCode>30)
	{
		icnt = iKeyCode-31;
		iflag = 1;
	}
	else
	{
		icnt = iKeyCode-1;
		iflag = 0;
	}
	iData = 0x20000000 >> icnt;

	/********************************************/
	switch(itype)
	{
	case	SELECT_MEMU_NUM:			
	case 	DATA_VIEW_NUM:			
	case 	BASE_SCREEN_NUM:
	case 	WINDOW_SCREEN_NUM:
	case 	SET_FUNTION_NUM:
	case 	SET_ENVIRONMENT_NUM:

#ifdef	LP_S044
	case	SELECT_IO_NUM:				//GLP
	case	GLP_IO_SEL:				//GLP
#endif
		iScreenType = 0;
		break;

	case 	MONITORING_NUM:
	case	PRINT_OUT_NUM:
		iScreenType = 1;
		break;

	case	DEVICE_MONITORING_NUM:
		iScreenType = 2;
		break;

	case	LANGUAGE_NUM:
		iScreenType = 3;
		break;

	case	SERIAL_PORT_NUM:
		iScreenType = 4;
		break;

	case	PLC_SETTING_NUM:
		iScreenType = 5;
		break;

	case	CLOCK_MENU_NUM:
		iScreenType = 6;
		break;

	case	CLEAR_DATA_NUM:
		iScreenType = 7;
		break;

	case	MENU_CALL_KEY_NUM:
		iScreenType = 8;
		break;

	case	BUZZER_NUM:
		iScreenType = 9;
		break;

	case	OPENNING_NUM:
	case	BATTERY_NUM:
		iScreenType = 10;
		break;

	case	BACKLIGHT_NUM:
	case	MEMORY_SIZE_NUM:
	case	DATA_TRANSFER_NUM:
		iScreenType = 11;
		break;

	case	LCDCONTRAST_NUM:
		iScreenType = 12;
		break;

	case	COMMENT_SCREEN_NUM:
		iScreenType = 13;
		break;

	case	TIME_SWITCH_NUM:
		iScreenType = 14;
		break;

	case 50:					/* TIME_SWITCH_NUM �ȿ� ȭ��. */
		iScreenType = 15;
		break;

	}
	if((iScreenData[iScreenType][iflag] & iData) == iData)
	{
		return iKeyCode;
	}


	for(i = 0; i < 8; i++)
	{
		if(KeyTochData[i] == 0xFF || KeyTochData[i] == 0x00)
		{
			iReKey = iKeyCode;
			break;
		}

		if(KeyTochData[i]>30)
		{
			icnt = KeyTochData[i]-31;
			iflag = 1;
		}
		else
		{
			icnt = KeyTochData[i]-1;
			iflag = 0;
		}
		iData = 0x20000000 >> icnt;


		if((iScreenData[iScreenType][iflag] & iData) == iData)
		{
			iReKey = KeyTochData[i];
			break;
		}
	}
	return iReKey;
}
int iKeyAcceptReturn(int itype)
{
	int		i;
	int		iReKey;
	int		iKeyCode;
	int		iData;
	short	icnt;
	short	iflag;
	short	iScreenType;

	iKeyCode = KeyAccept();

		if((iKeyCode == 1 || iKeyCode == 2 ||		//Exit
		  (iKeyCode >= 13 && iKeyCode <= 15) ||		//Menue
		   iKeyCode == 0 || iKeyCode == PC_DNLOAD_START ||
		   iKeyCode == PC_UPLOAD_START || iKeyCode == -1))	/* ��� ȭ�鿡�� ������ �ִ� Ű */
		{
			return iKeyCode;
		}

		/************************/
		if(iKeyCode>30)
		{
			icnt = iKeyCode-31;
			iflag = 1;
		}
		else
		{
			icnt = iKeyCode-1;
			iflag = 0;
		}
		iData = 0x20000000 >> icnt;

		/********************************************/
		switch(itype)
		{
			case	SELECT_MEMU_NUM:			
			case 	DATA_VIEW_NUM:			
			case 	BASE_SCREEN_NUM:
			case 	WINDOW_SCREEN_NUM:
			case 	SET_FUNTION_NUM:
			case 	SET_ENVIRONMENT_NUM:
				iScreenType = 0;
			break;

			case 	MONITORING_NUM:
			case	PRINT_OUT_NUM:
				iScreenType = 1;
			break;

			case	DEVICE_MONITORING_NUM:
				iScreenType = 2;
			break;

			case	LANGUAGE_NUM:
				iScreenType = 3;
			break;

			case	SERIAL_PORT_NUM:
				iScreenType = 4;
			break;

			case	PLC_SETTING_NUM:
				iScreenType = 5;
			break;

			case	CLOCK_MENU_NUM:
				iScreenType = 6;
			break;

			case	CLEAR_DATA_NUM:
				iScreenType = 7;
			break;


			case	MENU_CALL_KEY_NUM:
				iScreenType = 8;
			break;

			case	BUZZER_NUM:
				iScreenType = 9;
			break;

			case	OPENNING_NUM:
			case	BATTERY_NUM:
				iScreenType = 10;
			break;

			case	BACKLIGHT_NUM:
			case	MEMORY_SIZE_NUM:
			case	DATA_TRANSFER_NUM:
				iScreenType = 11;
			break;

			case	LCDCONTRAST_NUM:
				iScreenType = 12;
			break;

			case	COMMENT_SCREEN_NUM:
				iScreenType = 13;
			break;

			case	TIME_SWITCH_NUM:
				iScreenType = 14;
			break;

			case 50:					/* TIME_SWITCH_NUM �ȿ� ȭ��. */
				iScreenType = 15;
			break;

		}
		if((iScreenData[iScreenType][iflag] & iData) == iData)
		{
			return iKeyCode;
		}


	for(i = 0; i < 8; i++)
	{
		if(KeyTochData[i] == 0xFF || KeyTochData[i] == 0x00)
		{
			iReKey = iKeyCode;
			break;
		}

		if(KeyTochData[i]>30)
		{
			icnt = KeyTochData[i]-31;
			iflag = 1;
		}
		else
		{
			icnt = KeyTochData[i]-1;
			iflag = 0;
		}
		iData = 0x20000000 >> icnt;


		if((iScreenData[iScreenType][iflag] & iData) == iData)
		{
			iReKey = KeyTochData[i];
			break;
		}
	}
	return iReKey;
}

/*int iKeyReturn(int itype)
{
	int i;
	int	iReKey;
	int iKeyCode;

	iKeyCode = KeyWait();

		if((iKeyCode == 1 || iKeyCode == 2 ||
		  (iKeyCode >= 13 && iKeyCode <= 15) ||
		   iKeyCode == 46 || iKeyCode == 47 ||
		   iKeyCode == 59 || iKeyCode == 60 || 
		   iKeyCode == 0 || iKeyCode == PC_START ||
		   iKeyCode == UP_START))
		{
			return iKeyCode;
		}


	for(i = 0; i < 8; i++)
	{
		if(KeyTochData[i] == 0xFF || KeyTochData[i] == 0x00)
		{
			iReKey = iKeyCode;
			break;
		}

		if(KeyTochData[i] == 1 || KeyTochData[i] == 2 ||
		  (KeyTochData[i] >= 13 && KeyTochData[i] <= 15) ||
		   KeyTochData[i] == 46 || KeyTochData[i] == 47 ||
		   KeyTochData[i] == 59 || KeyTochData[i] == 60)
		{
			iReKey = KeyTochData[i];
			break;
		}
	}
	return iReKey;
}
*/
/*************************************************************/
