void	SetComment_Func(int iDispOrder);
int	DrawComment_Func(int mode,_COMMENT_EVENT_TBL* CommentEventTbl,int iDispOrder);
void	CommentDispWatch(int iOrder);
void vMultiTextDisp(int sX, int sY, int eX, int eY, char * cDispData,int xbai,int ybai, int iColor, int iType);
int vCommentDataSet(int inowNum, char *cDataBuffer, int *iColor, int *iLen);
void vCommentDisplayFormat(int i ,char* Data, short SizeH ,short SizeV );

