void	InitSci1( int borate, int ldata, int parity );
void	Rs232cBordrateOrgSet( void );
void	Rs232cBordrateSet( void );
void	Sio1RtsOn(void);
void	Sio1RtsOff(void);
int	_Sci1ERProc( void );
//void	_Sci1ERInterruptHandler( void );
int	_Sci1RXInterruptProc( void );
//void	_Sci1RXInterruptHandler( void );
int	_Sci1TXInterruptProc(void);
//void	_Sci1TXInterruptHandler( void );
int Sio1SendChar( unsigned char ch );
void	Sio1RecDrv( STTFrm* pSTT );     /* SIO���M�h���C�o�^�X�N */
void	Sio1Drv( STTFrm* pSTT );     /* SIO���M�h���C�o�^�X�N */
