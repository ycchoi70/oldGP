/*****************************************************************************************/
/*	PLC ����M �v���O��?(Autonics LP Series)	*/
/*	2003.5.31				*/
/************************************************/
/*  2008.09.29.																	*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����	  */
/*****************************************************************************************/

#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include	"hook_plcapl.h"

/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V3.3M"
/*****************************************************************************************/


#ifdef	WIN32
#define SGN_PLC		0			/* 0��° �ñ׳��� 0�϶� ���ø� ���� �ʵ��� ��. */
#endif								/* ���� �Ʒ� ������ ������ ����� �߰� �Ͽ��� */ 		

#define	MAX_RTY_COUNT		3	/* Retry count */

#define	MAX_BITCNT			255	/* �ѹ��� �а� ���� �ִ� �ִ� ��Ʈī��Ʈ, ����� ����*/
#define	MAX_WORDCNT			127	/* �ѹ��� �а� ���� �ִ� �ִ� ���� ī��Ʈ */

#define	MAX_MON_BITCNT_PKG	16	/* ���� ��Ʈ ����� �ѹ��� ��� ������ �ִ� ��Ʈ�� */

#ifdef	OLD
#define	ONE_MON_BITCNT		0  /* ����� �ѹ��� ����Ҽ� �ִ� �ִ� ��Ʈ�� */
#define	MAX_MON_BITCNT		0 * 16	/* ����� ��� ������ �ִ� ��Ʈ��  */

#define	ONE_MON_WORDCNT		0	/* ����� �ѹ��� ����Ҽ� �ִ� �ִ� ����� */
#define	MAX_MON_WORDCNT		0 * 16	/* ����� ��� ������ �ִ� ����� */

#else

#define	ONE_MON_BITCNT		64   /* ����� �ѹ��� ����Ҽ� �ִ� �ִ� ��Ʈ�� */
#define	MAX_MON_BITCNT		64 * 16	 /* ����� ��� ������ �ִ� ��Ʈ��  */

#define	ONE_MON_WORDCNT		64	 /* ����� �ѹ��� ����Ҽ� �ִ� �ִ� ����� */
#define	MAX_MON_WORDCNT		64 * 16	 /* ����� ��� ������ �ִ� ����� */
#endif

#define	MAX_MONITOR_CNT     1024 

/* 20081003 */
#define	MAX_BLOC_NO		(MAX_MONITOR_CNT/64)

#define	MAX_WORD_CONT_CNT	4	/* ���� ���� */
#define	MAX_BIT_CONT_CNT	4	/* ��Ʈ ���� */

#ifdef SH_CPU
static	int			gSetNumBit;
static	int			gSetNumWord;
static	int			GroopSema;		/* Grooping Semafo */
static	int			GroopingFlag;	/* Grooping ON */
#endif
#ifdef AMR_CPU
/* PLC COmBUFF �� ������ ����. ARM�ϰ�� ��ũ�� ��巹���� ���ϱ� ������ ���� ������ ��� */
#endif

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/****************************************************************************************************/
/* LGMKCNET ���� �������� �ҽ� ���� */
/****************************************************************************************************/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH1, PLCTYPE_CH2 ���� ����ϴ� �Լ� ���� */ 
/********************************/
/*	LG Cnet Command Table   	*/
/********************************/
#define	DUMY_DEV			2000
#define	Device_Length_R_ST	DUMY_DEV
#define	Device_Length_R		4100
#define	MAXDevice_Length_R	4000
#define	Device_Length_V_ST	(Device_Length_R_ST+Device_Length_R)
#define	Device_Length_V		300
#define	MAXDevice_Length_V	256
#define	Device_Length_F_ST	(Device_Length_V_ST+Device_Length_V)
#define	Device_Length_F		300
#define	MAXDevice_Length_F	256
#define	Device_Length_Z_ST	(Device_Length_F_ST+Device_Length_F)
#define	Device_Length_Z		300
#define	MAXDevice_Length_Z	256
#define	Device_Length_X_ST	(Device_Length_Z_ST+Device_Length_Z)
#define	Device_Length_X		300		/* ���̓���? */
#define	MAXDevice_Length_X	256		/* ���̓���? */
#define	Device_Length_Y_ST	(Device_Length_X_ST+Device_Length_X)
#define	Device_Length_Y		300		/* �o�̓���? */
#define	MAXDevice_Length_Y	256		/* �o�̓���? */

#define	Device_Length_BT_ST	(Device_Length_Y_ST+Device_Length_Y)
#define	Device_Length_BT	100
#define	MAXDevice_Length_BT	16
#define	Device_Length_T_ST	(Device_Length_BT_ST+Device_Length_BT)
#define	Device_Length_T		300
#define	Device_Length_T_BIT		256		
#define	MAXDevice_Length_T	256		
#define	Device_Length_ST_ST	(Device_Length_T_ST+Device_Length_T)
#define	Device_Length_ST	300
#define	MAXDevice_Length_ST	256
#define	Device_Length_BC_ST	(Device_Length_ST_ST+Device_Length_ST)
#define	Device_Length_BC	100
#define	MAXDevice_Length_BC	16
#define	Device_Length_C_ST	(Device_Length_BC_ST+Device_Length_BC)
#define	Device_Length_C		300
#define	MAXDevice_Length_C	256
#define	Device_Length_SC_ST	(Device_Length_C_ST+Device_Length_C)
#define	Device_Length_SC	300
#define	MAXDevice_Length_SC	256
#define	Device_Length_M_ST	(Device_Length_SC_ST+Device_Length_SC)
#define	Device_Length_M		10500
#define	MAXDevice_Length_M	10000
#define	Device_Length_S_ST	(Device_Length_M_ST+Device_Length_M)
#define	Device_Length_S		500
#define	MAXDevice_Length_S	256
#define	Device_Length_L_ST	(Device_Length_S_ST+Device_Length_S)
#define	Device_Length_L		1000
#define	MAXDevice_Length_L	256
#define	Device_Length_D_ST	(Device_Length_L_ST+Device_Length_L)
#define	Device_Length_D		10000
#define	MAXDevice_Length_D	10000
#define	Device_Length_END	(Device_Length_D_ST+Device_Length_D+Device_Length_F)





static	const	PLC_CONST	CommTbl[]={
	{"BR",1},		/*0 Bit Cont read */
	{"WR",1},		/*1 Word Cont Read */
	{"RB",1},		/*2 Bit Random Read */
	{"RW",1},		/*3 Word Random Read */
	{"BW",1},		/*4 Bit Cont Write */
	{"WW",1},		/*5 Word Cont Write */
	{"ME",1},		/*6 Monitor Entry */
	{"MR",1},		/*6 Monitor Read */
	{"MC",1},		/*6 Monitor Clear */
};


static	const	DEV_CODE_TBL bPLCDeviceTbl[] = {
	{"X"  ,0x0010,Device_Length_X_ST  , 2},
	{"Y"  ,0x0014,Device_Length_Y_ST  , 2},
	{"M"  ,0x0018,Device_Length_M_ST  , 3},
	{"S"  ,0x0020,Device_Length_S_ST  , 2},
	{"L"  ,0x0028,Device_Length_L_ST  , 2},	
	{"T"  ,0x0032,Device_Length_BT_ST , 5},	
	{"C"  ,0x0050,Device_Length_BC_ST , 2},
	{"F"  ,0x001B,Device_Length_F_ST  , 2},
	{"UB" ,0x007F,                   0, 4},
};


static	const	DEV_CODE_TBL wPLCDeviceTbl[] = {
	{"X"  ,0x0080,Device_Length_X_ST  , 2},
	{"Y"  ,0x0084,Device_Length_Y_ST  , 2},
	{"M"  ,0x0088,Device_Length_M_ST  , 3},
	{"S"  ,0x0090,Device_Length_S_ST  , 2},
	{"L"  ,0x0098,Device_Length_L_ST  , 2},	
	{"R"  ,0x00C2,Device_Length_R_ST  , 2},
	{"T"  ,0x00A2,Device_Length_T_ST  , 6},
	{"ST" ,0x0000,Device_Length_ST_ST , 6},
	{"C"  ,0x00B0,Device_Length_C_ST  , 2},
	{"SC" ,0x0000,Device_Length_SC_ST , 2},
	{"F"  ,0x008B,Device_Length_F_ST  , 2},		
	{"D"  ,0x00C0,Device_Length_D_ST  , 2},
	{"UW" ,0x00EF,                   0, 4},
};

/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef	PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_115200;
	*DataBit= RS_DATA8;
	*Parity= ((RS_XONOFF << 16) |(RS_STOP01 << 8) | (RS_EVEN << 0));		/* 20090527 */	
}
/************************************************/
/*	Func:GetGroopSema							*/
/*		PLC Semafor(�󂭂܂ő҂�)				*/
/*	Ret	:�Ȃ�									*/
/************************************************/
/*	Func:GetGroopSema							*/
/*		PLC Semafor : �⺻������ �浹�� �Ͼ�� �ʵ��� �ϴ� ��� 				*/
/*           ����͸� ����Ҷ��� ��ȿ, CH1���� �۽��� �������Ʈ�� ��ȣ�� ����ö� ���� PLC�� ������ �ְ� �ޱ� ���ؼ� �켱 ó������ ����� �Ϸ�ɶ����� ��� */
/*	Ret	:����									*/
/************************************************/
/* 20081003 */
static	void	GetGroopSema(void)
{
/*	unsigned int	NowTime;
	unsigned int	StartTime;
*/
	if(GroopSema == 0){		/* Grooping Sema */
	}else{
/*		StartTime= B_GetNowTime();
*/
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
/*
			NowTime= B_GetNowTime();
			if((StartTime+ 3000) < NowTime){
				GroopSema= 0;
			}
*/
			B_Delay(20);
		}
	}
	GroopSema++;
}
/************************************************/
/*	Func:GetGroopSema							*/
/*		PLC Semafor Crear						*/
/*	Ret	:�Ȃ�									*/
/************************************************/
/*	Func:GetGroopSema							*/
/*		PLC Semafor Crear						*/
/*	Ret	:����									*/
/************************************************/
static	void	ResetGroopSema(void)
{
	GroopSema= 0;
}
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	if(*RecCnt < PLC_BUF_MAX){
		RecBuff[(*RecCnt)++] = data;
	}
	switch(data){
	case STX:
		if(*CommMode == 1){
			*CommMode = 2;
		}
		break;
	case ETB:
	case ETX:
		if(*CommMode == 2){
			*CommMode = 3;
		}
		break;
	case ENQ:
	case ACK:
	case NAK:
		ret= 0;
		break;
	default:
		switch(*CommMode){
		case 0:				/* Start */
			*CommMode = 1;
			*RecCnt= 0;
			RecBuff[(*RecCnt)++] = data;
			break;
		case 1:				/* kyokuban+STX */
			break;
		case 2:				/* Data */
			break;
		case 3:		/* BCC1 */
			*CommMode = 4;
			break;
		case 4:		/* BCC2 */
			*CommMode = 0;
			ret = 0;	
			break;
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���ʏ���							*/
/************************************/
static	void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	if(data < 0){			/* - check 041116 */
		
		data *= -1;
		buff[0]= '-';
		for(i= 1; i < cnt+1; i++){								/*cnt+1�̵� ������ */
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}else{
		for(i= 0; i < cnt; i++){
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}
	buff[i]= 0;
}
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
/* kyukuban Addition */
static	int SetPLCBCC(char *buff,int cnt,int DstNo)
{
	int		i;
	unsigned char bcc;

	B_Bin2Hex(DstNo,2,&buff[0]);
	B_Bin2Hex(MyStationNo,2,&buff[2]);
	buff[4] = STX;
	buff[cnt+5] = ETX;
	bcc = 0;
	for(i = 0; i < cnt+1; i++){
		bcc ^= buff[i+5];
	}
	B_Bin2Hex(bcc&0x00ff,2,(char *)&buff[cnt+6]);
	return(cnt + 8);
}




/************************************/
/*	PLC Send						*/
/************************************/
/*	*Cnt:���M(Data Count)�A��M(All Data Count)�f??�J�E���g */
static	int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode,int DstNo,int wmode)
{
	int		i;
	int		ret;
	int		rty_cnt;
	unsigned char bcc;
	unsigned char bcc1;
	int		SendCnt;
	unsigned	mSt;

	SendCnt= SetPLCBCC((char *)combuf,*Cnt,DstNo);
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
		ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		if(ret == OK){
			/* �ǔ�?�F�b�N */
			mSt= (unsigned)B_Hex2Bin((char*)&rData[0]);

			if(mSt == (unsigned)MyStationNo){
				if(*Cnt > 5){		/* Control Code */
					/* DATA->EOT(SUM) */
					bcc= 0;
					for(i = 0; i < *Cnt-7; i++){
						bcc ^= rData[i+5];
					}
					bcc1= (unsigned char)B_Hex2Bin((char *)&rData[i+5]);
					if(bcc != bcc1){
						ret= NG; /* NG = -1; */
					}else{
						if(wmode == 1){
							if(rData[4] == NAK){	ret= NG;	}
						}
					}
				}else{											/*2009.08.26*/
					if(rData[4] == NAK){	ret= NG;	}		/*2009.08.26*/
				}												/*2009.08.26*/
			}else{
				ret= NG;		/* Station No Error */
			}
		}
		if(ret == OK){
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}
	return(ret);
}

static	int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode,int DstNo)
{
	int		ret;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,*Cnt,DstNo);
	ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	return(ret);
}

static	int	SendRecPLCContl(int mode,char *combuf,unsigned char *rData,int Data,int DstNo)
{
	int	ret;
	int	Cnt;
	unsigned int		mSt;

	B_Bin2Hex(DstNo,2,&combuf[0]);
	B_Bin2Hex(MyStationNo,2,&combuf[2]);
	combuf[4] = Data;
	ret= C_SendRecPLC(mode,rData,&Cnt,0,5,(char *)combuf,2000);
	if(ret == OK){
		/* �ǔ�?�F�b�N */
		mSt= (unsigned)B_Hex2Bin((char*)&rData[0]);

		if(mSt == (unsigned)MyStationNo){
		}else{
			ret= NG;
		}
	}
	return(ret);
}


/********************************************/
/*	Connection Proc							*/
/*	*PlcType:[0]->PlcType					*/
/*	         [1]->MyStation					*/
/*	         [2]->DstStation				*/
/********************************************/


static	int	C_Connection( int *PlcType,int iConnect )
{
	int		ret;
	char	buff[32];

	int		Speed;
	int		DataBit;
	int		Parity;



	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
	/*		B_RsModeSet(RS_PLC,RS_INIT,RS_19200,RS_DATA8,RS_NONE); */

		}else{						/* RS-422 */

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
	/*		B_RsModeSet(RS_PLC,RS_INIT,RS_19200,RS_DATA8,RS_NONE); */

		}
#ifdef	WIN32
		while(1){
			if(SioPLCOpenFlag == 0){
				break;
			}
			B_Delay(10);
		}
#endif
		B_Delay(200);
	}
	/* PLC Connect Check */
	monitorModeFlag= PlcType[4];		/* 20090704 */

	ResetGroopSema();		/* 20081003 */
	GroopingFlag= 0;		/* 20081003 */

	MyStationNo= PlcType[1];

#ifdef	PLCTYPE_CH1
	DstStationNo = (unsigned char)0xff;	/* DA */
#endif
#ifdef	PLCTYPE_CH2
	DstStationNo = (unsigned char)PlcType[2];	/* DA */
#endif


	ret= SendRecPLCContl(2,(char *)buff,PlcRecBuff,ENQ,DstStationNo);
	if((ret == 0) && (PlcRecBuff[4] == ACK)){
		ret= 1;
#ifdef	PLCTYPE_CH1
		DstStationNo= (unsigned char)B_Hex2nBin((char *)&PlcRecBuff[2],2);		/* �ǔ� */
#endif
	}else{
		ret= 0;
	}
	return(ret);
}


static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif

#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif

}
/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
static	int	MakePLCDevAddress(int mode, unsigned char *pDevice, int *Address)		/* ksc20090522 */
{
	int		i;
	int		ret;

	ret = -1;
	if(mode == 0){			/* Bit Device */
		for(i= 0; i < TBQ(bPLCDeviceTbl); i++){
			if(bPLCDeviceTbl[i].DevCode == ((int)*pDevice & 0xff)){
				break;
			}
		}
		if(i >= TBQ(bPLCDeviceTbl)){	return(ret);	}	/* Code Error */
		*Address= *Address+ bPLCDeviceTbl[i].StartAddr;
		ret = 0;
	}else{
		for(i= 0; i < TBQ(wPLCDeviceTbl); i++){
			if(wPLCDeviceTbl[i].DevCode == ((int)*pDevice & 0xff)){
				break;
			}
		}
		if(i >= TBQ(wPLCDeviceTbl)){	return(ret);	}	/* Code Error */
		*Address= *Address+ wPLCDeviceTbl[i].StartAddr;
		ret = 0;
	}
	return(ret);
}


/****************************/
/* Make Read Device			*/
/****************************/
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	char	buff[8];
	int		WordAddr;
	int		BitAddr;

	if(mode == 0){			/* Bit */
		WordAddr= Address/16;
		BitAddr= Address%16;
		ret= MakePLCDevAddress(mode, (unsigned char*)pDevice, &WordAddr);		/* ksc20090522 */
		if(ret != 0){	return(ret);	}
		B_gstrcpy(&combuff[0],CommTbl[0].strData);
		B_Bin2Hex(sCnt,2,buff);
		B_gstrcat(&combuff[0],buff);
		B_Bin2Hex(WordAddr,4,buff);
		B_gstrcat(&combuff[0],buff);
		B_Bin2Hex(BitAddr,1,buff);
		B_gstrcat(&combuff[0],buff);
	}else{					/* Word */
		WordAddr= Address;
		ret= MakePLCDevAddress(mode, (unsigned char*)pDevice, &WordAddr);		/* ksc20090522 */
		if(ret != 0){	return(ret);	}
		B_gstrcpy(&combuff[0],CommTbl[1].strData);
		B_Bin2Hex(sCnt,2,buff);
		B_gstrcat(&combuff[0],buff);
		B_Bin2Hex(WordAddr,4,buff);
		B_gstrcat(&combuff[0],buff);
	}
	return(ret);
}
/************************************************/
/*	Func:BitReadProc							*/
/*		Bit Read Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:�ʐM�p��M�o�b�t??Addr	*/
/*		int PlcType:���g�p						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:BitReadProc							*/
/*		Bit Read Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:��ſ� ���� ���� Addr	*/
/*		int PlcType:�̻��						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	BitReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt;
	unsigned char	*SaveAddr;
	int		dCnt;
	int		Address;
	int		SendRecCnt;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_BITCNT){	dCnt -= MAX_BITCNT;	mp->mext= MAX_BITCNT;	}
		else{					mp->mext= dCnt;		dCnt = 0;				}
		ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[5],mp->mext);
		if(ret != 0){				break;		}
		Cnt = mp->mext;
		SendRecCnt= B_gstrlen((char*)&PlcSendBuff[5]);
		SaveAddr = (unsigned char *)mp->mptr;

#ifdef	PLCTYPE_CH1
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&SendRecCnt,0,DstStationNo,0);
#endif
#ifdef	PLCTYPE_CH2
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&SendRecCnt,0,mp->mbuf[4],0);
#endif
		if(ret != 0){				ret= -1;	break;	}
		for(i = 0; i < Cnt; i++){
			*SaveAddr++ = rDataFx[i+ 9] == '0' ? 0 : 1;
		}
		if(dCnt == 0){			break;		}
		Address += MAX_BITCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_BITCNT);
	}
	return(ret);
}
/************************************************/
/*	Func:WordReadProc							*/
/*		Word Read Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:�ʐM�p��M�o�b�t??Addr	*/
/*		int PlcType:���g�p						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:WordReadProc							*/
/*		Word Read Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:��ſ� ���� ���� Addr	*/
/*		int PlcType:�̻��						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	WordReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt;
	unsigned char	*SaveAddr;
	int		dCnt;
	int		Address;
	int		SendRecCnt;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_WORDCNT){	dCnt -= MAX_WORDCNT;	mp->mext= MAX_WORDCNT;	}
		else{					mp->mext= dCnt;			dCnt = 0;				}
		ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[5],mp->mext*2);
		if(ret != 0){					break;			}
		Cnt = mp->mext* 2;
		SendRecCnt= B_gstrlen((char*)&PlcSendBuff[5]);
		SaveAddr = (unsigned char *)mp->mptr;
#ifdef	PLCTYPE_CH1
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&SendRecCnt,0,DstStationNo,0);
#endif
#ifdef	PLCTYPE_CH2
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&SendRecCnt,0,mp->mbuf[4],0);
#endif
		if(ret != 0){			ret= -1;	break;		}
		for(i = 0; i < Cnt; i++){
			rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+ 9]);
		}
		for(i = 0; i < Cnt/2; i++){
#ifdef SH_CPU
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+0];
#endif
#ifdef ARM_CPU
			*(unsigned char *)SaveAddr++ = rDataFx[i*2];
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
#endif
		}
		if(dCnt == 0){						break;		}
		Address += MAX_WORDCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
	}
	return(ret);
}
/************************************************/
/*	Func:C_PLCCommRead							*/
/*		Device Read Func						*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:�ʐM�p��M�o�b�t??Addr	*/
/*		int PlcType:���g�p						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:C_PLCCommRead							*/
/*		Device Read Func						*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:��ſ� ���� ���� Addr	*/
/*		int PlcType:�̻��						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;

/* 20081003 */
	GetGroopSema();
	switch(mp->mpec){
	case PLC_BIT:		ret= BitReadProc(mp,rDataFx,PlcType);
						break;
	case PLC_WORD:		ret= WordReadProc(mp,rDataFx,PlcType);
						break;
	}
/* 20081003 */
	ResetGroopSema();
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	char	buff[8];
	int		WordAddr;
	int		BitAddr;
#ifdef SH_CPU
	char	sdata;
#endif
	if(mode == 0){		/* BIT */
		WordAddr= Address/16;
		BitAddr= Address%16;
		ret= MakePLCDevAddress(mode, (unsigned char*)pDevice, &WordAddr);		/* ksc20090522 */			
		if(ret != 0){	return(ret);	}
		B_gstrcpy(&combuff[0],CommTbl[4].strData);
		B_Bin2Hex(Cnt,2,buff);
		B_gstrcat(&combuff[0],buff);
		B_Bin2Hex(WordAddr,4,buff);
		B_gstrcat(&combuff[0],buff);
		B_Bin2Hex(BitAddr,1,buff);
		B_gstrcat(&combuff[0],buff);
		buff[1]= 0;
		for(i= 0; i < Cnt; i++){
			if(*data++ == 0){	buff[0]= '0';	}
			else{				buff[0]= '1';	}
			B_gstrcat(&combuff[0],buff);
		}
	}else{		/* WORD */
		WordAddr= Address;
		ret= MakePLCDevAddress(mode, (unsigned char*)pDevice, &WordAddr);		/* ksc20090522 */
		if(ret != 0){	return(ret);	}
		B_gstrcpy(&combuff[0],CommTbl[5].strData);
		B_Bin2Hex(Cnt,2,buff);
		B_gstrcat(&combuff[0],buff);
		B_Bin2Hex(WordAddr,4,buff);
		B_gstrcat(&combuff[0],buff);
		for(i= 0; i < Cnt; i++){
#ifdef SH_CPU
			sdata= *data++;
			B_Bin2Hex(*data++,2,buff);
			B_gstrcat(&combuff[0],buff);
			B_Bin2Hex(sdata,2,buff);
			B_gstrcat(&combuff[0],buff);
#endif
#ifdef ARM_CPU
			B_Bin2Hex(*data++,2,buff);
			B_gstrcat(&combuff[0],buff);
			B_Bin2Hex(*data++,2,buff);
			B_gstrcat(&combuff[0],buff);
#endif
		}
	}
	return(ret);
}
/************************************************/
/*	Func:BitWriteProc							*/
/*		Bit Write Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:�ʐM�p��M�o�b�t??Addr	*/
/*		int PlcType:���g�p						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:BitWriteProc							*/
/*		Bit Write Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:��ſ� ���� ���� Addr	*/
/*		int PlcType:�̻��						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	BitWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		dCnt;
	int		Address;
	char	*dataAddr;
	int		SendRecCnt;

	Address= mp->mpar;
	dCnt= mp->mext;
	dataAddr= (char*)mp->mptr;
	while(1){
		if(dCnt > MAX_BITCNT){	dCnt -= MAX_BITCNT;	mp->mext= MAX_BITCNT;	}
		else{					mp->mext= dCnt;		dCnt = 0;				}
		ret = MakePLCWriteData(0,(char *)mp->mbuf,Address,mp->mext,(char *)&PlcSendBuff[5],dataAddr);
		if(ret != 0){		ret= -1;		break;		}
		SendRecCnt= B_gstrlen((char*)&PlcSendBuff[5]);

#ifdef	PLCTYPE_CH1
		ret= SendRecPLCWithBCC(2,(char*)PlcSendBuff,rDataFx,&SendRecCnt,0,DstStationNo,1);
#endif
#ifdef	PLCTYPE_CH2
		ret= SendRecPLCWithBCC(2,(char*)PlcSendBuff,rDataFx,&SendRecCnt,0,mp->mbuf[4],1);
#endif
		if((ret != 0) || (rDataFx[4] != ACK)){		ret= -1;		break;		}
		if(dCnt == 0){						break;		}
		Address += MAX_BITCNT;
		dataAddr += MAX_BITCNT;
	}
	return(ret);
}
/************************************************/
/*	Func:WordWriteProc							*/
/*		Word Write Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:�ʐM�p��M�o�b�t??Addr	*/
/*		int PlcType:���g�p						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:WordWriteProc							*/
/*		Word Write Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx: ��ſ� ���� ���� Addr	*/
/*		int PlcType:�̻��						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	WordWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		SendRecCnt;
	int		dCnt;
	int		Address;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_WORDCNT){	dCnt -= MAX_WORDCNT;	mp->mext= MAX_WORDCNT;	}
		else{					mp->mext= dCnt;			dCnt = 0;				}
		ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)&PlcSendBuff[5],(char *)mp->mptr);
		if(ret != 0){				break;			}
		SendRecCnt= B_gstrlen((char*)&PlcSendBuff[5]);

#ifdef	PLCTYPE_CH1
		ret= SendRecPLCWithBCC(2,(char*)PlcSendBuff,rDataFx,&SendRecCnt,0,DstStationNo,1);
#endif
#ifdef	PLCTYPE_CH2
		ret= SendRecPLCWithBCC(2,(char*)PlcSendBuff,rDataFx,&SendRecCnt,0,mp->mbuf[4],1);
#endif
		if((ret != 0) || (rDataFx[4] != ACK)){				ret= -1;	break;	}
		if(dCnt == 0){							break;	}
		Address += MAX_WORDCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	
/* 20081003 */
	GetGroopSema();
	ret=0;
	switch(mp->mpec){
	case PLC_BIT:		ret= BitWriteProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordWriteProc(mp,rDataFx,PlcType);		break;
	}
/* 20081003 */
	ResetGroopSema();
	return(ret);
}
static	int	C_GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}

/* ���� �ҽ� �� */
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH1������ ����ϴ� �Լ� ���� */ 

#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
/************************************/
/*	Device & Address Change			*/
/************************************/
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/************************************************/
/*	�O��?�v����								*/
/************************************************/
int	MakePLCGroupAddr(int mode, int First, char *pDevice, int Address, char *combuff)
{
	int		ret;
	char	buff[8];
	int		WordAddr;
	int		BitAddr;

	ret= -1;
	if(mode == 0){		/* Bit */
		WordAddr= Address/16;
		BitAddr= Address%16;
		ret= MakePLCDevAddress(mode, (unsigned char*)pDevice, &WordAddr);		/* ksc20090522 */
		if(ret != 0){	return(ret);	}
		B_Bin2Hex(WordAddr,4,buff);
		B_gstrcpy(&combuff[0],buff);
		B_Bin2Hex(BitAddr,1,buff);
		B_gstrcat(&combuff[0],buff);
	}else{		/* WORD */
		WordAddr= Address;
		ret= MakePLCDevAddress(mode, (unsigned char*)pDevice, &WordAddr);		/* ksc20090522 */
		if(ret != 0){	return(ret);	}
		B_Bin2Hex(WordAddr,4,buff);
		B_gstrcpy(&combuff[0],buff);
	}
	return(ret);
}
/****************************************/
/*	Monitor Reset�쐬					*/
/****************************************/
int	RestMonitor(void)
{
	int	ret;
	int	SendRecCnt;

	B_gstrcpy((char*)&PlcSendBuff[5],CommTbl[8].strData);
	SendRecCnt= 2;
	ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&SendRecCnt,0,DstStationNo,1);
	if((ret != 0) || (PlcRecBuff[4] != ACK)){
		return(-1);
	}else{
		return(0);
	}
}
/****************************************/
/*	Bit Monitor�쐬						*/
/****************************************/
int	MakeBitMonitor(int *rBlock)
{
	int		i;
	int		StartIdx;
	int		block;
	int		ret;
	char	buff[8];

	StartIdx= 0;
/* 20081003 */
	block= MAX_BLOC_NO;
	ret= 0;
	/*Bit Device Set*/
	B_gmemset((char *)PlcSendBuff,0,sizeof(PlcSendBuff));
	B_gstrcpy((char*)&PlcSendBuff[5],CommTbl[6].strData);			/* ME */
	for(i = 0; i < DeviceCntSys; i++){
		if(CommonArea.PcUpDownMode != 0){			/* 071102 */
			return(0);
		}
		/* 20060411 */
		if((DeviceDataSys[i].DevFlag == 0) &&				/* 0:Bit / 1:Word */
			(DeviceDataSys[i].SameDevInf == 0) &&			/* 0:Start Device 1:Same Device, 2:Continue Device, 3:Patten Device */ 
			(DeviceDataSys[i].Continus == 0) &&				/* Continue or Patten */
			(DeviceDataSys[i].DevName[0] != 0x7f) &&		/* DevName[0] : Device Index */
			(DeviceDataSys[i].DevCnt == 1)){				/* Device Count */

			if(MakePLCGroupAddr(DeviceDataSys[i].DevFlag, StartIdx, (char *)DeviceDataSys[i].DevName, 
				DeviceDataSys[i].DevAddress, (char *)&PlcSendBuff[StartIdx*5+12]) != 0){
				continue;	/* ��������� ��Ʈ ����̽� ��� */
			}
			gDevTempAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
			DeviceDataSys[i].SameDevInf= -1;
			gDeviceCnt++;
			gDeviceCntBit++;
			StartIdx++;
			if(StartIdx >= ONE_MON_BITCNT){
/* 20081003 */
				B_Bin2Hex(block--,2,buff);			/* Block No */
				B_gmemcpy((char*)&PlcSendBuff[7],buff,2);
				B_Bin2Hex(StartIdx,2,buff);			/* Count */
				B_gmemcpy((char*)&PlcSendBuff[9],buff,2);
				PlcSendBuff[11]= '0';				/* Bit */
				StartIdx= B_gstrlen((char *)&PlcSendBuff[5]);
				ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0,DstStationNo,1);
		//		if(ret != 0){								/* 2009.08.26 del */
		//			ret= -1;								/* 2009.08.26 del */
		//			break;
		//		}											/* 2009.08.26 del */
				if((ret != 0) || (PlcRecBuff[4] != ACK)){	/* 2009.08.26 add */
					ret= -1;								/* 2009.08.26 add */
					break;									/* 2009.08.26 add */
				}											/* 2009.08.26 add */
				StartIdx= 0;
/* 20081003 */
				if(block < 1){	break;	}
			}
			if(gDeviceCnt >= MAX_MONITOR_CNT){
				break;
			}
		}
	}
	if((StartIdx != 0) && (ret == 0)){
/* 20081003 */
		B_Bin2Hex(block--,2,buff);			/* Block No */
		B_gmemcpy((char*)&PlcSendBuff[7],buff,2);
		B_Bin2Hex(StartIdx,2,buff);			/* Count */
		B_gmemcpy((char*)&PlcSendBuff[9],buff,2);
		PlcSendBuff[11]= '0';				/* Bit */
		StartIdx= B_gstrlen((char *)&PlcSendBuff[5]);
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0,DstStationNo,1);
//		if(ret != 0){								/* 2009.08.26 del */
//			ret= -1;								/* 2009.08.26 del */
//		}											/* 2009.08.26 del */
		if((ret != 0) || (PlcRecBuff[4] != ACK)){	/* 2009.08.26 add */
			ret= -1;								/* 2009.08.26 add */
		}											/* 2009.08.26 add */

	}
	*rBlock= block;
	return(ret);
}
/****************************************/
/*	Word Monitor�쐬						*/
/****************************************/
int	MakeWordMonitor(int block)
{
	int		i;
	int		StartIdx;
	int		ret= 0;
	char	buff[8];

/* 20081003 */
	if(block < 1){
		return(0);
	}
	StartIdx= 0;
	B_gmemset((char *)PlcSendBuff,0,sizeof(PlcSendBuff));
	B_gstrcpy((char*)&PlcSendBuff[5],CommTbl[6].strData);			/* ME */
	for(i = 0; i < DeviceCntSys; i++){
		if(CommonArea.PcUpDownMode != 0){			/* 071102 */
			return(0);
		}
		/* 20060411 */
		if((DeviceDataSys[i].DevFlag == 1) &&
			(DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus == 0) &&
			(DeviceDataSys[i].DevName[0] != (unsigned char)0xef) &&
			(DeviceDataSys[i].DevCnt == 1)){

			if(MakePLCGroupAddr(DeviceDataSys[i].DevFlag, StartIdx, (char *)DeviceDataSys[i].DevName,
								DeviceDataSys[i].DevAddress, (char *)&PlcSendBuff[StartIdx*4+12]) != 0){
				continue;
			}
			gDevTempAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
			DeviceDataSys[i].SameDevInf= -1;	/* ����Ϳ��� ����ϴ� ����̽��� �ǹ� */
			gDeviceCnt++;
			StartIdx++;
			gDeviceCntWord++;
			if(StartIdx >= ONE_MON_WORDCNT){
/* 20081003 */
				B_Bin2Hex(block--,2,buff);			/* Block No */
				B_gmemcpy((char*)&PlcSendBuff[7],buff,2);
				B_Bin2Hex(StartIdx,2,buff);			/* Count */
				B_gmemcpy((char*)&PlcSendBuff[9],buff,2);
				PlcSendBuff[11]= '1';				/* Word */
				StartIdx= B_gstrlen((char *)&PlcSendBuff[5]);
				ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0,DstStationNo,1);
//				if(ret != 0){	break;	}					/* 2009.08.26 del */
				if((ret != 0) || (PlcRecBuff[4] != ACK)){	/* 2009.08.26 add */
					ret= -1;								/* 2009.08.26 add */
					break;									/* 2009.08.26 add */
				}											/* 2009.08.26 add */
				StartIdx= 0;
			}
			if(gDeviceCnt >= MAX_MONITOR_CNT){				
				break;
			}
		}
	}
/* ���� ����� ����� ������ �ϳ��� ������ ����� �� */
	if((StartIdx != 0) && (ret == 0)){
/* 20081003 */
		B_Bin2Hex(block--,2,buff);			/* Block No */
		B_gmemcpy((char*)&PlcSendBuff[7],buff,2);
		B_Bin2Hex(StartIdx,2,buff);			/* Count */
		B_gmemcpy((char*)&PlcSendBuff[9],buff,2);
		PlcSendBuff[11]= '1';				/* Word */
		StartIdx= B_gstrlen((char *)&PlcSendBuff[5]);
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0,DstStationNo,1);
//		if(ret != 0){								/* 2009.08.26 del */
//			ret= -1;								/* 2009.08.26 del */
//		}											/* 2009.08.26 del */
		if((ret != 0) || (PlcRecBuff[4] != ACK)){	/* 2009.08.26 add */
			ret= -1;								/* 2009.08.26 add */
		}											/* 2009.08.26 add */
	}
	return(ret);
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			return;	
		}
		if(i > 0){
			if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
						MyAddress= DeviceDataSys[i].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
					MyAddress= DeviceDataSys[i].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN			   */
/*	2006.03.31 makebitpatarn �ϰ� ����         */
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/*	2006.03.31 makewordpatarn �ϰ� ����        */
/***************************************************/
void	MakeWordPatarn(int Start)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/***************************************************/
void	ClearBWContinue(void)
{
	int		i,j,idx;

	for(i= 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus != 0)){
			/* Continue */
			if(DeviceDataSys[i].DevFlag == 0){		/* BIT */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_BIT_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}else{									/* WORD */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_WORD_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}
		}
	}
}
void	DeviceInfClear(int *pBitCnt,int *pWordCnt,int *pTotalBitCnt,int *pTotalWordCnt)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Set Group */
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gDeviceCnt= 0;

	gSetNumBit= 0;
	gSetNumWord= 0;

	/* Same Device Check */
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	*pBitCnt= BitCnt;
	*pWordCnt= WordCnt;
	*pTotalBitCnt= TotalBitCnt;
	*pTotalWordCnt= TotalWordCnt;
}
/****************************************/
/*	�O��?�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;
	int		BlockNo;
/* 20081003 */
	int		ret= 0;

/* 20081003 */
	GetGroopSema();

	DeviceInfClear(&BitCnt,&WordCnt,&TotalBitCnt,&TotalWordCnt);
	/* Monitor Reset */
/* 20081003 */
/*	ret= RestMonitor(); */

	/* Bit Check */

/* 20081003 */
	BlockNo= MAX_BLOC_NO;
	if(BitCnt <= MAX_MON_BITCNT){
		if(monitorModeFlag == MONITOR){			/* 20090704 */
			MakeBitContinue();
		}else{
			ret= MakeBitMonitor(&BlockNo);
		}
	}else{
		MakeBitContinue();
		if(monitorModeFlag != MONITOR){			/* 20090704 */
			ret= MakeBitMonitor(&BlockNo);
		}
	}


	/* Word Check */
/* 20081003 */
	if(ret == 0){
		if(WordCnt <= MAX_MON_WORDCNT){
			if(monitorModeFlag == MONITOR){			/* 20090704 */
				MakeWordContinue(TotalBitCnt);
			}else{
				ret= MakeWordMonitor(BlockNo);
			}
		}else{
			MakeWordContinue(TotalBitCnt);
			if(monitorModeFlag != MONITOR){			/* 20090704 */
				ret= MakeWordMonitor(BlockNo);
			}
		}
	}
	if(ret != 0){		/* Monitor Clear */
		DeviceInfClear(&BitCnt,&WordCnt,&TotalBitCnt,&TotalWordCnt);
	}

	/* Continue MAX Check */
	ClearBWContinue();
	/* Bit Patarn */
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	/* Word Patarn */
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}

/* 20081003 */
	ResetGroopSema();
	return(ret);
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int	ret,i;
	int	SendRecCnt;
	char	buff[8];
	int	block;
	int	sidx;
	int	dCnt;
	int	devcnt;		/* 20081107 */

	if(monitorModeFlag == MONITOR){			/* 20090704 */
		return(0);
	}

/* 20081003 */
	GetGroopSema();
	if(gDeviceCnt == 0){	/* No Monitor */
		ResetGroopSema();
		return(0);
	}
	/* Bit Monitor Read */
/* 20081003 */
	block= MAX_BLOC_NO;
	sidx= 0;
	if(gDeviceCntBit > 0){
		devcnt= 0;							/* 20081107 */
		while(devcnt < gDeviceCntBit){		/* 20081107 */
			B_gstrcpy((char*)&PlcSendBuff[5],CommTbl[7].strData);
	/* 20081003 */
			B_Bin2Hex(block--,2,buff);			/* Block No */
			B_gmemcpy((char*)&PlcSendBuff[7],buff,2);
			SendRecCnt= 4;
			ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&SendRecCnt,0,DstStationNo,0);
			if(ret != 0){				/* 20081107 */
				ResetGroopSema();		/* 20081107 */
				return(ret);			/* 20081107 */
			}
			if(SendRecCnt > 5){			/* 2009.08.26 add */
				dCnt= B_Hex2nBin((char*)&PlcRecBuff[10],2);
				if(dCnt == 0){			/* 2009.08.26 add */
					ResetGroopSema();	/* 2009.08.26 add */
					return(-1);			/* 2009.08.26 add */
				}else{					/* 2009.08.26 add */
					for(i= 0; i < dCnt; i++){
						*gDevTempAddr[sidx++]= PlcRecBuff[i+12] == '0' ? 0 : 1;  
						devcnt++;						/* 20081107 */
						if(devcnt == gDeviceCntBit){	/* 20081107 */
							break;						/* 20081107 */
						}								/* 20081107 */
					}
				}						/* 2009.08.26 add */
			}else{						/* 2009.08.26 add */
				ResetGroopSema();		/* 2009.08.26 add */
				return(-1);				/* 2009.08.26 add */
			}							/* 2009.08.26 add */
		}
	}
	/* Word Monitor Read */
	if(gDeviceCntWord > 0){
		devcnt= 0;							/* 20081107 */
		while(devcnt < gDeviceCntWord){		/* 20081107 */
			B_gstrcpy((char*)&PlcSendBuff[5],CommTbl[7].strData);
	/* 20081003 */
			B_Bin2Hex(block--,2,buff);			/* Block No */
			B_gmemcpy((char*)&PlcSendBuff[7],buff,2);
			SendRecCnt= 4;
			ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&SendRecCnt,0,DstStationNo,0);
			if(ret != 0){					/* 20081107 */
				ResetGroopSema();			/* 20081107 */
				return(ret);				/* 20081107 */
			}
			if(SendRecCnt > 5){			/* 2009.08.26 add */

				dCnt= B_Hex2nBin((char*)&PlcRecBuff[10],2);
				if(dCnt == 0){			/* 2009.08.26 add */
					ResetGroopSema();	/* 2009.08.26 add */
					return(-1);			/* 2009.08.26 add */
				}else{					/* 2009.08.26 add */
					for(i= 0; i < dCnt; i++){
	#ifdef SH_CPU
						*(gDevTempAddr[sidx]+ 1) = B_Hex2Bin((char *)&PlcRecBuff[i*4+12]);
						*(gDevTempAddr[sidx++]+ 0) = B_Hex2Bin((char *)&PlcRecBuff[i*4+14]);
	#endif
	#ifdef ARM_CPU
						*(gDevTempAddr[sidx]+ 0) = B_Hex2Bin((char *)&PlcRecBuff[i*4+12]);
						*(gDevTempAddr[sidx++]+ 1) = B_Hex2Bin((char *)&PlcRecBuff[i*4+14]);
	#endif
						devcnt++;						/* 20081107 */
						if(devcnt == gDeviceCntWord){	/* 20081107 */
							break;						/* 20081107 */
						}								/* 20081107 */
					}
				}
			}else{						/* 2009.08.26 add */
				ResetGroopSema();		/* 2009.08.26 add */
				return(-1);				/* 2009.08.26 add */
			}							/* 2009.08.26 add */
		}
	}
/* 20081003 */
	ResetGroopSema();

	return(ret);
}
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/********************************************/
/*	Thru Monitor Proc						*/
/********************************************/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret= -1;

	if(*Sio1RecCnt < PLC_BUF_MAX){
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
	}
	switch(data){
	case STX:
		if(*CommMode == 1){
			*CommMode = 2;
		}
		break;
	case ETB:
	case ETX:
		if(*CommMode == 2){
			*CommMode = 3;
		}
		break;
	case ENQ:
	case ACK:
	case NAK:
		ret= 0;
		break;
	default:
		switch(*CommMode){
		case 0:				/* Start */
			*CommMode = 1;
			*Sio1RecCnt= 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			break;
		case 1:				/* kyokuban+STX */
			break;
		case 2:				/* Data */
			break;
		case 3:		/* BCC1 */
			*CommMode = 4;
			break;
		case 4:		/* BCC2 */
			*CommMode = 0;
			ret = 0;	
			break;
		}
		break;
	}
	return(ret);
}

/************************************/
/*	��M�R?���h?�F�b�N	        */
/************************************/
int	PLCPcMonitorCheck(char *buff,char *oBuff,int *Cnt,int PlcConnectFlag,int PlcType)
{
	int		i;
	int		ret= -1;

	for(i= 0; i < TBQ(CommTbl); i++){
		if(B_gstrncmp(buff,CommTbl[i].strData,2) == 0){
			ret= i;
			break;
		}
	}
	return(ret);

}

/****************************************************************/
/*	*/
int	CheckEtbEtx(char* buff)
{
	int	i;

	if(buff[4] != STX){		return(0);	}
	for(i= 5; i < 512+32; i++){
		if(buff[i] == ETX){	return(0);	}
		if(buff[i] == ETB){	return(1);	}
	}
	return(0);
}
/************************************/
/*	ThruMode Proc			        */
/************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	GetGroopSema();
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendThruePLC(2,*OutCnt,OutBuff,3000); /*20090706*/
	ResetGroopSema();

#ifdef	OLDSOURCE

	int	ret= -1;
	int	status;
	int	sendMode;

	/* Cnnect Check */
	if(PlcConnectFlag == 0){
		B_gmemcpy(&OutBuff[0],&CommBuff[2],2);
		B_gmemcpy(&OutBuff[2],&CommBuff[0],2);
		OutBuff[4]= NAK;
		B_SendPC2PLCData(0,5,OutBuff,2000);
		return;
	}
	if(GroopingFlag == 0){	GetGroopSema();	}
	sendMode= 2;
	if(*RecCommCnt > 5){
		if(CommBuff[*RecCommCnt-3] == ETX){
			if(B_gstrncmp(&CommBuff[5],"RP",2) == 0){
				status= 1;								/* GP Start */
				GroopingFlag= 2;						/* Upload */
			}else{
				status= 0;	/* GP Start */
			}
		}else{
			status= 1;								/* GP Start */
			GroopingFlag= 1;						/* DownLoad */
		}
	}else{
		status= 0;	/* GP Start */
		if((CommBuff[4] == ACK) || (CommBuff[4] == NAK)){
			if(GroopingFlag != 2){
				sendMode= 0;
			}else{
				status= 1;								/* GP Start */
			}
		}
	}
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	ret= B_SendThruePLC(sendMode,*OutCnt,OutBuff,2000);
	if(ret == -1){
		status= 0;
	}else{
		if(GroopingFlag == 3){						/* Upload End */
			status= 0;
		}
	}
	if(status == 0){
		ResetGroopSema();
		GroopingFlag= 0;
	}
	if((GroopingFlag == 2) && (ret == 0)){	/* Up Load Command */
		if(CheckEtbEtx(OutBuff) == 0){	/* ETX */
			GroopingFlag= 3;						/* Upload End */
		}
	}
#endif

}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}

/*++++++++++++++++++++++++++++++++++++*/
#endif

/* PLCTYPE_CH1������ ����ϴ� �Լ� �� */
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH2������ ����ϴ� �Լ� ���� */ 

#ifdef	PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif

#include	"hook_aplplc.h"

/****************************** END **********************/
