int iCommentPointOnOff(short iNum);
void	vCommentMenu(int* iScreenNo);
void vCommentListDisplay(int inowNum, char *cDataBuffer, int *iColor, int *iLen);
