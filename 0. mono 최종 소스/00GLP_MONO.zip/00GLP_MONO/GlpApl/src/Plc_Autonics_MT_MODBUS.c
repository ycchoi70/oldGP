/*****************************************************************************************/
/*	PLC ����M �v���O��?(LG-K3P-07AS)		  		*/
/*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		 		*/
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  		*/
/*		LG 80S			*/
/*	2006.09.25 		*/
/*      �����͹� ���ø� ������ ���� ver 2.6�� �ϰ� ����	  		*/
/*  2007.01.30 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����			*/  
/*  2007.10.08 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����			*/
/*****************************************************************************************/

/**********************************************************/
/*	2006.05.09 NEW GP									*/
/**********************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include	"hook_plcapl.h"

/*****************************************************************************************/
/* PLCTYPE_CH1, PLCTYPE_CH2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V3.2M"
/*****************************************************************************************/


#define	MAX_BITCNT	16
#define	MAX_WORDCNT	60
#define	MAX_PBITCNT	16
#define	MAX_PWORDCNT	10
#define	MAX_UR_CNT	26
#define	MAX_WORD_CONT_CNT	4
#define	MAX_BIT_CONT_CNT	4

#define	MAX_RTY_COUNT	3

#ifdef	SH_CPU
static	int	GroopSema;			/* Grooping Semafo */
static	int	GroopingFlag;		/* Grooping ON */
static	int	LgCommSeq;
static	int	LgConnectFlag;		/* Write Record Count */
#endif
#ifdef	ARM_CPU
/* PLC COmBUFF �� ������ ����. ARM�ϰ�� ��ũ�� ��巹���� ���ϱ� ������ ���� ������ ��� */
#endif




/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/****************************************************************************************************/
/* LG-MK200 ���� �������� �ҽ� ���� */
/****************************************************************************************************/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH1, PLCTYPE_CH2 ���� ����ϴ� �Լ� ���� */ 

static	const	DEV_TBL bPLCDeviceTbl[16] = {
	{"P" ,0x5c00,2},
	{"M" ,0x5d00,3},
	{"K" ,0x6000,2},
	{"F" ,0x6300,2},
	{"L" ,0x5f00,2},
	{"T" ,0x6100,3},
	{"C" ,0x6200,3},
/*	{"S" ,0x6400,5},*/
	{"GB" ,    0,4},
};
static	const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"P" ,0x5c00,2},
	{"M" ,0x5d00,3},
	{"K" ,0x6000,2},
	{"F" ,0x6300,2},
	{"L" ,0x5f00,2},
	{"D" ,0x0000,4},
	{"T" ,0x5000,3},
	{"C" ,0x5200,3},
	{"S" ,0x6400,2},
	{"GD" ,    0,4},
};
/* ���� ���̺� */
/* SH �����Ϸ��� const �� �ٿ��� �ҿ����� ��� ���� ���� */  
#ifdef	SH_CPU
static	const	char	*LgComm[]={
	"uW","uR","uE","uA"
};
#endif
/* ARM �����Ϸ��� const�� �ٿ��� ������ ������ ����Ÿ����� ����ϱ� ������, ������ ������ ������ �����ؼ� �ҿ����� ����ϵ��� �� */  
/* ����Ÿ ������ ����ϸ� �����ϱ����� �ʱⰪ�� ������ �־���Ѵ�. ������ ���������� �ʱ� ������ ���� ������ �Ұ��� */
#ifdef	ARM_CPU
static	const	PLC_CONST	LgComm[4]={
	{"uW",1},
	{"uR",1},
	{"uE",1},
	{"uA",1}
};
#endif
/************************************/
/* ��M�v���g�R��					*/
/************************************/
/************************************************/
/*	Func:C_SendRecPLC							*/
/*		PLC�ɑ��M����							*/
/*	IN	int mode:���M��?�h						*/
/*			0:���M�̂�,1:���M��ACK��M,2:���M��f??��M,3:���M��ACK+�f??��M */
/*		unsigned char *RecData:��M�f??�i?�̈� */
/*		int *Cnt:��M�J�E���g					*/
/*		int rmode:��M��?�h					*/
/*			0:��M�f??�����̂܂�,1:��M�f??���o�C�i��?�ɕϊ� */
/*		int sCnt:���M������						*/
/*		char *sBuff:���M�o�b�t??				*/
/*		int TimeOut:��M�҂�?�C?�A�E�g�i�����j*/
/*	Ret	0:OK,-1:Error							*/
/************************************************/
/*	Func:C_SendRecPLC							*/
/*      PLC�� �۽�								*/
/*  IN	int mode: �۽� ���						*/
/*			0: �۽Ÿ�, 1:�۽��� ACK����, 2:�۽��� ����Ÿ ����, 3:�۽��� ACK + ����Ÿ ���� */
/*      unsigned char *RecData:���� ����Ÿ ���� */
/*		int *Cnt:���� ���ڼ� 					*/
/*		int rmode:���� ���					*/
/*			0:���� ����Ÿ �״��,1:���ŵ���Ÿ�� ���̳ʸ��� ��ȯ  */
/*		int sCnt:�۽� ���ڼ�						*/
/*		char *sBuff:�۽� ����				*/
/*		int TimeOut:�۽��� ���Ŵ��ð� (ms) */
/*	Ret	0:OK,-1:Error							*/
/************************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef	PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
/************************************************/
/*	Func:C_SendPC2PLCData						*/
/*		PLC���ɑ��M����							*/
/*	IN	int mode:���M��?�h						*/
/*			0:���M�̂�,1:���M��ACK��M,2:���M��f??��M,3:���M��ACK+�f??��M */
/*		int cnt:���M�J�E���g					*/
/*		char *buff:���M�o�b�t??				*/
/*		int TimeOut:��M�҂�?�C?�A�E�g�i�����j*/
/*	Ret	0:OK,-1:Error							*/
/************************************************/
/*	Func:C_SendPC2PLCData						*/
/*      PLC�� �۽�								*/
/*  IN	int mode: �۽� ���						*/
/*			0: �۽Ÿ�, 1:�۽��� ACK����, 2:�۽��� ����Ÿ ����, 3:�۽��� ACK + ����Ÿ ���� */
/*		int Cnt:�۽� ���ڼ� 					*/
/*		char *buff:�۽� ����				*/
/*			0:���� ����Ÿ �״��,1:���ŵ���Ÿ�� ���̳ʸ��� ��ȯ  */
/*		int TimeOut:�۽��� ���Ŵ��ð� (ms) */
/*	Ret	0:OK,-1:Error							*/
/************************************************/
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/************************************************/
/*	Func:C_Get_Ms_Sel							*/
/*		Master,Slave���̎��o��				*/
/*	Ret											*/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
/************************************************/
/*	Func:C_Get_Ms_Sel							*/
/*		Master,Slave �� ��ż��� ��ġ �����б�  				*/
/*	Ret											*/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
/************************************************/
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
/************************************************/
/*	Func:C_GetMonBaudrate						*/
/*		Boadrate���̎��o��					*/
/*	In	int *Speed:Speed�i?�̈�				*/
/*		int *DataBit;Data Bit�i?�̈�			*/
/*		int *Parity:Parity�i?�̈�				*/
/*	Ret	:�Ȃ�									*/
/************************************************/
/*	Func:C_GetMonBaudrate						*/
/*		Boadrate ���� �б�  					*/
/*	In	int *Speed:Speed 				*/
/*		int *DataBit;Data Bit			*/
/*		int *Parity:Parity				*/
/*	Ret	:����									*/
/************************************************/
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_38400;
	*DataBit= RS_DATA8;
	*Parity= ((RS_XONOFF << 16) |(RS_STOP01 << 8) | (RS_NONE << 0));		/* 20090527 */	
}
/************************************************/
/*	Func:GetGroopSema							*/
/*		PLC Semafor(�󂭂܂ő҂�)				*/
/*	Ret	:�Ȃ�									*/
/************************************************/
/*	Func:GetGroopSema							*/
/*		PLC Semafor : �⺻������ �浹�� �Ͼ�� �ʵ��� �ϴ� ��� 				*/
/*           ����͸� ����Ҷ��� ��ȿ, CH1���� �۽��� �������Ʈ�� ��ȣ�� ����ö� ���� PLC�� ������ �ְ� �ޱ� ���ؼ� �켱 ó������ ����� �Ϸ�ɶ����� ��� */
/*	Ret	:����									*/
/************************************************/
static	void	GetGroopSema(void)
{
	unsigned int	NowTime;
	unsigned int	StartTime;

	if(GroopSema == 0){		/* Grooping Sema */
	}else{
		StartTime= B_GetNowTime();
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
			NowTime= B_GetNowTime();
			if((StartTime+ 3000) < NowTime){
				GroopSema= 0;
			}
			B_Delay(10);
		}
	}
	GroopSema++;
}

/************************************************/
/*	Func:GetGroopSema							*/
/*		PLC Semafor Crear						*/
/*	Ret	:����									*/
/************************************************/
static	void	ResetGroopSema(void)
{
	GroopSema= 0;
}
/****************************************************/
/*   FUNC  : C_PlcReadProc							*/
/*			PLC Recieve Handler						*/
/*	In	unsigned char data:��M�f??				*/
/*		int *CommMode:��M��?�h�i?�̈�			*/
/*		int *RecCnt:��M�J�E���g�i?�̈�			*/
/*		unsigned char *RecBuff:��M�f??�i?�̈�	*/
/*	Ret   :0:��M�����i��M?�X�N���N������j-1:��M���p������	*/
/*   DATE  : 2003.5.25	                            */
/****************************************************/
/*   FUNC  : C_PlcReadProc							*/
/*			PLC Recieve Handler						*/
/*	In	unsigned char data: �ѹ��� ���ŵ���Ÿ 			*/
/*		int *CommMode:���Ÿ��			*/
/*		int *RecCnt:����ī��Ʈ			*/
/*		unsigned char *RecBuff:���ŵ���Ÿ ���� */
/*	Ret   :0:���ſϷ�(����Ÿ��ũ �⵿), -1:��� ������	*/
/*   DATE  : 2003.5.25	                            */
/****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(data){
	case STX:
	case ENQ:
	case ACK:
	case NAK:
		*RecCnt= 0;			/* ?���X??�g */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 1;
		break;
	default:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		switch(*CommMode){
		case 1:
			if((data == EOT) || (data == ETX)){
				*CommMode = 0;
				ret= 0;
			}
			break;
		}
		break;
	}
	return(ret);
}
/****************************************************/
/*   FUNC  : SetPLCBCC								*/
/*			BCC�쐬									*/
/*			STX,ETX,BCC��t������					*/
/*	In	char *buff:�f??�i?�̈�					*/
/*		int cnt:�i?�f??��						*/
/*	Ret   :�쐬��̎��ۂ̕�����						*/
/*   DATE  : 2003.5.25	                            */
/****************************************************/
/*   FUNC  : SetPLCBCC								*/
/*			BCC �ۼ�									*/
/*			STX,ETX,BCC �� �ΰ��Ѵ�.				*/
/*	In	char *buff:����Ÿ				*/
/*		int cnt:����Ÿ ����					*/
/*	Ret   :�ۼ��� ���� ����Ÿ��						*/
/*   DATE  : 2003.5.25	                            */
/****************************************************/
static	int SetPLCBCC(char *buff,int cnt)
{
	int		i;
	unsigned char bcc;

	buff[0] = STX;
	bcc = 0;
	for(i = 0; i < cnt; i++){
		bcc += buff[i+1];
	}
	/*sprintf((char *)&OutBuf[cnt+1],"%02X",bcc&0x00ff);*/
	B_Bin2Hex(bcc&0x00ff,2,(char *)&buff[cnt+1]);
	buff[cnt+3] = ETX;
	return(cnt + 4);
}
/****************************************************/
/*   FUNC  : SetPLCBCCACK							*/
/*			BCC�쐬									*/
/*			�擪�Ɏw�肵��������t������			*/
/*	In	unsigned char code:�擪�̕���				*/
/*		char *buff:�f??�i?�̈�					*/
/*		int cnt:�i?�f??��						*/
/*	Ret   :�쐬��̎��ۂ̕�����						*/
/*   DATE  : 2003.5.25	                            */
/****************************************************/
/*   FUNC  : SetPLCBCCACK							*/
/*			BCC �ۼ�									*/
/*			���ο� ������ ���ڸ� �ΰ��Ѵ�.			*/
/*	In	unsigned char code:���� ����				*/
/*		char *buff:����Ÿ					*/
/*		int cnt:����Ÿ ����						*/
/*	Ret   :�ۼ����� ���� ���ڼ�						*/
/*   DATE  : 2003.5.25	                            */
/****************************************************/
static	int SetPLCBCCACK(unsigned char code,char *buff,int cnt)
{
	int		i;
	unsigned char bcc;

	buff[0] = code;
	bcc = 0;
	for(i = 0; i < cnt; i++){
		bcc += buff[i+1];
	}
	/*sprintf((char *)&OutBuf[cnt+1],"%02X",bcc&0x00ff);*/
	B_Bin2Hex(bcc&0x00ff,2,(char *)&buff[cnt+1]);
	buff[cnt+3] = EOT;
	return(cnt + 4);
}
/************************************************/
/*	Func:SendRecPLCWithBCC						*/
/*		���M�f??��BCC��t����PLC�ɑ��M����	*/
/*		��M��BCC?�F�b�N���A���g���C�R��		*/
/*	IN	int mode:���M��?�h						*/
/*			0:���M�̂�,1:���M��ACK��M,2:���M��f??��M,3:���M��ACK+�f??��M */
/*		char *combuf:���M�o�b�t??				*/
/*		unsigned char *RecData:��M�f??�i?�̈� */
/*		int *Cnt:��M�J�E���g					*/
/*		int rmode:��M��?�h					*/
/*			0:��M�f??�����̂܂�,1:��M�f??���o�C�i��?�ɕϊ� */
/*	Ret	0:OK,-1:Error							*/
/************************************************/
/*	Func:SendRecPLCWithBCC						*/
/*		�۽ŵ���Ÿ�� BCC �ΰ��Ͽ� PLC�� �۽� 	*/
/*		������ BCC üũ�� Retry 		*/
/*  IN	int mode: �۽� ���						*/
/*			0: �۽Ÿ�, 1:�۽��� ACK����, 2:�۽��� ����Ÿ ����, 3:�۽��� ACK + ����Ÿ ���� */
/*		char *combuf:�۽� ����				*/
/*		unsigned char *RecData:���� ����Ÿ ���� */
/*		int *Cnt:���� ���ڼ�					*/
/*		int rmode:���� ���					*/
/*			0:���� ����Ÿ �״��,1:���ŵ���Ÿ�� ���̳ʸ��� ��ȯ��  */
/*	Ret	0:OK,-1:Error							*/
/************************************************/
static	int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *RecData,int *Cnt,int rmode)
{
	int		i;
	int		ret;
	int		rty_cnt;
	unsigned char bcc;
	unsigned char bcc1;
	int		SendCnt;

/*	PlcCommCnt= SetPLCBCC((char *)combuf,gstrlen(combuf),PlcSendBuff);*/
	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen((char *)&combuf[1]));
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
/*		ret= B_SendRecPLC(mode,rData,Cnt,rmode);*/
		ret= C_SendRecPLC(mode,RecData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		if(ret == 0){
			if(mode <= 1){
			}
			else{
				/* DATA->EOT(SUM) */
				bcc= 0;
				for(i = 0; i < *Cnt-4; i++){
					bcc += RecData[i+1];
				}
				bcc1= (unsigned char)B_Hex2Bin((char *)&RecData[*Cnt-3]);
				if(bcc != bcc1){
					ret= -1;
				}
			}
		}
		if(ret == OK){
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}
	return(ret);
}
/************************************************/
/*	Func:SendRecPLCWithBCCCont					*/
/*		���M�f??��BCC��t����PLC�ɑ��M����	*/
/*	IN	int mode:���M��?�h						*/
/*			0:���M�̂�,1:���M��ACK��M,2:���M��f??��M,3:���M��ACK+�f??��M */
/*		char *combuf:���M�o�b�t??				*/
/*		unsigned char *RecData:��M�f??�i?�̈� */
/*		int *Cnt:��M�J�E���g					*/
/*		int rmode:��M��?�h					*/
/*			0:��M�f??�����̂܂�,1:��M�f??���o�C�i��?�ɕϊ� */
/*	Ret	0:OK,-1:Error							*/
/************************************************/
/*	Func:SendRecPLCWithBCCCont					*/
/*		�۽ŵ���Ÿ�� BCC �ΰ��Ͽ� PLC�� �۽� 	*/
/*  IN	int mode: �۽� ���						*/
/*			0: �۽Ÿ�, 1:�۽��� ACK����, 2:�۽��� ����Ÿ ����, 3:�۽��� ACK + ����Ÿ ���� */
/*		char *combuf:�۽� ����				*/
/*		unsigned char *RecData:���� ����Ÿ ���� */
/*		int *Cnt:���� ���ڼ�					*/
/*		int rmode:���� ���					*/
/*			0:���� ����Ÿ �״��,1:���ŵ���Ÿ�� ���̳ʸ��� ��ȯ��  */
/*	Ret	0:OK,-1:Error							*/
/************************************************/
static	int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *RecData,int *Cnt,int rmode)
{
	int		ret;
	int		SendCnt;

/*	PlcCommCnt= SetPLCBCC((char *)combuf,gstrlen(combuf),PlcSendBuff);*/
/*	ret= B_SendRecPLC(mode,RecData,Cnt,rmode);*/
	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen((char *)&combuf[1]));
	ret= C_SendRecPLC(mode,RecData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	return(ret);
}
/************************************************/
/*	Func:C_Connection							*/
/*		PLC�̐ڑ�?�F�b�N���s��					*/
/*	IN	int *PlcType:���g�p						*/
/*		int iConnect:PLC�ڑ����				*/
/*			0:RS-422,1:RS-232C					*/
/*	Ret	0:Error,1:Connect OK					*/
/************************************************/
/*	Func:C_Connection							*/
/*		PLC ���� üũ					*/
/*	IN	int *PlcType:�̻��						*/
/*		int iConnect:PLC ���� ����				*/
/*			0:RS-422,1:RS-232C					*/
/*	Ret	0:Error,1:Connect OK					*/
/************************************************/
static	int	C_Connection( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;
	int		Speed;
	int		DataBit;
	int		Parity;
	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE); */
		}else{						/* RS-422 */
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE); */
		}
#ifdef	WIN32
		while(1){
			if(SioPLCOpenFlag == 0){
				break;
			}
			B_Delay(10);
		}
#endif
		B_Delay(100);
	}
	/* PLC Connect Check */
/*	ret= SendRecPLCWithBCCCont(2,"j",GrpPLCcombuf,&Cnt,0);*/
	PlcSendBuff[1]= 'j';
	PlcSendBuff[2]= 0;
	ret= SendRecPLCWithBCCCont(2,(char *)PlcSendBuff,PlcRecBuff,&Cnt,0);
/*	if(gstrncmp((char *)GrpPLCcombuf,"\x06j",2) != 0){*/
	if(PlcRecBuff[0] != 0x06){
		ret= -1;
	}

	ResetGroopSema();
	LgCommSeq= 0;
	LgConnectFlag= 0;

	PlcThruMonCnt= 0;		/* Thru Mon 070214 */
	PlcThruRecCnt= 0;		/* Thru Mon 070214 */
	B_gmemset((char *)PlcThruRecDataCnt,0,sizeof(PlcThruRecDataCnt));
	if(ret < 0){
		return(0);
	}
	ret= 1;
	LgConnectFlag= 1;
	return(ret);
}
/************************************************/
/*	Func:SetPLCDevAddr							*/
/*		PLC�f�o�C�X���A�h���X���o��			*/
/*	IN	int *PLCByteCnt:Bit Device Count Addr	*/
/*		int *PLCWordCnt:Word Device Count Addr	*/
/*		DEV_PC_TBL **ByteTbl:Bit Device Table Addr	*/
/*		DEV_PC_TBL **WordTbl:Word Device Table Addr	*/
/*		PLCIndex:Code2Index Table Addr			*/
/*	Ret	�Ȃ�									*/
/************************************************/
/*	Func:SetPLCDevAddr							*/
/*		PLC ����̽� �������� ��巹���� ���			*/
/*	IN	int *PLCByteCnt:Bit Device Count Addr	*/
/*		int *PLCWordCnt:Word Device Count Addr	*/
/*		DEV_PC_TBL **ByteTbl:Bit Device Table Addr	*/
/*		DEV_PC_TBL **WordTbl:Word Device Table Addr	*/
/*		PLCIndex:Code2Index Table Addr			*/
/*	Ret	����									*/
/************************************************/

static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif

#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif
}
/************************************************/
/*	Func:C_GetDevNamePLC						*/
/*		Device Name���o��						*/
/*	IN	int bFlag:0:Bit1:Word					*/
/*		unsigned char *src:Device Code Addr		*/
/*		char *obj:Device Name Addr				*/
/*		int *DevInfo:Device Info Addr			*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:C_GetDevNamePLC						*/
/*		Device Name�� ���						*/
/*	IN	int bFlag:0:Bit1:Word					*/
/*		unsigned char *src:Device Code Addr		*/
/*		char *obj:Device Name Addr				*/
/*		int *DevInfo:Device Info Addr			*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/************************************************/
/*	Func:MakePLCDevAddress						*/
/*		Make PLC ABS ADDRESS					*/
/*	IN	int mode:0:Bit1:Word					*/
/*		char *pDevice:Device Code �i? Addr		*/
/*		int Address:User Device Addr			*/
/*		int *DevAddr:�ʐMDevice �i? Addr		*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:MakePLCDevAddress						*/
/*		Make PLC ABS ADDRESS					*/
/*	IN	int mode:0:Bit1:Word					*/
/*		char *pDevice:Device Code ���� Addr		*/
/*		int Address:User Device Addr			*/
/*		int *DevAddr:��� Device ���� Addr		*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i,j;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(bPLCDeviceTbl[i].Device[0] == Device[0]){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				if(DeviceFlag == 5){		/* S */
					*DevAddr = OffSet+ (Address/ 100) * 2;
				}else{
					*DevAddr = OffSet+ (Address/ 16) * 2;
					ret = Address % 16;
					BitAndData = 1;
					for(j = 0; j < ret; j++){
						BitAndData <<= 1;
					}
					ret += (sCnt- 1);
					ret = ret / 8 + 1;
					if((ret % 2) != 0){
						ret++;
					}
					BitRecCnt = ret;
				}
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(wPLCDeviceTbl[i].Device[0] == Device[0]){
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address* 2;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/************************************************/
/*	Func:MakePLCReadData						*/
/*		Make Read Device						*/
/*	IN	int mode:0:Bit1:Word					*/
/*		char *pDevice:Device Code �i? Addr		*/
/*		int Address:Device Address				*/
/*		char *combuff:���M�f??�i? Addr		*/
/*		int sCnt:Device Count					*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:MakePLCReadData						*/
/*		Make Read Device						*/
/*	IN	int mode:0:Bit1:Word					*/
/*		char *pDevice:Device Code ���� Addr		*/
/*		int Address:Device Address				*/
/*		char *combuff:�۽ŵ���Ÿ ���� Addr		*/
/*		int sCnt:Device Count					*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int		DevAddr;
	char	buff[32];
	char	abuff[4+1];

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		B_Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		if(mode == 0){		/* BIT */
			/*sprintf(combuff,"rM%s00%02X",abuff,BitRecCnt);*/
			B_gstrcpy(combuff,"rM");
			B_gstrcat(combuff,abuff);
			B_gstrcat(combuff,"00");
			B_Bin2Hex(BitRecCnt,2,abuff);
			B_gstrcat(combuff,abuff);
		}else{				/* WORD */
			/*sprintf(combuff,"rM%s00%02X",abuff,sCnt);*/
			B_gstrcpy(combuff,"rM");
			B_gstrcat(combuff,abuff);
			B_gstrcat(combuff,"00");
			B_Bin2Hex(sCnt,2,abuff);
			B_gstrcat(combuff,abuff);
		}
	}
	return(ret);
}
/************************************************/
/*	Func:BitReadProc							*/
/*		Bit Read Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:�ʐM�p��M�o�b�t??Addr	*/
/*		int PlcType:���g�p						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:BitReadProc							*/
/*		Bit Read Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:��ſ� ���� ���� Addr	*/
/*		int PlcType:�̻��						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	BitReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j;
	int		Cnt;
	int		rCnt;
	int		rdata;
	unsigned char	*SaveAddr;
	int		dCnt;
	int		Address;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_BITCNT){	dCnt -= MAX_BITCNT;	mp->mext= MAX_BITCNT;	}
		else{					mp->mext= dCnt;		dCnt = 0;				}
		ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],mp->mext);
		if(ret != 0){				break;		}
		Cnt = mp->mext;
		rCnt = BitRecCnt;
		SaveAddr = (unsigned char *)mp->mptr;
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0);
		if(ret != 0){				ret= -1;	break;	}
		if(rDataFx[0] != 0x06){		ret= -1;	break;	}
		for(i = 0; i < rCnt; i++){
			rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+ 2]);
		}
		rdata= rDataFx[0] + (rDataFx[1] << 8);
		for(i = 0,j= 1; i < Cnt; i++){
			if(rdata & BitAndData){	*(unsigned char *)SaveAddr++ = 1;	}
			else{					*(unsigned char *)SaveAddr++ = 0;	}
			BitAndData <<= 1;
			if(BitAndData > 0x8000){
				BitAndData = 1;
				rdata= rDataFx[j*2] + (rDataFx[j*2+1] << 8);
				j++;
			}
		}
		if(dCnt == 0){			break;		}
		Address += MAX_BITCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_BITCNT);
	}
	return(ret);
}
/************************************************/
/*	Func:WordReadProc							*/
/*		Word Read Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:�ʐM�p��M�o�b�t??Addr	*/
/*		int PlcType:���g�p						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:WordReadProc							*/
/*		Word Read Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:��ſ� ���� ���� Addr	*/
/*		int PlcType:�̻��						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	WordReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt;
	int		rCnt;
	unsigned char	*SaveAddr;
	int		dCnt;
	int		Address;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_WORDCNT){	dCnt -= MAX_WORDCNT;	mp->mext= MAX_WORDCNT;	}
		else{					mp->mext= dCnt;			dCnt = 0;				}
		ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],mp->mext*2);
		if(ret != 0){					break;			}
		Cnt = mp->mext* 2;
		rCnt = mp->mext* 2;
		SaveAddr = (unsigned char *)mp->mptr;
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0);
		if(ret != 0){			ret= -1;	break;		}
		if(rDataFx[0] != 0x06){	ret= -1;	break;		}
		for(i = 0; i < rCnt; i++){
			rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+ 2]);
		}
		for(i = 0; i < Cnt/2; i++){
#ifdef	SH_CPU
			*(unsigned char *)SaveAddr++ = rDataFx[i*2];
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
#endif
#ifdef	ARM_CPU
#ifdef	WIN32
			*(unsigned char *)SaveAddr++ = rDataFx[i*2];
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
#else
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
			*(unsigned char *)SaveAddr++ = rDataFx[i*2];
#endif
#endif
		}
		if(dCnt == 0){						break;		}
		Address += MAX_WORDCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
	}
	return(ret);
}
/************************************************/
/*	Func:C_PLCCommRead							*/
/*		Device Read Func						*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:�ʐM�p��M�o�b�t??Addr	*/
/*		int PlcType:���g�p						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:C_PLCCommRead							*/
/*		Device Read Func						*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:��ſ� ���� ���� Addr	*/
/*		int PlcType:�̻��						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret= 0;

	GetGroopSema();			/* For Monitor */
	switch(mp->mpec){
	case PLC_BIT:		ret= BitReadProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordReadProc(mp,rDataFx,PlcType);		break;
	}
	ResetGroopSema();
	return(ret);
}
/************************************************/
/*	Func:MakePLCWriteData						*/
/*		Make Write Device						*/
/*	IN	int mode:0:Bit1:Word					*/
/*		char *pDevice:Device Code �i? Addr		*/
/*		int Address:Device Address				*/
/*		int Cnt:Device Count					*/
/*		char *combuff:���M�f??�i? Addr		*/
/*		char *data:Data �i? Addr				*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:MakePLCWriteData						*/
/*		Make Write Device						*/
/*	IN	int mode:0:Bit1:Word					*/
/*		char *pDevice:Device Code ���� Addr		*/
/*		int Address:Device Address				*/
/*		int Cnt:Device Count					*/
/*		char *combuff:�۽� ����Ÿ ����  Addr		*/
/*		char *data:Data ���� Addr				*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	int		DevAddr;
	char	buff[32];
	char	abuff[4+1];

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		B_Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		if(mode == 0){		/* BIT */
			if(*data == 0){			/* OFF */
				/*sprintf(combuff,"nM%s00",abuff);*/
				B_gstrcpy(combuff,"nM");
				B_gstrcat(combuff,abuff);
				B_gstrcat(combuff,"00");
				/*sprintf(buff,"%04X",(~BitAndData & 0x0000ffff));*/
				B_Bin2Hex((~BitAndData & 0x0000ffff),4,buff);
				abuff[0]= buff[2];
				abuff[1]= buff[3];
				abuff[2]= buff[0];
				abuff[3]= buff[1];
				abuff[4]= 0;
				B_gstrcat(combuff,abuff);
			}else{
				/*sprintf(combuff,"oM%s00",abuff);*/
				B_gstrcpy(combuff,"oM");
				B_gstrcat(combuff,abuff);
				B_gstrcat(combuff,"00");
				/*sprintf(buff,"%04X",BitAndData);*/
				B_Bin2Hex(BitAndData,4,buff);
				abuff[0]= buff[2];
				abuff[1]= buff[3];
				abuff[2]= buff[0];
				abuff[3]= buff[1];
				abuff[4]= 0;
				B_gstrcat(combuff,abuff);
			}
		}else{		/* WORD */
			/*sprintf(combuff,"wM%s00%02d",abuff,Cnt*2);*/
			B_gstrcpy(combuff,"wM");
			B_gstrcat(combuff,abuff);
			B_gstrcat(combuff,"00");
			B_Bin2Hex(Cnt*2,2,buff);
			B_gstrcat(combuff,buff);
#ifdef	SH_CPU
			for(i= 0; i < Cnt*2; i++){
				/*sprintf(buff,"%02X",data[i] & 0xff);*/
				B_Bin2Hex(data[i] & 0xff,2,buff);
				B_gstrcat(combuff,buff);
			}
#endif
#ifdef	ARM_CPU
			for(i= 0; i < Cnt; i++){
				/*sprintf(buff,"%02X",data[i] & 0xff);*/
				B_Bin2Hex(data[i*2+1] & 0xff,2,buff);
				B_gstrcat(combuff,buff);
				B_Bin2Hex(data[i*2] & 0xff,2,buff);
				B_gstrcat(combuff,buff);
			}
#endif
		}
	}
	return(ret);
}
/************************************************/
/*	Func:BitWriteProc							*/
/*		Bit Write Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:�ʐM�p��M�o�b�t??Addr	*/
/*		int PlcType:���g�p						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:BitWriteProc							*/
/*		Bit Write Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:��ſ� ���� ���� Addr	*/
/*		int PlcType:�̻��						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	BitWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt;
	int		Address;
	char	*dataAddr;

	Address= mp->mpar;
	dataAddr= (char *)mp->mptr;
	for(i= 0; i < (signed)mp->mext; i++){
		ret = MakePLCWriteData(0,(char *)mp->mbuf,Address,1,(char *)&PlcSendBuff[1],dataAddr);
		if(ret != 0){		ret= -1;		break;		}
		ret= SendRecPLCWithBCC(2,(char*)PlcSendBuff,rDataFx,&Cnt,0);
		if(ret != 0){		ret= -1;		break;		}
		Address++;
		dataAddr++;
	}
	return(ret);
}
/************************************************/
/*	Func:WordWriteProc							*/
/*		Word Write Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:�ʐM�p��M�o�b�t??Addr	*/
/*		int PlcType:���g�p						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:WordWriteProc							*/
/*		Word Write Func							*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx: ��ſ� ���� ���� Addr	*/
/*		int PlcType:�̻��						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	WordWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;
	int		dCnt;
	int		Address;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_WORDCNT){	dCnt -= MAX_WORDCNT;	mp->mext= MAX_WORDCNT;	}
		else{					mp->mext= dCnt;			dCnt = 0;				}
		ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)&PlcSendBuff[1],(char *)mp->mptr);
		if(ret != 0){				break;			}
		if(DeviceFlag == 2){	Cnt = mp->mext* 4;	}
		else{					Cnt = mp->mext* 2;	}
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0);
		if(ret != 0){				ret= -1;	break;	}
		if(rDataFx[0] != 0x06){		ret= -1;	break;	}
		if(dCnt == 0){							break;	}
		Address += MAX_WORDCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
	}
	return(ret);
}
/************************************************/
/*	Func:C_PLCCommWrite							*/
/*		Device Write Func						*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:�ʐM�p��M�o�b�t??Addr	*/
/*		int PlcType:���g�p						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
/*	Func:C_PLCCommWrite							*/
/*		Device Write Func						*/
/*	IN	T_MAIL *mp:Read Device Info Mail		*/
/*			mp->mpar:Device Addr				*/
/*			mp->mext:Device Count				*/
/*			mp->mbuf:Device Code				*/
/*			mp->mptr:Read Data Save Addr		*/
/*		unsigned char *rDataFx:��ſ� ���� ���� Addr	*/
/*		int PlcType:�̻��						*/
/*	Ret:	0:OK,-1:Error						*/
/************************************************/
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	
	ret=0;
	GetGroopSema();			/* For Monitor */
	switch(mp->mpec){
	case PLC_BIT:		ret= BitWriteProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordWriteProc(mp,rDataFx,PlcType);		break;
	}
	ResetGroopSema();
	return(ret);
}
/************************************************/
/*	Func:C_GetSendRecTime						*/
/*		Send��̎�M�҂����Ԏ��o���i���g�p�j	*/
/*	Ret:	0:									*/
/************************************************/
/*	Func:C_GetSendRecTime						*/
/*		Send�Ŀ� ���Ŵ�� �ð��� ���(�̻��)	*/
/*	Ret:	0:									*/
/************************************************/
static	int	C_GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
/************************************************/
/*	Func:C_Get_Plc_Ver							*/
/*		�v���g�R���o?�W�������o��			*/
/*	In	char *name:Versin �i? addr				*/
/*	Ret:	�Ȃ�								*/
/************************************************/
/*	Func:C_Get_Plc_Ver							*/
/*		�������� ���� ���			*/
/*	In	char *name:Versin ���� addr				*/
/*	Ret:	����								*/
/************************************************/
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name, VERSION_SET);
}

/* ���� �ҽ� �� */
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH1������ ����ϴ� �Լ� ���� */ 

#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1 ó�� 									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
/************************************************/
/*	Func:GetDevMaxPLC							*/
/*		Device Max Addr ���o��				*/
/*	IN	int bFlag:0:Bit,1:Word					*/
/*		int idx:Device Code						*/
/*	Ret:	Max Address							*/
/************************************************/
/*	Func:GetDevMaxPLC							*/
/*		Device Max Addr ���				*/
/*	IN	int bFlag:0:Bit,1:Word					*/
/*		int idx:Device Code						*/
/*	Ret:	Max Address							*/
/************************************************/
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
/************************************************/
/*	Func:GetDevMinPLC							*/
/*		Device Min Addr ���o��				*/
/*	IN	int bFlag:0:Bit,1:Word					*/
/*		int idx:Device Code						*/
/*	Ret:	Max Address							*/
/************************************************/
/*	Func:GetDevMinPLC							*/
/*		Device Min Addr ���				*/
/*	IN	int bFlag:0:Bit,1:Word					*/
/*		int idx:Device Code						*/
/*	Ret:	Max Address							*/
/************************************************/
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/************************************************/
/*	Func:PLCPCDownThrue							*/
/*		PLC Thru Mode(Monitor) 1 Char handler	*/
/*	IN	unsigned char data:��M�f??			*/
/*		int *CommMode:��M��?�h�i?�̈�		*/
/*		int *Sio1RecCnt:��M�J�E���g�i?�̈�	*/
/*		unsigned char *Sio1RecBuff:��M�f??�i?�̈� */
/*	Ret   :0:��M�����i��M?�X�N���N������j-1:��M���p������	*/
/************************************************/
/*	Func:PLCPCDownThrue							*/
/*		PLC Thru Mode(Monitor) 1 Char handler	*/
/*	IN	unsigned char data: ���ŵ���Ÿ			*/
/*		int *CommMode:���Ÿ�� ���� ����		*/
/*		int *Sio1RecCnt:����ī��Ʈ ���� ����	*/
/*		unsigned char *Sio1RecBuff:���ŵ���Ÿ ���� ���� */
/*	Ret   :0:���� �Ϸ� (����Ÿ��ũ �⵿), -1:������ ��� ���� */
/************************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	switch(*CommMode){
	case 0:		/* Normal */
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:		/* Thru Mode */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			if((data == EOT) || (data == ETX)){
				*CommMode = 99;
				ret = 0;	/* Pendding Req */
			}
		}else{
			*CommMode = 0;
		}
		break;
	}
	return(ret);
}
/************************************************/
/*	Func:PlcMakeDeviceAddr						*/
/*		Groop Monitor Address					*/
/*	IN	int mode:0:Bit,1:Word					*/
/*		char *DevName:Device Code�i?�̈�		*/
/*		int DevAddress:Device Address			*/
/*		char *work:�ϊ��f??�i?�̈�			*/
/*	Ret   :0:OK-1:Error							*/
/************************************************/
/*	Func:PlcMakeDeviceAddr						*/
/*		Groop Monitor Address					*/
/*	IN	int mode:0:Bit,1:Word					*/
/*		char *DevName:Device Code ���� ����		*/
/*		int DevAddress:Device Address			*/
/*		char *work: ��ȯ ����Ÿ ���� ����		*/
/*	Ret   :0:OK-1:Error							*/
/************************************************/
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	int	ret;
	int	DevAddr;
	char	buff[8];
	char	abuff[8];

	if(((unsigned char)DevName[0] == 0x7f) || ((unsigned char)DevName[0] == 0xef)){		/* UB,UW */
		return(-1);
	}
	ret= MakePLCDevAddress(mode, DevName, DevAddress, &DevAddr, 2);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		B_Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		/*sprintf(work,"M%s0002",abuff);*/
		B_gstrcpy(work,"M");
		B_gstrcat(work,abuff);
		B_gstrcat(work,"0002");
	}
	return(ret);
}
/************************************************/
/*	Func:MakeBitContinue						*/
/*		Make Bit Continue Patarn				*/
/*	IN	�Ȃ�									*/
/*	Ret �Ȃ�									*/
/************************************************/
/*	Func:MakeBitContinue						*/
/*		Make Bit Continue Patarn				*/
/*	IN	����									*/
/*	Ret ����									*/
/************************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
						MyAddress= DeviceDataSys[i].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/************************************************/
/*	Func:MakeWordContinue						*/
/*		Make Word Continue Patarn				*/
/*	IN	�Ȃ�									*/
/*	Ret �Ȃ�									*/
/************************************************/
/*	Func:MakeWordContinue						*/
/*		Make Word Continue Patarn				*/
/*	IN	����									*/
/*	Ret ����									*/
/************************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;
	char	Device[4];*/
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
					MyAddress= DeviceDataSys[i].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN			   */	
/*	2006.03.31 makebitpatarn �ϰ� ����         */
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/*	2006.03.31 makewordpatarn �ϰ� ����        */
/***************************************************/
void	MakeWordPatarn(int Start)
{

}
/************************************************/
/*	Func:ClearBWContinue						*/
/*		Clear Continue Patarn					*/
/*	IN	�Ȃ�									*/
/*	Ret �Ȃ�									*/
/************************************************/
/*	Func:ClearBWContinue						*/
/*		Clear Continue Patarn					*/
/*	IN	����									*/
/*	Ret ����									*/
/************************************************/
void	ClearBWContinue(void)
{
	int		i,j,idx;

	for(i= 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus != 0)){
			/* Continue */
			if(DeviceDataSys[i].DevFlag == 0){		/* BIT */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_BIT_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}else{									/* WORD */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_WORD_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}
		}
	}
}
/************************************************/
/*	Func:MakeGroupDevPLC						*/
/*		make Group Patarn						*/
/*	IN	int PlcType:���g�p						*/
/*	Ret �Ȃ�									*/
/************************************************/
/*	Func:MakeGroupDevPLC						*/
/*		make Group Patarn						*/
/*	IN	int PlcType:�̻��						*/
/*	Ret ����									*/
/************************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Set Group */
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gDeviceCnt= 0;
	/* Same Device Check */
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	if(BitCnt > 0){
		MakeBitContinue();
	}
	if(WordCnt > 0){
		MakeWordContinue(TotalBitCnt);
	}
	/* Continue MAX Check */
	ClearBWContinue();
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}
	return(0);
}
/************************************************/
/*	Func:SetGroupDevPLC							*/
/*		Monitor Group ���M����					*/
/*	IN	�Ȃ�									*/
/*	Ret 0:OK,-1:Error							*/
/************************************************/
/*	Func:SetGroupDevPLC							*/
/*		Monitor Group ����ó��					*/
/*	IN	����									*/
/*	Ret 0:OK,-1:Error							*/
/************************************************/
int		SetGroupDevPLC(void)
{
	int		i;
	int		idx;
	char	work[12+ 1];
	int		ret= 0;
	int		Cnt;

	/* Same Device Check */
	B_gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	B_gstrcpy((char *)&PlcSendBuff[1],"uW0002");
	idx= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	for(i = 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].DevCnt == 1) &&
			(DeviceDataSys[i].DevFlag == 1) &&
			(DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus == 0)){
			if(PlcMakeDeviceAddr(DeviceDataSys[i].DevFlag, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work) == 0){
				B_gstrcpy((char *)&PlcSendBuff[7 + idx+ gDeviceCnt*9],(char *)work);
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
				gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
				DeviceDataSys[i].SameDevInf= 4;
				gDeviceCnt++;
				gDeviceCntWord++;
			}
		}
		/*sprintf(work,"%02X",gDeviceCntWord);*/
		B_Bin2Hex(gDeviceCntWord,2,work);
		B_gmemcpy((char *)&PlcSendBuff[5],work,2);
		if(gDeviceCnt > MAX_UR_CNT){
			break;
		}
	}
	if(gDeviceCnt != 0){
		B_gstrcpy(&work[1],"uA00");
		ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcRecBuff,&Cnt,0);
		if(ret == 0){
/*			if(gstrncmp((char *)PLCbuf,"\x06u",2) != 0){*/
			if(PlcRecBuff[0] != 0x06){
				ret= -1;
			}
		}
		if(ret == 0){
			ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)PlcRecBuff,&Cnt,0);
			if(ret == 0){
/*				if(gstrncmp((char *)PLCbuf,"\x06u",2) != 0){*/
				if(PlcRecBuff[0] != 0x06){
					ret= -1;
				}
			}
		}
		B_gstrcpy(&work[1],"uE00");
		if(ret == 0){
			ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcRecBuff,&Cnt,0);
			if(ret == 0){
/*				if(gstrncmp((char *)PLCbuf,"\x06u",2) != 0){*/
				if(PlcRecBuff[0] != 0x06){
					ret= -1;
				}
			}
		}
	}
	return(ret);
}
/************************************************/
/*	Func:ReadGroupPLCDev						*/
/*		Monitor Read����						*/
/*	IN	�Ȃ�									*/
/*	Ret 0:OK,-1:Error							*/
/************************************************/
/*	Func:ReadGroupPLCDev						*/
/*		Monitor Read ó��						*/
/*	IN	����									*/
/*	Ret 0:OK,-1:Error							*/
/************************************************/
int		ReadGroupPLCDev(void)
{
	int		ret;
	int		idx;
	int		i;
	int		WordCnt;
	char	work[16];
	char	work1[8];

	if(gDeviceCntWord == 0){
		return(0);
	}
	ret= 0;
	WordCnt= gDeviceCntWord;
	/*sprintf(work,"uR0000%02X",WordCnt);*/
	work[0]= STX;
	work[1]= 0;
	B_gstrcpy(&work[1],"uR0000");
	B_Bin2Hex(WordCnt,2,work1);
	B_gstrcat(work,work1);
	ret= SendRecPLCWithBCC(2,work,PlcSendDevData,&idx,0);
	if(ret == OK){
/*		if(gstrncmp((char *)PlcSendDevData,"\x06u",2) != 0){*/
		if(PlcSendDevData[0] != 0x06){
			ret= -1;
		}
		if(ret == 0){
			for(i = 0; i < gDeviceCntWord; i++){
#ifdef	SH_CPU
				*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 2]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 4]);
#endif
#ifdef	ARM_CPU
#ifdef	WIN32
				*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 2]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 4]);
#else
				*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 4]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 2]);
#endif
#endif
			}
			B_gstrcpy(&work[1],"uE00");
			ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcRecBuff,&idx,0);
			if(ret == 0){
/*				if(gstrncmp(work,"\x06u",2) != 0){*/
				if(PlcRecBuff[0] != 0x06){
					ret= -1;
				}
			}
		}
	}
	return(ret);
}
/************************************************/
/*	Func:SendMonuW								*/
/*		uW���M����								*/
/*	IN	int idx:Thru Monitor idx				*/
/*	Ret 0:OK,-1:Error							*/
/************************************************/
/*	Func:SendMonuW								*/
/*		uW �۽�ó��								*/
/*	IN	int idx:Thru Monitor idx				*/
/*	Ret 0:OK,-1:Error							*/
/************************************************/
int		SendMonuW(int idx)
{
	int		ret;
	int		SendCnt;
	int		Cnt;
	char	work[16];

	B_gstrcpy(&work[1],"uA00");
	ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcRecBuff,&Cnt,0);
	if(ret == 0){
		if(PlcRecBuff[0] != 0x06){
			ret= NG;
		}
	}
	SendCnt= PlcThruMonDataCnt[idx];
	B_gmemcpy((char *)&PlcSendBuff[0],(char *)PlcThruMonBuff[idx],SendCnt);
	ret= C_SendRecPLC(2,PlcRecBuff,&Cnt,0,SendCnt,(char *)PlcSendBuff,2000);
	if(ret == 0){
		if(PlcRecBuff[0] != 0x06){
			ret= NG;
		}
	}
	B_gstrcpy(&work[1],"uE00");
	if(ret == 0){
		ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcRecBuff,&Cnt,0);
		if(ret == 0){
			if(PlcRecBuff[0] != 0x06){
				ret= NG;
			}
		}
	}
	return(OK);
}
/************************************************/
/*	Func:SendMonuR								*/
/*		uR���M����								*/
/*	IN	int idx:Thru Monitor idx				*/
/*	Ret 0:OK,-1:Error							*/
/************************************************/
/*	Func:SendMonuR								*/
/*		uR �۽� ó��								*/
/*	IN	int idx:Thru Monitor idx				*/
/*	Ret 0:OK,-1:Error							*/
/************************************************/
int		SendMonuR(int idx)
{
	int		ret;
	int		RecCnt;
	int		Cnt;
	char	work[16];

	PlcSendBuff[0]= STX;
	PlcSendBuff[1]= 0;
	B_gstrcpy((char *)&PlcSendBuff[1],"uR0000");
	B_gmemcpy((char *)&PlcSendBuff[7],(char *)&PlcThruMonBuff[idx][5],2);	/* Word Cnt */
	PlcSendBuff[9]= 0;
	ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&RecCnt,0);
	if(ret == OK){
		if(PlcRecBuff[0] != 0x06){
			ret= NG;
		}
		B_gstrcpy(&work[1],"uE00");
		if(ret == 0){
			ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcSendBuff,&Cnt,0);
			if(ret == 0){
				if(PlcSendBuff[0] != 0x06){
					ret= NG;
				}
			}
		}
		PlcThruRecDataCnt[idx]= RecCnt;
		B_gmemcpy((char *)PlcThruRecBuff[idx],(char *)PlcRecBuff,RecCnt);
	}
	return(OK);
}
/************************************************/
/*	Func:RecGroupPLCDev							*/
/*		Groop Read����							*/
/*	IN	int PlcType:���g�p						*/
/*	Ret 0:OK,-1:Error							*/
/************************************************/
/*	Func:RecGroupPLCDev							*/
/*		Groop Read ó��							*/
/*	IN	int PlcType:�̻��						*/
/*	Ret 0:OK,-1:Error							*/
/************************************************/
int		RecGroupPLCDev(int PlcType)
{
	int		i;
	int		ret;

	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].SameDevInf == 4){
			DeviceDataSys[i].SameDevInf= 0;
		}
	}
	GetGroopSema();			/* For Monitor */
	while(1){				/* GP Monitor */
		ret= SetGroupDevPLC();
		if((ret != 0) || (gDeviceCntWord == 0)){
			break;
		}
		ret= ReadGroupPLCDev();
		if(ret != 0){
			break;
		}
	}
	for(i= 0; i < PlcThruMonCnt; i++){				/* PC->PLC Monitor */
		ret= SendMonuW(i);
		if(ret == OK){
			SendMonuR(i);
		}
	}
	LgCommSeq= 1;
	ResetGroopSema();
	return(ret);
}
/************************************************/
/*	Func:CheckLGCommand							*/
/*		��M�R?���h?�F�b�N					*/
/*	IN	char *comm:��M�f??address			*/
/*	Ret -1�ȊO:�R?���hIndex,-1:Error			*/
/************************************************/
/*	Func:CheckLGCommand							*/
/*		���� Ŀ��� üũ					*/
/*	IN	char *comm:���� ����Ÿ address			*/
/*	Ret -1 �̿� : Ŀ��� Index,-1:Error			*/
/************************************************/
int	CheckLGCommand(char *comm)
{
	int		i;
	int		ret= -1;

	for(i= 0; i < 4; i++){
/* �����Ϸ� ���� ���̺� ���� */
#ifdef	SH_CPU
		if(B_gstrncmp(comm,(char *)LgComm[i],2) == 0){
#endif
/* �����Ϸ� ���� ���̺� ���� */
#ifdef	ARM_CPU
		if(B_gstrncmp(comm,(char *)LgComm[i].strData,2) == 0){
#endif			
			ret= i;
			break;
		}
	}
	return(ret);
}
/*******************************************/
/*
char	LgLogBuff[1280];
int		LgLogFlag;
*/
/************************************************/
/*	Func:PLCFxThruProc							*/
/*		Thru Mode ��M����						*/
/*	IN	char *CommBuff:��M�f??address		*/
/*		int *RecCommCnt:��M�f??�J�E���g		*/
/*		char *OutBuff:���M�f??address			*/
/*		int *OutCnt:���M�f??��				*/
/*		int PlcConnectFlag:���g�p				*/
/*		int PlcType:���g�p						*/
/*	Ret �Ȃ�									*/
/************************************************/
/*	Func:PLCFxThruProc							*/
/*		Thru Mode ����ó��						*/
/*	IN	char *CommBuff: ���� ����Ÿ address		*/
/*		int *RecCommCnt:���� ����Ÿ ī��Ʈ 		*/
/*		char *OutBuff:�۽� ����Ÿ address			*/
/*		int *OutCnt:�۽� ����Ÿ ��				*/
/*		int PlcConnectFlag:�̻��				*/
/*		int PlcType:�̻��						*/
/*	Ret �Ȃ�									*/
/************************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	int		command;
	int	SendCnt;

	if(LgConnectFlag != 1){
		/* DisConnect */
		/* NAK */
		PlcSendBuff[1]= 'u';
		PlcSendBuff[2]= 0;
		SendCnt= SetPLCBCCACK(NAK,(char *)&PlcSendBuff,1);
		/* ACK Send To PC */
		B_SendPLC2PCData( 0,SendCnt,(char *)PlcSendBuff,2000 );
		return;
	}
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;

	command= CheckLGCommand(&CommBuff[1]);
	switch(command){
	case 0:			/* uW Commnad */
		GetGroopSema();			/* For Monitor */
		if((PlcThruMonCnt < 10) && (*RecCommCnt <= 256)){
			PlcThruMonDataCnt[PlcThruMonCnt]= *RecCommCnt;
			B_gmemcpy((char *)&PlcThruMonBuff[PlcThruMonCnt++],CommBuff,*RecCommCnt);
			PlcSendBuff[1]= 'u';
			PlcSendBuff[2]= 0;
			SendCnt= SetPLCBCCACK(ACK,(char *)&PlcSendBuff,1);
			/* ACK Send To PC */
			B_SendPLC2PCData( 0,SendCnt,(char *)PlcSendBuff,2000 );
		}else{
			/* Error */
		}
		LgCommSeq= 0;
		ResetGroopSema();
		break;
	case 1:			/* uR Command */
		while(1){
			if(LgCommSeq != 0){
				break;
			}
			B_Delay(50);
		}
		GetGroopSema();			/* For Monitor */
		if(PlcThruRecCnt < 10){
			SendCnt= PlcThruRecDataCnt[PlcThruRecCnt];
			B_gmemcpy((char *)&PlcSendBuff[0],(char *)PlcThruRecBuff[PlcThruRecCnt++],SendCnt);
			/* Rec Data Send To PC */
			B_SendPLC2PCData( 0,SendCnt,(char *)PlcSendBuff,2000 );
		}
		ResetGroopSema();
		break;
	case 3:			/* uA Command */
		PlcThruMonCnt= 0;
		PlcThruRecCnt= 0;
	case 2:			/* uE Command */
		GetGroopSema();			/* For Monitor */
		PlcSendBuff[1]= 'u';
		PlcSendBuff[2]= 0;
		SendCnt= SetPLCBCCACK(ACK,(char *)&PlcSendBuff,1);
		/* ACK Send To PC */
		B_SendPLC2PCData( 0,SendCnt,(char *)PlcSendBuff,2000 );
		ResetGroopSema();			/* For Monitor */
		break;
	default:
		GetGroopSema();			/* For Monitor */
		B_SendThruePLC(2,*OutCnt,OutBuff,3000);		/* ACK ���M */
		ResetGroopSema();			/* For Monitor */
		break;
	}
}
/************************************************/
/*	Func:Device2IndexPLC						*/
/*		Device Name��Device Code�ɕϊ�����		*/
/*	IN	int bwflag:0:Bit,1:Word					*/
/*		char *Name:Device Name Addr				*/
/*	Ret 0:OK,-1:Error							*/
/************************************************/
/*	Func:Device2IndexPLC						*/
/*		Device Name�� Device Code�� ��ȯ ó��		*/
/*	IN	int bwflag:0:Bit,1:Word					*/
/*		char *Name:Device Name Addr				*/
/*	Ret 0:OK,-1:Error							*/
/************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}

/*++++++++++++++++++++++++++++++++++++*/
#endif

/* PLCTYPE_CH1������ ����ϴ� �Լ� �� */
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH2������ ����ϴ� �Լ� ���� */ 

#ifdef	PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �Լ�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif

#include	"hook_aplplc.h"

/****************************** END **********************/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
