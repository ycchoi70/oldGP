/*************** PLC1 *****************/
int	PLC_CONNECT(int *PlcType,int iConnect);
int	GET_PLC_NAME(int bFlag,unsigned char *src,char *obj,int *DevInfo);
int	PLC1CHAR_READ(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff);
int	PLC_DEV_READ(T_MAIL *mp,unsigned char *rDataFx,int PlcType);
int	PLC_DEV_WRITE(T_MAIL *mp,unsigned char *rDataFx,int PlcType);
int	PLC_MAKE_GROUP(int PlcType);
int	PLC_GROUP_READ(int PlcType);
int	PLCPCDOWN(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff);
void	PLC_THRU_PROC(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType);
int	GET_PLC_MAX(int bFlag,int idx);
int	GET_PLC_MIN(int bFlag,int idx);
int		DEVICE_2_INDEX(int bwflag,char *Name);
int		CHECK_PLC_ADDR(int bwflag,char *Name,int *Address1,int *plctype);
void	GET_MON_BAUDRATE(int *Speed,int *DataBit,int *Parity);
int	GET_SEND_REC_TIME(void);
void	GET_PLC1_VER(char *Name);
int	GET_MS_SEL(void);

/*************** PLC2 *****************/
int	PLC_CONNECT2(int *PlcType,int iConnect);
int	PLC1CHAR_READ2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff);
int	PLC_DEV_READ2(T_MAIL *mp,unsigned char *rDataFx,int PlcType);
int	PLC_DEV_WRITE2(T_MAIL *mp,unsigned char *rDataFx,int PlcType);
int	GET_SEND_REC_TIME2(void);
void	GET_PLC2_VER(char *Name);
int	GET_MS_SEL2(void);
void	GET_MON_BAUDRATE2(int *Speed,int *DataBit,int *Parity);

/*************** Defualt *****************/
void	LG_PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType);
int	UN_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo);
int		UN_CheckDevice_Addr(int bwflag,char *DevName,unsigned int *Address1,unsigned int *Address2);
int		UN_Device2IndexPLC(int bwflag,char *Name);
int	LG_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo);
int		LG_Device2IndexPLC(int bwflag,char *Name);
int		CheckDevice_Addr(int bwflag,char *DevName,unsigned int *Address1,unsigned int *Address2);
int	LG_GetDevMaxPLC(int bFlag,int idx);
int	LG_GetDevMinPLC(int bFlag,int idx);
int		LG_MakeGroupDevPLC(int PlcType);
int		LG_RecGroupPLCDev(int PlcType);
int	LG_Connection( int *PlcType,int iConnect );
int	LG_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType);
int	LG_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType);
void	LG_GetMonBaudrate(int *Speed,int *DataBit,int *Parity);
int PCDownThrueLG(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff);
int	PlcRecRS(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff);
void	Def_Get_Plc1_Ver(char *name);
int	Def_Get_Ms_Sel(void);
