/********************************************************************************/
/* �� �� �� : GpLineGraphTask.cpp												*/
/* ��    �� : LineGraphTask														*/
/* �� �� �� : 2002�� 5�� 13�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"
typedef struct{
	short		iPosX;
	short		iPosY;
} _ST0;
typedef struct{
	_ST0	st_data[80][50];
} _ST;

/********************************************************************************/
/* �� �� �� : DrawLineGraph_Task												*/
/* ��    �� : LineGraph������ �ص��Ͽ� ȭ�鿡 ���								*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 30�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetLineGraph_Func(int iDispOrder)
{
	_LINEGRAPH_EVENT_TBL*	 LineGraphEventTbl;
	LineGraphEventTbl= (_LINEGRAPH_EVENT_TBL*)TakeMemory(sizeof(_LINEGRAPH_EVENT_TBL));
	DrawLineGraph_Func(0,LineGraphEventTbl,iDispOrder);
	FreeMail((char *)LineGraphEventTbl);
}
int	DrawLineGraph_Func(int mode,_LINEGRAPH_EVENT_TBL* LineGraphEventTbl,int iDispOrder)
{
/*	unsigned int	iTagSizeOf;	*/
	int				i;
	int				iOffset;
	int				iDevStartAddr;
	int				iTemp;
//	int				k;	
	unsigned char *buffer;
/*	_LINEGRAPH_EVENT_TBL*	 LineGraphEventTbl;*/
	buffer= ScreenTagData[iDispOrder].TagPos;
/*
	if(CheckMailBox(sizeof(_LINEGRAPH_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_LINEGRAPH_EVENT_TBL));
	LineGraphEventTbl= (_LINEGRAPH_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)LineGraphEventTbl, 0x00, sizeof(_LINEGRAPH_EVENT_TBL));

	i		= 0;
	iOffset = 0;
//	k		= 0;	
/*
	iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
	iTagSizeOf += (unsigned int)buffer[1] & 0xff;
*/		
	/* ��ǥ */
/*
	LineGraphEventTbl->sX  = (unsigned int)(buffer[6]  << 0x08);
	LineGraphEventTbl->sX += (unsigned int)buffer[7] & 0xff;


	LineGraphEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
	LineGraphEventTbl->sY += (unsigned int)buffer[9] & 0xff;

	LineGraphEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
	LineGraphEventTbl->eX += (unsigned int)buffer[11] & 0xff;

	LineGraphEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
	LineGraphEventTbl->eY += (unsigned int)buffer[13] & 0xff;
*/

	LineGraphEventTbl->iDirecition = (unsigned int)buffer[14];

	LineGraphEventTbl->iFrameColor = (unsigned int)buffer[15];
	/* Number : ��Ʈ�� ��Ÿ�� ���� ���� */
	LineGraphEventTbl->iNumber = (unsigned int)buffer[16];
	/* Points : ��Ʈ�� ���� ���̴� Ƚ�� */
	LineGraphEventTbl->iPoints = (unsigned int)buffer[17];

	switch((unsigned int)buffer[18]){
		case 1:
			LineGraphEventTbl->iCaseUpFixedVal = CHECKED;	/* Fixed ���� �� CHECKED, Device ���� �� UNCHECKED*/
			LineGraphEventTbl->iCaseLoFixedVal = CHECKED;
			break;
		case 2:
			LineGraphEventTbl->iCaseUpFixedVal = UNCHECKED;
			LineGraphEventTbl->iCaseLoFixedVal = UNCHECKED;
			break;
		case 3:/* �Ѵ� Fixed���� ����ϹǷ� Signed Unsigned ������ ����-> */
			LineGraphEventTbl->iCaseUpFixedVal = CHECKED;
			LineGraphEventTbl->iCaseLoFixedVal = UNCHECKED;				
			break;
		case 4:
			LineGraphEventTbl->iCaseUpFixedVal = UNCHECKED;
			LineGraphEventTbl->iCaseLoFixedVal = CHECKED;
			break;
	}
	/* Plate Color */
	LineGraphEventTbl->iPlateColor = (unsigned int)buffer[19];

	switch((unsigned int)buffer[20]){
		case 1:
			LineGraphEventTbl->iFrameChecked		= CHECKED;
			LineGraphEventTbl->iScaleDispChecked	= CHECKED;
			break;
		
		case 2:
			LineGraphEventTbl->iFrameChecked		= UNCHECKED;
			LineGraphEventTbl->iScaleDispChecked	= CHECKED;
			break;

		case 3:
			LineGraphEventTbl->iFrameChecked		= CHECKED;
			LineGraphEventTbl->iScaleDispChecked	= UNCHECKED;
			break;

		case 4:
			LineGraphEventTbl->iFrameChecked		= UNCHECKED;
			LineGraphEventTbl->iScaleDispChecked	= UNCHECKED;
			break;
	}
	iOffset = 21;
	if(LineGraphEventTbl->iCaseUpFixedVal == CHECKED){	/* Fixed�� ������� ��� */
#ifdef	WIN32
		LineGraphEventTbl->lUpperFixedData  = (unsigned int)buffer[iOffset] << 0x18;
		LineGraphEventTbl->lUpperFixedData += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		LineGraphEventTbl->lUpperFixedData += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		LineGraphEventTbl->lUpperFixedData += (unsigned int)buffer[++iOffset] & 0xff; 
		iOffset+=2;
#else
		memcpy(&LineGraphEventTbl->lUpperFixedData,&buffer[iOffset],4);
		iOffset+=5;
#endif
	}
	else{	/* Device�� ������� ��� */
		/*------------------------------------------------------------*/
		if(mode == 0){
			GetDeviceSet((buffer+iOffset),
					LineGraphEventTbl->cUpperDeviceName,
					&(LineGraphEventTbl->iUpperDeviceNumber));
		}
		/*-------------------------------------------------------------*/		
		iOffset+=5;
	}
		
	/* Case �ǿ��� Lower ���� */
	if(LineGraphEventTbl->iCaseLoFixedVal == CHECKED){	/* Fixed�� ������� ��� */
#ifdef	WIN32
		LineGraphEventTbl->lLowerFixedData  = (unsigned int)buffer[iOffset] << 0x18;
		LineGraphEventTbl->lLowerFixedData += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		LineGraphEventTbl->lLowerFixedData += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		LineGraphEventTbl->lLowerFixedData += (unsigned int)buffer[++iOffset] & 0xff; 
		iOffset++;
#else
		memcpy(&LineGraphEventTbl->lLowerFixedData,&buffer[iOffset],4);
		iOffset += 4;
#endif
	}
	else{	/* Device�� ������� ��� */
		/*------------------------------------------------------------*/
		if(mode == 0){
			GetDeviceSet((buffer+iOffset),
					LineGraphEventTbl->cLowerDeviceName,
					&(LineGraphEventTbl->iLowerDeviceNumber));
		}
		/*-------------------------------------------------------------*/		
		iOffset+=4;
	}
	if(LineGraphEventTbl->iScaleDispChecked == CHECKED){
		LineGraphEventTbl->iScaleColor = (unsigned int)buffer[++iOffset];
		/* Scale Point(V) */
		LineGraphEventTbl->iScalePointsV = (unsigned int)buffer[++iOffset];
		/* Scale Point(H) */
		LineGraphEventTbl->iScalePointsH = (unsigned int)buffer[++iOffset];
		if(mode == 0){
			ScreenTagData[iDispOrder].sX += 4;
			ScreenTagData[iDispOrder].eY -= 4;
		}
	}
	if((unsigned int)buffer[++iOffset] == 0x00)
	{
		LineGraphEventTbl->IsChkVNDisplayed = UNCHECKED;
		LineGraphEventTbl->VNDisplayedVal = 0;
	}
	else
	{
		LineGraphEventTbl->IsChkVNDisplayed = CHECKED;
#ifdef	WIN32
		LineGraphEventTbl->VNDisplayedVal  = (unsigned int)buffer[++iOffset] << 0x18;
		LineGraphEventTbl->VNDisplayedVal += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		LineGraphEventTbl->VNDisplayedVal += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		LineGraphEventTbl->VNDisplayedVal += (unsigned int)buffer[++iOffset] & 0xff;
#else
		iOffset++;
		memcpy(&LineGraphEventTbl->VNDisplayedVal,&buffer[iOffset],4);
		iOffset += 3;
#endif
	}
	if((unsigned int)buffer[++iOffset] == 0x00)
	{
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed = UNCHECKED;
		}
		LineGraphEventTbl->ShapeNo = 0;
		iOffset++;
	}else
	{
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed = CHECKED;
		}
		LineGraphEventTbl->ShapeNo = (unsigned int)buffer[++iOffset];
	}
	if((unsigned int)buffer[++iOffset] < 4)	/* 1,2,3 -> 16Bit */
		LineGraphEventTbl->i1632BitFlag = BIT16;
	else								/* 4,5,6 -> 32Bit */
		LineGraphEventTbl->i1632BitFlag = BIT32;

	if((unsigned int)buffer[iOffset] == 0x01 || (unsigned int)buffer[iOffset] == 0x04)
		LineGraphEventTbl->iSignedFlag = SIGNED;
	else if((unsigned int)buffer[iOffset] == 0x02 || (unsigned int)buffer[iOffset] == 0x05)
		LineGraphEventTbl->iSignedFlag = UNSIGNED;
	else
		LineGraphEventTbl->iSignedFlag = BCD;

	for(i=0 ; i<LineGraphEventTbl->iNumber ; i++){
		LineGraphEventTbl->lf[i].iLineType  = (unsigned int)buffer[++iOffset];
		LineGraphEventTbl->lf[i].iLineType++;
		LineGraphEventTbl->lf[i].iLineColor = (unsigned int)buffer[++iOffset];			
	}
	/* Monitor Device Infomation */

	/* Monitor Device Infomation */
	/*------------------------------------------------------------*/
	iOffset++;
/*	if(mode == 0){*/
		GetDeviceSet((buffer+iOffset),
				LineGraphEventTbl->cDeviceName,
				&(LineGraphEventTbl->iDeviceNumber));
/*	}*/
	iOffset+=4;
	/*-------------------------------------------------------------*/		
	
	LineGraphEventTbl->iRegisterNumber = DeviceCnt;
	iTemp = LineGraphEventTbl->iRegisterNumber; 

	i = 0;
	iDevStartAddr = LineGraphEventTbl->iDeviceNumber;
	
	if(mode == 0){
			ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
/*		while(i<LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints){*/
			DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */
			DeviceDataHed[DeviceCnt].DevName[0] = LineGraphEventTbl->cDeviceName[0];
			DeviceDataHed[DeviceCnt].DevName[1] = LineGraphEventTbl->cDeviceName[1];
			DeviceDataHed[DeviceCnt].DevAddress = iDevStartAddr;
			/* ���� �ϳ� �������� */

			if(LineGraphEventTbl->i1632BitFlag == BIT16){
				DeviceDataHed[DeviceCnt].DevCnt = LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints;				
			}else{
				DeviceDataHed[DeviceCnt].DevCnt = LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints*2;				
			}
			DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];
			ScreenTagData[iDispOrder].DevCnt += DeviceDataHed[DeviceCnt].DevCnt*2;
			if(LineGraphEventTbl->i1632BitFlag == BIT16)
			{	
				iDeviceOffset += (LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints * 2);
/*
				LineGraphEventTbl->cBefMonitorDevVal = (char*)TakeMemory(LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints * 2+1);
				memset(LineGraphEventTbl->cBefMonitorDevVal,0x00,LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints * 2+1);
*/
			}else{														
				iDeviceOffset += (LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints * 4);
/*
				LineGraphEventTbl->cBefMonitorDevVal = (char*)TakeMemory(LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints * 4+1);
				memset(LineGraphEventTbl->cBefMonitorDevVal,0x00,LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints * 4+1);
*/
			}
				

								
			/*if(LineGraphEventTbl->i1632BitFlag == BIT16){*/	/* 16bit*/	
			/*	DeviceDataHed[DeviceCnt].DevCnt = 1;*/				
			/*}else{*/											/* 32bit	*/
			/*	DeviceDataHed[DeviceCnt].DevCnt = 2;*/				
			/*}	*/			
			/*DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];*/
			/*if(LineGraphEventTbl->i1632BitFlag == BIT16){*/	/* 16bit */				
			/*	iDeviceOffset += 2;*/
			/*}else{*/											/* 32bit */			
			/*	iDeviceOffset += 4;*/
			/*}*/
		

			/* 20020819 choijh add*/
/*			LineGraphEventTbl->SuperVOffset= WatchingDevice(LineGraphEventTbl->cDeviceName, 
										   iDevStartAddr, 
			     						   LineGraphEventTbl-> i1632BitFlag,
										   iTemp,
										   WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
			iTemp++;
			DeviceCnt++;
			iDevStartAddr++;			
			i++;
/*		}*/
			
		/* ���Ѱ��� Device�� ���� ��� */
		if(LineGraphEventTbl->iCaseUpFixedVal == UNCHECKED){			
			DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */
			DeviceDataHed[DeviceCnt].DevName[0] = LineGraphEventTbl->cUpperDeviceName[0];
			DeviceDataHed[DeviceCnt].DevName[1] = LineGraphEventTbl->cUpperDeviceName[1];
			DeviceDataHed[DeviceCnt].DevAddress = LineGraphEventTbl->iUpperDeviceNumber;
			if(LineGraphEventTbl->i1632BitFlag == BIT16){/* 16bit */
				DeviceDataHed[DeviceCnt].DevCnt = 1;				
			}else{/* 32bit */
				DeviceDataHed[DeviceCnt].DevCnt = 2;				
			}
			DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];			
/*			LineGraphEventTbl->iUpperRegistNumber = DeviceCnt;*/
			if(LineGraphEventTbl->i1632BitFlag == BIT16){/* 16bit */				
				iDeviceOffset += 2;
			}else{/* 32bit */				
				iDeviceOffset += 4;
			}

			/* 20020819 choijh add*/
/*			LineGraphEventTbl->Up_SuperVOffset= WatchingDevice(LineGraphEventTbl->cUpperDeviceName, 
											   LineGraphEventTbl->iUpperDeviceNumber, 
			     							   LineGraphEventTbl->i1632BitFlag,
											   LineGraphEventTbl->iUpperRegistNumber,
											   WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
			ScreenTagData[iDispOrder].DevCnt += DeviceDataHed[DeviceCnt].DevCnt*2;
			DeviceCnt++;
		}
			
		/* ���Ѱ��� Device�� ���� ��� */
		if(LineGraphEventTbl->iCaseLoFixedVal == UNCHECKED){		
			DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */
			DeviceDataHed[DeviceCnt].DevName[0] = LineGraphEventTbl->cLowerDeviceName[0];
			DeviceDataHed[DeviceCnt].DevName[1] = LineGraphEventTbl->cLowerDeviceName[1];
			DeviceDataHed[DeviceCnt].DevAddress = LineGraphEventTbl->iLowerDeviceNumber;
			if(LineGraphEventTbl->i1632BitFlag == BIT16){/* 16bit */
				DeviceDataHed[DeviceCnt].DevCnt = 1;				
			}else{/* 32bit */
				DeviceDataHed[DeviceCnt].DevCnt = 2;				
			}
			DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];			
/*			LineGraphEventTbl->iLowerRegistNumber = DeviceCnt;*/
			if(LineGraphEventTbl->i1632BitFlag == BIT16){/* 16bit */				
				iDeviceOffset += 2;
			}else{/* 32bit */				
				iDeviceOffset += 4;
			}

			/* 20020819 choijh add*/
/*			LineGraphEventTbl->Lw_SuperVOffset= WatchingDevice(LineGraphEventTbl->cLowerDeviceName, 
										   LineGraphEventTbl->iLowerDeviceNumber, 
			     						   LineGraphEventTbl->i1632BitFlag,
										   LineGraphEventTbl->iLowerRegistNumber,
										   WORD, DeviceDataHed[DeviceCnt].DevCnt);
*/
			ScreenTagData[iDispOrder].DevCnt += DeviceDataHed[DeviceCnt].DevCnt*2;
			DeviceCnt++;
		}	
		LineGraphDispCnt++;
	}
/*	IventTableCnt++;*/

	return(0);
}

/********************************************************************************/
/* �� �� �� : LineGraphDispWatch												*/
/* ��    �� : Line Graph�±������� ���� ȭ������� ���.						*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 31�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
extern void __MoveTo( int sx, int sy, int Pattern, int Mode );
extern void	__LineToPrn(int ex,int ey,int mode );
void LineGraphDispWatch(int iOrder)
{	
/* 050422	_ST				st[8][50];*/  /*	_ST				st[8][50]; */
	_ST				*st;  /*	_ST				st[8][50]; */
	int				k;
	int				j;
	int				m;
	int				iTemp;
	float			iVSite;
	float			iHSite;
	float			fGap;
	float			fGapPos;
	short			iShapeSize;
	float			*fGapValue;
	float			*fGapSite;
	int				*iDevicePos;
	long			lUpperDevVal;
	long			lLowerDevVal;
	long			lMonitorDevVal;
	unsigned long	ulUpperDevVal;
	unsigned long	ulLowerDevVal;
	unsigned long	ulMonitorDevVal;
	unsigned long	uVNDisplayedVal;
	short			sX,sY,eX,eY;
	short			iCnt;
	short			iMove2type;				/* Moveto �Ұ��ΰ� ���Ұ��ΰ� */
	char			*cMonitorDevVal;
	char			*cBefMonitorDevVal;
	int				ssx;
	int				ssy;
	int				eex;
	int				eey;
	int				idx;
	_LINE_INFO		LineInfo;
	_RECTANGLE_INFO RectInfo;
	_LINEGRAPH_EVENT_TBL*	 LineGraphEventTbl;

/*	LineGraphEventTbl= (_LINEGRAPH_EVENT_TBL*)IventTable[iOrder];*/
	LineGraphEventTbl= (_LINEGRAPH_EVENT_TBL*)TakeMemory(sizeof(_LINEGRAPH_EVENT_TBL));
	DrawLineGraph_Func(1,LineGraphEventTbl,iOrder);

	k			= 0;
	j			= 0;
	m			= 0;
	iTemp		= 0;
	iVSite		= 0;
	iHSite		= 0;
	fGap		= 0;
	fGapPos		= 0;
	iShapeSize	= 0;


	st= (_ST *)TakeMemory(sizeof(_ST));
	fGapValue= (float *)TakeMemory(sizeof(float)*81);
	fGapSite= (float *)TakeMemory(sizeof(float)*81);
	iDevicePos= (int *)TakeMemory(sizeof(int)*51);

	/* Monitor Value toridasi */
	cBefMonitorDevVal= (char *)TakeMemory(LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints*4);
	idx= ScreenTagData[iOrder].DevOrder;
	if(LineGraphEventTbl->i1632BitFlag == BIT16){
		memcpy(cBefMonitorDevVal,&DispDeviceData[idx],LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints*2);
/* 060919		idx= LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints*2; */
		idx += LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints*2;
	}else{
		memcpy(cBefMonitorDevVal,&DispDeviceData[idx],LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints*4);
/* 060919		idx= LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints*4; */
		idx += LineGraphEventTbl->iNumber * LineGraphEventTbl->iPoints*4;
	}
	/* MAX,MIN Value Set */
	if(LineGraphEventTbl->iCaseUpFixedVal == CHECKED){
		lUpperDevVal = LineGraphEventTbl->lUpperFixedData;
	}else{
/*		lUpperDevVal = LineGraphEventTbl->lBefUpperDevVal;*/
		if(LineGraphEventTbl->iSignedFlag == UNSIGNED){
			lUpperDevVal = ChangeChar2Unsinlong(&DispDeviceData[idx],LineGraphEventTbl->i1632BitFlag);
		}else{
			lUpperDevVal = ChangeChar2long(&DispDeviceData[idx],LineGraphEventTbl->i1632BitFlag);
		}
		if(LineGraphEventTbl->iSignedFlag == BCD)
			BCD_TO_BIN(&lUpperDevVal);		/* BCD�� �ٲٴ� �Լ� */
		if(LineGraphEventTbl->i1632BitFlag == BIT16){
			idx += 2;
		}else{
			idx += 4;
		}
	}
	if(LineGraphEventTbl->iCaseLoFixedVal == CHECKED){
		lLowerDevVal = LineGraphEventTbl->lLowerFixedData;
	}else{
/*		lLowerDevVal = LineGraphEventTbl->lBefLowerDevVal;*/
		if(LineGraphEventTbl->iSignedFlag == UNSIGNED){
			lLowerDevVal = ChangeChar2Unsinlong(&DispDeviceData[idx],LineGraphEventTbl->i1632BitFlag);
		}else{
			lLowerDevVal = ChangeChar2long(&DispDeviceData[idx],LineGraphEventTbl->i1632BitFlag);
		}
		if(LineGraphEventTbl->iSignedFlag == BCD)
			BCD_TO_BIN(&lLowerDevVal);		/* BCD�� �ٲٴ� �Լ� */
		if(LineGraphEventTbl->i1632BitFlag == BIT16){
			idx += 2;
		}else{
			idx += 4;
		}
	}

	sX = ScreenTagData[iOrder].sX;
	sY = ScreenTagData[iOrder].sY;
	eX = ScreenTagData[iOrder].eX;
	eY = ScreenTagData[iOrder].eY;

	/* Shape Draw */
	if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){
		iShapeSize = DrawShape(LineGraphEventTbl->ShapeNo, 
			(sX -4), 
			sY, 
			eX, 
			(eY + 4),
			LineGraphEventTbl->iFrameColor,
			LineGraphEventTbl->iPlateColor);
		sX += iShapeSize;
		sY += iShapeSize;
		eX -= iShapeSize;
		eY -= iShapeSize;

	}
	/* Scale Draw	*/
	if(LineGraphEventTbl->iScaleDispChecked == CHECKED){			
		iVSite = (float)(eY - sY)/(LineGraphEventTbl->iScalePointsV-1);
		iHSite = (float)(eX - sX)/(LineGraphEventTbl->iScalePointsH-1);
		
		iTemp = eY;
		LineInfo.iLineColor = LineGraphEventTbl->iScaleColor;
		LineInfo.iLineStyle = SOLID_LINE;

		for(k=1;k<LineGraphEventTbl->iScalePointsV;k++){
			LineOut(sX - 4, iTemp, sX, iTemp, &LineInfo);
			iTemp = (int)(eY - (iVSite * k));
		}
		LineOut(sX - 4, sY, sX, sY, &LineInfo);

		iTemp = sX;
		for(k=1;k<LineGraphEventTbl->iScalePointsH;k++){
			LineOut(iTemp, eY + 4, iTemp, eY, &LineInfo);
			iTemp = (int)(sX + (iHSite * k));
		}
		LineOut(eX, eY + 4, eX, eY, &LineInfo);
	}
	/*	Frame Draw				
	if(LineGraphEventTbl->iFrameChecked ==  CHECKED)
	{
		RectInfo.iLineStyle = SOLID_LINE;
		RectInfo.iLineColor = WHITE;
		RectInfo.iPattern	= PAT0;
		RectInfo.iForeColor = BLACK;
		RectInfo.iBackColor = BLACK;
			
		RectAngleOut(sX,
			sY,
			eX,
			eY,
			&RectInfo);
	}*/
/* ----------------- */
		/* ��ǥ�� �����ϱ� ���� ����ġ�� ����ġ������ ��ǥ���� ���Ѵ�. */
	/* Data Format Setting		*/
/*
	if(strlen(LineGraphEventTbl->cDeviceName))
	{
*/
/*lsi20040529 ���� */
	if(strlen(LineGraphEventTbl->cDeviceName) && !(LineGraphEventTbl->iSignedFlag == BCD && (lLowerDevVal < 0 || lUpperDevVal < 0)))
	{
/*lsi20040529*/
		if((LineGraphEventTbl->i1632BitFlag != 0) && (LineGraphEventTbl->iSignedFlag == UNSIGNED)){
			ulUpperDevVal= lUpperDevVal;
			ulLowerDevVal= lLowerDevVal;
			fGap  = (float)((float)ulUpperDevVal - (float)ulLowerDevVal)/80;
		}else{
			fGap  = (float)((float)lUpperDevVal - (float)lLowerDevVal)/80;
		}
/* 050422		fGapPos = (float)(eY - sY - 1)/80;*/
		fGapPos = (float)(eY - sY)/80;
			
		for(k=0;k<=80;k++){
			fGapValue[k] = lLowerDevVal + (fGap * k);
			fGapSite[k] = eY - (fGapPos * k);
		}
		fGapValue[80] = (float)lUpperDevVal;
		if(sY==0)
			fGapSite[80] = 1;
		else
			fGapSite[80] = sY;
		iHSite = (float)(eX - sX)/(LineGraphEventTbl->iPoints-1);
		if(LineGraphEventTbl->iDirecition == RIGHT)
		{
			for(k=0;k<LineGraphEventTbl->iPoints;k++){
				iDevicePos[k] = (int)(sX + iHSite * k + 0.5);
			}
		}
		else if(LineGraphEventTbl->iDirecition == LEFT)
		{
			for(k=0;k<LineGraphEventTbl->iPoints;k++){
				iDevicePos[k] = (int)(eX - iHSite * k + 0.5);
			}
		}

		/* �ٽ� ������ ���鼭 ������ ����̽� ���� ���� ��ȭ�ϴ� ��ǥ�� ������ ����. */
		iTemp = 0;
		iCnt = 0;
		cMonitorDevVal = (char*)TakeMemory(5);			/* Char Data change extra buffer */

		/*** Darw Point Set ***/
		for(m=0;m<LineGraphEventTbl->iNumber;m++)
		{
			for(j=0;j<LineGraphEventTbl->iPoints;j++)
			{
/*				iCnt = iTemp*(LineGraphEventTbl->i1632BitFlag*2+2);*/	/* Data Positoin */
				iCnt = iTemp*((LineGraphEventTbl->i1632BitFlag+1)*2);	/* Data Positoin */
				memset(cMonitorDevVal,0x00,5);
/*				memcpy(cMonitorDevVal, LineGraphEventTbl->cBefMonitorDevVal+iCnt,(LineGraphEventTbl->i1632BitFlag*2+2));*/
				memcpy(cMonitorDevVal, cBefMonitorDevVal+iCnt,((LineGraphEventTbl->i1632BitFlag+1)*2));

				if((LineGraphEventTbl->i1632BitFlag != 0) && (LineGraphEventTbl->iSignedFlag == UNSIGNED)){		/* V202 u32 */
					ulMonitorDevVal= ChangeChar2Unsinlong(cMonitorDevVal,LineGraphEventTbl->i1632BitFlag);
					uVNDisplayedVal= LineGraphEventTbl->VNDisplayedVal;
					if(ulUpperDevVal < ulMonitorDevVal ||
					   ulLowerDevVal > ulMonitorDevVal ||
					   (LineGraphEventTbl->IsChkVNDisplayed == CHECKED &&
					   uVNDisplayedVal == ulMonitorDevVal))
					{
						st->st_data[m][j].iPosY = -1;
						st->st_data[m][j].iPosX = -1;
						iTemp++;
						continue;
					}
				}else{
					if(LineGraphEventTbl->iSignedFlag == UNSIGNED)	/* unsigned Type	*/
						lMonitorDevVal= ChangeChar2Unsinlong(cMonitorDevVal,LineGraphEventTbl->i1632BitFlag);
					else														
					{												/* signed Type		*/	
						lMonitorDevVal= ChangeChar2long(cMonitorDevVal,LineGraphEventTbl->i1632BitFlag);

						if(LineGraphEventTbl->iSignedFlag == BCD)	/* BCD Type			*/
							BCD_TO_BIN(&(lMonitorDevVal));		/* BCD Change Function */
					}
					if(lUpperDevVal < lMonitorDevVal ||
					   lLowerDevVal > lMonitorDevVal ||
					   (LineGraphEventTbl->IsChkVNDisplayed == CHECKED &&
					   LineGraphEventTbl->VNDisplayedVal == lMonitorDevVal))
					{
						st->st_data[m][j].iPosY = -1;
						st->st_data[m][j].iPosX = -1;
						iTemp++;
						continue;
					}
				}
				for(k=0;k<81;k++)
				{
					if((LineGraphEventTbl->i1632BitFlag != 0) && (LineGraphEventTbl->iSignedFlag == UNSIGNED)){		/* V202 u32 */
						if(fGapValue[k] >= ulMonitorDevVal)
						{
							st->st_data[m][j].iPosY = (int)(fGapSite[k]+ 0.5);
							st->st_data[m][j].iPosX = iDevicePos[j];
							break;
						}
					}else{
						if(fGapValue[k] >= lMonitorDevVal)
						{
							st->st_data[m][j].iPosY = (int)(fGapSite[k]+ 0.5);
							st->st_data[m][j].iPosX = iDevicePos[j];
							break;
						}
					}
				}
				iTemp++;
			}				
		}
		FreeMail((char*)cMonitorDevVal);
/*--------------------------*/
		/* Line Graph Data Draw	*/
		for(m=0;m<LineGraphEventTbl->iNumber;m++){
			k = 0;
			iTemp = 0;
			iMove2type = 1;
			SetDispSema();
			while(k < LineGraphEventTbl->iPoints - 1){
				LineInfo.iLineColor = LineGraphEventTbl->lf[m].iLineColor;
				LineInfo.iLineStyle = LineGraphEventTbl->lf[m].iLineType;	/* 1:�Ǽ� 2:�ļ� 3:���� 4:�����⼱ 5:�����⼱ */

				if((st->st_data[m][k].iPosX != -1 && st->st_data[m][k].iPosY != -1) && (st->st_data[m][k+1].iPosX != -1 && st->st_data[m][k+1].iPosY != -1)){
/*********************************************/
					if(TateYoko == 0){
						ssx= st->st_data[m][k].iPosX;
						ssy= st->st_data[m][k].iPosY;
						eex= st->st_data[m][k+1].iPosX;
						eey= st->st_data[m][k+1].iPosY;

					}else{
						ssx= st->st_data[m][k].iPosY;
						ssy= (GAMEN_Y_SIZE-1) - st->st_data[m][k].iPosX;
						eex= st->st_data[m][k+1].iPosY;
						eey= (GAMEN_Y_SIZE-1) - st->st_data[m][k+1].iPosX;
					}
/*********************************************/
					if(iMove2type == 1)
					{
						LineBit = 0;
						if(LineInfo.iLineColor == 0){
							DrawColor = LineInfo.iLineColor;
						}else{
							DrawColor = 3;
						}
						__MoveTo(ssx, ssy, LineInfo.iLineStyle, 0 );
					}
					__LineToPrn(eex, eey,1);
					if(LineInfo.iLineStyle == 1){		/* 051213 Owashi */
						__MoveTo(eex, eey, LineInfo.iLineStyle, 0 );
					}
				/*	LineOut(st[m][k].iPosX, st[m][k].iPosY, st[m][k+1].iPosX, st[m][k+1].iPosY,&LineInfo);  lee 040610*/
					iMove2type = 0;
				}else
					iMove2type = 1;
				k++;
			}
			ResetDispSema();
		}
	}
	/*	Frame Draw		*/		
	if(LineGraphEventTbl->iFrameChecked ==  CHECKED)
	{
		RectInfo.iLineStyle = SOLID_LINE;
		RectInfo.iLineColor = WHITE;
		RectInfo.iPattern	= PAT0;
		RectInfo.iForeColor = BLACK;
		RectInfo.iBackColor = BLACK;
			
		RectAngleOut(sX,
			sY,
			eX,
			eY,
			&RectInfo);
	}
	FreeMail((char *)cBefMonitorDevVal);		/* 060920 */
	FreeMail((char *)st);
	FreeMail((char *)fGapValue);
	FreeMail((char *)fGapSite);
	FreeMail((char *)iDevicePos);

	FreeMail((char *)LineGraphEventTbl);

/* ----------------- */
}
