void	SetTrendGraph_Func(int iDispOrder);
int	DrawTrendGraph_Func(int mode,_TRENDGRAPH_EVENT_TBL* TrendGraphEventTbl,int iDispOrder);
void TrendGraphDispWatch(int iOrder);
