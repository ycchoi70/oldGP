//extern Inst_Len_Rtn Inst_Len_Rtn_Table[13][] ;
extern Inst_Len_Rtn *Inst_Len_Rtn_Table_Pointer[];

extern unsigned short int	Inst_Operand_Area[] ;  /* LOAD AREA */
extern Inst_Table		Inst_Point_Table[] ;

extern int Load_Count ;
extern int Instruction_Count ;
extern int Label_Count ;
extern int Line_Count ;

extern int  Current_Stack_Addr ;       /* ���݂�Stack Address */

extern Inst_Ope_Label Inst_Ope_Label_Table[] ;     /* Label �ݒ�@Area */
extern Ladder_Line Ladder_Line_Table[] ;
extern Loads_In_Ladder_Line Loads_In_Ladder_Line_Table;

extern unsigned short int Current_Instruction ;
extern int Current_Addr ;
extern int Current_Number;
extern int Current_Operand_Leng ;
extern int Current_Line_Number ;
extern int Current_Instruction_Number ;
extern int Current_Load_Number ;

extern unsigned short int Current_Instruction ;


extern unsigned short int X[] ;  /* ���̓����[ */
extern unsigned short int Y[] ;  /* �o�̓����[ */
extern unsigned short int M[] ;

extern Device_Bit_Operation X_Device_Bit_Operation_Table[] ; 

extern bool LOAD_Bool ;
extern bool AND_Bool ;
extern bool OR_Bool ;

extern bool ORL_Bool ;
extern bool ANDL_Bool ;
extern bool OUT_Bool ;
