/* ****************************************************************************** */
/*  �� �� �� : GP_SETUPMODE.CPP													 */
/*  ��    �� : ����ȯ�漳�� �޴�													 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */

#include	"sgt.h"

/* *******************************************************************************/
/*  �Լ� ������ Ÿ�� ����														 */
/* *******************************************************************************/

/* *******************************************************************************/
/*  �Լ�																		 */
/* *******************************************************************************/

/* ****************************************************************************** */
/*  �� �� �� : SetEnvironmentMode()												 */
/*  ��    �� : ȯ�漳�� ���� ����Ʈ.											 */
/*  ��    �� : iScreenNo(���� ȭ�� ��ȣ)										 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 6�� 27�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#ifdef	GP_S044
void	SetEnvironmentMode(int *iScreenNo){

	int			iKeyCode;
	int			iSetFlag; 
	int			iflag;
	short		iSetFlag2;
	short		i;
	short		j;
	short		ScreenNum;
	short		iLineData;
	short		iLen;
	short		iNowSecTime;
	char		*LineDataBuffer;
	char		CopyData[10];
	char		*ListData1;

	iSetFlag2   = 1;
	iSetFlag	= 1;
	iLineData	= 0;
	/**************************/
	RepeatInfo.EntryCnt = 2;
	RepeatInfo.RepeatNo[0][0] = (char)KEY_29;
	RepeatInfo.RepeatNo[0][1] = (char)KEY_30;
	RepeatInfo.RepeatNo[1][0] = (char)KEY_59;
	RepeatInfo.RepeatNo[1][1] = (char)KEY_60;
	/**************************/
	ScreenNum = SET_ENVIRONMENT_NUM * 100;

	LineDataBuffer = TakeMemory(30);
	memset(LineDataBuffer,0x00,30);
	ListData1 = TakeMemory(30);
	memset(ListData1,0x00,30);

	KerRepeatFlag = 1;	/* 040815 */

#define		SCROLL_MAX	11		//20091222

	while ( *iScreenNo == SET_ENVIRONMENT_NUM) {
		if(iSetFlag == 2)
			AreaClear(0,0,GAMEN_X_SIZE-1,GAMEN_Y_SIZE-1,0);
		else
			i = 0;
		DefaultFormDisplay(4 , Dspname[SET_ENVIRONMENT].chTitle[Set.iLang]);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	
		iKeyCode = -1;
		while (iKeyCode == -1 || iKeyCode == 0) {
			if((iSetFlag == 1) || ((i>=0 && i<=2) && (SystemTime.sec != iNowSecTime)) || (iSetFlag == 2))
			{
				AreaClear(GAMEN_START_X+0,GAMEN_START_Y+23,GAMEN_START_X+197,GAMEN_START_Y+79,0);
				for(j=0;j<3;j++)
				{	
					iLineData = (NLine_2+(j*18));
					
					if((i+j) == 2)			/* Clock	*/
					{
						memset(LineDataBuffer,0x00,30);
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);
						sprintf(LineDataBuffer,"%s [%d:%02d:%02d]",ListData1,SystemTime.hour,SystemTime.min,SystemTime.sec);
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);
						iNowSecTime = SystemTime.sec;
					}else if((i+j) == 5)	/* Buzzer	*/
					{
						memset(LineDataBuffer,0x00,30);	
						memset(CopyData,0x00,sizeof(CopyData));
						sprintf(CopyData,Dspname[BUZZER].chName[Set.iLang][Set.iBuzzer+2]);
						Last_SP_Del(CopyData);
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);
						sprintf(LineDataBuffer,"%s [%s]",ListData1,CopyData);
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);		
					}else if((i+j) == 6)	/* Openning */
					{
						memset(LineDataBuffer,0x00,30);	
						memset(CopyData,0x00,sizeof(CopyData));
						sprintf(CopyData,Dspname[OPENNING].chName[Set.iLang][1]);
						Last_SP_Del(CopyData);
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);
						sprintf(LineDataBuffer,"%s [%d%s]",ListData1,Set.iTitleDispTime,CopyData);
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);		
					}else if((i+j) == 7)	/* BackLight */
					{
						memset(LineDataBuffer,0x00,30);	
						memset(CopyData,0x00,sizeof(CopyData));
						sprintf(CopyData,Dspname[BACKLIGHT].chName[Set.iLang][1]);
						Last_SP_Del(CopyData);
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);
						sprintf(LineDataBuffer,"%s [%d%s]",ListData1,Set.iBackLightTime,CopyData);
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);		
					}else if((i+j) == 8)	/* Battery	*/
					{
/*
						iLen = (int)((CommonArea.BatteryLevel*100)/1024);
						memset(LineDataBuffer,0x00,30);	
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);
						sprintf(LineDataBuffer,"%s [%d%%]",ListData1,iLen);
						DotTextOut(4,iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);		
*/

/*ksc20040508*/
						memset(LineDataBuffer,0x00,30);	
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);

						if(CommonArea.BatteryLevel>=BATT_MAX_REVEL)	
						{
							iLen=100;
							sprintf(LineDataBuffer,"%s [%d%%]",ListData1,iLen);
							DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);
						}
						else if((BATT_MIN_REVEL < CommonArea.BatteryLevel) && (CommonArea.BatteryLevel< BATT_MAX_REVEL))
						{
							iLen = (int)(((CommonArea.BatteryLevel-BATT_MIN_REVEL)*100)/(BATT_MAX_REVEL- BATT_MIN_REVEL));
							sprintf(LineDataBuffer,"%s [%d%%]",ListData1,iLen);
							DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);
						}
						else
						{
							iLen=0;
							sprintf(LineDataBuffer,"%s [Bat Low]",ListData1);
							DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);
						}
/*ksc20040508*/					
/* 20091222 */					
					}else if((i+j) == 10)	/* UW Backup Set	*/
					{
						memset(LineDataBuffer,0x00,30);	
						memset(CopyData,0x00,sizeof(CopyData));
						sprintf(CopyData,Dspname[UWLATCH].chName[Set.iLang][Set.iuwLatch+2]);
						Last_SP_Del(CopyData);
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);
						sprintf(LineDataBuffer,"%s [%s]",ListData1,CopyData);
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);							
					
					}else 
					{
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,(Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]),1,1, TRANS, T_WHITE, T_BLACK);	
					}
				}
				ScroolBarDisplay(SCROLL_MAX, i);
				DrawLcdBank1();	
				iSetFlag = 0;
			}
			if(iSetFlag2 == 1)
			{
				KeyWaitData(30,0xffff);
				iSetFlag2 = 0;
			}
			/* leesi 040612 iKeyCode = KeyAccept();	*/							/* �Էµ� Ű���� �о��	 */
			iKeyCode = iKeyAcceptReturn(SET_ENVIRONMENT_NUM);

/*			if(!((iKeyCode >= KEY_03 && iKeyCode <= KEY_12 ) ||
				 iKeyCode == KEY_28 || iKeyCode == KEY_43 || 
				 iKeyCode == KEY_44 || iKeyCode == KEY_45 ||
				 iKeyCode == KEY_58 || iKeyCode == 0 || iKeyCode == -1 ))
			{
				iKeyFlag = 1;
				NormalBuzzer();											Buzzer			
			}
*/
/*ksc20040509  */ /* ��ġŰ ���� ���� */
			if(!((iKeyCode >= KEY_03 && iKeyCode <= KEY_12 ) ||
				 iKeyCode == KEY_44 || iKeyCode == KEY_45 ||
				 iKeyCode == 0 || iKeyCode == -1 ))
			{
				NormalBuzzer();										/*	Buzzer			*/
			}
/*ksc20040509  */

			if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
			{												
				*iScreenNo = DOWN_TRANS;
				break;
			}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
			{
				*iScreenNo = UP_TRANS;
				break;
			}
			/* Ű ���� ó�� */		
			if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02)
			{
				*iScreenNo = USER_SCREEN_NUM;	
			}else if(iKeyCode >= KEY_13 && iKeyCode <= KEY_15) 
			{									/*  ����, ���� ��ưŬ���� */						
				*iScreenNo = SELECT_MEMU_NUM;	
			} else if (iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ) 
			{
				iflag = iSysSetretCheck(ScreenNum + i);
				if(iflag == DOWN_TRANS)		/* DownLoad */
					*iScreenNo = DOWN_TRANS;
				else if(iflag == UP_TRANS)	/* UPLoad */
					*iScreenNo = UP_TRANS;
				else if(iflag == 0)			/* ȭ���̵� ó�� */
					if(i >= 1){
						*iScreenNo = ScreenNum + i+ 1;										/*  ȭ�����			 */
					}else{
						*iScreenNo = ScreenNum + i;										/*  ȭ�����			 */
					}
				else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = SET_ENVIRONMENT_NUM;
					iSetFlag = 2;
					break;
				}
			} else if (iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ) 
			{
				iflag = iSysSetretCheck(ScreenNum + 1 + i);
				if(iflag == DOWN_TRANS)		/* DownLoad */
					*iScreenNo = DOWN_TRANS;
				else if(iflag == UP_TRANS)	/* UPLoad */
					*iScreenNo = UP_TRANS;
				else if(iflag == 0)			/* ȭ���̵� ó�� */
					*iScreenNo = ScreenNum + 1 + i+ 1;										/*  ȭ�����			 */
				else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = SET_ENVIRONMENT_NUM;
					iSetFlag = 2;
					break;
				}
			} else if (iKeyCode >= KEY_46 && iKeyCode <= KEY_57 ) 
			{
				iflag = iSysSetretCheck(ScreenNum + 2 + i);
				if(iflag == DOWN_TRANS)		/* DownLoad */
					*iScreenNo = DOWN_TRANS;
				else if(iflag == UP_TRANS)	/* UPLoad */
					*iScreenNo = UP_TRANS;
				else if(iflag == 0)			/* ȭ���̵� ó�� */
					*iScreenNo = ScreenNum + 2 + i+ 1;										/*  ȭ�����			 */
				else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = SET_ENVIRONMENT_NUM;
					iSetFlag = 2;
					break;
				}
			} else if (iKeyCode >= KEY_59 && iKeyCode <= KEY_60 ) 
			{
				if(i < (SCROLL_MAX-3)){
					iSetFlag = 1;
					i++;												/*  �޴� ���� ����		  */	
				}						
				KerRepeatFlag = 1;	/*ksc20040726 ���� �ٲ�  */
				iKeyCode = -1;
				
			} else if (iKeyCode >= KEY_29 && iKeyCode <= KEY_30 ) 
			{
				if(i > 0){
					iSetFlag = 1;
					i--;												/*  �޴� ���� �ø�		  */	
				}						
				iKeyCode = -1;
				KerRepeatFlag = 1;	/*ksc20040726 ���� �ٲ�  */

/*ksc20040509  */
			}else if(iKeyCode == KEY_28)  /* ó  �� */ /************************************************************/
			{
				iSetFlag = 1;
				i = 0;
				iKeyCode = -1;
/*ksc20040726*/ /* ���̽� ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */ /* ���� �ٲ�  */
/*			KerRepeatFlag = 1;  */
/*ksc20040726*/	

			}else if(iKeyCode == KEY_43)  /* ��  �� */
			{
				iSetFlag = 1;
				i = (SCROLL_MAX-3)/2;
				iKeyCode = -1;
/*ksc20040726*/ /* ���̽� ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */ /* ���� �ٲ�  */
/*			KerRepeatFlag = 1;  */
/*ksc20040726*/

			}else if(iKeyCode == KEY_58)  /* ������ */
			{
				iSetFlag = 1;
				i = (SCROLL_MAX-3);
				iKeyCode = -1;
/*ksc20040726*/ /* ���̽� ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */ /* ���� �ٲ�  */
/*			KerRepeatFlag = 1;  */
/*ksc20040726*/
/*ksc20040509	*/


			}else{
				iKeyCode = -1;
			} 	
			Delay(50);
		} 	
	} 
	FreeMail(LineDataBuffer);
	FreeMail(ListData1);
	KerRepeatFlag = 0;
	memset(&RepeatInfo,0x00,sizeof(RepeatInfo));
	return;
}
#endif

#ifdef	LP_S044
void	SetEnvironmentMode(int *iScreenNo){

	int			iKeyCode;
	int			iSetFlag; 
	int			iflag;
	short		iSetFlag2;
	short		i;
	short		j;
	short		ScreenNum;
	short		iLineData;
	short		iLen;
	short		iNowSecTime;
	char		*LineDataBuffer;
	char		CopyData[10];
	char		*ListData1;

	iSetFlag2   = 1;
	iSetFlag	= 1;
	iLineData	= 0;
	/**************************/
	RepeatInfo.EntryCnt = 2;
	RepeatInfo.RepeatNo[0][0] = (char)KEY_29;
	RepeatInfo.RepeatNo[0][1] = (char)KEY_30;
	RepeatInfo.RepeatNo[1][0] = (char)KEY_59;
	RepeatInfo.RepeatNo[1][1] = (char)KEY_60;
	/**************************/
	ScreenNum = SET_ENVIRONMENT_NUM * 100;

	LineDataBuffer = TakeMemory(30);
	memset(LineDataBuffer,0x00,30);
	ListData1 = TakeMemory(30);
	memset(ListData1,0x00,30);

	KerRepeatFlag = 1;	/* 040815 */

#define		SCROLL_MAX	10		//20091222

	while ( *iScreenNo == SET_ENVIRONMENT_NUM) {
		if(iSetFlag == 2)
			AreaClear(0,0,GAMEN_X_SIZE-1,GAMEN_Y_SIZE-1,0);
		else
			i = 0;
		DefaultFormDisplay(4 , Dspname[SET_ENVIRONMENT].chTitle[Set.iLang]);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	
		iKeyCode = -1;
		while (iKeyCode == -1 || iKeyCode == 0) {
			if((iSetFlag == 1) || ((i>=0 && i<=2) && (SystemTime.sec != iNowSecTime)) || (iSetFlag == 2))
			{
				AreaClear(GAMEN_START_X+0,GAMEN_START_Y+23,GAMEN_START_X+197,GAMEN_START_Y+79,0);
				for(j=0;j<3;j++)
				{	
					iLineData = (NLine_2+(j*18));
					
					if((i+j) == 2)			/* Clock	*/
					{
						memset(LineDataBuffer,0x00,30);
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);
						sprintf(LineDataBuffer,"%s [%d:%02d:%02d]",ListData1,SystemTime.hour,SystemTime.min,SystemTime.sec);
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);
						iNowSecTime = SystemTime.sec;
					}else if((i+j) == 5)	/* Buzzer	*/
					{
						memset(LineDataBuffer,0x00,30);	
						memset(CopyData,0x00,sizeof(CopyData));
						sprintf(CopyData,Dspname[BUZZER].chName[Set.iLang][Set.iBuzzer+2]);
						Last_SP_Del(CopyData);
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);
						sprintf(LineDataBuffer,"%s [%s]",ListData1,CopyData);
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);		
					}else if((i+j) == 6)	/* Openning */
					{
						memset(LineDataBuffer,0x00,30);	
						memset(CopyData,0x00,sizeof(CopyData));
						sprintf(CopyData,Dspname[OPENNING].chName[Set.iLang][1]);
						Last_SP_Del(CopyData);
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);
						sprintf(LineDataBuffer,"%s [%d%s]",ListData1,Set.iTitleDispTime,CopyData);
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);		
					}else if((i+j) == 7)	/* BackLight */
					{
						memset(LineDataBuffer,0x00,30);	
						memset(CopyData,0x00,sizeof(CopyData));
						sprintf(CopyData,Dspname[BACKLIGHT].chName[Set.iLang][1]);
						Last_SP_Del(CopyData);
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);
						sprintf(LineDataBuffer,"%s [%d%s]",ListData1,Set.iBackLightTime,CopyData);
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);		
					}else if((i+j) == 8)	/* Battery	*/
					{
/*
						iLen = (int)((CommonArea.BatteryLevel*100)/1024);
						memset(LineDataBuffer,0x00,30);	
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);
						sprintf(LineDataBuffer,"%s [%d%%]",ListData1,iLen);
						DotTextOut(4,iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);		
*/

/*ksc20040508*/
						memset(LineDataBuffer,0x00,30);	
						sprintf(ListData1,Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]);
						Last_SP_Del(ListData1);

						if(CommonArea.BatteryLevel>=BATT_MAX_REVEL)	
						{
							iLen=100;
							sprintf(LineDataBuffer,"%s [%d%%]",ListData1,iLen);
							DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);
						}
						else if((BATT_MIN_REVEL < CommonArea.BatteryLevel) && (CommonArea.BatteryLevel< BATT_MAX_REVEL))
						{
							iLen = (int)(((CommonArea.BatteryLevel-BATT_MIN_REVEL)*100)/(BATT_MAX_REVEL- BATT_MIN_REVEL));
							sprintf(LineDataBuffer,"%s [%d%%]",ListData1,iLen);
							DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);
						}
						else
						{
							iLen=0;
							sprintf(LineDataBuffer,"%s [Bat Low]",ListData1);
							DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);
						}
/*ksc20040508*/					
/* 20091222 */					
					}else 
					{
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+iLineData,(Dspname[SET_ENVIRONMENT].chName[Set.iLang][i+j]),1,1, TRANS, T_WHITE, T_BLACK);	
					}
				}
				ScroolBarDisplay(SCROLL_MAX, i);
				DrawLcdBank1();	
				iSetFlag = 0;
			}
			if(iSetFlag2 == 1)
			{
				KeyWaitData(30,0xffff);
				iSetFlag2 = 0;
			}
			/* leesi 040612 iKeyCode = KeyAccept();	*/							/* �Էµ� Ű���� �о��	 */
			iKeyCode = iKeyAcceptReturn(SET_ENVIRONMENT_NUM);

/*			if(!((iKeyCode >= KEY_03 && iKeyCode <= KEY_12 ) ||
				 iKeyCode == KEY_28 || iKeyCode == KEY_43 || 
				 iKeyCode == KEY_44 || iKeyCode == KEY_45 ||
				 iKeyCode == KEY_58 || iKeyCode == 0 || iKeyCode == -1 ))
			{
				iKeyFlag = 1;
				NormalBuzzer();											Buzzer			
			}
*/
/*ksc20040509  */ /* ��ġŰ ���� ���� */
			if(!((iKeyCode >= KEY_03 && iKeyCode <= KEY_12 ) ||
				 iKeyCode == KEY_44 || iKeyCode == KEY_45 ||
				 iKeyCode == 0 || iKeyCode == -1 ))
			{
				NormalBuzzer();										/*	Buzzer			*/
			}
/*ksc20040509  */

			if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
			{												
				*iScreenNo = DOWN_TRANS;
				break;
			}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
			{
				*iScreenNo = UP_TRANS;
				break;
			}
			/* Ű ���� ó�� */		
			if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02)
			{
				*iScreenNo = USER_SCREEN_NUM;	
			}else if(iKeyCode >= KEY_13 && iKeyCode <= KEY_15) 
			{									/*  ����, ���� ��ưŬ���� */						
				*iScreenNo = SELECT_MEMU_NUM;	
			} else if (iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ) 
			{
				iflag = iSysSetretCheck(ScreenNum + i);
				if(iflag == DOWN_TRANS)		/* DownLoad */
					*iScreenNo = DOWN_TRANS;
				else if(iflag == UP_TRANS)	/* UPLoad */
					*iScreenNo = UP_TRANS;
				else if(iflag == 0)			/* ȭ���̵� ó�� */
					if(i >= 1){
						*iScreenNo = ScreenNum + i+ 1;										/*  ȭ�����			 */
					}else{
						*iScreenNo = ScreenNum + i;										/*  ȭ�����			 */
					}
				else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = SET_ENVIRONMENT_NUM;
					iSetFlag = 2;
					break;
				}
			} else if (iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ) 
			{
				iflag = iSysSetretCheck(ScreenNum + 1 + i);
				if(iflag == DOWN_TRANS)		/* DownLoad */
					*iScreenNo = DOWN_TRANS;
				else if(iflag == UP_TRANS)	/* UPLoad */
					*iScreenNo = UP_TRANS;
				else if(iflag == 0)			/* ȭ���̵� ó�� */
					*iScreenNo = ScreenNum + 1 + i+ 1;										/*  ȭ�����			 */
				else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = SET_ENVIRONMENT_NUM;
					iSetFlag = 2;
					break;
				}
			} else if (iKeyCode >= KEY_46 && iKeyCode <= KEY_57 ) 
			{
				iflag = iSysSetretCheck(ScreenNum + 2 + i);
				if(iflag == DOWN_TRANS)		/* DownLoad */
					*iScreenNo = DOWN_TRANS;
				else if(iflag == UP_TRANS)	/* UPLoad */
					*iScreenNo = UP_TRANS;
				else if(iflag == 0)			/* ȭ���̵� ó�� */
					*iScreenNo = ScreenNum + 2 + i+ 1;										/*  ȭ�����			 */
				else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = SET_ENVIRONMENT_NUM;
					iSetFlag = 2;
					break;
				}
			} else if (iKeyCode >= KEY_59 && iKeyCode <= KEY_60 ) 
			{
				if(i < (SCROLL_MAX-3)){
					iSetFlag = 1;
					i++;												/*  �޴� ���� ����		  */	
				}						
				KerRepeatFlag = 1;	/*ksc20040726 ���� �ٲ�  */
				iKeyCode = -1;
				
			} else if (iKeyCode >= KEY_29 && iKeyCode <= KEY_30 ) 
			{
				if(i > 0){
					iSetFlag = 1;
					i--;												/*  �޴� ���� �ø�		  */	
				}						
				iKeyCode = -1;
				KerRepeatFlag = 1;	/*ksc20040726 ���� �ٲ�  */

/*ksc20040509  */
			}else if(iKeyCode == KEY_28)  /* ó  �� */ /************************************************************/
			{
				iSetFlag = 1;
				i = 0;
				iKeyCode = -1;
/*ksc20040726*/ /* ���̽� ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */ /* ���� �ٲ�  */
/*			KerRepeatFlag = 1;  */
/*ksc20040726*/	

			}else if(iKeyCode == KEY_43)  /* ��  �� */
			{
				iSetFlag = 1;
				i = (SCROLL_MAX-3)/2;
				iKeyCode = -1;
/*ksc20040726*/ /* ���̽� ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */ /* ���� �ٲ�  */
/*			KerRepeatFlag = 1;  */
/*ksc20040726*/

			}else if(iKeyCode == KEY_58)  /* ������ */
			{
				iSetFlag = 1;
				i = (SCROLL_MAX-3);
				iKeyCode = -1;
/*ksc20040726*/ /* ���̽� ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */ /* ���� �ٲ�  */
/*			KerRepeatFlag = 1;  */
/*ksc20040726*/
/*ksc20040509	*/


			}else{
				iKeyCode = -1;
			} 	
			Delay(50);
		} 	
	} 
	FreeMail(LineDataBuffer);
	FreeMail(ListData1);
	KerRepeatFlag = 0;
	memset(&RepeatInfo,0x00,sizeof(RepeatInfo));
	return;
}
#endif 
