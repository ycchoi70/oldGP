#include	"Mts.h"
#include    "MtsMiscP.h"
#include    "stdio.h"

extern	void    Lcdprintf( int Line, int Column, char* pFrm, ... );
extern	void	DrawLcdBank1(void);
extern	void	SetWindowNo(int WinNo);

void SystemError( void )
{
	DrawLcdBank1();
	for(;;){}
}

STTFrm*     GetpSTT( int TaskNo )
{
    STTFrm* pSTT;
    
    for( pSTT= _StaticTaskTableUsr; pSTT->Entry != 0; pSTT++ ) {
        if ( pSTT->TaskNo == TaskNo ) { return pSTT; }
    }
    for( pSTT= _StaticTaskTableSys; pSTT->Entry != 0; pSTT++ ) {
        if ( pSTT->TaskNo == TaskNo ) { return pSTT; }
    }
    return (STTFrm*)0;
}
void SystemLoop( void )
{
	for(;;){}
}

void            _SysErrorReturn( void )
{
    STTFrm  *pSTT;
    
	SetWindowNo(1);
    pSTT= GetpSTT( _RunTaskNo );
    Lcdprintf( 0, 0, "RETURN FROM TASKMAIN",0,0,0,0 );
    Lcdprintf( 1, 0, "TASK NAME= [%s]", pSTT->Name,0,0,0 );
/*    SystemLoop();		*/
	SystemError();
}

void            _SysErrorMailAddress( unsigned MbxNo, char* pMail )
{
    STTFrm  *pSTT;
    
	SetWindowNo(1);
    pSTT= GetpSTT( _RunTaskNo );
    Lcdprintf( 0, 0, "ERROR MAIL ADDRESS.",0,0,0,0 );
    Lcdprintf( 1, 0, "TASK NAME= [%s]", pSTT->Name,0,0,0 );
    Lcdprintf( 2, 0, "MAILBOXNO=       [%02x]", MbxNo,0,0,0 );
    Lcdprintf( 3, 0, "MAILADRS.= [%08x]", pMail,0,0,0 );
/*    SystemLoop();		*/
	SystemError();
}

void            _SysErrorMbxNo( unsigned MbxNo, char* pMail )
{
    STTFrm  *pSTT;
    
	SetWindowNo(1);
    pSTT= GetpSTT( _RunTaskNo );
    Lcdprintf( 0, 0, "ERROR MBX NUMBER.",0,0,0,0 );
    Lcdprintf( 1, 0, "TASK NAME= [%s]", pSTT->Name,0,0,0 );
    Lcdprintf( 2, 0, "MAILBOXNO=       [%02x]", MbxNo,0,0,0 );
    Lcdprintf( 3, 0, "MAILADRS.= [%08x]", pMail,0,0,0 );
/*    SystemLoop();		*/
	SystemError();
}

void            _SysErrorMailNoOwner( unsigned MbxNo, char* pMail )
{
    STTFrm  *pSTT;
    
	SetWindowNo(1);
    pSTT= GetpSTT( _RunTaskNo );
    Lcdprintf( 0, 0, "NO MAIL OWNER.",0,0,0,0 );
    Lcdprintf( 1, 0, "TASK NAME= [%s]", pSTT->Name,0,0,0 );
    Lcdprintf( 2, 0, "MAILBOXNO=       [%02x]", MbxNo,0,0,0 );
    Lcdprintf( 3, 0, "MAILADRS.= [%08x]", pMail,0,0,0 );
/*    SystemLoop();		*/
	SystemError();
}
                /* 98.11.12 */
void            _SysErrorMbxNoOwner( unsigned MbxNo, char* pMbx )
{
    STTFrm  *pSTT;
    
	SetWindowNo(1);
    pSTT= GetpSTT( _RunTaskNo );
    Lcdprintf( 0, 0, "NO MAIL OWNER1.",0,0,0,0 );
    Lcdprintf( 1, 0, "TASK NAME= [%s]", pSTT->Name,0,0,0 );
    Lcdprintf( 2, 0, "MAILBOXNO=       [%02x]", MbxNo,0,0,0 );
    Lcdprintf( 3, 0, "MAILADRS.= [%08x]", pMbx,0,0,0 );
/*    SystemLoop();		*/
	SystemError();
}

void            _SysErrorLinkAddr( char* pMbx )
{
    STTFrm  *pSTT;
    
	SetWindowNo(1);
    pSTT= GetpSTT( _RunTaskNo );
    Lcdprintf( 0, 0, "NO MAIL OWNER2.",0,0,0,0 );
    Lcdprintf( 1, 0, "TASK NAME= [%s]", pSTT->Name,0,0,0 );
    Lcdprintf( 2, 0, "MAILBOXNO=       [%02x]", 0,0,0,0 );
    Lcdprintf( 3, 0, "MAILADRS.= [%08x]", pMbx,0,0,0 );
/*    SystemLoop();		*/
	SystemError();
}

const   char	*VectorString[64]= {
/*	     012345678901234567890123456789*/
/*00*/	"Initial Interrupt StackPointer",
/*01*/	"Initial Program Counter",
/*02*/	"Bus Error",
/*03*/	"Address Error",
/*04*/	"Illegal Instruction",
/*05*/	"Zero Divide",
/*06*/	"CHK Instruction",
/*07*/	"TRAPVInstructi",
/*08*/	"Privilege Vioration",
/*09*/	"Trace",
/*0a*/	"Line 1010 Emulator",
/*0b*/	"Line 1111 Emulator",
/*0c*/	"(Unassigned, Reserved)",
/*0d*/	"(Unassigned, Reserved)",
/*0e*/	"Format Error",
/*0f*/	"Uninitialized Interrupt",
/*10*/	"(Reserved-10)",
/*11*/	"(Reserved-11)",
/*12*/	"(Reserved-12)",
/*13*/	"(Reserved-13)",
/*14*/	"(Reserved-14)",
/*15*/	"(Reserved-15)",
/*16*/	"(Reserved-16)",
/*17*/	"(Reserved-17)",
/*18*/	"Spurious Interrupt",
/*19*/	"Level 1 Int",
/*1a*/	"Level 2 Int",
/*1b*/	"Level 3 Int",
/*1c*/	"Level 4 Int",
/*1d*/	"Level 5 Int",
/*1e*/	"Level 6 Int",
/*1f*/	"Level 7 Int",
/*20*/	"TRAP  0",
/*21*/	"TRAP  1",
/*22*/	"TRAP  2",
/*23*/	"TRAP  3",
/*24*/	"TRAP  4",
/*25*/	"TRAP  5",
/*26*/	"TRAP  6",
/*27*/	"TRAP  7",
/*28*/	"TRAP  8",
/*29*/	"TRAP  9",
/*2a*/	"TRAP 10",
/*2b*/	"TRAP 11",
/*2c*/	"TRAP 12",
/*2d*/	"TRAP 13",
/*2e*/	"TRAP 14",
/*2f*/	"TRAP 15",
/*30*/	"(Unassigned, Reserved)",
/*31*/	"(Unassigned, Reserved)",
/*32*/	"(Unassigned, Reserved)",
/*33*/	"(Unassigned, Reserved)",
/*34*/	"(Unassigned, Reserved)",
/*35*/	"(Unassigned, Reserved)",
/*36*/	"(Unassigned, Reserved)",
/*37*/	"(Unassigned, Reserved)",
/*38*/	"(Unassigned, Reserved)",
/*39*/	"(Unassigned, Reserved)",
/*3a*/	"(Unassigned, Reserved)",
/*3b*/	"(Unassigned, Reserved)",
/*3c*/	"(Unassigned, Reserved)",
/*3d*/	"(Unassigned, Reserved)",
/*3e*/	"(Unassigned, Reserved)",
/*3f*/	"(Unassigned, Reserved)" };

/*
	0123456789012345678901234567890123456789
00:	Vector[xx]mmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
01:	SR:xxxx PC:xxxxxxxx
02: Task Name:xxxxxxxxxxxx      SSP:xxxxxxxx
03:	Data xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
04:	-Reg xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
05:	Adrs xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
06:	-Reg xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
07: SSP  xxxxxxxx->    USP xxxxxxxx->
08: SSP  xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
09: +10H xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
10: +20H xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
11: USP  xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
12:	+10H xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
13: +20H xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
14: +30H xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
*/
/*void	_IntErrorProc( FrameFrm *pFrame, unsigned long *StackPtr, int RegPtr[16] )*/
//extern	int Sio1SendChar( unsigned char ch );
void	_IntErrorProc( FrameFrm *pFrame, unsigned long Vector, int RegPtr[16] )
{
/*    unsigned    Vector;*/
    STTFrm  *pSTT;
    unsigned streg;
	unsigned short exvct;	/* Exception trap Vector Number */

	unsigned long*	DataReg;
//	unsigned long*	AdrsReg;
//	unsigned long*	USP;
//	unsigned long*	SSP;
	unsigned long*	PC;
	unsigned long*	SR;
	unsigned long	vector;
	char	dbuff[4];


//	sprintf(dbuff,"03d",Vector);
	sprintf(dbuff,"03d");
//	Sio1SendChar(dbuff[0]);
//	Sio1SendChar(dbuff[1]);
//	Sio1SendChar(dbuff[2]);

	DataReg = (unsigned long*)(&streg);
//	AdrsReg = (unsigned long*)(&streg + 8 );
//	SSP = (unsigned long*)(*(&streg + 15));
	PC  = (unsigned long*)(*(&streg + 16));
//	USP = (unsigned long*)(*(&streg + 17));
	SR  = (unsigned long*)(*(&streg + 18));
	
	exvct = 0; vector = exvct;	vector &= 0xff;

    pSTT= GetpSTT( _RunTaskNo );
	Lcdprintf( 0, 0, "Vector[%02lx]%-30s", vector, VectorString[vector>0x3f?0x3f:vector],0,0 );
    Lcdprintf( 1, 0, "SR:%04x PC:%08x", SR, PC );
    Lcdprintf( 2, 0, "Task Name:%-18sSSP:%08x", pSTT->Name, pFrame,0,0 );
    Lcdprintf( 3, 0, "Data %08x %08x %08x %08x",
        DataReg[0], DataReg[1], DataReg[2], DataReg[3] );
    Lcdprintf( 4, 0, "-Reg %08x %08x %08x %08x",
        DataReg[4], DataReg[5], DataReg[6], DataReg[7] );
/*
    pSTT= GetpSTT( _RunTaskNo );
	Lcdprintf( 0, 0, "Vector[%02lx]%-30s", Vector, VectorString[Vector>0x3f?0x3f:Vector],0,0 );
    Lcdprintf( 1, 0, "SR:%04x PC:%08x", pFrame->SR, pFrame->PC,0,0 );
    Lcdprintf( 2, 0, "Task Name:%-18sSSP:%08x", pSTT->Name, pFrame,0,0 );

    Lcdprintf( 3, 0, "Data %08x %08x %08x %08x",
        _ReadyQue->DataReg[0], _ReadyQue->DataReg[1], _ReadyQue->DataReg[2], _ReadyQue->DataReg[3] );
    Lcdprintf( 4, 0, "-Reg %08x %08x %08x %08x",
        _ReadyQue->DataReg[4], _ReadyQue->DataReg[5], _ReadyQue->DataReg[6], _ReadyQue->DataReg[7] );
    Lcdprintf( 5, 0, "Adrs %08x %08x %08x %08x",
        _ReadyQue->AdrsReg[0], _ReadyQue->AdrsReg[1], _ReadyQue->AdrsReg[2], _ReadyQue->AdrsReg[3] );
    Lcdprintf( 6, 0, "-Reg %08x %08x %08x %08x",
        _ReadyQue->AdrsReg[4], _ReadyQue->AdrsReg[5], _ReadyQue->AdrsReg[6], _ReadyQue->AdrsReg[7] );

    SP= (unsigned*)pFrame-2;
    Lcdprintf( 7, 0, "SSP  %08x->   USP %08x->", SP, _ReadyQue->AdrsReg[7],0,0 );

    Lcdprintf( 8, 0, "SSP- %08x %08x %08x %08x", SP[0], SP[1], SP[2], SP[3] );
    Lcdprintf( 9, 0, "+08H %08x %08x %08x %08x", SP[4], SP[5], SP[6], SP[7] );
    Lcdprintf(10, 0, "+18H %08x %08x %08x %08x", SP[8], SP[9], SP[10], SP[11] );

    SP= (unsigned*)_ReadyQue->AdrsReg[7];
    Lcdprintf(11, 0, "USP  %08x %08x %08x %08x", SP[0], SP[1], SP[2], SP[3] );
    Lcdprintf(12, 0, "+10H %08x %08x %08x %08x", SP[4], SP[5], SP[6], SP[7] );
    Lcdprintf(13, 0, "+20H %08x %08x %08x %08x", SP[8], SP[9], SP[10], SP[11] );
    Lcdprintf(14, 0, "+20H %08x %08x %08x %08x", SP[12], SP[13], SP[14], SP[15] );
    Lcdprintf(15, 0, "+20H %08x %08x %08x %08x", SP[16], SP[17], SP[18], SP[19] );
*/
	/*	SystemLoop();	*/
	SystemError();
}


void SelfChkErr0( void )
{
	    Lcdprintf( 0, 0, "DRAM BANK00 N.G." );
}
void SelfChkErr1( void )
{
	    Lcdprintf( 1, 0, "DRAM BANK01 N.G." );
}
void SelfChkErr2( void )
{
	    Lcdprintf( 2, 0, "DUAL PORT RAM N.G." );
}
void SelfChkErr3( void )
{
	    Lcdprintf( 3, 0, "LCD BUFFER N.G." );
}


#ifdef WIN32
void    _IntError( void ) {}
#else
#ifdef	NO_SIM
void    _IntError( void ) {}
#endif
#endif
