#include    "sgt.h"

#define     KEY_INTERVAL            50
#define     REPEAT_START            500
#define     REPEAT_CONT             300
#define     NOR_BUZZER_TIME         50
#define     ERR_BUZZER_TIME         500
#define     FLS_BUZZER_TIME_ON      40
#define     FLS_BUZZER_TIME_OFF     60
#define     FLS_SHORT_BUZZER_TIME   50


#define S_BUZ_OFF   0x01
#define S_BUZ_SHORT 0x02
#define S_BUZ_LONG  0x04
#define S_BUZ_FLS   0x08
#define S_BUZ_FLS2  0x10
#define S_BUZ_ALM0  0x20
#define S_BUZ_ALM1  0x40
#define S_BUZ_ALM2  0x80
#define S_BUZ_FLS3  0x100

#define S_BUZ_OFF_ELS  0x200           /* �A��??���ȊO�Œ�? 98.12.1 */

extern  unsigned    _TimeMSec;
extern	int		TateYoko;			/* �c�E�� */
/************************************/
/*	1�o�b�N���C�g					*/
/************************************/
extern	int	BackLitsCnt;		/* �b */
extern	int	BackLitmCnt;		/* �� */
extern	int	BackLitSec;
extern	int	BackLitFlag;
extern	void    BuzOn(void);
extern	void    BuzOff(void);

/************************************/

int KeyGet( void );
int ScanKey(void);
extern  _SETUP		Set;					/* ������ ����E����ü						*/
void    NormalBuzzer(void)
{
	if(Set.iBuzzer==1)
		OnSignal(S_BUZ, S_BUZ_SHORT);
}

void    ErrorBuzzer(void)
{
/*    OnSignal(S_BUZ, S_BUZ_LONG);*/
 	if(Set.iBuzzer==1)
		OnSignal(S_BUZ, S_BUZ_FLS);
}

void    StopBuzzer(void)
{
    OnSignal(S_BUZ, S_BUZ_OFF);
}

void    FlashBuzzer(void)
{
    OnSignal(S_BUZ, S_BUZ_FLS);
}

void    FlashBuzzer2(void)
{
    OnSignal(S_BUZ, S_BUZ_FLS2);
}

void    AlarmBuzzer0(void)
{
    OnSignal(S_BUZ, S_BUZ_ALM0);
}

void    AlarmBuzzer1(void)
{
    OnSignal(S_BUZ, S_BUZ_ALM1);
}

void    AlarmBuzzer2(void)
{
    OnSignal(S_BUZ, S_BUZ_ALM2);
}

void    FlashBuzzer3(void)
{
  	if(Set.iBuzzer==1)
		OnSignal(S_BUZ, S_BUZ_FLS3);
}
void    StopBuzzerElse(void)
{
    OnSignal(S_BUZ, S_BUZ_OFF_ELS);
}

/*************************************/
/*	FUNC: KeyWaitAll(void)           */
/*  �L?���͑҂�                      */
/*    IN:                            */
/*   OUT:                            */
/*************************************/
/*char	dsp_buff[32];*/
extern	void	BackLightOnOff(int mode);
extern	void    BuzOff(void);
extern	int	BuzzerOnFlag;
int   KeyWait( void )
{
    T_MAIL  *RecMail;
    int   rec;
/*	int		i;*/
    
    RecMail= (T_MAIL*)ReceiveMail( T_KEYHAND );
    rec = (int)RecMail->mext;
	/* ���������L? */
	memcpy(KeyTochData,RecMail->mbuf,sizeof(KeyTochDataWork));
	if(rec != 0){
		if(BackLitFlag == OFF){			/* �o�b�N���C�g������ */
			BackLightOnOff(ON);
			BackLitFlag= ON;
			CommonArea.BackLightData= 1;
		}
		BackLitSec= SystemTime.sec;
		BackLitsCnt= 0;			/* 021207 */
		BackLitmCnt= 0;			/* 021207 */
		if(BuzzerOnFlag == 1){
			BuzOff();
			BuzzerOnFlag= 0;
		}
	}
    ResponseMail((char *)RecMail);
    return(rec);
}

/*************************************/
/*	FUNC: KeyAccept(int)             */
/*  �L?���͑҂�                      */
/*    IN:                            */
/*   OUT:                            */
/*************************************/
int   KeyAccept( void )
{
    T_MAIL  *RecMail;
    int   rec;
    
    RecMail= (T_MAIL*)AcceptMail( T_KEYHAND );
    if (RecMail == R_NoMail) {
        return -1;
    }
    rec = (int)RecMail->mext;
	/* ���������L? */
	memcpy(KeyTochData,RecMail->mbuf,sizeof(KeyTochDataWork));
	if(rec >0){
		if(BackLitFlag == OFF){			/* �o�b�N���C�g������ */
			BackLightOnOff(ON);
			BackLitFlag= ON;
			CommonArea.BackLightData= 1;
		}
		BackLitSec= SystemTime.sec;
		BackLitsCnt= 0;			/* 021207 */
		BackLitmCnt= 0;			/* 021207 */
		if(BuzzerOnFlag == 1){
			BuzOff();
			BuzzerOnFlag= 0;
		}
	}
    ResponseMail((char *)RecMail);
    return(rec);
}
int	CheckReptKey(void)
{
	int		i,j,k;
	int		ret;

	ret= -1;
	for(i= 0; i< RepeatInfo.EntryCnt; i++){
		for(j= 0; j < 8; j++){
			if(RepeatInfo.RepeatNo[i][j] == 0){
				break;
			}
			for(k= 0; k < 8; k++){
				if(KeyTochDataWork[k] == 0){
					break;
				}
				if(RepeatInfo.RepeatNo[i][j] == KeyTochDataWork[k]){
					ret= 0;
					break;
				}
			}
			
		}
		if(ret == 0){
			break;
		}
	}
	return(ret);
}
/********************************************************************/
/*                                                                  */
/*      �j�d�x�n���h��?                                             */
/*                                                                  */
/********************************************************************/
void    KeyHand(STTFrm* pSTT )
{
    int     i;
    T_MAIL    *recv;

    KeyFreeMbx = TakeMbx();
    for( i=0; i<2; i++ ) {
        recv= (T_MAIL *)TakeMail();
        ChangeMailResp( (char*)recv, KeyFreeMbx );
        SendMail( KeyFreeMbx, (char*)recv );
    }
    KeyRptFlag = 0;
    KeyPrev = (unsigned char)-1;
	memset(&RepeatInfo,0,sizeof(RepeatInfo));


    while(1) {
        recv = (T_MAIL *)ReceiveMail( KeyFreeMbx );
        while(1) {
#ifdef	WIN32
			if(KeyRptFlag != 0){
                KeyRptFlag = 0;         
                KeyPrev = (unsigned char)-1;
                recv->mext = 0;
				memset(KeyTochDataWork, 0, sizeof(KeyTochDataWork));
				memcpy(recv->mbuf,KeyTochDataWork,sizeof(KeyTochDataWork));
                SendMail( _RunTaskNo, (char *)recv);
                break;
			}
#endif
            if (KeyRptFlag == 0) {  /* ��߰Ē��ł?��??*/
                KeyGet();
                if (KeyData != -1) {
                    recv->mext = KeyData;
					memcpy(recv->mbuf,KeyTochDataWork,sizeof(KeyTochDataWork));
                    SendMail( _RunTaskNo, (char *)recv);
                    RptTime1 = _TimeMSec;
                    KeyRptFlag = 1;
                    KeyPrev = KeyData;
					memcpy(BefKeyTochDataWork,KeyTochDataWork,sizeof(BefKeyTochDataWork));
                    break;
                }
            } else if (KeyRptFlag == 1) {     /* ��߰Ē?*/
                KeyGet();
                if (KeyData == -1) {      /* �����͂Ȃꂽ */
                    KeyRptFlag = 0;         
                    KeyPrev = (unsigned char)-1;
					memset(BefKeyTochDataWork,0,sizeof(BefKeyTochDataWork));
					memset(KeyTochDataWork,0,sizeof(KeyTochDataWork));
                    recv->mext = 0;
					memcpy(recv->mbuf,KeyTochDataWork,sizeof(KeyTochDataWork));
                    SendMail( _RunTaskNo, (char *)recv);
                    break;
                } else {
/*                    if (KeyData == KeyPrev) {*/   /* �O�񷰂Ɠ��� */
					if(CheckReptKey() == 0){
						KeyPrev= KeyData;
						if(KerRepeatFlag == 1){		/* Repeat Enable Flag ON */
							if ((_TimeMSec - RptTime1) > REPEAT_START) {
								recv->mext = KeyPrev;
								memcpy(recv->mbuf,KeyTochDataWork,sizeof(KeyTochDataWork));
								SendMail( _RunTaskNo, (char *)recv);
								RptTime2 = _TimeMSec;
								KeyRptFlag = 2;     /* ��߰ĂQ���? */
								break;
							}
						}
                    } else {                      /* �ʂ̷����� */
						if(memcmp(KeyTochDataWork,BefKeyTochDataWork,8) != 0){
							KeyPrev = KeyData;
							recv->mext = KeyData;
							memcpy(recv->mbuf,KeyTochDataWork,sizeof(KeyTochDataWork));
							memcpy(BefKeyTochDataWork,KeyTochDataWork,sizeof(BefKeyTochDataWork));
							SendMail( _RunTaskNo, (char *)recv);
							break;
						}
                    }
                }   
            }
            else if (KeyRptFlag == 2) {         /* ��߰ĂQ��ڈ�? */
                KeyGet();
                if (KeyData == -1) {          /* �������ꂽ */
                    KeyRptFlag = 0;
                    KeyPrev = (unsigned char)-1;
					memset(BefKeyTochDataWork,0,sizeof(BefKeyTochDataWork));
					memset(KeyTochDataWork,0,sizeof(KeyTochDataWork));
                    recv->mext = 0;
					memcpy(recv->mbuf,KeyTochDataWork,sizeof(KeyTochDataWork));
                    SendMail( _RunTaskNo, (char *)recv);
                    break;
                }
                else {
/*                    if (KeyData == KeyPrev) {*/   /* ��߰Ē?*/
					if(CheckReptKey() == 0){
						KeyPrev= KeyData;
                        if ((_TimeMSec - RptTime2) > REPEAT_CONT) {
							if(KerRepeatFlag == 1){
								recv->mext = KeyPrev;
								memcpy(recv->mbuf,KeyTochDataWork,sizeof(KeyTochDataWork));
								SendMail( _RunTaskNo, (char *)recv);
								RptTime2 = _TimeMSec;
								break;
							}
                        }
                    }else {                  /* �ʂ̷����� */
						if(memcmp(KeyTochDataWork,BefKeyTochDataWork,8) != 0){
							KeyPrev = KeyData;
							recv->mext = KeyData;
							memcpy(recv->mbuf,KeyTochDataWork,sizeof(KeyTochDataWork));
							memcpy(BefKeyTochDataWork,KeyTochDataWork,sizeof(BefKeyTochDataWork));
							SendMail( _RunTaskNo, (char *)recv);
							break;
						}
                    }
                }   
            }
        }
		Delay(50);
    }
}
 
int KeyGet( void )
{
    OffSignal(S_KEY, 0x01);
    WaitSignal(S_KEY, 0x01, 0x00);
    return(KeyData);
}

/********************************************************************/
/*                                                                  */
/*      �j�d�x�X�L�����̃h���C�o?                                  */
/*                                                                  */
/********************************************************************/
void    KeyDrv(STTFrm* pSTT)
{

#ifdef WIN32
	lMouseKey = -1;
#else
	int		ret;

#endif
    
    while(1) {
#ifdef	WIN32
		if(lMouseKey != -1){
			if(lMouseAction != 0){
#ifdef	GP_S057
				if((lMouseY >=0)  && (lMouseY < 240) && 
					(lMouseX >= 0) && (lMouseX < 320)){
					if(TateYoko == 0){
						KeyData = (lMouseY / MESH_Y) * MAX_COLUM_NO + (lMouseX / MESH_X) + 1;
					}else{
						KeyData= 1;
					}
					memset(KeyTochDataWork,0,sizeof(KeyTochDataWork));
					KeyTochDataWork[0] = KeyData;
					OnSignal(S_KEY, 0x01);
				}
#endif
#ifdef	LP_S044
				if((lMouseY >=80)  && (lMouseY < 160) && 
					(lMouseX >= 40) && (lMouseX < 280)){
					if(TateYoko == 0){
						KeyData = ((lMouseY- 80) / 20) * 15 + ((lMouseX- 40) / 16) + 1;
						if(KeyData > 60){
							KeyData = 60;
						}
					}else{
						KeyData = (3- (lMouseY- 80) / 20) + 1 + ((lMouseX- 40) / 16) * 4;
						if(KeyData > 60){
							KeyData = 60;
						}
					}
					memset(KeyTochDataWork,0,sizeof(KeyTochDataWork));
					KeyTochDataWork[0] = KeyData;
					OnSignal(S_KEY, 0x01);
				}
#endif
#ifdef	GP_S044
				if((lMouseY >=80)  && (lMouseY < 160) && 
					(lMouseX >= 40) && (lMouseX < 280)){
					if(TateYoko == 0){
						KeyData = ((lMouseY- 80) / 20) * 15 + ((lMouseX- 40) / 16) + 1;
						if(KeyData > 60){
							KeyData = 60;
						}
					}else{
						KeyData = (3- (lMouseY- 80) / 20) + 1 + ((lMouseX- 40) / 16) * 4;
						if(KeyData > 60){
							KeyData = 60;
						}
					}
					memset(KeyTochDataWork,0,sizeof(KeyTochDataWork));
					KeyTochDataWork[0] = KeyData;
					OnSignal(S_KEY, 0x01);
				}
#endif
			}
			lMouseKey = -1;
		}
#else
        ret = ScanKey();
        if (ret != -1) {          /* �ŏ��̷� */
            KeyData = ret;
            OnSignal(S_KEY, 0x01);
        }
/*        else if (flag == 1) {*/       /* �������ꂽ */
        else {       /* �������ꂽ */
            KeyData = ret;
            OnSignal(S_KEY, 0x01);
        }
#endif
        Delay(50);
    }
}



void BuzDrv(STTFrm* pSTT)
{
    unsigned int    sig;
    int     state;      /* 0:OFF/1:SHORT/2:LONG/3:CONTINUE ON/4,6:FLASH ON/5,7:FLASH OFF */
                        /* 10,12:ALARM ON/11,13:ALARM OFF */
    int     TimeMsec;
    int     Count;

    state = 0;
    sig = S_BUZ_SHORT | S_BUZ_LONG | S_BUZ_FLS;
    OffSignal(S_BUZ, sig );
    while(1) {
        if ( state == 0 ) {
            sig = WaitSignal( S_BUZ, S_BUZ_SHORT | S_BUZ_LONG | S_BUZ_FLS, 0 );
			if (sig & S_BUZ_SHORT) {
				state= 1;
				TimeMsec = NOR_BUZZER_TIME;
			}
			if (sig & S_BUZ_LONG) {
				state= 1;
				TimeMsec = ERR_BUZZER_TIME;
			}
			if (sig & S_BUZ_FLS) {
				state= 1;
				TimeMsec = FLS_BUZZER_TIME_ON;
				Count= 5;
			}
		    OffSignal(S_BUZ, sig );
			BuzOn();
        } else {
            Delay(20);
            TimeMsec -= 20;
			if(TimeMsec <= 0){
				if (sig & S_BUZ_SHORT) {
					state= 0;
					BuzOff();
				}
				if (sig & S_BUZ_LONG) {
					state= 0;
					BuzOff();
				}
				if (sig & S_BUZ_FLS) {
					Count--;
					if(Count <= 0){
						state= 0;
						BuzOff();
					}else{
						if((Count % 2) != 0){
							BuzOn();
							TimeMsec = FLS_BUZZER_TIME_ON;
						}else{
							BuzOff();
							TimeMsec = FLS_BUZZER_TIME_OFF;
						}
					}
				}
			}
        }
    } 
}
#ifndef	WIN32
char	*itoa(int data, char *buff, int p)
{
	int		i,j;
	unsigned int wData;
	unsigned int bData;
	char	work[32];

	if(p == 2){
		bData= (unsigned int)data;
		for(i = 0; ; i++){
			work[i] = bData % p;
			bData /= p;
			if(bData == 0){
				break;
			}
		}
		j = 0;
		for(; i >= 0; i--){
			buff[j++] = work[i] | '0';
		}
		buff[j] = 0;
	}else{
		if(data < 0){
			wData = data * -1;
		}else{
			wData = data;
		}
		for(i = 0; ; i++){
			work[i] = wData % p;
			wData /= p;
			if(wData == 0){
				break;
			}
		}
		j = 0;
		if(data < 0){
			buff[j++] = '-';
		}
		for(; i >= 0; i--){
			buff[j++] = work[i] | '0';
		}
		buff[j] = 0;
	}
	return(buff);
}
#endif
