/*** Intel NOR type flash programming algorithm for RVD ***
  /  
 / /
/ / /\
\\\/ /// CLABSYS
 \\ ///  Cyber Lab System
  \\//
   \/

Revision history___
2004-4-28 John
*/

#include "typedefs.h"
#include "manid.h"
#include "intel.h"
#include "rvd.h"
#include "commonflash.h"
#include "asm.h"
#include "operations.h"

#define WIDTH 1	// 0=8, 1=16, 2=32
#define OFFSET_MASK 0xFFFF0000

void KickTheDog(void);

WORD Intel16ClearState(volatile WORD Address)
{
	REGISTER16( Address ) = (HWORD)INTEL_CLEAR_STAT;
	return NO_ERR;
}


WORD Intel16FlashGetManID( volatile WORD FlashBase )
{
	WORD ManID;

	FlashBase &= OFFSET_MASK;
	REGISTER16( FlashBase ) = (HWORD)INTEL_ID;
	ManID = REGISTER16( FlashBase);
	REGISTER16( FlashBase ) = (HWORD)INTEL_EXIT;
	return ManID;
}
WORD Intel16FlashIsBlockLocked(volatile WORD BlockBase)
{
	HWORD Status;

	REGISTER16(BlockBase) = (HWORD)INTEL_ID;
	Status = (HWORD)REGISTER16((unsigned short)(BlockBase + (2 << WIDTH)));
	if(Status & 0x3)
		return true;	//Block is Locked
	else
		return false;	//Block is Unlocked
}	

WORD Intel16FlashBlockUnlock(volatile WORD BlockBase)
{

	REGISTER16(BlockBase) = (HWORD)INTEL_LOCK;
	REGISTER16(BlockBase) = (HWORD)INTEL_CONFIRM;
	REGISTER16(BlockBase) = (HWORD)INTEL_ID;
	if( REGISTER16(BlockBase + (2 << WIDTH)) & 0x3)
		return false;
	else
		return true;
}

WORD Intel16FlashBlockLock(volatile WORD BlockBase)
{

	REGISTER16(BlockBase) = (HWORD)INTEL_LOCK;
	REGISTER16(BlockBase) = (HWORD)INTEL_UNLOCK;
	//
	// Confirm the operation
	//
	REGISTER16(BlockBase) = (HWORD)INTEL_ID;
	if( REGISTER16(BlockBase + (2 << WIDTH)) & 0x3 )
		return true;
	else
		return false;
}

WORD Intel16WaitState(volatile WORD Address)
{
	HWORD Status;
	WORD check_time = 0x00100000;

	REGISTER16(Address) = (HWORD) INTEL_STAT;	//0x70 Get the Register status
	
	Status = REGISTER16(Address);
	while(check_time--){
//		KickTheDog();
		Status = REGISTER16(Address);
		if( ( Status & FUSING_OK) != 0){
			REGISTER16(Address) = (HWORD)INTEL_EXIT;
			return true;
	}}
	if(!check_time)
		return false;
	REGISTER16(Address) = (HWORD)INTEL_EXIT;
	return true;
}

unsigned int Intel16FlashErase(volatile WORD Address)
{
	REGISTER16(Address) = (HWORD)INTEL_ERASE;
	REGISTER16(Address) = (HWORD)INTEL_CONFIRM;
	
	/*
	Block Erase wait
	*/
	if( Intel16WaitState( Address ) != true )
		return ERR_ERASE;
	REGISTER16(Address) = (HWORD)INTEL_EXIT;
	return NO_ERR;
}

WORD Intel16FlashWrite( volatile WORD WriteAddress, WORD BufferAddress, const WORD Count, const WORD VerifyFlag )
{
	WORD i;
	
	//
	// WORD Programming
	//
	for(i = ( Count >> WIDTH ) ; i != 0 ; i-- )
	{
		REGISTER16(WriteAddress) = (HWORD)INTEL_WRITE;
		REGISTER16(WriteAddress) = REGISTER16(BufferAddress);
		if( Intel16WaitState( WriteAddress) != true )
			return ERR_FLASHWR_WAIT;
		REGISTER16(WriteAddress) = (HWORD)INTEL_EXIT;
		if( VerifyFlag )
		{
			if(REGISTER16(WriteAddress) != REGISTER16(BufferAddress))
				return ERR_FLASHWR_VALIDATE;
		}
		WriteAddress += 1 << WIDTH;
		BufferAddress += 1 << WIDTH;
	}
	REGISTER16((WriteAddress - (1 << WIDTH))) = (HWORD)INTEL_EXIT; //Array Read mode

	return NO_ERR;
}
WORD Intel16FlashWriteBuffer( volatile WORD WriteAddress, WORD BufferAddress, WORD Count, WORD BufferSize, const WORD VerifyFlag)
{
	WORD Retries;
	WORD i;

	while( Count )
	{
		Retries = 0xff00;
		while( --Retries )
		{
			REGISTER16(WriteAddress) = (HWORD)INTEL_BUFFER;
			if( REGISTER16(WriteAddress) & FUSING_OK)
				break;
		}
		if( !Retries )
			break;
		
		if( Count < BufferSize ) BufferSize = Count;	//Adjust Buffer size
		
		REGISTER16(WriteAddress) = (BufferSize >> WIDTH) - 1;	// Issue 'N-1' where the start address

		for( i = (BufferSize >> WIDTH) ; i != 0 ; i--) {
			REGISTER16(WriteAddress) = REGISTER16(BufferAddress);
			WriteAddress += 1 << WIDTH; 
			BufferAddress += 1 << WIDTH;
		}
		REGISTER16( (WriteAddress - BufferSize) )  = (HWORD)INTEL_CONFIRM;
		//*( pWA - wHwordBufSize ) = (HWORD)INTEL_CONFIRM;

		if(Intel16WaitState( WriteAddress - (1 << WIDTH) ) != true)
			return ERR_FLASHWR_WAIT;

		REGISTER16((WriteAddress - (1 << WIDTH))) = (HWORD)INTEL_EXIT;

		if( VerifyFlag ){
			if( Verify(WriteAddress - BufferSize, BufferAddress  - BufferSize, BufferSize ) != NO_ERR)	// See the Skeleton.s
				return ERR_FLASHWR_VALIDATE;
		}
		Count -= BufferSize;
	}
	REGISTER16((WriteAddress - (1 << WIDTH))) = (HWORD)INTEL_EXIT;
	return NO_ERR;
}
WORD Mitsubishi16FlashWritePage( volatile WORD WriteAddress, WORD BufferAddress, WORD Count, const WORD PageSize, const WORD VerifyFlag)
{
	WORD i;
	for( i = ( Count >> WIDTH ) ; i != 0 ; i -= ( PageSize >> WIDTH ) )
	{
		if( Mitsubishi16FlashPageProgram( WriteAddress, BufferAddress, PageSize ) != NO_ERR){
			return ERR_FLASHWR_WAIT;
		}
		if( VerifyFlag){
			if( Verify(WriteAddress, BufferAddress, PageSize ) != NO_ERR )
				return ERR_FLASHWR_VALIDATE;
		}
		WriteAddress += PageSize;
		BufferAddress += PageSize;
	}
	return NO_ERR;
}
WORD Mitsubishi16FlashWriteLockedPage( volatile WORD WriteAddress, WORD BufferAddress, WORD Count, const WORD PageSize, const WORD VerifyFlag)
{	
	WORD i;
	for( i = ( Count >> WIDTH ) ; i != 0 ; i -= (PageSize >> WIDTH ) )
	{
	
		Mitsubishi16FlashSoftwareLockRelease(WriteAddress );	//Software lock release setup
		if( Mitsubishi16FlashPageProgram( WriteAddress, BufferAddress, PageSize) != true)
			return ERR_FLASHWR_WAIT;
		if( VerifyFlag){
			if( Verify(WriteAddress, BufferAddress, PageSize ) != NO_ERR )
				return ERR_FLASHWR_VALIDATE;
		}
		WriteAddress += PageSize;
		BufferAddress += PageSize;
	}
	return NO_ERR;
}
WORD Mitsubishi16FlashPageBuffer2Flash(volatile WORD WriteAddress)
{

	REGISTER16(WriteAddress) = (HWORD)MITSUBISHI_BUFFER;	//Page Buffer to Flash Setup
	REGISTER16(WriteAddress) = (HWORD)INTEL_CONFIRM;	//Program & verify
	if( Intel16WaitState( WriteAddress ) != true )
		return ERR_FLASHWR_WAIT;
	return NO_ERR;
}

WORD Mitsubishi16FlashPageProgram(volatile WORD WriteAddress, WORD BufferAddress, const WORD PageSize)
{
	WORD i;
//	KickTheDog();
	REGISTER16(WriteAddress) = (HWORD)INTEL_PAGE;	//Page program command
	for( i = ( PageSize >> WIDTH ) ; i != 0 ; i-- ){
		REGISTER16(WriteAddress) = REGISTER16(BufferAddress);
		WriteAddress += 1 << WIDTH;
		BufferAddress += 1 << WIDTH;
	}
	if( Intel16WaitState( WriteAddress - (1 << WIDTH) ) != true )
		return ERR_FLASHWR_WAIT;
	REGISTER16((WriteAddress - (1 << WIDTH))) = (HWORD)INTEL_EXIT;
	return NO_ERR;
}
WORD Mitsubishi16SingleBufferWrite(volatile WORD WriteAddress, WORD BufferAddress)
{

	REGISTER16(WriteAddress) = (HWORD) INTEL_SINGLE;	//Single Data Load to Page Buffer Setup
	REGISTER16(WriteAddress) = REGISTER16(BufferAddress);//Write Data
	return Mitsubishi16FlashPageBuffer2Flash( WriteAddress );
}
void Mitsubishi16FlashSoftwareLockRelease( volatile  WORD BlockBase)
{
	HWORD Block;
	HWORD _Block_;

	Block = (HWORD)((WORD)BlockBase >> 16);	// >> 15 for a[21:15], >>1 for 16bit mapping = >>16
	_Block_ = ~Block;
	Block &= 0x007F;	//DQ7 fix 0
	_Block_ &= 0x007F; 	//DQ7 fix 0
	REGISTER16(BlockBase) = 0x0060;	//Software Lock Release Setup 1 60h
	REGISTER16(BlockBase) = Block;	//Software Lock Release Setup 2 Block
	REGISTER16(BlockBase) = 0x00AC;	//Software Lock Release Setup 3 ACh
	REGISTER16(BlockBase) = _Block_;	//Software Lock Release Setup 4 Block#
	REGISTER16(BlockBase) = 0x007b;	//Software Lock Release Setup 5 7Bh
	return;
}

