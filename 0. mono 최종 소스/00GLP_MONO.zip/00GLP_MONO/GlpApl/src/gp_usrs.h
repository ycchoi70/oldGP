void		WindowScreenList(int* iScreenNo);
void		WindowScreenNumDisplay(int TLineCnt, int iStartNum);
void	vScreenDataSet(void);
void	Observe_ScreenSet(short	iScreenNum);
int NowBackColor(int iScreenNum);
