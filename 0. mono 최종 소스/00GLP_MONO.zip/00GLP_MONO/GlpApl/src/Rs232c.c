/****************************************************/
/*    FUNC   : SCI0 Program(RS-422)                 */
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 2002.4.10                            */
/*    Update :                                      */
/****************************************************/
#include    "sgt.h"
#include    "mtsschdp.h"
#include    "mtsscid.h"
#include "Selib.h"
#include "s3c44b0x.h"


//#define	LOG	1

//static	int	PLC_MyTaskNo;
volatile	int	PLC_MyTaskNo1;
volatile	int	PLC_MyTaskNo;
volatile	int	Init232CFlag0;
unsigned char	Sio00SndBuff[PLC_BUF_MAX];
int		Sio00SndCnt;
volatile	int		Init232C0Flag;		//061228

#ifdef	LOG
int		volatile	rs0Cnt;
int		volatile	rs0SaveCnt;
char	rs0log[1024];
//KSC20090112
//char	rs0Mtrixlog[1024];
int		volatile	rs0OutCnt;
int		volatile	rs0SaveOutCnt;
char	rs0Outlog[1024];
#endif



/************************************************/
/*	RS422 TX Enable								*/
/************************************************/
void	Rs422Enable(int mode)
{
	if(mode == ON){
		rPDATC |= RS422_DIR0;
	}else{
		rPDATC &= ~RS422_DIR0;
	}
}
/****************************************/
/*	Init(SCI0)                          */
/****************************************/
void	InitSci0( int speed, int ldata, int parity )
{
#ifndef	WIN32
	int	mode;
	int	mclk;
	int	i;
	int	BoadRate;

	Init232CFlag0= 1;
    mclk=MCLK;
//    rUFCON0=0x97;     	// FIFO Disable
//    rUFCON0=0x17;     	// FIFO Disable
    rUFCON0=0x07;     	// FIFO Enable(4Byte)
    rUMCON0=0x1;		//RTS-ON    
	if(ldata == RS_DATA7){
		mode= 0x02;
	}else{
		mode= 0x03;
	}
	switch(parity & 0xff){
	case RS_NONE:
		break;
	case RS_ODD:
		mode |= 0x04 << 3;
		break;
	case RS_EVEN:
		mode |= 0x05 << 3;
		break;
	}

	switch((parity & 0xff00) >> 8){      /* STOP 20090527 */ 
	case RS_STOP01:
		mode |= 0x00 << 2;
		break;
	case RS_STOP02:
		mode |= 0x01 << 2;
		break;
	}

    rULCON0= mode;     	//Normal,No parity,1 stop,8 bit
#ifdef	SIO_SENSE
    rUCON0=0x2c5;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
#endif
#ifdef	SIO_INTRUPT
	rUCON0=0x0c1;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
#endif
	switch(speed){
	case RS_300:
		BoadRate= 300;
		break;
	case RS_600:
		BoadRate= 600;
		break;
	case RS_1200:
		BoadRate= 1200;
		break;
	case RS_2400:
		BoadRate= 2400;
		break;
	case RS_4800:
		BoadRate= 4800;
		break;
	case RS_9600:
		BoadRate= 9600;
		break;
	case RS_19200:
		BoadRate= 19200;
		break;
	case RS_38400:
		BoadRate= 38400;
		break;
	case RS_57600:
		BoadRate= 57600;
		break;
	case RS_115200:
		BoadRate= 115200;
		break;
	}
    rUBRDIV0=( (int)(mclk/16./BoadRate + 0.5) -1 );
    for(i=0;i<100;i++);
	Init232CFlag0= 0;
#endif
}
/****************************************************
*   FUNC  : Rts ON/OFF                              *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
void	Sio0RtsOn(void)
{
	rUMCON0 = 0x0001;
}
void	Sio0RtsOff(void)
{                    
	rUMCON0 = 0x0000;
}
/****************************************************
*   FUNC  : Sio0 Error Handler                      *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
int	_Sci0ERProc( void )
{
	volatile unsigned char	status;
	
	status= *(unsigned char *)rUERSTAT0;
    if((status & 0x07) == 0){
    }else{      /* Error */
		/* �V�X�e?�C���t�H��?�V������ݒ肷�� */
		if((status & 0x01) != 0){			/* Overrun */
			InDevArea.UW[5] |= 0x0400;
		}
		if((status & 0x04) != 0){			/* Framing */
			InDevArea.UW[5] |= 0x0100;
		}
		if((status & 0x02) != 0){			/* Parity */ 
			InDevArea.UW[5] |= 0x0200;
		}
    }
#ifdef	OLD		//Fix Boadrate
	if((TaskStartFlag == ON) && ((status & 0x07) != 0)){
		if( (((Set.Ch1_iConnect == CH_CH0) && (Set.Ch1_iKind == EDITER)) ||
			 ((Set.Ch2_iConnect == CH_CH0) && (Set.Ch2_iKind == EDITER))) &&
			(GlpTimeout == 0)											  &&
			((BoardRateChangingFlag == 0) && (CommonArea.PcUpDownMode == 0)) ){			/* PC��MStart */
			BoardRateChangingFlag= 1;
			CommMode= 0;
			Comm0RecMode= 0;
			Comm00RecMode= 0;
			Sio00RecCnt= 0;
			return(0);
		}else{
			return(-1);
		}
	}
#endif
	return(-1);
}
#ifdef	WIN32
void	_Sci0ERInterruptHandler( void )
#else
void	__irq _Sci0ERInterruptHandler( void )
#endif
{
//	int	Ret;

	_Sci0ERProc();
    rI_ISPC= rI_ISPC | BIT_UERR01 ;   //clear pending bits,Default value=0x0000000
/*	070917	Fix Boadrate
	if(Ret == 0){
   		_PendingRequest( ID_PAddFlag | PLC_MyTaskNo << 16 | 1 );
	}
*/
}
/****************************************************
*   FUNC  : Sio0 Recieve Handler                    *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
int	_Sci0RXInterruptProc( void )
{
	int		ret;
    unsigned char rs_input_data;
	int		rCnt;
	int		rc;

	ret = -1;
	
	while(1){
		rCnt= rUFSTAT0 & 0x10f;
		if(rCnt == 0){
			break;
		}
		rs_input_data= Uart0_RxInt();

#ifdef	LOG
rs0log[rs0Cnt]= rs_input_data;
rs0SaveCnt = rs0Cnt;
//KSC20090112
//rs0Mtrixlog[rs0Cnt]= Matrix_Mode;
rs0Cnt= (rs0Cnt+ 1) % 1024;
#endif
		if(BoardRateChangingFlag == 0){
			rc= PlcConnect(rs_input_data);
			if(rc < 0){
			}else{
//KSC20090112
//				if(Init232C0Flag == OFF){
//					memcpy(Sio00RecBuff,Sio0RecBuff,Sio0RecCnt);
//					Sio00RecCnt= Sio0RecCnt;
//					Comm00RecMode= Comm0RecMode;

					SetPC1CharTimeOut0(0);	/*20090117*/

					memcpy(Sio00sRecBuff[Sio00BufIdx],Sio0RecBuff,Sio0RecCnt);
					Sio00sRecCnt[Sio00BufIdx]= Sio0RecCnt;
					Comm00sRecMode[Sio00BufIdx]= Comm0RecMode;
					Comm00Result[Sio00BufIdx]= rc;
					Comm00RecKind[Sio00BufIdx]= wCommRecKind0;
					Sio00BufIdx= (Sio00BufIdx+1)&1;
					Sio0RecCnt= 0;
					Comm0RecMode= 0;
					ret= 0;
//KSC20090112
//					CommResult0= rc;
//				}
//				break;
			}
		}
	}
/*	SetPLCTimeOut((unsigned int)(_TimeMSec+ 3000)); 061024 */
	if(Sio0RecCnt != 0){			/*20090117*/
		SetPC1CharTimeOut0(3000);	/*20090117*/
	}								/*20090117*/
	return(ret);
}
#ifdef	WIN32
void	_Sci0RXInterruptHandler( void )
#else
void	__irq _Sci0RXInterruptHandler( void )
#endif
{
	int	Ret;

	Ret = _Sci0RXInterruptProc();
	if(Ret == 0){
   		_PendingRequest( ID_PAddFlag | PLC_MyTaskNo << 16 | 1 );
	}
    rI_ISPC= rI_ISPC | BIT_URXD0 ;//  (Rx_Int�ł���Ă���) //clear pending bits,Default value=0x0000000
}
int		_Sci0TXInterruptProc( void )
{
	int		ret;

	ret = -1;
	if(Sio0OutCnt > 0){
		Uart_SendByte0((int)*Sio0OutBuf++);
		Sio0OutCnt--;
	}else{
		while(!(rUTRSTAT0 & 0x4));
		Usrt0TxMode(0);
		ReSetIntMask(BIT_UTXD0);
		Rs422Enable(0);
		if(Sio0OutCnt == 0){
			ret = 0;
		}
		Sio0OutCnt--;
	}
	return(ret);
}
#ifdef	WIN32
void	_Sci0TXInterruptHandler( void )
#else
void	__irq _Sci0TXInterruptHandler( void )
#endif
{
	int	Ret;

	Ret = _Sci0TXInterruptProc();
	if(Ret == 0){
   		_PendingRequest( ID_PAddFlag | PLC_MyTaskNo1 << 16 | 1 );
	}
    rI_ISPC= rI_ISPC | BIT_UTXD0 ;   //clear pending bits,Default value=0x0000000
}
int		_Sci0TEInterruptProc( void )
{
	return(0);
}
void	_Sci0TEInterruptHandler( void )
{
}
/************************************************************/
/*	�P�������M												*/
/************************************************************/
int Sio0SendChar( unsigned char ch )
{
	Uart_SendByte0(ch);
	return( TRUE );
}
int	RP_CommNext(char *buff,char *SndBuff);
/****************************************************
*   FUNC  : Sio0 Recieve Driver		                *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
void	Sio0RecDrv( STTFrm* pSTT )     /* SIO���M�h���C�o?�X�N */
{
	int		iKind;
#ifdef	LP_S044
//KSC20090112
//	unsigned char	*GlpSendBuff;
	int		GlpSendCnt;
#endif	
	PLC_MyTaskNo = _RunTaskNo;
	Sio0RecCnt= 0;		/* PLC Rec Count */
	Comm0RecMode= 0;		/* PLC Rec Mode */
	Sci0ErrorFlag= 0;
#ifdef	LOG
	rs0Cnt= 0;
#endif
	CommRecKind0= 0;
//KSC20090112
	wCommRecKind0= 0;
	Init232C0Flag= OFF;

	Sio00BufIdx= 0;		//20090112

//	SetWindowNo(1);
#ifdef	LP_S044
	SWpWriteBuff= (char*)-1;
#endif	
	while(1){
		Init232C0Flag= OFF;
#ifdef	WIN32
		while(1){
			if(PlcRecData == 1){
				PlcRecData= 0;
				break;
			}
			Delay(20);
		}
#else
		WaitFlag(1);
		//20090112
		if(Sio00BufIdx == 0){
			memcpy(Sio00RecBuff,Sio00sRecBuff[1],Sio00sRecCnt[1]);
			Comm00RecMode= Comm00sRecMode[1];
			Sio00RecCnt= Sio00sRecCnt[1];
			CommResult0= Comm00Result[1];
			CommRecKind0= Comm00RecKind[1];
		}else{
			memcpy(Sio00RecBuff,Sio00sRecBuff[0],Sio00sRecCnt[0]);
			Comm00RecMode= Comm00sRecMode[0];
			Sio00RecCnt= Sio00sRecCnt[0];
			CommResult0= Comm00Result[0];
			CommRecKind0= Comm00RecKind[0];
		}
		if(Sio00RecCnt > PLC_BUF_MAX){
			Sio00RecCnt= PLC_BUF_MAX;
		}
#endif
		Init232C0Flag= ON;
/*		if((Set.iConnect & 1) != 0){*/	/* PLC = RS-422 */
		if(Set.Ch1_iConnect == CH_CH0){
			iKind= Set.Ch1_iKind;
		}else{
			iKind= Set.Ch2_iKind;
		}
		if(DModeFlag == 0){
			switch(iKind){
			case UNIVERSAL:		/* Universal */
				if(CommonArea.PcUpDownMode != 0){		/* 081024 */
					break;
				}
				CommMode= Comm00RecMode;
				memcpy(CommBuff,Sio00RecBuff,Sio00RecCnt);
				RecCommCnt= Sio00RecCnt;
				HanyouComm((char *)CommBuff,(int)RecCommCnt,(char *)PlcThrueBuff,(int *)&PlcThrueCnt);
				if(PlcThrueCnt != 0){
/*					SendPLC2PCData(0,PlcThrueCnt,(char *)PlcThrueBuff,3000);*/
					SendPLCData(PlcThrueBuff,(int *)&PlcThrueCnt);
				}
				break;
			case DEFAULT_PLC:					/* PLC */
				if(CommonArea.PcUpDownMode != 0){		/* 081024 */
					break;
				}
				if(Def_Get_Ms_Sel() == 1){		/* MASTER */
					AddFlag(PLC_MyTaskNo1,1);
				}else{
					CommMode= Comm00RecMode;
					memcpy(CommBuff,Sio00RecBuff,Sio00RecCnt);
					RecCommCnt= Sio00RecCnt;
					LG_PLCFxThruProc((char *)CommBuff,(int *)&RecCommCnt,(char *)PlcThrueBuff,(int *)&PlcThrueCnt,PlcConnectFlag,PlcType);
				}
				break;
			case ELSE_PLC:
				if(CommonArea.PcUpDownMode != 0){		/* 081024 */
					break;
				}
				if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
					if((GET_MS_SEL() & 0x00ff) == 1){		/* MASTER */
						AddFlag(PLC_MyTaskNo1,1);
					}else{
						CommMode= Comm00RecMode;
						memcpy(CommBuff,Sio00RecBuff,Sio00RecCnt);
						RecCommCnt= Sio00RecCnt;
						PLC_THRU_PROC((char *)CommBuff,(int *)&RecCommCnt,(char *)PlcThrueBuff,(int *)&PlcThrueCnt,PlcConnectFlag,PlcType);
					}
				}
				break;
			case EDITER:		/* EDITOR */
//KSC20090112
				if(CommRecKind0 == 1){		//PLC Editor
					CommRecKind0= 0;
#ifdef	LP_S044
					GlpTimeout= _TimeMSec;
//KSC20090112
//					GlpSendBuff= (unsigned char*)TakeMemory(sizeof(Sio1SndBuff));
					switch(CommResult0){
					case 0:
						GlpSendCnt= PlcCommCheck((char *)Sio00RecBuff,(char *)Sio00SndBuff,Sio00RecCnt);
						if(GlpSendCnt > 0){
							if(GlpSendCnt < PLC_BUF_MAX){
								Sio00SndCnt= GlpSendCnt;						//For Retry		2008.12.08
//KSC20090112
//								memcpy(Sio00SndBuff,GlpSendBuff,Sio00SndCnt);	//For Retry		2008.12.08
								SendPCData(Sio00SndBuff,(int *)&GlpSendCnt);
							}
						}else if(GlpSendCnt == 0){
							//ACK���M
//KSC20090112
							Sio00SndBuff[4]= ACK;
							GlpSendCnt= 5;
//KSC20090112
							SendPCData(Sio00SndBuff,(int *)&GlpSendCnt);
						}else{
							//NAK���M
//KSC20090112
							Sio00SndBuff[4]= NAK;
							GlpSendCnt= 5;
//KSC20090112
							SendPCData(Sio00SndBuff,(int *)&GlpSendCnt);
						}
						break;
					case 1:		/* ACK��M */
//KSC20090112
//						GlpSendCnt= RP_CommNext((char *)Sio00RecBuff,(char *)GlpSendBuff);
						GlpSendCnt= RP_CommNext((char *)Sio00RecBuff,(char *)Sio00SndBuff);
						if(GlpSendCnt > 0){
//KSC20090112
							SendPCData(Sio00SndBuff,(int *)&GlpSendCnt);
						}
						break;
					case 2:		/* NAK��M */
						if(++RetryCnt < 4){
//KSC20090112
//							memcpy(GlpSendBuff,Sio00SndBuff,Sio00SndCnt);
							GlpSendCnt= Sio00SndCnt;
//KSC20090112
							SendPCData(Sio00SndBuff,(int *)&GlpSendCnt);
						}
						break;
					case 3:		/* �P�������M */
//KSC20090112
						memcpy(Sio00SndBuff,Sio0SndBuff,Sio0SndCnt);
						GlpSendCnt= Sio0SndCnt;
						SendPCData(Sio00SndBuff,(int *)&GlpSendCnt);
						break;
					default:
						break;
					}
//KSC20090112
//					FreeMail((char *)GlpSendBuff);
					Init232C0Flag= OFF;
#endif
				}else{
					CommMode= Comm00RecMode;
					if(Sio00RecCnt != 0){
						memcpy(CommBuff,Sio00RecBuff,Sio00RecCnt);
					}
					RecCommCnt= Sio00RecCnt;
					PC_CommProc();		/* DownLoad & UpLoad */
				}
				break;
//KSC20090112
			case MONITOR:	/* PLC MONITOR */
				CommMode= Comm00RecMode;
				if(Sio00RecCnt != 0){
					memcpy(CommBuff,Sio00RecBuff,Sio00RecCnt);
				}
				RecCommCnt= Sio00RecCnt;
				PC_CommProc();		/* DownLoad & UpLoad */
				break;
			case BAR_CODE:	/* BarCode */
				BarcodeIn((char *)Sio00RecBuff);
				break;
			case PLCTYPE2:		/* PLC TYPE2 */
				AddFlag(PLC_MyTaskNo1,1);
				break;
			}
		}else{
			if(iKind == EDITER){		/* 2008.09.18 */
				CommMode= Comm00RecMode;
				memcpy(CommBuff,Sio00RecBuff,Sio00RecCnt);
				RecCommCnt= Sio00RecCnt;
				DebugSend();
			}
		}
/*		}*/
	}
}
void	Sio0Drv( STTFrm* pSTT )     /* SIO���M�h���C�o?�X�N */
{
	T_MAIL	*pMail;
	int		ret;
#ifdef	WIN32
	int		recFlag;
#else
#ifdef	SIO_SENSE
	int		i;
#endif
#ifdef	LOG
	int		i;
#endif
#endif

	PLC_MyTaskNo1 = _RunTaskNo;

#ifdef	LOG
	rs0OutCnt= 0;
#endif

	ClearFlag();
	Sio0OutCnt = -1;
	Init232CFlag0= 0;

	while(1){
		pMail = (T_MAIL *)WaitRequest();
		switch(pMail->mcmd){
		case RS_CNTL:			/* Control */
			switch(pMail->mext){
			case RS_INIT:		/* Initial */
				InitSci0(pMail->mpar,pMail->mpec,pMail->mcod);
				break;
			case RS_RTSON:		/* RTS ON */
				Sio0RtsOn();
				break;
			case RS_RTSOFF:		/* RTS OFF */
				Sio0RtsOff();
				break;
			}
			pMail->mpec = 0;
			break;
		case RS_SEND:					/* ���M */
#ifdef	WIN32
			recFlag= 0;
			while(1){
				if(SioPLCDlgCommCnt == 0){
					break;
				}
				Delay(20);
			}
			PlcRecData= 0;
			ClearFlag();
			memcpy(Sio0SndBuff,(char *)pMail->mptr,pMail->mpar);
			SioPLCDlgCommCnt = pMail->mpar;
			SetTimeOut(pMail->mwrk);		/* Mail Count(500ms) */
			ret= WaitFlag(1);
#else
/*			Sio1SendChar('A');*/
			Comm0RecMode= 0;
			ClearFlag();
			Rs422Enable(1);
			//Retry Data Save
			memcpy(Sio00SndBuff,(char *)pMail->mptr,pMail->mpar);
			Sio0OutCnt = pMail->mpar;
			Sio0OutBuf = (char *)&Sio00SndBuff[0];
#ifdef	SIO_SENSE
			for(i= 0; i < pMail->mpar; i++){
				Sio0SendChar(*Sio0OutBuf++);
			}
			ret= 0;
			while(!(rUTRSTAT0 & 0x4));
			Rs422Enable(0);
#endif
#ifdef	LOG
for(i= 0; i < pMail->mpar; i++){
rs0Outlog[rs0OutCnt]= Sio0OutBuf[i];
rs0OutCnt= (rs0OutCnt+ 1) % 1024;
}
rs0SaveOutCnt = rs0OutCnt;
#endif
#ifdef	SIO_INTRUPT
			if(Sio0OutCnt == 1){
				Usrt0TxMode(1);					//20081108
				Sio0SendChar(*Sio0OutBuf++);
				Sio0OutCnt--;
				ret= 0;
				while(!(rUTRSTAT0 & 0x4));
				Usrt0TxMode(0);					//20081108
				Rs422Enable(0);
			}else{
//				Sio0OutCnt--;
//				Sio0SendChar(*Sio0OutBuf++);
				Usrt0TxMode(1);
				SetIntMask(BIT_UTXD0);
				SetTimeOut(500);		/* 500ms */
				ret= WaitFlag(1);
			}
#endif
#endif
			pMail->mpec = 0;		//2008.05.26
			if((ret == 0) && (pMail->mext != 0)){				/* Recive */
#ifndef	WIN32
				SetTimeOut(pMail->mwrk);		/* Mail Count(500ms) */
				ret = WaitFlag(1);		/*  */
				if((ret == 0) && (CommonArea.PcUpDownMode == 0)){		/* 070205 */
#else
				if(CommonArea.PcUpDownMode == 0){		/* 070205 */
#endif
					switch(pMail->mext){
					case 1:				/* ACK */
						if(Sio00RecBuff[0] != ACK){
							pMail->mpec = (unsigned short)-1;
						}
						break;
					case 2:				/* Data */
						pMail->mptr = Sio00RecBuff;
						pMail->mext = Sio00RecCnt;
						pMail->mpec = 0;
						break;
					case 3:				/* ACK & DATA */
						if(Sio00RecBuff[0] != ACK){
							pMail->mpec = (unsigned short)-1;
						}else{
							SetTimeOut(pMail->mwrk);		/* Mail Count(500ms) */
#ifndef	WIN32	
							ret = WaitFlag(1);		/*  */
#endif
							pMail->mptr = Sio00RecBuff;
							pMail->mext = Sio00RecCnt;
							pMail->mpec = ret;
						}
						break;
					}
				}else{
					if(ret != 0){
						pMail->mpec = (unsigned short)-1;
					}
					else{			pMail->mpec = 0;					}
				}
			}
 			break;
		}
		if(pMail->mpec != 0){
			ret = -1;
		}
		ResponseMail((char *)pMail);
	}
}

void	RsModeSetChanel(int Port,_SERIALPARAM* pParam)		//2009.09.04		/* 20091222 */
{
	int	Speed;
	int	Parity;
	int	DataBit;


	Speed = pParam->iSpeed;			/* 9600 */
	Parity = pParam->iParity;			/* 0:NONE,1:ODD,2:EVEN */
	Parity |= pParam->iStop << 8;	/* 0:STOP1,1:STOP2 */
	DataBit = pParam->iData1;			/* 0:7,1:8 */
	RsModeSet(Port,RS_INIT,Speed, DataBit, Parity);
}
/****************************************************/
/*	SIO Mode Set									*/
/****************************************************/
/* int parity 0xff00:stop,0x00ff:parity				*/
void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
#ifdef	WIN32
extern	int		simspeed[2];
extern	int		simdata[2];
extern	int		simparity[2];
extern	int		simstop[2];		//2009.09.04
extern	int		SioPCMode;
extern	int		SioPCOpenFlag;
extern	int		SioPLCOpenFlag;
extern	int		SioPLCMode;
	int	idx;

	if(type == RS_PLC){
		SioPLCOpenFlag= 1;
		idx= 1;
		SioPLCMode= 99;
	}else{
		SioPCOpenFlag= 1;
		idx= 0;
		SioPCMode= 99;
	}
	switch(bordrate){
	case RS_300:
		simspeed[idx]= 300;
		break;
	case RS_600:
		simspeed[idx]= 600;
		break;
	case RS_1200:
		simspeed[idx]= 1200;
		break;
	case RS_2400:
		simspeed[idx]= 2400;
		break;
	case RS_4800:
		simspeed[idx]= 4800;
		break;
	case RS_9600:
		simspeed[idx]= 9600;
		break;
	case RS_19200:
		simspeed[idx]= 19200;
		break;
	case RS_38400:
		simspeed[idx]= 38400;
		break;
	case RS_57600:
		simspeed[idx]= 57600;
		break;
	case RS_115200:
		simspeed[idx]= 115200;
		break;
	}
	if(ldata == RS_DATA7){
		simdata[idx]= 7;
	}else{
		simdata[idx]= 8;
	}
//	simparity[idx]= parity;
	simparity[idx]= parity & 0x00ff;		//2009.09.04
	simstop[idx]= (parity & 0xff00) >> 8;	//2009.09.04
	return;
#else
	T_MAIL	*mp;
	int		mbx;
	int		OldResp;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RS_CNTL;
	mp->mext = mode;
	if(mode == RS_INIT){
		mp->mpar = bordrate;
		mp->mpec = ldata;
		mp->mcod = parity;
	}
	if(type == RS_PLC){
		SendMail( T_SIO0DRV, (char *)mp );
	}else{
		SendMail( T_SIO1DRV, (char *)mp );
	}
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	FreeMail((char *)mp);
	FreeMbx(mbx);
#endif
}
/****************************************************/
/*	RTS ON/OFF Set									*/
/****************************************************/
void	RtsOnOffSet(int type,int mode)
{
	T_MAIL	*mp;
	int		mbx;
	int		OldResp;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = mode;
	if(type == RS_PLC){
		SendMail( T_SIO0DRV, (char *)mp );
	}else{
		SendMail( T_SIO1DRV, (char *)mp );
	}
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	FreeMail((char *)mp);
	FreeMbx(mbx);
}

