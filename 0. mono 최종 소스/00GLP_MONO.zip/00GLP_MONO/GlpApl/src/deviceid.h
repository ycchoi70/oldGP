/*** Flash device Flash Device ID definitions for RVD ***
  /  
 / /
/ / /\
\\\/ /// CLABSYS
 \\ ///  Cyber Lab System
  \\//
   \/

Revision history___
2004-12-10 Joon

NOTE:
[31:16] Manufacturer ID
[15:0] Device ID
*/

#ifndef __DEVICEID_H__
#define __DEVICEID_H__

/* INTEL 0x89 */

/* MITUBISHI 0x1C */

/* AMD 0x01 */
#define AM29LV160DT 0x000122C4
#define AM29LV160DB 0x00012249

/* ST 0x02 */
#define M29W160DT 0x000222C4
#define M29W160DB 0x00022249
#define M29W160ET 0x000222C4
#define M29W160EB 0x00022249

/* SAMSUNG 0xEC */

/* SHARP 0xB0 */

/* TOSHIBA 0x98 */

/* FUJITSU 0x04 */
#define MBM29LV320TE 0x000422F6
#define MBM29LV320BE 0x000422F9
/* SST 0xBF */
#define SST39VF160Q	0x00BF0000

#endif
