/************************************************/
/*	ARM LCD Contorol							*/
/*	2006.05.11									*/
/************************************************/
#include <string.h>
#include <stdarg.h>
#include "define.h"
#include "S3c44b0x.h"
#include "Graphics.h"

//#define _LcdOn()	rPDATC|=(1<<10)
//#define _LcdOff()	rPDATC&=~(1<<10)

#define SCR_XSIZE 	(GAMEN_X_SIZE)  
#define SCR_YSIZE 	(GAMEN_Y_SIZE)
#define LCD_XSIZE 	(GAMEN_X_SIZE)
#define LCD_YSIZE 	(GAMEN_Y_SIZE)
//#define SCR_XSIZE 	(240)  
//#define SCR_YSIZE 	(320)
//#define LCD_XSIZE 	(240)
///#define LCD_YSIZE 	(320)

#define MVAL_USED 		0
#define M5D(n) 			((n) & 0x1fffff)
#define ARRAY_SIZE_COLOR 	(SCR_XSIZE/1*SCR_YSIZE)
#define HOZVAL			(LCD_XSIZE/4-1) 
//#define HOZVAL_COLOR	(LCD_XSIZE*3/8-1) 
#define HOZVAL_COLOR	(LCD_XSIZE/4-1) 
#define LINEVAL			(LCD_YSIZE-1)  
//#define MVAL			(13) 
#define MVAL			(13) 

//#define MVAL			(0x31) 
//#define CLKVAL_COLOR 	(10)  //66Mhz/(10*2) --> CLKVAL=10 ->3.3MHz(VCLK)
//#define CLKVAL_COLOR 	(30)  //66Mhz/(30*2) --> CLKVAL=30 ->1.1MHz(VCLK)
//#define CLKVAL_COLOR 	(DEF_LCDCLK)  //66Mhz/(45*2) --> CLKVAL=45 ->0.5MHz(VCLK)

//extern	unsigned char	font_data_jpn[256][16];
extern	unsigned char godic_eng8_16_bma[];
/************************************************/
/*	LCD Initialize								*/
/************************************************/
void Lcd_Init(void)
{
    int tmp;

//    rPCONC&=~(3<<20); rPCONC|=(1<<20);	// For Lcd Reset Pin
//    rPCONC|=(0xff<<8);			// VD[4..7]
//    rPUPC|=(0x0f<<8);
    rPCOND=0xaaaa;				// VD[0..3], VFRM, VLINE, VCLK  
    rPUPD=0xff;	
//    _LcdOff();
 
//  31      22 21      12 11-10 9-8 7 6-5 4   0
//  0000000000 0000000100 11    11  0 01  00000
//             :          :     :     :
//             :          :     :    MMODE(4bit single scan)
//             :          :    WDLY(16clock)
//             :         WLH(16clock)
//             CLKVAL(4)
	rLCDCON1=(0)|(1<<5)|(MVAL_USED<<7)|(0x3<<8)|(0x3<<10)|(lcd_clk<<12);
//  31       21 20       10 9        0
//  00000001010 00001001111 0011101111
//  :           :           :     
//  :           :          LINEVAL(239)
//  :          HOZVAL(79)
// LINEBLANK(10)
	rLCDCON2=(LINEVAL)|(HOZVAL_COLOR<<10)|(10<<21);  
//  31-29 28-27 26  21 20                  0
//  000   00    110001 000000000000000000000
//        :     :      :     
//        :     :     LCDBASEU(0x000000)
//        :    LCDBANK(0x031)
//       MODESEL(00monochrome)
	rLCDSADDR1= (0<<27) | ( ((unsigned int)BaseLcd_Buffer>>22)<<21 ) | M5D((unsigned int)BaseLcd_Buffer>>1);
//  31-30 29 28    21 20                  0
//  00    0  00001011 000000010010110000000
//        :  :        :     
//        :  :       LCDBASEL((0x0c400000 + 320/8*240) >> 1)
//        : MVAL(13)
//       BSWAP(0)
	rLCDSADDR2= M5D((((unsigned int)BaseLcd_Buffer+(SCR_XSIZE/8*LCD_YSIZE))>>1)) | (MVAL<<21);
//  31        20 19        9 8       0
//  000000000000 00000000000 001010000
//               :           :     
//               :          PAGEWIDTH(320/4)
//              OFFSIZE(0)
	rLCDSADDR3= (LCD_XSIZE/4) | ( ((SCR_XSIZE-LCD_XSIZE)/2)<<9 );

	//Display Enable
	rLCDCON1=(1)|(1<<5)|(MVAL_USED<<7)|(0x3<<8)|(0x3<<10)|(lcd_clk<<12);
	    // enable,8B_SNGL_SCAN,WDLY=8clk,WLH=8clk,

     	for(tmp=0;tmp<100000;tmp++);			// Delay Time for Power On Sequence
//     	_LcdOn();	

}
void Rtc_Set(char hour, char min, char sec)
{
       rRTCCON|=(1<<0);

       rBCDHOUR=( ((hour/10)<<4) + (hour%10) );
       rBCDMIN=( ((min/10)<<4) + (min%10) );
       rBCDSEC=( ((sec/10)<<4) + (sec%10) );     	

       rRTCCON&=~(1<<0);

} // end of Rtc_Set(...)

