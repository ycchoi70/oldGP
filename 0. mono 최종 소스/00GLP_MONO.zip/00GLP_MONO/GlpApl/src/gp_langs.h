void		vLangSet(int*	iScreenNo);
void Last_SP_Del(char* cBuffer);

