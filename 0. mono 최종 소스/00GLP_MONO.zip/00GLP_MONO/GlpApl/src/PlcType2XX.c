/************************************************************/
/*	PLC TYPE 1												*/
/************************************************************/
#define	ARM_CPU		1
#define FX1S	1


// �Ʒ� ������ SH CPU �϶� App�� Protocol ���α׷��� ������ �����ϵǾ� ��ũ�ȴ�.
// SH ��ũ ȯ�濡�� ������ �������� ����� ���� �Ʒ��� �̸����� ����ϱ� �����̴�.    
//#ifndef	WIN32
//#pragma	section PlcProc
//#endif

/****************************** START **********************/
#ifdef	WIN32

#ifdef	FX
#include	"PlcTypeFx.cpp"
#endif
#ifdef	FX1S
#include	"PlcTypeFx1s.cpp"
#endif
#ifdef	MK10
#include	"PLgmk10s1.cpp"
#endif
#ifdef	MK200
#include	"PlcTypeLg.cpp"
#endif
#ifdef	N70 /* FPG PLC SAME */
#define		PLC_SPEED	RS_19200
#include	"Plcsm_70n.cpp"
#endif
#ifdef	N70P
#include	"Plcsm2_70p.cpp"
#endif
#ifdef	ATHD
#include	"PlcThdM.cpp"
#endif
#ifdef	ATZ
#include	"PlcTypeTZ.cpp"
#endif
#ifdef	AMT
#include	"PlcTypeMT.cpp"
#endif
#ifdef	AMP
#include	"PlcTypeMP.cpp"
#endif
#ifdef	MODMS
#include	"PlcModMS.cpp"
#endif
#ifdef	LGCNET
#include	"PlcLGcnet.cpp"
#endif
#ifdef	UNI_S
#include	"Plc_UniS.cpp"
#endif
#ifdef	FP0
#define		PLC_SPEED	RS_9600
#include	"Plcsm_70n.cpp"
#endif
#ifdef	GM4
#include	"PlcTypeGM.cpp"
#endif
#ifdef	E5XX
#include	"PlcOmronE5CN_Mod.cpp"
#endif
#ifdef	CPM1A
#include	"PlcTypeCPM1A.cpp"
#endif
#ifdef	DTB
#include	"PlcDeltaB_Mod.cpp"
#endif
#ifdef	FPG
#define		PLC_SPEED	RS_19200
#include	"Plcsm_70n.cpp"
#endif


#else

#ifdef	FX
#include	"PlcTypeFx.c"
#endif
#ifdef	FX1S
#include	"PlcTypeFx1s.c"
#endif
#ifdef	MK10
#include	"PLgmk10s1.c"
#endif
#ifdef	MK200
#include	"PlcTypeLg.c"
#endif
#ifdef	N70
#define		PLC_SPEED	RS_19200
#include	"Plcsm_70n.c"
#endif
#ifdef	N70P
#include	"Plcsm2_70p.c"
#endif


#ifdef	ATHD
#include	"PlcThdM.c"
#endif
#ifdef	ATZ
#include	"PlcTypeTZ.c"
#endif
#ifdef	AMT
#include	"PlcTypeMT.c"
#endif
#ifdef	AMP
#include	"PlcTypeMP.c"
#endif
#ifdef	MODMS
#include	"PlcModMS.c"
#endif
#ifdef	LGCNET
#include	"PlcLGcnet.c"
#endif

#ifdef	UNI_S
#include	"Plc_UniS.c"
#endif
#ifdef	FP0
#define		PLC_SPEED	RS_9600
#include	"Plcsm_70n.c"
#endif
#ifdef	GM4
#include	"PlcTypeGM.c"
#endif
#ifdef	E5XX
#include	"PlcOmronE5CN_Mod.c"
#endif
#ifdef	CPM1A
#include	"PlcTypeCPM1A.c"
#endif
#ifdef	DTB
#include	"PlcDeltaB_Mod.c"
#endif
#ifdef	FPG
#define		PLC_SPEED	RS_19200
#include	"Plcsm_70n.c"
#endif


#endif
/****************************** END **********************/

