/*** Flash device manufacturers ID definitions for RVD ***
  /  
 / /
/ / /\
\\\/ /// CLABSYS
 \\ ///  Cyber Lab System
  \\//
   \/

Revision history___
2004-4-28 John
*/

#ifndef __MANID_H__
#define __MANID_H__

#define ID_SST		0xbf
#define ID_TOSHIBA	0x98	

#define ID_AMD		0x01	// AMD Manufacturer Code
#define ID_ST   0x02    //ST
#define ID_FUJITSU	0x04	//Fujitsu manufacturer ID


#define ID_INTEL	0x89	// Intel manufacturer ID
#define ID_SHARP 	0xb0	//Sharp manufacturer ID


#define ID_MITSUBISHI	0x01C	//Mitsubishi Manufacturer Code


#define ID_SAMSUNG	0xEC	//Samsung Electronics ID
#endif 	//#ifndef __MANID_H__
