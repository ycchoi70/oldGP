#ifdef	WIN32
#ifndef	PLCTYPE_ELSE2
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
void	B_SendPLCPCData( void )
{
	SendPLCPCData();
}
int	B_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
	return(SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
}
int	B_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
	return(SendPC2PLCData(mode,cnt,buff,TimeOut));
}
/* Thrue Mode */
int	B_SendPLC2PCData( int mode,int cnt,char *buff,int TimeOut )
{
	return(SendPLC2PCData( mode,cnt,buff,TimeOut ));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
void	B_PlcDevInit(void)
{
	PlcDevInit();
}
int	B_SendPLCGroup()
{
	SendPLCGroup();
	return(0);
}
void	B_Bin2Hex(int data,int cnt,char *buff)
{
	Bin2Hex(data,cnt,buff);
}
int	B_gstrlen(char *buff)
{
	return(gstrlen(buff));
}
void	B_gmemset(char *buff,int data,int cnt)
{
	gmemset(buff,data,cnt);
}
void	B_gmemcpy(char *obj,char *src,int cnt)
{
	gmemcpy(obj,src,cnt);
}
void	B_gstrcpy(char *obj,char *src)
{
	gstrcpy(obj,src);
}
int	B_gstrcmp(char *src,char *obj)
{
	return(gstrcmp(src,obj));
}
int	B_gstrncmp(char *src,char *obj,int cnt)
{
	return(gstrncmp(src,obj,cnt));
}
void	B_gstrcat(char *src,char *obj)
{
	gstrcat(src,obj);
}
#else
/************************************************/
/*	TYPE 2										*/
/************************************************/
extern	int	B_Hex2nBin(char *buff,int cnt);
extern	int	B_Hex2Bin(char *buff);
extern	unsigned int B_LHexAsToBin(char *buff, int cnt);
int	B_SendRecPLC2(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
	return(SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
}
extern	void	B_SendPLCPCData( void );
int	B_SendPC2PLCData2( int mode,int cnt,char *buff,int TimeOut )
{
	return(SendPC2PLCData2(mode,cnt,buff,TimeOut));
}
extern	int	B_Delay(int p);
extern	int	B_ReadSignal(int p);
extern	void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	B_PlcDevInit(void);
extern	int	B_SendPLCGroup();
/************************************/
/* ���ʏ���							*/
/************************************/
extern	void	B_Bin2Hex(int data,int cnt,char *buff);
extern	int	B_gstrlen(char *buff);
extern	void	B_gmemset(char *buff,int data,int cnt);
extern	void	B_gmemcpy(char *obj,char *src,int cnt);
extern	void	B_gstrcpy(char *obj,char *src);
extern	int	B_gstrcmp(char *src,char *obj);
extern	int	B_gstrncmp(char *src,char *obj,int cnt);
extern	void	B_gstrcat(char *src,char *obj);
#endif
#else
#ifndef	PLCTYPE_ELSE2
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
void	B_SendPLCPCData( void )
{
	SendPLCPCData();
}
int	B_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
	return(SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
}
int	B_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
	return(SendPC2PLCData(mode,cnt,buff,TimeOut));
}
/* Thrue Mode */
int	B_SendPLC2PCData( int mode,int cnt,char *buff,int TimeOut )
{
	return(SendPLC2PCData( mode,cnt,buff,TimeOut ));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
void	B_PlcDevInit(void)
{
	PlcDevInit();
}
int	B_SendPLCGroup()
{
	SendPLCGroup();
	return(0);
}
/************************************/
/* ���ʏ���							*/
/************************************/
void	B_Bin2Hex(int data,int cnt,char *buff)
{
	Bin2Hex(data,cnt,buff);
}
int	B_gstrlen(char *buff)
{
	return(gstrlen(buff));
}
void	B_gmemset(char *buff,int data,int cnt)
{
	gmemset(buff,data,cnt);
}
void	B_gmemcpy(char *obj,char *src,int cnt)
{
	gmemcpy(obj,src,cnt);
}
void	B_gstrcpy(char *obj,char *src)
{
	gstrcpy(obj,src);
}
int	B_gstrcmp(char *src,char *obj)
{
	return(gstrcmp(src,obj));
}
int	B_gstrncmp(char *src,char *obj,int cnt)
{
	return(gstrncmp(src,obj,cnt));
}
void	B_gstrcat(char *src,char *obj)
{
	gstrcat(src,obj);
}
#else
/************************************************/
/*	TYPE 2										*/
/************************************************/
extern	int	B_Hex2nBin(char *buff,int cnt);
extern	int	B_Hex2Bin(char *buff);
extern	unsigned int B_LHexAsToBin(char *buff, int cnt);
extern	int	B_Delay(int p);
extern	int	B_ReadSignal(int p);
extern	void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	B_PlcDevInit(void);
extern	int	B_SendPLCGroup();
/************************************/
/* ���ʏ���							*/
/************************************/
extern	void	B_Bin2Hex(int data,int cnt,char *buff);
extern	int	B_gstrlen(char *buff);
extern	void	B_gmemset(char *buff,int data,int cnt);
extern	void	B_gmemcpy(char *obj,char *src,int cnt);
extern	void	B_gstrcpy(char *obj,char *src);
extern	int	B_gstrcmp(char *src,char *obj);
extern	int	B_gstrncmp(char *src,char *obj,int cnt);
extern	void	B_gstrcat(char *src,char *obj);
int	B_SendRecPLC2(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
	return(SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
}
extern	void	B_SendPLCPCData( void );
int	B_SendPC2PLCData2( int mode,int cnt,char *buff,int TimeOut )
{
	return(SendPC2PLCData2(mode,cnt,buff,TimeOut));
}
#endif
#endif
