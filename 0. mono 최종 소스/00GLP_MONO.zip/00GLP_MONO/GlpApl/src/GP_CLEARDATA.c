/* ******************************************************************************/
/*  �� �� �� : GP_CLEARDATA.CPP													*/
/*  ��    �� :	�޸� Ŭ����														*/
/*  �� �� �� : 2002�� 2�� 16�� (��)												*/
/*  �� �� �� : ȫ �� ��															*/
/*  ��    �� : (��) LC Tech														*/
/*  ��    �� : 																	*/
/* 050616:Common Area Clear														*/
/* ******************************************************************************/
#include	"sgt.h"
#define		SCREENCOUNT	512

extern	void	RamFlashEraze(short *addr);

/* ****************************************************************************** */
/*  �� �� �� : vClearGPData()														 */
/*  ��    �� : �޸� Ŭ����													 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 6�� 30�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#ifdef	SIZE_2480
extern	void	SendPlcWaitFlag(void);
void		vClearGPData(int* iScreenNo)
{
	int		iKeyCode;
	short	iKeyFlag;
	int		i;
	_RECTANGLE_INFO RECParam;
	_LINE_INFO param;
	int				SetScreenNo;
	int		dspIdx;

	SetScreenNo= *iScreenNo;

#ifdef	GP_S044
	dspIdx= CLEAR_GP_DATA;
#endif
#ifdef	LP_S044
	if(SetScreenNo == CLEAR_GP_DATA_NUM){	dspIdx= CLEAR_GP_DATA;	}
	else{									dspIdx= CLEAR_GLP_DATA;	}
#endif
	iKeyCode	= -1;
	iKeyFlag	= 1;
	param.iLineColor	= WHITE;							/* Line Data Set		*/
	param.iLineStyle	= SOLID_LINE;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	SetWinSema();
    RectAngleOut(GAMEN_START_X+49,GAMEN_START_Y+58,GAMEN_START_X+103,GAMEN_START_Y+78,&RECParam);					/* ��						 */
	LineOut(GAMEN_START_X+50, GAMEN_START_Y+77, GAMEN_START_X+102, GAMEN_START_Y+77, &param);
	LineOut(GAMEN_START_X+102, GAMEN_START_Y+58, GAMEN_START_X+102, GAMEN_START_Y+77, &param);

	RectAngleOut(GAMEN_START_X+132,GAMEN_START_Y+58,GAMEN_START_X+186,GAMEN_START_Y+78,&RECParam);					/* ��						 */	
	LineOut(GAMEN_START_X+132, GAMEN_START_Y+77, GAMEN_START_X+185, GAMEN_START_Y+77, &param);
	LineOut(GAMEN_START_X+185, GAMEN_START_Y+58, GAMEN_START_X+185, GAMEN_START_Y+77, &param);

	CenterDisplay(0,GAMEN_START_Y+24,GAMEN_X_SIZE-1,GAMEN_START_Y+39,Dspname[dspIdx].chName[Set.iLang][0]);
    CenterDisplay(0,GAMEN_START_Y+40,GAMEN_X_SIZE-1,GAMEN_START_Y+55,Dspname[dspIdx].chName[Set.iLang][1]);
	CenterDisplay(GAMEN_START_X+49,GAMEN_START_Y+60,GAMEN_START_X+103,GAMEN_START_Y+75,Dspname[dspIdx].chName[Set.iLang][2]);
	CenterDisplay(GAMEN_START_X+132,GAMEN_START_Y+60,GAMEN_START_X+186,GAMEN_START_Y+75,Dspname[dspIdx].chName[Set.iLang][3]);

	DefaultFormDisplay(LINE_FORM, Dspname[dspIdx].chTitle[Set.iLang]);
	DrawLcdBank1();

	ResetWinSema();
	while ( *iScreenNo == SetScreenNo ) {
		iKeyCode = KeyWaitData(iKeyFlag,CLEAR_DATA_NUM);									/*  �Էµ� Ű���� �о��	 */
		iKeyFlag = 0;
		if ( iKeyCode == KEY_01 || iKeyCode == KEY_02 ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) ||
			(iKeyCode >= KEY_34 && iKeyCode <= KEY_36 ) ||
			(iKeyCode >= KEY_49 && iKeyCode <= KEY_51 ) ||
			(iKeyCode >= KEY_39 && iKeyCode <= KEY_41 ) ||
			(iKeyCode >= KEY_54 && iKeyCode <= KEY_56 ) )
		{
			iKeyFlag = 1;
			NormalBuzzer();										/*	Buzzer		*/
		}
		
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}
		if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) 
		{			
			*iScreenNo = USER_SCREEN_NUM;
		} else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 )
		{															/*  END			*/
			*iScreenNo = CLEAR_DATA_NUM;
		} else if (iKeyCode >= KEY_49 && iKeyCode <= KEY_51)
		{															/*  YES			*/
			RECParam.iPattern	= PAT8;
			RECParam.iForeColor = WHITE;
			RECParam.iBackColor = WHITE;

			SetWinSema();
			RectAngleOut(GAMEN_START_X+26,GAMEN_START_Y+36,GAMEN_START_X+220,GAMEN_START_Y+62,&RECParam);
			if(Set.iLang == 0)
				DotTextOut(GAMEN_START_X+56,GAMEN_START_Y+41,Dspname[dspIdx].chName[Set.iLang][4],1,1, TRANS, T_BLACK, T_WHITE);
			else
				DotTextOut(GAMEN_START_X+28,GAMEN_START_Y+41,Dspname[dspIdx].chName[Set.iLang][4],1,1, TRANS, T_BLACK, T_WHITE);
			DrawLcdBank1();
			ResetWinSema();
			if(SetScreenNo == CLEAR_GP_DATA_NUM){
				for(i = 0; i<SCREENCOUNT ; i++)
				{
					Screen[i].iNum = 0x00;
					Screen[i].chTitle=0x00;
				}
				iDispOrder= 0;			//2008.04.21
				Delay(1000);											/* imsi		*/
/*-------------------------------------------------------------------------------------*/			
/* PLC Protocoa area clear */ /* 050623 */			
				OffSignal(SGN_PLC, 0xFFFFFFFF);
#ifdef	LP_S044	//2009.08.26   �� ��ȣ�� LP������ ���, 5.7��ġ�� �ٸ� ����
				PlcSignalInf= OFF;			//0:PLC Stop,1:PLC Start
#endif
//				Delay(200);
//--------------------------------------------------------------------------------------
//	Plotocol Stop Check 2008.08.20
				Set.TimeSwitch_DevAdd= 0;		/* ksc20090525 ����Ÿ ������� �ʵ��� �����Ŀ� ����Ÿ �����ϴ� �������� �����Ͽ��� */
				Set.Ch1_iKind= UNIVERSAL;		/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
				Set.Ch2_iKind= EDITER;			/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */

				/* 2008.09.26 Plc Prc Clear�̂��ߐݒ�l���N���A���� */
				memset(Set.cPlcTypeCode,0,sizeof(Set.cPlcTypeCode));
				memset(Set.cPlcTypeAdd,0,sizeof(Set.cPlcTypeAdd));		/* ksc20090525 */
				memset(Set.cPlcTypeCode2,0,sizeof(Set.cPlcTypeCode2));	/* ksc20090525 */
				memset(Set.cPlcTypeAdd2,0,sizeof(Set.cPlcTypeAdd2));		/* ksc20090525 */

				SendPlcWaitFlag();				/* 080820 */
				for(i= 0; i < 100; i++){				//5s Timeout  /* ksc20090525 */
					if((PlchandTask == 0) && (PlcstateTask == 0) && (ConnectTask == 0) &&
						(WaitDisplayTask == 0)){
						break;
					}
					Delay(100);
				}
//--------------------------------------------------------------------------------------
				mformat();												/* ��� ���� �����͸� ����� ó�� */
				RamFlashEraze((short *)PLC1_DEV_TABLE);
				memset(&CommonArea,0,sizeof(CommonArea));
				memset(Set._TIMESWITCH,0,sizeof(Set._TIMESWITCH));
				memset(Set.TimeSwitch_DevName,0,sizeof(Set.TimeSwitch_DevName));
				strncpy(CommonArea.System,dVersion,6);			/* 20090703 */
	/*			initSet();	*/
				DeviceMonitorBuffClear(0,4);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */
				/****************************************************/
/* ksc20090525 ������� ���� �κ� */
				mWriteSettei();
	/*-------------------------------------------------------------------------------------*/			
				
				iBaseScreenCnt = 0;
				iWinScreenCnt = 0;
				iComCnt = 0;
				pcFileCnt = 0;
			}else{
#ifdef	LP_S044
				PlcMainTaskStopWait();	//Plc Main Stop
				PlcDeviceClear();		/* 20081007 */
				mformat2();				/* �t?�C���V�X�e?�̏����� */
				PlcDataSram.ParamTableCnt= 0;
				PlcDataSram.Load_Count= 0;
				memset(PlcDataSram.PLC_Pass,' ',sizeof(PlcDataSram.PLC_Pass));
				mWritePlcPass(PlcDataSram.PLC_Pass);		//20081108
#ifdef	WIN32
				memset(&GpFont[PLC_PARAM_FILE],0,4);
#else
				//�����O�X���O�ɂ���B
				RamFlashWrite((short *)PLC_PARAM_FILE,(short *)&PlcDataSram.ParamTableCnt,4);
#endif
				InitParamFile();			/* 20090703 */


				//Clear Error Info
				LedModeFlag= LED_MODE_OFF;		//�ꉞStop�ɂ��Ă���


				PlcSignalInf= ON;			//0:Stop,1:Start
#endif
			}
			*iScreenNo = USER_SCREEN_NUM;
#ifdef	LP_S044	//2009.08.26
			PlcSignalInf= ON;			//0:Stop,1:Start
#endif
		}
		else if (iKeyCode >= KEY_55 && iKeyCode <= KEY_57 ) 
		{															/*  NO		 */
			*iScreenNo = SET_ENVIRONMENT_NUM;
		} 
	}
}
void		vClearData(int* iScreenNo)
{
	int				iKeyCode;
	short			iKeyFlag;
	int				SetScreenNo;
	int				j;

	SetScreenNo= *iScreenNo;
	iKeyFlag = 1;
	iUserScreenFlag = 0;
	/**************************/

	DefaultFormDisplay(ARROW_FORM,Dspname[CLEAR_DATA].chTitle[Set.iLang]);

#ifdef	LP_S044
	for(j=0;j<2;j++)
	{
		DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+(NLine_2+(j*18)),(Dspname[CLEAR_DATA].chName[Set.iLang][j]),1,1, TRANS, T_WHITE, T_BLACK);
	}
#endif
#ifdef	GP_S044
	for(j=0;j<1;j++)
	{
		DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+(NLine_2+(j*18)),(Dspname[CLEAR_DATA].chName[Set.iLang][j]),1,1, TRANS, T_WHITE, T_BLACK);
	}
#endif
	ScroolBarDisplay(2, 0);
	DrawLcdBank1();	

	while(*iScreenNo == SetScreenNo){
		while(1){
			/* leesi 040612  iKeyCode = KeyWait();  */
			iKeyCode = iKeyReturn(SELECT_IO_NUM);
			if(iKeyFlag == 0 || iKeyCode == PC_DNLOAD_START || iKeyCode == PC_UPLOAD_START || iKeyCode == 0){	break;	}
		}
		iKeyFlag = 0;
		if(( iKeyCode == KEY_01 || iKeyCode == KEY_02  ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_43) ||
			(iKeyCode >= KEY_46 && iKeyCode <= KEY_60))) {	iKeyFlag = 1;	NormalBuzzer();	}

		switch(iKeyCode){
		case PC_DNLOAD_START:				*iScreenNo = DOWN_TRANS;		break;		/* DownLoad	*/
		case PC_UPLOAD_START:				*iScreenNo = UP_TRANS;			break;		/* UPLoad	*/
		case KEY_01: case KEY_02:	*iScreenNo = USER_SCREEN_NUM;	break;
		case KEY_13: case KEY_14: case KEY_15:	*iScreenNo = SET_ENVIRONMENT_NUM;		break;
		default:
#ifdef	LP_S044
			//1Line
			if(iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ){	*iScreenNo = CLEAR_GP_DATA_NUM;	break;	}
			//2Line
			if(iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ){	*iScreenNo = CLEAR_GLP_DATA_NUM;break;	}
			iKeyCode= -1;
#endif
#ifdef	GP_S044
			//1Line
			if(iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ){	*iScreenNo = CLEAR_GP_DATA_NUM;	break;	}
			iKeyCode= -1;
#endif
			break;
		}
		iScreenDisp = 0;
	}
}
#endif
/* ****************************************************************************** */
/*  �� �� �� : CenterDisplay()													 */
/*  ��    �� : �߽ɿ� ���߾ ���.											 */
/*  ��    �� :																	 */
/*  ��    �� : 																	 */
/*  �� �� �� : 	2002�� 6�� 30�� (��)											 */
/*  �� �� �� : 	�� �� ��														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void	CenterDisplay(int sX, int sY, int eX, int eY,char* strData)
{
	int	iLen;

	iLen = strlen(strData);
	if(eY == OVER_CODE && iLen > 3)
	{
		iLen = (short)((eX-sX) - (iLen*6))/2;
		DotTextOut(sX+iLen,sY+4,strData,0,0, NON_TRANS, T_WHITE, T_BLACK);	/* Title	*/
	}
	else
	{
		iLen = (short)((eX-sX) - (iLen*8))/2;
		DotTextOut(sX+iLen,sY,strData,1,1, NON_TRANS, T_WHITE, T_BLACK);	/* Title	*/
	}
}
