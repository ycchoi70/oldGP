void	SetNumericInput_Func(int iDispOrder);
int	DrawNumericInput_Func(int mode,_NUMERIC_INPUT_EVENT_TBL* NumericInputEventTbl,int iDispOrder);
void NumericInputWatch(int mode,int iOrder,char *DispData);
void	NumericPointDisplay(char *cDispBuffer,char *cBuffer,int iDigits,int iDecimalPoint);
void	NumericZeroDisplay(char *cDispBuffer,char *cBuffer,int iDigits);
void	NumericFormFormat(char *cTempBuffer, int iDigits, char *OrgData,int iFormFormat, long lBasicDevVal, int i1632BitFlag,short iDecimalPoint);
void RealToString(char  szReturnStr[], long lBasicDevVal, int iDigits, int iDecimalPoint);
void SPrintDecimalPointForm(char *cTempBuffer, double fNum, int iDigits, int iDecimalPoint, int iIntLength);
int	NumericalInputTouchCheck(int iOrder);

