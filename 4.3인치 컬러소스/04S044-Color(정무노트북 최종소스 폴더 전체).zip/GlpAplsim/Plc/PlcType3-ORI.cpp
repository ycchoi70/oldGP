/************************************************************/
/*	PLC TYPE 2												*/
/************************************************************/
//ARM_CPU�� ��� 7��ġ ����[GP-S044, LP-S044, GP-S057] : LITTLE_ENDIAN, 7��ġ �̻�[GP-S070, LP-S070, WIN32] : BIG_ENDIAN

#define	ARM_CPU		1
#define	LITTLE_ENDIAN	1	
// #define	BIG_ENDIAN	1
#define	PLCTYPE_CH2	1


//#define FX				1
//#define FX1S				1
//#define MK10S1			1
//#define MK200S			1
//#define N70				1
//#define N70PLUS			1
//#define THD_MODBUS		1
//#define TZ				1
//#define MT				1
//#define MP				1
//#define MASTER_MODBUS		1		/* 20111010 �߰� */
//#define MK_CNET			1
//#define FP0				1
//#define GM4				1
//#define GM6				1
//#define GM7U				1
//#define E5XX_MODBUS		1
//#define CPM1A				1
//#define DTB_MODBUS		1
//#define FPG				1
//#define XGT_CNET			1
//#define DPU_MODBUS		1
//#define MT_MODBUS			1
//#define LP_S044_P			1
//#define KR50_MODBUS		1
//#define TM4_MODBUS		1
//#define Q00J_MC_3C		1
//#define MICROLOGIC1000	1
//#define MICROLOGIC1200	1
//#define S7_200			1
//#define TK4_MODBUS		1
//#define		CT_MODBUS		1
//#define		KCU_MODBUS		1

//#define MODBUS_MASTER		1
#define  FC200_MODBUS			1		/* DANFOSS FC SERIES FC200 Modebus ���� Protocol */



//#define VLT_AQUA				1		/* ALL *//* 20111010 �߰�, ���ۼ� �������� *//* �̱����� ��û, ��������� */


//#define S7_300				1		/* ���ۼ� �������� */
//#define PMS_HS				1		/* ���ۼ� �������� */
//#define Q00J					1		/* �ۼ������� �̿ϼ� �������� */
//#define K30_MODBUS			1		/* ALL *//* �ۼ������� �̿ϼ� �������� �̻�ȭź�� ������, ����� ��û�� ���� ���� ��������  */

//#define UNIS_MODBUS			1		//CH2�� ���Ϲ��� ����
//#define TB42_MODBUS			1		// ���������� ��� ������

/* �Ʒ� ������ SH CPU �϶� App�� Protocol ���α׷��� ������ �����ϵǾ� ��ũ�ȴ�.	*/
/* SH ��ũ ȯ�濡�� ������ �������� ����� ���� �Ʒ��� �̸����� ����ϱ� �����̴�.    */
#ifdef	SH_CPU
#ifndef	WIN32
#pragma	section PlcProc2
#endif
#endif
/****************************** START **********************/
#ifdef	WIN32
#ifdef	SH_CPU
#define	const
#endif

#ifdef	FX	
#define		TYPE_FX1N	1					/* 01 */
/* #include	"PlcTypeFx.cpp" */
#include	"Plc_Mitsubishi_FX.cpp"         /* FX3U ���� ��� */
#endif
#ifdef	FX1S
#define		TYPE_FX1S	1					/* 02 */
/* #include	"PlcTypeFx.cpp" */
#include	"Plc_Mitsubishi_FX.cpp"
#endif
#ifdef	MK10S1								/* 03 */
/* #include	"PLgmk10s1.cpp" */
#include	"Plc_LS_MK10S1.cpp"
#endif
#ifdef	MK200S								/* 04 */
/* #include	"PlcTypeLg.cpp" */
#include	"Plc_LS_MK200S.cpp"
#endif
#ifdef	N70 /* FPG PLC SAME */				/* 05 */
#define		PLC_SPEED	RS_19200
/* #include	"Plcsm_70n.cpp" */
#include	"Plc_Samsung_N70.cpp"
#endif
#ifdef	N70PLUS								/* 06 */
/* #include	"Plcsm2_70p.cpp" */
#include	"Plc_Samsung_N70PLUS.cpp"
#endif
#ifdef	THD_MODBUS							/* 07 */
/* #include	"PlcThdM.cpp" */
#include	"Plc_MODBUS_ALL.cpp"
#endif
#ifdef	TZ									/* 08 */
/* #include	"PlcTypeTZ.cpp" */
#include	"Plc_Autonics_TZ.cpp"
#endif
#ifdef	MT									/* 09 */
/* #include	"PlcTypeMT.cpp" */
#include	"Plc_Autonics_MT.cpp"
#endif
#ifdef	MP									/* 10 */
/* #include	"PlcTypeMP.cpp" */
#include	"Plc_Autonics_MP.cpp"
#endif
#ifdef	MASTER_MODBUS						/* 11 */
/* #include	"PlcModMS.cpp" */
/* #include	"Plc_Modicon_MASTER_MODBUS.cpp"	*/
#include	"Plc_MODBUS_ALL.cpp"
#endif
#ifdef	MK_CNET								/* 12 */
/* #include	"PlcLGcnet.cpp" */
#include	"Plc_LS_MK_CNET.cpp"
#endif

#ifdef	UNIS_MODBUS							/* 13 */	
/* #include	"Plc_UniS.cpp" */
#include	"Plc_Autonics_UNIS_MODBUS.cpp"
#endif
#ifdef	FP0									/* 14 */
#define		PLC_SPEED	RS_9600
/* #include	"Plcsm_70n.cpp" */
#include	"Plc_Samsung_N70.cpp"
#endif
#ifdef	GM4									/* 15 */
#define	MAX_UR_CNT	 25 /* Max Monitor ��� ���� */
#define MAX_MOR_CNT 100
/* #include	"PlcTypeGM.cpp" */
#include	"Plc_LS_GM.cpp"
#endif
#ifdef	GM6									/* 16 */
#define	MAX_UR_CNT	 25 /* Max Monitor ��� ���� */
#define MAX_MOR_CNT 100
/* #include	"PlcTypeGM.cpp" */
#include	"Plc_LS_GM.cpp"
#endif
#ifdef	GM7U								/* 17 */
#define	MAX_UR_CNT	 16  /* Max Monitor ��� ���� */
#define MAX_MOR_CNT  64	
/* #include	"PlcTypeGM.cpp" */
#include	"Plc_LS_GM.cpp"
#endif
#ifdef	E5XX_MODBUS							/* 18 */	
/* #include	"PlcOmronE5CN_Mod.cpp" */
/* #include	"Plc_Omron_E5CN_MODBUS.cpp" */
#include	"Plc_MODBUS_E5.cpp"
#endif
#ifdef	CPM1A								/* 19 */
/* #include	"PlcTypeCPM1A.cpp" */
#include	"Plc_Omron_CPM1A.cpp"
#endif
#ifdef	DTB_MODBUS							/* 20 */
/* #include	"PlcDeltaB_Mod.cpp" */
#include	"Plc_MODBUS_ALL.cpp"
#endif
#ifdef	FPG									/* 21 */
#define		PLC_SPEED	RS_19200
/* #include	"Plcsm_70n.cpp" */
#include	"Plc_Samsung_N70.cpp"
#endif
#ifdef	XGT_CNET							/* 22 */
/* #include	"PlcXGTcnet.cpp" */
#include	"Plc_LS_XGT_CNET.cpp"
#endif
#ifdef	DPU_MODBUS							/* 23 */
/* #include	"Plc_Konics_Mod2.cpp" */
#include	"Plc_MODBUS_ALL.cpp"
#endif
#ifdef	TB42_MODBUS							/* 24 */
/* #include	"Plc_Tb42_Mod.cpp" */
#include	"Plc_Autonics_TB42_MODBUS.cpp"
#endif

#ifdef	S7_200								/* 25 */
#include	"Plc_Simens_S7_200.cpp"
#endif
#ifdef	S7_300								/* 26 */
#include	"Plc_Simens_S7_300.cpp"
#endif
#ifdef	MICROLOGIC1000
#define PLC_SPEED	RS_9600						/* 27 */
#include	"Plc_Allenbradley_MICROLOGIC.cpp"
#endif
#ifdef	MICROLOGIC1200	
#define PLC_SPEED	RS_19200					/* 28 */
#include	"Plc_Allenbradley_MICROLOGIC.cpp"
#endif
#ifdef	MT_MODBUS							/* 30 */
#include	"Plc_MODBUS_ALL.cpp"
#endif
#ifdef	PMS_HS								/* 31 */
#include	"Plc_Autonics_PMS_HS.cpp"
#endif
#ifdef	Q00J								/* 32 */
#include	"Plc_Mitsubishi_Q00J.cpp"
#endif
#ifdef	LP_S044_P								/* 33 */
#include	"Plc_Autonics_LP_S044.cpp"
#endif
#ifdef	KR50_MODBUS							/* 34 */
#include	"Plc_MODBUS_ALL.cpp"
#endif
#ifdef	TM4_MODBUS							/* 35*/
#include	"Plc_MODBUS_ALL.cpp"
#endif
#ifdef	Q00J_MC_3C							/* 36*/
#include	"Plc_Mitsubishi_Q00J_MC_3C.cpp"
#endif

#ifdef	TK4_MODBUS							/* 37 */
#include	"Plc_MODBUS_ALL.cpp"
#endif
#ifdef	K30_MODBUS							/* 38 */
#include	"Plc_MODBUS_ALL.cpp"
#endif
#ifdef	CT_MODBUS							/* 39 */
#include	"Plc_MODBUS_ALL.cpp"
#endif

#ifdef	VLT_AQUA							/* 40 */
#include	"Plc_MODBUS_ALL.cpp"
#endif

#ifdef	MODBUS_MASTER						/* 41 */
#include	"Plc_MODBUS_Master.cpp"
#endif

#ifdef	KCU_MODBUS							/* 42 */
#include	"Plc_MODBUS_ALL.cpp"
#endif

#ifdef	FC200_MODBUS						/* 44 */
#include	"Plc_FC200_Mod_A.cpp"
#endif


#else




#ifdef	FX	
#define		TYPE_FX1N	1								
/* #include	"PlcTypeFx.c" */
#include	"Plc_Mitsubishi_FX.c"
#endif
#ifdef	FX1S
#define		TYPE_FX1S	1					
/* #include	"PlcTypeFx.c" */
#include	"Plc_Mitsubishi_FX.c"
#endif
#ifdef	MK10S1
/* #include	"PLgmk10s1.c" */
#include	"Plc_LS_MK10S1.c"
#endif
#ifdef	MK200S
/* #include	"PlcTypeLg.c" */
#include	"Plc_LS_MK200S.c"
#endif
#ifdef	N70 /* FPG PLC SAME */				
#define		PLC_SPEED	RS_19200
/* #include	"Plcsm_70n.c" */
#include	"Plc_Samsung_N70.c"
#endif
#ifdef	N70PLUS
/* #include	"Plcsm2_70p.c" */
#include	"Plc_Samsung_N70PLUS.c"
#endif
#ifdef	THD_MODBUS
/* #include	"PlcThdM.c" */
#include	"Plc_MODBUS_ALL.c"
#endif
#ifdef	TZ
/* #include	"PlcTypeTZ.c" */
#include	"Plc_Autonics_TZ.c"
#endif
#ifdef	MT
/* #include	"PlcTypeMT.c" */
#include	"Plc_Autonics_MT.c"
#endif
#ifdef	MP
/* #include	"PlcTypeMP.c" */
#include	"Plc_Autonics_MP.c"
#endif
#ifdef	MASTER_MODBUS
/* #include	"PlcModMS.c" */
/* #include	"Plc_Modicon_MASTER_MODBUS.c"	*/
#include	"Plc_MODBUS_ALL.c"
#endif
#ifdef	MK_CNET
/* #include	"PlcLGcnet.c" */
#include	"Plc_LS_MK_CNET.c"
#endif

#ifdef	UNIS_MODBUS
/* #include	"Plc_UniS.c" */
#include	"Plc_Autonics_UNIS_MODBUS.c"
#endif
#ifdef	FP0
#define		PLC_SPEED	RS_9600
/* #include	"Plcsm_70n.c" */
#include	"Plc_Samsung_N70.c"
#endif
#ifdef	GM4									
#define	MAX_UR_CNT	 25 /* Max Monitor ��� ���� */
#define MAX_MOR_CNT 100
/* #include	"PlcTypeGM.c" */
#include	"Plc_LS_GM.c"
#endif
#ifdef	GM6									
#define	MAX_UR_CNT	 25 /* Max Monitor ��� ���� */
#define MAX_MOR_CNT 100
/* #include	"PlcTypeGM.c" */
#include	"Plc_LS_GM.c"
#endif
#ifdef	GM7U								
#define	MAX_UR_CNT	 16  /* Max Monitor ��� ���� */
#define MAX_MOR_CNT  64	
/* #include	"PlcTypeGM.c" */
#include	"Plc_LS_GM.c"
#endif
#ifdef	E5XX_MODBUS
/* #include	"PlcOmronE5CN_Mod.c" */
/* #include	"Plc_Omron_E5CN_MODBUS.c" */
#include	"Plc_MODBUS_E5.c"
#endif
#ifdef	CPM1A
/* #include	"PlcTypeCPM1A.c" */
#include	"Plc_Omron_CPM1A.c"
#endif
#ifdef	DTB_MODBUS									
/* #include	"PlcDeltaB_Mod.c" */
#include	"Plc_MODBUS_ALL.c"
#endif
#ifdef	FPG									
#define		PLC_SPEED	RS_19200
/* #include	"Plcsm_70n.c" */
#include	"Plc_Samsung_N70.c"
#endif
#ifdef	XGT_CNET								
/* #include	"PlcXGTcnet.c" */
#include	"Plc_LS_XGT_CNET.c"
#endif
#ifdef	DPU_MODBUS								
/* #include	"Plc_Konics_Mod2.c" */
#include	"Plc_MODBUS_ALL.c"
#endif
#ifdef	TB42_MODBUS								
/* #include	"Plc_Tb42_Mod.cpp" */
#include	"Plc_Autonics_TB42_MODBUS.c"
#endif

#ifdef	S7_200
#include	"Plc_Simens_S7_200.c"
#endif
#ifdef	S7_300
#include	"Plc_Simens_S7_300.c"
#endif
#ifdef	MICROLOGIC1000
#define PLC_SPEED	RS_9600						/* 27 */
#include	"Plc_Allenbradley_MICROLOGIC.c"
#endif
#ifdef	MICROLOGIC1200
#define PLC_SPEED	RS_19200					/* 28 */
#include	"Plc_Allenbradley_MICROLOGIC.c"
#endif
#ifdef	MT_MODBUS
#include	"Plc_MODBUS_ALL.c"
#endif
#ifdef	PMS_HS
#include	"Plc_Autonics_PMS_HS.c"
#endif
#ifdef	Q00J
#include	"Plc_Mitsubishi_Q00J.c"
#endif
#ifdef	LP_S044_P								
#include	"Plc_Autonics_LP_S044.c"
#endif
#ifdef	KR50_MODBUS							/* 33 */
#include	"Plc_MODBUS_ALL.c"
#endif
#ifdef	TM4_MODBUS							/* 34 */
#include	"Plc_MODBUS_ALL.c"
#endif
#ifdef	Q00J_MC_3C							/* 35 */
#include	"Plc_Mitsubishi_Q00J_MC_3C.c"
#endif

#ifdef	TK4_MODBUS							/* 36 */
#include	"Plc_MODBUS_ALL.c"
#endif
#ifdef	K30_MODBUS							/* 37 */
#include	"Plc_MODBUS_ALL.c"
#endif
#ifdef	CT_MODBUS							/* 38 */
#include	"Plc_MODBUS_ALL.c"
#endif

#ifdef	VLT_AQUA							/* 40 */
#include	"Plc_MODBUS_ALL.c"
#endif

#ifdef	MODBUS_MASTER						/* 41 */
#include	"Plc_MODBUS_Master.c"
#endif

#ifdef	KCU_MODBUS							/* 39 */
#include	"Plc_MODBUS_ALL.c"
#endif

#ifdef	FC200_MODBUS						/* 44 */
#include	"Plc_FC200_Mod_A.c"
#endif


#endif
 
/****************************** END **********************/


/* SH_CPU�� ARM_CPU�� �ҽ��� �����ϰ� ��� 	#define���� ���� */
/* PLCTYPE_CH1�� PLCTYPE_CH2�� �ҽ��� �����ϰ� ��� 	#define���� ���� */
/* #ifdef PLCTYPE_ELSE2 �� PLCTYPE_CH2�� ���� */
/* #ifndef PLCTYPE_ELSE2 �� PLCTYPE_CH1�� ���� */
/* #ifdef PLCTYPE_ELSE2�� #else �κ��� PLCTYPE_CH1�� ���� */
