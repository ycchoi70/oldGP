/****************************************************************************************/
/*	PLC MITSUBISHI(Q00J MC 3C)		  										     		*/
/*																						*/
/*	MC(MELSEC COMPUNICATiON) PROTOCOL�߿��� QnAȣȯ3C������ ������ Q00J CPU ����̹�	*/
/*																						*/
/*	< �������� >																		*/
/*	CheckSum		: ���																*/
/*	Default Speed	: 9600bps															*/
/*	Default DataBit : 8bit																*/
/*	Default Parity	: ODD																*/
/****************************************************************************************/
#ifdef WIN32
#include <windows.h>
#endif

#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

#define PROTOCOL_TYPE	1	/* �������� Ÿ�� 1~4(5) */

#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include	"hook_plcapl.h"

/*****************************************************************************************/
/* PLCTYPE_CH1, PLCTYPE_CH2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET			"V3.3M"
/*****************************************************************************************/




/*
#ifdef WIN32
#include <stdio.h>
	char szDebug[1024];
#endif
*/


#define	MAX_BITCNT	512
#define	MAX_WORDCNT	512
/*
#define	MAX_PBITCNT	16
#define	MAX_PWORDCNT	10
#define	MAX_UR_CNT	26
*/
#define	MAX_WORD_CONT_CNT	1
#define	MAX_BIT_CONT_CNT	1

#define	MAX_RTY_COUNT	3

#ifdef	SH_CPU
static	int	GroopSema;			/* Grooping Semafo */
static	int	GroopingFlag;		/* Grooping ON */
static	int	LgCommSeq;
static	int	LgConnectFlag;		/* Write Record Count */

static	unsigned char gReadBlockNo;		/* �б� ���� ��ȣ */
static	unsigned char gWriteBlockNo;	/* ���� ���� ��ȣ */
static  unsigned char gGukNo;			/* ���� */

#endif
#ifdef	ARM_CPU
/* PLC COmBUFF �� ������ ����. ARM�ϰ�� ��ũ�� ��巹���� ���ϱ� ������ ���� ������ ��� */
#endif



static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int rCnt, int *pfrmSize);

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/****************************************************************************************************/
/* ���� �������� �ҽ� ���� */
/****************************************************************************************************/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH1, PLCTYPE_CH2 ���� ����ϴ� �Լ� ���� */ 

static	const	DEV_TBL bPLCDeviceTbl[16] = {
	{"M",  0x0090, 1},
	{"SM", 0x0091, 1},
	{"L",  0x0092, 1},
	{"F",  0x0093, 1},
	{"X",  0x009c, 2},
	{"Y",  0x009d, 2},
	{"B",  0x00a0, 2},
	{"TS", 0x00c1, 1},
	{"CS", 0x00c4, 1},
};
static	const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"D",  0x00a8, 1},
	{"SD", 0x00a9, 1},
	{"W",  0x00b4, 2},
	{"TN", 0x00c2, 1},
	{"CN", 0x00c5, 1},
};

/* connection ���˿����� ��� �� ����̽��� ����Ÿ ����̽�[D]�� �����Ѵ�. */
#define		DEVICE_FOR_CONNECT_CHECK	0xc0

/********************************************************************************/
/*	Func:C_SendRecPLC															*/
/*      PLC�� �۽�(���Ź��۸� �μ��� �Ѱ���)									*/
/*																				*/
/*	[PARAM]																		*/
/*  (IN) int mode: �۽� ���													*/
/*			0: �۽Ÿ�, 1:�۽��� ACK����,										*/ 
/*			2:�۽��� ����Ÿ ����,												*/
/*			3:�۽��� ACK + ����Ÿ ����											*/
/*	(OUT)unsigned char *RecData:���� ����Ÿ ����								*/
/*	(OUT)int *Cnt:���� ���ڼ� 													*/
/*	(IN) int rmode:���� ���													*/
/*			0:���� ����Ÿ �״��,												*/
/*			1:���ŵ���Ÿ�� ���̳ʸ��� ��ȯ										*/
/*	(IN) int sCnt:�۽� ���ڼ�													*/
/*	(IN) char *sBuff:�۽� ����													*/
/*	(IN) int TimeOut:�۽��� ���Ŵ��ð� (ms)									*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef	PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
																				
/********************************************************************************/
/*	Func:C_SendPC2PLCData														*/
/*      PLC�� �۽�(���Ź��۸� �μ��� �Ѱ����� ����)								*/
/*																				*/
/*	[PARAM]																		*/
/*  (IN) int mode: �۽� ���													*/
/*			0: �۽Ÿ�, 1:�۽��� ACK����, 2:�۽��� ����Ÿ ����,					*/
/*			3:�۽��� ACK + ����Ÿ ����											*/
/*	(IN) int Cnt:�۽� ���ڼ� 													*/
/*	(IN) char *buff:�۽� ����													*/
/*			0:���� ����Ÿ �״��,1:���ŵ���Ÿ�� ���̳ʸ��� ��ȯ					*/
/*	(IN) int TimeOut:�۽��� ���Ŵ��ð� (ms)									*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}

/********************************************************************************/
/*	Func:C_Get_Ms_Sel															*/
/*		Master,Slave �� ��ż��� ��ġ �����б�  								*/
/*																				*/
/*	[RETRUN]																	*/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master					*/
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set			*/
/********************************************************************************/
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}

/********************************************************************************/
/*	Func:C_GetMonBaudrate														*/
/*		Boadrate ���� �б�  													*/
/*																				*/
/*	[PARAM]																		*/
/*	(out)int *Speed:Speed 														*/
/*	(out)int *DataBit;Data Bit													*/
/*	(out)int *Parity:Parity														*/
/********************************************************************************/
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_115200;
	*DataBit= RS_DATA8;
	*Parity= ((RS_XONOFF << 16) |(RS_STOP01 << 8) | (RS_ODD << 0));		/* 20090527 */	
}

/********************************************************************************/
/*	Func:GetGroopSema															*/
/*		PLC Semafor : �⺻������ �浹�� �Ͼ�� �ʵ��� �ϴ� ��� 				*/
/*          ����͸� ����Ҷ��� ��ȿ, CH1���� �۽��� �������Ʈ�� ��ȣ��		*/
/*			����ö� ���� PLC�� ������ �ְ� �ޱ� ���ؼ� �켱 ó������ �����	*/
/*			�Ϸ�ɶ����� ���													*/
/********************************************************************************/
static	void	GetGroopSema(void)
{
	unsigned int	NowTime;
	unsigned int	StartTime;

	if(GroopSema == 0){		/* Grooping Sema */
	}else{
		StartTime= B_GetNowTime();
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
			NowTime= B_GetNowTime();
			if((StartTime+ 3000) < NowTime){
				GroopSema= 0;
			}
			B_Delay(10);
		}
	}
	GroopSema++;
}

/********************************************************************************/
/*	Func:ResetGroopSema															*/
/*		PLC Semafor Crear														*/
/********************************************************************************/
static	void	ResetGroopSema(void)
{
	GroopSema= 0;
}


/********************************************************************************/
/*   FUNC  : C_PlcReadProc														*/
/*			PLC Recieve Handler													*/
/*			�ѹ��ھ� �����ؼ� ���Ź��ۿ� �ְ� �� �������� ������ �޾Ҵ���		*/
/*			 Ȯ���Ѵ�.															*/
/*																				*/
/*	[PARAM]																		*/
/*	(in) unsigned char data: �ѹ��� ���ŵ���Ÿ 									*/
/*	(in) int *CommMode:���Ÿ��(TYPE�� ���� �ٸ�)								*/
/*	(out)int *RecCnt:����ī��Ʈ													*/
/*	(out)unsigned char *RecBuff:���ŵ���Ÿ ����									*/
/*																				*/
/*	[RETUN]																		*/
/*	0:���ſϷ�(����Ÿ��ũ �⵿), -1:��� ������									*/
/********************************************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	/* ���Ź��۰� ���� ü�����µ��� ������ ó���� ���� ���� ��� ���Ź��۸� ����. */
	if(*RecCnt >= PLC_BUF_MAX){
		*CommMode = 0;
		*RecCnt = 0;
		B_gmemset((char*)RecBuff, 0x00, PLC_BUF_MAX);
	}

	/* ���Ź��ۿ� ����Ÿ �ֱ� */
	RecBuff[(*RecCnt)++] = data;

#if	  PROTOCOL_TYPE == 1

	/* Type1�� ��� CommMode								*/
	/********************************************************/
	/* 0 : ���ſϷ�											*/
	/* 1 : STX ������, ����Ÿ ���� ���� ����				*/
	/* 2 : ETX ������, CheckSum 1th���� ���Ű��ɻ���		*/
	/* 3 : CheckSum 1th���� ���ſϷ�, 2th���� ���Ű��ɻ���	*/
	/* 4 : NAC ������, ����Ÿ ���� ���� ���� ����			*/
	/* 5 : ACK ������, ����Ÿ ���� ���� ���� ����			*/

	if(data == STX)			{ *CommMode = 1; }
	else if(data == ETX)	{ *CommMode = 2; }
	else if(*CommMode == 2)	{ *CommMode = 3; }
	else if(data == NAK)	{ *CommMode = 4; }
	else if(data == ACK)	{ *CommMode = 5; }
	else if(*CommMode == 3)	{ *CommMode = 0; }

	if( (*CommMode == 4 && *RecCnt == 15) ||
		(*CommMode == 5 && *RecCnt == 11)	)
	{
		*CommMode = 0;
	}

#elif PROTOCOL_TYPE == 2

	/* Type2�� ��� CommMode								*/
	/********************************************************/
	/* 0 : ���ſϷ�											*/
	/* 1 : STX ������, ����Ÿ ���� ���� ����				*/
	/* 2 : ETX ������, CheckSum 1th���� ���Ű��ɻ���		*/
	/* 3 : CheckSum 1th���� ���ſϷ�, 2th���� ���Ű��ɻ���	*/
	/* 4 : NAC ������, ����Ÿ ���� ���� ���� ����			*/
	/* 5 : ACK ������, ����Ÿ ���� ���� ���� ����			*/
	
	if(data == STX)			{ *CommMode = 1; }
	else if(data == ETX)	{ *CommMode = 2; }
	else if(*CommMode == 2)	{ *CommMode = 3; }
	else if(data == NAK)	{ *CommMode = 4; }
	else if(data == ACK)	{ *CommMode = 5; }
	else if(*CommMode == 3)	{ *CommMode = 0; }
	
	if( (*CommMode == 4 && *RecCnt == 17) ||
		(*CommMode == 5 && *RecCnt == 13)	)
	{
		*CommMode = 0;
	}

#elif PROTOCOL_TYPE == 3

	/* Type3�� ��� CommMode								*/
	/********************************************************/
	/* 0 : ���ſϷ�											*/
	/* 1 : STX ������, ����Ÿ ���� ���� ����				*/
	/* 2 : ETX ������, CheckSum 1th���� ���Ű��ɻ���		*/
	/* 3 : CheckSum 1th���� ���ſϷ�, 2th���� ���Ű��ɻ���	*/
	
	if(data == STX)			{ *CommMode = 1; }
	else if(data == ETX){
		if(*RecCnt >= 16){
			if(B_gstrncmp((char*)&RecBuff[11], "QACK", 4) == OK)
			{
				if(*RecCnt == 16)	*CommMode = 0;
				else				*CommMode = 2;
			}
			else
			{
				*CommMode = 0;
			}
		}
	}
	else if(*CommMode == 2)	{ *CommMode = 3; }
	else if(*CommMode == 3)	{ *CommMode = 0; }
	
#elif PROTOCOL_TYPE == 4

	/* Type4�� ��� CommMode								*/
	/********************************************************/
	/* 0 : ���ſϷ�											*/
	/* 1 : STX ������, ����Ÿ ���� ���� ����				*/
	/* 2 : ETX ������, CheckSum 1th���� ���Ű��ɻ���		*/
	/* 3 : CheckSum 1th���� ���ſϷ�, 2th���� ���Ű��ɻ���	*/
	/* 4 : CheckSum 2th���� ���ſϷ�, CR���� ���Ű��� ����	*/
	/* 5 : NAC ������, ����Ÿ ���� ���� ���� ����			*/
	/* 6 : ACK ������, ����Ÿ ���� ���� ���� ����			*/
	/* 7 : CR ������, LF ���� ���� ����						*/
	/* 8 : LF ������, ���ſϷ�								*/

	if(data == STX)			{ *CommMode = 1; }
	else if(data == ETX)	{ *CommMode = 2; }
	else if(*CommMode == 2)	{ *CommMode = 3; }
	else if(*CommMode == 3)	{ *CommMode = 4; }
	else if(data == NAK)	{ *CommMode = 5; }
	else if(data == ACK)	{ *CommMode = 6; }
	else if(data == CR)		{ *CommMode = 7; }
	else if(data == LF)		{ *CommMode = 0; }	
	
#elif PROTOCOL_TYPE == 5
#endif

	ret = (*CommMode == 0) ? 0 : -1;
/*
#ifdef WIN32
	sprintf(szDebug, "-->[%d](%d) : [%c][%02x]\n", *RecCnt, ret, data, data);
	OutputDebugString(szDebug);
#endif
*/

	return(ret);
}


/********************************************************************************/
/*   FUNC  : SetPLCBCC															*/
/*			���� �����ӿ� BCC�� �߰��ؼ� ������ �ϼ�							*/
/*																				*/
/*	[PARAM]																		*/
/*	(inout)	char *buff:����Ÿ													*/
/*	(in)	int cnt:����Ÿ ����(checksum�� �ֱ� �������� ����Ÿũ��)			*/
/*																				*/
/*	[RETRUN]																	*/
/*	�ۼ��� ���� ����Ÿ��														*/
/********************************************************************************/
static	int SetPLCBCC(unsigned char *buff,int cnt)
{
	int		i;
	unsigned char bcc;

	bcc = 0;
	for(i = 1; i < cnt; i++){
		bcc += buff[i];
	}
	B_Bin2Hex(bcc&0x00ff,2,(char *)&buff[cnt]);

#if	  PROTOCOL_TYPE == 4
	buff[cnt+2] = CR;
	buff[cnt+3] = LF;
	return(cnt + 4);
#else
	return(cnt + 2);
#endif	
}

/********************************************************************************/
/*	Func:SendRecPLCWithBCC														*/
/*		�۽ŵ���Ÿ�� BCC �ΰ��Ͽ� PLC�� �۽� 									*/
/*		������ BCC üũ�� Retry 												*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	int mode: �۽� ���													*/
/*			0: �۽Ÿ�, 1:�۽��� ACK����, 2:�۽��� ����Ÿ ����,					*/
/*			3:�۽��� ACK + ����Ÿ ����											*/
/*	(inout)	unsigned char *combuf:�۽� ����										*/
/*	(in)	int sCnt: ������������ ũ��(byte)									*/
/*	(out)	unsigned char *RecData:���� ����Ÿ ����								*/
/*	(out)	int *rCnt:���� ���ڼ�												*/
/*	(in)	int rmode:���� ���													*/
/*			0:���� ����Ÿ �״��,1:���ŵ���Ÿ�� ���̳ʸ��� ��ȯ��				*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	SendRecPLCWithBCC(int mode,unsigned char *combuf, int sCnt, unsigned char *RecData,int *rCnt,int rmode)
{
	int		i;
	int		ret;
	int		rty_cnt;
	unsigned char bcc;
	unsigned char bcc1;
	int		SendCnt;

	SendCnt= SetPLCBCC(combuf, sCnt);
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
		ret= C_SendRecPLC(mode,RecData,rCnt,rmode,SendCnt,(char *)combuf,2000);
		if(ret == 0)
		{
			if(mode <= 1)
			{
			}
			else
			{

#if	  PROTOCOL_TYPE == 1 || PROTOCOL_TYPE == 2
				if(RecData[0] == STX)
				{
					/* ������ üũ�� ���� */
					bcc1= (unsigned char)B_Hex2nBin((char *)&RecData[*rCnt-2],2);

					/* ���� üũ�� ��� */					
					bcc= 0;
					for(i = 1; i < (*rCnt)-2; i++){
						bcc += RecData[i];
					}
					bcc &= 0x00ff;

					/* ������ üũ���� ���� ����� üũ�� �� */
					if(bcc != bcc1){
						ret= -1;
					}
				}

#elif PROTOCOL_TYPE == 3
				if(B_gstrncmp((char*)&RecData[11], "QACK", 4) == OK)
				{
					if(*rCnt>=16 && RecData[15]==ETX)	/* ���⿡ ���� ���� */
					{
						ret = OK;
					}
					else								/* �б⿡ ���� ���� */
					{
						/* ������ üũ�� ���� */
						bcc1= (unsigned char)B_Hex2nBin((char *)&RecData[*rCnt-2],2);
						
						/* ���� üũ�� ��� */					
						bcc= 0;
						for(i = 1; i < (*rCnt)-2; i++){
							bcc += RecData[i];
						}
						bcc &= 0x00ff;
						
						/* ������ üũ���� ���� ����� üũ�� �� */
						if(bcc != bcc1){
							ret= -1;
						}
					}
				}

#elif PROTOCOL_TYPE == 4
				if(RecData[0] == STX)
				{
					/* ������ üũ�� ���� */
					bcc1= (unsigned char)B_Hex2nBin((char *)&RecData[*rCnt-4],2);
					
					/* ���� üũ�� ��� */					
					bcc= 0;
					for(i = 1; i < (*rCnt)-4; i++){
						bcc += RecData[i];
					}
					bcc &= 0x00ff;
					
					/* ������ üũ���� ���� ����� üũ�� �� */
					if(bcc != bcc1){
						ret= -1;
					}
				}
#endif
			}
		}
		if(ret == OK){
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}
	return(ret);
}


/********************************************************************************/
/*	Func:C_Connection															*/
/*		PLC ���� üũ															*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	int *PlcType:�̻��													*/
/*	(in)	int iConnect:PLC ���� ����											*/
/*			0:RS-422,1:RS-232C													*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:Error,1:Connect OK														*/
/********************************************************************************/
static	int	C_Connection( int *PlcType,int iConnect )
{
	int		i;
	int		ret;
	int		Speed;
	int		DataBit;
	int		Parity;
	int		frmSize, SendCnt;
	int		rCnt;
	unsigned char bcc;
	unsigned char bcc1;
	char DeviceName[2];
	


	/* ���� ���� �б� */
	gGukNo = *(PlcType+2);		/* Stattion */ 	

	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */
		if(iConnect == CH_CH1){		/* RS-232C */
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
		}else{						/* RS-422 */
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
		}
#ifdef	WIN32
		while(1){
			if(SioPLCOpenFlag == 0){
				break;
			}
			B_Delay(10);
		}
#endif
		B_Delay(100);
	}
	monitorModeFlag= PlcType[4];		/* 20090704 */

	/* connection�� ������ ����� */
/*	B_gmemcpy((char*)PlcSendBuff, (char*)connFrame, sizeof(connFrame)); */
	DeviceName[0] = (char)DEVICE_FOR_CONNECT_CHECK;
	ret = MakePLCReadData(1, DeviceName, 0, (char *)PlcSendBuff, 1, &frmSize);
	if(ret != 0){ return -1; }
	SendCnt= SetPLCBCC(PlcSendBuff, frmSize);
	ret= C_SendRecPLC(2, PlcRecBuff, &rCnt, 0, SendCnt,(char *)PlcSendBuff, 2000);
	if(ret == 0)
	{			
#if	  PROTOCOL_TYPE == 1 || PROTOCOL_TYPE == 2
		if(PlcRecBuff[0] == STX)
		{
			/* ������ üũ�� ���� */
			bcc1= (unsigned char)B_Hex2nBin((char *)&PlcRecBuff[rCnt-2],2);
			
			/* ���� üũ�� ��� */					
			bcc= 0;
			for(i = 1; i < rCnt-2; i++){
				bcc += PlcRecBuff[i];
			}
			bcc &= 0x00ff;
			
			/* ������ üũ���� ���� ����� üũ�� �� */
			if(bcc != bcc1){
				ret= -1;
			}
		}
			
#elif PROTOCOL_TYPE == 3
		if(B_gstrncmp((char*)&PlcRecBuff[11], "QACK", 4) == OK)
		{
			if(rCnt>=16 && PlcRecBuff[15]==ETX)	/* ���⿡ ���� ���� */
			{
				ret = OK;
			}
			else								/* �б⿡ ���� ���� */
			{
				/* ������ üũ�� ���� */
				bcc1= (unsigned char)B_Hex2nBin((char *)&PlcRecBuff[rCnt-2],2);
				
				/* ���� üũ�� ��� */					
				bcc= 0;
				for(i = 1; i < rCnt-2; i++){
					bcc += PlcRecBuff[i];
				}
				bcc &= 0x00ff;
				
				/* ������ üũ���� ���� ����� üũ�� �� */
				if(bcc != bcc1){
					ret= -1;
				}
			}
		}
		
#elif PROTOCOL_TYPE == 4
		if(PlcRecBuff[0] == STX)
		{
			/* ������ üũ�� ���� */
			bcc1= (unsigned char)B_Hex2nBin((char *)&PlcRecBuff[rCnt-4],2);
			
			/* ���� üũ�� ��� */					
			bcc= 0;
			for(i = 1; i < rCnt-4; i++){
				bcc += PlcRecBuff[i];
			}
			bcc &= 0x00ff;
			
			/* ������ üũ���� ���� ����� üũ�� �� */
			if(bcc != bcc1){
				ret= -1;
			}
		}
#endif
	}
	

	ResetGroopSema();

 	LgCommSeq= 0;
 	LgConnectFlag= 0;

	/*
 	PlcThruMonCnt= 0;		// Thru Mon 070214
 	PlcThruRecCnt= 0;		// Thru Mon 070214
 	B_gmemset((char *)PlcThruRecDataCnt,0,sizeof(PlcThruRecDataCnt));
	*/

	if(ret < 0){
		return(0);
	}

	ret= 1;
	LgConnectFlag= 1;
	return(ret);
}

/********************************************************************************/
/*	Func:SetPLCDevAddr															*/
/*		PLC ����̽� �������� ��巹���� ���									*/
/*																				*/
/*	[PARAM]																		*/
/*	(out)	int *PLCByteCnt:Bit Device Count Addr								*/
/*	(out)	int *PLCWordCnt:Word Device Count Addr								*/
/*	(out)	DEV_PC_TBL **ByteTbl:Bit Device Table Addr							*/
/*	(out)	DEV_PC_TBL **WordTbl:Word Device Table Addr							*/
/*	(out)	unsigned char **PLCIndex:Code2Index Table Addr						*/
/********************************************************************************/

static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif

#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif
}

/********************************************************************************/
/*	Func:C_GetDevNamePLC														*/
/*		Device Name�� ���														*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	int bFlag:0:Bit1:Word												*/
/*	(in)	unsigned char *src:Device Code Addr									*/
/*	(out)	char *obj:Device Name Addr											*/
/*	(out)	int *DevInfo:Device Info Addr										*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}

static	void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;
	
	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	if(data < 0){			/* - check 041116 */
		
		data *= -1;
		buff[0]= '-';
		for(i= 1; i < cnt+1; i++){								/*cnt+1�̵� ������ */
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}else{
		for(i= 0; i < cnt; i++){
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}
	buff[i]= 0;
}

/********************************************************************************/
/*	Func:MakePLCDevAddress														*/
/*		 Make PLC ABS ADDRESS													*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	int mode:0:Bit1:Word												*/
/*	(in)	char *pDevice:Device index Code										*/
/*	(in)	int Address:User Device Addr										*/
/*	(out)	char *pDevName: Devcie Name											*/
/*	(out)	char *pDevAddr: Device�� ǥ����Ŀ� ���� �ּҸ� 10��,16�� ���ڿ���	*/
/*							ǥ���ȴ�.											*/
/*	(out)	int *DevCode : CPU TOOL ��Ż󿡼� ����ϴ� device code				*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, char *pDevName, char *pDevAddr, unsigned short *DevCode)
{
	int		i;
	int		ret;
	char	Device[4];

	ret = -1;

	/* Device Name */
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}

	/* Device Name Copy */
	B_gstrcpy(pDevName, Device);

	if(mode == 0)			/* Bit Device */
	{
		if(Device[0] == 'U'){	ret = -1; }		/* UB */
		else
		{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++)
			{
				if(bPLCDeviceTbl[i].Device[0] == 0){ break;	}				
				if(B_gstrcmp((char *)&bPLCDeviceTbl[i].Device[0], Device) == 0)
				{
					DeviceFlag= bPLCDeviceTbl[i].flag;
					*DevCode = (unsigned short)bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}					
		}
	}
	else
	{
		if(Device[0] == 'U')
		{
			ret = -1;		/* UW */
		}
		else
		{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++)
			{
				if(wPLCDeviceTbl[i].Device[0] == 0){ break;	}
				if(B_gstrcmp((char *)&wPLCDeviceTbl[i].Device[0], Device) == 0)
				{
					DeviceFlag= wPLCDeviceTbl[i].flag;
					*DevCode= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}			
		}
	}

	if(DeviceFlag == 1)			/* 10�� �ּ�ǥ�� */
	{
		Bin2dec(Address, 6, pDevAddr);
		ret = 0;
	}
	else if(DeviceFlag == 2)	/* 16�� �ּ�ǥ�� */
	{
		B_Bin2Hex(Address, 6, pDevAddr);
		ret = 0;
	}

	return(ret);
}

/********************************************************************************/
/*	Func:MemcopyCaseByCPU														*/
/*		�������� �޸𸮿� �����Ҷ� CPU Ÿ�Կ� ���� ��Ʋ�ص��, ��ص����		*/
/*		�����ؼ� �Ÿ� ���縦 �Ѵ�.											*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	char *pDes:destinatiocn pointer										*/
/*	(in)	char *Src:source pointer											*/
/*	(in)	int nCnt:copy data size												*/
/*	(out)	char *combuff:�۽ŵ���Ÿ ���� Addr									*/
/*	(in)	int rCnt:���� Device Count											*/
/*	(out)	int *pfrmSize:�ϼ� �� �������� ũ��(byte)							*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	void MemcopyCaseByCPU(char *pDes, char *pSrc, int nCnt)
{       
#ifdef	WIN32
	B_gmemcpy(pDes, pSrc, nCnt);	
	return;
#endif

#ifdef	SH_CPU
	int i;
	for(i=0; i<nCnt; i++)
	{
		B_gmemcpy(pDes+i,	pSrc+nCnt-1-i,	1);
	}
	return;
#endif

#ifdef	ARM_CPU
	B_gmemcpy(pDes, pSrc, nCnt);
	return;
#endif
}

/********************************************************************************/
/*	Func:MakePLCReadData														*/
/*		Make Read Device Frame(checksum�� ������ ������)						*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	int mode:0:Bit1:Word												*/
/*	(in)	char *pDevice: DeviceInfo XML ���Ͽ��� �� Device�� index��			*/
/*	(in)	int Address:Device Address											*/
/*	(out)	char *combuff:�۽ŵ���Ÿ ���� Addr									*/
/*	(in)	int rCnt:���� Device Count											*/
/*	(out)	int *pfrmSize:�ϼ� �� �������� ũ��(byte)							*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int rCnt, int *pfrmSize)
{
	int		ret;	
	int     pos;
	unsigned short readCnt;
	unsigned short devCode;
	char	Device[5];
	char	DevAddr[10];

	*pfrmSize = 0;
	ret= MakePLCDevAddress(mode, pDevice, Address, Device, DevAddr, &devCode);
	if(ret != 0) return -1;

	pos = 0;

#if PROTOCOL_TYPE == 3
	/* STX */
	combuff[pos] = STX;										pos += 1;
#else
	/* ENQ */
	combuff[pos] = ENQ;										pos += 1;
#endif

#if PROTOCOL_TYPE == 2
	/* ���Ϲ�ȣ */
	B_Bin2Hex(gReadBlockNo, 2, (char *)&combuff[pos]);	pos += 2;
	if(++gReadBlockNo > 0xFF) gReadBlockNo = 0;
#endif

	/* QnAȣȯ 3C ������ �ĺ���ȣ(F9) */
	combuff[pos] = 'F';										pos += 1;
	combuff[pos] = '9';										pos += 1;

	/* ����ȣ */
	B_Bin2Hex(gGukNo, 2, (char *)&combuff[pos]);			pos += 2;

	/* ��Ʈ��ũ��ȣ(00), PLC��ȣ(FF), �ڱ���ȣ(00) */
	B_gmemcpy((char *)&combuff[pos], "00FF00", 6);			pos += 6;

	/* Command */
	B_gmemcpy((char *)&combuff[pos], "0401", 4);			pos += 4;

	/* Sub COMMAND(��������� �б�) */
	B_gmemcpy((char *)&combuff[pos], "0000", 4);			pos += 4;

	/* DEVICE NAME */
	if( B_gstrlen(Device) > 1 ){
		B_gmemcpy((char *)&combuff[pos], Device, 2);		pos += 2;
	}else{
		B_gmemcpy((char *)&combuff[pos], Device, 1);		pos += 1;
		B_gmemcpy((char *)&combuff[pos], "*", 1);			pos += 1;
	}

	/* Start Address */
	B_gmemcpy((char *)&combuff[pos], DevAddr, 6);			pos += 6;

	/* Count */
	/* bit �б�� word ������ �д´�. �б� Count�� 0���� �Ѿ� ���� �ʴ� ���� �����Ѵ�. */	
	if(mode == 0){
		readCnt = (rCnt+(16-rCnt%16))/16;
	}else{
		readCnt = rCnt;
	}
	B_Bin2Hex(readCnt, 4, (char *)&combuff[pos]);			pos += 4;

#if PROTOCOL_TYPE == 3
	/* ETX */
	combuff[pos] = ETX;										pos += 1;
#endif
	
	/* frame size set */
	*pfrmSize = pos;

	return(ret);
}

/********************************************************************************/
/*	Func:BitReadProc															*/
/*		Bit Read Func															*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	T_MAIL *mp:Read Device Info Mail									*/
/*			mp->mpar:Device Addr												*/
/*			mp->mext:Device Count												*/
/*			mp->mbuf:Device Code												*/
/*			mp->mptr:Read Data Save Addr										*/
/*	(in)	unsigned char *rDataFx:��ſ� ���� ���� Addr						*/
/*	(in)	int PlcType:�̻��													*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	BitReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j;
	int		Cnt;
	int		rCnt;
	unsigned char	*SaveAddr;
	int		dCnt;
	int		Address;
	int		frmSize;
	int		bBreak;
	int		nData;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1)
	{
		if(dCnt > MAX_BITCNT){	dCnt -= MAX_BITCNT;	mp->mext= MAX_BITCNT;	}
		else{					mp->mext= dCnt;		dCnt = 0;				}
		ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext, &frmSize);
		if(ret != 0){ ret=-1; break; }
		Cnt = mp->mext;
		SaveAddr = (unsigned char *)mp->mptr;
		ret= SendRecPLCWithBCC(2, PlcSendBuff, frmSize, rDataFx, &rCnt, 0);
		
		if(ret != 0){ ret= -1;	break; }

#if	  PROTOCOL_TYPE == 1
		bBreak = 0;
		if(rDataFx[0] == STX)
		{
			for(i=0; !bBreak; i++)
			{
				nData = B_Hex2nBin((char*)&rDataFx[11+i*4],4);
				for(j=0; j<16; j++)
				{
					*(unsigned char *)SaveAddr++ = (nData>>j)&0x0001;
					if(i*16+j+1>=Cnt){
						bBreak = 1;
						break;
					}
				}
			}
		}
#elif	  PROTOCOL_TYPE == 2
		bBreak = 0;
		if(rDataFx[0] == STX)
		{
			for(i=0; !bBreak; i++)
			{
				nData = B_Hex2nBin((char*)&rDataFx[13+i*4],4);
				for(j=0; j<16; j++)
				{
					*(unsigned char *)SaveAddr++ = (nData>>j)&0x0001;
					if(i*16+j+1>=Cnt){
						bBreak = 1;
						break;
					}
				}
			}
		}
#elif	  PROTOCOL_TYPE == 3
		bBreak = 0;
		if(B_gstrncmp((char *)&rDataFx[11], "QACK", 4) == 0)
		{
			for(i=0; !bBreak; i++)
			{
				nData = B_Hex2nBin((char*)&rDataFx[15+i*4],4);
				for(j=0; j<16; j++)
				{
					*(unsigned char *)SaveAddr++ = (nData>>j)&0x0001;
					if(i*16+j+1>=Cnt){
						bBreak = 1;
						break;
					}
				}
			}
		}
#elif	  PROTOCOL_TYPE == 4
		bBreak = 0;
		if(rDataFx[0] == STX)
		{
			for(i=0; !bBreak; i++)
			{
				nData = B_Hex2nBin((char*)&rDataFx[11+i*4],4);
				for(j=0; j<16; j++)
				{
					*(unsigned char *)SaveAddr++ = (nData>>j)&0x0001;
					if(i*16+j+1>=Cnt){
						bBreak = 1;
						break;
					}
				}
			}
		}
#endif
		
		if(dCnt == 0){	break;	}

		Address += Cnt;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + Cnt);
	}
	return(ret);
}

/********************************************************************************/
/*	Func:WordReadProc															*/
/*		Word Read Func															*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	T_MAIL *mp:Read Device Info Mail									*/
/*			mp->mpar:Device Addr												*/
/*			mp->mext:Device Count												*/
/*			mp->mbuf:Device Code												*/
/*			mp->mptr:Read Data Save Addr										*/
/*	(in)	unsigned char *rDataFx:��ſ� ���� ���� Addr						*/
/*	(in)	int PlcType:�̻��													*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	WordReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt;
	int		rCnt;
	int		frmSize;
	unsigned short	*SaveAddr;
	int		dCnt;
	int		Address;
	unsigned short	nData;
	unsigned short	lendData;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_WORDCNT){	dCnt -= MAX_WORDCNT;	mp->mext= MAX_WORDCNT;	}
		else{					mp->mext= dCnt;			dCnt = 0;				}
		ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff, mp->mext, &frmSize);
		if(ret != 0){ ret=-1; break; }

		Cnt = mp->mext;

		SaveAddr = (unsigned short *)mp->mptr;
		ret= SendRecPLCWithBCC(2, PlcSendBuff, frmSize, rDataFx, &rCnt, 0);

		if(ret != 0){ ret= -1;	break; }

#if	  PROTOCOL_TYPE == 1
		if(rDataFx[0] == STX)
		{
			for(i=0; i<Cnt; i++)
			{
				nData = B_Hex2nBin((char*)&rDataFx[11+i*4],4);
				MemcopyCaseByCPU((char*)&lendData, (char*)&nData, 2);
				*SaveAddr++ = lendData;
			}
		}
#elif	  PROTOCOL_TYPE == 2
		if(rDataFx[0] == STX)
		{
			for(i=0; i<Cnt; i++)
			{
				nData = B_Hex2nBin((char*)&rDataFx[13+i*4],4);
				MemcopyCaseByCPU((char*)&lendData, (char*)&nData, 2);
				*SaveAddr++ = lendData;
			}
		}
#elif	  PROTOCOL_TYPE == 3
		if(B_gstrncmp((char *)&rDataFx[11], "QACK", 4) == 0)
		{
			for(i=0; i<Cnt; i++)
			{
				nData = B_Hex2nBin((char*)&rDataFx[15+i*4],4);
				MemcopyCaseByCPU((char*)&lendData, (char*)&nData, 2);
				*SaveAddr++ = lendData;
			}
		}
#elif	  PROTOCOL_TYPE == 4
		if(rDataFx[0] == STX)
		{
			for(i=0; i<Cnt; i++)
			{
				nData = B_Hex2nBin((char*)&rDataFx[11+i*4],4);
				MemcopyCaseByCPU((char*)&lendData, (char*)&nData, 2);
				*SaveAddr++ = lendData;
			}
		}
#endif
	
		if(dCnt == 0){ break; }
		Address += Cnt;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + Cnt*2);
	}
	return(ret);
}

/********************************************************************************/
/*	Func:C_PLCCommRead															*/
/*		Device Read Func														*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	T_MAIL *mp:Read Device Info Mail									*/
/*			mp->mpar:Device Addr												*/
/*			mp->mext:Device Count												*/
/*			mp->mbuf:Device Code												*/
/*			mp->mptr:Read Data Save Addr										*/
/*	(in)	unsigned char *rDataFx:��ſ� ���� ���� Addr						*/
/*	(in)	int PlcType:�̻��													*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret= 0;

	GetGroopSema();			/* For Monitor */
	switch(mp->mpec){
	case PLC_BIT:		ret= BitReadProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordReadProc(mp,rDataFx,PlcType);		break;
	}
	ResetGroopSema();
	return(ret);
}

/********************************************************************************/
/*	Func:MakePLCWriteData														*/
/*		Make Write Device														*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	int mode:0:Bit1:Word												*/
/*	(in)	char *pDevice:Device Code ���� Addr									*/
/*	(in)	int Address:Device Address											*/
/*	(in)	int Cnt:Device Count												*/
/*	(out)	char *combuff:�۽� ����Ÿ ����  Addr								*/
/*	(in)	char *data:����̽��� �� ���� ���� point							*/
/*	(out)	int *pfrmSize:�ϼ� �� �������� ũ��(byte)							*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data, int *pfrmSize)
{
	int		ret, i;
	unsigned short devCode;
	int     pos;
	unsigned short	wData;
	char	Device[5];
	char	DevAddr[10];

	*pfrmSize = 0;
	ret= MakePLCDevAddress(mode, pDevice, Address, Device, DevAddr, &devCode);
	if(ret != 0) return -1;
	
	pos = 0;
	
#if PROTOCOL_TYPE == 3
	/* STX */
	combuff[pos] = STX;										pos += 1;
#else
	/* ENQ */
	combuff[pos] = ENQ;										pos += 1;
#endif
	
#if PROTOCOL_TYPE == 2
	/* ���Ϲ�ȣ */
	B_Bin2Hex(gWriteBlockNo, 2, (char *)&combuff[pos]);	pos += 2;
	if(++gWriteBlockNo > 0xFF) gWriteBlockNo = 0;
#endif
	
	/* QnAȣȯ 3C ������ �ĺ���ȣ(F9) */
	combuff[pos] = 'F';										pos += 1;
	combuff[pos] = '9';										pos += 1;
	
	/* ����ȣ */
	B_Bin2Hex(gGukNo, 2, (char *)&combuff[pos]);			pos += 2;
	
	/* ��Ʈ��ũ��ȣ(00), PLC��ȣ(FF), �ڱ���ȣ(00) */
	B_gmemcpy((char *)&combuff[pos], "00FF00", 6);			pos += 6;
	
	/* Command (�ϰ�����) */
	B_gmemcpy((char *)&combuff[pos], "1401", 4);			pos += 4;
	
	/* Sub COMMAND */
	if(mode == 0){	/* bit ���� ���� */
		B_gmemcpy((char *)&combuff[pos], "0001", 4);		pos += 4;
	}else{			/* word ���� ���� */
		B_gmemcpy((char *)&combuff[pos], "0000", 4);		pos += 4;
	}
	
	/* DEVICE NAME */
	if( B_gstrlen(Device) > 1 ){
		B_gmemcpy((char *)&combuff[pos], Device, 2);		pos += 2;
	}else{
		B_gmemcpy((char *)&combuff[pos], Device, 1);		pos += 1;
		B_gmemcpy((char *)&combuff[pos], "*", 1);			pos += 1;
	}
	
	/* Start Address */
	B_gmemcpy((char *)&combuff[pos], DevAddr, 6);			pos += 6;
	
	/* Count */
	B_Bin2Hex(Cnt, 4, (char *)&combuff[pos]);				pos += 4;

	if(mode == 0){
		for(i=0; i<Cnt; i++){
			combuff[pos] = (*data++==0) ? '0' : '1';			pos += 1;
		}
	}else{
		for(i=0; i<Cnt; i++){
			MemcopyCaseByCPU((char*)&wData, (char*)(((unsigned short *)data)+i), 2);
			B_Bin2Hex(wData, 4, (char *)&combuff[pos]);		pos += 4;
		}
	}
	
#if PROTOCOL_TYPE == 3
	/* ETX */
	combuff[pos] = ETX;										pos += 1;
#endif
	
	/* frame size set */
	*pfrmSize = pos;
	
	return(ret);
}

/********************************************************************************/
/*	Func:BitWriteProc															*/
/*		Bit Write Func															*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	T_MAIL *mp:Read Device Info Mail									*/
/*			mp->mpar:Device Addr												*/
/*			mp->mext:Device Count												*/
/*			mp->mbuf:Device Code												*/
/*			mp->mptr:write data address											*/
/*	(in)	unsigned char *rDataFx:��ſ� ���� ���� Addr						*/
/*	(in)	int PlcType:�̻��													*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	BitWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		rCnt;
	int		Address;
	char	*dataAddr;
	int		frmSize;	
	int		dCnt;	
	
	Address= mp->mpar;
	dCnt= mp->mext;
	dataAddr= (char *)mp->mptr;
	while(1)
	{
		if(dCnt > MAX_BITCNT){	dCnt -= MAX_BITCNT;	mp->mext= MAX_BITCNT;	}
		else{					mp->mext= dCnt;		dCnt = 0;				}
		ret = MakePLCWriteData(0, (char *)mp->mbuf, Address, mp->mext, (char*)PlcSendBuff, dataAddr, &frmSize);
		if(ret != 0){ ret=-1; break; }				
		ret= SendRecPLCWithBCC(2, PlcSendBuff, frmSize, rDataFx, &rCnt, 0);		
		if(ret != 0){ ret= -1;	break; }		
		
		Address += mp->mext;	
		dataAddr += mp->mext;
		
		if(dCnt == 0){	break;	}
	}
	return(ret);
}

/********************************************************************************/
/*	Func:WordWriteProc															*/
/*		Word Write Func															*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	T_MAIL *mp:Read Device Info Mail									*/
/*			mp->mpar:Device Addr												*/
/*			mp->mext:Device Count												*/
/*			mp->mbuf:Device Code												*/
/*			mp->mptr:write data address											*/
/*	(in)	unsigned char *rDataFx: ��ſ� ���� ���� Addr						*/
/*	(in)	int PlcType:�̻��													*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	WordWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		rCnt;
	int		dCnt;
	int		Address;
	int		frmSize;
	char	*dataAddr;

	Address= mp->mpar;
	dCnt= mp->mext;
	dataAddr = (char *)mp->mptr;
	while(1){
		if(dCnt > MAX_WORDCNT){	dCnt -= MAX_WORDCNT;	mp->mext= MAX_WORDCNT;	}
		else{					mp->mext= dCnt;			dCnt = 0;				}
		ret = MakePLCWriteData(1,(char *)mp->mbuf, Address, mp->mext,(char *)PlcSendBuff, dataAddr, &frmSize);
		if(ret != 0){ ret = -1;		break; }		
		ret= SendRecPLCWithBCC(2, PlcSendBuff, frmSize, rDataFx, &rCnt, 0);
		if(ret != 0){ ret= -1;		break;	}

		Address += mp->mext;
		dataAddr += mp->mext*2;

		if(dCnt == 0) break;
	}
	return(ret);
}

/********************************************************************************/
/*	Func:C_PLCCommWrite															*/
/*		Device Write Func														*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	T_MAIL *mp:Read Device Info Mail									*/
/*			mp->mpar:Device Addr												*/
/*			mp->mext:Device Count												*/
/*			mp->mbuf:Device Code												*/
/*			mp->mptr:Read Data Save Addr										*/
/*	(in)	unsigned char *rDataFx:��ſ� ���� ���� Addr						*/
/*	(in)	int PlcType:�̻��													*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	
	ret=0;
	GetGroopSema();			/* For Monitor */
	switch(mp->mpec){
	case PLC_BIT:		ret= BitWriteProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordWriteProc(mp,rDataFx,PlcType);		break;
	}
	ResetGroopSema();
	return(ret);
}

/********************************************************************************/
/*	Func:C_GetSendRecTime														*/
/*		Send�Ŀ� ���Ŵ�� �ð��� ���(�̻��)									*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:																			*/
/********************************************************************************/
static	int	C_GetSendRecTime(void)
{
	return(0);				/* 0ms */
}

/********************************************************************************/
/*	Func:C_Get_Plc_Ver															*/
/*		�������� ���� ���														*/
/*																				*/
/*	[PARAM]																		*/
/*	(out)	char *name:Versin ���� addr											*/
/********************************************************************************/
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name, VERSION_SET);
}

/* ���� �ҽ� �� */
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH1������ ����ϴ� �Լ� ���� */ 


#ifdef	PLCTYPE_CH1
/********************************************************************************/
/* PLC1 ó�� 																	*/
/********************************************************************************/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}

/********************************************************************************/
/*	Func:GetDevMaxPLC															*/
/*		Device Max Addr ���													*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	int bFlag:0:Bit,1:Word												*/
/*	(in)	int idx:Device Code													*/
/*																				*/
/*	[RETRUN]																	*/
/*	Max Address																	*/
/********************************************************************************/
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}

/********************************************************************************/
/*	Func:GetDevMinPLC															*/
/*		Device Min Addr ���													*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	int bFlag:0:Bit,1:Word												*/
/*	(in)	int idx:Device Code													*/
/*																				*/
/*	[RETRUN]																	*/
/*	Max Address																	*/
/********************************************************************************/
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}

/********************************************************************************/
/*	Func:PLCPCDownThrue															*/
/*		PLC Thru Mode(Monitor) 1 Char handler(Q00J���� ��������)				*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	unsigned char data: ���ŵ���Ÿ										*/
/*	(out)	int *CommMode:���Ÿ�� ���� ����									*/
/*	(out)	int *Sio1RecCnt:����ī��Ʈ ���� ����								*/
/*	(out)	unsigned char *Sio1RecBuff:���ŵ���Ÿ ���� ����						*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:���� �Ϸ� (����Ÿ��ũ �⵿), -1:������ ��� ����							*/
/********************************************************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret= -1;

	/* ���Ź��۰� ���� ü�����µ��� ������ ó���� ���� ���� ��� ���Ź��۸� ����. */
	if(*Sio1RecCnt >= PLC_BUF_MAX){
		*CommMode = 0;
		*Sio1RecCnt = 0;
		B_gmemset((char*)Sio1RecBuff, 0x00, PLC_BUF_MAX);
	}

	/* ���Ź��ۿ� ����Ÿ �ֱ� */
	Sio1RecBuff[(*Sio1RecCnt)++] = data;

#if	  PROTOCOL_TYPE == 1

	/* Type1�� ��� CommMode								*/
	/********************************************************/
	/* 0 : ���ſϷ�											*/
	/* 1 : STX ������, ����Ÿ ���� ���� ����				*/
	/* 2 : ETX ������, CheckSum 1th���� ���Ű��ɻ���		*/
	/* 3 : CheckSum 1th���� ���ſϷ�, 2th���� ���Ű��ɻ���	*/
	/* 4 : NAC ������, ����Ÿ ���� ���� ���� ����			*/
	/* 5 : ACK ������, ����Ÿ ���� ���� ���� ����			*/

	if(data == STX)			{ *CommMode = 4; }
	else if(data == ETX)	{ *CommMode = 5; }
	else if(*CommMode == 5)	{ *CommMode = 6; }
	else if(data == NAK)	{ *CommMode = 7; }
	else if(data == ACK)	{ *CommMode = 8; }
	else if(*CommMode == 6)	{ *CommMode = 0; }

	if( (*CommMode == 7 && *Sio1RecCnt == 15) ||
		(*CommMode == 8 && *Sio1RecCnt == 11)	)
	{
		*CommMode = 0;
	}

#elif PROTOCOL_TYPE == 2

	/* Type2�� ��� CommMode								*/
	/********************************************************/
	/* 0 : ���ſϷ�											*/
	/* 1 : STX ������, ����Ÿ ���� ���� ����				*/
	/* 2 : ETX ������, CheckSum 1th���� ���Ű��ɻ���		*/
	/* 3 : CheckSum 1th���� ���ſϷ�, 2th���� ���Ű��ɻ���	*/
	/* 4 : NAC ������, ����Ÿ ���� ���� ���� ����			*/
	/* 5 : ACK ������, ����Ÿ ���� ���� ���� ����			*/
	
	if(data == STX)			{ *CommMode = 4; }
	else if(data == ETX)	{ *CommMode = 5; }
	else if(*CommMode == 5)	{ *CommMode = 6; }
	else if(data == NAK)	{ *CommMode = 7; }
	else if(data == ACK)	{ *CommMode = 8; }
	else if(*CommMode == 6)	{ *CommMode = 0; }
	
	if( (*CommMode == 7 && *Sio1RecCnt == 17) ||
		(*CommMode == 8 && *Sio1RecCnt == 13)	)
	{
		*CommMode = 0;
	}

#elif PROTOCOL_TYPE == 3

	/* Type3�� ��� CommMode								*/
	/********************************************************/
	/* 0 : ���ſϷ�											*/
	/* 1 : STX ������, ����Ÿ ���� ���� ����				*/
	/* 2 : ETX ������, CheckSum 1th���� ���Ű��ɻ���		*/
	/* 3 : CheckSum 1th���� ���ſϷ�, 2th���� ���Ű��ɻ���	*/
	
	if(data == STX)			{ *CommMode = 4; }
	else if(data == ETX){
		if(*Sio1RecCnt >= 16){
			if(B_gstrncmp((char*)&Sio1RecBuff[11], "QACK", 4) == OK)
			{
				if(*Sio1RecCnt == 16)	*CommMode = 0;
				else					*CommMode = 5;
			}
			else
			{
				*CommMode = 0;
			}
		}
	}
	else if(*CommMode == 5)	{ *CommMode = 6; }
	else if(*CommMode == 6)	{ *CommMode = 0; }
	
#elif PROTOCOL_TYPE == 4

	/* Type4�� ��� CommMode								*/
	/********************************************************/
	/* 0 : ���ſϷ�											*/
	/* 1 : STX ������, ����Ÿ ���� ���� ����				*/
	/* 2 : ETX ������, CheckSum 1th���� ���Ű��ɻ���		*/
	/* 3 : CheckSum 1th���� ���ſϷ�, 2th���� ���Ű��ɻ���	*/
	/* 4 : CheckSum 2th���� ���ſϷ�, CR���� ���Ű��� ����	*/
	/* 5 : NAC ������, ����Ÿ ���� ���� ���� ����			*/
	/* 6 : ACK ������, ����Ÿ ���� ���� ���� ����			*/
	/* 7 : CR ������, LF ���� ���� ����						*/
	/* 8 : LF ������, ���ſϷ�								*/

	if(data == STX)			{ *CommMode = 4; }
	else if(data == ETX)	{ *CommMode = 5; }
	else if(*CommMode == 5)	{ *CommMode = 6; }
	else if(*CommMode == 6)	{ *CommMode = 7; }
	else if(data == NAK)	{ *CommMode = 8; }
	else if(data == ACK)	{ *CommMode = 9; }
	else if(data == CR)		{ *CommMode = 10; }
	else if(data == LF)		{ *CommMode = 0; }	
	
#elif PROTOCOL_TYPE == 5
#endif

	ret = (*CommMode == 0) ? 0 : -1;
	if(ret == 0){	*CommMode= 99;	}			//2012.07.05
/*
#ifdef WIN32
	sprintf(szDebug, "-->[%d](%d) : [%c][%02x]\n", *RecCnt, ret, data, data);
	OutputDebugString(szDebug);
#endif
*/

	return(ret);
}

/********************************************************************************/
/*	Func:PlcMakeDeviceAddr														*/
/*		Group Monitor Address(Q00J���� ���� ����)								*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	int mode:0:Bit,1:Word												*/
/*	(in)	char *DevName:Device Code ���� ����									*/
/*	(in)	int DevAddress:Device Address										*/
/*	(out)	char *work: ��ȯ ����Ÿ ���� ����									*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK, -1:Error																*/
/********************************************************************************/
/*
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	return (-1);

	int	ret;
	int	DevAddr;
	char	buff[8];
	char	abuff[8];

	if(((unsigned char)DevName[0] == 0x7f) || ((unsigned char)DevName[0] == 0xef)){		// UB,UW
		return(-1);
	}
	ret= MakePLCDevAddress(mode, DevName, DevAddress, &DevAddr, 2);
	if(ret == 0){
		// sprintf(buff,"%04X",DevAddr);
		B_Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		// sprintf(work,"M%s0002",abuff);
		B_gstrcpy(work,"M");
		B_gstrcat(work,abuff);
		B_gstrcat(work,"0002");
	}
	return(ret);
}
*/

/********************************************************************************/
/*	Func:MakeBitContinue														*/
/*		Make Bit Continue Patarn												*/
/********************************************************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
						MyAddress= DeviceDataSys[i].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}

/********************************************************************************/
/*	Func:MakeWordContinue														*/
/*		Make Word Continue Patarn												*/
/********************************************************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;
	char	Device[4];*/
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
					MyAddress= DeviceDataSys[i].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}

/********************************************************************************/
/*	BIT GROUP-PATARN															*/	
/*	2006.03.31 makebitpatarn �ϰ� ����											*/
/********************************************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{

}

/********************************************************************************/
/*	WORD GROUP-PATARN															*/
/*	2006.03.31 makewordpatarn �ϰ� ����											*/
/********************************************************************************/
void	MakeWordPatarn(int Start)
{

}

/********************************************************************************/
/*	Func:ClearBWContinue														*/
/*		Clear Continue Patarn													*/
/********************************************************************************/
void	ClearBWContinue(void)
{
	int		i,j,idx;

	for(i= 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus != 0)){
			/* Continue */
			if(DeviceDataSys[i].DevFlag == 0){		/* BIT */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_BIT_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}else{									/* WORD */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_WORD_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}
		}
	}
}

/********************************************************************************/
/*	Func:MakeGroupDevPLC														*/
/*		make Group Patarn														*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	int PlcType:�̻��													*/
/********************************************************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Set Group */
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gDeviceCnt= 0;
	/* Same Device Check */
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	if(BitCnt > 0){
		MakeBitContinue();
	}
	if(WordCnt > 0){
		MakeWordContinue(TotalBitCnt);
	}
	/* Continue MAX Check */
	ClearBWContinue();
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}
	return(0);
}

/********************************************************************************/
/*	Func:SetGroupDevPLC															*/
/*		Monitor Group ����ó��													*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK, -1:Error																*/
/********************************************************************************/
/*
int		SetGroupDevPLC(void)
{
	int		i;
	int		idx;
	char	work[12+ 1];
	int		ret= 0;
	int		Cnt;

	// Same Device Check
	B_gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	B_gstrcpy((char *)&PlcSendBuff[1],"uW0002");
	idx= 0;
	// Word Device Set
	gDeviceCnt= 0;
	for(i = 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].DevCnt == 1) &&
			(DeviceDataSys[i].DevFlag == 1) &&
			(DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus == 0)){
			if(PlcMakeDeviceAddr(DeviceDataSys[i].DevFlag, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work) == 0){
				B_gstrcpy((char *)&PlcSendBuff[7 + idx+ gDeviceCnt*9],(char *)work);
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
				gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
				DeviceDataSys[i].SameDevInf= 4;
				gDeviceCnt++;
				gDeviceCntWord++;
			}
		}
		// sprintf(work,"%02X",gDeviceCntWord);
		B_Bin2Hex(gDeviceCntWord,2,work);
		B_gmemcpy((char *)&PlcSendBuff[5],work,2);
		if(gDeviceCnt > MAX_UR_CNT){
			break;
		}
	}
	if(gDeviceCnt != 0){
		B_gstrcpy(&work[1],"uA00");
		ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcRecBuff,&Cnt,0);
		if(ret == 0){
			// if(gstrncmp((char *)PLCbuf,"\x06u",2) != 0){
			if(PlcRecBuff[0] != 0x06){
				ret= -1;
			}
		}
		if(ret == 0){
			ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)PlcRecBuff,&Cnt,0);
			if(ret == 0){
				// if(gstrncmp((char *)PLCbuf,"\x06u",2) != 0){
				if(PlcRecBuff[0] != 0x06){
					ret= -1;
				}
			}
		}
		B_gstrcpy(&work[1],"uE00");
		if(ret == 0){
			ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcRecBuff,&Cnt,0);
			if(ret == 0){
				// if(gstrncmp((char *)PLCbuf,"\x06u",2) != 0){
				if(PlcRecBuff[0] != 0x06){
					ret= -1;
				}
			}
		}
	}
	return(ret);
}
*/

/********************************************************************************/
/*	Func:ReadGroupPLCDev														*/
/*		Monitor Read ó��														*/
/*																				*/
/*	[RETRUN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/

int		ReadGroupPLCDev(void)
{
/*
	int		ret;
	int		idx;
	int		i;
	int		WordCnt;
	char	work[16];
	char	work1[8];

	if(gDeviceCntWord == 0){
		return(0);
	}
	ret= 0;
	WordCnt= gDeviceCntWord;
	// sprintf(work,"uR0000%02X",WordCnt);
	work[0]= STX;
	work[1]= 0;
	B_gstrcpy(&work[1],"uR0000");
	B_Bin2Hex(WordCnt,2,work1);
	B_gstrcat(work,work1);
	ret= SendRecPLCWithBCC(2,work,PlcSendDevData,&idx,0);
	if(ret == OK){
		// if(gstrncmp((char *)PlcSendDevData,"\x06u",2) != 0){
		if(PlcSendDevData[0] != 0x06){
			ret= -1;
		}
		if(ret == 0){
			for(i = 0; i < gDeviceCntWord; i++){
#ifdef	SH_CPU
				*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 2]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 4]);
#endif
#ifdef	ARM_CPU
#ifdef	WIN32
				*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 2]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 4]);
#else
				*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 4]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 2]);
#endif
#endif
			}
			B_gstrcpy(&work[1],"uE00");
			ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcRecBuff,&idx,0);
			if(ret == 0){
				// if(gstrncmp(work,"\x06u",2) != 0){
				if(PlcRecBuff[0] != 0x06){
					ret= -1;
				}
			}
		}
	}
	return(ret);
*/
	return(0);
 }


/********************************************************************************/
/*	Func:SendMonuW																*/
/*		uW �۽�ó��																*/
/*																				*/
/*	[PARAM]																		*/
/*	(IN)	int idx:Thru Monitor idx											*/
/*																				*/
/*	[RETURN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
/*
int		SendMonuW(int idx)
{
	int		ret;
	int		SendCnt;
	int		Cnt;
	char	work[16];

	B_gstrcpy(&work[1],"uA00");
	ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcRecBuff,&Cnt,0);
	if(ret == 0){
		if(PlcRecBuff[0] != 0x06){
			ret= NG;
		}
	}
	SendCnt= PlcThruMonDataCnt[idx];
	B_gmemcpy((char *)&PlcSendBuff[0],(char *)PlcThruMonBuff[idx],SendCnt);
	ret= C_SendRecPLC(2,PlcRecBuff,&Cnt,0,SendCnt,(char *)PlcSendBuff,2000);
	if(ret == 0){
		if(PlcRecBuff[0] != 0x06){
			ret= NG;
		}
	}
	B_gstrcpy(&work[1],"uE00");
	if(ret == 0){
		ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcRecBuff,&Cnt,0);
		if(ret == 0){
			if(PlcRecBuff[0] != 0x06){
				ret= NG;
			}
		}
	}
	return(OK);
}
*/

/********************************************************************************/
/*	Func:SendMonuR																*/
/*		uR �۽� ó��															*/
/*																				*/
/*	[PARAM]																		*/
/*	(IN)	int idx:Thru Monitor idx											*/
/*																				*/
/*	[RETURN]																	*/
/*	0:OK, -1:Error																*/
/********************************************************************************/
/*
int		SendMonuR(int idx)
{
	int		ret;
	int		RecCnt;
	int		Cnt;
	char	work[16];

	PlcSendBuff[0]= STX;
	PlcSendBuff[1]= 0;
	B_gstrcpy((char *)&PlcSendBuff[1],"uR0000");
	B_gmemcpy((char *)&PlcSendBuff[7],(char *)&PlcThruMonBuff[idx][5],2);	// Word Cnt
	PlcSendBuff[9]= 0;
	ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&RecCnt,0);
	if(ret == OK){
		if(PlcRecBuff[0] != 0x06){
			ret= NG;
		}
		B_gstrcpy(&work[1],"uE00");
		if(ret == 0){
			ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcSendBuff,&Cnt,0);
			if(ret == 0){
				if(PlcSendBuff[0] != 0x06){
					ret= NG;
				}
			}
		}
		PlcThruRecDataCnt[idx]= RecCnt;
		B_gmemcpy((char *)PlcThruRecBuff[idx],(char *)PlcRecBuff,RecCnt);
	}
	return(OK);
}
*/

/********************************************************************************/
/*	Func:RecGroupPLCDev															*/
/*		Groop Read ó��															*/
/*																				*/
/*	[PARAM]																		*/
/*	(IN)	Int PlcType:�̻��													*/
/*																				*/
/*	[RETURN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
int		RecGroupPLCDev(int PlcType)
{
	return (0);
/*
	int		i;
	int		ret;

	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].SameDevInf == 4){
			DeviceDataSys[i].SameDevInf= 0;
		}
	}
	GetGroopSema();			// For Monitor
	while(1){				// GP Monitor
		ret= SetGroupDevPLC();
		if((ret != 0) || (gDeviceCntWord == 0)){
			break;
		}
		ret= ReadGroupPLCDev();
		if(ret != 0){
			break;
		}
	}
	for(i= 0; i < PlcThruMonCnt; i++){				// PC->PLC Monitor
		ret= SendMonuW(i);
		if(ret == OK){
			SendMonuR(i);
		}
	}
	LgCommSeq= 1;
	ResetGroopSema();
	return(ret);
*/
}



/********************************************************************************/
/*	Func:PLCFxThruProc															*/
/*		Thru Mode ����ó��														*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	char *CommBuff: ���� ����Ÿ address									*/
/*	(in)	int *RecCommCnt:���� ����Ÿ ī��Ʈ 									*/
/*	(out)	char *OutBuff:�۽� ����Ÿ address									*/
/*	(out)	int *OutCnt:�۽� ����Ÿ ��											*/
/*	(in)	int PlcConnectFlag:�̻��											*/
/*	(in)	int PlcType:�̻��													*/
/********************************************************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	GetGroopSema();
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendThruePLC(2,*OutCnt,OutBuff,3000); /*20090706*/
	ResetGroopSema();

#ifdef	OLDSOURCE
	int		command;
	int	SendCnt;

	if(LgConnectFlag != 1){
		// DisConnect
		// NAK
		PlcSendBuff[1]= 'u';
		PlcSendBuff[2]= 0;
		SendCnt= SetPLCBCCACK(NAK,(char *)&PlcSendBuff,1);
		// ACK Send To PC
		B_SendPLC2PCData( 0,SendCnt,(char *)PlcSendBuff,2000 );
		return;
	}
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;

	command= CheckLGCommand(&CommBuff[1]);
	switch(command){
	case 0:			// uW Commnad
		GetGroopSema();			// For Monitor
		if((PlcThruMonCnt < 10) && (*RecCommCnt <= 256)){
			PlcThruMonDataCnt[PlcThruMonCnt]= *RecCommCnt;
			B_gmemcpy((char *)&PlcThruMonBuff[PlcThruMonCnt++],CommBuff,*RecCommCnt);
			PlcSendBuff[1]= 'u';
			PlcSendBuff[2]= 0;
			SendCnt= SetPLCBCCACK(ACK,(char *)&PlcSendBuff,1);
			// ACK Send To PC
			B_SendPLC2PCData( 0,SendCnt,(char *)PlcSendBuff,2000 );
		}else{
			// Error
		}
		LgCommSeq= 0;
		ResetGroopSema();
		break;
	case 1:			// uR Command
		while(1){
			if(LgCommSeq != 0){
				break;
			}
			B_Delay(50);
		}
		GetGroopSema();			// For Monitor
		if(PlcThruRecCnt < 10){
			SendCnt= PlcThruRecDataCnt[PlcThruRecCnt];
			B_gmemcpy((char *)&PlcSendBuff[0],(char *)PlcThruRecBuff[PlcThruRecCnt++],SendCnt);
			// Rec Data Send To PC
			B_SendPLC2PCData( 0,SendCnt,(char *)PlcSendBuff,2000 );
		}
		ResetGroopSema();
		break;
	case 3:			// uA Command
		PlcThruMonCnt= 0;
		PlcThruRecCnt= 0;
	case 2:			// uE Command
		GetGroopSema();			// For Monitor
		PlcSendBuff[1]= 'u';
		PlcSendBuff[2]= 0;
		SendCnt= SetPLCBCCACK(ACK,(char *)&PlcSendBuff,1);
		// ACK Send To PC
		B_SendPLC2PCData( 0,SendCnt,(char *)PlcSendBuff,2000 );
		ResetGroopSema();			// For Monitor
		break;
	default:
		GetGroopSema();			// For Monitor
		B_SendThruePLC(2,*OutCnt,OutBuff,3000);		// ACK
		ResetGroopSema();			// For Monitor
		break;
	}
#endif
}

/********************************************************************************/
/*	Func:Device2IndexPLC														*/
/*		Device Name�� Device Code�� ��ȯ ó��									*/
/*																				*/
/*	[PARAM]																		*/
/*	(in)	int bwflag:0:Bit,1:Word												*/
/*	(out)	char *Name:Device Name Addr											*/
/*																				*/
/*	[RETURN]																	*/
/*	0:OK,-1:Error																*/
/********************************************************************************/
int		Device2IndexPLC(int bwflag, char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}

/********************************************************************************/
/*	Check Device Address 														*/
/********************************************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}

/*++++++++++++++++++++++++++++++++++++*/
#endif

/* PLCTYPE_CH1������ ����ϴ� �Լ� �� */
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH2������ ����ϴ� �Լ� ���� */ 

#ifdef	PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �Լ�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif

#include	"hook_aplplc.h"

/****************************** END **********************/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
