/*****************************************************************************************/
/*	PLC ����M �v���O��?(AUTONICS)		*/
/*	2003.5.31				*/
/************************************************/
/*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		  */
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
/*	2006.09.25 */
/*      �����͹� ���ø� ������ ���� ver 2.6�� �ϰ� ����	  */
/*  2007.01.30 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����		*/
/*  2007.10.08 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����	 		*/ 
/*****************************************************************************************/

#include	"define.h"
#include	"GpCommon.h"
#include	"PlcCommBuff.h"
#include	"mail.h"
#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include "hook_plcapl.h"

/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V3.3M"
/*****************************************************************************************/



#ifdef	S7_300

#define	MAX_RTY_COUNT	3
#define	MAX_WORDCNT		80

#define PLC_SPEED	RS_38400
#define	PLC_DATA	RS_DATA8
#define PLC_PARITY	RS_ODD 
#define SendChek   0xE5
#define Endbuff    0x16
#endif




#ifdef	SH_CPU		/* ���� */
/*ksc20040707*/
/****************************************************************/
/*	Station Connect Area										*/
/****************************************************************/
static	int	PlcRecCnt;
static	int	PlcRecCmd;
static	int	GroopSema;			/* Grooping Semafo */
static	unsigned	int	Port_TimeoutCnt;		/* 20060203 */
static	int	Pro_Speed;			/* 20061025ksc */
static	unsigned int Plc_sync_time;				/* 20061025ksc */ 
#endif


#ifdef	SH_CPU
static	int	FrameCnt;
static  int FirstRec;
static	unsigned int gReadFrameIdx;		
static	unsigned int gWriteFrameIdx;
#endif

static  unsigned char FrameNo;
static  unsigned char RecvFlag;
static  int MessageAckCnt;


static const unsigned char Sch[3]={0x10, 0x02, 0x15};
static unsigned char SaveAck[50];


static	const	DEV_TBL bPLCDeviceTbl[16] = {
	{"I",  0x0081, 1},
	{"Q", 0x0082, 1},
	{"M",  0x0083, 1},
	{"T",  0x001F, 1},
	{"C",  0x001E, 1},
	{"GB" ,    0,4},

};
static	const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"IW",  0x0081, 1},
	{"QW", 0x0082, 1},
	{"MW",  0x0083, 1},
	{"T",  0x001F, 1},
	{"C",  0x001E, 1},
	{"GW",    0,4},
};


static	const	DATA_FRAME	FrameType[6] = {
	{
		 5, {0x00,0x0C,0x03,0x03,0xF1},
	},

	{
		 6, {0x32,0x01,0x00,0x00,0x33,0x01},
	},
	{
		 7, {0x04,0x01,0x12,0x0A,0x10,0x10,0x02},
	},
	{
		7, {0x00,0x0c,0x03,0x03,0xb0,0x01,0x00},
	},
	{ 
		8, {0x00,0x0C,0x03,0x03,0x80,0x10,0x03,0x9F},
	},
	{ 
		11, {0x12,0x0A,0x10,0x1F,0x00,0x01,0x00,0x00,0x1F,0x00,
			 0x00,},
	},

};
//���� ������
static const DATA_FRAME ConnFrame[6]={
	{
		26,{0x01,0x03,0x02,0x17,0x00,0x9F,0x01,0x3C,0x00,0x90,
			0x01,0x14,0x00,0x00,0x14,0x02,0x00,0x0F,0x05,0x01,
			0x00,0x03,0x00,0x10,0x03,0x3D}
	},
	{
		 6, {0x01,0x07,0x02,0x10,0x03,0x17},
	},
	{
		23,{0x00,0x0D,0x00,0x03,0xE0,0x04,0x00,0x80,0x00,0x02,
			0x01,0x06,0x01,0x00,0x00,0x01,0x02,0x02,0x01,0x00,
		0x10,0x03,0x7D}
	},
	{
		9,{0x00,0x0C,0x03,0x03,0x05,0x01,0x10,0x03,0x1B}
	},
	{
		 27,{0x00,0x0C,0x03,0x03,0xF1,0x00,0x32,0x01,0x00,0x00,
			0xFF,0xFF,0x00,0x08,0x00,0x00,0xF0,0x00,0x00,0x03,
			0x00,0x03,0x01,0x00,0x10,0x03,0x24}
	},
	{
		 10,{0x00,0x0C,0x03,0x03,0xB0,0x01,0x00,0x10,0x03,0xAE}
	},
};

/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef  PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= PLC_SPEED;
	*DataBit= PLC_DATA;
	*Parity= PLC_PARITY;
}
/*********************************/
/*	PLC Semafor			         */
/*********************************/
static	void	GetGroopSema(void)
{
	
	unsigned int	NowTime;
	unsigned int	StartTime;

	if(GroopSema == 0){		/* Grooping Sema */
	}else{
		StartTime= B_GetNowTime();
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
			NowTime= B_GetNowTime();
			if((StartTime+ 2000) < NowTime){
				GroopSema= 0;
			}
			B_Delay(10);
		}
	}
	GroopSema++;
}
static	void	ResetGroopSema(void)
{
	GroopSema= 0;
}
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{

int	ret= -1;
	int i=0;
	unsigned char bcc=0x00;

	switch(*CommMode)
	{
	case 0:	
		*RecCnt=0;
		RecBuff[(*RecCnt)++]=data;
		switch(data)
		{
		case DLE:
			if(RecvFlag ==0x00)
			{
				ret=0;
				*CommMode=0;
				RecvFlag = 0x01;
				return (ret);
			}
			else if(RecvFlag == 0x01)
			{
				*CommMode=1;
				return (ret);
			}
			else if(RecvFlag == 0x03)
			{
				ret=0;
				RecvFlag = 0x04;
				return (ret);
			}
			else if(RecvFlag == 0x04)
			{
				ret=0;
				RecvFlag = 0x00;
				return (ret);
			}
			break;
		case STX:
			ret=0;
			*CommMode=0;
			RecvFlag = 0x03;
			return (ret);
			break;
		case NAK:
			if(RecvFlag==0x03)
			{
				ret =-1;
				return (ret);
			}
			break;
		default:
			if(RecvFlag==0x02)
			{
				*CommMode = 2;
			}
			else if(RecvFlag==0x03)
			{
				*CommMode = 2;
			}
			return (ret);
			break;
		}
		break;
	case 1:
		if(data == STX)
		{
			RecBuff[(*RecCnt)++]=data;
			ret=0;
			*CommMode=0;
			RecvFlag=0x02;
			return (ret);
		}
		break;

	case 2:
		if(*RecCnt<PLC_BUF_MAX)
			RecBuff[(*RecCnt)++]=data;

		if(data == DLE)
		{
			*CommMode=3;
		}
		break;
	case 3:
		if(*RecCnt<PLC_BUF_MAX)
			RecBuff[(*RecCnt)++]=data;
		if(data == ETX)
		{
			*CommMode =4;
		}
		else 
		{
			*CommMode =2;
		}
		break;
	case 4:
		if(*RecCnt<PLC_BUF_MAX)
			RecBuff[(*RecCnt)++]=data;

		for(i =0; i< *RecCnt-1 ; i++)
		{
			bcc ^=RecBuff[i];
		}
		if(data == bcc)
		{
			// ������ ���� ����
			ret =0;
			*CommMode=0;
			if(RecvFlag==0x02)
				RecvFlag=0x00;
			else if(RecvFlag ==0x03)
				RecvFlag = 0x03;

		}
		else
		{
			ret = -1;
			*CommMode = 2;
			return (ret);
		}
		break;
	}
	return(ret);    
}                        

static	int SetPLCBCC(char *buff,int cnt)
{

	int		i;
	unsigned char sum=0x00;	
		buff[cnt]=DLE;
	buff[cnt+1]=ETX;

	for(i=0; i< cnt+2; i++){
		sum =sum^buff[i];
	}
	buff[cnt+2] = sum;
	return(cnt + 3);
    
}	    



/************************************/
/*	PLC Send						*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,unsigned char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	int		SendCnt;
	int		sCnt,i;

	FirstRec=0;
	SendCnt= SetPLCBCC((char *)combuf,*Cnt);

	ret= C_SendRecPLC(2,PlcRecBuff, &sCnt,0,1,(char*)(Sch+1),100); // 0x02
	if(ret != OK) return NG; //���� ���� 
	if(PlcRecBuff[0] == DLE){
		ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000); // ~~~~~~0x10,0x03,BCC
	}
	else
		return NG;
	if(rData[0]==0x10 && rData[1]==0x02)
	{
		ret= C_SendRecPLC(2,(unsigned char *)rData, &sCnt,0,1,(char*)(Sch),100); //0x10
		if(ret == OK){
			// MessageAck Check FrameNo;
			if(rData[4]==0xB0){
				MessageAckCnt=sCnt;
				for(i=0;i<sCnt;i++)
				SaveAck[i]=rData[i];
			}
			else
				return NG;
		}
	}
	else
		return NG;
	ret= C_SendRecPLC(2,(unsigned char *)rData, &sCnt,0,1,(char*)(Sch),100); // 0x10
	if(ret != 0)return NG;
	if(rData[0]!=0x02) return NG;



	return(ret);
}
static	int	SendRecPLCWithBCCCont(int mode,unsigned char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		i;
	int		ret;
	unsigned char bcc;
	unsigned char bcc1;
	int		SendCnt;
	
	FirstRec=0;
	SendCnt= SetPLCBCC((char *)combuf,*Cnt);
		ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		B_Delay(20);
		if(FirstRec==1)
		{
			ret= C_SendRecPLC(mode,rData,Cnt,rmode,FrameType[0].cnt,(char *)FrameType[0].frame,2000);  /* 20090611 */
		}
		if(ret == 0){
			if(mode <= 1){
			}
			else{
				bcc1=rData[*Cnt-2];
				bcc= 0;
				for(i = 4; i < *Cnt-2; i++){
					bcc+=rData[i];
				}
				if(bcc != bcc1){
					ret= -1;
				}
			}
		}
		return(ret);
}
static	int	C_Connection( int *PlcType,int iConnect )
{
	
	int		ret;
	int		Cnt;
 	int		Speed;
	int		DataBit;
	int		Parity;
	int i;
 
	if((C_Get_Ms_Sel() & 0xff00) == 0){		
		if(iConnect == CH_CH1){		

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
		}else{						

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
		}
#ifdef	WIN32
		while(1){
			if((iConnect & 1) == 0){
				if(SioPCOpenFlag == 0){
					break;
				}
			}else{
				if(SioPLCOpenFlag == 0){
					break;
				}
			}
			B_Delay(10);
		}
#else
  		B_Delay(100);
#endif
	}
	monitorModeFlag= PlcType[4];		/* 20090704 */
// 	Cnt=FrameType[1].cnt;  /* 20090611 */
//	B_gmemcpy((char*)PlcSendBuff, (char*)FrameType[1].frame,50);
// 	ret= SendRecPLCWithBCCCont(2,PlcSendBuff,PlcRecBuff,&Cnt,0);  /* 20090611 */

	RecvFlag=0x00;
	FrameNo=0x00;
	for(i=0; i<6; i++){
		ret= C_SendRecPLC(0,PlcRecBuff, &Cnt,0,1,(char*)Sch,10); // DLE Send
		B_Delay(100);
	}

	FrameNo=0x00;
	//���� ������.
	ret= C_SendRecPLC(2,PlcRecBuff, &Cnt,0,1,(char*)(Sch+1),100);
	if(ret != 0){
		ret=0;
		return (ret);
	}  //���� ���� 

	for(i=0; i<6 ; i++)
	{
		ret= C_SendRecPLC(2,PlcRecBuff, &Cnt,0,ConnFrame[i].cnt,(char*)ConnFrame[i].frame,2000);
		if(ret != 0){
			return (0); // ���� Ȯ�� 
		}
		if(i<4)
		{
			ret= C_SendRecPLC(2,PlcRecBuff, &Cnt,0,1,(char*)Sch,500); // DLE Send
			if(ret != 0) return NG;
			if(PlcRecBuff[1]== 0x0D)
			{
				ret = 0;
				return (ret);
			}
//			B_Delay(100);
			ret= C_SendRecPLC(2,PlcRecBuff, &Cnt,0,2,(char*)Sch,500);
			if(ret != 0) return (0);
		}
		else if(i==4)
		{
			ret= C_SendRecPLC(2,PlcRecBuff, &Cnt,0,1,(char*)Sch,500);
			if(ret != 0)return (0);
			ret= C_SendRecPLC(2,PlcRecBuff, &Cnt,0,1,(char*)Sch,500);
			if(ret != 0) return (0);
			ret= C_SendRecPLC(2,PlcRecBuff, &Cnt,0,1,(char*)Sch,500);
			if(ret != 0) return (0);
			ret= C_SendRecPLC(2,PlcRecBuff, &Cnt,0,2,(char*)Sch,500);
			if(ret != 0) return (0);
		}
	}
	
   	ResetGroopSema();	


	if(ret < 0){
		return(0);
	}
	ret= 1;
//	MyChanel= PlcType[5];			//2011.04.08 Chanel Setting
	return(ret);
}
/******************************************/
static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif
#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00]; 
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100]; 
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif

}
/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;


	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i,j;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			
		if(Device[0] == 'G'){		
			ret = Address % 16;
			BitAndData = 1;
			for(j = 0; j < ret; j++){
				BitAndData <<= 1;
			}
			ret += sCnt;
			ret = ret / 8 + 1;
			BitRecCnt = ret;
			ret = 1;		
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrncmp(bPLCDeviceTbl[i].Device,Device,2) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = Address;
				pDevice[0]=OffSet/0x100;	
				pDevice[1]=OffSet%0x100;
				ret=0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		
			ret = 1;	
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrncmp(wPLCDeviceTbl[i].Device,Device,2) == 0){	
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = Address;
				pDevice[0]=OffSet/0x100;	
				pDevice[1]=OffSet%0x100;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt,int StationNo)
{
	int		ret,i;
	int     pos,tpos,dpos,pCnt;
	int		DevAddr;
	char sTmp[256];
	
	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	if(ret==0 ) {
		pos = 0;   
		tpos=0;
		dpos=0;
		B_gmemcpy(combuff+pos, (char*)FrameType[0].frame, FrameType[0].cnt);  
		pos += FrameType[0].cnt; 
		
		// frame number
		FrameNo+=0x01;
		if(FrameNo==0x10)
		{
			combuff[pos++]= FrameNo; 	
		}
		combuff[pos++]= FrameNo; 
		if(FrameNo==0xff)
		{
			FrameNo=0x00;
		}
		
		B_gmemcpy(combuff+pos,(char*)FrameType[1].frame, FrameType[1].cnt);
		pos +=(FrameType[1].cnt);
		
		//�Ķ���� ������ ����
		B_gmemcpy(sTmp+tpos, (char*)FrameType[2].frame, FrameType[2].cnt);
		tpos += FrameType[2].cnt;
		
		//Read Type : 0x01 :Bit, 0x02 Byte, 0x04 Word
		sTmp[tpos-1]=0x02;
		
		// Number of Data to read (byte) sCnt ���� ����
		sTmp[tpos++]=0x00;
		if(mode==0){
			pCnt = sCnt / 8;
			if(sCnt%8==0) // Address
				sTmp[tpos++]=pCnt;
			else
			{
				pCnt++;
				sTmp[tpos++]=pCnt;
			}
		}
		else {
			pCnt = sCnt+1;
			sTmp[tpos++]=pCnt;
		}
		
		
		if(pCnt==0x10)
		{
			sTmp[tpos++]=DLE;
			dpos-=1;
		}
		
		//Number of data block
		sTmp[tpos++]=0x00;
		sTmp[tpos++]=0x00;
		
		//device code
		if(mode ==0)
			sTmp[tpos++] = pDevice[1];
		else
			sTmp[tpos++] = pDevice[1];
		
		//device start address
		sTmp[tpos++] = 0x00; 
		
		if(mode==1)Address = Address*8;
		if(mode==0)Address=(Address/8)*8; //&& sCnt>1

		sTmp[tpos++]=Address/0x100;
		if(sTmp[tpos-1]==DLE)
		{
			sTmp[tpos++]=DLE;
			dpos-=1;
		}
		sTmp[tpos++]=Address%0x100;
		if(sTmp[tpos-1]==DLE)
		{
			sTmp[tpos++]=DLE;
			dpos-=1;
		}
		
		//parameter length
		combuff[pos++]=(tpos+dpos-1)/255;
		combuff[pos++]=(tpos+dpos-1)%255;
		
		//data length
		combuff[pos++]=0x00;
		combuff[pos++]=0x00;
		
		for(i=0; i<tpos;i++)
			combuff[pos++]=sTmp[i];
		//B_gmemcpy(combuff+pos, sTmp, tpos+dpos);
	}
	FrameCnt = pos;
	return(ret);
}
static	int	BitReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j;
	int		sCnt,dataCnt;
	int		bitCnt;
	unsigned int CmpbitCnt;
	int		Cnt,DataFrame;
	int		sAddr;
	unsigned char	*SaveAddr;
	int		Address;
	int		EndFlag;
	
	Address= mp->mpar;
	EndFlag= 0;
	
	while(EndFlag == 0){
			ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext,(int)mp->mbuf[4]);
			Cnt = mp->mext;
			if(ret != 0){	
				ret= -1;	
				return(ret);	
			}
			sCnt= FrameCnt;
			DataFrame=25;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				B_gmemset((char*)rDataFx, 0x00, PLC_BUF_MAX);
				if(SendRecPLCWithBCC(2,(unsigned char *)PlcSendBuff,(unsigned char *)rDataFx,&sCnt,0) == 0){
				ret= C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt,0,1,(char*)(Sch),100); //0x10
						if(ret != 0)return NG; 
						//Data Analysis
						for(dataCnt=0; dataCnt< Cnt ; dataCnt++)
						{
							if(rDataFx[dataCnt]==0xff && rDataFx[dataCnt+1]==0x04){
								break;
							}
						}
						if(rDataFx[dataCnt++]==0xff)
						{ 
							//Read ���� 
							if(rDataFx[dataCnt++] == 0x04) // bit 21
							{//22
								bitCnt = (rDataFx[dataCnt++]<<8);//23
								if(rDataFx[dataCnt-1]==DLE) dataCnt++; //24
								bitCnt = bitCnt | rDataFx[dataCnt++]; // 23,24=>24 25 
								if(rDataFx[dataCnt-1]==DLE) dataCnt++; // 25,26
								
								bitCnt = bitCnt/8;
								sAddr = mp->mpar % 8; 
								CmpbitCnt=0;
								for(j=0; j< bitCnt; j++)
								{
									if(rDataFx[dataCnt]==0x10 ){
										dataCnt++;
									}
									for(i=sAddr; i<8;i++)
									{
										if((rDataFx[dataCnt]&(0x01<<i)) == 0)
										{
											*(unsigned char *)SaveAddr = 0;
											SaveAddr++;
										}
										else
										{
											*(unsigned char *)SaveAddr = 1;
											SaveAddr++;
										}
										CmpbitCnt++;
										if(CmpbitCnt == mp->mext)
											break;
									}
									sAddr=0;
									dataCnt++;
								}
								
							}
				
							ret= C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt,0,2,(char*)(Sch),100); //0x10, 0x02
							if(ret != OK)return NG;
							ret = C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt, 0,MessageAckCnt,(char*)SaveAck,0); //Data ACK
							if(ret!=OK)
							{
								ret = NG;
								EndFlag=1;
								return(ret);
							}
							ret=OK;
							EndFlag=1;
							RecvFlag=0x00;
						}
						else
						{
							ret=NG;
							EndFlag=1;
						}		
				}else{
					ret = NG;
					EndFlag = 1;
				}
			}else{
				ret =NG;
				EndFlag =1;
			}
		
	}
		return(ret);
}
static	int	WordReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i, bitCnt;
	int		sCnt, Cnt, dataCnt;
	int		dCnt;
	int		Address;
	int		EndFlag;
	unsigned char	*SaveAddr;
		
	Address= mp->mpar;
	dCnt= mp->mext;	
	EndFlag= 0;
	while(EndFlag==0){
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
		
			ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext,(int)mp->mbuf[4]); 
			Cnt = mp->mext* 2;
			sCnt= FrameCnt;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){

				if(SendRecPLCWithBCC(2,(unsigned char *)PlcSendBuff,(unsigned char *)rDataFx,&sCnt,0) == 0){ 
if(C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt,0,1,(char*)(Sch),2000)!=OK) return NG; // 0x10

					// data frame check
					for(dataCnt=0; dataCnt< Cnt ; dataCnt++)
					{
						if(rDataFx[dataCnt]==0xff && rDataFx[dataCnt+1]==0x04){
							break;
						}
					}
					if(dataCnt==Cnt)return NG; 
					else dataCnt++;

					if(rDataFx[dataCnt++]==0x04)
					{
						//���� ����Ʈ�� ���� 
						bitCnt = rDataFx[dataCnt++]<<8;
						if(rDataFx[dataCnt-1]==DLE){
							dataCnt++;
						}
						bitCnt |= rDataFx[dataCnt++];
						if(rDataFx[dataCnt-1]==DLE){
							dataCnt++;
						}
						
						
						bitCnt = bitCnt/8;  // bit -> byte
						
						for(i=0; i< bitCnt-1; i++)
						{

#ifdef	SH_CPU					
							if(rDataFx[dataCnt+i]==DLE)
							{
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[dataCnt+i+2];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[dataCnt+i];
								SaveAddr++;
								i++;
								bitCnt++;							
							}
							else
							{
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[dataCnt+i+1];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[dataCnt+i];
								SaveAddr++;
							}
								
#endif
#ifdef	ARM_CPU
#ifdef	LITTLE_ENDIAN
								
							if(rDataFx[dataCnt+i]==DLE)
							{
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[dataCnt+i+2];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[dataCnt+i];
								SaveAddr++;
								i++;
								bitCnt++;
							}	
							else
							{
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[dataCnt+i+1];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[dataCnt+i];
								SaveAddr++;
							}
								
#else if BIG_ENDIAN
								
							if(rDataFx[dataCnt+i]==DLE){
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[dataCnt+i];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[dataCnt+i+2];
								SaveAddr++;
								bitCnt++;
								i++;
							}
							else
							{
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[dataCnt+i];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[dataCnt+i+1];
								SaveAddr++;
							}								
#endif
#endif
							}

						if(C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt,0,2,(char*)(Sch),100)!=OK)return NG; //0x10, 0x02
						if(rDataFx[0]==NAK)
							if(C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt,0,2,(char*)(Sch),100)!=OK)return NG; //0x10, 0x02

						if(C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt, 0,MessageAckCnt,(char*)SaveAck,0)!=OK) //Data ACK
						{
							ret = NG;
							EndFlag=1;
							return(ret);
						}
						ret=OK;
						EndFlag=1;
						RecvFlag=0x00;
						
						Address += MAX_WORDCNT;
						mp->mpar= Address;
						mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
					}
					else
					{
						ret=NG;
						EndFlag=1;
						return (ret);
					}


				}else{
					ret = NG;
					EndFlag= 1;
				}					
			}else{
				ret= NG;
				EndFlag= 1;
			}
		}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;

	GetGroopSema();
	switch(mp->mpec){
	case PLC_BIT:		ret= BitReadProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordReadProc(mp,rDataFx,PlcType);		break;
	}
	ResetGroopSema();
	B_Delay(10);
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/	
static	int	ChangeIntData(char *data,int Cnt,int mode)
{
	int		iData;
	int		i;
	union{
		int		iData;
		char	cData[4];
	}rData;

	B_gmemset((char *)&rData,0,sizeof(rData));
	if(mode == 1){
		for(i= 0; i < Cnt*2 && i < 4; i++){
			rData.cData[3- i]= *data;
			data++;
		}
		iData = rData.iData;
	}else{
		iData = *data;
	}
	return(iData);
}
/****************************/
/* Make Write Device		*/
/****************************/

static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data,int StationNo)
{
	
	int	ret;
	int pos,tpos,dpos,i,cnt;
	int	DevAddr;
	char sTmp[256];

	pos=0;
	tpos=0;
	dpos=0;
	ret = 0;

	if(Cnt==0){ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);}

	//���� ������ 0x00, 0x0C, 0x03, 0x03, 0xF1
	B_gmemcpy(combuff+pos, (char*)FrameType[0].frame, FrameType[0].cnt);  
	pos += FrameType[0].cnt;
	
	// Frame Number
	FrameNo+=0x01;
	if(FrameNo==0x10)
	{
		combuff[pos++]= FrameNo; 	
	}
	combuff[pos++]= FrameNo; 
	if(FrameNo==0xff)
	{
			FrameNo=0x00;
	}

	// fix frame 0x32, 0x01, 0x00,0x00,0x44,0x01
	B_gmemcpy(combuff+pos, (char*)FrameType[1].frame, FrameType[1].cnt);
	pos+=FrameType[1].cnt;
	combuff[pos-2]=0x44; // Write mode
		
	// fix frame 0x05,0x01,0x12,0x0A,0x10,0x10,0x02
	B_gmemcpy(sTmp+tpos, (char*)FrameType[2].frame, FrameType[2].cnt);  
	tpos += FrameType[2].cnt;
	sTmp[0]= 0x05;
	
	if(mode == 0)
	{
		sTmp[tpos-1]=0x01;// bit write
		sTmp[tpos++]=0x00;
		sTmp[tpos++]=0x01;
	}
	else{
		sTmp[tpos-1]=0x04; // byte//02
		sTmp[tpos++]=0x00;
		sTmp[tpos++]=0x01;   //02
	}
	

	sTmp[tpos++]=0x00;
	sTmp[tpos++]=0x00;

	//device code
	if(mode==0){
		sTmp[tpos++] = pDevice[1];
		//device start address
		sTmp[tpos++] = 0x00; 
		sTmp[tpos++]=Address/0x100;
		if(sTmp[tpos-1]==DLE)
		{
			sTmp[tpos++]=DLE;
			dpos-=1;
		}
		sTmp[tpos++]=Address%0x100;
		if(sTmp[tpos-1]==DLE)
		{
			sTmp[tpos++]=DLE;
			dpos-=1;
		}
	}
	else
	{
		sTmp[tpos++] = pDevice[1]; // ����̽� �ڵ� 
		//device start address
		sTmp[tpos++] = 0x00; 
		sTmp[tpos++]=(Address*8)/0x100;
		if(sTmp[tpos-1]==DLE)
		{
			sTmp[tpos++]=DLE;
			dpos-=1;
		}
		sTmp[tpos++]=(Address*8)%0x100;
		if(sTmp[tpos-1]==DLE)
		{
			sTmp[tpos++]=DLE;
			dpos-=1;
		}
		

	}
				
	//parameter ���� 
	combuff[pos++]= (tpos+dpos-1)/0x100;
	combuff[pos++]= (tpos+dpos-1)%0x100;

	if(mode ==0){
		sTmp[tpos++]=0x00;
		sTmp[tpos++]=0x03;
		sTmp[tpos++]=0x00;
		sTmp[tpos++]=0x01;
		sTmp[tpos++]=*(data+Cnt);
		if(*(data+Cnt)==DLE)
			sTmp[tpos++]=DLE;

		combuff[pos++]=0x00;
		combuff[pos++]=0x05;

	}
	else{
		sTmp[tpos++]=0x00;
		sTmp[tpos++]=0x04;
		sTmp[tpos++]=0x00;
		sTmp[tpos++]=0x10;
		sTmp[tpos++]=0x10;
		dpos--;
#ifdef SH_CPU
		sTmp[tpos++]=*(data+1+(Cnt*2));
		if(*(data+1+(Cnt*2))==DLE){
			sTmp[tpos++] = DLE;
			dpos--;
		}
		sTmp[tpos++]=*(data+(Cnt*2));
		if(*(data+1+(Cnt*2))==DLE){
			sTmp[tpos++] = DLE;
			dpos--;
		}
#endif
#ifdef ARM_CPU
#ifdef LITTLE_ENDIAN
		sTmp[tpos++]=*(data+1+(Cnt*2));
		if(*(data+1+(Cnt*2))==DLE){
			sTmp[tpos++] = DLE;
			dpos--;			
		}
		sTmp[tpos++]=*(data+(Cnt*2));
		if(*(data+(Cnt*2))==DLE){
			sTmp[tpos++] = DLE;
			dpos--;
		}
#else BIG_ENDIAN
		sTmp[tpos++]=*(data+(Cnt*2));
		if(*(data+(Cnt*2))==DLE){
			sTmp[tpos++] = DLE;
			dpos--;
		}
		sTmp[tpos++]=*(data+1+(Cnt*2));
		if(*(data+1+(Cnt*2))==DLE){
			sTmp[tpos++] = DLE;
			dpos--;
		}
#endif
#endif
		cnt = tpos+dpos-combuff[pos-1]-1;

		combuff[pos++]=cnt/0x100; //0x00;
		combuff[pos++]=cnt % 0x100; //0x06;
	}
for(i=0; i<tpos;i++)
		combuff[pos++]=sTmp[i];

	FrameCnt=pos;	
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
static	int	BitWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,Address,sCnt;
	int		DeviceCount;
	int		ReCnt;
	int		i;

	ret = 0;
	ReCnt=mp->mext;
	DeviceCount=0;
	Address=mp->mpar;
	GetGroopSema();
	while(ReCnt!=0){
		RecvFlag=0x00;
		ret = MakePLCWriteData(0,(char *)mp->mbuf,Address,DeviceCount,(char *)PlcSendBuff,(char *)mp->mptr,(int)mp->mbuf[4]);
	sCnt = FrameCnt; 
		if(ret == 0){
			B_gmemset((char*)rDataFx, 0x00, PLC_BUF_MAX);

			if(SendRecPLCWithBCC(2,(unsigned char *)PlcSendBuff,rDataFx,&sCnt,0) == 0){
				B_Delay(20);
			}else{
				ret = -1;
			}

			if(C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt,0,1,(char*)(Sch),100)==0)
			{
				B_Delay(20);
			}
			//Data Analysis
			for(i=0; i<Cnt ; i++)
			{
				if(rDataFx[i]==0xff)
					break;
			}
			if(i == Cnt) return NG;
			ret= C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt,0,2,(char*)(Sch),100);
			ret = C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt, 0,MessageAckCnt,(char*)SaveAck,0);
		}else if(ret == 1){
			ret= 0;
		}
		ReCnt--;
		Address++;
		DeviceCount++;
	}
	return(ret);
}
static	int	WordWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,Address, i, sCnt;
	int		DeviceCount;
	int		ReCnt;
	
	ret = 0;
	ReCnt=mp->mext;
	DeviceCount=0;
	Address=mp->mpar;
	GetGroopSema();
		while(ReCnt!=0){
			ret = MakePLCWriteData(1,(char *)mp->mbuf,Address,DeviceCount,(char *)PlcSendBuff,(char *)mp->mptr,(int)mp->mbuf[4]);
			if(ret == 0){
			sCnt=FrameCnt;
				B_gmemset((char*)rDataFx, 0x00, PLC_BUF_MAX);

				if(SendRecPLCWithBCC(2,(unsigned char *)PlcSendBuff,rDataFx,&sCnt,0) == 0){ // send write frame
				//	B_Delay(20);
				}else{
					ret = -1;
				}

				if(C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt,0,1,(char*)(Sch),100)==0)
				{
					B_Delay(20);
				}
				//Data Analysis
				for(i=0; i<Cnt ; i++)
				{
					if(rDataFx[i]==0xff)
						break;
				}
				if(i == Cnt) return NG;
				if(C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt,0,2,(char*)(Sch),100)!=OK)return NG;
				if(C_SendRecPLC(2,(unsigned char *)rDataFx, &Cnt, 0,MessageAckCnt,(char*)SaveAck,0)!=OK)return NG;

			}else if(ret == 1){	
				ret= 0;
			}
			ReCnt--;
			Address++;
			DeviceCount++;
		}
	return(ret);
}
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	switch(mp->mpec){
	case PLC_BIT:		ret= BitWriteProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordWriteProc(mp,rDataFx,PlcType);		break;
	}
	ResetGroopSema();
	return(ret);
}
static	int	C_GetSendRecTime(void)
{
	return(5);				/* 1ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}


/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
//	int	ret;

//	ret = -1;
//	switch(*CommMode){
//	case 0:		/* Normal */
//		switch(data){
//		case STX:
//		case ENQ:
//		case ACK:
//		case NAK:
//			*CommMode = 4;
//			*Sio1RecCnt = 0;
//			Sio1RecBuff[(*Sio1RecCnt)++] = data;
//		}
//		break;
//	case 4:		/* Thru Mode */
//		if(*Sio1RecCnt < PLC_BUF_MAX){
//			Sio1RecBuff[(*Sio1RecCnt)++] = data;
//			if((data == EOT) || (data == ETX)){
//				*CommMode = 5;
//			}
//		}else{
//			*CommMode = 0;
//		}
//		break;
//	case 5:		/* CRC1 */
//		if(*Sio1RecCnt < PLC_BUF_MAX){
//			Sio1RecBuff[(*Sio1RecCnt)++] = data;
//			*CommMode = 99;
//			ret= 0;
//		}else{
//			*CommMode = 0;
//		}
//		break;
//	}
//	return(ret);
int	ret= -1;
	int i=0;
	unsigned char bcc=0x00;

	switch(*CommMode)
	{
	case 0:	
		*Sio1RecCnt=0;
		Sio1RecBuff[(*Sio1RecCnt)++]=data;
		switch(data)
		{
		case DLE:
			if(RecvFlag ==0x00)
			{
				ret=0;
				*CommMode=99;
				RecvFlag = 0x01;
				return (ret);
			}
			else if(RecvFlag == 0x01)
			{
				*CommMode=4;
				return (ret);
			}
			else if(RecvFlag == 0x03)
			{
				ret=0;
				RecvFlag = 0x04;
				return (ret);
			}
			else if(RecvFlag == 0x04)
			{
				ret=0;
				RecvFlag = 0x00;
				return (ret);
			}
			break;
		case STX:
			ret=0;
			*CommMode=99;
			RecvFlag = 0x03;
			return (ret);
			break;
		case NAK:
			if(RecvFlag==0x03)
			{
				ret =-1;
				return (ret);
			}
			break;
		default:
			if(RecvFlag==0x02)
			{
				*CommMode = 5;
			}
			else if(RecvFlag==0x03)
			{
				*CommMode = 5;
			}
			return (ret);
			break;
		}
		break;
	case 4:
		if(data == STX)
		{
			Sio1RecBuff[(*Sio1RecCnt)++]=data;
			ret=0;
			*CommMode=99;
			RecvFlag=0x02;
			return (ret);
		}
		break;

	case 5:
		if(*Sio1RecCnt<PLC_BUF_MAX)
			Sio1RecBuff[(*Sio1RecCnt)++]=data;

		if(data == DLE)
		{
			*CommMode=6;
		}
		break;
	case 6:
		if(*Sio1RecCnt<PLC_BUF_MAX)
			Sio1RecBuff[(*Sio1RecCnt)++]=data;
		if(data == ETX)
		{
			*CommMode =7;
		}
		else 
		{
			*CommMode =5;
		}
		break;
	case 7:
		if(*Sio1RecCnt<PLC_BUF_MAX)
			Sio1RecBuff[(*Sio1RecCnt)++]=data;

		for(i =0; i< *Sio1RecCnt-1 ; i++)
		{
			bcc ^=Sio1RecBuff[i];
		}
		if(data == bcc)
		{
			// ������ ���� ����

			ret =0;
			*CommMode=99;
			if(RecvFlag==0x02)
				RecvFlag=0x00;
			else if(RecvFlag ==0x03)
				RecvFlag = 0x03;

		}
		else
		{
			ret = -1;
			*CommMode = 2;
			return (ret);
		}
		break;
	}
	return(ret);    

}
/************************************************/
/*	�O��?�v����								*/
/************************************************/
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	return(0);
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if(DeviceDataSys[i].SameDevInf == 0){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
						MyAddress= DeviceDataSys[i].DevAddress;
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Before Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;

	int		StartIdx;

	StartIdx= WordStart;
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
					MyAddress= DeviceDataSys[i].DevAddress;
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Before Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN			   */									
/*	2006.03.31 makebitpatarn �ϰ� ����         */
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/*	2006.03.31 makewordpatarn �ϰ� ����        */							
/***************************************************/
void	MakeWordPatarn(int Start)
{

}
/****************************************/
/*	�O��?�v�쐬			*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Same Device Check */
/*	gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));*/
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	/* �r�b�g�A��?�h�̘A����?�F�b�N���� */
	MakeBitContinue();
	MakeWordContinue(TotalBitCnt);
	/* �r�b�g�A��?�h�̃p??����?�F�b�N���� */
	/* Bit Patarn */
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	/* Word Patarn */
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}

	return(0);
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int	ret;

	ret= 0;
	return(ret);
}
/************************************/
/*	�X��?��?�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	GetGroopSema();
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendThruePLC(2,*OutCnt,OutBuff,3000); /*20090706*/
	ResetGroopSema();

#ifdef	OLDSOURCE
#endif
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
#endif
/*++++++++++++++++++++++++++++++++++++*/
#ifdef PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif


#include  "hook_aplplc.h"
/****************************** END **********************/
