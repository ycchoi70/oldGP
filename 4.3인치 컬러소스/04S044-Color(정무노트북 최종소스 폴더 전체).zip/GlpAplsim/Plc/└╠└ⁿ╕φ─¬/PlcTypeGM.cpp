/*****************************************************************************************/
/*	PLC ����M �v���O��?(LG-K3P-07AS)	*/
/*	2003.5.31				*/
/************************************************/
/*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		  */
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
/*	2006.09.25 */
/*      �����͹� ���ø� ������ ���� ver 2.6�� �ϰ� ����	  */
/*  2007.01.30 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����		*/
/*  2007.10.08 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����			*/  
/*****************************************************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include	"hook_plcapl.h"




/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V4.0M"
/*****************************************************************************************/


#define	MAX_BITCNT	512
#define	MAX_WORDCNT	58    /*check complete*/ 
#define	MAX_PBITCNT	512
#define	MAX_PWORDCNT 10
#define MAX_MOR_CNT 200
#define	MAX_WORD_CONT_CNT	4
#define	MAX_BIT_CONT_CNT	4

#define	MAX_RTY_COUNT	3


/********************************/
/*	GM Serease					*/
/********************************/
static	const	DEV_TBL bPLCDeviceTbl[16] = {
	{"IX",0x0000,1},
	{"QX",0x0000,2},
	{"MX",0x0000,3},
	{"GB",     0,4},
};
static	const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"IW",0x0000,1},
	{"QW",0x0000,2},
	{"MW",0x0000,3},
	{"GD",     0,4},
};

/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef	PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
/************************************************/
/*	Func:C_SendPC2PLCData						*/
/*		PLC���ɑ��M����							*/
/*	IN	int mode:���M��?�h						*/
/*			0:���M�̂�,1:���M��ACK��M,2:���M��f??��M,3:���M��ACK+�f??��M */
/*		int cnt:���M�J�E���g					*/
/*		char *buff:���M�o�b�t??				*/
/*		int TimeOut:��M�҂�?�C?�A�E�g�i�����j*/
/*	Ret	0:OK,-1:Error							*/
/************************************************/
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_38400;
	*DataBit= RS_DATA8;
	*Parity= RS_NONE;
}

/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(data){
	case STX:
	case ENQ:
	case ACK:
	case NAK:
		*RecCnt= 0;			/* ?���X??�g */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 1;
		break;
	default:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		switch(*CommMode){
		case 1:
			if((data == EOT) || (data == ETX)){
				*CommMode = 0;
				ret= 0;
			}
			break;
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/

/****************************/
/* Make Check SUM For PLC	*/
/****************************/
static	int SetPLCBCC(char *buff,int cnt)
{
	int		i;
	unsigned char bcc;

	buff[0] = STX;
/*	for(i = 0; i < cnt; i++){
		OutBuf[i+1] = buff[i];
	}
*/
	bcc = 0;
	for(i = 0; i < cnt; i++){
		bcc += buff[i+1];
	}
	/*sprintf((char *)&OutBuf[cnt+1],"%02X",bcc&0x00ff);*/
	B_Bin2Hex(bcc&0x00ff,2,(char *)&buff[cnt+1]);
	buff[cnt+3] = ETX;
	return(cnt + 4);
}
/************************************/
/*	PLC Send						*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *RecData,int *Cnt,int rmode)
{
	int		i;
	int		ret;
	int		rty_cnt;
	unsigned char bcc;
	unsigned char bcc1;
	int		SendCnt;

/*	PlcCommCnt= SetPLCBCC((char *)combuf,gstrlen(combuf),PlcSendBuff);*/
	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen((char *)&combuf[1]));
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
/*		ret= B_SendRecPLC(mode,RecData,Cnt,rmode);*/
		ret= C_SendRecPLC(mode,RecData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		if(ret == 0){
			/* DATA->EOT(SUM) */
			bcc= 0;
			for(i = 0; i < *Cnt-4; i++){
				bcc += RecData[i+1];
			}
			bcc1= (unsigned char)B_Hex2Bin((char *)&RecData[*Cnt-3]);
			if(bcc != bcc1){
				ret= -1;
			}
		}
		if(ret == OK){
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}
	return(ret);
}
static	int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *RecData,int *Cnt,int rmode)
{
	int		ret;
	int		SendCnt;

/*	PlcCommCnt= SetPLCBCC((char *)combuf,gstrlen(combuf),PlcSendBuff);*/
/*	ret= B_SendRecPLC(mode,RecData,Cnt,rmode);*/
	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen((char *)&combuf[1]));
	ret= C_SendRecPLC(mode,RecData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	return(ret);
}
static	int	C_Connection( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;
	char	buff[10];
#ifndef	WIN32
	int		Speed;
	int		DataBit;
	int		Parity;
#endif
	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */
#ifdef	WIN32
			SioPCMode= 2;
			SioPCOpenFlag= 1;
#else
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PC,RS_INIT,RS_38400,RS_DATA8,RS_NONE); */
#endif
		}else{						/* RS-422 */
#ifdef	WIN32
			SioPLCMode= 2;
			SioPLCOpenFlag= 1;
#else
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE); */
#endif
		}
#ifdef	WIN32
		while(1){
			if(SioPLCOpenFlag == 0){
				break;
			}
			B_Delay(10);
		}
#endif
	}
	B_Delay(100);

	/* PLC Connect Check */
/*	ret= SendRecPLCWithBCCCont(2,"j",GrpPLCcombuf,&Cnt,0);*/
	buff[1]= 'j';
	buff[2]= 0;
	ret= SendRecPLCWithBCCCont(2,buff,PlcRecBuff,&Cnt,0);
/*	if(gstrncmp((char *)GrpPLCcombuf,"\x06j",2) != 0){*/
	if(PlcRecBuff[0] != 0x06){
		ret= -1;
	}
	if(ret < 0){
		return(0);
	}
	ret= 1;
	return(ret);
}
/******************************************/
static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif

#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif

}

/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}


/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, char *DeviceName, int sCnt)
{
	int		i,j;
	int		ret;
	char  Device[4];
	
	ret = -1;
	
	/* Device Name */
/*	if(B_GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&i,&Address) == -1){*/
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(bPLCDeviceTbl[i].Device[0] == Device[0]){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = (Address / 16) * 2;
				ret = Address % 16;
				BitAndData = 1;
				for(j = 0; j < ret; j++){
					BitAndData <<= 1;
				}
				ret += (sCnt-1);
				ret = ret / 8 + 1;
				if((ret % 2) != 0){
					ret++;
				}
				BitRecCnt = ret;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(wPLCDeviceTbl[i].Device[0]==Device[0]){
					DeviceFlag= wPLCDeviceTbl[i].flag;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = Address * 2;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	switch(Device[0]){
	case 'I':
		B_gstrcpy(DeviceName,"X");
		break;
	case 'Q':
		B_gstrcpy(DeviceName,"Y");
		break;
	case 'M':
		B_gstrcpy(DeviceName,"Z");
		break;
	default:
		/*gstrcpy(DeviceName,"Z");*/
		break;
	}

	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int	DevAddr;
	char	buff[32];
	char	abuff[4+1];
	char	DeviceName[4];
	
	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, DeviceName, sCnt);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		B_Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		if(mode == 0){		/* BIT */
			/*sprintf(combuff,"r%s00%02X",abuff,BitRecCnt);*/
			B_gstrcpy(combuff,"r");
			B_gstrcat(combuff,DeviceName);
			B_gstrcat(combuff,abuff);
			B_gstrcat(combuff,"00");
			B_Bin2Hex(BitRecCnt,2,abuff);
			B_gstrcat(combuff,abuff);
		}else{				/* WORD */
			/*sprintf(combuff,"r%s00%02X",abuff,sCnt);*/
			B_gstrcpy(combuff,"r");
			B_gstrcat(combuff,DeviceName);
			B_gstrcat(combuff,abuff);
			B_gstrcat(combuff,"00");
			B_Bin2Hex(sCnt,2,abuff);
			B_gstrcat(combuff,abuff);
		}
	}
	return(ret);
}

/************************************/
/* PLC Read							*/
/************************************/
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j;
	int		Cnt;
	int		rCnt;
	int		rdata;
	unsigned char	*SaveAddr;
	int		dCnt;
/*	char	Device[4];
	int		DevInfo;
*/
	int		Address;
/*	int		UsrAddress;*/

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		Address= mp->mpar;
/*		ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);*/
		dCnt= mp->mext;
		while(1){
			if(dCnt > MAX_BITCNT){
				dCnt -= MAX_BITCNT;
				mp->mext= MAX_BITCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],mp->mext);
			Cnt = mp->mext;
			rCnt = BitRecCnt;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0) == 0){
					if(rDataFx[0] != 0x06){
						ret= -1;
						break;
					}else{
						for(i = 0; i < rCnt; i++){
							rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+ 2]);
						}
						j= 0;
						rdata= rDataFx[j] + (rDataFx[j+1] << 8);
						for(i = 0; i < Cnt; i++){
							if(rdata & BitAndData){
								*(unsigned char *)SaveAddr++ = 1;
							}else{
								*(unsigned char *)SaveAddr++ = 0;
							}
							BitAndData <<= 1;
							if(BitAndData > 0x8000){
								BitAndData = 1;
								j++;
								rdata= rDataFx[j*2] + (rDataFx[j*2+1] << 8);
							}
						}
					}
				}else{
					ret = -1;
					break;
				}
			}
			if(dCnt == 0){
				break;
			}
			Address += MAX_BITCNT;
/*			UsrAddress= plcSetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);*/
			mp->mpar= Address;
			mp->mptr= (void *)((char *)mp->mptr + MAX_BITCNT);
		}
		break;
	case PLC_WORD:		/* Word Device */
		Address= mp->mpar;
/*		ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);*/
		dCnt= mp->mext;
		while(1){
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],mp->mext*2);
			Cnt = mp->mext* 2;
			rCnt = mp->mext* 2;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0) == 0){
					if(rDataFx[0] != 0x06){
						ret= -1;
						break;
					}else{
						for(i = 0; i < rCnt; i++){
							rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+ 2]);
						}

						for(i = 0; i < Cnt/2; i++){
#ifdef	SH_CPU
							*(unsigned char *)SaveAddr++ = rDataFx[i*2];
							*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
#endif
#ifdef	ARM_CPU
#ifdef	WIN32
							*(unsigned char *)SaveAddr++ = rDataFx[i*2];
							*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
#else
							*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
							*(unsigned char *)SaveAddr++ = rDataFx[i*2];
#endif
#endif
						}
					}
				}else{
					ret = -1;
					break;
				}
			}
			if(dCnt == 0){
				break;
			}
			Address += MAX_WORDCNT;
/*			UsrAddress= plcSetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);*/
			mp->mpar= Address;
			mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
		}
		break;
	}
	return(ret);
}




/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	int		DevAddr;
	char	buff[32],buff2[32];
	char	abuff[4+1];
	char	bbuff[4+1];
	char	cbuff[2+1];
	char	DeviceName[4];
	
	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, DeviceName, Cnt);
	
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		/*Bin2Hex(DevAddr,4,buff);*/
		B_Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		B_Bin2Hex(DevAddr+1,4,buff2);
		bbuff[0]= buff2[2];
		bbuff[1]= buff2[3];
		bbuff[2]= buff2[0];
		bbuff[3]= buff2[1];
		bbuff[4]= 0;
		if(mode == 0){		/* BIT */
			if(*data == 0){			/* OFF */
				B_gstrcpy(combuff,"n");
				B_gstrcat(combuff,DeviceName);
				B_Bin2Hex((~BitAndData & 0x0000ffff),4,buff);				
				if((BitAndData & 0x0000ffff) < 0xff){
						B_gstrcat(combuff,abuff);
						cbuff[0]=buff[2];
						cbuff[1]=buff[3];
						cbuff[2]=0;
				}else{
						B_gstrcat(combuff,bbuff);
					        cbuff[0]=buff[0];
						cbuff[1]=buff[1];
						cbuff[2]=0;
				}
				B_gstrcat(combuff,"00");
				B_gstrcat(combuff,cbuff);
			}else{
				/*sprintf(combuff,"oM%s00",abuff);*/
				B_gstrcpy(combuff,"o");
				B_gstrcat(combuff,DeviceName);
				B_Bin2Hex(BitAndData,4,buff);				
				if(BitAndData < 0xff){
						B_gstrcat(combuff,abuff);
						cbuff[0]=buff[2];
						cbuff[1]=buff[3];
						cbuff[2]=0;
				}else{
						B_gstrcat(combuff,bbuff);
					    	cbuff[0]=buff[0];
						cbuff[1]=buff[1];
						cbuff[2]=0;
				}
				B_gstrcat(combuff,"00");
				B_gstrcat(combuff,cbuff);
			}
		}else{		/* WORD */
			/*sprintf(combuff,"wM%s00%02d",abuff,Cnt*2);*/
			B_gstrcpy(combuff,"w");
			B_gstrcat(combuff,DeviceName);
			B_gstrcat(combuff,abuff);
			B_gstrcat(combuff,"00");
			B_Bin2Hex(Cnt*2,2,buff);
			B_gstrcat(combuff,buff);
#ifdef	SH_CPU
			for(i= 0; i < Cnt*2; i++){
				/*sprintf(buff,"%02X",data[i] & 0xff);*/
				B_Bin2Hex(data[i] & 0xff,2,buff);
				B_gstrcat(combuff,buff);
			}
#endif
#ifdef	ARM_CPU
			for(i= 0; i < Cnt; i++){
				/*sprintf(buff,"%02X",data[i] & 0xff);*/
				B_Bin2Hex(data[i*2+1] & 0xff,2,buff);
				B_gstrcat(combuff,buff);
				B_Bin2Hex(data[i*2] & 0xff,2,buff);
				B_gstrcat(combuff,buff);
			}
#endif
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;
	int		dCnt;
/*	char	Device[4];
	int		DevInfo;
*/
	int		Address;
/*	int		UsrAddress;*/

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)&PlcSendBuff[1],(char *)mp->mptr);
		Cnt = mp->mext;
		if(ret == 0){
			if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){
				if(rDataFx[0] != 0x06){
					ret= -1;
				}
			}else{
				ret = -1;
			}
		}
		break;
	case PLC_WORD:		/* Word Device */
		Address= mp->mpar;
/*		ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);*/
		dCnt= mp->mext;
		while(1){
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)&PlcSendBuff[1],(char *)mp->mptr);
			if(DeviceFlag == 2){		/* TS,CS */
				Cnt = mp->mext* 4;
			}else{
				Cnt = mp->mext* 2;
			}
			if(ret == 0){
				if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){
					if(rDataFx[0] != 0x06){
						ret= -1;
						break;
					}
				}else{
					ret = -1;
					break;
				}
			}
			if(dCnt == 0){
				break;
			}
			Address += MAX_WORDCNT;
/*			UsrAddress= plcSetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);*/
			mp->mpar= Address;
			mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
		}
		break;
	}
	return(ret);
}
static	int	C_GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}


/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	switch(*CommMode){
	case 0:		/* Normal */
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:		/* Thru Mode */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			if((data == EOT) || (data == ETX)){
				*CommMode = 99;
				ret = 0;	/* Pendding Req */
			}
		}else{
			*CommMode = 0;
		}
		break;
	}
	return(ret);
}
/************************************************/
/*	�O��?�v����								*/
/************************************************/
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	int	ret;
	int	DevAddr;
	char	buff[8];
	char	abuff[8];
	char	DeviceName[4];

	if(((unsigned char)DevName[0] == 0x7f) || ((unsigned char)DevName[0] == 0xef)){		/* UB,UW */
		return(-1);
	}
	ret= MakePLCDevAddress(mode, DevName, DevAddress, &DevAddr, DeviceName, 0);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		B_Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		/*sprintf(work,"M%s0002",abuff);*/
		B_gstrcpy(work,DeviceName);
		/*gstrcpy(work,"M");*/
		B_gstrcat(work,abuff);
		B_gstrcat(work,"0002");
	}
	return(ret);
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
						MyAddress= DeviceDataSys[i].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
					MyAddress= DeviceDataSys[i].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN			   */
/*	2006.03.31 makebitpatarn �ϰ� ����         */
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/*	2006.03.31 makewordpatarn �ϰ� ����        */
/***************************************************/
void	MakeWordPatarn(int Start)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/***************************************************/
void	ClearBWContinue(void)
{
	int		i,j,idx;

	for(i= 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus != 0)){
			/* Continue */
			if(DeviceDataSys[i].DevFlag == 0){		/* BIT */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_BIT_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}else{									/* WORD */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_WORD_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}
		}
	}
}

int	MakeWordMonitor(void)
{
	int		i=0,j,k;
	int		idx;
	char	work[12+ 1];
	int		ret= 0;
	int		Cnt;
	char	*b_number[4]={"00","01","02","03"};
	

	for(j=0; j<4; j++){
	B_gstrcpy(&work[1],"uA");
	B_gstrcat(&work[1],b_number[j]);
	ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcRecBuff,&Cnt,0);
		if(ret == 0){
			if(PlcRecBuff[0] != 0x06){
			ret= -1;
			}	
		}
	}

	for(j=0; j<4; j++){
		for(k=0; k<2; k++){
			B_gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));
			gDeviceCntWord= 0;
			gDeviceCntBit= 0;
			B_gstrcpy((char *)&PlcSendBuff[1],"uW");
			idx= 0;
			gDeviceCnt= 0;

			for(i = 0+i; i < DeviceCntSys; i++){
				if((DeviceDataSys[i].DevCnt == 1) &&
					(DeviceDataSys[i].DevFlag == 1) &&
					(DeviceDataSys[i].SameDevInf == 0) &&
					(DeviceDataSys[i].Continus == 0)){
					if(PlcMakeDeviceAddr(DeviceDataSys[i].DevFlag, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work) == 0){
						B_gstrcpy((char *)&PlcSendBuff[7 + idx+ gDeviceCnt*9],(char *)work);
						gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
						gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
						DeviceDataSys[i].SameDevInf= 4;
						gDeviceCnt++;
						gDeviceCntWord++;
					}
				}
				if(gDeviceCnt >= MAX_UR_CNT/2){
					break;
				}
			}
			if(gDeviceCnt != 0){
				
				if(ret == 0){
					B_gstrcat((char *)&PlcSendBuff[1],b_number[j]);
					B_Bin2Hex(gDeviceCntWord,2,work);
					B_gmemcpy((char *)&PlcSendBuff[5],work,2);
					ret= SendRecPLCWithBCC(2,(char *)&PlcSendBuff[0],(unsigned char *)PlcRecBuff,&Cnt,0);
					if(ret == 0){
						if(PlcRecBuff[0] != 0x06){
							ret= -1;
						}
					}
				}
				
			}
		}
	}
	
	for(j=0; j<4; j++){
		B_gstrcpy(&work[1],"uE");
		B_gstrcat(&work[1],b_number[j]);
		if(ret == 0){
			ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PlcRecBuff,&Cnt,0);
			if(ret == 0){
				if(PlcRecBuff[0] != 0x06){
				ret= -1;
				}
			}
		}
	}

	return(ret);
}




/****************************************/
/*	�O��?�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Set Group */
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gDeviceCnt= 0;
	/* Same Device Check */
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	if(BitCnt > 0){
		MakeBitContinue();
	}
	if(WordCnt > 0){
		if(WordCnt <= MAX_MOR_CNT){
			MakeWordMonitor();
		}else{
			MakeWordMonitor();
			MakeWordContinue(TotalBitCnt);
			
		}
	}
	/* Continue MAX Check */
	ClearBWContinue();
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}
	return(0);
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
void	SetGroupDevPLC(void)
{
	int		i;
	int		idx;
	char	work[12+ 1];
	
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;

	idx= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	for(i = 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].DevCnt == 1) &&
			(DeviceDataSys[i].DevFlag == 1) &&
			(DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus == 0)){
			if(PlcMakeDeviceAddr(DeviceDataSys[i].DevFlag, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work) == 0){
				B_gstrcpy((char *)&PlcSendBuff[7 + idx+ gDeviceCnt*9],(char *)work);
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
				gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
				DeviceDataSys[i].SameDevInf= 4;
				gDeviceCnt++;
				gDeviceCntWord++;
			}
		}
		if(gDeviceCnt >= MAX_UR_CNT){
			break;
		}
	}
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		ReadGroupPLCDev(int mode)
{
	int		ret;
	int		idx;
	int		i;
	int		WordCnt;
	char	work[16];
	char	work1[8];
	char	*b_number[4]={"00","01","02","03"};
	if(gDeviceCntWord == 0){
		return(0);
	}
	ret= 0;
	WordCnt= gDeviceCntWord;
	/*sprintf(work,"uR0000%02X",WordCnt);*/
	B_gstrcpy(&work[1],"uR");
	B_gstrcat(&work[1],b_number[mode]);
	B_gstrcat(&work[1],"00");
	B_Bin2Hex(WordCnt,2,work1);
	B_gstrcat(&work[1],work1);
	ret= SendRecPLCWithBCC(2,work,PlcSendDevData,&idx,0);
	if(ret == OK){
/*		if(B_gstrncmp((char *)PlcSendDevData,"\x06u",2) != 0){*/
		if(PlcSendDevData[0] != 0x06){
			ret= -1;
		}
		if(ret == 0){
			for(i = 0; i < gDeviceCntWord; i++){
#ifdef SH_CPU				
				*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 2]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 4]);
#endif
#ifdef ARM_CPU
#ifdef	WIN32
				*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 2]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 4]);
#else
				*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 4]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 2]);
#endif
#endif
			}
		}
	}
	return(ret);
}

int		RecGroupPLCDev(int PlcType)
{
	int		i;
	int		ret;
	
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].SameDevInf == 4){
			DeviceDataSys[i].SameDevInf= 0;
		}
	}
	i=0;
	while(1){
		SetGroupDevPLC();
		if(gDeviceCntWord == 0){
			break;
		}
		ret= ReadGroupPLCDev(i);
		if(ret != 0){
			break;
		}
		i++;
	}
	return(ret);
}
/************************************/
/*	�X��?��?�hfor FX		          */
/************************************/
/************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;

	B_SendPLCPCData();
/* ksc20050311 */	
	/*B_SendThruePLC(*OutCnt,OutBuff);*/

}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
#endif

/* PLCTYPE_CH1������ ����ϴ� �Լ� �� */
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH2������ ����ϴ� �Լ� ���� */ 

#ifdef	PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(1);
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif

#include	"hook_aplplc.h"
/****************************** END **********************/
