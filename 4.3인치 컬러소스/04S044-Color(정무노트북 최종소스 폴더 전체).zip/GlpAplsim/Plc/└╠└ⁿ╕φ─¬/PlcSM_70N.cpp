/****************************************************************/
/*	Version 1.4M - 2005.04.21. 08:59                	*/
/*	Version 1.5M - 2005.12.01. 15:00 - monitor �߰�  	*/
/*****************************************************************************************/
/*	Samsung N70				*/
/*	2005.12.01				*/	
/************************************************/
/*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		  */
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
/*	2006.09.25 		*/
/*      �����͹� ���ø� ������ ���� ver 2.6�� �ϰ� ����	  */
/*  2007.01.30 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����		*/	  
/*  2007.10.08 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����		*/	  
/*****************************************************************************************/

/**********************************************************/
/*	2006.05.09 NEW GP									*/
/**********************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include	"hook_plcapl.h"

/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V4.0M"
/*****************************************************************************************/


/*#define	LOG	1*/

#define	MAX_RTY_COUNT	2

#define	MAX_WORDCNT			16
#define	MAX_MON_BITCNT_PKG	20
#define	MAX_MON_BITCNT		80
#define	MAX_MON_WORDCNT		16
#define	MAX_PBITCNT			16
#define	MAX_PWORDCNT		10
#define	MAX_WORD_CONT_CNT	4
#define	MAX_BIT_CONT_CNT	4

#define	MAX_BIT_CNT			8

#ifdef	LOG
int		logCnt;
char	SendReclog[1024];
#endif

/**************************************/
#ifdef	SH_CPU
/**************************************/
static	int	GppPcThruWCnt;		/* PC MOnitor Word Device Count */ 
static	int	GppPcThruBCnt;		/* PC MOnitor Bit Device Count */
static	int	GroopSema;			/* Grooping Semafo */
static	int	GroopingFlag;		/* Grooping ON */
static	char	PLC_Kyoku[2];	/* �o�k�b�ǔ� */

static	int		PcThru1014;					/* PC��GroupMonitor�t���b�O */
static	int		PcThru1014Rec;				/* E00179 ��M�t���b�O */
static	int		PcThruWCnt;
static	int		PcThruBCnt;
static	int		PcThruAllCnt;
static	int		PcThruByteCnt;
static	int		PcThruByteCnt179;
static	int		PcThruByteCntStr;
static	int		PcThruByteCnt1SW;
static	int		PcThruByteCnt1SB;
#endif
/********************************/
/*	FX Serease		*/
/********************************/
#ifdef	ARM_CPU
static	const	PLC_CONST	CommTbl[16]={
	{"RCS",1},		/*0 X,Y,R,L,T,C */
	{"WCS",1},		/*1 X,Y,R,L,T,C */
	{"RCP",1},		/*2 X,Y,R,L,T,C */
	{"WCP",1},		/*3 X,Y,R,L,T,C */
	{"RCC",1},		/*4 X,Y,R,L,T,C */
	{"WCC",1},		/*5 Y,R,L */
	{"RD",1},		/*6 DT,FL,Ld,I */
	{"WD",1},		/*7 DT,FL,Ld,I */
	{"RS",1},		/*8 S(TC) */
	{"WS",1},		/*9 S(TC) */
	{"RK",1},		/*10 K(TC) */
	{"WK",1},		/*11 K(TC) */
	{"MC",1},		/*12 Bit Monitor Entry */
	{"MD",1},		/*13 Word Monitor Entry */
	{"MG",1},		/*14 Monitor Read */
};
#endif
#ifdef	SH_CPU
static	const char	*CommTbl[16]={
		"RCS",		/*0 X,Y,R,L,T,C */
		"WCS",		/*1 X,Y,R,L,T,C */
		"RCP",		/*2 X,Y,R,L,T,C */
		"WCP",		/*3 X,Y,R,L,T,C */
		"RCC",		/*4 X,Y,R,L,T,C */
		"WCC",		/*5 Y,R,L */
		"RD",		/*6 DT,FL,Ld,I */
		"WD",		/*7 DT,FL,Ld,I */
		"RS",		/*8 S(TC) */
		"WS",		/*9 S(TC) */
		"RK",		/*10 K(TC) */
		"WK",		/*11 K(TC) */
		"MC",		/*12 Bit Monitor Entry */
		"MD",		/*13 Word Monitor Entry */
		"MG",		/*14 Monitor Read */
};
#endif
static	const	DEV_TBL bPLCDeviceTbl[16] = {
	{"X" ,0x0000,1},
	{"Y" ,0x0000,1},
	{"R" ,0x0000,1},
	{"L" ,0x0000,1},
	{"T" ,0x0000,2},
	{"C" ,0x0000,2},
	{"GB",     0,9},
};
static	const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"WX",0x0000,1},		/* X */
	{"WY",0x0000,1},		/* Y */
	{"WR",0x0000,1},		/* R */
	{"WL",0x0000,1},		/* L */
	{"SV",0x0000,2},		/* S */
	{"EV",0x0000,3},		/* K */
	{"FL",0x0000,4},		/* F */
	{"LD",0x0000,5},		/* L */
	{"DT",0x0000,6},		/* D */
	{"IX",0x0000,7},		/* IX */
	{"IY",0x0000,7},		/* IY */
	{"ID",0x0000,7},		/* ID */
	{"GD",     0,9},
};
#ifdef	SH_CPU
static const int	bitTable[8]={
	0x0001,0x0002,0x0004,0x0008,0x0010,0x0020,0x0040,0x0080
};
#endif
#ifdef	ARM_CPU
static	const	PLC_INT_CONST	bitTable[8]={
	{0x0001,1},
	{0x0002,1},
	{0x0004,1},
	{0x0008,1},
	{0x0010,1},
	{0x0020,1},
	{0x0040,1},
	{0x0080,1},
};
#endif
#ifdef	SH_CPU
static	const	iAndData[16]={
	0x0001,0x0002,0x0004,0x0008,0x0010,0x0020,0x0040,0x0080,
	0x0100,0x0200,0x0400,0x0800,0x1000,0x2000,0x4000,0x8000,
};
#endif
#ifdef	ARM_CPU
static	const PLC_INT_CONST	iAndData[16]={
	{0x0001,1},
	{0x0002,1},
	{0x0004,1},
	{0x0008,1},
	{0x0010,1},
	{0x0020,1},
	{0x0040,1},
	{0x0080,1},
	{0x0100,1},
	{0x0200,1},
	{0x0400,1},
	{0x0800,1},
	{0x1000,1},
	{0x2000,1},
	{0x4000,1},
	{0x8000,1},	
};

#endif
#ifdef	SH_CPU
#define	MAX_COMMAND	5
static const char	*FPComm[MAX_COMMAND]={
	"MC",
	"MD",
	"MG",
	"01",
	"EX",
};
#endif
#ifdef	ARM_CPU
#define	MAX_COMMAND	5
static	const	PLC_CONST	FPComm[MAX_COMMAND]={
	{"MC",1},
	{"MD",1},
	{"MG",1},
	{"01",1},
	{"EX",1},
};
#endif

/************************************/
/* ��M�v���g�R��					*/
/************************************/
/****************************************************/
static	void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	if(data < 0){			/* - check 041116 */
		
		data *= -1;
		buff[0]= '-';
		for(i= 1; i < cnt+1; i++){								/*cnt+1�̵� ������ */
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}else{
		for(i= 0; i < cnt; i++){
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}
	buff[i]= 0;
}
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef	PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif	
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));	
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= PLC_SPEED;
	*DataBit= RS_DATA8;
	*Parity= RS_ODD;
}
/**************************************************/
static	void	GetGroopSema(void)
{
	if(GroopSema == 0){		/* Grooping Sema */
	}else{
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
			B_Delay(10);
		}
	}
	GroopSema++;
}
static	void	SetGroopSema(void)
{
	GroopSema= 0;
}

/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(*CommMode){
	case 0:				/*  */
		if(data == 0x25){		/* % */
			*RecCnt= 0;			/* ?���X??�g */
			RecBuff[(*RecCnt)++] = data;
			*CommMode = 1;
		}
		break;
	case 1:				/* Data Recieve */
		if(*RecCnt < 1024){
			RecBuff[(*RecCnt)++] = data;
		}
		if(data == 0x0d){		/* CR */
			*CommMode = 0;
			ret= 0;
		}
		break;
	}
	return(ret);
}



/************************************/
/* ���M�v���g�R��					*/
/************************************/
/****************************/
/* Make Check SUM For PLC	*/
/****************************/

static	int SetPLCBCC(char *buff,int cnt)
{
	int		i;
	unsigned int sum;
	char	work[2];

	sum= 0;
	for(i = 0; i < cnt; i++){
/*		OutBuf[i] = buff[i];*/
		sum = sum ^ buff[i];
	}
	B_Bin2Hex(sum,2,work);
	buff[cnt] = work[0];
	buff[cnt+1] = work[1];
	buff[cnt+2] = 0x0d;
	return(cnt + 3);
}


/************************************/
/*	PLC Send						*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *RecData,int *Cnt,int rmode)
{
	int		ret;
	int		i;
	unsigned int  sum;
	unsigned int  sum1;
	int		rty_cnt;
	int	SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,*Cnt);
#ifdef	LOG
	SendCnt= *Cnt;
	for(i= 0; i < SendCnt; i++){
		SendReclog[logCnt]= combuf[i];
		logCnt= (logCnt+1) % 1024;
	}
#endif
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
/*		ret= B_SendRecPLC(mode,rData,Cnt,rmode);*/
		ret= C_SendRecPLC(mode,RecData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		if(ret == 0){
			sum = 0;
			for(i = 0; i < *Cnt-3; i++){
				sum= sum ^ RecData[i];
			}
			sum1= B_Hex2Bin((char *)&RecData[i]);
			if(sum != sum1){
				ret= -1;
			}
		}
		if(ret == OK){
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}
#ifdef	LOG
	SendReclog[logCnt]= ret;
	logCnt= (logCnt+1) % 1024;
#endif
	return(ret);
}
static	int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *RecData,int *Cnt,int rmode)
{
	int		ret;
	int		i;
	unsigned int  sum;
	unsigned int  sum1;
	int	SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,*Cnt);

/*	ret= B_SendRecPLC(mode,rData,Cnt,rmode);*/
	ret= C_SendRecPLC(mode,RecData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	if(ret == 0){
		sum = 0;
		for(i = 0; i < *Cnt-3; i++){
			sum= sum ^ RecData[i];
		}
		sum1= B_Hex2Bin((char *)&RecData[i]);
		if(sum != sum1){
			ret= -1;
		}
	}
	return(ret);
}
static	void	PlcBuffClear(void)
{
	PcThru1014= 0;
	PcThru1014Rec= 0;
	PcThruWCnt= 0;
	PcThruBCnt= 0;
	PcThruAllCnt= 0;
	PcThruByteCnt= 0;
	PcThruByteCnt179= 0;
	PcThruByteCntStr= 0;
	PcThruByteCnt1SW= 0;
	PcThruByteCnt1SB= 0;
#ifdef	LOG
	logCnt= 0;
#endif
}
/********************************************/
/*	Connection Proc							*/
/*	*PlcType:[0]->PlcType					*/
/*	         [1]->MyStation					*/
/*	         [2]->DstStation				*/
/********************************************/


static	int	C_Connection( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;
	char	buff[10];
#ifndef	WIN32
	int		Speed;
	int		DataBit;
	int		Parity;
#endif
#ifdef	LOG
	logCnt= 0;
#endif

	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */
#ifdef	WIN32
			SioPCMode= 2;
			SioPCOpenFlag= 1;
#else
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PC,RS_INIT,RS_38400,RS_DATA8,RS_NONE); */
#endif
		}else{						/* RS-422 */
#ifdef	WIN32
			SioPLCMode= 2;
			SioPLCOpenFlag= 1;
#else
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE); */
#endif
		}
#ifdef	WIN32
		while(1){
			if(SioPLCOpenFlag == 0){
				break;
			}
			B_Delay(10);
		}
#endif
		B_Delay(100);
	}
	/* PLC Connect Check */
	MyStationNo= PlcType[1];
	DstStationNo= PlcType[2];
	B_gmemset((char *)buff, 0, sizeof(buff));
	buff[0]= '%';			/*  */
	buff[1]= 'E';			/* S-H */
	buff[2]= 'E';			/* S-L */
	buff[3]= '#';			/* Command */
	buff[4]= 'R';			/* Command */
	buff[5]= 'T';			/* Command */

	Cnt= B_gstrlen((char *)buff);
	ret= SendRecPLCWithBCCCont(2,(char *)buff,PlcRecBuff,&Cnt,0);
	if((ret == 0) && (PlcRecBuff[3] == 0x24)){	/* $ */
		ret= 1;
		/* �ǔԂ�ۑ����� */
		B_gmemcpy(PLC_Kyoku,(char *)&PlcRecBuff[1],2);
	}else{
		ret= 0;
	}
	/* ���j??�p�ɏ��������� */
	GppPcThruWCnt= 0;		/* PC MOnitor Word Device Count */ 
	GppPcThruBCnt= 0;		/* PC MOnitor Bit Device Count */
	PlcBuffClear();
	GroopSema= 0;		/* Grooping Sema */
	GroopingFlag= 0;	/* Grooping ON */
	PcThru1014= 0;
	return(ret);
}
/******************************************/
static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif

#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif
}
/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/************************************/
/*	Device & Address Change			*/
/************************************/
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, char *Device)
{
	int		i;
	int		ret;

	ret = -1;
	/* Device Name */
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrcmp(bPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					break;
				}
			}
			if(DeviceFlag > 0){
/*				*DevAddr = OffSet+ Address;*/
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrcmp(wPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= wPLCDeviceTbl[i].flag;
					break;
				}
			}
			if(DeviceFlag > 0){
/*				*DevAddr = OffSet+ Address;*/
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
static	unsigned int	Bin2Bcd(int data)
{
	int		i;
	unsigned int	ret;

	ret= 0;
	for(i= 0; i < 8; i++){
		ret |= (data % 10) << (i*4);
		data = data / 10;
		if(data == 0){
			break;
		}
	}
	return(ret);
}
static	unsigned int	BcdAddBcd(unsigned int data1,unsigned int data2)
{
	int		i;
	int				flag;
	unsigned int	ret;
	unsigned int	work;

	ret= 0;
	flag= 0;
	for(i= 0; i < 8; i++){
		work= (data1 & 0x0f) + (data2 & 0x0f) + flag;
		flag= work / 10;
		ret |= (work % 10) << (i * 4);
		data1 = data1 >> 4;
		data2 = data2 >> 4;
		if((data1 == 0) && (data2 == 0)){
			if(flag != 0){
				ret |= 1 << ((i+1) * 4);
			}
			break;
		}
	}
	return(ret);
}
static	unsigned int	Bcd2Asc(int data,int keta,char *buff)
{
	int		i;
	unsigned int	ret;

	ret= 0;
	for(i= 0; i < keta; i++){
		buff[keta- i- 1]= (data & 0x0f) + '0';
		data = data >> 4;
	}
	buff[keta]= 0;
	return(ret);
}
/************************************/
/*	Device & Address Change			*/
/************************************/
static	int	plcGetDevAddInf(int bwflag,unsigned char *src,int *Keta,int *LowMax)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bwflag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			*Keta= ByteTbl[PLCIndex[src[0]]].LowKeta;
			*LowMax= ByteTbl[PLCIndex[src[0]]].LowDeviceMax;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			*Keta= WordTbl[PLCIndex[src[0]]].LowKeta;
			*LowMax= WordTbl[PLCIndex[src[0]]].LowDeviceMax;
			ret= 0;
		}
	}
	return(ret);
}
static	void	plcChangeAddressUsr(int Digit1,int Digit0, int *Address,int LowMax,int Keta)
{
	int		i;
	unsigned int	work;
	unsigned int	work1;
	unsigned int	work2;

	work= (unsigned int)*Address;
	work1= work%LowMax;				/* 1Keta */
	work2= 0;
	for(i = 0;i < Keta; i++){
		work2 += (work1 % Digit0) << (i*4);
		work1= work1/Digit0;
	}
	work= work/LowMax;
	for(;i < 8; i++){
		if(work == 0){
			break;
		}
		work2 += (work % Digit1) << (i*4);
		work= work/Digit1;
	}
	*Address= work2;
}
/*********************************************************************/
static	int	plcSetPLCUsrAddr(int DevInfo,int Address,unsigned char idx,int bFlag)
{
	int		ret;
	int		LowMax;
	int		Keta;

	ret= plcGetDevAddInf(bFlag,&idx,&Keta,&LowMax);
	if(ret == 0){
		LowMax++;
		ret= Address;
		switch(DevInfo & 0x0f){
		case 0:		/* 8/8 */
			plcChangeAddressUsr(8,8,&ret,LowMax,Keta);
			break;
		case 1:		/* 8/10 */
			plcChangeAddressUsr(8,10,&ret,LowMax,Keta);
			break;
		case 2:		/* 8/16 */
			plcChangeAddressUsr(8,16,&ret,LowMax,Keta);
			break;
		case 3:		/* 10/8 */
			plcChangeAddressUsr(10,8,&ret,LowMax,Keta);
			break;
		case 4:		/* 10/10 */
			plcChangeAddressUsr(10,10,&ret,LowMax,Keta);
			break;
		case 5:		/* 10/16 */
			plcChangeAddressUsr(10,16,&ret,LowMax,Keta);
			break;
		case 6:		/* 16/8 */
			plcChangeAddressUsr(16,8,&ret,LowMax,Keta);
			break;
		case 7:		/* 16/10 */
			plcChangeAddressUsr(16,10,&ret,LowMax,Keta);
			break;
		case 8:		/* 16/16 */
/*			ChangeAddressUsr(16,16,&ret,LowMax,Keta);*/
			break;
		case 9:		/* 16 */
			plcChangeAddressUsr(10,10,&ret,10,1);
			break;
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int		DevAddr;
	int		work;
	char	Device[4];
	char	buff[8];
	int		BinAddress;
	int		DevInfo;

	BinAddress= Address;
	ret= C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&DevInfo);
	Address= plcSetPLCUsrAddr(DevInfo,Address,*pDevice,mode);
	ret= MakePLCDevAddress(mode, pDevice, Address, Device);
	if(ret == 0){
		DstStationNo= pDevice[4];
		combuff[0]= '%';		/* Start */
		combuff[1]= 'E';		/* SA */
		combuff[2]= 'E';		/* SA */
		combuff[3]= '#';		/* Command */
		combuff[4]= 0;
		if(mode == 0){			/* Bit */
			if(sCnt == 1){
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[0]);	/* RCS */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[0].strData);	/* RCS */
#endif
				B_gstrcat(combuff,Device);		/* Device Name */
				if(DeviceFlag == 1){
					Bcd2Asc(Address/16,3,buff);
					B_gstrcat(combuff,buff);
					work= Address % 16;
					B_Bin2Hex(work,1,buff);
					B_gstrcat(combuff,buff);
				}else{			/* T,C */
					Bcd2Asc(Address,4,buff);
					B_gstrcat(combuff,buff);
				}
			}else{
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[4]);	/* RCC */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[4].strData);	/* RCC */
#endif
				B_gstrcat(combuff,Device);		/* Device Name */
				if(DeviceFlag == 1){
					Address = Address >> 4;
				}
				Bcd2Asc(Address,4,buff);
				B_gstrcat(combuff,buff);

				BinAddress += sCnt- 1;
				Address= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				if(DeviceFlag == 1){
					Address = Address >> 4;
				}
				Bcd2Asc(Address,4,buff);
				B_gstrcat(combuff,buff);
			}
		}else{
/*Address= Address << 4;*/
			switch(DeviceFlag){
			case 1:					/* WX,WY,WR,WL */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[4]);	/* RCC */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[4].strData);	/* RCC */
#endif
				B_gstrcat(combuff,&Device[1]);		/* Device Name */
				Bcd2Asc(Address,4,buff);
				B_gstrcat(combuff,buff);
				BinAddress += sCnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,4,buff);
				B_gstrcat(combuff,buff);
				break;
			case 2:					/* SV */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[8]);	/* RS */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[8].strData);	/* RS */
#endif
				Bcd2Asc(Address,4,buff);
				B_gstrcat(combuff,buff);
				BinAddress += sCnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,4,buff);
				B_gstrcat(combuff,buff);
				break;
			case 3:					/* EV */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[10]);	/* RK */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[10].strData);	/* RK */
#endif
				Bcd2Asc(Address,4,buff);
				B_gstrcat(combuff,buff);
				BinAddress += sCnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,4,buff);
				B_gstrcat(combuff,buff);
				break;
			case 4:					/* F(FL) */
			case 5:					/* L(LD) */
			case 6:					/* D(DT) */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[6]);	/* RD */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[6].strData);	/* RD */
#endif
				combuff[6]= Device[0];		/* Device Name */
				combuff[7]= 0;
				Bcd2Asc(Address,5,buff);
				B_gstrcat(combuff,buff);
				BinAddress += sCnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,5,buff);
				B_gstrcat(combuff,buff);
				break;
			case 7:					/* IX,IY,ID */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[6]);	/* RD */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[6].strData);	/* RD */
#endif
				B_gstrcat(combuff,Device);		/* Device Name */
				B_gstrcat(combuff,"000000000");
				break;
			}

		}
	}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
static	int	BitReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j,k;
	int		Cnt;
	int		wCnt;
	unsigned char	*SaveAddr;
	unsigned short	rdata;

	/* MakePLCReadData()�Ō��ǂ� */
	ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext);
	if(ret != 0){			ret= -1;	return(ret);	}
	Cnt = mp->mext;
	SaveAddr = (unsigned char *)mp->mptr;
	i= B_gstrlen((char *)PlcSendBuff);
	ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0);
	if((ret != 0) || (rDataFx[3] != 0x24)){		ret= -1;	return(ret);	}
	if(Cnt == 1){
		if(rDataFx[6] == '1'){	*(unsigned char *)SaveAddr++ = 1;	}
		else{						*(unsigned char *)SaveAddr++ = 0;	}
	}else{		/* RCC */
		if(DeviceFlag == 1){	ret= mp->mpar & 0x000f;		}
		else{					ret= mp->mpar;				}
		wCnt= (Cnt+ret-1) / 16 + 1;
#ifdef	SH_CPU
		BitAndData= iAndData[ret];
#endif
#ifdef	ARM_CPU
		BitAndData= iAndData[ret].strData;
#endif		
		for(i= 0,j= 0; i < wCnt; i++){
			rdata = B_LHexAsToBin((char *)&rDataFx[i*4+6],2);
			rdata += B_LHexAsToBin((char *)&rDataFx[i*4+6+2],2) << 8;
			for(k= 0;(j < Cnt) & (k < 16); j++, k++){
				if(rdata & BitAndData){	*(unsigned char *)SaveAddr++ = 1;	}
				else{					*(unsigned char *)SaveAddr++ = 0;	}
				BitAndData = BitAndData << 1;
				if(BitAndData == 0x10000){
					BitAndData= 0x0001;
					break;
				}
			}
		}
		ret= 0;
	}
	return(ret);
}
static	int	WordReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt,dCnt;
	unsigned char	*SaveAddr;
	int		Address;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_WORDCNT){	dCnt -= MAX_WORDCNT;	mp->mext= MAX_WORDCNT;	}
		else{					mp->mext= dCnt;			dCnt = 0;				}
		ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext);
		if(ret != 0){	ret= -1;	break;		}
		Cnt = mp->mext;
		SaveAddr = (unsigned char *)mp->mptr;
		i= B_gstrlen((char *)PlcSendBuff);
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0);
		if((ret != 0) || (rDataFx[3] != 0x24)){	ret= -1;	break;	}
		for(i = 0; i < Cnt; i++){
#ifdef	SH_CPU
			*(unsigned char *)SaveAddr++ = B_Hex2Bin((char *)&rDataFx[i*4+6]);
			*(unsigned char *)SaveAddr++ = B_Hex2Bin((char *)&rDataFx[i*4+8]);
#endif
#ifdef	ARM_CPU
			*(unsigned char *)SaveAddr++ = B_Hex2Bin((char *)&rDataFx[i*4+8]);
			*(unsigned char *)SaveAddr++ = B_Hex2Bin((char *)&rDataFx[i*4+6]);
#endif
		}
		if(dCnt == 0){			break;			}
		Address += MAX_WORDCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
	}
	return(ret);
}
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;

	ret= 0;
	/* For Program Download */
	if(PcThru1014 != 0){
		return(0);
	}

	switch(mp->mpec){
	case PLC_BIT:		ret= BitReadProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordReadProc(mp,rDataFx,PlcType);		break;
	}
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	int		work;
	int		DevAddr;
	char	Device[4];
	char	buff[8];
	int		BinAddress;
	int		DevInfo;

	BinAddress= Address;
	ret= C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&DevInfo);
	Address= plcSetPLCUsrAddr(DevInfo,Address,*pDevice,mode);
	ret= MakePLCDevAddress(mode, pDevice, Address, Device);
	if(ret == 0){
		DstStationNo= pDevice[4];
		combuff[0]= '%';		/* Start */
		combuff[1]= 'E';		/* SA */
		combuff[2]= 'E';		/* SA */
		combuff[3]= '#';		/* Command */
		combuff[4]= 0;
		if(mode == 0){		/* BIT */
			if(Cnt == 1){
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[1]);	/* WCS */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[1].strData);	/* WCS */
#endif
				B_gstrcat(combuff,Device);		/* Device Name */
				Bcd2Asc(Address/16,3,buff);
				B_gstrcat(combuff,buff);
				work= Address % 16;
				B_Bin2Hex(work,1,buff);
				B_gstrcat(combuff,buff);
				if(data[0] == 0){
					B_gstrcat(combuff,"0");
				}else{
					B_gstrcat(combuff,"1");
				}
			}else{
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[3]);	/* WCP */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[3].strData);	/* WCS */
#endif
				Bcd2Asc(Cnt,1,buff);
				B_gstrcat(combuff,buff);	/* ������ */
				for(i= 0; i < Cnt; i++){
					Address= plcSetPLCUsrAddr(DevInfo,BinAddress++,*pDevice,mode);
					B_gstrcat(combuff,Device);		/* Device Name */
					Bcd2Asc(Address/16,3,buff);
					B_gstrcat(combuff,buff);
					work= Address % 16;
					B_Bin2Hex(work,1,buff);
					B_gstrcat(combuff,buff);
					if(data[i] == 0){
						B_gstrcat(combuff,"0");
					}else{
						B_gstrcat(combuff,"1");
					}
				}
			}
		}else{		/* WORD */
			switch(DeviceFlag){
			case 1:					/* WX,WY,WR,WL */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[5]);	/* WCC */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[5].strData);	/* WCC */
#endif
				B_gstrcat(combuff,&Device[1]);		/* Device Name */
				Bcd2Asc(Address,4,buff);
				B_gstrcat(combuff,buff);
				BinAddress += Cnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,4,buff);
				B_gstrcat(combuff,buff);
				break;
			case 2:					/* SV */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[9]);	/* WS */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[9].strData);	/* WS */
#endif
				Bcd2Asc(Address,4,buff);
				B_gstrcat(combuff,buff);
				BinAddress += Cnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,4,buff);
				B_gstrcat(combuff,buff);
				break;
			case 3:					/* EV */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[11]);	/* WK */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[11].strData);	/* WK */
#endif
				Bcd2Asc(Address,4,buff);
				B_gstrcat(combuff,buff);
				BinAddress += Cnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,4,buff);
				B_gstrcat(combuff,buff);
				break;
			case 4:					/* F(FL) */
			case 5:					/* L(Ld) */
			case 6:					/* D(DT) */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[7]);	/* WD */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[7].strData);	/* WD */
#endif
				combuff[6]= Device[0];		/* Device Name */
				combuff[7]= 0;
				Bcd2Asc(Address,5,buff);
				B_gstrcat(combuff,buff);
				BinAddress += Cnt- 1;
				DevAddr= plcSetPLCUsrAddr(DevInfo,BinAddress,(unsigned char)pDevice[0],mode);
				Bcd2Asc(DevAddr,5,buff);
				B_gstrcat(combuff,buff);
				break;
			case 7:					/* IX,IY,ID */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[7]);	/* WD */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[7].strData);	/* WD */
#endif
				B_gstrcat(combuff,Device);		/* Device Name */
				B_gstrcat(combuff,"000000000");
				break;
			}
#ifdef	SH_CPU
			for(i= 0; i < Cnt*2; i++){
				B_Bin2Hex(data[i],2,buff);
				B_gstrcat(combuff,buff);
			}
#endif
#ifdef	ARM_CPU
			for(i= 0; i < Cnt; i++){
				B_Bin2Hex(data[i*2+1],2,buff);
				B_gstrcat(combuff,buff);
				B_Bin2Hex(data[i*2],2,buff);
				B_gstrcat(combuff,buff);
			}
#endif
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
static	int	BitWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;
	int		Address;
	int		DevCnt;
	char	*DataAddr;

	Address= mp->mpar;
	DataAddr= (char *)mp->mptr;
	while(1){
		if(mp->mext > MAX_BIT_CNT){	DevCnt= MAX_BIT_CNT;	mp->mext-= MAX_BIT_CNT;	}
		else{						DevCnt= mp->mext;		mp->mext= 0;			}
		ret = MakePLCWriteData(0,(char *)mp->mbuf,Address,DevCnt,(char *)PlcSendBuff,DataAddr);
		if(ret != 0){		ret= -1;	break;		}
		Cnt= B_gstrlen((char *)PlcSendBuff);
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0);
		if(ret != 0){		ret= -1;	break;		}
		if(mp->mext == 0){				break;		}
		Address += MAX_BIT_CNT;
		DataAddr += MAX_BIT_CNT;
	}
	return(ret);
}
static	int	WordWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,dCnt;
	int		Address;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(dCnt > MAX_WORDCNT){	dCnt -= MAX_WORDCNT;	mp->mext= MAX_WORDCNT;	}
		else{					mp->mext= dCnt;			dCnt = 0;				}
		ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PlcSendBuff,(char *)mp->mptr);
		if(ret != 0){		ret= -1;	break;		}
		Cnt= B_gstrlen((char *)PlcSendBuff);
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0);
		if(ret != 0){		ret= -1;	break;		}
		if(dCnt == 0){					break;		}
		Address += MAX_WORDCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
	}
	return(ret);
}
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;

	ret= 0;
	/* For Program Download */
	if(PcThru1014 != 0){
		return(0);
	}

	switch(mp->mpec){
	case PLC_BIT:		ret= BitWriteProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordWriteProc(mp,rDataFx,PlcType);		break;
	}
	return(ret);
}
static	int	C_GetSendRecTime(void)
{
	/* ���j??�p�ɏ��������� */
	GppPcThruWCnt= 0;		/* PC MOnitor Word Device Count */ 
	GppPcThruBCnt= 0;		/* PC MOnitor Bit Device Count */
	PlcBuffClear();
	GroopSema= 0;		/* Grooping Sema */
	GroopingFlag= 0;	/* Grooping ON */
	PcThru1014= 0;
	return(0);				/* 0ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}

/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret;

	ret = -1;
	switch(*CommMode){			/* CommMode=0:Normal,1->3:Editor,4->PLC */
	case 0:		/* Normal DA */
		if(data == 0x25){		/* % */
			*CommMode = 4;
			*RecCnt = 0;
			RecBuff[(*RecCnt)++] = data;
		}
		break;
	case 4:				/* Data Rec */
		if(*RecCnt < 1024){
			RecBuff[(*RecCnt)++] = data;
		}
		if(data == 0x0d){
			*CommMode = 99;
			ret= 0;
		}
		break;
	}
	return(ret);
}

/************************************************/
/*	�O��?�v����								*/
/************************************************/
int	MakePLCGroupAddr(int mode, int First, char *pDevice, int Address, char *combuff)
{
	int		ret;
	int		work;
	char	Device[4];
	char	buff[8];
	int		DevInfo;

	ret= C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&DevInfo);
	if(ret != 0){
		return(ret);
	}
	Address= plcSetPLCUsrAddr(DevInfo,Address,*pDevice,mode);
	ret= MakePLCDevAddress(mode, pDevice, Address, Device);
	if(ret == 0){
		if(First == 0){
			DstStationNo= pDevice[4];
			combuff[0]= '%';		/* Start */
			combuff[1]= 'E';		/* SA */
			combuff[2]= 'E';		/* SA */
			combuff[3]= '#';		/* Command */
			combuff[4]= 0;
#ifdef	SH_CPU
			if(mode == 0){		/* BIT */
				B_gstrcat(combuff,CommTbl[12]);	/* MC */
			}else{
				B_gstrcat(combuff,CommTbl[13]);	/* MD */
			}
#endif
#ifdef	ARM_CPU
			if(mode == 0){		/* BIT */
				B_gstrcat(combuff,CommTbl[12].strData);	/* MC */
			}else{
				B_gstrcat(combuff,CommTbl[13].strData);	/* MD */
			}
#endif
		}
		if(mode == 0){		/* BIT */
			B_gstrcat(combuff,Device);		/* Device Name */
			if(DeviceFlag == 1){
				Bcd2Asc(Address/16,3,buff);
				B_gstrcat(combuff,buff);
				work= Address % 16;
				B_Bin2Hex(work,1,buff);
				B_gstrcat(combuff,buff);
			}else{			/* T,C */
				Bcd2Asc(Address,4,buff);
				B_gstrcat(combuff,buff);
			}
		}else{		/* WORD */
			switch(DeviceFlag){
			case 1:					/* WX,WY,WR,WL */
				B_gstrcat(combuff,&Device[0]);		/* Device Name */
				Bcd2Asc(Address,4,buff);
				B_gstrcat(combuff,buff);
				break;
			case 2:					/* SV */
				B_gstrcat(combuff,"S");	/* WS */
				Bcd2Asc(Address,5,buff);
				B_gstrcat(combuff,buff);
				break;
			case 3:					/* EV */
				B_gstrcat(combuff,"K");	/* WK */
				Bcd2Asc(Address,5,buff);
				B_gstrcat(combuff,buff);
				break;
			case 4:					/* F(FL) */
			case 5:					/* L(Ld) */
			case 6:					/* D(DT) */
				Device[0]= Device[0];		/* Device Name */
				Device[1]= 0;
				B_gstrcat(combuff,Device);
				Bcd2Asc(Address,5,buff);
				B_gstrcat(combuff,buff);
				break;
			case 7:					/* IX,IY,ID */
				B_gstrcat(combuff,&Device[0]);		/* Device Name */
				B_gstrcat(combuff,"0000");
				break;
			}
		}
	}
	return(ret);
}
/****************************************/
/*	Monitor Reset�쐬					*/
/****************************************/
void	RestMonitor(void)
{
	int		Cnt;

	PlcSendBuff[0]= '%';		/* Start */
	PlcSendBuff[1]= 'E';		/* SA */
	PlcSendBuff[2]= 'E';		/* SA */
	PlcSendBuff[3]= '#';		/* Command */
	PlcSendBuff[4]= 'M';
	PlcSendBuff[5]= 'C';
	PlcSendBuff[6]= 'F';
	PlcSendBuff[7]= 'F';
	PlcSendBuff[8]= 'F';
	PlcSendBuff[9]= 'F';
	PlcSendBuff[10]= 'F';
	PlcSendBuff[11]= 0;
	PlcSendBuff[12]= 0;
	Cnt= 11;
	SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)PlcRecBuff,&Cnt,0);
	PlcSendBuff[0]= '%';		/* Start */
	PlcSendBuff[1]= 'E';		/* SA */
	PlcSendBuff[2]= 'E';		/* SA */
	PlcSendBuff[3]= '#';		/* Command */
	PlcSendBuff[4]= 'M';
	PlcSendBuff[5]= 'D';
	PlcSendBuff[6]= 'F';
	PlcSendBuff[7]= 'F';
	PlcSendBuff[8]= 'F';
	PlcSendBuff[9]= 'F';
	PlcSendBuff[10]= 'F';
	PlcSendBuff[11]= 'F';
	PlcSendBuff[12]= 0;
	Cnt= 12;
	SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)PlcRecBuff,&Cnt,0);

}
void	ClearMonDevice(void)
{
	int		i;

	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].SameDevInf == -1){
			DeviceDataSys[i].SameDevInf= 0;
		}
	}
	gDeviceCnt= 0;
	gDeviceCntBit= 0;
	gDeviceCntWord= 0;
	RestMonitor();
}
/****************************************/
/*	Bit Monitor�쐬						*/
/****************************************/
void	MakeBitMonitor(void)
{
	int		i,ret;
	int		StartIdx;
	int		cnt;
	int		idx;

	StartIdx= 0;
	ret= OK;
	/*Bit Device Set*/
	B_gmemset((char *)PlcSendBuff,0,sizeof(PlcSendBuff));
	/* ���j??�r�b�g������ΐ�ɑ��� */
	if(PcThruBCnt > 0){
		PlcSendBuff[0]= '%';		/* Start */
		PlcSendBuff[1]= 'E';		/* SA */
		PlcSendBuff[2]= 'E';		/* SA */
		PlcSendBuff[3]= '#';		/* Command */
		PlcSendBuff[4]= 'M';		/* Command */
		PlcSendBuff[5]= 'C';		/* Command */
		idx= 0;
		for(i = 0; i < PcThruBCnt; i+= MAX_MON_BITCNT_PKG){
			cnt= PcThruBCnt- i;
			if(cnt < MAX_MON_BITCNT_PKG){
				StartIdx= cnt;
				B_gmemcpy((char *)&PlcSendBuff[6],(char *)&PcThruBData[idx*5],cnt*5);
				break;
			}else{
				B_gmemcpy((char *)&PlcSendBuff[6],(char *)&PcThruBData[idx*5],MAX_MON_BITCNT_PKG*5);
				StartIdx= B_gstrlen((char *)PlcSendBuff);
				ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0);
				if(ret == OK){
					B_gmemset((char *)PlcSendBuff,0,sizeof(PlcSendBuff));
					PlcSendBuff[0]= '%';		/* Start */
					PlcSendBuff[1]= 'E';		/* SA */
					PlcSendBuff[2]= 'E';		/* SA */
					PlcSendBuff[3]= '#';		/* Command */
					PlcSendBuff[4]= 'M';		/* Command */
					PlcSendBuff[5]= 'C';		/* Command */
					StartIdx= 0;
					idx += MAX_MON_BITCNT_PKG;
				}
			}
		}
	}
	if((ret == OK) && (PcThruBCnt < MAX_MON_BITCNT)){
		for(i = 0; i < DeviceCntSys; i++){
			if((DeviceDataSys[i].DevFlag == 0) &&
				(DeviceDataSys[i].SameDevInf == 0) &&
				(DeviceDataSys[i].Continus == 0) &&
				(DeviceDataSys[i].DevName[0] != 0x7f) &&
				(DeviceDataSys[i].DevCnt == 1)){
				if(MakePLCGroupAddr(DeviceDataSys[i].DevFlag, StartIdx, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, (char *)PlcSendBuff) != 0){
					continue;
				}
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
				DeviceDataSys[i].SameDevInf= -1;
				gDeviceCnt++;
				gDeviceCntBit++;
				StartIdx++;
				if((((gDeviceCntBit+ PcThruBCnt) % MAX_MON_BITCNT_PKG) == 0) && (gDeviceCntBit != 0)){
					StartIdx= B_gstrlen((char *)PlcSendBuff);
					ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0);
					if(ret == OK){
						StartIdx= 0;
						if((gDeviceCntBit+ PcThruBCnt) >= MAX_MON_BITCNT){
							break;
						}
					}else{
						break;
					}
				}
			}
		}
		if(StartIdx != 0){
			StartIdx= B_gstrlen((char *)PlcSendBuff);
			ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0);
		}
	}
	if(ret != OK){
		/* Monitor Clear */
		ClearMonDevice();
	}
}
/****************************************/
/*	Word Monitor�쐬						*/
/****************************************/
void	MakeWordMonitor(void)
{
	int		i,ret;
	int		StartIdx;
	/*Word MONITOR Device Set*/
	StartIdx= 0;
	ret= OK;
	B_gmemset((char *)PlcSendBuff,0,sizeof(PlcSendBuff));
	/* ���j??�r�b�g������ΐ�ɑ��� */
	if(PcThruWCnt > 0){
		PlcSendBuff[0]= '%';		/* Start */
		PlcSendBuff[1]= 'E';		/* SA */
		PlcSendBuff[2]= 'E';		/* SA */
		PlcSendBuff[3]= '#';		/* Command */
		PlcSendBuff[4]= 'M';		/* Command */
		PlcSendBuff[5]= 'D';		/* Command */
		B_gmemcpy((char *)&PlcSendBuff[6],(char *)&PcThruWData[0],PcThruWCnt*6);
		StartIdx= PcThruWCnt;
	}
	if(PcThruWCnt < MAX_MON_WORDCNT){
		for(i = 0; i < DeviceCntSys; i++){
			if((DeviceDataSys[i].DevFlag == 1) &&
				(DeviceDataSys[i].SameDevInf == 0) &&
				(DeviceDataSys[i].Continus == 0) &&
				(DeviceDataSys[i].DevName[0] != (unsigned char)0xef) &&
				(DeviceDataSys[i].DevCnt == 1)){
				if(MakePLCGroupAddr(DeviceDataSys[i].DevFlag, StartIdx, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, (char *)PlcSendBuff) != 0){
					continue;
				}
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
				DeviceDataSys[i].SameDevInf= -1;
				gDeviceCnt++;
				gDeviceCntWord++;
				StartIdx++;
				if((gDeviceCntWord+ PcThruWCnt) >= MAX_MON_WORDCNT){
					StartIdx= B_gstrlen((char *)PlcSendBuff);
					ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0);
					StartIdx= 0;
					break;
				}
			}
		}
	}
	if(StartIdx != 0){
		StartIdx= B_gstrlen((char *)PlcSendBuff);
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0);
	}
	if(ret != OK){
		/* Monitor Clear */
		ClearMonDevice();
	}
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
						MyAddress= DeviceDataSys[i].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
					MyAddress= DeviceDataSys[i].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN			   */
/*	2006.03.31 makebitpatarn �κ� ����         */
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/*	2006.03.31 makewordpatarn �κ� ����        */
/***************************************************/
void	MakeWordPatarn(int Start)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/***************************************************/
void	ClearBWContinue(void)
{
	int		i,j,idx;

	for(i= 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus != 0)){
			/* Continue */
			if(DeviceDataSys[i].DevFlag == 0){		/* BIT */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_BIT_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}else{									/* WORD */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_WORD_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	�O��?�v�쐬						*/
/****************************************/
int	MakeGroupDevPLCProc(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Set Group */
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gDeviceCnt= 0;
	/* Same Device Check */
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceCntSys > 0){
		if(DeviceDataSys[0].DevFlag == 0){
			BitCnt++;
			TotalBitCnt++;
		}else{
			WordCnt++;
			TotalWordCnt++;
		}
		if(DeviceDataSys[0].DevName[0] == 0){
			DeviceDataSys[0].SameDevInf= -1;
		}
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	/* Monitor Reset */
	RestMonitor();
	/* Bit Check */
	if(BitCnt <= MAX_MON_BITCNT){
		MakeBitMonitor();
	}else{
		MakeBitContinue();
		MakeBitMonitor();
	}
	/* Word Check */
	if(WordCnt <= MAX_MON_WORDCNT){
		MakeWordMonitor();
	}else{
		MakeWordContinue(TotalBitCnt);
		MakeWordMonitor();
	}
	/* Continue MAX Check */
	ClearBWContinue();
	/* Bit Patarn */
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	/* Word Patarn */
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}
	SetGroopSema();
	return(0);
}
int		MakeGroupDevPLC(int PlcType)
{
	int	ret;

	/* For Program Download */
	if(PcThru1014 != 0){
		return(0);
	}
	if(GroopingFlag != 0){
		while(1){
			if(GroopingFlag == 0){
				break;
			}
			B_Delay(10);
		}
	}
	GetGroopSema();
	ret= MakeGroupDevPLCProc(PlcType);
	return(ret);
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int		Cnt,ret;
	int		i,j,k;
	int		idx;
	int		dCnt;
	unsigned short	rdata;

	/* For Program Download */
	if(PcThru1014 != 0){
		return(0);
	}
	if(gDeviceCnt == 0){
		return(0);
	}
	if(GroopingFlag != 0){
		while(1){
			if(GroopingFlag == 0){
				break;
			}
			B_Delay(10);
		}
	}
	GetGroopSema();

	PlcSendBuff[0]= '%';		/* Start */
	PlcSendBuff[1]= 'E';		/* SA */
	PlcSendBuff[2]= 'E';		/* SA */
	PlcSendBuff[3]= '#';		/* Command */
	PlcSendBuff[4]= 'M';
	PlcSendBuff[5]= 'G';
	PlcSendBuff[6]= 0;
	Cnt= 6;
	ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)PlcRecBuff,&Cnt,0);
	if((ret == 0) && (PlcRecBuff[3] == 0x24)){		/* $ */
		idx= 7;			/* BIT POS */
		rdata= B_LHexAsToBin((char *)&PlcRecBuff[idx],2);
		if((PcThruBCnt == 0) && (gDeviceCntBit == 0)){
			idx= 0;
		}else{
			idx= ((PcThruBCnt+ gDeviceCntBit- 1)/8+ 1) * 2;
		}
		/* �r�b�g������������ */
		if(rdata == idx){
			/* ���j??�r�b�g������΃R�s?���� 051029 */
			if(PcThruBCnt > 0){
				dCnt= ((PcThruBCnt-1)/8+1)*2;
				B_gmemcpy((char *)&PcThruRecData[0],(char *)&PlcRecBuff[9],dCnt);
			}else{
				dCnt= 0;
			}
			/* ���j??��?�h������΃R�s?���� 051029 */
			if(PcThruWCnt > 0){
				if((PcThruBCnt == 0) && (gDeviceCntBit == 0)){
					idx= 2;
				}else{
					idx= ((PcThruBCnt+ gDeviceCntBit- 1)/8+ 1) * 2 + 2;	/* ��?�h�����O�X���܂� */
				}
				B_gmemcpy((char *)&PcThruRecData[dCnt],(char *)&PlcRecBuff[9+idx],PcThruWCnt*4);
			}
			idx= 7;			/* BIT POS */
			rdata= B_LHexAsToBin((char *)&PlcRecBuff[idx],2);
			dCnt= rdata;	/* BIT COUNT */
			j= 0;
			if(rdata != 0){
				/* ���j?�f�o�C�X������ꍇ�͔�΂� */
				if(PcThruBCnt > 0){
					idx+= PcThruBCnt/8*2;
#ifdef	SH_CPU
					BitAndData= bitTable[PcThruBCnt%8];
#endif
#ifdef	ARM_CPU
					BitAndData= bitTable[PcThruBCnt%8].strData;
#endif					
					k= PcThruBCnt%8;
				}else{
					BitAndData= 0x0001;
					k= 0;
				}
				for(i= 0; (j < gDeviceCntBit) && (i < gDeviceCnt); i++){
					idx += 2;
					rdata = B_LHexAsToBin((char *)&PlcRecBuff[idx],2);
					for(;(j < gDeviceCntBit) & (k < 8); j++, k++){
						if(rdata & BitAndData){
							*gDeviceAddr[j] = 1;
						}else{
							*gDeviceAddr[j] = 0;
						}
						BitAndData = BitAndData << 1;
					}
					BitAndData= 0x0001;
					k= 0;
				}
			}
			idx= dCnt+ 9;		/* WORD POS */
			rdata = B_LHexAsToBin((char *)&PlcRecBuff[idx],2);
			idx += 2;		/* Word Count */
			/* ���j??��?�h������ꍇ */
			if(PcThruWCnt > 0){
				idx+= PcThruWCnt*4;
			}
			if(rdata != 0){
	/*			for(i= gDeviceCntBit; i < gDeviceCnt; i++,j++){*/
				for(i= 0; i < gDeviceCntWord; i++,j++){
#ifdef	SH_CPU
					*(gDeviceAddr[j]+ 0) = B_Hex2Bin((char *)&PlcRecBuff[idx]);
					idx += 2;
					*(gDeviceAddr[j]+ 1) = B_Hex2Bin((char *)&PlcRecBuff[idx]);
					idx += 2;
#endif
#ifdef	ARM_CPU
#ifdef	WIN32
					*(gDeviceAddr[j]+ 0) = B_Hex2Bin((char *)&PlcRecBuff[idx]);
					idx += 2;
					*(gDeviceAddr[j]+ 1) = B_Hex2Bin((char *)&PlcRecBuff[idx]);
					idx += 2;
#else
					*(gDeviceAddr[j]+ 1) = B_Hex2Bin((char *)&PlcRecBuff[idx]);
					idx += 2;
					*(gDeviceAddr[j]+ 0) = B_Hex2Bin((char *)&PlcRecBuff[idx]);
					idx += 2;
#endif
#endif
				}
			}
		}
	}
	SetGroopSema();
	return(ret);
}
void	MonitGroop(void)
{
	SetGroopSema();
	MakeGroupDevPLCProc(0);
	GroopingFlag= 0;			/* Grooping Start */
	RecGroupPLCDev(0);
}
/************************************/
/*	���j?�R?���h��?�F�b�N����     */
/************************************/
int	PLCFxThruCheckProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt)
{
	int		i;
	int		ret;
	int		cnt;

	ret= -1;
	for(i= 0; i < MAX_COMMAND; i++){
#ifdef	SH_CPU
		if(B_gstrncmp(FPComm[i],&CommBuff[4],2) == 0){
			break;
		}
#endif
#ifdef	ARM_CPU
		if(B_gstrncmp(FPComm[i].strData,&CommBuff[4],2) == 0){
			break;
		}
#endif
	}
	if(i < MAX_COMMAND){	/* �R?���h�����݂��� */
		ret= i;
		switch(i){
		case 0:		/* MC */
			if(B_gstrncmp(&CommBuff[6],"FFFFF",5) == 0){
				/* ���j?���� */
				GroopingFlag= 1;
				GppPcThruBCnt= 0;
/*				PcThruWCnt= GppPcThruWCnt;*/
				PcThruBCnt= GppPcThruBCnt;
				MonitGroop();
				/* �O��?�v����蒼�� */
			}else{
				cnt= (*RecCommCnt- 9)/5;
				/* ���j?�f??��ۑ����� */
				B_gmemcpy((char *)&PcThruBData[GppPcThruBCnt*5],&CommBuff[6],cnt*5);
				GppPcThruBCnt+= cnt;
			}
			/* �����f??���쐬���� */
			OutBuff[0]= '%';
			B_gmemcpy(&OutBuff[1],PLC_Kyoku,2);
			OutBuff[3]= '$';
			OutBuff[4]= 'M';
			OutBuff[5]= 'C';
			OutBuff[6]= 0;
			cnt= 6;
			*OutCnt= SetPLCBCC((char *)OutBuff,cnt);
			break;
		case 1:		/* MD */
			if(B_gstrncmp(&CommBuff[6],"FFFFFF",6) == 0){
				/* ���j?���� */
				GroopingFlag= 1;
				GppPcThruWCnt= 0;
				PcThruWCnt= GppPcThruWCnt;
/*				PcThruBCnt= GppPcThruBCnt;*/
				MonitGroop();
				/* �O��?�v����蒼�� */
			}else{
				cnt= (*RecCommCnt- 9)/6;
				/* ���j?�f??��ۑ����� */
				B_gmemcpy((char *)&PcThruWData[GppPcThruWCnt*6],&CommBuff[6],cnt*6);
				GppPcThruWCnt+= cnt;
			}
			/* �����f??���쐬���� */
			OutBuff[0]= '%';
			B_gmemcpy(&OutBuff[1],PLC_Kyoku,2);
			OutBuff[3]= '$';
			OutBuff[4]= 'M';
			OutBuff[5]= 'D';
			OutBuff[6]= 0;
			cnt= 6;
			*OutCnt= SetPLCBCC((char *)OutBuff,cnt);
			break;
		case 2:		/* MG */
			if((GppPcThruBCnt != 0) || (GppPcThruWCnt != 0)){
				GroopingFlag= 1;
				PcThruWCnt= GppPcThruWCnt;
				PcThruBCnt= GppPcThruBCnt;
				GppPcThruBCnt= 0;
				GppPcThruWCnt= 0;
				MonitGroop();
			}
			/* �o�̓f??�쐬 */
			OutBuff[0]= '%';
			B_gmemcpy(&OutBuff[1],PLC_Kyoku,2);
			OutBuff[3]= '$';
			OutBuff[4]= 'M';
			OutBuff[5]= 'G';
			OutBuff[6]= '0';
			if(PcThruBCnt > 0){
				cnt= (PcThruBCnt- 1)/8+1;	/* �r�b�g�f�o�C�X*/
				cnt*= 2;
				B_Bin2Hex(cnt,2,&OutBuff[7]);
			}else{
				cnt= 0;
				B_Bin2Hex(cnt,2,&OutBuff[7]);
			}
			B_gmemcpy(&OutBuff[9],(char *)&PcThruRecData[0],cnt);
			B_Bin2Hex(PcThruWCnt*4,2,&OutBuff[9+cnt]);
			B_gmemcpy(&OutBuff[11+cnt],(char *)&PcThruRecData[cnt],PcThruWCnt*4);
			cnt += PcThruWCnt*4;
			cnt += 11;	/* �w�b???�����O�X */
			*OutCnt= SetPLCBCC(OutBuff,cnt);
			break;
		case 3:
			PcThru1014= 1;		/* Program Download Start */
			break;
		case 4:
			PcThru1014= 0;		/* Program Download End */
			break;
		}
	}else{
		/* ���j?�R?���h������΃O��?�s���O���� */
		if((GppPcThruBCnt != 0) || (GppPcThruWCnt != 0)){
			PcThruWCnt= GppPcThruWCnt;
			PcThruBCnt= GppPcThruBCnt;
			GppPcThruBCnt= 0;
			GppPcThruWCnt= 0;
			MonitGroop();
		}
	}
	return(ret);
}
/************************************/
/*	�X��?��?�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	int	ret;

	/* �X��?�R?���h��?�F�b�N���� */
	ret= PLCFxThruCheckProc(CommBuff,RecCommCnt,&OutBuff[0],OutCnt);
	switch(ret){
	case 0:			/* MC */
		B_SendPLC2PCData(0,*OutCnt,OutBuff,3000);		/* �������M */
		break;
	case 1:			/* MD */
		B_SendPLC2PCData(0,*OutCnt,OutBuff,3000);		/* �������M */
		break;
	case 2:			/* MG */
		B_SendPLC2PCData(0,*OutCnt,OutBuff,3000);		/* �������M */
		break;
	default:
		B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
		*OutCnt= *RecCommCnt;
		B_SendPLCPCData();
		break;
	}
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
#endif
#ifdef	PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(1);
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif

#include	"hook_aplplc.h"
/****************************** END **********************/