/*****************************************************************************************/
/*	PLC ����M �v���O��?(LG-K3P-07AS)		  */
/*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		  */
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
/*	2006.09.25 */
/*      �����͹� ���ø� ������ ���� ver 2.7�� �ϰ� ����	  */
/*  20061023 ���Ϲ��� �������� ��Ƽ���ӽ� ��ε��ɽ��ý� �������� ���� ���� ���� V2.7S  */ 
/*  20061025ksc  */ 
/*	     ������ �۽Ž��� ������ �ð� �߰� 30ms V2.7S  - �ٽ� ����  */ 
/* 		 3�� ���� 4�� ���� ���� �����ϵ��� ����  V2.7S		 */
/*       ���Ϲ����� ��� �ӵ� ������ ���������� �ܳؼǿ��� ���� ������ ���� */
/*		 RTU�� ���� �ð��� �ӵ��� ���� �޸� �����ϵ��� ����. �ӵ������� �������� ���� Plchand ���� */ 
/*  2007.01.30 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����		*/
/*  2007.10.08 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����	 		*/ 
/*****************************************************************************************/




#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

#ifdef PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include  "hook_plcapl.h"

/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0100
#define	VERSION_SET	"V4.2S"
/*****************************************************************************************/





#define	UNVERS_WRITE_START	15
#define	UNVERS_WRITE_END	6047
#define	UNVERS_READ_START	0
#define	UNVERS_READ_END	6047
#define	UNVERS_ERR_FNC	0x01
#define	UNVERS_ERR_ADR	0x02
#define	UNVERS_ERR_DAT	0x03


/****************************** for Window **********************/
#ifdef	SH_CPU
static	int	SUnvPlcRecCnt;
static	int	SUnvPlcRecCmd;
static	unsigned	int	Port_TimeoutCnt;		/* 20060203 */
static	int	Pro_Speed;			/* 20061025ksc */
static	unsigned int Plc_sync_time;				/* 20061025ksc */ 
#endif

/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif

}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_38400;
	*DataBit= RS_DATA8;
	*Parity= RS_NONE;
}
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/

static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret;

	ret = -1;


/* 20060202 */
	if(Port_TimeoutCnt != 0){
		if(Plc_sync_time < (B_GetNowTime() - Port_TimeoutCnt)){   /* 20061025ksc */ 
			*CommMode =0;
			*RecCnt = 0;
		}
	}
	Port_TimeoutCnt = B_GetNowTime();		
	
	
	switch(*CommMode){
	case 0:		/* Idle */
		*CommMode = 1;
		*RecCnt = 0;
		RecBuff[(*RecCnt)++] = data;		/* Slave Address */
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		SUnvPlcRecCnt= 6;
		SUnvPlcRecCmd= data;					/* Command */
		switch(SUnvPlcRecCmd){
		case 0x01:
		case 0x02:
		case 0x03:
		case 0x04:
		case 0x05:
		case 0x06:
			SUnvPlcRecCnt= 6;
			break;
		case 0x07:
		case 0x0b:
		case 0x0c:
			SUnvPlcRecCnt= 2;
			break;
		case 0x0f:	/* �A��DO */
			SUnvPlcRecCnt= 5;
			break;
		case 0x10:	/* �A���ێ����W�X? */
			SUnvPlcRecCnt= 5;
			break;
		case 0x11:	/*  */
			SUnvPlcRecCnt= 2;
			break;
		default:
			SUnvPlcRecCnt= 6;
			break;
		}
		*CommMode = 2;
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		SUnvPlcRecCnt--;
		if(SUnvPlcRecCnt <= 0){
			if((SUnvPlcRecCmd == 0x0f) || (SUnvPlcRecCmd == 0x10)){
				SUnvPlcRecCnt= data+ 2;		/* Write Cnt + CRC */
				*CommMode = 3;
			}else{
				ret= 0;		/* Command End */
				Port_TimeoutCnt = 0;	/* 20060203 */
			}
		}
		break;
	case 3:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		SUnvPlcRecCnt--;
		if(SUnvPlcRecCnt <= 0){
			ret= 0;		/* Command End */
			Port_TimeoutCnt = 0;	/* 20060203 */
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/

/************************************/
/* ���ʏ���							*/
/************************************/
/* Table of CRC values for high.order byte */
static	const	unsigned char SUnv_auchCRCHi[] = {
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
} ;
/* Table of CRC values for low.order byte */
static	const	unsigned char SUnv_auchCRCLo[] = {
    0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 
    0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 
    0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 
    0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, 0x11, 0xD1, 0xD0, 0x10, 
    0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 
    0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 
    0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 
    0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, 0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 
    0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 
    0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 
    0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 
    0xB4, 0x74, 0x75, 0xB5, 0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 
    0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 
    0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 
    0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
    0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80, 0x40
} ;
static	unsigned short SUnv_crc16(unsigned char *puchMsg, int usDataLen)
{
    unsigned char uchCRCHi = 0xFF ; /* high byte of CRC initialized */
    unsigned char uchCRCLo = 0xFF ; /* low byte of CRC initialized */
    int uIndex ; /* will index into CRC lookup table */
	if(usDataLen <= 0){	return(0); }		/* 20090527 */
    while (usDataLen--) /* pass through message buffer */
    {
        uIndex = uchCRCHi ^ *puchMsg++ ; /* calculate the CRC */
        uchCRCHi = uchCRCLo ^ SUnv_auchCRCHi[uIndex] ;
        uchCRCLo = SUnv_auchCRCLo[uIndex] ;
    }
    return (uchCRCHi << 8 | uchCRCLo) ;
}
/****************************************************************/
/*	FUNC    :�ėp�ʐM�i���R?�h�����j							*/
/*	����	:char *RecBuff:��M�o�b�t?							*/
/*			:int RecCnt:��M�����O�X							*/
/*			:char *SndBuff:���M�o�b�t?							*/
/*			:int *SndCnt:���M�����O�X							*/
/*			   STX,DATA,ETX,SUM									*/
/*			   STX,DATA,CR										*/
/****************************************************************/
static	void	SUniversalError(unsigned char *RecBuff,char *SndBuff,int *SndCnt,int Code)
{
	int		idx;
	unsigned short	_crc16;

	idx= 0;
	SndBuff[idx++]= RecBuff[0];	/* �ǔ� */
	SndBuff[idx++]= RecBuff[1];	/* Command */
	SndBuff[idx++]= Code  | 0x80;		/* Code */
	_crc16= SUnv_crc16((unsigned char *)SndBuff,idx);
	SndBuff[idx++]= (char)(_crc16 >> 8);
	SndBuff[idx++]= (char)_crc16;
	*SndCnt= idx;
}
static	void	SUniversalRead(unsigned char *RecBuff,char *SndBuff,int *SndCnt,int mode)
{
	int		Cnt;
	int		i,idx;
	int		didx;
	int		address;
	int		Endaddress;
	unsigned short	_crc16;

	idx= 0;
	SndBuff[idx++]= RecBuff[0];	/* �ǔ� */
	SndBuff[idx++]= RecBuff[1];	/* Command */
	switch(RecBuff[1]){
	case 0x03:
	case 0x04:

		address= (RecBuff[2] << 8) + RecBuff[3];
		Cnt= (RecBuff[4] << 8) + RecBuff[5];
		SndBuff[idx++]= Cnt*2;	/* Count */
		didx= address;
		Endaddress= address+ Cnt - 1;
		if((address >= UNVERS_READ_START) && (address <= UNVERS_READ_END) && (Endaddress <= UNVERS_READ_END)){
			for(i= 0; i < Cnt; i++){
#ifdef	SH_CPU
				SndBuff[idx++]= (char)InDevArea.UW[didx];
				SndBuff[idx++]= (char)(InDevArea.UW[didx++] >> 8);
#endif
#ifdef	SH_CPU
#ifdef	WIN32
				SndBuff[idx++]= (char)InDevArea.UW[didx];
				SndBuff[idx++]= (char)(InDevArea.UW[didx++] >> 8);
#else
				SndBuff[idx++]= (char)(InDevArea.UW[didx] >> 8);
				SndBuff[idx++]= (char)InDevArea.UW[didx++];
#endif
#endif
			}
			_crc16= SUnv_crc16((unsigned char *)SndBuff,idx);
			SndBuff[idx++]= (char)(_crc16 >> 8);
			SndBuff[idx++]= (char)_crc16;
			*SndCnt= idx;
		}else{
			SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}
		break;
	}
}

static	void	SUniversalWrite(unsigned char *RecBuff,int RecCnt,char *SndBuff,int *SndCnt,int mode)
{
	int		Cnt,i;
	int		idx;
	int		didx;
	int		address;
	int		Endaddress;
	unsigned short	_crc16;

	switch(RecBuff[1]){

	case 0x10:			/* Preset Multiple Registers */
		address= (RecBuff[2] << 8) + RecBuff[3];
		Cnt= ((RecBuff[4] << 8) + RecBuff[5])* 2;
		idx= 7;
		Endaddress= address+ (Cnt/2 - 1);
		if((address >= UNVERS_WRITE_START) && (address <= UNVERS_WRITE_END) && (Endaddress <= UNVERS_WRITE_END)){
			didx= address;
			for(i= 0; i < Cnt/2; i++){
#ifdef	SH_CPU
				InDevArea.UW[didx]= RecBuff[idx++];
				InDevArea.UW[didx++] += RecBuff[idx++] << 8;
#endif
#ifdef	SH_CPU
#ifdef	WIN32
				InDevArea.UW[didx]= RecBuff[idx++];
				InDevArea.UW[didx++] += RecBuff[idx++] << 8;
#else
				InDevArea.UW[didx]= RecBuff[idx++] << 8;
				InDevArea.UW[didx++] += RecBuff[idx++]; 				
#endif
#endif
			}
			idx= 0;
			SndBuff[idx++]= RecBuff[0];	/* �ǔ� */
			SndBuff[idx++]= RecBuff[1];	/* Command */
			SndBuff[idx++]= RecBuff[2];	/* Start Addr */
			SndBuff[idx++]= RecBuff[3];	/*  */
			SndBuff[idx++]= RecBuff[4];	/* Register Cnt */
			SndBuff[idx++]= RecBuff[5];	/*  */
			_crc16= SUnv_crc16((unsigned char *)SndBuff,idx);
			SndBuff[idx++]= (char)(_crc16 >> 8);
			SndBuff[idx++]= (char)_crc16;
			*SndCnt= idx;
		}else{
			SUniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}
		break;
	}
}
/*ksc 20050307 */
static	void	SUniversalBroadWrite(unsigned char *RecBuff,int RecCnt,char *SndBuff,int *SndCnt,int mode)
{
	int		Cnt,i;
	int		idx;
	int		didx;
	int		address;
	int		Endaddress;


	switch(RecBuff[1]){

	case 0x10:			/* Preset Multiple Registers */
		address= (RecBuff[2] << 8) + RecBuff[3];
		Cnt= ((RecBuff[4] << 8) + RecBuff[5])* 2;
		idx= 7;
		Endaddress= address+ (Cnt/2 - 1);
		if((address >= UNVERS_WRITE_START) && (address <= UNVERS_WRITE_END) && (Endaddress <= UNVERS_WRITE_END)){
			didx= address;
			for(i= 0; i < Cnt/2; i++){
				InDevArea.UW[didx]= RecBuff[idx++];
				InDevArea.UW[didx++] += RecBuff[idx++] << 8;
			}

		}
		*SndCnt= 0; /* *SndCnt = 0 No response */
		break;
	}
}
/*ksc 20050307 */

static	int	SHanyouComm(char	*RecBuff,int RecCnt,char *SndBuff,int *SndCnt)
{
	int		ret;
	unsigned short	_crc16;
	unsigned short	sum1;
	unsigned char work;

	ret = 0;
	*SndCnt= 0;		/* 20061023 */	
	/* Check SUM Check */
	_crc16= SUnv_crc16((unsigned char *)RecBuff,RecCnt- 2);
	work= (unsigned char)RecBuff[RecCnt- 2];
	sum1= (work << 8)+ (unsigned char)RecBuff[RecCnt- 1];
	if(_crc16 != sum1){
		ret= -1;
	}
	if((Set.iGPSta != RecBuff[0]) && (RecBuff[0] != 0)){ 	/* Address = 0 ok Broadcast */
		ret= -2;	
	}
	if(ret == 0){			/* ��MOK */
		switch(RecBuff[1]){
		case 0x03:		/* Read Holding Reg */
		case 0x04:
			if(RecBuff[0] != 0){	/* 20061023 */
				SUniversalRead((unsigned char *)RecBuff,SndBuff,SndCnt,0);
			}
			break;

		case 0x10:		/* Multiple Regs */
		
			if(RecBuff[0] != 0){
				SUniversalWrite((unsigned char *)RecBuff,RecCnt,SndBuff,SndCnt,0);
			}else{
				SUniversalBroadWrite((unsigned char *)RecBuff,RecCnt,SndBuff,SndCnt,0);
			}
			break;

		default:
			if(RecBuff[0] != 0){	/* 20061023 */
				SUniversalError((unsigned char *)RecBuff,SndBuff,SndCnt,UNVERS_ERR_FNC);
			}		
			break;
		}
	}else{
		if(ret == -1){
/*			SUniversalError((unsigned char *)RecBuff,SndBuff,SndCnt,UNVERS_ERR_DAT); 20061023 */
		}else{
			*SndCnt= 0;
		}
	}
	return(ret);
}
/********************************************************/
static	int	C_Connection( int *PlcType, int iConnect ) /* 20061025ksc */ 
{
	int		ret;
	Port_TimeoutCnt = 0;	/* 20060203 */

	Pro_Speed = PlcType[3];			/* 20061025ksc */ 

	switch(Pro_Speed){		
	case 0:						/* 300bps */
		Plc_sync_time = 50;
		break;
	case 1:						/* 600bps */
		Plc_sync_time = 30;
		break;
	case 2:						/* 1200bps */
	case 3:						/* 2400bps */
	case 4:						/* 4800bps */
	case 5:						/* 9600bps */
	case 6:						/* 19200bps */
	case 7:						/* 38400bps */
	case 8:						/* 57600bps */
	case 9:						/* 115200bps */
		Plc_sync_time = 20;
		break;
	default:
		Plc_sync_time = 50;
		break;
	}

	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */
#ifdef	TEST			 /* 20061025ksc */ 
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */
#ifdef	WIN32
			SioPCMode= 2;
			SioPCOpenFlag= 1;
#else
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);  */
#endif
		}else{						/* RS-422 */
#ifdef	WIN32
			SioPLCMode= 2;
			SioPLCOpenFlag= 1;
#else
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE); */
#endif
		}
#ifdef	WIN32
		while(1){
			if(SioPLCOpenFlag == 0){
				break;
			}
			B_Delay(10);
		}
#endif
		B_Delay(500);
#endif
	}
	ret= 1;
	return(ret);
}
/******************************************/
static	void	C_SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif

#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif

}
/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	C_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/************************************/
/* PLC Read							*/
/************************************/
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(0);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/************************************/
/* PLC Write						*/
/************************************/
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(0);
}
static	int	C_GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}


/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType, int iConnect) 
{
	return(C_Connection(PlcType, iConnect)); 
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	C_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	C_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	return(ret);
}
/************************************************/
/*	�O��?�v����								*/
/************************************************/
/****************************************/
/*	�O��?�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	return(0);
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	return(0);
}
/************************************/
/*	�X��?��?�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	int	PlcCommCnt;
/*	B_Delay(30); *//* 20061025ksc */
	SHanyouComm((char *)CommBuff,*RecCommCnt,(char *)PlcSendBuff,&PlcCommCnt);
	if(PlcCommCnt != 0){
		B_SendPC2PLCData(0,PlcCommCnt,(char *)PlcSendBuff,3000);
	}
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	C_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
#endif
/*++++++++++++++++++++++++++++++++++++*/
#ifdef PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(1);
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif

#include  "hook_aplplc.h"

/****************************** END **********************/
