/************************************************************/
/*	PLC TYPE 2												*/
/************************************************************/
#define	ARM_CPU		1
#define	PLCTYPE_CH2	1
#define FX1S	1
#ifndef	WIN32
/* #pragma	section PlcProc2 */
#endif

/****************************** START **********************/
#ifdef	WIN32
#ifdef	FX	
#define		TYPE_FX1N	1								/* 01 */
#include	"PlcTypeFx.cpp"
#include	"Plc_Mitsubishi-FX.cpp"
#endif
#ifdef	FX1S
#define		TYPE_FX1S	1					/* 01 */
#include	"PlcTypeFx.cpp"
#include	"Plc_Mitsubishi-FX.cpp"
#endif
#ifdef	MK10S1
#include	"PLgmk10s1.cpp"
#include	"Plc_LS-MK10S1.cpp"
#endif
#ifdef	MK200S
#include	"PlcTypeLg.cpp"
#include	"Plc_LS-MK200S.cpp"
#endif
#ifdef	N70 /* FPG PLC SAME */				/* 04 */
#define		PLC_SPEED	RS_19200
#include	"Plcsm_70n.cpp"
#include	"Plc_Samsung-N70.cpp"
#endif
#ifdef	N70PLUS
#include	"Plcsm2_70p.cpp"
#include	"Plc_Samsung-N70PLUS.cpp"
#endif
#ifdef	THD_MODBUS
#include	"PlcThdM.cpp"
#include	"Plc_Autonics-THD_MODBUS.cpp"
#endif
#ifdef	TZ
#include	"PlcTypeTZ.cpp"
#include	"Plc_Autonics-TZ.cpp"
#endif
#ifdef	MT
#include	"PlcTypeMT.cpp"
#include	"Plc_Autonics-MT.cpp"
#endif
#ifdef	MP
#include	"PlcTypeMP.cpp"
#include	"Plc_Autonics-MP.cpp"
#endif
#ifdef	MASTER_MODBUS
#include	"PlcModMS.cpp"
#include	"Plc_Modicon-MASTER_MODBUS.cpp"
#endif
#ifdef	MK_CNET
#include	"PlcLGcnet.cpp"
#include	"Plc_LS-MK_CNET.cpp"
#endif

#ifdef	UNIS_MODBUS
#include	"Plc_UniS.cpp"
#include	"Plc_Autonics-UNIS_MODBUS.cpp"
#endif
#ifdef	FP0
#define		PLC_SPEED	RS_9600
#include	"Plcsm_70n.cpp"
#include	"Plc_Samsung-N70.cpp"
#endif
#ifdef	GM4		
#define	MAX_UR_CNT	 50  /* Max Monitor ��� ���� */
#include	"PlcTypeGM.cpp"
#include	"Plc_LS-GM4.cpp"
#endif
#ifdef	GM6		
#define	MAX_UR_CNT	 50  /* Max Monitor ��� ���� */
#include	"PlcTypeGM.cpp"
#include	"Plc_LS-GM6.cpp"
#endif
#ifdef	GM7U		
#define	MAX_UR_CNT	 50  /* Max Monitor ��� ���� */
#include	"PlcTypeGM.cpp"
#include	"Plc_LS-GM7U.cpp"
#endif
#ifdef	E5XX_MODBUS
#include	"PlcOmronE5CN_Mod.cpp"
#include	"Plc_Omron-E5CN_MODBUS.cpp"
#endif
#ifdef	CPM1A
#include	"PlcTypeCPM1A.cpp"
#include	"Plc_Omron-CPM1A.cpp"
#endif
#ifdef	DTB_MODBUS									/* 16 */
#include	"PlcDeltaB_Mod.cpp"
#include	"Plc_Delta-DTB_MODBUS.cpp"
#endif
#ifdef	FPG									/* 17 */
#define		PLC_SPEED	RS_19200
#include	"Plcsm_70n.cpp"
#include	"Plc_Samsung-N70.cpp"
#endif
#ifdef	XGT_CNET								/* 19 */
#include	"PlcXGTcnet.cpp"
#include	"Plc_LS-XGT_CNET.cpp"
#endif
#ifdef	DPU_MODBUS									/* 20 */
#include	"Plc_Konics_Mod2.cpp"
#include	"Plc_Konics-DPU_MODBUS.cpp"
#endif
#ifdef	TB42_MODBUS									/* 21 */
#include	"Plc_Tb42_Mod.cpp"
#include	"Plc_Autonics-TB42_MODBUS.cpp"
#endif

#ifdef	S7_200
#include	"Plc_Simens-S7_200.cpp"
#endif
#ifdef	S7_300
#include	"Plc_Simens-S7_300.cpp"
#endif
#ifdef	MICROLOGIC1000
#include	"Plc_Allenbradley-MICROLOGIC1000.cpp"
#endif
#ifdef	MICROLOGIC1200
#include	"Plc_Allenbradley-MICROLOGIC1200.cpp"
#endif
#ifdef	FX3U
#include	"Plc_Mitsubishi-FX3U.cpp"
#endif
#ifdef	MT_MODBUS
#include	"Plc_Autonics-MT_MODBUS.cpp"
#endif
#ifdef	PMS_HS
#include	"Plc_Autonics-PMS_HS.cpp"
#endif
#ifdef	Q00J
#include	"Plc_Mitsubishi-Q00J.cpp"
#endif



#else

#ifdef	FX	
#define		TYPE_FX1N	1								/* 01 */
#include	"PlcTypeFx.c"
#endif
#ifdef	FX1S
#define		TYPE_FX1S	1					/* 01 */
#include	"PlcTypeFx.c"
#endif
#ifdef	MK10
#include	"PLgmk10s1.c"
#endif
#ifdef	MK200
#include	"PlcTypeLg.c"
#endif
#ifdef	N70
#define		PLC_SPEED	RS_19200
#include	"Plcsm_70n.c"
#endif
#ifdef	N70P
#include	"Plcsm2_70p.c"
#endif
#ifdef	ATHD
#include	"PlcThdM.c"
#endif
#ifdef	ATZ
#include	"PlcTypeTZ.c"
#endif
#ifdef	AMT
#include	"PlcTypeMT.c"
#endif
#ifdef	AMP
#include	"PlcTypeMP.c"
#endif
#ifdef	MODMS
#include	"PlcModMS.c"
#endif
#ifdef	LGCNET
#include	"PlcLGcnet.c"
#endif
#ifdef	UNI_S
#include	"Plc_UniS.c"
#endif
#ifdef	FP0
#define		PLC_SPEED	RS_9600
#include	"Plcsm_70n.c"
#endif
#ifdef	GM4		
#define	MAX_UR_CNT	 50  /* Max Monitor ��� ���� */
#include	"PlcTypeGM.c"
#endif
#ifdef	GM6		
#define	MAX_UR_CNT	 50  /* Max Monitor ��� ���� */
#include	"PlcTypeGM.c"
#endif
#ifdef	GM7		
#define	MAX_UR_CNT	 50  /* Max Monitor ��� ���� */
#include	"PlcTypeGM.c"
#endif
#ifdef	E5XX
#include	"PlcOmronE5CN_Mod.c"
#endif
#ifdef	CPM1A
#include	"PlcTypeCPM1A.c"
#endif
#ifdef	DTB
#include	"PlcDeltaB_Mod.c"
#endif
#ifdef	FPG
#define		PLC_SPEED	RS_19200
#include	"Plcsm_70n.c"
#endif

#ifdef	XGTCNET			
#include	"PlcXGTcnet.c"
#endif
#ifdef	DPU
#include	"Plc_Konics_Mod2.c"
#endif
#ifdef	TB42									/* 21 */
#include	"Plc_Tb42_Mod.c"
#endif
#endif
/****************************** END **********************/

