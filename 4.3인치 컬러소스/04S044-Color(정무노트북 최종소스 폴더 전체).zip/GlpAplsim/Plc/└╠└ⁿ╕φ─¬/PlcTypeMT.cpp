/*****************************************************************************************/
/*	PLC ����M �v���O��?(AUTONICS)		*/
/*	2003.5.31				*/
/************************************************/
/*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		  */
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
/*	2006.09.25 */
/*      �����͹� ���ø� ������ ���� ver 2.6�� �ϰ� ����	  */
/*  2007.01.30 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����		*/
/*  2007.10.08 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����	 		*/ 
/*****************************************************************************************/

#include	"define.h"
#include	"GpCommon.h"
#include	"PlcCommBuff.h"
#include	"mail.h"
#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include	"hook_plcapl.h"
/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V4.0M"
/*****************************************************************************************/



#define	MAX_RTY_COUNT	3


#ifdef	SH_CPU
static	int	GroopSema;			/* Grooping Semafo */
static	int DeviceStartPoint;		/* 0�϶� D100 ����̽�, 1�϶� D101 ����̽� 
						   D100���� ��Ž� D100[����], D101[�µ�]
                           D101��   ��Ž� D100[�µ�], D101[����] */
#endif

static	const	DEV_TBL bPLCDeviceTbl[16] = {
	{"MT" ,0x00,2},
	{"GB" ,    0,4},
};
static	const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"MT" ,0x00,2},
	{"GB" ,    0,4},
};


static	const unsigned char CRC8[256]={
   0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41,
   0x9d, 0xc3, 0x21, 0x7f, 0xfc, 0xa2, 0x40, 0x1e, 0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc,
   0x23, 0x7d, 0x9f, 0xc1, 0x42, 0x1c, 0xfe, 0xa0, 0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62,
   0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81, 0x63, 0x3d, 0x7c, 0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff,
   0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5, 0x84, 0xda, 0x38, 0x66, 0xe5, 0xbb, 0x59, 0x07,
   0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58, 0x19, 0x47, 0xa5, 0xfb, 0x78, 0x26, 0xc4, 0x9a,
   0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6, 0xa7, 0xf9, 0x1b, 0x45, 0xc6, 0x98, 0x7a, 0x24,
   0xf8, 0xa6, 0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b, 0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05, 0xe7, 0xb9,
   0x8c, 0xd2, 0x30, 0x6e, 0xed, 0xb3, 0x51, 0x0f, 0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd,
   0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc, 0x92, 0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50,
   0xaf, 0xf1, 0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c, 0x6d, 0x33, 0xd1, 0x8f, 0x0c, 0x52, 0xb0, 0xee,
   0x32, 0x6c, 0x8e, 0xd0, 0x53, 0x0d, 0xef, 0xb1, 0xf0, 0xae, 0x4c, 0x12, 0x91, 0xcf, 0x2d, 0x73,
   0xca, 0x94, 0x76, 0x28, 0xab, 0xf5, 0x17, 0x49, 0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b,
   0x57, 0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4, 0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16,
   0xe9, 0xb7, 0x55, 0x0b, 0x88, 0xd6, 0x34, 0x6a, 0x2b, 0x75, 0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8,
   0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b, 0xa9, 0xf7, 0xb6, 0xe8, 0x0a, 0x54, 0xd7, 0x89, 0x6b, 0x35
};


/*ksc20040707 ������ ������ �����Ѵ� */
#ifdef	SH_CPU
static	const	char	*DevTbl[12]= {
	"P0","P0", "P0"
};
#endif
#ifdef	ARM_CPU
static	const	PLC_CONST	DevTbl[12]= {
	{"P0",1},
	{"P0",1},
	{"P0",1},
};
#endif


/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef	PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_9600;
	*DataBit= RS_DATA8;
	*Parity= RS_NONE;
}
/*********************************/
/*	PLC Semafor			         */
/*********************************/
static	void	GetGroopSema(void)
{
	unsigned int	NowTime;
	unsigned int	StartTime;

	if(GroopSema == 0){		/* Grooping Sema */
	}else{
		StartTime= B_GetNowTime();
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
			NowTime= B_GetNowTime();
			if((StartTime+ 3000) < NowTime){
				GroopSema= 0;
			}
			B_Delay(10);
		}
	}
	GroopSema++;
}
static	void	ResetGroopSema(void)
{
	GroopSema= 0;
}

static int	C_gatoi(char *buff)
{
	char	c;
	int	ret;
	int flag;

	ret= 0;
	flag= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){
			break;
		}
		if((c >= '0') && (c <= '9')){
			ret= ret*10;
			ret+= c- '0';
		}else{
			if(c == '+'){
				continue;
			}
			if(c == '-'){
				flag= 1;
				continue;
			}
			break;
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
extern	int		SioPLCDlgCommCnt;
extern	int	Sio0OutCnt;

	int	ret;
	
	ret= -1;
#ifdef	OLD
#ifdef	WIN32
	if(SioPLCDlgCommCnt != 0){
		return(ret);
	}
#else
	if(Sio0OutCnt != 0){
		return(ret);
	}
#endif
#endif

	switch(*CommMode){
/*ksc20040707*/
/* ���� ���ŵ� ����Ÿ�� ���� 
 - ��Ʈ���ڵ�	: RecBuff[0], RecBuff[1]�� ACK, STX �Է�
 - ����Ÿ		: RecBuff[2], RecBuff[3]�� ����,
                  RecBuff[4], RecBuff[5]�� RD,
				  RecBuff[6], RecBuff[7], RecBuff[8], RecBuff[9]�� ����Ÿ,
				  RecBuff[10]�� ETX,
 - �����ڵ�		: RecBuff[11]�� FSC, */ 

	case 0:
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*RecCnt= 0;			/* ?���X??�g */
			RecBuff[(*RecCnt)++] = data;
			*CommMode = 1;
			break;
/*ksc20040716*/
		default:
			break;
		}
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		if((data == EOT) || (data == ETX)){
			*CommMode = 2;
		}
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		*CommMode = 0;
		if((B_gstrncmp((char *)&RecBuff[4],"RD",2) == 0) || (B_gstrncmp((char *)&RecBuff[4],"WD",2) == 0) ||
			(((RecBuff[4] >= '0') && (RecBuff[4] <= '9')) && (RecBuff[5] == 'D'))){
			ret= 0;
		}else{
			*RecCnt= 0;			/* ?���X??�g */
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/


/*ksc20040707*/
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
/* char *buff : �۽��ϰ����ϴ� ����Ÿ ����,
   int cnt    : �۽��ϰ����ϴ� ����Ÿ ��,
   unsigned char *OutBuf : CRC���� �ΰ��� �����۽� ����Ÿ */

static	int SetPLCBCC(char *buff,int cnt)
{


/* �ʱⰪ : *buff = 0, 1, R, X, P, 0 */
/*          cnt = 6									*/
/*			*OutBuf = ?									*/	
	int		i;
	unsigned char _crc8;
/*	*OutBuf = 0;*/
	buff[0] = STX;				/* �۽Ź��� OutBuf[0] = STX */
/*	for(i = 0; i < cnt; i++){*/
/*		OutBuf[i+1] = buff[i];*/		/* �۽Ź��� OutBuf[1] = ����, OutBuf[2] = ����, OutBuf[3] = R, OutBuf[4] = X,
												OutBuf[5] = P, OutBuf[6] = 0 */												
/*	}*/
	buff[cnt+1] = ETX;				/* �۽Ź���	OutBuf[7] = ETX */
	_crc8 = 0;
	for(i = 1; i < cnt+2; i++){
		_crc8 = CRC8[(unsigned int)(_crc8 ^ buff[i])]; /* CRC ��� �������� ETX */
 	}
	buff[cnt+2]= _crc8&0x00ff;	/* �۽Ź���	OutBuf[8] = CRC */ 
	return(cnt + 3);				/* 9�� ���� */


}



/************************************/
/*	PLC Send						*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret,i;
	int		rty_cnt;
	unsigned char _crc8;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen(&combuf[1]));
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
		ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		if(ret == OK){
			_crc8 = 0;
			for(i = 2; i < *Cnt-1; i++){
				_crc8 = CRC8[(unsigned int)(_crc8 ^ rData[i])]; /* CRC ��� �������� ETX */
 			}
			if(_crc8 != rData[*Cnt-1]){
				ret= -1;
			}
		}
		if(ret == OK){
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}
	return(ret);
}
static	int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen(&combuf[1]));
	ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	return(ret);
}
static	int	C_Connection( int *PlcType,int iConnect )
{
	int		ret;
/*ksc20040714*/

	int		Cnt;
	char	buff[32];
#ifndef	WIN32
	int		Speed;
	int		DataBit;
	int		Parity;
#endif
	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */
#ifdef	WIN32
			SioPCMode= 3;
			SioPCOpenFlag= 1;
#else
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PC,RS_INIT,RS_9600,RS_DATA8,RS_NONE); */ /* RS_PC �� 1�϶� RS-232C */
#endif
		}else{						
#ifdef	WIN32
			SioPLCMode= 3;
			SioPLCOpenFlag= 1;
#else
			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
/*			B_RsModeSet(RS_PLC,RS_INIT,RS_9600,RS_DATA8,RS_NONE); */ /* RS_PLC �� 0�϶� RS-422 */
#endif
		}
#ifdef	WIN32
		while(1){
			if((iConnect & 1) == 0){
				if(SioPCOpenFlag == 0){
					break;
				}
			}else{
				if(SioPLCOpenFlag == 0){
					break;
				}
			}
	/*ksc20040714*/
			B_Delay(300);
		}
#endif
	}
	/* PLC Connect Check *(PlcType+2) ���� ������ �Ѱ� ���� */



	B_Bin2Hex(*(PlcType+2),2,&buff[1]);
	B_gstrcat(&buff[1],"RXP0");


	ret= SendRecPLCWithBCCCont(2,buff,PlcRecBuff,&Cnt,0);		

	ResetGroopSema();

	if(ret < 0){
		return(0);
	}

	/* PLC Connect Check */
	ret= 1;
	return(ret);
/*ksc20040715*/
/*���ؼ��� ���� ������ ������ Ȯ�εǸ� �����޼����� ǥ������ �ʴ´�. 
  ���� ������ ������ �����޼��� ǥ���Ѵ�.
  ret=1�϶� �������� ó�� 	*/
}
/******************************************/
static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif
#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif
}
/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;


	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i,j;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
/*ksc20040713*/
			ret = Address % 16;
			BitAndData = 1;
			for(j = 0; j < ret; j++){
				BitAndData <<= 1;
			}
			ret += sCnt;
			ret = ret / 8 + 1;
			BitRecCnt = ret;
/*ksc20040713*/
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrncmp(bPLCDeviceTbl[i].Device,Device,2) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ (Address/ 16) * 2;
				ret = Address % 16;
				BitAndData = 1;
				for(j = 0; j < ret; j++){
					BitAndData <<= 1;
				}
				ret += sCnt;
				ret = ret / 8 + 1;
				if((ret % 2) != 0){
					ret++;
				}
				BitRecCnt = ret;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrncmp(wPLCDeviceTbl[i].Device,Device,2) == 0){	/* mp���� ����ϴ� ����̽��ΰ� Ȯ�� */
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
/* �۽� ������ ���� */
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt,int StationNo)
{
	int		ret;
	int		DevAddr;
	char	buff[4];	

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	/* �Ƿ��� ��巹���� ����ϴ� ��巹���ΰ� ���� ret = 0 �϶� ����� */

	
	if(ret == 0){



/*ksc20040707*/
		switch(DevAddr)
		{
			case 0:
				DeviceStartPoint = 0;
				break;						
			case 1:
				DeviceStartPoint = 1;
				break;			
			case 2:
				DeviceStartPoint = 2;
				break;							

			default:
				break;
		}


		if(DevAddr == 0 || DevAddr == 1 || DevAddr == 2){
			/*sprintf(combuff,"01RX%s",DevTbl[DevAddr-100]);*/
			B_Bin2Hex(StationNo,2,buff);
			B_gstrcpy(combuff,buff);
			B_gstrcat(combuff,"RX");
#ifdef	ARM_CPU
			B_gstrcat(combuff,(char *)DevTbl[DevAddr].strData);
#endif
#ifdef	SH_CPU
			B_gstrcat(combuff,(char *)DevTbl[DevAddr]);
#endif
		}else{
			ret= -1; /* �ش� PLC�� 100�� �۽� ��巹���� ������ -1 ���� */ 
		}

	}
	return(ret);
}

static	void	SetReadData( unsigned char *SaveAddr, unsigned int data, int Cnt)
{
		int	i;
#ifdef	SH_CPU
	for(i = 0; i < Cnt; i++){
		*(unsigned char *)SaveAddr++ = (unsigned char)(data % 0x100);
		data = data / 0x100;
	}
#endif
#ifdef	ARM_CPU
	for(i = 0; i < Cnt/2; i++){
#ifdef	WIN32
		*(unsigned char *)SaveAddr++ = (unsigned char)(data % 0x10000)%0x100;
		*(unsigned char *)SaveAddr++ = (unsigned char)(data % 0x10000)/0x100;
		data = data / 0x10000;
#else
		*(unsigned char *)SaveAddr++ = (unsigned char)(data % 0x10000)/0x100;
		*(unsigned char *)SaveAddr++ = (unsigned char)(data % 0x10000)%0x100;
		data = data / 0x10000;
#endif
	}
#endif
}
/************************************/
/* PLC Read							*/
/************************************/
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;

	int		Cnt;
	unsigned char	*SaveAddr;

	unsigned int data1;
	char	work[16];
/*ksc20041117*/
	unsigned int dotdata;	
	char	dotpoint[2];	
	unsigned int errordata;
	char	errorcode[2];

	GetGroopSema();
	switch(mp->mpec){	/* mp->mpec�� 0�϶� Bit Device, 1�϶� Word Device */
	case PLC_BIT:		/* Bit Device */
		ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],mp->mext,(int)mp->mbuf[4]);
		Cnt = mp->mext;
		break;
	case PLC_WORD:		/* Word Device */
		/* �۽� ������ ���� */
		ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],mp->mext*2,(int)mp->mbuf[4]); 
		Cnt = mp->mext* 2;
		break;
	}
	SaveAddr = (unsigned char *)mp->mptr;
	if(ret == 0){	/* PLC���� ����ϴ� ��巹���� ��� 0 ���� */

		if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0) == 0){ /* ����ؼ� ���ϰ��� 0 �϶� ����Ÿ ó�� */ 
				for(i = 0; i < 7; i++){
					work[i] = rDataFx[i+8];
				}
				work[i]= 0;
			
				dotpoint[0] = rDataFx[15];
				dotpoint[1] = 0;					

				if(rDataFx[4]>= 0x30 && rDataFx[4] <=0x39)
				{  
						errorcode[0] = rDataFx[4];	
						errorcode[1] = 0;	
				}


				errordata= C_gatoi(errorcode);		/* error code */
				dotdata= C_gatoi(dotpoint);		/* �Ҽ��� �ڸ��� */				
				data1= C_gatoi(work);			/* ���簪 */

		switch(DeviceStartPoint)
		{
				case 0:
					SetReadData(SaveAddr,data1,Cnt);
					break;
				case 1:
					SetReadData(SaveAddr,dotdata,Cnt);
					break;
				case 2:
					if(rDataFx[4]>= 0x30 && rDataFx[4] <=0x39)
					{  
						SetReadData(SaveAddr,errordata,Cnt);
					}
						break;															
					default:
						break;
		}				

			
/*ksc20040715*/
		}else{
			ret = -1;
		}					
	}else if(ret == 1){		/* ����Device */
		ret= 0;

	}else{
		ret= 0;

	}
	ResetGroopSema();
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
static	int	ChangeIntData(char *data,int Cnt,int mode)
{
	int		iData;
	int		i;
	union{
		int		iData;
		char	cData[4];
	}rData;
	union{
		short		iData;
		char	cData[2];
	}rData_sort;

	if(Cnt == 1){		/* short */
		B_gmemset((char *)&rData_sort,0,sizeof(rData_sort));
#ifdef	SH_CPU
		if(mode == 1){
#endif
#ifdef	ARM_CPU
		if(mode != 1){
#endif
			for(i= 0; i < Cnt*2 && i < 2; i++){
				rData_sort.cData[1- i]= *data;
				data++;
			}
			iData = rData_sort.iData;

		}else{
				iData = *(short*)data;

		}
	}else{
		B_gmemset((char *)&rData,0,sizeof(rData));
#ifdef	SH_CPU
		if(mode == 1){
#endif
#ifdef	ARM_CPU
		if(mode != 1){
#endif
			for(i= 0; i < Cnt*2 && i < 4; i++){
				rData.cData[3- i]= *data;
				data++;
			}
			iData = rData.iData;
		}else{
				iData = *(int*)data;
		}
	}
	return(iData);
}


/****************************/
/* Make Write Device		*/
/****************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data,int StationNo)
{

	int		ret;
	int		DevAddr;

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);
	if(ret == 0){

	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;

	ret = 0;
	
	return(ret);
}
static	int	C_GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}


/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	switch(*CommMode){
	case 0:		/* Normal */
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:		/* Thru Mode */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			if((data == EOT) || (data == ETX)){
				*CommMode = 5;
			}
		}else{
			*CommMode = 0;
		}
		break;
	case 5:		/* CRC1 */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			*CommMode = 99;
			ret= 0;
		}else{
			*CommMode = 0;
		}
		break;
	}
	return(ret);
}
/************************************************/
/*	�O��?�v����								*/
/************************************************/
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	return(0);
}
/****************************************/
/*	�O��?�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Same Device Check */
/*	B_gmemset((char *)GrpPLCcombuf, 0, sizeof(GrpPLCcombuf));*/
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	return(0);
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int	ret;

	ret= 0;
	return(ret);
}
/************************************/
/*	�X��?��?�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	GetGroopSema();
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendPLCPCData();
	ResetGroopSema();
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
#endif

/*++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(1);
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif
#include	"hook_aplplc.h"
/****************************** END **********************/
