/*****************************************************************************************/
/*	PLC ����M �v���O��?(Sumson N70Plus)	*/
/*	2003.5.31				*/
/************************************************/
/*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		  */
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
/*  2006.04.13 32��Ʈ ����̽� ����� ��� ó�� ���� - ���� 2.6���� */
/*	2006.09.25 */
/*      �����͹� ���ø� ������ ���� ver 2.7�� �ϰ� ����	  */
/*  2007.01.30												*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����	*/
/*  2007.10.08																	*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����	  */
/*****************************************************************************************/

#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include	"hook_plcapl.h"

/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V3.3M"
/*****************************************************************************************/


#ifdef	WIN32
#define SGN_PLC		0			/* 0��° �ñ׳��� 0�϶� ���ø� ���� �ʵ��� ��. */
#endif								/* ���� �Ʒ� ������ ������ ����� �߰� �Ͽ��� */ 		

#define	MAX_RTY_COUNT		3	/* Retry count */

#define	MAX_BITCNT			80	/* �ѹ��� ������ �ִ� �ִ� ��Ʈī��Ʈ, ����� ����*/
#define	MAX_WORDCNT			32	/* �ִ� ���� ī��Ʈ */

#define	MAX_MON_BITCNT_PKG	16	/* ���� ��Ʈ ����� �ѹ��� ��� ������ �ִ� ��Ʈ�� */

#define	ONE_MON_BITCNT		16  /* ����� �ѹ��� ����Ҽ� �ִ� �ִ� ��Ʈ�� */
#define	MAX_MON_BITCNT		64	/* ����� ��� ������ �ִ� ��Ʈ��  */

#define	ONE_MON_WORDCNT		16	/* ����� �ѹ��� ����Ҽ� �ִ� �ִ� ����� */
#define	MAX_MON_WORDCNT		64	/* ����� ��� ������ �ִ� ����� */
								/* ���� ��ϰ����� ���� ��Ʈ ���� ���ļ� 160�������� 
                                   gDeviceAddr�ǹ��۰� 128�� �����̹Ƿ� ��Ʈ 64, ���� 64�� �� 128�������� ��� ���� */
#define	MAX_MONITOR_CNT     128 

#define	MAX_PBITCNT			16  /* ��Ʈ �������� ���� ����  */
#define	MAX_PWORDCNT		16	/* ���� �������� ���� ���� */

#define	MAX_WORD_CONT_CNT	4	/* ���� ���� */
#define	MAX_BIT_CONT_CNT	4	/* ��Ʈ ���� */

#ifdef SH_CPU
static	int			gSetNumBit;
static	int			gSetNumWord;
static	int			GroopSema;			/* Grooping Semafo */
#endif
#ifdef AMR_CPU
/* PLC COmBUFF �� ������ ����. ARM�ϰ�� ��ũ�� ��巹���� ���ϱ� ������ ���� ������ ��� */
#endif

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/****************************************************************************************************/
/* LGMKCNET ���� �������� �ҽ� ���� */
/****************************************************************************************************/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH1, PLCTYPE_CH2 ���� ����ϴ� �Լ� ���� */ 
/********************************/
/*	LG Cnet Command Table   	*/
/********************************/
#ifdef	SH_CPU
static	char	*CommTbl[8]={
		"rSS",		/*0 P,M */
		"rSB",		/*1 P,M */
		"wSS",		/*2 P,M */
		"wSB",		/*3 P,M */
		"x",		/*4 Monitor Entry */
		"y",		/*5 Monitor Read */
		"rST",		/*6 states Read */
};
#endif
#ifdef	ARM_CPU
static	const	PLC_CONST	CommTbl[8]={
	{"rSS",1},		/*0 P,M */
	{"rSB",1},		/*1 P,M */
	{"wSS",1},		/*2 P,M */
	{"wSB",1},		/*3 P,M */
	{"x",1},		/*4 Monitor Entry */
	{"y",1},		/*5 Monitor Read */
	{"rST",1},		/*6 states Read */
};
#endif

static	const	DEV_TBL bPLCDeviceTbl[16] = {
	{"P" ,0x0000,2},
	{"M" ,0x0000,3},
	{"K" ,0x0000,2},
	{"F" ,0x0000,2},
	{"L" ,0x0000,2},	
	{"T" ,0x0000,6},
	{"C" ,0x0000,6},
	{"S" ,0x0000,5},	
	{"UB" ,    0,4},
};
static	const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"P" ,0x0000,2},
	{"M" ,0x0000,3},
	{"K" ,0x0000,2},
	{"F" ,0x0000,2},
	{"L" ,0x0000,2},	
	{"T" ,0x0000,3},
	{"C" ,0x0000,3},
	{"D" ,0x0000,4},
	{"S" ,0x0000,2},	
	{"UW" ,    0,4},
};
#ifdef	SH_CPU
static	const int	iAndData[16]={
0x0001,0x0002,0x0004,0x0008,0x0010,0x0020,0x0040,0x0080,
0x0100,0x0200,0x0400,0x0800,0x1000,0x2000,0x4000,0x8000,
};
#endif
#ifdef	ARM_CPU
static	const PLC_INT_CONST	iAndData[16]={
	{0x0001,1},
	{0x0002,1},
	{0x0004,1},
	{0x0008,1},
	{0x0010,1},
	{0x0020,1},
	{0x0040,1},
	{0x0080,1},
	{0x0100,1},
	{0x0200,1},
	{0x0400,1},
	{0x0800,1},
	{0x1000,1},
	{0x2000,1},
	{0x4000,1},
	{0x8000,1},	
};
#endif

static int CH1_stationNo; /* sh 20090630 ���� ���� */ 

/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef	PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_19200;
	*DataBit= RS_DATA8;
	*Parity= ((RS_XONOFF << 16) |(RS_STOP01 << 8) | (RS_NONE << 0));		/* 20090527 */	
}
/**************************************************/
static	void	GetGroopSema(void)
{
	if(GroopSema == 0){		/* Grooping Sema */
	}else{
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
			B_Delay(10);
		}
	}
	GroopSema++;
}
static	void	ResetGroopSema(void)
{
	GroopSema= 0;
}

/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(data){
	case STX:
	case ENQ:
	case ACK:
	case NAK:
		*RecCnt= 0;			/* ?���X??�g */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 1;
		break;
	default:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		switch(*CommMode){
		case 1:
			if((data == EOT) || (data == ETX)){
				*CommMode = 2;
			}
			break;
		case 2:		/* BCC1 */
			*CommMode = 3;
			break;
		case 3:		/* BCC2 */
			*CommMode = 0;
			ret = 0;	
			break;
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���ʏ���							*/
/************************************/
static	void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	if(data < 0){			/* - check 041116 */
		
		data *= -1;
		buff[0]= '-';
		for(i= 1; i < cnt+1; i++){								/*cnt+1�̵� ������ */
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}else{
		for(i= 0; i < cnt; i++){
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}
	buff[i]= 0;
}

static	int	Bcd2Bin(unsigned int Address)
{
	int		i,ret;
	int		bairitu;

	bairitu= 1;
	ret= 0;
	for(i= 0; i < 8; i++){
		ret += (Address & 0x000f)* bairitu;
		Address = Address >> 4;
		bairitu *= 10;
		if(Address == 0){
			break;
		}
	}
	return(ret);
}
static	unsigned int	Hex2Bcd(int data)
{
	unsigned int	ret,i;
#ifdef	OLD
	ret= 0;
	if((data % 16) >= 10){
		ret = (data + 0x0006);
		if((data / 16) == 9){
			ret = (data + 0x0066);
		}
		if((data / 16) == 99){
			ret = (data + 0x0666);	
		}
		if((data / 16) == 999){
			ret = (data + 0x6666);	
		}		
	}else{
		ret = data;	
	}
#else
	ret= 0;
	for(i= 0; i < 4; i++){
		if(data == 0){
			break;
		}
		ret |= (data % 10) << (i*4);
		data /= 10;
	}
#endif
	return(ret);
}
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
static	int SetPLCBCC(char *buff,int cnt)
{
	int		i;
	unsigned char bcc;
	buff[0] = ENQ;
/*	for(i = 0; i < cnt; i++){*/
/*		OutBuf[i+1] = buff[i];*/
/*	}*/
	buff[cnt+1] = EOT;
	/* DATA->EOT(SUM) */
	bcc = 0;
	for(i = 0; i < cnt+2; i++){
		bcc += buff[i];
	}
	/*sprintf((char *)&OutBuf[cnt+1],"%02X",bcc&0x00ff);*/
	B_Bin2Hex(bcc&0x00ff,2,(char *)&buff[cnt+2]);
	/*OutBuf[cnt+2] = bcc;*/
	return(cnt + 4);
}




/************************************/
/*	PLC Send						*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		i;
	int		ret;
	int		rty_cnt;
	unsigned char bcc;
	unsigned char bcc1;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen(&combuf[1]));
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
		ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		if(ret == 0){
			/* DATA->EOT(SUM) */
			bcc= 0;
			for(i = 0; i < *Cnt-2; i++){
				bcc += rData[i];
			}
			bcc1= (unsigned char)B_Hex2Bin((char *)&rData[*Cnt-2]);
			if(bcc != bcc1){
				ret= NG; /* NG = -1; */
			}
		}
		if(ret == OK){
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}
	return(ret);
}

static	int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen(&combuf[1]));
	ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	return(ret);
}



/********************************************/
/*	Connection Proc							*/
/*	*PlcType:[0]->PlcType					*/
/*	         [1]->MyStation					*/
/*	         [2]->DstStation				*/
/********************************************/


static	int	C_Connection( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;
	char	buff[32];

	int		Speed;
	int		DataBit;
	int		Parity;

	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
	/*		B_RsModeSet(RS_PLC,RS_INIT,RS_19200,RS_DATA8,RS_NONE); */

		}else{						/* RS-422 */

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
	/*		B_RsModeSet(RS_PLC,RS_INIT,RS_19200,RS_DATA8,RS_NONE); */

		}
#ifdef	WIN32
		while(1){
			if(SioPLCOpenFlag == 0){
				break;
			}
			B_Delay(10);
		}
#endif
		B_Delay(200);
	}
	/* PLC Connect Check */
	monitorModeFlag= PlcType[4];		/* 20090704 */

	B_Bin2Hex(*(PlcType+2),2,&buff[1]); /* sh 20090630 ���� ó�� */
	CH1_stationNo = *(PlcType+2);
	B_gstrcat(&buff[1],"rST");

	ret= SendRecPLCWithBCC(2,(char *)buff,PlcRecBuff,&Cnt,0);
	if((ret == 0) && (PlcRecBuff[0] == ACK)){
		ret= 1;
	}else{
		ret= 0;
	}
	return(ret);
}


static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif

#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif

}
/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, char *Device)
{
	int		i;
	int		ret;

	ret = -1;
	/* Device Name */
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'U'){		/* IN DEVICE */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrcmp(bPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					break;
				}
			}
			if(DeviceFlag > 0){
/*				*DevAddr = OffSet+ Address;*/
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'U'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrcmp(wPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= wPLCDeviceTbl[i].flag;
					break;
				}
			}
			if(DeviceFlag > 0){
/*				*DevAddr = OffSet+ Address;*/
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}


/****************************/
/* Make Read Device			*/
/****************************/
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret,i;
	char	Device[4];
	char	buff[8];

	int		WordAdd;
	int		WordCnt;
	int		Address10;

	ret= MakePLCDevAddress(mode, pDevice, Address, Device);
	if(ret == 0){

		if(mode == 0){			/* Bit */
			if(sCnt == 1 && DeviceFlag != 6){

				B_Bin2Hex(pDevice[4],2,buff); /* sh 20090630 ���� ó�� */
				B_gstrcpy(combuff,buff);

/*				B_gstrcpy(combuff,"00");	*/		/* ���� */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[0]);	/* Command rSS */
#endif
#ifdef	ARM_CPU	
				B_gstrcat(combuff,CommTbl[0].strData);	/* Command rSS */
#endif
				B_gstrcat(combuff,"01");			/* ���ϼ� */
				B_gstrcat(combuff,"07");			/* �������� */
				B_gstrcat(combuff,"%");				
				B_gstrcat(combuff,Device);		/* �����̸� */ 
				B_gstrcat(combuff,"X");			/* Type Bit */ 
				Address10= Address/16;
				Bin2dec(Address10,3,buff);
				B_Bin2Hex(Address%16,1,&buff[3]);
				B_gstrcat(combuff,buff);			/* Address */

			}else if(DeviceFlag == 6){				/* T,C */
		
				B_Bin2Hex(pDevice[4],2,buff); /* sh 20090630 ���� ó�� */
				B_gstrcpy(combuff,buff);

/*				B_gstrcpy(combuff,"00");	*/		/* ���� */

#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[0]);	/* Command rSS */
#endif
#ifdef	ARM_CPU	
				B_gstrcat(combuff,CommTbl[0].strData);	/* Command rSS */
#endif
				B_gstrcat(combuff,"01");			/* ���ϼ� */
/*				Address *= 2;	*/
				
				for(i = 0; i < sCnt; i++){
					B_gstrcat(combuff,"07");	
					B_gstrcat(combuff,"%");				
					B_gstrcat(combuff,Device);		/* �����̸� */ 
					B_gstrcat(combuff,"X");			/* Type Bit */ 
					Bin2dec(Address,4,buff);
					B_gstrcat(combuff,buff);			/* Address */
					Address+=1;
				}
				B_Bin2Hex(i,2,buff);			/* ���ϼ� */	
				combuff[5] = buff[0];
				combuff[6] = buff[1];
				
			}else{								/* WORD */

				WordAdd = Address/16;	/* ���� ��Ʈ ��巹���� ���ι����� 16���� ������ ���� �����ּҰ� �ȴ� */
				/* ��Ʈ�� ����� �о� ó���ϹǷ� ���� ��Ʈ ��巹���� ���۹����� ���� ���� ��巹���� ���� �����Ƿ� ������ �ʿ��ؼ� */

				WordCnt = ((Address + sCnt)/16) - WordAdd + 1;

				B_Bin2Hex(pDevice[4],2,buff); /* sh 20090630 ���� ó�� */
				B_gstrcpy(combuff,buff);

/*				B_gstrcpy(combuff,"00");	*/		/* ���� */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[1]);	/* Command rSS */
#endif
#ifdef	ARM_CPU	
				B_gstrcat(combuff,CommTbl[1].strData);	/* Command rSB */
#endif
				B_gstrcat(combuff,"07");			/* �������� */
				B_gstrcat(combuff,"%");				
				B_gstrcat(combuff,Device);		/* �����̸� */ 
				B_gstrcat(combuff,"W");			/* Type Word */ 
				Bin2dec(WordAdd,4,buff);			/* Data Count */
				B_gstrcat(combuff,buff);
				B_Bin2Hex(WordCnt,2,buff);			/* Data Count */
				B_gstrcat(combuff,buff);

			}
		}else{

			/*sprintf(combuff,"rM%s00%02X",abuff,sCnt);*/
			B_Bin2Hex(pDevice[4],2,buff); /* sh 20090630 ���� ó�� */
			B_gstrcpy(combuff,buff);

/*			B_gstrcpy(combuff,"00");  */			/* ���� */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[1]);	/* Command rSS */
#endif
#ifdef	ARM_CPU	
				B_gstrcat(combuff,CommTbl[1].strData);	/* Command rSB */
#endif
			B_gstrcat(combuff,"07");			/* �������� */
			B_gstrcat(combuff,"%");				
			B_gstrcat(combuff,Device);		/* �����̸� */ 
			B_gstrcat(combuff,"W");			/* Type Word */ 
			Bin2dec(Address,4,buff);
			B_gstrcat(combuff,buff);			/* Address */
			B_Bin2Hex(sCnt,2,buff);			/* Data Count */
			B_gstrcat(combuff,buff);			 	

		}
	}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
static	int	BitReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j;
	int		Cnt,dCnt;

	unsigned char	*SaveAddr;
	unsigned short	rdata;
	char	Device[4];
	int		Address;
	int		BitAdd;
	int		WordAdd;
	int		WordCnt;

	Address= mp->mpar;			/* BCD Address */
	ret= MakePLCDevAddress(0, (char *)mp->mbuf, Address, Device);		
	Cnt = mp->mext;

	if(Cnt == 1 && DeviceFlag != 6){
		ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],mp->mext);
		if(ret != 0){	ret= -1;	return(ret);	}
		SaveAddr = (unsigned char *)mp->mptr;
		i= B_gstrlen((char *)&PlcSendBuff[1]);
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0);
		if((ret != 0) || (rDataFx[0] != 0x06)){	ret= -1;	return(ret);	}
		for(i = 0; i < Cnt; i++){
			if(rDataFx[i+11] == '1'){	*(unsigned char *)SaveAddr++ = 1;	}
			else{						*(unsigned char *)SaveAddr++ = 0;	}
		}
	}else{	
		if(DeviceFlag == 6){	/* T, C Bit �� ��쿡 Cnt�� 1�̻��϶�  */
								/* ����̽� ���̺� ���� */
			dCnt= mp->mext;
			while(1){
				if(CommonArea.PcUpDownMode != 0){	return(0);	}
				if(dCnt > MAX_MON_BITCNT_PKG){	dCnt -= MAX_MON_BITCNT_PKG;	mp->mext= MAX_MON_BITCNT_PKG;	}
				else{							mp->mext= dCnt;				dCnt = 0;					}
				Cnt= mp->mext;
				ret = MakePLCReadData(0,(char *)mp->mbuf,Address,(char *)&PlcSendBuff[1],mp->mext);
				if(ret != 0){	ret= -1;	break;		}
				SaveAddr = (unsigned char *)mp->mptr;
				i= B_gstrlen((char *)&PlcSendBuff[1]);
				ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0);
				if((ret != 0) || (rDataFx[0] != 0x06)){	ret= -1;	break;		}
				for(i = 0; i < Cnt; i++){
					if(rDataFx[i*4+11] == '1'){	*(unsigned char *)SaveAddr++ = 1;	}
					else{						*(unsigned char *)SaveAddr++ = 0;	}
				}
				if(dCnt == 0){			break;		}

				Address += MAX_MON_BITCNT_PKG;
				mp->mpar= Address;
				mp->mptr= (void *)((char *)mp->mptr + MAX_MON_BITCNT_PKG);
			}
		}else{	/* Bit�� Word�� ���� */

			dCnt= mp->mext;
			/* ���� ��Ʈ �� */

			while(1){

				if(CommonArea.PcUpDownMode != 0){	return(0);		}

				if(dCnt > MAX_BITCNT){		dCnt -= MAX_BITCNT;		mp->mext= MAX_BITCNT;	}
				else{						mp->mext= dCnt;			dCnt = 0;				}
				
				WordAdd = Address/16;	/* ���� ��Ʈ ��巹���� ���ι����� 16���� ������ ���� �����ּҰ� �ȴ� */
				BitAdd =  Address%16;	/* ���� ��Ʈ ��巹���� ���ι����� 16���� ���� �������� ��Ʈ���̴� */
				/* ��Ʈ�� ����� �о� ó���ϹǷ� ���� ��Ʈ ��巹���� ���۹����� ���� ���� ��巹���� ���� �����Ƿ� ������ �ʿ��ؼ� */

				WordCnt = ((Address + mp->mext)/16) - WordAdd + 1;
				/* ���� �о�;ߵ� ���� ī��Ʈ�� */

				Cnt = mp->mext;
				ret = MakePLCReadData(0,(char *)mp->mbuf,Address,(char *)&PlcSendBuff[1],Cnt);
				if(ret != 0){				break;		}
				SaveAddr = (unsigned char *)mp->mptr;
				ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0);
				if(ret != 0){				ret= -1;	break;	}
				if(rDataFx[0] != 0x06){		ret= -1;	break;	}
				for(i = 0; i < WordCnt*2; i++){
					rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+10]);
				}
				/* �о�� ����Ÿ�� ����Ʈ ������ ���� ī��Ʈ * 2��ŭ ���̳ʸ��� ��ȯ */

#ifdef	SH_CPU
				BitAndData = iAndData[BitAdd];
#endif
#ifdef	ARM_CPU /* ARMȯ�濡 ���� �ҽ� ���� �ʿ� */
				BitAndData = iAndData[BitAdd].strData;
#endif
				rdata= (rDataFx[1]) + (rDataFx[0]<< 8);
				/* ���� ����Ʈ ��������Ʈ�� �ٲپ ����Ʈ ����Ÿ�� ���� ����Ÿ�� �ٲ� */
				for(i = 0,j= 1; i < Cnt; i++){
					if(rdata & BitAndData){	*(unsigned char *)SaveAddr++ = 1;	}
					else{					*(unsigned char *)SaveAddr++ = 0;	}
					BitAndData <<= 1;
					if(BitAndData > 0x8000){
						BitAndData = 1;
						rdata= (rDataFx[j*2+1]) + (rDataFx[j*2]<< 8);
						j++;
					}
				}
				if(dCnt == 0){			break;		}
				Address += MAX_BITCNT;
				mp->mptr= (void *)((char *)mp->mptr + MAX_BITCNT);
			}
		}
	}
	return(ret);
}
static	int	WordReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt,dCnt;

	unsigned char	*SaveAddr;
	int		Address;

	Address= mp->mpar;
	dCnt= mp->mext;
	while(1){
		if(CommonArea.PcUpDownMode != 0){	return(0);		}

		if(dCnt > MAX_WORDCNT){	dCnt -= MAX_WORDCNT;	mp->mext= MAX_WORDCNT;	}
		else{					mp->mext= dCnt;			dCnt = 0;				}
		ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],mp->mext);
		if(ret != 0){			break;			}
		Cnt = mp->mext;
		SaveAddr = (unsigned char *)mp->mptr;
		i= B_gstrlen((char *)&PlcSendBuff[1]);
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0);
		if((ret != 0) || (rDataFx[0] != 0x06)){	ret= -1;	break;	}
		for(i = 0; i < Cnt*2; i++){
			rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+ 10]);
			/* ���ŵ���Ÿ�� ���� Hexasc ����Ÿ�� ���̳ʸ��� ��ȯ�ؼ� ���� ���ۿ� ���� */
		}
		for(i = 0; i < Cnt; i++){
#ifdef SH_CPU
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
			*(unsigned char *)SaveAddr++ = rDataFx[i*2];
#endif
#ifdef ARM_CPU
#ifdef WIN32
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
			*(unsigned char *)SaveAddr++ = rDataFx[i*2];
#else
			*(unsigned char *)SaveAddr++ = rDataFx[i*2];
			*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
#endif
#endif

			/* ���ŵ���Ÿ�� APL Address�� ������ ������ �ٲپ �־��� */
		}
		if(dCnt == 0){			break;		}
		Address += MAX_WORDCNT;
		mp->mpar= Address;
		mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
	}
	return(ret);
}
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;

	switch(mp->mpec){
	case PLC_BIT:		ret= BitReadProc(mp,rDataFx,PlcType);
						break;
	case PLC_WORD:		ret= WordReadProc(mp,rDataFx,PlcType);
						break;
	}
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	char	Device[4];
	char	buff[8];
	int		Address10;

	ret= MakePLCDevAddress(mode, pDevice, Address, Device);
	if(ret == 0){
		
		if(mode == 0){		/* BIT */
			if(Cnt == 1 && DeviceFlag != 6){

				B_Bin2Hex(pDevice[4],2,buff); /* sh 20090630 ���� ó�� */
				B_gstrcpy(combuff,buff);
				
/*				B_gstrcpy(combuff,"00");	*/		/* ���� */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[2]);	/* Command rSS */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[2].strData);	/* Command rSS */
#endif
				B_gstrcat(combuff,"01");			/* ���ϼ� */
				B_gstrcat(combuff,"07");			/* �������� */
				B_gstrcat(combuff,"%");				
				B_gstrcat(combuff,Device);		/* �����̸� */ 
				B_gstrcat(combuff,"X");			/* Type Bit */ 

				Address10= Address/16;
				Bin2dec(Address10,3,buff);
				B_Bin2Hex(Address%16,1,&buff[3]);

				B_gstrcat(combuff,buff);			/* Address */
				B_Bin2Hex(*data & 0xff,2,buff);
				B_gstrcat(combuff,buff);
			}else{
				if(Cnt == 1 && DeviceFlag == 6){	/* T, C Bit �� ��쿡 Cnt�� 1�̻��϶�  */

/*					Address *= 2;	*/
					B_Bin2Hex(pDevice[4],2,buff); /* sh 20090630 ���� ó�� */
					B_gstrcpy(combuff,buff);

/*					B_gstrcpy(combuff,"00");	*/		/* ���� */
#ifdef	SH_CPU
					B_gstrcat(combuff,CommTbl[2]);	/* Command rSS */
#endif
#ifdef	ARM_CPU
					B_gstrcat(combuff,CommTbl[2].strData);	/* Command rSS */
#endif
					B_gstrcat(combuff,"01");			/* ���ϼ� */
					B_gstrcat(combuff,"07");			/* �������� */
					B_gstrcat(combuff,"%");				
					B_gstrcat(combuff,Device);		/* �����̸� */ 
					B_gstrcat(combuff,"X");			/* Type Bit */ 
					Bin2dec(Address,4,buff);
					B_gstrcat(combuff,buff);			/* Address */
					B_Bin2Hex(*data & 0xff,2,buff);
					B_gstrcat(combuff,buff);

				}
			}
		}else{		/* WORD */
			B_Bin2Hex(pDevice[4],2,buff); /* sh 20090630 ���� ó�� */
			B_gstrcpy(combuff,buff);

/*			B_gstrcpy(combuff,"00");	*/		/* ���� */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[3]);	/* Command rSS */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[3].strData);	/* Command rSS */
#endif
			B_gstrcat(combuff,"07");
			B_gstrcat(combuff,"%");
			B_gstrcat(combuff,Device);
			B_gstrcat(combuff,"W");
			Bin2dec(Address,4,buff);
			B_gstrcat(combuff,buff);
			B_Bin2Hex(Cnt,2,buff);
			B_gstrcat(combuff,buff);	

			for(i= 0; i < Cnt; i++){
#ifdef	SH_CPU
				/*sprintf(buff,"%02X",data[i] & 0xff);*/
				B_Bin2Hex(data[i*2+1] & 0xff,2,buff);
				B_gstrcat(combuff,buff);
				B_Bin2Hex(data[i*2] & 0xff,2,buff);
				B_gstrcat(combuff,buff);
#endif
#ifdef	ARM_CPU /* ARMȯ�濡 ���� �ҽ� ���� �ʿ� */
#ifdef	WIN32
				/*sprintf(buff,"%02X",data[i] & 0xff);*/
				B_Bin2Hex(data[i*2+1] & 0xff,2,buff);
				B_gstrcat(combuff,buff);
				B_Bin2Hex(data[i*2] & 0xff,2,buff);
				B_gstrcat(combuff,buff);
#else
				/*sprintf(buff,"%02X",data[i] & 0xff);*/
				B_Bin2Hex(data[i*2] & 0xff,2,buff);
				B_gstrcat(combuff,buff);
				B_Bin2Hex(data[i*2+1] & 0xff,2,buff);
				B_gstrcat(combuff,buff);
#endif
#endif
			}
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,dCnt,bCnt;
	char	Device[4];
/*	int		DevInfo;*/
	int		Address;
/*	int		UsrAddress;*/
/*	int		signal;*/
	int		i;
	switch(mp->mpec){

	case PLC_BIT:		/* Bit Device */

		Address= mp->mpar;			/* BCD Address */
/*		ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);*/
		/* BCD Address�� Bin���� ����, &Address�� ���̳ʸ��� ���ϵ� */
		ret= MakePLCDevAddress(0, (char *)mp->mbuf, Address, Device);			
		Cnt = mp->mext;

		if(Cnt == 1 && DeviceFlag != 6){		
	
			ret = MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)&PlcSendBuff[1],(char *)mp->mptr);
			if(ret == 0){
				Cnt= B_gstrlen((char *)&PlcSendBuff[1]);
				ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0);
			}else if(ret == 1){		/* ����Address */
				ret= -1;
			}
		}else if(Cnt == 1 && DeviceFlag == 6){	/* T, C Bit �� ��쿡 Cnt�� 1�̻��϶�  */
									/* ����̽� ���̺� ���� */
			ret = MakePLCWriteData(0,(char *)mp->mbuf,Address,mp->mext,(char *)&PlcSendBuff[1],(char *)mp->mptr);
			if(ret == 0){
				Cnt= B_gstrlen((char *)&PlcSendBuff[1]);
				ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0);
			}else if(ret == 1){		/* ����Address */
				ret= -1;
			}
		}else if(Cnt != 1){
			bCnt = Cnt;
			for(i=0 ; i<bCnt ; i++){ 
				ret = MakePLCWriteData(0,(char *)mp->mbuf,Address,1,(char *)&PlcSendBuff[1],(char *)mp->mptr+i);
				if(ret == 0){
					Cnt= B_gstrlen((char *)&PlcSendBuff[1]);
					ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0);
				}else if(ret == 1){		/* ����Address */
					ret= -1;
				}
				Address += 1;
			}
		}else{
		}

		break;
	case PLC_WORD:		/* Word Device */
		Address= mp->mpar;
/*		ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);*/
		dCnt= mp->mext;
		while(1){

/*			signal = B_ReadSignal(SGN_PLC);
			if((signal & 0x0001) == 0){
				return(0);			
			}		
*/
			if(CommonArea.PcUpDownMode != 0){			/* 071102 */
				return(0);
			}
			
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)&PlcSendBuff[1],(char *)mp->mptr);
			if(ret == 0){
				Cnt= B_gstrlen((char *)&PlcSendBuff[1]);
				ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0);
			}else if(ret == 1){		/* ����Address */
				ret= -1;
				break;
			}
			if(dCnt == 0){
				break;
			}
			Address += MAX_WORDCNT;
/*			UsrAddress= plcSetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);*/
			mp->mpar= Address;
			mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
		}
		break;
	}
	return(ret);
}
static	int	C_GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}

/* ���� �ҽ� �� */
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH1������ ����ϴ� �Լ� ���� */ 

#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
/************************************/
/*	Device & Address Change			*/
/************************************/
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
//	int	ret;

//	ret = -1;
//	switch(*CommMode){
//	case 0:		/* Normal */
//		switch(data){
//		case STX:
//		case ENQ:
//		case ACK:
//		case NAK:
//			*CommMode = 4;
//			*Sio1RecCnt = 0;
//			Sio1RecBuff[(*Sio1RecCnt)++] = data;
//		}
//		break;
//	case 4:		/* Thru Mode */
//		if(*Sio1RecCnt < PLC_BUF_MAX){
//			Sio1RecBuff[(*Sio1RecCnt)++] = data;
//			if((data == EOT) || (data == ETX)){
//				*CommMode = 99;
//				ret = 0;	/* Pendding Req */
//			}
//		}else{
//			*CommMode = 0;
//		}
//		break;
//	}
//	return(ret);
	int	ret= -1;

	switch(data){
	case STX:
	case ENQ:
	case ACK:
	case NAK:
		*Sio1RecCnt= 0;			/* ?���X??�g */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		*CommMode = 4;
		break;
	default:
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		switch(*CommMode){
		case 4:
			if((data == EOT) || (data == ETX)){
				*CommMode = 5;
			}
			break;
		case 5:		/* BCC1 */
			*CommMode = 6;
			break;
		case 6:		/* BCC2 */
			*CommMode = 99;
			ret = 0;	
			break;
		}
		break;
	}
	return(ret);
}

/************************************************/
/*	�O��?�v����								*/
/************************************************/
int	MakePLCGroupAddr(int mode, int First, char *pDevice, int Address, char *combuff)
{
	int		ret;

	char	Device[4];
	char	buff[8];



	ret= MakePLCDevAddress(mode, pDevice, Address, Device);
	if(ret == 0){

		if(mode == 0){		/* BIT */

			if(First == 0){
				B_Bin2Hex(CH1_stationNo,2,buff); /* sh 20090630 ���� ó�� */

				B_gstrcpy(combuff,buff);

/*				B_gstrcpy(combuff,"00");		*/	/* ���� */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[4]);	/* Command x */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[4].strData);	/* Command x */
#endif
				B_Bin2Hex(gSetNumBit,2,buff);		/* ��Ϲ�ȣ */
				B_gstrcat(combuff,buff);
				B_gstrcat(combuff,"RSS");	/* ��� ���ɾ� */
				Bin2dec(First+1,2,buff);		/* ���ϼ� */	
				B_gstrcat(combuff,buff);
				gSetNumBit++;
			}

			B_gstrcat(combuff,"07");			/* �������� */
			B_gstrcat(combuff,"%");				
			B_gstrcat(combuff,Device);		/* �����̸� */ 
			B_gstrcat(combuff,"X");			/* Type Bit */ 

			if(DeviceFlag == 6){
				Address = Bcd2Bin(Address);			/* Address */	
/*				Address*=2;	*/
				Bin2dec(Address,4,buff);
				B_gstrcat(combuff,buff);
			}else{
				B_Bin2Hex(Address,4,buff);			/* Address */	
				B_gstrcat(combuff,buff);
			}
			

			B_Bin2Hex(First+1,2,buff);			/* ���ϼ� */	
			combuff[8] = buff[0];
			combuff[9] = buff[1];

		}else{		/* WORD */

			if(First == 0){

				B_Bin2Hex(CH1_stationNo,2,buff); /* sh 20090630 ���� ó�� */

				B_gstrcpy(combuff,buff);

/*				B_gstrcpy(combuff,"00");	*/		/* ���� */
#ifdef	SH_CPU
				B_gstrcat(combuff,CommTbl[4]);	/* Command x */
#endif
#ifdef	ARM_CPU
				B_gstrcat(combuff,CommTbl[4].strData);	/* Command x */
#endif
				B_Bin2Hex(gSetNumWord+gSetNumBit,2,buff);		/* ��Ϲ�ȣ */
				B_gstrcat(combuff,buff);
				B_gstrcat(combuff,"RSS");	/* ��� ���ɾ� */
				Bin2dec(First+1,2,buff);		/* ���ϼ� */	
				B_gstrcat(combuff,buff);
				gSetNumWord++;
			}

			B_gstrcat(combuff,"07");			/* �������� */
			B_gstrcat(combuff,"%");				
			B_gstrcat(combuff,Device);		/* �����̸� */ 
			B_gstrcat(combuff,"W");			/* Type Bit */ 
			B_Bin2Hex(Address,4,buff);			/* Address */	
			B_gstrcat(combuff,buff);

			B_Bin2Hex(First+1,2,buff);			/* ���ϼ� */	
			combuff[8] = buff[0];
			combuff[9] = buff[1];			

		}
	}
	return(ret);
}
/****************************************/
/*	Monitor Reset�쐬					*/
/****************************************/
void	RestMonitor(void)
{

}
/****************************************/
/*	Bit Monitor�쐬						*/
/****************************************/
void	MakeBitMonitor(void)
{
	int		i;
	int		StartIdx;
/*	int		signal;*/

	StartIdx= 0;
	/*Bit Device Set*/
	B_gmemset((char *)PlcSendBuff,0,sizeof(PlcSendBuff));
	for(i = 0; i < DeviceCntSys; i++){
/*
		signal = B_ReadSignal(SGN_PLC);
		if((signal & 0x0001) == 0){
			return;			
		}		
*/
		if(CommonArea.PcUpDownMode != 0){			/* 071102 */
			return;
		}
		/* 20060411 */
		if((DeviceDataSys[i].DevFlag == 0) &&				/* 0:Bit / 1:Word */
			(DeviceDataSys[i].SameDevInf == 0) &&			/* 0:Start Device 1:Same Device, 2:Continue Device, 3:Patten Device */ 
			(DeviceDataSys[i].Continus == 0) &&				/* Continue or Patten */
			(DeviceDataSys[i].DevName[0] != 0x7f) &&		/* DevName[0] : Device Index */
			(DeviceDataSys[i].DevCnt == 1)){				/* Device Count */

			if(MakePLCGroupAddr(DeviceDataSys[i].DevFlag, StartIdx, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, (char *)&PlcSendBuff[1]) != 0){
				continue;	/* ��������� ��Ʈ ����̽� ��� */
			}
			gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
			DeviceDataSys[i].SameDevInf= -1;
			gDeviceCnt++;
			gDeviceCntBit++;
			StartIdx++;
			if(StartIdx >= ONE_MON_WORDCNT){
				StartIdx= B_gstrlen((char *)&PlcSendBuff[1]);
				SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0);
				StartIdx= 0;
			}
			if(gDeviceCnt >= MAX_MONITOR_CNT){
				break;
			}
		}
	}
	if(StartIdx != 0){
		StartIdx= B_gstrlen((char *)&PlcSendBuff[1]);
		SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0);
	}
}
/****************************************/
/*	Word Monitor�쐬						*/
/****************************************/
void	MakeWordMonitor(void)
{
	int		i, j;
	int		StartIdx;
/*	int		signal;*/
	int		ChangeDevAddress;
	/*Word MONITOR Device Set*/
	StartIdx= 0;
	B_gmemset((char *)PlcSendBuff,0,sizeof(PlcSendBuff));
	for(i = 0; i < DeviceCntSys; i++){

/*		signal = B_ReadSignal(SGN_PLC);
		if((signal & 0x0001) == 0){
			return;				
		}		
*/
		if(CommonArea.PcUpDownMode != 0){			/* 071102 */
			return;
		}
		/* 20060411 */
		if((DeviceDataSys[i].DevFlag == 1) &&
			(DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus == 0) &&
			(DeviceDataSys[i].DevName[0] != (unsigned char)0xef) &&
			(DeviceDataSys[i].DevCnt < MAX_WORD_CONT_CNT)){

			if(gDeviceCnt+(DeviceDataSys[i].DevCnt) > MAX_MONITOR_CNT){				
				break;
			}	

			for(j = 0; j < DeviceDataSys[i].DevCnt; j++){

				ChangeDevAddress = Hex2Bcd(DeviceDataSys[i].DevAddress + j);

				if(MakePLCGroupAddr(DeviceDataSys[i].DevFlag, StartIdx, (char *)DeviceDataSys[i].DevName, ChangeDevAddress, (char *)&PlcSendBuff[1]) != 0){
					continue;
				}
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData + j*2;
				DeviceDataSys[i].SameDevInf= -1;	/* ����Ϳ��� ����ϴ� ����̽��� �ǹ� */
				gDeviceCnt++;
				StartIdx++;
				gDeviceCntWord++;
				if(StartIdx >= ONE_MON_WORDCNT){
					StartIdx= B_gstrlen((char *)&PlcSendBuff[1]);
					SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0);
					StartIdx= 0;
				}
				if(gDeviceCnt >= MAX_MONITOR_CNT){				
					break;
				}
			}
		}
	}
/* ���� ����� ����� ������ �ϳ��� ������ ����� �� */
	if(StartIdx != 0){
		StartIdx= B_gstrlen((char *)&PlcSendBuff[1]);
		SendRecPLCWithBCC(2,(char *)PlcSendBuff,PlcRecBuff,&StartIdx,0);
	}
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			return;	
		}
		if(i > 0){
			if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
						MyAddress= DeviceDataSys[i].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
					MyAddress= DeviceDataSys[i].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN			   */
/*	2006.03.31 makebitpatarn �ϰ� ����         */
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/*	2006.03.31 makewordpatarn �ϰ� ����        */
/***************************************************/
void	MakeWordPatarn(int Start)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/***************************************************/
void	ClearBWContinue(void)
{
	int		i,j,idx;

	for(i= 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus != 0)){
			/* Continue */
			if(DeviceDataSys[i].DevFlag == 0){		/* BIT */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_BIT_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}else{									/* WORD */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_WORD_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	�O��?�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Set Group */
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gDeviceCnt= 0;

	gSetNumBit= 0;
	gSetNumWord= 0;

	/* Same Device Check */
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}

	if(monitorModeFlag != MONITOR){			/* 20090704 */
	/* Monitor Reset */
	RestMonitor();
	/* Bit Check */
	}

#ifdef	OLD
	if(BitCnt <= MAX_MON_BITCNT){
		if(monitorModeFlag == MONITOR){			/* 20090704 */
			MakeBitContinue();
		}else{
			MakeBitMonitor();
		}
	}else{
		MakeBitContinue();
		if(monitorModeFlag != MONITOR){			/* 20090704 */
			MakeBitMonitor();
		}
	}
#else
		MakeBitContinue();
#endif

#ifndef	OLD
	/* Word Check */
	if(WordCnt <= MAX_MON_WORDCNT){
		if(monitorModeFlag == MONITOR){			/* 20090704 */
			MakeWordContinue(TotalBitCnt);
		}else{
			MakeWordMonitor();
		}

	}else{
		MakeWordContinue(TotalBitCnt);

		if(monitorModeFlag != MONITOR){			/* 20090704 */
			MakeWordMonitor();
		}
	}
#else
		MakeWordContinue(TotalBitCnt);
#endif

	/* Continue MAX Check */
	ClearBWContinue();
	/* Bit Patarn */
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	/* Word Patarn */
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}

	return(0);
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int		Cnt,ret;


	int		i,j,k;
	int		idx;
/*	int		signal;*/

	unsigned short	rdata;

	char	buff[8];

	if(monitorModeFlag == MONITOR){			/* 20090704 */
		return(0);
	}

	if(gDeviceCnt == 0){
		return(0);
	}

	j= 0;

	for(k= 0; k < gSetNumBit; k++){

/*		signal = B_ReadSignal(SGN_PLC);
		if((signal & 0x0001) == 0){
			return(0);			
		}
*/
		if(CommonArea.PcUpDownMode != 0){			/* 071102 */
			return(0);
		}

		B_Bin2Hex(CH1_stationNo,2,buff); /* sh 20090630 ���� ó�� */
		PlcSendBuff[1]= buff[0];		/* Start */
		PlcSendBuff[2]= buff[1];		/* SA */
		PlcSendBuff[3]= 'y';		/* SA */
		Bin2dec(k,2,buff);		
		PlcSendBuff[4]= buff[0];		/* Command */
		PlcSendBuff[5]= buff[1];
		PlcSendBuff[6]= 0;
		
		Cnt= 5;


		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)PlcSendDevData,&Cnt,0);
		if((ret == 0) && (PlcSendDevData[0] == 0x06)){		/* $ */
			idx= 6;			/* BIT POS */

			rdata = B_LHexAsToBin((char *)&PlcSendDevData[idx],2);
			idx += 4;		/* Word Count */
			if(rdata != 0){
				for(i= 0; i < rdata; i++,j++){
					*(gDeviceAddr[j]) = B_Hex2Bin((char *)&PlcSendDevData[idx]);
					idx += 4;
				}
			}
		}else{
			ret = -1;
		}
	}
	
	j=gDeviceCntBit;

	for(k= gSetNumBit; k < gSetNumBit+gSetNumWord; k++){

/*		signal = B_ReadSignal(SGN_PLC);
		if((signal & 0x0001) == 0){
			return(0);			
		}
*/
		if(CommonArea.PcUpDownMode != 0){			/* 071102 */
			return(0);
		}
		B_Bin2Hex(CH1_stationNo,2,buff); /* sh 20090630 ���� ó�� */
		PlcSendBuff[1]= buff[0];
		PlcSendBuff[2]= buff[1];
		PlcSendBuff[3]= 'y';		/* SA */
		Bin2dec(k,2,buff);		
		PlcSendBuff[4]= buff[0];		/* Command */
		PlcSendBuff[5]= buff[1];
		PlcSendBuff[6]= 0;

		Cnt= 5;
		
		ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)PlcSendDevData,&Cnt,0);
		if((ret == 0) && (PlcSendDevData[0] == 0x06)){		/* $ */
			idx= 6;			/* BIT POS */
			
			rdata = B_LHexAsToBin((char *)&PlcSendDevData[idx],2);
			idx += 4;		/* Word Count */
			if(rdata != 0){
				for(i= 0; i < rdata; i++,j++){
#ifdef	SH_CPU
					*(gDeviceAddr[j]+ 1) = B_Hex2Bin((char *)&PlcSendDevData[idx]);
					idx += 2;
					*(gDeviceAddr[j]+ 0) = B_Hex2Bin((char *)&PlcSendDevData[idx]);
					idx += 4;
#endif
#ifdef	ARM_CPU
#ifdef	WIN32
					*(gDeviceAddr[j]+ 1) = B_Hex2Bin((char *)&PlcSendDevData[idx]);
					idx += 2;
					*(gDeviceAddr[j]+ 0) = B_Hex2Bin((char *)&PlcSendDevData[idx]);
					idx += 4;
#else
					*(gDeviceAddr[j]+ 0) = B_Hex2Bin((char *)&PlcSendDevData[idx]);
					idx += 2;
					*(gDeviceAddr[j]+ 1) = B_Hex2Bin((char *)&PlcSendDevData[idx]);
					idx += 4;
#endif
#endif
				}
			}
		}else{
			ret = -1;
			break;
		}
	}

		return(ret);
}
/************************************/
/*	�X��?��?�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	GetGroopSema();
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendThruePLC(2,*OutCnt,OutBuff,3000); /*20090706*/
	ResetGroopSema();

#ifdef	OLDSOURCE
#endif
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}

/*++++++++++++++++++++++++++++++++++++*/
#endif

/* PLCTYPE_CH1������ ����ϴ� �Լ� �� */
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLCTYPE_CH2������ ����ϴ� �Լ� ���� */ 

#ifdef	PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif

#include	"hook_aplplc.h"

/****************************** END **********************/
