/*****************************************************************************************/
/*	PLC ����M �v���O��?(AUTONICS)		*/
/*	2003.5.31				*/
/************************************************/
/*	2011.10.27 ������ ���������� ����ϴ� ���ӱ��� ������ �ϰ� 2.0���� ����		  */
/*             ������ ����̽� ��Ī�� ���� ��Ŀ��� ������ �������ݿ� ���� �ϰ� �����߱� ����   */
/*****************************************************************************************/

#include	"define.h"
#include	"GpCommon.h"
#include	"PlcCommBuff.h"
#include	"mail.h"
#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include "hook_plcapl.h"

/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V2.0M"
/*****************************************************************************************/

/*--------------------------------------------------------------*/
/*--------------------------------------------------------------*/
/* ��� conut ����				    							*/
/*--------------------------------------------------------------*/
/*		#define	MAX_RTY_COUNT	3								*/
/*		#define	MAX_BITCNT		128								*/
/*		#define	MAX_WORDCNT		16								*/
/*--------------------------------------------------------------*/
/* Modbus device ����			    							*/
/* Coil(Discreate) output	 R/W			00001~09999			*/
/* Coil(Discreate) input	 R				10001~19999   		*/
/* Input Register			 R				30001~39999	   		*/
/* Holding Register			 R/W			40001~49999	   		*/
/*--------------------------------------------------------------*/
/*		#define	READ_COIL_OUTPUT_MIN			00001			*/
/*		#define	READ_COIL_OUTPUT_MAX			09999			*/
/*		#define	READ_COIL_INPUT_MIN				10001			*/
/*		#define	READ_COIL_INPUT_MAX				19999			*/
/*		#define	READ_INPUT_REGISTER_MIN			30001			*/	
/*		#define	READ_INPUT_REGISTER_MAX			39999			*/	
/*		#define	READ_HOLDING_REGISTER_MIN		40001			*/		
/*		#define	READ_HOLDING_REGISTER_MAX		49999			*/
/*																*/
/*		#define	WRITE_COIL_OUTPUT_MIN			00001			*/	
/*		#define	WRITE_COIL_OUTPUT_MAX			09999			*/	
/*		#define	WRITE_HOLDING_REGISTER_MIN		40001			*/	
/*		#define	WRITE_HOLDING_REGISTER_MAX		49999			*/
/*																*/
/*--------------------------------------------------------------*/
/* ��Ž� ���� ��巹�� ����(AC : ADDRESS CHANGE)				*/
/*--------------------------------------------------------------*/
/*		#define	READ_COIL_OUTPUT_AC				00001			*/	
/*		#define	READ_COIL_INPUT_AC				10001			*/
/*		#define	READ_INPUT_REGISTER_AC			30001			*/
/*		#define	READ_HOLDING_REGISTER_AC		40001			*/
/*		#define	WRITE_COIL_OUTPUT_AC			00001			*/
/*		#define	WRITE_HOLDING_REGISTER_AC		40001			*/
/*																*/
/*--------------------------------------------------------------*/
/* Read commend													*/
/*--------------------------------------------------------------*/
/*		#define	READ_COIL_STATUS			0x01				*/
/*		#define	READ_INPUT_STATUS			0x02				*/
/*		#define	READ_HOLDING_REGISTERS		0x03				*/
/*		#define	READ_INPUT_REGISTERS		0x04				*/
/*																*/
/*--------------------------------------------------------------*/
/* Write commend												*/
/*--------------------------------------------------------------*/
/*		#define	FORCE_SINGLE_COIL			0x05				*/
/*		#define	PRESET_SINGLE_REGISTER		0x06				*/
/*		#define	FORCE_MULTIPLE_COILS		0x0F				*/
/*		#define	PRESET_MULTIPLE_REGISTERS	0x10				*/
/*																*/
/*--------------------------------------------------------------*/
/* ���� ���� ���� 												*/
/* coil ���� ���� ���ý� single, multiple ���� ��� �ȵ�.		*/
/* �ݵ�� �ϳ��� �����Ͽ� ����Ͽ��� ��.						*/	
/* register ���� ���� ���ýÿ��� ����							*/
/* ���� ���� ��� ���� ��� WT_NONE ������ 						*/
/*--------------------------------------------------------------*/
/*		#define COIL_SINGLE_WRITE_ONLY							*/
/*		#define COIL_MULTIPLE_WRITE_ONLY						*/
/*		#define REGISTER_SINGLE_WRITE_ONLY						*/
/*		#define REGISTER_MULTIPLE_WRITE_ONLY					*/
/*		#define	WT_NONE											*/
/*																*/
/*--------------------------------------------------------------*/
/* ��� ���� �׸�												*/
/*--------------------------------------------------------------*/
/*		#define PLC_SPEED	RS_9600								*/
/*		#define	PLC_DATA	RS_DATA8							*/
/*		#define PLC_PARITY	RS_NONE								*/
/*																*/
/*--------------------------------------------------------------*/
/* ���� ���� ����												*/
/*--------------------------------------------------------------*/
/*		#define	PLC_COMMEND 0x04								*/
/*		#define	PLC_HADDR	0x00								*/
/*		#define PLC_LADDR	0x00								*/
/*		#define	PLC_HCNT	0x00								*/		
/*		#define	PLC_LCNT	0x01								*/
/*--------------------------------------------------------------*/
/*--------------------------------------------------------------*/

/*--------------------------------------------------------------*/
/* ������� ���� ����						      				*/
/*--------------------------------------------------------------*/
enum WRITE_CMD_TYPE { 
	WCT_SM		= 0,	/* single & multi write */
	WCT_SONLY	= 1,	/* single write only	*/
	WCT_MONLY	= 2		/* multi write only		*/
};

/*--------------------------------------------------------------*/
/* ���� ��⺰ �Ӽ��� �����ϱ� ���� ����ü      				*/
/*--------------------------------------------------------------*/
typedef struct
{
	unsigned int	makecd;						/* 1 make code */
	unsigned char	seriescd;					/* 2 series code */
	unsigned char	modelcd;					/* 3 */

	unsigned char	maxRtyCnt;					/* 4 max retry count */
	unsigned char	maxBitCnt;					/* 5 max bit read/write count */
	unsigned char	maxWordCnt;					/* 6 max word read/write count */
	
	unsigned int	readInputCoilAC;			/* 7 read input coil address change value */

	unsigned int	readOutputCoilAC;			/* 8 read output coil address change value */
	unsigned int	writeOutputCoilAC;			/* 9 write output coil address change value */

	unsigned int	readInputRegisterAC;		/* 10 read input register address change value */

	unsigned int	readHoldingRegisterAC;		/* 11 read holding register address change value */
	unsigned int	writeHoldingRegisterAC;		/* 12 write holding register address change value */

	// unsigned char	coilSingleWriteOnly;		/* 13 coil single write only(1) | coil singe&multy write (0) */
	// unsigned char	registerSingleWriteOnly;	/* 14 register single write only(1) | register singe&multy write (0) */
	unsigned char	coilWriteCmdType;			/* 13 coil single&multi write (0) | coil single write only(1) | coil multi write (2) */
	unsigned char	registerWriteCmdType;		/* 14 register singe&multi write (0) | register single write only(1) | register multi write (2) */

	unsigned char	connectCmd;					/* 15 connection commend */
	unsigned char	connectHAddr;				/* 16 connection High Address */
	unsigned char	connectLAddr;				/* 17 connection Low Address */
	unsigned char	connectHCnt;				/* 18 connection High Count */
	unsigned char	connectLCnt;				/* 19 connection Low Count */

	int				plcSpeed;					/* 20 communiction speed */
	int				plcData;					/* 21 communiction data size */
	int				plcParity;					/* 22 communiction parity */
	int				plcStopbit;					/* 23 communiction stop bit */
	int				plcFlow;					/* 24 communiction flow control */
} _CONNECT_DEVINFO;


/*--------------------------------------------------------------*/
/* ���� ��⺰ �Ӽ� ���̺�					      				*/
/*--------------------------------------------------------------*/
static const _CONNECT_DEVINFO conDevInfo[] = {
	/*	   1,	 2,    3, 4,   5,  6,     7, 8, 9,    10.    11,    12,13,14,   15,   16,   17,   18,   19,      20,       21,      22,        23,       24  */   	
	/* MASTER */
	{ 0xf000, 0x01, 0x01, 1, 128, 16,	  1, 1, 1,     1,     1,     1, 0, 0, 0x00, 0x00, 0x00, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* MODBUS Master single&multi write */	
	{ 0xf000, 0x01, 0x02, 1, 128, 16,	  1, 1, 1,     1,     1,     1, 1, 1, 0x00, 0x00, 0x00, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* MODBUS Master single write only  */	
	{ 0xf000, 0x01, 0x03, 1, 128, 16,	  1, 1, 1,     1,     1,     1, 2, 2, 0x00, 0x00, 0x00, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* MODBUS Master multi write only   */	
	
	/* AUTONICS METER SERIES */
	{ 0x0001, 0x10, 0x88, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x00, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* MT4N */
	{ 0x0001, 0x10, 0x89, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x00, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* MT4W */
	{ 0x0001, 0x10, 0x8A, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x00, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* MT4Y */
	/* AUTONICS TEMP/HUMI SERIES */
	{ 0x0001, 0x30, 0x08, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* THD-RT */
	/* AUTONICS TEMP SERIES */
	{ 0x0001, 0x40, 0x09, 3, 128, 36, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP02, RS_XONOFF  },	/* TK4 */
	{ 0x0001, 0x40, 0x49, 3, 128, 36, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP02, RS_XONOFF  },	/* TM2 */
	{ 0x0001, 0x40, 0x48, 3, 128, 36, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP02, RS_XONOFF  },	/* TM4 */
	/* AUTONICS COUNTER/TIMER SERIES */
	{ 0x0001, 0x50, 0x08, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* CT6M-2P_Mod */
	{ 0x0001, 0x50, 0x09, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* CT6M-1P_Mod */
	{ 0x0001, 0x50, 0x0A, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* CT6M-I_Mod  */
	{ 0x0001, 0x50, 0x18, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* CT6Y-2P_Mod */
	{ 0x0001, 0x50, 0x19, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* CT6Y-1P_Mod */
	{ 0x0001, 0x50, 0x1A, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* CT6Y-I_Mod  */
	{ 0x0001, 0x50, 0x28, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* CT6S-2P_Mod */
	{ 0x0001, 0x50, 0x29, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* CT6S-1P_Mod */
	{ 0x0001, 0x50, 0x2A, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* CT6S-I_Mod  */
	{ 0x0001, 0x50, 0x38, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* CT4S-2P_Mod */
	{ 0x0001, 0x50, 0x39, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* CT4S-1P_Mod */

	/* AUTONICS DS/DA SERIES */
	{ 0x0001, 0x60, 0x08, 1, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 0, 0x00, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* DS/DA_Mod */

	/* AUTONICS REMOTE I/0 SERIES */
	{ 0x0001, 0xA0, 0x01, 1, 128, 16, 10001, 1, 1,     1,     1,     1, 0, 0, 0x00, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP02, RS_XONOFF  },	/* ARM */
	
	/* KONICS DPU SERIES */
	{ 0x0015, 0x01, 0x08, 3, 128, 16, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x00, 0x00, 0x01, RS_38400, RS_DATA8, RS_EVEN, RS_STOP01, RS_XONOFF  },	/* DPU */

	/* KONICS TEMP RECORD SERIES */
	{ 0x0015, 0x80, 0x08, 3, 128, 36, 10001, 1, 1,     1,     1,     1, 1, 1, 0x04, 0x00, 0x64, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP02, RS_XONOFF  },	/* KR50 */

	/* DELTA */
	{ 0x0016, 0x01, 0x08, 3, 128,  8,     0, 0, 0,     0,     0,     0, 1, 1, 0x03, 0x10, 0x00, 0x00, 0x01, RS_9600, RS_DATA8, RS_NONE, RS_STOP01, RS_XONOFF  },	/* DTP */

	/* DANFOSS FC SERIES */
	{ 0x0019, 0x01, 0x01, 3, 128,  8,     0, 0, 0,     0,     0,     0, 0, 0, 0x03, 0x10, 0x00, 0x00, 0x01, RS_9600, RS_DATA8, RS_EVEN, RS_STOP01, RS_XONOFF  },	/* FC200_Mod */

	
};

/*--------------------------------------------------------------*/
/* ��� ���� ��� �Ӽ�						      				*/
/*--------------------------------------------------------------*/
static _CONNECT_DEVINFO *gcurDevInfo;

/*--------------------------------------------------------------*/
/* Read commend													*/
/*--------------------------------------------------------------*/
#define	READ_COIL_STATUS			0x01
#define	READ_INPUT_STATUS			0x02
#define	READ_HOLDING_REGISTERS		0x03
#define	READ_INPUT_REGISTERS		0x04

/*--------------------------------------------------------------*/
/* Write commend												*/
/*--------------------------------------------------------------*/
#define	FORCE_SINGLE_COIL			0x05
#define	PRESET_SINGLE_REGISTER		0x06
#define	FORCE_MULTIPLE_COILS		0x0F
#define	PRESET_MULTIPLE_REGISTERS	0x10

/*--------------------------------------------------------------*/
/* device kind													*/
/*--------------------------------------------------------------*/
#define DEV_DI	0x10		/* input coil */
#define DEV_DC	0x14		/* output coil */
#define DEV_IR	0x88		/* input register */
#define DEV_HR	0xc0		/* hold register  */

#ifdef	SH_CPU
static	int PLC2_DeviceLHFlag;		/* 0�϶� D100 ����̽�, 1�϶� D101 ����̽� 
									   D100���� ��Ž� D100[����], D101[�µ�]
									   D101��   ��Ž� D100[�µ�], D101[����] */
static	int	PlcRecCnt;
static	int	PlcRecCmd;
/****************************************************************/
/*	Station Connect Area										*/
/****************************************************************/

static	int	GroopSema;						/* Grooping Semafo */

static	unsigned	int	Port_TimeoutCnt;
static	int	Pro_Speed;
static	unsigned int Plc_sync_time;
#endif

static	const unsigned char CRC8[256]={
   0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41,
   0x9d, 0xc3, 0x21, 0x7f, 0xfc, 0xa2, 0x40, 0x1e, 0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc,
   0x23, 0x7d, 0x9f, 0xc1, 0x42, 0x1c, 0xfe, 0xa0, 0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62,
   0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81, 0x63, 0x3d, 0x7c, 0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff,
   0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5, 0x84, 0xda, 0x38, 0x66, 0xe5, 0xbb, 0x59, 0x07,
   0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58, 0x19, 0x47, 0xa5, 0xfb, 0x78, 0x26, 0xc4, 0x9a,
   0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6, 0xa7, 0xf9, 0x1b, 0x45, 0xc6, 0x98, 0x7a, 0x24,
   0xf8, 0xa6, 0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b, 0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05, 0xe7, 0xb9,
   0x8c, 0xd2, 0x30, 0x6e, 0xed, 0xb3, 0x51, 0x0f, 0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd,
   0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc, 0x92, 0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50,
   0xaf, 0xf1, 0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c, 0x6d, 0x33, 0xd1, 0x8f, 0x0c, 0x52, 0xb0, 0xee,
   0x32, 0x6c, 0x8e, 0xd0, 0x53, 0x0d, 0xef, 0xb1, 0xf0, 0xae, 0x4c, 0x12, 0x91, 0xcf, 0x2d, 0x73,
   0xca, 0x94, 0x76, 0x28, 0xab, 0xf5, 0x17, 0x49, 0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b,
   0x57, 0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4, 0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16,
   0xe9, 0xb7, 0x55, 0x0b, 0x88, 0xd6, 0x34, 0x6a, 0x2b, 0x75, 0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8,
   0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b, 0xa9, 0xf7, 0xb6, 0xe8, 0x0a, 0x54, 0xd7, 0x89, 0x6b, 0x35
};

/* Table of CRC values for high.order byte */
static	const	unsigned char auchCRCHi[] = {
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
} ;
/* Table of CRC values for low.order byte */
static	const	unsigned char auchCRCLo[] = {
    0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 
    0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 
    0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 
    0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, 0x11, 0xD1, 0xD0, 0x10, 
    0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 
    0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 
    0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 
    0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, 0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 
    0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 
    0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 
    0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 
    0xB4, 0x74, 0x75, 0xB5, 0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 
    0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 
    0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 
    0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
    0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80, 0x40
} ;


/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef  PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}

/*--------------------------------------------------*/
/* ���ӽ� C_Connection()�� ���ؼ� ȣ�� �Ǹ�,		*/
/* ���ӵ� PLC�� ���� Ȯ���ؼ� PLC ���� �Ӽ���	*/
/* ���� ������ �����Ѵ�.							*/
/*--------------------------------------------------*/
void FindConnectionDeviceInfo(int *PlcType)
{
	int i;
	_CONNECT_DEVINFO *pDevInfo = 0;
	for(i=0; i<sizeof(conDevInfo)/sizeof(_CONNECT_DEVINFO); i++)
	{
		pDevInfo = (_CONNECT_DEVINFO *)&conDevInfo[i];
		if( pDevInfo->makecd	== (unsigned int)PlcType[6] && 
			pDevInfo->seriescd	== (unsigned int)PlcType[7] &&
			pDevInfo->modelcd	== (unsigned int)PlcType[8])
		{
			gcurDevInfo = pDevInfo;
			return;
		}
	}
	
	gcurDevInfo = (_CONNECT_DEVINFO *)&conDevInfo[0];
}


static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	/*--------------------------------------------------------------------------*/
	/* �μ��� ���ӱ�� ������ ���� �޾��� ���, �ش� ���ӱ�� ������ �����Ѵ�.	*/
	/* �μ��� ���޵Ǵ� ���ӱ� ������ ������ ���� ���� �ȴ�.						*/
	/* (�μ��� ���ӱ�⸦ ������ �������� ���� ���� (Speed = -1)�� �����ȴ�.	*/
	/*																			*/
	/*	int *Speed		: makecode												*/
	/*	int *DataBit	: series code											*/
	/*	int *Parity		: plc code												*/
	/*--------------------------------------------------------------------------*/
	if(*Speed > -1)
	{
		int plcType[9];
		plcType[6] = *Speed;
		plcType[7] = *DataBit;
		plcType[8] = *Parity;

		FindConnectionDeviceInfo(plcType);
	}

	*Speed= gcurDevInfo->plcSpeed;
	*DataBit= gcurDevInfo->plcData;
	*Parity= ((gcurDevInfo->plcFlow << 16) |(gcurDevInfo->plcStopbit << 8) | (gcurDevInfo->plcParity << 0));
}

/*********************************/
/*	PLC Semafor			         */
/*********************************/
static	void	GetGroopSema(void)
{
	unsigned int	NowTime;
	unsigned int	StartTime;

	if(GroopSema == 0){		/* Grooping Sema */
	}else{
		StartTime= B_GetNowTime();
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
			NowTime= B_GetNowTime();
			if((StartTime+ 3000) < NowTime){
				GroopSema= 0;
			}
			B_Delay(10);
		}
	}
	GroopSema++;
}

static	void	ResetGroopSema(void)
{
	GroopSema= 0;
}

/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{

	int	ret;
	
	ret= -1;

	if(Port_TimeoutCnt != 0){
		if(Plc_sync_time < (B_GetNowTime() - Port_TimeoutCnt)){   /* 20061025ksc */ 
			*CommMode =0;
			*RecCnt = 0;
		}
	}
	Port_TimeoutCnt = B_GetNowTime();		



	switch(*CommMode){

/* ���� ���ŵ� ����Ÿ�� ���� 
 - ��Ʈ���ڵ�	: RecBuff[0], RecBuff[1]�� ACK, STX �Է�
 - ����Ÿ		: RecBuff[2], RecBuff[3]�� ����,
                  RecBuff[4], RecBuff[5]�� RD,
				  RecBuff[6], RecBuff[7], RecBuff[8], RecBuff[9]�� ����Ÿ,
				  RecBuff[10]�� ETX,
 - �����ڵ�		: RecBuff[11]�� FSC, */ 

	case 0:
		*RecCnt= 0;			/* ?���X??�g */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 1;
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		PlcRecCnt= 6;
		PlcRecCmd= data;
		*CommMode = 2;
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		switch(PlcRecCmd){
		case 0x01:
		case 0x02:
		case 0x03:
		case 0x04:
			PlcRecCnt= data+2;  /*01,02,03,04 ���� ���� ����*/
			break;
		case 0x05:
		case 0x06:
		case 0x0F:
		case 0x10:
			PlcRecCnt= 5;    /*05,16 ���� ���� ���� */
			break;
		default:
			PlcRecCnt= 2;
			break;
		}
		*CommMode = 3;
		break;
	case 3:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		PlcRecCnt--;
		if(PlcRecCnt <= 0){
			ret= 0;
		}
		break;
	}
	return(ret);
}


/****************************/
/* Make Check SUM For PLC	*/
/****************************/
/* char *buff : �۽��ϰ����ϴ� ����Ÿ ����,
   int cnt    : �۽��ϰ����ϴ� ����Ÿ ��,
   unsigned char *OutBuf : CRC���� �ΰ��� �����۽� ����Ÿ */

static	unsigned short crc16(unsigned char *puchMsg, int usDataLen)
{
    unsigned char uchCRCHi = 0xFF ; /* high byte of CRC initialized */
    unsigned char uchCRCLo = 0xFF ; /* low byte of CRC initialized */

    int uIndex ; /* will index into CRC lookup table */
	if(usDataLen <= 0){	return(0); }		/* 20090527 */
    while (usDataLen--) /* pass through message buffer */
    {
        uIndex = uchCRCHi ^ *puchMsg++ ; /* calculate the CRC */
        uchCRCHi = uchCRCLo ^ auchCRCHi[uIndex] ;
        uchCRCLo = auchCRCLo[uIndex] ;
    }
    return (uchCRCHi << 8 | uchCRCLo) ;
}

static	int SetPLCBCC(char *buff,int cnt)
{

	unsigned short _crc16;

	_crc16= crc16((unsigned char *)buff,cnt);
	buff[cnt]= _crc16/0x100;
	buff[cnt+1]= _crc16%0x100;
	return(cnt + 2);				/* 18�� ���� */

}



/************************************/
/*	PLC Send						*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	unsigned short _crc16;
	unsigned short cal16;
	int		rty_cnt;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,*Cnt);
	for(rty_cnt= 0; rty_cnt < gcurDevInfo->maxRtyCnt; rty_cnt++){
		ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		if(ret == 0 && combuf[1] == rData[1]){  /* ���� �����̸鼭 ���� �ڵ尡 �ƴ� ��쿡 crc üũ */
			cal16= (rData[*Cnt- 2] << 8) + rData[*Cnt- 1];
			_crc16= crc16(rData,*Cnt- 2);
			if(cal16 != _crc16){
				ret= -1;
			}
		}else ret= -1;
		if(ret == OK){
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}
	return(ret);
}

static	int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	unsigned short _crc16;
	unsigned short cal16;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,*Cnt);
	ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	if(ret == 0){
		cal16= (rData[*Cnt- 2] << 8) + rData[*Cnt- 1];
		_crc16= crc16(rData,*Cnt- 2);
		if(cal16 != _crc16){
			ret= -1;
		}
	}
	return(ret);
}

static	int	C_Connection( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;
	char	buff[32];

	int		Speed = 0;
	int		DataBit = 0;
	int		Parity = 0;

	ret = -1;

	Port_TimeoutCnt = 0;	/* 20060203 */

	Pro_Speed = PlcType[3];			/* 20061025ksc */ 

	switch(Pro_Speed){		
	case 0:						/* 300bps */
		Plc_sync_time = 280;	/* ������ ���� �ð� 120ms = [ 33.3ms * 3(3���ں�) + 10ms(����Ÿ�̸�) ] �̽ð����ٴ� ū �ð����� ���� */
		break;
	case 1:						/* 600bps */
		Plc_sync_time = 150;	
		break;
	case 2:						/* 1200bps */
		Plc_sync_time = 80;
		break;
	case 3:						/* 2400bps */
		Plc_sync_time = 50;
		break;
	case 4:						/* 4800bps */
		Plc_sync_time = 20;
		break;
	case 5:						/* 9600bps */
		Plc_sync_time = 20;		
		break;
	case 6:						/* 19200bps */
		Plc_sync_time = 20;
		break;
	case 7:						/* 38400bps */
		Plc_sync_time = 20;
		break;
	case 8:						/* 57600bps */
		Plc_sync_time = 20;
		break;
	case 9:						/* 115200bps */
		Plc_sync_time = 20;
		break;
	default:
		Plc_sync_time = 20;
		break;
	}



	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */	
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
		}else{						

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
		}
#ifdef	WIN32
		while(1){
			if((iConnect & 1) == 0){
				if(SioPCOpenFlag == 0){
					break;
				}
			}else{
				if(SioPLCOpenFlag == 0){
					break;
				}
			}
	/*ksc20040714*/
			B_Delay(300);
		}
#else

	/*ksc20040714*/
		B_Delay(300);
#endif
	}

	/* PLC Connect Check *(PlcType+2) ���� ������ �Ѱ� ���� */
	monitorModeFlag= PlcType[4];		/* 20090704 */

	// model property setting
	FindConnectionDeviceInfo(PlcType);

	// connection frame send
	// connection command�� 0x00�̸� �׳� return
	if(gcurDevInfo->connectCmd > 0x00)
	{
		buff[0]= *(PlcType+2);				/* Stattion */
		buff[1]= gcurDevInfo->connectCmd;	/* Read Inpu Reg */
		buff[2]= gcurDevInfo->connectHAddr;	/* H-Addr */
		buff[3]= gcurDevInfo->connectLAddr;	/* L-Addr */
		buff[4]= gcurDevInfo->connectHCnt;	/* H-Cnt */
		buff[5]= gcurDevInfo->connectLCnt;	/* L-Cnt */
		Cnt= 6;
		
		ret= SendRecPLCWithBCCCont(2,buff,PlcRecBuff,&Cnt,0);
	}else{
		ret =0;
	}
	ResetGroopSema();	

	if(ret < 0){
		return(0);
	}

	/* PLC Connect Check */
	ret= 1;
	return(ret);
}


static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif
#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif

}
/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;


	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}

/****************************/
/* Make Read Device			*/
/****************************/
/************************************************/
/* int mode		: deive type [bit(0), word(1)]	*/
/* char pDevice : device code					*/
/* int Address  : device start address			*/
/* char *combuff: frame buff					*/
/* int sCnt		: read count					*/
/* int StationNo: station no					*/
/************************************************/
/* �۽� ������ ���� */
static	int	MakePLCReadData(int mode, char pDevice, int Address, char *combuff, int sCnt,int StationNo)
{
	int		ret;
	int		DevAddr;

	ret = 0;
	DevAddr = Address;

	combuff[0]= StationNo;


	if(mode == 0)						/* Bit */
	{		
		if( (unsigned char)pDevice == (unsigned char)DEV_DI )			/* read input coil */
		{	
			DevAddr = DevAddr - gcurDevInfo->readInputCoilAC;
			combuff[1]= READ_INPUT_STATUS;
		}
		else if( (unsigned char)pDevice == (unsigned char)DEV_DC )		/* read output coil */
		{
			DevAddr = DevAddr - gcurDevInfo->readOutputCoilAC;
			combuff[1]= READ_COIL_STATUS;
		}
		else
		{
			ret = -1;
			return(ret);
		}
	}
	else								/* Word */
	{
		if( (unsigned char)pDevice == (unsigned char)DEV_IR )								/* read input register */
		{
			DevAddr = DevAddr - gcurDevInfo->readInputRegisterAC;
			combuff[1]= READ_INPUT_REGISTERS;		
		}
		else if( (unsigned char)pDevice == (unsigned char)DEV_HR )							/* read hold register */
		{
			DevAddr = DevAddr - gcurDevInfo->readHoldingRegisterAC;
			combuff[1]= READ_HOLDING_REGISTERS;
		}
		else
		{
			ret = -1;
			return(ret);
		}
	}
	combuff[2]= DevAddr/0x100;
	combuff[3]= DevAddr%0x100;
	combuff[4]= sCnt/0x100;
	combuff[5]= sCnt%0x100;	


	return(ret);
}

/************************************/
/* PLC Read							*/
/************************************/
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		sCnt;
	int		Cnt,dCnt;
	unsigned char	*SaveAddr;
	int		Address;
	int		EndFlag;	
	int		CmpBit;
	
	GetGroopSema();
	Address= mp->mpar;
	dCnt= mp->mext;	
	EndFlag= 0;
	while(EndFlag == 0){
		switch(mp->mpec){	/* mp->mpec�� 0�϶� Bit Device, 1�϶� Word Device */
		case PLC_BIT:		/* Bit Device */

			ret = MakePLCReadData(0,mp->mbuf[0],mp->mpar,(char *)PlcSendBuff,mp->mext,(int)mp->mbuf[4]);
			Cnt = mp->mext;
			if(ret != 0){	
				ret= -1;	
				return(ret);	
			}
			sCnt= 6;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&sCnt,0) == 0){;
					CmpBit = 1;

					// 2011.10.07 by ycchoi
					//
					// �����ҽ��� ���ÿ� ���� �� �ִ�
					// bit data ���� �ִ� 8���� ���� �ǵ���
					// �ۼ� �Ǿ� �ִ�.
					// �̸� ������ ������� ó������ �ϵ���
					// �����Ѵ�.
					// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
					/*
					for(i = 0; i < Cnt; i++){
						if((rDataFx[3] & CmpBit) == 0){	
							*(unsigned char *)SaveAddr = 0;	
							SaveAddr++;
						}else{						
							*(unsigned char *)SaveAddr = 1;
							SaveAddr++;
						}
						CmpBit <<= 1;
					}
					*/					
					for(i = 0; i < Cnt; i++){
						if((rDataFx[3+i/8] & CmpBit) == 0){	
							*(unsigned char *)SaveAddr = 0;	
							SaveAddr++;
						}else{						
							*(unsigned char *)SaveAddr = 1;
							SaveAddr++;
						}

						CmpBit <<= 1;
						if(CmpBit > 0xFF) CmpBit = 1;
					}
					// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
					ret = 0;
					EndFlag = 1;
				}else{
					ret = -1;
					EndFlag= 1;
				}					
			}else{
				ret= -1;
				EndFlag= 1;
			}
			break;

		case PLC_WORD:		/* Word Device */
			if(dCnt > gcurDevInfo->maxWordCnt){
				dCnt -= gcurDevInfo->maxWordCnt;
				mp->mext= gcurDevInfo->maxWordCnt;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}

			/* �۽� ������ ���� */
			ret = MakePLCReadData(1,mp->mbuf[0],mp->mpar,(char *)PlcSendBuff,mp->mext,(int)mp->mbuf[4]);			
			Cnt = mp->mext* 2;
			sCnt= 6;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){	/* PLC���� ����ϴ� ��巹���� ��� 0 ���� */

				if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&sCnt,0) == 0){ /* ����ؼ� ���ϰ��� 0 �϶� ����Ÿ ó�� */ 
					if(PlcSendBuff[1] == rDataFx[1]){
						for(i = 0; i < Cnt/2; i++){
#ifdef	SH_CPU
							*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+3+1];
							SaveAddr++;
							*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+3];
							SaveAddr++;
#endif

#ifdef	ARM_CPU
#ifdef	LITTLE_ENDIAN
							*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+3];
							SaveAddr++;
							*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+3+1];
							SaveAddr++;
#elif defined BIG_ENDIAN
							*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+3+1];
							SaveAddr++;
							*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+3];
							SaveAddr++;
#endif
#endif
						}
					}
					if(dCnt == 0){
						EndFlag= 1;
						break;
					}
					Address += gcurDevInfo->maxWordCnt;
					mp->mpar= Address;
					mp->mptr= (void *)((char *)mp->mptr + gcurDevInfo->maxWordCnt*2);
				}else{
					ret = -1;
					EndFlag= 1;
				}					
			}else{
				ret= 0;
				EndFlag= 1;
			}
			break;
		}
		B_Delay(100);
	}
	ResetGroopSema();
	return(ret);
}

/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
static	int	ChangeIntData(char *data,int Cnt,int mode)
{
	int		iData;
	int		i;
	union{
		int		iData;
		char	cData[4];
	}rData;

	B_gmemset((char *)&rData,0,sizeof(rData));
	if(mode == 1){
		for(i= 0; i < Cnt*2 && i < 4; i++){
			rData.cData[3- i]= *data;
			data++;
		}
		iData = rData.iData;
	}else{
		iData = *data;
	}
	return(iData);
}

/****************************/
/* Make Write Device		*/
/****************************/
static	int	MakePLCWriteData(int mode, char pDevice, int Address,int Cnt, char *combuff, char *data,int StationNo)
{
	int		ret;
	int		DevAddr;
	int 	ByteCnt;
	int		i;
	int		j;
	char	ByteCmp;
	int		k;
	ret = 0;
	DevAddr = Address;

	if(mode == 0)						/* Bit */
	{
		if( (unsigned char)pDevice == (unsigned char)DEV_DC )
		{
			DevAddr = DevAddr - gcurDevInfo->writeOutputCoilAC;
			
			/* single bit write */
			if( gcurDevInfo->coilWriteCmdType == WCT_SONLY ||
				(gcurDevInfo->coilWriteCmdType == WCT_SM && Cnt == 1))
			{
				combuff[0]= StationNo;
				combuff[1]= FORCE_SINGLE_COIL;			
				combuff[2]= DevAddr/0x100;
				combuff[3]= DevAddr%0x100;
				if(*data == 0){
					combuff[4]=0x00;
					combuff[5]=0x00;
				}else{
					combuff[4]=(char)0xff;
					combuff[5]=0x00;
				}
			}
			else									/* multi bit write */
			{
				combuff[0]= StationNo;
				combuff[1]= FORCE_MULTIPLE_COILS;			
				combuff[2]= DevAddr/0x100;
				combuff[3]= DevAddr%0x100;
				combuff[4]= Cnt/0x100;
				combuff[5]= Cnt%0x100;

				if(Cnt%8){
					ByteCnt=Cnt/8+1;
				}else{
					ByteCnt=Cnt/8;
				}
				combuff[6]= ByteCnt;
				
				for(j=0; j<ByteCnt; j++){					
					combuff[7+j]=0;						/* combuff init*/
					if(j == (ByteCnt-1)){				/* 8�� ������*/
						
						// 2011.11.24 by ycchoi
						// ���� bit count�� 8�� ����� ��� ������ byte�� ������
						// ó������ ���ϴ� bug ������.
						// for(i=0; i<Cnt%8; i++){
						for(i=0; i< ((Cnt%8==0) ? 8 : Cnt%8); i++){
							
							ByteCmp=1;
							if(*data++ == 1){
								ByteCmp <<= i;
								combuff[7+j] = combuff[7+j]|ByteCmp;
							}else{
								ByteCmp=0;
								combuff[7+j] = combuff[7+j]|ByteCmp;
							}
						}
					}else{								/*8�� �� */
						for(i=0; i<8; i++){
							ByteCmp=1;
							if(*data++ == 1){
								ByteCmp <<= i;
								combuff[7+j] = combuff[7+j]|ByteCmp;
							}else{
								ByteCmp=0;
								combuff[7+j] = combuff[7+j]|ByteCmp;
							}
						}
					}
				}
			}
		}else{	
			ret = -1;
			return(ret);
		}
	}
	else								/* Word */
	{
		if( (unsigned char)pDevice == (unsigned char)DEV_HR )
		{
			DevAddr = DevAddr - gcurDevInfo->writeHoldingRegisterAC;

			if( gcurDevInfo->coilWriteCmdType == WCT_SONLY ||
				(gcurDevInfo->coilWriteCmdType == WCT_SM && Cnt == 1))
			{
				combuff[0]= StationNo;
				combuff[1]= PRESET_SINGLE_REGISTER;		
				combuff[2]= DevAddr/0x100;
				combuff[3]= DevAddr%0x100;
#ifdef	SH_CPU
				combuff[5]= *data++;	/* High */
				combuff[4]= *data++;	/* Low */
#endif
				
#ifdef	ARM_CPU
#ifdef	LITTLE_ENDIAN
				combuff[4]= *data++;	/* High */
				combuff[5]= *data++;	/* Low */
#elif defined BIG_ENDIAN
				combuff[5]= *data++;	/* Low */
				combuff[4]= *data++;	/* High */
#endif
#endif	
			}
			else
			{
				combuff[0]= StationNo;
				combuff[1]= PRESET_MULTIPLE_REGISTERS;		
				combuff[2]= DevAddr/0x100;
				combuff[3]= DevAddr%0x100;
				combuff[4]= Cnt/0x100;
				combuff[5]= Cnt%0x100;
				combuff[6]= Cnt*2;	
				
				for(k= 0; k < Cnt; k++){
#ifdef	SH_CPU
					combuff[7+k*2+1]= *data++;	/* High */
					combuff[7+k*2]= *data++;	/* Low */
#endif
#ifdef	ARM_CPU
#ifdef	LITTLE_ENDIAN
					combuff[7+k*2]= *data++;	/* High */
					combuff[7+k*2+1]= *data++;	/* Low */
#elif defined BIG_ENDIAN
					combuff[7+k*2+1]= *data++;	/* Low */
					combuff[7+k*2]= *data++;	/* High */
#endif
#endif
				}

			}
		}
		else
		{
			ret = 1;
			return(ret);
		}	
	}
	return(ret);
}

/************************************/
/* PLC Write						*/
/************************************/
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;
	int		tCnt;
	int		bCnt;
	int		Address;
	char	*dataAddr;

	int		bCnt1;
	int		Address1;
	char	*dataAddr1;

	ret = 0;
	tCnt = mp->mext;  //2011.10.21.
	GetGroopSema();
	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */

		if( gcurDevInfo->coilWriteCmdType == WCT_SONLY ||
			(gcurDevInfo->coilWriteCmdType == WCT_SM && tCnt == 1))
		{
			Address = mp->mpar;
			dataAddr= (char *)mp->mptr;
			bCnt = mp->mext;
			while(1){
				Cnt = 6;
				ret = MakePLCWriteData(0,mp->mbuf[0],Address,mp->mext,(char *)PlcSendBuff,dataAddr,(int)mp->mbuf[4]);
				if(ret == 0){
					if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){
					}else{
						ret = -1;
					}
				}else if(ret == 1){		/* ����Address */
					ret= 0;
				}
				bCnt--;
				Address++;
				dataAddr++;
				if(bCnt == 0){
					break;
				}
			}
		}
		else
		{
			ret = MakePLCWriteData(0,mp->mbuf[0],mp->mpar,mp->mext,(char *)PlcSendBuff,(char *)mp->mptr,(int)mp->mbuf[4]);
			Cnt = PlcSendBuff[6]+7; 
			if(ret == 0){
				if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){
				}else{
					ret = -1;
				}
			}else if(ret == 1){		/* ����Address */
				ret= 0;
			}
		}
		break;

	case PLC_WORD:		/* Word Device */

		if( gcurDevInfo->coilWriteCmdType == WCT_SONLY ||
			(gcurDevInfo->coilWriteCmdType == WCT_SM && tCnt == 1))
		{
			Address1 = mp->mpar;
			dataAddr1= (char *)mp->mptr;
			bCnt1 = mp->mext;
			while(1){
				ret = MakePLCWriteData(1,mp->mbuf[0],Address1,mp->mext,(char *)PlcSendBuff,dataAddr1,(int)mp->mbuf[4]);
				Cnt = 6; 
				if(ret == 0){
					if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){
					}else{
						ret = -1;
					}
				}else if(ret == 1){		/* ����Address */
					ret= 0;
				}
				bCnt1--;
				Address1++;
				dataAddr1=dataAddr1+2;
				if(bCnt1 == 0){
					break;
				}
			}
		}
		else
		{
			ret = MakePLCWriteData(1,mp->mbuf[0],mp->mpar,mp->mext,(char *)PlcSendBuff,(char *)mp->mptr,(int)mp->mbuf[4]);
			Cnt = (mp->mext * 2)+7; 
			if(ret == 0){
				if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){
				}else{
					ret = -1;
				}
			}else if(ret == 1){		/* ����Address */
				ret= 0;
			}
		}
	    break;
	}

	ResetGroopSema();
	return(ret);
}
static	int	C_GetSendRecTime(void)
{
	return(5);				/* 1ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}


/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	if(Port_TimeoutCnt != 0){
		if(Plc_sync_time < (B_GetNowTime() - Port_TimeoutCnt)){   /* 20061025ksc */ 
			*CommMode =0;
			*Sio1RecCnt = 0;
		}
	}
	Port_TimeoutCnt = B_GetNowTime();		
	
/***********************************/
	switch(*CommMode){
	case 0:		/* Idle */
		*CommMode = 4;
		*Sio1RecCnt = 0;
		Sio1RecBuff[(*Sio1RecCnt)++] = data;		/* Slave Address */
		break;
	case 4:
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		PlcRecCnt= 6;
		PlcRecCmd= data;					/* Command */
		switch(PlcRecCmd){
		case 0x01:
		case 0x02:
		case 0x03:
		case 0x04:
		case 0x05:
		case 0x06:
			PlcRecCnt= 6;
			break;
		case 0x07:
		case 0x0b:
		case 0x0c:
			PlcRecCnt= 2;
			break;
//			break;
		case 0x0f:	/* �A��DO */
			PlcRecCnt= 5;
			break;
		case 0x10:	/* �A���ێ����W�X? */
			PlcRecCnt= 5;
			break;
		case 0x11:	/*  */
			PlcRecCnt= 2;
			break;
		default:
			PlcRecCnt= 6;
			break;
		}
		*CommMode = 5;
		break;
	case 5:
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		PlcRecCnt--;
		if(PlcRecCnt <= 0){
			if((PlcRecCmd == 0x0f) || (PlcRecCmd == 0x10)){
				PlcRecCnt= data+ 2;		/* Write Cnt + CRC */
				*CommMode = 6;
			}else{
				ret= 0;		/* Command End */
				*CommMode = 99;
			}
		}
		break;
	case 6:
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		PlcRecCnt--;
		if(PlcRecCnt <= 0){
			ret= 0;		/* Command End */
			*CommMode = 99;
		}
		break;
	}
	return(ret);
}
/************************************************/
/*	�O��?�v����								*/
/************************************************/
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	return(0);
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if(DeviceDataSys[i].SameDevInf == 0){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
						MyAddress= DeviceDataSys[i].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
					MyAddress= DeviceDataSys[i].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN			   */									
/*	2006.03.31 makebitpatarn �ϰ� ����         */
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/*	2006.03.31 makewordpatarn �ϰ� ����        */							
/***************************************************/
void	MakeWordPatarn(int Start)
{

}
/****************************************/
/*	�O��?�v�쐬			*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Same Device Check */
/*	gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));*/
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	/* �r�b�g�A��?�h�̘A����?�F�b�N���� */
	MakeBitContinue();
	MakeWordContinue(TotalBitCnt);
	/* �r�b�g�A��?�h�̃p??����?�F�b�N���� */
	/* Bit Patarn */
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	/* Word Patarn */
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}

	return(0);
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int	ret;

	ret= 0;
	return(ret);
}
/************************************/
/*	�X��?��?�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	GetGroopSema();
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendThruePLC(2,*OutCnt,OutBuff,3000); /*20090706*/
	ResetGroopSema();

#ifdef	OLDSOURCE
#endif
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
#endif
/*++++++++++++++++++++++++++++++++++++*/
#ifdef PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif


#include  "hook_aplplc.h"
/****************************** END **********************/
