///****************************************************************/
///*	Version 1.0M - 2005.06.24  11:08                	*/
///****************************************************************/
///*	PLC OMRON CPM1A			    */
///*	2005.05.24			    */
///*	Kim.J.H				    */
///********************************************/
///*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		  */
///*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
///*	2006.09.25 */
///*      �����͹� ���ø� ������ ���� ver 2.6�� �ϰ� ����	  */
///**********************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"
#ifdef	PLCTYPE_ELSE2
	#include	"PlcHed_type2.h"
#else
	#include	"PlcHed.h"
#endif

/*#ifndef	WIN32
#pragma	section PlcProc
#endif
*/

#define	MAX_BITCNT	28
#define	MAX_WORDCNT	28
#define	MAX_PBITCNT	16
#define	MAX_PWORDCNT	10
#define	MAX_UR_CNT	26
#define	MAX_WORD_CONT_CNT	4
#define	MAX_BIT_CONT_CNT	4

#define	MAX_RTY_COUNT	3



/********************************************/
/*	�O���֐�								*/
/*	APL �֐�								*/
/********************************************/
#ifdef	WIN32
#ifndef	PLCTYPE_ELSE2
/************************************************/
/*	PLC	TYPE 1									*/
/************************************************/
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
void	B_SendPLCPCData( void )
{
	SendPLCPCData();
}
int	B_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
	return(SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
}
int	B_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
	return(SendPC2PLCData(mode,cnt,buff,TimeOut));
}
/* Thrue Mode */
int	B_SendPLC2PCData( int mode,int cnt,char *buff,int TimeOut )
{
	return(SendPLC2PCData( mode,cnt,buff,TimeOut ));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
void	B_PlcDevInit(void)
{
	PlcDevInit();
}
int	B_SendPLCGroup()
{
	SendPLCGroup();
	return(0);
}
/************************************/
void	B_Bin2Hex(int data,int cnt,char *buff)
{
	Bin2Hex(data,cnt,buff);
}
int	B_gstrlen(char *buff)
{
	return(gstrlen(buff));
}
void	B_gmemset(char *buff,int data,int cnt)
{
	gmemset(buff,data,cnt);
}
void	B_gmemcpy(char *obj,char *src,int cnt)
{
	gmemcpy(obj,src,cnt);
}
void	B_gstrcpy(char *obj,char *src)
{
	gstrcpy(obj,src);
}
int	B_gstrcmp(char *src,char *obj)
{
	return(gstrcmp(src,obj));
}
int	B_gstrncmp(char *src,char *obj,int cnt)
{
	return(gstrncmp(src,obj,cnt));
}
void	B_gstrcat(char *src,char *obj)
{
	gstrcat(src,obj);
}
int	B_SendThruePLC(int mode,int cnt,char *sBuff,int TimeOut)
{
	return(SendThruePLC(mode,cnt,sBuff,TimeOut));
}
unsigned int	B_GetNowTime(void)
{
	return(GetNowTime());
}

#else
/************************************************/
/*	TYPE 2										*/
/************************************************/
extern	int	B_Hex2nBin(char *buff,int cnt);
extern	int	B_Hex2Bin(char *buff);
extern	unsigned int B_LHexAsToBin(char *buff, int cnt);
extern	int	B_Delay(int p);
extern	int	B_ReadSignal(int p);
extern	void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	B_PlcDevInit(void);
extern	int	B_SendPLCGroup();
extern	void	B_Bin2Hex(int data,int cnt,char *buff);
extern	int	B_gstrlen(char *buff);
extern	void	B_gmemset(char *buff,int data,int cnt);
extern	void	B_gmemcpy(char *obj,char *src,int cnt);
extern	void	B_gstrcpy(char *obj,char *src);
extern	int	B_gstrcmp(char *src,char *obj);
extern	int	B_gstrncmp(char *src,char *obj,int cnt);
extern	void	B_gstrcat(char *src,char *obj);
extern	unsigned int	B_GetNowTime(void);
int	B_SendRecPLC2(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
	return(SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
}
extern	void	B_SendPLCPCData( void );
int	B_SendPC2PLCData2( int mode,int cnt,char *buff,int TimeOut )
{
	return(SendPC2PLCData2(mode,cnt,buff,TimeOut));
}
#endif
#endif

/*	PLC-Program Title */
#ifdef	WIN32
static	char Title[32]= {
	"PLCPROC CPM1A-V1.0M",
};
#else
static	const char Title[32]= {
	"PLCPROC CPM1A-V1.0M",
};
#endif


#ifdef	WIN32
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#endif


/*	��Ʈ ����̽� �������		*/
static	const	DEV_TBL bPLCDeviceTbl[16] = {
	{"IR", 0x0100, 1},
	{"HR", 0x0300, 1},
	{"SR", 0x0100, 1},
	{"AR", 0x03c8, 1},
	{"LR", 0x0000, 1},
	{"TC", 0x0800, 2},
	{"GB",      0, 4},
};

/*	���� ����̽� �������(��Ʈ�� ���� ����)		*/
static	const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"IR", 0x0100, 1},
	{"HR", 0x0300, 1},
	{"SR", 0x0100, 1},			/*	start ����̽� ��ȣ�� SR232�̹Ƿ� SR0�� �ش�Ǵ� ��������� ���	*/
	{"AR", 0x03c8, 1},
	{"LR", 0x0000, 1},
	{"DM", 0x0c00, 1},
	{"TC", 0x0400, 2},
	{"GD",      0, 4},
};
/****************************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef	PLCTYPE_ELSE2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#else
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_ELSE2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#else
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
}

static int	C_gatoi(char *buff)
{
	char	c;
	int	ret;
	int flag;

	ret= 0;
	flag= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){
			break;
		}
		if((c >= '0') && (c <= '9')){
			ret= ret*10;
			ret+= c- '0';
		}else{
			if(c == '+'){
				continue;
			}
			if(c == '-'){
				flag= 1;
				continue;
			}
			break;
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}
static void	C_Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	if(data < 0){			/* - check 041116 */
		
		data *= -1;
		buff[0]= '-';
		for(i= 1; i < cnt+1; i++){								/*cnt+1�̵� ������ */
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}else{
		for(i= 0; i < cnt; i++){
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}
	buff[i]= 0;
}

/*	Master/Slave ����		*/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(0x0101);											
}

/****************************************************/
/*   FUNC  : PLC Recieve Handler					*/
/*	In    :											*/
/*	Out   : 										*/
/*   DATE  : 2005.05.24								*/
/****************************************************/

/*	���� ������ 1���ھ� �ǵ�	*/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(*CommMode){
	case 0:
		if(data == 0x40){		/* @ */
			*RecCnt= 0;
			RecBuff[(*RecCnt)++] = data;
			*CommMode = 1;
		}
		break;
	case 1:				/* Data Recieve */
		if(*RecCnt < 1024){
			RecBuff[(*RecCnt)++] = data;
		}
		if(data == 0x0d){		/* CR */
			*CommMode = 0;
			ret= 0;
		}
		break;
	}
	return(ret);
}


/************************************/
/* ������ ��ȯ �Լ�					*/
/************************************/

/*	PLC�� ������ ������ ���� �� BCC���		*/
/*	@ + Outbuf[1]+...+BCC(H)+BCC(L)+ * + CR		*/
static	int SetPLCBCC(char *buff,int cnt)
{
	int		i;
	unsigned int sum;
	char	work[2];

	sum= 0;
	for(i = 0; i < cnt; i++){
/*		OutBuf[i] = buff[i];*/
		sum = sum ^ buff[i];		/*	XOR, Check Sum	*/
	}
	B_Bin2Hex(sum,2,work);
	buff[cnt] = work[0];		/*	BCC(H)	*/
	buff[cnt+1] = work[1];	/*	BCC(L)	*/
	buff[cnt+2] = 0x2a;		/*	*		*/
	buff[cnt+3] = 0x0d;		/*	CR		*/
	return(cnt + 4);
}


/************************************/
/*	PLC Send						*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *RecData,int *Cnt,int rmode)
{
	int		ret;
	int		i;
	unsigned int  sum;
	unsigned int  sum1;
	int		rty_cnt;
	int		SendCnt;

/*	PlcCommCnt= SetPLCBCC((char *)combuf,*Cnt,PlcSendBuff);*/
	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen((char *)combuf));
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
/*		ret= B_SendRecPLC(mode,RecData,Cnt,rmode);*/
		ret= C_SendRecPLC(mode,RecData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		if(ret == 0){
			sum = 0;
			for(i = 0; i < *Cnt-4; i++){
				sum= sum ^ RecData[i];			/*	XOR, CHECK SUM		*/
			}
			sum1= B_Hex2Bin((char *)&RecData[i]);
			if(sum != sum1){
				ret= -1;
			}
		}
		if(ret == OK){		/*	OK=0	*/
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}
	return(ret);
}

static	int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *RecData,int *Cnt,int rmode)
{
	int		ret;
	int		i;
	unsigned int  sum;
	unsigned int  sum1;
	int		SendCnt;

/*	PlcCommCnt= SetPLCBCC((char *)combuf,*Cnt,PlcSendBuff);*/
/*	ret= B_SendRecPLC(mode,RecData,Cnt,rmode);*/
	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen((char *)combuf));
	ret= C_SendRecPLC(mode,RecData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	if(ret == 0){
		sum = 0;
		for(i = 0; i < *Cnt-4; i++){
			sum= sum ^ RecData[i];
		}
		sum1= B_Hex2Bin((char *)&RecData[i]);
		if(sum != sum1){
			ret= -1;
		}
	}
	return(ret);
}


/*	��� ����	*/
static	int	C_Connection( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;

	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */
		/* �������̃{�[���[�g */
		if(iConnect == CH_CH1){		/* RS-232C */
#ifdef	WIN32
			SioPCMode= 0;
			SioPCOpenFlag= 1;
#else
			B_RsModeSet(RS_PC,RS_INIT,RS_9600,RS_DATA7,RS_EVEN);
#endif
		}else{						/* RS-422 */
#ifdef	WIN32
			SioPLCMode= 0;
			SioPLCOpenFlag= 1;
#else
			B_RsModeSet(RS_PLC,RS_INIT,RS_9600,RS_DATA7,RS_EVEN);
#endif
		}
#ifdef	WIN32
		while(1){
			if(SioPLCOpenFlag == 0){
				break;
			}
			B_Delay(10);
		}
#endif
		B_Delay(100);
	}

	/* PLC ���� ����(PLC �̻� ���۽� �ʱ�ȭ �����ֹǷ� �ݵ�� �߰��Ǿ�� ��		*/
	B_gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));		/*	PLCcombuf �ʱ�ȭ	*/
	
	/*	������ ���� @00XZ + FCS + * + CR		*/
	B_gstrcpy((char *)PlcSendBuff, "@00XZ");

	Cnt= B_gstrlen((char *)PlcSendBuff);
	ret= SendRecPLCWithBCCCont(2,(char *)PlcSendBuff,PlcSendBuff,&Cnt,0);

	/*	���� Ȯ�� ������	*/
	B_gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));

	/*	������ ���� @00MB1A0300 + FCS + * + CR	*/
	B_gstrcpy((char *)PlcSendBuff, "@00MB1A0300");

	Cnt= B_gstrlen((char *)PlcSendBuff);
	ret= SendRecPLCWithBCCCont(2,(char *)PlcSendBuff,PlcSendBuff,&Cnt,0);
		
	if((ret== 0) && (PlcSendBuff[0] == 0x40)){	/*	������ ó���� @�̸�		*/
			ret= 1;			/*	���� Ż��		*/
			}else{
			ret= 0;			/*	���� �ݺ�		*/
			}
	return(ret);
}

/*	��Ʈ/���� ����, ����̽���, �ε��� Ȯ��(����)		*/
static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	PLCTYPE_ELSE2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#else
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif
}


/************************************/
/* Get Device Name					*/
/************************************/
/*	����̽��� ȹ��(����)		*/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){		/*	No Device		*/
		return(-1);
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){			/*	Bit		*/
		if(PLCIndex[src[0]] != 0xff){		/*	�ε��� ���̺����� 0xff�� �ƴ� �Ϳ� ���Ͽ�	*/
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{					/*	Word	*/
		if(PLCIndex[src[0]] != 0xff){		/*	�ε��� ���̺����� 0xff�� �ƴ� �Ϳ� ���Ͽ�	*/
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}


/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	�� ����̽��� ������� ���		*/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i, j;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;

	/*	Device Name		*/
/*	if(B_GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&i,&Address) == -1){*/
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			/*	Bit		*/
		if(Device[0] == 'G'){		/*	GB		*/
			ret = 1;
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrcmp(bPLCDeviceTbl[i].Device, Device) ==0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			
			/* TC bit ó��*******************/
			if(DeviceFlag == 1){
			/********************************/
			/*
			if(DeviceFlag > 0){
			*/
				*DevAddr = OffSet + (Address / 16) * 2;
				ret = Address % 16;
				BitAndData = 1;
				for ( j=0;j<ret; j++) {
					BitAndData <<= 1;
				}
				ret += (sCnt - 1);
				ret = (ret / 16) + 1;
				if ( ret%2 != 0 ) {
					ret++;
				}
				BitRecCnt = ret;
				ret = 0;
			} else if ( DeviceFlag == 2 ) {
				*DevAddr = OffSet + Address * 2;
				ret = 0;
			} else {
				ret = -1;
				}
			}

		}else{				/*	Word	*/
		if(Device[0] == 'G'){		/*	GD		*/
			ret = 1;
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrcmp(wPLCDeviceTbl[i].Device, Device) == 0){
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address * 2;			/*	��巹���� +2�� ����	*/
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}


/********************************************/
/*	��Ʈ/���� ����̽� Read ������ ����		*/
/********************************************/
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int		DevAddr;

	int		i;
	char	buff[32];
	char	abuff[5];

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	
	if (ret == 0) {
		B_Bin2Hex(DevAddr, 4, buff);			/*	����̽� ��巹�� ����	*/
		for ( i=0; i<4; i++) {
			abuff[i] = buff[i];
		}
		abuff[4] = 0;
		
		B_gstrcpy(combuff, "@00MB0D070000");

		if (mode == 0) {		/*	Bit		*/
			if (DeviceFlag == 1) {
				B_gstrcat(combuff, abuff);
				B_Bin2Hex(BitRecCnt, 2, abuff);
				B_gstrcat(combuff, abuff);
			} else {			/* T, C		*/
					B_gstrcat(combuff, abuff);
					B_Bin2Hex(sCnt, 2, abuff);
					B_gstrcat(combuff, abuff);
			}
		}
		else					/*	Word	*/
		{
			B_gstrcat(combuff, abuff);
			B_Bin2Hex(sCnt, 2, abuff);
			B_gstrcat(combuff, abuff);
		}
	}
	/* �߰�	*/
	else {
		ret = -1;
	}
	/********/
	return(ret);
}


/************************************/
/* PLC Read ����(����) �м�			*/
/************************************/
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i, j;
	int		Cnt,dCnt;
	int		rCnt;
	int		rdata;
	unsigned char	*SaveAddr;
/*	char	Device[4];*/
	int		Address;
/*	int		UsrAddress;*/
/*	int		DevInfo;*/
	int		EndFlag;

	char	work[4];
	unsigned int	data;

	Address= mp->mpar;
/*	ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);*/
	dCnt= mp->mext;
	EndFlag= 0;

	while(EndFlag == 0){
		switch(mp->mpec){
		case PLC_BIT:		/* Bit Device */
			if(dCnt > MAX_BITCNT){
				dCnt -= MAX_BITCNT;
				mp->mext= MAX_BITCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext);
			Cnt = mp->mext;
			rCnt = BitRecCnt;
			SaveAddr = (unsigned char *)mp->mptr;

			if (ret == 0) {
				i = B_gstrlen((char *)PlcSendBuff);
				ret = SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0);
				
				if(ret == 0){
					if (DeviceFlag == 1) {
					for(i = 0; i < rCnt*2; i++){
						rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+ 14]);
					}
					j= 0;
					rdata= (rDataFx[j] << 8) + rDataFx[j+1];
					
					for(i = 0; i < Cnt; i++){
						if(rdata & BitAndData){
							*(unsigned char *)SaveAddr++ = 1;
						}else{
							*(unsigned char *)SaveAddr++ = 0;
						}
						BitAndData <<= 1;
						if(BitAndData > 0x8000){
							BitAndData = 1;
							j++;
							rdata= (rDataFx[j*2] << 8) + rDataFx[j*2+1];
						}
					}
					} else {			/*	T, C	*/
						for ( i=0; i<Cnt*4; i++ ) {
							if ( (rDataFx[ (i*4) + 14] == 0x45) || (rDataFx[ (i*4) + 14] == 0x41) || ((rDataFx[ (i*4) + 14] == 0x36)&&(rDataFx[ (i*4) + 15] == 0x32)) ) {		/*	E or A, 62	*/
								*(unsigned char *)SaveAddr++ = 1;
							}else{
								*(unsigned char *)SaveAddr++ = 0;
							}
						}
					}
				} else {
					/*	�߰�	*/
					ret = -1;
					/************/
					EndFlag = 1;
				}
				if(dCnt == 0){
					EndFlag= 1;
					break;
				}
				Address += MAX_BITCNT;
/*				UsrAddress= plcSetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);*/
				mp->mpar= Address;
				mp->mptr= (void *)((char *)mp->mptr + MAX_BITCNT);
				}else{
				EndFlag= 1;
			}
			break;
		
		case PLC_WORD:		/* Word Device */
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext);
			Cnt = mp->mext*2;
			rCnt = mp->mext;
			SaveAddr = (unsigned char *)mp->mptr;
			
			if(ret == 0){
				i = B_gstrlen((char *)PlcSendBuff);
				if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&i,0) == 0){
								

					if (DeviceFlag == 1) {

						for(i = 0; i < Cnt; i++){
							rDataFx[i] = B_Hex2Bin((char *)&rDataFx[i*2 + 14]);
						}
						for(i = 0; i < rCnt; i++){
							*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
							*(unsigned char *)SaveAddr++ = rDataFx[i*2];
						}
					} else {			/*	TC�� ���(ASC->int)	*/
						for ( j = 0; j < rCnt; j++ ) {
							for ( i = 0; i < 4; i ++ ) {
								work[i] = rDataFx[14 + 4*j + i];
							}
							work[i] = 0;
							data = C_gatoi(work);
							for(i = 0; i < 2; i++){
								*(unsigned char *)SaveAddr++= (unsigned char)(data % 0x100);
								data = data / 0x100;
							}
						}
					}
				} else {
					/*	�߰�	*/
					ret = -1;
					/************/
					EndFlag = 1;
				}
					if(dCnt == 0){
						EndFlag= 1;
						break;
					}
					Address += MAX_WORDCNT;
/*					UsrAddress= plcSetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);*/
					mp->mpar= Address;
					mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
				}else{
					EndFlag= 1;
				}
				break;
			}
	}
	return(ret);
}


/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		ret;
	int		DevAddr;

	int		i;
	char	buff[32];
	char	abuff[15];

	char	iAndData[4] = {'1', '2', '4', '8'};
	char	work[15];
	int		j;

	int		rdata;

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);

	if (ret == 0) {
		B_Bin2Hex(DevAddr, 4, buff);
		for ( i=0; i<4; i++) {
			abuff[i] = buff[i];
		}
		abuff[4] = 0;
		
		if (mode == 0) {		/*	Bit	*/
			if (DeviceFlag == 1) {
				B_gstrcpy(combuff, "@00MB2E0D00");
				B_gstrcat(combuff, abuff);
				B_Bin2Hex((BitAndData & 0x0000ffff), 4, buff);
				for ( i=0; i<4; i++ ) {
					work[i] = buff[i];
				}
				work[4] = 0;

				if (*data == 0) {		/*	OFF	*/
					for ( i=0; i<4; i++ ) {
						for ( j=0; j<4; j++ ) {
							if ( work[i] == iAndData[3-j] ) {
								B_gstrcat(combuff, "2");
							} else {
								B_gstrcat(combuff, "0");
							}
						}
					}
				} else {				/*	ON	*/
					for ( i=0; i<4; i++ ) {
						for ( j=0; j<4; j++ ) {
							if ( work[i] == iAndData[3-j] ) {
								B_gstrcat(combuff, "3");
							} else {
								B_gstrcat(combuff, "0");
							}
						}
					}
				}
			} else {			/*	T, C	*/
				ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);
				DevAddr = DevAddr - 0x0400;

				if (ret == 0) {
					B_Bin2Hex(DevAddr, 4, buff);
					for ( i=0; i<4; i++) {
						abuff[i] = buff[i];
					}
					abuff[4] = 0;

					B_gstrcpy(combuff, "@00MB2E0600");
					B_gstrcat(combuff, abuff);

					if (*data == 0) {		/*	OFF	*/
						B_gstrcat(combuff, "04");
					} else {				/*	ON	*/
						B_gstrcat(combuff, "05");
					}
				}
			}
		} else	{				/*	Word	*/
			if (DeviceFlag == 1) {
			B_gstrcpy(combuff, "@00MB0E870200");
			B_gstrcat(combuff, abuff);
			B_gstrcat(combuff, "01,");
			rdata = ((data[1]&0xff) << 8) + (data[0]&0xff);
			B_Bin2Hex(rdata, 4, abuff);
			B_gstrcat(combuff, abuff);
			} else {			/*	TC	*/
				B_gstrcpy(combuff, "@00MB0E870200");
				B_gstrcat(combuff, abuff);
				B_gstrcat(combuff, "01,");
				rdata = ((data[1]&0xff) << 8) + (data[0]&0xff);
				C_Bin2dec(rdata, 4, abuff);
				B_gstrcat(combuff, abuff);
			}
		}
	}
	return(ret);
}


/************************************/
/* PLC Write						*/
/************************************/
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,dCnt;
/*	char	Device[4];*/
	int		Address;
/*	int		UsrAddress;*/
/*	int		DevInfo;*/
	int		EndFlag;

	Address= mp->mpar;
/*	ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);*/
	dCnt= mp->mext;
	EndFlag= 0;

	while(EndFlag == 0){
		switch(mp->mpec){
		case PLC_BIT:		/* Bit Device */
			if (DeviceFlag == 1) {
			ret = MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PlcSendBuff,(char *)mp->mptr);
			Cnt = mp->mext + 30;
			} else {		/*	TC�� ���	*/
				ret = MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PlcSendBuff,(char *)mp->mptr);
				Cnt = mp->mext + 16;
			}
			/***********************/

			if(ret == 0){
				ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0);
				if (ret == 0) {
				} else {
					ret = -1;
				}
			}
			EndFlag= 1;		/* 1 Bit Only */
			break;
		case PLC_WORD:		/* Word Device */
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PlcSendBuff,(char *)mp->mptr);
			Cnt = mp->mext + 23;

			if(ret == 0){
				ret= SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0);
				if(ret == 0){
					if(dCnt == 0){
						EndFlag= 1;
						break;
					}
					Address += MAX_WORDCNT;
/*					UsrAddress= plcSetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);*/
					mp->mpar= Address;
					mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
				}else{
					ret = -1;
					EndFlag= 1;
				}
			}else{
				EndFlag= 1;
			}
			break;
		}
	}
	return(ret);
}

/*	���� ��ȯ �� delay �ð�		*/
static	int	C_GetSendRecTime(void)
{
	return(0);				/* 0ms */
}

/*	�������� ����		*/
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,"V2.6M");
}
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifndef	PLCTYPE_ELSE2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
/*	����̽� �ִ���� ȹ��(����)		*/
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){			/*	Bit		*/
		if(PLCIndex[idx] != 0xff){		/*	�ε��� ���̺����� 0xff�� �ƴ� �Ϳ� ���Ͽ�	*/
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{					/*	Word	*/
		if(PLCIndex[idx] != 0xff){		/*	�ε��� ���̺����� 0xff�� �ƴ� �Ϳ� ���Ͽ�	*/
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}

/*	����̽� �ּҹ��� ȹ��(����)		*/
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){			/*	Bit		*/
		if(PLCIndex[idx] != 0xff){		/*	�ε��� ���̺����� 0xff�� �ƴ� �Ϳ� ���Ͽ�	*/
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{					/*	Word	*/
		if(PLCIndex[idx] != 0xff){		/*	�ε��� ���̺����� 0xff�� �ƴ� �Ϳ� ���Ͽ�	*/
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}

/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	switch(*CommMode){			/* CommMode=0:Normal,1->3:Editor,4->PLC */
	case 0:		/* Normal @ */
		if(data == 0x40){		/* @ */
			*CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:				/* Data Rec */
		if(*Sio1RecCnt < 1024){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		if(data == 0x0d){
			*CommMode = 99;
			ret= 0;
		}
		break;
	}
	return(ret);
}

/************************************************/
/*	�O���[�v����								*/
/************************************************/
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
/*	����		*/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
						MyAddress= DeviceDataSys[i].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}


/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
/*	����		*/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
					MyAddress= DeviceDataSys[i].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}


/***************************************************/
/*	BIT GROUP-PATARN			   */
/*	2006.03.31 makebitpatarn �ϰ� ����         */
/***************************************************/
/*	����		*/
void	MakeBitPatarn(int Bit_Cnt)
{

}

/***************************************************/
/*	WORD GROUP-PATARN			   */
/*	2006.03.31 makewordpatarn �ϰ� ����        */
/***************************************************/
/*	����		*/
void	MakeWordPatarn(int Start)
{	

}


/***************************************************/
/*	WORD GROUP-PATARN								*/
/***************************************************/
/*	����		*/
void	ClearBWContinue(void)
{
	int		i,j,idx;

	for(i= 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus != 0)){
			/* Continue */
			if(DeviceDataSys[i].DevFlag == 0){		/* BIT */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_BIT_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}else{									/* WORD */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_WORD_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}
		}
	}
}


/****************************************/
/*	�O���[�v�쐬						*/
/****************************************/
/*	����		*/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Set Group */
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gDeviceCnt= 0;
	/* Same Device Check */
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	if(BitCnt > 0){
		MakeBitContinue();
	}
	if(WordCnt > 0){
		MakeWordContinue(TotalBitCnt);
	}
	/* Continue MAX Check */
	ClearBWContinue();
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}
	return(0);
}


int		RecGroupPLCDev(int PlcType)
{
	return(0);
}


/************************************/
/*	�X���[���[�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;

	B_SendPLCPCData();
}


/********************************/
/*	Device2Index				*/
/********************************/
/*	����̽����� �ε����� ��ȯ		*/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}

/*	����̽��� ��巹�� ���� üũ		*/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}

/*	PLC ��� �Ķ���� ����		*/
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_9600;
	*DataBit= RS_DATA7;
	*Parity= RS_EVEN;
}
/*++++++++++++++++++++++++++++++++++++*/
#else
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}

#endif

#ifdef	TEST_PROT
/********************************************/
/*	�����֐�								*/
/********************************************/
#ifdef	PLCTYPE_ELSE2
int	PLC_CONNECT2(int *PlcType,int iConnect)
{
	return(Connection2(PlcType,iConnect));
}
int	PLC1CHAR_READ2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc2(data,CommMode,RecCnt,RecBuff));
}
void	GET_PLC2_VER(char *Name)
{
	Get_Plc2_Ver(Name);
}
int	PLC_DEV_READ2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead2(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite2(mp,rDataFx,PlcType));
}
int	GET_SEND_REC_TIME2(void)
{
	return(GetSendRecTime2());
}
int	GET_MS_SEL2(void)
{
	return(Get_Ms_Sel2());
}
#else
int	PLC_CONNECT(int *PlcType,int iConnect)
{
	return(Connection(PlcType,iConnect));
}
int	GET_PLC_NAME(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	PLC1CHAR_READ(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite(mp,rDataFx,PlcType));
}
int	PLCPCDOWN(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PLCPCDownThrue(data,CommMode,RecCnt,RecBuff));
}
int	GET_PLC_MAX(int bFlag,int idx)
{
	return(GetDevMaxPLC(bFlag,idx));
}
int	GET_PLC_MIN(int bFlag,int idx)
{
	return(GetDevMinPLC(bFlag,idx));
}
int		DEVICE_2_INDEX(int bwflag,char *Name)
{
	return(Device2IndexPLC(bwflag,Name));
}
int		CHECK_PLC_ADDR(int bwflag,char *Name,int *Address1,int *plctype)
{
	return(CheckPLC_Addr(bwflag,Name,Address1,plctype));
}
void	GET_MON_BAUDRATE(int *Speed,int *DataBit,int *Parity)
{
	GetMonBaudrate(Speed,DataBit,Parity);
}
int	GET_SEND_REC_TIME(void)
{
	return(GetSendRecTime());
}
void	GET_PLC1_VER(char *Name)
{
	Get_Plc1_Ver(Name);
}
int	PLC_MAKE_GROUP(int PlcType)
{
	return(MakeGroupDevPLC(PlcType));
}
int	PLC_GROUP_READ(int PlcType)
{
	return(RecGroupPLCDev(PlcType));
}
void	PLC_THRU_PROC(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	PLCFxThruProc(CommBuff,RecCommCnt,OutBuff,OutCnt,PlcConnectFlag,PlcType);
}
int	GET_MS_SEL(void)
{
	return(Get_Ms_Sel());
}
#endif
#endif
/****************************** END **********************/
