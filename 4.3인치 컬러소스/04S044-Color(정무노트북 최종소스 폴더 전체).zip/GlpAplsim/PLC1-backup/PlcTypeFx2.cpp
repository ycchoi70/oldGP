/************************************/
/*	PLC TYPE2(FX) Proc				*/
/************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"
#ifdef	PLCTYPE_ELSE2
	#include	"PlcHed_type2.h"
#else
	#include	"PlcHed.h"
#endif
/*#define	LOG*/


#define	MAX_WORDCNT		16
#define	MAX_BITCNT		128
#define	MAX_MON_WORDCNT	126
#define	MAX_MON_WD_1S	25
#define	MAX_MON_FIST	30
#define	MAX_MON_SECD	32
#define	MAX_MON_BITCNT	16

#define	MAX_PBITCNT		128
#define	MAX_PWORDCNT	16
#define	MAX_WORD_CONT_CNT	4
#define	MAX_BIT_CONT_CNT	4

#define	RTY_COUNT		2

#define	MAX_REC_BUF		512

/**************************************/
static	int	PLC_Type_In;
static	int	GppPcThruWCnt;
static	int	GppPcThruBCnt;
static	int	GroopSema;		/* Grooping Semafo */
static	int	GroopingFlag;	/* Grooping ON */
static	int	DoubleWordCnt;	/* C2-Count */

static	int		PcThru1014;					/* PC��GroupMonitor�t���b�O */
static	int		PcThru1014Rec;				/* E00179 ��M�t���b�O */
static	int		PcThruWCnt;
static	int		PcThruBCnt;
static	int		PcThruAllCnt;
static	int		PcThruByteCnt;
static	int		PcThruByteCnt179;
static	int		PcThruByteCntStr;
static	int		PcThruByteCnt1SW;
static	int		PcThruByteCnt1SB;

static	char	PLCFX1N_00E0202[4+4];
static	char	PLCFX1N_00EE804[8+4];
static	char	PLC2FX1N_00E0202[4+4];
static	char	PLC2FX1N_00EE804[8+4];

/****************************** Function **********************/
static	int		Device2IndexPLC(int bwflag,char *Name);


/********************************************/
/*	�O���֐�								*/
/********************************************/
//#ifdef	WIN32
static	int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
static	int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
static	unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
static	void	B_SendPLCPCData( void )
{
	SendPLCPCData();
}
static	int	B_SendRecPLC2(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef	PLCTYPE_ELSE2
	return(SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#else
	return(SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	B_SendPC2PLCData2( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_ELSE2
	return(SendPC2PLCData2(mode,cnt,buff,TimeOut));
#else
	return(SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
}
/* Thrue Mode */
#ifdef	PLCTYPE_ELSE2
#else
static	int	B_SendPLC2PCData( int mode,int cnt,char *buff,int TimeOut )
{
	return(SendPLC2PCData( mode,cnt,buff,TimeOut ));
}
#endif
static	int	B_Delay(int p)
{
	return(Delay(p));
}
static	int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
static	void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
static	void	B_PlcDevInit(void)
{
	PlcDevInit();
}
static	int	B_SendPLCGroup()
{
	SendPLCGroup();
	return(0);
}
/************************************/
/* ���ʏ���							*/
/************************************/
static	void	B_Bin2Hex(int data,int cnt,char *buff)
{
	Bin2Hex(data,cnt,buff);
}
static	int	B_gstrlen(char *buff)
{
	return(gstrlen(buff));
}
static	void	B_gmemset(char *buff,int data,int cnt)
{
	gmemset(buff,data,cnt);
}
static	void	B_gmemcpy(char *obj,char *src,int cnt)
{
	gmemcpy(obj,src,cnt);
}
static	void	B_gstrcpy(char *obj,char *src)
{
	gstrcpy(obj,src);
}
static	int	B_gstrcmp(char *src,char *obj)
{
	return(gstrcmp(src,obj));
}
static	int	B_gstrncmp(char *src,char *obj,int cnt)
{
	return(gstrncmp(src,obj,cnt));
}
static	void	B_gstrcat(char *src,char *obj)
{
	gstrcat(src,obj);
}

//#endif
/********************************************/
/* FX�V���[�Y */
static	const char Title[32]= {
	"PLCPROC MFX-V1.10",
};
/********************************/
/*	FX Serease					*/
/********************************/
static	const	DEV_TBL bPLCDeviceTbl[4][16] = {
	{						/* FX1N */
		{"M" ,0x0000,7},		/* 0 */
		{"M2",0x0E00,0},		/* 1 */
		{"Y" ,0x0C00,0},		/* 2 */
		{"C" ,0x0F00,11},		/* 3(�J�E���^�ړ_) */
		{"CR",0x3700,0},		/* 4(�J�E���^���Z�b�g) */
		{"T" ,0x1000,10},		/* 5 */
		{"TR",0x3800,0},		/* 5 */
		{"X" ,0x1200,0},		/* 6 */
		{"S" ,0x1400,0},		/* 7 */
		{"GB",0x0000,1},		/* 8 */
	},
	{						/* FX1S */
		{"M" ,0x0800,7},		/* 0 */
		{"M2",0x0F00,0},		/* 1 */
		{"Y" ,0x0500,0},		/* 2 */
		{"C" ,0x0E00,11},		/* 3 */
		{"CR",0x2E00,0},		/* 4 */
		{"T" ,0x0600,10},		/* 5 */
		{"TR",0x2600,0},		/* 6 */
		{"X" ,0x0400,0},		/* 7 */
		{"S" ,0x0000,0},		/* 8 */
		{"GB",0x0000,1},		/* 9 */
	}
};
static	const	DEV_TBL	wPLCDeviceTbl[4][16] = {
	{						/* FX1N */
		{"Y" ,0x0180,9},		/* 0 */
		{"M" ,0x0000,8},		/* 0 */
		{"M2",0x01c0,0},		/* 0 */
		{"X" ,0x0240,9},		/* 0 */
		{"C" ,0x0A00,3},		/* 0 */
		{"C2",0x0C00,0},		/* 1 */
		{"CS",0x4190,2},		/* 2 */
		{"D" ,0x4000,4},		/* 6 */
		{"D2",0x0E00,0},		/* 3 */
		{"T" ,0x1000,10},		/* 4 */
		{"TS",0x41B8,2},		/* 5 */
		{"Z" ,0x0F68,5},		/* 7 */
		{"V" ,0x0F68,6},		/* 8 */
		{"S" ,0x0280,8},		/* 9 */
		{"GD",0x0000,1},		/* 10 */
	},
	{						/* FX1S */
		{"Y" ,0x00A0,9},		/* 0 */
		{"M" ,0x0100,8},		/* 0 */
		{"M2",0x01E0,0},		/* 0 */
		{"X" ,0x0080,9},		/* 0 */
		{"C" ,0x0A00,3},		/* 0 */
		{"C2",0x0C00,0},		/* 1 */
		{"CS",0x10C8,2},		/* 2 */
		{"D" ,0x1000,4},		/* 3 */
		{"D2",0x1100,0},		/* 4 */
		{"T" ,0x0800,10},		/* 5 */
		{"TS",0x10C8,2},		/* 6 */
		{"Z" ,0x0E38,5},		/* 7 */
		{"V" ,0x0E38,6},		/* 8 */
		{"S" ,0x0000,8},		/* 9 */
		{"GD",0x0000,1},		/* 9 */
	}

};
/************************************/
/* Fx1n								*/
static	const char *PLCConnectHed= "10EEC04";
static	const char	*PLCFX1NHed  = "E1014000000810000";
static	const char	*PLCFX1NHed1 = "E10144000";
static	const char	*PLCFX1SHedW = "11800000001";
static	const char	*PLCFX1SHedB = "11826000000";
/* Fx1s								*/
/************************************/
/* ��M�v���g�R��					*/
/************************************/
#ifdef	LOG
int		logCnt;
char	reclog[512];
char	modlog[512];
#endif
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :	unsigned char data: In Data				*
*			int *CommMode: Matrix Mode				*
*			int *RecCnt: Recieve Count				*
*			unsigned char *RecBuff: Recieve Buffer	*
*	Out   : 0: Recieve End							*
*			-1: Continue							*
*   DATE  : 2003.5.25	                            *
*****************************************************/
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(data){
	case ACK:
		if(*CommMode == 0){
			RecBuff[(*RecCnt)++] = data;
			ret = 0;
		}
		break;
	case STX:
		if(*CommMode == 0){
			*RecCnt = 0;
			*CommMode = 1;
			RecBuff[(*RecCnt)++] = data;
		}
		break;
	case ETX:
		if(*CommMode == 1){
			RecBuff[(*RecCnt)++] = data;
			*CommMode = 2;
		}
		break;
	case NAK:
		if(*CommMode == 0){
			RecBuff[(*RecCnt)++] = data;
			ret = 0;
		}
		break;
	default:
		if(*CommMode > 1){
			if(*RecCnt < MAX_REC_BUF-2){
				RecBuff[(*RecCnt)++] = data;
			}
			if(*CommMode == 2){
				*CommMode = 3;
			}else if(*CommMode == 3){
				*CommMode = 0;
				ret = 0;
			}
		}else if(*CommMode == 1){
			if(*RecCnt < MAX_REC_BUF-2){
				RecBuff[(*RecCnt)++] = data;
			}
		}
		break;
	}
	return(ret);
}
/****************************************************/
/*	PC Port Recieve									*/
/*	In    :	unsigned char data: In Data				*
*			int *CommMode: Matrix Mode				*
*			int *RecCnt: Recieve Count				*
*			unsigned char *RecBuff: Recieve Buffer	*
*	Out   : 0: Recieve End							*
*			-1: Continue							*/
/****************************************************/
static	int PLCPCDownThrue(unsigned char data,int *recmode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret;
#ifdef	LOG
	reclog[logCnt]= data;
	modlog[logCnt]= *recmode;
	logCnt= (logCnt+ 1) & 0xff;
#endif
	ret = -1;
	switch(*recmode){
	case 0:		/* Normal */
		switch(data){
		case ENQ:
			*recmode = 99;			/* True Mode */
			*RecCnt = 0;
			RecBuff[(*RecCnt)++] = data;
			ret = 0;	/* Pendding Req */
			break;
		case STX:
			*recmode = 4;
			*RecCnt = 0;
			RecBuff[(*RecCnt)++] = data;
			break;
		case ACK:
			*RecCnt = 0;
			RecBuff[(*RecCnt)++] = data;
			*recmode = 99;			/* True Mode */
			ret = 0;	/* Pendding Req */
			break;
		case NAK:
			*RecCnt = 0;
			RecBuff[(*RecCnt)++] = data;
			*recmode = 99;			/* True Mode */
			ret = 0;	/* Pendding Req */
			break;
		}
		break;
	case 4:		/* Thru Mode */
		if(*RecCnt < MAX_REC_BUF-2){
			RecBuff[(*RecCnt)++] = data;
			if(data == ETX){
				*recmode = 5;
			}
		}else{
			*recmode = 0;
		}
		break;
	case 5:		/* BCC1 */
		RecBuff[(*RecCnt)++] = data;
		*recmode = 6;
		break;
	case 6:		/* BCC2 */
		RecBuff[(*RecCnt)++] = data;
		*recmode = 99;
		ret = 0;	/* Pendding Req */
		break;
	}
	return(ret);
}
/************************************************/
/* Make Check SUM For PLC						*/
/*	IN		char *buff: Make Sum Buff			*/
/*						buff[0]:STX Set			*/
/*						buff[cnt+1]:ETX			*/
/*						buff[cnt+2]:Bcc(Hex 2)	*/
/*	OUT		buff length							*/
/************************************************/
static	int SetPLCBCC(char *buff,int cnt)
{
	int		i;
	unsigned char bcc;

	buff[0] = STX;
	buff[cnt+1] = ETX;
	bcc = 0;
	for(i = 0; i < cnt+ 1; i++){
		bcc += buff[i+1];
	}
/*	sprintf((char *)&OutBuf[cnt+2],"%02X",bcc&0x00ff);*/
	B_Bin2Hex(bcc&0x00ff,2,(char *)&buff[cnt+2]);
	return(cnt + 4);
}
/************************************/
/*	PLC Send						*/
/*	IN		int mode: 0:Only Send	*/
/*					1:ACK Recieve	*/
/*					2:Data Recieve	*/
/*					3:ACK+Data Recieve	*/
/*	OUT		0:OK					*/
/*			-1:NG					*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,unsigned char *combuf,unsigned char *RecData,int *Cnt,int rmode)
{
	int		ret,i;
	int		rtycnt;
	int		SendCnt;
	unsigned char bcc;
	unsigned char bcc1;

	SendCnt= SetPLCBCC((char *)combuf,B_gstrlen((char *)&combuf[1]));
	for(rtycnt= 0; rtycnt < RTY_COUNT;rtycnt++){
		ret= B_SendRecPLC2(mode,RecData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		if((ret == OK) && (rmode == 0)){
			bcc = 0;
			for(i = 0; i < *Cnt- 3; i++){
				bcc += RecData[i+1];
			}
			bcc1= (unsigned char)B_Hex2nBin((char *)&RecData[*Cnt-2],2);
			if(bcc != bcc1){
				ret = -1;
			}
		}
		if(ret == OK){
			break;
		}
	}
	return(ret);
}
/********************************************************/
/*	FX Serase Connect Check								*/
/*	IN		unsigned long RecData: 00EE804 Response Data	*/
/*	OUT		CheckDigit									*/
/********************************************************/
static	unsigned long MakeCheckPLCDigit(unsigned long RecData)
{
	int		i;
	unsigned long sData;
	unsigned long sData1;

	sData = (RecData & 0xff000000) >> 8;
	sData |= (RecData & 0x00ff0000) << 8;
	sData |= (RecData & 0x0000ff00) >> 8;
	sData |= (RecData & 0x000000ff) << 8;

	sData1 = (RecData & 0xff000000) >> 24;
	sData1 |= (RecData & 0x00ff0000) >> 8;
	sData1 |= (RecData & 0x0000ff00) << 8;
	sData1 |= (RecData & 0x000000ff) << 24;

	for(i = 0; i < 2; i++){
		if((sData & 0x80000000) == 0){
			sData= sData << 1;
		}else{
			sData= sData << 1;
			sData |= 1;
		}
	}
	sData+= sData1;
	for(i = 0; i < 2; i++){
		if((sData & 0x80000000) == 0){
			sData= sData << 1;
		}else{
			sData= sData << 1;
			sData |= 1;
		}
	}
	sData= sData ^ sData1;
	sData1 = (sData & 0xff000000) >> 24;
	sData1 |= (sData & 0x00ff0000) >> 8;
	sData1 |= (sData & 0x0000ff00) << 8;
	sData1 |= (sData & 0x000000ff) << 24;
	return(sData1);
}
/****************************/
/* PLC ENQ Check(FX1N)		*/
/****************************/
static	int	PlcEnqFXCheck(void)
{
	int		ret;
	char	buff[12];

	buff[0]= ENQ;
	ret= B_SendPC2PLCData2(1,1,(char *)buff,500);		/* ENQ ���M */
	return(ret);
}
static	void	PlcBuffClear(void)
{
	PcThru1014= 0;
	PcThru1014Rec= 0;
	PcThruWCnt= 0;
	PcThruBCnt= 0;
	PcThruAllCnt= 0;
	PcThruByteCnt= 0;
	PcThruByteCnt179= 0;
	PcThruByteCntStr= 0;
	PcThruByteCnt1SW= 0;
	PcThruByteCnt1SB= 0;
#ifdef	LOG
	logCnt= 0;
#endif
}
int	Connection2( int *PlcType,int iConnect )
{
	unsigned long data;
	int		ret;
	int		Cnt;

	PlcBuffClear();
	/* �������̃{�[���[�g */
	if(iConnect == CH_CH1){		/* RS-232C */
#ifdef	WIN32
		SioPCMode= 1;
		SioPCOpenFlag= 1;
#else
		B_RsModeSet(RS_PC,RS_INIT,RS_9600,RS_DATA7,RS_EVEN);
#endif
	}else{						/* RS-422 */
#ifdef	WIN32
		SioPLCMode= 0;
		SioPLCOpenFlag= 1;
#else
		B_RsModeSet(RS_PLC,RS_INIT,RS_9600,RS_DATA7,RS_EVEN);
#endif
	}
#ifdef	WIN32
	while(1){
		if(SioPLCOpenFlag == 0){
			break;
		}
		B_Delay(10);
	}
#endif
	B_Delay(500);

	/* PLC Connect Check */
	if(PlcEnqFXCheck() != OK){
		return(0);
	}
	B_gstrcpy((char *)&PlcSendBuff[1],"00E0202");
	ret= SendRecPLCWithBCC(2,PlcSendBuff,PlcSendBuff,&Cnt,0);
	if(ret < 0){
		return(0);
	}
	B_gmemset(PLCFX1N_00E0202,0,sizeof(PLCFX1N_00E0202));
	B_gmemcpy(PLCFX1N_00E0202,(char *)&PlcSendBuff[0],8);
	data = (unsigned char)(B_Hex2Bin((char *)&PlcSendBuff[3]) & 0x3f);
	if(data == 22){	/* Fx-1S */
		B_gstrcpy((char *)&PlcSendBuff[1],"0804808");
		ret= SendRecPLCWithBCC(2,PlcSendBuff,PlcSendBuff,&Cnt,0);
		if(ret < 0){
			return(0);
		}
		B_gstrcpy((char *)&PlcSendBuff[1],"0800002");
		ret= SendRecPLCWithBCC(2,PlcSendBuff,PlcSendBuff,&Cnt,0);
		if(ret < 0){
			return(0);
		}
		B_gstrcpy((char *)&PlcSendBuff[1],"0800808");
		ret= SendRecPLCWithBCC(2,PlcSendBuff,PlcSendBuff,&Cnt,0);
		if(ret < 0){
			return(0);
		}
		B_gstrcpy((char *)&PlcSendBuff[1],"11800020001");
		ret= SendRecPLCWithBCC(1,PlcSendBuff,PlcSendBuff,&Cnt,1);
		if(ret < 0){
			return(0);
		}
		B_gstrcpy((char *)&PlcSendBuff[1],"11826020000");
		ret= SendRecPLCWithBCC(1,PlcSendBuff,PlcSendBuff,&Cnt,1);
		if(ret < 0){
			return(0);
		}
		*PlcType= 1;
		PLC_Type_In= 1;		/* Fx1N */
		ret= 1;
	}else{			/* Fx-1N,FX-2NC */
		B_gstrcpy((char *)&PlcSendBuff[1],"00EE804");
		ret= SendRecPLCWithBCC(2,PlcSendBuff,PlcSendBuff,&Cnt,0);
		if(ret == 0){
			B_gmemset(PLCFX1N_00EE804,0,sizeof(PLCFX1N_00EE804));
			B_gmemcpy(PLCFX1N_00EE804,(char *)&PlcSendBuff[0],12);
			data = (unsigned char)B_Hex2Bin((char *)&PlcSendBuff[1]) << 24;
			data += (unsigned char)B_Hex2Bin((char *)&PlcSendBuff[3]) << 16;
			data += (unsigned char)B_Hex2Bin((char *)&PlcSendBuff[5]) << 8;
			data += (unsigned char)B_Hex2Bin((char *)&PlcSendBuff[7]);
			data= MakeCheckPLCDigit(data);
			B_gstrcpy((char *)&PlcSendBuff[1],(char *)PLCConnectHed);
/*			sprintf((char *)&PLCcombuf[7],"%08X",data);*/
			B_Bin2Hex(data,8,(char *)&PlcSendBuff[8]);
			ret= SendRecPLCWithBCC(1,PlcSendBuff,PlcSendBuff,&Cnt,1);
			if(ret < 0){
				return(0);
			}
		}else{
			return(0);
		}
		B_gstrcpy((char *)&PlcSendBuff[1],"A1");
		ret= SendRecPLCWithBCC(1,PlcSendBuff,PlcSendBuff,&Cnt,1);
		if(ret < 0){
			return(0);
		}
		*PlcType= 0;
		PLC_Type_In= 0;		/* Fx1N */
		ret= 2;
	}
	if(ret == 2){		/* FX1N */
		/* ����ڑ����̃{�[���[�g */
		B_Delay(100);
		if((iConnect & 1) == 0){	/* RS-232C */
#ifdef	WIN32
		SioPCMode= 1;
		SioPCOpenFlag= 1;
#else
			B_RsModeSet(RS_PC,RS_INIT,RS_19200,RS_DATA7,RS_EVEN);
#endif
		}else{
#ifdef	WIN32
		SioPLCMode= 1;
		SioPLCOpenFlag= 1;
#else
			B_RsModeSet(RS_PLC,RS_INIT,RS_19200,RS_DATA7,RS_EVEN);
#endif
		}
#ifdef	WIN32
	while(1){
		if(SioPLCOpenFlag == 0){
			break;
		}
		B_Delay(10);
	}
#endif
		B_Delay(100);
	}
	if(ret > 0){
		ret= 1;
	}

	GroopSema= 0;		/* Grooping Sema */
	GroopingFlag= 0;	/* Grooping ON */

	return(ret);
}
/******************************************/
static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	PLCTYPE_ELSE2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TBLBCT];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TBLBYT];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TBLWCT];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TBLWOR];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TBLIDX];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TBLBCT;
	*ByteTbl= (DEV_PC_TBL *)PLC2_DEV_TBLBYT;
	*PLCWordCnt= *(int *)PLC2_DEV_TBLWCT;		/*  */
	*WordTbl= (DEV_PC_TBL *)PLC2_DEV_TBLWOR;
	*PLCIndex= (unsigned char *)PLC2_DEV_TBLIDX;
#endif
#else
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC_DEV_TBLBCT];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC_DEV_TBLBYT];
	*PLCWordCnt= (int)GpFont[PLC_DEV_TBLWCT];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC_DEV_TBLWOR];
	*PLCIndex= (unsigned char *)&GpFont[PLC_DEV_TBLIDX];
#else
	*PLCByteCnt= *(int *)PLC_DEV_TBLBCT;
	*ByteTbl= (DEV_PC_TBL *)PLC_DEV_TBLBYT;
	*PLCWordCnt= *(int *)PLC_DEV_TBLWCT;		/*  */
	*WordTbl= (DEV_PC_TBL *)PLC_DEV_TBLWOR;
	*PLCIndex= (unsigned char *)PLC_DEV_TBLIDX;
#endif
#endif
}
/************************************/
/* Get Device Name					*/
/************************************/
int	GetDevNamePLC2(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;
	char	Device[4];
	unsigned char	sDevice;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	sDevice= src[0];
	if(sDevice >= 0xf0){
		Device[1]= 0;
		switch(sDevice){
		case DEV_CR:
			Device[0]= 'C';
			break;
		case DEV_TR:
			Device[0]= 'T';
			break;
		case DEV_CS:
			Device[0]= 'C';
			break;
		case DEV_TS:
			Device[0]= 'T';
			break;
		}
		ret= Device2IndexPLC(bFlag,Device);
		if(ret != -1){
			src[0]= (char)ret;
		}
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	if(ret == 0){
		if(sDevice >= 0xf0){
			src[0]= sDevice;
			obj[2]= 0;
			switch(sDevice){
			case DEV_CR:
				obj[0]= 'C';
				obj[1]= 'R';
				break;
			case DEV_TR:
				obj[0]= 'T';
				obj[1]= 'R';
				break;
			case DEV_CS:
				obj[0]= 'C';
				obj[1]= 'S';
				break;
			case DEV_TS:
				obj[0]= 'T';
				obj[1]= 'S';
				break;
			}
		}
	}
	return(ret);
}
/************************************/
/*	Device & Address Change			*/
/************************************/
static	int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	ret= -1;
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] < 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
static	int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	ret= -1;
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] < 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/****************************/
/* Make Read Device			*/
/****************************/
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt, int PlcType)
{
	int		i,j;
	int		ret;
	int		idx;
	int		OrBit;
	int		sAddress;
	char	Device[4];
	int		DevInfo;
	char	buff[32];
	char	buff1[32];

	ret = -2;
	sAddress= Address;
	/* Device Name */
	if(GetDevNamePLC2(mode,(unsigned char *)pDevice,Device,&DevInfo) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		for(i = 0; ; i++){
			if(bPLCDeviceTbl[PlcType][i].Device == (char *)0){
				DeviceFlag= -1;
				break;
			}else{
				if(B_gstrcmp(bPLCDeviceTbl[PlcType][i].Device,Device) == 0){
					DeviceFlag= bPLCDeviceTbl[PlcType][i].flag;
					if(DeviceFlag == 1){
						ret = 1;		/* GB */
					}else{
						if((DeviceFlag == 7) && (Address >= 8000)){
							i++;
							Address -= 8000;
						}
						ret = Address % 8;
						BitAndData = 1;
						for(j = 0; j < ret; j++){
							BitAndData <<= 1;
						}
						ret += sCnt;
						ret = (ret- 1) / 8 + 1;
						BitRecCnt = ret;
						Address = (Address + (bPLCDeviceTbl[PlcType][i].StartAddr)) / 8;
						if(PlcType == 0){
							B_gstrcpy(buff,"E00");
						}else{
							B_gstrcpy(buff,"0");
						}
						B_Bin2Hex(Address & 0xffff,4,buff1);
						B_gstrcat(buff,buff1);
						B_Bin2Hex(ret,2,buff1);
						B_gstrcat(buff,buff1);
						B_gstrcpy(combuff,buff);
						ret = 0;
					}
					break;
				}
			}
		}
	}else{
		for(i = 0; ; i++){
			if(wPLCDeviceTbl[PlcType][i].Device == (char *)0){
				DeviceFlag= -1;
				break;
			}else{
				if(B_gstrcmp(wPLCDeviceTbl[PlcType][i].Device,Device) == 0){
					DeviceFlag= wPLCDeviceTbl[PlcType][i].flag;
					if(DeviceFlag == 1){
						ret = 1;		/* GD */
					}else{
						if(DeviceFlag == 2){	/* TS,CS */
							ret= 0;
							idx= Address / 8;
							OrBit= 0x01 << (Address % 8);
							if(PlcType == 0){
								B_gstrcpy(buff,"E0");
								if((Device[0] == 'T') && ((CommonArea.TS_Inf[idx] & OrBit) != 0)){
										Address = Address * 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
										B_Bin2Hex(Address,5,buff1);
								}else if((Device[0] == 'C') && ((CommonArea.CS_Inf[idx] & OrBit) != 0)){
									if(Address == 0){
										B_Bin2Hex(CommonArea.CS_StartAddr+ Address*4,5,buff1);
									}else{
										Address = Address * 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
										B_Bin2Hex(Address,5,buff1);
									}
								}else{
									ret= -2;
								}
							}else{
								B_gstrcpy(buff,"0");
								if((Device[0] == 'T') && ((CommonArea.TS_Inf[idx] & OrBit) != 0)){
									Address = Address * 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
									B_Bin2Hex(Address,4,buff1);
								}else if((Device[0] == 'C') && ((CommonArea.CS_Inf[idx] & OrBit) != 0)){
									Address = Address * 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
									B_Bin2Hex(Address,4,buff1);
								}else{
									ret= -2;
								}
							}
							if(ret == 0){
								B_gstrcat(buff,buff1);
								/*sprintf(buff1,"%02X",sCnt*4);*/
								B_Bin2Hex(sCnt*4,2,buff1);
								B_gstrcat(buff,buff1);
								B_gstrcpy(combuff,buff);
							}
						}else{
							if((DeviceFlag == 3) && (Address >= 200)){	/*C200->*/
								i++;
								Address -= 200;
								Address *= 2;
							}else if((DeviceFlag == 4) && (Address >= 8000)){	/*D800->*/
								i++;
								Address -= 8000;
							}
							if(DeviceFlag == 9){	/* Bit DEVICE(X,Y) */
								Address= Address << 4;
								Address= Address / 8;
								Address = Address + wPLCDeviceTbl[PlcType][i].StartAddr;
							}else if(DeviceFlag == 8){	/* Bit Device (M) */
								if(Address >= 8000){
									i++;
									Address -= 8000;
								}
								Address = (Address / 16)* 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
							}else if((DeviceFlag == 5) || (DeviceFlag == 6)){		/* Z,V */
								if(Address == 0){
									Address= 0x0E38;
								}else{
									Address = Address* 4 + wPLCDeviceTbl[PlcType][i].StartAddr;
								}
								if(DeviceFlag == 6){
									Address += 2;
								}
							}else{
								Address = Address * 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
							}
							if(PlcType == 0){
								B_gstrcpy(buff,"E00");
							}else{
								B_gstrcpy(buff,"0");
							}
							/*sprintf(buff1,"%04X",Address & 0xffff);*/
							B_Bin2Hex(Address & 0xffff,4,buff1);
							B_gstrcat(buff,buff1);
							/*sprintf(buff1,"%02X",sCnt*2);*/
							if(DeviceFlag == 9){	/* Bit DEVICE */
								B_Bin2Hex(sCnt,2,buff1);
							}else{
								B_Bin2Hex(sCnt*2,2,buff1);
							}
							B_gstrcat(buff,buff1);
							B_gstrcpy(combuff,buff);
							ret = 0;
						}
					}
					break;
				}
			}
		}
	}
	return(ret);
}
/************************************/
/*	Device & Address Change			*/
/************************************/
static	int	plcGetDevAddInf(int bwflag,unsigned char *src,int *Keta,int *LowMax)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	PLCByteCnt= *(int *)PLC_DEV_TBLBCT;
	ByteTbl= (DEV_PC_TBL *)PLC_DEV_TBLBYT;
	PLCWordCnt= *(int *)PLC_DEV_TBLWCT;		/*  */
	WordTbl= (DEV_PC_TBL *)PLC_DEV_TBLWOR;
	PLCIndex= (unsigned char *)PLC_DEV_TBLIDX;
	ret= -1;
	if(bwflag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			*Keta= ByteTbl[PLCIndex[src[0]]].LowKeta;
			*LowMax= ByteTbl[PLCIndex[src[0]]].LowDeviceMax;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			*Keta= WordTbl[PLCIndex[src[0]]].LowKeta;
			*LowMax= WordTbl[PLCIndex[src[0]]].LowDeviceMax;
			ret= 0;
		}
	}
	return(ret);
}
static	void	plcChangeAddressUsr(int Digit1,int Digit0, int *Address,int LowMax,int Keta)
{
	int		i;
	unsigned int	work;
	unsigned int	work1;
	unsigned int	work2;

	work= (unsigned int)*Address;
	work1= work%LowMax;				/* 1Keta */
	work2= 0;
	for(i = 0;i < Keta; i++){
		work2 += (work1 % Digit0) << (i*4);
		work1= work1/Digit0;
	}
	work= work/LowMax;
	for(;i < 8; i++){
		if(work == 0){
			break;
		}
		work2 += (work % Digit1) << (i*4);
		work= work/Digit1;
	}
	*Address= work2;
}
/*********************************************************************/
static	int	plcSetPLCUsrAddr(int DevInfo,int Address,unsigned char idx,int bFlag)
{
	int		ret;
	int		LowMax;
	int		Keta;

	ret= plcGetDevAddInf(bFlag,&idx,&Keta,&LowMax);
	if(ret == 0){
		LowMax++;
		ret= Address;
		switch(DevInfo & 0x0f){
		case 0:		/* 8/8 */
			plcChangeAddressUsr(8,8,&ret,LowMax,Keta);
			break;
		case 1:		/* 8/10 */
			plcChangeAddressUsr(8,10,&ret,LowMax,Keta);
			break;
		case 2:		/* 8/16 */
			plcChangeAddressUsr(8,16,&ret,LowMax,Keta);
			break;
		case 3:		/* 10/8 */
			plcChangeAddressUsr(10,8,&ret,LowMax,Keta);
			break;
		case 4:		/* 10/10 */
			plcChangeAddressUsr(10,10,&ret,LowMax,Keta);
			break;
		case 5:		/* 10/16 */
			plcChangeAddressUsr(10,16,&ret,LowMax,Keta);
			break;
		case 6:		/* 16/8 */
			plcChangeAddressUsr(16,8,&ret,LowMax,Keta);
			break;
		case 7:		/* 16/10 */
			plcChangeAddressUsr(16,10,&ret,LowMax,Keta);
			break;
		case 8:		/* 16/16 */
/*			ChangeAddressUsr(16,16,&ret,LowMax,Keta);*/
			break;
		case 9:		/* 16 */
			plcChangeAddressUsr(10,10,&ret,10,1);
			break;
		}
	}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		i,j;
	int		ret;
	int		Cnt,dCnt;
	int		rCnt;
	unsigned char	*SaveAddr;
	int		EndFlag;
	int		Address;
	unsigned char wdata;

	Address= mp->mpar;
	EndFlag= 0;
	while(EndFlag == 0){
		switch(mp->mpec){
		case PLC_BIT:		/* Bit Device */
			if(mp->mext > MAX_BITCNT){
				dCnt= MAX_BITCNT;
				mp->mext -= MAX_BITCNT;
			}else{
				dCnt= mp->mext;
				mp->mext= 0;
			}
			ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],dCnt,PlcType);
			Cnt = dCnt;
			rCnt = BitRecCnt;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				if(SendRecPLCWithBCC(2,PlcSendBuff,(unsigned char *)rDataFx,&i,0) == 0){
					j= 0;
					wdata= B_Hex2Bin((char *)&rDataFx[j*2+ 1]);
					for(i = 0; i < Cnt; i++){
						if(wdata & BitAndData){
							*(unsigned char *)SaveAddr++ = 1;
						}else{
							*(unsigned char *)SaveAddr++ = 0;
						}
						BitAndData <<= 1;
						if(BitAndData > 128){
							BitAndData = 1;
							j++;
							wdata= B_Hex2Bin((char *)&rDataFx[j*2+ 1]);
						}
					}
					if(mp->mext > 0){
						Address += MAX_BITCNT;
						mp->mpar= Address;
						mp->mptr= (void *)((char *)mp->mptr + MAX_BITCNT);
					}else{
						EndFlag= 1;
					}
				}else{
					EndFlag= 1;
					ret= -1;
				}
			}else{
				EndFlag= 1;
			}
			break;
		case PLC_WORD:		/* Word Device */
			if(mp->mext > MAX_WORDCNT){
				dCnt= MAX_WORDCNT;
				mp->mext -= MAX_WORDCNT;
			}else{
				dCnt= mp->mext;
				mp->mext= 0;
			}
			ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],dCnt,PlcType);
			if(DeviceFlag == 2){		/* TS,CS */
				Cnt = dCnt* 4;
				rCnt = dCnt* 4;
			}else if(DeviceFlag == 9){	/* Bit Dev (X,Y) */
				Cnt = dCnt;
				rCnt = dCnt;
			}else{
				Cnt = dCnt* 2;
				rCnt = dCnt* 2;
			}
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				if(SendRecPLCWithBCC(2,PlcSendBuff,(unsigned char *)rDataFx,&rCnt,0) == 0){
					if((PlcType == 0) && (mp->mbuf[0] == 0xf8) && (mp->mpar == 0)){		/* CS0 */
						for(i = 0,j= 0; i < Cnt; i++,j++){
							if((i % 2) == 0){
								*(unsigned char *)SaveAddr++ = B_Hex2Bin((char *)&rDataFx[j*2+ 1]);
							}
						}
					}else if(DeviceFlag == 9){		/* BitAddr(X,Y) */
						for(i = 0,j= 0; i < Cnt; i++,j++){
							*(unsigned char *)SaveAddr++ = B_Hex2Bin((char *)&rDataFx[j*2+ 1]);
							*(unsigned char *)SaveAddr++ = 0;
						}
					}else{
						for(i = 0,j= 0; i < Cnt; i++,j++){
							*(unsigned char *)SaveAddr++ = B_Hex2Bin((char *)&rDataFx[j*2+ 1]);
						}
					}
					if(mp->mext > 0){
						if((DeviceFlag == 9) || (DeviceFlag == 8)){
							Address += MAX_WORDCNT*16;
						}else{
							Address += MAX_WORDCNT;
						}
						mp->mpar= Address;
						mp->mptr= (void *)((char *)mp->mptr + Cnt);
					}else{
						EndFlag= 1;
					}
				}else{
					ret = -1;
					EndFlag= 1;
				}
			}else{
				EndFlag= 1;
			}
			break;
		}
	}
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data,int PlcType)
{
	int		i;
	int		ret;
	int		sAddress;
	int		DevInfo;
	char	Device[4];
	char	buff1[32];

	ret = -2;
	sAddress= Address;
	/* Device Name */
	if(GetDevNamePLC2(mode,(unsigned char *)pDevice,Device,&DevInfo) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		for(i = 0; ; i++){
			if(bPLCDeviceTbl[PlcType][i].Device == (char *)0){
				DeviceFlag= -1;
				break;
			}else{
				if(B_gstrcmp(bPLCDeviceTbl[PlcType][i].Device,Device) == 0){
					DeviceFlag= bPLCDeviceTbl[PlcType][i].flag;
					if(DeviceFlag == 1){
						ret = 1;		/* GB */
					}else{
						if((DeviceFlag == 7) && (Address >= 8000)){
							i++;
							Address -= 8000;
						}
						Address += bPLCDeviceTbl[PlcType][i].StartAddr;
						if(Cnt == 1){
							if(PlcType == 0){
								B_gstrcpy(combuff,"E");
							}else{
								combuff[0]= 0;
							}
							if(*data == 1){	/* ON */
								B_gstrcat(combuff,"7");
							}else{
								B_gstrcat(combuff,"8");
							}
							/*sprintf(buff1,"%02X",Address & 0x00ff);*/
							B_Bin2Hex(Address & 0x00ff,2,buff1);
							B_gstrcat(combuff,buff1);
							/*sprintf(buff1,"%02X",(Address & 0xff00) >> 8);*/
							B_Bin2Hex((Address & 0xff00) >> 8,2,buff1);
							B_gstrcat(combuff,buff1);
						}else{
						}
						ret = 0;
					}
					break;
				}
			}
		}
	}else{
		for(i = 0; ; i++){
			if(wPLCDeviceTbl[PlcType][i].Device == (char *)0){
				DeviceFlag= -1;
				break;
			}else{
				if(B_gstrcmp(wPLCDeviceTbl[PlcType][i].Device,Device) == 0){
					DeviceFlag= wPLCDeviceTbl[PlcType][i].flag;
					if(wPLCDeviceTbl[PlcType][i].flag == 1){
						ret = 1;		/* GD */
					}else{
						if(DeviceFlag == 2){
							ret= 0;
							if(PlcType == 0){
								B_gstrcpy(combuff,"E1");
								if((Device[0] == 'T') && (CommonArea.TS_StartAddr != 0)){
									/*sprintf(buff1,"%05X",CommonArea.TS_StartAddr+ Address*6);*/
									/*B_Bin2Hex(CommonArea.TS_StartAddr+ Address*6,5,buff1);*/
									Address = Address* 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
									B_Bin2Hex(Address,5,buff1);
								}else if((Device[0] == 'C') && (CommonArea.CS_StartAddr != 0)){
									if(Address == 0){
										B_Bin2Hex(CommonArea.CS_StartAddr+ Address,5,buff1);
									}else{
										Address = Address* 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
										B_Bin2Hex(Address,5,buff1);
									}
								}else{
									ret= -2;
								}
							}else{
								B_gstrcpy(combuff,"1");
								if((Device[0] == 'T') && (CommonArea.TS_StartAddr != 0)){
									/*sprintf(buff1,"%05X",CommonArea.TS_StartAddr+ Address*6);*/
									/*B_Bin2Hex(CommonArea.TS_StartAddr+ Address*6,5,buff1);*/
									Address = Address* 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
									B_Bin2Hex(Address,4,buff1);
								}else if((Device[0] == 'C') && (CommonArea.CS_StartAddr != 0)){
									Address = Address* 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
									B_Bin2Hex(Address,4,buff1);
								}else{
									ret= -2;
								}
							}
							if(ret == 0){
								B_gstrcat(combuff,buff1);
								/*sprintf(buff1,"%02X",Cnt*4);*/
								if((PlcType == 0) && (Address == 0) && (Device[0] == 'C')){
									B_Bin2Hex(Cnt*4,2,buff1);
									B_gstrcat(combuff,buff1);
									for(i = 0; i < Cnt*4; i++){
										if((i % 2) == 0){
											/*sprintf(buff1,"%02X",*data++ & 0x00ff);*/
											B_Bin2Hex(*data++ & 0x00ff,2,buff1);
										}else{
											/*sprintf(buff1,"%02X",0x80 & 0x00ff);*/
											B_Bin2Hex(0x80 & 0x00ff,2,buff1);
										}
										B_gstrcat(combuff,buff1);
									}
								}else{
									B_Bin2Hex(Cnt*2,2,buff1);
									B_gstrcat(combuff,buff1);
									for(i = 0; i < Cnt*2; i++){
										/*sprintf(buff1,"%02X",*data++ & 0x00ff);*/
										B_Bin2Hex(*data++ & 0x00ff,2,buff1);
										B_gstrcat(combuff,buff1);
									}
								}
							}
						}else{
							if((DeviceFlag == 3) && (Address >= 200)){	/*C200->*/
								i++;
								Address -= 200;
								Address *= 2;
							}else if((DeviceFlag == 4) && (Address >= 8000)){	/*D800->*/
								i++;
								Address -= 8000;
							}
							if(DeviceFlag == 9){	/* BIT DEVICE(8) */
								Address= Address << 4;
								Address= Address / 8;
								Address = Address + wPLCDeviceTbl[PlcType][i].StartAddr;
							}else if(DeviceFlag == 8){	/* Bit Device (16) */
								if(Address >= 8000){
									i++;
									Address -= 8000;
								}
								Address = (Address / 16)* 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
							}else if((DeviceFlag == 5) || (DeviceFlag == 6)){		/* Z,V */
								if(Address == 0){
									Address= 0x0E38;
								}else{
									Address = Address* 4 + wPLCDeviceTbl[PlcType][i].StartAddr;
								}
								if(DeviceFlag == 6){
									Address += 2;
								}
							}else{
								Address = Address* 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
							}
							if(PlcType == 0){
								B_gstrcpy(combuff,"E10");
							}else{
								B_gstrcpy(combuff,"1");
							}
							/*sprintf(buff1,"%04X",Address & 0xffff);*/
							B_Bin2Hex(Address & 0xffff,4,buff1);
							B_gstrcat(combuff,buff1);
							/*sprintf(buff1,"%02X",Cnt*2);*/
							if(DeviceFlag == 9){	/* BIT DEVICE(X,Y) */
								B_Bin2Hex(Cnt,2,buff1);
								B_gstrcat(combuff,buff1);
								for(i = 0; i < Cnt; i++){
									/*sprintf(buff1,"%02X",*data++ & 0x00ff);*/
									B_Bin2Hex(*data++ & 0x00ff,2,buff1);
									B_gstrcat(combuff,buff1);
									data++;
								}
							}else{
								B_Bin2Hex(Cnt*2,2,buff1);
								B_gstrcat(combuff,buff1);
								for(i = 0; i < Cnt*2; i++){
									/*sprintf(buff1,"%02X",*data++ & 0x00ff);*/
									B_Bin2Hex(*data++ & 0x00ff,2,buff1);
									B_gstrcat(combuff,buff1);
								}
							}
							ret = 0;
						}
					}
					break;
				}
			}
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,dCnt;
	int		EndFlag;
	int		Address;
	int		i;
	char	*dataAddr;

	Address= mp->mpar;
	EndFlag= 0;
	while(EndFlag == 0){
		switch(mp->mpec){
		case PLC_BIT:		/* Bit Device */
			Address= mp->mpar;
			dataAddr= (char *)mp->mptr;
			for(i= 0; i < (signed)mp->mext; i++){
				ret = MakePLCWriteData(0,(char *)mp->mbuf,Address,1,(char *)&PlcSendBuff[1],dataAddr,PlcType);
				if(ret == 0){
					if(SendRecPLCWithBCC(1,PlcSendBuff,rDataFx,&Cnt,1) == 0){
						Address++;
						dataAddr++;
					}else{
						ret= -1;
						break;
					}
				}else{
					ret= -1;
					break;
				}
			}
			EndFlag= 1;
			break;
		case PLC_WORD:		/* Word Device */
			if(mp->mext > MAX_WORDCNT){
				dCnt= MAX_WORDCNT;
				mp->mext -= MAX_WORDCNT;
			}else{
				dCnt= mp->mext;
				mp->mext= 0;
			}
			ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,dCnt,(char *)&PlcSendBuff[1],(char *)mp->mptr,PlcType);
			if(DeviceFlag == 2){		/* TS,CS */
				Cnt = dCnt* 4;
			}else if(DeviceFlag == 9){		/* BIT DEVICE(X,Y) */
				Cnt= dCnt;
			}else{
				Cnt = dCnt* 2;
			}
			if(ret == 0){
				if(SendRecPLCWithBCC(1,PlcSendBuff,rDataFx,&Cnt,1) == 0){
					if(mp->mext > 0){
						if((DeviceFlag == 9) || (DeviceFlag == 8)){
							Address += MAX_WORDCNT*16;
						}else{
							Address += MAX_WORDCNT;
						}
						mp->mpar= Address;
						mp->mptr= (void *)((char *)mp->mptr + Cnt);
					}else{
						EndFlag= 1;
					}
				}else{
					ret = -1;
					EndFlag= 1;
				}
			}else{
				EndFlag= 1;
			}
			break;
		}
	}
	return(ret);
}
/************************************************/
/*	�O���[�v����								*/
/************************************************/
#ifdef	PLCTYPE_ELSE2
#else
/************************************/
/*	PLC �O���[�v�f�[�^�̍쐬		*/
/************************************/
void	CheckTSCS_PLCFX1N(DEV_DATA *DevData)
{
	int		idx;
	int		OrBit;
	int		ret;
	int		Cnt;
	int		DevInfo;
	char	DeviceName[4];
	char	dBuff[16];

	/* Start Address Read */
	GetDevNamePLC2(DevData->DevFlag,(unsigned char *)DevData->DevName,DeviceName,&DevInfo);
	if(((CommonArea.TS_StartAddr == 0) && (DeviceName[0] == 'T')) ||
		((CommonArea.CS_StartAddr == 0) && (DeviceName[0] == 'C'))){
		B_gstrcpy(&dBuff[1],"E41805C");
		if(DeviceName[0] == 'T'){
			B_gstrcpy(&dBuff[8],"0006");
		}else{
			B_gstrcpy(&dBuff[8],"000E");
		}
		ret= SendRecPLCWithBCC(2,(unsigned char *)dBuff,PlcSendBuff,&Cnt,0);
		if(ret == 0){
			if(DeviceName[0] == 'T'){
				CommonArea.TS_StartAddr= B_Hex2nBin((char *)&PlcSendBuff[1],Cnt- 4);
				if(CommonArea.TS_StartAddr != (unsigned int)0xfffff){
					CommonArea.TS_StartAddr += 2;
				}
			}else{
				CommonArea.CS_StartAddr= B_Hex2nBin((char *)&PlcSendBuff[1],Cnt- 4);
				if(CommonArea.CS_StartAddr != (unsigned int)0xfffff){
					CommonArea.CS_StartAddr += 2;
				}
			}
		}
	}
	B_gstrcpy(&dBuff[1],"E41805C");
	if(DeviceName[0] == 'T'){
		/*sprintf(&dBuff[7],"%02X06",DevData->DevAddress);*/
		B_Bin2Hex(DevData->DevAddress,2,&dBuff[8]);
		B_gstrcpy(&dBuff[10],"06");
	}else{
		/*sprintf(&dBuff[7],"%02X0E",DevData->DevAddress);*/
		B_Bin2Hex(DevData->DevAddress,2,&dBuff[8]);
		B_gstrcpy(&dBuff[10],"0E");
	}
	idx= DevData->DevAddress / 8;
	OrBit= 0x01 << (DevData->DevAddress % 8);
	ret= SendRecPLCWithBCC(2,(unsigned char *)dBuff,PlcSendBuff,&Cnt,0);
	if(DeviceName[0] == 'T'){
		if(ret == OK){
			if(B_gstrncmp((char *)&PlcSendBuff[1],"FFFFF",5) == 0){
				CommonArea.TS_Inf[idx] &= ~OrBit;
			}else{
				CommonArea.TS_Inf[idx] |= OrBit;
			}
		}else{
			CommonArea.TS_Inf[idx] &= ~OrBit;
		}
	}else{
		if(ret == OK){
			if(B_gstrncmp((char *)&PlcSendBuff[1],"FFFFF",5) == 0){
				CommonArea.CS_Inf[idx] &= ~OrBit;
			}else{
				CommonArea.CS_Inf[idx] |= OrBit;
			}
		}else{
			CommonArea.CS_Inf[idx] &= ~OrBit;
		}
	}
}
void	CheckTSCS_PLCFX1S(DEV_DATA *DevData)
{
	int		idx;
	int		OrBit;
	int		ret;
	int		Cnt;
	int		DevInfo;
	char	DeviceName[4];
	char	dBuff[16];

	/* Start Address Read */
	GetDevNamePLC2(DevData->DevFlag,(unsigned char *)DevData->DevName,DeviceName,&DevInfo);
	if(((CommonArea.TS_StartAddr == 0) && (DeviceName[0] == 'T')) ||
		((CommonArea.CS_StartAddr == 0) && (DeviceName[0] == 'C'))){
		B_gstrcpy(&dBuff[1],"4805C");
		if(DeviceName[0] == 'T'){
			B_gstrcpy(&dBuff[6],"0006");
		}else{
			B_gstrcpy(&dBuff[6],"000E");
		}
		ret= SendRecPLCWithBCC(2,(unsigned char *)dBuff,PlcSendBuff,&Cnt,0);
		if(ret == 0){
			if(DeviceName[0] == 'T'){
				CommonArea.TS_StartAddr= B_Hex2nBin((char *)&PlcSendBuff[1],Cnt- 4)+ 2;
				if(CommonArea.TS_StartAddr != (unsigned int)0xfffff){
					CommonArea.TS_StartAddr += 2;
				}
			}else{
				CommonArea.CS_StartAddr= B_Hex2nBin((char *)&PlcSendBuff[1],Cnt- 4)+ 2;
				if(CommonArea.CS_StartAddr != (unsigned int)0xfffff){
					CommonArea.CS_StartAddr += 2;
				}
			}
		}
	}
	B_gstrcpy(&dBuff[1],"4805C");
	if(DeviceName[0] == 'T'){
		/*sprintf(&dBuff[5],"%02X06",DevData->DevAddress);*/
		B_Bin2Hex(DevData->DevAddress,2,&dBuff[6]);
		B_gstrcpy(&dBuff[8],"06");
	}else{
		/*sprintf(&dBuff[5],"%02X0E",DevData->DevAddress);*/
		B_Bin2Hex(DevData->DevAddress,2,&dBuff[6]);
		B_gstrcpy(&dBuff[8],"0E");
	}
	idx= DevData->DevAddress / 8;
	OrBit= 0x01 << (DevData->DevAddress % 8);
	ret= SendRecPLCWithBCC(2,(unsigned char *)dBuff,PlcSendBuff,&Cnt,0);
	if(DeviceName[0] == 'T'){
		if(ret == OK){
			if(B_gstrncmp((char *)&PlcSendBuff[1],"FFFF",4) == 0){
				CommonArea.TS_Inf[idx] &= ~OrBit;
			}else{
				CommonArea.TS_Inf[idx] |= OrBit;
			}
		}else{
			CommonArea.TS_Inf[idx] &= ~OrBit;
		}
	}else{
		if(ret == OK){
			if(B_gstrncmp((char *)&PlcSendBuff[1],"FFFF",4) == 0){
				CommonArea.CS_Inf[idx] &= ~OrBit;
			}else{
				CommonArea.CS_Inf[idx] |= OrBit;
			}
		}else{
			CommonArea.CS_Inf[idx] &= ~OrBit;
		}
	}
}
/*********************************/
/*	PLC GROP(FX1N)		         */
/*********************************/
int	MakePLCDeviceAddr(int BitWord, char *pDevice, int Address, char *buff,int PlcType)
{
	int		i;
	int		ret;
	int		sAddress;
	char	Device[4];
	int		DevInfo;
	char	buff1[32];

	ret= -1;
	sAddress= Address;
	/* Device Name */
	if(((unsigned char)pDevice[0] == 0x7f) || ((unsigned char)pDevice[0] == 0xef)){		/* UB,UW */
		return(ret);
	}
	if(GetDevNamePLC2(BitWord,(unsigned char *)pDevice,Device,&DevInfo) == -1){
		return(ret);
	}
	if(BitWord == 0){		/* Bit */
		for(i = 0; ; i++){
			if(bPLCDeviceTbl[PlcType][i].Device == (char *)0){
				DeviceFlag= -1;
				break;
			}else{
				if(B_gstrcmp(bPLCDeviceTbl[PlcType][i].Device,Device) == 0){
					DeviceFlag= bPLCDeviceTbl[PlcType][i].flag;
					if(DeviceFlag == 1){
						ret = 1;		/* GB */
					}else{
						if((DeviceFlag == 7) && (Address >= 8000)){
							i++;
							Address -= 8000;
						}
						Address += bPLCDeviceTbl[PlcType][i].StartAddr;
						/*sprintf(&buff[0],"%02X",Address & 0x00ff);*/
						B_Bin2Hex(Address & 0x00ff,2,&buff[0]);
						/*sprintf(&buff[2],"%02X",(Address & 0xff00) >> 8);*/
						B_Bin2Hex((Address & 0xff00) >> 8,2,&buff[2]);
						ret = 0;
					}
					break;
				}
			}
		}
	}else{			/* Word */
		for(i = 0; ; i++){
			if(wPLCDeviceTbl[PlcType][i].Device == (char *)0){
				DeviceFlag= -1;
				break;
			}else{
				if(B_gstrcmp(wPLCDeviceTbl[PlcType][i].Device,Device) == 0){
					DeviceFlag= wPLCDeviceTbl[PlcType][i].flag;
					if(DeviceFlag == 1){
						ret = 1;		/* GD */
					}else if((DeviceFlag == 8) || (DeviceFlag == 9)){
						ret= -1;
					}else{
						if(DeviceFlag == 2){
							if(PlcType == 0){
								B_gstrcpy(buff,"E0");
							}else{
								B_gstrcpy(buff,"0");
							}
							if(Device[0] == 'T'){
								/*sprintf(buff1,"%05X",CommonArea.TS_StartAddr+ Address*6);*/
								B_Bin2Hex(CommonArea.TS_StartAddr+ Address*6,5,buff1);
							}else{
								/*sprintf(buff1,"%05X",CommonArea.CS_StartAddr+ Address*6);*/
								B_Bin2Hex(CommonArea.CS_StartAddr+ Address*6,5,buff1);
							}
							B_gstrcat(buff,buff1);
						}else{
							if((DeviceFlag == 3) && (Address >= 200)){	/*C200->*/
								i++;
								Address -= 200;
								Address *= 2;
							}
							if((DeviceFlag == 4) && (Address >= 8000)){	/*D8000->*/
								i++;
								Address -= 8000;
							}
							if((DeviceFlag == 5) || (DeviceFlag == 6)){		/* Z,V */
								if(Address == 0){
									Address= 0x0E38;
								}else{
									Address = Address* 4 + wPLCDeviceTbl[PlcType][i].StartAddr;
								}
								if(DeviceFlag == 6){
									Address += 2;
								}
							}else{
								Address = Address* 2 + wPLCDeviceTbl[PlcType][i].StartAddr;
							}
							Address = (Address/ 256)+ ((Address% 256) << 8);
							/*sprintf(buff,"%04X",Address & 0xffff);*/
							B_Bin2Hex(Address & 0xffff,4,buff);
						}
						ret = 0;
					}
					break;
				}
			}
		}
	}
	return(ret);
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
						MyAddress= DeviceDataSys[i].DevAddress;
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
	int		DevInfo;
	char	Device[4];
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
					MyAddress= DeviceDataSys[i].DevAddress;
					GetDevNamePLC2(DeviceDataSys[i].DevFlag,(unsigned char *)DeviceDataSys[i].DevName,Device,&DevInfo);
					if((Device[0] == 'S') || (Device[0] == 'M')){
						if((Address+ DeviceDataSys[j].DevCnt*16) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}else{
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN								*/
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;

	for(i= 1; i < Bit_Cnt; i++){	/* BIT Start */
		if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].Patarn == 0) && 
			(DeviceDataSys[i].DevCnt == 1) && (DeviceDataSys[i].Continus == 0)){
			for(j= 0; j < i; j++){
				if((DeviceDataSys[j].SameDevInf == 0) &&
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].Patarn == 0) &&
					(DeviceDataSys[j].DevCnt == 1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
					MyAddress= DeviceDataSys[i].DevAddress;
					if(((MyAddress+ DeviceDataSys[j].DevCnt)- Address) < MAX_PBITCNT){
						DeviceDataSys[j].Order= i+1;		/* Next Device */
						DeviceDataSys[j].Continus = (MyAddress+ DeviceDataSys[j].DevCnt)- Address;	/* First */
						DeviceDataSys[j].Patarn= 1;

						DeviceDataSys[i].SameDevInf= 3;
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						DeviceDataSys[i].Patarn= MyAddress- Address+ 1;
						break;
					}
				}else{
					if(((DeviceDataSys[j].SameDevInf == 0) && (DeviceDataSys[j].Patarn != 0)) &&
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
						MyAddress= DeviceDataSys[i].DevAddress;
						if(((MyAddress+ DeviceDataSys[j].DevCnt)- Address) < MAX_PBITCNT){
							/* �擪�̓ǂݍ��ݐ����X�V���� */
							DeviceDataSys[j].Continus = (MyAddress+ DeviceDataSys[j].DevCnt)- Address;	/* First */
							k= j;
							while(1){
								if(DeviceDataSys[k].Order == -1){
									break;
								}
								k= DeviceDataSys[k].Order- 1;
							}
							DeviceDataSys[k].Order= i+1;		/* Next Device */

							DeviceDataSys[i].SameDevInf= 3;
							DeviceDataSys[i].Continus= k+ 1;	/* Befor Device */
							DeviceDataSys[i].Patarn= MyAddress- Address+ 1;
							break;
						}
					}
				}
			}
		}
	}
}
/***************************************************/
/*	WORD GROUP-PATARN								*/
/***************************************************/
void	MakeWordPatarn(int Start)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;

	for(i= Start+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].Patarn == 0) && (DeviceDataSys[i].Continus == 0)){
			for(j= Start; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) && ((DeviceDataSys[j].Order == -1) && (DeviceDataSys[j].Patarn == 0))) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
					MyAddress= DeviceDataSys[i].DevAddress;
					if(((MyAddress+ DeviceDataSys[j].DevCnt)- Address) < MAX_PWORDCNT){
						DeviceDataSys[j].Order= i+1;		/* Next Device */
						DeviceDataSys[j].Continus = (MyAddress+ DeviceDataSys[j].DevCnt)- Address;	/* First */
						DeviceDataSys[j].Patarn= 1;

						DeviceDataSys[i].SameDevInf= 3;
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						DeviceDataSys[i].Patarn= MyAddress- Address;
						break;
					}
				}else{
					if(((DeviceDataSys[j].SameDevInf == 0) && (DeviceDataSys[j].Patarn != 0)) &&
						(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
						MyAddress= DeviceDataSys[i].DevAddress;
						if(((MyAddress+ DeviceDataSys[j].DevCnt)- Address) < MAX_PWORDCNT){
							/* �擪 */
							DeviceDataSys[j].Continus = (MyAddress+ DeviceDataSys[j].DevCnt)- Address;	/* First */
							k= j;
							while(1){
								if(DeviceDataSys[k].Order == -1){
									break;
								}
								k= DeviceDataSys[k].Order- 1;
							}
							DeviceDataSys[k].Order= i+1;		/* Next Device */

							DeviceDataSys[i].SameDevInf= 3;
							DeviceDataSys[i].Continus= k+ 1;	/* Befor Device */
							DeviceDataSys[i].Patarn= MyAddress- Address;
							break;
						}
					}
				}
			}
		}
	}
}
/***************************************************/
/*	WORD GROUP-PATARN								*/
/***************************************************/
void	ClearBWContinue(void)
{
	int		i,j,idx;
	int		MyAddress;
	int		DevInfo;
	char	Device[4];

	for(i= 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus != 0)){
			/* Continue */
			if(DeviceDataSys[i].DevFlag == 0){		/* BIT */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_BIT_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}else{									/* WORD */
				MyAddress= DeviceDataSys[i].DevAddress;
				GetDevNamePLC2(DeviceDataSys[i].DevFlag,(unsigned char *)DeviceDataSys[i].DevName,Device,&DevInfo);
				if((Device[0] == 'S') || (Device[0] == 'M')){
				}else{
					if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_WORD_CONT_CNT){
						/* Clear Continue */
						j= i;
						while(1){
							idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
							DeviceDataSys[j].SameDevInf= 0;
							DeviceDataSys[j].Continus= 0;
							DeviceDataSys[j].Order= -1;
							j= idx;
							if(j < 0){
								break;
							}
						}
					}
				}
			}
		}
	}
}
/********************************************/
/*	Make Group For Fx1N						*/
/********************************************/
int	MakeFx1NGroupBW(int PlcType)
{
	int		idx,i;
	int		AllCnt;
	int		ret= 0;
	int		Cnt;
	int		mCnt;
	char	work[4+ 1];

	if(PcThru1014 != 0){		/* Thru Device ON *//*?????????????*/
		if(PcThruWCnt > 0){
			B_gmemcpy((char *)&PlcSendBuff[18],(char *)PcThruWData,PcThruWCnt*4);
			B_gmemcpy((char *)&PlcSendDevData[0],(char *)PcThruWData,PcThruWCnt*4);
		}
		idx= PcThruWCnt;
	}else{
		idx= 0;
	}
	/*Word Device Set*/
	gDeviceCnt= 0;
	for(i = 0; i < DeviceCntSys; i++){
		/* CS,TS Check */
		if((DeviceDataSys[i].DevFlag == 1) && (DeviceDataSys[i].SameDevInf == 0)){
			if(MakePLCDeviceAddr(DeviceDataSys[i].DevFlag, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work,PlcType) != 0){
				continue;
			}
			if(DeviceFlag == 2){		/* 'TS','CS' */
				CheckTSCS_PLCFX1N(&DeviceDataSys[i]);
			}else{
				if((DeviceDataSys[i].DevCnt == 1) &&
					(DeviceDataSys[i].DevFlag == 1) &&
					(DeviceDataSys[i].Continus == 0) &&
					(DeviceDataSys[i].SameDevInf == 0) ){
/*					if((DeviceFlag != 8) && (DeviceFlag != 9)){*/		/* NOT Bit DEVICE(M,X,Y) */
						B_gstrcpy((char *)&PlcSendBuff[18 + (idx+ gDeviceCnt)*4],work);
						B_gstrcpy((char *)&PlcSendDevData[0 + (idx+ gDeviceCnt)*4],work);
						gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
						gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
						DeviceDataSys[i].SameDevInf= -1;
						gDeviceCnt++;
						gDeviceCntWord++;
						if((idx+ gDeviceCnt) >= MAX_MON_WORDCNT){
							break;						/* MAX */
						}
						if(PcThru1014 != 0){
							AllCnt= PcThruWCnt+ PcThruBCnt+ gDeviceCnt;
						}else{
							AllCnt= gDeviceCnt;
						}
						if(AllCnt >= MAX_MON_WORDCNT){
							break;
						}
/*					}*/
				}
			}
		}
	}
	/***************************************************/
	if(PcThru1014 != 0){		/* Thru Device ON *//*?????????????*/
		if(PcThruBCnt > 0){
			B_gmemcpy((char *)&PlcSendBuff[18 + (idx+ gDeviceCnt)*4],(char *)PcThruBData,PcThruBCnt*4);
			B_gmemcpy((char *)&PlcSendDevData[0 + (idx+ gDeviceCnt)*4],(char *)PcThruBData,PcThruBCnt*4);
		}
		idx= (PcThruWCnt+ PcThruBCnt);
	}else{
		idx= 0;
	}
	for(i = 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].DevCnt == 1) &&
			(DeviceDataSys[i].DevFlag == 0) &&
			(DeviceDataSys[i].Continus == 0) &&
			(DeviceDataSys[i].SameDevInf == 0) ){
			if(MakePLCDeviceAddr(DeviceDataSys[i].DevFlag, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work,PlcType) == 0){
				if((DeviceFlag != 10) && (DeviceFlag != 11)){		/* NOT Bit DEVICE(C,T) */
					B_gstrcpy((char *)&PlcSendBuff[18 + (idx+ gDeviceCnt)*4],work);
					B_gstrcpy((char *)&PlcSendDevData[0 + (idx+ gDeviceCnt)*4],work);
					gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
					gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
					DeviceDataSys[i].SameDevInf= -1;
					gDeviceCnt++;
					gDeviceCntBit++;
					if((idx+ gDeviceCnt) >= MAX_MON_WORDCNT){
						break;						/* MAX */
					}
					if(PcThru1014 != 0){
						AllCnt= PcThruWCnt+ PcThruBCnt+ gDeviceCnt;
					}else{
						AllCnt= gDeviceCnt;
					}
					if(AllCnt >= MAX_MON_WORDCNT){
						break;
					}
				}
			}
		}
	}
	if((gDeviceCnt != 0) || (PcThru1014 != 0)){
		if(PcThru1014 != 0){
			idx= PcThruWCnt+ PcThruBCnt+ gDeviceCnt;
		}else{
			idx= gDeviceCnt;
		}
		AllCnt= idx;
		if(AllCnt > MAX_MON_FIST){
			idx= MAX_MON_FIST;
		}
		/* Data Count */
		/*sprintf(work,"%02X",idx* 2+ 4);*/
		B_Bin2Hex(idx* 2+ 4,2,work);
		B_gmemcpy((char *)&PlcSendBuff[8], work, 2);
		/* Word Count */
		if(PcThru1014 != 0){
			idx= PcThruWCnt+ gDeviceCntWord;
		}else{
			idx= gDeviceCntWord;
		}
		/*sprintf(work,"%02X",idx);*/
		B_Bin2Hex(idx,2,work);
		B_gmemcpy((char *)&PlcSendBuff[10], work, 2);
		/* Bit Count */
		if(PcThru1014 != 0){
			idx= PcThruBCnt+ gDeviceCntBit;
		}else{
			idx= gDeviceCntBit;
		}
		/*sprintf(work,"%02X",idx);*/
		B_Bin2Hex(idx,2,work);
		B_gmemcpy((char *)&PlcSendBuff[14], work, 2);
		if(AllCnt > MAX_MON_FIST){
			PlcSendBuff[18+60*2]= 0;
			ret= SendRecPLCWithBCC(1,PlcSendBuff,PlcSendBuff,&Cnt,1);
			if(ret == 0){
				AllCnt -= MAX_MON_FIST;
				mCnt= MAX_MON_FIST*4;
				for(i= 1; ; i++){
					B_gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));
					/* 2 Command */
					B_gstrcpy((char *)&PlcSendBuff[1],(char *)PLCFX1NHed1);
					B_Bin2Hex(i*0x40,2,work);
					B_gmemcpy((char *)&PlcSendBuff[6], work, 2);
					if(AllCnt > MAX_MON_SECD){
						idx= MAX_MON_SECD;
					}else{
						idx= AllCnt;
					}
					/* Data Count */
					/*sprintf(work,"%02X",idx* 2);*/
					B_Bin2Hex(idx* 2,2,work);
					B_gmemcpy((char *)&PlcSendBuff[8], work, 2);
					B_gmemcpy((char *)&PlcSendBuff[10], (char *)&PlcSendDevData[mCnt], idx* 4); 
					PlcSendBuff[10+idx*4]= 0;
					ret= SendRecPLCWithBCC(1,PlcSendBuff,PlcSendBuff,&Cnt,1);
					if((ret != 0) || (AllCnt <= MAX_MON_SECD)){
						break;
					}
					mCnt += MAX_MON_SECD*4;
					AllCnt -= MAX_MON_SECD;
				}
			}
		}else{
			ret= SendRecPLCWithBCC(1,PlcSendBuff,PlcSendBuff,&Cnt,1);
		}
		if(PcThru1014 != 0){
			PcThru1014Rec = 1;
		}
	}
	return(ret);
}
/*********************************/
/*	PLC GROP(FX1N)		         */
/*********************************/
void	GetGroopSema(void)
{
	if(GroopSema == 0){		/* Grooping Sema */
	}else{
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
			B_Delay(10);
		}
	}
	GroopSema++;
}
void	SetGroopSema(void)
{
	GroopSema= 0;
}
int	MakeGroupPLCFX1N( int PlcType )
{
	int		i,j;
	int		ret;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	ret= 0;
	/* Ts,Cs Start Addr Clear */
	CommonArea.TS_StartAddr= 0;
	CommonArea.CS_StartAddr= 0;
	B_gmemset(CommonArea.TS_Inf,0,sizeof(CommonArea.TS_Inf));
	B_gmemset(CommonArea.CS_Inf,0,sizeof(CommonArea.CS_Inf));
	/* Same Device Check */
	B_gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	B_gstrcpy((char *)&PlcSendBuff[1],(char *)PLCFX1NHed);
	gDeviceCnt= 0;

	if((BitCnt+ WordCnt) > MAX_MON_WORDCNT){
		/* �r�b�g�A���[�h�̘A�����`�F�b�N���� */
		MakeBitContinue();
		MakeWordContinue(TotalBitCnt);
		ret= MakeFx1NGroupBW(PlcType);
	}else{
		ret= MakeFx1NGroupBW(PlcType);
		/* �r�b�g�A���[�h�̘A�����`�F�b�N���� */
		MakeBitContinue();
		MakeWordContinue(TotalBitCnt);
	}
	/* Continue MAX Check */
	ClearBWContinue();
	/* �r�b�g�A���[�h�̃p�^�[�����`�F�b�N���� */
	/* Bit Patarn */
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	/* Word Patarn */
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}
	return(ret);
}
/********************************************/
/*	Make Group For Fx1S						*/
/********************************************/
int	MakeFx1SGroupBW(int PlcType)
{
	int		idx,i;
	int		ret= 0;
	int		Cnt;
	char	work[4+ 1];

	if(PcThru1014 != 0){		/* Thru Device ON *//*?????????????*/
		if(PcThruWCnt > 0){
			B_gmemcpy((char *)&PlcSendBuff[12],(char *)PcThruWData,PcThruWCnt*4);
		}
		idx= PcThruWCnt*4;
	}else{
		idx= 0;
	}
	gDeviceCnt= 0;
	for(i = 0; i < DeviceCntSys; i++){
		/* CS,TS Check */
		if((DeviceDataSys[i].DevFlag == 1) && (DeviceDataSys[i].SameDevInf == 0)){
			if(MakePLCDeviceAddr(DeviceDataSys[i].DevFlag, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work,PlcType) != 0){
				continue;
			}
			if(DeviceFlag == 2){		/* 'TS','CS' */
				CheckTSCS_PLCFX1S(&DeviceDataSys[i]);
			}else{
				if((DeviceDataSys[i].DevCnt == 1) &&
					(DeviceDataSys[i].DevFlag == 1) &&
					(DeviceDataSys[i].Continus == 0) &&
					(DeviceDataSys[i].SameDevInf == 0) ){
					if((DeviceFlag != 9) && (DeviceFlag != 8)){		/* NOT Bit DEVICE(X,Y,M) */
						B_gstrcpy((char *)&PlcSendBuff[12 + idx+ gDeviceCnt*4],work);
						gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
						gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
						DeviceDataSys[i].SameDevInf= -1;
						gDeviceCnt++;
						gDeviceCntWord++;
						if((idx + gDeviceCntWord) >= 15){	/* 19->15 040726 */
							break;
						}
					}
				}
			}
		}
	}
	if((gDeviceCntWord != 0) || (PcThruWCnt != 0)){
		/*sprintf(work,"%02X",(PcThruWCnt+gDeviceCntWord)* 2+ 2);*/
		B_Bin2Hex((PcThruWCnt+gDeviceCntWord)* 2+ 2,2,work);
		B_gmemcpy((char *)&PlcSendBuff[6], work, 2);
		/*sprintf(work,"%02X",(PcThruWCnt+gDeviceCntWord));*/
		B_Bin2Hex((PcThruWCnt+gDeviceCntWord),2,work);
		B_gmemcpy((char *)&PlcSendBuff[8], work, 2);
		ret= SendRecPLCWithBCC(1,PlcSendBuff,PlcSendBuff,&Cnt,1);
	}
	/************************/
	/* Bit Device Set		*/
	/************************/
	B_gstrcpy((char *)&PlcSendBuff[1],(char *)PLCFX1SHedB);
	if(PcThru1014 != 0){		/* Thru Device ON *//*?????????????*/
		if(PcThruBCnt > 0){
			B_gmemcpy((char *)&PlcSendBuff[12],(char *)PcThruBData,PcThruBCnt*4);
		}
		idx= PcThruBCnt*4;
	}else{
		idx= 0;
	}
	for(i = 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].DevCnt == 1) &&
			(DeviceDataSys[i].DevFlag == 0) &&
			(DeviceDataSys[i].Continus == 0) &&
			(DeviceDataSys[i].SameDevInf == 0) ){
			if(MakePLCDeviceAddr(DeviceDataSys[i].DevFlag, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work,PlcType) == 0){
				if((DeviceFlag != 10) && (DeviceFlag != 11)){		/* NOT Bit DEVICE(C,T) */
					B_gstrcpy((char *)&PlcSendBuff[12 + idx+ gDeviceCntBit*4],work);
					gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
					gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
					DeviceDataSys[i].SameDevInf= -1;
					gDeviceCnt++;
					gDeviceCntBit++;
					if((idx + gDeviceCntBit) >= 15){		/* 18->15 040726 */
						break;
					}
				}
			}
		}
	}
	if((gDeviceCntBit != 0) || (PcThruBCnt != 0)){
		/*sprintf(work,"%02X",(PcThruBCnt+gDeviceCntBit)* 2+ 2);*/
		B_Bin2Hex((PcThruBCnt+gDeviceCntBit)* 2+ 2,2,work);
		B_gmemcpy((char *)&PlcSendBuff[6], work, 2);
		/*sprintf(work,"%02X",(PcThruBCnt+gDeviceCntBit));*/
		B_Bin2Hex((PcThruBCnt+gDeviceCntBit),2,work);
		B_gmemcpy((char *)&PlcSendBuff[8], work, 2);
		ret= SendRecPLCWithBCC(1,PlcSendBuff,PlcSendBuff,&Cnt,1);
	}
	if(PcThru1014 != 0){
		PcThru1014Rec = 1;
	}
	return(ret);
}
/*********************************/
/*	PLC GROP(FX1S)		         */
/*********************************/

int	MakeGroupPLCFX1S( int PlcType )
{
	int		i,j;
	int		ret= 0;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Ts,Cs Start Addr Clear */
	CommonArea.TS_StartAddr= 0;
	CommonArea.CS_StartAddr= 0;
	B_gmemset(CommonArea.TS_Inf,0,sizeof(CommonArea.TS_Inf));
	B_gmemset(CommonArea.CS_Inf,0,sizeof(CommonArea.CS_Inf));
	/* Same Device Check */
	B_gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	for(i = 1; i < DeviceCntSys; i++){
		/* ����PLC�`�F�b�N */
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		for(j = 0; j < i; j++){
			if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
				(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
				(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
				(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
				break;
			}
		}
		if(j != i){		/* Same Device */
			DeviceDataSys[i].SameDevInf= 1;
			DeviceDataSys[i].Order= j+ 1;
		}else{
			if(DeviceDataSys[i].DevFlag == 0){
				BitCnt++;
			}else{
				WordCnt++;
			}
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	/* Word Device Set */
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	B_gstrcpy((char *)&PlcSendBuff[1],(char *)PLCFX1SHedW);
	gDeviceCnt= 0;
	if((BitCnt+ WordCnt) > MAX_MON_WD_1S){
		/* �r�b�g�A���[�h�̘A�����`�F�b�N���� */
		MakeBitContinue();
		MakeWordContinue(TotalBitCnt);
		ret= MakeFx1SGroupBW(PlcType);
	}else{
		ret= MakeFx1SGroupBW(PlcType);
		/* �r�b�g�A���[�h�̘A�����`�F�b�N���� */
		MakeBitContinue();
		MakeWordContinue(TotalBitCnt);
	}
	/* Continue MAX Check */
	ClearBWContinue();
	/* �r�b�g�A���[�h�̃p�^�[�����`�F�b�N���� */
	/* Bit Patarn */
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	/* Word Patarn */
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}
	return(ret);
}
/************************************/
/*	PLC Group DEVICE Read			*/
/************************************/
int	GrpDevCnt;
int	RecGroupPLCFX1N( void )
{
	int		ret;
	int		wIdx;
	int		idx;
	int		sidx;
	int		i,j;
	int		BitCnt;
	int		wBitCnt;
	int		WordCnt;
	int		AndData;
	unsigned char wData;
	int	wBitCntIdx;
	char	work[16];
	int		EntryAddr;

	if((gDeviceCntBit == 0) && (gDeviceCntWord == 0) && (PcThru1014 == 0)){
		return(0);
	}

	ret= 0;
	if(PcThru1014 != 0){
		WordCnt= gDeviceCntWord+ PcThruWCnt+ DoubleWordCnt;
		if((gDeviceCntBit != 0) || (PcThruBCnt != 0)){
			BitCnt= ((gDeviceCntBit+PcThruBCnt)- 1)/ 8+ 1;
		}else{
			BitCnt= 0;
		}
	}else{
		WordCnt= gDeviceCntWord;
		if(gDeviceCntBit != 0){
			BitCnt= (gDeviceCntBit- 1)/ 8+ 1;
		}else{
			BitCnt= 0;
		}
	}
	GrpDevCnt= WordCnt*2+ BitCnt;
	if(GrpDevCnt >= 0x40){
		/*sprintf(work,"E001790%02X",0x40);*/
		B_gstrcpy((char *)&PlcSendBuff[1],"E00179040");
	}else{
		/*sprintf(work,"E001790%02X",WordCnt*2+ BitCnt);*/
		B_gstrcpy((char *)&PlcSendBuff[1],"E001790");
		B_Bin2Hex(GrpDevCnt,2,(char *)&PlcSendBuff[8]);
	}
	if(GrpDevCnt > 0x40){
		EntryAddr= 0x1790;
		sidx= 0;
		for(i= 0; ; i++)
		{
			B_Bin2Hex(EntryAddr/0x100,2,(char *)&PlcSendBuff[4]);
			B_Bin2Hex(EntryAddr%0x100,2,(char *)&PlcSendBuff[6]);
			if(GrpDevCnt > 0x40)
			{
				work[7]= '4';
				work[8]= '0';
			}else{
				B_Bin2Hex(GrpDevCnt,2,(char *)&PlcSendBuff[8]);
			}
			ret= SendRecPLCWithBCC(2,PlcSendBuff,PlcSendBuff,&idx,0);
			if(ret == OK){
				B_gmemcpy((char *)&PlcSendDevData[sidx],(char *)PlcSendBuff,idx);
				idx -= 4;
				B_gmemcpy((char *)&PlcSendDevData[sidx], (char *)&PlcSendDevData[sidx+1], idx);
				sidx += idx;
				EntryAddr += 0x40;
			}else{
				break;
			}
			if(GrpDevCnt <= 0x40){
				break;
			}
			GrpDevCnt -= 0x40;
		}
	}else{
		ret= SendRecPLCWithBCC(2,PlcSendBuff,PlcSendBuff,&idx,0);
		if(ret == OK){
			B_gmemcpy((char *)&PlcSendDevData[0], (char *)&PlcSendBuff[1], idx);
		}
	}

	if(ret == OK){
		if(PcThru1014 != 0){
			B_gmemcpy((char *)&PcThruRecData[0],(char *)&PlcSendDevData[0],(PcThruWCnt+ DoubleWordCnt)*4);
			wIdx= (PcThruWCnt+ DoubleWordCnt)*4;
		}else{
			wIdx= 0;
		}
		for(i = 0; i < gDeviceCntWord; i++){
			*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ wIdx]);
			*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 2+ wIdx]);
		}
		if(PcThru1014 != 0){
			wIdx= WordCnt*4;
			if(PcThruBCnt != 0){
				wBitCnt= (PcThruBCnt- 1)/ 8+ 1;
			}else{
		
				wBitCnt= 0;
			}
			PcThruByteCnt= wBitCnt;
			B_gmemcpy((char *)&PcThruRecData[(PcThruWCnt+ DoubleWordCnt)*4],(char *)&PlcSendDevData[WordCnt*4],wBitCnt*2);
		}else{
			wIdx= gDeviceCntWord*4;
			wBitCnt= 0;
		}
		idx= 0;
		wBitCntIdx= wBitCnt;
		if(PcThru1014 != 0){
			if(PcThruBCnt != 0){
				wBitCntIdx= PcThruBCnt;
			}else{
		
				wBitCntIdx= 0;
			}
		}
		for(i = 0; i < BitCnt; i++){
			wData= (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*2+ wIdx]);
			AndData= 1;
			for(j = 0; j < 8; j++){
				if((i*8+ j) >= wBitCntIdx){
					if((i*8+ j) < (wBitCntIdx+ gDeviceCntBit)){
						if((wData & AndData) == 0){
							*gDeviceAddr[idx+ gDeviceCntWord] = 0;
						}else{
							*gDeviceAddr[idx+ gDeviceCntWord] = 1;
						}
						AndData= AndData << 1;
					}
					idx++;
				}else{
					AndData= AndData << 1;
				}
			}
		}
		if((PcThru1014 != 0) && (PcThru1014Rec == 1)){
			PcThru1014Rec= 2;
		}
	}else{			/* Send Error */
/*		Comm0RecMode= 0;*/
	}
	return(ret);
}

int	RecGroupPLCFX1S( void )
{
	int		ret;
	int		wIdx;
	int		idx;
	int		i,j;
	int		BitCnt;
	int		wBitCnt;
	int		WordCnt;
	int		AndData;
	unsigned char wData;
	int	wBitCntIdx;

	if((gDeviceCntBit == 0) && (gDeviceCntWord == 0) && (PcThru1014 == 0)){
		return(0);
	}
	ret= 0;
	/* Word data Read */
	if((PcThruWCnt != 0) || (gDeviceCntWord != 0)){
		WordCnt= gDeviceCntWord+ PcThruWCnt;
		/*sprintf(work,"01958%02X",WordCnt*2);*/
		B_gstrcpy((char *)&PlcSendBuff[1],"01958");
		B_Bin2Hex(WordCnt*2,2,(char *)&PlcSendBuff[6]);
		ret= SendRecPLCWithBCC(2,PlcSendBuff,PlcSendBuff,&ret,0);
		if(ret == OK){
			if(PcThruWCnt != 0){
				B_gmemcpy((char *)&PcThruRecData[0],(char *)&PlcSendBuff[1],PcThruWCnt*4);
				wIdx= PcThruWCnt*4;
			}else{
				wIdx= 0;
			}
			for(i = 0; i < gDeviceCntWord; i++){
				*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendBuff[i*4+ 1+ wIdx]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendBuff[i*4+ 3+ wIdx]);
			}
			if((PcThru1014 != 0) && (PcThru1014Rec == 1)){
				PcThru1014Rec= 2;
			}
		}else{			/* Send Error */
/*			Comm0RecMode= 0;*/
		}
	}
	/* Bit data Read */
	if((gDeviceCntBit != 0) || (PcThruBCnt != 0)){
		BitCnt= ((gDeviceCntBit+PcThruBCnt)- 1)/ 8+ 1;
		/*sprintf(work,"019A0%02X",BitCnt);*/
		B_gstrcpy((char *)&PlcSendBuff[1],"019A0");
		B_Bin2Hex(BitCnt,2,(char *)&PlcSendBuff[6]);
		ret= SendRecPLCWithBCC(2,PlcSendBuff,PlcSendBuff,&ret,0);
		if(ret == 0){
			if(PcThruBCnt != 0){
				wBitCnt= (PcThruBCnt- 1)/ 8+ 1;
			}else{
				wBitCnt= 0;
			}
			B_gmemcpy((char *)&PcThruRecData[256],(char *)&PlcSendBuff[1],wBitCnt*2);
			idx= 0;
			if(PcThruBCnt != 0){
				wBitCntIdx= PcThruBCnt;
			}else{
				wBitCntIdx= 0;
			}
		
			for(i = 0; i < BitCnt; i++){
				wData= (unsigned char)B_Hex2Bin((char *)&PlcSendBuff[i*2+ 1]);
				AndData= 1;
				for(j = 0; j < 8; j++){
					if((i*8+ j) >= wBitCntIdx){
						if((i*8+ j) < (wBitCntIdx+ gDeviceCntBit)){
							if((wData & AndData) == 0){
								*gDeviceAddr[idx+ gDeviceCntWord] = 0;
							}else{
								*gDeviceAddr[idx+ gDeviceCntWord] = 1;
							}
							AndData= AndData << 1;
						}
						idx++;
					}else{
						AndData= AndData << 1;
					}
				}
			}
			if((PcThru1014 != 0) && (PcThru1014Rec == 1)){
				PcThru1014Rec= 2;
			}
		}else{			/* Send Error */
/*			Comm0RecMode= 0;*/
		}
	}
	return(ret);
}
/****************************************/
/*	�O���[�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int	ret;

	if(GroopingFlag != 0){
		while(1){
			if(GroopingFlag == 0){
				break;
			}
			B_Delay(10);
		}
	}
	GetGroopSema();
	switch(PlcType){
	case 0:				/* FX1N */
		ret= MakeGroupPLCFX1N(PlcType);
		break;
	case 1:				/* FX1S */
		ret= MakeGroupPLCFX1S(PlcType);
		break;
	}
	SetGroopSema();
	return(ret);
}
int		RecGroupPLCDev(int PlcType)
{
	int	ret;

	if(GroopingFlag != 0){
		while(1){
			if(GroopingFlag == 0){
				break;
			}
			B_Delay(10);
		}
	}
	GetGroopSema();
	switch(PlcType){
	case 0:
		ret= RecGroupPLCFX1N();
		break;
	case 1:
		ret= RecGroupPLCFX1S();
		break;
	}
	SetGroopSema();
	return(ret);
}
/************************************/
/*	�X���[���[�hfor FX		        */
/************************************/
int	DoublrWordCheck(void)
{
	int	i;
	int	addr;
	int	Cnt;

	Cnt= 0;
	for(i= 0; i < PcThruWCnt; i++)
	{
		addr= (unsigned char)B_Hex2nBin((char*)&PcThruAllData[i*4],2);
		addr= (unsigned char)B_Hex2nBin((char*)&PcThruAllData[i*4+2],2)*256;
		if((addr >= 0x0c00) && (addr <= 0x0cff))
		{
			Cnt++;
		}
	}
	return(Cnt);
}
/********************************************************/
/*	Thrue Mode											*/
/********************************************************/
/*********************************/
/* PC Monitor Check(FX1N)		 */
/*********************************/
int	PcPLCMonitorCheckFX1N(char *buff,char *oBuff,int *Cnt,int PlcConnectFlag)
{
	int		ret;
	char	work[10];

	ret= 9;		/* THRUE COMMAND */
	if(PlcConnectFlag == 0){
		oBuff[0]= NAK;
		*Cnt= 1;
		return(-1);
	}
	if(buff[0] == ENQ){		/* ENQ Recieve */
		if(PlcConnectFlag == 1){
			oBuff[0]= ACK;
		}else{
			oBuff[0]= NAK;
		}
		*Cnt= 1;
		ret= 3;
	}else if(B_gstrncmp(&buff[1],"00E0202",7) == 0){		/* PLC Type Read */
		B_gmemcpy(oBuff,PLCFX1N_00E0202,8);
		*Cnt= 8;
		ret= 5;
	}else if(B_gstrncmp(&buff[1],"00EE804",7) == 0){		/* PLC Type Read */
		B_gmemcpy(oBuff,PLCFX1N_00EE804,12);
		*Cnt= 12;
		ret= 5;
	}else if(B_gstrncmp(&buff[1],(char *)PLCConnectHed,7) == 0){
		oBuff[0]= ACK;
		*Cnt= 1;
		ret= 3;
	}else if(B_gstrncmp(&buff[1],"A1",2) == 0){		/* PLC Type Read */
		oBuff[0]= ACK;
		*Cnt= 1;
		ret= 4;
	}else if(B_gstrncmp(&buff[1],"E1014",5) == 0){		/* Group Command */
		if(B_gstrncmp(&buff[6],"00",2) == 0){
			GroopingFlag= 1;			/* Grooping Start */
			GetGroopSema();
			DoubleWordCnt= 0;
			work[0]= buff[8];
			work[1]= buff[9];
			work[2]= 0;
			PcThruAllCnt= B_LHexAsToBin(work,2)- 4;
			B_gmemcpy((char *)PcThruAllData,(char *)&buff[18],PcThruAllCnt*2);
			work[0]= buff[10];
			work[1]= buff[11];
			work[2]= 0;
			GppPcThruWCnt= B_LHexAsToBin(work,2);
			work[0]= buff[14];
			work[1]= buff[15];
			work[2]= 0;
			GppPcThruBCnt= B_LHexAsToBin(work,2);
			if(PcThruAllCnt >= ((GppPcThruWCnt+ GppPcThruBCnt)* 2)){
				B_gmemcpy((char *)PcThruWData,(char *)&buff[18],GppPcThruWCnt*4);
				B_gmemcpy((char *)PcThruBData,(char *)&buff[18+GppPcThruWCnt*4],GppPcThruBCnt*4);
				PcThruWCnt= GppPcThruWCnt;
				PcThruBCnt= GppPcThruBCnt;
				DoubleWordCnt= DoublrWordCheck();
				PcThru1014= 1;
				PcThru1014Rec= 0;
				ret= 1;
			}else{
				oBuff[0]= ACK;
				*Cnt= 1;
				ret= 0;
			}
		}else{
			work[0]= buff[8];
			work[1]= buff[9];
			work[2]= 0;
			ret= B_LHexAsToBin(work,2);
			B_gmemcpy((char *)&PcThruAllData[PcThruAllCnt*2],(char *)&buff[10],ret*2);
			PcThruAllCnt += ret;
			if(PcThruAllCnt >= ((GppPcThruWCnt+ GppPcThruBCnt)* 2)){
				B_gmemcpy((char *)PcThruWData,(char *)&PcThruAllData[0],GppPcThruWCnt*4);
				B_gmemcpy((char *)PcThruBData,(char *)&PcThruAllData[0+GppPcThruWCnt*4],GppPcThruBCnt*4);
				PcThruWCnt= GppPcThruWCnt;
				PcThruBCnt= GppPcThruBCnt;
				DoubleWordCnt= DoublrWordCheck();
				PcThru1014= 1;
				PcThru1014Rec= 0;
				ret= 1;
			}else{
				oBuff[0]= ACK;
				*Cnt= 1;
				ret= 0;
			}
/*			B_PlcDevInit();*/
		}
	}else if((B_gstrncmp(&buff[1],"E0017",5) == 0) ||		/* Group Command */
		(B_gstrncmp(&buff[1],"E0018",5) == 0)){
		work[0]= buff[5];
		work[1]= buff[6];
		work[2]= buff[7];
		PcThruByteCntStr= B_LHexAsToBin(work,3);
		switch(PcThruByteCntStr){
		case 0x790:
			PcThruByteCntStr= 0;
			break;
		case 0x7d0:
			PcThruByteCntStr= 1;
			break;
		case 0x810:
			PcThruByteCntStr= 2;
			break;
		case 0x850:
			PcThruByteCntStr= 3;
			break;
		default:
			PcThruByteCntStr= 0;
			break;
		}

		work[0]= buff[8];
		work[1]= buff[9];
		PcThruByteCnt179= B_LHexAsToBin(work,2);
		ret= 2;
	}else if(B_gstrncmp(&buff[1],"E61",3) == 0){		/* Group Command */
		ret= 8;
	}
	return(ret);
}
/*********************************/
/* PC Monitor Check(FX1S)		 */
/*********************************/
int	PcPLCMonitorCheckFX1S(char *buff,char *oBuff,int *Cnt,int PlcConnectFlag)
{
	int		ret;
	char	work[10];

	ret= 9;			/* THRU COMMAND */
	if(PlcConnectFlag == 0){
		oBuff[0]= NAK;
		*Cnt= 1;
		return(-1);
	}
	if(buff[0] == ENQ){		/* ENQ Recieve */
		if(PlcConnectFlag == 1){
			oBuff[0]= ACK;
		}else{
			oBuff[0]= NAK;
		}
		*Cnt= 1;
		ret= 3;
	}else if(B_gstrncmp(&buff[1],"00E0202",7) == 0){		/* PLC Type Read */
		B_gmemcpy(oBuff,PLCFX1N_00E0202,8);
		*Cnt= 8;
		ret= 5;
	}else if(B_gstrncmp(&buff[1],"11800",5) == 0){		/* Group Command */
		if(B_gstrncmp(&buff[8],"00",2) == 0){
			ret= 0;
		}else{
			GroopingFlag= 1;
			GetGroopSema();
			work[0]= buff[8];
			work[1]= buff[9];
			work[2]= 0;
			GppPcThruWCnt= B_LHexAsToBin(work,2);
			B_gmemcpy((char *)PcThruWData,(char *)&buff[12],GppPcThruWCnt*4);

			GppPcThruBCnt= 1;
			B_gmemcpy((char *)PcThruBData,(char *)&buff[12+0x26*2],GppPcThruBCnt*4);
			ret= 1;
			PcThruBCnt= GppPcThruBCnt;
			PcThru1014= 1;
			PcThru1014Rec= 0;
		}
	}else if(B_gstrncmp(&buff[1],"01958",5) == 0){		/* WORD Read Group Command */
		work[0]= buff[6];
		work[1]= buff[7];
		PcThruByteCnt1SW= B_LHexAsToBin(work,2);
		ret= 6;
	}else if(B_gstrncmp(&buff[1],"019A0",5) == 0){		/* BIT Read Group Command */
		work[0]= buff[6];
		work[1]= buff[7];
		PcThruByteCnt1SB= B_LHexAsToBin(work,2);
		ret= 7;
	}
	return(ret);
}
int	PLCPcMonitorCheck(char *buff,char *oBuff,int *Cnt,int PlcConnectFlag,int PlcType)
{
	int		ret;

	ret = 3;
	switch(PlcType){
	case 0:				/* FX1N */
		ret= PcPLCMonitorCheckFX1N(buff,oBuff,Cnt,PlcConnectFlag);
		break;
	case 1:				/* FX1S */
		ret= PcPLCMonitorCheckFX1S(buff,oBuff,Cnt,PlcConnectFlag);
		break;
	}
	return(ret);
}
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	int		ret;
	int		Cnt;

/*	CommMode= 0;*/
	*OutBuff= 0;
	/* PLC�֑��M */
	ret= PLCPcMonitorCheck(CommBuff,OutBuff,OutCnt,PlcConnectFlag,PlcType);
	switch(ret){
	case 0:
		if(*OutBuff != 0){
			B_SendPLC2PCData(0,*OutCnt,OutBuff,3000);		/* ACK ���M */
		}
		break;
	case 1:			/* Group Set */
		SetGroopSema();
		switch(PlcType){
		case 0:				/* FX1N */
			ret= MakeGroupPLCFX1N(PLC_Type_In);
			break;
		case 1:				/* FX1S */
			ret= MakeGroupPLCFX1S(PLC_Type_In);
			break;
		}
/*		MakeGroupDevPLC(PLC_Type_In);*/		/* Group Read */
		switch(PLC_Type_In){
		case 0:
			ret= RecGroupPLCFX1N();
			break;
		case 1:
			ret= RecGroupPLCFX1S();
			break;
		}
/*		RecGroupPLCDev(PLC_Type_In);*/
		GroopingFlag= 0;			/* Grooping Start */
		B_SendPLCGroup();
		*OutCnt= 1;
		OutBuff[0]= ACK;
		B_SendPLC2PCData(0,*OutCnt,OutBuff,3000);		/* ACK ���M */
		break;
	case 2:							/* FX1N GROUP */
		if(PcThru1014 == 1){
			if(PcThru1014Rec != 2){		/* �O���[�v����M */
				while(1){
					if(PcThru1014Rec == 2){
						break;
					}
					B_Delay(20);
				}
			}
			Cnt= 0x40*PcThruByteCntStr*2;
			B_gmemcpy(&OutBuff[1],(char *)&PcThruRecData[Cnt],PcThruByteCnt179*2);
			*OutCnt= SetPLCBCC(OutBuff,PcThruByteCnt179*2);
		}else{
			B_gmemset((char *)&OutBuff[1],'0',PcThruByteCnt179*2);
			*OutCnt= SetPLCBCC(OutBuff,PcThruByteCnt179*2);
		}
		if(*OutBuff != 0){
			B_SendPLC2PCData(0,*OutCnt,OutBuff,3000);		/* E100179 ���� ���M */
		}else{
			*OutCnt= 1;
			OutBuff[0]= NAK;
			B_SendPLC2PCData(0,*OutCnt,OutBuff,3000);		/* ACK ���M */
		}
		break;
	case -1:				/* Error */
	case 3:					/* ENQ Response */
		if(*OutBuff != 0){
			B_SendPLC2PCData(0,*OutCnt,OutBuff,3000);		/* E100179 ���� ���M */
		}
		break;
	case 4:					/* A1 Response */
		if(*OutBuff != 0){
			B_SendPLC2PCData(0,*OutCnt,OutBuff,3000);		/* A1���� ���M */
		}
		B_Delay(50);
#ifdef	WIN32
		SioPLCMode= 1;
		SioPLCOpenFlag= 1;
		while(1){
			if(SioPLCOpenFlag == 0){
				break;
			}
			B_Delay(10);
		}
#else
		B_RsModeSet(RS_PC,RS_INIT,RS_19200,RS_DATA7,RS_EVEN);
#endif
		break;
	case 5:
		if(*OutBuff != 0){
			B_SendPLC2PCData(0,*OutCnt,OutBuff,3000);		/* ELSE���� ���M */
		}
		break;
	case 6:							/* FX1S GROUP */
		if((PcThru1014 == 1) && (PcThru1014Rec == 2)){		/* �O���[�v��M�ς� */
			B_gmemcpy(&OutBuff[1],(char *)PcThruRecData,PcThruByteCnt1SW*2);
			*OutCnt= SetPLCBCC(OutBuff,PcThruByteCnt1SW*2);
		}else{
			B_gmemset((char *)&OutBuff[1],'0',PcThruByteCnt1SW*2);
			*OutCnt= SetPLCBCC(OutBuff,PcThruByteCnt1SW*2);
		}
		if(*OutBuff != 0){
			B_SendPLC2PCData(0,*OutCnt,OutBuff,3000);		/* E100179 ���� ���M */
		}
		break;
	case 7:							/* FX1S GROUP */
		if((PcThru1014 == 1) && (PcThru1014Rec == 2)){		/* �O���[�v��M�ς� */
			B_gmemcpy(&OutBuff[1],(char *)&PcThruRecData[256],PcThruByteCnt1SB*2);
			*OutCnt= SetPLCBCC(OutBuff,PcThruByteCnt1SB*2);
		}else{
			B_gmemset((char *)&OutBuff[1],'0',PcThruByteCnt1SB*2);
			*OutCnt= SetPLCBCC(OutBuff,PcThruByteCnt1SB*2);
		}
		if(*OutBuff != 0){
			B_SendPLC2PCData(0,*OutCnt,OutBuff,3000);		/* E100179 ���� ���M */
		}
		break;
	case 8:
		B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
		*OutCnt= *RecCommCnt;
		if(*OutBuff != 0){
			B_SendPLCPCData();
			ret= OK;
		}
		break;
	default:
		B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
		*OutCnt= *RecCommCnt;
		if(*OutBuff != 0){
			B_SendPLCPCData();
		}
		break;
	}
}
#endif
/****************************************************/
/*	Device2Index									*/
/****************************************************/
static	int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
static	int		CheckPLC_Addr(int bwflag,char *src,int *Address1,int *PlcType)
{
	int		i;
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;
	char	obj[5];
	int		iDeviceFlag;
	unsigned char	idx;

	idx= (unsigned char)src[0];
	if(idx == 1){     /* No Device */
		return(-1);
	}
	ret= -1;
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	B_gmemset(obj,0,sizeof(obj));
	if(bwflag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[idx]].DevName,3);
			ret= 0;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[idx]].DevName,3);
			ret= 0;
		}
	}
	if(ret == 0){
		if(bwflag == 0){			/* Bit Device */
			for(i = 0; ; i++){
				if(bPLCDeviceTbl[*PlcType][i].Device == (char *)0){
					ret= -1;
					break;
				}else{
					if(B_gstrcmp(bPLCDeviceTbl[*PlcType][i].Device,obj) == 0){
						iDeviceFlag= bPLCDeviceTbl[*PlcType][i].flag;
						if(iDeviceFlag == 10){			/* T */
							*Address1= DEV_TR;
						}else if(iDeviceFlag == 11){	/* C */
							*Address1= DEV_CR;
						}else{
							ret= -1;
						}
						break;
					}
				}
			}
		}
		else{
			for(i = 0; ; i++){
				if(wPLCDeviceTbl[*PlcType][i].Device == (char *)0){
					ret= -1;
					break;
				}else{
					if(B_gstrcmp(wPLCDeviceTbl[*PlcType][i].Device,obj) == 0){
						iDeviceFlag= wPLCDeviceTbl[*PlcType][i].flag;
						if(iDeviceFlag == 10){			/* T */
							*Address1= DEV_TS;
						}else if(iDeviceFlag == 3){	/* C */
							*Address1= DEV_CS;
						}else{
							ret= -1;
						}
						break;
					}
				}
			}
		}
	}
	return(ret);
}
static	void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_9600;
	*DataBit= RS_DATA7;
	*Parity= RS_EVEN;
}
int	GetSendRecTime2(void)
{
	PlcBuffClear();
	GroopSema= 0;		/* Grooping Sema */
	GroopingFlag= 0;	/* Grooping ON */
	return(0);				/* 0ms */
}
void	Get_Plc2_Ver(char *name)
{
	B_gstrcpy(name,"V1.5M");
}
static	int	Get_Ms_Sel(void)
{
	return(1);				/* 0:Slave,1:Master */
}
//#ifdef	WIN32
/********************************************/
/*	�����֐�								*/
/********************************************/
int	PLC_CONNECT2(int *PlcType,int iConnect)
{
	return(Connection2(PlcType,iConnect));
}
static	int	GET_PLC_NAME(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(GetDevNamePLC2(bFlag,src,obj,DevInfo));
}
int	PLC1CHAR_READ2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc2(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead2(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite2(mp,rDataFx,PlcType));
}
#ifdef	PLCTYPE_ELSE2
#else
static	int	PLC_MAKE_GROUP(int PlcType)
{
	return(MakeGroupDevPLC(PlcType));
}
static	int	PLC_GROUP_READ(int PlcType)
{
	return(RecGroupPLCDev(PlcType));
}
#endif
static	int	PLCPCDOWN(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PLCPCDownThrue(data,CommMode,RecCnt,RecBuff));
}
#ifdef	PLCTYPE_ELSE2
#else
static	void	PLC_THRU_PROC(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	PLCFxThruProc(CommBuff,RecCommCnt,OutBuff,OutCnt,PlcConnectFlag,PlcType);
}
static	int	GET_PLC_MAX(int bFlag,int idx)
{
	return(GetDevMaxPLC(bFlag,idx));
}
static	int	GET_PLC_MIN(int bFlag,int idx)
{
	return(GetDevMinPLC(bFlag,idx));
}
static	int		DEVICE_2_INDEX(int bwflag,char *Name)
{
	return(Device2IndexPLC(bwflag,Name));
}
static	int		CHECK_PLC_ADDR(int bwflag,char *Name,int *Address1,int *plctype)
{
	return(CheckPLC_Addr(bwflag,Name,Address1,plctype));
}
static	void	GET_MON_BAUDRATE(int *Speed,int *DataBit,int *Parity)
{
	GetMonBaudrate(Speed,DataBit,Parity);
}
#endif
int	GET_SEND_REC_TIME2(void)
{
	return(GetSendRecTime2());
}
void	GET_PLC2_VER(char *Name)
{
	Get_Plc2_Ver(Name);
}
static	int	GET_MS_SEL(void)
{
	return(Get_Ms_Sel());
}
//#endif
/****************************** END **********************/
