/************************************************/
/*	PLC ����M �v���O����(Sumson N70Plus)		*/
/*	2003.5.31									*/
/************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

/*#define	PLC_TYPE2	1*/

#ifndef	WIN32
#pragma	section PlcProc2
#endif

#define	BIT_RD2	0x21
#define	BIT_WT2	0x22
#define	WRD_RD2	0x23
#define	WRD_WT2	0x24
#define	BWD_RD2	0x25
#define	BWD_WT2	0x26

#define	BIT_RD4	0x01
#define	BIT_WT4	0x02
#define	WRD_RD4	0x03
#define	WRD_WT4	0x04
#define	BWD_RD4	0x05
#define	BWD_WT4	0x06

/**************************************/
extern	int	Hex2nBin(char *buff,int cnt);
extern	int	Hex2Bin(char *buff);
extern	unsigned int LHexAsToBin(char *buff, int cnt);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	RtsOnOffSet(int type,int mode);
#ifdef	WIN32
extern int __cdecl Delay(int);
extern unsigned int __cdecl ReadSignal(int);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	PlcDevInit( void );
extern	unsigned char			GpFont[0x200000];
#else
#define SGN_PLC		0
#endif
extern	int	SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode);

/**************************************/


/****************************** for Window **********************/
/********************************************/
/*	�O���֐�								*/
/********************************************/
#ifdef	PLC_TYPE2
#ifdef	WIN32
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
#endif
#else
extern	int	B_Hex2nBin(char *buff,int cnt);
extern	int	B_Hex2Bin(char *buff);
extern	unsigned int B_LHexAsToBin(char *buff, int cnt);
extern	int	B_Delay(int p);
extern	int	B_ReadSignal(int p);
extern	void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
#endif
#ifdef	WIN32
int	B_SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode)
{
	return(SendRecPLC2(mode,rData,Cnt,rmode));
}
#endif

/********************************************/
/* PLC-Program Title */
#ifdef	WIN32
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#endif
/********************************/
/*						*/
/********************************/
const	DEV_TBL PLC2bPLCDeviceTbl[16] = {
	{"R" ,0x0000,1},
	{"L" ,0x0800,1},
	{"M" ,0x0C00,1},
	{"K" ,0x1400,1},
	{"F" ,0x1C00,1},
	{"TC",0x1D00,1},
	{"GB" ,    0,4},
};
const	DEV_TBL	PLC2wPLCDeviceTbl[16] = {
	{"R" ,0x0000,1},
	{"L" ,0x0080,1},
	{"M" ,0x00C0,1},
	{"K" ,0x0140,1},
	{"F" ,0x01C0,1},
	{"D" ,0x0200,1},	/* W->D(D�Œ�ŗ���) */
	{"PV",0x0B00,1},
	{"SV",0x0A00,1},
	{"SR",0x0C00,1},
	{"GD" ,    0,4},
};
/************************************/
/* ��M�v���g�R��					*/
/************************************/
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(*CommMode){
	case 0:				/* DA */
		*RecCnt= 0;			/* �`���X�^�[�g */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 1;
		break;
	case 1:				/* SA */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 2;
		break;
	case 2:				/* Command */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 3;
		break;
	case 3:				/* Length */
		RecBuff[(*RecCnt)++] = data;
		PlcProtLeng= data;
		if(PlcProtLeng <= 0){
			*CommMode = 5;
		}else{
			*CommMode = 4;
		}
		break;
	case 4:				/* Data */
		RecBuff[(*RecCnt)++] = data;
		PlcProtLeng--;
		if(PlcProtLeng <= 0){
			*CommMode = 5;
		}
		break;
	case 5:				/* CRC1 */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 6;
		break;
	case 6:				/* CRC2 */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 0;
		ret= 0;
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/

/************************************/
/* ���ʏ���							*/
/************************************/
#ifdef	PLC_TYPE2
int	Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
void	Bin2Hex(int data,int cnt,char *buff)
{
	int		i;
	unsigned int AndData;

	AndData= 0x000f;
	for(i= 1; i < cnt; i++){
		AndData= AndData << 4;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= Bin2Hex1((data & AndData) >> ((cnt- i- 1)*4));
		AndData = AndData >> 4;
	}
	buff[i]= 0;
}
void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= '0'+ ((data / AndData) % 10);
		data= data % AndData;
		AndData = AndData / 10;
	}
	buff[i]= 0;
}
int	gstrlen(char *buff)
{
	int		i;

	for(i= 0; ; i++){
		if(buff[i] == 0){
			break;
		}
	}
	return(i);
}
void	gmemset(char *buff,int data,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*buff= (char)data;
		buff++;
	}
}
void	gmemcpy(char *obj,char *src,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*obj= *src;
		src++;
		obj++;
	}
}
void	gstrcpy(char *obj,char *src)
{
	int		i;

	for(i= 0; ; i++){
		*obj= *src;
		if(*src == 0){
			break;
		}
		src++;
		obj++;
	}
	*obj= 0;
}
int	gstrcmp(char *src,char *obj)
{
	int		i;
	int		ret;

	ret= NG;
	for(i= 0; ; i++){
		if(src[i] == 0){
			if(obj[i] == 0){
				ret= OK;
			}
			break;
		}
		if(obj[i] == 0){
			break;
		}
		if(src[i] != obj[i]){
			break;
		}
	}
	return(ret);
}
int	gstrncmp(char *src,char *obj,int cnt)
{
	int		i;
	int		ret;

	ret= OK;
	for(i= 0; i < cnt; i++){
		if(src[i] != obj[i]){
			ret= NG;
			break;
		}
	}
	return(ret);
}
void	gstrcat(char *src,char *obj)
{
	int		i;

	for(i= 0; ; i++){
		if(*src == 0){
			break;
		}
		src++;
	}
	for(i= 0; ; i++){
		if(*obj == 0){
			*src= 0;
			break;
		}
		*src= *obj;
		src++;
		obj++;
	}
}
#else
extern	int	Bin2Hex1(int data);
extern	void	Bin2Hex(int data,int cnt,char *buff);
extern	void	Bin2dec(int data,int cnt,char *buff);
extern	int	gstrlen(char *buff);
extern	void	gmemset(char *buff,int data,int cnt);
extern	void	gmemcpy(char *obj,char *src,int cnt);
extern	void	gstrcpy(char *obj,char *src);
extern	int	gstrcmp(char *src,char *obj);
extern	int	gstrncmp(char *src,char *obj,int cnt);
extern	void	gstrcat(char *src,char *obj);
#endif
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
int	Bcd2Bin(unsigned int	Address)
{
	int		i,ret;
	int		bairitu;

	bairitu= 1;
	ret= 0;
	for(i= 0; i < 8; i++){
		ret += (Address & 0x000f)* bairitu;
		Address = Address >> 4;
		bairitu *= 10;
		if(Address == 0){
			break;
		}
	}
	return(ret);
}
int PLC2_SetPLCBCC(char *buff,int cnt,unsigned char *OutBuf)
{
	int		i,j;
	unsigned int _crc16;

	_crc16 = 0xffff;
	for(i = 0; i < cnt; i++){
		OutBuf[i] = buff[i];
#ifdef	OLD
		_crc16 = crc16table[((_crc16 >> 8) & 0x00ff) ^ (buff[i] & 0x00ff)] ^ (_crc16 << 8);
#else
		_crc16= _crc16 ^ (buff[i] & 0x00ff);
		for(j= 0; j < 8; j++){
			if((_crc16 & 0x0001) == 0x0001){
				_crc16= (_crc16 >> 1) ^ 0xa001;
			}else{
				_crc16= _crc16 >> 1;
			}
		}
#endif
	}
	OutBuf[cnt] = (unsigned char)_crc16;
	OutBuf[cnt+1] = (unsigned char)(_crc16 >> 8);
	return(cnt + 2);
}
/************************************/
/*	PLC Send						*/
/************************************/
int	PLC2_SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	int		i,j;
	unsigned int  _crc16;
	unsigned int  _crc16Rec;

	PcThruByteCnt= PLC2_SetPLCBCC((char *)combuf,*Cnt,PcThruRecDataWork);
	ret= B_SendRecPLC2(mode,rData,Cnt,rmode);
	if(ret == 0){
		_crc16 = 0xffff;
		for(i = 0; i < *Cnt-2; i++){
#ifdef	OLD
			_crc16 = crc16table[((_crc16 >> 8) & 0xff) ^ rData[i]] ^ (_crc16 << 8);
#else
			_crc16= _crc16 ^ (rData[i] & 0x00ff);
			for(j= 0; j < 8; j++){
				if((_crc16 & 0x0001) == 0x0001){
					_crc16= (_crc16 >> 1) ^ 0xa001;
				}else{
					_crc16= _crc16 >> 1;
				}
			}
#endif
		}
		_crc16Rec= (rData[*Cnt-1] << 8) + (rData[*Cnt-2]);
		if(_crc16 != _crc16Rec){
			ret= -1;
		}
	}
	return(ret);
}
/********************************************/
int	PLC2_SendCommandPLC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	unsigned char Comm;

	Comm= combuf[2] | 0x80;
	ret= PLC2_SendRecPLCWithBCC(mode,combuf,rData,Cnt,rmode);
	if((ret == 0) && (rData[2] == 0x80)){
		combuf[0]= (unsigned char)DstStationNo;	/* DA */
		combuf[1]= (unsigned char)MyStationNo;	/* SA */
		combuf[2]= (unsigned char)0x00;			/* Command */
		combuf[3]= (unsigned char)0x01;			/* Length */
		combuf[4]= (unsigned char)0x00;			/* Command */
		*Cnt= 5;
		ret= PLC2_SendRecPLCWithBCC(mode,combuf,rData,Cnt,0);
		if((ret == 0) && (rData[2] == Comm)){
		}else{
			ret= -1;
		}
	}
	return(ret);
}
/********************************************/
/*	Connection Proc							*/
/*	*PlcType:[0]->PlcType					*/
/*	         [1]->MyStation					*/
/*	         [2]->DstStation				*/
/********************************************/
int	Connection2( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;

	/* �������̃{�[���[�g */
	if((iConnect & 1) == 0){		/* RS-232C */
#ifdef	WIN32
		SioPCMode= 2;
		SioPCOpenFlag= 1;
#else
		B_RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);
#endif
	}else{						/* RS-422 */
#ifdef	WIN32
		SioPLCMode= 2;
		SioPLCOpenFlag= 1;
#else
		B_RsModeSet(RS_PC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);
#endif
	}
#ifdef	WIN32
	while(1){
		if(SioPLCOpenFlag == 0){
			break;
		}
		B_Delay(10);
	}
#endif
	B_Delay(100);

	/* PLC Connect Check */
	MyStationNo= PlcType[1];
	DstStationNo= PlcType[2];
	PcThruRecDataWork[0]= (unsigned char)PlcType[2];	/* DA */
	PcThruRecDataWork[1]= (unsigned char)PlcType[1];	/* SA */
	PcThruRecDataWork[2]= (unsigned char)BWD_RD4;		/* Command */
	PcThruRecDataWork[3]= (unsigned char)0x02;			/* Length */
	PcThruRecDataWork[4]= (unsigned char)0x00;			/* BASE(L) */
	PcThruRecDataWork[5]= (unsigned char)0x40;			/* BASE(H) */

	Cnt= 6;
	ret= PLC2_SendCommandPLC(2,(char *)PcThruRecDataWork,PcThruRecDataWork,&Cnt,0);
	if(ret < 0){
		return(0);
	}
	ret= 1;
	return(ret);
}
/******************************************/
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
int	PLC2MakePLCDevAddress(int mode, char *Device, int Address, int *DevAddr, int sCnt)
{
	int		i;
	int		ret;
	int		OffSet;

	ret = -1;
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(PLC2bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(PLC2bPLCDeviceTbl[i].Device[0] == Device[0]){
					DeviceFlag= PLC2bPLCDeviceTbl[i].flag;
					OffSet= PLC2bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(PLC2wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(PLC2wPLCDeviceTbl[i].Device[0] == Device[0]){
					DeviceFlag= PLC2wPLCDeviceTbl[i].flag;
					OffSet= PLC2wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Bcd2Bin(Address);
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
int	PLC2MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int		DevAddr;

	ret= PLC2MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	if(ret == 0){
		DstStationNo= pDevice[4];
		combuff[0]= DstStationNo;		/* DA */
		combuff[1]= MyStationNo;		/* SA */
		if(mode == 0){		/* BIT */
			combuff[2]= BIT_RD4;		/* Command */
			combuff[3]= 0x03;		/* Length */
			combuff[4]= (char)DevAddr;
			combuff[5]= (char)(DevAddr >> 8);
			combuff[6]= sCnt;
		}else{				/* WORD */
			combuff[2]= WRD_RD4;		/* Command */
			combuff[3]= 0x03;		/* Length */
			combuff[4]= (char)DevAddr;
			combuff[5]= (char)(DevAddr >> 8);
			combuff[6]= sCnt;
		}
	}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt;
	unsigned char	*SaveAddr;

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = PLC2MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PcThruRecData,mp->mext);
		Cnt = mp->mext;
		break;
	case PLC_WORD:		/* Word Device */
		ret = PLC2MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PcThruRecData,mp->mext);
		Cnt = mp->mext;
		break;
	}
	SaveAddr = (unsigned char *)mp->mptr;
	if(ret == 0){
		i= 7;
		ret= PLC2_SendCommandPLC(2,(char *)PcThruRecData,(unsigned char *)rDataFx,&i,0);
		if(ret == 0){
			if(mp->mpec == PLC_BIT){		/* Bit Device */
				for(i = 0; i < Cnt; i++){
					if(rDataFx[i+4] != 0){
						*(unsigned char *)SaveAddr = 1;
						SaveAddr++;
					}else{
						*(unsigned char *)SaveAddr = 0;
						SaveAddr++;
					}
				}
			}else{						/* WORD */
				for(i = 0; i < Cnt*2; i++){
					*(unsigned char *)SaveAddr = rDataFx[i+4];
					SaveAddr++;
				}
			}
		}
	}else if(ret == 1){		/* ����Device */
		ret= 0;
	}
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
int	PLC2MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	int		DevAddr;

	ret= PLC2MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);
	if(ret == 0){
		DstStationNo= pDevice[4];
		combuff[0]= DstStationNo;		/* DA */
		combuff[1]= MyStationNo;		/* SA */
		if(mode == 0){		/* BIT */
			combuff[2]= BIT_WT4;		/* Command */
			combuff[3]= Cnt+2;			/* Length */
			combuff[4]= (char)DevAddr;
			combuff[5]= (char)(DevAddr >> 8);
			for(i= 0; i < Cnt; i++){
				if(data[i] == 0){
					combuff[6+i]= 0;
				}else{
					combuff[6+i]= (char)0xff;
				}
			}
		}else{		/* WORD */
			combuff[2]= WRD_WT4;		/* Command */
			combuff[3]= Cnt*2+2;		/* Length */
			combuff[4]= (char)DevAddr;
			combuff[5]= (char)(DevAddr >> 8);
			for(i= 0; i < Cnt*2; i++){
				combuff[6+i]= data[i];
			}
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = PLC2MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PcThruRecData,(char *)mp->mptr);
		Cnt = mp->mext+2+4;
		break;
	case PLC_WORD:		/* Word Device */
		ret = PLC2MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PcThruRecData,(char *)mp->mptr);
		Cnt = mp->mext*2+2+4;
		break;
	}
	if(ret == 0){
		ret= PLC2_SendCommandPLC(2,(char *)PcThruRecData,rDataFx,&Cnt,0);
	}else if(ret == 1){		/* ����Address */
		ret= 0;
	}
	return(ret);
}
int	GetSendRecTime2(void)
{
	return(0);				/* 0ms */
}
void	Get_Plc2_Ver(char *name)
{
	gstrcpy(name,"V1.10");
}
#ifdef	WIN32
/********************************************/
/*	�����֐�								*/
/********************************************/
int	PLC_CONNECT2(int *PlcType,int iConnect)
{
	return(Connection2(PlcType,iConnect));
}
int	PLC1CHAR_READ2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc2(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead2(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite2(mp,rDataFx,PlcType));
}
int	GET_SEND_REC_TIME2(void)
{
	return(GetSendRecTime2());
}
void	GET_PLC2_VER(char *Name)
{
	Get_Plc2_Ver(Name);
}
#endif
/****************************** END **********************/