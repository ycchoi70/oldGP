/************************************************/
/*	PLC ����M �v���O����(LG-K3P-07AS)			*/
/*	2003.5.31									*/
/************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

/*#define	PLC_TYPE2	1*/
#define	MAX_RTY_COUNT	3
#define	MAX_WORDCNT		5
#define	MAX_WR_WORDCNT	20

#ifndef	WIN32
#pragma	section PlcProc2
#endif

#define	MAX_PLC_STATION	32
#define	MAX_PLC_ERR		10


/**************************************/
extern	int	Hex2nBin(char *buff,int cnt);
extern	int	Hex2Bin(char *buff);
extern	unsigned int LHexAsToBin(char *buff, int cnt);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
#ifdef	WIN32
extern int __cdecl Delay(int);
extern unsigned int __cdecl ReadSignal(int);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	PlcDevInit( void );
extern	unsigned char			GpFont[0x200000];
#else
#define SGN_PLC		0
#endif

extern	int	SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode);

/****************************************************************/
/*	Station Connect Area										*/
/****************************************************************/
int		Plc2_DeviceFlag;						/* Device Check Flag */
int		Plc2_BitRecCnt;
int		Plc2_BitAndData;
char	StationInf[MAX_PLC_STATION];
/****************************** for Window **********************/
/********************************************/
/*	�O���֐�								*/
/********************************************/
#ifdef	PLC_TYPE2
#ifdef	WIN32
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
#endif
#else
extern	int	B_Hex2nBin(char *buff,int cnt);
extern	int	B_Hex2Bin(char *buff);
extern	unsigned int B_LHexAsToBin(char *buff, int cnt);
extern	int	B_Delay(int p);
extern	int	B_ReadSignal(int p);
extern	void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
#endif
/******************************************************************/
#ifdef	WIN32
int	B_SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode)
{
	return(SendRecPLC2(mode,rData,Cnt,rmode));
}
#endif
/********************************************/
/* PLC-Program Title */
#ifdef	WIN32
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#endif
/********************************/
/*	FX Serease					*/
/********************************/
const	DEV_TBL PLC2bPLCDeviceTbl[16] = {
	{"P" ,0x5c00,2},
	{"M" ,0x5d00,3},
	{"K" ,0x6000,2},
	{"F" ,0x6300,2},
	{"L" ,0x5f00,2},
	{"T" ,0x6100,3},
	{"C" ,0x6200,3},
	{"GB" ,    0,4},
};
const	DEV_TBL	PLC2wPLCDeviceTbl[16] = {
	{"P" ,0x5c00,2},
	{"M" ,0x5d00,3},
	{"K" ,0x6000,2},
	{"F" ,0x6300,2},
	{"L" ,0x5f00,2},
	{"D" ,0x0000,4},
	{"T" ,0x5000,3},
	{"C" ,0x5200,3},
	{"S" ,0x6400,2},
	{"GB" ,    0,4},
};
/************************************/
/* ��M�v���g�R��					*/
/************************************/
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(data){
	case STX:
	case ENQ:
	case ACK:
	case NAK:
		*RecCnt= 0;			/* �`���X�^�[�g */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 1;
		break;
	default:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		switch(*CommMode){
		case 1:
			if((data == EOT) || (data == ETX)){
				*CommMode = 0;
				ret= 0;
			}
			break;
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/

/************************************/
/* ���ʏ���							*/
/************************************/
#ifdef	PLC_TYPE2
int	Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
void	Bin2Hex(int data,int cnt,char *buff)
{
	int		i;
	unsigned int AndData;

	AndData= 0x000f;
	for(i= 1; i < cnt; i++){
		AndData= AndData << 4;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= Bin2Hex1((data & AndData) >> ((cnt- i- 1)*4));
		AndData = AndData >> 4;
	}
	buff[i]= 0;
}
void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= '0'+ ((data / AndData) % 10);
		data= data % AndData;
		AndData = AndData / 10;
	}
	buff[i]= 0;
}
int	gstrlen(char *buff)
{
	int		i;

	for(i= 0; ; i++){
		if(buff[i] == 0){
			break;
		}
	}
	return(i);
}
void	gmemset(char *buff,int data,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*buff= (char)data;
		buff++;
	}
}
void	gmemcpy(char *obj,char *src,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*obj= *src;
		src++;
		obj++;
	}
}
void	gstrcpy(char *obj,char *src)
{
	int		i;

	for(i= 0; ; i++){
		*obj= *src;
		if(*src == 0){
			break;
		}
		src++;
		obj++;
	}
	*obj= 0;
}
int	gstrcmp(char *src,char *obj)
{
	int		i;
	int		ret;

	ret= NG;
	for(i= 0; ; i++){
		if(src[i] == 0){
			if(obj[i] == 0){
				ret= OK;
			}
			break;
		}
		if(obj[i] == 0){
			break;
		}
		if(src[i] != obj[i]){
			break;
		}
	}
	return(ret);
}
int	gstrncmp(char *src,char *obj,int cnt)
{
	int		i;
	int		ret;

	ret= OK;
	for(i= 0; i < cnt; i++){
		if(src[i] != obj[i]){
			ret= NG;
			break;
		}
	}
	return(ret);
}
void	gstrcat(char *src,char *obj)
{
	int		i;

	for(i= 0; ; i++){
		if(*src == 0){
			break;
		}
		src++;
	}
	for(i= 0; ; i++){
		if(*obj == 0){
			*src= 0;
			break;
		}
		*src= *obj;
		src++;
		obj++;
	}
}
#else
extern	int	Bin2Hex1(int data);
extern	void	Bin2Hex(int data,int cnt,char *buff);
extern	void	Bin2dec(int data,int cnt,char *buff);
extern	int	gstrlen(char *buff);
extern	void	gmemset(char *buff,int data,int cnt);
extern	void	gmemcpy(char *obj,char *src,int cnt);
extern	void	gstrcpy(char *obj,char *src);
extern	int	gstrcmp(char *src,char *obj);
extern	int	gstrncmp(char *src,char *obj,int cnt);
extern	void	gstrcat(char *src,char *obj);
#endif
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
int PLC2_SetPLCBCC(char *buff,int cnt,unsigned char *OutBuf)
{
	int		i;
	unsigned char bcc;

	OutBuf[0] = STX;
	for(i = 0; i < cnt; i++){
		OutBuf[i+1] = buff[i];
	}
	bcc = 0;
	for(i = 0; i < cnt; i++){
		bcc += OutBuf[i+1];
	}
	/*sprintf((char *)&OutBuf[cnt+1],"%02X",bcc&0x00ff);*/
	Bin2Hex(bcc&0x00ff,2,(char *)&OutBuf[cnt+1]);
	OutBuf[cnt+3] = ETX;
	return(cnt + 4);
}
/************************************/
/*	PLC Send						*/
/************************************/
int	PLC2_SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret,i;
	int		rty_cnt;
	unsigned char bcc;
	unsigned char bcc1;

	PcThruByteCnt= PLC2_SetPLCBCC((char *)combuf,gstrlen(combuf),PcThruRecDataWork);
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
		ret= B_SendRecPLC2(mode,rData,Cnt,rmode);
		if(ret == 0){
			/* DATA->EOT(SUM) */
			bcc= 0;
			for(i = 0; i < *Cnt-4; i++){
				bcc += rData[i+1];
			}
			bcc1= (unsigned char)B_Hex2Bin((char *)&rData[*Cnt-3]);
			if(bcc != bcc1){
				ret= -1;
			}
		}else{
			break;		/* Time Out Error */
		}
		if(ret == OK){
			break;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC2 Connect									*/
/*	IN		:*PlcType	NoUse						*/
/*			:iConnect PLC1-Connect0:RS-422,1:Rs232c	*/
/****************************************************/
int	Connection2( int *PlcType,int iConnect )
{
	int		ret;
/*	int		Cnt;*/

	/* �������̃{�[���[�g */
	if((iConnect & 1) == 0){		/* RS-232C */
#ifdef	WIN32
		SioPLCMode= 2;
		SioPLCOpenFlag= 1;
#else
		B_RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);
#endif
	}else{						/* RS-422 */
#ifdef	WIN32
		SioPCMode= 2;
		SioPCOpenFlag= 1;
#else
		B_RsModeSet(RS_PC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);
#endif
	}
#ifdef	WIN32
	while(1){
		if(SioPLCOpenFlag == 0){
			break;
		}
		B_Delay(10);
	}
#endif
	B_Delay(500);
#ifdef	OLD	/* 041203 */
	/* PLC Connect Check */
	ret= PLC2_SendRecPLCWithBCC(2,"j",PcThruRecDataWork,&Cnt,0);
/*	if(gstrncmp((char *)PcThruRecDataWork,"\x06j",2) != 0){*/
	if(PcThruRecDataWork[0] != 0x06){
		ret= -1;
	}
	if(ret < 0){
		return(0);
	}
#endif
	ret= 1;
/*	Station Inf Clear */
	gmemset(StationInf,0,sizeof(StationInf));
	return(ret);
}
/******************************************/
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
int	PLC2MakePLCDevAddress(int mode, char *Device, int Address, int *DevAddr, int sCnt)
{
	int		i,j;
	int		ret;
	int		OffSet;

	ret = -1;
	/* Device Name */
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = Address % 16;
			Plc2_BitAndData = 1;
			for(j = 0; j < ret; j++){
				Plc2_BitAndData <<= 1;
			}
			ret += sCnt;
			ret = ret / 8 + 1;
			Plc2_BitRecCnt = ret;
			ret = 1;		/* GB */
		}else{
			Plc2_DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(PLC2bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(PLC2bPLCDeviceTbl[i].Device[0] == Device[0]){
					Plc2_DeviceFlag= PLC2bPLCDeviceTbl[i].flag;
					OffSet= PLC2bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(Plc2_DeviceFlag > 0){
				*DevAddr = OffSet+ (Address/ 16) * 2;
				ret = Address % 16;
				Plc2_BitAndData = 1;
				for(j = 0; j < ret; j++){
					Plc2_BitAndData <<= 1;
				}
				ret += sCnt;
				ret = ret / 8 + 1;
				if((ret % 2) != 0){
					ret++;
				}
				Plc2_BitRecCnt = ret;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			Plc2_DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(PLC2wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(PLC2wPLCDeviceTbl[i].Device[0] == Device[0]){
					Plc2_DeviceFlag= PLC2wPLCDeviceTbl[i].flag;
					OffSet= PLC2wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(Plc2_DeviceFlag > 0){
				*DevAddr = OffSet+ Address* 2;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
int	PLC2MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int		DevAddr;
	char	buff[32];
	char	abuff[4+1];

	ret= PLC2MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		if(mode == 0){		/* BIT */
			/*sprintf(combuff,"rM%s00%02X",abuff,BitRecCnt);*/
			gstrcpy(combuff,"rM");
			gstrcat(combuff,abuff);
			gstrcat(combuff,"00");
			Bin2Hex(Plc2_BitRecCnt,2,abuff);
			gstrcat(combuff,abuff);
		}else{				/* WORD */
			/*sprintf(combuff,"rM%s00%02X",abuff,sCnt);*/
			gstrcpy(combuff,"rM");
			gstrcat(combuff,abuff);
			gstrcat(combuff,"00");
			Bin2Hex(sCnt,2,abuff);
			gstrcat(combuff,abuff);
		}
	}
	return(ret);
}
/************************************/
/* Station Check 					*/
/************************************/
int	CeckStation(void)
{
	int		i,ret;

	ret= OK;
	for(i= 0; i < MAX_PLC_STATION; i++){
		if(StationInf[i] > MAX_PLC_ERR){
			ret= NG;
			break;
		}
	}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j;
	int		Cnt,dCnt;
	int		rCnt;
	unsigned char	*SaveAddr;
	int		EndFlag;


	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = PLC2MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PcThruRecData,mp->mext);
		Cnt = mp->mext;
		rCnt = Plc2_BitRecCnt;
		break;
	case PLC_WORD:		/* Word Device */
		EndFlag= 0;
		while(EndFlag == 0){
			if(mp->mext > MAX_WORDCNT){
				dCnt= MAX_WORDCNT;
				mp->mext -= MAX_WORDCNT;
			}else{
				dCnt= mp->mext;
				mp->mext= 0;
			}
			ret = PLC2MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PcThruRecData,dCnt*2);
			Cnt = dCnt* 2;
			rCnt = dCnt* 2;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				if(StationInf[mp->mbuf[4]] == 0){		/* Error Count Up */
					if(PLC2_SendRecPLCWithBCC(2,(char *)PcThruRecData,(unsigned char *)rDataFx,&i,0) == 0){
						if(rDataFx[0] != 0x06){
							ret= -1;
						}else{
							for(i = 0; i < rCnt; i++){
								rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+ 2]);
							}
							for(i = 0,j = 0; i < Cnt; i++){
								*(unsigned char *)SaveAddr++ = rDataFx[i];
							}
							if(mp->mext > 0){
								mp->mpar+= MAX_WORDCNT;
								mp->mptr= (void *)((char *)mp->mptr + Cnt);
							}else{
								EndFlag= 1;
							}
						}
					}else{
						ret = -1;
					}
					if(ret == -1){
						/************************************************/
						/*	Station Check								*/
						/************************************************/
						StationInf[mp->mbuf[4]]++;		/* Error Count Up */
						ret= 0;
						EndFlag= 1;
						/************************************************/
					}
				}else{
					/************************************************/
					/*	Station Check								*/
					/************************************************/
					StationInf[mp->mbuf[4]]++;		/* Error Count Up */
					if(CeckStation() == OK){
						ret= 0;
					}else{
						ret = -1;
					}
					EndFlag= 1;
					/************************************************/
				}
			}
		}
		break;
	}
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
int	PLC2MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	int		DevAddr;
	char	buff[32];
	char	abuff[4+1];

	ret= PLC2MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		if(mode == 0){		/* BIT */
			if(*data == 0){			/* OFF */
				/*sprintf(combuff,"nM%s00",abuff);*/
				gstrcpy(combuff,"nM");
				gstrcat(combuff,abuff);
				gstrcat(combuff,"00");
				/*sprintf(buff,"%04X",(~BitAndData & 0x0000ffff));*/
				Bin2Hex((~Plc2_BitAndData & 0x0000ffff),4,buff);
				abuff[0]= buff[2];
				abuff[1]= buff[3];
				abuff[2]= buff[0];
				abuff[3]= buff[1];
				abuff[4]= 0;
				gstrcat(combuff,abuff);
			}else{
				/*sprintf(combuff,"oM%s00",abuff);*/
				gstrcpy(combuff,"oM");
				gstrcat(combuff,abuff);
				gstrcat(combuff,"00");
				/*sprintf(buff,"%04X",BitAndData);*/
				Bin2Hex(Plc2_BitAndData,4,buff);
				abuff[0]= buff[2];
				abuff[1]= buff[3];
				abuff[2]= buff[0];
				abuff[3]= buff[1];
				abuff[4]= 0;
				gstrcat(combuff,abuff);
			}
		}else{		/* WORD */
			/*sprintf(combuff,"wM%s00%02d",abuff,Cnt*2);*/
			gstrcpy(combuff,"wM");
			gstrcat(combuff,abuff);
			gstrcat(combuff,"00");
			Bin2Hex(Cnt*2,2,buff);
			gstrcat(combuff,buff);
			for(i= 0; i < Cnt*2; i++){
				/*sprintf(buff,"%02X",data[i] & 0xff);*/
				Bin2Hex(data[i] & 0xff,2,buff);
				gstrcat(combuff,buff);
			}
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,dCnt;
	int		EndFlag;

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = PLC2MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PcThruRecData,(char *)mp->mptr);
		Cnt = mp->mext;
		break;
	case PLC_WORD:		/* Word Device */
		EndFlag= 0;
		while(EndFlag == 0){
			if(mp->mext > MAX_WR_WORDCNT){
				dCnt= MAX_WR_WORDCNT;
				mp->mext -= MAX_WR_WORDCNT;
			}else{
				dCnt= mp->mext;
				mp->mext= 0;
			}
			ret = PLC2MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,dCnt,(char *)PcThruRecData,(char *)mp->mptr);
			Cnt = dCnt* 2;
			if(ret == 0){
				if(StationInf[mp->mbuf[4]] == 0){		/* Error Count Up */
					if((PLC2_SendRecPLCWithBCC(2,(char *)PcThruRecData,rDataFx,&Cnt,0) == 0) &&
						(rDataFx[0] == 0x06)){
						ret= 0;
						if(mp->mext > 0){
							mp->mpar+= MAX_WR_WORDCNT;
							mp->mptr= (void *)((char *)mp->mptr + dCnt* 2);
						}else{
							EndFlag= 1;
						}
					}else{
						/************************************************/
						/*	Station Check								*/
						/************************************************/
						StationInf[mp->mbuf[4]]++;		/* Error Count Up */
						ret= 0;
						EndFlag= 1;
						/************************************************/
					}
				}else{
					/************************************************/
					/*	Station Check								*/
					/************************************************/
					StationInf[mp->mbuf[4]]++;		/* Error Count Up */
					if(CeckStation() == OK){
						ret= 0;
					}else{
						ret = -1;
					}
					EndFlag= 1;
					/************************************************/
				}
			}
		}
		break;
	}
	return(ret);
}
int	GetSendRecTime2(void)
{
	return(0);				/* 0ms */
}
void	Get_Plc2_Ver(char *name)
{
	gstrcpy(name,"V1.30");
}
#ifdef	WIN32
/********************************************/
/*	�����֐�								*/
/********************************************/
int	PLC_CONNECT2(int *PlcType,int iConnect)
{
	return(Connection2(PlcType,iConnect));
}
int	PLC1CHAR_READ2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc2(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead2(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite2(mp,rDataFx,PlcType));
}
int	GET_SEND_REC_TIME2(void)
{
	return(GetSendRecTime2());
}
void	GET_PLC2_VER(char *Name)
{
	Get_Plc2_Ver(Name);
}
#endif
/****************************** END **********************/