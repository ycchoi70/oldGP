/************************************************/
/*	PLC ����M �v���O����(MLgMKCnet80s)			*/
/*	2005.02.01									*/
/************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

#ifndef	WIN32
#pragma	section PlcProc
#endif

/*ksc Edit*******************************************/
#define	MAX_BITCNT	16
#define	MAX_WORDCNT	60
#define	MAX_PBITCNT	16
#define	MAX_PWORDCNT	10
#define	MAX_UR_CNT	26
#define	MAX_WORD_CONT_CNT	4
#define	MAX_BIT_CONT_CNT	4

#define	MAX_RTY_COUNT	3
/*ksc Edit*******************************************/


extern	int	Hex2nBin(char *buff,int cnt);
extern	int	Hex2Bin(char *buff);
extern	unsigned int LHexAsToBin(char *buff, int cnt);
extern	void	SendPLCPCData( void );
extern	int	SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode);
extern	int	SendPLC2PCData( int mode );
extern	int	SendPC2PLCData( int mode );
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	int	GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address);
extern	void	RtsOnOffSet(int type,int mode);
#ifdef	WIN32
extern int __cdecl Delay(int);
extern unsigned int __cdecl ReadSignal(int);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	PlcDevInit( void );
extern	unsigned char			GpFont[0x200000];
#else
#define SGN_PLC		0
#endif

/**************************************/


/****************************** for Window **********************/
/********************************************/
/*	�O���֐�								*/
/********************************************/
#ifdef	WIN32
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
void	B_SendPLCPCData( void )
{
	SendPLCPCData();
}
int	B_SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode)
{
	return(SendRecPLC(mode,rData,Cnt,rmode));
}
int	B_SendPLC2PCData( int mode )
{
	return(SendPLC2PCData(mode ));
}
int	B_SendPC2PLCData( int mode )
{
	return(SendPC2PLCData(mode ));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
int	B_GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address)
{
	return(GetDevNamePLCAddr(bFlag,src,obj,DevInfo,Address));
}
void	B_RtsOnOffSet(int type,int mode)
{
	RtsOnOffSet(type,mode);
}
#endif


/*ksc Edit*******************************************/
/* PLC-Program Title */ 
#ifdef	WIN32
char Title[32]= {
	"PLCPROC LGMK80SCnet-V1.00",
};
#else
const char Title[32]= {
	"PLCPROC LGMK80SCnet-V1.00",
};
#endif
/*ksc Edit*******************************************/

#ifdef	WIN32
/*********************************/ 
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#endif
/********************************/
/*	FX Serease					*/
/********************************/
const	unsigned char PLCIndexTable[256]={
	/* BIT */
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0xff,0x02,0x03,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x04,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0x05,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x06,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x07,
	/* WORD */
	0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0xff,0x02,0x03,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x04,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0x05,0x06,0x07,0x08,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x09,0x0a,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x0b,0x0c,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0x0d,0x0e,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x0f,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
};
const	int PLCLowHighFlag= 0;				/* 0:L-H,1:H-L */
const	int	PLC_K3P_SereaseByteCnt= 8;
const	DEV_PC_TBL	PLC_K3P_SereaseByte[32]=
	{
		{1,0x10,{'P',  0, 0},0x85,0x00000000,0x0000063f},
		{1,0x18,{'M',  0, 0},0x85,0x00000000,0x0000191f},
		{1,0x1a,{'K',  0, 0},0x85,0x00000000,0x0000031f},
		{1,0x1b,{'F',  0, 0},0x85,0x00000000,0x0000063f},
		{1,0x28,{'L',  0, 0},0x85,0x00000000,0x0000063f},
		{1,0x34,{'T',  0, 0},0x84,0x00000000,0x00000191},
		{1,0x50,{'C',  0, 0},0x84,0x00000000,0x00000255},
		{1,0x7f,{'U','B', 0},0x88,0x00000000,0x00001024},
	};
const	int	PLC_K3P_SereaseWordCnt= 16;
const	DEV_PC_TBL	PLC_K3P_SereaseWord[32]=
	{
		{2,(unsigned char)0x80,{'P',  0, 0},0x84,0x00000000,0x00000063},
		{2,(unsigned char)0x88,{'M',  0, 0},0x84,0x00000000,0x00000191},
		{2,(unsigned char)0x8a,{'K',  0, 0},0x84,0x00000000,0x00000031},
		{2,(unsigned char)0x8b,{'F',  0, 0},0x84,0x00000000,0x00000063},
		{2,(unsigned char)0x98,{'L',  0, 0},0x84,0x00000000,0x00000063},
		{2,(unsigned char)0xa2,{'T',  0, 0},0xc4,0x00000192,0x00000239},
		{2,(unsigned char)0xa3,{'T',  0, 0},0xc4,0x00000240,0x00000255},
		{2,(unsigned char)0xa4,{'T',  0, 0},0xc4,0x00000000,0x00000143},
		{2,(unsigned char)0xa5,{'T',  0, 0},0xc4,0x00000144,0x00000191},
		{2,(unsigned char)0xb0,{'C',  0, 0},0xc4,0x00000000,0x00000191},
		{2,(unsigned char)0xb1,{'C',  0, 0},0xa4,0x00000192,0x00000255},
		{2,(unsigned char)0xc0,{'D',  0, 0},0xa4,0x00000000,0x00005999},
		{2,(unsigned char)0xc1,{'D',  0, 0},0xa4,0x00006000,0x00009999},
		{2,(unsigned char)0xd4,{'S',  0, 0},0xa4,0x00000000,0x00000079},
		{2,(unsigned char)0xd5,{'S',  0, 0},0xa4,0x00000000,0x00000099},
		{2,(unsigned char)0xef,{'U','W', 0},0x88,0x00000000,0x00001024},
	};
const	DEV_TBL bPLCDeviceTbl[16] = {
	{"P" ,0x5c00,2},
	{"M" ,0x5d00,3},
	{"K" ,0x6000,2},
	{"F" ,0x6300,2},
	{"L" ,0x5f00,2},
	{"T" ,0x6100,3},
	{"C" ,0x6200,3},
/*	{"S" ,0x6400,5},*/
	{"GB" ,    0,4},
};
const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"P" ,0x5c00,2},
	{"M" ,0x5d00,3},
	{"K" ,0x6000,2},
	{"F" ,0x6300,2},
	{"L" ,0x5f00,2},
	{"D" ,0x0000,4},
	{"T" ,0x5000,3},
	{"C" ,0x5200,3},
	{"S" ,0x6400,2},
	{"GD" ,    0,4},
};
/************************************/
/* ��M�v���g�R��					*/
/************************************/
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(data){
	case STX:
	case ENQ:
	case ACK:
	case NAK:
		*RecCnt= 0;			/* �`���X�^�[�g */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 1;
		break;
	default:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		switch(*CommMode){
		case 1:
			if((data == EOT) || (data == ETX)){
				*CommMode = 0;
				ret= 0;
			}
			break;
		}
		break;
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	switch(*CommMode){
	case 0:		/* Normal */
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:		/* Thru Mode */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			if((data == EOT) || (data == ETX)){
				*CommMode = 99;
				ret = 0;	/* Pendding Req */
			}
		}else{
			*CommMode = 0;
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/

/************************************/
/* ���ʏ���							*/
/************************************/
int	Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
void	Bin2Hex(int data,int cnt,char *buff)
{
	int		i;
	unsigned int AndData;

	AndData= 0x000f;
	for(i= 1; i < cnt; i++){
		AndData= AndData << 4;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= Bin2Hex1((data & AndData) >> ((cnt- i- 1)*4));
		AndData = AndData >> 4;
	}
	buff[i]= 0;
}
void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	if(data < 0){			/* - check 041116 */
		
		data *= -1;
		buff[0]= '-';
		for(i= 1; i < cnt+1; i++){								/*cnt+1�̵� ������ */
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}else{
		for(i= 0; i < cnt; i++){
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}
	buff[i]= 0;
}
int	gstrlen(char *buff)
{
	int		i;

	for(i= 0; ; i++){
		if(buff[i] == 0){
			break;
		}
	}
	return(i);
}
void	gmemset(char *buff,int data,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*buff= (char)data;
		buff++;
	}
}
void	gmemcpy(char *obj,char *src,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*obj= *src;
		src++;
		obj++;
	}
}
void	gstrcpy(char *obj,char *src)
{
	int		i;

	for(i= 0; ; i++){
		*obj= *src;
		if(*src == 0){
			break;
		}
		src++;
		obj++;
	}
	*obj= 0;
}
int	gstrcmp(char *src,char *obj)
{
	int		i;
	int		ret;

	ret= NG;
	for(i= 0; ; i++){
		if(src[i] == 0){
			if(obj[i] == 0){
				ret= OK;
			}
			break;
		}
		if(obj[i] == 0){
			break;
		}
		if(src[i] != obj[i]){
			break;
		}
	}
	return(ret);
}
int	gstrncmp(char *src,char *obj,int cnt)
{
	int		i;
	int		ret;

	ret= OK;
	for(i= 0; i < cnt; i++){
		if(src[i] != obj[i]){
			ret= NG;
			break;
		}
	}
	return(ret);
}
void	gstrcat(char *src,char *obj)
{
	int		i;

	for(i= 0; ; i++){
		if(*src == 0){
			break;
		}
		src++;
	}
	for(i= 0; ; i++){
		if(*obj == 0){
			*src= 0;
			break;
		}
		*src= *obj;
		src++;
		obj++;
	}
}
int	gatoi(char *buff)
{
	char	c;
	int	ret;
	int flag;

	ret= 0;
	flag= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){
			break;
		}
		if((c >= '0') && (c <= '9')){
			ret= ret*10;
			ret+= c- '0';
		}else{
			if(c == '+'){
				continue;
			}
			if(c == '-'){
				flag= 1;
				continue;
			}
			break;
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}
unsigned int	Bcd2Asc(int data,int keta,char *buff)
{
	int		i;
	unsigned int	ret;

	ret= 0;
	for(i= 0; i < keta; i++){
		buff[keta- i- 1]= (data & 0x0f) + '0';
		data = data >> 4;
	}
	buff[keta]= 0;
	return(ret);
}
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
int SetPLCBCC(char *buff,int cnt,unsigned char *OutBuf)
{
	int		i;
	unsigned char bcc;

	OutBuf[0] = ENQ;
	for(i = 0; i < cnt; i++){
		OutBuf[i+1] = buff[i];
	}

	OutBuf[cnt+1] = EOT;

	bcc = 0;
	for(i = 0; i < cnt+2; i++){
		bcc += OutBuf[i];
	}
	/*sprintf((char *)&OutBuf[cnt+1],"%02X",bcc&0x00ff);*/
	Bin2Hex(bcc&0x00ff,2,(char *)&OutBuf[cnt+2]);
	return(cnt + 4);
}
/************************************/
/*	PLC Send						*/
/************************************/
int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		i;
	int		ret;
	int		rty_cnt;
	unsigned char bcc;
	unsigned char bcc1;

	PlcCommCnt= SetPLCBCC((char *)combuf,gstrlen(combuf),PlcSendBuff);
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
		ret= B_SendRecPLC(mode,rData,Cnt,rmode);
		if(ret == 0){
			/* DATA->EOT(SUM) */
			bcc= 0;
			for(i = 0; i < *Cnt-4; i++){
				bcc += rData[i+1];
			}
			bcc1= (unsigned char)B_Hex2Bin((char *)&rData[*Cnt-3]);
			if(bcc != bcc1){
				ret= -1;
			}
		}
		if(ret == OK){
			break;
		}
	}
	return(ret);
}
int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;

	PlcCommCnt= SetPLCBCC((char *)combuf,gstrlen(combuf),PlcSendBuff);
	ret= B_SendRecPLC(mode,rData,Cnt,rmode);
	return(ret);
}
int	Connection( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;
	char	buff[32];

	/* �������̃{�[���[�g */
	if((iConnect & 1) == 0){		/* RS-232C */
#ifdef	WIN32
		SioPCMode= 2;
		SioPCOpenFlag= 1;
#else
		B_RsModeSet(RS_PC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);
#endif
	}else{						/* RS-422 */
#ifdef	WIN32
		SioPLCMode= 2;
		SioPLCOpenFlag= 1;
#else
		B_RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);
#endif
	}
#ifdef	WIN32
	while(1){
		if(SioPLCOpenFlag == 0){
			break;
		}
		B_Delay(10);
	}
#endif
	B_Delay(500);


	Bin2Hex(*(PlcType+2),2,buff);
	gstrcat(buff,"RST");

	/* PLC Connect Check */
	ret= SendRecPLCWithBCCCont(2,buff,GrpPLCcombuf,&Cnt,0);			/* ret = 1 : OK, ret = 0 : NG */
/* mode, *combuff, *rdata, *cnt, rmode */

/*	if(gstrncmp((char *)GrpPLCcombuf,"\x06j",2) != 0){*/
	if(GrpPLCcombuf[0] != 0x06){
		ret= -1;
	}
	if(ret < 0){
		return(0);
	}
	ret= 1;
	return(ret);
}
/******************************************/
void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	WIN32
	*PLCByteCnt= (int)PLC_K3P_SereaseByteCnt;
	*PLCWordCnt= (int)PLC_K3P_SereaseWordCnt;		/*  */
	*ByteTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseByte[0];
	*WordTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseWord[0];
	*PLCIndex= (unsigned char *)&PLCIndexTable[0];
#else
	*PLCByteCnt= *(int *)PLC_DEV_TBLBCT;
	*ByteTbl= (DEV_PC_TBL *)PLC_DEV_TBLBYT;
	*PLCWordCnt= *(int *)PLC_DEV_TBLWCT;		/*  */
	*WordTbl= (DEV_PC_TBL *)PLC_DEV_TBLWOR;
	*PLCIndex= (unsigned char *)PLC_DEV_TBLIDX;
#endif
}
/************************************/
/* Get Device Name					*/
/************************************/
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i,j;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(B_GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&i,&Address) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(bPLCDeviceTbl[i].Device[0] == Device[0]){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				if(DeviceFlag == 5){		/* S */
					*DevAddr = OffSet+ (Address/ 100) * 2;
				}else{
					*DevAddr = OffSet+ (Address/ 16) * 2;
					ret = Address % 16;
					BitAndData = 1;
					for(j = 0; j < ret; j++){
						BitAndData <<= 1;
					}
					ret += (sCnt- 1);
					ret = ret / 8 + 1;
					if((ret % 2) != 0){
						ret++;
					}
					BitRecCnt = ret;
				}
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(wPLCDeviceTbl[i].Device[0] == Device[0]){
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address* 2;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/************************************/
/*	Device & Address Change			*/
/************************************/
int	plcGetDevAddInf(int bwflag,unsigned char *src,int *Keta,int *LowMax)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	PLCByteCnt= *(int *)PLC_DEV_TBLBCT;
	ByteTbl= (DEV_PC_TBL *)PLC_DEV_TBLBYT;
	PLCWordCnt= *(int *)PLC_DEV_TBLWCT;		/*  */
	WordTbl= (DEV_PC_TBL *)PLC_DEV_TBLWOR;
	PLCIndex= (unsigned char *)PLC_DEV_TBLIDX;
	ret= -1;
	if(bwflag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			*Keta= ByteTbl[PLCIndex[src[0]]].LowKeta;
			*LowMax= ByteTbl[PLCIndex[src[0]]].LowDeviceMax;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			*Keta= WordTbl[PLCIndex[src[0]]].LowKeta;
			*LowMax= WordTbl[PLCIndex[src[0]]].LowDeviceMax;
			ret= 0;
		}
	}
	return(ret);
}
void	plcChangeAddressUsr(int Digit1,int Digit0, int *Address,int LowMax,int Keta)
{
	int		i;
	unsigned int	work;
	unsigned int	work1;
	unsigned int	work2;

	work= (unsigned int)*Address;
	work1= work%LowMax;				/* 1Keta */
	work2= 0;
	for(i = 0;i < Keta; i++){
		work2 += (work1 % Digit0) << (i*4);
		work1= work1/Digit0;
	}
	work= work/LowMax;
	for(;i < 8; i++){
		if(work == 0){
			break;
		}
		work2 += (work % Digit1) << (i*4);
		work= work/Digit1;
	}
	*Address= work2;
}
/*********************************************************************/
int	plcSetPLCUsrAddr(int DevInfo,int Address,unsigned char idx,int bFlag)
{
	int		ret;
	int		LowMax;
	int		Keta;

	ret= plcGetDevAddInf(bFlag,&idx,&Keta,&LowMax);
	if(ret == 0){
		LowMax++;
		ret= Address;
		switch(DevInfo & 0x0f){
		case 0:		/* 8/8 */
			plcChangeAddressUsr(8,8,&ret,LowMax,Keta);
			break;
		case 1:		/* 8/10 */
			plcChangeAddressUsr(8,10,&ret,LowMax,Keta);
			break;
		case 2:		/* 8/16 */
			plcChangeAddressUsr(8,16,&ret,LowMax,Keta);
			break;
		case 3:		/* 10/8 */
			plcChangeAddressUsr(10,8,&ret,LowMax,Keta);
			break;
		case 4:		/* 10/10 */
			plcChangeAddressUsr(10,10,&ret,LowMax,Keta);
			break;
		case 5:		/* 10/16 */
			plcChangeAddressUsr(10,16,&ret,LowMax,Keta);
			break;
		case 6:		/* 16/8 */
			plcChangeAddressUsr(16,8,&ret,LowMax,Keta);
			break;
		case 7:		/* 16/10 */
			plcChangeAddressUsr(16,10,&ret,LowMax,Keta);
			break;
		case 8:		/* 16/16 */
/*			ChangeAddressUsr(16,16,&ret,LowMax,Keta);*/
			break;
		case 9:		/* 16 */
			plcChangeAddressUsr(10,10,&ret,10,1);
			break;
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int		DevAddr;
	char	buff[32];
	char	abuff[4+1];

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		if(mode == 0){		/* BIT */
			/*sprintf(combuff,"rM%s00%02X",abuff,BitRecCnt);*/
			gstrcpy(combuff,"rM");
			gstrcat(combuff,abuff);
			gstrcat(combuff,"00");
			Bin2Hex(BitRecCnt,2,abuff);
			gstrcat(combuff,abuff);
		}else{				/* WORD */
			/*sprintf(combuff,"rM%s00%02X",abuff,sCnt);*/
			gstrcpy(combuff,"rM");
			gstrcat(combuff,abuff);
			gstrcat(combuff,"00");
			Bin2Hex(sCnt,2,abuff);
			gstrcat(combuff,abuff);
		}
	}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j;
	int		Cnt;
	int		rCnt;
	int		rdata;
	unsigned char	*SaveAddr;
	int		dCnt;
	char	Device[4];
	int		DevInfo;
	int		Address;
	int		UsrAddress;

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		Address= mp->mpar;
		ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);
		dCnt= mp->mext;
		while(1){
			if(dCnt > MAX_BITCNT){
				dCnt -= MAX_BITCNT;
				mp->mext= MAX_BITCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PLCbuf,mp->mext);
			Cnt = mp->mext;
			rCnt = BitRecCnt;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				if(SendRecPLCWithBCC(2,(char *)PLCbuf,(unsigned char *)rDataFx,&i,0) == 0){
					if(rDataFx[0] != 0x06){
						ret= -1;
						break;
					}else{
						for(i = 0; i < rCnt; i++){
							rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+ 2]);
						}
						j= 0;
						rdata= rDataFx[j] + (rDataFx[j+1] << 8);
						for(i = 0; i < Cnt; i++){
							if(rdata & BitAndData){
								*(unsigned char *)SaveAddr++ = 1;
							}else{
								*(unsigned char *)SaveAddr++ = 0;
							}
							BitAndData <<= 1;
							if(BitAndData > 0x8000){
								BitAndData = 1;
								j++;
								rdata= rDataFx[j*2] + (rDataFx[j*2+1] << 8);
							}
						}
					}
				}else{
					ret = -1;
					break;
				}
			}
			if(dCnt == 0){
				break;
			}
			Address += MAX_BITCNT;
			UsrAddress= plcSetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);
			mp->mpar= UsrAddress;
			mp->mptr= (void *)((char *)mp->mptr + MAX_BITCNT);
		}
		break;
	case PLC_WORD:		/* Word Device */
		Address= mp->mpar;
		ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);
		dCnt= mp->mext;
		while(1){
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PLCbuf,mp->mext*2);
			Cnt = mp->mext* 2;
			rCnt = mp->mext* 2;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				if(SendRecPLCWithBCC(2,(char *)PLCbuf,(unsigned char *)rDataFx,&i,0) == 0){
					if(rDataFx[0] != 0x06){
						ret= -1;
						break;
					}else{
						for(i = 0; i < rCnt; i++){
							rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+ 2]);
						}
						for(i = 0; i < Cnt; i++){
							*(unsigned char *)SaveAddr++ = rDataFx[i];
						}
					}
				}else{
					ret = -1;
					break;
				}
			}
			if(dCnt == 0){
				break;
			}
			Address += MAX_WORDCNT;
			UsrAddress= plcSetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);
			mp->mpar= UsrAddress;
			mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
		}
		break;
	}
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	int		DevAddr;
	char	buff[32];
	char	abuff[4+1];

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		if(mode == 0){		/* BIT */
			if(*data == 0){			/* OFF */
				/*sprintf(combuff,"nM%s00",abuff);*/
				gstrcpy(combuff,"nM");
				gstrcat(combuff,abuff);
				gstrcat(combuff,"00");
				/*sprintf(buff,"%04X",(~BitAndData & 0x0000ffff));*/
				Bin2Hex((~BitAndData & 0x0000ffff),4,buff);
				abuff[0]= buff[2];
				abuff[1]= buff[3];
				abuff[2]= buff[0];
				abuff[3]= buff[1];
				abuff[4]= 0;
				gstrcat(combuff,abuff);
			}else{
				/*sprintf(combuff,"oM%s00",abuff);*/
				gstrcpy(combuff,"oM");
				gstrcat(combuff,abuff);
				gstrcat(combuff,"00");
				/*sprintf(buff,"%04X",BitAndData);*/
				Bin2Hex(BitAndData,4,buff);
				abuff[0]= buff[2];
				abuff[1]= buff[3];
				abuff[2]= buff[0];
				abuff[3]= buff[1];
				abuff[4]= 0;
				gstrcat(combuff,abuff);
			}
		}else{		/* WORD */
			/*sprintf(combuff,"wM%s00%02d",abuff,Cnt*2);*/
			gstrcpy(combuff,"wM");
			gstrcat(combuff,abuff);
			gstrcat(combuff,"00");
			Bin2Hex(Cnt*2,2,buff);
			gstrcat(combuff,buff);
			for(i= 0; i < Cnt*2; i++){
				/*sprintf(buff,"%02X",data[i] & 0xff);*/
				Bin2Hex(data[i] & 0xff,2,buff);
				gstrcat(combuff,buff);
			}
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;
	int		dCnt;
	char	Device[4];
	int		DevInfo;
	int		Address;
	int		UsrAddress;

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCbuf,(char *)mp->mptr);
		Cnt = mp->mext;
		if(ret == 0){
			if(SendRecPLCWithBCC(2,(char *)PLCbuf,rDataFx,&Cnt,0) == 0){
				if(rDataFx[0] != 0x06){
					ret= -1;
				}
			}else{
				ret = -1;
			}
		}
		break;
	case PLC_WORD:		/* Word Device */
		Address= mp->mpar;
		ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);
		dCnt= mp->mext;
		while(1){
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCbuf,(char *)mp->mptr);
			if(DeviceFlag == 2){		/* TS,CS */
				Cnt = mp->mext* 4;
			}else{
				Cnt = mp->mext* 2;
			}
			if(ret == 0){
				if(SendRecPLCWithBCC(2,(char *)PLCbuf,rDataFx,&Cnt,0) == 0){
					if(rDataFx[0] != 0x06){
						ret= -1;
						break;
					}
				}else{
					ret = -1;
					break;
				}
			}
			if(dCnt == 0){
				break;
			}
			Address += MAX_WORDCNT;
			UsrAddress= plcSetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);
			mp->mpar= UsrAddress;
			mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
		}
		break;
	}
	return(ret);
}
/************************************************/
/*	�O���[�v����								*/
/************************************************/
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	int	ret;
	int	DevAddr;
	char	buff[8];
	char	abuff[8];

	if(((unsigned char)DevName[0] == 0x7f) || ((unsigned char)DevName[0] == 0xef)){		/* UB,UW */
		return(-1);
	}
	ret= MakePLCDevAddress(mode, DevName, DevAddress, &DevAddr, 2);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		/*sprintf(work,"M%s0002",abuff);*/
		gstrcpy(work,"M");
		gstrcat(work,abuff);
		gstrcat(work,"0002");
	}
	return(ret);
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k,ret;
	int		Address;
	int		MyAddress;
	int		DevInfo;
	char	Device[4];

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);
						MyAddress= DeviceDataSys[i].DevAddress;
						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k,ret;
	int		Address;
	int		MyAddress;
	int		DevInfo;
	char	Device[4];
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);
					MyAddress= DeviceDataSys[i].DevAddress;
					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN								*/
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{
	int		i,j,k,ret;
	int		Address;
	int		MyAddress;
	int		DevInfo;
	char	Device[4];

	for(i= 1; i < Bit_Cnt; i++){	/* BIT Start */
		if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].Patarn == 0) && 
			(DeviceDataSys[i].DevCnt == 1) && (DeviceDataSys[i].Continus == 0)){
			for(j= 0; j < i; j++){
				if((DeviceDataSys[j].SameDevInf == 0) &&
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].Patarn == 0) &&
					(DeviceDataSys[j].DevCnt == 1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);
					MyAddress= DeviceDataSys[i].DevAddress;
					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);
					if(((MyAddress+ DeviceDataSys[j].DevCnt)- Address) < MAX_PBITCNT){
						DeviceDataSys[j].Order= i+1;		/* Next Device */
						DeviceDataSys[j].Continus = (MyAddress+ DeviceDataSys[j].DevCnt)- Address;	/* First */
						DeviceDataSys[j].Patarn= 1;

						DeviceDataSys[i].SameDevInf= 3;
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						DeviceDataSys[i].Patarn= MyAddress- Address+ 1;
						break;
					}
				}else{
					if((DeviceDataSys[j].SameDevInf == 0) && (DeviceDataSys[j].Patarn != 0) && 
						(DeviceDataSys[j].DevCnt == 1) &&
						(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);
						MyAddress= DeviceDataSys[i].DevAddress;
						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);
						if(((MyAddress+ DeviceDataSys[j].DevCnt)- Address) < MAX_PBITCNT){
							/* �擪�̓ǂݍ��ݐ����X�V���� */
							DeviceDataSys[j].Continus = (MyAddress+ DeviceDataSys[j].DevCnt)- Address;	/* First */
							k= j;
							while(1){
								if(DeviceDataSys[k].Order == -1){
									break;
								}
								k= DeviceDataSys[k].Order- 1;
							}
							DeviceDataSys[k].Order= i+1;		/* Next Device */

							DeviceDataSys[i].SameDevInf= 3;
							DeviceDataSys[i].Continus= k+ 1;	/* Befor Device */
							DeviceDataSys[i].Patarn= MyAddress- Address+ 1;
							break;
						}
					}
				}
			}
		}
	}
}
/***************************************************/
/*	WORD GROUP-PATARN								*/
/***************************************************/
void	MakeWordPatarn(int Start)
{
	int		i,j,k,ret;
	int		Address;
	int		MyAddress;
	int		DevInfo;
	char	Device[4];

	for(i= Start+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].Patarn == 0) && (DeviceDataSys[i].Continus == 0)){
			for(j= Start; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) && ((DeviceDataSys[j].Order == -1) && (DeviceDataSys[j].Patarn == 0))) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);
					MyAddress= DeviceDataSys[i].DevAddress;
					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);
					if(((MyAddress+ DeviceDataSys[j].DevCnt)- Address) < MAX_PWORDCNT){
						DeviceDataSys[j].Order= i+1;		/* Next Device */
						DeviceDataSys[j].Continus = (MyAddress+ DeviceDataSys[j].DevCnt)- Address;	/* First */
						DeviceDataSys[j].Patarn= 1;

						DeviceDataSys[i].SameDevInf= 3;
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						DeviceDataSys[i].Patarn= MyAddress- Address;
						break;
					}
				}else{
					if(((DeviceDataSys[j].SameDevInf == 0) && (DeviceDataSys[j].Patarn != 0)) &&
						(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);
						MyAddress= DeviceDataSys[i].DevAddress;
						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);
						if(((MyAddress+ DeviceDataSys[j].DevCnt)- Address) < MAX_PWORDCNT){
							/* �擪 */
							DeviceDataSys[j].Continus = (MyAddress+ DeviceDataSys[j].DevCnt)- Address;	/* First */
							k= j;
							while(1){
								if(DeviceDataSys[k].Order == -1){
									break;
								}
								k= DeviceDataSys[k].Order- 1;
							}
							DeviceDataSys[k].Order= i+1;		/* Next Device */

							DeviceDataSys[i].SameDevInf= 3;
							DeviceDataSys[i].Continus= k+ 1;	/* Befor Device */
							DeviceDataSys[i].Patarn= MyAddress- Address;
							break;
						}
					}
				}
			}
		}
	}
}
/***************************************************/
/*	WORD GROUP-PATARN								*/
/***************************************************/
void	ClearBWContinue(void)
{
	int		i,j,idx;

	for(i= 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus != 0)){
			/* Continue */
			if(DeviceDataSys[i].DevFlag == 0){		/* BIT */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_BIT_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}else{									/* WORD */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_WORD_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	�O���[�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Set Group */
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gDeviceCnt= 0;
	/* Same Device Check */
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	if(BitCnt > 0){
		MakeBitContinue();
	}
	if(WordCnt > 0){
		MakeWordContinue(TotalBitCnt);
	}
	/* Continue MAX Check */
	ClearBWContinue();
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}
	return(0);
}
/************************************/
/*	�O���[�v���[�h			        */
/************************************/
int		SetGroupDevPLC(void)
{
	int		i;
	int		idx;
	char	work[12+ 1];
	int		ret= 0;
	int		Cnt;

	/* Same Device Check */
	gmemset((char *)GrpPLCcombuf, 0, sizeof(GrpPLCcombuf));
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gstrcpy((char *)GrpPLCcombuf,"uW0002");
	idx= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	for(i = 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].DevCnt == 1) &&
			(DeviceDataSys[i].DevFlag == 1) &&
			(DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus == 0)){
			if(PlcMakeDeviceAddr(DeviceDataSys[i].DevFlag, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work) == 0){
				gstrcpy((char *)&GrpPLCcombuf[6 + idx+ gDeviceCnt*9],(char *)work);
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
				gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
				DeviceDataSys[i].SameDevInf= 4;
				gDeviceCnt++;
				gDeviceCntWord++;
			}
		}
		/*sprintf(work,"%02X",gDeviceCntWord);*/
		Bin2Hex(gDeviceCntWord,2,work);
		gmemcpy((char *)&GrpPLCcombuf[4],work,2);
		if(gDeviceCnt > MAX_UR_CNT){
			break;
		}
	}
	if(gDeviceCnt != 0){
		gstrcpy(work,"uA00");
		ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PLCbuf,&Cnt,0);
		if(ret == 0){
/*			if(gstrncmp((char *)PLCbuf,"\x06u",2) != 0){*/
			if(PLCbuf[0] != 0x06){
				ret= -1;
			}
		}
		if(ret == 0){
			ret= SendRecPLCWithBCC(2,(char *)&GrpPLCcombuf[0],(unsigned char *)PLCbuf,&Cnt,0);
			if(ret == 0){
/*				if(gstrncmp((char *)PLCbuf,"\x06u",2) != 0){*/
				if(PLCbuf[0] != 0x06){
					ret= -1;
				}
			}
		}
		gstrcpy(work,"uE00");
		if(ret == 0){
			ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PLCbuf,&Cnt,0);
			if(ret == 0){
/*				if(gstrncmp((char *)PLCbuf,"\x06u",2) != 0){*/
				if(PLCbuf[0] != 0x06){
					ret= -1;
				}
			}
		}
	}
	return(ret);
}
/************************************/
/*	�O���[�v���[�h			        */
/************************************/
int		ReadGroupPLCDev(void)
{
	int		ret;
	int		idx;
	int		i;
	int		WordCnt;
	char	work[16];
	char	work1[8];

	if(gDeviceCntWord == 0){
		return(0);
	}
	ret= 0;
	WordCnt= gDeviceCntWord;
	/*sprintf(work,"uR0000%02X",WordCnt);*/
	gstrcpy(work,"uR0000");
	Bin2Hex(WordCnt,2,work1);
	gstrcat(work,work1);
	ret= SendRecPLCWithBCC(2,work,PlcSendDevData,&idx,0);
	if(ret == OK){
/*		if(gstrncmp((char *)PlcSendDevData,"\x06u",2) != 0){*/
		if(PlcSendDevData[0] != 0x06){
			ret= -1;
		}
		if(ret == 0){
			for(i = 0; i < gDeviceCntWord; i++){
				*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 2]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 4]);
			}
			gstrcpy(work,"uE00");
			ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)work,&idx,0);
			if(ret == 0){
/*				if(gstrncmp(work,"\x06u",2) != 0){*/
				if(work[0] != 0x06){
					ret= -1;
				}
			}
		}
	}
	return(ret);
}
int		RecGroupPLCDev(int PlcType)
{
	int		i;
	int		ret;

	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].SameDevInf == 4){
			DeviceDataSys[i].SameDevInf= 0;
		}
	}
	while(1){
		ret= SetGroupDevPLC();
		if((ret != 0) || (gDeviceCntWord == 0)){
			break;
		}
		ret= ReadGroupPLCDev();
		if(ret != 0){
			break;
		}
	}
	return(ret);
}
/************************************/
/*	�X���[���[�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendPLCPCData();
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_38400;
	*DataBit= RS_DATA8;
	*Parity= RS_NONE;
}
int	GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
void	Get_Plc1_Ver(char *name)
{
	gstrcpy(name,"V1.00");
}
#ifdef	WIN32
/********************************************/
/*	�����֐�								*/
/********************************************/
int	PLC_CONNECT(int *PlcType,int iConnect)
{
	return(Connection(PlcType,iConnect));
}
int	GET_PLC_NAME(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	PLC1CHAR_READ(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite(mp,rDataFx,PlcType));
}
int	PLC_MAKE_GROUP(int PlcType)
{
	return(MakeGroupDevPLC(PlcType));
}
int	PLC_GROUP_READ(int PlcType)
{
	return(RecGroupPLCDev(PlcType));
}
int	PLCPCDOWN(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	return(PLCPCDownThrue(data,CommMode,Sio1RecCnt,Sio1RecBuff));
}
void	PLC_THRU_PROC(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	PLCFxThruProc(CommBuff,RecCommCnt,OutBuff,OutCnt,PlcConnectFlag,PlcType);
}
int	GET_PLC_MAX(int bFlag,int idx)
{
	return(GetDevMaxPLC(bFlag,idx));
}
int	GET_PLC_MIN(int bFlag,int idx)
{
	return(GetDevMinPLC(bFlag,idx));
}
int		DEVICE_2_INDEX(int bwflag,char *Name)
{
	return(Device2IndexPLC(bwflag,Name));
}
int		CHECK_PLC_ADDR(int bwflag,char *Name,int *Address1,int *Address2)
{
	return(CheckPLC_Addr(bwflag,Name,Address1,Address2));
}
void	GET_MON_BAUDRATE(int *Speed,int *DataBit,int *Parity)
{
	GetMonBaudrate(Speed,DataBit,Parity);
}
int	GET_SEND_REC_TIME(void)
{
	return(GetSendRecTime());
}
void	GET_PLC1_VER(char *Name)
{
	Get_Plc1_Ver(Name);
}
#endif
/****************************** END **********************/