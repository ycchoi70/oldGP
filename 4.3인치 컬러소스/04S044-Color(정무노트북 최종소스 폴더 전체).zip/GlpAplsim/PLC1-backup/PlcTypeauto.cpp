/************************************************/
/*	PLC ����M �v���O����(AUTONICS)				*/
/*	2003.5.31									*/
/************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"PlcCommBuff.h"
#include	"mail.h"

#define	MP 1

#ifndef	WIN32
#pragma	section PlcProc
#endif



/**************************************/
extern	int	Hex2nBin(char *buff,int cnt);
extern	int	Hex2Bin(char *buff);
extern	unsigned int LHexAsToBin(char *buff, int cnt);
extern	void	SendPLCPCData( void );
extern	int	SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode);
extern	int	SendPLC2PCData( int mode );
extern	int	SendPC2PLCData( int mode );
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	int	GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address);
extern	void	RtsOnOffSet(int type,int mode);
#ifdef	WIN32
extern int __cdecl Delay(int);
extern unsigned int __cdecl ReadSignal(int);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	unsigned char			GpFont[0x200000];
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#else
#define SGN_PLC		0
#endif

int	PlcSendFlag;		/* ���M���t���O */

/*ksc20040707*/
int DeviceLHFlag;		/* 0�϶� D100 ����̽�, 1�϶� D101 ����̽� 
						   D100���� ��Ž� D100[����], D101[�µ�]
                           D101��   ��Ž� D100[�µ�], D101[����] */

/**************************************/


/****************************** for Window **********************/
/********************************************/
/*	�O���֐�								*/
/********************************************/
#ifdef	WIN32
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
void	B_SendPLCPCData( void )
{
	SendPLCPCData();
}
int	B_SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode)
{
	return(SendRecPLC(mode,rData,Cnt,rmode));
}
int	B_SendPLC2PCData( int mode )
{
	return(SendPLC2PCData(mode ));
}
int	B_SendPC2PLCData( int mode )
{
	return(SendPC2PLCData(mode ));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
int	B_GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address)
{
	return(GetDevNamePLCAddr(bFlag,src,obj,DevInfo,Address));
}
void	B_RtsOnOffSet(int type,int mode)
{
	RtsOnOffSet(type,mode);
}
#endif

/********************************************/
/* PLC-Program Title */
const char Title[16]= {
	'P','L','C', 'P','R','O','C',
};
#ifdef	WIN32
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#endif
/********************************/
/*	FX Serease					*/
/********************************/
const	unsigned char PLCIndexTable[256]={
	/* BIT */
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0xff,0x02,0x03,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x04,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0x05,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x06,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x07,
	/* WORD */
	0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0xff,0x02,0x03,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x04,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0x05,0x06,0x07,0x08,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x09,0x0a,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x0b,0x0c,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0x0d,0x0e,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x0f,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
};
const	int PLCLowHighFlag= 0;				/* 0:L-H,1:H-L */
const	int	PLC_K3P_SereaseByteCnt= 8;
const DEV_PC_TBL	PLC_K3P_SereaseByte[32]=
	{
		{1,0x10,{'P',  0, 0},0x85,0x00000000,0x0000063f},
		{1,0x18,{'M',  0, 0},0x85,0x00000000,0x0000191f},
		{1,0x1a,{'K',  0, 0},0x85,0x00000000,0x0000031f},
		{1,0x1b,{'F',  0, 0},0x85,0x00000000,0x0000063f},
		{1,0x28,{'L',  0, 0},0x85,0x00000000,0x0000063f},
		{1,0x34,{'T',  0, 0},0x84,0x00000000,0x00000191},
		{1,0x50,{'C',  0, 0},0x84,0x00000000,0x00000255},
		{1,0x7f,{'G','B', 0},0x88,0x00000000,0x00001024},
	};
const	int	PLC_K3P_SereaseWordCnt= 16;
const	DEV_PC_TBL	PLC_K3P_SereaseWord[32]=
	{
		{2,(unsigned char)0x80,{'P',  0, 0},0x84,0x00000000,0x00000063},
		{2,(unsigned char)0x88,{'M',  0, 0},0x84,0x00000000,0x00000191},
		{2,(unsigned char)0x8a,{'K',  0, 0},0x84,0x00000000,0x00000031},
		{2,(unsigned char)0x8b,{'F',  0, 0},0x84,0x00000000,0x00000063},
		{2,(unsigned char)0x98,{'L',  0, 0},0x84,0x00000000,0x00000063},
		{2,(unsigned char)0xa2,{'T',  0, 0},0xc4,0x00000192,0x00000239},
		{2,(unsigned char)0xa3,{'T',  0, 0},0xc4,0x00000240,0x00000255},
		{2,(unsigned char)0xa4,{'T',  0, 0},0xc4,0x00000000,0x00000143},
		{2,(unsigned char)0xa5,{'T',  0, 0},0xc4,0x00000144,0x00000191},
		{2,(unsigned char)0xb0,{'C',  0, 0},0xc4,0x00000000,0x00000191},
		{2,(unsigned char)0xb1,{'C',  0, 0},0xa4,0x00000192,0x00000255},
		{2,(unsigned char)0xc0,{'D',  0, 0},0xa4,0x00000000,0x00005999},
		{2,(unsigned char)0xc1,{'D',  0, 0},0xa4,0x00006000,0x00009999},
		{2,(unsigned char)0xd4,{'S',  0, 0},0xa4,0x00000000,0x00000079},
		{2,(unsigned char)0xd5,{'S',  0, 0},0xa4,0x00000000,0x00000099},
		{2,(unsigned char)0xef,{'G','D', 0},0x88,0x00000000,0x00001024},
	};
#ifdef	MP
const	DEV_TBL bPLCDeviceTbl[16] = {
	{"MP" ,0x00,2},
	{"GB" ,    0,4},
};
const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"MP" ,0x00,2},
	{"GB" ,    0,4},
};
#endif
#ifdef	MT
const	DEV_TBL bPLCDeviceTbl[16] = {
	{"MT" ,0x00,2},
	{"GB" ,    0,4},
};
const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"MT" ,0x00,2},
	{"GB" ,    0,4},
};
#endif
#ifdef	TZ
const	DEV_TBL bPLCDeviceTbl[16] = {
	{"TZ" ,0x00,2},
	{"GB" ,    0,4},
};
const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"TZ" ,0x00,2},
	{"GB" ,    0,4},
};
#endif
const unsigned char CRC8[256]={
   0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41,
   0x9d, 0xc3, 0x21, 0x7f, 0xfc, 0xa2, 0x40, 0x1e, 0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc,
   0x23, 0x7d, 0x9f, 0xc1, 0x42, 0x1c, 0xfe, 0xa0, 0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62,
   0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81, 0x63, 0x3d, 0x7c, 0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff,
   0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5, 0x84, 0xda, 0x38, 0x66, 0xe5, 0xbb, 0x59, 0x07,
   0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58, 0x19, 0x47, 0xa5, 0xfb, 0x78, 0x26, 0xc4, 0x9a,
   0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6, 0xa7, 0xf9, 0x1b, 0x45, 0xc6, 0x98, 0x7a, 0x24,
   0xf8, 0xa6, 0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b, 0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05, 0xe7, 0xb9,
   0x8c, 0xd2, 0x30, 0x6e, 0xed, 0xb3, 0x51, 0x0f, 0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd,
   0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc, 0x92, 0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50,
   0xaf, 0xf1, 0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c, 0x6d, 0x33, 0xd1, 0x8f, 0x0c, 0x52, 0xb0, 0xee,
   0x32, 0x6c, 0x8e, 0xd0, 0x53, 0x0d, 0xef, 0xb1, 0xf0, 0xae, 0x4c, 0x12, 0x91, 0xcf, 0x2d, 0x73,
   0xca, 0x94, 0x76, 0x28, 0xab, 0xf5, 0x17, 0x49, 0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b,
   0x57, 0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4, 0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16,
   0xe9, 0xb7, 0x55, 0x0b, 0x88, 0xd6, 0x34, 0x6a, 0x2b, 0x75, 0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8,
   0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b, 0xa9, 0xf7, 0xb6, 0xe8, 0x0a, 0x54, 0xd7, 0x89, 0x6b, 0x35
};


/*ksc20040707 ������ ������ �����Ѵ� */
#ifdef	MP
const	char	*DevTbl[12]= {
	"P0","C0","C1","C2","C3","K0","K1","X0","X1","Y0","Y1","R0",
};
#endif
#ifdef	MT
const	char	*DevTbl[12]= {
	"P0"
};
#endif
#ifdef	THD
const	char	*DevTbl[12]= {
	"P0"
};
#endif
#ifdef	TZ
const	char	*DevTbl[12]= {
	"P0","S0"
};
#endif



/************************************/
/* ���ʏ���							*/
/************************************/
int	Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
void	Bin2Hex(int data,int cnt,char *buff)
{
	int		i;
	unsigned int AndData;

	AndData= 0x000f;
	for(i= 1; i < cnt; i++){
		AndData= AndData << 4;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= Bin2Hex1((data & AndData) >> ((cnt- i- 1)*4));
		AndData = AndData >> 4;
	}
	buff[i]= 0;
}
void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= '0'+ ((data / AndData) % 10);
		data= data % AndData;
		AndData = AndData / 10;
	}
	buff[i]= 0;
}
int	gstrlen(char *buff)
{
	int		i;

	for(i= 0; ; i++){
		if(buff[i] == 0){
			break;
		}
	}
	return(i);
}
void	gmemset(char *buff,int data,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*buff= (char)data;
		buff++;
	}
}
void	gmemcpy(char *obj,char *src,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*obj= *src;
		src++;
		obj++;
	}
}
void	gstrcpy(char *obj,char *src)
{
	int		i;

	for(i= 0; ; i++){
		*obj= *src;
		if(*src == 0){
			break;
		}
		src++;
		obj++;
	}
	*obj= 0;
}
int	gstrcmp(char *src,char *obj)
{
	int		i;
	int		ret;

	ret= NG;
	for(i= 0; ; i++){
		if(src[i] == 0){
			if(obj[i] == 0){
				ret= OK;
			}
			break;
		}
		if(obj[i] == 0){
			break;
		}
		if(src[i] != obj[i]){
			break;
		}
	}
	return(ret);
}
int	gstrncmp(char *src,char *obj,int cnt)
{
	int		i;
	int		ret;

	ret= OK;
	for(i= 0; i < cnt; i++){
		if(src[i] != obj[i]){
			ret= NG;
			break;
		}
	}
	return(ret);
}
void	gstrcat(char *src,char *obj)
{
	int		i;

	for(i= 0; ; i++){
		if(*src == 0){
			break;
		}
		src++;
	}
	for(i= 0; ; i++){
		if(*obj == 0){
			*src= 0;
			break;
		}
		*src= *obj;
		src++;
		obj++;
	}
}
int	gatoi(char *buff)
{
	char	c;
	int	ret;
	int flag;

	ret= 0;
	flag= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){
			break;
		}
		if((c >= '0') && (c <= '9')){
			ret= ret*10;
			ret+= c- '0';
		}else{
			if(c == '+'){
				continue;
			}
			if(c == '-'){
				flag= 1;
				continue;
			}
			break;
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}
/************************************/
/* ��M�v���g�R��					*/
/************************************/
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
extern	int		SioPLCDlgCommCnt;
extern	int	Sio0OutCnt;

	int	ret;
	
	ret= -1;
#ifdef	OLD
#ifdef	WIN32
	if(SioPLCDlgCommCnt != 0){
		return(ret);
	}
#else
	if(Sio0OutCnt != 0){
		return(ret);
	}
#endif
#endif

	switch(*CommMode){
/*ksc20040707*/
/* ���� ���ŵ� ����Ÿ�� ���� 
 - ��Ʈ���ڵ�	: RecBuff[0], RecBuff[1]�� ACK, STX �Է�
 - ����Ÿ		: RecBuff[2], RecBuff[3]�� ����,
                  RecBuff[4], RecBuff[5]�� RD,
				  RecBuff[6], RecBuff[7], RecBuff[8], RecBuff[9]�� ����Ÿ,
				  RecBuff[10]�� ETX,
 - �����ڵ�		: RecBuff[11]�� FSC, */ 

	case 0:
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*RecCnt= 0;			/* �`���X�^�[�g */
			RecBuff[(*RecCnt)++] = data;
			*CommMode = 1;
			break;
/*ksc20040716*/
		default:
			break;
		}
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		if((data == EOT) || (data == ETX)){
			*CommMode = 2;
		}
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		*CommMode = 0;
		if((gstrncmp((char *)&RecBuff[4],"RD",2) == 0) || (gstrncmp((char *)&RecBuff[4],"WD",2) == 0) ||
			(((RecBuff[4] >= '0') && (RecBuff[4] <= '9')) && (RecBuff[5] == 'D'))){
			ret= 0;
		}else{
			*RecCnt= 0;			/* �`���X�^�[�g */
		}
		break;
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	switch(*CommMode){
	case 0:		/* Normal */
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:		/* Thru Mode */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			if((data == EOT) || (data == ETX)){
				*CommMode = 5;
			}
		}else{
			*CommMode = 0;
		}
		break;
	case 5:		/* CRC1 */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			*CommMode = 99;
			ret= 0;
		}else{
			*CommMode = 0;
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/


/*ksc20040707*/
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
/* char *buff : �۽��ϰ����ϴ� ����Ÿ ����,
   int cnt    : �۽��ϰ����ϴ� ����Ÿ ��,
   unsigned char *OutBuf : CRC���� �ΰ��� �����۽� ����Ÿ */

int SetPLCBCC(char *buff,int cnt,unsigned char *OutBuf)
{

#ifdef	MP
/* �ʱⰪ : *buff = 0, 1, R, X, 0, P, 0, +, 0, 0, 0, 0, 0, 0, 0	*/
/*          cnt = 15									*/
/*			*OutBuf = ?									*/	
	int		i;
	unsigned char _crc8;

	OutBuf[0] = STX;				/* �۽Ź��� OutBuf[0] = STX */
	for(i = 0; i < cnt; i++){
		OutBuf[i+1] = buff[i];		/* �۽Ź��� OutBuf[1] = ����, OutBuf[2] = ����, OutBuf[3] = R, OutBuf[4] = X,
										OutBuf[5] = 0, OutBuf[6] = P, OutBuf[7] = 0, 
												OutBuf[8] = +, OutBuf[9] = 0, OutBuf[10] = 0, 
											    OutBuf[11] = 0, OutBuf[12] = 0, OutBuf[13] = 0, 
												OutBuf[14] = 0, OutBuf[15] = 0 */
	}
	OutBuf[i+1] = ETX;				/* �۽Ź���	OutBuf[16] = ETX */
	_crc8 = 0;
	for(i = 1; i < cnt+2; i++){
		_crc8 = CRC8[(unsigned int)(_crc8 ^ OutBuf[i])]; /* CRC ��� �������� ETX */
 	}
	OutBuf[cnt+2]= _crc8&0x00ff;	/* �۽Ź���	OutBuf[17] = CRC */ 
	return(cnt + 3);				/* 18�� ���� */

#endif

#ifdef	MT
/* �ʱⰪ : *buff = 0, 1, R, X, P, 0 */
/*          cnt = 6									*/
/*			*OutBuf = ?									*/	
	int		i;
	unsigned char _crc8;
	*OutBuf = 0;
	OutBuf[0] = STX;				/* �۽Ź��� OutBuf[0] = STX */
	for(i = 0; i < cnt; i++){
		OutBuf[i+1] = buff[i];		/* �۽Ź��� OutBuf[1] = ����, OutBuf[2] = ����, OutBuf[3] = R, OutBuf[4] = X,
												OutBuf[5] = P, OutBuf[6] = 0 */												
	}
	OutBuf[i+1] = ETX;				/* �۽Ź���	OutBuf[7] = ETX */
	_crc8 = 0;
	for(i = 1; i < cnt+2; i++){
		_crc8 = CRC8[(unsigned int)(_crc8 ^ OutBuf[i])]; /* CRC ��� �������� ETX */
 	}
	OutBuf[cnt+2]= _crc8&0x00ff;	/* �۽Ź���	OutBuf[8] = CRC */ 
	return(cnt + 3);				/* 9�� ���� */

#endif
#ifdef	THD
/* �ʱⰪ : *buff = 0, 1, R, X, T2, T1, T0, R2, R1, R0	*/
/*          cnt = 10									*/
/*			*OutBuf = ?									*/	
	int		i;
	unsigned char _crc8;

	OutBuf[0] = STX;				/* �۽Ź��� OutBuf[0] = STX */
	for(i = 0; i < cnt; i++){
		OutBuf[i+1] = buff[i];		/* �۽Ź��� OutBuf[1] = ����, OutBuf[2] = ����, OutBuf[3] = R, OutBuf[4] = X,
												OutBuf[5] = T2, OutBuf[6] = T1, OutBuf[7] = T0, 
												OutBuf[8] = R2, OutBuf[9] = R1, OutBuf[10] = R0, */
											
	}
	OutBuf[i+1] = ETX;				/* �۽Ź���	OutBuf[11] = ETX */
	_crc8 = 0;
	for(i = 1; i < cnt+2; i++){
		_crc8 = CRC8[(unsigned int)(_crc8 ^ OutBuf[i])]; /* CRC ��� STX--ETX */
 	}
	OutBuf[cnt+2]= _crc8&0x00ff;	/* �۽Ź���	OutBuf[12] = CRC */ 
	return(cnt + 3);				/* 13�� ���� */

#endif
#ifdef	TZ
/* �ʱⰪ : *buff = 0, 1, R, X, P, 0 */
/*          cnt = 6									*/
/*			*OutBuf = ?									*/	
	int		i;
	unsigned char _crc8;

	OutBuf[0] = STX;				/* �۽Ź��� OutBuf[0] = STX */
	for(i = 0; i < cnt; i++){
		OutBuf[i+1] = buff[i];		/* �۽Ź��� OutBuf[1] = ����, OutBuf[2] = ����, OutBuf[3] = R, OutBuf[4] = X,
												OutBuf[5] = P, OutBuf[6] = 0 */								
	}
	OutBuf[i+1] = ETX;				/* �۽Ź���	OutBuf[7] = ETX */
	_crc8 = 0;
	for(i = 0; i < cnt+2; i++){
		_crc8 = (unsigned int)(_crc8 ^ OutBuf[i]); /* BCC ��� STX--ETX */
 	}
	OutBuf[cnt+2]= _crc8&0x00ff;	/* �۽Ź���	OutBuf[8] = BCC */ 
	return(cnt + 3);				/* 9�� ���� */

#endif

}



/************************************/
/*	PLC Send						*/
/************************************/
int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;

	PlcCommCnt= SetPLCBCC((char *)combuf,gstrlen(combuf),PlcSendBuff);
	ret= B_SendRecPLC(mode,rData,Cnt,rmode);
	return(ret);
}
int	Connection( int *PlcType,int iConnect )
{
	int		ret;
/*ksc20040714*/
	int		Cnt;
	char	buff[32];

	/* �������̃{�[���[�g */
	if((iConnect & 1) == 0){		
#ifdef	WIN32
		SioPCMode= 3;
		SioPCOpenFlag= 1;
#else
		B_RsModeSet(RS_PC,RS_INIT,RS_9600,RS_DATA8,RS_NONE); /* RS_PC �� 1�϶� RS-232C */
#endif
	}else{						
#ifdef	WIN32
		SioPLCMode= 3;
		SioPLCOpenFlag= 1;
#else
		B_RsModeSet(RS_PLC,RS_INIT,RS_9600,RS_DATA8,RS_NONE); /* RS_PLC �� 0�϶� RS-422 */
#endif
	}
#ifdef	WIN32
	while(1){
		if((iConnect & 1) == 0){
			if(SioPCOpenFlag == 0){
				break;
			}
		}else{
			if(SioPLCOpenFlag == 0){
				break;
			}
		}
/*ksc20040714*/
		B_Delay(300);
	}
#else

/*ksc20040714*/
	B_Delay(300);
#endif

	/* PLC Connect Check *(PlcType+2) ���� ������ �Ѱ� ���� */


#ifdef	MP
	Bin2Hex(*(PlcType+2),2,buff);
	gstrcat(buff,"RX0P0+0000000");
#endif

#ifdef	MT
	Bin2Hex(*(PlcType+2),2,buff);
	gstrcat(buff,"RXP0");
#endif

#ifdef	THD
	Bin2Hex(*(PlcType+2),2,buff);
	gstrcat(buff,"RX000000");
#endif

#ifdef	TZ
	Bin2Hex(*(PlcType+2),2,buff);
	gstrcat(buff,"RXP0");
#endif

	ret= SendRecPLCWithBCC(2,buff,GrpPLCcombuf,&Cnt,0);		
/*ksc20040817

ret�� 0�϶� ���� ����
      -1�϶� Ÿ�Ӿƿ��� ����
	
/*ksc20040716*/	
/*ksc20040716	
	if(GrpPLCcombuf[0] != 0x06){
		ret= -1;
	}
/*ksc20040716*/
	if(ret < 0){
		return(0);
	}

	/* PLC Connect Check */
	ret= 1;
	return(ret);
/*ksc20040715*/
/*���ؼ��� ���� ������ ������ Ȯ�εǸ� �����޼����� ǥ������ �ʴ´�. 
  ���� ������ ������ �����޼��� ǥ���Ѵ�.
  ret=1�϶� �������� ó�� 	*/
}
/******************************************/
void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	WIN32
#ifdef	OLD
	*PLCByteCnt= (int)GpFont[PLC_DEV_TBLBCT];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC_DEV_TBLBYT];
	*PLCWordCnt= (int)GpFont[PLC_DEV_TBLWCT];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC_DEV_TBLWOR];
	*PLCIndex= (unsigned char *)&GpFont[PLC_DEV_TBLIDX];
#else
	*PLCByteCnt= (int)PLC_K3P_SereaseByteCnt;
	*PLCWordCnt= (int)PLC_K3P_SereaseWordCnt;		/*  */
	*ByteTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseByte[0];
	*WordTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseWord[0];
	*PLCIndex= (unsigned char *)&PLCIndexTable[0];
#endif
#else
#ifndef	OLD
	*PLCByteCnt= *(int *)PLC_DEV_TBLBCT;
	*ByteTbl= (DEV_PC_TBL *)PLC_DEV_TBLBYT;
	*PLCWordCnt= *(int *)PLC_DEV_TBLWCT;		/*  */
	*WordTbl= (DEV_PC_TBL *)PLC_DEV_TBLWOR;
	*PLCIndex= (unsigned char *)PLC_DEV_TBLIDX;
#else
	*PLCByteCnt= (int)PLC_K3P_SereaseByteCnt;
	*PLCWordCnt= (int)PLC_K3P_SereaseWordCnt;		/*  */
	*ByteTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseByte[0];
	*WordTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseWord[0];
	*PLCIndex= (unsigned char *)&PLCIndexTable[0];
#endif
#endif
}
/************************************/
/* Get Device Name					*/
/************************************/
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;


	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i,j;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(B_GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&i,&Address) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
/*ksc20040713*/
			ret = Address % 16;
			BitAndData = 1;
			for(j = 0; j < ret; j++){
				BitAndData <<= 1;
			}
			ret += sCnt;
			ret = ret / 8 + 1;
			BitRecCnt = ret;
/*ksc20040713*/
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(gstrncmp(bPLCDeviceTbl[i].Device,Device,2) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ (Address/ 16) * 2;
				ret = Address % 16;
				BitAndData = 1;
				for(j = 0; j < ret; j++){
					BitAndData <<= 1;
				}
				ret += sCnt;
				ret = ret / 8 + 1;
				if((ret % 2) != 0){
					ret++;
				}
				BitRecCnt = ret;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(gstrncmp(wPLCDeviceTbl[i].Device,Device,2) == 0){	/* mp���� ����ϴ� ����̽��ΰ� Ȯ�� */
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
/* �۽� ������ ���� */
int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt,int StationNo)
{
	int		ret;
	int		DevAddr;
	char	buff[4];	

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	/* �Ƿ��� ��巹���� ����ϴ� ��巹���ΰ� ���� ret = 0 �϶� ����� */

	
	if(ret == 0){
#ifdef	MP

		if(DevAddr >= 0 && DevAddr <= 10 ){
			/*sprintf(combuff,"01RX0%s+0000000",DevTbl[DevAddr-100]);*/
			Bin2Hex(StationNo,2,buff);
			gstrcpy(combuff,buff);
			gstrcat(combuff,"RX0");
			gstrcat(combuff,(char *)DevTbl[DevAddr]);
			gstrcat(combuff,"+0000000");
		}else{
			ret= -1; /* �ش� PLC�� 100�� �۽� ��巹���� ������ -1 ���� */ 
		}
#endif
#ifdef	MT
		if(DevAddr == 0){
			/*sprintf(combuff,"01RX%s",DevTbl[DevAddr-100]);*/
			Bin2Hex(StationNo,2,buff);
			gstrcpy(combuff,buff);
			gstrcat(combuff,"RX");
			gstrcat(combuff,(char *)DevTbl[DevAddr]);
		}else{
			ret= -1; /* �ش� PLC�� 100�� �۽� ��巹���� ������ -1 ���� */ 
		}
#endif
#ifdef	THD

/*ksc20040707*/
		if(DevAddr == 0){
			DeviceLHFlag = 0;
		}else{
			DeviceLHFlag = 1;
		}
			
		if(DevAddr == 0 || DevAddr == 1){
			/*sprintf(combuff,"01RX%s",DevTbl[DevAddr-100]);*/
			Bin2Hex(StationNo,2,buff);
			gstrcpy(combuff,buff);
			gstrcat(combuff,"RX");
			gstrcat(combuff,"000000");

		}else{
			ret= -1; /* �ش� PLC�� 100�� �۽� ��巹���� ������ -1 ���� */ 
		}
#endif

#ifdef	TZ

/*ksc20040707*/
 		if(DevAddr == 0 || DevAddr == 1){
			/*sprintf(combuff,"01RX%s",DevTbl[DevAddr-100]);*/
			Bin2Hex(StationNo,2,buff);
			gstrcpy(combuff,buff);
			gstrcat(combuff,"RX");
			gstrcat(combuff,(char *)DevTbl[DevAddr]);
		}else{
			ret= -1; /* �ش� PLC�� 100�� �۽� ��巹���� ������ -1 ���� */ 
		}
#endif

	}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;

	int		Cnt;
	int		rCnt;
	unsigned char	*SaveAddr;

#ifdef	MP
	unsigned int data1;
	char	work[16];
#endif
#ifdef	MT
	unsigned int data1;
	char	work[16];
#endif
#ifdef	THD
	unsigned int data;
	unsigned int data1;
	char	work[16];
#endif
#ifdef	TZ
	unsigned int data1;
	char	work[16];
#endif

	


	switch(mp->mpec){	/* mp->mpec�� 0�϶� Bit Device, 1�϶� Word Device */
	case PLC_BIT:		/* Bit Device */
		ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PLCbuf,mp->mext,(int)mp->mbuf[4]);
		Cnt = mp->mext;
		rCnt = BitRecCnt;
		break;
	case PLC_WORD:		/* Word Device */
		/* �۽� ������ ���� */
		ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PLCbuf,mp->mext*2,(int)mp->mbuf[4]); 
		Cnt = mp->mext* 2;
		rCnt = mp->mext* 2;
		break;
	}
	SaveAddr = (unsigned char *)mp->mptr;
	if(ret == 0){	/* PLC���� ����ϴ� ��巹���� ��� 0 ���� */

		if(SendRecPLCWithBCC(2,(char *)PLCbuf,(unsigned char *)rDataFx,&i,0) == 0){ /* ����ؼ� ���ϰ��� 0 �϶� ����Ÿ ó�� */ 
/*ksc20040713*/
#ifdef	MP
				for(i = 0; i < 7; i++){
					work[i] = rDataFx[i+9];
				}
				work[i]= 0;
				data1= gatoi(work);
				for(i = 0; i < Cnt; i++){
					*(unsigned char *)SaveAddr= (unsigned char)(data1 % 0x100);
					SaveAddr++;
					data1 = data1 / 0x100;
				}
#endif
#ifdef	MT
				for(i = 0; i < 7; i++){
					work[i] = rDataFx[i+8];
				}
				work[i]= 0;
				data1= gatoi(work);
				for(i = 0; i < Cnt; i++){
					*(unsigned char *)SaveAddr= (unsigned char)(data1 % 0x100);
					SaveAddr++;
					data1 = data1 / 0x100;
				}
#endif
#ifdef	THD
				for(i = 0; i < 6; i++){
					work[i] = rDataFx[i+6];
				}
				work[i]= 0;
				data1= gatoi(&work[3]);		/* ���� 3�� ����Ÿ ���� */
				work[3]= 0;
				data= gatoi(work);			/* ���� 3�� ����Ÿ �µ� */
/*ksc20040707*/
				if(DeviceLHFlag == 0){
				
					for(i = 0; i < Cnt; i++){
						*(unsigned char *)SaveAddr= (unsigned char)(data1 % 0x100);
						SaveAddr++;
						data1 = data1 / 0x100;
					}
					for(i = 0; i < Cnt; i++){
						*(unsigned char *)SaveAddr= (unsigned char)(data % 0x100);
						SaveAddr++;
						data = data / 0x100;
					}
				}else{
				
					for(i = 0; i < Cnt; i++){
						*(unsigned char *)SaveAddr= (unsigned char)(data % 0x100);
						SaveAddr++;
						data = data / 0x100;
					}
					for(i = 0; i < Cnt; i++){
						*(unsigned char *)SaveAddr= (unsigned char)(data1 % 0x100);
						SaveAddr++;
						data1 = data1 / 0x100;
					}
				}
#endif
#ifdef	TZ
				for(i = 0; i < 5; i++){
					work[i] = rDataFx[i+8];
				}
				work[i]= 0;
				if(work[0] == ' '){
					work[0]= '+';
				}
				data1= gatoi(work);
				for(i = 0; i < Cnt; i++){
					*(unsigned char *)SaveAddr= (unsigned char)(data1 % 0x100);
					SaveAddr++;
					data1 = data1 / 0x100;
				}
#endif
				
/*ksc20040715*/
		}else{
			ret = -1;
		}					
	}else if(ret == 1){		/* ����Device */
		ret= 0;

	}else{
		ret= 0;

	}
#ifdef	THD
	B_Delay(100);
#endif
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
int	ChangeIntData(char *data,int Cnt,int mode)
{
	int		iData;
	int		i;
	union{
		int		iData;
		char	cData[4];
	}rData;

	gmemset((char *)&rData,0,sizeof(rData));
	if(mode == 1){
		for(i= 0; i < Cnt*2 && i < 4; i++){
			rData.cData[3- i]= *data;
			data++;
		}
		iData = rData.iData;
	}else{
		iData = *data;
	}
	return(iData);
}
/****************************/
/* Make Write Device		*/
/****************************/
int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data,int StationNo)
{
#ifdef	MP
	int		iData;
	int		i,j,idx;
	char	buff[32];
#endif
#ifdef	TZ
	int		iData;
	int		i,j,idx;
	char	buff[32];
#endif	

	int		ret;
	int		DevAddr;

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);
	if(ret == 0){

#ifdef	MP 
		if(((DevAddr >= 1) && (DevAddr <= 4)) || ((DevAddr >= 7) && (DevAddr <= 11))){
			/*sprintf(combuff,"01WX0%s",DevTbl[DevAddr-100]);*/
			Bin2Hex(StationNo,2,buff);
			gstrcpy(combuff,buff);
			gstrcat(combuff,"WX0");
			gstrcat(combuff,(char *)DevTbl[DevAddr]);


			iData = ChangeIntData(data,Cnt,mode);
			Bin2dec(iData,6,buff); /*����Ÿ�� ��𿡼� ������ Ȯ�� */
			if((buff[0] == '-') || (buff[0] == '+')){
				combuff[7]= buff[0];
				idx= 1;
			}else{
				combuff[7]= '+';
				idx= 0;
			}
			for(i= 8,j= 0;;idx++){
				if(buff[idx] == 0){
					break;
				}
				if(buff[idx] == '.'){
					j= 0;
					continue;
				}
				combuff[i++]= buff[idx];
				j++;
				if(i >= 14){
					break;
				}
			}
			gstrcpy(buff,"0");
			combuff[i++]= buff[0];
			combuff[i++]= 0;
		}else{
			ret= -1;
		}
#endif
#ifdef	MT

#endif
#ifdef	THD

#endif
#ifdef	TZ
		if(DevAddr == 1){
			/*sprintf(combuff,"01WX0%s",DevTbl[DevAddr-100]);*/
			Bin2Hex(StationNo,2,buff);
			gstrcpy(combuff,buff);
			gstrcat(combuff,"WX");
			gstrcat(combuff,(char *)DevTbl[DevAddr]);

			iData = ChangeIntData(data,Cnt,mode);
			/*sprintf(buff,"%06d",*data);*/
			Bin2dec(iData,4,buff);

			if((buff[0] == '-') || (buff[0] == '+')){
				combuff[6]= buff[0];
				idx= 1;
			}else{
				combuff[6]= ' ';
				idx= 0;
			}
			for(i= 7,j= 0;;idx++){
				if(buff[idx] == 0){
					break;
				}
				if(buff[idx] == '.'){
					j= 0;
					continue;
				}
				combuff[i++]= buff[idx];
				j++;
				if(i >= 11){
					break;
				}
			}

			combuff[i++]= 0;
		}else{
			ret= -1;
		}

#endif

	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCbuf,(char *)mp->mptr,(int)mp->mbuf[4]);
		Cnt = mp->mext;
		break;
	case PLC_WORD:		/* Word Device */
		ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCbuf,(char *)mp->mptr,(int)mp->mbuf[4]);
		if(DeviceFlag == 2){		/* TS,CS */
			Cnt = mp->mext* 4;
		}else{
			Cnt = mp->mext* 2;
		}
		break;
	}
	if(ret == 0){
		if(SendRecPLCWithBCC(1,(char *)PLCbuf,rDataFx,&Cnt,0) == 0){
		}else{
			ret = -1;
		}
	}else if(ret == 1){		/* ����Address */
		ret= 0;
	}
	return(ret);
}
/************************************************/
/*	�O���[�v����								*/
/************************************************/
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	return(0);
}
/****************************************/
/*	�O���[�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		idx;
	int		ret= 0;

	/* Same Device Check */
	gmemset((char *)GrpPLCcombuf, 0, sizeof(GrpPLCcombuf));
	DeviceDataSys[0].SameDevInf= 0;
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		for(j = 0; j < i; j++){
			if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
				(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
				(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
				(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) &&
				(DeviceDataSys[j].DevCnt == 1) ){
				break;
			}
		}
		if(j != i){		/* Same Device */
			DeviceDataSys[i].SameDevInf= j+ 1;
		}
	}
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gstrcpy((char *)GrpPLCcombuf,"uW0002");
	idx= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	return(0);
}
/************************************/
/*	�O���[�v���[�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int	ret;

	ret= 0;
	return(ret);
}
/************************************/
/*	�X���[���[�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendPLCPCData();
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_9600;
	*DataBit= RS_DATA8;
	*Parity= RS_NONE;
}
int	GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
#ifdef	WIN32
/********************************************/
/*	�����֐�								*/
/********************************************/
int	PLC_CONNECT(int *PlcType,int iConnect)
{
	return(Connection(PlcType,iConnect));
}
int	GET_PLC_NAME(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	PLC1CHAR_READ(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite(mp,rDataFx,PlcType));
}
int	PLC_MAKE_GROUP(int PlcType)
{
	return(MakeGroupDevPLC(PlcType));
}
int	PLC_GROUP_READ(int PlcType)
{
	return(RecGroupPLCDev(PlcType));
}
int	PLCPCDOWN(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	return(PLCPCDownThrue(data,CommMode,Sio1RecCnt,Sio1RecBuff));
}
void	PLC_THRU_PROC(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	PLCFxThruProc(CommBuff,RecCommCnt,OutBuff,OutCnt,PlcConnectFlag,PlcType);
}
int	GET_PLC_MAX(int bFlag,int idx)
{
	return(GetDevMaxPLC(bFlag,idx));
}
int	GET_PLC_MIN(int bFlag,int idx)
{
	return(GetDevMinPLC(bFlag,idx));
}
int		DEVICE_2_INDEX(int bwflag,char *Name)
{
	return(Device2IndexPLC(bwflag,Name));
}
int		CHECK_PLC_ADDR(int bwflag,char *Name,int *Address1,int *Address2)
{
	return(CheckPLC_Addr(bwflag,Name,Address1,Address2));
}
void	GET_MON_BAUDRATE(int *Speed,int *DataBit,int *Parity)
{
	GetMonBaudrate(Speed,DataBit,Parity);
}
int	GET_SEND_REC_TIME(void)
{
	return(GetSendRecTime());
}
#endif
/****************************** END **********************/