/************************************************/
/*	PLC ����M �v���O����(LG-GLOFA-CNET)		*/
/*	2003.11.10									*/
/************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

#ifndef	WIN32
#pragma	section PlcProc
#endif



/**************************************/
extern	int	Hex2nBin(char *buff,int cnt);
extern	int	Hex2Bin(char *buff);
extern	unsigned int LHexAsToBin(char *buff, int cnt);
extern	void	SendPLCPCData( void );
extern	int	SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode);
extern	int	SendPLC2PCData( int mode );
extern	int	SendPC2PLCData( int mode );
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
#ifdef	WIN32
extern int __cdecl Delay(int);
extern unsigned int __cdecl ReadSignal(int);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	PlcDevInit( void );
extern	int	GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address);
extern	void	SendPLCGroup(void);
extern	void	RtsOnOffSet(int type,int mode);
extern	unsigned char			GpFont[0x200000];
#else
#define SGN_PLC		0
#endif

/**************************************/


/****************************** for Window **********************/
/********************************************/
/*	�O���֐�								*/
/********************************************/
#ifdef	WIN32
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
void	B_SendPLCPCData( void )
{
	SendPLCPCData();
}
int	B_SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode)
{
	return(SendRecPLC(mode,rData,Cnt,rmode));
}
int	B_SendPLC2PCData( int mode )
{
	return(SendPLC2PCData(mode ));
}
int	B_SendPC2PLCData( int mode )
{
	return(SendPC2PLCData(mode ));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
void	B_PlcDevInit(void)
{
	PlcDevInit();
}
int	B_SendPLCGroup()
{
	SendPLCGroup();
	return(0);
}
int	B_GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address)
{
	return(GetDevNamePLCAddr(bFlag,src,obj,DevInfo,Address));
}
void	B_RtsOnOffSet(int type,int mode)
{
	RtsOnOffSet(type,mode);
}
#endif

/********************************************/
/* PLC-Program Title */
const char Title[16]= {
	'P','L','C', 'P','R','O','C',
};
#ifdef	WIN32
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#endif
/********************************/
/*	FX Serease					*/
/********************************/
const	unsigned char PLCIndexTable[256]={
	/* BIT */
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0xff,0x02,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x03,
	/* WORD */
	0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x02,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x04,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
};
const	int PLCLowHighFlag= 0;				/* 0:L-H,1:H-L */
const	int	PLC_K3P_SereaseByteCnt= 4;
const	DEV_PC_TBL	PLC_K3P_SereaseByte[32]=
	{
		{1,0x10,{'I','X', 0},0x85,0x00000000,0x0000063f},
		{1,0x18,{'Q','X', 0},0x85,0x00000000,0x0000191f},
		{1,0x1a,{'M','X', 0},0x85,0x00000000,0x0000031f},
		{1,0x7f,{'G','B', 0},0x88,0x00000000,0x00001024},
	};
const	int	PLC_K3P_SereaseWordCnt= 4;
const	DEV_PC_TBL	PLC_K3P_SereaseWord[32]=
	{
		{2,(unsigned char)0x80,{'I','W', 0},0x84,0x00000000,0x00000063},
		{2,(unsigned char)0x88,{'Q','W', 0},0x84,0x00000000,0x00000191},
		{2,(unsigned char)0xc0,{'M','W', 0},0x84,0x00000000,0x00000031},
		{2,(unsigned char)0xef,{'G','D', 0},0x88,0x00000000,0x00001024},
	};
const	DEV_TBL bPLCDeviceTbl[16] = {
	{"IX" ,0x0000,1},
	{"QX" ,0x0000,1},
	{"MX" ,0x0000,1},
	{"GB" ,0x0000,9},
};
const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"IW" ,0x0000,1},
	{"QW" ,0x0000,1},
	{"MW" ,0x0000,1},
	{"GB" ,    0,4},
};
/************************************/
/* ��M�v���g�R��					*/
/************************************/
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(*CommMode){
	case 0:
		switch(data){
		case ENQ:
		case ACK:
		case NAK:
			*RecCnt= 0;			/* �`���X�^�[�g */
			RecBuff[(*RecCnt)++] = data;
			*CommMode = 1;
			break;
		}
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		if((data == EOT) || (data == ETX)){
			*CommMode = 2;
		}
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		*CommMode = 0;
		ret= 0;
		break;
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	switch(*CommMode){
	case 0:		/* Normal */
		switch(data){
		case ENQ:
		case ACK:
		case NAK:
			*CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:		/* Thru Mode */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		if((data == EOT) || (data == ETX)){
			*CommMode = 5;
		}
		break;
	case 5:
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		*CommMode = 99;
		ret = 0;	/* Pendding Req */
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/

/************************************/
/* ���ʏ���							*/
/************************************/
int	Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
void	Bin2Hex(int data,int cnt,char *buff)
{
	int		i;
	unsigned int AndData;

	AndData= 0x000f;
	for(i= 1; i < cnt; i++){
		AndData= AndData << 4;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= Bin2Hex1((data & AndData) >> ((cnt- i- 1)*4));
		AndData = AndData >> 4;
	}
	buff[i]= 0;
}
void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= '0'+ ((data / AndData) % 10);
		data= data % AndData;
		AndData = AndData / 10;
	}
	buff[i]= 0;
}
int	gstrlen(char *buff)
{
	int		i;

	for(i= 0; ; i++){
		if(buff[i] == 0){
			break;
		}
	}
	return(i);
}
void	gmemset(char *buff,int data,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*buff= (char)data;
		buff++;
	}
}
void	gmemcpy(char *obj,char *src,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*obj= *src;
		src++;
		obj++;
	}
}
void	gstrcpy(char *obj,char *src)
{
	int		i;

	for(i= 0; ; i++){
		*obj= *src;
		if(*src == 0){
			break;
		}
		src++;
		obj++;
	}
	*obj= 0;
}
int	gstrcmp(char *src,char *obj)
{
	int		i;
	int		ret;

	ret= NG;
	for(i= 0; ; i++){
		if(src[i] == 0){
			if(obj[i] == 0){
				ret= OK;
			}
			break;
		}
		if(obj[i] == 0){
			break;
		}
		if(src[i] != obj[i]){
			break;
		}
	}
	return(ret);
}
int	gstrncmp(char *src,char *obj,int cnt)
{
	int		i;
	int		ret;

	ret= OK;
	for(i= 0; i < cnt; i++){
		if(src[i] != obj[i]){
			ret= NG;
			break;
		}
	}
	return(ret);
}
void	gstrcat(char *src,char *obj)
{
	int		i;

	for(i= 0; ; i++){
		if(*src == 0){
			break;
		}
		src++;
	}
	for(i= 0; ; i++){
		if(*obj == 0){
			*src= 0;
			break;
		}
		*src= *obj;
		src++;
		obj++;
	}
}
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
int SetPLCBCC(char *buff,int cnt,unsigned char *OutBuf)
{
	int		i;
	unsigned char bcc;

	bcc = 0;
	for(i = 0; i < cnt; i++){
		OutBuf[i] = buff[i];
		bcc += OutBuf[i];
	}
	OutBuf[cnt] = EOT;
	bcc += OutBuf[cnt];
	OutBuf[cnt+1] = bcc;
	return(cnt + 2);
}
/************************************/
/*	PLC Send						*/
/************************************/
int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		i;
	int		ret;
	unsigned char bcc;

	PlcCommCnt= SetPLCBCC((char *)combuf,gstrlen(combuf),PlcSendBuff);
	ret= B_SendRecPLC(mode,rData,Cnt,rmode);
	if(ret == OK){
		bcc = 0;
		for(i = 0; i < *Cnt- 1; i++){
			bcc += rData[i];
		}
		if(bcc != rData[i]){
			ret= NG;
		}
	}
	return(ret);
}
int	Connection( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;

	/* �������̃{�[���[�g */
	if((iConnect & 1) == 0){		/* RS-232C */
#ifdef	WIN32
		SioPCMode= 2;
		SioPCOpenFlag= 1;
#else
		B_RsModeSet(RS_PC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);
#endif
	}else{						/* RS-422 */
#ifdef	WIN32
		SioPLCMode= 2;
		SioPLCOpenFlag= 1;
#else
		B_RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);
#endif
	}
#ifdef	WIN32
	while(1){
		if(SioPLCOpenFlag == 0){
			break;
		}
		B_Delay(10);
	}
#endif
	B_Delay(500);

	/* PLC Connect Check */
	GrpPLCcombuf[0]= ENQ;
	GrpPLCcombuf[1]= '0';
	GrpPLCcombuf[2]= '1';
	GrpPLCcombuf[3]= 'r';
	GrpPLCcombuf[4]= 'S';
	GrpPLCcombuf[5]= 'T';
	GrpPLCcombuf[6]= 0;
	ret= SendRecPLCWithBCC(2,(char *)GrpPLCcombuf,GrpPLCcombuf,&Cnt,0);
	if((ret == 0) && (GrpPLCcombuf[0] == ACK)){
		ret= 1;
	}else{
		ret= 0;
	}
	return(ret);
}
/******************************************/
void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	WIN32
#ifdef	OLD
	*PLCByteCnt= (int)GpFont[PLC_DEV_TBLBCT];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC_DEV_TBLBYT];
	*PLCWordCnt= (int)GpFont[PLC_DEV_TBLWCT];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC_DEV_TBLWOR];
	*PLCIndex= (unsigned char *)&GpFont[PLC_DEV_TBLIDX];
#else
	*PLCByteCnt= (int)PLC_K3P_SereaseByteCnt;
	*PLCWordCnt= (int)PLC_K3P_SereaseWordCnt;		/*  */
	*ByteTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseByte[0];
	*WordTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseWord[0];
	*PLCIndex= (unsigned char *)&PLCIndexTable[0];
#endif
#else
#ifndef	OLD
	*PLCByteCnt= *(int *)PLC_DEV_TBLBCT;
	*ByteTbl= (DEV_PC_TBL *)PLC_DEV_TBLBYT;
	*PLCWordCnt= *(int *)PLC_DEV_TBLWCT;		/*  */
	*WordTbl= (DEV_PC_TBL *)PLC_DEV_TBLWOR;
	*PLCIndex= (unsigned char *)PLC_DEV_TBLIDX;
#else
	*PLCByteCnt= (int)PLC_K3P_SereaseByteCnt;
	*PLCWordCnt= (int)PLC_K3P_SereaseWordCnt;		/*  */
	*ByteTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseByte[0];
	*WordTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseWord[0];
	*PLCIndex= (unsigned char *)&PLCIndexTable[0];
#endif
#endif
}
/************************************/
/* Get Device Name					*/
/************************************/
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i,j;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(B_GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&i,&Address) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = Address % 16;
			BitAndData = 1;
			for(j = 0; j < ret; j++){
				BitAndData <<= 1;
			}
			ret += sCnt;
			ret = ret / 8 + 1;
			BitRecCnt = ret;
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(bPLCDeviceTbl[i].Device[0] == Device[0]){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ (Address/ 16) * 2;
				ret = Address % 16;
				BitAndData = 1;
				for(j = 0; j < ret; j++){
					BitAndData <<= 1;
				}
				ret += sCnt;
				ret = ret / 8 + 1;
				if((ret % 2) != 0){
					ret++;
				}
				BitRecCnt = ret;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(wPLCDeviceTbl[i].Device[0] == Device[0]){
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address* 2;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int		DevAddr;
	char	buff[32];
	char	abuff[4+1];

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		if(mode == 0){		/* BIT */
			/*sprintf(combuff,"rM%s00%02X",abuff,BitRecCnt);*/
			gstrcpy(combuff,"rM");
			gstrcat(combuff,abuff);
			gstrcat(combuff,"00");
			Bin2Hex(BitRecCnt,2,abuff);
			gstrcat(combuff,abuff);
		}else{				/* WORD */
			/*sprintf(combuff,"rM%s00%02X",abuff,sCnt);*/
			gstrcpy(combuff,"rM");
			gstrcat(combuff,abuff);
			gstrcat(combuff,"00");
			Bin2Hex(sCnt,2,abuff);
			gstrcat(combuff,abuff);
		}
	}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j;
	int		Cnt;
	int		rCnt;
	unsigned char	*SaveAddr;
#ifdef	OLD
	int		InAddr;
#endif

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PLCbuf,mp->mext);
		Cnt = mp->mext;
		rCnt = BitRecCnt;
		break;
	case PLC_WORD:		/* Word Device */
		ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PLCbuf,mp->mext*2);
		Cnt = mp->mext* 2;
		rCnt = mp->mext* 2;
		break;
	}
	SaveAddr = (unsigned char *)mp->mptr;
	if(ret == 0){
		if(SendRecPLCWithBCC(2,(char *)PLCbuf,(unsigned char *)rDataFx,&i,0) == 0){
			if(gstrncmp((char *)rDataFx,"\x06r",2) != 0){
				ret= -1;
			}else{
				for(i = 0; i < rCnt; i++){
					rDataFx[i] = (unsigned char)B_Hex2Bin((char *)&rDataFx[i*2+ 2]);
				}
				if(mp->mpec == PLC_BIT){		/* Bit Device */
					for(i = 0,j = 0; i < Cnt; i++){
						if(rDataFx[j] & BitAndData){
							*(unsigned char *)SaveAddr++ = 1;
						}else{
							*(unsigned char *)SaveAddr++ = 0;
						}
						BitAndData <<= 1;
						if(BitAndData > 128){
							BitAndData = 1;
							j++;
						}
					}
				}else{
					for(i = 0,j = 0; i < Cnt; i++){
						*(unsigned char *)SaveAddr++ = rDataFx[i];
					}
				}
			}
		}else{
			ret = -1;
		}
	}else if(ret == 1){		/* ����Device */
		ret= 0;
	}
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	int		DevAddr;
	char	buff[32];
	char	abuff[4+1];

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		if(mode == 0){		/* BIT */
			if(*data == 0){			/* OFF */
				/*sprintf(combuff,"nM%s00",abuff);*/
				gstrcpy(combuff,"nM");
				gstrcat(combuff,abuff);
				gstrcat(combuff,"00");
				/*sprintf(buff,"%04X",(~BitAndData & 0x0000ffff));*/
				Bin2Hex((~BitAndData & 0x0000ffff),4,buff);
				abuff[0]= buff[2];
				abuff[1]= buff[3];
				abuff[2]= buff[0];
				abuff[3]= buff[1];
				abuff[4]= 0;
				gstrcat(combuff,abuff);
			}else{
				/*sprintf(combuff,"oM%s00",abuff);*/
				gstrcpy(combuff,"oM");
				gstrcat(combuff,abuff);
				gstrcat(combuff,"00");
				/*sprintf(buff,"%04X",BitAndData);*/
				Bin2Hex(BitAndData,4,buff);
				abuff[0]= buff[2];
				abuff[1]= buff[3];
				abuff[2]= buff[0];
				abuff[3]= buff[1];
				abuff[4]= 0;
				gstrcat(combuff,abuff);
			}
		}else{		/* WORD */
			/*sprintf(combuff,"wM%s00%02d",abuff,Cnt*2);*/
			gstrcpy(combuff,"wM");
			gstrcat(combuff,abuff);
			gstrcat(combuff,"00");
			Bin2Hex(Cnt*2,2,buff);
			gstrcat(combuff,buff);
			for(i= 0; i < Cnt*2; i++){
				/*sprintf(buff,"%02X",data[i] & 0xff);*/
				Bin2Hex(data[i] & 0xff,2,buff);
				gstrcat(combuff,buff);
			}
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;
#ifdef	OLD
	int		i,j;
	int		InAddr;
	unsigned char	*SaveAddr;
#endif

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCbuf,(char *)mp->mptr);
		Cnt = mp->mext;
		break;
	case PLC_WORD:		/* Word Device */
		ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCbuf,(char *)mp->mptr);
		if(DeviceFlag == 2){		/* TS,CS */
			Cnt = mp->mext* 4;
		}else{
			Cnt = mp->mext* 2;
		}
		break;
	}
	if(ret == 0){
		if(SendRecPLCWithBCC(1,(char *)PLCbuf,rDataFx,&Cnt,0) == 0){
			if(gstrncmp((char *)rDataFx,"\x06w",2) != 0){
				ret= -1;
			}
		}else{
			ret = -1;
		}
	}else if(ret == 1){		/* ����Address */
		ret= 0;
	}
	return(ret);
}
/************************************************/
/*	�O���[�v����								*/
/************************************************/
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	int	ret;
	int	DevAddr;
	char	buff[8];
	char	abuff[8];

	ret= MakePLCDevAddress(mode, DevName, DevAddress, &DevAddr, 2);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		/*sprintf(work,"M%s0002",abuff);*/
		gstrcpy(work,"M");
		gstrcat(work,abuff);
		gstrcat(work,"0002");
	}
	return(ret);
}
/****************************************/
/*	�O���[�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		idx;
	char	work[12+ 1];
	int		ret= 0;
	int		Cnt;

	/* Same Device Check */
	gmemset((char *)GrpPLCcombuf, 0, sizeof(GrpPLCcombuf));
	DeviceDataSys[0].SameDevInf= 0;
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		for(j = 0; j < i; j++){
			if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
				(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
				(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
				(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) &&
				(DeviceDataSys[j].DevCnt == 1) ){
				break;
			}
		}
		if(j != i){		/* Same Device */
			DeviceDataSys[i].SameDevInf= j+ 1;
		}
	}
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gstrcpy((char *)GrpPLCcombuf,"uW0002");
	idx= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	for(i = 0; i < DeviceCntSys; i++){
		/* CS,TS Check */
		if((DeviceDataSys[i].DevCnt == 1) &&
			(DeviceDataSys[i].DevFlag == 1) &&
			(DeviceDataSys[i].SameDevInf == 0) ){
			if(PlcMakeDeviceAddr(DeviceDataSys[i].DevFlag, DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work) == 0){
				gstrcpy((char *)&GrpPLCcombuf[6 + idx+ gDeviceCnt*9],work);
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
				gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
				DeviceDataSys[i].SameDevInf= -1;
				gDeviceCnt++;
				gDeviceCntWord++;
			}
		}
		/*sprintf(work,"%02X",gDeviceCntWord);*/
		Bin2Hex(gDeviceCntWord,2,work);
		gmemcpy((char *)&GrpPLCcombuf[4],work,2);
	}
	if(gDeviceCnt != 0){
		gstrcpy(work,"uA00");
		ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PLCbuf,&Cnt,0);
		if(ret == 0){
			if(gstrncmp((char *)PLCbuf,"\x06u",2) != 0){
				ret= -1;
			}
		}
		if(ret == 0){
			ret= SendRecPLCWithBCC(2,(char *)&GrpPLCcombuf[0],(unsigned char *)PLCbuf,&Cnt,0);
			if(ret == 0){
				if(gstrncmp((char *)PLCbuf,"\x06u",2) != 0){
					ret= -1;
				}
			}
		}
		gstrcpy(work,"uE00");
		if(ret == 0){
			ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)PLCbuf,&Cnt,0);
			if(ret == 0){
				if(gstrncmp((char *)PLCbuf,"\x06u",2) != 0){
					ret= -1;
				}
			}
		}
	}
	return(ret);
}
/************************************/
/*	�O���[�v���[�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int		ret;
	int		idx;
	int		i;
	int		WordCnt;
	char	work[16];
	char	work1[8];

	if(gDeviceCntWord == 0){
		return(0);
	}
	ret= 0;
	WordCnt= gDeviceCntWord;
	/*sprintf(work,"uR0000%02X",WordCnt);*/
	gstrcpy(work,"uR0000");
	Bin2Hex(WordCnt,2,work1);
	gstrcat(work,work1);
	ret= SendRecPLCWithBCC(2,work,PlcSendDevData,&idx,0);
	if(ret == OK){
		if(gstrncmp((char *)PlcSendDevData,"\x06u",2) != 0){
			ret= -1;
		}
		if(ret == 0){
			for(i = 0; i < gDeviceCntWord; i++){
				*gDeviceAddr[i] = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 2]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)B_Hex2Bin((char *)&PlcSendDevData[i*4+ 4]);
			}
			gstrcpy(work,"uE00");
			ret= SendRecPLCWithBCC(2,(char *)work,(unsigned char *)work,&idx,0);
			if(ret == 0){
				if(gstrncmp(work,"\x06u",2) != 0){
					ret= -1;
				}
			}
		}
	}
	return(ret);
}
/************************************/
/*	�X���[���[�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendPLCPCData();
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_38400;
	*DataBit= RS_DATA8;
	*Parity= RS_NONE;
}
#ifdef	WIN32
/********************************************/
/*	�����֐�								*/
/********************************************/
int	PLC_CONNECT(int *PlcType,int iConnect)
{
	return(Connection(PlcType,iConnect));
}
int	GET_PLC_NAME(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	PLC1CHAR_READ(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite(mp,rDataFx,PlcType));
}
int	PLC_MAKE_GROUP(int PlcType)
{
	return(MakeGroupDevPLC(PlcType));
}
int	PLC_GROUP_READ(int PlcType)
{
	return(RecGroupPLCDev(PlcType));
}
int	PLCPCDOWN(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	return(PLCPCDownThrue(data,CommMode,Sio1RecCnt,Sio1RecBuff));
}
void	PLC_THRU_PROC(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	PLCFxThruProc(CommBuff,RecCommCnt,OutBuff,OutCnt,PlcConnectFlag,PlcType);
}
int	GET_PLC_MAX(int bFlag,int idx)
{
	return(GetDevMaxPLC(bFlag,idx));
}
int	GET_PLC_MIN(int bFlag,int idx)
{
	return(GetDevMinPLC(bFlag,idx));
}
int		DEVICE_2_INDEX(int bwflag,char *Name)
{
	return(Device2IndexPLC(bwflag,Name));
}
int		CHECK_PLC_ADDR(int bwflag,char *Name,int *Address1,int *plctype)
{
	return(CheckPLC_Addr(bwflag,Name,Address1,plctype));
}
void	GET_MON_BAUDRATE(int *Speed,int *DataBit,int *Parity)
{
	GetMonBaudrate(Speed,DataBit,Parity);
}
#endif
/****************************** END **********************/