/************************************************/
/*	PLC ����M �v���O��?(LG-K3P-07AS)			*/
/*	2003.5.31									*/
/************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"PlcCommBuff.h"
#include	"mail.h"

/*#define	PLC_TYPE2	1*/
#define	MAX_RTY_COUNT	3

#define	MT	1

/*#define	AUTO_FLOAT	1*/

#ifndef	WIN32
#pragma	section PlcProc2
#endif

#define	MAX_PLC_STATION	32
#define	MAX_PLC_ERR		10


/**************************************/
extern	int	Hex2nBin(char *buff,int cnt);
extern	int	Hex2Bin(char *buff);
extern	unsigned int LHexAsToBin(char *buff, int cnt);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
#ifdef	WIN32
extern int __cdecl Delay(int);
extern unsigned int __cdecl ReadSignal(int);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	unsigned char			GpFont[0x200000];
extern	int	SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode);
extern	int	SendPC2PLCData2( int mode );
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#else
#define SGN_PLC		0
#endif

/*ksc20040707*/
int PLC2_DeviceStartPoint;		/* 0�϶� D100 ����̽�, 1�϶� D101 ����̽� 
						   D100���� ��Ž� D100[����], D101[�µ�]
                           D101��   ��Ž� D100[�µ�], D101[����] */
char	PlcStation[33];		/* 041119 */

/****************************************************************/
/*	Station Connect Area										*/
/****************************************************************/
int		Plc2_DeviceFlag;						/* Device Check Flag */
int		Plc2_BitRecCnt;
int		Plc2_BitAndData;
char	StationInf[MAX_PLC_STATION];
/****************************** for Window **********************/
/********************************************/
/*	�O���֐�								*/
/********************************************/
#ifdef	PLC_TYPE2
#ifdef	WIN32
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
#endif
#else
extern	int	B_Hex2nBin(char *buff,int cnt);
extern	int	B_Hex2Bin(char *buff);
extern	unsigned int B_LHexAsToBin(char *buff, int cnt);
extern	int	B_Delay(int p);
extern	int	B_ReadSignal(int p);
extern	void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
#endif
#ifdef	WIN32
int	B_SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode)
{
	return(SendRecPLC2(mode,rData,Cnt,rmode));
}
int	B_SendPC2PLCData2( int mode )
{
	return(SendPC2PLCData2(mode ));
}
#endif

/********************************************/
/* PLC-Program Title */
#ifdef	WIN32
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#endif
/********************************/
/*	MT Serease					*/
/********************************/
const unsigned char PLC2_CRC8[256]={
   0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41,
   0x9d, 0xc3, 0x21, 0x7f, 0xfc, 0xa2, 0x40, 0x1e, 0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc,
   0x23, 0x7d, 0x9f, 0xc1, 0x42, 0x1c, 0xfe, 0xa0, 0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62,
   0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81, 0x63, 0x3d, 0x7c, 0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff,
   0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5, 0x84, 0xda, 0x38, 0x66, 0xe5, 0xbb, 0x59, 0x07,
   0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58, 0x19, 0x47, 0xa5, 0xfb, 0x78, 0x26, 0xc4, 0x9a,
   0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6, 0xa7, 0xf9, 0x1b, 0x45, 0xc6, 0x98, 0x7a, 0x24,
   0xf8, 0xa6, 0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b, 0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05, 0xe7, 0xb9,
   0x8c, 0xd2, 0x30, 0x6e, 0xed, 0xb3, 0x51, 0x0f, 0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd,
   0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc, 0x92, 0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50,
   0xaf, 0xf1, 0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c, 0x6d, 0x33, 0xd1, 0x8f, 0x0c, 0x52, 0xb0, 0xee,
   0x32, 0x6c, 0x8e, 0xd0, 0x53, 0x0d, 0xef, 0xb1, 0xf0, 0xae, 0x4c, 0x12, 0x91, 0xcf, 0x2d, 0x73,
   0xca, 0x94, 0x76, 0x28, 0xab, 0xf5, 0x17, 0x49, 0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b,
   0x57, 0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4, 0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16,
   0xe9, 0xb7, 0x55, 0x0b, 0x88, 0xd6, 0x34, 0x6a, 0x2b, 0x75, 0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8,
   0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b, 0xa9, 0xf7, 0xb6, 0xe8, 0x0a, 0x54, 0xd7, 0x89, 0x6b, 0x35
};

#ifdef	MT
const	char	*PlcType2DevTbl[12]= {
	"P0","P0","P0"
};
#endif


/************************************/
/* ���ʏ���							*/
/************************************/
#ifdef	PLC_TYPE2
int	Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
void	Bin2Hex(int data,int cnt,char *buff)
{
	int		i;
	unsigned int AndData;

	AndData= 0x000f;
	for(i= 1; i < cnt; i++){
		AndData= AndData << 4;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= Bin2Hex1((data & AndData) >> ((cnt- i- 1)*4));
		AndData = AndData >> 4;
	}
	buff[i]= 0;
}
void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	if(data < 0){			/* - check 041116 */
		
		data *= -1;
		buff[0]= '-';
		for(i= 1; i < cnt+1; i++){								/*cnt+1�̵� ������ */
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}else{
		for(i= 0; i < cnt; i++){
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}
	buff[i]= 0;
}
int	gstrlen(char *buff)
{
	int		i;

	for(i= 0; ; i++){
		if(buff[i] == 0){
			break;
		}
	}
	return(i);
}
void	gmemset(char *buff,int data,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*buff= (char)data;
		buff++;
	}
}
void	gmemcpy(char *obj,char *src,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*obj= *src;
		src++;
		obj++;
	}
}
void	gstrcpy(char *obj,char *src)
{
	int		i;

	for(i= 0; ; i++){
		*obj= *src;
		if(*src == 0){
			break;
		}
		src++;
		obj++;
	}
	*obj= 0;
}
int	gstrcmp(char *src,char *obj)
{
	int		i;
	int		ret;

	ret= NG;
	for(i= 0; ; i++){
		if(src[i] == 0){
			if(obj[i] == 0){
				ret= OK;
			}
			break;
		}
		if(obj[i] == 0){
			break;
		}
		if(src[i] != obj[i]){
			break;
		}
	}
	return(ret);
}
int	gstrncmp(char *src,char *obj,int cnt)
{
	int		i;
	int		ret;

	ret= OK;
	for(i= 0; i < cnt; i++){
		if(src[i] != obj[i]){
			ret= NG;
			break;
		}
	}
	return(ret);
}
void	gstrcat(char *src,char *obj)
{
	int		i;

	for(i= 0; ; i++){
		if(*src == 0){
			break;
		}
		src++;
	}
	for(i= 0; ; i++){
		if(*obj == 0){
			*src= 0;
			break;
		}
		*src= *obj;
		src++;
		obj++;
	}
}
int	gatoi(char *buff)
{
	char	c;
	int	ret;
	int flag;

	ret= 0;
	flag= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){
			break;
		}
		if((c >= '0') && (c <= '9')){
			ret= ret*10;
			ret+= c- '0';
		}else{
			if(c == '+'){
				continue;
			}
			if(c == '-'){
				flag= 1;
				continue;
			}
			break;
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}
#else
extern	int	Bin2Hex1(int data);
extern	void	Bin2Hex(int data,int cnt,char *buff);
extern	void	Bin2dec(int data,int cnt,char *buff);
extern	int	gstrlen(char *buff);
extern	void	gmemset(char *buff,int data,int cnt);
extern	void	gmemcpy(char *obj,char *src,int cnt);
extern	void	gstrcpy(char *obj,char *src);
extern	int	gstrcmp(char *src,char *obj);
extern	int	gstrncmp(char *src,char *obj,int cnt);
extern	void	gstrcat(char *src,char *obj);
extern	int	gatoi(char *buff);
#endif
/************************************/
/* ��M�v���g�R��					*/
/************************************/
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
extern	int		SioPLCDlgCommCnt;
extern	int	Sio0OutCnt;

	int	ret;
	
	ret= -1;
#ifdef	OLD
#ifdef	WIN32
	if(SioPLCDlgCommCnt != 0){
		return(ret);
	}
#else
	if(Sio0OutCnt != 0){
		return(ret);
	}
#endif
#endif
	switch(*CommMode){
	case 0:
		switch(data){
		case STX:
		case ENQ:
		case ACK:
			*RecCnt= 0;			/* ?���X??�g */
			RecBuff[(*RecCnt)++] = data;
			*CommMode = 1;
			break;
		case NAK:
			*RecCnt= 0;			/* ?���X??�g */
			RecBuff[(*RecCnt)++] = data;
			*CommMode = 0;
			ret = 0;
			break;
		}
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		if((data == EOT) || (data == ETX)){
			*CommMode = 2;
		}
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		*CommMode = 0;
		if((gstrncmp((char *)&RecBuff[4],"RD",2) == 0) || (gstrncmp((char *)&RecBuff[4],"WD",2) == 0) ||
			(((RecBuff[4] >= '0') && (RecBuff[4] <= '9')) && (RecBuff[5] == 'D')) || (RecBuff[0] == NAK)){
			ret= 0;
		}else{
			*RecCnt= 0;			/* ?���X??�g */
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/

/****************************/
/* Make Check SUM For PLC	*/
/****************************/
int PLC2_SetPLCBCC(char *buff,int cnt,unsigned char *OutBuf)
{

#ifdef	MT
/* �ʱⰪ : *buff = 0, 1, R, X, P, 0 */
/*          cnt = 6									*/
/*			*OutBuf = ?									*/	
	int		i;
	unsigned char _crc8;
	*OutBuf = 0;
	OutBuf[0] = STX;				/* �۽Ź��� OutBuf[0] = STX */
	for(i = 0; i < cnt; i++){
		OutBuf[i+1] = buff[i];		/* �۽Ź��� OutBuf[1] = ����, OutBuf[2] = ����, OutBuf[3] = R, OutBuf[4] = X,
												OutBuf[5] = P, OutBuf[6] = 0 */												
	}
	OutBuf[i+1] = ETX;				/* �۽Ź���	OutBuf[7] = ETX */
	_crc8 = 0;
	for(i = 1; i < cnt+2; i++){
		_crc8 = PLC2_CRC8[(unsigned int)(_crc8 ^ OutBuf[i])]; /* CRC ��� �������� ETX */
 	}
	OutBuf[cnt+2]= _crc8&0x00ff;	/* �۽Ź���	OutBuf[8] = CRC */ 
	return(cnt + 3);				/* 9�� ���� */

#endif

}
/************************************/
/*	PLC Send						*/
/************************************/
int	PLC2_SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret,i;
	int		rty_cnt;
	unsigned char _crc8;

	PcThruByteCnt= PLC2_SetPLCBCC((char *)combuf,gstrlen(combuf),PcThruRecDataWork);
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
		ret= B_SendRecPLC2(mode,rData,Cnt,rmode);
		if(ret == OK){
			_crc8 = 0;
			for(i = 2; i < *Cnt-1; i++){
				_crc8 = PLC2_CRC8[(unsigned int)(_crc8 ^ rData[i])]; /* CRC ��� �������� ETX */
 			}
			if(_crc8 != rData[*Cnt-1]){
				ret= -1;
			}
		}else{
			break;
		}
		if(ret == OK){
			break;
		}
	}
	return(ret);
}

int	Connection2( int *PlcType,int iConnect )
{
	int		ret;

#ifdef	KSC		/*ksc20041122	*/

	int		Cnt;
	char	buff[32];

#endif


	gmemset(PlcStation,0,sizeof(PlcStation));		/* 041119 */
	/* ��������??��?�g */
	if((iConnect & 1) == 0){		/* RS-232C */
#ifdef	WIN32
		SioPCMode= 3;
		SioPCOpenFlag= 1;
#else
		B_RsModeSet(RS_PLC,RS_INIT,RS_9600,RS_DATA8,RS_NONE);
#endif
	}else{						/* RS-422 */
#ifdef	WIN32
		SioPLCMode= 3;
		SioPLCOpenFlag= 1;
#else
		B_RsModeSet(RS_PC,RS_INIT,RS_9600,RS_DATA8,RS_NONE);
#endif
	}
#ifdef	WIN32
	while(1){
		if(SioPLCOpenFlag == 0){
			break;
		}
		B_Delay(10);
	}
#endif


#ifdef	KSC		/*ksc20041122	*/

#ifdef	MT
	Bin2Hex(*(PlcType+2),2,buff);
	gstrcat(buff,"RXP0");
#endif
	
	B_Delay(500);

/*ksc20041119 connection ignore */
	ret= PLC2_SendRecPLCWithBCC(2,buff,PcThruRecDataWork,&Cnt,0);		
	

	/* PLC Connect Check */

	if(ret == 0){
		ret= 1;
	}else{
		ret= 0;
	}

#endif

	ret= 1; /* always connection */
/*	Station Inf Clear */
	gmemset(StationInf,0,sizeof(StationInf));

	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
int	PLC2_MakePLCReadData(int mode, char *pDevice, int DevAddr, char *combuff, int sCnt)
{
	int		ret;
	char	Kyoku[3];

	Bin2dec(pDevice[4],2,Kyoku);
	ret= 0;


#ifdef	MT

		switch(DevAddr)
		{
			case 0:
				PLC2_DeviceStartPoint = 0;
				break;						
			case 1:
				PLC2_DeviceStartPoint = 1;
				break;			
			case 2:
				PLC2_DeviceStartPoint = 2;
				break;							

			default:
				break;
		}

		if(DevAddr == 0 || DevAddr == 1 || DevAddr == 2){
			/*sprintf(combuff,"01RX%s",DevTbl[DevAddr-100]);*/
			gstrcpy(combuff,Kyoku);
			gstrcat(combuff,"RX");
			gstrcat(combuff,(char *)PlcType2DevTbl[DevAddr]);
		}else{
			ret= -1; /* �ش� PLC�� MT0,MT1,MT2�� �۽� ��巹���� ������ -1 ���� */ 
		}
#endif

	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
int	PLCCommRead2Proc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt;
	int		rCnt;
	unsigned char	*SaveAddr;
#ifdef	AUTO_FLOAT
	float	data;
#endif


#ifdef	MT
	unsigned int PLC2_data1;
	char	work[16];
/*ksc20041117*/
	unsigned int PLC2_dotdata;	
	char	dotpoint[2];	
	unsigned int PLC2_errordata;
	char	errorcode[2];

/*ksc20041117*/
#endif


	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = PLC2_MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PcThruRecData,mp->mext);
		Cnt = mp->mext;
		rCnt = Plc2_BitRecCnt;
		break;
	case PLC_WORD:		/* Word Device */
		ret = PLC2_MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PcThruRecData,mp->mext*2);
		Cnt = mp->mext* 2;
		rCnt = mp->mext* 2;
		break;
	}
	SaveAddr = (unsigned char *)mp->mptr;
	if(ret == 0){
		if(PLC2_SendRecPLCWithBCC(2,(char *)PcThruRecData,(unsigned char *)rDataFx,&i,0) == 0){
/*			if(rDataFx[0] == ACK){*/


#ifdef	MT
				for(i = 0; i < 7; i++){
					work[i] = rDataFx[i+8];
				}
				work[i]= 0;
			
				dotpoint[0] = rDataFx[15];
				dotpoint[1] = 0;					

				if(rDataFx[4]>= 0x30 && rDataFx[4] <=0x39)
				{  
					errorcode[0] = rDataFx[4];	
				}
				else
				{
					errorcode[0] = ' ';	
				}
				errorcode[1] = 0;	
				PLC2_data1= gatoi(work);			/* ���簪 */
				PLC2_errordata= gatoi(errorcode);		/* error code */
				PLC2_dotdata= gatoi(dotpoint);		/* �Ҽ��� �ڸ��� */				



			switch(PLC2_DeviceStartPoint)
			{
				case 0:
					for(i = 0; i < 2; i++){
						*(unsigned char *)SaveAddr= (unsigned char)(PLC2_data1 % 0x100);
						SaveAddr++;
						PLC2_data1 = PLC2_data1 / 0x100;
					}
					break;
				case 1:
					for(i = 0; i < 2; i++){
						*(unsigned char *)SaveAddr= (unsigned char)(PLC2_dotdata % 0x100);
						SaveAddr++;
						PLC2_dotdata = PLC2_dotdata / 0x100;
					}	
					break;
				case 2:
					if(rDataFx[4]>= 0x30 && rDataFx[4] <=0x39)
					{  
						for(i = 0; i < 2; i++){
							*(unsigned char *)SaveAddr= (unsigned char)(PLC2_errordata % 0x100);
							SaveAddr++;
							PLC2_errordata = PLC2_errordata / 0x100;
						}
					}

					break;															
			}				


/*ksc20041117*/
#endif
				
		}else{
			for(i = 0; i < Cnt; i++){
				*(unsigned char *)SaveAddr= (unsigned char)0;
				SaveAddr++;
			}
			ret = -1;
		}
	}else{
		ret= 0;
	}
	return(ret);
}




int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int	i;
	int	Cnt,idx;
	int	ret;

	Cnt= 0;
	idx= 0;

#ifdef	MT
	Cnt= mp->mext;
	idx= 2;
#endif


#ifdef	KSC		/*ksc20041122	*/

	for(i= 0; i < Cnt; i++){
		ret= PLCCommRead2Proc(mp,rDataFx,PlcType);
		if(ret == NG){
			break;
		}
		mp->mptr = (void *)((int)mp->mptr+ idx);	/* Save Addr */
		mp->mpar ++;	/* Read DEV Addr */

	}

#else	

	if(PlcStation[mp->mbuf[4]] == 0 ){		/* PLC Station OK 041119 */

		for(i= 0; i < Cnt; i++){
			ret= PLCCommRead2Proc(mp,rDataFx,PlcType);		/* ret = 0 : OK, ret = -1 : NG */  
			if(ret == NG){

				PlcStation[mp->mbuf[4]] = 1;		/* PLC Station NG 041119 */
				ret = 0;		/* NG ������ ���� ������ �е��� */			
				break;
			}
			mp->mptr = (void *)((int)mp->mptr+ idx);	/* Save Addr */
			mp->mpar ++;	/* Read DEV Addr */

		}
	}else if( PlcStation[mp->mbuf[4]] > 10 ){		/* ���� ������ ���� ī���Ͱ� 10�� �̻��ΰ��� ������ �ʱ�ȭ */

		for(i=0;i<32;i++)
		{
			if(PlcStation[i] != 0)
				PlcStation[32]++;
		}

		ret = 0;			/* ���� ī��Ʈ �ʱ�ȭ�� 6ȸ°�� ���� ��⵿ ���ؼ� ���� �̵����� �ʰ� ��� ��� */

		if(PlcStation[32] != 0){
			PlcStation[32] = 0;
			ret = -1;
		}			
		PlcStation[mp->mbuf[4]] = 0;		/* error count �ʱ�ȭ */	

	}else{					
		PlcStation[mp->mbuf[4]] = PlcStation[mp->mbuf[4]] + 1;		/* PLC error count �ش� ������ ������ ����.*/
		ret= 0;				/* ���� �ʱ�ȭ ���� �ʰ� ���������� ��� */
	}						

#endif

	return(ret);

}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
int	PLC2_ChangeIntData(char *data,int Cnt,int mode)
{
	int		iData;
	int		i;
	union{
		int		iData;
		char	cData[4];
	}rData;

	gmemset((char *)&rData,0,sizeof(rData));
	if(mode == 1){
		for(i= 0; i < Cnt*2 && i < 4; i++){
			rData.cData[3- i]= *data;
			data++;
		}
		iData = rData.iData;
	}else{
		iData = *data;
	}
	return(iData);
}
int	PLC2_ChangeShortData(char *data,int Cnt,int mode)
{
	int		iData;
	int		i;
	union{
		short	iData;
		char	cData[2];
	}rData;

	gmemset((char *)&rData,0,sizeof(rData));
	if(mode == 1){
		for(i= 0; i < Cnt*2 && i < 2; i++){
			rData.cData[1- i]= *data;
			data++;
		}
		iData = rData.iData;
	}else{
		iData = *data;
	}
	return(iData);
}
/****************************/
/* Make Write Device		*/
/****************************/
int	PLC2_MakePLCWriteData(int mode, char *pDevice, int DevAddr,int Cnt, char *combuff, char *data)
{

	int		ret;
	ret= 0;

	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
int	PLCCommWrite2Proc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;

	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = PLC2_MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PcThruRecData,(char *)mp->mptr);
		Cnt = mp->mext;
		break;
	case PLC_WORD:		/* Word Device */
		ret = PLC2_MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PcThruRecData,(char *)mp->mptr);
		Cnt = mp->mext* 2;
		break;
	}
	if(ret == 0){
		if(PLC2_SendRecPLCWithBCC(2,(char *)PcThruRecData,rDataFx,&Cnt,0) == 0){
		}else{
			ret = -1;
		}
	}

	return(ret);
}


int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(0);
}


int	GetSendRecTime2(void)
{
	return(0);				/* 0ms */
}
void	Get_Plc2_Ver(char *name)
{
	gstrcpy(name,"V1.30");
}
#ifdef	WIN32
/********************************************/
/*	�����֐�								*/
/********************************************/
int	PLC_CONNECT2(int *PlcType,int iConnect)
{
	return(Connection2(PlcType,iConnect));
}
int	PLC1CHAR_READ2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc2(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead2(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite2(mp,rDataFx,PlcType));
}
int	GET_SEND_REC_TIME2(void)
{
	return(GetSendRecTime2());
}
void	GET_PLC2_VER(char *Name)
{
	Get_Plc2_Ver(Name);
}
#endif
/****************************** END **********************/