/************************************************/
/*	PLC ����M �v���O����(Sumson N70Plus)		*/
/*	2003.5.31									*/
/************************************************/
#include	"define.h"
#include	"GpCommon.h"
#include	"plccommbuff.h"
#include	"mail.h"

/*#define	LOG*/

#ifndef	WIN32
#pragma	section PlcProc
#endif

#define	BIT_RD2	0x21
#define	BIT_WT2	0x22
#define	WRD_RD2	0x23
#define	WRD_WT2	0x24
#define	BWD_RD2	0x25
#define	BWD_WT2	0x26
#define	PRG_RD2	0x27

#define	BIT_RD4	0x01
#define	BIT_WT4	0x02
#define	WRD_RD4	0x03
#define	WRD_WT4	0x04
#define	BWD_RD4	0x05
#define	BWD_WT4	0x06
#define	PRG_RD4	0x07
int	ProtFlag;
/**************************************/
extern	int	Hex2nBin(char *buff,int cnt);
extern	int	Hex2Bin(char *buff);
extern	unsigned int LHexAsToBin(char *buff, int cnt);
extern	void	SendPLCPCData( void );
extern	int	SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode);
extern	int	SendPLC2PCData( int mode );
extern	int	SendPC2PLCData( int mode );
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	int	GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address);
extern	void	RtsOnOffSet(int type,int mode);
#ifdef	WIN32
extern int __cdecl Delay(int);
extern unsigned int __cdecl ReadSignal(int);
extern	void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity);
extern	void	PlcDevInit( void );
extern	unsigned char			GpFont[0x200000];
#else
#define SGN_PLC		0
#endif

/**************************************/


/****************************** for Window **********************/
/********************************************/
/*	�O���֐�								*/
/********************************************/
#ifdef	WIN32
int	B_Hex2nBin(char *buff,int cnt)
{
	return(Hex2nBin(buff,cnt));
}
int	B_Hex2Bin(char *buff)
{
	return(Hex2Bin(buff));
}
unsigned int B_LHexAsToBin(char *buff, int cnt)
{
	return(LHexAsToBin(buff,cnt));
}
void	B_SendPLCPCData( void )
{
	SendPLCPCData();
}
int	B_SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode)
{
	return(SendRecPLC(mode,rData,Cnt,rmode));
}
int	B_SendPLC2PCData( int mode )
{
	return(SendPLC2PCData(mode ));
}
int	B_SendPC2PLCData( int mode )
{
	return(SendPC2PLCData(mode ));
}
int	B_Delay(int p)
{
	return(Delay(p));
}
int	B_ReadSignal(int p)
{
	return(ReadSignal(p));
}
void	B_RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
	RsModeSet(type,mode,bordrate,ldata,parity);
}
int	B_GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address)
{
	return(GetDevNamePLCAddr(bFlag,src,obj,DevInfo,Address));
}
void	B_RtsOnOffSet(int type,int mode)
{
	RtsOnOffSet(type,mode);
}
#endif

/********************************************/
/* PLC-Program Title */
const char Title[16]= {
	'P','L','C', 'P','R','O','C',
};
#ifdef	WIN32
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#endif
/********************************/
/*	FX Serease					*/
/********************************/
const	unsigned char PLCIndexTable[256]={
	/* BIT */
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0xff,0x02,0x03,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x04,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0x05,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x06,
	/* WORD */
	0x00,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,0xff,0x02,0x03,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x04,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x07,0x08,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0x0d,0x0e,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x09,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
};
const	int PLCLowHighFlag= 0;				/* 0:L-H,1:H-L */
const	int	PLC_K3P_SereaseByteCnt= 7;
const	DEV_PC_TBL	PLC_K3P_SereaseByte[32]=
	{
		{1,0x10,{'R',  0, 0},0x85,0x00000000,0x00012715},
		{1,0x18,{'L',  0, 0},0x85,0x00000000,0x00006315},
		{1,0x1a,{'M',  0, 0},0x85,0x00000000,0x00012715},
		{1,0x1b,{'K',  0, 0},0x85,0x00000000,0x00012715},
		{1,0x28,{'F',  0, 0},0x85,0x00000000,0x00012715},
		{1,0x34,{'T',  0, 0},0x84,0x00000000,0x00001515},
		{1,0x7f,{'G','B', 0},0x88,0x00000000,0x00001024},
	};
const	int	PLC_K3P_SereaseWordCnt= 10;
const	DEV_PC_TBL	PLC_K3P_SereaseWord[32]=
	{
		{2,(unsigned char)0x80,{'R',  0, 0},0x84,0x00000000,0x00000127},
		{2,(unsigned char)0x88,{'L',  0, 0},0x84,0x00000000,0x00000063},
		{2,(unsigned char)0x8a,{'M',  0, 0},0x84,0x00000000,0x00000127},
		{2,(unsigned char)0x8b,{'K',  0, 0},0x84,0x00000000,0x00000127},
		{2,(unsigned char)0x98,{'F',  0, 0},0x84,0x00000000,0x00000127},
		{2,(unsigned char)0xa2,{'T','C', 0},0xc4,0x00000000,0x00000255},
		{2,(unsigned char)0xa3,{'T','C', 0},0xc4,0x00000000,0x00000255},
		{2,(unsigned char)0xc0,{'W',  0, 0},0xa4,0x00000000,0x00002047},
		{2,(unsigned char)0xc1,{'W',  0, 0},0xa4,0x00002560,0x00003071},
		{2,(unsigned char)0xef,{'G','D', 0},0x88,0x00000000,0x00001024},
	};
const	DEV_TBL bPLCDeviceTbl[16] = {
	{"R" ,0x0000,1},
	{"L" ,0x0800,1},
	{"M" ,0x0C00,1},
	{"K" ,0x1400,1},
	{"F" ,0x1C00,1},
	{"TC",0x1D00,1},
	{"GB" ,    0,4},
};
const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"R" ,0x0000,1},
	{"L" ,0x0080,1},
	{"M" ,0x00C0,1},
	{"K" ,0x0140,1},
	{"F" ,0x01C0,1},
	{"W" ,0x0200,1},
	{"PV",0x0B00,1},
	{"SV",0x0A00,1},
	{"SR",0x0C00,1},
	{"GD" ,    0,4},
};
#ifdef	OLD
  unsigned short crc16table[256] = {
	0x0000,0x1021,0x2042,0x3063,0x4084,0x50a5,0x60c6,0x70e7,
	0x8108,0x9129,0xa14a,0xb16b,0xc18c,0xd1ad,0xe1ce,0xf1ef,
	0x1231,0x0210,0x3273,0x2252,0x52b5,0x4294,0x72f7,0x62d6,
	0x9339,0x8318,0xb37b,0xa35a,0xd3bd,0xc39c,0xf3ff,0xe3de,
	0x2462,0x3443,0x0420,0x1401,0x64e6,0x74c7,0x44a4,0x5485,
	0xa56a,0xb54b,0x8528,0x9509,0xe5ee,0xf5cf,0xc5ac,0xd58d,
	0x3653,0x2672,0x1611,0x0630,0x76d7,0x66f6,0x5695,0x46b4,
	0xb75b,0xa77a,0x9719,0x8738,0xf7df,0xe7fe,0xd79d,0xc7bc,
	0x48c4,0x58e5,0x6886,0x78a7,0x0840,0x1861,0x2802,0x3823,
	0xc9cc,0xd9ed,0xe98e,0xf9af,0x8948,0x9969,0xa90a,0xb92b,
	0x5af5,0x4ad4,0x7ab7,0x6a96,0x1a71,0x0a50,0x3a33,0x2a12,
	0xdbfd,0xcbdc,0xfbbf,0xeb9e,0x9b79,0x8b58,0xbb3b,0xab1a,
	0x6ca6,0x7c87,0x4ce4,0x5cc5,0x2c22,0x3c03,0x0c60,0x1c41,
	0xedae,0xfd8f,0xcdec,0xddcd,0xad2a,0xbd0b,0x8d68,0x9d49,
	0x7e97,0x6eb6,0x5ed5,0x4ef4,0x3e13,0x2e32,0x1e51,0x0e70,
	0xff9f,0xefbe,0xdfdd,0xcffc,0xbf1b,0xaf3a,0x9f59,0x8f78,
	0x9188,0x81a9,0xb1ca,0xa1eb,0xd10c,0xc12d,0xf14e,0xe16f,
	0x1080,0x00a1,0x30c2,0x20e3,0x5004,0x4025,0x7046,0x6067,
	0x83b9,0x9398,0xa3fb,0xb3da,0xc33d,0xd31c,0xe37f,0xf35e,
	0x02b1,0x1290,0x22f3,0x32d2,0x4235,0x5214,0x6277,0x7256,
	0xb5ea,0xa5cb,0x95a8,0x8589,0xf56e,0xe54f,0xd52c,0xc50d,
	0x34e2,0x24c3,0x14a0,0x0481,0x7466,0x6447,0x5424,0x4405,
	0xa7db,0xb7fa,0x8799,0x97b8,0xe75f,0xf77e,0xc71d,0xd73c,
	0x26d3,0x36f2,0x0691,0x16b0,0x6657,0x7676,0x4615,0x5634,
	0xd94c,0xc96d,0xf90e,0xe92f,0x99c8,0x89e9,0xb98a,0xa9ab,
	0x5844,0x4865,0x7806,0x6827,0x18c0,0x08e1,0x3882,0x28a3,
	0xcb7d,0xdb5c,0xeb3f,0xfb1e,0x8bf9,0x9bd8,0xabbb,0xbb9a,
	0x4a75,0x5a54,0x6a37,0x7a16,0x0af1,0x1ad0,0x2ab3,0x3a92,
	0xfd2e,0xed0f,0xdd6c,0xcd4d,0xbdaa,0xad8b,0x9de8,0x8dc9,
	0x7c26,0x6c07,0x5c64,0x4c45,0x3ca2,0x2c83,0x1ce0,0x0cc1,
	0xef1f,0xff3e,0xcf5d,0xdf7c,0xaf9b,0xbfba,0x8fd9,0x9ff8,
	0x6e17,0x7e36,0x4e55,0x5e74,0x2e93,0x3eb2,0x0ed1,0x1ef0};
#endif
/************************************/
/* ��M�v���g�R��					*/
/************************************/
#ifdef	LOG
int		logCnt;
char	reclog[512];
char	modlog[512];
#endif
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(*CommMode){
	case 0:				/* DA */
		*RecCnt= 0;			/* �`���X�^�[�g */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 1;
		break;
	case 1:				/* SA */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 2;
		break;
	case 2:				/* Command */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 3;
		break;
	case 3:				/* Length */
		RecBuff[(*RecCnt)++] = data;
		PlcProtLeng= data;
		if(PlcProtLeng <= 0){
			*CommMode = 5;
		}else{
			*CommMode = 4;
		}
		break;
	case 4:				/* Data */
		RecBuff[(*RecCnt)++] = data;
		PlcProtLeng--;
		if(PlcProtLeng <= 0){
			*CommMode = 5;
		}
		break;
	case 5:				/* CRC1 */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 6;
		break;
	case 6:				/* CRC2 */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 0;
		ret= 0;
		break;
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

#ifdef	LOG
	reclog[logCnt]= data;
	modlog[logCnt]= *CommMode;
	logCnt= (logCnt+ 1) & 0xff;
#endif
	ret = -1;
	switch(*CommMode){			/* CommMode=0:Normal,1->3:Editor,4->PLC */
	case 0:		/* Normal DA */
		*CommMode = 4;
		*Sio1RecCnt = 0;
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		break;
	case 4:				/* SA */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		*CommMode = 5;
		break;
	case 5:				/* Command */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		*CommMode = 6;
		break;
	case 6:				/* Length */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		PlcProtLeng= data;
		if(PlcProtLeng <= 0){
			*CommMode = 8;
		}else{
			*CommMode = 7;
		}
		break;
	case 7:				/* Data */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		PlcProtLeng--;
		if(PlcProtLeng <= 0){
			*CommMode = 8;
		}
		break;
	case 8:				/* CRC1 */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		*CommMode = 9;
		break;
	case 9:				/* CRC2 */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		*CommMode = 99;
		ret= 0;
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/

/************************************/
/* ���ʏ���							*/
/************************************/
int	Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
void	Bin2Hex(int data,int cnt,char *buff)
{
	int		i;
	unsigned int AndData;

	AndData= 0x000f;
	for(i= 1; i < cnt; i++){
		AndData= AndData << 4;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= Bin2Hex1((data & AndData) >> ((cnt- i- 1)*4));
		AndData = AndData >> 4;
	}
	buff[i]= 0;
}
void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= '0'+ ((data / AndData) % 10);
		data= data % AndData;
		AndData = AndData / 10;
	}
	buff[i]= 0;
}
int	gstrlen(char *buff)
{
	int		i;

	for(i= 0; ; i++){
		if(buff[i] == 0){
			break;
		}
	}
	return(i);
}
void	gmemset(char *buff,int data,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*buff= (char)data;
		buff++;
	}
}
void	gmemcpy(char *obj,char *src,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*obj= *src;
		src++;
		obj++;
	}
}
void	gstrcpy(char *obj,char *src)
{
	int		i;

	for(i= 0; ; i++){
		*obj= *src;
		if(*src == 0){
			break;
		}
		src++;
		obj++;
	}
	*obj= 0;
}
int	gstrcmp(char *src,char *obj)
{
	int		i;
	int		ret;

	ret= NG;
	for(i= 0; ; i++){
		if(src[i] == 0){
			if(obj[i] == 0){
				ret= OK;
			}
			break;
		}
		if(obj[i] == 0){
			break;
		}
		if(src[i] != obj[i]){
			break;
		}
	}
	return(ret);
}
int	gstrncmp(char *src,char *obj,int cnt)
{
	int		i;
	int		ret;

	ret= OK;
	for(i= 0; i < cnt; i++){
		if(src[i] != obj[i]){
			ret= NG;
			break;
		}
	}
	return(ret);
}
void	gstrcat(char *src,char *obj)
{
	int		i;

	for(i= 0; ; i++){
		if(*src == 0){
			break;
		}
		src++;
	}
	for(i= 0; ; i++){
		if(*obj == 0){
			*src= 0;
			break;
		}
		*src= *obj;
		src++;
		obj++;
	}
}
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
int SetPLCBCC(char *buff,int cnt,unsigned char *OutBuf)
{
	int		i,j;
	unsigned int _crc16;

	_crc16 = 0xffff;
	for(i = 0; i < cnt; i++){
		OutBuf[i] = buff[i];
#ifdef	OLD
		_crc16 = crc16table[((_crc16 >> 8) & 0x00ff) ^ (buff[i] & 0x00ff)] ^ (_crc16 << 8);
#else
		_crc16= _crc16 ^ (buff[i] & 0x00ff);
		for(j= 0; j < 8; j++){
			if((_crc16 & 0x0001) == 0x0001){
				_crc16= (_crc16 >> 1) ^ 0xa001;
			}else{
				_crc16= _crc16 >> 1;
			}
		}
#endif
	}
	OutBuf[cnt] = (unsigned char)_crc16;
	OutBuf[cnt+1] = (unsigned char)(_crc16 >> 8);
	return(cnt + 2);
}
/************************************/
/*	PLC Send						*/
/************************************/
int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	int		i,j;
	unsigned int  _crc16;
	unsigned int  _crc16Rec;

	PlcCommCnt= SetPLCBCC((char *)combuf,*Cnt,PlcSendBuff);
	ret= B_SendRecPLC(mode,rData,Cnt,rmode);
	if(ret == 0){
		_crc16 = 0xffff;
		for(i = 0; i < *Cnt-2; i++){
#ifdef	OLD
			_crc16 = crc16table[((_crc16 >> 8) & 0xff) ^ rData[i]] ^ (_crc16 << 8);
#else
			_crc16= _crc16 ^ (rData[i] & 0x00ff);
			for(j= 0; j < 8; j++){
				if((_crc16 & 0x0001) == 0x0001){
					_crc16= (_crc16 >> 1) ^ 0xa001;
				}else{
					_crc16= _crc16 >> 1;
				}
			}
#endif
		}
		_crc16Rec= (rData[*Cnt-1] << 8) + (rData[*Cnt-2]);
		if(_crc16 != _crc16Rec){
			ret= -1;
		}
	}
	return(ret);
}
/********************************************/
int	SendCommandPLC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	unsigned char Comm;

	Comm= combuf[2] | 0x80;
	ret= SendRecPLCWithBCC(mode,combuf,rData,Cnt,rmode);
	if((ret == 0) && (rData[2] == 0x80)){
		combuf[0]= (unsigned char)DstStationNo;	/* DA */
		combuf[1]= (unsigned char)MyStationNo;	/* SA */
		combuf[2]= (unsigned char)0x00;			/* Command */
		combuf[3]= (unsigned char)0x01;			/* Length */
		combuf[4]= (unsigned char)0x00;			/* Command */
		*Cnt= 5;
		ret= SendRecPLCWithBCC(mode,combuf,rData,Cnt,0);
		if((ret == 0) && (rData[2] == Comm)){
		}else{
			ret= -1;
		}
	}
	return(ret);
}
/********************************************/
/*	Connection Proc							*/
/*	*PlcType:[0]->PlcType					*/
/*	         [1]->MyStation					*/
/*	         [2]->DstStation				*/
/********************************************/
int	Connection( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;

#ifdef	LOG
	logCnt= 0;
#endif
	ProtFlag= 0;		/* Protocol Flag */
	/* �������̃{�[���[�g */
	if((iConnect & 1) == 0){		/* RS-232C */
#ifdef	WIN32
		SioPCMode= 2;
		SioPCOpenFlag= 1;
#else
		B_RsModeSet(RS_PC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);
#endif
	}else{						/* RS-422 */
#ifdef	WIN32
		SioPLCMode= 2;
		SioPLCOpenFlag= 1;
#else
		B_RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);
#endif
	}
#ifdef	WIN32
	while(1){
		if(SioPLCOpenFlag == 0){
			break;
		}
		B_Delay(10);
	}
#endif
	B_Delay(500);

	/* PLC Connect Check */
	MyStationNo= PlcType[1];
	DstStationNo= PlcType[2];
	PLCcombuf[0]= (unsigned char)0xff;	/* DA */
	PLCcombuf[1]= (unsigned char)PlcType[1];	/* SA */
	PLCcombuf[2]= (unsigned char)PRG_RD4;		/* Command */
	PLCcombuf[3]= (unsigned char)0x03;			/* Length */
	PLCcombuf[4]= (unsigned char)0x00;			/* BASE(L) */
	PLCcombuf[5]= (unsigned char)0x00;			/* BASE(H) */
	PLCcombuf[6]= (unsigned char)0x02;			/* BASE(H) */

	Cnt= 7;
	ret= SendCommandPLC(2,(char *)PLCcombuf,GrpPLCcombuf,&Cnt,0);
	if(ret < 0){
		return(0);
	}
	DstStationNo= GrpPLCcombuf[1];		/* �ǔ� */
	ret= 1;
	return(ret);
}
/******************************************/
void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef	WIN32
#ifdef	OLD
	*PLCByteCnt= (int)GpFont[PLC_DEV_TBLBCT];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC_DEV_TBLBYT];
	*PLCWordCnt= (int)GpFont[PLC_DEV_TBLWCT];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC_DEV_TBLWOR];
	*PLCIndex= (unsigned char *)&GpFont[PLC_DEV_TBLIDX];
#else
	*PLCByteCnt= (int)PLC_K3P_SereaseByteCnt;
	*PLCWordCnt= (int)PLC_K3P_SereaseWordCnt;		/*  */
	*ByteTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseByte[0];
	*WordTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseWord[0];
	*PLCIndex= (unsigned char *)&PLCIndexTable[0];
#endif
#else
#ifndef	OLD
	*PLCByteCnt= *(int *)PLC_DEV_TBLBCT;
	*ByteTbl= (DEV_PC_TBL *)PLC_DEV_TBLBYT;
	*PLCWordCnt= *(int *)PLC_DEV_TBLWCT;		/*  */
	*WordTbl= (DEV_PC_TBL *)PLC_DEV_TBLWOR;
	*PLCIndex= (unsigned char *)PLC_DEV_TBLIDX;
#else
	*PLCByteCnt= (int)PLC_K3P_SereaseByteCnt;
	*PLCWordCnt= (int)PLC_K3P_SereaseWordCnt;		/*  */
	*ByteTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseByte[0];
	*WordTbl= (DEV_PC_TBL *)&PLC_K3P_SereaseWord[0];
	*PLCIndex= (unsigned char *)&PLCIndexTable[0];
#endif
#endif
}
/************************************/
/* Get Device Name					*/
/************************************/
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/************************************/
/*	Device & Address Change			*/
/************************************/
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(B_GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&i,&Address) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(gstrcmp(bPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(gstrcmp(wPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int		DevAddr;

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	if(ret == 0){
/*		DstStationNo= pDevice[4];*/
		combuff[0]= DstStationNo;		/* DA */
		combuff[1]= MyStationNo;		/* SA */
		if(mode == 0){		/* BIT */
			combuff[2]= BIT_RD4;		/* Command */
			combuff[3]= 0x03;		/* Length */
			combuff[4]= (char)DevAddr;
			combuff[5]= (char)(DevAddr >> 8);
			combuff[6]= sCnt;
		}else{				/* WORD */
			combuff[2]= WRD_RD4;		/* Command */
			combuff[3]= 0x03;		/* Length */
			combuff[4]= (char)DevAddr;
			combuff[5]= (char)(DevAddr >> 8);
			combuff[6]= sCnt;
		}
	}
	return(ret);
}
/************************************/
/* PLC Semafo						*/
/************************************/
void	SetPlcSema(void)
{
	while(ProtFlag != 0){
		B_Delay(10);
	}
	ProtFlag= 1;
}
void	ReSetPlcSema(void)
{
	ProtFlag= 0;
}
/************************************/
/* PLC Read							*/
/************************************/
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		Cnt;
	unsigned char	*SaveAddr;

	SetPlcSema();
	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PLCbuf,mp->mext);
		Cnt = mp->mext;
		break;
	case PLC_WORD:		/* Word Device */
		ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PLCbuf,mp->mext);
		Cnt = mp->mext;
		break;
	}
	SaveAddr = (unsigned char *)mp->mptr;
	if(ret == 0){
		i= 7;
		ret= SendCommandPLC(2,(char *)PLCbuf,(unsigned char *)rDataFx,&i,0);
		if(ret == 0){
			if(mp->mpec == PLC_BIT){		/* Bit Device */
				for(i = 0; i < Cnt; i++){
					if(rDataFx[i+4] != 0){
						*(unsigned char *)SaveAddr++ = 1;
					}else{
						*(unsigned char *)SaveAddr++ = 0;
					}
				}
			}else{						/* WORD */
				for(i = 0; i < Cnt*2; i++){
					*(unsigned char *)SaveAddr++ = rDataFx[i+4];
				}
			}
		}
	}else if(ret == 1){		/* ����Device */
		ret= 0;
	}
	ReSetPlcSema();
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	int		DevAddr;

	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);
	if(ret == 0){
/*		DstStationNo= pDevice[4];*/
		combuff[0]= DstStationNo;		/* DA */
		combuff[1]= MyStationNo;		/* SA */
		if(mode == 0){		/* BIT */
			combuff[2]= BIT_WT4;		/* Command */
			combuff[3]= Cnt+2;			/* Length */
			combuff[4]= (char)DevAddr;
			combuff[5]= (char)(DevAddr >> 8);
			for(i= 0; i < Cnt; i++){
				if(data[i] == 0){
					combuff[6+i]= 0;
				}else{
					combuff[6+i]= (char)0xff;
				}
			}
		}else{		/* WORD */
			combuff[2]= WRD_WT4;		/* Command */
			combuff[3]= Cnt*2+2;		/* Length */
			combuff[4]= (char)DevAddr;
			combuff[5]= (char)(DevAddr >> 8);
			for(i= 0; i < Cnt*2; i++){
				combuff[6+i]= data[i];
			}
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;

	SetPlcSema();
	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCbuf,(char *)mp->mptr);
		Cnt = mp->mext+2+4;
		break;
	case PLC_WORD:		/* Word Device */
		ret = MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCbuf,(char *)mp->mptr);
		Cnt = mp->mext*2+2+4;
		break;
	}
	if(ret == 0){
		ret= SendCommandPLC(2,(char *)PLCbuf,rDataFx,&Cnt,0);
	}else if(ret == 1){		/* ����Address */
		ret= 0;
	}
	ReSetPlcSema();
	return(ret);
}
/************************************************/
/*	�O���[�v����								*/
/************************************************/
int	MakePLCgDevAddress(int mode, char *pDevice, int Address, int *DevAddr)
{
	int		i;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(((unsigned char)pDevice[0] == 0x7f) || ((unsigned char)pDevice[0] == 0xef)){		/* UB,UW */
		return(ret);
	}
	/* Device Name */
	if(B_GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&i,&Address) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(gstrcmp(bPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(gstrcmp(wPLCDeviceTbl[i].Device,Device) == 0){
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address | 0x4000;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************************/
/*	�O���[�v�쐬						*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		iAddr;

	/* Same Device Check */
	DeviceDataSys[0].SameDevInf= 0;
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		for(j = 0; j < i; j++){
			if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
				(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
				(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
				(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) &&
				(DeviceDataSys[j].DevCnt == 1) ){
				break;
			}
		}
		if(j != i){		/* Same Device */
			DeviceDataSys[i].SameDevInf= j+ 1;
		}
	}
	/* Word Device */
	gDeviceCnt= 0;
	gDeviceCntWord= 0;
	for(i= 0; i< DeviceCntSys; i++){
		if((DeviceDataSys[i].DevFlag == 1) && (DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
			if(MakePLCgDevAddress(DeviceDataSys[i].DevFlag, DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress,&iAddr) == 0){
				PcThruAllData[4+gDeviceCnt*2]= iAddr;
				PcThruAllData[4+gDeviceCnt*2+1]= iAddr >> 8;
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
				DeviceDataSys[i].SameDevInf= -1;
				gDeviceCnt++;
				gDeviceCntWord++;
				if(gDeviceCnt > 99){
					break;
				}
			}
		}
	}
	/* Bit Sevice */
	gDeviceCntBit= 0;
	if(gDeviceCnt < 100){
		for(i= 0; i< DeviceCntSys; i++){
			if((DeviceDataSys[i].DevFlag == 0) && (DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				if(MakePLCgDevAddress(DeviceDataSys[i].DevFlag, DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress,&iAddr) == 0){
					PcThruAllData[4+gDeviceCnt*2]= iAddr;
					PcThruAllData[4+gDeviceCnt*2+1]= iAddr >> 8;
					gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
					DeviceDataSys[i].SameDevInf= -1;
					gDeviceCnt++;
					gDeviceCntBit++;
					if(gDeviceCnt > 99){
						break;
					}
				}
			}
		}
	}
	if(gDeviceCnt != 0){
		PcThruAllData[0]= DstStationNo;		/* DA */
		PcThruAllData[1]= MyStationNo;		/* SA */
		PcThruAllData[2]= BWD_RD4;			/* Command */
		PcThruAllData[3]= gDeviceCnt*2;			/* Length */
	}
	return(0);
}
/************************************/
/*	�O���[�v���[�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int		i;
	int		ret;
	int		Cnt;
	int		idx;
	char *SaveAddr;

	if(gDeviceCnt != 0){
		Cnt= gDeviceCnt*2+ 4;
		gmemcpy((char *)PLCcombuf,(char *)PcThruAllData,Cnt);
		ret= SendCommandPLC(2,(char *)PLCcombuf,(unsigned char *)GrpPLCcombuf,&Cnt,0);
		if(ret == 0){
			idx= 0;
			Cnt= 0;
			/* Word */
			for(i= 0; i < gDeviceCntWord; i++){
				SaveAddr= gDeviceAddr[idx];
				*SaveAddr++ = GrpPLCcombuf[idx*2+4];
				*SaveAddr= GrpPLCcombuf[idx*2+5];
				idx++;
			}
			Cnt= idx*2;
			/* Bit */
			for(i= 0; i < gDeviceCntBit; i++){
				SaveAddr= gDeviceAddr[idx];
				if(GrpPLCcombuf[Cnt+4+i] != 0){
					*SaveAddr= 1;
				}else{
					*SaveAddr= 0;
				}
				idx++;
			}
		}
	}
	return(0);
}
/************************************/
/*	�X���[���[�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	int		ret;
	int		Ds;
	int		Ss;
	int		Comm;

	if(CommBuff[2] != 0){
		SetPlcSema();
		Ds= CommBuff[0];
		Ss= CommBuff[1];
		Comm= CommBuff[2] | 0x80;
		PlcCommCnt= *RecCommCnt;
		gmemcpy((char *)PlcSendBuff,CommBuff,*RecCommCnt);
		ret= B_SendRecPLC(2,PcThruWData,&PcThruWCnt,0);
		if((ret == 0) && (PcThruWData[2] == 0x80)){
			PcThruRecData[0]= (unsigned char)Ds;	/* DA */
			PcThruRecData[1]= (unsigned char)Ss;	/* SA */
			PcThruRecData[2]= (unsigned char)0x00;			/* Command */
			PcThruRecData[3]= (unsigned char)0x01;			/* Length */
			PcThruRecData[4]= (unsigned char)0x00;			/* Command */
			PcThruBCnt= 5;
			ret= SendRecPLCWithBCC(2,(char *)PcThruRecData,PcThruBData,&PcThruBCnt,0);
			if((ret == 0) && (PcThruBData[2] == Comm)){
			}else{
				ret= -1;
			}
		}
		if(ret == 0){
			PlcThrueCnt= PcThruWCnt;
			gmemcpy((char *)PlcThrueBuff,(char *)PcThruWData,PcThruWCnt);
			B_SendPLC2PCData(0);
		}
		PcThru1014Rec= ret;
		ReSetPlcSema();
	}else{
		if(PcThru1014Rec == 0){
			PlcThrueCnt= PcThruBCnt;
			gmemcpy((char *)PlcThrueBuff,(char *)PcThruBData,PcThruBCnt);
			B_SendPLC2PCData(0);
		}
	}
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_38400;
	*DataBit= RS_DATA8;
	*Parity= RS_NONE;
}
int	GetSendRecTime(void)
{
	return(0);				/* 0ms */
}
#ifdef	WIN32
/********************************************/
/*	�����֐�								*/
/********************************************/
int	PLC_CONNECT(int *PlcType,int iConnect)
{
	return(Connection(PlcType,iConnect));
}
int	GET_PLC_NAME(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	PLC1CHAR_READ(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommRead(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(PLCCommWrite(mp,rDataFx,PlcType));
}
int	PLC_MAKE_GROUP(int PlcType)
{
	return(MakeGroupDevPLC(PlcType));
}
int	PLC_GROUP_READ(int PlcType)
{
	return(RecGroupPLCDev(PlcType));
}
int	PLCPCDOWN(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	return(PLCPCDownThrue(data,CommMode,Sio1RecCnt,Sio1RecBuff));
}
void	PLC_THRU_PROC(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	PLCFxThruProc(CommBuff,RecCommCnt,OutBuff,OutCnt,PlcConnectFlag,PlcType);
}
int	GET_PLC_MAX(int bFlag,int idx)
{
	return(GetDevMaxPLC(bFlag,idx));
}
int	GET_PLC_MIN(int bFlag,int idx)
{
	return(GetDevMinPLC(bFlag,idx));
}
int		DEVICE_2_INDEX(int bwflag,char *Name)
{
	return(Device2IndexPLC(bwflag,Name));
}
int		CHECK_PLC_ADDR(int bwflag,char *Name,int *Address1,int *plctype)
{
	return(CheckPLC_Addr(bwflag,Name,Address1,plctype));
}
void	GET_MON_BAUDRATE(int *Speed,int *DataBit,int *Parity)
{
	GetMonBaudrate(Speed,DataBit,Parity);
}
int	GET_SEND_REC_TIME(void)
{
	return(GetSendRecTime());
}
#endif
/****************************** END **********************/