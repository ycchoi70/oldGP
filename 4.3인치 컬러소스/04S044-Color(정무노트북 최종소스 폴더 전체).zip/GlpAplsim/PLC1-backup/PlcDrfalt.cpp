/************************************************/
/*	PLC ����M �v���O����(LG-K3P-07AS)			*/
/*	2003.5.31									*/
/************************************************/
#include	<string.h>
#include	<stdio.h>
#include	<stdlib.h>

#include	"mts.h"
#include	"mtscifp.h"
#include	"taskhed.h"
#include	"mail.h"
#include	"define.h"
#include	"GpCommon.h"

#define	MAX_BITCNT	16
#define	MAX_WORDCNT	60
#define	MAX_PBITCNT	16
#define	MAX_PWORDCNT	10
#define	MAX_UR_CNT	26
#define	MAX_WORD_CONT_CNT	4
#define	MAX_BIT_CONT_CNT	4

/*#ifndef	WIN32
#pragma	section DefPlcProc
#endif
*/

#define	DEFULT_PLC
#include	"PlcCommBuff.h"
#include	"PlcHed.h"


/****************************** for Window **********************/
/********************************************/
/*	�O���֐�								*/
/********************************************/

/********************************************/
/* PLC-Program Title */
#ifdef	WIN32
/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
#endif
/********************************/
/*	FX Serease					*/
/********************************/
#ifdef	WIN32
unsigned char IndexTable[256]={
#else
const	unsigned char IndexTable[256]={
#endif

	/* BIT */
/*
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x01,0xff,0xff,0xff,0x02,0xff,0xff,0xff,0x03,0xff,0x04,0x05,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x06,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0x07,0x08,0x09,0x0a,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x0b,0x0c,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x0d,
*/

	/* BIT */
/*ksc20040529*/
/*     0    1    2    3    4    5    6    7    8    9    a    b    c    d    e    f    */
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x01,0xff,0xff,0xff,0x02,0xff,0xff,0xff,0x03,0xff,0x04,0x05,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0x06,0x07,0x08,0x09,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x0a,0x0b,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x0c,
/*ksc20040529*/

/*ksc20041119 ���� �߰� */
/* BIT�� ����̽� �ڵ� 00���� 7F���� �Ҵ�Ȱ��� �ǹ��Ѵ�.
   ����ϴ� ��� ����̽��� ���⼭ �����Ѵ�. */
/*ksc20041119 ���� �߰� */
	
	/* WORD */
/*
	0x01,0xff,0xff,0xff,0x02,0xff,0xff,0xff,0x03,0xff,0x04,0x05,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x06,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0x07,0x08,0x09,0x0a,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x0b,0x0c,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x0d,0x0e,0xff,0x0f,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x10,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
*/

	/* WORD */
/*ksc20040529*/
/*     0    1    2    3    4    5    6    7    8    9    a    b    c    d    e    f    */
	0x01,0xff,0xff,0xff,0x02,0xff,0xff,0xff,0x03,0xff,0x04,0x05,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0x06,0x07,0x08,0x09,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x0a,0x0b,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x0c,0x0d,0xff,0x0e,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x0f,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*ksc20040529*/

};
#ifdef	WIN32
int LowHighFlag= 0;				/* 0:L-H,1:H-L */
int	K3P_SereaseByteCnt= 25;
DEV_PC_TBL	K3P_SereaseByte[32]=
#else
const	int LowHighFlag= 0;				/* 0:L-H,1:H-L */
const	int	K3P_SereaseByteCnt= 25;
const	DEV_PC_TBL	K3P_SereaseByte[32]=
#endif
	{

/*
		{1,0x01,{'?',  0, 0},0x88,0x00000000,0x00000000,0x0000,0x0000,0x0001},	
		{1,0x10,{'P',  0, 0},0x85,0x00000000,0x0000015f,0x0000,0x000f,0x0001},	
		{1,0x14,{'P',  0, 0},0x85,0x00000000,0x0000015f,0x0000,0x000f,0x0001},	
		{1,0x18,{'M',  0, 0},0x85,0x00000000,0x0000191f,0x0000,0x000f,0x0001},	
		{1,0x1a,{'K',  0, 0},0x85,0x00000000,0x0000031f,0x0000,0x000f,0x0001},	
		{1,0x1b,{'F',  0, 0},0x85,0x00000000,0x0000031f,0x0000,0x000f,0x0001},	
		{1,0x29,{'L',  0, 0},0x85,0x00000000,0x0000063f,0x0000,0x000f,0x0001},	
		{1,0x32,{'T',  0, 0},0xc4,0x00000192,0x00000255,0x0000,0x0009,0x0001},	
		{1,0x33,{'T',  0, 0},0xc4,0x00000240,0x00000255,0x0000,0x0009,0x0001},	
		{1,0x34,{'T',  0, 0},0xc4,0x00000000,0x00000191,0x0000,0x0009,0x0001},	
		{1,0x35,{'T',  0, 0},0xc4,0x00000144,0x00000191,0x0000,0x0009,0x0001},	
		{1,0x50,{'C',  0, 0},0xc4,0x00000000,0x00000255,0x0000,0x0009,0x0001},	
		{1,0x51,{'C',  0, 0},0xc4,0x00000192,0x00000255,0x0000,0x0009,0x0001},	
		{1,0x7f,{'U','B', 0},0x85,0x00000000,0x0006047f,0x0000,0x000f,0x0001},	
*/
/*ksc20040529*/ /* Default PLC ����ϴ� ��Ʈ����̽��� ����, ������ �����ڵ�� ������ ��� */
		{1,0x01,{'?',  0, 0},0x88,0x00000000,0x00000000,0x0000,0x0000,0x0001},	/* 0x00	*/
		{1,0x10,{'P',  0, 0},0x85,0x00000000,0x0000031f,0x0000,0x000f,0x0001},	/* 0x01	*/
		{1,0x14,{'P',  0, 0},0x85,0x00000000,0x0000031f,0x0000,0x000f,0x0001},	/* 0x02	*/
		{1,0x18,{'M',  0, 0},0x85,0x00000000,0x0000191f,0x0000,0x000f,0x0001},	/* 0x03	*/
		{1,0x1a,{'K',  0, 0},0x85,0x00000000,0x0000031f,0x0000,0x000f,0x0001},	/* 0x04	*/
		{1,0x1b,{'F',  0, 0},0x85,0x00000000,0x0000063f,0x0000,0x000f,0x0001},	/* 0x05	*/
/*		{1,0x29,{'L',  0, 0},0x85,0x00000000,0x0000063f,0x0000,0x000f,0x0001},	*/
		{1,0x32,{'T',  0, 0},0x84,0x00000192,0x00000255,0x0000,0x0009,0x0001},	/* 0x06	*/
		{1,0x33,{'T',  0, 0},0x84,0x00000240,0x00000255,0x0000,0x0009,0x0001},	/* 0x07	*/
		{1,0x34,{'T',  0, 0},0x84,0x00000000,0x00000191,0x0000,0x0009,0x0001},	/* 0x08	*/
		{1,0x35,{'T',  0, 0},0x84,0x00000144,0x00000191,0x0000,0x0009,0x0001},	/* 0x09	*/

		{1,0x50,{'C',  0, 0},0x84,0x00000000,0x00000255,0x0000,0x0009,0x0001},	/* 0x0a	*/
		{1,0x51,{'C',  0, 0},0x84,0x00000192,0x00000255,0x0000,0x0009,0x0001},	/* 0x0b	*/
//		{1,0x7f,{'U','B', 0},0x85,0x00000000,0x0032767f,0x0000,0x000f,0x0001},	/* 0x0c	*/
		{2,0x7f,{'U','B', 0},0x85,0x00000000,0x0007255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00080000,0x0008255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00100000,0x0010031f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00110000,0x0011255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00130000,0x0013255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00150000,0x0015031f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00160000,0x0016255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00180000,0x0018255f,0x0000,0x000f,0x0001},

		{2,0x7f,{'U','B', 0},0x85,0x00200000,0x0029999f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00360000,0x0036255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00380000,0x0038999f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00400000,0x0049999f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00600000,0x0061511f,0x0000,0x000f,0x0001},
/*		{��Ʈ. �ڵ�, ����̽�, , , ����, ���۹���, �������, , , , } */

/*ksc20040529*/
	};
#ifdef	WIN32
int	K3P_SereaseWordCnt= 28;
DEV_PC_TBL	K3P_SereaseWord[32]=
#else
const	int	K3P_SereaseWordCnt= 28;
const	DEV_PC_TBL	K3P_SereaseWord[32]=
#endif
	{
/*
		{2,(unsigned char)0x01,{'?',  0, 0},0x88,0x00000000,0x00000000,0x0000,0x0000,0x0001},
		{2,(unsigned char)0x80,{'P',  0, 0},0x84,0x00000000,0x00000015,0x0000,0x0009,0x0001},
		{2,(unsigned char)0x84,{'P',  0, 0},0x84,0x00000000,0x00000015,0x0000,0x0009,0x0001},
		{2,(unsigned char)0x88,{'M',  0, 0},0x84,0x00000000,0x00000191,0x0000,0x0009,0x0001},
		{2,(unsigned char)0x8a,{'K',  0, 0},0x84,0x00000000,0x00000031,0x0000,0x0009,0x0001},
		{2,(unsigned char)0x8b,{'F',  0, 0},0x84,0x00000000,0x00000031,0x0000,0x0009,0x0001},
		{2,(unsigned char)0x98,{'L',  0, 0},0x84,0x00000000,0x00000063,0x0000,0x0009,0x0001},	
		{2,(unsigned char)0xa2,{'T',  0, 0},0xc4,0x00000192,0x00000255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xa3,{'T',  0, 0},0xc4,0x00000240,0x00000255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xa4,{'T',  0, 0},0xc4,0x00000000,0x00000191,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xa5,{'T',  0, 0},0xc4,0x00000144,0x00000191,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xb0,{'C',  0, 0},0xc4,0x00000000,0x00000255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xb1,{'C',  0, 0},0xa4,0x00000192,0x00000255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xc0,{'D',  0, 0},0xa4,0x00000000,0x00004500,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xc1,{'D',  0, 0},0xa4,0x00003500,0x00004500,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xc3,{'D',  0, 0},0xa4,0x00004500,0x00004999,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00000000,0x00006047,0x0000,0x0009,0x0001},

*/
/*ksc20040529*/ /* Default PLC ����ϴ� �������̽��� ����, ������ �����ڵ�� ������ ��� */
		{2,(unsigned char)0x01,{'?',  0, 0},0x88,0x00000000,0x00000000,0x0000,0x0000,0x0001}, /* 0x00	*/
		{2,(unsigned char)0x80,{'P',  0, 0},0x84,0x00000000,0x00000031,0x0000,0x0009,0x0001}, /* 0x01	*/
		{2,(unsigned char)0x84,{'P',  0, 0},0x84,0x00000000,0x00000031,0x0000,0x0009,0x0001}, /* 0x02	*/
		{2,(unsigned char)0x88,{'M',  0, 0},0x84,0x00000000,0x00000191,0x0000,0x0009,0x0001}, /* 0x03	*/
		{2,(unsigned char)0x8a,{'K',  0, 0},0x84,0x00000000,0x00000031,0x0000,0x0009,0x0001}, /* 0x04	*/
		{2,(unsigned char)0x8b,{'F',  0, 0},0x84,0x00000000,0x00000063,0x0000,0x0009,0x0001}, /* 0x05	*/
/*		{2,(unsigned char)0x98,{'L',  0, 0},0x84,0x00000000,0x00000063,0x0000,0x0009,0x0001},	*/
		{2,(unsigned char)0xa2,{'T',  0, 0},0xc4,0x00000192,0x00000255,0x0000,0x0009,0x0001}, /* 0x06	*/
		{2,(unsigned char)0xa3,{'T',  0, 0},0xc4,0x00000240,0x00000255,0x0000,0x0009,0x0001}, /* 0x07	*/
		{2,(unsigned char)0xa4,{'T',  0, 0},0xc4,0x00000000,0x00000191,0x0000,0x0009,0x0001}, /* 0x08	*/
		{2,(unsigned char)0xa5,{'T',  0, 0},0xc4,0x00000144,0x00000191,0x0000,0x0009,0x0001}, /* 0x09	*/

		{2,(unsigned char)0xb0,{'C',  0, 0},0xc4,0x00000000,0x00000255,0x0000,0x0009,0x0001}, /* 0x0a	*/
		{2,(unsigned char)0xb1,{'C',  0, 0},0xc4,0x00000192,0x00000255,0x0000,0x0009,0x0001}, /* 0x0b	*/
		{2,(unsigned char)0xc0,{'D',  0, 0},0xa4,0x00000000,0x00004500,0x0000,0x0009,0x0001}, /* 0x0c	*/
		{2,(unsigned char)0xc1,{'D',  0, 0},0xa4,0x00003500,0x00004500,0x0000,0x0009,0x0001}, /* 0x0d	*/
		{2,(unsigned char)0xc3,{'D',  0, 0},0xa4,0x00004500,0x00004999,0x0000,0x0009,0x0001}, /* 0x0e	*/
//		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00000000,0x00032767,0x0000,0x0009,0x0001}, /* 0x0f	*/
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00000000,0x00007255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00008000,0x00008255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00010000,0x00010031,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00011000,0x00011255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00013000,0x00013255,0x0000,0x0009,0x0001},

		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00015000,0x00015031,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00016000,0x00016255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00018000,0x00018255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00020000,0x00029999,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00036000,0x00036255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00038000,0x00038999,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00040000,0x00049999,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00060000,0x00061511,0x0000,0x0009,0x0001},
/* 0x84�� 8 �ǹ̴� ��Ʈ�ϰ�� ��Ʈ ǥ��, �����ϰ�� ����ǥ�ø� �ǹ��Ѵ�. */  
/* 0xc4�� C �ǹ̴� ��Ʈ/���� ���� ǥ���Ҷ� C�� ���� */
/* 0xa4�� a �ǹ̴� 16��Ʈ/32��Ʈ ǥ�ý� a�� ���� */
/* ���ÿ� ǥ���ϰ��� �Ұ�� DeviceMoni�� GETDevName �Լ����� itype�� Ȯ���ϸ� �˼� ���� */
		
/*ksc20040529*/

	};
const	DEV_TBL bDeviceTbl[16] = {
	{"P" ,0x5c00,2},
	{"M" ,0x5d00,3},
	{"K" ,0x6000,2},
	{"F" ,0x6300,2},
	{"L" ,0x5f00,2},
	{"T" ,0x6100,3},
	{"C" ,0x6200,3},
	{"UB" ,    0,4},
};
const	DEV_TBL	wDeviceTbl[16] = {
	{"P" ,0x5c00,2},
	{"M" ,0x5d00,3},
	{"K" ,0x6000,2},
	{"F" ,0x6300,2},
	{"L" ,0x5f00,2},
	{"T" ,0x5000,3},
	{"C" ,0x5200,3},
	{"D" ,0x0000,4},
	{"S" ,0x6400,2},
	{"UW" ,    0,4},
};
const	PLC_CONST	LgComm[3]={
	{"uW",1},
	{"uR",1},
	{"uE",1},
};
/************************************/
/* ��M�v���g�R��					*/
/************************************/
/*********************************/
/*	PLC Semafor			         */
/*********************************/
void	LgGetGroopSema(void)
{
	if(LgGroopSema == 0){		/* Grooping Sema */
	}else{
		while(1)
		{
			if(LgGroopSema == 0){		/* Grooping Sema */
				break;
			}
			Delay(10);
		}
	}
	LgGroopSema++;
}
void	LgResetGroopSema(void)
{
	LgGroopSema= 0;
}
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
int	PlcRecRS(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret= -1;

	switch(data){
	case STX:
	case ENQ:
	case ACK:
	case NAK:
		*RecCnt= 0;			/* �`���X�^�[�g */
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 1;
		break;
	default:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		switch(*CommMode){
		case 1:
			if((data == EOT) || (data == ETX)){
				*CommMode = 0;
				ret= 0;
			}
			break;
		}
		break;
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PCDownThrueLG(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	switch(*CommMode){
	case 0:		/* Normal */
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:		/* Thru Mode */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			if((data == EOT) || (data == ETX)){
				*CommMode = 99;
				ret = 0;	/* Pendding Req */
			}
		}else{
			*CommMode = 0;
		}
		break;
	}
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/

/************************************/
/* ���ʏ���							*/
/************************************/
int	LG_Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
void	LG_Bin2Hex(int data,int cnt,char *buff)
{
	int		i;
	unsigned int AndData;

	AndData= 0x000f;
	for(i= 1; i < cnt; i++){
		AndData= AndData << 4;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= LG_Bin2Hex1((data & AndData) >> ((cnt- i- 1)*4));
		AndData = AndData >> 4;
	}
	buff[i]= 0;
}
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
int LG_SetPLCBCC(char *buff,int cnt)
{
	int		i;
	unsigned char bcc;

	buff[0] = STX;
	bcc = 0;
	for(i = 0; i < cnt; i++){
		bcc += buff[i+1];
	}
	/*sprintf((char *)&OutBuf[cnt+1],"%02X",bcc&0x00ff);*/
	LG_Bin2Hex(bcc&0x00ff,2,(char *)&buff[cnt+1]);
	buff[cnt+3] = ETX;
	return(cnt + 4);
}
/************************************/
/*	PLC Send						*/
/************************************/
int	LG_SendRecPLCWithBCC(int mode,unsigned char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	int		SendCnt;

	SendCnt= LG_SetPLCBCC((char *)combuf,strlen((char *)&combuf[1]));
	ret= SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	return(ret);
}
int	LG_Connection( int *PlcType,int iConnect )
{
	int		ret;
	int		Cnt;

	/* �������̃{�[���[�g */
	if(iConnect == CH_CH1){		/* RS-232C */
#ifdef	WIN32
		SioPCMode= 2;
		SioPCOpenFlag= 1;
#else
		RsModeSet(RS_PC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);
#endif
	}else{						/* RS-422 */
#ifdef	WIN32
		SioPLCMode= 2;
		SioPLCOpenFlag= 1;
#else
		RsModeSet(RS_PLC,RS_INIT,RS_38400,RS_DATA8,RS_NONE);
#endif
	}
#ifdef	WIN32
#endif
	Delay(250);

	/* PLC Connect Check */
	PlcSendBuff[1]= 'j';
	PlcSendBuff[2]= 0;
	ret= LG_SendRecPLCWithBCC(2,PlcSendBuff,PlcSendBuff,&Cnt,0);
	if(PlcSendBuff[0] != 0x06){
		ret= -1;
	}
	LgResetGroopSema();
	LgLgCommSeq= 0;

	if(ret < 0){
		return(0);
	}
	ret= 1;
	return(ret);
}
/******************************************/
void	LG_SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
	*PLCByteCnt= (int)K3P_SereaseByteCnt;
	*PLCWordCnt= (int)K3P_SereaseWordCnt;		/*  */
	*ByteTbl= (DEV_PC_TBL *)&K3P_SereaseByte[0];
	*WordTbl= (DEV_PC_TBL *)&K3P_SereaseWord[0];
	*PLCIndex= (unsigned char *)&IndexTable[0];
}
/************************************/
/* Get Device Name					*/
/************************************/
int	LG_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	LG_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			memcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			memcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			/* 16/32/48/64�ǉ� */
			*DevInfo= *DevInfo | (WordTbl[PLCIndex[src[0]]].WordType << 16);
			ret= 0;
		}
	}
	return(ret);
}
int	LG_GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	LG_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	LG_GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	LG_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
int	LG_MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i,j;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(LG_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(bDeviceTbl[i].Device[0] == Device[0]){
					DeviceFlag= bDeviceTbl[i].flag;
					OffSet= bDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ (Address/ 16) * 2;
				ret = Address % 16;
				BitAndData = 1;
				for(j = 0; j < ret; j++){
					BitAndData <<= 1;
				}
				ret += (sCnt- 1);
				ret = ret / 8 + 1;
				if((ret % 2) != 0){
					ret++;
				}
				BitRecCnt = ret;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(wDeviceTbl[i].Device[0] == Device[0]){
					DeviceFlag= wDeviceTbl[i].flag;
					OffSet= wDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = OffSet+ Address* 2;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
int	LG_MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		ret;
	int		DevAddr;
	char	buff[32];
	char	abuff[4+1];

	ret= LG_MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		LG_Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		if(mode == 0){		/* BIT */
			/*sprintf(combuff,"rM%s00%02X",abuff,BitRecCnt);*/
			strcpy(combuff,"rM");
			strcat(combuff,abuff);
			strcat(combuff,"00");
			LG_Bin2Hex(BitRecCnt,2,abuff);
			strcat(combuff,abuff);
		}else{				/* WORD */
			/*sprintf(combuff,"rM%s00%02X",abuff,sCnt);*/
			strcpy(combuff,"rM");
			strcat(combuff,abuff);
			strcat(combuff,"00");
			LG_Bin2Hex(sCnt,2,abuff);
			strcat(combuff,abuff);
		}
	}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
int	LG_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j;
	int		Cnt,dCnt;
	int		rCnt;
	int		rdata;
	unsigned char	*SaveAddr;
/*	char	Device[4];*/
/*	int		DevInfo;*/
	int		Address;
/*	int		UsrAddress;*/

	LgGetGroopSema();			/* For Monitor */
	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		Address= mp->mpar;
/*		ret= GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);*/
		dCnt= mp->mext;
		while(1){
			if(dCnt > MAX_BITCNT){
				dCnt -= MAX_BITCNT;
				mp->mext= MAX_BITCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = LG_MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],mp->mext);
			Cnt = mp->mext;
			rCnt = BitRecCnt;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				if(LG_SendRecPLCWithBCC(2,PlcSendBuff,(unsigned char *)rDataFx,&i,0) == 0){
					if(rDataFx[0] != 0x06){
						ret= -1;
					}else{
						for(i = 0; i < rCnt; i++){
							rDataFx[i] = (unsigned char)Hex2Bin((char *)&rDataFx[i*2+ 2]);
						}
						j= 0;
						rdata= rDataFx[j] + (rDataFx[j+1] << 8);
						for(i = 0; i < Cnt; i++){
							if(rdata & BitAndData){
								*(unsigned char *)SaveAddr++ = 1;
							}else{
								*(unsigned char *)SaveAddr++ = 0;
							}
							BitAndData <<= 1;
							if(BitAndData > 0x8000){
								BitAndData = 1;
								j++;
								rdata= rDataFx[j*2] + (rDataFx[j*2+1] << 8);
							}
						}
					}
				}else{
					ret = -1;
					break;
				}
			}
			if(dCnt == 0){
				break;
			}
			Address += MAX_BITCNT;
/*			UsrAddress= SetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);
			mp->mpar= UsrAddress;
*/
			mp->mpar= Address;
			mp->mptr= (void *)((char *)mp->mptr + MAX_BITCNT);
		}
		break;
	case PLC_WORD:		/* Word Device */
		Address= mp->mpar;
/*		ret= GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);*/
		dCnt= mp->mext;
		while(1){
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = LG_MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)&PlcSendBuff[1],mp->mext*2);
			Cnt = mp->mext* 2;
			rCnt = mp->mext* 2;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				if(LG_SendRecPLCWithBCC(2,PlcSendBuff,(unsigned char *)rDataFx,&i,0) == 0){
					if(rDataFx[0] != 0x06){
						ret= -1;
					}else{
						for(i = 0; i < rCnt; i++){
							rDataFx[i] = (unsigned char)Hex2Bin((char *)&rDataFx[i*2+ 2]);
						}
#ifdef	WIN32
						for(i = 0; i < Cnt; i++){
							*(unsigned char *)SaveAddr++ = rDataFx[i];
						}
#else
						for(i = 0; i < Cnt/2; i++){
							*(unsigned char *)SaveAddr++ = rDataFx[i*2+1];
							*(unsigned char *)SaveAddr++ = rDataFx[i*2];
						}
#endif
					}
				}else{
					ret = -1;
					break;
				}
			}
			if(dCnt == 0){
				break;
			}
			Address += MAX_WORDCNT;
/*			UsrAddress= SetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);
			mp->mpar= UsrAddress;
*/
			mp->mpar= Address;
			mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
		}
		break;
	}
	LgResetGroopSema();
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
/****************************/
/* Make Write Device		*/
/****************************/
int	LG_MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	int		DevAddr;
	char	buff[32];
	char	abuff[4+1];

	ret= LG_MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		LG_Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		if(mode == 0){		/* BIT */
			if(*data == 0){			/* OFF */
				/*sprintf(combuff,"nM%s00",abuff);*/
				strcpy(combuff,"nM");
				strcat(combuff,abuff);
				strcat(combuff,"00");
				/*sprintf(buff,"%04X",(~BitAndData & 0x0000ffff));*/
				LG_Bin2Hex((~BitAndData & 0x0000ffff),4,buff);
				abuff[0]= buff[2];
				abuff[1]= buff[3];
				abuff[2]= buff[0];
				abuff[3]= buff[1];
				abuff[4]= 0;
				strcat(combuff,abuff);
			}else{
				/*sprintf(combuff,"oM%s00",abuff);*/
				strcpy(combuff,"oM");
				strcat(combuff,abuff);
				strcat(combuff,"00");
				/*sprintf(buff,"%04X",BitAndData);*/
				LG_Bin2Hex(BitAndData,4,buff);
				abuff[0]= buff[2];
				abuff[1]= buff[3];
				abuff[2]= buff[0];
				abuff[3]= buff[1];
				abuff[4]= 0;
				strcat(combuff,abuff);
			}
		}else{		/* WORD */
			/*sprintf(combuff,"wM%s00%02d",abuff,Cnt*2);*/
			strcpy(combuff,"wM");
			strcat(combuff,abuff);
			strcat(combuff,"00");
			LG_Bin2Hex(Cnt*2,2,buff);
			strcat(combuff,buff);
			for(i= 0; i < Cnt*2; i++){
				/*sprintf(buff,"%02X",data[i] & 0xff);*/
				LG_Bin2Hex(data[i] & 0xff,2,buff);
				strcat(combuff,buff);
			}
		}
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
int	LG_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;
	int		dCnt;
/*	char	Device[4];*/
/*	int		DevInfo;*/
	int		Address;
/*	int		UsrAddress;*/

	LgGetGroopSema();			/* For Monitor */
	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = LG_MakePLCWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)&PlcSendBuff[1],(char *)mp->mptr);
		Cnt = mp->mext;
		if(ret == 0){
			if(LG_SendRecPLCWithBCC(2,PlcSendBuff,rDataFx,&Cnt,0) == 0){
				if(rDataFx[0] != 0x06){
					ret= -1;
				}
			}else{
				ret = -1;
			}
		}
		break;
	case PLC_WORD:		/* Word Device */
		Address= mp->mpar;
/*		ret= GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);*/
		dCnt= mp->mext;
		while(1){
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
			ret = LG_MakePLCWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)&PlcSendBuff[1],(char *)mp->mptr);
			if(DeviceFlag == 2){		/* TS,CS */
				Cnt = mp->mext* 4;
			}else{
				Cnt = mp->mext* 2;
			}
			if(ret == 0){
				if(LG_SendRecPLCWithBCC(2,PlcSendBuff,rDataFx,&Cnt,0) == 0){
					if(rDataFx[0] != 0x06){
						ret= -1;
						break;
					}
				}else{
					ret = -1;
					break;
				}
			}
			if(dCnt == 0){
				break;
			}
			Address += MAX_WORDCNT;
/*			UsrAddress= SetPLCUsrAddr(DevInfo,Address,mp->mbuf[0],mp->mpec);
			mp->mpar= UsrAddress;
*/
			mp->mpar= Address;
			mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
		}
		break;
	}
	LgResetGroopSema();
	return(ret);
}
/************************************************/
/*	�O���[�v����								*/
/************************************************/
int	LG_PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	int	ret;
	int	DevAddr;
	char	buff[8];
	char	abuff[8];

	if(((unsigned char)DevName[0] == 0x7f) || ((unsigned char)DevName[0] == 0xef)){		/* UB,UW */
		return(-1);
	}
	ret= LG_MakePLCDevAddress(mode, DevName, DevAddress, &DevAddr, 2);
	if(ret == 0){
		/*sprintf(buff,"%04X",DevAddr);*/
		LG_Bin2Hex(DevAddr,4,buff);
		abuff[0]= buff[2];
		abuff[1]= buff[3];
		abuff[2]= buff[0];
		abuff[3]= buff[1];
		abuff[4]= 0;
		/*sprintf(work,"M%s0002",abuff);*/
		strcpy(work,"M");
		strcat(work,abuff);
		strcat(work,"0002");
	}
	return(ret);
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	LG_MakeBitContinue(void)
{
/*	int		i,j,k,ret;*/
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if((DeviceDataSys[i].SameDevInf == 0) && (DeviceDataSys[i].DevCnt == 1)){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
/*						ret= GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
						MyAddress= DeviceDataSys[i].DevAddress;
/*						ret= GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}

						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
void	LG_MakeWordContinue(int WordStart)
{
/*	int		i,j,k,ret;*/
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
/*					ret= GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
					MyAddress= DeviceDataSys[i].DevAddress;
/*					ret= GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Befor Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}

					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN								*/
/***************************************************/
void	LG_MakeBitPatarn(int Bit_Cnt)
{

}
/***************************************************/
/*	WORD GROUP-PATARN								*/
/***************************************************/
void	LG_MakeWordPatarn(int Start)
{

}
/***************************************************/
/*	WORD GROUP-PATARN								*/
/***************************************************/
void	LG_ClearBWContinue(void)
{
	int		i,j,idx;

	for(i= 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus != 0)){
			/* Continue */
			if(DeviceDataSys[i].DevFlag == 0){		/* BIT */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_BIT_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}else{									/* WORD */
				if((DeviceDataSys[i].Continus+ DeviceDataSys[i].DevCnt) <= MAX_WORD_CONT_CNT){
					/* Clear Continue */
					j= i;
					while(1){
						idx= DeviceDataSys[j].Order- 1;	/* NEXT DEV */
						DeviceDataSys[j].SameDevInf= 0;
						DeviceDataSys[j].Continus= 0;
						DeviceDataSys[j].Order= -1;
						j= idx;
						if(j < 0){
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	�O���[�v�쐬						*/
/****************************************/
int		LG_MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Set Group */
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	gDeviceCnt= 0;
	/* Same Device Check */
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		for(j = 0; j < i; j++){
			if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
				(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
				(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
				(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
				break;
			}
		}
		if(j != i){		/* Same Device */
			DeviceDataSys[i].SameDevInf= 1;
			DeviceDataSys[i].Order= j+ 1;
		}else{
			if(DeviceDataSys[i].DevFlag == 0){
				BitCnt++;
			}else{
				WordCnt++;
			}
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	if(BitCnt > 0){
		LG_MakeBitContinue();
	}
	if(WordCnt > 0){
		LG_MakeWordContinue(TotalBitCnt);
	}
	/* Continue MAX Check */
	LG_ClearBWContinue();
	if(BitCnt > 0){
		LG_MakeBitPatarn(TotalBitCnt);
	}
	if(WordCnt > 0){
		LG_MakeWordPatarn(TotalBitCnt);
	}
	return(0);
}
/************************************/
/*	�O���[�v���[�h			        */
/************************************/
int		LG_SetGroupDevPLC(void)
{
	int		i;
	int		idx;
	char	work[12+ 1];
	int		ret= 0;
	int		Cnt;

	/* Same Device Check */
	memset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	strcpy((char *)&PlcSendBuff[1],"uW0002");
	idx= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	for(i = 0; i < DeviceCntSys; i++){
		/* CS,TS Check */
		if((DeviceDataSys[i].DevCnt == 1) &&
			(DeviceDataSys[i].DevFlag == 1) &&
			(DeviceDataSys[i].SameDevInf == 0) &&
			(DeviceDataSys[i].Continus == 0)){
			if(LG_PlcMakeDeviceAddr(DeviceDataSys[i].DevFlag, (char *)DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work) == 0){
				strcpy((char *)&PlcSendBuff[7 + idx+ gDeviceCnt*9],work);
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
				gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
				DeviceDataSys[i].SameDevInf= 4;
				gDeviceCnt++;
				gDeviceCntWord++;
			}
		}
		/*sprintf(work,"%02X",gDeviceCntWord);*/
		LG_Bin2Hex(gDeviceCntWord,2,work);
		memcpy((char *)&PlcSendBuff[5],work,2);
		if(gDeviceCnt > MAX_UR_CNT){
			break;
		}
	}
	if(gDeviceCnt != 0){
		strcpy(&work[1],"uA00");
		ret= LG_SendRecPLCWithBCC(2,(unsigned char *)work,(unsigned char *)work,&Cnt,0);
		if(ret == 0){
/*			if(strncmp((char *)PLCbuf,"\x06u",2) != 0){*/
			if(work[0] != 0x06){
				ret= -1;
			}
		}
		if(ret == 0){
			ret= LG_SendRecPLCWithBCC(2,PlcSendBuff,(unsigned char *)PlcSendBuff,&Cnt,0);
			if(ret == 0){
/*				if(strncmp((char *)PLCbuf,"\x06u",2) != 0){*/
				if(PlcSendBuff[0] != 0x06){
					ret= -1;
				}
			}
		}
		strcpy(&work[1],"uE00");
		if(ret == 0){
			ret= LG_SendRecPLCWithBCC(2,(unsigned char *)work,(unsigned char *)work,&Cnt,0);
			if(ret == 0){
/*				if(strncmp((char *)PLCbuf,"\x06u",2) != 0){*/
				if(work[0] != 0x06){
					ret= -1;
				}
			}
		}
	}
	return(ret);
}
/************************************/
/*	�O���[�v���[�h			        */
/************************************/
int		LG_ReadGroupPLCDev(void)
{
	int		ret;
	int		idx;
	int		i;
	int		WordCnt;
	char	work1[8];

	if(gDeviceCntWord == 0){
		return(0);
	}
	ret= 0;
	WordCnt= gDeviceCntWord;
	/*sprintf(work,"uR0000%02X",WordCnt);*/
	strcpy((char *)&PlcSendBuff[1],"uR0000");
	LG_Bin2Hex(WordCnt,2,work1);
	strcat((char *)&PlcSendBuff[1],work1);
	ret= LG_SendRecPLCWithBCC(2,PlcSendBuff,PlcSendBuff,&idx,0);
	if(ret == OK){
/*		if(strncmp((char *)PlcSendDevData,"\x06u",2) != 0){*/
		if(PlcSendBuff[0] != 0x06){
			ret= -1;
		}
		if(ret == 0){
			for(i = 0; i < gDeviceCntWord; i++){
#ifdef	WIN32
				*gDeviceAddr[i] = (unsigned char)Hex2Bin((char *)&PlcSendBuff[i*4+ 2]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)Hex2Bin((char *)&PlcSendBuff[i*4+ 4]);
#else
				*gDeviceAddr[i] = (unsigned char)Hex2Bin((char *)&PlcSendBuff[i*4+ 4]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)Hex2Bin((char *)&PlcSendBuff[i*4+ 2]);
#endif
			}
			strcpy((char *)&PlcSendBuff[1],"uE00");
			ret= LG_SendRecPLCWithBCC(2,PlcSendBuff,(unsigned char *)PlcSendBuff,&idx,0);
			if(ret == 0){
/*				if(strncmp(work,"\x06u",2) != 0){*/
				if(PlcSendBuff[0] != 0x06){
					ret= -1;
				}
			}
		}
	}
	return(ret);
}
int		LG_RecGroupPLCDev(int PlcType)
{
	int		i;
	int		ret;

	for(i = 1; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].SameDevInf == 4){
			DeviceDataSys[i].SameDevInf= 0;
		}
	}
	LgGetGroopSema();			/* For Monitor */
	while(1){
		ret= LG_SetGroupDevPLC();
		if((ret != 0) || (gDeviceCntWord == 0)){
			break;
		}
		ret= LG_ReadGroupPLCDev();
		if(ret != 0){
			break;
		}
	}
	LgResetGroopSema();
	return(ret);
}
/************************************/
/*	�X���[���[�hfor LG		        */
/************************************/
int	CheckDefLGCommand(char *comm)
{
	int		i;
	int		ret= -1;

	for(i= 0; i < 3; i++){
		if(gstrncmp(comm,(char *)LgComm[i].strData,2) == 0){
			ret= i;
			break;
		}
	}
	return(ret);
}
/*******************************************/
void	LG_PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	int		command;
	int		ret;

	gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;

	command= CheckDefLGCommand(&CommBuff[1]);
	switch(command){
	case 0:			/* uW Commnad */
		if(LgLgCommSeq == 0){
			LgGetGroopSema();			/* For Monitor */
		}
		LgLgCommSeq= 1;
		break;
	case 1:			/* uR Command */
		if(LgLgCommSeq != 2){
			LgLgCommSeq= 2;
		}
		break;
	case 2:			/* uE Command */
		break;
	default:
/*		if(CommBuff[1]= 'j'){
			if(LgCommSeq != 0){
				LgCommSeq= 0;
				ResetGroopSema();
			}
		}
*/
		break;
	}
/*	B_SendPLCPCData();*/	/* PC->PLC->PC */
	if(LgLgCommSeq == 0){
		LgGetGroopSema();			/* For Monitor */
	}
	ret= SendThruePLC(2,*OutCnt,OutBuff,3000);		/* ACK ���M */
	if(ret == 0){		/* OK */
		if(LgLgCommSeq == 0){
			LgResetGroopSema();			/* For Monitor */
		}
		if(command == 2){	/* uE Command */
			if(LgLgCommSeq == 2){
				LgLgCommSeq= 0;
				LgResetGroopSema();
			}
		}
	}else{
		LgLgCommSeq= 0;
		LgResetGroopSema();			/* For Monitor */
	}
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		LG_Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	LG_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(strcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(strcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		LG_CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
void	LG_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= RS_38400;
	*DataBit= RS_DATA8;
	*Parity= RS_NONE;
}
int		CheckDevice_Addr(int bwflag,char *DevName,unsigned int *Address1,unsigned int *Address2)
{
	int		i;
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;
	unsigned int		Max,Min;

	LG_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	Max= 0;
	Min= 99999999;		//070827 999999->99999999
	if(bwflag == 0){	/* Bit */
		for(i= 0; i< PLCByteCnt; i++){
			if(strcmp(ByteTbl->DevName,DevName) == 0){
				if((*Address1 >= ByteTbl->DeviceMin) && (*Address1 <= ByteTbl->DeviceMax)){
					ret= 0;
				}else{
					if((ByteTbl->DeviceMin > *Address1) && (ByteTbl->DeviceMin < Min)){
						Min= ByteTbl->DeviceMin;
					}
					if((ByteTbl->DeviceMax < *Address1) && (ByteTbl->DeviceMax > Max)){
						Max= ByteTbl->DeviceMax;
					}
				}
			}
			ByteTbl++;
		}
	}else{
		for(i= 0; i< PLCWordCnt; i++){
			if(strcmp(WordTbl->DevName,DevName) == 0){
				if((*Address1 >= WordTbl->DeviceMin) && (*Address1 <= WordTbl->DeviceMax)){
					ret= 0;
				}else{
					if((WordTbl->DeviceMin > *Address1) && (WordTbl->DeviceMin < Min)){
						Min= WordTbl->DeviceMin;
					}
					if((WordTbl->DeviceMax < *Address1) && (WordTbl->DeviceMax > Max)){
						Max= WordTbl->DeviceMax;
					}
				}
			}
			WordTbl++;
		}
	}
	*Address1= Max;
	*Address2= Min;
	return(ret);
}
/********************************************/
/*	PLC Protocol Clear						*/
/********************************************/
void	Def_Get_Plc1_Ver(char *name)
{
	strcpy(name,"V1.4M");
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
int	Def_Get_Ms_Sel(void)
{
	return(0x0101);											
}

/****************************** END **********************/
