/*****************************************************************************************/
/*	PLC ����M �v���O��?(AUTONICS)		*/
/*	2003.5.31				*/
/************************************************/
/*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		  */
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
/*	2006.09.25 */
/*      �����͹� ���ø� ������ ���� ver 2.6�� �ϰ� ����	  */
/*  2007.01.30 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����		*/
/*  2007.10.08 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����	 		*/ 
/*****************************************************************************************/

#include	"define.h"
#include	"GpCommon.h"
#include	"PlcCommBuff.h"
#include	"mail.h"
#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include "hook_plcapl.h"

/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V3.3M"
/*****************************************************************************************/



#ifdef	S7_200

#define	MAX_RTY_COUNT	3
#define	MAX_WORDCNT		80

#define PLC_SPEED	RS_9600
#define	PLC_DATA	RS_DATA8
#define PLC_PARITY	RS_EVEN 
#define SendChek   0xE5
#define Endbuff    0x16
#endif




#ifdef	SH_CPU		/* ���� */
/*ksc20040707*/
/****************************************************************/
/*	Station Connect Area										*/
/****************************************************************/
static	int	PlcRecCnt;
static	int	PlcRecCmd;
static	int	GroopSema;			/* Grooping Semafo */
static	unsigned	int	Port_TimeoutCnt;		/* 20060203 */
static	int	Pro_Speed;			/* 20061025ksc */
static	unsigned int Plc_sync_time;				/* 20061025ksc */ 
#endif


#ifdef	SH_CPU
static	int	FrameCnt;
static  int FirstRec;
static	unsigned int gReadFrameIdx;		
static	unsigned int gWriteFrameIdx;
#endif




static	const	DEV_TBL bPLCDeviceTbl[16] = {
	{"I",  0x0081, 1},
	{"Q", 0x0082, 1},
	{"V",  0x0184, 1},
	{"M",  0x0083, 1},
	{"SM",  0x0005, 1},
	{"T",  0x001F, 1},
	{"C",  0x001E, 1},
	{"GB" ,    0,4},

};
static	const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"IW",  0x0081, 1},
	{"QW", 0x0082, 1},
	{"VW",  0x0184, 1},
	{"MW",  0x0083, 1},
	{"SM",  0x0005, 1},   
	{"T",  0x001F, 1},
	{"C",  0x001E, 1},
	{"GW",    0,4},
};


static	const	DATA_FRAME	FrameType[6] = {
	{
		 6, {0x10,0x02,0x00,0x5C,0x5E,0x16,},
	},
	{
		31, {0x68,0x1b,0x1b,0x68,0x02,0x00,0x7c,0x32,0x01,0x00,
			 0x00,0x00,0x00,0x00,0x0E,0x00,0x00,0x04,0x01,0x12,
			 0x0A,0x10,0x04,0x00,0x01,0x00,0x00,0x83,0x00,0x00,
			 0x00,},
	},
	{ 
		22, {0x68,0x1b,0x1b,0x68,0x02,0x00,0x7c,0x32,0x01,0x00,
			 0x00,0x00,0x00,0x00,0x0E,0x00,0x00,0x04,0x01,0x12,
			 0x0A,0x10,},
	},
	{ 
		11, {0x12,0x0A,0x10,0x1F,0x00,0x01,0x00,0x00,0x1F,0x00,
			 0x00,},
	},
	{
		11, {0x12,0x0A,0x10,0x1E,0x00,0x01,0x00,0x00,0x1E,0x00,
			 0x00,},
	},   
	{
		22, {0x68,0x21,0x21,0x68,0x02,0x00,0x7c,0x32,0x01,0x00,
			 0x00,0x00,0x00,0x00,0x0E,0x00,0x06,0x05,0x01,0x12,
			 0x0A,0x10,},
	},
};


/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef  PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= PLC_SPEED;
	*DataBit= PLC_DATA;
	*Parity= PLC_PARITY;
}
/*********************************/
/*	PLC Semafor			         */
/*********************************/
static	void	GetGroopSema(void)
{
	
	unsigned int	NowTime;
	unsigned int	StartTime;

	if(GroopSema == 0){		/* Grooping Sema */
	}else{
		StartTime= B_GetNowTime();
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
			NowTime= B_GetNowTime();
			if((StartTime+ 2000) < NowTime){
				GroopSema= 0;
			}
			B_Delay(10);
		}
	}
	GroopSema++;
}
static	void	ResetGroopSema(void)
{
	GroopSema= 0;
}
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{

	int	ret;
	ret= -1;

	if(*RecCnt >= PLC_BUF_MAX){
		*CommMode = 0;
		PlcRecCnt=0;	
		B_gmemset((char*)RecBuff, 0x00, PLC_BUF_MAX);
	}   

	switch(*CommMode){
	case 0:
		*RecCnt= 0;
		*CommMode = 0;	
		RecBuff[(*RecCnt)++] = data;

		if(RecBuff[0] == SendChek)
		{
			FirstRec=1;
			ret=0;
			return ret;
		}   
		else FirstRec=0;                  
		
		if(data==0x68) *CommMode=1;
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		*CommMode=2;
		PlcRecCnt=0x19+(data-0x15);
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){	
			RecBuff[(*RecCnt)++] = data;
		}
		PlcRecCnt--;
		if(PlcRecCnt <= 0 && data==Endbuff){
			ret=0;	
			*CommMode = 0;
		}
		break;
	}
	return(ret);        
}                        

static	int SetPLCBCC(char *buff,int cnt)
{

	int		i;
	unsigned char bcc;
	
	bcc = 0;
	for(i = 4; i < cnt; i++){
		bcc += buff[i];
	}
	
	buff[cnt] = bcc;
	buff[cnt+1] = Endbuff;
	return(cnt + 2);
    
}	    



/************************************/
/*	PLC Send						*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,unsigned char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		i;
	int		ret;
	int		rty_cnt;
	unsigned char bcc;
	unsigned char bcc1;
	int		SendCnt;
	
	FirstRec=0;
	SendCnt= SetPLCBCC((char *)combuf,*Cnt);
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT; rty_cnt++){
		ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		B_Delay(20);
		if(FirstRec==1)
		{
			ret= C_SendRecPLC(mode,rData,Cnt,rmode,FrameType[0].cnt,(char *)FrameType[0].frame,2000);  /* 20090611 */
		}
		if(ret == 0){
			if(mode <= 1){
			}
			else{
			    bcc1=rData[*Cnt-2];
			    bcc= 0;
				for(i = 4; i < *Cnt-2; i++){
					bcc+=rData[i];
				}
		        if(bcc != bcc1){
					ret= -1;
				}
			}
		}
		if(ret == OK){
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}  
	return(ret);
}
static	int	SendRecPLCWithBCCCont(int mode,unsigned char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		i;
	int		ret;
	unsigned char bcc;
	unsigned char bcc1;
	int		SendCnt;
	
	FirstRec=0;
	SendCnt= SetPLCBCC((char *)combuf,*Cnt);
		ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
		B_Delay(20);
		if(FirstRec==1)
		{
			ret= C_SendRecPLC(mode,rData,Cnt,rmode,FrameType[0].cnt,(char *)FrameType[0].frame,2000);  /* 20090611 */
		}
		if(ret == 0){
			if(mode <= 1){
			}
			else{
				bcc1=rData[*Cnt-2];
				bcc= 0;
				for(i = 4; i < *Cnt-2; i++){
					bcc+=rData[i];
				}
				if(bcc != bcc1){
					ret= -1;
				}
			}
		}
		return(ret);
}
static	int	C_Connection( int *PlcType,int iConnect )
{
	
	int		ret;
	int		Cnt;
 	int		Speed;
	int		DataBit;
	int		Parity;

 
	if((C_Get_Ms_Sel() & 0xff00) == 0){		
		if(iConnect == CH_CH1){		

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
		}else{						

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
		}
#ifdef	WIN32
		while(1){
			if((iConnect & 1) == 0){
				if(SioPCOpenFlag == 0){
					break;
				}
			}else{
				if(SioPLCOpenFlag == 0){
					break;
				}
			}
			B_Delay(10);
		}
#else
  		B_Delay(100);
#endif
	}
	monitorModeFlag= PlcType[4];		/* 20090704 */
 	Cnt=FrameType[1].cnt;  /* 20090611 */
	B_gmemcpy((char*)PlcSendBuff, (char*)FrameType[1].frame,50);
  	ret= SendRecPLCWithBCCCont(2,PlcSendBuff,PlcRecBuff,&Cnt,0);  /* 20090611 */
   	ResetGroopSema();	

	if(ret < 0){
		return(0);
	}
	ret= 1;
	return(ret);
}
/******************************************/
static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif
#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00]; 
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100]; 
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif

}
/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;


	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i,j;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			
		if(Device[0] == 'G'){		
			ret = Address % 16;
			BitAndData = 1;
			for(j = 0; j < ret; j++){
				BitAndData <<= 1;
			}
			ret += sCnt;
			ret = ret / 8 + 1;
			BitRecCnt = ret;
			ret = 1;		
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrncmp(bPLCDeviceTbl[i].Device,Device,2) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = Address;
				pDevice[0]=OffSet/0x100;	
				pDevice[1]=OffSet%0x100;
				ret=0;
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		
			ret = 1;	
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrncmp(wPLCDeviceTbl[i].Device,Device,2) == 0){	
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				*DevAddr = Address;
				pDevice[0]=OffSet/0x100;	
				pDevice[1]=OffSet%0x100;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt,int StationNo)
{
	int		ret,i;
	int     pos, DataNumAddr;
	int		DevAddr,TCAddress;
	char readCnt[2],readAddr[2];

		ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);
		if(ret==0 ) {
			pos = 0;
			B_gmemcpy(combuff+pos, (char*)FrameType[2].frame, FrameType[2].cnt);  /* 20090611 */
			pos += FrameType[2].cnt;  /* 20090611 */
			if(mode==0 && sCnt<2){
				gReadFrameIdx = 1;
			}
			else if(mode==1 && sCnt<2){
				gReadFrameIdx = 4;
			}
			else{
				 gReadFrameIdx = 2;
			}
			readCnt[0]=sCnt/0x100;	
			readCnt[1]=sCnt%0x100;
			TCAddress=Address;
			DataNumAddr=(Address%8)+(sCnt%8);
			if(DataNumAddr>8){
				DataNumAddr=2;
			}
			else DataNumAddr=1;
			
			if(mode>0)Address=Address*8; 
			if(mode==0 && sCnt>1)Address=(Address/8)*8;
			readAddr[0]=Address/0x100;
			readAddr[1]=Address%0x100;
		
			combuff[pos++]=gReadFrameIdx;
			combuff[pos++]=readCnt[0];
			if(gReadFrameIdx==2 && mode>0)combuff[pos++]=readCnt[1]+1;
			else if(gReadFrameIdx==2 && mode==0)combuff[pos++]=(sCnt/8)+DataNumAddr;
			else if(gReadFrameIdx==4)combuff[pos++]=1;
			else combuff[pos++]=readCnt[1];
			combuff[pos++]=0x00;
			combuff[pos++]=pDevice[0];
			combuff[pos++]=pDevice[1];
			combuff[pos++]=0x00;
			combuff[pos++]=readAddr[0];
			combuff[pos++]=readAddr[1];
		
			if(pDevice[1]==0x1F || pDevice[1]==0x1E){
				pos = 0;
				B_gmemcpy(combuff+pos, (char*)FrameType[2].frame, FrameType[2].cnt);  /* 20090611 */
				pos += FrameType[2].cnt;  /* 20090611 */
				pos=pos-3;
				for(i=0;i<sCnt;i++){
					if(pDevice[1]==0x1F){
						B_gmemcpy(combuff+pos, (char*)FrameType[3].frame, FrameType[3].cnt);  /* 20090611 */
						pos += FrameType[3].cnt;  /* 20090611 */
						combuff[pos++]=TCAddress+i;
					}
					else{
						B_gmemcpy(combuff+pos, (char*)FrameType[4].frame, FrameType[4].cnt);  /* 20090611 */
						pos += FrameType[4].cnt;  /* 20090611 */
						combuff[pos++]=TCAddress+i;
					}
					combuff[1]=0x1B+(i*12);
					combuff[2]=0x1B+(i*12);
					combuff[14]=0x0E+(i*12);
					combuff[18]=sCnt;
				}
			}
		}
		FrameCnt=pos;

	return(ret);
}
static	int	BitReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		sCnt;
	int		Cnt,DataFrame,DataOffSet;
	unsigned char	*SaveAddr;
	int		Address;
	int		EndFlag;
	int	CmpBit;
	
	Address= mp->mpar;
	EndFlag= 0;
	while(EndFlag == 0){
			ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext,(int)mp->mbuf[4]);
			Cnt = mp->mext;
			if(ret != 0){	
				ret= -1;	
				return(ret);	
			}
			sCnt= FrameCnt;
			DataFrame=25;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				B_gmemset((char*)rDataFx, 0x00, PLC_BUF_MAX);
				if(SendRecPLCWithBCC(2,(unsigned char *)PlcSendBuff,(unsigned char *)rDataFx,&sCnt,0) == 0){
					CmpBit = 0x01;
					if(Cnt>1)CmpBit <<= Address%8;
					if(rDataFx[22]==0x09){
						DataFrame=25;
						if(rDataFx[24]==0x05)DataOffSet=10;
						else DataOffSet=8;
						for(i = 0; i < Cnt; i++){
							if((rDataFx[DataFrame+(i*DataOffSet)] & 2) == 0){	
								*(unsigned char *)SaveAddr = 0;	
								SaveAddr++;
							}else{						
								*(unsigned char *)SaveAddr = 1;
								SaveAddr++;
							}	
						}
					}
					else{
						for(i = 0; i < Cnt; i++){
							if((rDataFx[DataFrame] & CmpBit) == 0){	
								*(unsigned char *)SaveAddr = 0;	
								SaveAddr++;
							}else{						
								*(unsigned char *)SaveAddr = 1;
								SaveAddr++;
							}	
							if(CmpBit==0x80){
								DataFrame++;
							}
							CmpBit <<= 1;
							if(CmpBit==0x100)CmpBit=1;
						}
					}
					ret = 0;
					EndFlag = 1;
				}else{
					ret = -1;
					EndFlag= 1;
				}					
			}else{
				ret= -1;
				EndFlag= 1;
			}
	}
		return(ret);
}
static	int	WordReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i;
	int		sCnt;
	int		Cnt,dCnt,DataFrame,DataOffSet;
	unsigned char	*SaveAddr;
	int		Address;
	int		EndFlag;
		
	Address= mp->mpar;
	dCnt= mp->mext;	
	EndFlag= 0;
	while(EndFlag==0){
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
		
			ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext,(int)mp->mbuf[4]); 
			Cnt = mp->mext* 2;
			sCnt= FrameCnt;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){

				if(SendRecPLCWithBCC(2,(unsigned char *)PlcSendBuff,(unsigned char *)rDataFx,&sCnt,0) == 0){ 
					
						for(i = 0; i < Cnt/2; i++){
							if(rDataFx[22]==0x09){
								if(rDataFx[24]==0x05){
									DataFrame=28;
									DataOffSet=10;
								}
								else {
									DataFrame=26;
									DataOffSet=8;
								}

#ifdef	SH_CPU					
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[(i*DataOffSet)+DataFrame+1];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[(i*DataOffSet)+DataFrame];
								SaveAddr++;
								
#endif
#ifdef	ARM_CPU
#ifdef	WIN32
								
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[(i*DataOffSet)+DataFrame+1];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[(i*DataOffSet)+DataFrame];
								SaveAddr++;
								
#else
								
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[(i*DataOffSet)+DataFrame];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[(i*DataOffSet)+DataFrame+1];
								SaveAddr++;
								
#endif
#endif
							}

							else{
								DataFrame=25;
#ifdef	SH_CPU				
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i+DataFrame+1];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i+DataFrame];
								SaveAddr++;
							
#endif
#ifdef	ARM_CPU
#ifdef	WIN32
						
							*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i+DataFrame+1];
							SaveAddr++;
							*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i+DataFrame];
							SaveAddr++;
							
#else
							
							*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i+DataFrame];
							SaveAddr++;
							*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i+DataFrame+1];
							SaveAddr++;
							
#endif
#endif
							}
						}
					
					if(dCnt == 0){
						EndFlag= 1;
						break;
					}
					Address += MAX_WORDCNT;
					mp->mpar= Address;
					mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
				}else{
					ret = -1;
					EndFlag= 1;
				}					
			}else{
				ret= 0;
				EndFlag= 1;
			}
		}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;

	GetGroopSema();
	switch(mp->mpec){
	case PLC_BIT:		ret= BitReadProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordReadProc(mp,rDataFx,PlcType);		break;
	}
	ResetGroopSema();
	B_Delay(10);
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/	
static	int	ChangeIntData(char *data,int Cnt,int mode)
{
	int		iData;
	int		i;
	union{
		int		iData;
		char	cData[4];
	}rData;

	B_gmemset((char *)&rData,0,sizeof(rData));
	if(mode == 1){
		for(i= 0; i < Cnt*2 && i < 4; i++){
			rData.cData[3- i]= *data;
			data++;
		}
		iData = rData.iData;
	}else{
		iData = *data;
	}
	return(iData);
}
/****************************/
/* Make Write Device		*/
/****************************/

static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data,int StationNo)
{
	
	int	ret;
	int pos;
	int	DevAddr;
	int ReAddress;
	char readAddr[2];

	pos=0;
	ret = 0;
	if(Cnt==0){ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, Cnt);}

	B_gmemcpy(combuff+pos, (char*)FrameType[5].frame, FrameType[5].cnt);  /* 20090611 */
	pos += FrameType[5].cnt;  /* 20090611 */

	if(mode == 0){
		readAddr[0]=Address/0x100;
		readAddr[1]=Address%0x100;
		combuff[pos++]=0x01;
		combuff[pos++]=0x00;
		combuff[pos++]=0x01;
		combuff[pos++]=0x00;
		combuff[pos++]=pDevice[0];
		combuff[pos++]=pDevice[1];
		combuff[pos++]=0x00;
		combuff[pos++]=readAddr[0];
		combuff[pos++]=readAddr[1];
		combuff[pos++]=0x00;
		combuff[pos++]=0x03;
		combuff[pos++]=0x00;
		combuff[pos++]=0x01;
		combuff[pos++]=*(data+Cnt);
		combuff[pos++]=0x00;

	}else{
		ReAddress=Address*8;
		readAddr[0]=ReAddress/0x100;
		readAddr[1]=ReAddress%0x100;
		combuff[pos++]=0x04;
		combuff[pos++]=0x00;
		combuff[pos++]=0x01;
		combuff[pos++]=0x00;
		combuff[pos++]=pDevice[0];
		combuff[pos++]=pDevice[1];
		combuff[pos++]=0x00;
		combuff[pos++]=readAddr[0];
		combuff[pos++]=readAddr[1];
		combuff[pos++]=0x00;
		combuff[pos++]=0x04;
		combuff[pos++]=0x00;
		combuff[pos++]=0x10;

#ifdef SH_CPU
		combuff[pos++]=*(data+1+(Cnt*2));
		combuff[pos++]=*(data+(Cnt*2));
#endif
#ifdef ARM_CPU
#ifdef WIN32
		combuff[pos++]=*(data+1+(Cnt*2));
		combuff[pos++]=*(data+(Cnt*2));
#else
		combuff[pos++]=*(data+(Cnt*2));
		combuff[pos++]=*(data+1+(Cnt*2));
#endif
#endif
	}
	FrameCnt=pos;	
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
static	int	BitWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,Address;
	int		DeviceCount;
	int		ReCnt;

	ret = 0;
	ReCnt=mp->mext;
	DeviceCount=0;
	Address=mp->mpar;
	GetGroopSema();
	while(ReCnt!=0){
		ret = MakePLCWriteData(0,(char *)mp->mbuf,Address,DeviceCount,(char *)PlcSendBuff,(char *)mp->mptr,(int)mp->mbuf[4]);
		Cnt = FrameCnt; 
		if(ret == 0){
			if(SendRecPLCWithBCC(2,(unsigned char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){
				B_Delay(20);
			}else{
				ret = -1;
			}
		}else if(ret == 1){
			ret= 0;
		}
		ReCnt--;
		Address++;
		DeviceCount++;
	}
	return(ret);
}
static	int	WordWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt,Address;
	int		DeviceCount;
	int		ReCnt;
	
	ret = 0;
	ReCnt=mp->mext;
	DeviceCount=0;
	Address=mp->mpar;
	GetGroopSema();
		while(ReCnt!=0){
			ret = MakePLCWriteData(1,(char *)mp->mbuf,Address,DeviceCount,(char *)PlcSendBuff,(char *)mp->mptr,(int)mp->mbuf[4]);
			if(ret == 0){
				Cnt=FrameCnt;
				if(SendRecPLCWithBCC(2,(unsigned char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){
					B_Delay(20);
				}else{
					ret = -1;
				}
			}else if(ret == 1){	
				ret= 0;
			}
			ReCnt--;
			Address++;
			DeviceCount++;
		}
	return(ret);
}
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	switch(mp->mpec){
	case PLC_BIT:		ret= BitWriteProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordWriteProc(mp,rDataFx,PlcType);		break;
	}
	ResetGroopSema();
	return(ret);
}
static	int	C_GetSendRecTime(void)
{
	return(5);				/* 1ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}


/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	switch(*CommMode){
	case 0:		/* Normal */
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:		/* Thru Mode */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			if((data == EOT) || (data == ETX)){
				*CommMode = 5;
			}
		}else{
			*CommMode = 0;
		}
		break;
	case 5:		/* CRC1 */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			*CommMode = 99;
			ret= 0;
		}else{
			*CommMode = 0;
		}
		break;
	}
	return(ret);
}
/************************************************/
/*	�O��?�v����								*/
/************************************************/
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	return(0);
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if(DeviceDataSys[i].SameDevInf == 0){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
						MyAddress= DeviceDataSys[i].DevAddress;
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Before Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;

	int		StartIdx;

	StartIdx= WordStart;
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
					MyAddress= DeviceDataSys[i].DevAddress;
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Before Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN			   */									
/*	2006.03.31 makebitpatarn �ϰ� ����         */
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/*	2006.03.31 makewordpatarn �ϰ� ����        */							
/***************************************************/
void	MakeWordPatarn(int Start)
{

}
/****************************************/
/*	�O��?�v�쐬			*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Same Device Check */
/*	gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));*/
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	/* �r�b�g�A��?�h�̘A����?�F�b�N���� */
	MakeBitContinue();
	MakeWordContinue(TotalBitCnt);
	/* �r�b�g�A��?�h�̃p??����?�F�b�N���� */
	/* Bit Patarn */
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	/* Word Patarn */
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}

	return(0);
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int	ret;

	ret= 0;
	return(ret);
}
/************************************/
/*	�X��?��?�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	GetGroopSema();
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendThruePLC(2,*OutCnt,OutBuff,3000); /*20090706*/
	ResetGroopSema();

#ifdef	OLDSOURCE
#endif
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
#endif
/*++++++++++++++++++++++++++++++++++++*/
#ifdef PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif


#include  "hook_aplplc.h"
/****************************** END **********************/
