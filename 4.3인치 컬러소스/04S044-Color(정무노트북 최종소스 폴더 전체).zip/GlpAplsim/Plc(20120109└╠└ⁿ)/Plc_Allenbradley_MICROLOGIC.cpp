/*****************************************************************************************/
/*	PLC ����M �v���O��?(AUTONICS)		*/
/*	2003.5.31				*/
/************************************************/
/*	2006.03.31 ���� ó�� ��ƾ �ϰ� ����		  */
/*      �����͹� ���ø� ������ ���� ver 2.5�� �ϰ� ����	  */
/*	2006.09.25 */
/*      �����͹� ���ø� ������ ���� ver 2.6�� �ϰ� ����	  */
/*  2007.01.30 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 3.6�� �ϰ� ����		*/
/*  2007.10.08 		*/
/*      ������ �� ���ø� ������ ���� ������ ���� ver 4.0�� �ϰ� ����	 		*/ 
/*****************************************************************************************/

#include	"define.h"
#include	"GpCommon.h"
#include	"PlcCommBuff.h"
#include	"mail.h"
#ifdef	PLCTYPE_CH1
	#include	"PlcHed.h"
#endif
#ifdef	PLCTYPE_CH2
	#include	"PlcHed_type2.h"
#endif

#include "hook_plcapl.h"

/*****************************************************************************************/
/* PLC1, PLC2 �����Ͻ� ���� ����  */
/*****************************************************************************************/
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
#define	SEL_MS_SERIALSET	0x0101
#define	VERSION_SET	"V3.3M"
/*****************************************************************************************/


#define POLYNORMIAL 0xA001
#define	MAX_RTY_COUNT	3
#define	MAX_WORDCNT		80


#define	PLC_DATA	RS_DATA8
#define PLC_PARITY	RS_NONE 
#define PLC_STOP	RS_STOP01 
#define PLC_FLOW	RS_XONOFF 



#ifdef	SH_CPU		/* ���� */
/*ksc20040707*/
/****************************************************************/
/*	Station Connect Area										*/
/****************************************************************/
static	int	PlcRecCnt;
static	int	PlcRecCmd;
static	int	GroopSema;			/* Grooping Semafo */
static	unsigned	int	Port_TimeoutCnt;		/* 20060203 */
static	int	Pro_Speed;			/* 20061025ksc */
static	unsigned int Plc_sync_time;				/* 20061025ksc */ 
#endif



#ifdef	SH_CPU
static unsigned char TNSW_high;
static unsigned char TNSW_low;
static	char DLEPlus;
static unsigned char DataRecCnt;
static unsigned char CheckDevice;
static unsigned char CheckAddr;
static unsigned char TNSWCheck;
#endif


static	const	DEV_TBL bPLCDeviceTbl[16] = {
	{"O",	0x8200,2},
	{"I",	0x8301,2},
	{"S2",	0x8402,2},
	{"B3",	0x8503,2},
	{"N7",	0x8907,2},
	{"T",	0x8604,2},
	{"C",	0x8705,2},
	{"T4",	0x8604,2},
	{"C5",	0x8705,2},
	{"R6",	0x8806,2},
	{"GB",	0x0000,4},
};
static	const	DEV_TBL	wPLCDeviceTbl[16] = {
	{"O",	0x8200,2},
	{"I",	0x8301,2},
	{"S2",	0x8402,2},
	{"B3",	0x8503,2},
	{"N7",	0x8907,2},
	{"TP",	0x8604,2},
	{"TS",	0x8604,2},
	{"CP",	0x8705,2},
	{"CS",	0x8705,2},
	{"R6",	0x8806,2},
	{"GW",	0x0000,4},
};



/************************************/
/* ��M�v���g�R��					*/
/************************************/
static	int	C_SendRecPLC(int mode,unsigned char *RecData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
#ifdef  PLCTYPE_CH1
	return(B_SendRecPLC(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendRecPLC2(mode,RecData,Cnt,rmode,sCnt,sBuff,TimeOut));
#endif
}
static	int	C_SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
#ifdef	PLCTYPE_CH1
	return(B_SendPC2PLCData(mode,cnt,buff,TimeOut));
#endif
#ifdef	PLCTYPE_CH2
	return(B_SendPC2PLCData2(mode,cnt,buff,TimeOut));
#endif
}
/* (0 & 0x00ff) : Slave,				(1 & 0x00ff) : Master */
/* (0 & 0xff00) : protocol Serial Set,	(1 & 0xff00) : Apl Serial Set */
static	int	C_Get_Ms_Sel(void)
{
	return(SEL_MS_SERIALSET);											
}
/* 20070206 */
static	void	C_GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	*Speed= PLC_SPEED;
	*DataBit= PLC_DATA;
	*Parity= ((PLC_FLOW << 16) |(PLC_STOP << 8) | (PLC_PARITY << 0));		/* 20090527 */	
}
/*********************************/
/*	PLC Semafor			         */
/*********************************/
static	void	GetGroopSema(void)
{
	unsigned int	NowTime;
	unsigned int	StartTime;

	if(GroopSema == 0){		/* Grooping Sema */
	}else{
		StartTime= B_GetNowTime();
		while(1)
		{
			if(GroopSema == 0){		/* Grooping Sema */
				break;
			}
			NowTime= B_GetNowTime();
			if((StartTime+ 2000) < NowTime){
				GroopSema= 0;
			}
			B_Delay(10);
		}
	}
	GroopSema++;
}
static	void	ResetGroopSema(void)
{
	GroopSema= 0;
}
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2003.5.25	                            *
*****************************************************/
static	int	C_PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{

	int	ret;
	ret= -1;
	
	if(*RecCnt >= PLC_BUF_MAX){
		*CommMode = 0;
		*RecCnt = 0;
		B_gmemset((char*)RecBuff, 0x00, PLC_BUF_MAX);
	}
	switch(*CommMode){

	case 0:
		*RecCnt= 0;			
		RecBuff[(*RecCnt)++] = data;
		PlcRecCmd= data;
		if(PlcRecCmd==0x10){
			*CommMode = 1;
		}
		else{
			*CommMode = 0;
		}
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		PlcRecCnt= 12 + DataRecCnt;	
		PlcRecCmd= data;
		if(PlcRecCmd==0x06){
			*CommMode = 2;
		}
		else{
			*CommMode = 0;
		}
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		PlcRecCnt--;
		if(PlcRecCnt <= 0){                    
			if(RecBuff[(*RecCnt-3)]==0x03){
				ret= 0;
			    *CommMode = 0;
			}
			else {
				PlcRecCnt=1;
			}
		}
		if(*RecCnt>13 && RecBuff[11]==0x03 && RecBuff[10]==0x10 && RecBuff[9]==TNSWCheck ){
			ret=0;	
			*CommMode = 0;									
		}
		break;
	}

	
	return(ret);
}
/************************************/
/* ���M�v���g�R��					*/
/************************************/


/*ksc20040707*/
/****************************/
/* Make Check SUM For PLC	*/
/****************************/


static unsigned short crc16(unsigned char *puchMsg, int usDataLen){ 
	int i;
	unsigned short crc, flag;
	crc = 0x0000;
	*puchMsg++;
	*puchMsg++;
	*puchMsg++;
	*puchMsg++;
	usDataLen=usDataLen-5;
	if(usDataLen <= 0){	return(0);}		/* 20090527 */
	while(usDataLen--){
		if(*puchMsg == 0x10 && usDataLen==0){
			*puchMsg++;
		}
		if(*puchMsg == 0x10 && *(puchMsg+1) == 0x10){
			*puchMsg++;
			usDataLen--;
		}
		crc ^= *puchMsg++;
		for (i=0; i<8; i++){
			flag = crc & 0x0001;
			crc >>= 1;
			if(flag) crc ^= POLYNORMIAL;
		}
	}
	return crc;
}


static	int SetPLCBCC(char *buff,int cnt)
{

	unsigned short _crc16;
  
	DataRecCnt = buff[11];
	TNSWCheck=buff[9];
	_crc16 = crc16((unsigned char *)buff, cnt);
	buff[cnt] = (unsigned char)((_crc16>>0) & 0x00ff); 
	buff[cnt+1] = (unsigned char)((_crc16>>8) & 0x00ff); /* write_comm(data, 8);*/
	return(cnt + 2);
    
}	



/************************************/
/*	PLC Send						*/
/************************************/
static	int	SendRecPLCWithBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	unsigned short _crc16;
	unsigned short cal16;
	int		rty_cnt;
	int		SendCnt;
    char rDatax;

	SendCnt= SetPLCBCC((char *)combuf,*Cnt);
	for(rty_cnt= 0; rty_cnt < MAX_RTY_COUNT/*2000*/; rty_cnt++){
		ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
			
		rDatax=rData[9];
		if(ret == 0 && combuf[9] ==rDatax){  /* ���� �����̸鼭 ���� �ڵ尡 �ƴ� ��쿡 crc üũ */
			ret=0;
			cal16= (rData[*Cnt- 1] << 8) + rData[*Cnt- 2];
			_crc16= crc16((unsigned char *)rData,*Cnt-2);
			if(cal16 != _crc16){
				ret= -1;/* -1*/
			}
		}else {
			ret= -1;/* -1*/
			TNSW_low=TNSW_low+4;
			if(TNSW_low==0x10){
				TNSW_low=TNSW_low+4;
			}
			rData[9]=TNSW_low;
			SendCnt= SetPLCBCC((char *)combuf,*Cnt);
		}
		if(ret == OK){
			break;
		}
		if(CommonArea.PcUpDownMode != 0){			/* 060628 */
			break;
		}
	}
	return(ret);
}
static	int	SendRecPLCWithBCCCont(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;
	unsigned short _crc16;
	unsigned short cal16;
	int		SendCnt;

	SendCnt= SetPLCBCC((char *)combuf,*Cnt);
	ret= C_SendRecPLC(mode,rData,Cnt,rmode,SendCnt,(char *)combuf,2000);
	if(ret == 0){
		cal16= (rData[*Cnt- 1] << 8) + rData[*Cnt- 2];
		_crc16= crc16((unsigned char *)rData,*Cnt-2);
		if(cal16 != _crc16){
			ret= -1;/* -1*/
		}
	}
	return(ret);
}



static	int	C_Connection( int *PlcType,int iConnect )
{
	int		ret;
/*ksc20040714*/
	int		Cnt;
	char	buff[32];

	int		Speed;
	int		DataBit;
	int		Parity;
    TNSW_low = TNSW_low+4;
	if(TNSW_low==0x10){
		TNSW_low=TNSW_low+4;
	}
 
	if((C_Get_Ms_Sel() & 0xff00) == 0){		/* Protocol SET */	
		/* ��������??��?�g */
		if(iConnect == CH_CH1){		/* RS-232C */

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PC,RS_INIT,Speed,DataBit,Parity);
		}else{						

			C_GetMonBaudrate(&Speed,&DataBit,&Parity);
			B_RsModeSet(RS_PLC,RS_INIT,Speed,DataBit,Parity);
		}
#ifdef	WIN32
		while(1){
			if((iConnect & 1) == 0){
				if(SioPCOpenFlag == 0){
					break;
				}
			}else{
				if(SioPLCOpenFlag == 0){
					break;
				}
			}
	/*ksc20040714*/
			B_Delay(10);
		}
#else

	/*ksc20040714*/
		B_Delay(100);
#endif
	}
	/* PLC Connect Check *(PlcType+2) ���� ������ �Ѱ� ���� */
	monitorModeFlag= PlcType[4];		/* 20090704 */
	
    
	buff[0]= 0x10;
	buff[1]= 0x06;
	buff[2]= 0x10;
	buff[3]= 0x02;
	buff[4]= 0x01;
    buff[5]= 0x00;
    buff[6]= 0x06;
	buff[7]= 0x00;
	buff[8]= 0x00;/*TNSW_high*/
	buff[9]= TNSW_low;
	buff[10]= 0x03;
	buff[11]= 0x10;
	buff[12]= 0x03;
	Cnt= 13;

	ret= SendRecPLCWithBCCCont(2,buff,PlcRecBuff,&Cnt,0);		


	ResetGroopSema();	

	if(ret < 0){
		return(0);
	}

	/* PLC Connect Check */
	ret= 1;
	return(ret);
}
/******************************************/
static	void	SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
#ifdef PLCTYPE_CH1
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC1_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
#endif
#ifdef	PLCTYPE_CH2
#ifdef	WIN32
	*PLCByteCnt= (int)GpFont[PLC2_DEV_TABLE];		/*  */
	*ByteTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0200];
	*PLCWordCnt= (int)GpFont[PLC2_DEV_TABLE+0x0004];		/*  */
	*WordTbl= (DEV_PC_TBL *)&GpFont[PLC2_DEV_TABLE+0x0A00];
	*PLCIndex= (unsigned char *)&GpFont[PLC2_DEV_TABLE+0x0100];
#else
	*PLCByteCnt= *(int *)PLC2_DEV_TABLE;
	*ByteTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0200);
	*PLCWordCnt= *(int *)(PLC2_DEV_TABLE+0x0004);		/*  */
	*WordTbl= (DEV_PC_TBL *)(PLC2_DEV_TABLE+0x0A00);
	*PLCIndex= (unsigned char *)(PLC2_DEV_TABLE+0x0100);
#endif
#endif

}
/************************************/
/* Get Device Name					*/
/************************************/
static	int	C_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;


	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			B_gmemcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}
	return(ret);
}
/****************************************************/
/*	PLC READ PROC									*/
/****************************************************/
/*	Make PLC ABS ADDRESS							*/
/****************************************************/
static	int	MakePLCDevAddress(int mode, char *pDevice, int Address, int *DevAddr, int sCnt)
{
	int		i,j;
	int		ret;
	int		OffSet;
	char	Device[4];

	ret = -1;
	/* Device Name */
	if(C_GetDevNamePLC(mode,(unsigned char *)pDevice,Device,&i) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		if(Device[0] == 'G'){		/* IN DEVICE */
/*ksc20040713*/
			ret = Address % 16;
			BitAndData = 1;
			for(j = 0; j < ret; j++){
				BitAndData <<= 1;
			}
			ret += sCnt;
			ret = ret / 8 + 1;
			BitRecCnt = ret;
/*ksc20040713*/
			ret = 1;		/* GB */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(bPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrncmp(bPLCDeviceTbl[i].Device,Device,2) == 0){
					DeviceFlag= bPLCDeviceTbl[i].flag;
					OffSet= bPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				CheckDevice=OffSet/0x100;
				pDevice[0]=OffSet/0x100;	
				pDevice[1]=OffSet%0x100;
				ret=0;
		
			}else{
				ret= -1;
			}
		}
	}else{
		if(Device[0] == 'G'){		/* IN DEVICE */
			ret = 1;		/* GD */
		}else{
			DeviceFlag= -1;
			for(i = 0; i < 16; i++){
				if(wPLCDeviceTbl[i].Device[0] == 0){
					break;
				}
				if(B_gstrncmp(wPLCDeviceTbl[i].Device,Device,2) == 0){	
					DeviceFlag= wPLCDeviceTbl[i].flag;
					OffSet= wPLCDeviceTbl[i].StartAddr;
					break;
				}
			}
			if(DeviceFlag > 0){
				CheckDevice=Device[1];
				pDevice[0]=OffSet/0x100;	
				pDevice[1]=OffSet%0x100;
				ret = 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
/****************************/
/* Make Read Device			*/
/****************************/
/* �۽� ������ ���� */
static	int	MakePLCReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt,int StationNo)
{
	int		ret;
	int		DevAddr,MonitorBit;

	
	
	TNSW_low = TNSW_low+4;
	if(TNSW_low==0x10){
		TNSW_low=TNSW_low+4;
	}
	ret= MakePLCDevAddress(mode, pDevice, Address, &DevAddr, sCnt);

		DevAddr	=Address/0x10;
		MonitorBit=(Address%0x10)+sCnt ;
		if(ret==0) {
			DLEPlus=0;
			combuff[0]= 0x10;
			combuff[1]= 0x06;
			combuff[2]= 0x10;
			combuff[3]= 0x02;
			combuff[4]= 0x01;
		    combuff[5]= 0x00;
			combuff[6]= 0x0F;
			combuff[7]= 0x00;
			combuff[8]= 0x00;/*TNSW_high*/
			combuff[9]= TNSW_low;
			combuff[10]= (char)-94;			
			switch(pDevice[1]){
			case 0x04 :
				combuff[11]=sCnt * 0x06;
			break;
			case 0x05 : 
				combuff[11]=sCnt * 0x06;
			break;
			default :
				if(mode==0){
					if(MonitorBit>16) 
						combuff[11]=0x04;  /*bit*/
					else combuff[11]=0x02;
				}
				else {
					combuff[11]= sCnt * 0x02;
					if(combuff[11]==0x10){
						combuff[12]=0x10;
						DLEPlus++;
					}
				}
			break;
			}
			combuff[12+DLEPlus]= pDevice[1];
			combuff[13+DLEPlus]= pDevice[0];
			if(mode==0){
				switch(pDevice[1]){
				case 0x04 :
					combuff[14+DLEPlus]=Address;
					break;
				case 0x05 : 
					combuff[14+DLEPlus]=Address;
					break;
				default :
					combuff[14+DLEPlus]=DevAddr;
				break;
				}
			}
			else combuff[14+DLEPlus]= Address;
			if(combuff[14+DLEPlus]==0x10){
				combuff[15+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[15+DLEPlus]= 0x00;
			combuff[16+DLEPlus]= 0x10;
			combuff[17+DLEPlus]= 0x03;
		}
	return(ret);
}
/************************************/
/* PLC Read							*/
/************************************/
static	int	BitReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		i,j,k,CmpbitUp;
	int		sCnt,Tempj;
	int		Cnt,bitCnt,MonitorPreCnt,MonitorAftCnt;
	unsigned char	*SaveAddr;
	int		Address;
	int		ValAddress,ValAddressAft;
	int		EndFlag;

	int		CmpBit;
	GetGroopSema();
	Address= mp->mpar;
/*	dCnt= mp->mext; */	
/*	ret= B_GetDevNamePLCAddr(mp->mpec,mp->mbuf,Device,&DevInfo,&Address);*/
	EndFlag= 0;
		while(EndFlag == 0){
			ret = MakePLCReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext,(int)mp->mbuf[4]);
			Cnt = mp->mext;
			if(ret != 0){	
				ret= -1;	
				return(ret);	
			}
			sCnt= 18+DLEPlus;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){
				if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&sCnt,0) == 0){;
					CmpBit = 1;
					bitCnt=Address%0x10;
					MonitorPreCnt=0x10-bitCnt;									
					MonitorAftCnt=Cnt-MonitorPreCnt;						
														
					for(j=10; j<sCnt; j++){
						if(rDataFx[j]==0x10){ 
							Tempj=j;
							if(rDataFx[j+1]!=0x03){
								for(k=Tempj; k<sCnt; k++){
									rDataFx[k+1]=rDataFx[k+2];
								}
							}
						}
					}
					
					ValAddress=rDataFx[10]+(rDataFx[11]*0x100);	
					if(MonitorAftCnt>0)ValAddressAft=rDataFx[12]+(rDataFx[13]*0x100);  
					for(CmpbitUp=0 ;CmpbitUp<bitCnt;CmpbitUp++){
						CmpBit <<= 1;
					}
				
					if(MonitorAftCnt>0){
						for(i=0;i<MonitorPreCnt;i++){
							if((ValAddress & CmpBit) == 0){	
								*(unsigned char *)SaveAddr = 0;	
								SaveAddr++;
							}else{						
								*(unsigned char *)SaveAddr = 1;
								SaveAddr++;
							}
							CmpBit <<= 1;
						}
						CmpBit=1;
						for(i=0;i<MonitorAftCnt;i++){
							if((ValAddressAft & CmpBit) == 0){	
								*(unsigned char *)SaveAddr = 0;	
								SaveAddr++;
							}else{						
								*(unsigned char *)SaveAddr = 1;
								SaveAddr++;
							}
							CmpBit <<= 1;
						}
					} 
					else{
						for(i = 0; i < Cnt; i++){
							if(CheckDevice==0x86 || CheckDevice==0x87 ){					/*TDN, CDN*/
							  if((rDataFx[11 + (i*6)] & 0x20) == 0){	
									*(unsigned char *)SaveAddr = 0;	
									SaveAddr++;
							  }else{						
									*(unsigned char *)SaveAddr = 1;
									SaveAddr++;
								}
							} 
							else{
								if((ValAddress & CmpBit) == 0){	
									*(unsigned char *)SaveAddr = 0;	
									SaveAddr++;
								}else{						
									*(unsigned char *)SaveAddr = 1;
									SaveAddr++;
								}
								CmpBit <<= 1;
							}
						}
					}
					ret = 0;
					EndFlag = 1;
				}else{
					ret = -1;
					EndFlag= 1;
				}					
			}else{
				ret= -1;
				EndFlag= 1;
			}
	}
	return(ret);
}
static	int	WordReadProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
int		ret;
	int		i,j,k;
	int		sCnt,Tempj;
	int		Cnt,dCnt;
	unsigned char	*SaveAddr;
	int		Address;
	int		EndFlag;
	
	GetGroopSema();
	Address= mp->mpar;
	dCnt= mp->mext;	
	EndFlag= 0;
		while(EndFlag == 0){
			if(dCnt > MAX_WORDCNT){
				dCnt -= MAX_WORDCNT;
				mp->mext= MAX_WORDCNT;
			}else{
				mp->mext= dCnt;
				dCnt = 0;
			}
		
			ret = MakePLCReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PlcSendBuff,mp->mext,(int)mp->mbuf[4]); 
			Cnt = mp->mext* 2;
			sCnt= 18+DLEPlus;
			SaveAddr = (unsigned char *)mp->mptr;
			if(ret == 0){

				if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,(unsigned char *)rDataFx,&sCnt,0) == 0){ 
					if(PlcSendBuff[9] == rDataFx[9]){
						for(j=10; j<sCnt; j++){
							if(rDataFx[j]==0x10){ 
								Tempj=j;
								if(rDataFx[j+1]!=0x03){	
									for(k=Tempj; k<sCnt; k++){
										rDataFx[k+1]=rDataFx[k+2];
									}
								}
							}
						}
						for(i = 0; i < Cnt/2; i++){
#ifdef	SH_CPU
							if(PlcSendBuff[12]==0x04 || PlcSendBuff[12]==0x05){
								if(CheckDevice==0x50){
									*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*6+14];
									SaveAddr++;
									*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*6+14+1];
									SaveAddr++;
								}
								else{
									*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*6+12];
									SaveAddr++;
									*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*6+12+1];
									SaveAddr++;
								}
							}
							else {
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+10];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+10+1];
								SaveAddr++;
							}
#endif
#ifdef	ARM_CPU
#ifdef	WIN32
							if(PlcSendBuff[12]==0x04 || PlcSendBuff[12]==0x05){
								if(CheckDevice==0x50){
									*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*6+14];
									SaveAddr++;
									*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*6+14+1];
									SaveAddr++;
								}
								else{
									*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*6+12];
									SaveAddr++;
									*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*6+12+1];
									SaveAddr++;
								}
							}
							else {
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+10];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+10+1];
								SaveAddr++;
							}
#else
							if(PlcSendBuff[12]==0x04 || PlcSendBuff[12]==0x05){
								if(CheckDevice==0x50){
									*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*6+14+1];
									SaveAddr++;
									*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*6+14];
									SaveAddr++;
								}
								else{
									*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*6+12+1];
									SaveAddr++;
									*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*6+12];
									SaveAddr++;
								}
							}
							else {
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+10+1];
								SaveAddr++;
								*(unsigned char *)SaveAddr= (unsigned char)rDataFx[i*2+10];
								SaveAddr++;
							}
#endif
#endif
						}
					}
					if(dCnt == 0){
						EndFlag= 1;
						break;
					}
					Address += MAX_WORDCNT;
					mp->mpar= Address;
					mp->mptr= (void *)((char *)mp->mptr + MAX_WORDCNT*2);
				}else{
					ret = -1;
					EndFlag= 1;
				}					
			}else{
				ret= 0;
				EndFlag= 1;
			}
		}
	return(ret);
}
static	int	C_PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	switch(mp->mpec){
	case PLC_BIT:		ret= BitReadProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordReadProc(mp,rDataFx,PlcType);		break;
	}	
	ResetGroopSema();
	return(ret);
}
/********************************************************/
/*	PLC Write Proc										*/
/********************************************************/
static	int	ChangeIntData(char *data,int Cnt,int mode)
{
	int		iData;
	int		i;
	union{
		int		iData;
		char	cData[4];
	}rData;

	B_gmemset((char *)&rData,0,sizeof(rData));
	if(mode == 1){
		for(i= 0; i < Cnt*2 && i < 4; i++){
			rData.cData[3- i]= *data;
			data++;
		}
		iData = rData.iData;
	}else{
		iData = *data;
	}
	return(iData);
}
/****************************/
/* Make Write Device		*/
/****************************/
static	int	MakePLCWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data,int StationNo)
{
	
	int		ret,Shiftdata,TempData_1,TempData_2;
  
	TNSW_low=TNSW_low+4;
	if(TNSW_low==0x10){
	   TNSW_low=TNSW_low+4;
	 }
	ret = 0;
	CheckAddr = pDevice[0];
	DLEPlus=0;

	if(mode == 0){	/* Bit */
		TempData_1=1;
		TempData_2=*data;
		combuff[0]= 0x10;
		combuff[1]= 0x06;
		combuff[2]= 0x10;
		combuff[3]= 0x02;
		combuff[4]= 0x01;
		combuff[5]= 0x00;
		combuff[6]= 0x0F;
		combuff[7]= 0x00;
		combuff[8]= 0x00;/*TNSW_high*/
		combuff[9]= TNSW_low;
		combuff[10]= (char)-85;/*0xAB*/
		combuff[11]= 0x02;
		switch(CheckAddr){
		case 0x14 :
			combuff[12]=0x00;                 /*O*/
			combuff[13]=(char)-126;/*0x82*/
		break;
		case 0x10 :
			combuff[12]=0x01;                 /*I*/
			combuff[13]=(char)-125;/*0x83*/
		break;
		case 0x20 :
			combuff[12]=0x02;                 /*S2*/
			combuff[13]=(char)-124;/*0x83*/
		break;
		case 0x18 :
			combuff[12]=0x03;                 /*B3*/
			combuff[13]=(char)-123;/*0x85*/
		break;
	
		case 0x32 :
			combuff[12]=0x04;                 /*T4*/
			combuff[13]=(char)-122;/*0x85*/
			break;
	
		case 0x50 :
		combuff[12]=0x05;                 /*C5*/
		combuff[13]=(char)-121;/*0x85*/
		break;
		}

		combuff[14]=Address/0x10;  
		Shiftdata =Address-(0x10*combuff[14]);
		if (combuff[13]== (char)-122 || combuff[13]== (char)-121){
			combuff[14]=Address;
		}
		if(combuff[14]==0x10){
			combuff[15]=0x10;
			DLEPlus++;
		}
		combuff[15+DLEPlus]=0x00; 
		TempData_1<<= Shiftdata;               /* bit device location*/ 
		TempData_2<<= Shiftdata;               /* bit device On, Off status */ 
#ifdef SH_CPU
		if (combuff[13]== (char)-122 || combuff[13]== (char)-121){
			combuff[16+DLEPlus]=0x00;
			combuff[17+DLEPlus]=0x20;
			combuff[18+DLEPlus]=0x00;
			combuff[19+DLEPlus]=*(data+Cnt) * 0x20;
		}
		else{
			combuff[16+DLEPlus]=TempData_1%0x100;
			if(combuff[16+DLEPlus]==0x10){
				combuff[17+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[17+DLEPlus]=TempData_1/0x100;
			if(combuff[17+DLEPlus]==0x10){
				combuff[18+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[18+DLEPlus]=TempData_2%0x100;
			if(combuff[18+DLEPlus]==0x10){
				combuff[19+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[19+DLEPlus]=TempData_2/0x100;
			if(combuff[19+DLEPlus]==0x10){
				combuff[20+DLEPlus]=0x10;
				DLEPlus++;
			}
		}
#endif
#ifdef ARM_CPU
#ifdef WIN32
		if (combuff[13]== (char)-122 || combuff[13]== (char)-121){
			combuff[16+DLEPlus]=0x00;
			combuff[17+DLEPlus]=0x20;
			combuff[18+DLEPlus]=0x00;
			combuff[19+DLEPlus]=*(data+Cnt) * 0x20;
		}
		else{
			combuff[16+DLEPlus]=TempData_1%0x100;
			if(combuff[16+DLEPlus]==0x10){
				combuff[17+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[17+DLEPlus]=TempData_1/0x100;
			if(combuff[17+DLEPlus]==0x10){
				combuff[18+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[18+DLEPlus]=TempData_2%0x100;
			if(combuff[18+DLEPlus]==0x10){
				combuff[19+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[19+DLEPlus]=TempData_2/0x100;
			if(combuff[19+DLEPlus]==0x10){
				combuff[20+DLEPlus]=0x10;
				DLEPlus++;
			}
		}
#else 
		if (combuff[13]== (char)-122 || combuff[13]== (char)-121){
			combuff[16+DLEPlus]=0x00;
			combuff[17+DLEPlus]=0x20;
			combuff[18+DLEPlus]=0x00;
			combuff[19+DLEPlus]=*(data+Cnt) * 0x20;
		}
		else{
			combuff[16+DLEPlus]=TempData_1%0x100;
			if(combuff[16+DLEPlus]==0x10){
				combuff[17+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[17+DLEPlus]=TempData_1/0x100;
			if(combuff[17+DLEPlus]==0x10){
				combuff[18+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[18+DLEPlus]=TempData_2%0x100;
			if(combuff[18+DLEPlus]==0x10){
				combuff[19+DLEPlus]=0x10;
				DLEPlus++;
			}
			combuff[19+DLEPlus]=TempData_2/0x100;
			if(combuff[19+DLEPlus]==0x10){
				combuff[20+DLEPlus]=0x10;
				DLEPlus++;
			}
		}
#endif
#endif
		combuff[20+DLEPlus]= 0x10;
		combuff[21+DLEPlus]= 0x03;
		
	}else{								/* Word */
		combuff[0]= 0x10;
		combuff[1]= 0x06;
		combuff[2]= 0x10;
		combuff[3]= 0x02;
		combuff[4]= 0x01;
		combuff[5]= 0x00;
		combuff[6]= 0x0F;
		combuff[7]= 0x00;
		combuff[8]= 0x00;/*TNSW_high*/
		combuff[9]= TNSW_low;
		combuff[10]= (char)-86;/*0xAA*/
		switch(CheckAddr){
		case 0x90 :
			/*S2 write*/ 
			combuff[11]= 0x02;
			combuff[12]= 0x02;
			combuff[13]= (char)-124;/*0x84*/
			combuff[14]= Address;
            combuff[15]= 0x00;
		break;
		case 0xB1 :
			/*B3 write*/ 
			combuff[11]= 0x02;
			combuff[12]= 0x03;
			combuff[13]= (char)-123;/*0x85*/
			combuff[14]= Address;
            combuff[15]= 0x00;
			
		break;
		case 0xC0 :
			 /*N7 write*/ 
			combuff[11]= 0x02;
			combuff[12]= 0x07;
			combuff[13]= (char)-119;/*0x89*/
			combuff[14]= Address;
            combuff[15]= 0x00;
		
		break;
		case 0xAA :
			 /*T4SV write*/  
			combuff[11]= 0x02;
			combuff[12]= 0x04;
			combuff[13]= (char)-122/*0x86*/;
			combuff[14]= Address;
            combuff[15]= 0x01;
		break;
		case 0xA2 :
		  /*T4PV write*/  
			combuff[11]= 0x02;
			combuff[12]= 0x04;
			combuff[13]= (char)-122/*0x86*/;;
			combuff[14]= Address;
            combuff[15]= 0x02;
		break;
		case 0xB8 :
			 /*C5SV write*/  
			combuff[11]= 0x02;
			combuff[12]= 0x05;
			combuff[13]= (char)-121/*0x87*/;;
			combuff[14]= Address;
            combuff[15]= 0x01;
		break;
		case 0xB0 :
			  /*C5PV write*/  
			combuff[11]= 0x02;
			combuff[12]= 0x05;
			combuff[13]= (char)-121/*0x87*/;
			combuff[14]= Address;
            combuff[15]= 0x02;
		break;
		}
		if(combuff[14]==0x10){
			combuff[16]=combuff[15];
			combuff[15]= 0x10;
			DLEPlus++;
		}
#ifdef SH_CPU
		combuff[16+DLEPlus]= *(data+(Cnt*2));
		if(combuff[16+DLEPlus]==0x10){
			combuff[17+DLEPlus]=0x10;
			DLEPlus++;
		}
		combuff[17+DLEPlus]= *(data+1+(Cnt*2));
		if(combuff[17+DLEPlus]==0x10){
			combuff[18+DLEPlus]=0x10;
			DLEPlus++;
		}
#endif
#ifdef ARM_CPU
#ifdef WIN32
		combuff[16+DLEPlus]= *(data+(Cnt*2));
		if(combuff[16+DLEPlus]==0x10){
			combuff[17+DLEPlus]=0x10;
			DLEPlus++;
		}
		combuff[17+DLEPlus]= *(data+1+(Cnt*2));
		if(combuff[17+DLEPlus]==0x10){
			combuff[18+DLEPlus]=0x10;
			DLEPlus++;
		}
#else
		combuff[16+DLEPlus]= *(data+1+(Cnt*2));
		if(combuff[16+DLEPlus]==0x10){
			combuff[17+DLEPlus]=0x10;
			DLEPlus++;
		}
		combuff[17+DLEPlus]= *(data+(Cnt*2));
		if(combuff[17+DLEPlus]==0x10){
			combuff[18+DLEPlus]=0x10;
			DLEPlus++;
		}
#endif
#endif
		combuff[18+DLEPlus]= 0x10;
		combuff[19+DLEPlus]= 0x03;
	}
	return(ret);
}
/************************************/
/* PLC Write						*/
/************************************/
static	int	BitWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;
	int		ReCnt;
	int     Address,DeviceCount;
	
	ret = 0;
	ReCnt=mp->mext;
	DeviceCount=0;
	Address= mp->mpar;
	GetGroopSema();
	while(ReCnt!=0){
		ret = MakePLCWriteData(0,(char *)mp->mbuf,Address,DeviceCount,(char *)PlcSendBuff,(char *)mp->mptr,(int)mp->mbuf[4]);
		Cnt = 22+DLEPlus;
		if(ret == 0){
		 	if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){
			}else{
				ret = -1;
			}
		}else if(ret == 1){		/* ����Address */
			ret= 0;
		}
		ReCnt--;
		Address++;
		DeviceCount++;
	}
	return(ret);
}
static	int	WordWriteProc(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	int		Cnt;
	int		ReCnt;
	int     Address,DeviceCount;
	ret = 0;

	ReCnt=mp->mext;
	DeviceCount=0;
	Address= mp->mpar;
	GetGroopSema();
		while(ReCnt!=0){
			ret = MakePLCWriteData(1,(char *)mp->mbuf,Address,DeviceCount,(char *)PlcSendBuff,(char *)mp->mptr,(int)mp->mbuf[4]);
			Cnt=20 + DLEPlus;
			if(ret == 0){
				if(SendRecPLCWithBCC(2,(char *)PlcSendBuff,rDataFx,&Cnt,0) == 0){}
				else{
					ret = -1;
				}
			}else if(ret == 1){		/* ����Address */
				ret= 0;
			}
			ReCnt--;
			Address++;
			DeviceCount++;
		}

	return(ret);
}
static	int	C_PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int		ret;
	switch(mp->mpec){
	case PLC_BIT:		ret= BitWriteProc(mp,rDataFx,PlcType);		break;
	case PLC_WORD:		ret= WordWriteProc(mp,rDataFx,PlcType);		break;
	}
	ResetGroopSema();
	return(ret);
}
static	int	C_GetSendRecTime(void)
{
	return(5);				/* 1ms */
}
static	void	C_Get_Plc_Ver(char *name)
{
	B_gstrcpy(name,VERSION_SET);
}


/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
#ifdef	PLCTYPE_CH1
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC1�̏���									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc1_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
int	GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	return(C_GetDevNamePLC(bFlag,src,obj,DevInfo));
}
int	GetDevMaxPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMax;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinPLC(int bFlag,int idx)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[idx] != 0xff){
			ret= ByteTbl[PLCIndex[idx]].DeviceMin;
		}
	}else{
		if(PLCIndex[idx] != 0xff){
			ret= WordTbl[PLCIndex[idx]].DeviceMin;
		}
	}
	return(ret);
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PLCPCDownThrue(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int	ret;

	ret = -1;
	switch(*CommMode){
	case 0:		/* Normal */
		switch(data){
		case STX:
		case ENQ:
		case ACK:
		case NAK:
			*CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:		/* Thru Mode */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			if((data == EOT) || (data == ETX)){
				*CommMode = 5;
			}
		}else{
			*CommMode = 0;
		}
		break;
	case 5:		/* CRC1 */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			*CommMode = 99;
			ret= 0;
		}else{
			*CommMode = 0;
		}
		break;
	}
	return(ret);
}
/************************************************/
/*	�O��?�v����								*/
/************************************************/
int	PlcMakeDeviceAddr(int mode, char *DevName, int DevAddress, char *work)
{
	return(0);
}
/****************************************/
/*	Bit Continue�쐬					*/
/****************************************/
void	MakeBitContinue(void)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/

	/* Continue DEVICE(Bit) check */
	for(i = 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag != 0){
			break;
		}
		if(i > 0){
			if(DeviceDataSys[i].SameDevInf == 0){
				for(j= 0; j < i; j++){
					if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
						(DeviceDataSys[j].Order == -1) &&
						(DeviceDataSys[j].DevName[0] != 0x7f) &&
						(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){	/* same Device Name */
						Address= DeviceDataSys[j].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
						MyAddress= DeviceDataSys[i].DevAddress;
/*						ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
						if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
							DeviceDataSys[j].Order= i+1;
							DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
							DeviceDataSys[i].Continus= j+ 1;	/* Before Device */
							k= j;
							while(1){
								if(DeviceDataSys[k].SameDevInf == 0){
									DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
									break;
								}
								k= DeviceDataSys[k].Continus- 1;
								if(k < 0){
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}
/****************************************/
/*	Word Continue�쐬					*/
/****************************************/
void	MakeWordContinue(int WordStart)
{
	int		i,j,k;
	int		Address;
	int		MyAddress;
/*	int		DevInfo;*/
/*	char	Device[4];*/
	int		StartIdx;

	StartIdx= WordStart;
	/* Continue DEVICE(Word) check */
	for(i= StartIdx+ 1; i < DeviceCntSys; i++){	/* WORD Start */
		if(DeviceDataSys[i].SameDevInf == 0){
			for(j= StartIdx; j < i; j++){
				if(((DeviceDataSys[j].SameDevInf == 0) || (DeviceDataSys[j].SameDevInf == 2)) && 
					(DeviceDataSys[j].Order == -1) &&
					(DeviceDataSys[j].DevName[0] != (unsigned char)0xef) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0])){		/* same Device Name */
					Address= DeviceDataSys[j].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[j].DevFlag,DeviceDataSys[j].DevName,Device,&DevInfo,&Address);*/
					MyAddress= DeviceDataSys[i].DevAddress;
/*					ret= B_GetDevNamePLCAddr(DeviceDataSys[i].DevFlag,DeviceDataSys[i].DevName,Device,&DevInfo,&MyAddress);*/
					if((Address+ DeviceDataSys[j].DevCnt) == MyAddress){
						DeviceDataSys[j].Order= i+1;
						DeviceDataSys[i].SameDevInf= 2;		/* Next Device */
						DeviceDataSys[i].Continus= j+ 1;	/* Before Device */
						k= j;
						while(1){
							if(DeviceDataSys[k].SameDevInf == 0){
								DeviceDataSys[k].Continus += DeviceDataSys[i].DevCnt;
								break;
							}
							k= DeviceDataSys[k].Continus- 1;
							if(k < 0){
								break;
							}
						}
						break;
					}
				}
			}
		}
	}
}
/***************************************************/
/*	BIT GROUP-PATARN			   */									
/*	2006.03.31 makebitpatarn �ϰ� ����         */
/***************************************************/
void	MakeBitPatarn(int Bit_Cnt)
{

}
/***************************************************/
/*	WORD GROUP-PATARN			   */
/*	2006.03.31 makewordpatarn �ϰ� ����        */							
/***************************************************/
void	MakeWordPatarn(int Start)
{

}
/****************************************/
/*	�O��?�v�쐬			*/
/****************************************/
int		MakeGroupDevPLC(int PlcType)
{
	int		i,j;
	int		BitCnt;
	int		WordCnt;
	int		TotalBitCnt;
	int		TotalWordCnt;

	/* Same Device Check */
/*	gmemset((char *)PlcSendBuff, 0, sizeof(PlcSendBuff));*/
	DeviceDataSys[0].SameDevInf= 0;
	DeviceDataSys[0].Patarn= 0;
	DeviceDataSys[0].Continus= 0;
	DeviceDataSys[0].Order= -1;
	BitCnt= 0;
	WordCnt= 0;
	TotalBitCnt= 0;
	TotalWordCnt= 0;
	if(DeviceDataSys[0].DevFlag == 0){
		BitCnt++;
		TotalBitCnt++;
	}else{
		WordCnt++;
		TotalWordCnt++;
	}
	if(DeviceDataSys[0].DevName[0] == 0){
		DeviceDataSys[0].SameDevInf= -1;
	}
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		DeviceDataSys[i].Patarn= 0;
		DeviceDataSys[i].Continus= 0;
		DeviceDataSys[i].Order= -1;
		if(DeviceDataSys[i].DevName[0] != 0){
			for(j = 0; j < i; j++){
				if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
					(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
					(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
					(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) ){
					break;
				}
			}
			if(j != i){		/* Same Device */
				DeviceDataSys[i].SameDevInf= 1;
				DeviceDataSys[i].Order= j+ 1;
			}else{
				if(DeviceDataSys[i].DevFlag == 0){
					BitCnt++;
				}else{
					WordCnt++;
				}
			}
		}else{
			DeviceDataSys[i].SameDevInf= -1;
		}
		/* Total Bit,Word Count */
		if(DeviceDataSys[i].DevFlag == 0){
			TotalBitCnt++;
		}else{
			TotalWordCnt++;
		}
	}
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	/*Word Device Set*/
	gDeviceCnt= 0;
	/* �r�b�g�A��?�h�̘A����?�F�b�N���� */
	MakeBitContinue();
	MakeWordContinue(TotalBitCnt);
	/* �r�b�g�A��?�h�̃p??����?�F�b�N���� */
	/* Bit Patarn */
	if(BitCnt > 0){
		MakeBitPatarn(TotalBitCnt);
	}
	/* Word Patarn */
	if(WordCnt > 0){
		MakeWordPatarn(TotalBitCnt);
	}

	return(0);
}
/************************************/
/*	�O��?�v��?�h			        */
/************************************/
int		RecGroupPLCDev(int PlcType)
{
	int	ret;

	ret= 0;
	return(ret);
}
/************************************/
/*	�X��?��?�hfor FX		        */
/************************************/
/*******************************************/
void	PLCFxThruProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	GetGroopSema();
	B_gmemcpy(OutBuff,CommBuff,*RecCommCnt);
	*OutCnt= *RecCommCnt;
	B_SendThruePLC(2,*OutCnt,OutBuff,3000); /*20090706*/
	ResetGroopSema();

#ifdef	OLDSOURCE
#endif
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(B_gstrcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(B_gstrcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	Check Device Address 							*/
/****************************************************/
int		CheckPLC_Addr(int bwflag,char *DevName,int *Address1,int *plctype)
{
	int		ret;

	ret= -1;
	return(ret);
}
#endif
/*++++++++++++++++++++++++++++++++++++*/
#ifdef PLCTYPE_CH2
/*++++++++++++++++++++++++++++++++++++++++++++++*/
/* PLC2 �֐�									*/
/*++++++++++++++++++++++++++++++++++++++++++++++*/
int	Connection2(int *PlcType,int iConnect)
{
	return(C_Connection(PlcType,iConnect));
}
int	PlcReadProc2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	return(C_PlcReadProc(data,CommMode,RecCnt,RecBuff));
}
int	PLCCommRead2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommRead(mp,rDataFx,PlcType));
}
int	PLCCommWrite2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	return(C_PLCCommWrite(mp,rDataFx,PlcType));
}
int	GetSendRecTime2(void)
{
	return(C_GetSendRecTime());
}
void	Get_Plc2_Ver(char *name)
{
	C_Get_Plc_Ver(name);
}
int	Get_Ms_Sel2(void)
{
	return(C_Get_Ms_Sel());
}
/* 20070206 */
void	GetMonBaudrate2(int *Speed,int *DataBit,int *Parity)
{
	C_GetMonBaudrate(Speed,DataBit,Parity);
}
#endif


#include  "hook_aplplc.h"
/****************************** END **********************/
