/********************************************************************************/
/* �� �� �� : GpNumericInputTask.cpp											*/
/* ��    �� : NumericInputTask													*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"

/********************************************************************************/
/* �� �� �� : DrawNumericInput_Task												*/
/* ��    �� : NumericInput ������ �ص��Ͽ� ȭ�鿡 ���						    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 30�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetNumericInput_Func(int iDispOrder)
{
	_NUMERIC_INPUT_EVENT_TBL* NumericInputEventTbl;

	NumericInputEventTbl= (_NUMERIC_INPUT_EVENT_TBL*)TakeMemory(sizeof(_NUMERIC_INPUT_EVENT_TBL));
	DrawNumericInput_Func(0,NumericInputEventTbl,iDispOrder);
	FreeMail((char *)NumericInputEventTbl);
}
int	DrawNumericInput_Func(int mode,_NUMERIC_INPUT_EVENT_TBL* NumericInputEventTbl,int iDispOrder)
{
	int					iOffset;
/*	unsigned int		iTagSizeOf;*/
//	unsigned int		iTemp;
	unsigned char *buffer;
	int		iUser_id;
/*
	_NUMERIC_INPUT_EVENT_TBL*	 NumericInputEventTbl;
	_NUMERIC_INPUT_EVENT_TBL*	 FirstNumericInput;
	_ASCIIINPUT_EVENT_TBL*	 FirstAsciiInput;
*/
	buffer= ScreenTagData[iDispOrder].TagPos;
/*
	if(CheckMailBox(sizeof(_NUMERIC_INPUT_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_NUMERIC_INPUT_EVENT_TBL));
	NumericInputEventTbl= (_NUMERIC_INPUT_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)NumericInputEventTbl, 0x00, sizeof(_NUMERIC_INPUT_EVENT_TBL));

/*		iTagSizeOf				= 0x00;*/
//		iTemp					= 0x00;
/*		
		iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
		iTagSizeOf += (unsigned int)buffer[1] & 0xff;
*/		
		/* ��ǥ�� �Է� �ޱ� */
/*
		NumericInputEventTbl->sX  = (unsigned int)(buffer[6] << 0x08);
		NumericInputEventTbl->sX += (unsigned int)buffer[7] & 0xff;

		NumericInputEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
		NumericInputEventTbl->sY += (unsigned int)buffer[9] & 0xff;

		NumericInputEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
		NumericInputEventTbl->eX += (unsigned int)buffer[11] & 0xff;

		NumericInputEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
		NumericInputEventTbl->eY += (unsigned int)buffer[13] & 0xff;
*/
		/* Plate Color ���� */
		NumericInputEventTbl->iPlateColor = (unsigned int)buffer[14];/* PlateColor */
		/* Frame Color ���� */
		NumericInputEventTbl->iFrameColor = (unsigned int)buffer[15];/* FrameColor */
		/* Form->Size ���� */
		NumericInputEventTbl->iFormSizeH = (unsigned int)buffer[16];
		NumericInputEventTbl->iFormSizeV = (unsigned int)buffer[17];
		iOffset = 18;
		/* Basic Device���� */
		/*------------------------------------------------------------*/
		GetDeviceSet((buffer+iOffset),
					NumericInputEventTbl->cDeviceName,
					&(NumericInputEventTbl->iDeviceNumber));
		/*-------------------------------------------------------------*/		
		iOffset +=5;
		/* Form Format���� */
		if(((unsigned int)buffer[iOffset] & 0x0F) == 0x00)
		{
			NumericInputEventTbl->iAlignment = DISPALLCHK_ALIGN;
		}else if(((unsigned int)buffer[iOffset] & 0x02) == 0x02){
			NumericInputEventTbl->iAlignment = CENTER_ALIGN;			
		}else if(((unsigned int)buffer[iOffset] & 0x01) == 0x01){
			NumericInputEventTbl->iAlignment = LEFT_ALIGN;			
		}else{
			NumericInputEventTbl->iAlignment = RIGHT_ALIGN;
		}

		if(((unsigned int)buffer[iOffset] & 0x50) == 0x50)
		{
			NumericInputEventTbl->iFormFormat = OCTAL;
		}else if(((unsigned int)buffer[iOffset] & 0x40) == 0x40){
			NumericInputEventTbl->iFormFormat = REAL;
		}else if(((unsigned int)buffer[iOffset] & 0x30) == 0x30){
			NumericInputEventTbl->iFormFormat = HEXA_DECIMAL;
		}else if(((unsigned int)buffer[iOffset] & 0x20) == 0x20){
			NumericInputEventTbl->iFormFormat = UNSIGNED_DECIMAL;
		}else if(((unsigned int)buffer[iOffset] & 0x10) == 0x10){
			NumericInputEventTbl->iFormFormat = SIGNED_DECIMAL;
		}else{
			NumericInputEventTbl->iFormFormat = BINARY;
		}
		/* Basic �ǿ���  Numeric Color���� */
		NumericInputEventTbl->iBasicNumColor = (unsigned int)buffer[++iOffset];

		/* Form �ǿ���  Decimal Point���� */
		NumericInputEventTbl->iDecimalPoint = (int)buffer[++iOffset];		

		/* Form �ǿ���  Digits���� */
		NumericInputEventTbl->iDigits = (int)buffer[++iOffset];
				
		/* Others�ǿ��� Userid 27-28 */
		NumericInputEventTbl->iUser_id  = (unsigned int)(buffer[++iOffset] << 0x08);/* iUser_id = 0xFF�̸� üũ���� ����*/
		NumericInputEventTbl->iUser_id += (unsigned int)buffer[++iOffset] & 0xff;
		
		/* Others�ǿ��� Move Destination id 29-30 */
		NumericInputEventTbl->iMoveDest_id  = (unsigned int)(buffer[++iOffset] << 0x08);/* iMoveDest_id = 0xFF�̸� üũ���� ����*/
		NumericInputEventTbl->iMoveDest_id += (unsigned int)buffer[++iOffset] & 0xff;
#ifdef	WIN32
		/* Gain1 */
		NumericInputEventTbl->iGain1  = (unsigned int)buffer[++iOffset] << 0x18;
		NumericInputEventTbl->iGain1 += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		NumericInputEventTbl->iGain1 += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		NumericInputEventTbl->iGain1 += (unsigned int)buffer[++iOffset] & 0xff; 

		/* Gain2 */
		NumericInputEventTbl->iGain2  = (unsigned int)buffer[++iOffset] << 0x18;
		NumericInputEventTbl->iGain2 += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		NumericInputEventTbl->iGain2 += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		NumericInputEventTbl->iGain2 += (unsigned int)buffer[++iOffset] & 0xff; 

		/* Offset */
		NumericInputEventTbl->Offset = (unsigned int)buffer[++iOffset] << 0x18;
		NumericInputEventTbl->Offset += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		NumericInputEventTbl->Offset += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		NumericInputEventTbl->Offset += (unsigned int)buffer[++iOffset] & 0xff; 
		iOffset++;
#else
		iOffset++;
		memcpy(&NumericInputEventTbl->iGain1,&buffer[iOffset],4);
		iOffset += 4;
		memcpy(&NumericInputEventTbl->iGain2,&buffer[iOffset],4);
		iOffset += 4;
		memcpy(&NumericInputEventTbl->Offset,&buffer[iOffset],4);
		iOffset += 4;
#endif
		if((unsigned int)buffer[iOffset] == 0x01)
		{
			NumericInputEventTbl->iUpperFlag = FIXED;
			NumericInputEventTbl->iLowerFlag = FIXED;
		}else if((unsigned int)buffer[iOffset] == 0x02)
		{
			NumericInputEventTbl->iUpperFlag = DEV;
			NumericInputEventTbl->iLowerFlag = DEV;
		}else if((unsigned int)buffer[iOffset] == 0x03)
		{
			NumericInputEventTbl->iUpperFlag = FIXED;
			NumericInputEventTbl->iLowerFlag = DEV;
		}else
		{
			NumericInputEventTbl->iUpperFlag = DEV;
			NumericInputEventTbl->iLowerFlag = FIXED;
		}

		if(NumericInputEventTbl->iUpperFlag == FIXED){
#ifdef	WIN32
			NumericInputEventTbl->iUpperFixedVal  = (unsigned int)buffer[++iOffset] << 0x18;
			NumericInputEventTbl->iUpperFixedVal += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
			NumericInputEventTbl->iUpperFixedVal += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
			NumericInputEventTbl->iUpperFixedVal += (unsigned int)buffer[++iOffset] & 0xff; 
			iOffset++;
#else
			iOffset++;
			memcpy(&NumericInputEventTbl->iUpperFixedVal,&buffer[iOffset],4);
			iOffset += 4;
#endif
		}
		else if(NumericInputEventTbl->iUpperFlag == DEV){
			/* UpperDeviceSet */
			/*------------------------------------------------------------*/
			iOffset++;
			GetDeviceSet((buffer+iOffset),
						NumericInputEventTbl->cUpperDeviceName,
						&(NumericInputEventTbl->iUpperDeviceNumber));
			/*-------------------------------------------------------------*/
			iOffset+=4;
		}
		if(NumericInputEventTbl->iLowerFlag == FIXED){
#ifdef	WIN32
			NumericInputEventTbl->iLowerFixedVal =  (unsigned int)buffer[++iOffset] << 0x18;
			NumericInputEventTbl->iLowerFixedVal += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
			NumericInputEventTbl->iLowerFixedVal += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
			NumericInputEventTbl->iLowerFixedVal += (unsigned int)buffer[++iOffset] & 0xff;
			iOffset++;
#else
			iOffset++;
			memcpy(&NumericInputEventTbl->iLowerFixedVal,&buffer[iOffset],4);
			iOffset += 4;
#endif
		}
		else if(NumericInputEventTbl->iLowerFlag == DEV){
			/* LowerDeviceSet */
			/*------------------------------------------------------------*/
			iOffset++;
			GetDeviceSet((buffer+iOffset),
						NumericInputEventTbl->cLowerDeviceName,
						&(NumericInputEventTbl->iLowerDeviceNumber));
			/*-------------------------------------------------------------*/	
			iOffset+=4;
		}
		iOffset++;
		if(mode == 0){
			if((unsigned int)buffer[iOffset] == 1)
				ScreenTagData[iDispOrder].uu.NumIn.iTriggerTypeVal = 2;
			else if((unsigned int)buffer[iOffset] == 2)
				ScreenTagData[iDispOrder].uu.NumIn.iTriggerTypeVal = ON;
			else if((unsigned int)buffer[iOffset] == 3)
				ScreenTagData[iDispOrder].uu.NumIn.iTriggerTypeVal = OFF;
		}
		iOffset++;
		if(ScreenTagData[iDispOrder].uu.NumIn.iTriggerTypeVal != 2){/* 2 */
			/* TriggerDeviceSet */
			/*------------------------------------------------------------*/
			GetDeviceSet((buffer+iOffset),
						NumericInputEventTbl->cTriggerDeviceName,
						&(NumericInputEventTbl->iTriggerDeviceNumber));
			iOffset+=5;
			/*-------------------------------------------------------------*/		
		}
		if((unsigned int)buffer[iOffset]==0x01){
			NumericInputEventTbl->iSignFlag		= SIGNED;    /* 0 : Signed BIN	1 : Unsigned BIN */
			NumericInputEventTbl->i1632BitFlag	= 0;	/* 0 : 16Bit		1 : 32Bit		*/
		}
		else if((unsigned int)buffer[iOffset]==0x02){
			NumericInputEventTbl->iSignFlag		= UNSIGNED;    /* 0 : Signed BIN	1 : Unsigned BIN */
			NumericInputEventTbl->i1632BitFlag	= 0;	/* 0 : 16Bit		1 : 32Bit		*/
		}
		else if((unsigned int)buffer[iOffset]==0x03){
			NumericInputEventTbl->iSignFlag		= SIGNED;    /* 0 : Signed BIN	1 : Unsigned BIN */
			NumericInputEventTbl->i1632BitFlag	= 1;	/* 0 : 16Bit		1 : 32Bit		*/
		}
		else{
			NumericInputEventTbl->iSignFlag		= UNSIGNED;    /* 0 : Signed BIN	1 : Unsigned BIN */
			NumericInputEventTbl->i1632BitFlag	= 1;	/* 0 : 16Bit		1 : 32Bit		*/
		}

		if((unsigned int)buffer[++iOffset] != 0x00){
			if(mode == 0){
				ScreenTagData[iDispOrder].BeShapeUsed = CHECKED;
			}
			NumericInputEventTbl->ShapeNo = (unsigned int)buffer[++iOffset];
		}else{
			if(mode == 0){
				ScreenTagData[iDispOrder].BeShapeUsed = UNCHECKED;
			}
			NumericInputEventTbl->ShapeNo = 0;
			iOffset++;
		}

		if((unsigned int)buffer[++iOffset] != 0x00){
			NumericInputEventTbl->iFormSizeH = 0;
			NumericInputEventTbl->iFormSizeV = 0;		//20101207
		}

		NumericInputEventTbl->iHighQuality = (unsigned int)buffer[++iOffset];
		if(mode == 0){		/* Setting */
			DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;
			DeviceDataHed[DeviceCnt].DevName[0] = NumericInputEventTbl->cDeviceName[0];
			DeviceDataHed[DeviceCnt].DevName[1] = NumericInputEventTbl->cDeviceName[1];
			DeviceDataHed[DeviceCnt].DevAddress = NumericInputEventTbl->iDeviceNumber;
			if(NumericInputEventTbl->i1632BitFlag == BIT16){
				DeviceDataHed[DeviceCnt].DevCnt = 1;
			}else{
				DeviceDataHed[DeviceCnt].DevCnt = 2;
			}
			DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];
			ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
			ScreenTagData[iDispOrder].DevCnt= DeviceDataHed[DeviceCnt].DevCnt*2;
			iDeviceOffset += (int)(DeviceDataHed[DeviceCnt].DevCnt*2);
/*			NumericInputEventTbl->iRegisterNumber = DeviceCnt;*/
		/*		*/
/*		NumericInputEventTbl->SuperVOffset= WatchingDevice(NumericInputEventTbl->cDeviceName, 
											 NumericInputEventTbl->iDeviceNumber, 
											 NumericInputEventTbl->i1632BitFlag,
											 NumericInputEventTbl->iRegisterNumber,
											 WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
			DeviceCnt++;
		

			/* ���Ѱ��� Device�� ���� ��� */		
			if(NumericInputEventTbl->iUpperFixedVal == UNCHECKED){
				
				DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */
				DeviceDataHed[DeviceCnt].DevName[0] = NumericInputEventTbl->cUpperDeviceName[0];
				DeviceDataHed[DeviceCnt].DevName[1] = NumericInputEventTbl->cUpperDeviceName[1];
				DeviceDataHed[DeviceCnt].DevAddress = NumericInputEventTbl->iUpperDeviceNumber;
				
				if(NumericInputEventTbl->i1632BitFlag == BIT16){
					DeviceDataHed[DeviceCnt].DevCnt = 1; /* DeviceDataHed[DeviceCnt].DevCnt = 1 * NumericInputEventTbl->iDigits;*/
				}else{
					DeviceDataHed[DeviceCnt].DevCnt = 2;
				}
				DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];
				iDeviceOffset += (int)(DeviceDataHed[DeviceCnt].DevCnt*2);
/*				NumericInputEventTbl->iUpperRegistNumber = DeviceCnt;*/

				/*		*/
/*				NumericInputEventTbl->Up_SuperVOffset= WatchingDevice(NumericInputEventTbl->cUpperDeviceName, 
													 NumericInputEventTbl->iUpperDeviceNumber, 
													 NumericInputEventTbl->i1632BitFlag,
													 NumericInputEventTbl->iUpperRegistNumber,
													 WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
				ScreenTagData[iDispOrder].DevCnt += DeviceDataHed[DeviceCnt].DevCnt*2;
				DeviceCnt++;
			}
			/* ���Ѱ��� Device�� ���� ��� */
			if(NumericInputEventTbl->iLowerFixedVal == UNCHECKED){
				
				DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */
				DeviceDataHed[DeviceCnt].DevName[0] = NumericInputEventTbl->cLowerDeviceName[0];
				DeviceDataHed[DeviceCnt].DevName[1] = NumericInputEventTbl->cLowerDeviceName[1];
				DeviceDataHed[DeviceCnt].DevAddress = NumericInputEventTbl->iLowerDeviceNumber;

				if(NumericInputEventTbl->i1632BitFlag == BIT16){
					DeviceDataHed[DeviceCnt].DevCnt = 1;
				}else{
					DeviceDataHed[DeviceCnt].DevCnt = 2;
				}
				DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];
				iDeviceOffset += (int)(DeviceDataHed[DeviceCnt].DevCnt*2);
/*				NumericInputEventTbl->iLowerRegistNumber = DeviceCnt;*/

				/*		*/
/*				NumericInputEventTbl->Lw_SuperVOffset= WatchingDevice(NumericInputEventTbl->cLowerDeviceName, 
													 NumericInputEventTbl->iLowerDeviceNumber, 
													 NumericInputEventTbl->i1632BitFlag,
													 NumericInputEventTbl->iLowerRegistNumber,
													 WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
				ScreenTagData[iDispOrder].DevCnt += DeviceDataHed[DeviceCnt].DevCnt*2;
				DeviceCnt++;
			}

			if(ScreenTagData[iDispOrder].uu.NumIn.iTriggerTypeVal != 2){
				ScreenTagData[iDispOrder].uu.NumIn.iBStartDataPos= iDeviceOffset;
				DeviceDataHed[DeviceCnt].DevFlag = DEVICE_BIT;/* Bit */
				DeviceDataHed[DeviceCnt].DevName[0] = NumericInputEventTbl->cTriggerDeviceName[0]; 
				DeviceDataHed[DeviceCnt].DevName[1] = NumericInputEventTbl->cTriggerDeviceName[1];
				DeviceDataHed[DeviceCnt].DevAddress = NumericInputEventTbl->iTriggerDeviceNumber;
				DeviceDataHed[DeviceCnt].DevCnt = 1;
				DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];
				iDeviceOffset += (int)DeviceDataHed[DeviceCnt].DevCnt;
/*				NumericInputEventTbl->iTriggerRegistNumber = DeviceCnt;*/
				
				/*		*/
/*				NumericInputEventTbl->Tr_SuperVOffset= WatchingDevice(NumericInputEventTbl->cTriggerDeviceName, 
													 NumericInputEventTbl->iTriggerDeviceNumber, 
													 NumericInputEventTbl->i1632BitFlag,
													 NumericInputEventTbl->iTriggerRegistNumber,
													 BIT,DeviceDataHed[DeviceCnt].DevCnt);
*/
/*				ScreenTagData[iDispOrder].DevCnt += DeviceDataHed[DeviceCnt].DevCnt;*/
				DeviceCnt++;

			}
		}
/*********************************************************/
		if(mode == 0){
			if(InputDisplay.iFlag == 1 && 
				NumericInputEventTbl->iUser_id != 0xff ){
				if(ScreenTagData[InputDisplay.iInputNo].cObjects == NUMERICAL_INPUT){
	/*				FirstNumericInput = (_NUMERIC_INPUT_EVENT_TBL*)IventTable[InputDisplay.iInputNo];*/
					iUser_id= GetUsrId(0,InputDisplay.iInputNo);
	/*				if(NumericInputEventTbl->iUser_id < FirstNumericInput->iUser_id){*/
					if((int)NumericInputEventTbl->iUser_id < iUser_id){
						InputDisplay.iFlag = 0;
						InputDisplay.iKeyOnOff = 0;
					}
				}else
				{	
					if(AsciiInputCnt!=0){
	/*					FirstAsciiInput = (_ASCIIINPUT_EVENT_TBL*)IventTable[InputDisplay.iInputNo];*/
						iUser_id= GetUsrId(1,InputDisplay.iInputNo);
	/*					if(NumericInputEventTbl->iUser_id < FirstAsciiInput->iUser_id){*/
						if((int)NumericInputEventTbl->iUser_id < iUser_id){
							InputDisplay.iFlag = 0;
							InputDisplay.iKeyOnOff = 0;
						}
					}
				}
			}
			if(InputDisplay.iFlag == 0){
				if(CommonArea.ProjectAuxSet.DispCursorWindow == 0x02)
				{
					if(mode == 0){	
						/*InputDisplay.iInputNo = IventTableCnt;*/ /* ID�� ���� Ŀ�� Display�� ����... */
						InputDisplay.iInputNo= iDispOrder;
					}
					if(NumericInputEventTbl->iFormFormat == HEXA_DECIMAL)
						CommonArea.KeyWindow.iKeyType = KEY_HEX;		/* HEXA Type */
					else if(NumericInputEventTbl->iFormFormat == OCTAL)
						CommonArea.KeyWindow.iKeyType = KEY_OCTAL;		/* OCTAL Type */
					else if(NumericInputEventTbl->iFormFormat == BINARY)
						CommonArea.KeyWindow.iKeyType = KEY_BINARY;		/* BINARY Type */
					else if(NumericInputEventTbl->iFormFormat == REAL)
						CommonArea.KeyWindow.iKeyType = KEY_REAL;		/* REAL Type */
					else
						CommonArea.KeyWindow.iKeyType = KEY_DECIMAL;	/* DESIMAL Type */					

					InputDisplay.iKeyOnOff = 1;
				}else if(CommonArea.ProjectAuxSet.DispCursorWindow == 0x01)
				{
					if(mode == 0){	
						/*InputDisplay.iInputNo = IventTableCnt;*//* ID�� ���� Ŀ�� Display�� ����... */
						InputDisplay.iInputNo = iDispOrder;/* ID�� ���� Ŀ�� Display�� ����... */
					}
					InputDisplay.iKeyOnOff = 3;
				}
				InputDisplay.iFlag = 1;
			}
			NumericInputCnt++;
		}
/*********************************************************/
/*		IventTableCnt++;*/
/*		NumericInputCnt++;*/
		return(0);
}

	char*			cImsiData;

void NumericInputWatch(int mode,int iOrder,char *DispData)
{
//	int				i;
	int				sX;
	int				sY;
	int				eX;
	int				eY;
	char			cDisplayFormat[10];
	char			cUpperDeviceVal[10];
	char			cLowerDeviceVal[10];
	char			cTriggerDeviceVal[2];
	long			lBasicDevVal;
//	long			lUpperDevVal;
//	long			lLowerDevVal;
	int				iSTemp;
/*	char			cTempBuffer[32];*/
	char			*cTempBuffer;
	int				istrLen;
	int				iFontsX;
	int				iNullFlag;
	int				Font_Color;
	int				Back_Color;
//	int				iType;
	int				iFontVal;
	short			iShapeSize;
	char*			cTemp;
	char*			cDispBuffer;
//	char*			cImsiData;
	_NUMERIC_INPUT_EVENT_TBL*	 NumericInputEventTbl;

/*	int				iTriggerRegistNumber;
	int				iTriggerDevVal;
	int				iWatchStart;
*/
	int				mCnt;
	int				midx;

	iNullFlag = 1;
	lBasicDevVal = 0;

/*	NumericInputEventTbl= (_NUMERIC_INPUT_EVENT_TBL*)IventTable[iOrder];*/
	NumericInputEventTbl= (_NUMERIC_INPUT_EVENT_TBL*)TakeMemory(sizeof(_NUMERIC_INPUT_EVENT_TBL));
	DrawNumericInput_Func(1,NumericInputEventTbl,iOrder);

	if(NumericInputEventTbl->i1632BitFlag == BIT16){
		mCnt= 2;
	}else{
		mCnt= 4;
	}
	midx= ScreenTagData[iOrder].DevOrder;
//	i = iOrder;

	memset(cUpperDeviceVal, 0x00, sizeof(cUpperDeviceVal));
	memset(cLowerDeviceVal, 0x00, sizeof(cLowerDeviceVal));
	memset(cTriggerDeviceVal, 0x00, sizeof(cTriggerDeviceVal));
	memset(cDisplayFormat, 0x00, sizeof(cDisplayFormat));

	cImsiData = (char*)TakeMemory((NumericInputEventTbl->iDigits+1));
	memset(cImsiData,0x00,(NumericInputEventTbl->iDigits+1));
	cTempBuffer= TakeMemory(0x400);
	memset(cTempBuffer,0x00,0x400);
	if(!(InputDisplay.iKeyOnOff == 2 && InputDisplay.iInputNo == iOrder))
	{
			iNullFlag = 0;
			memcpy(cTempBuffer,&DispDeviceData[midx],mCnt);
			midx+= mCnt;
			if(NumericInputEventTbl->iSignFlag == SIGNED)
				lBasicDevVal= ChangeChar2long(cTempBuffer,NumericInputEventTbl->i1632BitFlag);
			else
				lBasicDevVal= ChangeChar2Unsinlong(cTempBuffer,NumericInputEventTbl->i1632BitFlag);
			lBasicDevVal = NumericInputEventTbl->Offset + ((lBasicDevVal * NumericInputEventTbl->iGain1)/NumericInputEventTbl->iGain2);
/* 20080822 �̺κ� �������� ���� Ȯ�� �ʿ�. ��ġ�Է��� �μ� ������ ��� */
			if(NumericInputEventTbl->i1632BitFlag == 0){	/* 16 Bit 060203 */
				if(NumericInputEventTbl->iFormFormat != SIGNED_DECIMAL){
					lBasicDevVal= lBasicDevVal & 0xffff;
				}
			}
			if(lBasicDevVal == 0)
				iNullFlag = 1;
	}else
	{
		InputDisplay.iInputNo = iOrder;
	}

	/* Upper Critical Value */
	if(NumericInputEventTbl->iUpperFlag != FIXED)
	{
		memcpy(cTempBuffer,&DispDeviceData[midx],mCnt);
		midx+= mCnt;
//		if(NumericInputEventTbl->iSignFlag == SIGNED)
//			lUpperDevVal= ChangeChar2long(cTempBuffer,NumericInputEventTbl->i1632BitFlag);
//		else
//			lUpperDevVal= ChangeChar2Unsinlong(cTempBuffer,NumericInputEventTbl->i1632BitFlag);
	}else{
//		lUpperDevVal = (long)NumericInputEventTbl->iUpperFixedVal;
	}
	/* Lower Critical Value */
	if(NumericInputEventTbl->iLowerFlag != FIXED){
		memcpy(cTempBuffer,&DispDeviceData[midx],mCnt);
		midx+= mCnt;
//		if(NumericInputEventTbl->iSignFlag == SIGNED)
//			lLowerDevVal= ChangeChar2long(cTempBuffer,NumericInputEventTbl->i1632BitFlag);
//		else
//			lLowerDevVal= ChangeChar2Unsinlong(cTempBuffer,NumericInputEventTbl->i1632BitFlag);
	}else{
//		lLowerDevVal = (long)NumericInputEventTbl->iLowerFixedVal;
	}
	/* Shape�� ���� ��� Shape�� �׸���. */
	sX = ScreenTagData[iOrder].sX;
	sY = ScreenTagData[iOrder].sY;
	eX = ScreenTagData[iOrder].eX;
	eY = ScreenTagData[iOrder].eY;
	if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){
		iShapeSize = DrawShape(NumericInputEventTbl->ShapeNo,
					sX, sY,	eX , eY,
					NumericInputEventTbl->iFrameColor,
					NumericInputEventTbl->iPlateColor);
		sX+=iShapeSize;
		sY+=iShapeSize;
		eX -= iShapeSize;
		eY -= iShapeSize;

	}
	if(strlen(NumericInputEventTbl->cDeviceName))
	{
		if(!(InputDisplay.iKeyOnOff == 2 && InputDisplay.iInputNo == iOrder))
		{
			if(iNullFlag == 0){
				memset(NumericInputEventTbl->cTempBuffer, 0x00 , 32);		/* strlen(NumericInputEventTbl->cTempBuffer)->32 */
				
				NumericFormFormat(cTempBuffer, NumericInputEventTbl->iDigits, 
								NumericInputEventTbl->cTempBuffer,
								NumericInputEventTbl->iFormFormat, lBasicDevVal,
								NumericInputEventTbl->i1632BitFlag,
								NumericInputEventTbl->iDecimalPoint);	/* Form Format ����. */

				memcpy(cImsiData, cTempBuffer,
						strlen(cTempBuffer));
				cImsiData[strlen(cTempBuffer)]= 0;		/* 2008.09.08 */
				if(	(NumericInputEventTbl->iGain1 != 1 ||  
					NumericInputEventTbl->iGain2 != 1 || 
					NumericInputEventTbl->Offset != 0) &&
					NumericInputEventTbl->iFormFormat != REAL)
				{
/*					lBasicDevVal =  (long)NumericInputEventTbl->lBefDevBal;*/

					NumericFormFormat(cTempBuffer, NumericInputEventTbl->iDigits, 
									NumericInputEventTbl->cTempBuffer,
									NumericInputEventTbl->iFormFormat, lBasicDevVal,
									NumericInputEventTbl->i1632BitFlag,
									NumericInputEventTbl->iDecimalPoint);	/* Form Format ����. */
				}
			}else
			{
				strcpy(NumericInputEventTbl->cTempBuffer,"0");
				strcpy(cImsiData,"0");
			}
		}else /* TouchSwitch Input */
		{
			InputDisplay.iLen = NumericInputEventTbl->iDigits;
			istrLen = strlen(InputDisplay.cInputDispBuff);
			istrLen = istrLen - InputDisplay.iLen;
			if(istrLen<=0)
				istrLen = 0;

			memcpy(cImsiData, InputDisplay.cInputDispBuff+istrLen,
							NumericInputEventTbl->iDigits);
			if(strlen(cImsiData)==0)
				strcpy(cImsiData,"0");
		}


		cDispBuffer = (char*)TakeMemory(((NumericInputEventTbl->iDigits)+1));
		cTemp = (char*)TakeMemory(((NumericInputEventTbl->iDigits)+1));
		memset(cTemp, 0x00, (NumericInputEventTbl->iDigits+1));

		if(NumericInputEventTbl->iAlignment == LEFT_ALIGN ||
		   NumericInputEventTbl->iAlignment == CENTER_ALIGN ||
		   NumericInputEventTbl->iAlignment == RIGHT_ALIGN){
				if(NumericInputEventTbl->iFormFormat == SIGNED_DECIMAL || 
				   NumericInputEventTbl->iFormFormat == UNSIGNED_DECIMAL || 
				   NumericInputEventTbl->iFormFormat == REAL){/* Signed Decimal, Unsinged Decimal, Real*/

					iSTemp = NumericInputEventTbl->iDecimalPoint;

					if(iSTemp != 0 && NumericInputEventTbl->iFormFormat != REAL){					
						NumericPointDisplay(cTemp,
											cImsiData,
											NumericInputEventTbl->iDigits,
											iSTemp); /*  �Ҽ����� ���ó���� �Ѵ�. */
						sprintf(cDispBuffer, "%s", cTemp);
					}else{
						sprintf(cDispBuffer, "%s", cImsiData);
					}
				}else{/* Hexa Decimal, Binary, Octal */
						sprintf(cDispBuffer, "%s", cImsiData);
				}
		}else if(NumericInputEventTbl->iAlignment == DISPALLCHK_ALIGN){
			sprintf(cDisplayFormat, "%%0%d%s",NumericInputEventTbl->iDigits, "s");
			if(NumericInputEventTbl->iFormFormat == SIGNED_DECIMAL || 
			   NumericInputEventTbl->iFormFormat == UNSIGNED_DECIMAL || 
			   NumericInputEventTbl->iFormFormat == REAL)
			{

				iSTemp = NumericInputEventTbl->iDecimalPoint;
				if(iSTemp != 0){
					NumericPointDisplay(cTemp,
										cImsiData,
										NumericInputEventTbl->iDigits,
										iSTemp);
					
					sprintf(cDispBuffer, cDisplayFormat, cTemp);
				}else{
					NumericZeroDisplay(cDispBuffer,cImsiData,NumericInputEventTbl->iDigits);
				}
			}else{
				NumericZeroDisplay(cDispBuffer,cImsiData,NumericInputEventTbl->iDigits);
			}
		}

/*		if(iOnSignalStart != OFF){*/
			Font_Color = NumericInputEventTbl->iBasicNumColor;
			if(Font_Color == 0)
			{
				Back_Color	= WHITE;	
//				iType		= T_FRONT;
			}else
			{
				Back_Color = BLACK;
//				iType      = T_OR;
			}		

			if(NumericInputEventTbl->iFormSizeH == 0){
				iFontVal = 6;
			}else{
				iFontVal = 8;
				if(NumericInputEventTbl->iFormSizeH > 1)
					iFontVal = NumericInputEventTbl->iFormSizeH * 8;
			}

			iFontsX = 0;
			if(NumericInputEventTbl->iAlignment == 0x00)
			{
				iFontsX =  (eX+1-sX)-(strlen(cDispBuffer)*iFontVal);
			/*	if(NumericInputEventTbl->BeShapeUsed == CHECKED)
					iFontsX = iFontsX - SHAPE_DISTANCE;*/
			}
			else if(NumericInputEventTbl->iAlignment==0x02)
			{
				iFontsX = ((eX+1-sX)-(strlen(cDispBuffer)*iFontVal))/2;
			}
			if(mode == 0){	/* Display */
				if(NumericInputEventTbl->iHighQuality == 0x00)
				{
					DotTextOut(iFontsX+sX, sY, cDispBuffer, 
						NumericInputEventTbl->iFormSizeH, 
						NumericInputEventTbl->iFormSizeV, 
						T_FRONT, Font_Color, 
						Back_Color);
				}else
				{
					DotTextOut2(iFontsX+sX, sY, cDispBuffer, 
						NumericInputEventTbl->iFormSizeH, 
						NumericInputEventTbl->iFormSizeV, 
						T_FRONT, Font_Color, 
						Back_Color);
				}
			}
			if((InputDisplay.iKeyOnOff == 2 || InputDisplay.iKeyOnOff == 3) && InputDisplay.iInputNo == iOrder)
			{
				istrLen = strlen(cDispBuffer);
				AreaRevers((sX+iFontsX+(iFontVal * (istrLen-1))),sY,(sX+iFontsX + (iFontVal * istrLen)-1),eY);
			}

		/*}*/
		if(mode == 1){
			strcpy(DispData,NumericInputEventTbl->cTempBuffer);
		}
		FreeMail(cDispBuffer);
		FreeMail(cTemp);
	}
	if(InputDisplay.iKeyOnOff == 1 && InputDisplay.iInputNo == iOrder)
	{
		InputDisplay.iKeyOnOff = 2;
		SwitchingScreenDevice.iBaseScreenFlag = 2;
	}
	FreeMail(cImsiData);
	FreeMail((char *)NumericInputEventTbl);
	FreeMail(cTempBuffer);
}
/********************************************************************************/
/* �� �� �� : NumericPointDisplay												*/
/* ��    �� : �Ҽ����� ��� ó��											    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 1�� (��)												*/
/* �� �� �� : �� �� �� 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	NumericPointDisplay(char *cDispBuffer,char *cBuffer,int iDigits,int iDecimalPoint)
{
	char		*cTemp;
	char		*FormatData;
	short		iLen;
	short		iCnt;
	int			isLen;
	int			iFlag;	


	cTemp = (char *)TakeMemory(iDigits + 1);
	FormatData = (char *)TakeMemory(32);

	memset(cDispBuffer,0x00,iDigits+1);
	memset(cTemp,0x00,iDigits+1);
	memset(FormatData,0x00,32);

	isLen = strlen(cBuffer);
	iLen = isLen;
	iFlag= 0;				/* 030705 */

	if(cBuffer[0] == '-'){
		iFlag = 1;
		iLen--;
		isLen--;
		strcpy(FormatData,cBuffer+1);
	}else
		strcpy(FormatData,cBuffer);

	if(isLen<=iDecimalPoint){
		isLen = iDecimalPoint;
		isLen++;
	}
	isLen++;

	if(iFlag==1)
		isLen++;

	if(iLen != 0){ 
		if(isLen > iDigits)
		{
			if(cBuffer[0] == '-' || cBuffer[0] == 'L'){
				strcpy(FormatData,"LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL");
			}else
			{
				strcpy(FormatData,"HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH");
			}
			strncpy(cTemp,FormatData,(iDigits-(iDecimalPoint+1)));
			strncat(cTemp,".",1);
			strncat(cTemp,FormatData,iDecimalPoint);
			strcpy(cDispBuffer,cTemp);
		}
		else
		{
			if(iLen>iDecimalPoint){
				strncpy(cTemp,FormatData,(iLen-iDecimalPoint));
				strncat(cTemp,".",1);
				strcat(cTemp,FormatData+(iLen-iDecimalPoint));
			}else{
				strcpy(cTemp,"0.");
				if(iLen<iDecimalPoint){
					iCnt=iDecimalPoint-iLen;
					for(;iCnt>0;iCnt--)
					{
						strncat(cTemp,"0",1);
					}
				}
				strcat(cTemp,FormatData);
			}
			if(iFlag == 1){
				strcpy(cDispBuffer,"-");
				strcat(cDispBuffer,cTemp);
			}else{
				strcpy(cDispBuffer,cTemp);
			}
		}
	}
	FreeMail((char *)FormatData);
	FreeMail((char *)cTemp);
}
/********************************************************************************/
/* �� �� �� : NumericZeroDisplay												*/
/* ��    �� : 0�� ä��� ó��												    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 1�� (��)												*/
/* �� �� �� : �� �� �� 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	NumericZeroDisplay(char *cDispBuffer,char *cBuffer,int iDigits)
{
	char		cDisplayFormat[10];
	char		*cTemp;

	cTemp = (char *)TakeMemory(iDigits + 1);

	memset(cTemp,0x00,iDigits+1);
	memset(cDisplayFormat, 0x00, sizeof(cDisplayFormat));
	if(cBuffer[0] == '-' && ((strlen(cBuffer)) != (unsigned int)iDigits)){
		sprintf(cDisplayFormat, "%%0%d%s",iDigits-1, "s");
		sprintf(cTemp, cDisplayFormat, cBuffer+1);
		strcpy(cDispBuffer,"-");
		strcat(cDispBuffer,cTemp);
	}else{
		sprintf(cDisplayFormat, "%%0%d%s",iDigits, "s");
		sprintf(cTemp, cDisplayFormat, cBuffer);
		strcpy(cDispBuffer,cTemp);
	}
	FreeMail(cTemp);
}

/********************************************************************************/
/* �� �� �� : NumericFormFormat													*/
/* ��    �� : NumericForm�� ���� ����.										    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 1�� (��)												*/
/* �� �� �� : �� �� �� 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	NumericFormFormat(char *cTempBuffer, int iDigits, char *OrgData,int iFormFormat, long lBasicDevVal, int i1632BitFlag,short iDecimalPoint)
{
	short			i;
//	short			iCnt;
	int				istrLen;
	char			iBuffer[33];
	char			cBufData[33];
	short			DelectCode;
	unsigned int	Buffer;

/*	J.S.LIM 2004/06/04 
	short			j; 
	int				pFlag;	
	int				iLen;
	int				iBufLen; 
	float			fWork;  
	float			fCheck; 
 */

//	iCnt = 0;
	DelectCode = 0;
	memset(iBuffer,0x00,33);
	memset(cBufData,0x00,33);
	switch(iFormFormat){
		case SIGNED_DECIMAL:
			itoa((int)lBasicDevVal, cTempBuffer, 10);
			break;

		case UNSIGNED_DECIMAL:
/*			Buffer = (lBasicDevVal & 0x0000ffff); 030705 Owashi */
			Buffer = (unsigned int)lBasicDevVal;
			sprintf(cTempBuffer, "%lu", Buffer);
			break;

		case HEXA_DECIMAL:
/*			sprintf(cTempBuffer, "%x", (int)lBasicDevVal); 030705 Owashi */
			sprintf(cTempBuffer, "%X", (int)lBasicDevVal);

/*			iLen = strlen(cTempBuffer);
			if(i1632BitFlag == 0 && iLen > 4){
				iLen = iLen - 4;
				strcpy(iBuffer,cTempBuffer);
				memset(cTempBuffer,0x00,33);	
				strncpy(cTempBuffer,iBuffer+iLen,4);
			}
			*/
			break;

		case OCTAL:
			sprintf(cTempBuffer, "%o", (int)lBasicDevVal);
			break;

		case BINARY:
			itoa((int)lBasicDevVal, cTempBuffer, 2);
/*			iLen = strlen(cTempBuffer);
			if(i1632BitFlag == 0 && iLen > 16){
				iLen = iLen - 16;
				strcpy(iBuffer,cTempBuffer);
				memset(cTempBuffer,0x00,33);	
				strncpy(cTempBuffer,iBuffer+iLen,16);
			}
			*/
			break;

		case REAL:
/*			sprintf(cTempBuffer, "%e", (float)lBasicDevVal); 030705 */
/* start : J.S.LIM 2004/06/04			
			memcpy(&fWork,&lBasicDevVal,4);
			fCheck = fWork;
			if(fCheck<0)
				fCheck*=-1;

			if((fCheck<=0.0001 || fCheck>=1000000000) && fCheck != 0)		//
			{
				sprintf(cTempBuffer, "%E", (double)fWork);
				pFlag = 1;
			}
			else
			{	
				if(iDecimalPoint == 0)
					sprintf(iBuffer,"%%.%df",iDecimalPoint);
				else
				{
					sprintf(cTempBuffer, "%f", (double)fWork);
					i = strcspn(cTempBuffer,".");		/ �Ҽ����� ��ġ /
					i++;
					if(iDigits == i)
						sprintf(iBuffer,"%%.%df",0);
					else if(iDigits > i)
					{
						if((iDigits-i)<iDecimalPoint) 
							sprintf(iBuffer,"%%.%df",(iDigits-i));
						else
							sprintf(iBuffer,"%%.%df",iDecimalPoint);
					}
					else
					{	
						/ �ڸ������� Ŭ ��� HHHH �Ǵ� LLLL ǥ�� /
						DelectCode = 1;
						break;
					}
					memset(cTempBuffer,0x00,sizeof(cTempBuffer));
				}
				sprintf(cTempBuffer, iBuffer, (double)fWork);
				pFlag = 0;
			}
			
			if(pFlag == 0)
			{
				istrLen = strlen(cTempBuffer);		/ ���� �������� ���� /

				i = strcspn(cTempBuffer,".");		/ �Ҽ����� ��ġ /

				if(iDigits < i)	/  1234.***  1234�κ�(i)�� ǥ���� �� �ִ� Data(iDigits-iDecimalPoint)�� ���� check /
				{
					DelectCode = 1;
					break;
				}

				if(iDigits == i){
					cTempBuffer[i] = 0x00;
				}
				if(i+iDecimalPoint+1 <= iDigits)
				{
					if(iDecimalPoint < (istrLen - i -1))
						cTempBuffer[i+iDecimalPoint+1] = 0x00;
					else
						cTempBuffer[i+(istrLen - i)] = 0x00;
				}
				else
				{
					if((iDigits-i) < (istrLen - i))
						cTempBuffer[iDigits] = 0x00;
					else
						cTempBuffer[istrLen] = 0x00;
				}
			}else	/  /
			{
				istrLen = strlen(cTempBuffer);
				for(i= 0; i < istrLen; i++){
					if(cTempBuffer[i] == 'E'){
						for(j=0;j<istrLen-i;j++){
							if(cTempBuffer[i+j]==0x00)
							{
								break;
							}
							else if((!(cTempBuffer[i+j]=='0' || cTempBuffer[i+j] =='+')) 
								|| (cTempBuffer[i+j]=='0' && cBufData[iCnt-1] != 'E' && cBufData[iCnt-1] != '-'))
							{
								cBufData[iCnt] = cTempBuffer[i+j];
								iCnt++;
							}
						}
						cBufData[iCnt] = 0x00;
						break;
					}
				}
				iBufLen = strlen(cBufData);
				if(iDigits == iBufLen)
				{
					memcpy(cTempBuffer,cBufData,iBufLen);
					cTempBuffer[iBufLen] = 0x00;
				}else
				{
					if((iDigits - iBufLen) < (2+iDecimalPoint))
					{
						if((iDigits - iBufLen) == 2)
							cTempBuffer[1] = 0x00;
						else
							cTempBuffer[iDigits - iBufLen] = 0x00;
						sprintf(cTempBuffer,"%s%s",cTempBuffer,cBufData);

					}else
					{
						if(iDecimalPoint>0)
							cTempBuffer[2+iDecimalPoint] = 0x00;
						else
							cTempBuffer[1] = 0x00;
							
						sprintf(cTempBuffer,"%s%s",cTempBuffer,cBufData);
					}

				}

			}
			iBufLen = (strlen(cTempBuffer))-1;
			if(cTempBuffer[iBufLen] == 0x2E)
				cTempBuffer[iBufLen] = 0x00; 
end : J.S.LIM 2004/06/04 */						
			/* START : J.S.LIM 2004/06/04 */
			RealToString(cTempBuffer, lBasicDevVal, iDigits, iDecimalPoint);
			if(OrgData != cTempBuffer)
				strcpy(OrgData,cTempBuffer);
			return;
			/* END : J.S.LIM 2004/06/04 */
	}
	if(OrgData != cTempBuffer){
		strcpy(OrgData,cTempBuffer);
	}

	istrLen = strlen(cTempBuffer);
	if(istrLen > iDigits || DelectCode == 1)
	{
		i = strcspn((cTempBuffer+1),"-");
		if(cTempBuffer[i] == '-')
		{
			memset(cTempBuffer,'0',iDigits);
			cTempBuffer[iDigits] = 0x00;
		}
		else if(cTempBuffer[0] == '-'){
			memset(cTempBuffer,0x00,strlen(cTempBuffer));
			strncpy(cTempBuffer,"LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL",iDigits);
		}else
		{
			memset(cTempBuffer,0x00,strlen(cTempBuffer));
			strncpy(cTempBuffer,"HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH",iDigits);
		}
	}
}

/*	J.S.LIM 2004/06/04
	void RealToString(szReturnStr, fNum, iDigits, iDecimalPoint)
	�־��� �Ǽ��� �ڸ����� �Ҽ�����ġ�� ����Ͽ� ȭ�鿡 ǥ�õ� ���ڿ��� ��ȯ
	char  szReturnStr[];  ȭ�鿡 ǥ�õ� ���ڿ�  
	double fNum;           ��ȯ�� �Ǽ�           
	int   iDigits;        ǥ�� �ڸ���            
	int   iDecimalPoint;  �Ҽ����� ǥ�� �ڸ���  
*/
/*void	ChangeShou(char* buff)
{
	char	c;

	while(1){
		c= *buff;
		if(c == 0){		break;		}
		if(c == 'm'){	*buff= '.';	}
		buff++;
	}
}
*/
/*char	szNum[41];*/    /* %e �ɼ����� ����Ʈ�� fNum */
void RealToString(char  szReturnStr[], long lBasicDevVal, int iDigits, int iDecimalPoint)
{
	float   fNum;         /* floating point number */ 
	char	szNum[41];    /* %e �ɼ����� ����Ʈ�� fNum */
	char	szExp[10];     /* �����κ� ���ڿ� */
	char	szMent[41];   /* Mentissa �κ� ���ڿ� */
	int		iExp;         /* ���� */
	int		iNegative;    /* ���������� ��Ÿ���� ���� */
	int		iExpWidth;    /* ������ ��Ÿ�������� �ʿ��� �ڸ��� */
	int		iIntLength;   /* �����κ� �ڸ��� */
	int		iMentWidth;   /* Mentissa �κ� �ڸ���  */
	double  fMent;		  /* Mentissa value  */
	int		i, j; 

	memcpy(&fNum, &lBasicDevVal, 4);

	/* If the number is of infinity or NaN, fill with 'H' */ 
	if( (lBasicDevVal & 0x7f800000) == 0x7f800000) {  /* exp = 0xFF */
		if( (lBasicDevVal & 0x007fffff) == 0 ) { /* Mentissa = 0 */
			 /* infinity */
		}
		else {
			/* NaN : Not a number */
		}
		for(i=0; i<iDigits; i++) 
			szReturnStr[i] = 'H';
		szReturnStr[i] = 0;
		return;
	}
	if( ((lBasicDevVal & 0x7f800000) == 0) 
			 && ((lBasicDevVal & 0x007fffff) != 0)) {  /* exp = 0x00 &&  Mentissa != 0 */
		for(i=0; i<iDigits; i++)           /* Denormalized number */
			szReturnStr[i] = '0';          /* fill with zero */
		szReturnStr[i] = 0;
		return;
	}

  	szReturnStr[0]=0;
/*	sprintf(szNum, "%E", fNum);*/		/* ��ȯ�� �Ǽ��� �ε��Ҽ��� �������� ����Ʈ */
	ParcentEProc(szNum,fNum);
/*	ChangeShou(szNum);*/				/* ����?�ύX�i��?���D�j2008.09.08 */
	iNegative= (szNum[0]=='-')?1:0; /* �����̸� szNum[0]=='-', iNegative=1, ������ �ƴϸ� iNegative=0*/

	for(i=0; szNum[i]!='E'; i++){
		if(szNum[i] == 0){	break;	}		/* 2008.09.09 */
		szMent[i] = szNum[i];
	}
	szMent[i] = 0;
	fMent = (double)gatof(szMent); /* Mentissa value  */

	/* ����(iExp)�� �������ڿ�(szExp)�� ���� */
	i++;
	for(j=0; szNum[i+j]!=0; j++)	szExp[j] = szNum[i+j];
	szExp[j] = szNum[i+j];
	iExp = gatoi(szExp);
	sprintf(szExp,"%d",iExp);

	if(iExp>=0) { /* larger than 1 */
		iIntLength = iExp+iNegative+1;
		if(iDigits>=iIntLength)  /* �����Ҽ��� ������� ����Ʈ */
			SPrintDecimalPointForm(szReturnStr, fNum, iDigits, iDecimalPoint, iIntLength);
		else  {
			iExpWidth = (iExp>9)?3:2; /* ������ ���ڸ����̸� ������ �����ϴ� ������ 3�ڸ�(E����) */
			iMentWidth = iDigits-iExpWidth;
			if(iMentWidth<0 || (iMentWidth==0 && iNegative) ) {
				if(iNegative)
					for(i=0; i<iDigits;i++) szReturnStr[i]='L';
				else
					for(i=0; i<iDigits;i++) szReturnStr[i]='H';
				szReturnStr[i]=0;
			}
			else {
				iIntLength = iNegative+1;
				if(iMentWidth>=iIntLength) { /* �����Ҽ��� ������� ����Ʈ */
					SPrintDecimalPointForm(szReturnStr, fMent, iMentWidth, iDecimalPoint, iIntLength);
				}
				else {
					if(iNegative) 
						strcpy(szReturnStr,"-");
				}
				strcat(szReturnStr,"E");
				strcat(szReturnStr, szExp);
			}
		}
	}
	else if(iExp>-3) { /* ������ -3���� ū ���� �����Ҽ������� ����Ʈ�� */
		iIntLength = iNegative+1;
		if(iDigits>=iIntLength) { /* �����Ҽ��� ������� ����Ʈ */
			SPrintDecimalPointForm(szReturnStr, fNum, iDigits, iDecimalPoint, iIntLength);
		}
		else { /* Negative & iDigits==1 */
			sprintf(szReturnStr, "%s", "L");
		}
	}
	else {/* ������ -3 ���� ���� �ε��Ҽ������� ����Ʈ�� */
		iExpWidth = (iExp<-9)?4:3; /*������ ���ڸ����̸� ������ �����ϴ� ������ 4�ڸ�(E-����) */ 
		iMentWidth = iDigits-iExpWidth;
		if(iMentWidth<0 || (iMentWidth==0 && iNegative)) {
			for(i=0; i<iDigits;i++) szReturnStr[i]='0';
			szReturnStr[i]=0;
		}
		else {
			iIntLength = iNegative+1;
			if(iMentWidth>=iIntLength) { /* �����Ҽ��� ������� ����Ʈ */
				SPrintDecimalPointForm(szReturnStr, fMent, iMentWidth, iDecimalPoint, iIntLength);
			}
			else {
				if(iNegative) 
					strcpy(szReturnStr,"-");
			}
			strcat(szReturnStr,"E");
			strcat(szReturnStr, szExp);
		}
	}
}

/* SPrintDecimalPointForm 
 J.S.LIM 2004/06/04   
 used in printing Real numbers */
void SPrintDecimalPointForm(char *cTempBuffer, double fNum, int iDigits, int iDecimalPoint, int iIntLength)
{
/*	char szForm[40];*/
/*	int  iPFr, i;*/
	int  i;

	if(iIntLength==iDigits || iIntLength == iDigits-1) 
		sprintf(cTempBuffer, "%d", (int)fNum);
	else {
/*		iPFr = iDigits-iIntLength-1;*/
/*		if(iDecimalPoint<=iPFr) {*/
/*			sprintf(szForm,"%%-%d.%df", iDigits, iDecimalPoint);*/
/*			sprintf(cTempBuffer, szForm, fNum);*/
/*			ChangeShou(cTempBuffer);*/				/* ����?�ύX�i��?���D�j2008.09.08 */
			ParcentfProc(cTempBuffer,(float)fNum,iDigits,iDecimalPoint);
/*			for(i=0; cTempBuffer[i] != ' ' && cTempBuffer[i] != 0; i++);*/
			for(i=0; cTempBuffer[i] != 0; i++);
			cTempBuffer[i]=0;
/*		}*/
/*		else {*/
/*			sprintf(szForm,"%%%d.%df", iDigits, iPFr);*/
/*			sprintf(cTempBuffer, szForm, fNum);*/
/*			ChangeShou(cTempBuffer);*/				/* ����?�ύX�i��?���D�j2008.09.08 */
/*		}*/
	}
}
int	NumericalInputTouchCheck(int iOrder)
{
	short			RetVal;
	unsigned int iTriggerDevVal;

	_NUMERIC_INPUT_EVENT_TBL*	 NumericInputEventTbl;

	RetVal = OFF;
	NumericInputEventTbl= (_NUMERIC_INPUT_EVENT_TBL*)TakeMemory(sizeof(_NUMERIC_INPUT_EVENT_TBL));
	DrawNumericInput_Func(1,NumericInputEventTbl,iOrder);

	/* NOTORDINARY�̎��L�������m�F���� */
	ScreenTagData[iOrder].uu.NumIn.iTriggerVal = ON;
	if(ScreenTagData[iOrder].uu.NumIn.iTriggerTypeVal != 2){
		iTriggerDevVal = (unsigned int)DeviceData[ScreenTagData[iOrder].uu.NumIn.iBStartDataPos];
		if(ScreenTagData[iOrder].uu.NumIn.iTriggerTypeVal == ON){
			if(iTriggerDevVal == OFF){
				ScreenTagData[iOrder].uu.NumIn.iTriggerVal = OFF;
			}
		}else{
			if(iTriggerDevVal == ON){
				ScreenTagData[iOrder].uu.NumIn.iTriggerVal = OFF;
			}
		}
	}
/***********************************************************/
	if(Key.iBuff > 0 && !(InputDisplay.iKeyOnOff == 2 &&
		InputDisplay.iInputNo == iOrder) &&
		ScreenTagData[iOrder].uu.NumIn.iTriggerVal == ON)
	{
		if((CommonArea.ProjectAuxSet.OpenKeyWinCkeck == 0xff)) /* || (CommonArea.ProjectAuxSet.DispCursorWindow == 0x02)*/
		{
			if(TouchAreaCheck(ScreenTagData[iOrder].sX,
							  ScreenTagData[iOrder].sY, 
							  ScreenTagData[iOrder].eX, 
							  ScreenTagData[iOrder].eY,
							  Key.iBuff) == 1){
				RetVal = ON;
				ScreenTagData[iOrder].UpdateFlag= 1;
				Key.iBuff = 0;
				iPassFlag = 0;
				InputDisplay.iKeyOnOff = 1;
				InputDisplay.iInputNo = iOrder;
				InputDisplay.iFirstflag = 0;
				NumericInputWatch(1,iOrder,NumericInputEventTbl->cTempBuffer);
				memset(InputDisplay.cInputDispBuff,0x00,41);		/* strlen(InputDisplay.cInputDispBuff)-> 41 */
				memcpy(InputDisplay.cInputDispBuff, NumericInputEventTbl->cTempBuffer,
								NumericInputEventTbl->iDigits);

				if(NumericInputEventTbl->iFormFormat == HEXA_DECIMAL)
					CommonArea.KeyWindow.iKeyType = KEY_HEX;		/* HEXA Type */
				else if(NumericInputEventTbl->iFormFormat == OCTAL)
					CommonArea.KeyWindow.iKeyType = KEY_OCTAL;		/* OCTAL Type */
				else if(NumericInputEventTbl->iFormFormat == BINARY)
					CommonArea.KeyWindow.iKeyType = KEY_BINARY;		/* BINARY Type */
				else if(NumericInputEventTbl->iFormFormat == REAL)
					CommonArea.KeyWindow.iKeyType = KEY_REAL;		/* REAL Type */
				else
					CommonArea.KeyWindow.iKeyType = KEY_DECIMAL;	/* DESIMAL Type */					
			}
		}else if((!(InputDisplay.iKeyOnOff == 3 && InputDisplay.iInputNo == iOrder)) && (CommonArea.ProjectAuxSet.DispCursorWindow == 0x00))
		{   
			if(TouchAreaCheck(ScreenTagData[iOrder].sX,
							  ScreenTagData[iOrder].sY, 
							  ScreenTagData[iOrder].eX, 
							  ScreenTagData[iOrder].eY,
							  Key.iBuff) == 1)
			{
				Key.iBuff = 0;
				iPassFlag = 0;
				InputDisplay.iKeyOnOff = 3;
				InputDisplay.iInputNo = iOrder;
				ScreenTagData[iOrder].UpdateFlag= 1;
				RetVal = ON;
			}
		}
	}else if(ScreenTagData[iOrder].uu.NumIn.iTriggerVal == OFF &&
				TouchAreaCheck(ScreenTagData[iOrder].sX,
							  ScreenTagData[iOrder].sY, 
							  ScreenTagData[iOrder].eX, 
							  ScreenTagData[iOrder].eY,
							  Key.iBuff) == 1)
	{
		ErrorBuzzer();
		Key.iBuff = 0;
		iPassFlag = 0;
	}else if(TouchAreaCheck(ScreenTagData[iOrder].sX,
							  ScreenTagData[iOrder].sY, 
							  ScreenTagData[iOrder].eX, 
							  ScreenTagData[iOrder].eY,
							  Key.iBuff) == 1){
		Key.iBuff = 0;	
		iPassFlag = 0;
	}
	if(InputDisplay.iKeyOnOff == 2 && InputDisplay.iInputNo == iOrder && !(Key.iBuff == 0))
	{
		if(strcmp(InputDisplay.cBufferData,InputDisplay.cInputDispBuff) != 0){
			memcpy(InputDisplay.cBufferData,InputDisplay.cInputDispBuff,sizeof(InputDisplay.cInputDispBuff));
			ScreenTagData[iOrder].UpdateFlag= 1;
			RetVal = ON;
		}
	}
	FreeMail((char *)NumericInputEventTbl);
	return(RetVal);
}
