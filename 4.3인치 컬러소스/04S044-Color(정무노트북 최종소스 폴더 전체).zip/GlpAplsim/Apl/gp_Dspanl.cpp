/********************************************************************************/
/* �� �� ��E: Sgt.cpp															*/
/* ��E   �� : ���� TASK ��?E													*/
/* �� �� �� : 2002��E2��E7�� (��E												*/
/* �� �� �� : ȫ �� ��E															*/
/* ��    �� : (��) LC Tech														*/
/* ��E   ��E: 																	*/
/* User Input Proc																*/
/********************************************************************************/
#include	"sgt.h"

/********************************************************************************/
/* �� �� �� : UpDownTouchDiplay													*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 9�� 24�� (ȭ)												*/
/* �� �� �� : �� �� �� 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetNextWindow(int mode,int i,_NUMERIC_INPUT_EVENT_TBL *NumericInputEventTbl_Buff,_ASCIIINPUT_EVENT_TBL *AsciiInputEventTbl_Buff)
{
	InputDisplay.iInputNo = i;
	InputDisplay.iKeyOnOff = 1;
	CloseWindow(SCREEN_1);
	WindowPointDel();
	vWindowFreemeil();

	if(mode == 0){
		NumericInputWatch(1,i,NumericInputEventTbl_Buff->cTempBuffer);
		memset(InputDisplay.cInputDispBuff,0x00,41);		/* strlen(InputDisplay.cInputDispBuff)-> 41 */
		memcpy(InputDisplay.cInputDispBuff, NumericInputEventTbl_Buff->cTempBuffer,
					NumericInputEventTbl_Buff->iDigits);

		if(NumericInputEventTbl_Buff->iFormFormat == HEXA_DECIMAL)
			CommonArea.KeyWindow.iKeyType = KEY_HEX;		/* HEXA Type */
		else if(NumericInputEventTbl_Buff->iFormFormat == OCTAL)
			CommonArea.KeyWindow.iKeyType = KEY_OCTAL;		/* OCTAL Type */
		else if(NumericInputEventTbl_Buff->iFormFormat == BINARY)
			CommonArea.KeyWindow.iKeyType = KEY_BINARY;		/* BINARY Type */
		else if(NumericInputEventTbl_Buff->iFormFormat == REAL)
			CommonArea.KeyWindow.iKeyType = KEY_REAL;		/* REAL Type */
		else
			CommonArea.KeyWindow.iKeyType = KEY_DECIMAL;	/* DESIMAL Type */
	}else{
		memcpy(InputDisplay.cInputDispBuff,&DispDeviceData[ScreenTagData[i].DevOrder],AsciiInputEventTbl_Buff->iDigits);
/*
		memcpy(InputDisplay.cInputDispBuff, AsciiInputEventTbl_Buff->cBefDevData,
			AsciiInputEventTbl_Buff->iDigits);
*/
		CommonArea.KeyWindow.iKeyType = KEY_ASCII; /* 3 : Ascii Type */
	}
}
int	GetUsrId(int mode,int No)
{
	int		ret;
	int		idx;
	unsigned char	*buffer;

	idx= 26;
	if(mode == 0){
		idx++;
	}
	buffer= ScreenTagData[No].TagPos;
	/* Others�ǿ��� Userid 27-28 */
	ret  = (unsigned int)(buffer[idx++] << 0x08);/* iUser_id = 0xFF�̸� üũ���� ����*/
	ret += (unsigned int)buffer[idx] & 0xff;
	return(ret);
}
int	GetMoveDestId(int mode,int No)
{
	int		idx;
	int		ret;
	unsigned char	*buffer;

	idx= 28;
	if(mode == 0){
		idx++;
	}
	buffer= ScreenTagData[No].TagPos;
	/* Others�ǿ��� Userid 27-28 */
	ret  = (unsigned int)(buffer[idx++] << 0x08);/* iUser_id = 0xFF�̸� üũ���� ����*/
	ret += (unsigned int)buffer[idx] & 0xff;
	return(ret);
}
int UpDownTouchDiplay(int iUpDown)
{
	int		iReturnVal;
	int		i;
	int		iUser_id;
	int		iMoveDest_id;
/*	_NUMERIC_INPUT_EVENT_TBL*	 NumericInputEventTbl;
	_ASCIIINPUT_EVENT_TBL*		AsciiInputEventTbl;
*/
	_NUMERIC_INPUT_EVENT_TBL*	 NumericInputEventTbl_Buff;
	_ASCIIINPUT_EVENT_TBL*		AsciiInputEventTbl_Buff;

	iReturnVal = 1;		/* ENT��L���ɂ��� 050421 */
	if(iUpDown == 1) /* Numerical input [UP_KEY] */
	{
/*		NumericInputEventTbl = (_NUMERIC_INPUT_EVENT_TBL*)IventTable[InputDisplay.iInputNo];*/
		iUser_id= GetUsrId(0,InputDisplay.iInputNo);
/*		for(i=0;IventTableCnt>i;i++){*/
		for(i= 0; i < iDispOrder; i++){
			if(ScreenTagData[i].cObjects==NUMERICAL_INPUT){

/*				NumericInputEventTbl_Buff = (_NUMERIC_INPUT_EVENT_TBL*)IventTable[i];*/
				iMoveDest_id= GetMoveDestId(0,i);
/*				if(NumericInputEventTbl->iUser_id == 
					NumericInputEventTbl_Buff->iMoveDest_id)*/
//2011.09.19				if(iUser_id == iMoveDest_id)
				if((iUser_id == iMoveDest_id) && (iUser_id != 65535) )
				{
					NumericInputEventTbl_Buff= (_NUMERIC_INPUT_EVENT_TBL*)TakeMemory(sizeof(_NUMERIC_INPUT_EVENT_TBL));
					DrawNumericInput_Func(1,NumericInputEventTbl_Buff,i);
					SetNextWindow(0,i,NumericInputEventTbl_Buff,NULL);
					iReturnVal = 2;
					FreeMail((char *)NumericInputEventTbl_Buff);
					break;
				}
			}else if(ScreenTagData[i].cObjects==ASCII_INPUT){
/*				AsciiInputEventTbl_Buff = (_ASCIIINPUT_EVENT_TBL*)IventTable[i];*/
				iMoveDest_id= GetMoveDestId(1,i);
/*				if(NumericInputEventTbl->iUser_id == 
					AsciiInputEventTbl_Buff->iMoveDest_id)
*/
//2011.09.19				if(iUser_id == iMoveDest_id)
				if( (iUser_id == iMoveDest_id) && (iUser_id != 65535) )
				{
					AsciiInputEventTbl_Buff= (_ASCIIINPUT_EVENT_TBL*)TakeMemory(sizeof(_ASCIIINPUT_EVENT_TBL));
					DrawAsciiInput_Func(1,AsciiInputEventTbl_Buff,i);
					SetNextWindow(1,i,NULL,AsciiInputEventTbl_Buff);
					iReturnVal = 2;
					FreeMail((char *)AsciiInputEventTbl_Buff);
					break;
				}
			}
		}
	}
	else if(iUpDown == 2) /*Numerical input  DOWN_KEY  */
	{
/*		NumericInputEventTbl = (_NUMERIC_INPUT_EVENT_TBL*)IventTable[InputDisplay.iInputNo];*/
		iMoveDest_id= GetMoveDestId(0,InputDisplay.iInputNo);
/*		for(i=0;IventTableCnt>i;i++){*/
		for(i= 0; i < iDispOrder; i++){
			if(ScreenTagData[i].cObjects==NUMERICAL_INPUT){

/*				NumericInputEventTbl_Buff = (_NUMERIC_INPUT_EVENT_TBL*)IventTable[i];*/
				iUser_id= GetUsrId(0,i);

/*				if(NumericInputEventTbl_Buff->iUser_id == 
					NumericInputEventTbl->iMoveDest_id)
*/
				if(iUser_id == iMoveDest_id)
				{
					NumericInputEventTbl_Buff= (_NUMERIC_INPUT_EVENT_TBL*)TakeMemory(sizeof(_NUMERIC_INPUT_EVENT_TBL));
					DrawNumericInput_Func(1,NumericInputEventTbl_Buff,i);
					SetNextWindow(0,i,NumericInputEventTbl_Buff,NULL);
					iReturnVal = 2;
					FreeMail((char *)NumericInputEventTbl_Buff);
					break;
				}
			}else if(ScreenTagData[i].cObjects==ASCII_INPUT){
/*				AsciiInputEventTbl_Buff = (_ASCIIINPUT_EVENT_TBL*)IventTable[i];*/
				iUser_id= GetUsrId(0,i);
/*
				if(AsciiInputEventTbl_Buff->iUser_id == 
					NumericInputEventTbl->iMoveDest_id)
*/
				if(iUser_id == iMoveDest_id)
				{
					AsciiInputEventTbl_Buff= (_ASCIIINPUT_EVENT_TBL*)TakeMemory(sizeof(_ASCIIINPUT_EVENT_TBL));
					DrawAsciiInput_Func(1,AsciiInputEventTbl_Buff,i);
					SetNextWindow(1,i,NULL,AsciiInputEventTbl_Buff);
					iReturnVal = 2;
					FreeMail((char *)AsciiInputEventTbl_Buff);
					break;
				}
			}
		}
	}else if(iUpDown == 3) /*ascii input [UP_KEY] */
	{
/*		AsciiInputEventTbl = (_ASCIIINPUT_EVENT_TBL*)IventTable[InputDisplay.iInputNo];*/
		iUser_id= GetUsrId(1,InputDisplay.iInputNo);
/*		for(i=0;IventTableCnt>i;i++){*/
		for(i= 0; i < iDispOrder; i++){
			if(ScreenTagData[i].cObjects==NUMERICAL_INPUT){
/*
				NumericInputEventTbl_Buff = (_NUMERIC_INPUT_EVENT_TBL*)IventTable[i];
				if(AsciiInputEventTbl->iUser_id == 
					NumericInputEventTbl_Buff->iMoveDest_id)
*/
				iMoveDest_id= GetMoveDestId(0,i);
				if(iUser_id == iMoveDest_id)
				{
					NumericInputEventTbl_Buff= (_NUMERIC_INPUT_EVENT_TBL*)TakeMemory(sizeof(_NUMERIC_INPUT_EVENT_TBL));
					DrawNumericInput_Func(1,NumericInputEventTbl_Buff,i);
					SetNextWindow(0,i,NumericInputEventTbl_Buff,NULL);
					iReturnVal = 2;
					FreeMail((char *)NumericInputEventTbl_Buff);
					break;
				}
			}else if(ScreenTagData[i].cObjects==ASCII_INPUT){
/*
				AsciiInputEventTbl_Buff = (_ASCIIINPUT_EVENT_TBL*)IventTable[i];
				if(AsciiInputEventTbl->iUser_id == 
					AsciiInputEventTbl_Buff->iMoveDest_id)
*/
				iMoveDest_id= GetMoveDestId(1,i);
				if(iUser_id == iMoveDest_id)
				{
					AsciiInputEventTbl_Buff= (_ASCIIINPUT_EVENT_TBL*)TakeMemory(sizeof(_ASCIIINPUT_EVENT_TBL));
					DrawAsciiInput_Func(1,AsciiInputEventTbl_Buff,i);
					SetNextWindow(1,i,NULL,AsciiInputEventTbl_Buff);
					iReturnVal = 2;
					FreeMail((char *)AsciiInputEventTbl_Buff);
					break;
				}
			}
		}
	}
	else if(iUpDown == 4) /*Ascii input  DOWN_KEY  */
	{
/*		AsciiInputEventTbl = (_ASCIIINPUT_EVENT_TBL*)IventTable[InputDisplay.iInputNo];*/
		iMoveDest_id= GetMoveDestId(1,InputDisplay.iInputNo);
/*		for(i=0;IventTableCnt>i;i++){*/
		for(i= 0; i < iDispOrder; i++){
			if(ScreenTagData[i].cObjects==NUMERICAL_INPUT){
/*
				NumericInputEventTbl_Buff = (_NUMERIC_INPUT_EVENT_TBL*)IventTable[i];
				if(NumericInputEventTbl_Buff->iUser_id == 
					AsciiInputEventTbl->iMoveDest_id)
*/
				iUser_id= GetUsrId(0,i);
				if(iUser_id == iMoveDest_id)
				{
					NumericInputEventTbl_Buff= (_NUMERIC_INPUT_EVENT_TBL*)TakeMemory(sizeof(_NUMERIC_INPUT_EVENT_TBL));
					DrawNumericInput_Func(1,NumericInputEventTbl_Buff,i);
					SetNextWindow(0,i,NumericInputEventTbl_Buff,NULL);
					iReturnVal = 2;
					FreeMail((char *)NumericInputEventTbl_Buff);
					break;
				}
			}else if(ScreenTagData[i].cObjects==ASCII_INPUT){
/*
				AsciiInputEventTbl_Buff = (_ASCIIINPUT_EVENT_TBL*)IventTable[i];
				if(AsciiInputEventTbl_Buff->iUser_id == 
					AsciiInputEventTbl->iMoveDest_id)
*/
				iUser_id= GetUsrId(1,i);
				if(iUser_id == iMoveDest_id)
				{
					AsciiInputEventTbl_Buff= (_ASCIIINPUT_EVENT_TBL*)TakeMemory(sizeof(_ASCIIINPUT_EVENT_TBL));
					DrawAsciiInput_Func(1,AsciiInputEventTbl_Buff,i);
					SetNextWindow(1,i,NULL,AsciiInputEventTbl_Buff);
					iReturnVal = 2;
					FreeMail((char *)AsciiInputEventTbl_Buff);
					break;
				}
			}
		}
	}
	return	iReturnVal;
}
int	GetNumericInputFormat(int No)
{
	int		iFormFormat;
	int		idx;
	unsigned char	*buffer;

	idx= 23;
	buffer= ScreenTagData[No].TagPos;

	if(((unsigned int)buffer[idx] & 0x50) == 0x50)
	{
		iFormFormat = OCTAL;
	}else if(((unsigned int)buffer[idx] & 0x40) == 0x40){
		iFormFormat = REAL;
	}else if(((unsigned int)buffer[idx] & 0x30) == 0x30){
		iFormFormat = HEXA_DECIMAL;
	}else if(((unsigned int)buffer[idx] & 0x20) == 0x20){
		iFormFormat = UNSIGNED_DECIMAL;
	}else if(((unsigned int)buffer[idx] & 0x10) == 0x10){
		iFormFormat = SIGNED_DECIMAL;
	}else{
		iFormFormat = BINARY;
	}
	return(iFormFormat);
}
int	StringLargCmp(char *src,char *obj)
{
	int		ret;
	int		i;

	ret= strlen(src)- strlen(obj);
	if(ret == 0){
		for(i = 0; i < (signed)strlen(src); i++){
			if(src[i] > obj[i]){
				ret= 1;
				break;
			}else if(src[i] < obj[i]){
				ret= -1;
				break;
			}
		}
	}
	return(ret);
}
unsigned long	atoul(char *buff)
{
	unsigned long value;
	int		i;

	value= 0;
	for(i= 0;;i++){
		if(buff[i] == 0){
			break;
		}
		value *= 10;
		if((buff[i] >= '0') && (buff[i] <= '9')){
			value += buff[i]- '0';
		}
	}
	return(value);
}
void	ChangeLowHighByte(char *buff,int cnt)
{
	int	i;
	char	ch;

	if(cnt %2){		cnt++;	}
	for(i= 0; i < cnt/2; i++){
		ch= buff[i*2];
		buff[i*2]= buff[i*2+1];
		buff[i*2+1]= ch;
	}
}
/********************************************************************************/
/* �� �� �� : InputNumberDisplaySetting											*/
/* ��    �� : �������̽��� ����̽���Ī�� Size�� �����Ѵ�.					*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 9�� 24�� (ȭ)												*/
/* �� �� �� : �� �� �� 															*/
/* ��    �� : 																	*/
/********************************************************************************/
int InputNumberDisplaySetting(void)
{
	char				cBuff[2];
	long				lNowNum;
	short				slNowNum;
	unsigned long		ulNowNum;
	float				fNowNum;
	unsigned int		iLen;
	char*				cDataBuff;
	char*				cRealCheng;
	char				wData[16];	
	int					iCode;
	unsigned int		i;
	long				iMax;
	long				iMin;
	unsigned long		uiMax;
	unsigned long		uiMin;
	int					iReturnVal;
	short				iEndFlag;
	short				iErrorCode;
	DEV_DATA			WriteDev;
	_NUMERIC_INPUT_EVENT_TBL*	 NumericInputEventTbl;
	_ASCIIINPUT_EVENT_TBL*		AsciiInputEventTbl;
	int					OverFlag;
	char *workData;
	int	cnt;

	
	iErrorCode = 0;
	iReturnVal = 1;
	iMin = -32768;
	iMax = 32767;
	uiMin = 0;
	uiMax = 65535;
/*	unsigned diMax = 0xffffffff;*/
	iCode = 0;
	cDataBuff = (char*)TakeMemory(12);
	memset(cDataBuff,0x00,12);
	memset(cBuff,0x00,2);
	memset(wData,0x00,4);
	if(NumericInputCnt > 0 && ScreenTagData[InputDisplay.iInputNo].cObjects == NUMERICAL_INPUT)
	{
/*		NumericInputEventTbl= (_NUMERIC_INPUT_EVENT_TBL*)IventTable[InputDisplay.iInputNo];*/
		NumericInputEventTbl= (_NUMERIC_INPUT_EVENT_TBL*)TakeMemory(sizeof(_NUMERIC_INPUT_EVENT_TBL));
		DrawNumericInput_Func(1,NumericInputEventTbl,InputDisplay.iInputNo);
		switch(NumericInputEventTbl->iFormFormat ){
				case	SIGNED_DECIMAL:
				case	UNSIGNED_DECIMAL:
				case	REAL:	
				case	HEXA_DECIMAL:
					iCode = 0x39;
					break;
				case	OCTAL:
					iCode = 0x37;
					break;

				case	BINARY:
					iCode = 0x31;
					break;
		}
		if((iMainKeyCode>=0x30 && iMainKeyCode<=iCode) || 
			((iMainKeyCode>=0x41 && iMainKeyCode <= 0x46) && NumericInputEventTbl->iFormFormat == HEXA_DECIMAL) ||
			((NumericInputEventTbl->iFormFormat == REAL) && (iMainKeyCode == 0x2E || iMainKeyCode == 0x2D || iMainKeyCode == 0x45) ) )
		{	
			iEndFlag = 0;
			if(InputDisplay.iFirstflag == 0)
			{
				memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
			}
			if(NumericInputEventTbl->iFormFormat == REAL)
			{
				iLen = strlen(InputDisplay.cInputDispBuff);
				if(iMainKeyCode==0x2E)			/* . */
				{
					if(!(strchr(InputDisplay.cInputDispBuff,iMainKeyCode)))	/* ���� ���� ��� */
					{
						if(iLen == 0)			/* ó������ ��(.) ������� */
						{
							InputDisplay.cInputDispBuff[0] = 0x30;
						}else if(iLen == 1 && InputDisplay.cInputDispBuff[0] == 0x2D)
						{
							InputDisplay.cInputDispBuff[1] = 0x30;
						}
					}else													/* ���� ���� ��� */
					{
						iEndFlag = 1;
					}
				}else if(iMainKeyCode==0x2D)	/* - */
				{
					if(iLen != 0)
					{
						if(!(InputDisplay.cInputDispBuff[iLen-1] == 0x45))
							iEndFlag = 1;
					}
				}else if(iMainKeyCode==0x45)	/* E */
				{
					if(strchr(InputDisplay.cInputDispBuff,iMainKeyCode))	/* ���� ���� ��� */
						iEndFlag = 1;
				}
			}
			if(iEndFlag == 0){
				cBuff[0] = (char)iMainKeyCode;
				if(NumericInputEventTbl->i1632BitFlag == 0){
					switch(NumericInputEventTbl->iFormFormat )
					{
					case	SIGNED_DECIMAL:		iLen = 6;	break;						
					case	UNSIGNED_DECIMAL:	iLen = 5;	break;
					case	REAL:				iLen = 16;	break;
					case	HEXA_DECIMAL:		iLen = 4;	break;
					case	OCTAL:				iLen = 6;	break;
					case	BINARY:				iLen = 16;	break;
					}
				}else{
					switch(NumericInputEventTbl->iFormFormat )
					{
						case	SIGNED_DECIMAL:		iLen = 11;	break;						
						case	UNSIGNED_DECIMAL:	iLen = 11;	break;
						case	REAL:				iLen = 16;	break;
						case	HEXA_DECIMAL:		iLen = 8;	break;
						case	OCTAL:				iLen = 11;	break;
						case	BINARY:				iLen = 32;	break;
					}
				}
				if(strlen(InputDisplay.cInputDispBuff) >= iLen)
				{
					memcpy(cDataBuff,InputDisplay.cInputDispBuff+1,iLen-1);
					memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
					memcpy(InputDisplay.cInputDispBuff,cDataBuff,iLen-1);
				}
				iLen = strlen(InputDisplay.cInputDispBuff);

				if(InputDisplay.cInputDispBuff[0] == 0x30 && iLen > 0 && NumericInputEventTbl->iFormFormat != BINARY)
				{
					if(!((iLen == 1 && cBuff[0] == 0x2E) || (iLen > 1 && InputDisplay.cInputDispBuff[1] == 0x2E)))
					{
						for(i=0;i<iLen;i++)
						{
							memcpy(cDataBuff,InputDisplay.cInputDispBuff+1,iLen-(1+i));
							memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
							memcpy(InputDisplay.cInputDispBuff,cDataBuff,iLen-(1+i));
							if(InputDisplay.cInputDispBuff[0] != 0x30)
								break;
						}
					}
				}
				if(!(cBuff[0] == 0x30 && (InputDisplay.cInputDispBuff[0] == 0x2D && iLen == 1)))
					strcat(InputDisplay.cInputDispBuff, cBuff);
				else
					strcpy(InputDisplay.cInputDispBuff, cBuff);
				iMainKeyCode = 0x0000;
				InputDisplay.iFirstflag = 1;
			}else							/* ���� �޼��� ��� */
			{
					ComWinKey.iVal = 2;

					if(TateYoko == 0){
						cRealCheng = (char *)TakeMemory(21);
						memset(cRealCheng,0x00,21);
#ifdef	GP_S057
						sprintf(cRealCheng,"%s%s",Dspname[WINDOW_SCREEN].chName[Set.iLang][0],Dspname[WINDOW_SCREEN].chName[Set.iLang][4]);
#endif
#ifdef	LP_S044
						sprintf(cRealCheng,"%s%s",Dspname[WINDOW_SCREEN].chName[Set.iLang][0],Dspname[WINDOW_SCREEN].chName[Set.iLang][1]);
#endif
#ifdef	GP_S044
						sprintf(cRealCheng,"%s%s",Dspname[WINDOW_SCREEN].chName[Set.iLang][0],Dspname[WINDOW_SCREEN].chName[Set.iLang][1]);
#endif
						iCaptionVerticalWindow(cRealCheng,"","","","");			/*  ��ư �ϳ��� �޼��� �ڽ�	 */	
						FreeMail((char *)cRealCheng);
					}else
					{
#ifdef	GP_S057
						iCaptionVerticalWindow("",Dspname[WINDOW_SCREEN].chName[Set.iLang][0],Dspname[WINDOW_SCREEN].chName[Set.iLang][4],"","");
#endif
#ifdef	LP_S044
						iCaptionVerticalWindow("",Dspname[WINDOW_SCREEN].chName[Set.iLang][0],Dspname[WINDOW_SCREEN].chName[Set.iLang][1],"","");
#endif
#ifdef	GP_S044
						iCaptionVerticalWindow("",Dspname[WINDOW_SCREEN].chName[Set.iLang][0],Dspname[WINDOW_SCREEN].chName[Set.iLang][1],"","");
#endif
					}

					ComWinKey.iVal = 0;
			}
		}else if(iMainKeyCode == ENT) /* ENT */
		{
/* 071108			if((ScreenTagData[iScreenPosition].uu.NumIn.iTriggerVal == ON) || */
			if((ScreenTagData[InputDisplay.iInputNo].uu.NumIn.iTriggerVal == ON) ||
				(Screen[iScreenPosition].iDefKeyAct == 0x02) ||		/* 040924 Add */
				(Screen[iScreenPosition].iDefKeyAct == 0x03)){		/* 040924 Add */
				if(NumericInputEventTbl->i1632BitFlag == 0){		/* 16bit */
					cnt = 2;	/* 20080822 */
					if(NumericInputEventTbl->iUpperFlag == FIXED)
						iMax = NumericInputEventTbl->iUpperFixedVal;
					else
					{
/* 071107 */
/*						memcpy(cDataBuff,
							DeviceDataHed[NumericInputEventTbl->iUpperRegistNumber].DevData,
							10);
*/
						memcpy(cDataBuff,&DeviceData[ScreenTagData[InputDisplay.iInputNo].DevOrder+cnt],10);	/* 20080822 */
						iMax = ChangeChar2long(cDataBuff,NumericInputEventTbl->i1632BitFlag);
						cnt += 2;	/* 20080822 */
					}
					if(NumericInputEventTbl->iLowerFlag == FIXED)
						iMin = NumericInputEventTbl->iLowerFixedVal;
					else
					{
/* 071107 */
/*						memcpy(cDataBuff,
							DeviceDataHed[NumericInputEventTbl->iLowerRegistNumber].DevData,
							10);
*/
						memcpy(cDataBuff,&DeviceData[ScreenTagData[InputDisplay.iInputNo].DevOrder+cnt],10);	/* 20080822 */
						iMin = ChangeChar2long(cDataBuff,NumericInputEventTbl->i1632BitFlag);
					}
				}else{		/* 32Bit */
					if(NumericInputEventTbl->iFormFormat == SIGNED_DECIMAL){
						cnt = 4;	/* 20080822 */
						if(NumericInputEventTbl->iUpperFlag == FIXED)
							iMax = NumericInputEventTbl->iUpperFixedVal;
						else
						{
/* 071107 */
/*							memcpy(cDataBuff,
								DeviceDataHed[NumericInputEventTbl->iUpperRegistNumber].DevData,
								10);
*/
							memcpy(cDataBuff,&DeviceData[ScreenTagData[InputDisplay.iInputNo].DevOrder+cnt],10);	/* 20080822 */
							iMax = ChangeChar2long(cDataBuff,NumericInputEventTbl->i1632BitFlag);
							cnt += 4;	/* 20080822 */
						}
						if(NumericInputEventTbl->iLowerFlag == FIXED)
							iMin = NumericInputEventTbl->iLowerFixedVal;
						else
						{
/* 071107 */
/*							memcpy(cDataBuff,
								DeviceDataHed[NumericInputEventTbl->iLowerRegistNumber].DevData,
								10);
*/
							memcpy(cDataBuff,&DeviceData[ScreenTagData[InputDisplay.iInputNo].DevOrder+cnt],10);	/* 20080822 */
							iMin = ChangeChar2long(cDataBuff,NumericInputEventTbl->i1632BitFlag);
						}
					}else{
						cnt = 4;	/* 20080822 */
						if(NumericInputEventTbl->iUpperFlag == FIXED)
							uiMax = NumericInputEventTbl->iUpperFixedVal;
						else
						{
/* 071107	*/
/*							memcpy(cDataBuff,DeviceDataHed[NumericInputEventTbl->iUpperRegistNumber].DevData,10);	*/
							memcpy(cDataBuff,&DeviceData[ScreenTagData[InputDisplay.iInputNo].DevOrder+cnt],10);	/* 20080822 */
							uiMax = ChangeChar2long(cDataBuff,NumericInputEventTbl->i1632BitFlag);
							cnt += 4;	/* 20080822 */
						}
						if(NumericInputEventTbl->iLowerFlag == FIXED)
							uiMin = NumericInputEventTbl->iLowerFixedVal;
						else
						{
/*							memcpy(cDataBuff,DeviceDataHed[NumericInputEventTbl->iLowerRegistNumber].DevData,10);	*/
							memcpy(cDataBuff,&DeviceData[ScreenTagData[InputDisplay.iInputNo].DevOrder+cnt],10);	/* 20080822 */
							uiMin = ChangeChar2long(cDataBuff,NumericInputEventTbl->i1632BitFlag);
						}
						// 2008.06.18 Signed Decimal
						iMax= uiMax;
						iMin= uiMin;
					}
				}
				OverFlag= 0;		/* V202 060124 */
				switch(NumericInputEventTbl->iFormFormat ){
					case	SIGNED_DECIMAL:
					case	UNSIGNED_DECIMAL:
						lNowNum = gatoi(InputDisplay.cInputDispBuff);
						if(NumericInputEventTbl->i1632BitFlag == 0){
							lNowNum = gatoi(InputDisplay.cInputDispBuff);
						}else{				/* 32 Bit */
							if(NumericInputEventTbl->iFormFormat == UNSIGNED_DECIMAL){		/* 070205 */
								lNowNum= atoul(InputDisplay.cInputDispBuff);
							}
							if(NumericInputEventTbl->iFormFormat == SIGNED_DECIMAL){
								if(InputDisplay.cInputDispBuff[0] == '-'){
									strcpy(wData,&InputDisplay.cInputDispBuff[1]);
									if(StringLargCmp(wData,"2147483648") > 0){
										OverFlag= 1;
									}
								}else{
									strcpy(wData,&InputDisplay.cInputDispBuff[0]);
									if(StringLargCmp(wData,"2147483647") > 0){
										OverFlag= 1;
									}
								}
							}else{
								strcpy(wData,&InputDisplay.cInputDispBuff[0]);
								if(StringLargCmp(wData,"4294967295") > 0){
									OverFlag= 1;
								}
							}
						}
						break;

					case	HEXA_DECIMAL:
						Hexa_SignedChangeData(InputDisplay.cInputDispBuff,&lNowNum);
						break;
					case	OCTAL:
						strcpy(wData,&InputDisplay.cInputDispBuff[0]);
						if(NumericInputEventTbl->i1632BitFlag == 0){
							if(StringLargCmp(wData,"177777") > 0){
								OverFlag= 1;
							}
						}else{
							if(StringLargCmp(wData,"37777777777") > 0){
								OverFlag= 1;
							}
						}
						Octal_SignedChangeData(InputDisplay.cInputDispBuff,&lNowNum);
						break;

					case	BINARY:
						Binary_SignedChangeData(InputDisplay.cInputDispBuff,&lNowNum);
						break;

					case	REAL:
						if(InputDisplay.cInputDispBuff[0] != 0x45){ /* E Check */
							fNowNum = (float)gatof(InputDisplay.cInputDispBuff);
						}else
						{
							cRealCheng = (char*)TakeMemory(21);
							memset(cRealCheng,0x00,21);
							cRealCheng[0] = 0x31;
							memcpy(cRealCheng+1,InputDisplay.cInputDispBuff,strlen(InputDisplay.cInputDispBuff));
							fNowNum = (float)gatof(cRealCheng);
							FreeMail(cRealCheng);
						}
						if(NumericInputEventTbl->iGain2==0)
							NumericInputEventTbl->iGain2 = 1;
						if(NumericInputEventTbl->iGain1==0)
							NumericInputEventTbl->iGain1 = 1;
						fNowNum= (fNowNum- NumericInputEventTbl->Offset)*NumericInputEventTbl->iGain2/NumericInputEventTbl->iGain1;
						memcpy(&lNowNum,&fNowNum,4);
						if(fNowNum<0)
							fNowNum = fNowNum*-1;
						break;
				}
				/* Calc */
				if(NumericInputEventTbl->iGain2==0)
					NumericInputEventTbl->iGain2 = 1;
				if(NumericInputEventTbl->iGain1==0)
					NumericInputEventTbl->iGain1 = 1;
				if(NumericInputEventTbl->iFormFormat == REAL){
				}else{
					lNowNum= (lNowNum- NumericInputEventTbl->Offset)*NumericInputEventTbl->iGain2/NumericInputEventTbl->iGain1;
					/* 16 Bit OR Siged Data */
					if(NumericInputEventTbl->i1632BitFlag == 0){
						if(NumericInputEventTbl->iSignFlag == SIGNED_DECIMAL){
							if(NumericInputEventTbl->iFormFormat == UNSIGNED_DECIMAL){
								if(lNowNum > 65535){
									OverFlag= 1;
								}
							}else{
								if((lNowNum > 32767) || (lNowNum < -32768)){
									OverFlag= 1;
								}
							}
							slNowNum= (short)lNowNum;	/* Sign On */
							lNowNum= slNowNum;
							if((lNowNum < iMin || lNowNum > iMax) && NumericInputEventTbl->iFormFormat != REAL){
								OverFlag= 1;
							}
						}else{
							if(NumericInputEventTbl->iFormFormat == UNSIGNED_DECIMAL){
								if((lNowNum < iMin || lNowNum > iMax) && NumericInputEventTbl->iFormFormat != REAL){
									OverFlag= 1;
								}
							}else{
								if((lNowNum > 32767) || (lNowNum < -32768)){
									OverFlag= 1;
								}
							}
						}
					}else{	/* 32 bit unsigned */
						if(NumericInputEventTbl->iSignFlag == SIGNED_DECIMAL){
							if((lNowNum < iMin || lNowNum > iMax) && NumericInputEventTbl->iFormFormat != REAL){
								OverFlag= 1;
							}
						}else{
							ulNowNum= (unsigned long)lNowNum;
							if(ulNowNum < uiMin || ulNowNum > uiMax){
								OverFlag= 1;
							}
						}
					}
				}
				if((OverFlag != 0) ||
/*					((lNowNum < iMin || lNowNum > iMax) && NumericInputEventTbl->iFormFormat != REAL) ||*/
/*					(NumericInputEventTbl->iFormFormat == REAL && (fNowNum > 3.402823466E+38 || fNowNum < 1.175494351E-38)))*/
					(NumericInputEventTbl->iFormFormat == REAL && (fNowNum > 3.402823466E+38)))
				{
					memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
					memcpy(InputDisplay.cInputDispBuff, NumericInputEventTbl->cTempBuffer,
							NumericInputEventTbl->iDigits);	

					ComWinKey.iVal = 2;
					if(TateYoko == 0)			/* 0 : ���� 1 : ���� */
#ifdef	SIZE_2480
						iCaptionVerticalWindow(Dspname[SET_FUNTION].chName[Set.iLang][9],"","","","");			/*  ��ư �ϳ��� �޼��� �ڽ�	 */	
#endif
#ifdef	GP_S057
						iCaptionVerticalWindow(Dspname[SET_FUNTION].chName[Set.iLang][12],"","","","");			/*  ��ư �ϳ��� �޼��� �ڽ�	 */						
#endif
					else
					{
#ifdef	SIZE_2480
						iCaptionVerticalWindow(Dspname[SET_FUNTION].chName[Set.iLang][4],
											Dspname[SET_FUNTION].chName[Set.iLang][5],
											Dspname[SET_FUNTION].chName[Set.iLang][6],
											Dspname[SET_FUNTION].chName[Set.iLang][7],"");
#endif
#ifdef	GP_S057
						iCaptionVerticalWindow(Dspname[SET_FUNTION].chName[Set.iLang][7],
											Dspname[SET_FUNTION].chName[Set.iLang][8],
											Dspname[SET_FUNTION].chName[Set.iLang][9],
											Dspname[SET_FUNTION].chName[Set.iLang][10],"");
#endif
					}
					InputDisplay.iFirstflag = 0;
					iErrorCode = 1;
					ComWinKey.iVal = 0;

				}
				else if(InputDisplay.iFirstflag != 0)
				{
					WriteDev.DevFlag = 1;	
					WriteDev.DevName[0] = NumericInputEventTbl->cDeviceName[0];
					WriteDev.DevName[1] = NumericInputEventTbl->cDeviceName[1];
					WriteDev.DevName[2] = 0x00;
					WriteDev.DevAddress = NumericInputEventTbl->iDeviceNumber;
					WriteDev.DevCnt = (NumericInputEventTbl->i1632BitFlag + 1);
					WriteDev.DevData = wData;
					//061124
//					if(NumericInputEventTbl->i1632BitFlag==1)
//					{
//						wData[3] = (lNowNum >> 24) & 0xff;
//						wData[2] = (lNowNum >> 16) & 0xff;
//						wData[1] = (lNowNum >> 8) & 0xff;
//						wData[0] = lNowNum & 0xff;
//					}
//					else
//					{
//						wData[1] = (lNowNum >> 8) & 0xff;
//						wData[0] = lNowNum & 0xff;
//					}
					if(NumericInputEventTbl->i1632BitFlag==1)
					{
						wData[2] = (lNowNum >> 24) & 0xff;
						wData[3] = (lNowNum >> 16) & 0xff;
						wData[0] = (lNowNum >> 8) & 0xff;
						wData[1] = lNowNum & 0xff;
					}
					else
					{
						wData[0] = (lNowNum >> 8) & 0xff;
						wData[1] = lNowNum & 0xff;
					}


					PLCWrite(&WriteDev);
/* 040114						readPlcDev1Round();						*/
					/*---------------DATA SET-----------------------------*/
			/*		iDevOrder = CompareDeviceAddr(NumericInputEventTbl->cDeviceName,
												  NumericInputEventTbl->iDeviceNumber);
					memcpy(DevSupervisorTbl[iDevOrder]->cpDevVal,wData,sizeof(wData));*/
					/*----------------------------------------------------*/
			/*		GetDeviceValue();*/
					/*------------------system information---------------------------------*/
/* 050306						if(strlen(CommonArea.SystemDev.Write_Dev.DevName)!=0 && (NumericInputEventTbl->iUser_id != 0xffff))*/
					if(NumericInputEventTbl->iUser_id != 0xffff)
					{
						/*NumericInputEventTbl->iUser_id++;*/
						//061124
//						InDevArea.UB[INDEV_WRITE+6] = NumericInputEventTbl->iUser_id & 0x00ff ;
//						InDevArea.UB[INDEV_WRITE+7] = (NumericInputEventTbl->iUser_id >> 8) & 0x00ff;
//						InDevArea.UB[INDEV_WRITE+8] = InDevArea.UB[INDEV_WRITE+8] | W_NUM_IN;
						InDevArea.UW[INDEV_WRITE+3] = NumericInputEventTbl->iUser_id;
						InDevArea.UW[INDEV_WRITE+4] |= W_NUM_IN;
						/*NumericInputEventTbl->iUser_id--;*/
						SendTimeAction(10,0,0,0);							
/* 050306						}else if(strlen(CommonArea.SystemDev.Write_Dev.DevName)!=0){*/
					}else {
						//061124
//						InDevArea.UB[INDEV_WRITE+6] = 0;
//						InDevArea.UB[INDEV_WRITE+7] = 0;
//						InDevArea.UB[INDEV_WRITE+8] = InDevArea.UB[INDEV_WRITE+8] | W_NUM_IN;
						InDevArea.UW[INDEV_WRITE+3] = 0;
						InDevArea.UW[INDEV_WRITE+4] |= W_NUM_IN;
						SendTimeAction(10,0,0,0);
					}
					/*----------------------------------------------------*/
					InputDisplay.iFirstflag = 0;

				}
				if(Screen[iScreenPosition].iDefKeyAct == 0x03 && iErrorCode == 0){
/*						NumericInputEventTbl->lBefDevBal++;*/
					CloseWindow(SCREEN_1);
					WindowPointDel();
					vWindowFreemeil();
					InputDisplay.iKeyOnOff = 0;
					/* ��ī �κ� ���÷��ø� �ϱ� ���� �κ� 030829 */
					ScreenTagData[InputDisplay.iInputNo].UpdateFlag = 1;
				}else if(Screen[iScreenPosition].iDefKeyAct == 0x02 && iErrorCode == 0){
					InputDisplay.iFirstflag = 0;
					if((NumericInputEventTbl->iMoveDest_id != 0xffff) 
						&& (NumericInputEventTbl->iMoveDest_id != NumericInputEventTbl->iUser_id))
					{
						iReturnVal = UpDownTouchDiplay(2);
					}else{
						if(NumericInputEventTbl->iMoveDest_id == 0xffff){	//���肪���Ȃ��ꍇ 
							CloseWindow(SCREEN_1);
							WindowPointDel();
							vWindowFreemeil();
							InputDisplay.iKeyOnOff = 0;
							/* ��ī �κ� ���÷��ø� �ϱ� ���� �κ� 030829 */
							ScreenTagData[InputDisplay.iInputNo].UpdateFlag = 1;
						}
					}
				}
				memcpy(NumericInputEventTbl->cTempBuffer,
						InputDisplay.cInputDispBuff,NumericInputEventTbl->iDigits);
			}else{
				ErrorBuzzer();
			}
			BaseChangeFlag2= 1;		/* ���ɃL?�������܂ő҂� 050314 */
		}else if(iMainKeyCode == CLR) /* CLR */
		{
			memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
			memcpy(InputDisplay.cInputDispBuff, NumericInputEventTbl->cTempBuffer,
							NumericInputEventTbl->iDigits);		
			InputDisplay.iFirstflag = 0;

//2011.09.19 Del			if(Screen[iScreenPosition].iDefKeyAct == 0x03){
			/*	NumericInputEventTbl->lBefDevBal++;*/
				CloseWindow(SCREEN_1);
				WindowPointDel();
				vWindowFreemeil();
				InputDisplay.iKeyOnOff = 0;
				/* ��ī �κ� ���÷��ø� �ϱ� ���� �κ� 030829 */
				ScreenTagData[InputDisplay.iInputNo].UpdateFlag = 1;
//2011.09.19 Del			}
			BaseChangeFlag2= 1;		/* ���ɃL?�������܂ő҂� 050314 */
		}else if(iMainKeyCode == UP_DISP) /* UP_KEY */
		{ 
			if(Screen[iScreenPosition].iDefKeyAct != 0x01){
//2011.09.19 Del				if((NumericInputEventTbl->iMoveDest_id != 0xffff)
//2011.09.19 Del					&& (NumericInputEventTbl->iMoveDest_id != NumericInputEventTbl->iUser_id))
//2011.09.19 Del				{
					iReturnVal = UpDownTouchDiplay(1);
//2011.09.19 Del				}
			} 
		}else if(iMainKeyCode == DOWN_DISP) /* DOWN_KEY */
		{
			if(Screen[iScreenPosition].iDefKeyAct != 0x01){
				InputDisplay.iFirstflag = 0;
				if((NumericInputEventTbl->iMoveDest_id != 0xffff) 
					&& (NumericInputEventTbl->iMoveDest_id != NumericInputEventTbl->iUser_id))
				{
					iReturnVal = UpDownTouchDiplay(2);
				}
			} 
		}else if(iMainKeyCode == 0x2D) /*  -  */
		{
			if(NumericInputEventTbl->iFormFormat == SIGNED_DECIMAL ||
				NumericInputEventTbl->iFormFormat == REAL)
			{
				cBuff[0] = (char)iMainKeyCode;
				iLen = NumericInputEventTbl->iDigits;
				if(InputDisplay.iFirstflag == 0 || iLen > 0)
				{
					memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
				}
				strcat(InputDisplay.cInputDispBuff, cBuff);

				iMainKeyCode = 0x0000;
				InputDisplay.iFirstflag = 1;
			}
		}else if(iMainKeyCode == BS)		/* Back Space */
		{
			iLen = strlen(InputDisplay.cInputDispBuff);
			if(iLen > 0)
			{
				InputDisplay.cInputDispBuff[iLen -1] = 0x00;
				InputDisplay.iFirstflag = 1;
			}
		}
		FreeMail((char*)NumericInputEventTbl);
	}
	if(AsciiInputCnt>0 && ScreenTagData[InputDisplay.iInputNo].cObjects == ASCII_INPUT)
	{
/*		AsciiInputEventTbl= (_ASCIIINPUT_EVENT_TBL*)IventTable[InputDisplay.iInputNo];*/
		AsciiInputEventTbl= (_ASCIIINPUT_EVENT_TBL*)TakeMemory(sizeof(_ASCIIINPUT_EVENT_TBL));
		DrawAsciiInput_Func(1,AsciiInputEventTbl,InputDisplay.iInputNo);
		if(InputDisplay.iKeyOnOff == 2)
		{
			if((iMainKeyCode>=0x20 && iMainKeyCode<=0x7E))		/* DisplayData ���� */
			{	
				if(InputDisplay.iFirstflag == 0)
				{
					memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
				}
				if(iAsciiKeyflag > 0)				/* ***** �ٸ� �÷��װ� �ʿ���.. */
				{
					if(iMainKeyCode == 0x37 && iAsciiKeyflag == 3)
						cBuff[0] = 0x00;
					else
						cBuff[0] = (char)(iMainKeyCode+(0x18*iAsciiKeyflag));
				}else
				{
					cBuff[0] = (char)iMainKeyCode;
				}
				iLen = AsciiInputEventTbl->iDigits;
				if(strlen(InputDisplay.cInputDispBuff) >= iLen)
				{
					memcpy(cDataBuff,InputDisplay.cInputDispBuff+1,iLen-1);
					memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
					memcpy(InputDisplay.cInputDispBuff,cDataBuff,iLen-1);
				}
				strcat(InputDisplay.cInputDispBuff, cBuff);
				iMainKeyCode = 0x0000;
				InputDisplay.iFirstflag = 1;
			}
			else if(iMainKeyCode == CLR || ScreenTagData[InputDisplay.iInputNo].uu.AsciiIn.iTriggerVal == OFF) /* CLR */
			{
				memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
				InputDisplay.iFirstflag = 0;
/*				memcpy(InputDisplay.cInputDispBuff, AsciiInputEventTbl->cBefDevData,
								AsciiInputEventTbl->iDigits);		
*/
				memcpy(InputDisplay.cInputDispBuff,&DispDeviceData[ScreenTagData[InputDisplay.iInputNo].DevOrder],AsciiInputEventTbl->iDigits);
//2011.09.27				if(Screen[iScreenPosition].iDefKeyAct == 0x03){
/*					AsciiInputEventTbl->cBefDevData++;*/
					CloseWindow(SCREEN_1);
					WindowPointDel();
					InputDisplay.iKeyOnOff = 0;
					vWindowFreemeil();
					/* ��ī �κ� ���÷��ø� �ϱ� ���� �κ� 030829 */
					ScreenTagData[InputDisplay.iInputNo].UpdateFlag = 1;
//2011.09.27				} 
				BaseChangeFlag2= 1;		/* ���ɃL?�������܂ő҂� 050314 */
			}
			else if(iMainKeyCode == ENT) /* ENT */
			{
				if(ScreenTagData[InputDisplay.iInputNo].uu.AsciiIn.iTriggerVal == ON){
					if(InputDisplay.iFirstflag != 0)
					{
						WriteDev.DevFlag = 1;	
						WriteDev.DevName[0] = AsciiInputEventTbl->cDeviceName[0];
						WriteDev.DevName[1] = AsciiInputEventTbl->cDeviceName[1];
						WriteDev.DevName[2] = 0x00;
						WriteDev.DevAddress = AsciiInputEventTbl->iDeviceNumber;
						WriteDev.DevCnt = (AsciiInputEventTbl->iDigits)/2; /* 20081223 sh �ڸ��� ���� */

//						WriteDev.DevData = InputDisplay.cInputDispBuff;
						//Data High Low Change 2008.06.18
						cnt= AsciiInputEventTbl->iDigits;
						if(cnt%2){
							cnt++;
						}
						workData= TakeMemory(AsciiInputEventTbl->iDigits);
						memcpy(workData,InputDisplay.cInputDispBuff,cnt);
						ChangeLowHighByte(workData,cnt);
						WriteDev.DevData = workData;
						PLCWrite(&WriteDev);
/* 040114						readPlcDev1Round();*/

				/*------------------system information---------------------------------*/
/*						if(strlen(CommonArea.SystemDev.Write_Dev.DevName)!=0 && (AsciiInputEventTbl->iUser_id != 0xffff))*/
						if(AsciiInputEventTbl->iUser_id != 0xffff)
						{
/*							AsciiInputEventTbl->iUser_id++;*/
							//061124
//							InDevArea.UB[INDEV_WRITE+6] = AsciiInputEventTbl->iUser_id & 0x00ff ;
//							InDevArea.UB[INDEV_WRITE+7] = (AsciiInputEventTbl->iUser_id >> 8) & 0x00ff;
//							InDevArea.UB[INDEV_WRITE+8] = InDevArea.UB[INDEV_WRITE+8] | W_NUM_IN;
							InDevArea.UW[INDEV_WRITE+3] = AsciiInputEventTbl->iUser_id;
							InDevArea.UW[INDEV_WRITE+4] |= W_NUM_IN;
/*							AsciiInputEventTbl->iUser_id--;*/
							SendTimeAction(10,0,0,0);
						}else{
							//061124
//							InDevArea.UB[INDEV_WRITE+6] = 0;
//							InDevArea.UB[INDEV_WRITE+7] = 0;
//							InDevArea.UB[INDEV_WRITE+8] = InDevArea.UB[INDEV_WRITE+8] | W_NUM_IN;
							InDevArea.UW[INDEV_WRITE+3] = 0;
							InDevArea.UW[INDEV_WRITE+4] |= W_NUM_IN;
							SendTimeAction(10,0,0,0);
						}
						/*----------------------------------------------------*/

			/*			memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));*/
						InputDisplay.iFirstflag = 0;
					}
					if(Screen[iScreenPosition].iDefKeyAct == 0x03){
/*						AsciiInputEventTbl->cBefDevData++;*/
						CloseWindow(SCREEN_1);
						WindowPointDel();
						vWindowFreemeil();
						InputDisplay.iKeyOnOff = 0;
						/* ��ī �κ� ���÷��ø� �ϱ� ���� �κ� 030829 */
						ScreenTagData[InputDisplay.iInputNo].UpdateFlag = 1;
					} 
					else if(Screen[iScreenPosition].iDefKeyAct != 0x01){
						InputDisplay.iFirstflag = 0;
						if((AsciiInputEventTbl->iMoveDest_id != 0xffff) 
							&& (AsciiInputEventTbl->iMoveDest_id != AsciiInputEventTbl->iUser_id))
						{
							iReturnVal = UpDownTouchDiplay(4);
						}else{													//2011.09.27
							if(AsciiInputEventTbl->iMoveDest_id == 0xffff){		//2011.09.27
								CloseWindow(SCREEN_1);							//2011.09.27
								WindowPointDel();								//2011.09.27
								vWindowFreemeil();								//2011.09.27
								InputDisplay.iKeyOnOff = 0;						//2011.09.27
								/* ��ī �κ� ���÷��ø� �ϱ� ���� �κ� 030829 *///2011.09.27
								ScreenTagData[InputDisplay.iInputNo].UpdateFlag = 1;	//2011.09.27
							}
						}
					}
				}else
				{
					ErrorBuzzer();
				}
				BaseChangeFlag2= 1;		/* ���ɃL?�������܂ő҂� 050314 */
			}else if(iMainKeyCode == UP_DISP) /* UP_KEY */
			{ 
				if(Screen[iScreenPosition].iDefKeyAct != 0x01){
//2011.09.27					if((AsciiInputEventTbl->iMoveDest_id != 0xffff)
//2011.09.27						&& (AsciiInputEventTbl->iMoveDest_id != AsciiInputEventTbl->iUser_id))
//2011.09.27					{
						iReturnVal = UpDownTouchDiplay(3);
//2011.09.27					}
				} 
			}else if(iMainKeyCode == DOWN_DISP)/*  DOWN_KEY  */
			{
				if(Screen[iScreenPosition].iDefKeyAct != 0x01){
					InputDisplay.iFirstflag = 0;
					if((AsciiInputEventTbl->iMoveDest_id != 0xffff) 
						&& (AsciiInputEventTbl->iMoveDest_id != AsciiInputEventTbl->iUser_id))
					{
						iReturnVal = UpDownTouchDiplay(4);
					}
				}
			}else if(iMainKeyCode == LEFT_DISP)				/* <- */
			{
				if(iAsciiKeyflag > 0)
				{
					iAsciiKeyflag--;
					iAsciiReDispflag = 1000;
				}
			}else if(iMainKeyCode == RIGHT_DISP)				/* -> */
			{
				if(iAsciiKeyflag < 3)
				{
					iAsciiKeyflag++;
					iAsciiReDispflag = 1000;
				}
			}else if(iMainKeyCode == BS)		/* Back Space */
			{

				iLen = strlen(InputDisplay.cInputDispBuff);
				if(InputDisplay.iFirstflag == 0 && iLen > 0)
				{
					InputDisplay.iFirstflag = 1;
					memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
					iLen = strlen(InputDisplay.cInputDispBuff);
				}
				if(iLen > 0)
				{
					InputDisplay.cInputDispBuff[iLen -1] = 0x00;
				}
			}
		}
		FreeMail((char*)AsciiInputEventTbl);
	}
	FreeMail((char*)cDataBuff);
	return	iReturnVal;
	/*InputDisplay.lInputDispBuff+=*/
}
/********************************************************************************/
/* �� �� �� : PassWordInputSetting												*/
/* ��    �� : PassWord �Է��Լ�.												*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2003�� 4�� 19�� (��)												*/
/* �� �� �� : �� �� �� 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	PasswordLevelWrite(void)
{
	DEV_DATA			WriteDev;
	char				cRetVal[2];

	if(CommonArea.SystemDev.Password_Dev.DevName[0] != 0){		/* Password Device ON */
		WriteDev.DevFlag = 1;	
		WriteDev.DevName[0] = CommonArea.SystemDev.Password_Dev.DevName[0];
		WriteDev.DevName[1] = CommonArea.SystemDev.Password_Dev.DevName[1];
		WriteDev.DevName[2] = 0x00;
		WriteDev.DevAddress = CommonArea.SystemDev.Password_Dev.DevAdd;
		WriteDev.DevCnt = 1;
		WriteDev.DevData = cRetVal;
		//061124
//		memset(cRetVal,0x00,sizeof(cRetVal));
//		cRetVal[0] = (char)iPassLevel;
//		cRetVal[1] = 0x00;
		cRetVal[1] = (char)iPassLevel;
		cRetVal[0] = 0x00;
		PLCWrite(&WriteDev);
	}
}
int PassWordInputSetting(void)
{
	char				cBuff[2];
	unsigned int		iLen;
	char*				cDataBuff;
	short				iFlag;			/* TouchKey Close check code */
	short				iDataFlag;
	short				i;
	int					ret;
	int					iRetVal;
	int					tmpiPassLevel;
	int					cnt;		/*060926 */

#ifdef	PASSWORD_NO_CHANGE		/* 20081023 */

#else
	extern	int	CheckLevelPassword(int idx,char* buff);
#endif		

	iFlag		= 0;
	iDataFlag	= 0;
	cDataBuff	= (char*)TakeMemory(9);
	memset(cDataBuff,0x00,9);
	memset(cBuff,0x00,2);
		iRetVal = 1;
		if(iMainKeyCode == ENT)	   /* ENT */
		{
			cnt= strlen(cPassBuff);
/* 060926 			if(strlen(cPassBuff)!=0){*/
			if(cnt!=0){
				for(i=0;i<15;i++){
#ifdef	PASSWORD_NO_CHANGE		/* 20081023 */
					if(strncmp(CommonArea.SystemDev.Password[i],cPassBuff,cnt)==0)
#else
/*					if(strncmp(CommonArea.SystemDev.Password[i],cPassBuff,cnt)==0)	20081023 */
					if(CheckLevelPassword(i,cPassBuff) == 0)
#endif	
					{
						tmpiPassLevel = i+1;
						iDataFlag = 1;
/* 060926 */
						if(tmpiPassLevel >= Screen[iPassPoint].iSecurity){
							NormalBuzzer();					/* Buzzer ����~�� */
							iPassLevel = tmpiPassLevel;
							PasswordLevelWrite();
							iFlag = 1;
							if(PassWordSettingFg != 0){		/* Password Touch */
								WriteBaseNo(PassWordSettingFg);
								PassWordSettingFg= 0;
								BaseChangeFlag2= 1;		/* 050425 */
							}
							break;	
						}else{
							iDataFlag= 0;
						}
					}
				}
/* 050427				if(iFlag || iPassFlag == 2){*/								/* ��ư ������ �ݱ�.. */
				if(iFlag){								/* ��ư ������ �ݱ�.. */
					CloseWindow(SCREEN_1);
					WindowPointDel();
					vWindowFreemeil();
					InputDisplay.iKeyOnOff = 0;
					if(iPassFlag != 2 && iPassFlag != 3){
						SwitchingScreenDevice.iBaseScreenFlag = 1;
					}
					if(iPassFlag == 3){
						while(1){
							ret= KeyAccept();
							if(ret == -1){
								break;
							}
						}
					 	SendKeyData(KEY_EVENT);
					/*	SendKeyData(0x00);*/
					}		
					iPassFlag = 0;

				}else{
					ErrorBuzzer();					/* Buzzer ����~�� */
				}
				memset(InputDisplay.cInputDispBuff,0x00,8);
			/*	memset(InputDisplay.cInputDispBuff,' ',8);*/
				memset(cPassBuff,0x00,sizeof(cPassBuff));
		
				if(iDataFlag == 0 && CommonArea.SystemDev.DispPassinputchk == 0xFF)
				{
					ClearDispBuff(MESSAGE_SCREEN);
					SetStartPos(MESSAGE_SCREEN, 0, 0);
					OpenWindow(MESSAGE_SCREEN, GAMEN_X_SIZE, GAMEN_Y_SIZE);

/*					ErrorBuzzer();*/					/* Buzzer ����~�� */

					iCaptionWindow(Dspname[BATTERY].chName[Set.iLang][10],"");			/*  ��ư �ϳ��� �޼��� �ڽ�	 */	
					CloseWindow(MESSAGE_SCREEN);
					iRetVal = 0;		/* 050411 */
				}

				iMainKeyCode = 0x0000;
				InputDisplay.iFirstflag = 0;

			}else{
				ErrorBuzzer();					/* Buzzer ����~�� */
			}
		}else if(iMainKeyCode == CLR) /* CLR */
		{
			NormalBuzzer();					/* Buzzer ����~�� */
			memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
			memset(cPassBuff,0x00,sizeof(cPassBuff));
//			if(iPassLevel >= Screen[iPassPoint].iSecurity){
//				iFlag = 1;
//			}
//			if(iFlag || iPassFlag == 2 || iPassFlag == 3){ /* 3:Sys Level 3 ȯ�漳������ �� �� PassLevel ���� ���  */
//			if(iFlag || iPassFlag == 1 || iPassFlag == 2 || iPassFlag == 3){ /* 3:Sys Level 3 ȯ�漳������ �� �� PassLevel ���� ���  */		/* 20100706 */
				CloseWindow(SCREEN_1);
				WindowPointDel();
				vWindowFreemeil();
				InputDisplay.iKeyOnOff = 0;
				iPassFlag = 0;
				BaseChangeFlag2= 1;		/* 050425 */				
//			}
			iMainKeyCode = 0x0000;
			InputDisplay.iFirstflag = 0;
			PassWordSettingChg= 0;			/* 050411 */
			PassWordSettingFg= 0;

		}else if(iMainKeyCode == UP_DISP)	/* UP_KEY	*/
		{
		}else if(iMainKeyCode == DOWN_DISP) /* DOWN_KEY */
		{
		}else if(iMainKeyCode == 0x2D)		/*  -		*/
		{
		}else if(iMainKeyCode == BS)		/* BS		*/
		{
			NormalBuzzer();					/* Buzzer ����~�� */
			iLen = strlen(cPassBuff);
			if(iLen > 0)
			{
				cPassBuff[iLen-1] = 0x00;
				memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
			}

			if(strlen(cPassBuff) > 0){
				memcpy(InputDisplay.cInputDispBuff, "********",iLen-1);
			}
			
			iMainKeyCode = 0x0000;
		}else if(iMainKeyCode>=0x30 && iMainKeyCode<=0x39){
			NormalBuzzer();					/* Buzzer ����~�� */
			if(InputDisplay.iFirstflag == 0)
			{
				memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
				memset(cPassBuff,0x00,sizeof(cPassBuff));
			}
			cBuff[0] = (char)iMainKeyCode;
			iLen = strlen(cPassBuff);
			if(iLen >= 8)
			{
				memcpy(cDataBuff,cPassBuff+1,iLen-1);
				memset(cPassBuff,0x00,sizeof(cPassBuff));
				memcpy(cPassBuff,cDataBuff,iLen-1);
			}
			strcat(cPassBuff, cBuff);
			if(strlen(InputDisplay.cInputDispBuff) != 8){
				strcat(InputDisplay.cInputDispBuff, "*");
			}
			iMainKeyCode = 0x0000;
			InputDisplay.iFirstflag = 1;
		}else
		{
			iRetVal = 0;
		}

	FreeMail((char*)cDataBuff);
	return(iRetVal);
}
int		GetKeyCode(int no)
{
	int				iKeyCode;
	unsigned char*	buffer;

	buffer= ScreenTagData[no].TagPos;
	/* Action Tab-> KeyCode Value */
	iKeyCode = (unsigned int)buffer[21] << 0x08;
	iKeyCode += (unsigned int)buffer[22] & 0xff;
	return(iKeyCode);
}
int	GetRepeatInfo(int no)
{
	int				iOptionRepeat;
	unsigned char*	buffer;

	buffer= ScreenTagData[no].TagPos;
	if(((unsigned int)buffer[16] & 0x40) == 0x40)
		iOptionRepeat = CHECKED;
	else
		iOptionRepeat = UNCHECKED;
	return(iOptionRepeat);
}
/********************************************************************************/
/* �� �� �� : TouchSwitchGetArea(int iOrder)[�迭�� ����]						*/
/* ��    �� : ��ġ���� �о� ���ſ��θ� �����Ѵ�.								*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2003�� 10�� 28�� (ȭ)												*/
/* �� �� �� : �� �� �� 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
//2011.09.08 Dell	short TouchSwitchGetArea(int iNum,int *OnOffFlag)
short TouchSwitchGetArea(int iNum,int *OnOffFlag,int *AreaOKFlag)
{
	short			RetVal;
	int				iKeyVal = OFF;
	int				sX;
	int				sY;
	int				WinNum;
	short			i;
	short			iCheckFlag;
	short			tsX,tsY,teX,teY;
	short			iOptionRepeat;
	unsigned int	iKeyCode;

//	_TOUCHSWICH_EVENT_TBL*	 TouchSwitchEventTbl;
/*	TouchSwitchEventTbl= (_TOUCHSWICH_EVENT_TBL*)IventTable[iNum];*/
//	TouchSwitchEventTbl= (_TOUCHSWICH_EVENT_TBL*)TakeMemory(sizeof(_TOUCHSWICH_EVENT_TBL));
//	DrawTouchSwitch_Func(1,TouchSwitchEventTbl,iNum,0, 0 );
	GetTouchAddr(iNum,&tsX,&tsY,&teX,&teY,&iOptionRepeat,&iKeyCode);
	
	WinNum = ScreenTagData[iNum].iWindowNo;
	iCheckFlag = 0;
	RetVal = OFF;
	sX = 0;
	sY = 0;
	if(WinNum == SCREEN_1)
	{
		sX = iWinStartPx;
		sY = iWinStartPy;
	}
	if(Key.iBuff > 0 && Key.iBuff <= MAX_TOUCH_NO){/* Key.iBuff != -1 */
	/* Key Input */
		for(i=0;i<8;i++)
		{
			if(KeyTochData[i] == 0){	break;		}		// Data End
//			if(TouchAreaCheck(TouchSwitchEventTbl->sX + sX,
//						  TouchSwitchEventTbl->sY + sY, 
//						  TouchSwitchEventTbl->eX + sX, 
//						  TouchSwitchEventTbl->eY + sY,
//						  KeyTochData[i]) == 1){
			if(TouchAreaCheck(tsX + sX,tsY + sY,teX + sX,teY + sY, KeyTochData[i]) == 1){	iCheckFlag = 1;	break;	}
		}
/*		if(TouchSwitchEventTbl->iOnOffFlag == 0 || (TouchSwitchEventTbl->iOptionRepeat == CHECKED && iCheckFlag == 1))*/
/*		{*/

		if(iCheckFlag == 1){	/* �L?�f??���� */
//			if((TouchSwitchEventTbl->iOptionRepeat == CHECKED) || 
			if((iOptionRepeat == CHECKED) || 
				(ScreenTagData[iNum].uu.TouchSw.TouchKeyVal == OFF)){
				if((AsciiInputCnt > 0) && (iAsciiKeyflag == 3) && (KeyTochData[i] == 52)){
					/* Ascci KeyWindow de End Not Key */
					iKeyVal = OFF;
				}else{
					*OnOffFlag |= 1;			/* ON */
					iKeyVal = ON;
/*					TouchSwitchEventTbl->iOnOffFlag = 1;*/
/*					iMainKeyCode = TouchSwitchEventTbl->iKeyCode;*/
					iMainKeyCode= GetKeyCode(iNum);
/*					KerRepeatFlag = TouchSwitchEventTbl->iOptionRepeat;*/ /* */
					KerRepeatFlag = GetRepeatInfo(iNum);
					if(KerRepeatFlag == CHECKED){		/* 040925 */
						SetRepeatInf(iNum);
					}
/*					TouchSwitchEventTbl->TouchType = 1;*/

/*					TouchSwitchEventTbl->iBefKeyVal = iKeyVal;*/
					ScreenTagData[iNum].uu.TouchSw.TouchKeyVal= iKeyVal;
					ScreenTagData[iNum].UpdateFlag= 1;
					iAlternateflag = (char)0x01;
					RetVal = ON;


				/*	Key.iBuff = -1;*/
					if(iPassFlag == 0){
						if((NumericInputCnt>0 || AsciiInputCnt>0) && 
							InputDisplay.iInputNo >= 0 && 
/* 040924							InputDisplay.iKeyOnOff > 0 && */
//							TouchSwitchEventTbl->iKeyCode != 0xffff)
							iKeyCode != 0xffff)
						{
							RetVal = InputNumberDisplaySetting();
							/*Key.iBuff = 0;*/
							if(RetVal != OFF){				/* Key 1 Touch Only 031120 */
								/**OnOffFlag |= 4;*/			/* Break */
							}
						}
	/* 031120					Key.iBuff = 0;*/
					}
					else{
						RetVal = 0;
						RetVal = PassWordInputSetting();
						/* 050425 */
						if(RetVal != OFF){				/* Key 1 Touch Only 031120 */
							*OnOffFlag &= 0xfffe;			/* Buzer Off */
/*							*OnOffFlag |= 4;*/			/* Break */
						}
					}
				}
			}
		}else{
			iKeyVal = OFF;
			if(ScreenTagData[iNum].uu.TouchSw.TouchKeyVal == ON){
				ScreenTagData[iNum].uu.TouchSw.TouchKeyVal= iKeyVal;
				RetVal = ON;
				ScreenTagData[iNum].UpdateFlag= 1;
			}
		}
	}else{		/* �L?�����ꂽ */
/*		if(TouchSwitchEventTbl->iOnOffFlag == 1 && iKeyVal != ON)*/
/*		{*/
			if(Key.iBuff != 0){
				for(i=0;i<8;i++)
				{
					if(KeyTochData[i] == 0){	break;		}		// Data End
//					if(TouchAreaCheck(TouchSwitchEventTbl->sX + sX,
//									  TouchSwitchEventTbl->sY + sY, 
//									  TouchSwitchEventTbl->eX + sX, 
//									  TouchSwitchEventTbl->eY + sY,
//									  KeyTochData[i]) == 1)
					if(TouchAreaCheck(tsX + sX,tsY + sY,teX + sX,teY + sY,KeyTochData[i]) == 1)
					{
						iCheckFlag = 1;
						break;
					}
				}
			}
			if(iCheckFlag == 0)		/* �L?���� */
			{
				*OnOffFlag |= 2;			/* OFF */
/*
				TouchSwitchEventTbl->iOnOffFlag = 0;
				TouchSwitchEventTbl->iBefKeyVal = iKeyVal;
*/
				if(ScreenTagData[iNum].uu.TouchSw.TouchKeyVal == ON){
					ScreenTagData[iNum].uu.TouchSw.TouchKeyVal= iKeyVal;
					RetVal = ON;
					ScreenTagData[iNum].UpdateFlag= 1;
				}
/*
				if(TouchSwitchEventTbl->TouchType != 1)
					TouchSwitchEventTbl->TouchType = 2;
*/
/*				iAlternateflag = (char)0x01;
				RetVal = ON;
*/
				/* 031119 */
/*
				if((NumericInputCnt>0 || AsciiInputCnt>0) && 
					InputDisplay.iInputNo >= 0 && 
					InputDisplay.iKeyOnOff > 0 && 
					TouchSwitchEventTbl->iKeyCode != 0xffff)
				{
*/
					/* 050314 ?�b?�L?�̔�?���c�� */
/*
					if((TouchSwitchEventTbl->iKeyCode >= C_AP) && 
						(TouchSwitchEventTbl->iKeyCode <= PW_RESET)){
					}else{
						*OnOffFlag |= 4;
					}
*/
/*				}*/
			}
/*		}*/
	}
	if(iAsciiReDispflag != -1)
	{
		if(iAsciiReDispflag == 1000)
		{
			iAsciiReDispflag = iNum;
			ScreenTagData[iNum].UpdateFlag= 1;
		}
		else if(iAsciiReDispflag != iNum && iAsciiReDispflag != -1)
		{
			if(iAsciiReDispflag<iNum)
				iAsciiReDispflag = iNum;
			ScreenTagData[iNum].UpdateFlag= 1;
		}else
		{
			iAsciiReDispflag = -1;
		}
	}
//	FreeMail((char *)TouchSwitchEventTbl);
	*AreaOKFlag= iCheckFlag;				//2011.09.08
	return RetVal;
}
int	CheckKeyWindow(int sPx,int sPy,int ePx,int ePy)
{
	int iReturn;
	/*
	if((iWinStartPx != 0) ||
		(iWinStartPy != 0) ||
		(iWinEndPx != 0) ||
		(iWinEndPy != 0) ){
		iReturn = TouchAreaCheck(iWinStartPx, iWinStartPy, iWinEndPx, iWinEndPy,Key.iCode);
		if((Key.iCode != 0) && (iReturn == 0)){
			iReturn= -1;
		}
	}else{
	*/
		iReturn = TouchAreaCheck(sPx, sPy, ePx, ePy,Key.iCode);
/*	}*/
	return iReturn+1;

}
/********************************************************************************/
/*	Touch Area Check															*/
/********************************************************************************/
void	TouchAreaCheckProc( void )
{
	int			iWinNum;
	int			iWinNumBuf;
	int			iScreenUpdateFlag;	
	int			iVal;
	short		k;
	short		iType;
	int			OnOffFlag;
	int			sx,sy,ex,ey;
/*	_TOUCHSWICH_EVENT_TBL*	 TouchSwitchEventTbl;*/
	int			TaouchOnFlag;	//2011.09.08
	int			AreaOKFlag;		//2011.09.08

	iWinNum				= 0;		
	iScreenUpdateFlag	= 0;	
	iVal				= 0;
	iType				= 1;

	iScreenUpdateFlag = OFF;
	OnOffFlag= 0;
	sx= iWinStartPx;
	sy= iWinStartPy;
	ex= iWinEndPx;
	ey= iWinEndPy;

	TaouchOnFlag= 0;				//2011.09.08
	for(k= iDispOrder - 1;k >= 0; k--){
		iWinNum = ScreenTagData[k].iWindowNo;
		if(Key.iCode != 0){
			if(iWinNum != CheckKeyWindow(sx,sy,ex,ey))
				continue;
		}
		switch(ScreenTagData[k].cObjects){
		case TOUCH_SWITCH:
/*			TouchSwitchEventTbl = (_TOUCHSWICH_EVENT_TBL*)IventTable[k];*/
			if(TaouchOnFlag == 1){	continue;	}			//2011.09.08
//2011.09.08 Dell			iVal = TouchSwitchGetArea(k,&OnOffFlag);
			iVal = TouchSwitchGetArea(k,&OnOffFlag,&AreaOKFlag);
			if(AreaOKFlag == 1){								//2011.09.08
				TaouchOnFlag= 1;								//2011.09.08
			}													//2011.09.08
			if(iVal != OFF){ /* if(TouchSwitchGetDevVal(k) == ON){ */
				iScreenUpdateFlag = ON;
				if(iVal == 2){			/* Window Screen �ٲ� �ٽ� Display �ؾ� �ϱ� ������ */
				
					iWinNum = 1;
					k=-1;
					iType = 0;

				}
				if(iWinNum == SCREEN_1 && iTouchFlag == 2) {
					iTouchFlag = 3;
				}
				iWinNumBuf = iWinNum;
				/* Touch Proc 050309 */
				if(k >= 0){
					TouchKeyWriteProc(k);		/* 050301 XXXXX */
				}
			}
			break;
		case NUMERICAL_INPUT:
				if(NumericalInputTouchCheck(k) == ON){
					iScreenUpdateFlag = ON;
					iWinNumBuf = iWinNum;
/* 050420					OnOffFlag= 0x0d;*/		/* For Buzzer On & Break & No DrawBank1 */
//					OnOffFlag= 0x09;		/* For Buzzer On & Break & No DrawBank1 */
					OnOffFlag= 0x05;		/* For Buzzer On & Break & No DrawBank1 */
					TrendClerFlag = 1;		/* TrendCler OFF Set 050313 */
					BaseChangeFlag2= 1;		/* 050422 ���ɗ����Ȃő҂� */
					//Numeric Input Area
					KeyWinCheck_sx= ScreenTagData[k].sX;		//Numeric,Adci Input Area
					KeyWinCheck_sy= ScreenTagData[k].sY;		//Numeric,Adci Input Area
					KeyWinCheck_ex= ScreenTagData[k].eX;		//Numeric,Adci Input Area
					KeyWinCheck_ey= ScreenTagData[k].eY;		//Numeric,Adci Input Area
				}
				break;
		case ASCII_INPUT:
				if(AsciiInputTouchCheck(k) == ON){
					iScreenUpdateFlag = ON;
					iWinNumBuf = iWinNum;
/* 050420					OnOffFlag= 0x0d;*/		/* For Buzzer On & Break & No DrawBank1 */
//					OnOffFlag= 0x09;		/* For Buzzer On & Break & No DrawBank1 */
					OnOffFlag= 0x05;		/* For Buzzer On & Break & No DrawBank1 */
					TrendClerFlag = 1;		/* TrendCler OFF Set 050313 */
					BaseChangeFlag2= 1;		/* 050422 ���ɗ����Ȃő҂� */
					//Numeric Input Area
					KeyWinCheck_sx= ScreenTagData[k].sX;		//Numeric,Adci Input Area
					KeyWinCheck_sy= ScreenTagData[k].sY;		//Numeric,Adci Input Area
					KeyWinCheck_ex= ScreenTagData[k].eX;		//Numeric,Adci Input Area
					KeyWinCheck_ey= ScreenTagData[k].eY;		//Numeric,Adci Input Area
				}
				break;
		}
		if(OnOffFlag & 0x04){
			break;
		}
	}
	if(iScreenUpdateFlag == ON){
		if((Key.iCode != 0) && (OnOffFlag & 1)){
			NormalBuzzer();
		}
		if(iAsciiReDispflag != -1){
			WindowDisplay_Task_Send(WIN_BASE_DATA,iWinNumBuf,k,0,1);			/* Ascii Window (>,<) Key */
		}else{
			if(OnOffFlag & 0x08){
				WindowDisplay_Task_Send(WIN_BASE_DATA,iWinNumBuf,k,iType,0);
			}else{
				WindowDisplay_Task_Send(WIN_BASE_DATA,iWinNumBuf,k,iType,1);
			}
		}
	}
}
/********************************************************************************/
/*	Touch Area Check															*/
/********************************************************************************/
void	MainTouchAreaCheckProc( void )
{
	short		k;
	int				WinNum;
	int		sX,sY;
/*	_TOUCHSWICH_EVENT_TBL*	 TouchSwitchEventTbl;
	_ASCIIINPUT_EVENT_TBL*	 AsciiInputEventTbl;
	_NUMERIC_INPUT_EVENT_TBL*	 NumericInputEventTbl;*/


	if(AsciiInputCnt == 0 &&
		NumericInputCnt == 0 &&
		TouchSwitchDispCnt == 0)
	{
		return;
	}
	/* Window Address Add 040920 */
	for(k = iDispOrder - 1;k >= 0; k--){
		WinNum = ScreenTagData[k].iWindowNo;
		if(WinNum == SCREEN_1)
		{
			sX = iWinStartPx;
			sY = iWinStartPy;
		}else{
			sX = 0;
			sY = 0;
		}
		switch(ScreenTagData[k].cObjects){
			case TOUCH_SWITCH:
/*				TouchSwitchEventTbl = (_TOUCHSWICH_EVENT_TBL*)IventTable[k];*/
				if(TouchAreaCheck(ScreenTagData[k].sX+ sX,
								  ScreenTagData[k].sY+ sY, 
								  ScreenTagData[k].eX+ sX, 
								  ScreenTagData[k].eY+ sY,
								  Key.iBuff) == 1)
				{
					Key.iBuff = 0;
				}		
				break;
			case NUMERICAL_INPUT:
/*				NumericInputEventTbl= (_NUMERIC_INPUT_EVENT_TBL*)IventTable[k];*/
				if(TouchAreaCheck(ScreenTagData[k].sX+ sX,
								  ScreenTagData[k].sY+ sY, 
								  ScreenTagData[k].eX+ sX, 
								  ScreenTagData[k].eY+ sY,
								  Key.iBuff) == 1)
				{
					Key.iBuff = 0;
				}					
				break;
			case ASCII_INPUT:

/*				AsciiInputEventTbl= (_ASCIIINPUT_EVENT_TBL*)IventTable[k];*/
				if(TouchAreaCheck(ScreenTagData[k].sX+ sX,
								  ScreenTagData[k].sY+ sY, 
								  ScreenTagData[k].eX+ sX, 
								  ScreenTagData[k].eY+ sY,
								  Key.iBuff) == 1)
				{
					Key.iBuff = 0;
				}
				break;
		}
	}
}
/********************************************************************************/
/* ��E��E��E: DispAnalysis														*/
/* ��E   �� : ȭ��ó���½�ũ ȣ��													*/
/* ��    �� :																	*/
/* ÁE   �� :																	*/
/* �� �� �� : 2002��2��14�� ()													*/
/* �� �� �� : ȫ �� ��																*/
/* ��    �� : ������(����ȣ)													*/
/********************************************************************************/
void	DispAnalysis( STTFrm* pSTT )
{
	int				iRet;
//	int				Cnt;
	int				iKeyBuff2;
	struct			find_t	finddata; 
	T_MAIL			*mp;
	int				BaseChabgeFlag;			/* 050421 */

//	Cnt			= 0;
	iKeyBuff2	= 0;	

	/* indow Initialize */
	SetWindowNo(1);						/* Disp Screen Set */
	while(1){
		mp = (T_MAIL *)WaitRequest();
		if(mp->mcmd == 1){				/* 031021 */
			OffSignal(S_PROJECT,1);
			vScreenDataSet();			/* leesi 03.10.21 */
										/* ó�� ȯ�漳�� ȭ������ �� �� Ŭ�� �Ͽ��� �� */
/*lsi20040524 �߰� */
			if((DeviceCnt==0 || Key.iCode == PC_DNLOAD_START) && iTransFlag != 1){	
				CommonFileSet();
			}
/*lsi20040524*/										
			SendTaskSet(1,0);
			ResponseMail((char *)mp);
			continue;
		}
		ResponseMail((char *)mp);
		if(DeviceCnt != 0 && SwitchingScreenDevice.iBaseScreenFlag == 0){
/* 060926			DeviceCnt = 0;
			memset(DeviceDataHed,0,sizeof(DeviceDataHed));
*/
			ClearDeviceMonInfo();		/* 060926 */
			iOnSignalStart = OFF;
		}
		iOnSignalStart = OFF;

		memset(cPcTempFileName, 0x00, sizeof(cPcTempFileName));
		iRet= m_findfirst("BAS*.*", ATTR_RDO, &finddata);
		if (iRet == OK) {					/* Base File ���� */
			memcpy(cPcTempFileName,finddata.name,strlen(finddata.name)); 
			pcFileCnt = 1;
		}else{
			pcFileCnt = 0;
		}
		SendTaskFile(0);		/* FileTask  0 : BaseScren , 1: WindowScreen */

		BaseChabgeFlag= 0;			/* 050421 */
		while(1){
			Key.iCode = KeyWait();			/*  KEY  */

			if(Key.iCode == PC_UPDOWN_END){	break;	}			//20090117

			/* ���?�F���W Command Recieve */
			if((Key.iCode == CHG_BASE1) || (Key.iCode == CHG_BASE2)){ /*  ?? OWASI  */
				if(Key.iCode == CHG_BASE1){
					SendTaskFile(0);
				}else{
					SendTaskFile(1);
				}
				iKeyBuff2	= 0;		/* 031124 */
				if(Key.iCode == CHG_BASE1){
					BaseChabgeFlag= 1;			/* 050421 */
				}
				continue;
			}
			/* ���?�F���W?�b?��͗����܂ő҂�(00Rec) */
			if(BaseChangeFlag2 == 1){		/* Base Change */
				if(Key.iCode == 0){
					if(BaseChabgeFlag == 0){			/* 050421 */
						Key.iBuff= Key.iCode;
						TouchAreaCheckProc();
					}
					BaseChangeFlag2= 0;
					iKeyBuff2= 0;
				}
				continue;
			}
			BaseChabgeFlag= 0;			/* 050421 */

			if(Key.iCode != 0){
				/* Repeat Flag Clesr */ 
				KerRepeatFlag = 0;
			}
			/* User Display Key In return Set */
			if(iUserScreenFlag != 0 && Key.iCode != 0){
				/* Usr Test Mode Display */
				break;
			}
/************************************************************/
/*	DownLoad CHECK 04.06.07									*/
/************************************************************/
			if(Key.iCode == PC_DNLOAD_START || Key.iCode == PC_UPLOAD_START)
			{	/* Download,Upload Start */
				CloseWindow(MESSAGE_SCREEN);
				if((NumericInputCnt > 0 || AsciiInputCnt > 0) && InputDisplay.iInputNo>=0){
					if(InputDisplay.iKeyOnOff == 2){	/*  Window Close */
						
						CloseWindow(SCREEN_1);
						WindowPointDel();
						vWindowFreemeil(); /* Window���� ���� �޸� ����. */

						InputDisplay.iKeyOnOff = 0;
						memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
						memset(InputDisplay.cBufferData,0x00,sizeof(InputDisplay.cBufferData));
						InputDisplay.iFirstflag = 0;
					}
				}
/* 060926				DeviceCnt = 0;	
				memset(DeviceDataHed,0,sizeof(DeviceDataHed));
*/
				ClearDeviceMonInfo();		/* 060926 */
				iOnSignalStart = OFF;			/* leesi 2002/09/13 */
				break;
			}else if((Set.iMessageFlag == 2 )){		/* Mrssage Display */
#ifdef	SIZE_2480
				if((TateYoko == 0 && (Key.iCode >= KEY_42 && Key.iCode <= KEY_44)) ||			/* Yoko */
					(TateYoko == 1 && (Key.iCode == KEY_39 || Key.iCode == KEY_40 ||
										Key.iCode == KEY_43 || Key.iCode == KEY_44))){
#endif
#ifdef	SIZE_3224
				if((TateYoko == 0 && ((Key.iCode >= 76 && Key.iCode <= 78)||(Key.iCode >= 92 && Key.iCode <= 94))) ||			/* Yoko */
					(TateYoko == 1 && (Key.iCode == KEY_39 || Key.iCode == KEY_40 ||
										Key.iCode == KEY_43 || Key.iCode == KEY_44))){
#endif

					SetWinSema();
					CloseWindow(MESSAGE_SCREEN);
					DrawLcdBank1();
					ResetWinSema();
					NormalBuzzer();	
					if(PLCCnErrorDsp == ON){		/* PLC Error Display */
/*ksc20040623*/
						PLCCnErrorDsp= OFF; /* �̿��� �޼��� ǥ�� ��/�� �÷��� OFF */
						PLCCnNewRec= _TimeMSec;
						PLCCnNewRec2= _TimeMSec;
/*ksc20040623*/
					}
					BaseChangeFlag2= 1;		/* ���ɃL?�������܂ő҂� 050418 */
				}
				continue;
			}else if(Set.iMessageFlag == 1 && Key.iCode == 0){
				Set.iMessageFlag = 2;
			}
/************************************************************/
/***************03/12/16***************** Message Close *****/
			/*********************************************/
			if((ComWinKey.iVal == 2 && (Key.iCode >= 0 && Key.iCode <= MAX_TOUCH_NO))){ /* Numeric, Ascii Input �� �� �Է¹����� ���� ������ ���... */
				continue;
			}else if(ComWinKey.iVal == 1 && (TouchAreaCheck(ComWinKey.sX, ComWinKey.sY, ComWinKey.sX+ALARM_WIDTH, ComWinKey.sY+ALARM_HEIGHT,Key.iCode)==1)){
				SendInitTask(INI_DETAIL_ALARM,Key.iCode);
				continue;
			}else if((InputDisplay.iKeyOnOff == 1 || InputDisplay.iKeyOnOff == 2) && (TouchAreaCheck(iWinStartPx, iWinStartPy, iWinEndPx, iWinEndPy,Key.iCode)==1 || Key.iCode == 0)){
				if(iOnSignalStart==ON)
				{
					Key.iBuff = Key.iCode;
					if(WaitBaseChange == 0)
					{
						if((Key.iCode == 0) || ((Key.iCode != 0) && (iKeyBuff2 == 0)))
						{
							TouchAreaCheckProc();	/* Touch Area Check */
						}
						iKeyBuff2 = Key.iCode;
					}
				}
				continue;
			}else if(((iMainCallSetValue(Key.iCode) && Key.iCode != 0) && 
				(Key.iCode==KEY_YTOP_LEFT || Key.iCode==KEY_YTOP_RIGHT || 
				Key.iCode==KEY_YBTM_LEFT || Key.iCode==KEY_YBTM_RIGHT)) || Key.iCode == KEY_EVENT){
				/*   || iScreenDisp != 0*/	/* ȯ�漳������ �� �� PASSWORD�� ���� �� */
				Key.iBuff= Key.iCode;
				MainTouchAreaCheckProc();
				if(Key.iBuff != 0){
					if(Key.iCode != 0x7f)
						NormalBuzzer();				/*	Buzzer  */
					if(Key.iBuff != 0){
						iOnSignalStart=0;
						break;
					}
				}
			}
/*************************************************************************/
			/* User Key Check */
			if(iOnSignalStart==ON)
			{
				Key.iBuff= Key.iCode;
				TouchAreaCheckProc();
				/* `gamen Change ha Key wo OFF suru 050425 */
				if((BaseChangeFlag1 == 1) || (BaseChangeFlag2 == 1)){
					Key.iBuff= 0;
					TouchAreaCheckProc();
				}
			}
		}
/*************************************************************************/
		if(iScreenDisp != 0 && iUserScreenFlag != 0){		/* ȭ�� �̵� */
			iOnSignalStart = 0;

			if(iUserScreenFlag == 0)
				iScreenDisp = 0;

/* 060926			DeviceCnt = 0;
			memset(DeviceDataHed,0,sizeof(DeviceDataHed));
*/
			ClearDeviceMonInfo();		/* 060926 */
			if(Key.iCode == PC_DNLOAD_START || Key.iCode == PC_UPLOAD_START)	/*  Down, Up Load �϶� ȭ�� ǥ�� (ȯ�漳������..)   */
			{
				CloseWindow(SCREEN_1);
				iOnSignalStart = 0;
/* 060926			DeviceCnt = 0;
			memset(DeviceDataHed,0,sizeof(DeviceDataHed));
*/
			ClearDeviceMonInfo();		/* 060926 */
				OffSignal(SGN_PLC, 0xFFFFFFFF);
				if(Key.iCode == PC_DNLOAD_START)		/* DownLoad	*/
				{												
					SendTaskSet(DOWN_TRANS,0);
				}else if(Key.iCode == PC_UPLOAD_START)	/* UPLoad	*/
				{
					SendTaskSet(UP_TRANS,0);
				}
			}
			else if(iUserScreenFlag == 1)
			{
				Key.iCode = -1;
				NormalBuzzer();				/*	Buzzer			*/
				SendTaskSet(BASE_SCREEN_NUM,0);			/* Base Screen ȭ������...	 030703	leesi */
			}
			else
			{
				Key.iCode = -1;
				NormalBuzzer();				/*	Buzzer			*/
				SendTaskSet(WINDOW_SCREEN_NUM,0);		/* Window Screen ȭ������... 030703	leesi */
			}
		}else if (iMainCallSetValue(Key.iCode) || Key.iCode == KEY_EVENT) { /* ȯ�漳������... */

			MomentaryOff();		/* Momentary OFF 050321 */

			if(ComWinKey.iVal == 1)			/* AlarmDetail ���� �� �ݱ� ���� */
			{
				SendInitTask(INI_DETAIL_ALARM,Key.iCode);
			}
			CloseWindow(SCREEN_1);
			iOnSignalStart = 0;
			Key.iCode = -1;
			if(DeviceCnt != 0){
/* 060926			DeviceCnt = 0;
			memset(DeviceDataHed,0,sizeof(DeviceDataHed));
*/
			ClearDeviceMonInfo();		/* 060926 */
				iOnSignalStart = OFF;
			}
			SendTaskSet(1,0);
		}else if(Key.iCode == PC_DNLOAD_START || Key.iCode == PC_UPLOAD_START){		/*  Down, Up Load �϶� ȭ�� ǥ�� (ȯ�漳������..)   */	/*  || Key.iCode == PC_ON */
			CloseWindow(SCREEN_1);
			iOnSignalStart = 0;
/* 060926			DeviceCnt = 0;
			memset(DeviceDataHed,0,sizeof(DeviceDataHed));
*/
			ClearDeviceMonInfo();		/* 060926 */
			OffSignal(SGN_PLC, 0xFFFFFFFF);
			if(Key.iCode == PC_DNLOAD_START)		/* DownLoad	*/
			{												
				SendTaskSet(DOWN_TRANS,0);
			}else if(Key.iCode == PC_UPLOAD_START)	/* UPLoad	*/
			{
				SendTaskSet(UP_TRANS,0);
			}
		}else if(Key.iCode == PC_UPDOWN_END){
		}

		if(Key.iCode == PC_DNLOAD_START || iMainCallSetValue(Key.iCode) || iScreenDisp != 0 || Key.iCode == PC_UPLOAD_START || Key.iCode == KEY_EVENT)
		{
			if((NumericInputCnt > 0 || AsciiInputCnt > 0) && InputDisplay.iInputNo>=0){
				if(InputDisplay.iKeyOnOff == 2){

					CloseWindow(SCREEN_1);
					WindowPointDel();
					vWindowFreemeil(); /* Window���� ���� �޸� ����. */

					InputDisplay.iKeyOnOff = 0;
					memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
					memset(InputDisplay.cBufferData,0x00,sizeof(InputDisplay.cBufferData));
					InputDisplay.iFirstflag = 0;
				}
			}
		}
	}
}
/* ****************************************************************************** */
/*  �Լ�����																	  */
/* ****************************************************************************** */
void	SendTaskAnal(int p1)
{
	T_MAIL	*mp;
	mp = (T_MAIL *)TakeMail();
	mp->mcmd = p1;   /* Base ȭ��   */
	SendMail(T_DISPANALYSIS,(char *)mp);
}
