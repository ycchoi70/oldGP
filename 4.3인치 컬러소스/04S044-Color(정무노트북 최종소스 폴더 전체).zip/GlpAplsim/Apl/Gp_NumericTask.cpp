/********************************************************************************/
/* �� �� �� : Gp_NumericTask.cpp												*/
/* ��    �� : NumericTask														*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"
/********************************************************************************/
/* �� �� �� : DrawNumeric_Func													*/
/* ��    �� : Numeric ������ �ص��Ͽ� ȭ�鿡 ���								*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 22�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetNumeric_Func(int iDispOrder)
{
	_NUMERIC_EVENT_TBL*	 NumericEventTbl;
	NumericEventTbl= (_NUMERIC_EVENT_TBL*)TakeMemory(sizeof(_NUMERIC_EVENT_TBL));
	DrawNumeric_Func(0,NumericEventTbl,iDispOrder);
	FreeMail((char *)NumericEventTbl);

}
int	DrawNumeric_Func(int mode,_NUMERIC_EVENT_TBL* NumericEventTbl,int iDispOrder)
{
/*	int					iTagSizeOf;*//* �±���������ü������ ������ ���� */
	int					iOffset;
	unsigned int		iFormatUpper;
	unsigned int		iFormatLower;
	unsigned char		*buffer;

	buffer= ScreenTagData[iDispOrder].TagPos;
/*	_NUMERIC_EVENT_TBL*	 NumericEventTbl;*/
/*
	if(CheckMailBox(sizeof(_NUMERIC_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_NUMERIC_EVENT_TBL));
	NumericEventTbl= (_NUMERIC_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)NumericEventTbl, 0x00, sizeof(_NUMERIC_EVENT_TBL));

/*	iTagSizeOf		= 0;*/
	iFormatUpper	= 0;
	iFormatLower	= 0;
/*		
	iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
	iTagSizeOf += (unsigned int)buffer[1] & 0xff;
	NumericEventTbl->sX  = (unsigned int)(buffer[6] << 0x08);
	NumericEventTbl->sX += (unsigned int)buffer[7] & 0xff;

	NumericEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
	NumericEventTbl->sY += (unsigned int)buffer[9] & 0xff;

	NumericEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
	NumericEventTbl->eX += (unsigned int)buffer[11] & 0xff;

	NumericEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
	NumericEventTbl->eY += (unsigned int)buffer[13] & 0xff;
*/	
	
	NumericEventTbl->iPlateColor = (unsigned int)buffer[14];	/* PlateColor */
	NumericEventTbl->iFrameColor = (unsigned int)buffer[15];	/* FrameColor */

	NumericEventTbl->iFontSizeH  = (unsigned int)buffer[16];	/* FontSizeV   6*8dot�� ����ϸ� �� ����Ʈ�� 0x00�� ��ȯ�ȴ� */
	NumericEventTbl->iFontSizeV  = (unsigned int)buffer[17];	/* FontSizeH  */
	if((unsigned int)buffer[18]<3)
		NumericEventTbl->i1632BitFlag = BIT16;	/* 16bit/signed:0x01, 16bit/unsigned:0x02, 32bit/signed:0x03, 32bit/unsigned:0x04 */
	else
		NumericEventTbl->i1632BitFlag = BIT32;
	if((unsigned int)buffer[18] == 1 || (unsigned int)buffer[18] == 3)
		NumericEventTbl->iSignFlag = SIGNED;
	else
		NumericEventTbl->iSignFlag = UNSIGNED;

	/*------------------------------------------------------------*/
	iOffset = 19;
	GetDeviceSet((buffer+iOffset),
				NumericEventTbl->cDeviceName,
				&(NumericEventTbl->iDeviceNumber));
	iOffset += 5;
	/*-------------------------------------------------------------*/		

	iFormatUpper =  (unsigned int)(buffer[iOffset] & 0xF0);			/* 24 */
	
	iFormatLower =  (unsigned int)(buffer[iOffset] & 0x0F);

	switch(iFormatUpper){
	case 0x10:
		NumericEventTbl->iFormat = 0x00;	/* Signed Decimal */
		break;
	case 0x20:
		NumericEventTbl->iFormat = 0x01;	/* Unsigned Decimal */
		break;
	case 0x30:
		NumericEventTbl->iFormat = 0x02;	/* HexaDecimal */
		break;
	case 0x50:
		NumericEventTbl->iFormat = 0x03;	/* Octal */
		break;
	case 0x00:
		NumericEventTbl->iFormat = 0x04;	/* Binary */
		break;
	case 0x40:
		NumericEventTbl->iFormat = 0x05;	/* Real */
		break;
	}

	switch(iFormatLower){
	case 0x04:
		NumericEventTbl->iAlignment = 0x00;	/* Right Alignment */
		break;
	case 0x05:
		NumericEventTbl->iAlignment = 0x01;	/* Left Alignment */
		break;
	case 0x06:
		NumericEventTbl->iAlignment = 0x02;	/* Center Alignment */
		break;
	case 0x00:
		NumericEventTbl->iAlignment = 0x03;	/* Disp All Digits Checked (�տ� ��� 0�� ä���.) */
		break;
	}
	NumericEventTbl->iTextColor = (unsigned int)buffer[++iOffset];	/* 25 */
	NumericEventTbl->iDecimalPnt = (unsigned int)buffer[++iOffset];	/* 26 */
	NumericEventTbl->iDigits = (unsigned int)buffer[++iOffset];		/* 27 */
		
	if((unsigned int)(buffer[++iOffset]) == 0x00){					/* 28 */
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed = UNCHECKED;
		}
		NumericEventTbl->ShapeNo = 0x00;
		iOffset++;
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed= UNCHECKED;
		}
	}
	else{
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed = CHECKED;
		}
		NumericEventTbl->ShapeNo = (unsigned int)(buffer[++iOffset]);	/* 29 */
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed= CHECKED;
		}
	}
#ifdef	WIN32
	NumericEventTbl->iGain1 = (unsigned int)buffer[++iOffset] << 0x18;				/* 30 */
	NumericEventTbl->iGain1 += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10;/* 31 */
	NumericEventTbl->iGain1 += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;	/* 32 */
	NumericEventTbl->iGain1 += (unsigned int)buffer[++iOffset] & 0xff;				/* 33 */

	NumericEventTbl->iGain2 = (unsigned int)buffer[++iOffset] << 0x18;				/* 34 */
	NumericEventTbl->iGain2 += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10;/* 35 */
	NumericEventTbl->iGain2 += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;	/* 36 */
	NumericEventTbl->iGain2 += (unsigned int)buffer[++iOffset] & 0xff;				/* 37 */

	NumericEventTbl->iOffset = (unsigned int)buffer[++iOffset] << 0x18;				/* 38 */
	NumericEventTbl->iOffset += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10;/* 39 */
	NumericEventTbl->iOffset += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;	/* 40 */
	NumericEventTbl->iOffset += (unsigned int)buffer[++iOffset] & 0xff;				/* 41 */
#else
	iOffset++;
	memcpy(&NumericEventTbl->iGain1,&buffer[iOffset],4);				/* 30 */
	iOffset += 4;
	memcpy(&NumericEventTbl->iGain2,&buffer[iOffset],4);				/* 30 */
	iOffset += 4;
	memcpy(&NumericEventTbl->iOffset,&buffer[iOffset],4);				/* 30 */
	iOffset += 3;
#endif
	if((unsigned int)buffer[++iOffset] != 0)										/* 42 */
	{
		NumericEventTbl->iFontSizeH = 0;
		NumericEventTbl->iFontSizeV = 0;		//20101207
	}
	NumericEventTbl->iHighQuality = (unsigned int)buffer[++iOffset];				/* 43 */
	if(mode == 0){

		DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */
		DeviceDataHed[DeviceCnt].DevName[0] = NumericEventTbl->cDeviceName[0];
		DeviceDataHed[DeviceCnt].DevName[1] = NumericEventTbl->cDeviceName[1];
		DeviceDataHed[DeviceCnt].DevAddress = NumericEventTbl->iDeviceNumber;
		
		
		DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];		
/*		NumericEventTbl->iRegisterNumber = DeviceCnt;		
*/
		ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
		if(NumericEventTbl->i1632BitFlag == BIT16){/* 16bit */
			DeviceDataHed[DeviceCnt].DevCnt = 1;		
			iDeviceOffset+=2;
		}else{/* 32bit */
			iDeviceOffset+=4;
			DeviceDataHed[DeviceCnt].DevCnt = 2;			
		}				
		ScreenTagData[iDispOrder].DevCnt= DeviceDataHed[DeviceCnt].DevCnt*2;
		/* 20020819 choijh add*/
/*
		NumericEventTbl->SuperVOffset= WatchingDevice(NumericEventTbl->cDeviceName, 
										 NumericEventTbl->iDeviceNumber, 
										 NumericEventTbl->i1632BitFlag,
										 NumericEventTbl->iRegisterNumber,
										 WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/

		DeviceCnt++;
	}
/*	IventTableCnt++;*/

	return(0);
}
/**************** 030705 */
void	SetRealPos(int iSTemp, char *cImsiData,int iDigits)
{
	int		i,j;
	int		flag;

	flag= 0;
	for(i= 0; ; i++){
		if(cImsiData[i] == 0){
			break;
		}
		if(cImsiData[i] == '.'){
			flag= 1;
			i++;
			break;
		}
	}
	if(flag == 1){
		if((iSTemp + i + 1) > iDigits){
			for(i= 0; i < iDigits; i++){
				cImsiData[i] = 'H';
			}
			cImsiData[i] = 0;
		}else{
			flag= 0;
			for(j= 0; j < iSTemp ; i++,j++){
				if(cImsiData[i] == 0){
					flag= 1;
				}
				if(flag == 1){
					cImsiData[i]= '0';
				}
			}
			cImsiData[i]= 0;
		}
	}
}
/********************************************************************************/
/* �� �� �� : NumericDispWatch													*/
/* ��    �� : Numeric�±������� ����  ȭ�鿡 ����� ����Ѵ�.					*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 27�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	NumericDispWatch(int iOrder)
{
	int				iAlignment;
	int				sX;
	int				sY;
	int				eX;
	int				eY;
	int				iFormatStyle;/* ȭ�� ��� ��Ÿ��(2����, 8����....) */	
	int				iDigits;
	int				Font_Color;
	int				Back_Color;
	int				iType;
	int				iXval;
	int				iFontVal;
	short			iSTemp;
	long			lDeviceValue;
	short			iShapeSize;
	char			cDisplayFormat[10];
	char*			cTempBuffer;
	char*			cDispBuffer;
	char*			cTemp;
	char*			cImsiData;
//	unsigned char	*buffer;		/* 20080822 */
	char			work[16];
	_NUMERIC_EVENT_TBL*	NumericEventTbl;		/* 030401 */

//	buffer= ScreenTagData[iOrder].TagPos;		/* 20080822 */

	iAlignment		= 0;
	sX				= 0;
	sY				= 0;
	eX				= 0;
	eY				= 0;
	iFormatStyle	= 0;    /* ȭ�� ��� ��Ÿ��(2����, 8����....) */	
	iDigits			= 0;
	Font_Color		= 0;
	Back_Color		= 0;
	iType			= 0;
	iXval			= 0;
	iFontVal		= 0;
	iSTemp			= 0;
	iShapeSize		= 0;


/*	NumericEventTbl = (_NUMERIC_EVENT_TBL*)IventTable[iOrder];*/
	NumericEventTbl = (_NUMERIC_EVENT_TBL*)TakeMemory(sizeof(_NUMERIC_EVENT_TBL));
	/*memset(cDisplayFormat, 0x00, sizeof(cDisplayFormat));*/
	DrawNumeric_Func(1,NumericEventTbl,iOrder);
			
	sX = ScreenTagData[iOrder].sX;
	eX = ScreenTagData[iOrder].eX;
	sY = ScreenTagData[iOrder].sY;
	eY = ScreenTagData[iOrder].eY;
	/* Shape�� ���� ��� Shape�� �׸���. */
	if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){
		iShapeSize = DrawShape(NumericEventTbl->ShapeNo,
								ScreenTagData[iOrder].sX,
								ScreenTagData[iOrder].sY,
								ScreenTagData[iOrder].eX,
								ScreenTagData[iOrder].eY,
								NumericEventTbl->iFrameColor,
								NumericEventTbl->iPlateColor);
		sX+=iShapeSize;
		sY+=iShapeSize;
		eX-=iShapeSize;
		eY-=iShapeSize;
	}
	if(strlen(NumericEventTbl->cDeviceName))
	{
		iDigits			= NumericEventTbl->iDigits;
		iAlignment		= NumericEventTbl->iAlignment;
		iFormatStyle	= NumericEventTbl->iFormat;	

/*		lDeviceValue = NumericEventTbl->lBefDevBal;*/
		memcpy(work,&DispDeviceData[ScreenTagData[iOrder].DevOrder],ScreenTagData[iOrder].DevCnt*2);
		if(NumericEventTbl->iSignFlag == SIGNED){
			lDeviceValue = ChangeChar2long(work,NumericEventTbl->i1632BitFlag);
		}else{
			lDeviceValue = ChangeChar2Unsinlong(work,NumericEventTbl->i1632BitFlag);
		}
		cImsiData = (char*)TakeMemory(iDigits+1);
		cTemp = (char*)TakeMemory(iDigits+1);
		memset(cImsiData,0x00,iDigits+1);
		/* ���� */

		if(NumericEventTbl->iGain2==0)
			NumericEventTbl->iGain2 = 1;
		if(NumericEventTbl->iGain1==0)
			NumericEventTbl->iGain1 = 1;
		lDeviceValue = NumericEventTbl->iOffset + ((lDeviceValue * NumericEventTbl->iGain1)/NumericEventTbl->iGain2);
/* 070205 		if(iFormatStyle != SIGNED_DECIMAL){	*//* 06050203 */
		if((iFormatStyle != SIGNED_DECIMAL) && (NumericEventTbl->i1632BitFlag == 0)){	/* 06050203 */
			lDeviceValue= lDeviceValue & 0xffff;
		}

		cTempBuffer		= (char*)TakeMemory(iDigits + 1);
		memset(cTempBuffer, 0x00, iDigits + 1);
			
		cDispBuffer	= (char*)TakeMemory(iDigits + 1);
		memset(cDispBuffer, 0x00, iDigits + 1);
		memset(cDispBuffer, 0x20, iDigits);
		memset(cImsiData, 0x00, iDigits + 1);

		NumericFormFormat(cTempBuffer, iDigits, cTempBuffer,
						iFormatStyle, lDeviceValue,	
						NumericEventTbl->i1632BitFlag,
						NumericEventTbl->iDecimalPnt);	/* Form Format ����. */
		strcpy(cImsiData,cTempBuffer);
		memset(cDisplayFormat,0x00,sizeof(cDisplayFormat));
		if(iAlignment == DISPALLCHK_ALIGN){		/* Disp All Digits Checked (�տ� ��� 0�� ä���.) */
			sprintf(cDisplayFormat, "%%0%d%s",iDigits, "s");
		}else{
			strcpy(cDisplayFormat, "%s");		/* RIGHT_ALIGN, LEFT_ALIGN, CENTER_ALIGN */
		}

		if(iFormatStyle == SIGNED_DECIMAL || 
			iFormatStyle == UNSIGNED_DECIMAL
			){/* Signed Decimal, Unsinged Decimal, Real (|| iFormatStyle == REAL)*/

			iSTemp = NumericEventTbl->iDecimalPnt;

			if(iFormatStyle == REAL){		/* Floating */
				if((iSTemp != 0) && ((cImsiData[0] != 'L') || (cImsiData[0] != 'H'))){
					SetRealPos(iSTemp,cImsiData,iDigits);
				}
				strcpy(cDispBuffer,cImsiData);
			}else{
				if(iSTemp != 0){					
					NumericPointDisplay(cTemp,
										cImsiData,
										iDigits,
										iSTemp);	/*  �Ҽ����� ���ó���� �Ѵ�. */
					sprintf(cDispBuffer, cDisplayFormat, cTemp);
				}else{
					if(iAlignment == DISPALLCHK_ALIGN){
						NumericZeroDisplay(cDispBuffer,cImsiData,iDigits);
					}
					else
						sprintf(cDispBuffer, cDisplayFormat, cImsiData);
				}
			}
		}else{/* Hexa Decimal, Binary, Octal */
				sprintf(cDispBuffer, cDisplayFormat, cImsiData);
		}
		Font_Color = NumericEventTbl->iTextColor;
		if(Font_Color == 0)
		{
			Back_Color	= WHITE;	
			iType		= T_FRONT;
		}else
		{
			Back_Color = BLACK;
			iType      = T_OR;
		}

		if(NumericEventTbl->iFontSizeH == 0){
			iFontVal = 6;
		}else{
			iFontVal = 8;
			if(NumericEventTbl->iFontSizeH > 1)
				iFontVal = NumericEventTbl->iFontSizeH * 8;
		}
		iXval = 0;
		if(iAlignment == 0x00)
		{
			iXval =  (eX+1-sX)-(strlen(cDispBuffer)*iFontVal);
		}
		else if(iAlignment==0x02)
		{
			iXval = ((eX+1-sX)-(strlen(cDispBuffer)*iFontVal))/2;
		}

		if(NumericEventTbl->iHighQuality == 0x00)
		{
			if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){
				DotTextOut((sX + iXval), 
							sY, cDispBuffer, 
							NumericEventTbl->iFontSizeH, 
							NumericEventTbl->iFontSizeV, 
							iType, Font_Color, Back_Color);
			}else{
				DotTextOut(	sX + iXval, sY, 
					cDispBuffer, 
					NumericEventTbl->iFontSizeH, 
					NumericEventTbl->iFontSizeV, 
					iType, Font_Color, Back_Color);
			}
		}else
		{
			if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){
				DotTextOut2((sX + iXval), 
							sY, cDispBuffer, 
							NumericEventTbl->iFontSizeH, 
							NumericEventTbl->iFontSizeV, 
							iType, Font_Color, Back_Color);
			}else{
				DotTextOut2(sX + iXval, sY, cDispBuffer, 
					NumericEventTbl->iFontSizeH, 
					NumericEventTbl->iFontSizeV, 
					iType, Font_Color, Back_Color);
			}
		}
		FreeMail(cImsiData);
		FreeMail(cTemp);
		FreeMail(cTempBuffer);
		FreeMail(cDispBuffer);
	}
	FreeMail((char *)NumericEventTbl);
}

void	NumericDispLenstr(char* cDispBuffer, int iDigits)
{
	char	*cpBuffer;
	int		iDatalen = 0;

	iDatalen = strlen(cDispBuffer);
	if(iDatalen > iDigits)
	{
		cpBuffer = TakeMemory(strlen(cDispBuffer)+1);
		memset(cpBuffer,0x00,strlen(cDispBuffer)+1);
		strncpy(cpBuffer, cDispBuffer+(iDatalen-iDigits), iDigits);
		strncpy(cDispBuffer,cpBuffer,iDigits + 1);
		FreeMail(cpBuffer);
	}

	return;
}
