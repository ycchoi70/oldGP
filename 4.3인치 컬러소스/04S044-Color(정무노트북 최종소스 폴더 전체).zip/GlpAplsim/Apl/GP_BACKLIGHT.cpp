/* ****************************************************************************** */
/*  �� �� ��E: GP_BACKLIGHT.CPP													 */
/*  ��E   �� : �����Ʈ ���ӽð� ����											 */
/*  �� �� �� : 2002��E2��E16�� (ŁE												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��    �� : (��) LC Tech														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

/* ****************************************************************************** */
/*  ��E��E��E: vBackLightSet()														 */
/*  ��E   �� : �����Ʈ ���ӽð� ���� ó��										 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E2��E16�� (ŁE												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
#ifdef	SIZE_2480
void		vBackLightSet(int* iScreenNo)
{
	int		iKeyCode;
	int		iLong;											/* ����� ������ ���� */	
	int		iLen;
//	int		iFlagData;
	short	iButtenFlag;
	short	iFocusFlag;										/* ���� ��Ŀ�� �÷��� */
//	short	iDelFocusFlag;
	short	iKeyFlag;
	short	iOldTime;
	char	chDsp_buff[4];		
	char	chSetTemp[4];									/* ������ �ӽ� ����� */

	memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
	memset(chSetTemp, 0x00, sizeof(chSetTemp));

	iKeyFlag		= 1;
//	iFlagData		= 0;
//	iDelFocusFlag	= 0;
	iKeyCode		= -1;
	iFocusFlag		= 1;									/* ���� ��Ŀ�� �÷��� */
	iLong			= 0;									/* ����� ������ ���� */	
	iLen			= 0;
	iButtenFlag		= 0;
	iOldTime		= Set.iBackLightTime;
	DefaultFormDisplay(KEY_FORM,Dspname[BACKLIGHT].chTitle[Set.iLang]);

	DotTextOut(GAMEN_START_X+132,GAMEN_START_Y+29,Dspname[BACKLIGHT].chName[Set.iLang][0],1,1, TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+207,GAMEN_START_Y+56,Dspname[BACKLIGHT].chName[Set.iLang][1],1,1, TRANS, T_WHITE, T_BLACK);

	itoa(Set.iBackLightTime, chDsp_buff, 10);
	DotTextOut(GAMEN_START_X+185-((strlen(chDsp_buff)-1)*8),GAMEN_START_X+56,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);		


/*ksc20040514*/	
	if(iFocusFlag == 1)
	{
		iFocusFlag = 0;
		itoa(Set.iBackLightTime, chDsp_buff, 10);
		iLen = strlen(chDsp_buff);
		if(iLen == 1)
		{
			DotTextOut(GAMEN_START_X+185,GAMEN_START_Y+56,chDsp_buff,1,1,TRANS, T_WHITE, T_BLACK);
			DotTextOut(GAMEN_START_X+177,GAMEN_START_Y+56," ",1,1,TRANS, T_WHITE, T_BLACK);
		}
		else
		{
			DotTextOut(GAMEN_START_X+177,GAMEN_START_Y+56,chDsp_buff,1,1,TRANS, T_WHITE, T_BLACK);
		}
		AreaRevers(GAMEN_START_X+185,GAMEN_START_Y+56,GAMEN_START_X+192,GAMEN_START_Y+56+15);
		memset(chDsp_buff,0x00,sizeof(chDsp_buff));
//		iDelFocusFlag = 0;
	}
/*ksc20040514*/				


	DrawLcdBank1();
	while ( *iScreenNo == BACKLIGHT_NUM ) {

		iKeyCode = KeyWaitData(iKeyFlag,BACKLIGHT_NUM);							/*  �Էµ� Ű���� �о��	 */
		iKeyFlag = 0;
/*ksc20040513 Key area ���� */
		if ((iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) ||
			 iKeyCode == KEY_01 || iKeyCode == KEY_02   || 
			(iKeyCode >= KEY_16 && iKeyCode <= KEY_23)  ||
			(iKeyCode >= KEY_31 && iKeyCode <= KEY_38)  ||
			(iKeyCode >= KEY_46 && iKeyCode <= KEY_53)  ||
			(iKeyCode >= KEY_56 && iKeyCode <= KEY_58)) 
/*ksc20040513*/
		{
				iKeyFlag = 1;
				NormalBuzzer();				/*	Buzzer  */
		}
		
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}
		memset(chSetTemp, 0x00, sizeof(chSetTemp));
		if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) 
		{
			*iScreenNo = USER_SCREEN_NUM;
		}else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) 
		{										/*  END				 */
//			iFlagData = 1;
			*iScreenNo = SET_ENVIRONMENT_NUM;
			memset(chSetTemp, 0x00, sizeof(chSetTemp));

/*		
		} else if (iKeyCode == KEY_57 || iKeyCode == KEY_58) 
		{										  ���� ��Ŀ��		 
*/
/*ksc20040513*/
		} else if (iKeyCode == KEY_56 || iKeyCode == KEY_57 || iKeyCode == KEY_58) 
		{										/*  ���� ��Ŀ��		 */
/*ksc20040513*/				
				iFocusFlag = 0;
				itoa(Set.iBackLightTime, chDsp_buff, 10);
				iLen = strlen(chDsp_buff);
				if(iLen == 1)
				{
					DotTextOut(GAMEN_START_X+185,GAMEN_START_Y+56,chDsp_buff,1,1,TRANS, T_WHITE, T_BLACK);
					DotTextOut(GAMEN_START_X+177,GAMEN_START_Y+56," ",1,1,TRANS, T_WHITE, T_BLACK);
				}
				else
				{
					DotTextOut(GAMEN_START_X+177,GAMEN_START_Y+56,chDsp_buff,1,1,TRANS, T_WHITE, T_BLACK);
				}
				AreaRevers(GAMEN_START_X+185,GAMEN_START_Y+56,GAMEN_START_X+192,GAMEN_START_Y+56+15);
				memset(chDsp_buff,0x00,sizeof(chDsp_buff));
//				iDelFocusFlag = 0;
			
		} else if (iKeyCode == KEY_33 || iKeyCode == KEY_34 ) 
		{										/*  5 ��ư			 */
			strcpy(chSetTemp, "5");
		} else if (iKeyCode == KEY_35 || iKeyCode == KEY_36 ) 
		{										/*  6 ��ư			 */
			strcpy(chSetTemp, "6");
		} else if (iKeyCode == KEY_37 || iKeyCode == KEY_38 ) 
		{										/*  7 ��ư			 */
			strcpy(chSetTemp, "7");
		} else if (iKeyCode == KEY_46 || iKeyCode == KEY_47)
		{										/*  8 ��ư			 */
			strcpy(chSetTemp, "8");
		} else if (iKeyCode == KEY_48 ||iKeyCode == KEY_49 ) 
		{										/*  9 ��ư			 */
			strcpy(chSetTemp, "9");
		} else if (iKeyCode == KEY_50 || iKeyCode == KEY_51 ) 
		{										/*  CLR ��ư		 */
			if (iFocusFlag == 0)
			{
				iFocusFlag = 1;
				itoa(Set.iBackLightTime, chDsp_buff, 10);
				DotTextOut(GAMEN_START_X+177,GAMEN_START_Y+56," ",1,1,TRANS, T_WHITE, T_BLACK);
				DotTextOut(GAMEN_START_X+185-((strlen(chDsp_buff)-1)*8),GAMEN_START_Y+56,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);		
				DrawLcdBank1();
			}
//			iDelFocusFlag = 0;
		} else if (iKeyCode == KEY_16 || iKeyCode == KEY_17 ) 
		{										/*  0 ��ư			 */
			if(strcmp(chDsp_buff,"0")!=0)
				strcpy(chSetTemp, "0");
		} else if (iKeyCode == KEY_18 || iKeyCode == KEY_19 ) 
		{										/*  1 ��ư			 */
			strcpy(chSetTemp, "1");
		} else if (iKeyCode == KEY_20 || iKeyCode == KEY_21 ) 
		{										/*  2 ��ư			 */
			strcpy(chSetTemp, "2");
		} else if (iKeyCode == KEY_22 || iKeyCode == KEY_23) 
		{										/*  3 ��ư			 */
			strcpy(chSetTemp, "3");
		} else if (iKeyCode == KEY_31 || iKeyCode == KEY_32) 
		{										/*  4 ��ư			 */
			strcpy(chSetTemp, "4");
		} else if (iKeyCode == KEY_52 || iKeyCode == KEY_53 ) 
		{										/*  ENT ��ư		 */
			if (iFocusFlag == 0)
			{
//				iDelFocusFlag = 0;
//				iFlagData = 1;
				iLong = gatoi(chDsp_buff);  /* 20080822 */
				if(chDsp_buff[0] != 0x20 && chDsp_buff[0] != 0x00){
/* 060920					if ( iLong <= 99 && iLong > 0 ) */
					if ( iLong <= 99 && iLong >= 0 ) 
					{
						Set.iBackLightTime = iLong;
						iFocusFlag = 1;
						itoa(Set.iBackLightTime, chDsp_buff, 10);
						DotTextOut(GAMEN_START_X+185-((strlen(chDsp_buff)-1)*8),GAMEN_START_Y+56,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);		
						memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
					/*	mWriteSettei();*/
						DrawLcdBank1();
					} else {
						iCaptionWindow(Dspname[SET_FUNTION].chName[Set.iLang][9],"");			/*  ��ư �ϳ� �޼���E�ڽ� ǥ��  */
						DefaultFormDisplay(KEY_FORM,Dspname[BACKLIGHT].chTitle[Set.iLang]);

						DotTextOut(GAMEN_START_X+132,GAMEN_START_Y+29,Dspname[BACKLIGHT].chName[Set.iLang][0],1,1, TRANS, T_WHITE, T_BLACK);
						DotTextOut(GAMEN_START_X+207,GAMEN_START_Y+56,Dspname[BACKLIGHT].chName[Set.iLang][1],1,1, TRANS, T_WHITE, T_BLACK);
						DotTextOut(GAMEN_START_X+185-((strlen(chDsp_buff)-1)*8),GAMEN_START_Y+56,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);		
						AreaRevers(GAMEN_START_X+185,GAMEN_START_Y+56,GAMEN_START_X+192,GAMEN_START_Y+56+15);
					}
				}
			} 	

		}else
		{
			iKeyCode = -1;
		}		
		if ( iFocusFlag == 0 && strlen(chSetTemp) != 0)
		{
			if(iButtenFlag != 0 || strlen(chDsp_buff)==0)
			{
				strcpy(chDsp_buff,"  ");
				DotTextOut(GAMEN_START_X+177,GAMEN_START_Y+56,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
				memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
			}
			strcat(chDsp_buff,chSetTemp);
			iLen = strlen(chDsp_buff);
			if(iLen > 2)
			{
				strncpy(chSetTemp,chDsp_buff+1,2);
				strcpy(chDsp_buff,chSetTemp);
			}
			if(chDsp_buff[0]==0x30 && strlen(chDsp_buff) == 2)
			{
				chDsp_buff[0] = chDsp_buff[1];
				chDsp_buff[1] = 0x00;
			}
			iLen = strlen(chDsp_buff);
			if(iLen == 1)
			{
				DotTextOut(GAMEN_START_X+185,GAMEN_START_Y+56,chDsp_buff,1,1,TRANS, T_WHITE, T_BLACK);
				DotTextOut(GAMEN_START_X+177,GAMEN_START_Y+56," ",1,1,TRANS, T_WHITE, T_BLACK);
			}
			else
			{
				DotTextOut(GAMEN_START_X+177,GAMEN_START_Y+56,chDsp_buff,1,1,TRANS, T_WHITE, T_BLACK);
			}
			AreaRevers(GAMEN_START_X+185,GAMEN_START_Y+56,GAMEN_START_X+192,GAMEN_START_Y+56+15);
			
			if(iButtenFlag != 0)
			{
				memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
				if(iButtenFlag == -1)
					iFocusFlag = 1;
			}
		}else
		{
			memset(chSetTemp, 0x00, sizeof(chSetTemp));
		}
		if(iKeyCode > 0 && iFocusFlag == 0)
		{
			memset(chSetTemp, 0x00, sizeof(chSetTemp));
			iButtenFlag = 0;
			DrawLcdBank1();
		}
	} 
	if(Set.iBackLightTime != iOldTime)
		mWriteSettei();
	return;
}
#endif
