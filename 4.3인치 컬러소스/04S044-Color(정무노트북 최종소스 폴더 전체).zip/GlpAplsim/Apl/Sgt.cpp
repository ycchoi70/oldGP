/********************************************************************************/
/* �� �� ��E: Sgt.cpp															*/
/* ��E   �� : ���� TASK ��?E												*/
/* �� �� �� : 2002��E2��E7�� (��E												*/
/* �� �� �� : ȫ �� ��E														*/
/* ��    �� : (��) LC Tech														*/
/* ��E   ��E: 																	*/
/********************************************************************************/
#define MAIN
#include	"stdio.h"
#include	"sgt.h"
#include	"graphics.h"

extern	void	FlashProcMoce(void);
extern	void	_INIT( void );
unsigned	FileTaskTime;
#ifndef WIN32
//	extern	const	DISPLAY_TBL	DspnameTbl;
//	extern	const	_DISPLAY DspnameData[];
//	extern	const	_DISPLAY1	LargDispName[];
#else
	extern	volatile	_DISPLAY	DspnameData[];
	extern	volatile	DISPLAY_TBL	DspnameTbl;
#endif

void		SendTaskSet( int p1,int p2 )
{
	T_MAIL	*mp;

	while(1){
		mp= (T_MAIL *)AcceptMail(T_DISP_TASK);
		if(mp == NULL){	break;	}
		Delay(50);
	}
	while(1){
		if((WaitDisplayTask == 0) && (WaitClassifTask == 0)){	break;	}
		Delay(50);
	}
	WaitSetting= 1;
	SetTask(p1,p2);
	WaitSetting= 0;

}
void	SendTaskFile( int p1 )
{
	int		ret;
#ifdef	LP_S044
	int		DiffTime;

/* 20080822 ���� ���� ������ ������ �߰��ߴ��� Ȯ�� �ʿ�, ��ġ�� ���ߴ� ������ ������ �ٸ���.*/
	DiffTime= ReadTimeMsec()- FileTaskTime;
	if(DiffTime < 200){
		Delay(200- DiffTime);
	}
#endif

	FileTask(p1);
	FileTaskTime= _TimeMSec;
	while(1){
		ret= KeyAccept();
		if(ret == -1){	break;	}
		/* ���?�F���W?�b?��͗����܂ő҂� */
		if(BaseChangeFlag2 == 1){		/* Base Change */
			if(ret == 0){	BaseChangeFlag2= 0;	}
		}
	}
}
void	SendInitTask(int mcod,int mcmd)
{
	T_MAIL	*mp;

	mp = (T_MAIL *)TakeMail();
	mp->mcod = mcod;					/* AlarmDetail (0 : Open  1 : Close) */
	mp->mcmd = mcmd;
	SendMail(T_INITASK,(char *)mp);
}
/* 060926 */
void	ClearDeviceMonInfo(void)
{
	DeviceCnt = 0;
	memset(DeviceDataHed,0,sizeof(DeviceDataHed));
	iDeviceOffset = 0;
}
void	SetSystemMessegeTbl(void)
{

/* 20080822 Arm������ ���̺� ���� */
	DISPLAY_TBL*	DispTable;
#ifdef	WIN32
	#ifdef	SIZE_3224
		DispTable= (DISPLAY_TBL*)&DspnameTbl;
		Dspname= DispTable->DspnameAddr[0];
		LDspname= (_DISPLAY1 *)DispTable->DspnameAddr[1];
	#endif
	#ifdef	SIZE_2480
		DispTable= (DISPLAY_TBL*)&DspnameTbl;
		Dspname= DispTable->DspnameAddr[0];
	#endif
#else
	#ifdef	SIZE_3224
		DispTable= (DISPLAY_TBL*)SYS_MESSAGE_ADDR;
		Dspname= DispTable->DspnameAddr[0];
		LDspname= (_DISPLAY1 *)DispTable->DspnameAddr[1];
	#endif
	#ifdef	SIZE_2480
		DispTable= (DISPLAY_TBL*)SYS_MESSAGE_ADDR;
		Dspname= DispTable->DspnameAddr[0];
	#endif
#endif
}
/* ****************************************************************************** */
/*  ��E��E��E: IniTask															  */
/*  ��E   �� : GP �ʱ�ȭ��E�ʱ�ȭ �� Ÿ��Ʋ ȭ��E�ۼ��Լ�EȣÁE				  */
/* 			  �Է� ���ο� ����Eȭ��ó���½�ũ�� ȯ�漳���½�ũ ȣÁE			  */
/*  ��    �� :																	  */
/*  ÁE   �� :																	  */
/*  �� �� �� : 2002��E2��E7�� (��E												  */
/*  �� �� �� : ȫ �� ��E														  */
/*  ��E   ��E: 																	  */
/* ****************************************************************************** */
/* 20080822 Arm�� */
void	Rs232c_Receive_Init(void);
void	InitPlcComm(void);
extern	void	HardInitial(void);
extern	void	_ei(void);
extern	void	_di(void);
extern	void	SetSpecialRegisterAddr(void);
//#define	TEST
#ifdef	TEST
float	aa;
char	testWork[40];
char	testWork1[40];
char	testWork2[40];
char	testWork3[40];
#endif



void	GetContrast(void)
{

	char* buff;

	buff=GetLcdTypeAddr();
#ifdef	SIZE_2480
	if(strcmp(buff,LCD_TYPE_NAME) == 0){	//optima lcd

		lcd_contrast=OPTIMA_LCD_CONTRAST;
		lcd_clk=OPTIMA_LCD_CLK;
		contrast_offset=OPTIMA_CONTRAST_OFFSET;
		max_contrast=OPTIMA_MAX_CONTRAST;

	}else{									//kjc lcd

		lcd_contrast=KJC_LCD_CONTRAST;
		lcd_clk=KJC_LCD_CLK;
		contrast_offset=KJC_CONTRAST_OFFSET;
		max_contrast=KJC_MAX_CONTRAST;
	}
#endif
#ifdef	SIZE_3224

		lcd_contrast=DEF_CONTRAST;
		lcd_clk=DEF_LCDCLK;
		contrast_offset=CONTRAST_OFFSET;
		max_contrast=MAX_CONTRAST;

#endif
}

void	IniTask( STTFrm* pSTT )
{	
	int		iKeyCode;										/* �Է� Ű �� ����E	 */
/*	int		signal;*/
/*	int		sTateYoko;	*/
	T_MAIL		*mp;
	int	PointX;
	int	PointY;
	int	i;
	int	iCommentNum;
	int	iColor;
	int	iSize;
	int	iCnt;
	int iLen;
	int	OpenFlag;
/*	int	iKey;	*/
	char*	cDispBuffer;
	short	sX;
	short	sY;
	short	A_WIDTH;
	short	A_HEIGHT;
	_RECTANGLE_INFO RECParam;

/*	DISPLAY_TBL*	DispTable;	*/
//int	data= gatoi("-2147483648");
//int	a= 0x80000000;

//	short a= 0xff9a;
//extern	float	gatof(char *buff);
//extern	void	ParcentEProc(char* buff,float data);
//extern	void	ParcentfProc(char* buff,float data,int keta,int sho);
//extern	int	CulcBitAddr(int andData16);

//	int	bitpos[16];
//	int	addr= 0x0001;
//	for(i= 0; i < 16; i++){
//		bitpos[i]= CulcBitAddr(addr);
//		addr <<= 1;
//	}
#ifdef	TEST
	aa= (float)gatof("-10000.000");
	ParcentEProc(testWork2,aa);
	sprintf(testWork3,"%E",aa);
	sprintf(testWork1,"%8.3f",aa);
	ParcentfProc(testWork,aa,8,3);
#endif

	UpdateProjectBaseCnt= 0;		/* 20080903 Add */
	UpdateProjectWindowCnt= 0;		/* 20080903 Add */
	UpdateProjectInf= NULL;			/* 20080903 Add */
	StartUpFlag= 0;		//�����オ����  /* GLP������ ������� ��ġ�� PLC�� �������� �ʵ��� �ϴ� Flag */
	FileTaskTime= 0;	
	DownloadStopFlag= -1;	/* GP �ٿ�δ��� PLC�� �������ΰ� ��������ΰ� üũ�� �÷��� */   
	TaskStartFlag= OFF;		/* PLC������ ����Ʈ���� ��� �����ϵ��� �ʱ�ȭ �Ϸ�ñ��� �� �÷��׸� OFF */
#ifdef	LP_S044
	PlcSignalInf= OFF;			//0:Stop,1:Start
#endif
#ifndef	WIN32
	_di();
	memset((char *)BaseLcd_Buffer,0,sizeof(LcdBuff[0]));
#endif
	//20100806
	GetContrast();

#ifndef	WIN32
	//GLP�p������
	HardInitial();
	FlashProcMoce();
#endif
#ifdef	LP_S044
	//INIT��PLCArea���A�N�Z�X���邽��
	SetSpecialRegisterAddr();
#endif
	_INIT();
	FontSet();
	InitDispSema();										/* ������ �ʱ�ȭ */
	InitWinSema();			/* 050428 */
	InitSendSema();

	init_filesystem();

	SetContrast(lcd_contrast);				/* �֤����� display */
	LCDDisplayEnable(ON); //20080814

	BackLightOnOff(ON);
	BackLitFlag= ON;

	Set.LcdReverseOn	=0;	
	TateYoko = 0;		/* 060926 */
	iGPTitleDisp(0);
	
	mReadSettei();



	if((Set.iLcdvalue < (lcd_contrast-(max_contrast/2))) ||
		(Set.iLcdvalue > (lcd_contrast+(max_contrast/2)))){
		SetContrast(lcd_contrast);				/* �֤����� display */
	}else{
		SetContrast(Set.iLcdvalue);				/* �֤����� display */
	}


	Set.LcdReverseOn	=0;	
	TateYoko = 0;		/* 060926 */
	iGPTitleDisp(1);
	KerRepeatFlag	= 0;

	SetSystemMessegeTbl();

	Set.iMessageFlag = 0;								/* Message ���� Setting */
	WaitSetting= 0;
	WaitBaseChange= 0;	
#ifndef	WIN32
	_ei();
#endif
	Rs232c_Receive_Init();
#ifdef	LP_S044
	InitPlcComm();
#endif

	TaskStartFlag= ON;

	BaseChangeFlag= 0;		/* 040815 */
	BaseChangeFlag1= 0;		/* 040815 */
	BaseChangeFlag2= 0;		/* 040815 */
	TrendClerFlag = 0;		/* TrendCler OFF Set 050313 */
	SaveiLampNumber= 0;
	PassWordSettingFg= 0;	/* Password Setting Flag Clear 050411 */
	PassWordSettingChg= 0;

	CommonArea.PcUpDownMode= 0;

	ChangeTaskPriority(T_INITASK,0x15);				/* AlarmDetail Task */
/*	OnSignal(SGN_PLC, 0x01);	*/					/* PLC Connect Start */
	/* Sirial������������ */
/*	Rs232cBordrateSet();*/		/* 060622 */

	mp = (T_MAIL *)TakeMail();						/* ���� �ۼ�				 */
	iKeyCode = -1;

	TateYoko= 0;
	vInit();										/* �ʱ�ȭ �Լ�		 */

	iKeyCode = iGPTitleDisp(2);						/* Ÿ��Ʋ ȭ���ۼ�		 */
	TateYoko= CommonArea.ProjectAuxSet.DispFormat;


	/*  �ӽ� ����  */
	iTransFlag			= 2;
	iPreviousScreenNum	= -1;
	iFirstScreen		= 1;
	iAsciiKeyflag		= 0;								/* AsciiKey Display */
	iAsciiReDispflag	= -1;

	DeviceMonitorBuffClear(0,BUFF_DISP_CNT);  /* 20090703 */

	/*  �ӽ� ����  */
	/*	leesi 0902 */
	iScreenDisp		= 0;
	iUserScreenFlag = 0;
	DeviceCnt		= 0;
/*		signal			= 0xFFFFFFFF;
	OffSignal(SGN_PLC, signal);
031017 */
	init_filesystem();
	DefaultClockSet();									/* ������ �ð����� ������� ����Ʈ �ð����Է� */
	iAlarmHistFlag	= OFF;
	/* --------------------- */
/*
DotTextOut(0, 32,"PLC COBBECT",1,1,T_REPLACE,3,0);
DrawLcdBank1();

while(1){
	i= PlcConnectProc();
	if(i == 1){
		break;
	}
}
DotTextOut(0, 32,"D0 READING ",1,1,T_REPLACE,3,0);
for(i= 0;;i++){
	TouchKeyWriteDev.DevFlag = 1;	
	TouchKeyWriteDev.DevName[0] = 0xc0;
	TouchKeyWriteDev.DevName[1] = 0x00;
	TouchKeyWriteDev.DevName[2] = 0x00;
	TouchKeyWriteDev.DevAddress = 0;
	TouchKeyWriteDev.DevCnt = 1;
	TouchKeyWriteDev.DevData = combuff;
	ret= PLCRead(&TouchKeyWriteDev);
	if(ret == OK){
		sprintf(combuff,"OK=%04d",i);
	}else{
		sprintf(combuff,"NG=%04d",i);
	}
DotTextOut(0, 48,combuff,1,1,T_REPLACE,3,0);
DrawLcdBank1();
}
*/
	Rs232cBordrateSet();		/* 060622 */
	if (iKeyCode != 1) {
		/* Sirial������������ */
//		Rs232cBordrateSet();		/* 060622 */
		OnSignal(SGN_PLC, 0x01);					/* PLC Connect Start */
//		PlcSignalInf= ON;			//0:Stop,1:Start
		//�҂����ԂO�̎��n�m�ɂ��Ȃ�����2008.05.02
#ifdef	LP_S044
		if(PlcSignalInf == OFF){
			PlcSignalInf= ON;			//0:Stop,1:Start
		}
		StartUpFlag= 1;		//�����オ����
#endif
		SendTaskAnal(0);
	} else {
		NormalBuzzer();
		SendTaskAnal(1);
	}	/*  end if  */

	/* Alarm Detail Proc */
	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT8;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	iColor		= 0;
	OpenFlag	= 0;

#ifndef	WIN32
//	WDT_Init();				/* 050413 */ /* 20080822 ��Ȯ�� �ʿ� */
#endif
	while(1){
		mp = (T_MAIL *)WaitRequest();
		switch(mp->mcod){
		case INI_COMMENT:

			cDispBuffer = (char *)TakeMemory(512);
			memset(cDispBuffer,0x00,512);
			iCommentNum = mp->mcmd;

			SetWinSema();
			if(TateYoko == 0)	/* ���� ȭ�� */
			{
				PointX = 0;
				sX = 25;			/* 16  */
				sY = 0;
				A_WIDTH = ALARM_WIDTH;
				A_HEIGHT = ALARM_HEIGHT;
			}else
			{
				PointX = 2;
				sX = 3;			
				sY = 24;
				A_HEIGHT = ALARM_WIDTH;
				A_WIDTH = ALARM_HEIGHT;
			}
			ClearDispBuff(MESSAGE_SCREEN);
			OpenWindow(MESSAGE_SCREEN,A_WIDTH,A_HEIGHT);
			SetStartPos(MESSAGE_SCREEN, sX, sY);

			/* �⺻ Form �׸��� */
			PointY = 0;
			RectAngleOut(PointX, PointY, PointX+A_WIDTH, PointY+19, &RECParam);
			RectAngleOut(PointX, PointY+20, PointX+A_WIDTH, PointY+A_HEIGHT, &RECParam);
			RectAngleOut(PointX+2, PointY+2, PointX+18, PointY+17, &RECParam);
			iSize = 0;
			vCommentDataSet(iCommentNum, cDispBuffer, &iColor, &iSize);
			iCnt = 0;
			PointY = 20;
			iLen = strlen(cDispBuffer);
			for(i=0;i<iLen;i++)
			{
				if(cDispBuffer[i] == 0x0D)
				{
					iCnt++;	
					if(iCnt>2)
					{
						PointY = 0;
						break;
					}
				}
			}

			vMultiTextDisp(PointX+2, 
						PointY, 
						PointX+A_WIDTH, 
						A_HEIGHT,
						cDispBuffer,
						1, 
						1,
						WHITE,
						TOP_LEFT);
			DrawLcdBank1();
			ResetWinSema();
			ComWinKey.iVal = 1;

/*			ComWinKey.sX = sX+2;
			ComWinKey.sY = sY;
			ComWinKey.eX = sX+18;
			ComWinKey.eY = sY+17;
*/
			ComWinKey.sX = sX;
			ComWinKey.sY = sY;
			ComWinKey.eX = ComWinKey.sX+A_WIDTH;
			ComWinKey.eY = ComWinKey.sY+A_HEIGHT;


			FreeMail(cDispBuffer);
			OpenFlag= 1;
			break;
		case INI_DETAIL_ALARM:
			if(OpenFlag == 1){
//				iKey = mp->mcmd;
		/*		if(TouchAreaCheck(ComWinKey.sX, ComWinKey.sY, ComWinKey.eX, ComWinKey.eY,iKey)==1)
				{  031112*/
					NormalBuzzer();
					CloseWindow(MESSAGE_SCREEN);
				
					ComWinKey.iVal = 0;

			/*		for(i=0;i<8;i++)
						KeyTochData[i] = 0;   */

					Key.iCode = -1;
					Key.iBuff = -1;
					DrawLcdBank1();
					OpenFlag= 0;
		/*		} 031112*/
			}
			break;
#ifdef	SIZE_3224
		case INI_ENV_STATE:		//ENV SELECT MENU
			DispEnvState(mp);
			break;
		case INI_ENV_DEVMON:		//ENV SELECT MENU
			DispEnvDeviceMon(mp);
			break;
#endif
		}
		ResponseMail((char *)mp);		
	}	/*  end while  */

}
/******************************************************************************* */
/*  ��E��E��E: SetTask															 */
/*  ��E   �� : ����ó���½�ũ ���θ޴� ȣÁE									 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E2��E14�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/******************************************************************************* */

void	vPrintOutMain(int* iScreenNo)
{
	if ( iTaskActFlag == 0 ) {			/*  ��ŁE��?E */
		iTaskActFlag = vPrintOut(iScreenNo);	
	} else if ( iTaskActFlag == 1 ) {	/*  ����Ʈ Ÿ��ũ ȣ�� */
		/*  Print Task ��?E�� ����Ʈ ȭ��Eó��  */
		iTaskActFlag = vPrintOut(iScreenNo);	
	} else if ( iTaskActFlag == 2 ) {	/*  ����Ʈ ÁE? */
		/*  ����Ʈ Ÿ��ũ ��?EÁE?�� ����Ʈ ȭ��Eó��  */
		iTaskActFlag = vPrintOut(iScreenNo);	
		iTaskActFlag = 0;				/*  �ٽ� �ʱ�ȭ  */
	} /*  end if  */
}
#ifdef	LP_S044
const	SET_PROC	SetScreenTbl[]={
	{SELECT_MEMU_NUM		,SelectMenu			},
	{MONITORING_NUM			,MonitoringMode		},
	{DEVICE_MONITORING_NUM	,vDeviceMoni		},
	{DEVICE_XY_MONITORING_NUM	,vXYDeviceMoni	},
	{DATA_VIEW_NUM			,DataViewMenu		},
	{BASE_SCREEN_NUM		,BaseScreenList		},
	{WINDOW_SCREEN_NUM		,WindowScreenList	},
	{COMMENT_SCREEN_NUM		,vCommentMenu		},
	{MEMORY_SIZE_NUM		,MemorySizeDisp		},
	{MODEL_VER_NUM			,ModelVerDisp		},
	{SET_FUNTION_NUM		,SetFuntionMode		},
	{TIME_SWITCH_NUM		,vTimeSwitch		},
	{DATA_TRANSFER_NUM		,vDataTrans			},
	{DOWN_TRANS				,vDataTrans			},
	{UP_TRANS				,vDataTrans			},
	{PRINT_OUT_NUM			,vPrintOutMain		},
	{SET_ENVIRONMENT_NUM	,SetEnvironmentMode	},
	{CLOCK_MENU_NUM			,vClockSet			},
	{LANGUAGE_NUM			,vLangSet			},
	{BACKLIGHT_NUM			,vBackLightSet		},
	{BATTERY_NUM			,vButDispMode		},
	{BUZZER_NUM				,vBuzzerSet			},
	{OPENNING_NUM			,vScreenSet			},
	{PLC_SETTING_NUM		,vPlcSet			},
	{MENU_CALL_KEY_NUM		,vMainCallSet		},	
	{CLEAR_DATA_NUM			,vClearData			},
	{LCDCONTRAST_NUM		,vLcdContSetDisp	},
	{CLEAR_GP_DATA_NUM		,vClearGPData		},
	{CLEAR_GLP_DATA_NUM		,vClearGPData		},
//	{SET_GLP_NUM			,GlpExtBoadDisp		},
	{SELECT_IO_NUM			,SelectIoSettingMenu},
	{SELECT_IO_FILTER_NUM	,GlpSetFilter		},
	{SELECT_IO_INT_NUM		,GlpSetInterrupt	},
	{SELECT_IO_10KEY_NUM	,GlpSetItem			},
	{SELECT_IO_7SEG_NUM		,GlpSetItem			},
	{SELECT_IO_SYC_NUM		,GlpSetSync			},
//	{SELECT_IO_PULS_NUM		,GlpSetItem			},
//	{SELECT_IO_ENCODE_NUM	,GlpSetItem			},
//	{SELECT_IO_CNT_NUM		,GlpSetItem			},
//	{SELECT_IO_PATRN_NUM	,GlpSetItem			},
};
void	SetTask( int p1,int p2 )
{
	int	i;
	int iScreenNo;
	int		smcod;

	BaseChangeFlag= 0;		/* 040815 */
	BaseChangeFlag1= 0;		/* 040815 */
	BaseChangeFlag2= 0;		/* 040815 */

	iTaskActFlag	= 0;							/* ��ɺ� Ÿ��ũ Ȱ��ȭ �÷��� */
	vFreemeilAll();
	TateYoko			= 0;
	Set.LcdReverseOn	= 1;	
	iScreen				= CONFIG_SCREEN;
	iScreenNo			= p1;
	smcod				= p2;

	if(iScreenNo > 1000){
		switch(iScreenNo){
		case 1001:	iScreenNo = 21;	break;
		case 1002:	iScreenNo = 22;	break;
		case 1003:	iScreenNo = 23;	break;
		case 1013:	iScreenNo = 455;break;
		case 1014:	iScreenNo = 41;	break;
		case 1015:	iScreenNo = 456;break;
		case 1016:	iScreenNo = 44;	break;
		case 1018:	iScreenNo = 43;	break;
		case 1019:	iScreenNo = 457;break;
		case 1020:	iScreenNo = 452;break;
		case 1021:	iScreenNo = 458;break;
		case 1026:	iScreenNo = 31;	break;
		case 1027:	iScreenNo = 450;break;
		case 1028:	iScreenNo = 451;break;
		case 1029:	iScreenNo = 453;break;
		case 1030:	iScreenNo = 454;break;
		}
	}
	if(iScreenNo == DOWN_TRANS || iScreenNo == UP_TRANS){iUserScreenFlag = 0;}
	while (iScreenNo != 0) {
		if(iScreenNo != 999){
			SetWindowNo(SCREEN_0);
			AreaClear(0,0,GAMEN_X_SIZE-1,(GAMEN_Y_SIZE-1),0);
		}
		for(i= 0; i < TBQ(SetScreenTbl); i++){
			if(SetScreenTbl[i].iScreenNo == iScreenNo){	break;	}
		}
		if(i < TBQ(SetScreenTbl)){	SetScreenTbl[i].RsCall(&iScreenNo);	}
		else{						Delay(50);							}
		if (iScreenNo == CONFIG_NEXT) {
			break;
		}
		if(smcod == 1)
		{
			iScreenNo = 0;
			smcod = 0;
		}

	} /* end while */

	if(iScreen == CONFIG_SCREEN && iScreenNo != CONFIG_NEXT){
		sprintf(cPcTempFileName, pcFileName[iBaseScreenCnt]);	/* File Setting */
		DeviceCnt = 0;
		memset(DeviceDataHed,0,sizeof(DeviceDataHed));
		OffSignal(SGN_PLC, 0xFFFFFFFF);
		SendTaskAnal(0);
	}		
	if(iUserScreenFlag == 0){
		RepeatInfo.EntryCnt= 0;
	}
	/* 050427 */
	PassWordSettingFg= 0;
	PassWordSettingChg= 0;
	iPassFlag= 0;
	/******************/
	if(StartUpFlag == 0){
		StartUpFlag= 1;		//�����オ����
		PlcSignalInf= ON;			//0:Stop,1:Start
	}
}
#endif
#ifdef	GP_S044
const	SET_PROC	SetScreenTbl[]={
	{SELECT_MEMU_NUM		,SelectMenu			},
	{MONITORING_NUM			,MonitoringMode		},
	{DEVICE_MONITORING_NUM	,vDeviceMoni		},
	{DATA_VIEW_NUM			,DataViewMenu		},
	{BASE_SCREEN_NUM		,BaseScreenList		},
	{WINDOW_SCREEN_NUM		,WindowScreenList	},
	{COMMENT_SCREEN_NUM		,vCommentMenu		},
	{MEMORY_SIZE_NUM		,MemorySizeDisp		},
	{MODEL_VER_NUM			,ModelVerDisp		},
	{SET_FUNTION_NUM		,SetFuntionMode		},
	{TIME_SWITCH_NUM		,vTimeSwitch		},
	{DATA_TRANSFER_NUM		,vDataTrans			},
	{DOWN_TRANS				,vDataTrans			},
	{UP_TRANS				,vDataTrans			},
	{PRINT_OUT_NUM			,vPrintOutMain		},
	{SET_ENVIRONMENT_NUM	,SetEnvironmentMode	},
	{CLOCK_MENU_NUM			,vClockSet			},
	{LANGUAGE_NUM			,vLangSet			},
	{BACKLIGHT_NUM			,vBackLightSet		},
	{BATTERY_NUM			,vButDispMode		},
	{BUZZER_NUM				,vBuzzerSet			},
	{OPENNING_NUM			,vScreenSet			},
	{PLC_SETTING_NUM		,vPlcSet			},
	{MENU_CALL_KEY_NUM		,vMainCallSet		},	
	{CLEAR_DATA_NUM			,vClearData			},
	{LCDCONTRAST_NUM		,vLcdContSetDisp	},
	{UWLATCH_NUM			,vUwLatchSetDisp	},		/* 20091222 */
	{CLEAR_GP_DATA_NUM		,vClearGPData		},
/*	{CLEAR_GLP_DATA_NUM		,vClearGPData		}, */
//	{SET_GLP_NUM			,GlpExtBoadDisp		},
/*	{SELECT_IO_NUM			,SelectIoSettingMenu},
	{SELECT_IO_FILTER_NUM	,GlpSetFilter		},
	{SELECT_IO_INT_NUM		,GlpSetInterrupt	},
	{SELECT_IO_10KEY_NUM	,GlpSetItem			},
	{SELECT_IO_7SEG_NUM		,GlpSetItem			},
	{SELECT_IO_SYC_NUM		,GlpSetSync			}, */
//	{SELECT_IO_PULS_NUM		,GlpSetItem			},
//	{SELECT_IO_ENCODE_NUM	,GlpSetItem			},
//	{SELECT_IO_CNT_NUM		,GlpSetItem			},
//	{SELECT_IO_PATRN_NUM	,GlpSetItem			},
};
void	SetTask( int p1,int p2 )
{
	int	i;
	int iScreenNo;
	int		smcod;

	BaseChangeFlag= 0;		/* 040815 */
	BaseChangeFlag1= 0;		/* 040815 */
	BaseChangeFlag2= 0;		/* 040815 */

	iTaskActFlag	= 0;							/* ��ɺ� Ÿ��ũ Ȱ��ȭ �÷��� */
	vFreemeilAll();
	TateYoko			= 0;
	Set.LcdReverseOn	= 1;	
	iScreen				= CONFIG_SCREEN;
	iScreenNo			= p1;
	smcod				= p2;

	if(iScreenNo > 1000){
		switch(iScreenNo){
		case 1001:	iScreenNo = 21;	break;
		case 1002:	iScreenNo = 22;	break;
		case 1003:	iScreenNo = 23;	break;
		case 1013:	iScreenNo = 455;break;
		case 1014:	iScreenNo = 41;	break;
		case 1015:	iScreenNo = 456;break;
		case 1016:	iScreenNo = 44;	break;
		case 1018:	iScreenNo = 43;	break;
		case 1019:	iScreenNo = 457;break;
		case 1020:	iScreenNo = 452;break;
		case 1021:	iScreenNo = 458;break;
		case 1026:	iScreenNo = 31;	break;
		case 1027:	iScreenNo = 450;break;
		case 1028:	iScreenNo = 451;break;
		case 1029:	iScreenNo = 453;break;
		case 1030:	iScreenNo = 454;break;
		}
	}
	if(iScreenNo == DOWN_TRANS || iScreenNo == UP_TRANS){iUserScreenFlag = 0;}
	while (iScreenNo != 0) {
		if(iScreenNo != 999){
			SetWindowNo(SCREEN_0);
			AreaClear(0,0,GAMEN_X_SIZE-1,(GAMEN_Y_SIZE-1),0);
		}
		for(i= 0; i < TBQ(SetScreenTbl); i++){
			if(SetScreenTbl[i].iScreenNo == iScreenNo){	break;	}
		}
		if(i < TBQ(SetScreenTbl)){	SetScreenTbl[i].RsCall(&iScreenNo);	}
		else{						Delay(50);							}
		if (iScreenNo == CONFIG_NEXT) {
			break;
		}
		if(smcod == 1)
		{
			iScreenNo = 0;
			smcod = 0;
		}

	} /* end while */

	if(iScreen == CONFIG_SCREEN && iScreenNo != CONFIG_NEXT){
		sprintf(cPcTempFileName, pcFileName[iBaseScreenCnt]);	/* File Setting */
		DeviceCnt = 0;
		memset(DeviceDataHed,0,sizeof(DeviceDataHed));
		OffSignal(SGN_PLC, 0xFFFFFFFF);
		SendTaskAnal(0);
	}		
	if(iUserScreenFlag == 0){
		RepeatInfo.EntryCnt= 0;
	}
	/* 050427 */
	PassWordSettingFg= 0;
	PassWordSettingChg= 0;
	iPassFlag= 0;
	/******************/
}
#endif
/********************************************/
/*	PLC Connect Error Dislay				*/
/********************************************/
void	PlcConnectDisp(void)
{
	char	cScreenDisp[20];

	SetWinSema();
	SetWindowNo(MESSAGE_SCREEN);
	SetStartPos(MESSAGE_SCREEN, 8, 10);		/* MESSAGE_SCREEN window display position (8, 10) set */
	OpenWindow(MESSAGE_SCREEN,222,60);		/* MESSAGE_SCREEN window size (222, 60) OPEN */
	ClearDispBuff(MESSAGE_SCREEN);
	ResetWinSema();
	if(TateYoko == 0)
	{
		memset(cScreenDisp, 0x00, 20);
		iCaptionVerticalWindow(Dspname[COMMENT_SCREEN].chName[Set.iLang][6],"","","","");	
	}
	else
	{
		memset(cScreenDisp, 0x00, 20);
		iCaptionVerticalWindow(Dspname[COMMENT_SCREEN].chName[Set.iLang][7],
					Dspname[COMMENT_SCREEN].chName[Set.iLang][8],
					Dspname[COMMENT_SCREEN].chName[Set.iLang][9],
					Dspname[COMMENT_SCREEN].chName[Set.iLang][10],cScreenDisp);	
	}
	Set.iMessageFlag = 2;
	DrawLcdBank1();
}
void	PlcConnectDispClr(void)
{
	SetWinSema();
	CloseWindow(MESSAGE_SCREEN);
	DrawLcdBank1();
	ResetWinSema();
}
/*// s : given string to be encrypted*/
/*// return value: encrypted value*/
unsigned long Encrypt(char *s)
{
	unsigned long x, x1, z;

	for(z=0; s[z]=='0'; z++);
	if(z)
/*		x= (unsigned long)atol(s)+z*100000000;*/
		x= (unsigned long)gatoi(s)+z*100000000;
	else
/*		x= (unsigned long)atol(s);*/
		x= (unsigned long)gatoi(s);
	x1 = ( (x&0xFFFF0000)>>16 ) + ( (x&0xFFFF)<<16 );
	return (x1&0x55555555)*2+(x1&0xAAAAAAAA)/2 + 0x1345;
}

/*// x : encrypted value to be decrypted*/
/*// s : decrypted string*/
void Decrypt(unsigned long x, char *s)
{
	
	int i, z;
	unsigned long  x1, x2;
	char s1[10];

	x1 = ((x-0x1345)&0x55555555)*2+((x-0x1345)&0xAAAAAAAA)/2;
	x2 = ( (x1&0xFFFF0000)>>16 ) + ( (x1&0xFFFF)<<16 );
	z = x2/100000000;
	x2= x2- z*100000000;
	for(i=0; i<z; i++)
		s[i]= '0';
	s[i]=0;
	itoa(x2, s1, 10);
	if(x2!=0)
		strcat(s, s1);
}
/********************************************************************************/
/* �� �� �� : DrawLine_Func														*/
/* ��    �� : �����±׸� �ص��Ͽ� ȭ�鿡 ���   							    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 16�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 2002��8��6�� ������.												*/
/********************************************************************************/
void	DrawLine_Func( int iTagSize, unsigned char *ucTagBuff, int iColor)
{
	int		sX;
	int		sY;
	int		eX;
	int		eY;
	_LINE_INFO param;

	sX = 0;
	sY = 0;
	eX = 0;
	eY = 0;

	if(iColor != -1)
		param.iLineColor = iColor;
	else
		param.iLineColor = (int)(*(ucTagBuff+4));  

	param.iLineStyle = (unsigned int)(*(ucTagBuff+5) + 1);

	sX  = (int)(*(ucTagBuff+6) << 0x08);
	sX += (int)(*(ucTagBuff+7));

	sY  = (int)(*(ucTagBuff+8) << 0x08);
	sY += (int)(*(ucTagBuff+9));

	eX  = (int)(*(ucTagBuff+10) << 0x08);
	eX += (int)(*(ucTagBuff+11));

	eY  = (int)(*(ucTagBuff+12) << 0x08);
	eY += (int)(*(ucTagBuff+13));

	LineOut(sX, sY, eX, eY, &param);
	return;
}

/********************************************************************************/
/* �� �� �� : DrawRect_Func														*/
/* ��    �� : �簢���±׸� �ص��Ͽ� ȭ�鿡 ���   							    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 16�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	DrawRect_Func(  int iTagSize, unsigned char *ucTagBuff , int iColor)
{
	int		sX;
	int		sY;
	int		eX;
	int		eY;
	_RECTANGLE_INFO RECParam;

	sX = 0;
	sY = 0;
	eX = 0;
	eY = 0;

	if(iColor != -1)
		RECParam.iLineColor = iColor;
	else
		RECParam.iLineColor = (int)(*(ucTagBuff+4));  

	RECParam.iBackColor = (int)(*(ucTagBuff+5));
	RECParam.iLineStyle	= (unsigned int)(*(ucTagBuff+6)) + 1;
	RECParam.iForeColor = (int)(*(ucTagBuff+7));
	RECParam.iPattern	= (int)(*(ucTagBuff+8));

	sX  = (int)(*(ucTagBuff+9) << 0x08);
	sX += (int)(*(ucTagBuff+10));

	sY  = (int)(*(ucTagBuff+11) << 0x08);
	sY += (int)(*(ucTagBuff+12));

	eX  = (int)(*(ucTagBuff+13) << 0x08);
	eX += (int)(*(ucTagBuff+14));

	eY  = (int)(*(ucTagBuff+15) << 0x08);
	eY += (int)(*(ucTagBuff+16));	
	
	RectAngleOut(sX, sY, eX, eY, &RECParam);	/* �簢�� Display */
	return;
}

/********************************************************************************/
/* �� �� �� : DrawCircle_Func													*/
/* ��    �� : ���±׸� �ص��Ͽ� ȭ�鿡 ���		  							    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 16�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	DrawCircle_Func(  int iTagSize, unsigned char *ucTagBuff , int iColor)
{
	int		sX;
	int		sY;
	int		eX;
	int		eY;
	int		radiusX;
	int		radiusY;
	_CIRCLE_INFO Circleparam;
	
	sX = 0;
	sY = 0;
	eX = 0;
	eY = 0;
	if(iColor != -1)
		Circleparam.iLineColor = iColor;
	else
		Circleparam.iLineColor = (int)(*(ucTagBuff+4));  

	Circleparam.iBackColor = (int)(*(ucTagBuff+5)); 
	Circleparam.iForeColor = (int)(*(ucTagBuff+6)); 
	Circleparam.iPattern = (unsigned int)(*(ucTagBuff+7));

	sX  = (int)(*(ucTagBuff+8) << 0x08);
	sX += (int)(*(ucTagBuff+9));

	sY  = (int)(*(ucTagBuff+10) << 0x08);
	sY += (int)(*(ucTagBuff+11));

	eX  = (int)(*(ucTagBuff+12) << 0x08);
	eX += (int)(*(ucTagBuff+13));

	eY  = (int)(*(ucTagBuff+14) << 0x08);
	eY += (int)(*(ucTagBuff+15));

	radiusX = (int)((eX - sX)/2);
	radiusY = (int)((eY - sY)/2);
	DrawDaen(sX + radiusX, sY + radiusY, radiusX,radiusY,&Circleparam);	/*  �� Display */

	return;
}
/********************************************************************************/
/* �� �� �� : DrawText_Func														*/
/* ��    �� : �ؽ�Ʈ�±׸� �ص��Ͽ� ȭ�鿡 ���   							    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 16�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	DrawText_Func( int iTagSize, unsigned char *ucTagBuff , int iColor)
{
	char*	cText;
	int		i=0;
	int		FsX;
	int		FsY; 
	int		sX;
	int		sY;
	int		iTextSize;
	int		iStartPos;
	int		iTextColor;
	int		iType;
	int		iSizeV;
	int		iSizeH;
	int		i68DotFlag;
	int		iBack_Color = 0;
	short	iLineCnt;

	if(iColor == -1)
		iTextColor = (int)(*(ucTagBuff+4));
	else
		iTextColor = iColor;

	iSizeH = (int)(*(ucTagBuff+7));	
	iSizeV = (int)(*(ucTagBuff+8));

	FsX  = (int)(*(ucTagBuff+9) << 0x08);
	FsX += (int)(*(ucTagBuff+10));

	FsY  = (int)(*(ucTagBuff+11) << 0x08);
	FsY += (int)(*(ucTagBuff+12));
	
	i68DotFlag = (int)(*(ucTagBuff+19));
	iLineCnt = (int)(*(ucTagBuff+21));

//	if(i68DotFlag == 0xff && iSizeV == 0 ){	iSizeH = 0;	}		//20101207
	if(i68DotFlag == 0xff){
		iSizeH = 0;
		iSizeV = 0;		//20101207
	}

	if(iLineCnt == 1){		/* 1 Line�� ��� */
		iTextSize = (int)((*(ucTagBuff+17))<< 0x08);
		iTextSize += (int)(*(ucTagBuff+18));
		cText = (char*)TakeMemory(iTextSize+1);
		memset(cText, 0x00, (iTextSize+1));
		memcpy(cText, (ucTagBuff+26), iTextSize);
		DotTextOut(FsX, FsY, cText, iSizeH, iSizeV, T_FRONT,iTextColor,iBack_Color);
		FreeMail(cText);
	}else{
		i=0;
		iStartPos = 21;
		while(i < iLineCnt){
			sX  = (int)(*(ucTagBuff+(++iStartPos)));
			sY  = (int)(*(ucTagBuff+(++iStartPos)));
			iTextSize = (int)(*(ucTagBuff+(++iStartPos)) << 0x08);
			iTextSize += (int)(*(ucTagBuff+(++iStartPos)));
			iStartPos++;
			cText = (char*)TakeMemory(iTextSize+1);
			memset(cText, 0x00, (iTextSize+1));
			memcpy(cText, (ucTagBuff + iStartPos), iTextSize);

			if(iTextColor == 0)	{
				iBack_Color	= WHITE;	
				iType		= T_FRONT;
			}else{
				iBack_Color = BLACK;
				iType      = T_OR;
			}
			DotTextOut(FsX + sX, FsY + sY, cText, iSizeH, iSizeV, iType, iTextColor, iBack_Color);
			FreeMail((char*)cText);
			iStartPos += iTextSize;
			iStartPos--;
			i++;				
		}
	}
	return;
}
/********************************************************************************/
/* �� �� �� : DrawShape(�Ϲ��Լ�)												*/
/* ��    �� : Shape������ ȭ�鿡 ���			  							    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 25�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
int	DrawShape(int ShapeNo, int sX, int sY, int eX, int eY, int iFrameC, int iPlateC)
{
	short	iRetData;

	_RECTANGLE_INFO RECParam;
	_LINE_INFO param;
	_LINE_INFO param1;
	/*_CIRCLE_INFO CIRparam;*/
	iRetData=0;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = iFrameC;
	RECParam.iPattern	= PAT8;
	RECParam.iForeColor = iPlateC;
	RECParam.iBackColor = iPlateC;

	param.iLineColor = WHITE;
	param.iLineStyle = SOLID_LINE;
	param1.iLineColor = BLACK;
	param1.iLineStyle = SOLID_LINE;

	switch(ShapeNo){
		case 1:
			iRetData = 3;
			RectAngleOut(sX, sY, eX, eY, &RECParam); 
			break;
		
		case 2:		
			iRetData = 4;			
			RectAngleOut(sX, sY, eX, eY, &RECParam); 
			RectAngleOut(sX+1, sY+1, eX-1, eY-1, &RECParam); 
			break;

		case 3:
			iRetData = 5;
			RectAngleOut(sX, sY, eX, eY, &RECParam); 
			if(iPlateC == WHITE)
			{
				LineOut(sX+1, sY+1, eX-2, sY+1, &param1);
				LineOut(sX+1, sY+1, sX+1, eY-2, &param1);
				LineOut(sX+2, sY+2, eX-3, sY+2, &param1);
				LineOut(sX+2, sY+2, sX+2, eY-3, &param1);
			}
			else
			{
				LineOut(sX+2, eY-2, eX-2, eY-2, &param);
				LineOut(eX-2, sY+2, eX-2, eY-2, &param);
				LineOut(sX+1, eY-1, eX-1, eY-1, &param);
				LineOut(eX-1, sY+1, eX-1, eY-1, &param);
			}
			break;
		case 4:
			iRetData = 5;
			RectAngleOut(sX, sY, eX, eY, &RECParam); 
			if(iPlateC!=WHITE)
			{
				LineOut(sX+1, sY+1, eX-1, sY+1, &param);
				LineOut(sX+1, sY+1, sX+1, eY-1, &param);
				LineOut(sX+2, sY+2, eX-2, sY+2, &param);
				LineOut(sX+2, sY+2, sX+2, eY-2, &param);
			}
			else
			{
				LineOut(sX+3, eY-2, eX-2, eY-2, &param1);
				LineOut(eX-2, sY+3, eX-2, eY-2, &param1);
				LineOut(sX+2, eY-1, eX-1, eY-1, &param1);
				LineOut(eX-1, sY+2, eX-1, eY-1, &param1);
			}
			break;
		case 5:
			iRetData = 5;
			RectAngleOut(sX, sY, eX, eY, &RECParam); 
			RectAngleOut(sX+2, sY+2, eX-2, eY-2, &RECParam); 
			break;
		case 6:
			iRetData = 4;
			RECParam.iLineStyle = 7;
			RectAngleOut(sX, sY, eX, eY, &RECParam); 
			RectAngleOut(sX+1, sY+1, eX-1, eY-1, &RECParam); 
			break;
	}
	return iRetData;
}

/********************************************************************************/
/* �� �� �� : vFreemeilAll()													*/
/* ��    �� : ��� Takememory�� �����. 			  						    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 25�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	vFreemeilAll(void)
{
/* 060926	DeviceCnt = 0;
	memset(DeviceDataHed,0,sizeof(DeviceDataHed));
*/
	ClearDeviceMonInfo();		/* 060926 */
	/*****03_11_11*************************/
	memset(DeviceData,0x00,sizeof(DeviceData));
	memset(DispDeviceData,0x00,sizeof(DispDeviceData));
/*	memset(DeviceData1,0x00,sizeof(DeviceData1));*/
	/**************************************/
	TagFileCnt= 0;				/* BASE Display Tag Info Count 050618 */
	/**************************************/

	/**********************/
	iNowScreenNum		= 0;
	iDeviceSearchCnt	= 0;
	iWinStartPx			= 0;
	iWinStartPy			= 0;
	iWinEndPx			= 0;
	iWinEndPy			= 0;	
	ClockDispCnt		= 0;
	CommentDispCnt		= 0;/* CommentDisplayTag Counter */
	AlarmHistoryDispCnt	= 0;/* AlarmHistoryDisplayTag Counter */
	AlarmListDispCnt	= 0;/* AlarmListDisplayTag Counter */
	PartDispCnt			= 0;/* PartDisplayTag Counter */
	LampDispCnt			= 0;/* LampDisplayTag Counter */
	PanelMeterDispCnt	= 0;/* PanelMeterTag Counter */
	TrendGraphDispCnt	= 0;/* TrendGraphDisplayTag Counter */
	LineGraphDispCnt	= 0;/* LineGraphDisplayTag Counter */
	BarGraphDispCnt		= 0;/* BarGraphDisplayTag Counter */
	StatisticsDispCnt	= 0;/* StatisticsDisplayTag Counter */
	ScalePosCnt         = 0;
	TouchSwitchDispCnt	= 0;/* TouchSwitchDisplayTag Counter */
	NumericInputCnt		= 0;/* NumericInputTag Counter */
	AsciiInputCnt		= 0;/* AsciiInputisplayTag Counter */
	iFigureCnt			= 0;/* Figure Total Counter*/					

	ClockDispCnt1			= 0;
	CommentDispCnt1			= 0;		/* CommentDisplayTag Counter		*/
	AlarmHistoryDispCnt1	= 0;	/* AlarmHistoryDisplayTag Counter	*/
	AlarmListDispCnt1		= 0;	/* AlarmListDisplayTag Counter		*/
	PartDispCnt1			= 0;			/* PartDisplayTag Counter			*/
	LampDispCnt1			= 0;			/* LampDisplayTag Counter			*/
	PanelMeterDispCnt1		= 0;	/* PanelMeterTag Counter			*/
	TrendGraphDispCnt1		= 0;	/* TrendGraphDisplayTag Counter		*/
	LineGraphDispCnt1		= 0;	/* LineGraphDisplayTag Counter		*/
	BarGraphDispCnt1		= 0;		/* BarGraphDisplayTag Counter		*/
	StatisticsDispCnt1		= 0;	/* StatisticsDisplayTag Counter		*/
	ScalePosCnt1			= 0;
	TouchSwitchDispCnt1		= 0;	/* TouchSwitchDisplayTag Counter	*/
	NumericInputCnt1		= 0;		/* NumericInputTag Counter			*/
	AsciiInputCnt1			= 0;		/* AsciiInputisplayTag Counter		*/	
	iDeviceSearchCnt1		= 0;
	DeviceCnt1				= 0;
/*	IventTableCnt1			= 0;*/
	iGlobleOrder			= 0;
}

/********************************************************************************/
/* �� �� �� : vWindowFreemeil()													*/
/* ��    �� : Window1 Takememory�� �����. 		  							    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 10�� 15�� (ȭ)												*/
/* �� �� �� : �� �� �� 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	vWindowFreemeil(void)
{
	DeviceCnt			= DeviceCnt1;
	iDispOrder			= iGlobleOrder;
	iWinStartPx			= 0;
	iWinStartPy			= 0;
	iWinEndPx			= 0;
	iWinEndPy			= 0;	
	/* 2002/08/20 choijh add DeviceTbl Delete!! */
}
