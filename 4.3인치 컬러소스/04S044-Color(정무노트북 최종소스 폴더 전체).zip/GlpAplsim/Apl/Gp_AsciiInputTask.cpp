/********************************************************************************/
/* �� �� �� : GpAsciiInputTask.cpp												*/
/* ��    �� : AsciiInputTask													*/
/* �� �� �� : 2002�� 5�� 14�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include    "sgt.h"

/********************************************************************************/
/* �� �� �� : DrawAscInput_Task													*/
/* ��    �� : AscInput������ �ص��Ͽ� ȭ�鿡 ���								*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 30�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetAsciiInput_Func(int iDispOrder)
{
	_ASCIIINPUT_EVENT_TBL*	 AsciiInputEventTbl;

	AsciiInputEventTbl= (_ASCIIINPUT_EVENT_TBL*)TakeMemory(sizeof(_ASCIIINPUT_EVENT_TBL));
	DrawAsciiInput_Func(0,AsciiInputEventTbl,iDispOrder);
	FreeMail((char *)AsciiInputEventTbl);
}
int	DrawAsciiInput_Func(int mode,_ASCIIINPUT_EVENT_TBL* AsciiInputEventTbl,int iDispOrder)
{
	int					iOffset;
	unsigned char		*buffer;
	unsigned int		iUser_id;
/*	unsigned int		iTagSizeOf;*/

/*	_ASCIIINPUT_EVENT_TBL*	 AsciiInputEventTbl;*/
/*	_NUMERIC_INPUT_EVENT_TBL*	 FirstNumericInput;*/
/*	_ASCIIINPUT_EVENT_TBL*	 FirstAsciiInput;*/


	buffer= ScreenTagData[iDispOrder].TagPos;
/*
	if(CheckMailBox(sizeof(_ASCIIINPUT_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_ASCIIINPUT_EVENT_TBL));
	AsciiInputEventTbl= (_ASCIIINPUT_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)AsciiInputEventTbl, 0x00, sizeof(_ASCIIINPUT_EVENT_TBL));

	
		iOffset			= 0;
/*		iTagSizeOf		= 0;*/
				
		
/*
		iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
		iTagSizeOf += (unsigned int)buffer[1] & 0xff;
*/

		/* 20020808 choijh add */

		/* 6*8dot��뿩�� */
		/* 0x00: üũ�� ���� �ʾ��� ���   0x08: üũ���� ���(������ ��쵵 0x08���� �״�� ���´�. */		

		/* ��ǥ */
/*
		AsciiInputEventTbl->sX  = (unsigned int)(buffer[6] << 0x08);
		AsciiInputEventTbl->sX += (unsigned int)buffer[7] & 0xff;

		AsciiInputEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
		AsciiInputEventTbl->sY += (unsigned int)buffer[9] & 0xff;

		AsciiInputEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
		AsciiInputEventTbl->eX += (unsigned int)buffer[11] & 0xff;

		AsciiInputEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
		AsciiInputEventTbl->eY += (unsigned int)buffer[13] & 0xff;
*/
		
		AsciiInputEventTbl->iFrameColor = (unsigned int)buffer[14];/* FrameColor */
		
		AsciiInputEventTbl->iFontSizeH = (unsigned int)buffer[15];
		AsciiInputEventTbl->iFontSizeV = (unsigned int)buffer[16];

		/* Basic Device���� */
		iOffset = 17;
		/*------------------------------------------------------------*/
		GetDeviceSet((buffer+iOffset),
					AsciiInputEventTbl->cDeviceName,
					&(AsciiInputEventTbl->iDeviceNumber));
		/*-------------------------------------------------------------*/
		iOffset+=5;
		/* Form->Alignment */
		AsciiInputEventTbl->iAlignment = (unsigned int)buffer[iOffset]; /* 0x00:Right, 0x01:Left, 0x02:Center */
		/* Basic->Text Color */	
		AsciiInputEventTbl->iTextColor = (unsigned int)buffer[++iOffset];
		
		/* Basic->Plate Color */
		AsciiInputEventTbl->iPlateColor = (unsigned int)buffer[++iOffset];
		/* Digits */
		AsciiInputEventTbl->iDigits = (unsigned int)buffer[++iOffset];

		/* Others�ǿ��� Userid 26-27 */
		AsciiInputEventTbl->iUser_id  = (unsigned int)(buffer[++iOffset] << 0x08);/* iUser_id = 0xFF�̸� üũ���� ����*/
		AsciiInputEventTbl->iUser_id += (unsigned int)buffer[++iOffset] & 0xff;
		
		/* Others�ǿ��� Move Destination id */
		AsciiInputEventTbl->iMoveDest_id  = (unsigned int)(buffer[++iOffset] << 0x08);/* iMoveDest_id = 0xFF�̸� üũ���� ����*/
		AsciiInputEventTbl->iMoveDest_id += (unsigned int)buffer[++iOffset] & 0xff;
		iOffset++;
		if(mode == 0){
			if((unsigned int)buffer[iOffset]==0x01)
				ScreenTagData[iDispOrder].uu.AsciiIn.iTriggerTypeVal = 2;
			else if((unsigned int)buffer[iOffset]==0x02)
				ScreenTagData[iDispOrder].uu.AsciiIn.iTriggerTypeVal = ON;
			else 
				ScreenTagData[iDispOrder].uu.AsciiIn.iTriggerTypeVal = OFF;
		}
		iOffset++;
		
		if(ScreenTagData[iDispOrder].uu.AsciiIn.iTriggerTypeVal != 2)
		{
			/*------------------------------------------------------------*/

			GetDeviceSet((buffer+iOffset),
						AsciiInputEventTbl->cTriggerDeviceName,
						&(AsciiInputEventTbl->iTriggerDeviceNumber));
			iOffset+=5;
			/*-------------------------------------------------------------*/
		}
		/* Shape */
		if((unsigned int)buffer[iOffset] != 0x00){
			if(mode == 0){
				ScreenTagData[iDispOrder].BeShapeUsed = CHECKED;
			}
			AsciiInputEventTbl->ShapeNo = (unsigned int)buffer[++iOffset];
		}else{
			if(mode == 0){
				ScreenTagData[iDispOrder].BeShapeUsed = UNCHECKED;
			}
			AsciiInputEventTbl->ShapeNo = 0;
			++iOffset;
		}

		if((unsigned int)buffer[++iOffset] != 0x00){
			AsciiInputEventTbl->iFontSizeH = 0;
			AsciiInputEventTbl->iFontSizeV = 0;		//20101207
		}
		
		/* DEV_DATA�� ���� ������ ����� ����Ѵ�. */		
		if(mode == 0){
			DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;
			DeviceDataHed[DeviceCnt].DevName[0] = AsciiInputEventTbl->cDeviceName[0];
			DeviceDataHed[DeviceCnt].DevName[1] = AsciiInputEventTbl->cDeviceName[1];
			DeviceDataHed[DeviceCnt].DevAddress = AsciiInputEventTbl->iDeviceNumber;
			DeviceDataHed[DeviceCnt].DevCnt		= (int)((AsciiInputEventTbl->iDigits+1)/2);
			DeviceDataHed[DeviceCnt].DevData	= &DeviceData[iDeviceOffset];		
			ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
			ScreenTagData[iDispOrder].DevCnt= DeviceDataHed[DeviceCnt].DevCnt*2;
			iDeviceOffset += AsciiInputEventTbl->iDigits * 2;
		
	/*		AsciiInputEventTbl->iRegisterNumber = DeviceCnt;*/
			/* 20020819 choijh add*/
	/*		AsciiInputEventTbl->Dev_SuperVOffset= WatchingDevice(AsciiInputEventTbl->cDeviceName, 
												AsciiInputEventTbl->iDeviceNumber, 
												0,
												AsciiInputEventTbl->iRegisterNumber,
												(WORD+2), DeviceDataHed[DeviceCnt].DevCnt);		
	*/
			DeviceCnt++;		

/*			if(ScreenTagData[iDispOrder].uu.AsciiIn.iTriggerTypeVal == NOT_ORDINARY){*/
			/* 0:OFF,1:ON,2:ORDINARY */
			if(ScreenTagData[iDispOrder].uu.AsciiIn.iTriggerTypeVal != 2){
				ScreenTagData[iDispOrder].uu.AsciiIn.iBStartDataPos= iDeviceOffset;
				DeviceDataHed[DeviceCnt].DevFlag = DEVICE_BIT;/* Bit */
				DeviceDataHed[DeviceCnt].DevName[0] = AsciiInputEventTbl->cTriggerDeviceName[0]; 
				DeviceDataHed[DeviceCnt].DevName[1] = AsciiInputEventTbl->cTriggerDeviceName[1];
				DeviceDataHed[DeviceCnt].DevAddress = AsciiInputEventTbl->iTriggerDeviceNumber;
				DeviceDataHed[DeviceCnt].DevCnt		= 1;
				DeviceDataHed[DeviceCnt].DevData	= &DeviceData[iDeviceOffset];
				iDeviceOffset += (int)DeviceDataHed[DeviceCnt].DevCnt;
	/*			AsciiInputEventTbl->iTriggerRegistNumber = DeviceCnt;*/

	/*			AsciiInputEventTbl->Trig_SuperVOffset= WatchingDevice(AsciiInputEventTbl->cTriggerDeviceName, 
													AsciiInputEventTbl->iTriggerDeviceNumber, 
													0,
													AsciiInputEventTbl->iTriggerRegistNumber,
													WORD, DeviceDataHed[DeviceCnt].DevCnt);
	*/
				DeviceCnt++;
			}
		}
	/******************************************************************/
		if(mode == 0){
			if(InputDisplay.iFlag == 1 && 
				AsciiInputEventTbl->iUser_id != 0xff ){
				/* �D��?�F�b�N */
				if(ScreenTagData[InputDisplay.iInputNo].cObjects == NUMERICAL_INPUT){
					if(NumericInputCnt!=0){
	/*					FirstNumericInput = (_NUMERIC_INPUT_EVENT_TBL*)IventTable[InputDisplay.iInputNo];*/
						iUser_id= GetUsrId(0,InputDisplay.iInputNo);
						if(AsciiInputEventTbl->iUser_id	< iUser_id){
							InputDisplay.iFlag = 0;
							InputDisplay.iKeyOnOff = 0;
						}
					}
				}else if(ScreenTagData[InputDisplay.iInputNo].cObjects == ASCII_INPUT)
				{
	/*				FirstAsciiInput = (_ASCIIINPUT_EVENT_TBL*)IventTable[InputDisplay.iInputNo];*/
					iUser_id= GetUsrId(1,InputDisplay.iInputNo);
					if(AsciiInputEventTbl->iUser_id	< iUser_id){
						InputDisplay.iFlag = 0;
						InputDisplay.iKeyOnOff = 0;
					}
				}
			}/* --------------------------------- */
			if(InputDisplay.iFlag == 0){
				if(CommonArea.ProjectAuxSet.DispCursorWindow == 0x02)
				{
					CommonArea.KeyWindow.iKeyType = KEY_ASCII;
	/*				InputDisplay.iInputNo = IventTableCnt;*/	/* ID�� ���� Ŀ�� Display�� ����... */
					InputDisplay.iInputNo = iDispOrder;	/* ID�� ���� Ŀ�� Display�� ����... */
					InputDisplay.iKeyOnOff = 1;
				}else if(CommonArea.ProjectAuxSet.DispCursorWindow == 0x01)
				{
	/*				InputDisplay.iInputNo = IventTableCnt;*/	/* ID�� ���� Ŀ�� Display�� ����... */
					InputDisplay.iInputNo = iDispOrder;	/* ID�� ���� Ŀ�� Display�� ����... */
					InputDisplay.iKeyOnOff = 3;
				}
				InputDisplay.iFlag = 1;
			}
			AsciiInputCnt++;
		}
	/******************************************************************/
/*		IventTableCnt++;*/
/*		AsciiInputCnt++;*/

		return(0);
}
 
void AsciiInputDispWatch(int iOrder)
{
	int				k;
	int				iFormatStyle;
	int				iFontsX;
	int				iFontsY;
//	int				iTemp;
	int				iType;
	int				Back_Color;
	int				iShape_Size;
	int				iFontVal;
	int				istrLen;
	short			iCursor;
	char*			cDataBuff;
	short			iLen;
	short			i;
	char*			cBefDevData;
	_ASCIIINPUT_EVENT_TBL*	 AsciiInputEventTbl;
extern	void	ChangeLowHighByte(char *buff,int cnt);

	k				= 0;
	iFormatStyle	= 0;
	iFontsX			= 0;
	iFontsY			= 0;
//	iTemp			= 0;
	iType			= 0;
	Back_Color		= 0;
	iShape_Size		= 0;
	iLen			= 0;

/*	AsciiInputEventTbl= (_ASCIIINPUT_EVENT_TBL*)IventTable[iOrder];*/
	AsciiInputEventTbl= (_ASCIIINPUT_EVENT_TBL*)TakeMemory(sizeof(_ASCIIINPUT_EVENT_TBL));
	DrawAsciiInput_Func(1,AsciiInputEventTbl,iOrder);
	iCursor=1;
	iFormatStyle = AsciiInputEventTbl->iAlignment;
	cDataBuff = TakeMemory(32);
	memset(cDataBuff,0x00,32);
	cBefDevData= TakeMemory(AsciiInputEventTbl->iDigits+2);
	memcpy(cBefDevData,&DispDeviceData[ScreenTagData[iOrder].DevOrder],AsciiInputEventTbl->iDigits);
// Display Buff Low High Change 2008.06.19
		ChangeLowHighByte(cBefDevData,AsciiInputEventTbl->iDigits);

	/* ������ ������ġ�� ���� ��Ʈ�Ѵ�. */	
		if(!(InputDisplay.iKeyOnOff == 2 && InputDisplay.iInputNo == iOrder))
		{
			for(i=0;i<AsciiInputEventTbl->iDigits;i++)
			{
				 if(cBefDevData[i] == 0x00)
				{
					break;
				}else if(!(cBefDevData[i]<0x80 && cBefDevData[i]>0x00))
				{
					i++;
					iLen++;
				}
				iLen++;		
			}
			memcpy(cDataBuff,cBefDevData,iLen);
		}
		else
		{
			InputDisplay.iLen = AsciiInputEventTbl->iDigits;
			iLen = strlen(InputDisplay.cInputDispBuff);
/* 20080822 */
			memcpy(cDataBuff,InputDisplay.cInputDispBuff,iLen);
			InputDisplay.iInputNo = iOrder;
			
		}

		if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){
			iShape_Size = DrawShape(AsciiInputEventTbl->ShapeNo, 
						ScreenTagData[iOrder].sX, 
						ScreenTagData[iOrder].sY, 
						ScreenTagData[iOrder].eX, 
						ScreenTagData[iOrder].eY,
						AsciiInputEventTbl->iFrameColor,
						AsciiInputEventTbl->iPlateColor);
		}else{
			iShape_Size = 0;			
		}
		if(AsciiInputEventTbl->iFontSizeH == 0){
			iFontVal = 6;
		}else{
			iFontVal = 8;
/* 060919			if(iTemp > 0) */
				iFontVal = AsciiInputEventTbl->iFontSizeH * 8;
		}
		if(iFormatStyle == 0x00)	{			/* Right Alignment	*/
			iFontsX = (ScreenTagData[iOrder].eX+1 - (iLen * iFontVal)) - iShape_Size;
			iFontsY = ScreenTagData[iOrder].sY + iShape_Size;
		}
		else if(iFormatStyle == 0x01){			/* Left Alignment	*/
			iFontsX = ScreenTagData[iOrder].sX + iShape_Size;
			iFontsY = ScreenTagData[iOrder].sY + iShape_Size;
		}
		else if(iFormatStyle == 0x02){			/* Center Alignment */
			iFontsX = (int)((ScreenTagData[iOrder].eX+1 + ScreenTagData[iOrder].sX)/2) - ((int)(iLen*iFontVal)/2);
			iFontsY = ScreenTagData[iOrder].sY + iShape_Size;
		}
		if(AsciiInputEventTbl->iTextColor == 0)
		{
			Back_Color	= WHITE;	
			iType		= T_FRONT;
		}else
		{
			Back_Color = BLACK;
			iType      = T_OR;
		}		

		DotTextOut(iFontsX,
						iFontsY, 
						cDataBuff, 
						AsciiInputEventTbl->iFontSizeH, 
						AsciiInputEventTbl->iFontSizeV, 
						iType, 
						AsciiInputEventTbl->iTextColor, 
						Back_Color);

		if((InputDisplay.iKeyOnOff == 2 || InputDisplay.iKeyOnOff == 3) && InputDisplay.iInputNo == iOrder)
		{
			istrLen = iLen;
			if(istrLen==0 && iFormatStyle == 0x01){
				istrLen=1;
			}else{
				iCursor=1;
				for(k=0;k<istrLen;k++){
					if((unsigned char)(cDataBuff[k]) > 0x80){

						if(istrLen == k+2){
							iCursor=2;
							break;
						}
						k++;
					}
				}
			}
			AreaRevers((iFontsX+(iFontVal * (istrLen-iCursor))),
				ScreenTagData[iOrder].sY+iShape_Size,
				(iFontsX + (iFontVal * istrLen)-1),
				ScreenTagData[iOrder].eY-iShape_Size);
		}

	if(InputDisplay.iKeyOnOff == 1  && InputDisplay.iInputNo == iOrder)
	{
		InputDisplay.iKeyOnOff = 2;
		SwitchingScreenDevice.iBaseScreenFlag = 2;
		iOnSignalStart=0;
	}
	FreeMail(cDataBuff);
	FreeMail(cBefDevData);
	FreeMail((char *)AsciiInputEventTbl);
}
int	AsciiInputTouchCheck(int iOrder)
{
	short			RetVal;
	unsigned int iTriggerDevVal;
extern	void	ChangeLowHighByte(char *buff,int cnt);

	_ASCIIINPUT_EVENT_TBL*	 AsciiInputEventTbl;

	RetVal = OFF;
	AsciiInputEventTbl= (_ASCIIINPUT_EVENT_TBL*)TakeMemory(sizeof(_ASCIIINPUT_EVENT_TBL));
	DrawAsciiInput_Func(1,AsciiInputEventTbl,iOrder);

	/* NOTORDINARY�̎��L�������m�F���� */
	ScreenTagData[iOrder].uu.AsciiIn.iTriggerVal = ON;
	if(ScreenTagData[iOrder].uu.AsciiIn.iTriggerTypeVal != 2){
		iTriggerDevVal = (unsigned int)DeviceData[ScreenTagData[iOrder].uu.AsciiIn.iBStartDataPos];
		if(ScreenTagData[iOrder].uu.AsciiIn.iTriggerTypeVal == ON){
			if(iTriggerDevVal == OFF){
				ScreenTagData[iOrder].uu.AsciiIn.iTriggerVal = OFF;
			}
		}else{
			if(iTriggerDevVal == ON){
				ScreenTagData[iOrder].uu.AsciiIn.iTriggerVal = OFF;
			}
		}
	}
	if(Key.iBuff > 0  &&
		!(InputDisplay.iKeyOnOff == 2 && InputDisplay.iInputNo == iOrder) &&
		ScreenTagData[iOrder].uu.AsciiIn.iTriggerVal == ON)
	{
		if((CommonArea.ProjectAuxSet.OpenKeyWinCkeck == 0xff)) /*|| (CommonArea.ProjectAuxSet.DispCursorWindow == 0x02)*/
		{   
			if(TouchAreaCheck(ScreenTagData[iOrder].sX,
							  ScreenTagData[iOrder].sY, 
							  ScreenTagData[iOrder].eX, 
							  ScreenTagData[iOrder].eY,
							  Key.iBuff) == 1)
			{
				RetVal = ON;
				ScreenTagData[iOrder].UpdateFlag= 1;
				Key.iBuff = 0;
				iPassFlag = 0;
				InputDisplay.iKeyOnOff = 1;
				InputDisplay.iInputNo = iOrder;
				InputDisplay.iFirstflag = 0;
				memset(InputDisplay.cInputDispBuff,0x00,41);		/* strlen(InputDisplay.cInputDispBuff)->41*/
				memcpy(InputDisplay.cInputDispBuff,&DispDeviceData[ScreenTagData[iOrder].DevOrder],AsciiInputEventTbl->iDigits);
// Display Buff Low High Change 2008.06.19
				ChangeLowHighByte(InputDisplay.cInputDispBuff,AsciiInputEventTbl->iDigits);
				CommonArea.KeyWindow.iKeyType = KEY_ASCII; /* 3 : Ascii Type */
			}
		}else if((!(InputDisplay.iKeyOnOff == 3 && InputDisplay.iInputNo == iOrder)) && (CommonArea.ProjectAuxSet.DispCursorWindow == 0x00))
		{
			if(TouchAreaCheck(ScreenTagData[iOrder].sX,
							  ScreenTagData[iOrder].sY, 
							  ScreenTagData[iOrder].eX, 
							  ScreenTagData[iOrder].eY,
							  Key.iBuff) == 1)
			{

				Key.iBuff = 0;
		
				InputDisplay.iKeyOnOff = 3;
				InputDisplay.iInputNo = iOrder;
				ScreenTagData[iOrder].UpdateFlag= 1;
				RetVal = ON;
				iPassFlag = 0;
			}
		}
	}else if(ScreenTagData[iOrder].uu.AsciiIn.iTriggerVal == OFF &&
				TouchAreaCheck(ScreenTagData[iOrder].sX,
							  ScreenTagData[iOrder].sY, 
							  ScreenTagData[iOrder].eX, 
							  ScreenTagData[iOrder].eY,
							  Key.iBuff) == 1)
	{
		ErrorBuzzer();
		Key.iBuff = 0;
		iPassFlag = 0;
	}else if(TouchAreaCheck(ScreenTagData[iOrder].sX,
							  ScreenTagData[iOrder].sY, 
							  ScreenTagData[iOrder].eX, 
							  ScreenTagData[iOrder].eY,
							  Key.iBuff) == 1)
	{
		Key.iBuff = 0;
		iPassFlag = 0;
	}
	if(InputDisplay.iKeyOnOff == 2 && InputDisplay.iInputNo == iOrder && !(Key.iBuff == 0)){
		if(strcmp(InputDisplay.cBufferData,InputDisplay.cInputDispBuff) != 0){
			memcpy(InputDisplay.cBufferData,InputDisplay.cInputDispBuff,sizeof(InputDisplay.cInputDispBuff));
			ScreenTagData[iOrder].UpdateFlag= 1;
			RetVal = ON;
		}
	}
	FreeMail((char *)AsciiInputEventTbl);
	return RetVal;
}
