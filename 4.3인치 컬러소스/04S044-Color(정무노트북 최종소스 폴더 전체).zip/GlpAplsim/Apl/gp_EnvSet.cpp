
#include	"sgt.h"


/* ****************************************************************************** */
/* �迭																			 */
/* ****************************************************************************** */
extern char *cSpeed[10];
extern char *cParity[3];
extern char *cData[2];
extern char *cFlow[2];
extern char *cStop[2];



#ifdef	GP_S057

//#ifdef	WIN32
//	extern	_DISPLAY *Dspname;
//	extern	_DISPLAY1	*LDspname;
//#else
//	extern	const	_DISPLAY *Dspname;
//	extern	const	_DISPLAY1	*LDspname[];
//#endif


_DISPLAY1	*DevDispName;
KEY_CHECK_DATA1	*DevDispKeyTbl;
const	KEY_CHECK_DATA EnvKeyTbl[]={
	{		//Menue Select(1001)
		6,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 1, 2,16, 2,KEY_DEV_MON},
			{ 1, 3,16, 3,KEY_ENVIRON},
			{ 1, 4,16, 4,KEY_DATA_VIEW},
			{ 1, 5,16, 5,KEY_SET_FUNC},
		},
	},
	{		// Device Monitor Select(1002)
		3,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 1, 2,16, 2,KEY_DEV_MON},
		},
	},
	{		// Device Monitor(1003)
		0
	},
	{		// (1004)
		0
	},
	{		// (1005)
		0
	},
	{		// (1006)
		0
	},
	{		// (1007)
		0
	},
	{		// (1008)
		0
	},
	{		// Set Environment(1009)
			0
	},
	{		// Set Language(1010)
		4,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 3, 9, 7,10,KEY_ENG},
			{10, 9,14,10,KEY_FOR},
		},
	},
	{		// Set Plc Kind(1011)
		0
	},
	{		// Set Clock(1012)
		0
	},
	{		// Set USER DATA CLEAR(1013)
		4,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 3, 7, 7, 8,KEY_YES},
			{10, 7,14, 8,KEY_NO},
		},
	},
	{		// Set Main Call(1014)
		6,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 2, 5, 2, 6,KEY_LEFT_TOP},
			{15, 5,15, 6,KEY_RIGHT_TOP},
			{ 2,10, 2,11,KEY_LET_BOT},
			{15,10,15,11,KEY_RIGHT_BOT},
		},
	},
	{		// Set BUZZER(1015)
		4,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 3, 7, 7, 8,KEY_BUZ_ON},
			{10, 7,14, 8,KEY_BUZ_OFF},
		},
	},
	{		// Set Plc Kind(1016)
		0
	},
	{		// Set Plc Kind(1017)
		0
	},
	{		// Battery(1018)
		2,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
		},
	},
	{		// Set LCD Contrast(1019)
		4,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 1,11, 1,11,KEY_LEFT},
			{16,11,16,11,KEY_RIGHT},
		},
	},
	{		// Data View Menu(1020)
		7,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 1, 2,16, 2,KEY_BASE_SCREEN},
			{ 1, 3,16, 3,KEY_WINDOW_SCREEN},
			{ 1, 4,16, 4,KEY_COMMENT_SCREEN},
			{ 1, 5,16, 5,KEY_MEMORY_SIZE},
			{ 1, 6,16, 6,KEY_VER_NUM},
		},
	},
	{		// Base Screen(1021)
		0
	},
	{		// Base Screen(1022)
		0
	},
	{		// Base Screen(1023)
		0
	},
	{		// Base Screen(1024)
		0
	},
	{		// Base Screen(1025)
		0
	},
	{		// Base Screen(1026)
		0
	},
	{		// Base Screen(1027)
		0
	},
	{		// Base Screen(1028)
		0
	},
	{		// Base Screen(1029)
		0
	},
	{		// Print Out(1030)
		4,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 7, 7, 9, 7,KEY_YES},
			{11, 7,13, 7,KEY_NO},
		},
	},
};
// Many Key Table
const	KEY_CHECK_DATA1 EnvKeyTbl1[]={
	{		// Set Environment(1009)(0)
		13,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 1, 2,16, 2,KEY_LANG},
			{ 1, 3,16, 3,KEY_PLC},
			{ 1, 4,16, 4,KEY_CLOCK},
			{ 1, 5,16, 5,KEY_CLEAR},
			{ 1, 6,16, 6,KEY_MENU_CALL},
			{ 1, 7,16, 7,KEY_BUZZER},
			{ 1, 8,16, 8,KEY_OPENNING},
			{ 1, 9,16, 9,KEY_BACK},
			{ 1,10,16,10,KEY_BATTERY},
			{ 1,11,16,11,KEY_CONTRAST},
			{ 1,12,16,12,KEY_UWLATCH},
		},
	},
	{		// Set Plc(1011)(1)
		18,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 1, 3,12, 3,KEY_CH1_PROT},
			{13, 3,16, 3,KEY_CH1_CHANEL},
			{ 4, 4, 7, 4,KEY_CH1_SPEED},
			{13, 4,16, 4,KEY_CH1_XON},
			{ 4, 5, 5, 5,KEY_CH1_DATA},
			{10, 5,11, 5,KEY_CH1_STOP},
			{15, 5,16, 5,KEY_CH1_PARTY},
			{ 1, 8,12, 8,KEY_CH2_PROT},
			{13, 8,16, 8,KEY_CH2_CHANEL},
			{ 4, 9, 7, 9,KEY_CH2_SPEED},
			{13, 9,16, 9,KEY_CH2_XON},
			{ 4,10, 5,10,KEY_CH2_DATA},
			{10,10,11,10,KEY_CH2_STOP},
			{15,10,16,10,KEY_CH2_PARTY},
			{ 6,12, 7,12,KEY_GP_NO},
			{15,12,16,12,KEY_PLC_NO},
		},
	},
	{		// Set Clock(1012)(2)
		26,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 3, 3, 5, 4,KEY_CLK0},
			{ 6, 3, 8, 4,KEY_CLK1},
			{ 9, 3,11, 4,KEY_CLK2},
			{12, 3,14, 4,KEY_CLK3},
			{ 3, 5, 5, 6,KEY_CLK4},
			{ 6, 5, 8, 6,KEY_CLK5},
			{ 9, 5,11, 6,KEY_CLK6},
			{12, 5,14, 6,KEY_CLK7},
			{ 3, 7, 5, 8,KEY_CLK8},
			{ 6, 7, 8, 8,KEY_CLK9},
			{ 9, 7,11, 8,KEY_CLK_CLR},
			{12, 7,14, 8,KEY_CLK_ENT},
			{ 5,10, 5,10,KEY_CLK_D01},
			{ 6,10, 6,10,KEY_CLK_D02},
			{ 7,10, 7,10,KEY_CLK_D03},
			{ 8,10, 8,10,KEY_CLK_D04},
			{ 9,10, 9,10,KEY_CLK_D05},
			{10,10,10,10,KEY_CLK_D06},
			{ 5,11, 5,11,KEY_CLK_T01},
			{ 6,11, 6,11,KEY_CLK_T02},
			{ 7,11, 7,11,KEY_CLK_T03},
			{ 8,11, 8,11,KEY_CLK_T04},
			{ 9,11, 9,11,KEY_CLK_T05},
			{10,11,10,11,KEY_CLK_T06},
		},
	},
	{		// Set Openning(1016)(3)
		15,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 3, 3, 5, 4,KEY_CLK0},
			{ 6, 3, 8, 4,KEY_CLK1},
			{ 9, 3,11, 4,KEY_CLK2},
			{12, 3,14, 4,KEY_CLK3},
			{ 3, 5, 5, 6,KEY_CLK4},
			{ 6, 5, 8, 6,KEY_CLK5},
			{ 9, 5,11, 6,KEY_CLK6},
			{12, 5,14, 6,KEY_CLK7},
			{ 3, 7, 5, 8,KEY_CLK8},
			{ 6, 7, 8, 8,KEY_CLK9},
			{ 9, 7,11, 8,KEY_CLK_CLR},
			{12, 7,14, 8,KEY_CLK_ENT},
			{10,10,12,10,KEY_CLK_D01},
		},
	},
	{		// Device Monitor(1003)(4)
		8,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{15, 2,16, 2,KEY_UP},
			{ 1,12, 4,12,KEY_DEVICE},
			{ 5,12, 7,12,KEY_SET},
			{ 9,12,11,12,KEY_ON},
			{12,12,14,12,KEY_OFF},
			{15,12,16,12,KEY_DOWN},
		},
	},
	{		// device/number (1012)(5)
		22,
		{

			{12+KEYSWITCH_X_OFFSET_MESH, 3+KEYSWITCH_Y_OFFSET_MESH,13+KEYSWITCH_X_OFFSET_MESH, 3+KEYSWITCH_Y_OFFSET_MESH,KEY_CLK_CLR},
			{12+KEYSWITCH_X_OFFSET_MESH, 7+KEYSWITCH_Y_OFFSET_MESH,13+KEYSWITCH_X_OFFSET_MESH, 7+KEYSWITCH_Y_OFFSET_MESH,KEY_CLK_ENT},
			{ 2+KEYSWITCH_X_OFFSET_MESH, 4+KEYSWITCH_Y_OFFSET_MESH, 3+KEYSWITCH_X_OFFSET_MESH, 4+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 4+KEYSWITCH_X_OFFSET_MESH, 4+KEYSWITCH_Y_OFFSET_MESH, 5+KEYSWITCH_X_OFFSET_MESH, 4+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 6+KEYSWITCH_X_OFFSET_MESH, 4+KEYSWITCH_Y_OFFSET_MESH, 7+KEYSWITCH_X_OFFSET_MESH, 4+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 8+KEYSWITCH_X_OFFSET_MESH, 4+KEYSWITCH_Y_OFFSET_MESH, 9+KEYSWITCH_X_OFFSET_MESH, 4+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{10+KEYSWITCH_X_OFFSET_MESH, 4+KEYSWITCH_Y_OFFSET_MESH,11+KEYSWITCH_X_OFFSET_MESH, 4+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 2+KEYSWITCH_X_OFFSET_MESH, 5+KEYSWITCH_Y_OFFSET_MESH, 3+KEYSWITCH_X_OFFSET_MESH, 5+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 4+KEYSWITCH_X_OFFSET_MESH, 5+KEYSWITCH_Y_OFFSET_MESH, 5+KEYSWITCH_X_OFFSET_MESH, 5+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 6+KEYSWITCH_X_OFFSET_MESH, 5+KEYSWITCH_Y_OFFSET_MESH, 7+KEYSWITCH_X_OFFSET_MESH, 5+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 8+KEYSWITCH_X_OFFSET_MESH, 5+KEYSWITCH_Y_OFFSET_MESH, 9+KEYSWITCH_X_OFFSET_MESH, 5+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{10+KEYSWITCH_X_OFFSET_MESH, 5+KEYSWITCH_Y_OFFSET_MESH,11+KEYSWITCH_X_OFFSET_MESH, 5+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 2+KEYSWITCH_X_OFFSET_MESH, 6+KEYSWITCH_Y_OFFSET_MESH, 3+KEYSWITCH_X_OFFSET_MESH, 6+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 4+KEYSWITCH_X_OFFSET_MESH, 6+KEYSWITCH_Y_OFFSET_MESH, 5+KEYSWITCH_X_OFFSET_MESH, 6+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 6+KEYSWITCH_X_OFFSET_MESH, 6+KEYSWITCH_Y_OFFSET_MESH, 7+KEYSWITCH_X_OFFSET_MESH, 6+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 8+KEYSWITCH_X_OFFSET_MESH, 6+KEYSWITCH_Y_OFFSET_MESH, 9+KEYSWITCH_X_OFFSET_MESH, 6+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{10+KEYSWITCH_X_OFFSET_MESH, 6+KEYSWITCH_Y_OFFSET_MESH,11+KEYSWITCH_X_OFFSET_MESH, 6+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 2+KEYSWITCH_X_OFFSET_MESH, 7+KEYSWITCH_Y_OFFSET_MESH, 3+KEYSWITCH_X_OFFSET_MESH, 7+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 4+KEYSWITCH_X_OFFSET_MESH, 7+KEYSWITCH_Y_OFFSET_MESH, 5+KEYSWITCH_X_OFFSET_MESH, 7+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 6+KEYSWITCH_X_OFFSET_MESH, 7+KEYSWITCH_Y_OFFSET_MESH, 7+KEYSWITCH_X_OFFSET_MESH, 7+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{ 8+KEYSWITCH_X_OFFSET_MESH, 7+KEYSWITCH_Y_OFFSET_MESH, 9+KEYSWITCH_X_OFFSET_MESH, 7+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},
			{10+KEYSWITCH_X_OFFSET_MESH, 7+KEYSWITCH_Y_OFFSET_MESH,11+KEYSWITCH_X_OFFSET_MESH, 7+KEYSWITCH_Y_OFFSET_MESH,KEY_NO_DATA},

		},
	},
	{		// Base Screen(1021)(6)
		14,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 1, 2,14, 2,KEY_LINE1},
			{ 1, 3,14, 3,KEY_LINE2},
			{ 1, 4,14, 4,KEY_LINE3},
			{ 1, 5,14, 5,KEY_LINE4},
			{ 1, 6,14, 6,KEY_LINE5},
			{ 1, 7,14, 7,KEY_LINE6},
			{ 1, 8,14, 8,KEY_LINE7},
			{ 1, 9,14, 9,KEY_LINE8},
			{ 1,10,14,10,KEY_LINE9},
			{ 1,11,14,11,KEY_LINE10},
			{15, 2,16, 2,KEY_UP},
			{15,12,16,12,KEY_DOWN},
		},
	},
	{		// Time Switch1(1026)(7)
		18,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 3, 3, 7, 3,KEY_DEV1},
			{ 8, 3,16, 3,KEY_DEVL1},
			{ 3, 4, 7, 4,KEY_DEV2},
			{ 8, 4,16, 4,KEY_DEVL2},
			{ 3, 5, 7, 5,KEY_DEV3},
			{ 8, 5,16, 5,KEY_DEVL3},
			{ 3, 6, 7, 6,KEY_DEV4},
			{ 8, 6,16, 6,KEY_DEVL4},
			{ 3, 7, 7, 7,KEY_DEV5},
			{ 8, 7,16, 7,KEY_DEVL5},
			{ 3, 8, 7, 8,KEY_DEV6},
			{ 8, 8,16, 8,KEY_DEVL6},
			{ 3, 9, 7, 9,KEY_DEV7},
			{ 8, 9,16, 9,KEY_DEVL7},
			{ 3,10, 7,10,KEY_DEV8},
			{ 8,10,16,10,KEY_DEVL8},
		},
	},
	{		// Time Switch2(1026)(8)
		15,
		{
			{ 1, 1, 3, 1,KEY_EXIT},
			{14, 1,16, 1,KEY_MENU_END},
			{ 2, 4, 3, 4,KEY_SUN},
			{ 4, 4, 5, 4,KEY_MON},
			{ 6, 4, 7, 4,KEY_THE},
			{ 8, 4, 9, 4,KEY_WED},
			{10, 4,11, 4,KEY_THU},
			{12, 4,13, 4,KEY_FRI},
			{14, 4,15, 4,KEY_SAT},
			{ 9, 8, 9, 8,KEY_START_H},
			{11, 8,11, 8,KEY_START_M},
			{13, 8,13, 8,KEY_START_S},
			{ 9,10, 9,10,KEY_END_H},
			{11,10,11,10,KEY_END_M},
			{13,10,13,10,KEY_END_S},
		},
	},
};
const	char	*WeekName[7]={
	"SUN","MON","TUE","WED","THU","FRI","SAT"
};
int	RepeatKeyCheck(int Key)
{
	int	ret= NG;
	int	i,j;

	if(KerRepeatFlag == 1){
		for(i= 0; i < RepeatInfo.EntryCnt; i++){
			for(j= 0; j < 8; j++){
				if(RepeatInfo.RepeatNo[i][j] == Key){
					ret= OK;
					break;
				}
			}
			if(ret == OK){
				break;
			}
		}
	}
	return(ret);
}
/********************************************************************************/
/*	Key Input Proc																*/
/*	�L?������Ȃ��ŘA���̓��͖͂�������										*/
/*																				*/
/********************************************************************************/
int	EndvKeyCheck(KEY_CHECK_DATA *pEnvKeyTbl)
{
	int		iKeyCode;
	int		EndFlag;
	int		i;
	int		InX;
	int		InY;
	int		OffClear;

	EndFlag= 0;
	OffClear= 1;
	while(EndFlag == 0){
		iKeyCode = KeyWait();
		switch(iKeyCode){
		case PC_DNLOAD_START:
		case PC_UPLOAD_START:
		case PC_UPDOWN_END:
			NormalBuzzer();										/*	Buzzer			*/
			EndFlag= 1;
			break;
		case PC_CONT:
			EndFlag= 1;
			break;
		case 0:
			OffClear= 0;
			break;
		default:
			if(OffClear == 1){
				//Repeat Key�͗L��
				if(RepeatKeyCheck(iKeyCode) == NG){
					break;
				}
			}
			InX= (iKeyCode- 1)%(GAMEN_X_SIZE/MESH_X)+ 1;
			InY= (iKeyCode- 1)/(GAMEN_X_SIZE/MESH_X)+ 1;
			for(i= 0; i < pEnvKeyTbl->cnt; i++){
				if(((InX >= pEnvKeyTbl->KeyData[i].startX) &&
					(InX <= pEnvKeyTbl->KeyData[i].endX)) &&
				   ((InY >= pEnvKeyTbl->KeyData[i].startY) &&
				   (InY <= pEnvKeyTbl->KeyData[i].endY))){
					NormalBuzzer();										/*	Buzzer			*/
					iKeyCode= pEnvKeyTbl->KeyData[i].code;
					EndFlag= 1;
					break;
				}
			}
			break;
		}
	}
	return(iKeyCode);
}
/********************************************************************************/
/*	�w��?�ځi�e�L�X�g�j�̎w��ʒu��?����									*/
/*	IN	int idx:?��ID															*/
/*		int pos:��?�����ʒu													*/
/********************************************************************************/
void	ReversTextItemData(int idx,int pos)
{
	int		sX,sY,eX,eY;
	int		iTextSize,iTextVSize;
	_FIGURE_EVENT_TBL* FigureEventTbl;

	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	MakeTagCode_09(ScreenTagData[idx].TagPos,0,FigureEventTbl);
	switch(FigureEventTbl->ST.TextInfo.iSizeH){
	case 0:
		iTextSize= 6;
		break;
	default:
		iTextSize= FigureEventTbl->ST.TextInfo.iSizeH*8;
		break;
	}
	switch(FigureEventTbl->ST.TextInfo.iSizeV){
	case 0:		//6*8
		iTextVSize= 8;
		break;
	default:
		iTextVSize= FigureEventTbl->ST.TextInfo.iSizeV*16;
		break;
	}

	sX= ScreenTagData[idx].sX+pos*iTextSize;
	sY= ScreenTagData[idx].sY;
	eX= sX+iTextSize- 1;
	eY= sY+iTextVSize- 1;
	AreaRevers(sX, sY, eX, eY);
	FreeMail((char *)FigureEventTbl);
}
/********************************************************************************/
/*	�w��?�ڂ̗̈���N���A����													*/
/*	IN	int idx:?��ID															*/
/********************************************************************************/
void	ClearTextItemData(int idx)
{
	AreaClear(ScreenTagData[idx].sX, ScreenTagData[idx].sY,
		ScreenTagData[idx].eX, ScreenTagData[idx].eY,0);
}
void	ClearTextItemData1(int idx)
{
	AreaClear(ScreenTagData[idx].sX, ScreenTagData[idx].sY,
		ScreenTagData[idx].eX, ScreenTagData[idx].eY-1,0);
}
void	ClearTextItemData2(int idx)
{
	AreaClear(ScreenTagData[idx].sX+1, ScreenTagData[idx].sY+1,
		ScreenTagData[idx].eX-1, ScreenTagData[idx].eY-1,0);
}
void	ReversItemData(int idx)
{
	AreaRevers(ScreenTagData[idx].sX+1, ScreenTagData[idx].sY+1,
		ScreenTagData[idx].eX-1, ScreenTagData[idx].eY-1);
}
/********************************************************************************/
/*	�w��?�ڂ�?���Ńe�L�X�g�𒆐S��?������									*/
/*	IN	int idx:?��ID															*/
/*		_FIGURE_EVENT_TBL* FigureEventTbl:�C�x���g�e?�u���A�h���X				*/
/*		char *textbuff:?������													*/
/********************************************************************************/
void	DispTextItemCenter(int idx,_FIGURE_EVENT_TBL* FigureEventTbl,char *textbuff)
{
	short	iBack_Color;
	short	iType;
	int	iLen;

	MakeTagCode_09(ScreenTagData[idx].TagPos,0,FigureEventTbl);
	if(FigureEventTbl->ST.TextInfo.iTextColor == 0)
	{
		iBack_Color	= WHITE;	
		iType		= T_FRONT;
	}else
	{
		iBack_Color = BLACK;
		iType      = T_OR;
	}
	iLen = strlen(textbuff);
	iLen = (short)((ScreenTagData[idx].eX-ScreenTagData[idx].sX) - (iLen*8))/2;
	DotTextOut(ScreenTagData[idx].sX+iLen, ScreenTagData[idx].sY,
		textbuff,
		FigureEventTbl->ST.TextInfo.iSizeH, 
		FigureEventTbl->ST.TextInfo.iSizeV, iType,
		FigureEventTbl->ST.TextInfo.iTextColor,
		iBack_Color);
}
/********************************************************************************/
/*	�w��?�ڂ�?���Ő擪���?������											*/
/*	IN	int idx:?��ID															*/
/*		_FIGURE_EVENT_TBL* FigureEventTbl:�C�x���g�e?�u���A�h���X				*/
/*		char *textbuff:?������													*/
/********************************************************************************/
void	DispTextItemData(int idx,_FIGURE_EVENT_TBL* FigureEventTbl,char *textbuff)
{
	short	iBack_Color;
	short	iType;

	MakeTagCode_09(ScreenTagData[idx].TagPos,0,FigureEventTbl);
	if(FigureEventTbl->ST.TextInfo.iTextColor == 0)
	{
		iBack_Color	= WHITE;	
		iType		= T_FRONT;
	}else
	{
		iBack_Color = BLACK;
		iType      = T_OR;
	}
	DotTextOut(ScreenTagData[idx].sX, ScreenTagData[idx].sY,
		textbuff,
		FigureEventTbl->ST.TextInfo.iSizeH, 
		FigureEventTbl->ST.TextInfo.iSizeV, iType,
		FigureEventTbl->ST.TextInfo.iTextColor,
		iBack_Color);
}
void	DispTextItemDataFont(int idx,_FIGURE_EVENT_TBL* FigureEventTbl,char *textbuff,int iSizeH,int iSizeV)
{
	short	iBack_Color;
	short	iType;

	MakeTagCode_09(ScreenTagData[idx].TagPos,0,FigureEventTbl);
	if(FigureEventTbl->ST.TextInfo.iTextColor == 0)
	{
		iBack_Color	= WHITE;	
		iType		= T_FRONT;
	}else
	{
		iBack_Color = BLACK;
		iType      = T_OR;
	}
	DotTextOut(ScreenTagData[idx].sX, ScreenTagData[idx].sY,
		textbuff,
		iSizeH, 
		iSizeV, iType,
		FigureEventTbl->ST.TextInfo.iTextColor,
		iBack_Color);
}
void	DispTextItemDataCursor(int idx,_FIGURE_EVENT_TBL* FigureEventTbl,char *textbuff)
{
	short	iBack_Color;
	short	iType;
	int		len;

	MakeTagCode_09(ScreenTagData[idx].TagPos,0,FigureEventTbl);
	if(FigureEventTbl->ST.TextInfo.iTextColor == 0)
	{
		iBack_Color	= T_WHITE;	
		iType		= T_FRONT;
	}else
	{
		iBack_Color = T_BLACK;
		iType      = T_OR;
	}
	DotTextOut(ScreenTagData[idx].sX, ScreenTagData[idx].sY,
		textbuff,
		FigureEventTbl->ST.TextInfo.iSizeH, 
		FigureEventTbl->ST.TextInfo.iSizeV, iType,
		FigureEventTbl->ST.TextInfo.iTextColor,
		iBack_Color);
	//Cursor Disp
//	iBack_Color	= BLACK;	
	iType		= T_FRONT;
	len= strlen(textbuff);
	DotTextOut(ScreenTagData[idx].sX+(len-1)*8, ScreenTagData[idx].sY,
		&textbuff[len-1],
		FigureEventTbl->ST.TextInfo.iSizeH, 
		FigureEventTbl->ST.TextInfo.iSizeV, iType,
		T_BLACK,
		T_WHITE);
}
/********************************************************************************/
/*	��ʃf??�̃e�L�X�g��S��?������B�e�L�X�g��SystemMessage�ԍ������o���B*/
/*	IN	int mesNo:���b�Z?�W�e?�u���ԍ�										*/
/*		int iTotalCnt:��ʓ�?�ڐ�												*/
/********************************************************************************/
void	DispTextData(int mesNo,int iTotalCnt)
{
	int		i,idx;
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	for(i= 0,idx= 0; i < iTotalCnt; i++){
		if(ScreenTagData[i].cObjects == TEXT_DISP){
			switch(mesNo){
			case PLC_SETTING:
				DispTextItemData(i,FigureEventTbl,LDspname[L_PLC_SETTING].chName[Set.iLang][idx++]);
				break;
			case CLOCK_MENU:
				DispTextItemData(i,FigureEventTbl,LDspname[L_CLOCK_MENU].chName[Set.iLang][idx++]);
				break;
			case OPENNING:
				DispTextItemData(i,FigureEventTbl,LDspname[L_OPENNING].chName[Set.iLang][idx++]);
				break;
			case DEVMON_SELECT:
				DispTextItemCenter(i,FigureEventTbl,DevDispName->chName[Set.iLang][idx++]);
				break;
			case LG_TIME_SWITCH:
				DispTextItemData(i,FigureEventTbl,LDspname[L_LG_TIME_SWITCH].chName[Set.iLang][idx++]);
				break;
			case PRINT_OUT:
				if(idx == 4){
					DispTextItemData(i,FigureEventTbl,Dspname[mesNo].chName[Set.iLang][idx++]);
				}else{
					DispTextItemCenter(i,FigureEventTbl,Dspname[mesNo].chName[Set.iLang][idx++]);
				}
				break;
			case UWLATCH:
				if(idx < 2){
					DispTextItemCenter(i,FigureEventTbl,Dspname[UWLATCH].chName[Set.iLang][idx++]);
				}else{
					DispTextItemData(i,FigureEventTbl,Dspname[UWLATCH].chName[Set.iLang][idx++]);
				}
				break;
			default:
				if(idx < 2){
					DispTextItemCenter(i,FigureEventTbl,Dspname[mesNo].chName[Set.iLang][idx++]);
				}else{
					DispTextItemData(i,FigureEventTbl,Dspname[mesNo].chName[Set.iLang][idx++]);
				}
				break;
			}
		}
	}
	FreeMail((char *)FigureEventTbl);
}
/********************************************************************************/
/*	�w��?�ڂ�?���Ő擪���?������											*/
/*	IN	int idx:?��ID															*/
/*		char *textbuff:?������													*/
/********************************************************************************/
void	DispTextSetItemData(int idx,char *textbuff)
{
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	DispTextItemData(idx,FigureEventTbl,textbuff);
	FreeMail((char *)FigureEventTbl);
}
void	DispTextSetItemDataFont(int idx,char *textbuff,int SizeH,int SizeV)
{
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	DispTextItemDataFont(idx,FigureEventTbl,textbuff,SizeH,SizeV);
	FreeMail((char *)FigureEventTbl);
}
void	DispTextSetItemDataCursor(int idx,char *textbuff)
{
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	DispTextItemDataCursor(idx,FigureEventTbl,textbuff);
	FreeMail((char *)FigureEventTbl);
}
/********************************************************************************/
/*	�w��?�ڂ�?���Ńe�L�X�g�𒆐S��?������									*/
/*	IN	int idx:?��ID															*/
/*		char *textbuff:?������													*/
/********************************************************************************/
void	DispTextSetItemCenter(int idx,char *textbuff)
{
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	DispTextItemCenter(idx,FigureEventTbl,textbuff);
	FreeMail((char *)FigureEventTbl);
}
/********************************************************************************/
/*	Select Menue																*/
/********************************************************************************/
void	SelectMenu(int *iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;

	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_MENU_SEL,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(SELECT_MEMU,iTotalCnt);
	DrawLcdBank1();
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_MENU_SEL-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
		case KEY_MENU_END:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_DEV_MON:
			*iScreenNo = MONITORING_NUM;
			EndFlag= 1;
			break;
		case KEY_ENVIRON:
			*iScreenNo = SET_ENVIRONMENT_NUM;										
			EndFlag= 1;
			break;
		case KEY_DATA_VIEW:
			*iScreenNo = DATA_VIEW_NUM;
			EndFlag= 1;
			break;
		case KEY_SET_FUNC:
			*iScreenNo = SET_FUNTION_NUM;
			EndFlag= 1;
			break;
		} 			
	} 
	return;
}
/********************************************************************************/
/*	Environment Menue Display													*/
/********************************************************************************/
void	ClockDisp(void)
{
	char	LineDataBuffer[40];

	memset(LineDataBuffer,0x00,sizeof(LineDataBuffer));
	sprintf(LineDataBuffer,"%s [ %d:%02d:%02d ]",Dspname[SET_ENVIRONMENT].chName[Set.iLang][4],
		SystemTime.hour,SystemTime.min,SystemTime.sec);
	DispTextSetItemData(G_ENV_CLOCK,LineDataBuffer);
}
void	BuzzerDisp(void)
{
	char	LineDataBuffer[40];

	memset(LineDataBuffer,0x00,sizeof(LineDataBuffer));
	sprintf(LineDataBuffer,"%s [ %s ]",Dspname[SET_ENVIRONMENT].chName[Set.iLang][7],
		Dspname[BUZZER].chName[Set.iLang][Set.iBuzzer+6]);
	DispTextSetItemData(G_ENV_BUZZER,LineDataBuffer);
}
void	OpenningDisp(void)
{
	char	LineDataBuffer[40];

	memset(LineDataBuffer,0x00,sizeof(LineDataBuffer));
	sprintf(LineDataBuffer,"%s [ %d%s ]",Dspname[SET_ENVIRONMENT].chName[Set.iLang][8],
		Set.iTitleDispTime,
		Dspname[OPENNING].chName[Set.iLang][1]);
	DispTextSetItemData(G_ENV_OPEN,LineDataBuffer);
}
void	BackLightDisp(void)
{
	char	LineDataBuffer[40];

	memset(LineDataBuffer,0x00,sizeof(LineDataBuffer));
	sprintf(LineDataBuffer,"%s [ %d%s ]",Dspname[SET_ENVIRONMENT].chName[Set.iLang][9],
		Set.iBackLightTime,
		Dspname[BACKLIGHT].chName[Set.iLang][1]);
	DispTextSetItemData(G_ENV_BACK,LineDataBuffer);		
}
void	BatteryDisp(void)
{
	int		iLen;
	char	LineDataBuffer[40];

	memset(LineDataBuffer,0x00,sizeof(LineDataBuffer));
	if(CommonArea.BatteryLevel>=BATT_MAX_REVEL)	
	{
		iLen=100;
		sprintf(LineDataBuffer,"%s [%d%%]",
			Dspname[SET_ENVIRONMENT].chName[Set.iLang][10],iLen);
	}
	else if((BATT_MIN_REVEL < CommonArea.BatteryLevel) && (CommonArea.BatteryLevel< BATT_MAX_REVEL))
	{
		iLen = (int)(((CommonArea.BatteryLevel-BATT_MIN_REVEL)*100)/(BATT_MAX_REVEL- BATT_MIN_REVEL));
		sprintf(LineDataBuffer,"%s [%d%%]",
			Dspname[SET_ENVIRONMENT].chName[Set.iLang][10],iLen);
	}
	else
	{
		sprintf(LineDataBuffer,"%s [ Bat Low ]",
			Dspname[SET_ENVIRONMENT].chName[Set.iLang][10]);
	}
	DispTextSetItemData(G_ENV_BATTERY,LineDataBuffer);
}
/********************************************************************************/
/*	Environment Menue Display													*/
/********************************************************************************/
void	EnvMenuDisp(void)
{
	//CLOCK
	ClockDisp();
	//BUZZER
	BuzzerDisp();
	//OPEN
	OpenningDisp();
	//BACK LIGHT
	BackLightDisp();
	//BATTERY
	BatteryDisp();
}
void	DispEnvState(T_MAIL *mp)
{
	int		signal;
	short		iNowSecTime;

	SetWindowNo(SCREEN_0);
	iNowSecTime= -1;
	while(1){
		signal= ReadSignal(S_ENV);
		if((signal & 0x0001) != 0){
			switch(mp->mcmd){
			case 0:		//ENV Select
				if(SystemTime.sec != iNowSecTime){
					iNowSecTime= SystemTime.sec;
					ClearTextItemData(G_ENV_CLOCK);
					ClockDisp();
					ClearTextItemData(G_ENV_BATTERY);
					BatteryDisp();
					DrawLcdBank1();
				}
				break;
			case 1:		//CLOC SET
				if(SystemTime.sec != iNowSecTime){
					iNowSecTime= SystemTime.sec;
					DateTimeDisp(mp->mpar,&SystemTime);
					DrawLcdBank1();
				}
				break;
			case 2:		//BATTERY
				if(SystemTime.sec != iNowSecTime){
					iNowSecTime= SystemTime.sec;
					DispBatterySet();
					DrawLcdBank1();
				}
				break;
			}
		}else{
			break;
		}
		Delay(100);
	}
}

/********************************************************************************/
/*	Environment Menue															*/
/********************************************************************************/
void	SetEnvironmentMode(int *iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		ScreenNum;
	int		iflag;
	int		iTotalCnt;

	ScreenNum = SET_ENVIRONMENT_NUM * 100;
	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_ENVIRONMENT_MENU,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(SET_ENVIRONMENT,iTotalCnt);

	EnvMenuDisp();
	DrawLcdBank1();
	EndFlag= 0;
	OnSignal(S_ENV,0x0001);			//State Start
	SendInitTask(INI_ENV_STATE,0);
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA*)&EnvKeyTbl1[0]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SELECT_MEMU_NUM;
			EndFlag= 1;
			break;
		default:
			OffSignal(S_ENV,0x0001);			//State End
			Delay(10);
			ScreenNum= ScreenNum+ (iKeyCode- KEY_LANG);
			if(iKeyCode > KEY_LANG){	//�̂̃o?�W�����ɍ��킹�邽��
				ScreenNum++;
			}
			iflag = iSysSetretCheck(ScreenNum);
			switch(iflag){
			case DOWN_TRANS:		/* DownLoad */
			case UP_TRANS:	/* UPLoad */
				*iScreenNo = iflag;
				EndFlag= 1;
				break;
			default:
				if(iflag == 0){					/* ȭ���̵� ó�� */
					*iScreenNo = ScreenNum;		/*  ȭ�����			 */
					EndFlag= 1;
				}else{	/* ���� ȭ�� ��� */
					*iScreenNo = SET_ENVIRONMENT_NUM;
				}
				break;
			}
			break;
		}
	}
	OffSignal(S_ENV,0x0001);			//State End
	Delay(100);
}
/********************************************************************************/
/*	Set Language																*/
/********************************************************************************/
void	EngForReverse(int idx)
{
	AreaRevers(ScreenTagData[idx].sX+1, 
				 ScreenTagData[idx].sY+1, 
				 ScreenTagData[idx].eX-1, 
				 ScreenTagData[idx].eY-1);
}
const	int	LangIdx[2]={
	17,18
};
void	DispLangageName(void)
{
	_FIGURE_EVENT_TBL*			FigureEventTbl;
	char	chFont[16];

	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	//Forign Name
	if(*Set.FontName == 0)
	{
		sprintf(chFont,Dspname[LANGUAGE].chName[Set.iLang][13]);
	}
	else
	{
		sprintf(chFont,Set.FontName);
	}
	DispTextItemData(LangIdx[0],FigureEventTbl,chFont);
	//English Name
	if(*Set.FontName == 0)
	{
		sprintf(chFont,Dspname[LANGUAGE].chName[Set.iLang][14]);
	}
	else
	{
		sprintf(chFont,Set.eFontName);
	}
	DispTextItemData(LangIdx[1],FigureEventTbl,chFont);
	FreeMail((char*)FigureEventTbl);
}
void	vLangSet(int *iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		OldLang;
	int		iTotalCnt;

	OldLang = Set.iLang;
	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_LANGUAGE,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(LANGUAGE,iTotalCnt);
	if(Set.iLang == LANG_ENG){
		EngForReverse(19);					//
		EngForReverse(20);					//�x?�X��ʂ���?���Ă��邽��
	}
	DispLangageName();
	DrawLcdBank1();
	EndFlag= 0;

	//19,20Reverse
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_LANGUAGE-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_ENVIRONMENT_NUM;
			EndFlag= 1;
			break;
		case KEY_ENG:
			if(Set.iLang == LANG_FOR){
				Set.iLang= LANG_ENG;
				EngForReverse(19);					//
				EngForReverse(20);					//�x?�X��ʂ���?���Ă��邽��
				DrawLcdBank1();
			}
			break;
		case KEY_FOR:
			if(Set.iLang == LANG_ENG){
				Set.iLang= LANG_FOR;
				EngForReverse(19);					//
				EngForReverse(20);					//�x?�X��ʂ���?���Ă��邽��
				DrawLcdBank1();
			}
			break;
		}
	}
	//Set Data Flash Write
	if(OldLang != Set.iLang)
	{
		mWriteSettei();
	}
}
/********************************************************************************/
/*	Set Plc																		*/
/********************************************************************************/
void	SetStationNoResult(int *iScreenNo,int iKeyCode,int *EndFlag,int *iTotalCnt)
{
	switch(iKeyCode){
	case PC_DNLOAD_START:		/* DownLoad	*/
		*iScreenNo = DOWN_TRANS;
		*EndFlag= 1;
		break;
	case PC_UPLOAD_START:
		*iScreenNo = UP_TRANS;
		*EndFlag= 1;
		break;
	default:
		ClearDispBuff(SCREEN_0);			/* Clear Display Buff */
		DispBaseFiger(G_PLC_SETTING,iTotalCnt);		/* Initial Display */
		DispTextData(PLC_SETTING,*iTotalCnt);
		vPlcSetDisp();								/*  ó��ȭ��E���			 */
		vSerialSetDisp();
		DrawLcdBank1();
		break;
	}
}
void	vPlcSet(int *iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		iKind;	/* 2008.11.21 */

	OffSignal(SGN_PLC, 0xFFFFFFFF);
	ClearDispBuff(SCREEN_0);			/* Clear Display Buff */
	DispBaseFiger(G_PLC_SETTING,&iTotalCnt);		/* Initial Display */
	DispTextData(PLC_SETTING,iTotalCnt);
	vPlcSetDisp();								/*  ó��ȭ��E���			 */
	vSerialSetDisp();
	DrawLcdBank1();
	EndFlag= 0;

	iKind= Set.Ch1_iKind;	/* 2008.11.21 */
	
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA*)&EnvKeyTbl1[1]);	/* Input Key */
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_ENVIRONMENT_NUM;
			EndFlag= 1;
			break;
		case KEY_CH1_PROT:
			SetCh1Protocol();
			break;
		case KEY_CH1_CHANEL:
			SetCh1Conect();
			break;
		case KEY_CH1_SPEED:
			SetSpeed1();
			break;
		case KEY_CH1_XON:
			SetFlow1();
			break;
		case KEY_CH1_DATA:
			SetData1();
			break;
		case KEY_CH1_PARTY:
			SetParity1();
			break;
		case KEY_CH1_STOP:
			SetStop1();
			break;
		case KEY_CH2_PROT:
			SetCh2Protocol();
			break;
		case KEY_CH2_CHANEL:
			SetCh2Conect();
			break;
		case KEY_CH2_SPEED:
			SetSpeed2();
			break;
		case KEY_CH2_XON:
			SetFlow2();
			break;
		case KEY_CH2_DATA:
			SetData2();
			break;
		case KEY_CH2_PARTY:
			SetParity2();
			break;
		case KEY_CH2_STOP:
			SetStop2();
			break;
		case KEY_GP_NO:
			iKeyCode= SetGpStation();
			SetStationNoResult(iScreenNo,iKeyCode,&EndFlag,&iTotalCnt);
			break;
		case KEY_PLC_NO:
			iKeyCode= SetPlcStation();
			SetStationNoResult(iScreenNo,iKeyCode,&EndFlag,&iTotalCnt);
			break;
		}
	}
	//Set Data Flash Write
#ifdef	WIN32
	char *temp= (char *)&GpFont[GP_SETTING_AREA];
	if(memcmp((char *)&Set,(char *)&GpFont[GP_SETTING_AREA],sizeof(Set)) != 0){
#else
	if(memcmp((char *)&Set,(char *)GP_SETTING_AREA,sizeof(Set)) != 0){
#endif
		mWriteSettei();
	}
	if((*iScreenNo == UP_TRANS) || (*iScreenNo == DOWN_TRANS)){
	}else{
		PlcConnectFlag= 0;
/*		PlcConnectFlag2= 0;	*/									/* 20081007 */
		memset(&PlcConnectFlag2[0],0,sizeof(PlcConnectFlag2));	/* 20081007 */
		Rs232cBordrateSet();
		PC_CommMode= 0;
		OnSignal(SGN_PLC,1);
	}
	/* PLC Change == Monitor Clear 2008.11.21 */
	if(iKind != Set.Ch1_iKind){	/* 2008.11.21 */

		DeviceMonitorBuffClear(0,BUFF_DISP_CNT);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */

	}
}
/********************************************************************************/
/*	Clock Set																	*/
/********************************************************************************/
void	DateTimeDisp(int iFocusFlag,RTC_DATA *DispTime)
{
	int		pos_date;
	int		pos_time;
	char	chDsp_Data[30];

	ClearTextItemData(IDX_DATE);
	ClearTextItemData(IDX_TIME);
	sprintf(chDsp_Data, "%4d / %02d / %02d (%s)",DispTime->year+START_YEAR ,DispTime->mon ,DispTime->day,WeekName[SystemTime.week]);
	switch(Set.iDataFormat){
	case 0:
		sprintf(chDsp_Data, "%4d / %02d / %02d (%s)",DispTime->year+START_YEAR ,DispTime->mon ,DispTime->day,WeekName[SystemTime.week]);
		break;
	case 1:
		sprintf(chDsp_Data, "%4d / %02d / %02d (%s)",DispTime->year+START_YEAR ,DispTime->day ,DispTime->mon,WeekName[SystemTime.week]);
		break;
	case 2:
		sprintf(chDsp_Data, "%2d / %04d / %02d (%s)",DispTime->day ,DispTime->year+START_YEAR ,DispTime->mon,WeekName[SystemTime.week]);
		break;
	case 3:
		sprintf(chDsp_Data, "%2d / %02d / %04d (%s)",DispTime->day ,DispTime->mon ,DispTime->year+START_YEAR,WeekName[SystemTime.week]);
		break;
	case 4:
		sprintf(chDsp_Data, "%2d / %02d / %04d (%s)",DispTime->mon ,DispTime->day ,DispTime->year+START_YEAR,WeekName[SystemTime.week]);
		break;
	case 5:
		sprintf(chDsp_Data, "%2d / %04d / %02d (%s)",DispTime->mon ,DispTime->year+START_YEAR ,DispTime->day,WeekName[SystemTime.week]);
		break;
	}
	DispTextSetItemData(IDX_DATE,chDsp_Data);
	sprintf(chDsp_Data, "%02d : %02d : %02d",DispTime->hour,DispTime->min,DispTime->sec);				
	DispTextSetItemData(IDX_TIME,chDsp_Data);
	//Reverse Position Settei
	if(iFocusFlag != 0){			/* ���ý� ���� */
		pos_date= 0;
		pos_time= 0;
		switch(iFocusFlag){
		case 1:
			switch(Set.iDataFormat){
			case YYYYMMDD:
			case YYYYDDMM:
				pos_date= 3;
				break;
			default:
				pos_date= 1;
				break;
			}
			break;
		case 2:
			switch(Set.iDataFormat){
			case DDMMYYYY:
			case MMDDYYYY:
				pos_date= 6;
				break;
			default:
				pos_date= 8;
				break;
			}
			break;
		case 3:
			pos_date= 13;
			break;
		case 4:
			pos_time= 1;
			break;
		case 5:
			pos_time= 6;
			break;
		case 6:
			pos_time= 11;
			break;
		}
		//FORCUS SET
		if(pos_date != 0){
			ReversTextItemData(IDX_DATE,pos_date);
		}else{
			ReversTextItemData(IDX_TIME,pos_time);
		}
	}
}
int	ChangeDateTimePos(int iKeyCode)
{
	int		ret;

	ret= 0;
	switch(Set.iDataFormat){
	case YYYYMMDD:
	case YYYYDDMM:
		switch(iKeyCode){
		case KEY_CLK_D01:
		case KEY_CLK_D02:
			ret= 1;
			break;
		case KEY_CLK_D04:
			ret= 2;
			break;
		case KEY_CLK_D06:
			ret= 3;
			break;
		}
		break;
	case DDYYYYMM:
	case MMYYYYDD:
		switch(iKeyCode){
		case KEY_CLK_D01:
			ret= 1;
			break;
		case KEY_CLK_D03:
		case KEY_CLK_D04:
			ret= 2;
			break;
		case KEY_CLK_D06:
			ret= 3;
			break;
		}
		break;
	case DDMMYYYY:
	case MMDDYYYY:
		switch(iKeyCode){
		case KEY_CLK_D01:
			ret= 1;
			break;
		case KEY_CLK_D03:
			ret= 2;
			break;
		case KEY_CLK_D05:
		case KEY_CLK_D06:
			ret= 3;
			break;
		}
		break;
	}
	switch(iKeyCode){
	case KEY_CLK_T02:
		ret= 4;
		break;
	case KEY_CLK_T04:
		ret= 5;
		break;
	case KEY_CLK_T06:
		ret= 6;
		break;
	}
	return(ret);
}
int	ChangeDateTimeKind(int iFocusFlag,int *indata)
{
	int	ret;
	
	ret= iFocusFlag;
	switch(Set.iDataFormat){
	case YYYYMMDD:
		break;
	case YYYYDDMM:
		switch(iFocusFlag){
		case 2:
			ret= 3;
			break;
		case 3:
			ret= 2;
			break;
		}
		break;
	case DDYYYYMM:
		switch(iFocusFlag){
		case 1:
			ret= 3;
			break;
		case 2:
			ret= 1;
			break;
		case 3:
			ret= 2;
			break;
		}
		break;
	case DDMMYYYY:
		switch(iFocusFlag){
		case 1:
			ret= 3;
			break;
		case 3:
			ret= 1;
			break;
		}
		break;
	case MMDDYYYY:
		switch(iFocusFlag){
		case 1:
			ret= 2;
			break;
		case 2:
			ret= 3;
			break;
		case 3:
			ret= 1;
			break;
		}
		break;
	case MMYYYYDD:
		switch(iFocusFlag){
		case 1:
			ret= 2;
			break;
		case 2:
			ret= 1;
			break;
		}
		break;
	}
	//���ݒl�������
	switch(ret){
	case 1:
		*indata= SystemTime.year+START_YEAR;
		break;
	case 2:
		*indata= SystemTime.mon;
		break;
	case 3:
		*indata= SystemTime.day;
		break;
	case 4:
		*indata= SystemTime.hour;
		break;
	case 5:
		*indata= SystemTime.min;
		break;
	case 6:
		*indata= SystemTime.sec;
		break;
	}
	return(ret);
}
void	SetMaxMin(int kind,int *max,int *min,int *maxketa)
{

	switch(kind){
	case 1:			//Year
		*maxketa= 4;
		*max= 2099;
		*min= 2000;
		break;
	case 2:			//Month
		*maxketa= 2;
		*max= 12;
		*min= 1;
		break;
	case 3:			//Day
		*maxketa= 2;
		*min= 1;
		switch(SystemTime.mon){
		case 2:
			*max= iLeapYear(SystemTime.year);
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			*max= 30;
			break;
		default:
			*max= 31;
			break;
		}
		break;
	case 4:			//Hour
		*maxketa= 2;
		*max= 23;
		*min= 0;
		break;
	case 5:			//Min
		*maxketa= 2;
		*max= 59;
		*min= 0;
		break;
	case 6:			//Sec
		*maxketa= 2;
		*max= 59;
		*min= 0;
		break;
	}
}
void	SendInitTaskPar(int mcod,int mcmd,int mpar,int mext)
{
	T_MAIL	*mp;

	mp = (T_MAIL *)TakeMail();
	mp->mcod = mcod;					/* AlarmDetail (0 : Open  1 : Close) */
	mp->mcmd = mcmd;
	mp->mpar = mpar;
	mp->mext = mext;
	SendMail(T_INITASK,(char *)mp);
}
void	SetInputData(RTC_DATA *DispTime,int InputKind,int indata)
{
	switch(InputKind){
	case 1:
		DispTime->year= indata-START_YEAR;
		break;
	case 2:
		DispTime->mon= indata;
		break;
	case 3:
		DispTime->day= indata;
		break;
	case 4:
		DispTime->hour= indata;
		break;
	case 5:
		DispTime->min= indata;
		break;
	case 6:
		DispTime->sec= indata;
		break;
	}
}
void	vClockSet(int *iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		iFocusFlag;
	char	InputBuff[8];
	int		InputCnt;
	int		InputKind;
	int		Max,Min,indata;
	int		mKeta;
	RTC_DATA	DispTime;

	DispTime= SystemTime;
	iFocusFlag= 1;
	InputCnt= 0;
	InputKind= ChangeDateTimeKind(iFocusFlag,&indata);
	SetMaxMin(InputKind,&Max,&Min,&mKeta);
	ClearDispBuff(SCREEN_0);			/* Clear Display Buff */
	DispBaseFiger(G_CLOCK_MENU,&iTotalCnt);		/* Initial Display */
	DispTextData(CLOCK_MENU,iTotalCnt);
//	DateTimeDisp(iFocusFlag,InputKind,&DispTime);
	DrawLcdBank1();

	OnSignal(S_ENV,0x0001);			//State Start
	SendInitTaskPar(INI_ENV_STATE,1,iFocusFlag,0);
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA*)&EnvKeyTbl1[2]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_ENVIRONMENT_NUM;
			EndFlag= 1;
			break;
		case KEY_CLK_CLR:
			if(iFocusFlag != 0){		//Inputing
				iFocusFlag= 0;
				InputCnt= 0;
				DispTime= SystemTime;
				DateTimeDisp(iFocusFlag,&DispTime);
				DrawLcdBank1();
				OnSignal(S_ENV,0x0001);			//State Start
				SendInitTaskPar(INI_ENV_STATE,1,iFocusFlag,InputKind);
			}
			break;
		case KEY_CLK_ENT:
			if(iFocusFlag != 0){		//Inputing
				if((indata >= Min) && (indata <= Max)){
					OffSignal(S_ENV,0x0001);		//2008.09.30
					Delay(200);						//2008.09.30
					DispTime.week= iNowWeek(&DispTime);
					DateTimeSet(&DispTime,0);
					iFocusFlag++;
					if(iFocusFlag > 6){
						iFocusFlag= 1;
					}
					InputCnt= 0;
					InputKind= ChangeDateTimeKind(iFocusFlag,&indata);
					SetMaxMin(InputKind,&Max,&Min,&mKeta);
					DispTime= SystemTime;
					DateTimeDisp(iFocusFlag,&DispTime);
					DrawLcdBank1();
					OnSignal(S_ENV,0x0001);			//State Start
					SendInitTaskPar(INI_ENV_STATE,1,iFocusFlag,InputKind);
				}else{		//Eror
					iCaptionWindow(Dspname[SET_FUNTION].chName[Set.iLang][12],"");
					DateTimeDisp(iFocusFlag,&DispTime);		//2008.09.30
					DrawLcdBank1();							//2008.09.30
				}
			}
			break;
		default:
			if((iKeyCode >= KEY_CLK0) && (iKeyCode <= KEY_CLK9)){
				//Ten-Key Touch
				if(iFocusFlag != 0){
					if(InputCnt < mKeta){
						if(InputCnt == 0){		//Stop Now Time
							DispTime= SystemTime;
							OffSignal(S_ENV,0x0001);			//State Start
							Delay(10);
						}
						InputBuff[InputCnt++]= iKeyCode;
						InputBuff[InputCnt]= 0;
					}else{
						memcpy(&InputBuff[0],&InputBuff[1],sizeof(InputBuff)-1);
						InputBuff[InputCnt-1]= iKeyCode;
						InputBuff[InputCnt]= 0;
					}
					indata= gatoi(InputBuff);
					SetInputData(&DispTime,InputKind,indata);
					DateTimeDisp(iFocusFlag,&DispTime);
					DrawLcdBank1();
				}
			}else{
				//Date Time Touch
				if(InputCnt == 0){
					iFocusFlag= ChangeDateTimePos(iKeyCode);
					if(iFocusFlag != 0){
						InputKind= ChangeDateTimeKind(iFocusFlag,&indata);
						SetMaxMin(InputKind,&Max,&Min,&mKeta);
						DispTime= SystemTime;
						DateTimeDisp(iFocusFlag,&DispTime);
						DrawLcdBank1();
						OffSignal(S_ENV,0x0001);			//State Start
						Delay(200);
						OnSignal(S_ENV,0x0001);			//State Start
						SendInitTaskPar(INI_ENV_STATE,1,iFocusFlag,0);
					}
				}
			}
			break;
		}
	}
	OffSignal(S_ENV,0x0001);			//State Start
	Delay(100);
}
void	WaitingDisp(void)
{
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	SetWinSema();
	if(Set.iLang == 0){
		RectAngleOut(78,171,262,196,&RECParam);
		DotTextOut(80,176,Dspname[CLEAR_DATA].chName[Set.iLang][8],1,1, TRANS, T_BLACK, T_WHITE);
	}else{
		RectAngleOut(58,171,252,196,&RECParam);
		DotTextOut(60,176,Dspname[CLEAR_DATA].chName[Set.iLang][8],1,1, TRANS, T_BLACK, T_WHITE);
	}
	DrawLcdBank1();
	ResetWinSema();

//	while(1){
//		Delay(100);
//	}
}
/********************************************************************************/
/*	Clear Data																	*/
/********************************************************************************/
extern	void	SendPlcWaitFlag(void);
void		vClearData(int* iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		i;

	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_CLEAR_DATA,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(CLEAR_DATA,iTotalCnt);
	DrawLcdBank1();
	EndFlag= 0;

	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_CLEAR_DATA-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_ENVIRONMENT_NUM;
			EndFlag= 1;
			break;
		case KEY_YES:	//Data Clear
			WaitingDisp();
			for(i = 0; i<TBQ(Screen) ; i++)
			{
				Screen[i].iNum = 0x00;
				Screen[i].chTitle=0x00;
			}
			iDispOrder= 0;			//2008.04.21
/*-------------------------------------------------------------------------------------*/			
/* PLC Protocoa area clear */ /* 050623 */			
			OffSignal(SGN_PLC, 0xFFFFFFFF);
//			PlcSignalInf= OFF;			//0:Stop,1:Start
//			Delay(200);
//--------------------------------------------------------------------------------------
//	Plotocol Stop Check 2008.08.20
				SendPlcWaitFlag();				/* 080820 */
				for(i= 0; i < 50; i++){				//5s Timeout
					if((PlchandTask == 0) && (PlcstateTask == 0) && (ConnectTask == 0) &&
						(WaitDisplayTask == 0)){
						break;
					}
					Delay(100);
				}
//--------------------------------------------------------------------------------------
			mformat();												/* ��� ���� �����͸� ����� ó�� */
//			mformat2();												/* ��� ���� �����͸� ����� ó�� */
			RamFlashEraze((short *)PLC1_DEV_TABLE);
			memset(&CommonArea,0,sizeof(CommonArea));				
			memset(Set._TIMESWITCH,0,sizeof(Set._TIMESWITCH));
			memset(Set.TimeSwitch_DevName,0,sizeof(Set.TimeSwitch_DevName));
			Set.TimeSwitch_DevAdd= 0;			
			Set.Ch1_iKind= UNIVERSAL;		/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */
			Set.Ch2_iKind= EDITER;	/* 0:Universal,1:Defualt,2:ELS-PLC,3:EDITOR,4:PRINTER,5:BARCODE,6:MONITOR */

			strncpy(CommonArea.System,dVersion,6);		/* 20090703 */

			DeviceMonitorBuffClear(0,BUFF_DISP_CNT);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */

/*			initSet();	*/
			/* 2008.09.26 Plc Prc Clear�̂��ߐݒ�l���N���A���� */
			memset(Set.cPlcTypeCode,0,sizeof(Set.cPlcTypeCode));
			/****************************************************/
			mWriteSettei();
/*-------------------------------------------------------------------------------------*/			
			
			iBaseScreenCnt = 0;
			iWinScreenCnt = 0;
			iComCnt = 0;
			pcFileCnt = 0;
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
//			PlcSignalInf= ON;			//0:Stop,1:Start
			break;
		case KEY_NO:
			*iScreenNo = SET_ENVIRONMENT_NUM;
			EndFlag= 1;
			break;
		}
	}
}
void	DrawCallRect(int idx)
{
	int		iBackColor;
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	iBackColor= 0;
	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	MakeTagCode_03(ScreenTagData[idx].TagPos,iBackColor,FigureEventTbl);
	FigureEventTbl->ST.RectInfo.RectType.iPattern= P_NONE;
	RectAngleOut(ScreenTagData[idx].sX, 
				 ScreenTagData[idx].sY, 
				 ScreenTagData[idx].eX, 
				 ScreenTagData[idx].eY, 
				 &(FigureEventTbl->ST.RectInfo.RectType));
	FreeMail((char *)FigureEventTbl);
}
void	MainCallSetDisp(int SetData)
{
	ClearTextItemData(IDX_LEFT_RIGHT);
	FigureDisplay(IDX_LEFT_RIGHT,0);
	DrawCallRect(IDX_LEFT_TOP_R);
	DrawCallRect(IDX_RGHT_TOP_R);
	DrawCallRect(IDX_LEFT_BOT_R);
	DrawCallRect(IDX_RGHT_BOT_R);
	if(SetData & 0x01){		//LEFT_TOP
		FigureDisplay(IDX_LEFT_TOP_R,0);
		FigureDisplay(IDX_LEFT_TOP_C,0);
	}
	if(SetData & 0x04){		//RIGHT_TOP
		FigureDisplay(IDX_RGHT_TOP_R,0);
		FigureDisplay(IDX_RGHT_TOP_C,0);
	}
	if(SetData & 0x02){		//LEFT_BOT
		FigureDisplay(IDX_LEFT_BOT_R,0);
		FigureDisplay(IDX_LEFT_BOT_C,0);
	}
	if(SetData & 0x08){		//RIGHT_BOT
		FigureDisplay(IDX_RGHT_BOT_R,0);
		FigureDisplay(IDX_RGHT_BOT_C,0);
	}
}
/********************************************************************************/
/*	MainCall																	*/
/********************************************************************************/
void		vMainCallSet(int* iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		iCallKeyCnt;					/* �������� ī��Ʈ �ִ�2������ ����	 */
	int		OldiCallKey;

	OldiCallKey= Set.iCallKey;
	iCallKeyCnt= 0;
	if ( Set.iCallKey & 0x01 )
		iCallKeyCnt++;

	if ( Set.iCallKey & 0x04 ) 
		iCallKeyCnt++;

	if ( Set.iCallKey & 0x02 )
		iCallKeyCnt++;

	if ( Set.iCallKey & 0x08 )
		iCallKeyCnt++;

	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_MENU_CALL_KEY,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(MENU_CALL_KEY,iTotalCnt);
	MainCallSetDisp(Set.iCallKey);
	DrawLcdBank1();
	EndFlag= 0;


	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_MENU_CALL_KEY-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_ENVIRONMENT_NUM;
			EndFlag= 1;
			break;
		default:
			switch(iKeyCode){
			case KEY_LEFT_TOP:
				if(Set.iCallKey & 0x01){
					if(iCallKeyCnt != 1){
						iCallKeyCnt--;	
						Set.iCallKey = Set.iCallKey ^ 0x01 ;
					}
				}else if(iCallKeyCnt < 2){
					iCallKeyCnt++;
					Set.iCallKey = Set.iCallKey ^ 0x01 ;
				}
				break;
			case KEY_RIGHT_TOP:
				if(Set.iCallKey & 0x04){
					if(iCallKeyCnt != 1){
						iCallKeyCnt--;	
						Set.iCallKey = Set.iCallKey ^ 0x04 ;
					}
				}else if(iCallKeyCnt < 2){
					iCallKeyCnt++;
					Set.iCallKey = Set.iCallKey ^ 0x04 ;
				}
				break;
			case KEY_LET_BOT:
				if(Set.iCallKey & 0x02){
					if(iCallKeyCnt != 1){
						iCallKeyCnt--;	
						Set.iCallKey = Set.iCallKey ^ 0x02 ;
					}
				}else if(iCallKeyCnt < 2){
					iCallKeyCnt++;
					Set.iCallKey = Set.iCallKey ^ 0x02 ;
				}
				break;
			case KEY_RIGHT_BOT:
				if(Set.iCallKey & 0x08){
					if(iCallKeyCnt != 1){
						iCallKeyCnt--;	
						Set.iCallKey = Set.iCallKey ^ 0x08 ;
					}
				}else if(iCallKeyCnt < 2){
					iCallKeyCnt++;
					Set.iCallKey = Set.iCallKey ^ 0x08 ;
				}
				break;
			}
			MainCallSetDisp(Set.iCallKey);
			DrawLcdBank1();
			break;
		}
	}
	if(OldiCallKey != Set.iCallKey){
		mWriteSettei();
	}
}
/********************************************************************************/
/*	BUZZER ON/OFF																*/
/********************************************************************************/
void		vBuzzerSet(int* iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		OldBuzzer;

	OldBuzzer= Set.iBuzzer;
	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_BUZZER,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(BUZZER,iTotalCnt);
	DrawLcdBank1();
	EndFlag= 0;

	if(Set.iBuzzer == OFF){			//�����l��ON��Ԃ̂���
		EngForReverse(8);					//
		EngForReverse(9);					//�x?�X��ʂ���?���Ă��邽��
		DrawLcdBank1();
	}
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_BUZZER-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_ENVIRONMENT_NUM;
			EndFlag= 1;
			break;
		case KEY_BUZ_ON:
			if(Set.iBuzzer == OFF){
				Set.iBuzzer = ON;
				EngForReverse(8);					//
				EngForReverse(9);					//�x?�X��ʂ���?���Ă��邽��
				DrawLcdBank1();
			}
			break;
		case KEY_BUZ_OFF:
			if(Set.iBuzzer == ON){
				Set.iBuzzer = OFF;
				EngForReverse(8);					//
				EngForReverse(9);					//�x?�X��ʂ���?���Ă��邽��
				DrawLcdBank1();
			}
			break;
		}
	}
	//Set Data Flash Write
	if(OldBuzzer != Set.iBuzzer)
	{
		mWriteSettei();
	}
}
void	DispOpenTime(int optime,int iFocusFlag)
{
	int		pos;
	char	work[40];
	char	LineDataBuffer[40];

	sprintf(LineDataBuffer,"%s : ",Dspname[OPENNING].chName[Set.iLang][0]);
	pos= strlen(LineDataBuffer);
	sprintf(work,"%2d",optime);			//20081002(%d->%2d)
	pos += strlen(work);
	pos--;
	strcat(LineDataBuffer,work);
	sprintf(work," %s",Dspname[OPENNING].chName[Set.iLang][1]);
	strcat(LineDataBuffer,work);
	DispTextSetItemData(IDX_SET_OPEN,LineDataBuffer);
	if(iFocusFlag != 0){
		ReversTextItemData(IDX_SET_OPEN,pos);
	}
}
void	DispBackLightTime(int optime,int iFocusFlag)
{
	int		pos;
	char	work[40];
	char	LineDataBuffer[40];

	sprintf(LineDataBuffer,"%s : ",Dspname[BACKLIGHT].chName[Set.iLang][0]);
	pos= strlen(LineDataBuffer);
	sprintf(work,"%2d",optime);			//20081002(%d->%2d)
	pos += strlen(work);
	pos--;
	strcat(LineDataBuffer,work);
	sprintf(work," %s",Dspname[BACKLIGHT].chName[Set.iLang][1]);
	strcat(LineDataBuffer,work);
	DispTextSetItemData(IDX_SET_OPEN,LineDataBuffer);
	if(iFocusFlag != 0){
		ReversTextItemData(IDX_SET_OPEN,pos);
	}
}
void	DispValueTime(int type,int optime,int iFocusFlag)
{
	ClearTextItemData(IDX_SET_OPEN);
	if(type == 0){
		DispOpenTime(optime,iFocusFlag);
	}else{
		DispBackLightTime(optime,iFocusFlag);
	}
}
void	DispSetTimeTitle(int type)
{
	ClearTextItemData(IDX_SET_TITLE);
	if(type == 0){
		DispTextSetItemCenter(IDX_SET_TITLE,LDspname[L_OPENNING].chTitle[Set.iLang]);
	}else{
		DispTextSetItemCenter(IDX_SET_TITLE,Dspname[BACKLIGHT].chTitle[Set.iLang]);
	}
}
/********************************************************************************/
/*	Openning Set																*/
/********************************************************************************/
int	SetTimeProc(int type,int *iScreenNo,int OldTime)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		iFocusFlag;
	char	InputBuff[8];
	int		InputCnt;
	int		Max,Min,indata;
	int		mKeta;
	int		NowTime;

	NowTime= OldTime;
	iFocusFlag= 1;
	InputCnt= 0;
	Min= 0;
	Max= 60;
	mKeta= 2;
	ClearDispBuff(SCREEN_0);			/* Clear Display Buff */
	DispBaseFiger(G_OPENNING,&iTotalCnt);		/* Initial Display */
	DispTextData(OPENNING,iTotalCnt);
	DispSetTimeTitle(type);
	DispValueTime(type,NowTime,iFocusFlag);
	DrawLcdBank1();
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA*)&EnvKeyTbl1[3]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_ENVIRONMENT_NUM;
			EndFlag= 1;
			break;
		case KEY_CLK_CLR:
			if(iFocusFlag != 0){		//Inputing
				iFocusFlag= 0;
				InputCnt= 0;
				DispValueTime(type,NowTime,iFocusFlag);
				DrawLcdBank1();
			}
			break;
		case KEY_CLK_ENT:
			if((iFocusFlag != 0) && (InputCnt != 0)){		//Inputing
				if((indata >= Min) && (indata <= Max)){
					NowTime= indata;
					InputCnt= 0;
					iFocusFlag= 0;
					DispValueTime(type,NowTime,iFocusFlag);
					DrawLcdBank1();
				}else{		//Eror
					iCaptionWindow(Dspname[SET_FUNTION].chName[Set.iLang][12],"");
				}
			}
			break;
		default:
			if((iKeyCode >= KEY_CLK0) && (iKeyCode <= KEY_CLK9)){
				//Ten-Key Touch
				if(iFocusFlag != 0){
					if(InputCnt < mKeta){
						InputBuff[InputCnt++]= iKeyCode;
						InputBuff[InputCnt]= 0;
					}else{
						memcpy(&InputBuff[0],&InputBuff[1],sizeof(InputBuff)-1);
						InputBuff[InputCnt-1]= iKeyCode;
						InputBuff[InputCnt]= 0;
					}
					indata= gatoi(InputBuff);
					DispValueTime(type,indata,iFocusFlag);
					DrawLcdBank1();
				}
			}else{
				if(InputCnt == 0){
					iFocusFlag= 1;
					indata= NowTime;
					DispValueTime(type,indata,iFocusFlag);
					DrawLcdBank1();
				}
			}
			break;
		}
	}
	return(NowTime);
}
void	vScreenSet(int *iScreenNo)
{
	int	SetTime;

	SetTime= SetTimeProc(0,iScreenNo,Set.iTitleDispTime);
	if(SetTime != Set.iTitleDispTime){
		Set.iTitleDispTime= SetTime;
		mWriteSettei();
	}
}
/********************************************************************************/
/*	BackLight Set																*/
/********************************************************************************/
void	vBackLightSet(int *iScreenNo)
{
	int	SetTime;

	SetTime= SetTimeProc(1,iScreenNo,Set.iBackLightTime);
	if(SetTime != Set.iBackLightTime){
		Set.iBackLightTime= SetTime;
		mWriteSettei();
	}
}
void	DrawPacentRect(int idx,float rate)
{
	int		iBackColor;
	int		eX;
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	if(rate == 0.0){
		return;
	}
	iBackColor= 0;
	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	MakeTagCode_03(ScreenTagData[idx].TagPos,iBackColor,FigureEventTbl);
	eX= ScreenTagData[idx].sX+ (int)((float)(ScreenTagData[idx].eX-ScreenTagData[idx].sX) * rate + 0.5);
	RectAngleOut(ScreenTagData[idx].sX, 
				 ScreenTagData[idx].sY, 
				 eX, 
				 ScreenTagData[idx].eY, 
				 &(FigureEventTbl->ST.RectInfo.RectType));
	FreeMail((char *)FigureEventTbl);
}
void	DispBatterySet(void)
{
	float	rate;
	int		iLen;
	char	LineDataBuffer[40];

	ClearTextItemData(IDX_SET_BATT);
	ClearTextItemData(IDX_BAT_NOW_BAR);
	memset(LineDataBuffer,0x00,sizeof(LineDataBuffer));
	if(CommonArea.BatteryLevel>=BATT_MAX_REVEL)	
	{
		iLen=100;
		sprintf(LineDataBuffer,"%s %d %%",
			Dspname[BATTERY].chName[Set.iLang][5],iLen);
	}
	else if((BATT_MIN_REVEL < CommonArea.BatteryLevel) && (CommonArea.BatteryLevel< BATT_MAX_REVEL))
	{
		iLen = (int)(((CommonArea.BatteryLevel-BATT_MIN_REVEL)*100)/(BATT_MAX_REVEL- BATT_MIN_REVEL));
		sprintf(LineDataBuffer,"%s %d %%",
			Dspname[BATTERY].chName[Set.iLang][5],iLen);
	}
	else
	{
		iLen= 0;
		sprintf(LineDataBuffer,"%s Bat Low",
			Dspname[BATTERY].chName[Set.iLang][5]);
	}
	DispTextSetItemData(IDX_SET_BATT,LineDataBuffer);
	rate = (float)iLen/(float)100.0;
	DrawPacentRect(IDX_BAT_NOW_BAR,rate);
}
/********************************************************************************/
/*	Battery																		*/
/********************************************************************************/
void	vButDispMode(int *iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;

	ClearDispBuff(SCREEN_0);			/* Clear Display Buff */
	DispBaseFiger(G_BATTERY,&iTotalCnt);		/* Initial Display */
	DispTextData(BATTERY,iTotalCnt);
	DispBatterySet();
	DrawLcdBank1();
	OnSignal(S_ENV,0x0001);			//State Start
	SendInitTaskPar(INI_ENV_STATE,2,0,0);
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_BATTERY-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_ENVIRONMENT_NUM;
			EndFlag= 1;
			break;
		}
	}
	OffSignal(S_ENV,0x0001);			//State Start
	Delay(100);
}
void	DispContrast(int cnt)
{
	float	rate;
	char	LineDataBuffer[40];

	ClearTextItemData(IDX_NOW_BAR);
	ClearTextItemData(IDX_BAR_TEXT);
	if(cnt > max_contrast){
		cnt= max_contrast;
	}
	rate= (float)cnt/(float)max_contrast;
	DrawPacentRect(IDX_NOW_BAR,rate);
	sprintf(LineDataBuffer,"%s : %d / %d",Dspname[LCDCONTRAST].chName[Set.iLang][3],cnt,max_contrast);
	DispTextSetItemData(IDX_BAR_TEXT,LineDataBuffer);
}
/********************************************************************************/
/*	Contrast																		*/
/********************************************************************************/

void	vLcdContSetDisp(int *iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		NowCnt;
	int		convertData;

	KerRepeatFlag= 1;
	RepeatInfo.EntryCnt = 2;
	RepeatInfo.RepeatNo[0][0] = (char)175;
	RepeatInfo.RepeatNo[0][1] = (char)176;
	RepeatInfo.RepeatNo[1][0] = (char)161;
	RepeatInfo.RepeatNo[1][1] = (char)162;

	NowCnt= Set.iLcdvalue;
	convertData = Set.iLcdvalue - contrast_offset ;
	if(convertData < 0){
		convertData= 0;
	}
	ClearDispBuff(SCREEN_0);			/* Clear Display Buff */
	DispBaseFiger(G_LCDCONTRAST,&iTotalCnt);		/* Initial Display */
	DispTextData(LCDCONTRAST,iTotalCnt);
	DispContrast(convertData);
	DrawLcdBank1();
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_LCDCONTRAST-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_ENVIRONMENT_NUM;
			EndFlag= 1;
			break;
		case KEY_LEFT:
			if(convertData > 0){
				convertData--;
				DispContrast(convertData);
				DrawLcdBank1();
				SetContrast(convertData+contrast_offset);			/* �֤����� display */
			}
			break;
		case KEY_RIGHT:
			if(convertData < max_contrast){
				convertData++;
				DispContrast(convertData);
				DrawLcdBank1();
				SetContrast(convertData+contrast_offset);			/* �֤����� display */
			}
			break;
		}
	}
	NowCnt= convertData+ contrast_offset;
	if(NowCnt != Set.iLcdvalue){
		Set.iLcdvalue= NowCnt;
		mWriteSettei();
	}
	KerRepeatFlag= 0;
	RepeatInfo.EntryCnt = 0;
	memset(&RepeatInfo,0x00,sizeof(RepeatInfo));
}
/* ****************************************************************************** */
/*  �� �� �� : DataViewMenu()													 */
/*  ��    �� : Data�� �ǽð����� �����ִ� �޴���.								 */
/*  ��    �� : iScreenNo(���� ȭ�� ��ȣ)										 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 6�� 27�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void	DataViewMenu(int *iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;

	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_DATA_VIEW,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(DATA_VIEW,iTotalCnt);
	DrawLcdBank1();
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_DATA_VIEW-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SELECT_MEMU_NUM;
			EndFlag= 1;
			break;
		case KEY_BASE_SCREEN:
			*iScreenNo = BASE_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_WINDOW_SCREEN:
			*iScreenNo = WINDOW_SCREEN_NUM;										
			EndFlag= 1;
			break;
		case KEY_COMMENT_SCREEN:
			*iScreenNo = COMMENT_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MEMORY_SIZE:
			*iScreenNo = MEMORY_SIZE_NUM;
			EndFlag= 1;
			break;
		case KEY_VER_NUM:
			*iScreenNo = MODEL_VER_NUM;
			EndFlag= 1;
			break;
		} 			
	} 
	return;
}
/* ****************************************************************************** */
/*  �� �� �� : BaseScreenList()													 */
/*  ��    �� : BaseScreen Listǥ��												 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 7�� 2�� (��)												 */
/*  �� �� �� : �� �� �� 														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
const	int	ScreenGamenID[10]={
	0x08,0x14,0x16,0x18,0x1a,0x1c,0x21,0x22,0x23,0x24
};
void	ClearScreenGamen(void)
{
	int		i;

	for(i= 0; i < 10; i++){
		ClearTextItemData(ScreenGamenID[i]);	//32Char
	}
}
void	DispBaseScreenGamen(int stidx)
{
	int		i;
	char	dspbuff[34];
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	for(i= 0; (i < 10) && (stidx < iBaseScreenCnt); i++,stidx++){
		if(Screen[stidx].chTitle != NULL){
			sprintf(dspbuff,"%3d %s",Screen[stidx].iNum,Screen[stidx].chTitle);
		}else{
			sprintf(dspbuff,"%3d",Screen[stidx].iNum);
		}
		DispTextItemData(ScreenGamenID[i],FigureEventTbl,dspbuff);	//32Char
	}
	FreeMail((char *)FigureEventTbl);
}
void		BaseScreenList(int* iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		stidx;
	int		iScreenNum;

	iUserScreenFlag = 0;			//2009.07.20 add
	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_BASE_SCREEN,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(BASE_SCREEN,iTotalCnt);
	stidx= 0;
	DispBaseScreenGamen(stidx);
	DrawLcdBank1();
	EndFlag= 0;
	iScreenNum		= 0;			//2009.07.20 add
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl1[6]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = DATA_VIEW_NUM;
			EndFlag= 1;
			break;
		case KEY_UP:
			if(stidx > 0){
				stidx -= 10;
				ClearScreenGamen();
				DispBaseScreenGamen(stidx);
				DrawLcdBank1();
			}
			break;
		case KEY_DOWN:
			if(stidx+ 10 < iBaseScreenCnt){
				stidx += 10;
				ClearScreenGamen();
				DispBaseScreenGamen(stidx);
				DrawLcdBank1();
			}
			break;
		default:
			if((stidx+(iKeyCode-KEY_LINE1)) < iBaseScreenCnt){
				iScreenNum= stidx+(iKeyCode-KEY_LINE1);
				iScreenNum= Screen[iScreenNum].iNum;		//2009.07.20 add
//				iScreenDisp = Screen[iScreenNum].iNum;		//2009.07.20 del
//				*iScreenNo = USER_SCREEN_NUM;				//2009.07.20 del
//				iUserScreenFlag = 1;						//2009.07.20 del
				EndFlag= 1;
			}
			break;
		}
	}
	iScreenDisp = 0;
	if(iScreenNum > 0)
	{
		iScreenDisp = iScreenNum;
		*iScreenNo = USER_SCREEN_NUM;
		iUserScreenFlag = 1;
	}
}
void	DispWinScreenGamen(int stidx)
{
	int		i;
	char	dspbuff[34];
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	for(i= 0; (i < 10) && (stidx < iWinScreenCnt); i++,stidx++){
		if(Screen[stidx].chTitle != NULL){
			sprintf(dspbuff,"%3d %s",WinScreen[stidx].iNum,WinScreen[stidx].chTitle);
		}else{
			sprintf(dspbuff,"%3d",WinScreen[stidx].iNum);
		}
		DispTextItemData(ScreenGamenID[i],FigureEventTbl,dspbuff);	//32Char
	}
	FreeMail((char *)FigureEventTbl);
}
void		WindowScreenList(int* iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		stidx;
	int		iScreenNum;

	iUserScreenFlag = 0;
	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_BASE_SCREEN,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(WINDOW_SCREEN,iTotalCnt);
	stidx= 0;
	ClearScreenGamen();
	DispWinScreenGamen(stidx);
	DrawLcdBank1();
	EndFlag= 0;
	iScreenNum		= 0;		//2009.07.20
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl1[6]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = DATA_VIEW_NUM;
			EndFlag= 1;
			break;
		case KEY_UP:
			if(stidx > 0){
				stidx -= 10;
				ClearScreenGamen();
				DispWinScreenGamen(stidx);
				DrawLcdBank1();
			}
			break;
		case KEY_DOWN:
			if(stidx+ 10 < iWinScreenCnt){
				stidx += 10;
				ClearScreenGamen();
				DispWinScreenGamen(stidx);
				DrawLcdBank1();
			}
			break;
		default:
			if((stidx+(iKeyCode-KEY_LINE1)) < iWinScreenCnt){
				iScreenNum= stidx+(iKeyCode-KEY_LINE1);
				iScreenNum= WinScreen[iScreenNum].iNum;			//2009.07.20 add
//				iScreenDisp = WinScreen[iScreenNum].iNum;		//2009.07.20 del
//				*iScreenNo = USER_SCREEN_NUM;					//2009.07.20 del
//				iUserScreenFlag = 1;							//2009.07.20 del
				EndFlag= 1;
			}
			break;
		}
	}
	//2009.07.20
	iScreenDisp = 0;
	if(iScreenNum > 0 && iWinScreenCnt > 0)
	{
		iScreenDisp = iScreenNum;
		*iScreenNo = USER_SCREEN_NUM;
		iUserScreenFlag = 2;
	}
}
const	int	CommentGamenID[10]={
	0x07,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,0x1a
};
void	ClearCommentGamen(void)
{
	int		i;

	for(i= 0; i < 10; i++){
		ClearTextItemData(CommentGamenID[i]);
	}
}
void	DispCommentGamen(int stidx)
{
	int		i,idx;
	unsigned char	*AllTagBuffer;
	int		iOffset;
	int		len;
	char	dspbuff[40];
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	iComCnt= 0;
	if(mfileserch("COMMENT.GP",&i,&idx) != OK){
		return;
	}
	AllTagBuffer = (unsigned char *)i;
	iComCnt  = (int)(AllTagBuffer[6] << 0x08);
	iComCnt += (int)AllTagBuffer[7] & 0xff;
	iOffset = 8;
	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	idx= 0;
	for(i=0 ; i < iComCnt ; i++){
		int	no;
		no = (unsigned int)(AllTagBuffer[iOffset] << 0x08);
		iOffset++;	/* comment No 2byte */
		no += (unsigned int)(AllTagBuffer[iOffset] & 0xff);
		iOffset++;
		len = (unsigned int)(AllTagBuffer[iOffset] << 0x08);
		iOffset ++;
		len += (unsigned int)(AllTagBuffer[iOffset] & 0xff);
		iOffset ++;
		iOffset ++;			
		if(i >= stidx){
			sprintf(dspbuff,"%3d:",no);
			if(len > 28){
				memcpy(&dspbuff[4], AllTagBuffer+iOffset, 28);
				dspbuff[32]= 0;
			}else{
				memcpy(&dspbuff[4], AllTagBuffer+iOffset, len);
				dspbuff[len+4]= 0;
			}
			DispTextItemData(CommentGamenID[idx++],FigureEventTbl,dspbuff);	//32Char
			if(idx >= 10){
				break;
			}
		}
		iOffset+=len;
	}
	FreeMail((char *)FigureEventTbl);
}
void	vCommentMenu(int* iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		stidx;

	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_COMMENT_SCREEN,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(LG_COMMENT_SCREEN,iTotalCnt);
	stidx= 0;
	DispCommentGamen(stidx);
	DrawLcdBank1();
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl1[6]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = DATA_VIEW_NUM;
			EndFlag= 1;
			break;
		case KEY_UP:
			if(stidx > 0){
				stidx -= 10;
				ClearCommentGamen();
				DispCommentGamen(stidx);
				DrawLcdBank1();
			}
			break;
		case KEY_DOWN:
			if(stidx+ 10 < iComCnt){
				stidx += 10;
				ClearCommentGamen();
				DispCommentGamen(stidx);
				DrawLcdBank1();
			}
			break;
		default:
			break;
		}
	}
}
const	int	MemoryGamenID[3]={
	0x07,0x08,0x09
};
void	DispMemoryGamen(void)
{
	int			iTotalMemoryData;
	int			iUserMemoryData;
	int			iAvailableMemoryData;
	char		cDispMemory[40];
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	iTotalMemoryData = 512;
	iUserMemoryData = (int)((CheckUserArea())/2);
	iAvailableMemoryData = iTotalMemoryData - iUserMemoryData;
	//Total Memory
	sprintf(cDispMemory,"%s %3dKbyte",Dspname[MEMORY_SIZE].chName[Set.iLang][3],iTotalMemoryData);
	DispTextItemData(MemoryGamenID[0],FigureEventTbl,cDispMemory);	//32Char
	//User Area
	sprintf(cDispMemory,"%s %3dKbyte",Dspname[MEMORY_SIZE].chName[Set.iLang][4],iUserMemoryData);
	DispTextItemData(MemoryGamenID[1],FigureEventTbl,cDispMemory);	//32Char
	//Avalable Area
	sprintf(cDispMemory,"%s %3dKbyte",Dspname[MEMORY_SIZE].chName[Set.iLang][5],iAvailableMemoryData);
	DispTextItemData(MemoryGamenID[2],FigureEventTbl,cDispMemory);	//32Char
	FreeMail((char *)FigureEventTbl);
}
void	MemorySizeDisp(int* iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;

	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_MEMORY_SIZE,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(MEMORY_SIZE,iTotalCnt);
	DispMemoryGamen();
	DrawLcdBank1();
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl1[6]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = DATA_VIEW_NUM;
			EndFlag= 1;
			break;
		}
	}
}
const	int	ModelGamenID[3]={
	0x07,0x08,0x0a
};
void	DispVersionGamen(void)
{
	char		cDispMemory[40];
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	sprintf(cDispMemory,"%s %s",Dspname[MODEL_VER].chName[Set.iLang][3],GP_MODEL);
	DispTextItemData(ModelGamenID[0],FigureEventTbl,cDispMemory);	//32Char

	sprintf(cDispMemory,"%s %s(%s)",Dspname[MODEL_VER].chName[Set.iLang][4],GP_SYSVER,dVersion);
	DispTextItemData(ModelGamenID[1],FigureEventTbl,cDispMemory);	//32Char

	sprintf(cDispMemory,"%s",GP_RELEASE);
	DispTextItemData(ModelGamenID[2],FigureEventTbl,cDispMemory);	//32Char

	FreeMail((char *)FigureEventTbl);
}
void	ModelVerDisp(int* iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;

	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_GP_MODEL,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(MODEL_VER,iTotalCnt);
	DispVersionGamen();
	DrawLcdBank1();
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl1[6]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = DATA_VIEW_NUM;
			EndFlag= 1;
			break;
		}
	}
}
void	SetFuntionMode(int *iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;

	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_SET_FUNTION,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(SET_FUNTION,iTotalCnt);
	DrawLcdBank1();
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_DATA_VIEW-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SELECT_MEMU_NUM;
			EndFlag= 1;
			break;
		case KEY_BASE_SCREEN:
			*iScreenNo = DATA_TRANSFER_NUM;
			EndFlag= 1;
			break;
		case KEY_WINDOW_SCREEN:
			*iScreenNo = TIME_SWITCH_NUM;										
			EndFlag= 1;
			break;
		case KEY_COMMENT_SCREEN:
			*iScreenNo = PRINT_OUT_NUM;
			EndFlag= 1;
			break;
		} 			
	} 
	return;
}
#define	REVERS_TEXT_ID	20
#define	REVERS_RECT_ID	19
#define	REVERS_RECT_ID_GP	8
#define	REVERS_RECT_ID_PC	10
void	vDataTrans(int* iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		iDisplayNo;
	int					pUpDownMode;				/* 2009.05.26 */
	
	pUpDownMode= CommonArea.PcUpDownMode;		/* 2009.05.26 */


	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_DATA_TRANSFER,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(DATA_TRANSFER,iTotalCnt);
	//��ʎ�ʂ����߂�
	switch(*iScreenNo){
	case DOWN_TRANS:				/* DOWNLOADING...*/
		iDisplayNo = 7;
		ClearTextItemData2(REVERS_RECT_ID);
		ReversItemData(REVERS_RECT_ID);
		DispTextSetItemCenter(REVERS_TEXT_ID,Dspname[DATA_TRANSFER].chName[Set.iLang][iDisplayNo]);
		ReversItemData(REVERS_RECT_ID_GP);
		break;
	case UP_TRANS:
		iDisplayNo = 8;
		ClearTextItemData2(REVERS_RECT_ID);
		ReversItemData(REVERS_RECT_ID);
		DispTextSetItemCenter(REVERS_TEXT_ID,Dspname[DATA_TRANSFER].chName[Set.iLang][iDisplayNo]);
		ReversItemData(REVERS_RECT_ID_PC);
	default:
		iDisplayNo = 0;
//		ReversItemData(REVERS_RECT_ID_PC);
		break;
	}
	DrawLcdBank1();
	if((*iScreenNo == DOWN_TRANS) || (*iScreenNo == UP_TRANS)){
//			Delay(200);
		NormalBuzzer();				/*	Buzzer  */
		iTransFlag		= 0;
		iUserScreenFlag = 0;
		if(*iScreenNo == DOWN_TRANS)
			iFirstScreen = 1;
	}else{
		iTransFlag = 1;
	}
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_DATA_VIEW-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_FUNTION_NUM;
			EndFlag= 1;
			break;
		case PC_UPDOWN_END:
			*iScreenNo = CONFIG_NEXT;
			EndFlag= 1;
			break;
		case PC_CONT:			//Blinkking
			if(*iScreenNo == DOWN_TRANS){
				ReversItemData(REVERS_RECT_ID_GP);
			}else if(*iScreenNo == UP_TRANS){
				ReversItemData(REVERS_RECT_ID_PC);
			}
			DrawLcdBank1();
			break;
		}
	}


//	if(Key.iCode == PC_DNLOAD_START){		/* ksc20090518 */
	if(pUpDownMode == 1){					/* 2009.05.26 */
		Key.iCode = PC_DNLOAD_END;
	}else{
//	if(Key.iCode == PC_UPLOAD_START){
		Key.iCode = PC_UPLOAD_END;
	}


}
const	int	TimeSwitchGamenID[8][4]={
	{15,16,17,18},
	{20,21,22,24},
	{25,27,28,30},
	{31,32,34,35},
	{37,38,39,41},
	{42,43,44,45},
	{46,47,48,49},
	{50,51,52,53},
};
//const	int	TimeSwitchTitleGamenID[4]={
//	7,8,9,10
//};
//void	DispItemTitle(void)
//{
//	ClearTextItemData(TimeSwitchTitleGamenID[0]);
//	DispTextSetItemCenter(TimeSwitchTitleGamenID[0],LDspname[4].chName[Set.iLang][3]);
//	ClearTextItemData(TimeSwitchTitleGamenID[1]);
//	DispTextSetItemCenter(TimeSwitchTitleGamenID[1],LDspname[4].chName[Set.iLang][4]);
//	ClearTextItemData(TimeSwitchTitleGamenID[2]);
//	DispTextSetItemCenter(TimeSwitchTitleGamenID[2],LDspname[4].chName[Set.iLang][5]);
//	ClearTextItemData(TimeSwitchTitleGamenID[3]);
//	DispTextSetItemCenter(TimeSwitchTitleGamenID[3],LDspname[4].chName[Set.iLang][6]);
//}
void	GetTimeSwTime(int SwitchNo)
{
	char	chDsp_buff[16];
	int		i;

	for(i=0;i<3;i++){
		VDateCall(chDsp_buff, i, SwitchNo,0);
		if(strlen(chDsp_buff)==0)
		{
			VDateCall("??", i, SwitchNo,2);
		}
		VDateCall(chDsp_buff, i, SwitchNo,1);
		if(strlen(chDsp_buff)==0)
		{
			VDateCall("??", i, SwitchNo,3);
		}
	}
}
const	int	WeekAndData[8]={
	0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80
};
void	GetTimeSWWeek(int SwitchNo,char *buff)
{
	int	i;

	buff[0]= 0;
	for(i= 0; i < 7; i++){
		if(Set._TIMESWITCH[SwitchNo].iWeek & WeekAndData[i]){
			strcat(buff,Dspname[31].chName[Set.iLang][i]);
		}
	}
}
void	DispTimeSwItem(void)
{
//	int		DevInfo,ret,TimeDevFlag;
	int		DevInfo,TimeDevFlag;
	int		ivalue;
	int		UsAddr;		/* 071102 */
	char	chDsp_buff[16];
	char	chChName[6];
//	char	chChName1[6];
	_FIGURE_EVENT_TBL*			FigureEventTbl;
	int	i;

	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	if((unsigned char)CommonArea.SystemDev.TimeSwitch_DevName[0] > 0){
		ivalue= CommonArea.SystemDev.TimeSwitch_DevAdd;			/* Bin */
//		TimeDevFlag= GetDevNamePLCAddr(0,(unsigned char *)CommonArea.SystemDev.TimeSwitch_DevName,chChName,&DevInfo,&ivalue);
		TimeDevFlag= GetDevName(0,(char *)CommonArea.SystemDev.TimeSwitch_DevName,chChName,&DevInfo);
	}else{
		TimeDevFlag= -1;
	}
#ifdef	OLD
	for(i= 0; i < 8; i++){
		//Display Device Name
		if(TimeDevFlag == -1){
			sprintf(chDsp_buff,"DEVICE");
		}else{
//			ivalue= SetPLCUsrAddr(DevInfo,ivalue++,Device2Index(0,chChName),0);		//KSC20090112
//				Device2Index(0,chChName);
//			if(ret >= 0){
				if(memcmp(chChName,"UB",2) == 0){
					chChName1[0]= chChName[0];
					chChName1[1]= chChName[1];
					chChName1[2]= 0;
				}else{
					chChName1[0]= chChName[0];
					chChName1[1]= 0;
				}
				work= ivalue/16;
				UsAddr= 0;
				for(k= 0; k < 5; k++){
					if(work == 0){
						break;
					}
					UsAddr |= work%10 << (k+1)*4;
					work /= 10;
				}
				UsAddr += ivalue % 16;

				ivalue++;		//20090112
//				sprintf(chDsp_buff,"%s%05X",chChName1,ret);
				sprintf(chDsp_buff,"%s %06X",chChName1,UsAddr);
//			}
		}
		DispTextItemData(TimeSwitchGamenID[i][1],FigureEventTbl,chDsp_buff);
		GetTimeSwTime(i);
		//Start Time
		sprintf(chDsp_buff,"%2s:%2s:%2s",Set._TIMESWITCH[i].chSHour
									,Set._TIMESWITCH[i].chSMinute
									,Set._TIMESWITCH[i].chSSecond);
		DispTextItemData(TimeSwitchGamenID[i][2],FigureEventTbl,chDsp_buff);
		//End Time
		sprintf(chDsp_buff,"%2s:%2s:%2s",Set._TIMESWITCH[i].chEHour
									,Set._TIMESWITCH[i].chEMinute
									,Set._TIMESWITCH[i].chESecond);
		DispTextItemData(TimeSwitchGamenID[i][3],FigureEventTbl,chDsp_buff);
	}

#else

	for(i= 0; i < 8; i++){
		//Display Device Name
		if(TimeDevFlag == -1){
			sprintf(chDsp_buff,"DEVICE");
		}else{
			UsAddr= SetPLCUsrAddr(DevInfo,ivalue,Device2Index(0,chChName),0);		//KSC20090112
			ivalue++;		//20090112

//			if(memcmp(chChName,"UB",2) == 0){
			if(strlen(chChName) == 2){
				sprintf(chDsp_buff," %s%05X",chChName,UsAddr);
			}else{
				sprintf(chDsp_buff," %s%06X",chChName,UsAddr);
			}

		
		}
		DispTextItemData(TimeSwitchGamenID[i][1],FigureEventTbl,chDsp_buff);
		GetTimeSwTime(i);
		//Start Time
		sprintf(chDsp_buff,"%2s:%2s:%2s",Set._TIMESWITCH[i].chSHour
									,Set._TIMESWITCH[i].chSMinute
									,Set._TIMESWITCH[i].chSSecond);
		DispTextItemData(TimeSwitchGamenID[i][2],FigureEventTbl,chDsp_buff);
		//End Time
		sprintf(chDsp_buff,"%2s:%2s:%2s",Set._TIMESWITCH[i].chEHour
									,Set._TIMESWITCH[i].chEMinute
									,Set._TIMESWITCH[i].chESecond);
		DispTextItemData(TimeSwitchGamenID[i][3],FigureEventTbl,chDsp_buff);
	}
#endif
	FreeMail((char *)FigureEventTbl);
}
const	int	WeekIdx[7]={
	7,10,12,14,16,18,20
};
const	int	TimeIdx[2]={
	45,49
};
void	DispSetTimeSwitchIni(int SwitchNo,SET_TIMESWITCH *TimeSwitchInf)
{
	int		i;
	char	chDsp_buff[16];
	_FIGURE_EVENT_TBL*			FigureEventTbl;

	//Week Reverse
	for(i= 0; i < 7; i++){
		if(TimeSwitchInf->iWeek & WeekAndData[i]){
			ReversItemData(WeekIdx[i]);
		}
	}
	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	//Start Time
	sprintf(chDsp_buff,"%2s : %2s : %2s",TimeSwitchInf->chSHour
								,TimeSwitchInf->chSMinute
								,TimeSwitchInf->chSSecond);
	DispTextItemData(TimeIdx[0],FigureEventTbl,chDsp_buff);
	//End Time
	sprintf(chDsp_buff,"%2s : %2s : %2s",TimeSwitchInf->chEHour
								,TimeSwitchInf->chEMinute
								,TimeSwitchInf->chESecond);
	DispTextItemData(TimeIdx[1],FigureEventTbl,chDsp_buff);
	FreeMail((char *)FigureEventTbl);
}
extern	int	vTimeInput(int kind,char *initdata);
int	GetTimeSwitchTime(int SwitchNo,int iKeyCode,SET_TIMESWITCH	*TimeSwitchInf)
{
	int		kind,ret;
	char	*indata;

	kind= 1;			//Min,Sec
	switch(iKeyCode){
	case KEY_START_H:
		indata= TimeSwitchInf->chSHour;
		kind= 0;			//Hour
		break;
	case KEY_START_M:
		indata= TimeSwitchInf->chSMinute;
		break;
	case KEY_START_S:
		indata= TimeSwitchInf->chSSecond;
		break;
	case KEY_END_H:
		indata= TimeSwitchInf->chEHour;
		kind= 0;			//Hour
		break;
	case KEY_END_M:
		indata= TimeSwitchInf->chEMinute;
		break;
	case KEY_END_S:
		indata= TimeSwitchInf->chESecond;
		break;
	}
	ret= vTimeInput(kind,indata);
	return(ret);
}
int	SetTimeSwitch(int SwitchNo,int* iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	SET_TIMESWITCH	TimeSwitchInf;
	int		ret;

	memcpy(&TimeSwitchInf,&Set._TIMESWITCH[SwitchNo],sizeof(SET_TIMESWITCH));
	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_TIME_SWITCH_ACT,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(TIME_SWITCH,iTotalCnt);
	DispSetTimeSwitchIni(SwitchNo,&TimeSwitchInf);
	DrawLcdBank1();
	EndFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl1[8]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = TIME_SWITCH_NUM;
			EndFlag= 1;
			break;
		default:
			if((iKeyCode >= KEY_SUN) && (iKeyCode <= KEY_SAT)){
				TimeSwitchInf.iWeek ^= WeekAndData[iKeyCode-KEY_SUN];
				ReversItemData(WeekIdx[iKeyCode-KEY_SUN]);
				DrawLcdBank1();
			}else{
				ret= GetTimeSwitchTime(SwitchNo,iKeyCode,&TimeSwitchInf);
				if(ret != 0){
					*iScreenNo= ret;
					EndFlag= 1;
				}else{
					ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
					DispBaseFiger(G_TIME_SWITCH_ACT,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
					DispTextData(TIME_SWITCH,iTotalCnt);
					DispSetTimeSwitchIni(SwitchNo,&TimeSwitchInf);
					DrawLcdBank1();
				}
			}
			break;
		}
	}
	if(memcmp(&Set._TIMESWITCH[SwitchNo],&TimeSwitchInf,sizeof(&TimeSwitchInf)) != 0){
		memcpy(&Set._TIMESWITCH[SwitchNo],&TimeSwitchInf,sizeof(SET_TIMESWITCH));
		mWriteSettei();
	}
	return(0);
}
extern	int	TimeSwitxhDevIn(int *DevAddr,short *DevName);
void	vTimeSwitch(int* iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		ret;
	int		Address;
	int		writeFlag;
	short	DevName;
	char	chDev1Key[10];

	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_TIME_SWITCH,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(LG_TIME_SWITCH,iTotalCnt);
//	DispItemTitle();
	DispTimeSwItem();
	DrawLcdBank1();
	EndFlag= 0;
	writeFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl1[7]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_FUNTION_NUM;
			EndFlag= 1;
			break;
		default:
			if((iKeyCode >= KEY_DEV1) && (iKeyCode <= KEY_DEV8)){	//DEVICE Select
				ret= TimeSwitxhDevIn(&Address,&DevName);
				if(ret > 0){
					*iScreenNo = ret;
				}else{
					if(ret == 0){
						strcpy(chDev1Key,Device_Name[DevName]);
						Set.TimeSwitch_DevName[0]= DeviceToIndexSet(0,chDev1Key);
						Set.TimeSwitch_DevAdd= Address;
						CommonArea.SystemDev.TimeSwitch_DevName[0]= Set.TimeSwitch_DevName[0];
						CommonArea.SystemDev.TimeSwitch_DevAdd= Address;
					}
					writeFlag= 1;
				}
			}else{
				iKeyCode= SetTimeSwitch(iKeyCode- KEY_DEVL1,iScreenNo);
			}
			EndFlag= 1;
			break;
		}
	}
	if(writeFlag == 1){
		mWriteSettei();
	}
	SwitchScrenSetting();
}

int	vPrintOut(int* iScreenNo)
{	
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
//	int		iKeyFlag;
	int	iPrintFlag;
//	char			chContent[30];
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;
	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_PRINT_OUT,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(PRINT_OUT,iTotalCnt);
	ReversItemData(9);
	DrawLcdBank1();
	EndFlag= 0;
	iPrintFlag= 0;
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_PRINT_OUT-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_FUNTION_NUM;
			EndFlag= 1;
			break;
		case KEY_YES:
			NormalBuzzer();				/*	Buzzer  */
//			memset(chContent, 0x00, sizeof(chContent));
//			sprintf(chContent, Dspname[PRINT_OUT].chName[Set.iLang][1]);

//			iKeyFlag = vOutEntWindowDisp(chContent);

//			if(iKeyFlag == DOWN_TRANS || iKeyFlag == UP_TRANS)
//			{
//				*iScreenNo = iKeyFlag;
//				break;
//			}
//			if (iKeyFlag == 0) {								
				iPrintFlag = 1;							/* ����Ʈ ���� */
				*iScreenNo = PRINT_OUT_NUM;
//				if(CommonArea.EntryCnt>0 && Set.Ch1_iKind == PRINTER){
				if(CheckPrintMode() == 0){
					/*	Message Display		*/
					AreaClear(8,10,230,70,0);							/*  ���ϴ� �κи��� ������.   */
					RectAngleOut(8,10,230,70,&RECParam);					/* ȭ��Ʋ �ۼ�				 */
					DotTextOut(10,Line_2,Dspname[DATA_TRANSFER].chName[Set.iLang][8],1,1, TRANS, T_WHITE, T_BLACK);
					DrawLcdBank1();
					/*----------------------*/
					PrintDataDisplay();
//				}else if(Set.Ch1_iKind != PRINTER){
				}else if((Set.Ch1_iKind != PRINTER) && (Set.Ch2_iKind != PRINTER)){
					iCaptionWindow(Dspname[DATA_TRANSFER].chName[Set.iLang][9],"");
				}
//			}else{
//				iPrintFlag = 2;							/* ����Ʈ ��� */
//				*iScreenNo = PRINT_OUT_NUM;
//			}
			EndFlag= 1;
			break;
		case KEY_NO:
			EndFlag= 1;
			*iScreenNo = SET_FUNTION_NUM;
			break;
		}
	}
	return(iPrintFlag);

}
/******************************************************************************* */
/*  ��E��E��E: SetTask															 */
/*  ��E   �� : ����ó���½�ũ ���θ޴� ȣÁE									 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E2��E14�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/******************************************************************************* */
const	SET_PROC	SetScreenTbl[]={
	{SELECT_MEMU_NUM		,SelectMenu},
	{MONITORING_NUM			,MonitoringMode},
	{DEVICE_MONITORING_NUM	,vDeviceMoni},
	{DATA_VIEW_NUM			,DataViewMenu},
	{BASE_SCREEN_NUM		,BaseScreenList},
	{WINDOW_SCREEN_NUM		,WindowScreenList},
	{COMMENT_SCREEN_NUM		,vCommentMenu},
	{MEMORY_SIZE_NUM		,MemorySizeDisp},
	{MODEL_VER_NUM			,ModelVerDisp},
	{SET_FUNTION_NUM		,SetFuntionMode},
	{TIME_SWITCH_NUM		,vTimeSwitch},
	{DATA_TRANSFER_NUM		,vDataTrans},
	{DOWN_TRANS				,vDataTrans},
	{UP_TRANS				,vDataTrans},
	{PRINT_OUT_NUM			,vPrintOutMain},
	{SET_ENVIRONMENT_NUM	,SetEnvironmentMode},
	{CLOCK_MENU_NUM			,vClockSet},
	{LANGUAGE_NUM			,vLangSet},
	{BACKLIGHT_NUM			,vBackLightSet},
	{BATTERY_NUM			,vButDispMode},
	{BUZZER_NUM				,vBuzzerSet},
	{OPENNING_NUM			,vScreenSet},
	{PLC_SETTING_NUM		,vPlcSet},
	{MENU_CALL_KEY_NUM		,vMainCallSet},	
	{CLEAR_DATA_NUM			,vClearData},
	{LCDCONTRAST_NUM		,vLcdContSetDisp},
	{UWLATCH_NUM			,vUwLatchSetDisp},		/* 20091222 */
};
void	SetTask( int p1,int p2 )
{
	int	i;
	int iScreenNo;
	int		smcod;

	BaseChangeFlag= 0;		/* 040815 */
	BaseChangeFlag1= 0;		/* 040815 */
	BaseChangeFlag2= 0;		/* 040815 */

	vFreemeilAll();
	TateYoko			= 0;
	Set.LcdReverseOn	= 1;	
	iScreen				= CONFIG_SCREEN;
	iScreenNo			= p1;
	smcod				= p2;

	if(iScreenNo == DOWN_TRANS || iScreenNo == UP_TRANS){
		iUserScreenFlag = 0;
	}
	while (iScreenNo != 0) {
		if(iScreenNo != 999){
			SetWindowNo(SCREEN_0);
			AreaClear(0,0,GAMEN_X_SIZE-1,(GAMEN_Y_SIZE-1),0);
		}
		for(i= 0; i < TBQ(SetScreenTbl); i++){
			if(SetScreenTbl[i].iScreenNo == iScreenNo){	break;	}
		}
		if(i < TBQ(SetScreenTbl)){	SetScreenTbl[i].RsCall(&iScreenNo);	}
		else{						Delay(50);							}
		if (iScreenNo == CONFIG_NEXT) {
			break;
		}
		if(smcod == 1)
		{
			iScreenNo = 0;
			smcod = 0;
		}

	} /* end while */

	if(iScreen == CONFIG_SCREEN && iScreenNo != CONFIG_NEXT){
		sprintf(cPcTempFileName, pcFileName[iBaseScreenCnt]);	/* File Setting */
		DeviceCnt = 0;
		memset(DeviceDataHed,0,sizeof(DeviceDataHed));
		OffSignal(SGN_PLC, 0xFFFFFFFF);
		SendTaskAnal(0);
	}		
/*	}*/
	/* 050321 Scrol Key */
	if(iUserScreenFlag == 0){
		RepeatInfo.EntryCnt= 0;
	}
	/* 050427 */
	PassWordSettingFg= 0;
	PassWordSettingChg= 0;
	iPassFlag= 0;
	/******************/

}


/****************************************************/
void	GetCh1Name(char *name,char *ver)
{
	switch(Set.Ch1_iKind){
	case UNIVERSAL:
		strcpy(name, Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iKind]);
		Uni_Get_Plc1_Ver(ver);
		break;
	case DEFAULT_PLC:
		strcpy(name, Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iKind]);
		Def_Get_Plc1_Ver(ver);
		break;
	case ELSE_PLC:

		if(IsPlc1Protocol() == OK){		/* 2008.12.10 */
			strcpy(name,Set.cPlcTypeAdd);
			GET_PLC1_VER(ver);
		}else{
			strcpy(name,"No Use");
			*ver= 0;
		}
		break;
	}
}
void	GetCh2Name(char *name,char *ver)
{
	switch(Set.Ch2_iKind){

	case PLCTYPE2:

		if(IsPlc2Protocol() == OK){		/* 2008.12.10 */
			strcpy(name,Set.cPlcTypeAdd2);
			GET_PLC2_VER(ver);
		}else{
			strcpy(name,"No Use");
			*ver= 0;
		}
		break;
	}
}


void	vPlcCh1ProtocolDisp(void)
{
	char	chDsp_buff[20];	
	char	chDsp_Ver[32];	

	//Protocol Name
	switch(Set.Ch1_iKind){
	case UNIVERSAL:
	case DEFAULT_PLC:
	case ELSE_PLC:
		memset(chDsp_buff,0,sizeof(chDsp_buff));
		memset(chDsp_Ver,0,sizeof(chDsp_Ver));
		GetCh1Name(chDsp_buff,chDsp_Ver);
		DispTextSetItemData(IDX_PROTOCOL1,chDsp_buff);	/* ����Ʈ PLC1 ����ǥ�� */
		DispTextSetItemData(IDX_PROT1_VER,chDsp_Ver);	/* ����Ʈ PLC1 ����ǥ�� */
		break;
	default:
		DispTextSetItemData(IDX_PROTOCOL1,Dspname[PLC_ADD_SETTING].chName[Set.iLang][Set.Ch1_iKind-EDITER+2]);	/* ����Ʈ PLC1 ����ǥ�� */
		break;
	}
}
void	vPlcCh1ConnectDisp(void)
{
//KSC20090112
#ifdef SBD0 
	//Connect
	DispTextSetItemDataFont(IDX_CONNECT1,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iConnect+2],1,1);		/* PLC1 ��Ʈ ����ǥ�� */	/* RS422/RS232C */
#endif
#ifdef SBD1 
	DispTextSetItemData(IDX_CONNECT1,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iConnect+2]);		/* PLC1 ��Ʈ ����ǥ�� */	/* RS422/RS232C */
	DispTextSetItemData(IDX_CONNECT11,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iConnect+4]);		/* PLC1 ��Ʈ ����ǥ�� */	/* PORT A/PORT B */
#endif
}
void	vPlcCh2ProtocolDisp(void)
{
	char	chDsp_buff[20];	
	char	chDsp_Ver[32];	

	switch(Set.Ch2_iKind){
	case PLCTYPE2:
		memset(chDsp_buff,0,sizeof(chDsp_buff));	/* 2008.12.11 */
		memset(chDsp_Ver,0,sizeof(chDsp_Ver));	/* 2008.12.11 */

		GetCh2Name(chDsp_buff,chDsp_Ver);

		DispTextSetItemData(IDX_PROTOCOL2,chDsp_buff);	/* �ٿ�δ� PLC2 ����ǥ�� */
		DispTextSetItemData(IDX_PROT2_VER,chDsp_Ver);	/* �ٿ�δ� PLC2 ����ǥ�� */
		break;
	default:
		DispTextSetItemData(IDX_PROTOCOL2,Dspname[PLC_ADD_SETTING].chName[Set.iLang][Set.Ch2_iKind-EDITER+2]);	/* ����Ʈ PLC1 ����ǥ�� */
		break;
	}
}
void	vPlcCh2ConnectDisp(void)
{
//KSC20090112
#ifdef SBD0 
	//Connect
	DispTextSetItemDataFont(IDX_CONNECT2,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch2_iConnect+2],1,1);		/* PLC1 ��Ʈ ����ǥ�� */	/* RS422/RS232C */
#endif
#ifdef SBD1 
	DispTextSetItemData(IDX_CONNECT2,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch2_iConnect+2]);		/* PLC1 ��Ʈ ����ǥ�� */	/* RS422/RS232C */
	DispTextSetItemData(IDX_CONNECT22,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch2_iConnect+4]);		/* PLC1 ��Ʈ ����ǥ�� */	/* PORT A/PORT B */
#endif
}
void	vPlcGpStationDisp(void)
{
	char	chDsp_buff[20];	

	//GP Station No
	sprintf(chDsp_buff,"%02d",Set.iGPSta);
	DispTextSetItemData(IDX_GP_STATIN,chDsp_buff);	/* GP ���� ǥ�� */
}
void	vPlcPlcStationDisp(void)
{
	char	chDsp_buff[20];	

	//CH1 Station No
	sprintf(chDsp_buff,"%03d",Set.iDstSta);
	DispTextSetItemData(IDX_PLC_STATIN,chDsp_buff);	/* PLC1 ���� ǥ�� */
}
void	vPlcSetDisp(void)
{	
	/* CH 1 SET */
	ClearTextItemData(IDX_PROTOCOL1);	/* Display Clear */
	ClearTextItemData(IDX_CONNECT1);	/* Display Clear */
	vPlcCh1ProtocolDisp();
	vPlcCh1ConnectDisp();
	/* CH2 SET */
	ClearTextItemData(IDX_PROTOCOL2);	/* Display Clear */
	ClearTextItemData(IDX_CONNECT2);	/* Display Clear */
	vPlcCh2ProtocolDisp();
	vPlcCh2ConnectDisp();
	//Station No
	ClearTextItemData(IDX_GP_STATIN);	/* Display Clear */
	ClearTextItemData(IDX_PLC_STATIN);	/* Display Clear */
	vPlcGpStationDisp();
	vPlcPlcStationDisp();
}
int	IsSirialSet(int kind)
{
	int		ret= NG;

	switch(kind){
	case DEFAULT_PLC:
		if((Def_Get_Ms_Sel() & 0xFF00) == 0x0100){		/* Apl Serial Set */
			ret= OK;
		}
		break;
	case ELSE_PLC:
//#ifdef	WIN32
//		if(memcmp((char *)&GpFont[PLC1_PROTOCOL],"PLCPROC",7) == 0){
//#else
//		if(memcmp((char *)PLC1_PROTOCOL,"PLCPROC",7) == 0){
//#endif
		if(IsPlc1Protocol() == OK){		/* 2008.12.10 */
			if((GET_MS_SEL() & 0xFF00) == 0x0100){		/* Apl Serial Set */
				ret= OK;
			}
		}
		break;
	case EDITER:
		ret= OK;
		break;
	case MONITOR:
		break;
	case PLCTYPE2:
		if(IsPlc2Protocol() == OK){		/* 2008.12.10 */
			if((GET_MS_SEL2() & 0xFF00) == 0x0100){		/* Apl Serial Set */
				ret= OK;
			}
		}
		break;
	default:
		ret= OK;
		break;
	}
	return(ret);
}
void	SetCh1Protocol(void)
{
	while(1){
		Set.Ch1_iKind= (Set.Ch1_iKind+ 1)%6;
		if(Set.Ch1_iKind == ELSE_PLC){		/* Download PLC */ /* ksc20090525 */
//#ifdef	WIN32	/* 2006.05.19 */
//			if((strlen(Set.cPlcTypeAdd) != 0) && (memcmp((char *)&GpFont[PLC1_PROTOCOL],"PLCPROC",7) == 0)){
//#else
//			if((strlen(Set.cPlcTypeAdd) != 0) && (memcmp((char *)PLC1_PROTOCOL,"PLCPROC",7) == 0)){
//#endif
			if(IsPlc1Protocol() == OK){		/* 2008.12.10 */  /* ksc20090525 */
			}else{
				if((Set.Ch2_iKind == PLCTYPE2) && (IsPlc2Protocol() == NG)){
					continue;		/* Slave */
				}
			}
		}
		if(Set.Ch1_iKind == MONITOR){
			continue;		/* Slave */
		}
		if(Set.Ch1_iKind != Set.Ch2_iKind){	/* 060622 */
			break;
		}
	}
	PlcConnectFlag = 0;
	ClearTextItemData(IDX_PROTOCOL1);	/* Display Clear */
	ClearTextItemData(IDX_PROT1_VER);	/* Display Clear */
	vPlcCh1ProtocolDisp();
	ClearSerial1();
	DiapSerial1();
	DrawLcdBank1();
}
void	SetCh2Protocol(void)
{
	while(1){

//		if(IsPlc2Protocol() == OK){		/* 2009.05.25 */
			Set.Ch2_iKind= (Set.Ch2_iKind+ 1)%8;
//		}else{
//			Set.Ch2_iKind= (Set.Ch2_iKind+ 1)%7;
//		}

		if(Set.Ch2_iKind < EDITER){
			Set.Ch2_iKind= EDITER;
		}
		if(Set.Ch2_iKind == MONITOR){
			switch(Set.Ch1_iKind){
			case DEFAULT_PLC:
				if((Def_Get_Ms_Sel() & 0x00ff) == 0x0000){		/* Apl Serial Set */
					continue;		/* Slave */
				}
				break;
			case ELSE_PLC:
				if(IsPlc1Protocol() == OK){		/* 2008.12.10 */
					if((GET_MS_SEL() & 0x00ff) == 0x0000){		/* Apl Serial Set */
						continue;		/* Slave */
					}
				}else{
					continue;		/* Slave */
				}
				break;
			default:
				continue;
			}
		}
		if(Set.Ch2_iKind == PLCTYPE2){				/* ksc20090525 Add*/
			if(IsPlc2Protocol()==NG){
				if((Set.Ch1_iKind == ELSE_PLC) && (IsPlc1Protocol() == NG)){
					continue;
				}
			}
			break;
		}
		if(Set.Ch1_iKind != Set.Ch2_iKind){
			break;
		}
	}
	PlcConnectFlag = 0;
	ClearTextItemData(IDX_PROTOCOL2);	/* Display Clear */
	ClearTextItemData(IDX_PROT2_VER);	/* Display Clear */
	vPlcCh2ProtocolDisp();
	ClearSerial2();
	DiapSerial2();
	DrawLcdBank1();
}
void	SetCh1Conect(void)
{
	Set.Ch1_iConnect= (Set.Ch1_iConnect+1)%2;	/* CH1 SET */
	Set.Ch2_iConnect= (Set.Ch1_iConnect+1)%2;	/* CH2 SET */
	PlcConnectFlag = 0;
	ClearTextItemData(IDX_CONNECT1);	/* Display Clear */
	ClearTextItemData(IDX_CONNECT11);	/* Display Clear */
	vPlcCh1ConnectDisp();
	ClearTextItemData(IDX_CONNECT2);	/* Display Clear */
	ClearTextItemData(IDX_CONNECT22);	/* Display Clear */
	vPlcCh2ConnectDisp();
	DrawLcdBank1();
}
void	SetCh2Conect(void)
{
	Set.Ch2_iConnect= (Set.Ch2_iConnect+1)%2;	/* CH2 SET */
	Set.Ch1_iConnect= (Set.Ch2_iConnect+1)%2;	/* CH1 SET */
	PlcConnectFlag = 0;
	ClearTextItemData(IDX_CONNECT2);	/* Display Clear */
	ClearTextItemData(IDX_CONNECT22);	/* Display Clear */
	vPlcCh2ConnectDisp();
	ClearTextItemData(IDX_CONNECT1);	/* Display Clear */
	ClearTextItemData(IDX_CONNECT11);	/* Display Clear */
	vPlcCh1ConnectDisp();
	DrawLcdBank1();
}
int	SetGpStation(void)
{
	char	chDsp_buff[24];	
	char	chData[10];
	short	iKeyCode;
	int		iLen;
	int		i;

	PlcConnectFlag = 0;
	iLen=2;
	memset(chDsp_buff,0,sizeof(chDsp_buff));
	itoa(Set.iGPSta, chDsp_buff, 10);
	if(chDsp_buff[1] == 0){
		chDsp_buff[1]= chDsp_buff[0];
		chDsp_buff[0]= ' ';
	}
	iKeyCode = iNumInput1(chDsp_buff, chData, &iLen);
	if(iKeyCode == 0){
		for(i= 0; ; i++){
			if((chDsp_buff[i] != ' ') || (chDsp_buff[i] == 0)){
				break;
			}
		}
		Set.iGPSta = gatoi(&chDsp_buff[i]);
	}
	return(iKeyCode);
}
int	SetPlcStation(void)
{
	char	chDsp_buff[24];	
	char	chData[10];
	short	iKeyCode;
	int		iLen,i,j;

	PlcConnectFlag = 0;
	itoa(Set.iDstSta, chData, 10);
	iLen= strlen(chData);
	for(i= 0; i < 3-iLen; i++){
		chDsp_buff[i]= ' ';
	}
	for(j= 0; i < 3; i++,j++){
		chDsp_buff[i]= chData[j];
	}
/* 20081003 */
	chDsp_buff[i]= 0;
	iLen=3;
	iKeyCode = iNumInput1(chDsp_buff, chData, &iLen);
	if(iKeyCode == 0){
		for(i= 0; ; i++){
			if((chDsp_buff[i] != ' ') || (chDsp_buff[i] == 0)){
				break;
			}
		}
		Set.iDstSta = gatoi(&chDsp_buff[i]);
	}
	return(iKeyCode);
}

void	ClearSerial1(void)
{
	ClearTextItemData(IDX_SPEED1);
	ClearTextItemData(IDX_DATA1);
	ClearTextItemData(IDX_STOP1);
	ClearTextItemData(IDX_PARITY1);
	ClearTextItemData(IDX_FLOW1);
}
//#ifdef	GP_S057
//void	ClearParity2(void)
//{
//	AreaClear(ScreenTagData[IDX_PARITY2].sX-12, ScreenTagData[IDX_PARITY2].sY,
//		ScreenTagData[IDX_PARITY2].sX+8*4-1-12, ScreenTagData[IDX_PARITY2].eY,0);
//}
//#endif
void	ClearSerial2(void)
{
	ClearTextItemData(IDX_SPEED2);
	ClearTextItemData(IDX_DATA2);
	ClearTextItemData(IDX_STOP2);
//#ifdef	GP_S057
//	ClearParity2();
//#else
	ClearTextItemData(IDX_PARITY2);
//#endif
	ClearTextItemData(IDX_FLOW2);
}
void	DiapSerial1(void)
{
	short	iSpeed;						/* 0:300, 1:600, 2:1200, 3:2400, 4:4800, 5:9600, 6:19200 7:38400bps 8:57600bps */
	short	iParity;					/* 0:NONE 1:EVEN 2:ODD */
	short	iData1;						/* 0: 7BITS 1:8BITS */
	short	iData2;						/* 0:XON/XOFF 1:DSR/DTR */
	short	iStop;						/* 0:1BITS 1:2BITS */

	ClearTextItemData(IDX_SPEED1);	/* Display Clear */
	ClearTextItemData(IDX_DATA1);	/* Display Clear */
	ClearTextItemData(IDX_STOP1);	/* Display Clear */
	ClearTextItemData(IDX_PARITY1);	/* Display Clear */
	ClearTextItemData(IDX_FLOW1);	/* Display Clear */
	if(IsSirialSet(Set.Ch1_iKind) == OK){
		iSpeed = Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed;			/* 9600 */
		iParity = Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity;			/* 0:NONE,1:ODD,2:EVEN */
		iData1 = Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1;			/* 0:7,1:8 */
		iData2 = Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2;			/* 0:XON/XOFF 1:DSR/DTR */		
		iStop = Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop;				/* 0:1BITS 1:2BITS */		
		/* SPEED */
		DispTextSetItemCenter(IDX_SPEED1,cSpeed[iSpeed]);
		/* DATA1 */
		DispTextSetItemCenter(IDX_DATA1,cData[iData1]);
		/* STOP */
		DispTextSetItemCenter(IDX_STOP1,cStop[iStop]);
		/* Parity */
		DispTextSetItemCenter(IDX_PARITY1,cParity[iParity]);
		/* F/C */
		DispTextSetItemCenter(IDX_FLOW1,cFlow[iData2]);
	}else{
		/* SPEED */
		DispTextSetItemCenter(IDX_SPEED1,"-");
		/* DATA1 */
		DispTextSetItemCenter(IDX_DATA1,"-");
		/* STOP */
		DispTextSetItemCenter(IDX_STOP1,"-");
		/* Parity */
		DispTextSetItemCenter(IDX_PARITY1,"-");
		/* F/C */
		DispTextSetItemCenter(IDX_FLOW1,"-");
	}
}
void	DiapSerial2(void)
{
	short	iSpeed;						/* 0:300, 1:600, 2:1200, 3:2400, 4:4800, 5:9600, 6:19200 7:38400bps 8:57600bps */
	short	iParity;					/* 0:NONE 1:EVEN 2:ODD */
	short	iData1;						/* 0: 7BITS 1:8BITS */
	short	iData2;						/* 0:XON/XOFF 1:DSR/DTR */
	short	iStop;						/* 0:1BITS 1:2BITS */

	ClearTextItemData(IDX_SPEED2);	/* Display Clear */
	ClearTextItemData(IDX_DATA2);	/* Display Clear */
	ClearTextItemData(IDX_STOP2);	/* Display Clear */
	ClearTextItemData(IDX_PARITY2);	/* Display Clear */
	ClearTextItemData(IDX_FLOW2);	/* Display Clear */
	if(IsSirialSet(Set.Ch2_iKind) == OK){
		iSpeed = Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed;			/* 9600 */
		iParity = Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity;			/* 0:NONE,1:ODD,2:EVEN */
		iData1 = Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1;			/* 0:7,1:8 */
		iData2 = Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2;			/* 0:XON/XOFF 1:DSR/DTR */		
		iStop = Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop;				/* 0:1BITS 1:2BITS */		
		/* SPEED */
		DispTextSetItemCenter(IDX_SPEED2,cSpeed[iSpeed]);
		/* DATA1 */
		DispTextSetItemCenter(IDX_DATA2,cData[iData1]);
		/* STOP */
		DispTextSetItemCenter(IDX_STOP2,cStop[iStop]);
		/* Parity */
		DispTextSetItemCenter(IDX_PARITY2,cParity[iParity]);
		/* F/C */
		DispTextSetItemCenter(IDX_FLOW2,cFlow[iData2]);
	}else{
		/* SPEED */
		DispTextSetItemCenter(IDX_SPEED2,"-");
		/* DATA1 */
		DispTextSetItemCenter(IDX_DATA2,"-");
		/* STOP */
		DispTextSetItemCenter(IDX_STOP2,"-");
		/* Parity */
		DispTextSetItemCenter(IDX_PARITY2,"-");
		/* F/C */
		DispTextSetItemCenter(IDX_FLOW2,"-");
	}
}
void	vSerialSetDisp(void)
{

	//CH1
	DiapSerial1();
	//CH2
	DiapSerial2();
	DrawLcdBank1();
}
void	SetSpeed1(void)
{
	if(IsSirialSet(Set.Ch1_iKind) == OK){
		if (Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed > 8 ) {
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed = 0;
		} else {
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed++;
		}
		ClearTextItemData(IDX_SPEED1);
		DispTextSetItemCenter(IDX_SPEED1,cSpeed[Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed]);
		DrawLcdBank1();
	}
}
void	SetData1(void)
{
	if(IsSirialSet(Set.Ch1_iKind) == OK){
		if (Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1 > 0 ) {
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1 = 0;
		} else {
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1++;
		}
		ClearTextItemData(IDX_DATA1);
		DispTextSetItemCenter(IDX_DATA1,cData[Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1]);
		DrawLcdBank1();
	}
}
void	SetStop1(void)
{
	if(IsSirialSet(Set.Ch1_iKind) == OK){
		if (Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop > 0 ) {
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop = 0;
		} else {
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop++;
		}
		ClearTextItemData(IDX_STOP1);
		DispTextSetItemCenter(IDX_STOP1,cStop[Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop]);
		DrawLcdBank1();
	}
}
void	SetParity1(void)
{
	if(IsSirialSet(Set.Ch1_iKind) == OK){
		if (Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity > 1 ) {
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity = 0;
		} else {
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity++;
		}	
		ClearTextItemData(IDX_PARITY1);
		DispTextSetItemCenter(IDX_PARITY1,cParity[Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity]);
		DrawLcdBank1();
	}
}
void	SetFlow1(void)
{
	if(IsSirialSet(Set.Ch1_iKind) == OK){
		if (Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2 > 0 ) {
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2 = 0;
		} else {
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2++;
		}
		ClearTextItemData(IDX_FLOW1);
		DispTextSetItemCenter(IDX_FLOW1,cFlow[Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2]);	
		DrawLcdBank1();
	}
}
void	SetSpeed2(void)
{
	if(IsSirialSet(Set.Ch2_iKind) == OK){
		if (Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed > 8 ) {
			Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed = 0;
		} else {
			Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed++;
		}
		ClearTextItemData(IDX_SPEED2);
		DispTextSetItemCenter(IDX_SPEED2,cSpeed[Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed]);
		DrawLcdBank1();
	}
}
void	SetData2(void)
{
	if(IsSirialSet(Set.Ch2_iKind) == OK){
		if (Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1 > 0 ) {
			Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1 = 0;
		} else {
			Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1++;
		}
		ClearTextItemData(IDX_DATA2);
		DispTextSetItemCenter(IDX_DATA2,cData[Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1]);
		DrawLcdBank1();
	}
}
void	SetStop2(void)
{
	if(IsSirialSet(Set.Ch2_iKind) == OK){
		if (Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop > 0 ) {
			Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop = 0;
		} else {
			Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop++;
		}
		ClearTextItemData(IDX_STOP2);
		DispTextSetItemCenter(IDX_STOP2,cStop[Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop]);
		DrawLcdBank1();
	}
}
void	SetParity2(void)
{
	if(IsSirialSet(Set.Ch2_iKind) == OK){
		if (Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity > 1 ) {
			Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity = 0;
		} else {
			Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity++;
		}	
		//���̃t?�C��������������
//#ifdef	GP_S057
//		ClearParity2();
//#else
		ClearTextItemData(IDX_PARITY2);
//#endif
		DispTextSetItemCenter(IDX_PARITY2,cParity[Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity]);
		DrawLcdBank1();
	}
}
void	SetFlow2(void)
{
	if(IsSirialSet(Set.Ch2_iKind) == OK){
		if (Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2 > 0 ) {
			Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2 = 0;
		} else {
			Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2++;
		}
		ClearTextItemData(IDX_FLOW2);
		DispTextSetItemCenter(IDX_FLOW2,cFlow[Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2]);	
		DrawLcdBank1();
	}
}

/********************************************************************************/
/*	UW LATCH ON/OFF																*/
/********************************************************************************/
void		vUwLatchSetDisp(int* iScreenNo)
{
	int		iKeyCode;
	int		EndFlag;
	int		iTotalCnt;
	int		OldiuwLatch;

	OldiuwLatch= Set.iuwLatch;
	ClearDispBuff(SCREEN_0);								/* ���÷��� ���� �ʱ�ȭ	 */
	DispBaseFiger(G_BUZZER,&iTotalCnt);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
	DispTextData(UWLATCH,iTotalCnt);
	DrawLcdBank1();
	EndFlag= 0;

	if((Set.iuwLatch != ON) && (Set.iuwLatch != OFF)){
		Set.iuwLatch= OFF;
	}

	if(Set.iuwLatch == OFF){			//�����l��ON��Ԃ̂���
		EngForReverse(8);					//
		EngForReverse(9);					//�x?�X��ʂ���?���Ă��邽��
		DrawLcdBank1();
	}
	while ( EndFlag == 0 ) {
		iKeyCode = EndvKeyCheck((KEY_CHECK_DATA *)&EnvKeyTbl[G_BUZZER-G_MENU_SEL]);
		switch(iKeyCode){
		case PC_DNLOAD_START:		/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			EndFlag= 1;
			break;
		case PC_UPLOAD_START:
			*iScreenNo = UP_TRANS;
			EndFlag= 1;
			break;
		case KEY_EXIT:
			*iScreenNo = USER_SCREEN_NUM;
			EndFlag= 1;
			break;
		case KEY_MENU_END:
			*iScreenNo = SET_ENVIRONMENT_NUM;
			EndFlag= 1;
			break;
		case KEY_BUZ_ON:
			if(Set.iuwLatch == OFF){
				Set.iuwLatch = ON;
				EngForReverse(8);					//
				EngForReverse(9);					//�x?�X��ʂ���?���Ă��邽��
				DrawLcdBank1();
			}
			break;
		case KEY_BUZ_OFF:
			if(Set.iuwLatch == ON){
				Set.iuwLatch = OFF;
				EngForReverse(8);					//
				EngForReverse(9);					//�x?�X��ʂ���?���Ă��邽��
				DrawLcdBank1();
			}
			break;
		}
	}
	//Set Data Flash Write
	if(OldiuwLatch != Set.iuwLatch)
	{
		mWriteSettei();
	}
}


/***********************************************************/
#endif
