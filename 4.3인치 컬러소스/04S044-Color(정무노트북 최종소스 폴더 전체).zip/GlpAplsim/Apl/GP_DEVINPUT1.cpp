/* ****************************************************************************** */
/*  �� �� �� : GP_DEVINPUT1.CPP													 */
/*  ��    �� : ����̽� �Է� ������ 1											 */
/*  �� �� �� : 2002�� 2�� 18�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

/* ****************************************************************************** */
/*  �� �� �� : vDevInput1(char *chKey, int iSize)								 */
/*  ��    �� : ����̽� �ּ� �Է¿� ������1										 */
/*  ��    �� : chKey	: �Է°� ���� �� ��ȯ										 */	
/* 			  iSize : char�� ũ��												 */
/*  ��    �� : iReFlag															 */	
/* 			1: CLR ����   0: ENT ����											 */
/*  �� �� �� : 2002�� 2�� 18�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#ifdef	SIZE_2480
int		vDevInput1(char *chKey, int iSize)
{
	int		iReFlag = -1;	
	short	iDevNum;
/* 20071109 	char	chKey1[4]; */
	char	chKey1[10];
/* 20071109 	char	chKey2[4]; */
	char	chKey2[10];
//	short	DeviceCnt;
	int		iLen;

	memset(chKey1, 0x00, sizeof(chKey1));
	memset(chKey2, 0x00, sizeof(chKey2));

//	DeviceCnt = 15;

	while ( iReFlag == -1 ) {
		if(strlen(Device_Name[12])==0)
			iReFlag = iDevInput1Select(&iDevNum);			/*  ���� ó��			 */
		else
			iReFlag = iDevInputKey2Select(&iDevNum);			/*  ���� ó��			 */

		if(iReFlag == DOWN_TRANS || iReFlag == UP_TRANS)
		{
			break;
		}		
		/* Ű���� �޾����� �ڵ����� ����̽� �Է� ������2 ȣ��					 */
		if ( iReFlag == 0 ) {

			/*	�ٿ�ε� �Ǵ� ���信 ���� ���� Ÿ�Լ����ϴ� �Լ��� �ʿ�. */
			if((Device_iType[iDevNum] & 0x100) == 0x100)
				iLen = 4;				
			else
				iLen = 3;
			chKey1[0] = (char)iDevNum;
			iReFlag = vDevInput2(chKey1, chKey2, 0, iLen);/*  iLen 3(8����), 4(10����) */
			if(iReFlag == DOWN_TRANS || iReFlag == UP_TRANS)
			{
				break;
			}
			if ( iReFlag == 0 ) {
				strcat(chKey, Device_Name[iDevNum]);
				strcat(chKey, " ");
				strcat(chKey, chKey2);
			} else if ( iReFlag == 1 ) { 
				memset(chKey, 0x00, iSize);
			} /*  end if  */
		}
	} /*  end while  */
	AreaClear(0,0,GAMEN_X_SIZE-1,GAMEN_Y_SIZE-1,0);	/* �Ϻθ� ����� */

	return iReFlag;
}



/* ****************************************************************************** */
/*  �� �� �� : iDevInput1Select()												 */
/*  ��    �� : ȭ�� ���ý� ó��													 */
/*  ��    �� :																	 */
/*  ��    �� : iReFlag 0 : ESC ����												 */
/*  �� �� �� : 2002�� 2�� 18�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
int		iDevInput1Select(short* iNum)
{

	int iKeyCode = -1;
	int iReFlag =  -1;	
	short	iKeyFlag;

	ClearDispBuff(SCREEN_1);
	SetStartPos(SCREEN_1, GAMEN_START_X+76, GAMEN_START_Y+0);
	OpenWindow(SCREEN_1,164,80);

	vNumberInputPan(0);									/* 16��ư �Է���.(10����) */


	iKeyFlag = 1;
	while (iKeyCode == -1) {
		iKeyCode = KeyWaitData(iKeyFlag, 0xffff);							/* �Էµ� Ű���� �о��	 */
		if(iKeyCode == 0)
			iKeyCode = -1;
		iKeyFlag = 0;
		
		if ((iKeyCode >= KEY_14 && iKeyCode <= KEY_15 ) ||
			(iKeyCode >= KEY_21 && iKeyCode <= KEY_30 ) ||
			(iKeyCode >= KEY_36 && iKeyCode <= KEY_45 ) ||
			(iKeyCode >= KEY_51 && iKeyCode <= KEY_60 )) 
		{
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
		} /*  end if  */		
			
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			iReFlag = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			iReFlag = UP_TRANS;
			break;
		}		/* Ű ���� ó�� */		
#ifdef	SIZE_3224
		switch(iKeyCode)
		{
			case KEY_14:				/*  CLR				 */
			case KEY_15:
				iReFlag = 1;
				*iNum = -1;
				break;
			case KEY_21:
			case KEY_22:
				*iNum	= 0;
				iReFlag = 0;
				break;
/*			case KEY_23:*/
			case KEY_24:
				*iNum	= 1;
				iReFlag = 0;
				break;

			case KEY_25:
			case KEY_26:
				*iNum	= 2;
				iReFlag = 0;
				break;

			case KEY_27:
/*			case KEY_28:*/
				*iNum	= 3;
				iReFlag = 0;
				break;

			case KEY_29:				/*	UP_KEY			 */
			case KEY_30:
					ErrorBuzzer();
				break;
			case KEY_36:
			case KEY_37:
				*iNum	= 4;
				iReFlag = 0;
				break;
/*			case KEY_38:*/
			case KEY_39:
				*iNum	= 5;
				iReFlag = 0;
				break;

			case KEY_40:
			case KEY_41:
				*iNum	= 6;
				iReFlag = 0;
				break;

			case KEY_42:
/*			case KEY_43:*/
				*iNum	= 7;
				iReFlag = 0;
				break;

			case KEY_44:				/*	DOWN_KEY				*/
			case KEY_45:
				ErrorBuzzer();
				break;
			case KEY_51:
			case KEY_52:
				*iNum	= 8;
				iReFlag = 0;
				break;
/*			case KEY_53:*/
			case KEY_54:
				*iNum	= 9;
				iReFlag = 0;
				break;

			case KEY_55:
			case KEY_56:
				*iNum	= 10;
				iReFlag = 0;
				break;

			case KEY_57:
/*			case KEY_58:*/
				*iNum	= 11;
				iReFlag = 0;
				break;

			case KEY_59:				/*  ENT				 */	
			case KEY_60:
				ErrorBuzzer();
				break;
		}
#endif
#ifdef	SIZE_2480
		switch(iKeyCode)
		{
			case KEY_14:				/*  CLR				 */
			case KEY_15:
				iReFlag = 1;
				*iNum = -1;
				break;
			case KEY_21:
			case KEY_22:
				*iNum	= 0;
				iReFlag = 0;
				break;
			case KEY_23:
			case KEY_24:
				*iNum	= 1;
				iReFlag = 0;
				break;

			case KEY_25:
			case KEY_26:
				*iNum	= 2;
				iReFlag = 0;
				break;

			case KEY_27:
			case KEY_28:
				*iNum	= 3;
				iReFlag = 0;
				break;

			case KEY_29:				/*	UP_KEY			 */
			case KEY_30:
					ErrorBuzzer();
				break;
			case KEY_36:
			case KEY_37:
				*iNum	= 4;
				iReFlag = 0;
				break;
			case KEY_38:
			case KEY_39:
				*iNum	= 5;
				iReFlag = 0;
				break;

			case KEY_40:
			case KEY_41:
				*iNum	= 6;
				iReFlag = 0;
				break;

			case KEY_42:
			case KEY_43:
				*iNum	= 7;
				iReFlag = 0;
				break;

			case KEY_44:				/*	DOWN_KEY				*/
			case KEY_45:
				ErrorBuzzer();
				break;
			case KEY_51:
			case KEY_52:
				*iNum	= 8;
				iReFlag = 0;
				break;
			case KEY_53:
			case KEY_54:
				*iNum	= 9;
				iReFlag = 0;
				break;

			case KEY_55:
			case KEY_56:
				*iNum	= 10;
				iReFlag = 0;
				break;

			case KEY_57:
			case KEY_58:
				*iNum	= 11;
				iReFlag = 0;
				break;

			case KEY_59:				/*  ENT				 */	
			case KEY_60:
				ErrorBuzzer();
				break;
		}
#endif
		if(strlen(Device_Name[*iNum])==0 && iReFlag == 0)
		{
			iReFlag = -1;
			iKeyCode = -1;
			ErrorBuzzer();
		}
	} /*  end while  */	
	CloseWindow(SCREEN_1);/*  ���ϴ� �κи��� ������. leesi 04/15  */	
	SetWindowNo(SCREEN_0);
	return iReFlag;
}
/* ****************************************************************************** */
/*  �� �� �� : iDevInput2Select()												 */
/*  ��    �� : ȭ�� ���ý� ó��	()												 */
/*  ��    �� :																	 */
/*  ��    �� : iReFlag 0 : ESC ����												 */
/*  �� �� �� : 2002�� 2�� 18�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
int		iDevInputKey2Select(short* iNum)
{

	int		iKeyCode;
	int		iReFlag;	
	short	iKeyFlag;

	iKeyCode = -1;
	iReFlag	=  -1;	
	iKeyFlag = 1;

	ClearDispBuff(SCREEN_1);
	SetStartPos(SCREEN_1, 59, 0);
	OpenWindow(SCREEN_1,181,80);

	vNumberInputPan_16(0);								/* 20��ư �Է���. */

	DrawLcdBank1();	
	while (iKeyCode == -1) {
		iKeyCode = KeyWaitData(iKeyFlag,0xffff);							/* �Էµ� Ű���� �о��	 */
		if(iKeyCode == 0)
			iKeyCode = -1;
		iKeyFlag = 0;
		
		if ((iKeyCode >= KEY_12 && iKeyCode <= KEY_15 ) ||		/* 031119 Add */
			((iKeyCode >= KEY_20 && iKeyCode <= KEY_30 ) && (iKeyCode != KEY_23)) ||
			((iKeyCode >= KEY_35 && iKeyCode <= KEY_45 ) && (iKeyCode != KEY_38)) ||
			((iKeyCode >= KEY_50 && iKeyCode <= KEY_60 )  && (iKeyCode != KEY_53)) ) 
		{
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
		} /*  end if  */		
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			iReFlag = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			iReFlag = UP_TRANS;
			break;
		}
#ifdef	SIZE_3224
		/* Ű ���� ó�� */	
		switch(iKeyCode)
		{
			
			case KEY_12:
/*			case KEY_13:*/
				*iNum	= 0;
				iReFlag = 0;
				break;
			case KEY_14:					/* CLR */
			case KEY_15:
				iReFlag = 1;
				*iNum	= -1;
				break;

			case KEY_20:
			case KEY_21:
				*iNum	= 1;
				iReFlag = 0;
				break;
			case KEY_22:
				*iNum	= 2;
				iReFlag = 0;
				break;
			case KEY_24:
				*iNum	= 3;
				iReFlag = 0;
				break;
			case KEY_25:
			case KEY_26:
				*iNum	= 4;
				iReFlag = 0;
				break;
			case KEY_27:
/*			case KEY_28:*/
				*iNum	= 5;
				iReFlag = 0;
				break;
			case KEY_29:					/* UP_KEY  */
			case KEY_30:
				ErrorBuzzer();
				break;

			case KEY_35:
			case KEY_36:
				*iNum	= 6;
				iReFlag = 0;
				break;
			case KEY_37:
				*iNum	= 7;
				iReFlag = 0;
				break;
			case KEY_39:
				*iNum	= 8;
				iReFlag = 0;
				break;
			case KEY_40:
			case KEY_41:
				*iNum	= 9;
				iReFlag = 0;
				break;
			case KEY_42:
/*			case KEY_43:*/
				*iNum	= 10;
				iReFlag = 0;
				break;
			case KEY_44:					/* DOWN_KEY  */
/*			case KEY_45:*/
				ErrorBuzzer();
				break;

			case KEY_50:
			case KEY_51:
				*iNum	= 11;
				iReFlag = 0;
				break;
			case KEY_52:
				*iNum	= 12;
				iReFlag = 0;
				break;
			case KEY_54:
				*iNum	= 13;
				iReFlag = 0;
				break;
			case KEY_55:
			case KEY_56:
				*iNum	= 14;
				iReFlag = 0;
				break;
			case KEY_57:
/*			case KEY_58:*/
				*iNum	= 15;
				iReFlag = 0;
				break;
			case KEY_59:					/* ENT */
			case KEY_60:
				ErrorBuzzer();
				break;
		}
#endif
#ifdef	SIZE_2480
		switch(iKeyCode)
		{
			
			case KEY_12:
			case KEY_13:
				*iNum	= 0;
				iReFlag = 0;
				break;
			case KEY_14:					/* CLR */
			case KEY_15:
				iReFlag = 1;
				*iNum	= -1;
				break;

			case KEY_20:
			case KEY_21:
				*iNum	= 1;
				iReFlag = 0;
				break;
			case KEY_22:
				*iNum	= 2;
				iReFlag = 0;
				break;
			case KEY_24:
				*iNum	= 3;
				iReFlag = 0;
				break;
			case KEY_25:
			case KEY_26:
				*iNum	= 4;
				iReFlag = 0;
				break;
			case KEY_27:
			case KEY_28:
				*iNum	= 5;
				iReFlag = 0;
				break;
			case KEY_29:					/* UP_KEY  */
			case KEY_30:
				ErrorBuzzer();
				break;

			case KEY_35:
			case KEY_36:
				*iNum	= 6;
				iReFlag = 0;
				break;
			case KEY_37:
				*iNum	= 7;
				iReFlag = 0;
				break;
			case KEY_39:
				*iNum	= 8;
				iReFlag = 0;
				break;
			case KEY_40:
			case KEY_41:
				*iNum	= 9;
				iReFlag = 0;
				break;
			case KEY_42:
			case KEY_43:
				*iNum	= 10;
				iReFlag = 0;
				break;
			case KEY_44:					/* DOWN_KEY  */
			case KEY_45:
				ErrorBuzzer();
				break;

			case KEY_50:
			case KEY_51:
				*iNum	= 11;
				iReFlag = 0;
				break;
			case KEY_52:
				*iNum	= 12;
				iReFlag = 0;
				break;
			case KEY_54:
				*iNum	= 13;
				iReFlag = 0;
				break;
			case KEY_55:
			case KEY_56:
				*iNum	= 14;
				iReFlag = 0;
				break;
			case KEY_57:
			case KEY_58:
				*iNum	= 15;
				iReFlag = 0;
				break;
			case KEY_59:					/* ENT */
			case KEY_60:
				ErrorBuzzer();
				break;
		}
#endif
		if(strlen(Device_Name[*iNum])==0 && iReFlag == 0)
		{
			iReFlag  = -1;
			iKeyCode = -1;
			ErrorBuzzer();
		}
	} /*  end while  */	
	/* Zero Read */
	/* 2008.10.02 */
	if((iReFlag != DOWN_TRANS) && (iReFlag != UP_TRANS)){		/* DownLoad	*/
		iKeyCode = KeyWaitData(iKeyFlag,0xffff);							/* �Էµ� Ű���� �о��	 */
	}
	CloseWindow(SCREEN_1);/*  ���ϴ� �κи��� ������. leesi 04/15  */	
	SetWindowNo(SCREEN_0);
	return iReFlag;
}
#endif
