/* ****************************************************************************** */
/*  �� �� ��E: GP_PLCTYPESET.CPP													 */
/*  ��E   �� : ����EPLC ����														 */
/*  �� �� �� : 2002��E2��E16�� (ŁE												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��    �� : (��) LC Tech														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

/* ****************************************************************************** */
/*  �Լ�E																		 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  ��E��E��E: vPlcSet()															 */
/*  ��E   �� : ����EPLC ���� ó��												 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E2��E16�� (ŁE												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
#ifdef	SIZE_2480
void		vPlcSet(int* iScreenNo)
{
	_SETUP	*SaveSet;

	SaveSet= (_SETUP*)TakeMemory(sizeof(_SETUP));
	memcpy(SaveSet,&Set,sizeof(_SETUP));
	OffSignal(SGN_PLC, 0xFFFFFFFF);
	while ( *iScreenNo == PLC_SETTING_NUM ) {
		vPlcSetDisp();								/*  ó��ȭ��E���			 */
		iPlcSetSelect(iScreenNo);					/*  ���� ó��				 */
	} /*  end while  */
	if(memcmp(SaveSet,&Set,sizeof(_SETUP)) != 0){
		mWriteSettei();
	}
	FreeMail((char*)SaveSet);
	if((*iScreenNo == UP_TRANS) || (*iScreenNo == DOWN_TRANS)){
	}else{
		PlcConnectFlag= 0;
/*		PlcConnectFlag2= 0;	*/									/* 20081007 */
		memset(&PlcConnectFlag2[0],0,sizeof(PlcConnectFlag2));	/* 20081007 */
		Rs232cBordrateSet();
		PC_CommMode= 0;
		OnSignal(SGN_PLC,1);
	}
	return;
}
void	GetCh1Name(char *name,char *ver)
{
	switch(Set.Ch1_iKind){
	case UNIVERSAL:
/*		strcpy(name,EndBtn.chPlcType[Set.iLang][Set.Ch1_iKind]);*/
		strcpy(name, Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iKind]);
		Uni_Get_Plc1_Ver(ver);
		break;
	case DEFAULT_PLC:
/*		strcpy(name,EndBtn.chPlcType[Set.iLang][Set.Ch1_iKind]);*/
		strcpy(name, Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iKind]);
		Def_Get_Plc1_Ver(ver);
		break;
	case ELSE_PLC:

		if(IsPlc1Protocol() == OK){		/* 2008.12.10 */
			strcpy(name,Set.cPlcTypeAdd);
			GET_PLC1_VER(ver);
		}else{
			strcpy(name,"No Use");
			*ver= 0;
		}
		break;
	}
}

void	GetCh2Name(char *name,char *ver)
{
	switch(Set.Ch2_iKind){
	case PLCTYPE2:

		if(IsPlc2Protocol() == OK){		/* 2008.12.10 */
			strcpy(name,Set.cPlcTypeAdd2);
			GET_PLC2_VER(ver);
		}else{
			strcpy(name,"No Use");
			*ver= 0;
		}
		break;
	}
}
/* *******************************************************************************/
/*  ��E��E��E: vPlcSetDisp()													 */
/*  ��E   �� : ����EPLC ���� ȭ��E���											 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E2��E16�� (ŁE												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/* *******************************************************************************/
void	vPlcSetDisp(void)
{	
	char	chDsp_buff[42];	
	char	chDsp_Ver[32];	

	_RECTANGLE_INFO RECParam;
	_LINE_INFO LineParam;

	
	LineParam.iLineColor = WHITE;
	LineParam.iLineStyle = SOLID_LINE;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;
	
	ClearDispBuff(SCREEN_0);								/*  ���÷��� ���� �ʱ�ȭ	 */
	memset(chDsp_buff,0,sizeof(chDsp_buff));
	memset(chDsp_Ver,0,sizeof(chDsp_Ver));
/*
	DotTextOut(1,25,Dspname[PLC_SETTING].chName[0][0],1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(1,44,Dspname[PLC_SETTING].chName[0][1],1,1, NON_TRANS, T_WHITE, T_BLACK);
*/
	DotTextOut(GAMEN_START_X+1,GAMEN_START_Y+25,Dspname[PLC_ADD_SETTING].chName[0][0],1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+1,GAMEN_START_Y+44,Dspname[PLC_ADD_SETTING].chName[0][1],1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+1,GAMEN_START_Y+63,Dspname[PLC_SETTING].chName[Set.iLang][2],1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+116,GAMEN_START_Y+63,Dspname[PLC_SETTING].chName[Set.iLang][3],1,1, NON_TRANS, T_WHITE, T_BLACK);
	/* CH1 */
	RectAngleOut(GAMEN_START_X+1,GAMEN_START_Y+24,GAMEN_START_X+36,GAMEN_START_Y+41,&RECParam);			/* plc1�簢�� */		
	RectAngleOut(GAMEN_START_X+1,GAMEN_START_Y+43,GAMEN_START_X+36,GAMEN_START_Y+60,&RECParam);			/* plc2�簢�� */
	RectAngleOut(GAMEN_START_X+38,GAMEN_START_Y+24,GAMEN_START_X+238,GAMEN_START_Y+41,&RECParam);			/* plc1�簢�� */		
	RectAngleOut(GAMEN_START_X+38,GAMEN_START_Y+43,GAMEN_START_X+238,GAMEN_START_Y+60,&RECParam);			/* plc2�簢�� */
	LineOut( GAMEN_START_X+186, GAMEN_START_Y+25, GAMEN_START_X+186, GAMEN_START_Y+40, &LineParam );		/* plc1 �߰����м� */		
	LineOut( GAMEN_START_X+186, GAMEN_START_Y+44, GAMEN_START_X+186, GAMEN_START_Y+59, &LineParam );		/* plc2 �߰����м� */		

	RectAngleOut(GAMEN_START_X+84,GAMEN_START_Y+62,GAMEN_START_X+108,GAMEN_START_Y+79,&RECParam);			/* GP���� �簢�� */
	RectAngleOut(GAMEN_START_X+208,GAMEN_START_Y+62,GAMEN_START_X+238,GAMEN_START_Y+79,&RECParam);			/* PLC1���� �簢�� */			
	/* ����� PLC1 ���� �� ���� ǥ�� */
	/* CH 1 SET */
	switch(Set.Ch1_iKind){
	case UNIVERSAL:
	case DEFAULT_PLC:
	case ELSE_PLC:
		GetCh1Name(chDsp_buff,chDsp_Ver);
		DotTextOut(GAMEN_START_X+40,GAMEN_START_Y+25,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	/* ����Ʈ PLC1 ����ǥ�� */
		break;
	default:
		DotTextOut(GAMEN_START_X+40,GAMEN_START_Y+25,Dspname[PLC_ADD_SETTING].chName[Set.iLang][Set.Ch1_iKind-EDITER+2],1,1, TRANS, T_WHITE, T_BLACK);	/* ����Ʈ PLC1 ����ǥ�� */
		break;
	}

#ifdef	SBD0
	DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+25,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iConnect+2],1,1, TRANS, T_WHITE, T_BLACK);		/* PLC1 ��Ʈ ����ǥ�� */
#endif
#ifdef	SBD1
	DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+25,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iConnect+2],1,0, TRANS, T_WHITE, T_BLACK);		/* PLC1 ��Ʈ ����ǥ�� */
	DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+33,Dspname[PLC_SETTING].chName[Set.iLang][Set.Ch1_iConnect+5],1,0, TRANS, T_WHITE, T_BLACK);
#endif
	/* CH2 SET */
	switch(Set.Ch2_iKind){
	case PLCTYPE2:
		GetCh2Name(chDsp_buff,chDsp_Ver);
		DotTextOut(GAMEN_START_X+40,GAMEN_START_Y+44,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);	/* �ٿ�δ� PLC2 ����ǥ�� */
		break;
	default:
		DotTextOut(GAMEN_START_X+40,GAMEN_START_Y+44,Dspname[PLC_ADD_SETTING].chName[Set.iLang][Set.Ch2_iKind-EDITER+2],1,1, TRANS, T_WHITE, T_BLACK);	/* ����Ʈ PLC1 ����ǥ�� */
		break;
	}

#ifdef	SBD0
	DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+44,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch2_iConnect+2],1,1, TRANS, T_WHITE, T_BLACK);	/* RS232C */
#endif	
#ifdef	SBD1
	DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+44,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch2_iConnect+2],1,0, TRANS, T_WHITE, T_BLACK);	/* RS232C */
	DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+52,Dspname[PLC_SETTING].chName[Set.iLang][Set.Ch2_iConnect+5],1,0, TRANS, T_WHITE, T_BLACK);
#endif

	sprintf(chDsp_buff,"%02d",Set.iGPSta);
	DotTextOut(GAMEN_START_X+88,GAMEN_START_Y+63,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	/* GP ���� ǥ�� */
	
	sprintf(chDsp_buff,"%03d",Set.iDstSta);
	DotTextOut(GAMEN_START_X+212,GAMEN_START_Y+63,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	/* PLC1 ���� ǥ�� */
	
	DefaultFormDisplay(LINE_FORM,Dspname[PLC_SETTING].chTitle[Set.iLang]);
	DrawLcdBank1();
}

/* ****************************************************************************** */
/*  ��E��E��E: iPlcSetSelect()													 */
/*  ��E   �� : ȭ��E���ý� ó��													 */
/*  ��    �� :																	 */
/*  ÁE   �� : iEscFlag 0 : ESC ����												 */
/*  �� �� �� : 2003�� 7�� 1�� (ȭ)												 */
/*  �� �� �� : �� �� �� 														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
void		iPlcSetSelect(int* iScreenNo)
{
	int		iKeyCode;
//	int		iSetTemp;
	char	chDsp_buff[24];	
	char	chData[10];
	short	iKeyFlag;
	int		iLen;
	int		iKind;	/* 040508 */
	char	chDsp_Ver[32];	

	iKind= Set.Ch1_iKind;	/* 040508 */
	iKeyFlag	= 1;
	iKeyCode	= -1;
//	iSetTemp	= 1;

	while (*iScreenNo == PLC_SETTING_NUM) {
		iKeyCode = KeyWaitData(iKeyFlag, PLC_SETTING_NUM);							/* �Էµ� Ű���� �о���	 */
		iKeyFlag = 0;
		if( (iKeyCode >= KEY_05 && iKeyCode <= KEY_10 ) ||
			(iKeyCode >= KEY_18 && iKeyCode <= KEY_45 ) ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_17 ) ||
			(iKeyCode >= KEY_51 && iKeyCode <= KEY_52 ) ||
			(iKeyCode >= KEY_59 && iKeyCode <= KEY_60 ) ||
			iKeyCode == KEY_01 || iKeyCode == KEY_02)
		{
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
		}
		switch(iKeyCode){
		case PC_DNLOAD_START:	/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			break;
		case PC_UPLOAD_START:	/* UPLoad	*/
			*iScreenNo = UP_TRANS;
			break;
		case KEY_01:
		case KEY_02:	/* EXIT */
			*iScreenNo = USER_SCREEN_NUM;
			break;
		
		case KEY_05:
		case KEY_06:
		case KEY_07:		
		case KEY_08:
		case KEY_09:
		case KEY_10:				

			*iScreenNo= PLC_SETTING_MODELTYPE_NUM;			
			vContypeDisplay(iScreenNo);
			vPlcSetDisp();
			break;
		case KEY_13:
		case KEY_14:
		case KEY_15:	/* MENU */ 
			*iScreenNo = SET_ENVIRONMENT_NUM;
			break;
		case KEY_16:
		case KEY_17:	/* CH1 Sirial SET */
			switch(Set.Ch1_iKind){
			case DEFAULT_PLC:
				if((Def_Get_Ms_Sel() & 0xFF00) == 0x0100){		/* Apl Serial Set */
					*iScreenNo= SERIAL_PORT_NUM;
					vSerialSet(iScreenNo,CH_CH0);
					if(*iScreenNo == SET_ENVIRONMENT_NUM){
						*iScreenNo = PLC_SETTING_NUM;
						vPlcSetDisp();
					}
				}
				break;
			case ELSE_PLC:
				if(IsPlc1Protocol() == OK){		/* 2008.12.10 */
					if((GET_MS_SEL() & 0xFF00) == 0x0100){		/* Apl Serial Set */
						*iScreenNo= SERIAL_PORT_NUM;
						vSerialSet(iScreenNo,CH_CH0);
						if(*iScreenNo == SET_ENVIRONMENT_NUM){
							*iScreenNo = PLC_SETTING_NUM;
							vPlcSetDisp();
						}
					}
				}
				break;
			case MONITOR:
				break;
//			case EDITER:		//070917
//					break;
			default:
				*iScreenNo= SERIAL_PORT_NUM;
				vSerialSet(iScreenNo,CH_CH0);
				if(*iScreenNo == SET_ENVIRONMENT_NUM){
					*iScreenNo = PLC_SETTING_NUM;
					vPlcSetDisp();
				}
				break;
			}
			break;
		case KEY_31:
		case KEY_32:	/* CH2 Sirial SET */
			switch(Set.Ch2_iKind){
			case MONITOR:
				break;
//			case EDITER:		//070917
//				break;
			case PLCTYPE2:
				if(IsPlc2Protocol() == OK){		/* 2008.12.10 */
					if((GET_MS_SEL2() & 0xFF00) == 0x0100){		/* Apl Serial Set */
						*iScreenNo= SERIAL_PORT_NUM;
						vSerialSet(iScreenNo,CH_CH1);
						if(*iScreenNo == SET_ENVIRONMENT_NUM){
							*iScreenNo = PLC_SETTING_NUM;
							vPlcSetDisp();
						}
					}
				}
				break;
			default:
				*iScreenNo= SERIAL_PORT_NUM;
				vSerialSet(iScreenNo,CH_CH1);
				if(*iScreenNo == SET_ENVIRONMENT_NUM){
					*iScreenNo = PLC_SETTING_NUM;
					vPlcSetDisp();
				}
				break;
			}
			break;
		case KEY_51:
		case KEY_52:	/*  GP STA Change	 */
			PlcConnectFlag = 0;
			iLen=2;
			itoa(Set.iGPSta, chDsp_buff, 10);
			iKeyCode = iNumInput1(chDsp_buff, chData, &iLen);
			if(iLen == 1){		/* 041213 */
				Set.iGPSta = gatoi(chData);
			}else{
				Set.iGPSta = gatoi(chDsp_buff);
			}
#ifdef	LP_S044
			SetPlcStationNo();		//Station No Setting
#endif
			vPlcSetDisp();
			break;
		case KEY_59:
		case KEY_60:		/*	DST STA Change */
			PlcConnectFlag = 0;
			iLen=3;
			itoa(Set.iDstSta, chDsp_buff, 10);
			iKeyCode = iNumInput1(chDsp_buff, chData, &iLen);
			if(iLen == 1){		/* 041213 */
				Set.iDstSta = gatoi(chData);
			}else{
				Set.iDstSta = gatoi(chDsp_buff);
			}
			vPlcSetDisp();
			break;
		case KEY_28:
		case KEY_29:
		case KEY_30:		/*  CH1 Connect */
			Set.Ch1_iConnect= (Set.Ch1_iConnect+1)%2;	/* CH1 SET */
			Set.Ch2_iConnect= (Set.Ch1_iConnect+1)%2;	/* CH2 SET */
			PlcConnectFlag = 0;
/*			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+25,EndBtn.chPlcConnect[Set.iLang][Set.Ch1_iConnect],1,1, TRANS, T_WHITE, T_BLACK);*/	/* PLC1 ��Ʈ ǥ�� */
/*			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+44,EndBtn.chPlcConnect[Set.iLang][Set.Ch2_iConnect],1,1, TRANS, T_WHITE, T_BLACK);*/	/* PLC1 ��Ʈ ǥ�� */
//			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+25,Dspname[25].chName[Set.iLang][Set.Ch1_iConnect+2],1,1, TRANS, T_WHITE, T_BLACK);	/* PLC1 ��Ʈ ǥ�� */
//			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+44,Dspname[25].chName[Set.iLang][Set.Ch2_iConnect+2],1,1, TRANS, T_WHITE, T_BLACK);	/* PLC1 ��Ʈ ǥ�� */
/* ksc20070306 */
#ifdef	SBD0
			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+25,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iConnect+2],1,1, TRANS, T_WHITE, T_BLACK);	/* PLC1 ��Ʈ ǥ�� */
			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+44,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch2_iConnect+2],1,1, TRANS, T_WHITE, T_BLACK);	/* PLC1 ��Ʈ ǥ�� */
#endif
#ifdef	SBD1
			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+25,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iConnect+2],1,0, TRANS, T_WHITE, T_BLACK);	/* PLC1 ��Ʈ ǥ�� */
			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+44,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch2_iConnect+2],1,0, TRANS, T_WHITE, T_BLACK);	/* PLC1 ��Ʈ ǥ�� */
			
			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+33,Dspname[PLC_SETTING].chName[Set.iLang][Set.Ch1_iConnect+5],1,0, TRANS, T_WHITE, T_BLACK);
			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+52,Dspname[PLC_SETTING].chName[Set.iLang][Set.Ch2_iConnect+5],1,0, TRANS, T_WHITE, T_BLACK);
#endif
			break;
		case KEY_43:
		case KEY_44:
		case KEY_45:		/*  CH2 Connect */
			Set.Ch2_iConnect= (Set.Ch2_iConnect+1)%2;	/* CH2 SET */
			Set.Ch1_iConnect= (Set.Ch2_iConnect+1)%2;	/* CH1 SET */
			PlcConnectFlag = 0;
/*			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+25,EndBtn.chPlcConnect[Set.iLang][Set.Ch1_iConnect],1,1, TRANS, T_WHITE, T_BLACK);*/	/* PLC1 ��Ʈ ǥ�� */
/*			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+44,EndBtn.chPlcConnect[Set.iLang][Set.Ch2_iConnect],1,1, TRANS, T_WHITE, T_BLACK);*/	/* PLC1 ��Ʈ ǥ�� */
//			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+25,Dspname[25].chName[Set.iLang][Set.Ch1_iConnect+2],1,1, TRANS, T_WHITE, T_BLACK);	/* PLC1 ��Ʈ ǥ�� */
//			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+44,Dspname[25].chName[Set.iLang][Set.Ch2_iConnect+2],1,1, TRANS, T_WHITE, T_BLACK);	/* PLC1 ��Ʈ ǥ�� */
/* ksc20070306 */
#ifdef	SBD0			
			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+25,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iConnect+2],1,1, TRANS, T_WHITE, T_BLACK);	/* PLC1 ��Ʈ ǥ�� */
			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+44,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch2_iConnect+2],1,1, TRANS, T_WHITE, T_BLACK);	/* PLC1 ��Ʈ ǥ�� */
#endif
#ifdef	SBD1
			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+25,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch1_iConnect+2],1,0, TRANS, T_WHITE, T_BLACK);	/* PLC1 ��Ʈ ǥ�� */
			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+44,Dspname[RS232C_SETTING].chName[Set.iLang][Set.Ch2_iConnect+2],1,0, TRANS, T_WHITE, T_BLACK);	/* PLC1 ��Ʈ ǥ�� */

			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+33,Dspname[PLC_SETTING].chName[Set.iLang][Set.Ch1_iConnect+5],1,0, TRANS, T_WHITE, T_BLACK);
			DotTextOut(GAMEN_START_X+188,GAMEN_START_Y+52,Dspname[PLC_SETTING].chName[Set.iLang][Set.Ch2_iConnect+5],1,0, TRANS, T_WHITE, T_BLACK);
#endif
			break;
		default:
			if(iKeyCode >= KEY_18 && iKeyCode <= KEY_27 ){	/* CH1 Connect Kind */
				while(1){
					Set.Ch1_iKind= (Set.Ch1_iKind+ 1)%6;

					if(Set.Ch1_iKind == MONITOR){
						continue;		/* Slave */
					}
//					if(Set.Ch1_iKind != Set.Ch2_iKind){	/* 060622 */
//						break;
//					}
//20080324 ksc
					if(Set.Ch1_iKind != Set.Ch2_iKind){	/* 060622 */
						if(Set.Ch2_iKind == MONITOR){	/* 060622 */
							if((0 < Set.Ch1_iKind) && (Set.Ch1_iKind < 3)){	/* 060622 */
								break;
							}else{
								continue;
							}
						}
						break;
					}
//20080324 ksc
				}
				PlcConnectFlag = 0;
				AreaClear(40,25,185,39,0);	/* Display Clear */
				switch(Set.Ch1_iKind){
				case UNIVERSAL:
				case DEFAULT_PLC:
				case ELSE_PLC:
					memset(chDsp_buff,0,sizeof(chDsp_buff));
					memset(chDsp_Ver,0,sizeof(chDsp_Ver));
					GetCh1Name(chDsp_buff,chDsp_Ver);
					DotTextOut(40,25,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	/* ��ġ�� PLC1 ���� ǥ�� */	
//					DotTextOut(145,33,chDsp_Ver,1,0, TRANS, T_WHITE, T_BLACK);	/* ��ġ�� PLC1 ���� ǥ�� */
					break;
				default:
					DotTextOut(40,25,Dspname[PLC_ADD_SETTING].chName[Set.iLang][Set.Ch1_iKind-EDITER+2],1,1, TRANS, T_WHITE, T_BLACK);	/* ����Ʈ PLC1 ����ǥ�� */
					break;
				}
			}else if(iKeyCode >= KEY_33 && iKeyCode <= KEY_42 ){	/* CH2 Connect Kind */
				while(1){
					Set.Ch2_iKind= (Set.Ch2_iKind+ 1)%8;
					if(Set.Ch2_iKind < EDITER){
						Set.Ch2_iKind= EDITER;
					}
					if(Set.Ch2_iKind == MONITOR){
						switch(Set.Ch1_iKind){
						case DEFAULT_PLC:
							if((Def_Get_Ms_Sel() & 0x00ff) == 0x0000){		/* Apl Serial Set */
								continue;		/* Slave */
							}
							break;
						case ELSE_PLC:
							if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
								if((GET_MS_SEL() & 0x00ff) == 0x0000){		/* Apl Serial Set */
									continue;		/* Slave */
								}
							}else{
								continue;		/* Slave */
							}
							break;
//20080324 ksc
						case UNIVERSAL:
//							Set.Ch2_iKind = (Set.Ch2_iKind+ 1)%7;
//							break;
						case EDITER:
						case PRINTER:
						case BAR_CODE:
								continue;
//							break;
//20080324 ksc

						default:
#ifdef	LP_S044
							break;
#endif
#ifdef	GP_S057
							continue;
#endif
#ifdef	GP_S044
							continue;
#endif
						}
					}
					if(Set.Ch1_iKind != Set.Ch2_iKind){
						break;
					}
				}
				PlcConnectFlag = 0;
				AreaClear(40,44,185,58,0);	/* Display Clear */
				switch(Set.Ch2_iKind){
				case PLCTYPE2:		/* 08.12.11 */
					GetCh2Name(chDsp_buff,chDsp_Ver);					
					DotTextOut(40,44,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);	/* �ٿ�δ� PLC2 ����ǥ�� */
//					DotTextOut(145,52,chDsp_Ver,1,0, NON_TRANS, T_WHITE, T_BLACK);	/* �ٿ�δ� PLC2 ����ǥ�� */
					break;
				default:
					DotTextOut(40,44,Dspname[PLC_ADD_SETTING].chName[Set.iLang][Set.Ch2_iKind-EDITER+2],1,1, TRANS, T_WHITE, T_BLACK);	/* ����Ʈ PLC1 ����ǥ�� */
					break;
				}
			}else{
				iKeyCode = -1;
			}
			break;
		}
		DrawLcdBank1();		
	
	} /*  end while  */	
	/* PLC Change == Monitor Clear 040508 */
	if(iKind != Set.Ch1_iKind){	/* 040508 */

		DeviceMonitorBuffClear(0,4);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */

	}

	return;
}
#endif

