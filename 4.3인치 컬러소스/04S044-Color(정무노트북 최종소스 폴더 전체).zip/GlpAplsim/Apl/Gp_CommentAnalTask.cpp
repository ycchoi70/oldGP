/********************************************************************************/
/* �� �� �� : Gp_CommentAnalTask.cpp											*/
/* ��    �� : Comment������ �м��Ѵ�.											*/
/* �� �� �� : 2002�� 5�� 31�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"

/* ****************************************************************************** */
/*  �� �� �� : iCommentPointOnOff()												 */
/*  ��    �� : Comment ������ �迭 ��ȣ ����													 */
/*  ��    �� : iNum (Comment Number)											 */
/*  ��    �� : �迭�� ��ġ ��ȣ													 */
/*  �� �� �� : 2003�� 7�� 3�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
int iCommentPointOnOff(short iNum)
{
	int				ipos;
	int				isize; 
	int				iSite;
	int				i;	
	int				iOffset;
	int				inowNum;
	char			*AllTagBuffer;
	short			sReturnData;

	ipos		= 0;
	isize		= 0; 
	sReturnData = -1;

	if(iNum >= 0){

		if(mfileserch("COMMENT.GP",&ipos,&isize) == OK){
	/*		AllTagBuffer=(char *)TakeMemory(isize + 1);
			memset(AllTagBuffer,0x00,isize + 1);
			memcpy(AllTagBuffer,(char *)ipos,isize);*/
			AllTagBuffer=(char *)ipos;
			iComCnt  = (int)(AllTagBuffer[6] << 0x08);
			iComCnt += (int)AllTagBuffer[7] & 0xff;
			iOffset = 8;

			for(i=0 ; i < iComCnt ; i++){
				inowNum = (unsigned int)(AllTagBuffer[iOffset] << 0x08);
				iOffset++;	/* comment No 2byte */
				inowNum += (unsigned int)(AllTagBuffer[iOffset]& 0xff);
				iOffset++;
				
				if(inowNum == iNum)
				{
					sReturnData = inowNum;
					break;
				}else if(iNum < inowNum)
				{
					break;
				}
				iSite = (unsigned int)(AllTagBuffer[iOffset] << 0x08);
				iOffset ++;
				iSite += (unsigned int)(AllTagBuffer[iOffset] & 0xff);
				iOffset ++;
				iOffset ++;			
				iOffset+=iSite;
			}
		/*	FreeMail((char *)AllTagBuffer); */
		}else
			iComCnt = 0;
	}
	return sReturnData;
}
#ifdef	SIZE_2480
/* ****************************************************************************** */
/*  �� �� �� : vCommentMenu()												 */
/*  ��    �� : Comment �޴�ǥ��													 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 7�� 3�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
extern int iKeyReturn(int);
void	vCommentMenu(int* iScreenNo)
{
	short	iVal;
	short	i;
	short	j;
	short	iCnt;
	int		iKeyCode;
	char	cDispBuff[25];
/*	char	cComData[20];*/
	char	*cComData;
	int		iColor;
	int		iLen;
	short	iKeyFlag;

	cComData= TakeMemory(512+1);
	iKeyFlag = 1;
	iVal	= 0;
	iLen	= 18;
	iKeyCode = 100;
	/**************************/
	RepeatInfo.EntryCnt = 2;
	RepeatInfo.RepeatNo[0][0] = (char)KEY_29;
	RepeatInfo.RepeatNo[0][1] = (char)KEY_30;
	RepeatInfo.RepeatNo[1][0] = (char)KEY_59;
	RepeatInfo.RepeatNo[1][1] = (char)KEY_60;
	/**************************/

	DefaultFormDisplay(ARROW_FORM, Dspname[COMMENT_SCREEN].chTitle[Set.iLang]);
	if(iComCnt==0)
		vCommentListDisplay(0, cComData, &iColor, &iLen);

	KerRepeatFlag = 1;	/* 040815 */
	while(*iScreenNo == COMMENT_SCREEN_NUM)
	{
		if(iKeyCode > 0)
		{
			SetWinSema();
			AreaClear(GAMEN_START_X+2,GAMEN_START_Y+23,GAMEN_START_X+197,GAMEN_START_Y+78,0);
			if(iComCnt>0)
			{
				for(i = 0; i < 3; i++)
				{
					if(i+iVal < iComCnt){
						iLen	= 18;
						memset(cComData,0x00,512);
						vCommentListDisplay(i+iVal, cComData, &iColor, &iLen);
/*						sprintf(cDispBuff,"%5d:%s",iColor,cComData);*/
						sprintf(cDispBuff,"%5d:",iColor);
						memcpy(&cDispBuff[6],cComData,25-6);
/*********************************************/
						if(strlen(cDispBuff)>=24)
						{
							iCnt = 0;
							memset(cDispBuff+24,0x00,2);
							for(j=0;j<24;j++)
							{
								if(cDispBuff[j]>0x00 && cDispBuff[j]<0x7f)
									iCnt++;
								else
									j++;

							}
							if(iCnt%2 == 1)	/* ������ �ڸ��� 2Byte �����̾... */
							{
								memset(cDispBuff+23,0x00,1);
							}
						}
/**********************************************/
						DotTextOut(GAMEN_START_X+4, GAMEN_START_Y+25+(i*18), cDispBuff, 1, 1, T_FRONT, T_WHITE, T_BLACK);
					}
				}
			}
			ScroolBarDisplay(iComCnt,iVal);
			DrawLcdBank1();

			ResetWinSema();
		}
		while(1)
		{
			/* iKeyCode = KeyWait(); */
			iKeyCode = iKeyReturn(COMMENT_SCREEN_NUM);
			if(iKeyFlag == 0 || iKeyCode == PC_DNLOAD_START || 
				iKeyCode == PC_UPLOAD_START || iKeyCode == 0)
				break;
		}
		iKeyFlag = 0;

		if(( iKeyCode == KEY_01 || iKeyCode == KEY_02  ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_15) ||
			 iKeyCode == KEY_29 || iKeyCode == KEY_30  ||
			 iKeyCode == KEY_59 || iKeyCode == KEY_60 ||
			 iKeyCode == KEY_28 || iKeyCode == KEY_43 || iKeyCode == KEY_58))
		{
			iKeyFlag = 1;
			NormalBuzzer();	
		}
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}
		if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 )			/* ����		*/
		{
			*iScreenNo = USER_SCREEN_NUM;
		}
		else if(iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) 		/* ����		*/
		{				
			*iScreenNo = DATA_VIEW_NUM;
		}
		else if(iKeyCode == KEY_29 || iKeyCode == KEY_30 )		/*  UP_KEY	*/
		{	
			if(iVal > 0)
				iVal--;
			iKeyFlag = 0;
			KerRepeatFlag = 1;
		}
		else if(iKeyCode == KEY_59 || iKeyCode == KEY_60 )		/*  DOWN_KEY	*/
		{
			if(iComCnt > iVal+3)
				iVal++;
			iKeyFlag = 0;
			KerRepeatFlag = 1;
		}else if(iKeyCode == KEY_28)  /* ó  �� */ /************************************************************/
		{
			if(iVal != 0)
			{
				iVal = 0;
			}
			iKeyFlag = 0;

/*ksc20040624*/ /* �ڸ�Ʈ ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */
/*			KerRepeatFlag = 1;*/ 
/*ksc20040624*/

		}else if(iKeyCode == KEY_43)  /* ��  �� */
		{
			if(iVal != (iComCnt/2-1) && (iComCnt/2-1) > 3)
			{
				iVal = (iComCnt/2-1);
			}
			iKeyFlag = 0;

/*ksc20040624*/ /* �ڸ�Ʈ ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */
/*			KerRepeatFlag = 1;*/ 
/*ksc20040624*/

		}else if(iKeyCode == KEY_58)  /* ������ */
		{
			if(iComCnt-iVal > 3 && iComCnt > 3)
			{
				iVal = iComCnt-3;
			}
			iKeyFlag = 0;

/*ksc20040624*/ /* �ڸ�Ʈ ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */
/*			KerRepeatFlag = 1;*/ 
/*ksc20040624*/

		}		
		else
			iKeyCode = -1;
	}
	KerRepeatFlag = 0;
	memset(&RepeatInfo,0x00,sizeof(RepeatInfo));
	FreeMail(cComData);
}
/* ****************************************************************************** */
/*  �� �� �� : vCommentListDisplay()											 */
/*  ��    �� : Comment Dataǥ��													 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 7�� 14�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void vCommentListDisplay(int inowNum, char *cDataBuffer, int *iColor, int *iLen)
{
	int				ipos;
	int				isize; 
	int				iSite;
	int				iNum;
	int				i;	
	int				iOffset;
	short			sLen;
	char			*AllTagBuffer;

	sLen = *iLen;
	*iColor = 0;
	*iLen	= 0;
	ipos	= 0;
	isize	= 0; 

	if(mfileserch("COMMENT.GP",&ipos,&isize) == OK){
	/*	AllTagBuffer=(char *)TakeMemory(isize + 1);*/
	/*	memset(AllTagBuffer,0x00,isize + 1);*/
	/*	memcpy(AllTagBuffer,(char *)ipos,isize);*/
		AllTagBuffer = (char *)ipos;

		iComCnt  = (int)(AllTagBuffer[6] << 0x08);
		iComCnt += (int)AllTagBuffer[7] & 0xff;
		iOffset = 8;

		for(i=0 ; i < iComCnt ; i++){
			iNum = (unsigned int)(AllTagBuffer[iOffset] << 0x08);
			iOffset++;	/* comment No 2byte */
			iNum += (unsigned int)(AllTagBuffer[iOffset]& 0xff);
			iOffset++;
			
			if(inowNum == i)
			{
				*iLen = (unsigned int)((AllTagBuffer[iOffset] << 0x08) & 0xff00);
				iOffset ++;
				*iLen += (unsigned int)(AllTagBuffer[iOffset] & 0xff);
				iOffset ++;

				*iColor = (unsigned int)(AllTagBuffer[iOffset] & 0xff);
				iOffset ++;

				*iColor = iNum;

				if(sLen==0 || sLen > *iLen)
					memcpy(cDataBuffer, AllTagBuffer+iOffset, *iLen);
				else
					memcpy(cDataBuffer, AllTagBuffer+iOffset, sLen);
				break;
			}
			iSite = (unsigned int)(AllTagBuffer[iOffset] << 0x08);
			iOffset ++;
			iSite += (unsigned int)(AllTagBuffer[iOffset] & 0xff);
			iOffset ++;
			iOffset ++;			
			iOffset+=iSite;
		}
	/*	FreeMail((char *)AllTagBuffer);*/
	}else
		iComCnt = 0;


}
#endif
