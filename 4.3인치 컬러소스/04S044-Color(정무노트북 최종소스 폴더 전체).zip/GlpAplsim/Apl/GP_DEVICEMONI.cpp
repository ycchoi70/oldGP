/* ****************************************************************************** */
/*  �� �� ��E: GPDEVICEMONI.CPP													 */
/*  ��E   �� : ����̽� ����� ó��												 */
/*  �� �� �� : 2002��E2��E15�� (��)												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��    �� : (��) LC Tech														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

int	HexDecTogleFlag;		/* 20090703 */

/* ****************************************************************************** */
/*  ��E��E��E: vDeviceMoni()														 */
/*  ��E   �� : ����̽� ����� ó�� ��� ó��									 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E2��E15�� (��)												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
#ifdef	SIZE_2480

void DeviceMonitorDisplayData(int* inowdev)		/* 20090703 */
{
	int	i;
	AreaClear(GAMEN_START_X+1,GAMEN_START_Y+23,GAMEN_START_X+195,GAMEN_START_Y+60,0);		/*AreaClear(1,20,238,58,0);*/
	*inowdev = 0;
	for(i=0;i<4;i++)
	{
		if(BuffDip[i].cDev_Now != -1)
		{	
			iScreenNum = i+1;
			vDeviceDisplay(i,*inowdev);		/* ����̽� ����� ����Ÿ ǥ�� */
			BuffDip[i].iDev_Count = *inowdev;
			(*inowdev)++;
			/*030808*/
			if(BuffDip[i].iDev_Type == 4)
				*inowdev = *inowdev + 0;  /* iPlus */
		}
	}
/*ksc20040513 bir/word Select AreaRevers */
	if(BuffDip[0].cDev_Now != -1)
	{
		if(BuffDip[NowDip.iDev_NowPoint].iDev_Type == 1) /* ���õ� ��ġ�� ����̽� Ÿ���� 1�̸� ��Ʈ */
		{
			AreaRevers(2+((NowDip.iDev_NowPoint+1)%2==0 ? 100 : 0),NLine_2+(((NowDip.iDev_NowPoint)/2)*18),95+((NowDip.iDev_NowPoint+1)%2==0 ? 100 : 0),15+NLine_2+(((NowDip.iDev_NowPoint)/2)*18)); 
		}
		else /* �׿� Ÿ���� ���� */
		{
			AreaRevers(2+((NowDip.iDev_NowPoint+1)%2==0 ? 100 : 0),NLine_2+(((NowDip.iDev_NowPoint)/2)*18),195+((NowDip.iDev_NowPoint+1)%2==0 ? 100 : 0),15+NLine_2+(((NowDip.iDev_NowPoint)/2)*18)); 
		}
	}
/*ksc20040513*/	
}

void		vDeviceMoni(int* iScreenNo)
{

	int		j, i;
/*	int     iPlus;	*/
	int		inowdev;
	int		iDevDataPosition;
	int		iBitWordFlag;
	int		iKeyCode;
	int		iEscFlag;	
	int		iSize;
	char	chDev1Key[10];
/* 20071109 	char	chBuffData[4][5]; */
	char	chBuffData[10][10];
/* 20071109 	DevName[4]; */
	char	DevName[10];
	int		iDataTrans;
	short	iData;
	short	iKeyFlag;
	short	iConnectFlag;
	char	cCodeData[10];

	DeviceTableSet(0);		/* ǥ���� Device Name Set */
	iConnectFlag	= PlcConnectFlag;
	iEscFlag		= 0;
	iData			= 0;
	inowdev			= 0;
	iDevDataPosition = 0;	
	HexDecTogleFlag = 0;  /* 20090703 */
	vDeviceDispFormDraw();		/* Form Display */
	
	BaseChangeFlag1= 0;		/* 041129 Plc State */
	BaseChangeFlag2= 0;

	iKeyFlag = 0;

	KerRepeatFlag = 1;	/* 040815 */
	
	memset(chBuffData,0,sizeof(chBuffData));


	while ( *iScreenNo == DEVICE_MONITORING_NUM ) 
	{
		iKeyCode	= -1;
/*******************************************************************************************************/

		iSize = sizeof(chDev1Key);
		memset(chDev1Key, 0x00, iSize);

		while (iKeyCode == -1 || iKeyCode == 0) {												/*						*/
			while(1)
			{
				/*leesi 040612 iKeyCode = KeyAccept();*/												/* �Էµ� Ű���� �о�� */
				iKeyCode = iKeyAcceptReturn(DEVICE_MONITORING_NUM);
				if(iKeyCode == -1 || iKeyCode == PC_DNLOAD_START ||
					iKeyCode == 0 || iKeyCode == PC_UPLOAD_START ||
					iKeyFlag == 0)
				{
					if(iKeyCode == 0)
						iKeyFlag = 0;
					break;
				}
			}
			if(((iKeyCode >= KEY_29 && iKeyCode <= KEY_30 )||
				(iKeyCode >= KEY_01 && iKeyCode <= KEY_02 )||
				(KEY_13 <= iKeyCode && KEY_15 >= iKeyCode) || 
				(KEY_44 <= iKeyCode && KEY_45 >= iKeyCode) ||
				(KEY_46 <= iKeyCode && KEY_57 >= iKeyCode) ||
				(KEY_59 == iKeyCode || KEY_60 == iKeyCode)))
			{
				iKeyFlag = 1;
				NormalBuzzer();													/*	Buzzer				*/
			}

			if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
			{												
				*iScreenNo = DOWN_TRANS;
				break;
			}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
			{
				*iScreenNo = UP_TRANS;
				break;
			}
			/* Ű ���� ó�� */		
			if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) {					/*  next					 */
				*iScreenNo = USER_SCREEN_NUM;
			}
			else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) {					/*  END					 */
				*iScreenNo = MONITORING_NUM;
			} else if (iKeyCode >= KEY_46 && iKeyCode <= KEY_48 ){				/*	DEVICE SET			 */
				iDataTrans = vDevInput1(chDev1Key, iSize);
				if(iDataTrans == DOWN_TRANS || iDataTrans == UP_TRANS){
					*iScreenNo = iDataTrans;
					return;
				}	
				iKeyFlag = 0;	/* 040815 */
				iEscFlag = 0;
				vDeviceDispFormDraw();
			} else if (iKeyCode >= KEY_49 && iKeyCode <= KEY_51 ) {				/*  SET ����			 */
				/* 040515 */
				strcpy(cCodeData,Device_Name[BuffDip[NowDip.iDev_NowPoint].cDev_Now]);
				if((PlcConnectFlag != 0) ||
					((memcmp(cCodeData,"UB",2) == 0) || (memcmp(cCodeData,"UW",2) == 0))){
					iData = vCurSetting(iScreenNo);
					if(*iScreenNo == DOWN_TRANS || *iScreenNo == UP_TRANS)
					{
						return;
					}
					if(iData)
					{
						vDeviceDispFormDraw();
/*						iEscFlag = 1;	*/
						iEscFlag = 0;
					}
				}
			} else if (iKeyCode >= KEY_52 && iKeyCode <= KEY_54 ) {				/*  ON ó��				 */	
				vOnCheck();
				iKeyCode = -1;
			} else if (iKeyCode >= KEY_44 && iKeyCode <= KEY_45 ) {				/*  DEC/HEX ó��		 */	
				HexDecTogleFlag = HexDecTogleFlag ? 0 : 1 ;		/* 0 : Dec,  0xff: Hex  */
				AreaClear(GAMEN_START_X+210,GAMEN_START_Y+43,GAMEN_START_X+238,GAMEN_START_Y+58,0);	/* 20090703 */
				if(HexDecTogleFlag == 1){
					CenterDisplay(GAMEN_START_X+210,GAMEN_START_Y+43,GAMEN_START_X+238,GAMEN_START_Y+58, "Hex");				/* 20090703 */
				}else{
					CenterDisplay(GAMEN_START_X+210,GAMEN_START_Y+43,GAMEN_START_X+238,GAMEN_START_Y+58, "Dec");				/* 20090703 */				
				}
				DeviceMonitorDisplayData(&inowdev);
				DrawLcdBank1();	
				iKeyCode = -1;
			} else if (iKeyCode >= KEY_55 && iKeyCode <= KEY_57 ) {				/*  OFF ó�� 			 */	
				vOffCheck();
				iKeyCode = -1;	
			} else if (iKeyCode >= KEY_29 && iKeyCode <= KEY_30 ) {				/*  UP					 */
				iEscFlag = vUpDisplay();
				iKeyCode = -1;
/*ksc20040513*/
				iKeyFlag = 0;
/*				KerRepeatFlag = 1;*/
/*ksc20040513*/

			} else if (iKeyCode >= KEY_59 && iKeyCode <= KEY_60 ) {				/*  DOWN				 */	
				iEscFlag = vDownDisplay();
				iKeyCode = -1;
/*ksc20040513*/
				iKeyFlag = 0;
/*				KerRepeatFlag = 1;*/
/*ksc20040513*/
			
			} else /*  end if  */			
			{
				iKeyCode = -1;
				if(PlcConnectFlag != iConnectFlag)
				{
					iConnectFlag = PlcConnectFlag;
					iEscFlag = 1;
				}
			}
			/* leesi 5.14 */
			if(BuffDip[0].cDev_Now != -1 && iEscFlag == 0)
			{
				OnSignal(SGN_PLC,1);
				iDevDataPosition=0;
				iEscFlag = 1;
				DeviceCnt = 0;						/*  */
				memset(DeviceDataHed,0,sizeof(DeviceDataHed));
				/*****03_11_11*************************/
				memset(DeviceData,0x00,sizeof(DeviceData));
				/**************************************/
				j = 0;
				for(i=0;i<4;i++)
				{
					if(BuffDip[i].cDev_Now != -1)
					{	
						if(BuffDip[i].iDev_Type == 1)
							iBitWordFlag = 0;
						else 
							iBitWordFlag = 1;

						memset(chDev1Key, 0x00, sizeof(chDev1Key));
						strcpy(chDev1Key,Device_Name[BuffDip[i].cDev_Now]);
						DeviceDataHed[j].DevName[0] = DeviceToIndexSet(iBitWordFlag,chDev1Key);
						DeviceDataHed[j].DevName[1] = 0;
						DeviceDataHed[j].DevData	= &DeviceData[iDevDataPosition];
						DeviceDataHed[j].DevAddress = ReturnDevAddress(i);
						switch(BuffDip[i].iDev_Type){
							case 1:
								DeviceDataHed[j].DevFlag = DEVICE_BIT;
								DeviceDataHed[j].DevCnt = 1;
								iDevDataPosition++;
								break;
							case 2:		/*  Word */
								DeviceDataHed[j].DevFlag  = DEVICE_WORD;
								DeviceDataHed[j].DevCnt = 1;
								iDevDataPosition += 2;
								break;
							case 3:		/*	Word32  */
								DeviceDataHed[j].DevFlag  = DEVICE_WORD;
								DeviceDataHed[j].DevCnt = 2;
								iDevDataPosition += 4;
								break;

							case 4:
								/*  ����ġ ���� word */
								DeviceDataHed[j].DevFlag  = DEVICE_WORD;
								DeviceDataHed[j].DevCnt = 1;
								iDevDataPosition +=2;
								j++;
								/* ���� ���� bit */
								memset(chDev1Key, 0x00, sizeof(chDev1Key));
								strcpy(chDev1Key,Device_Name[BuffDip[i].cDev_Now]);
								DeviceDataHed[j].DevName[0] = DeviceToIndexSet(0,chDev1Key);
								DeviceDataHed[j].DevName[1] = 0;
								DeviceDataHed[j].DevData	= &DeviceData[iDevDataPosition];
								DeviceDataHed[j].DevAddress = ReturnDevAddress(i);
								
								DeviceDataHed[j].DevFlag	= DEVICE_BIT;
								DeviceDataHed[j].DevCnt		= 1;
								iDevDataPosition++;

								/***********************************/
								memset(DevName,0x00,sizeof(DevName));
								DevName[0] = DeviceToIndexSet(1,chDev1Key);
								j++;
								if(GetDevCntTime(1,DevName, (char *)DeviceDataHed[j].DevName)==0)
								{
									
									/* ����ġ ���� word */
									DeviceDataHed[j].DevName[1] = 0;
									DeviceDataHed[j].DevData	= &DeviceData[iDevDataPosition];
									DeviceDataHed[j].DevAddress = ReturnDevAddress(i);
									DeviceDataHed[j].DevFlag	= DEVICE_WORD;
									DeviceDataHed[j].DevCnt		= 1;
									iDevDataPosition += 2;
								}else
									j--;
								memset(DevName,0x00,sizeof(DevName));
								j++;
								DevName[0] = DeviceToIndexSet(0,chDev1Key);
								if(GetDevCntTime(0,DevName, (char *)DeviceDataHed[j].DevName)==0)
								{
									
									/* RET ���� Bit */
									DeviceDataHed[j].DevName[1] = 0;
									DeviceDataHed[j].DevData	= &DeviceData[iDevDataPosition];
									DeviceDataHed[j].DevAddress = ReturnDevAddress(i);
									DeviceDataHed[j].DevFlag	= DEVICE_BIT;
									DeviceDataHed[j].DevCnt		= 1;
									iDevDataPosition += 1;
								}else
									j--;
								/*************************************/

							/*	j++; */
								/* ����ġ ���� word */
							/*	DeviceDataHed[j].DevName[0] = (char)BuffDip[i].cDev_Now;
								DeviceDataHed[j].DevName[1] = 0;
								DeviceDataHed[j].DevData	= &DeviceData[iDevDataPosition];
								DeviceDataHed[j].DevAddress = BuffDip[i].iDev_NowNum;
								DeviceDataHed[j].DevFlag	= 1;
								DeviceDataHed[j].DevCnt		= 1;
								iDevDataPosition += 2;*/
/*								iPlus = j;		*/
								break;
						}
						j++;

					}
				}
				DeviceCnt = j;
			/*	for(i = 0; i < DeviceCnt; i++)
					PLCReadNoWait(&DeviceDataHed[i]);*/
				OffSignal(SGN_PLC,1);
				Delay(100);
				SystemDevNoClearEntry();			/* */
				PlcDevInitRead(0);
				OnSignal(SGN_PLC,1);
			}
			/* E ����̽��� ���� �ϱ�E���ؼ� leesi 5/13 */

			if(iEscFlag == 1 || (iEscFlag == 2 && BuffDip[0].cDev_Now != -1))
			{

				DeviceMonitorDisplayData(&inowdev);		/* 20090703 */
/*				
				if(BuffDip[0].cDev_Now != -1)
					DotTextOut(((NowDip.iDev_NowPoint+1)%2==0 ? 100 : 0),NLine_2+(((NowDip.iDev_NowPoint)/2)*18),Dspname[LCDCONTRAST].chName[Set.iLang][4],1,1, NON_TRANS, T_WHITE, T_BLACK);		
*/


				for(i=0;i<inowdev;i++){
/*					strcpy(chBuffData[i],DeviceDataHed[i].DevData);*/
					if(DeviceDataHed[i].DevFlag == DEVICE_BIT){
						memcpy(chBuffData[i],DeviceDataHed[i].DevData,DeviceDataHed[i].DevCnt);
					}else{
						memcpy(chBuffData[i],DeviceDataHed[i].DevData,DeviceDataHed[i].DevCnt*2);
					}
				}
			}/* leesi 5.14 */

			if(iEscFlag != 3)
			{
				DrawLcdBank1();	
				iEscFlag = 3;
			}


/* ksc050513 */
			for(i=0;i<inowdev;i++){
/*				if(strcmp(chBuffData[i],DeviceDataHed[i].DevData))*/
				if(DeviceDataHed[i].DevFlag == DEVICE_BIT){
/* 070206					if(strncmp(chBuffData[i],DeviceDataHed[i].DevData,DeviceDataHed[i].DevCnt) != 0)*/
					if(memcmp(chBuffData[i],DeviceDataHed[i].DevData,DeviceDataHed[i].DevCnt) != 0)
					{
						iEscFlag = 1;
					}
				}else{
/* 070206					if(strncmp(chBuffData[i],DeviceDataHed[i].DevData,DeviceDataHed[i].DevCnt*2) != 0)*/
					if(memcmp(chBuffData[i],DeviceDataHed[i].DevData,DeviceDataHed[i].DevCnt*2) != 0)
					{
						iEscFlag = 1;
					}

				}
			}
		
			Delay(50);
		} 

	} /*  end while  */

/*ksc20040513*/
	KerRepeatFlag = 0;
/*ksc20040513*/
	return;
}
void vDeviceDispFormDraw(void)
{
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;
	

	AreaClear(0,0,GAMEN_X_SIZE-1,GAMEN_Y_SIZE-1,0);
	
	/*  DEV.	 */		
	CenterDisplay(GAMEN_START_X+2,GAMEN_START_Y+62,GAMEN_START_X+48,GAMEN_START_Y+78,Dspname[DEVICE_MONITORING].chName[Set.iLang][0]);

	/*  SET	 */		
	CenterDisplay(GAMEN_START_X+51,GAMEN_START_Y+62,GAMEN_START_X+97,GAMEN_START_Y+78,Dspname[DEVICE_MONITORING].chName[Set.iLang][1]);

	/*  ON	 */		
	CenterDisplay(GAMEN_START_X+100,GAMEN_START_Y+62,GAMEN_START_X+146,GAMEN_START_Y+78,Dspname[DEVICE_MONITORING].chName[Set.iLang][2]);

	/*  OFF	 */		
	CenterDisplay(GAMEN_START_X+149,GAMEN_START_Y+62,GAMEN_START_X+195,GAMEN_START_Y+78,Dspname[DEVICE_MONITORING].chName[Set.iLang][3]);

	/* TITLE �� Form */
	DefaultFormDisplay(4 , Dspname[DEVICE_MONITORING].chTitle[Set.iLang]);

//	CenterDisplay(GAMEN_START_X+210,GAMEN_START_Y+43,GAMEN_START_X+238,GAMEN_START_Y+58, "Dec");		/* 20090703 */
	if(HexDecTogleFlag == 1){
		CenterDisplay(GAMEN_START_X+210,GAMEN_START_Y+43,GAMEN_START_X+238,GAMEN_START_Y+58, "Hex");				/* 20090703 */
	}else{
		CenterDisplay(GAMEN_START_X+210,GAMEN_START_Y+43,GAMEN_START_X+238,GAMEN_START_Y+58, "Dec");				/* 20090703 */				
	}

	RectAngleOut(GAMEN_START_X+2,GAMEN_START_Y+61,GAMEN_START_X+48,GAMEN_START_Y+78,&RECParam);						/* DEV						 */
	RectAngleOut(GAMEN_START_X+51,GAMEN_START_Y+61,GAMEN_START_X+97,GAMEN_START_Y+78,&RECParam);					/* SET						 */
	RectAngleOut(GAMEN_START_X+100,GAMEN_START_Y+61,GAMEN_START_X+146,GAMEN_START_Y+78,&RECParam);					/* ON						 */
	RectAngleOut(GAMEN_START_X+149,GAMEN_START_Y+61,GAMEN_START_X+195,GAMEN_START_Y+78,&RECParam);					/* OFF						 */
}
/* ****************************************************************************** */
/*  �� �� �� : vDeviceDisplay()													 */
/*  ��    �� : DeviceMoniter�� ���� �����͸� Display �ϴ� ��					 */
/*  ��    �� : inowdev(����̽� ���� ����)										 */
/*  ��    �� : 																	 */
/*  �� �� �� : 2002�� 4�� 2�� (ȭ)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void	vDeviceDisplay(short  i, int inowdev)/* �ڵ�Ex,y,m...),��ȣ,�¿���,�� */
{	
/* 071108	char	cCodeData[3];*/
	char	cCodeData[10];
	char	chDsp_buff[30];
/* 071108	char	chDsp_buff1[10];*/
	char	chDsp_buff1[30];
	char	cDev_Rst[10];
/* 071108	char	chCur[6];	*/
	char	chCur[10];
	int		iNum;
	int		iOnOff;
	long	iValue;
	int		iRst;
	int		iSet;
	short	k;
	short	iInfo;
	int	iReturnData;
	int iAdd;
	int	UbUwFlag;		/* 040508 */


	int		iX;
	int		iY;

	/* leesi 0808 */
	_LINE_INFO param;
	_LINE_INFO param_Zero;

	param_Zero.iLineColor = WHITE;
	param_Zero.iLineStyle = NO_LINE;

	param.iLineColor = WHITE;
	param.iLineStyle = SOLID_LINE;
	/* leesi 0808 */
	iInfo	= 0;
	iOnOff	= 0;
	iValue	= 0;
	iRst	= 0;
	iSet	= 0;
	iX		= 0;
	iY		= 0;

	iNum	= BuffDip[i].iDev_NowNum;                   /* DevAddress */
	strcpy(cCodeData,Device_Name[BuffDip[i].cDev_Now]);
/*	ReturnDeviceName(&(BuffDip[i].cDev_Now),cCodeData,1);*/
	if((memcmp(cCodeData,"UB",2) == 0) || (memcmp(cCodeData,"UW",2) == 0)){
		UbUwFlag= 1;		/* 040508 */
	}else{
		UbUwFlag= 0;		/* 040508 */
	}

	if(BuffDip[i].iDev_Type == 1)						/* Bit */
	{	
		iOnOff = (int)iReturn_DevValue(0, inowdev);
	}
	else if(BuffDip[i].iDev_Type == 2 || BuffDip[i].iDev_Type == 3)	 /* Word */
	{	
		iValue = iReturn_DevValue(1, inowdev);
	}
	else if(BuffDip[i].iDev_Type == 4)			/* Bit + Word */
	{												
		iOnOff =  iReturn_DevValue(0, inowdev+1);	/* ���� ǥ��  */
		iRst = 0;
		if(RetrunSetVal(BuffDip[i].iDev_NowNum))
		{
			iSet = iReturn_DevValue(1, inowdev+2);	/* SET value  */
			itoa(iSet,chCur,10);
		}
		else
		{
			sprintf(chCur,"******");
		}
		iValue = iReturn_DevValue(1, inowdev);
	}
	
	if(BuffDip[i].iDev_Type == 4)			/* Bit + Word */
	{	
		
		if(iRst==1 && PlcConnectFlag != 0){/* (iRst==1 || iValue == 0) && PlcConnectFlag != 0 */
/* KSC20070222 */
/*			sprintf(cDev_Rst,"��");  */
			sprintf(cDev_Rst,"\xff\x05");  
		}else{
			sprintf(cDev_Rst,"  ");
		}
		if(BuffDip[2].iDev_NowPoint == 0)
		{


/*
			sprintf(chDsp_buff1,"%s%4d",cCodeData,iNum);	 ù��° ���� �� 
			if(PlcConnectFlag == 0)
				sprintf(chDsp_buff,"CUR[      ]");	 ù��° ���� �� PLC ���� �� 
			else
				sprintf(chDsp_buff,"CUR[%6d]",iValue);	 ù��° ���� ��  PLC ���� �� 			

			DotTextOut(17,NLine_2,chDsp_buff1,1,1, TRANS, T_WHITE, T_BLACK);	
			DotTextOut(110,NLine_2,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	

			LineOut(69, 33, 73, 33,&param);			  ��ȣǥ�� ����  
			LineOut(73, 26, 73, 40,&param);
			LineOut(80, 26, 80, 40,&param);
			LineOut(80, 33, 84, 33,&param);
*/
/*ksc20040524*/
/* 20080822 �� %5d���� ��Ȯ�� �ʿ�, ����Ʈ �������Ͽ��� bit/word ������ Ȯ�� */ 
			sprintf(chDsp_buff1,"%s %5d",cCodeData,iNum);	/* ù��° ���� �� */
			if(PlcConnectFlag == 0)
				sprintf(chDsp_buff,"CUR[      ]");	/* ù��° ���� �� PLC ���� �� */
			else
				sprintf(chDsp_buff,"CUR[%6d]",iValue);	/* ù��° ���� ��  PLC ���� �� */			

			DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+NLine_2,chDsp_buff1,1,1, TRANS, T_WHITE, T_BLACK);	
			DotTextOut(GAMEN_START_X+108,GAMEN_START_Y+NLine_2,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);

			LineOut(GAMEN_START_X+77, GAMEN_START_Y+33, GAMEN_START_X+81, GAMEN_START_Y+33,&param);			/*  ��ȣǥ�� ����  */
			LineOut(GAMEN_START_X+81, GAMEN_START_Y+26, GAMEN_START_X+81, GAMEN_START_Y+40,&param);
			LineOut(GAMEN_START_X+88, GAMEN_START_Y+26, GAMEN_START_X+88, GAMEN_START_Y+40,&param);
			LineOut(GAMEN_START_X+88, GAMEN_START_Y+33, GAMEN_START_X+92, GAMEN_START_Y+33,&param);			


/*ksc20040524*/
/*
			if(PlcConnectFlag != 0){
				if(iOnOff!=0)	 ON ǥ�� 
				{
					for(k=0;k<4;k++)
						LineOut(75+iX+k, 27+iY, 75+iX+k, 39+iY,&param);
				}else			 OFF ǥ�� 
				{
					for(k=0;k<4;k++)
						LineOut(75+iX+k, 27+iY, 75+iX+k, 39+iY,&param_Zero);
				}
			}
			if(PlcConnectFlag == 0)
			{
				memset(chCur,0x00,sizeof(chCur));
			}
*/
/*ksc20040524*/
			if(PlcConnectFlag != 0){
				if(iOnOff!=0)	/* ON ǥ�� */
				{
					for(k=0;k<4;k++)
						LineOut(83+iX+k, 27+iY, 83+iX+k, 39+iY,&param);
				}else			/* OFF ǥ�� */
				{
					for(k=0;k<4;k++)
						LineOut(83+iX+k, 27+iY, 83+iX+k, 39+iY,&param_Zero);
				}
			}
			if(PlcConnectFlag == 0)
			{
				memset(chCur,0x00,sizeof(chCur));
			}
/*ksc20040524*/




/*
			sprintf(chDsp_buff1,"RST-(%s)",cDev_Rst);				
			sprintf(chDsp_buff,"SET[%6s]",chCur);				
			DotTextOut(32,NLine_2+18,chDsp_buff1,1,1, TRANS, T_WHITE, T_BLACK);	
			DotTextOut(110,NLine_2+18,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	
*/
/*ksc20040518*/
			sprintf(chDsp_buff1,"RST - (%s)",cDev_Rst);				
			sprintf(chDsp_buff,"SET[%6s]",chCur);				
			DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+NLine_2+18,chDsp_buff1,1,1, TRANS, T_WHITE, T_BLACK);	
			DotTextOut(GAMEN_START_X+108,GAMEN_START_Y+NLine_2+18,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	
/*ksc20040518*/
		}
		else
		{
/*
			sprintf(chDsp_buff1,"RST-(%s)",cDev_Rst);				
			sprintf(chDsp_buff,"SET[%6s]",chCur);		
			DotTextOut(32,NLine_2,chDsp_buff1,1,1, TRANS, T_WHITE, T_BLACK);	
			DotTextOut(110,NLine_2,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	
*/			
/*ksc20040518*/
			sprintf(chDsp_buff1,"RST - (%s)",cDev_Rst);				
			sprintf(chDsp_buff,"SET[%6s]",chCur);		
			DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+NLine_2,chDsp_buff1,1,1, TRANS, T_WHITE, T_BLACK);	
			DotTextOut(GAMEN_START_X+108,GAMEN_START_Y+NLine_2,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	
/*ksc20040518*/
		}

	}
	else if(BuffDip[i].iDev_Type == 2 || BuffDip[i].iDev_Type == 3)	 /* Word */
	{
		if(strstr(cCodeData,"16") || strstr(cCodeData,"32")){
/*
			sprintf(chDsp_buff1,"%c%4d",cCodeData[0],iNum);
*/

/*ksc20050526*/
			iAdd = BuffDip[i].cDev_Now;
			iInfo = (Device_iType[iAdd]) & 0x000F;
			iReturnData= SetPLCUsrAddr(iInfo,iNum,(unsigned char)DeviceToIndexSet(1,Device_Name[iAdd]),1);

			if(cCodeData[1] == '1' || cCodeData[1] == '3'){
				sprintf(chDsp_buff1,"%c %5X",cCodeData[0],iReturnData);
			}
			else{
				sprintf(chDsp_buff1,"%c%c%5X",cCodeData[0],cCodeData[1],iReturnData);
			}

/*ksc20050526*/

		}else{
			iAdd = BuffDip[i].cDev_Now;
			iInfo = (Device_iType[iAdd]) & 0x000F;
			iReturnData= SetPLCUsrAddr(iInfo,iNum,(unsigned char)DeviceToIndexSet(1,Device_Name[iAdd]),1);
			sprintf(chDsp_buff1,"%s %5X",cCodeData,iReturnData);				
		}

		if(BuffDip[i].iDev_Type == 3)		/* 32Bit(word)*/
		{
			if(PlcConnectFlag != 0){
				if(HexDecTogleFlag){
					sprintf(chDsp_buff,"CUR[ 0x%08X]",iValue);		/* 20090703 */
				}else{
					sprintf(chDsp_buff,"CUR[%11d]",iValue);		/* 20090703 */
				}
			}else{
				if(UbUwFlag == 0){	/* 040508 */
					sprintf(chDsp_buff,"CUR[           ]");
				}else{		/* UB,UW */
					if(HexDecTogleFlag){
						sprintf(chDsp_buff,"CUR[ 0x%08X]",iValue);		/* 20090703 */
					}else{
						sprintf(chDsp_buff,"CUR[%11d]",iValue);		/* 20090703 */
					}
				}
			}
			iX = 53;
		}
		else
		{
			if(PlcConnectFlag != 0){
				if(HexDecTogleFlag){
					sprintf(chDsp_buff,"CUR[0x%04X]",iValue);		/* 20090703 */
				}else{
					sprintf(chDsp_buff,"CUR[%6d]",iValue);		/* 20090703 */
				}
			}else{
				if(UbUwFlag == 0){	/* 040508 */
					sprintf(chDsp_buff,"CUR[      ]");
				}else{		/* UB,UW */
					if(HexDecTogleFlag){
						sprintf(chDsp_buff,"CUR[0x%04X]",iValue);		/* 20090703 */
					}else{
						sprintf(chDsp_buff,"CUR[%6d]",iValue);		/* 20090703 */
					}
				}
			}
			iX = 93;
		}
/*�� ��ȣǥ�ð���
		DotTextOut(17,(NLine_2+(iScreenNum > 2 ? 18:0)),chDsp_buff1,1,1, TRANS, T_WHITE, T_BLACK);	
		DotTextOut(17+iX,(NLine_2+(iScreenNum > 2 ? 18:0)),chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	
*/
/*ksc20040512 ��ġ���� */
		DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+(NLine_2+(iScreenNum > 2 ? 18:0)),chDsp_buff1,1,1, TRANS, T_WHITE, T_BLACK);	
		DotTextOut(GAMEN_START_X+15+iX,GAMEN_START_Y+(NLine_2+(iScreenNum > 2 ? 18:0)),chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);	
/*ksc20040512 */
	
	
	}
	else if(BuffDip[i].iDev_Type == 1)						/* Bit */
	{

		switch(iScreenNum)	
		{
			case	1:
				iX = 0;
				iY = 0;
				break;
			case	2:
				iX = 100;
				iY = 0;
				break;
			case	3:
				iX = 0;
				iY = 18;
				break;
			case	4:
				iX = 100;
				iY = 18;
				break;
		}
/*
		if(iOnOff!=0)	 ON ǥ�� 
		{
			for(k=0;k<4;k++)
				LineOut(86+iX+k, 27+iY, 86+iX+k, 39+iY,&param);
		}else			 OFF ǥ�� 
		{
			for(k=0;k<4;k++)
				LineOut(86+iX+k, 27+iY, 86+iX+k, 39+iY,&param_Zero);
		}
		
		LineOut(69+iX, 33+iY, 73+iX, 33+iY,&param);	  ��ȣǥ�� ����  
		LineOut(73+iX, 26+iY, 73+iX, 40+iY,&param);
		LineOut(80+iX, 26+iY, 80+iX, 40+iY,&param);
		LineOut(80+iX, 33+iY, 84+iX, 33+iY,&param);
*/
/*ksc20040512 ��ġ���� */
		if(iOnOff!=0)	/* ON ǥ�� */
		{
			for(k=0;k<4;k++)
				LineOut(83+iX+k, 27+iY, 83+iX+k, 39+iY,&param);
		}else			/* OFF ǥ�� */
		{
			for(k=0;k<4;k++)
				LineOut(83+iX+k, 27+iY, 83+iX+k, 39+iY,&param_Zero);
		}

		LineOut(GAMEN_START_X+77+iX, GAMEN_START_Y+33+iY, GAMEN_START_X+81+iX, GAMEN_START_Y+33+iY,&param);			/*  ��ȣǥ�� ����  */
		LineOut(GAMEN_START_X+81+iX, GAMEN_START_Y+26+iY, GAMEN_START_X+81+iX, GAMEN_START_Y+40+iY,&param);
		LineOut(GAMEN_START_X+88+iX, GAMEN_START_Y+26+iY, GAMEN_START_X+88+iX, GAMEN_START_Y+40+iY,&param);
		LineOut(GAMEN_START_X+88+iX, GAMEN_START_Y+33+iY, GAMEN_START_X+92+iX, GAMEN_START_Y+33+iY,&param);
/*ksc20040512*/
		iAdd = BuffDip[i].cDev_Now;
		iInfo = (Device_iType[iAdd]) & 0x000F;
		iReturnData= SetPLCUsrAddr(iInfo,iNum,(unsigned char)DeviceToIndexSet(0,Device_Name[iAdd]),0);

/*
		sprintf(chDsp_buff,"%s %03X",cCodeData,iReturnData);				
		DotTextOut(17+iX,NLine_2+iY,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
*/
/*ksc20040518 ����̽��� �� ��巹�� ��ġ���� */
//		sprintf(chDsp_buff,"%s %05X",cCodeData,iReturnData);				
//		sprintf(chDsp_buff,"%s%7X",cCodeData,iReturnData);	//070822 Zerosupless
//		DotTextOut(GAMEN_START_X+4+iX,GAMEN_START_Y+NLine_2+iY,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
		sprintf(chDsp_buff,"%s",cCodeData);				
		DotTextOut(3+iX,NLine_2+iY,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
		sprintf(chDsp_buff,"%7X",iReturnData);				
		DotTextOut(20+iX,NLine_2+iY,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
/*ksc20040518*/
	}
}
/* ****************************************************************************** */
/*  ��E��E��E: vUpDisplay()														 */
/*  ��E   �� : UP �� ȭ�� ��ȭ												 */
/*  ��    �� :																	 */
/*  ÁE   �� : 																	 */
/*  �� �� �� : 2002��E4��E8��													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
enum{CHK_OFF,CHK_ON,CHK_NEG};	//070828
int vUpDisplay(void)
{
	int		iNowValue;
	int		j;
	int		iEscFlag;
	int     iRetVal;
/* 20071109	    char	chType[3]; */
	char	chType[10];
/* 20071109 	char	chData[10]; */
	char	chData[20]; 
	short	iFlag;
	int		DifFlag;	//070828
	int		iDev_NowNum;				

	memset(chType,0x00,sizeof(chType));
	memset(chData,0x00,sizeof(chData));
	iEscFlag	= 0;
	iFlag		= 0;
	DifFlag= CHK_OFF;	//070828
	iNowValue = NowDip.iDev_NowPoint;
	if((iNowValue > 0 || BuffDip[0].iDev_NowNum > 0) && !(BuffDip[0].iDev_NowNum == 1 && BuffDip[0].iDev_Type == 3))
	{

	if(BuffDip[0].iDev_NowPoint != 0)
	{

		if(iNowValue == 0 || BuffDip[0].iDev_NowPoint == 4)
		{
/*			
			if(iNowValue == 0){
				ReturnDeviceName(&(BuffDip[0].cDev_Now), chType,1);
				itoa(BuffDip[0].iDev_NowNum-1,chData,10);
				vErrorBox(chType,chData,0);
			}
*/
			if(BuffDip[0].iDev_NowPoint == 4 && (iNowValue == 0 || iNowValue ==2))		/* ��E?ȭ���� ������ �� */
			{
				if(BuffDip[2].iDev_NowPoint == 0){
					/* 040116 */
					ReturnDeviceName(&(BuffDip[0].cDev_Now), chType,1);
					itoa(BuffDip[0].iDev_NowNum-1,chData,10);
					iRetVal = vErrorCheck(chType,chData,_UP);
					if(iRetVal == 2)
					{
						BuffDip[0].iDev_NowNum = gatoi(chData);
					}else{
						BuffDip[0].iDev_NowNum = BuffDip[0].iDev_NowNum - 1;
					}
				}
					
				for(j=1;j<4;j++)				/* ȭ����E��?�翁Eϱ�E������ ���۸� ���������. */
				{
					BuffDip[j].iDev_NowPoint = 0;
					BuffDip[j].iDev_NowNum = 0;
					BuffDip[j].cDev_Now = -1;
				}
				NowDip.cDev_Now = BuffDip[0].cDev_Now;		/*  ȭ��E��?���� ������ ����  */
				NowDip.iDev_NowNum = BuffDip[0].iDev_NowNum;		/*  ����E������ �Ϳ� ��E?������ ������E�ִ´�. */
				NowDip.iDev_NowPoint = 0;							/*  ���õǾ�?E��ġ */
				NowDip.iDev_Type = BuffDip[0].iDev_Type;
			}
			else if(BuffDip[0].iDev_Type == 4 && 
				BuffDip[2].iDev_Type == 1 &&
				BuffDip[3].iDev_Type == 1 &&
				NowDip.iDev_NowPoint == 3)
			{
				NowDip.cDev_Now = BuffDip[iNowValue-1].cDev_Now;
				NowDip.iDev_NowNum = BuffDip[iNowValue-1].iDev_NowNum;
				NowDip.iDev_NowPoint = iNowValue-1;
				iEscFlag = 2;
				NowDip.iDev_Type = BuffDip[iNowValue-1].iDev_Type;
			}
			else
			{
				if(!(BuffDip[2].iDev_NowPoint == 2 && NowDip.iDev_NowPoint == 2 ))
				{
					if(NowDip.iDev_NowPoint == 0)
					{
						iRetVal = 0;
						if(NowDip.iDev_Type == 1)
						{
							ReturnDeviceName(&(BuffDip[0].cDev_Now), chType,1);
							itoa(BuffDip[0].iDev_NowNum-1,chData,10);
							iRetVal = vErrorCheck(chType,chData,_UP);
							iDev_NowNum= BuffDip[0].iDev_NowNum-1;
							if(iRetVal!=-1 && (BuffDip[0].iDev_NowNum-1 != 0))
							{
								/***************************************/
								if(iRetVal == 2){		/* 040114 */
									/* Set for NowDip.iDev_NowNum- 1 */
									NowDip.iDev_NowNum = gatoi(chData)+ 1;
									DifFlag= CHK_NEG;	//070828
								}
								/***************************************/
								ReturnDeviceName(&(BuffDip[0].cDev_Now), chType,1);
								itoa(BuffDip[0].iDev_NowNum-2,chData,10);
								iRetVal = vErrorCheck(chType,chData,_UP);
								if(iRetVal == -1){
									iRetVal = 128;
								}
								if((iRetVal == 2) && (DifFlag == CHK_OFF)){		/* 070828 */
									/* Set for NowDip.iDev_NowNum- 1 */
									NowDip.iDev_NowNum = gatoi(chData)+ 2;
									DifFlag= CHK_ON;	//070828
								}
							}
						}
						else
						{
							ReturnDeviceName(&(BuffDip[0].cDev_Now), chType,1);
							if((Device_iType[BuffDip[0].cDev_Now] & 0x000f) == 0x0009)
							{
								itoa(BuffDip[0].iDev_NowNum-16,chData,10);
								iFlag = 1;
							}
							else
								itoa(BuffDip[0].iDev_NowNum-1,chData,10);
							iRetVal = vErrorCheck(chType,chData,_UP);
							if(iRetVal == 2)
							{
								iFlag = 2;
								NowDip.iDev_NowNum = gatoi(chData);
							}

						}
						if(iRetVal == -1)
						{
 							return iEscFlag;
						}
					}
					for(j=0;j<2;j++)
					{
						BuffDip[j+2].cDev_Now = BuffDip[j].cDev_Now;
						BuffDip[j+2].iDev_NowNum = BuffDip[j].iDev_NowNum;
						BuffDip[j+2].iDev_NowPoint = BuffDip[j].iDev_NowPoint;
						BuffDip[j+2].iDev_Type = BuffDip[j].iDev_Type;
					}
				}
				if(BuffDip[0].iDev_NowPoint == 1)						/*  ȭ���� 1/4�� ǥ���� ���(bit) */
				{
					if(BuffDip[2].iDev_NowNum == 1 || iEscFlag == 128)
					{
						BuffDip[0].iDev_NowNum = NowDip.iDev_NowNum -1;
						BuffDip[1].cDev_Now = -1;
						BuffDip[1].iDev_NowNum = 0;
						BuffDip[1].iDev_NowPoint = 0;
						NowDip.iDev_NowNum = NowDip.iDev_NowNum - 1;		/*  ����E������ �Ϳ� ��E?������ ������E�ִ´�. */
						NowDip.iDev_NowPoint = 0;							/*  ���õǾ�?E��ġ */
					}
					else
					{
						for(j=2;j>0;j--)
						{
							BuffDip[j-1].cDev_Now = NowDip.cDev_Now;
							NowDip.iDev_NowNum = NowDip.iDev_NowNum - 1;
							BuffDip[j-1].iDev_NowNum = NowDip.iDev_NowNum;
							BuffDip[j-1].iDev_Type = NowDip.iDev_Type;		/* 061024 */
						}
						if(DifFlag != CHK_ON){	//070828
							NowDip.iDev_NowNum = NowDip.iDev_NowNum + 1;		/*  ���� ������ �Ϳ� ��E?������ ������ �ִ´�. */
						}else{
							NowDip.iDev_NowNum = iDev_NowNum;		/*  ���� ������ �Ϳ� ��E?������ ������ �ִ´�. */
							BuffDip[1].iDev_NowNum = iDev_NowNum;
						}
						NowDip.iDev_NowPoint = 1;							/*  ���õǾ�?E��ġ */
					}
				}
				else														/*  ȭ���� 1/2�� ǥ���� ���(word) */
				{
					if(BuffDip[0].iDev_Type == 3)
					{
						BuffDip[0].iDev_NowNum = NowDip.iDev_NowNum - 2;
						NowDip.iDev_NowNum = NowDip.iDev_NowNum - 2;		/*  ���� ������ �Ϳ� ���� ������ ������ �ִ´�. */

					}
					else
					{
						if(iFlag == 0)
						{
							BuffDip[0].iDev_NowNum = NowDip.iDev_NowNum - 1;
							NowDip.iDev_NowNum = NowDip.iDev_NowNum - 1;		/*  ���� ������ �Ϳ� ���� ������ ������ �ִ´�. */
						}else if(iFlag == 1) /* 16 */
						{
							BuffDip[0].iDev_NowNum = NowDip.iDev_NowNum - 16;
							NowDip.iDev_NowNum = NowDip.iDev_NowNum - 16;		/*  ���� ������ �Ϳ� ���� ������ ������ �ִ´�. */
						}else				/* �߰��� ������� ��� */
						{
							BuffDip[0].iDev_NowNum = NowDip.iDev_NowNum;
						}
					}
						NowDip.iDev_NowPoint = 0;	
				}
			}
		}
		else if(iNowValue == 1 || iNowValue == 3)
		{
			NowDip.cDev_Now = BuffDip[iNowValue-1].cDev_Now;
			NowDip.iDev_NowNum = BuffDip[iNowValue-1].iDev_NowNum;
			NowDip.iDev_NowPoint = iNowValue-1;
			NowDip.iDev_Type = BuffDip[iNowValue-1].iDev_Type;

			iEscFlag = 2;
		}
		else 
		{
			if(BuffDip[1].iDev_NowPoint != 0)
			{
				NowDip.cDev_Now = BuffDip[1].cDev_Now;
				NowDip.iDev_NowNum = BuffDip[1].iDev_NowNum;
				NowDip.iDev_NowPoint = 1;
				NowDip.iDev_Type = BuffDip[1].iDev_Type;
				iEscFlag = 2;
			}
			else
			{
				NowDip.cDev_Now = BuffDip[0].cDev_Now;
				NowDip.iDev_NowNum = BuffDip[0].iDev_NowNum;
				NowDip.iDev_NowPoint = 0;
				NowDip.iDev_Type = BuffDip[0].iDev_Type;
				iEscFlag = 2;
			}
		}
	}
	}
	return iEscFlag;
}
/* ****************************************************************************** */
/*  ��E��E��E: vDownDisplay()													 */
/*  ��E   �� : DOWN�� ȭ�� ��ȭ 												 */
/*  ��    �� :																	 */
/*  ÁE   �� : 																	 */
/*  �� �� �� : 2002��E4��E8��													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
int vDownDisplay(void)
{
	int		iNowValue;

/* 20071109	    char	chType[3]; */
	char	chType[10];
/* 20071109 	char	chData[10]; */
	char	chData[20]; 
	
	int		iEscFlag;
//	short	iFlag;

	iEscFlag = 0;
//	iFlag = 0;
	iNowValue = NowDip.iDev_NowPoint;

	memset(chType,0,sizeof(chType));
	if(BuffDip[0].iDev_NowPoint != 0)
	{
		if(iNowValue == 0)
		{
			if(BuffDip[0].iDev_NowPoint == 4)						
			{
				ReturnDeviceName(&(BuffDip[0].cDev_Now), chType,1);
				itoa(BuffDip[0].iDev_NowNum+1,chData,10);
				vErrorBox(chType,chData,0);
			}
			else if(BuffDip[0].iDev_NowPoint == 2)
			{
				if(BuffDip[2].iDev_NowPoint==0)
				{
					ReturnDeviceName(&(BuffDip[0].cDev_Now), chType, 1);
					if(BuffDip[0].iDev_Type==3)
						itoa(BuffDip[0].iDev_NowNum+2,chData,10);	
					else if((Device_iType[BuffDip[0].cDev_Now] & 0x000f) == 0x0009)
						itoa(BuffDip[0].iDev_NowNum+16,chData,10);
					else
						itoa(BuffDip[0].iDev_NowNum+1,chData,10);
					vErrorBox(chType,chData,0);
				}
				else
				{
					NowDip.cDev_Now = BuffDip[2].cDev_Now;
					NowDip.iDev_NowNum = BuffDip[2].iDev_NowNum;
					NowDip.iDev_NowPoint = 2;
					NowDip.iDev_Type = BuffDip[2].iDev_Type;
					iEscFlag = 2;
				}
			}
			else
			{
				if(BuffDip[1].iDev_NowPoint==0)
				{
					if(BuffDip[2].iDev_NowPoint!=0)
					{
						NowDip.cDev_Now = BuffDip[2].cDev_Now;
						NowDip.iDev_NowNum = BuffDip[2].iDev_NowNum;
						NowDip.iDev_NowPoint = 2;
						NowDip.iDev_Type = BuffDip[2].iDev_Type;
					}
					else
					{
						ReturnDeviceName(&(BuffDip[0].cDev_Now), chType, 1);
						itoa(BuffDip[0].iDev_NowNum+1,chData,10);
						vErrorBox(chType,chData,0);
					}
				}
				else
				{
					NowDip.cDev_Now = BuffDip[1].cDev_Now;
					NowDip.iDev_NowNum = BuffDip[1].iDev_NowNum;
					NowDip.iDev_NowPoint = 1;
					NowDip.iDev_Type = BuffDip[1].iDev_Type;

				}
			}
		}
		else if(iNowValue == 1)
		{
			if(BuffDip[2].iDev_NowPoint==0)
			{
				ReturnDeviceName(&(BuffDip[1].cDev_Now), chType, 1);
				itoa(BuffDip[1].iDev_NowNum+1,chData,10);
				vErrorBox(chType,chData,0);
			}
			else
			{
				NowDip.cDev_Now = BuffDip[2].cDev_Now;
				NowDip.iDev_NowNum = BuffDip[2].iDev_NowNum;
				NowDip.iDev_NowPoint = 2;
				NowDip.iDev_Type = BuffDip[2].iDev_Type;
			}
		}
		else if(iNowValue == 2)
		{

			if(BuffDip[2].iDev_NowPoint == 2)
			{
				ReturnDeviceName(&(BuffDip[2].cDev_Now), chType, 1);
				if(BuffDip[2].iDev_Type == 3)
					itoa(BuffDip[2].iDev_NowNum+2,chData,10);				
				else if((Device_iType[BuffDip[2].cDev_Now] & 0x000f) == 0x0009)
					itoa(BuffDip[2].iDev_NowNum+16,chData,10);
				else
					itoa(BuffDip[2].iDev_NowNum+1,chData,10);

				vErrorBox(chType,chData,0);
			}
			else
			{
				if(BuffDip[3].iDev_NowPoint==0)
				{
				ReturnDeviceName(&(BuffDip[2].cDev_Now), chType, 1);
					if(BuffDip[2].iDev_Type==3)
						itoa(BuffDip[2].iDev_NowNum+2,chData,10);				
					else
						itoa(BuffDip[2].iDev_NowNum+1,chData,10);
					vErrorBox(chType,chData,0);
				}
				else
				{
					NowDip.cDev_Now = BuffDip[3].cDev_Now;
					NowDip.iDev_NowNum = BuffDip[3].iDev_NowNum;
					NowDip.iDev_NowPoint = 3;
					NowDip.iDev_Type = BuffDip[3].iDev_Type;					
				}
			}
		}
		else
		{
			ReturnDeviceName(&(BuffDip[3].cDev_Now), chType, 1);
			itoa(BuffDip[3].iDev_NowNum+1,chData,10);
			vErrorBox(chType,chData,0);
		}
	}
	return iEscFlag;
}
/* ****************************************************************************** */
/*  ��E��E��E: vOnCheck()														 */
/*  ��E   �� : -||-    -->    -|��|-												 */
/*  ��    �� :																	 */
/*  ÁE   �� : 																	 */
/*  �� �� �� : 2002��E4��E9��													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
void	vOnCheck(void)
{

	if(BuffDip[0].iDev_NowPoint != 0)
	{
		switch(NowDip.iDev_Type)								/* ��ġ�� ��E?On, Off���� �ִ´�. */
		{
			case 1:				
					iReturn_DevValue(2, 1);
					break;
			case 4:
					iReturn_DevValue(4, 1);
					break;
		}
	}
}
/* ****************************************************************************** */
/*  ��E��E��E: vOffCheck()														 */
/*  ��E   �� : -|��|-   -->	 -||-												 */
/*  ��    �� :																	 */
/*  ÁE   �� : 																	 */
/*  �� �� �� : 2002��E4��E9��													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
void	vOffCheck(void)
{

	if(BuffDip[0].iDev_NowPoint != 0)
	{
		switch(NowDip.iDev_Type)								/* �� ��ġ�� ��E?�ִ�E��?�ִ´�. */
		{
			case 1:	
					iReturn_DevValue(2, 0);
					break;

	/*		case 2:
			case 3:
					iReturn_DevValue(3, 0);
					break;	
	*/
			case 4:
					iReturn_DevValue(4, 0);
					break; 
		}
	}
}
/* ****************************************************************************** */
/*  ��E��E��E: vCurSetting()														 */
/*  ��E   �� :																	 */
/*  ��    �� :																	 */
/*  ÁE   �� : 																	 */
/*  �� �� �� : 2002��E4��E9��													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
short	vCurSetting(int *iScreenNo)
{
	int		iLen;
	int		iNum;
	int		iMax;
	int		iMin;
	long	lValue;
//	int		iDataSet;
/* 20071109 	char	cValue[10]; */
	char	cValue[20];
/* 20071109 	char	cValue1[10]; */
	char	cValue1[20];

	int		iTrans;

	lValue = 0;
														/*  �Է¹��� ������ ����  */
	if(NowDip.iDev_Type == 3)
	{
		iMax = 2147483647;
		iMin = -2147483647;
		iLen = 11;
	}
	else
	{
		iMax = 32767;
		iMin = -32768;
		iLen = 6;
	}

	memset(cValue1,0x00,10);
	memset(cValue,0x00,10);
	if(BuffDip[0].iDev_NowPoint != 0)
	{
		switch(NowDip.iDev_Type)								/*  �� ��ġ�� ��E?�ִ�E��?�ִ´�.  */
		{
			case 2:
			case 3:
				lValue = iReturn_DevValue(1, BuffDip[NowDip.iDev_NowPoint].iDev_Count);
				sprintf(cValue,"%d",lValue);
				break;

			case 4:
				itoa(iReturn_DevValue(1,0),cValue,10);
				itoa(iReturn_DevValue(1,2),cValue1,10);   
				break;

			default:
				return 0;
			
		}
		iTrans = iNumInput1(cValue,cValue1,&iLen);
		if(iTrans == DOWN_TRANS || iTrans == UP_TRANS)
		{
			*iScreenNo = iTrans;
		}											/*  0 : ������  1 : �Ʒ�����  2 : setting����.  */
		else
		{
			if(iLen == 1)
				iNum = gatoi(cValue1);
			else
				iNum = gatoi(cValue);
			if((iNum > iMax || iNum < iMin) && NowDip.iDev_Type != 3)								/*  ��E��?����E���� �濁E */
			{
				iCaptionWindow(Dspname[SET_FUNTION].chName[Set.iLang][9],"");			/*  ��ư �ϳ��� �޼���E�ڽ�	 */	
			}
			else if(iLen != 2)											/*  ��E��?�´� �濁E		 */
			{
				switch(NowDip.iDev_Type)								/*  �� ��ġ�� ��E?�ִ�E��?�ִ´�.  */
				{
					case 2:
					case 3:
						iReturn_DevValue(3, iNum);
						break;

					case 4:
						if(iLen==0)										/* ����ġ ������ �濁E*/
							iReturn_DevValue(3, iNum);
						else
						{												/* ����ġ ������ �濁E*/
					/*		if(Set.Pass.iFlag==1)
								iCaptionWindow(Dspname[DEVICE_MONITORING].chName[Set.iLang][5],Dspname[2].chName[Set.iLang][6]);
							else */
								iReturn_DevValue(5, iNum);
						}
						break;
				}
//				iDataSet = iNum;	

				/*  sendmail�� ���� �ؾ���.  */
			}
		}
	}
	return 1;
}
#endif
/****************************************************/
/*	�g�p�v���O��?									*/
/****************************************************/
/* ****************************************************************************** */
/*  ��E��E��E: iReturn_DevValue()														 */
/*  ��E   �� :																	 */
/*  ��    �� :																	 */
/*  ÁE   �� : 																	 */
/*  �� �� �� : 2002��E4��E9��													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
long		iReturn_DevValue(int iType, int iNowNum) /*  */
{	
	long		iRetValue;
	int			iNum;
	
	DEV_DATA	WriteDev;
/* 20071109 	char		wData[4]; */
	char		wData[10];	
/* 20071109 	char		cDataValue[6]; */
	char		cDataValue[20];

	iRetValue = 0;

	memset(wData,0x00,sizeof(wData));
	memset(cDataValue,0x00,sizeof(cDataValue));

	if(iType == 0){				/* Bit �� ��. ��Ʈ ������ŭ ���� */
		if(DeviceDataHed[iNowNum].DevData != NULL){	//2008.11.21
			iRetValue = (unsigned int)DeviceDataHed[iNowNum].DevData[0];
		}
	}else if(iType == 1){		/* Word �� �� */
		if(DeviceDataHed[iNowNum].DevCnt==2){	/* 32��Ʈ. �ѹ��� ǥ���Ҽ� �ִ°� 32��Ʈ�� �ϳ����̹Ƿ� �ѹ��� ���� */
//0624
//			iRetValue =		(((int)DeviceDataHed[iNowNum].DevData[3]) & 0x000000ff) << 24;
//			iRetValue +=	(((int)DeviceDataHed[iNowNum].DevData[2]) & 0x0000ff) << 16;
//			iRetValue +=	(((int)DeviceDataHed[iNowNum].DevData[1]) & 0x00ff) << 8;
//			iRetValue +=	(((int)DeviceDataHed[iNowNum].DevData[0]) & 0xff) ;
			iRetValue =		(((int)DeviceDataHed[iNowNum].DevData[2]) & 0x000000ff) << 24;
			iRetValue +=	(((int)DeviceDataHed[iNowNum].DevData[3]) & 0x0000ff) << 16;
			iRetValue +=	(((int)DeviceDataHed[iNowNum].DevData[0]) & 0x00ff) << 8;
			iRetValue +=	(((int)DeviceDataHed[iNowNum].DevData[1]) & 0xff) ;
		}else{									/* 16��Ʈ. ���� ������ŭ ���� */
			if(BuffDip[NowDip.iDev_NowPoint].iDev_Type != 4){
//061124
//				iRetValue =		(unsigned int)DeviceDataHed[iNowNum].DevData[1] << 8;
//				iRetValue +=	((unsigned int)DeviceDataHed[iNowNum].DevData[0] & 0xff);
				iRetValue =		(unsigned int)DeviceDataHed[iNowNum].DevData[0] << 8;
				iRetValue +=	((unsigned int)DeviceDataHed[iNowNum].DevData[1] & 0xff);
			}else{
				if(iNowNum == 0 || iNowNum == 1){
//061124
//					iRetValue =		(unsigned int)DeviceDataHed[iNowNum].DevData[1] << 8;
//					iRetValue +=	((unsigned int)DeviceDataHed[iNowNum].DevData[0] & 0xff);
					iRetValue =		(unsigned int)DeviceDataHed[iNowNum].DevData[0] << 8;
					iRetValue +=	((unsigned int)DeviceDataHed[iNowNum].DevData[1] & 0xff);
				}
			}
		}
	}else if(iType == 2 || iType == 4){
		iNum = BuffDip[NowDip.iDev_NowPoint].iDev_Count;
		if(iType == 4){
			iNum++;
		}
		WriteDev.DevFlag = DeviceDataHed[iNum].DevFlag;	
		WriteDev.DevName[0] = DeviceDataHed[iNum].DevName[0];
		WriteDev.DevName[1] = DeviceDataHed[iNum].DevName[1];
		WriteDev.DevName[2] = 0x00;
		WriteDev.DevAddress = DeviceDataHed[iNum].DevAddress;
		WriteDev.DevCnt = DeviceDataHed[iNum].DevCnt;
		WriteDev.DevData = wData;
		//061124
//		wData[0] = iNowNum;
//		wData[1] = 0;
		if(DeviceDataHed[iNum].DevFlag == 1){
			wData[1] = iNowNum;
			wData[0] = 0;
		}else{
			wData[0] = iNowNum;
			wData[1] = 0;
		}
		PLCWrite(&WriteDev); 
	}else if(iType == 3 || iType == 5){
		iNum = BuffDip[NowDip.iDev_NowPoint].iDev_Count;
		if(iType == 5){
			iNum =+ 2;
		}
		WriteDev.DevFlag = DeviceDataHed[iNum].DevFlag;	
		WriteDev.DevName[0] = DeviceDataHed[iNum].DevName[0];
		WriteDev.DevName[1] = DeviceDataHed[iNum].DevName[1];
		WriteDev.DevName[2] = 0x00;
		WriteDev.DevAddress = DeviceDataHed[iNum].DevAddress;
		WriteDev.DevCnt = DeviceDataHed[iNum].DevCnt;
		WriteDev.DevData = wData;
		//061124
		if(DeviceDataHed[iNum].DevFlag == 0){
			if(DeviceDataHed[iNum].DevCnt==2 && iType != 5){
//061124
//				wData[3] = (iNowNum >> 24) & 0xff;
//				wData[2] = (iNowNum >> 16) & 0xff;
//				wData[1] = (iNowNum >> 8) & 0xff;
//				wData[0] = iNowNum & 0xff;
				wData[2] = (iNowNum >> 24) & 0xff;
				wData[3] = (iNowNum >> 16) & 0xff;
				wData[0] = (iNowNum >> 8) & 0xff;
				wData[1] = iNowNum & 0xff;
			}else{
//061124
//				wData[1] = (iNowNum >> 8) & 0xff;
//				wData[0] = iNowNum & 0xff;
				wData[0] = (iNowNum >> 8) & 0xff;
				wData[1] = iNowNum & 0xff;
			}
		}else{
			if(DeviceDataHed[iNum].DevCnt==2 && iType != 5){
//061124
				wData[2] = (iNowNum >> 24) & 0xff;
				wData[3] = (iNowNum >> 16) & 0xff;
				wData[0] = (iNowNum >> 8) & 0xff;
				wData[1] = iNowNum & 0xff;
			}else{
//061124
				wData[0] = (iNowNum >> 8) & 0xff;
				wData[1] = iNowNum & 0xff;
			}
		}
		PLCWrite(&WriteDev); 
	}
	return iRetValue;
}
/* *******************************************************************************/
/*  �� �� �� : DeviceTableSet()													 */
/*  ��    �� : ����̽� ���̺� �ۼ�.											 */
/*  ��    �� :																	 */
/*  ��    �� : 																	 */
/*  �� �� �� : 2003.06.03														 */
/*  �� �� �� : �� �� ��															 */
/*  ��    Ÿ : 																	 */
/* *******************************************************************************/
/* 20080822 Ÿ�ӽ���ġ�� ��Ʈ����̽��� �ٿ�δ��Ұ��̳�, ��ü���� �����Ұ��γĿ� ���� mode�� �߰��� ���� */
void DeviceTableSet(int mode)
{
	short	i;
	short	iVal;
	int		iType;
	char	DeviceNum;
	short	iBit_Word;
	short	k;
	short	j;
	short	iSet;		/* 16/32 �ΰ� ǥ�� �÷��� */
	short	iPoint;
	int		DevCode;
	
	iSet		= -1;
	iBit_Word	= 0;			/* BIT	*/
	k			= 0;
	iPoint		= 0;
	memset(Device_Name,0,sizeof(Device_Name));			/* 030903 */
	if(mode == 0){		//070119
		DevCode= 255;	//Bit,Word
	}else{
		DevCode= 127;	//Bit Only
	}
	for(i=0;i<DevCode;i++){
		DeviceNum = (char)(i+1);
/*		Device_Number[i] = (char)DeviceNum;*/
		if((i >= 0x7f) && (iBit_Word == 0))		/* 80 --> 7f 031119 */
		{
			iBit_Word = 1;		/* WORD */
			iPoint = k;
		}

/* ksc20050621 iType ������ ����̽� ����Ϳ� ǥ���� ������ �����Ѵ�. */		
		iVal = GetDevName(iBit_Word,&DeviceNum,Device_Name[k],&iType);

//		if(iBit_Word == 1)
//			Device_iType[k] = (short)(iType | 0x100);	/* Word flag�� ���� */
//		else
//			Device_iType[k] = (short)iType;

		if(iVal != -1){
			if(iBit_Word == 1)
				Device_iType[k] = (short)(iType | 0x100);	/* Word flag�� ���� */
			else
				Device_iType[k] = (short)iType;


			if((iType & 0x80) != 0x80)
				continue;
			if(k>0){
				for(j=iPoint;j<k;j++)
				{
					if(strcmp(Device_Name[k],Device_Name[j])==0)
					{
						iType = 0;
						memset(Device_Name[k],0x00,5);
						k--;
						break;
					}
				}
			}
			
			if(((iType & 0x20) == 0x20) && iSet == -1) 
			{
				iSet = k;
				if(k>=15)
				{
					iPoint =-1;
					break;
				}

				sprintf(Device_Name[k+1],"%s",Device_Name[k]);
				Device_iType[k+1] = (Device_iType[k] | 0x200);
	     		k++;
				if(k>=16)
				{
					iPoint =-1;
					break;
				}
			}
			/**/
			k++;
			if(k>=16)
				break;
			
		}
	}
	if(iSet != -1)
	{
		if(iPoint != -1)
			sprintf(Device_Name[iSet+1],"%s%d",Device_Name[iSet],32);
		sprintf(Device_Name[iSet],"%s%d",Device_Name[iSet],16);
	}
}
char DeviceToIndexSet(int iBitWordFlag,char* cDeviceNameData)
{
	int  i;
	char cDeviceData[5];

	memset(cDeviceData,0x00,sizeof(cDeviceData));
	if(strstr(cDeviceNameData,"16") || strstr(cDeviceNameData,"32"))
	{
		for(i= 0; i < 4; i++){
			if(cDeviceNameData[i] >= 0x41){		/* A-> */
				cDeviceData[i]= cDeviceNameData[i];
			}else{
				break;
			}
		}
		cDeviceData[i]=0x00;
	}
	else
	{
		strncpy(cDeviceData,cDeviceNameData,strlen(cDeviceNameData));
	}
	return (char)Device2Index(iBitWordFlag,cDeviceData);
}
int ReturnDevAddress(int idx)
{
	return(BuffDip[idx].iDev_NowNum);
}
int RetrunSetVal(int	Address)
{
		short	iPoint1;
		short	iPoint2;
		short	iPoint3;
		int		ReturnVal;

		ReturnVal = 0;
		iPoint1 = Address/8;
		if((unsigned int)DeviceDataHed[2].DevName[0] == (unsigned int)0xF8)
			iPoint2 = (short)CommonArea.CS_Inf[iPoint1];
		else
			iPoint2 = (short)CommonArea.TS_Inf[iPoint1];

		iPoint1 = Address%8;
		iPoint3 = 1 << iPoint1;
		if(iPoint2 & iPoint3)
			ReturnVal = 1;
		return ReturnVal;
}
/* *******************************************************************************/
/*  �� �� �� : ReturnDeviceName()												 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  ��    �� : 																	 */
/*  �� �� �� : 2002/04/09														 */
/*  �� �� �� : �� �� ��															 */
/*  ��    Ÿ : iType (1: Device->Num , 2: Num -> Device)						 */
/* *******************************************************************************/
void ReturnDeviceName(short*iDeviceNum, char* DeviceName, short iType)
{
	if(iType == 1){	/* ���ڷ�  ����̽���  ã�� */
		DeviceName[0] = (char)*iDeviceNum ;
	}else{			/* ����̽������� ���� ã�� */
		*iDeviceNum = (short)DeviceName[0];
	}
	return;
}

void DeviceMonitorBuffClear(int start, int end)
{
	short				i;
	for(i=start;i<end;i++){						/* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */
		BuffDip[i].iDev_NowPoint = 0;
		BuffDip[i].iDev_NowNum = 0;
		BuffDip[i].cDev_Now = -1;
		BuffDip[i].iDev_Type = 0;
	}
}
