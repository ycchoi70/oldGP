/* ****************************************************************************** */
/*  �� �� �� : GP_MAINCALLSET.CPP												 */
/*  ��    �� : ���θ޴� ȣ��Ű ����												 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

/* ****************************************************************************** */
/*  �Լ�																			 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �� �� �� : vMainCallSet()													 */
/*  ��    �� : ���θ޴� ȣ�� Ű ���� ó��										 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#ifdef	SIZE_2480
void		vMainCallSet(int* iScreenNo)
{	

	int				iKeyCode;	
	int				iCallKeyCnt;					/* �������� ī��Ʈ �ִ�2������ ����	 */
	short			iKeyFlag;
	_RECTANGLE_INFO RECParam;

	iKeyCode = 80;	
	iCallKeyCnt = 0;								/* �������� ī��Ʈ �ִ�2������ ����	 */
	iKeyFlag = 1;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;
	
	ClearDispBuff(SCREEN_0);								/*  ���÷��� ���� �ʱ�ȭ	 */

	RectAngleOut(GAMEN_START_X+99,GAMEN_START_Y+26,GAMEN_START_X+238,GAMEN_START_Y+76,&RECParam);					/* 							 */	
	RectAngleOut(GAMEN_START_X+99,GAMEN_START_Y+26,GAMEN_START_X+125,GAMEN_START_Y+47,&RECParam);					/* �»�						 */
	RectAngleOut(GAMEN_START_X+212,GAMEN_START_Y+26,GAMEN_START_X+238,GAMEN_START_Y+47,&RECParam);					/* ���						 */
	RectAngleOut(GAMEN_START_X+99,GAMEN_START_Y+55,GAMEN_START_X+125,GAMEN_START_Y+76,&RECParam);					/* ����						 */
	RectAngleOut(GAMEN_START_X+212,GAMEN_START_Y+55,GAMEN_START_X+238,GAMEN_START_Y+76,&RECParam);					/* ����						 */

	DotTextOut(GAMEN_START_X+10,GAMEN_START_Y+36,(Dspname[MENU_CALL_KEY].chName[Set.iLang][0]),1,1, TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+10,GAMEN_START_Y+52,(Dspname[MENU_CALL_KEY].chName[Set.iLang][1]),1,1, TRANS, T_WHITE, T_BLACK);

	DefaultFormDisplay(LINE_FORM,Dspname[MENU_CALL_KEY].chTitle[Set.iLang]);

	if ( Set.iCallKey & 0x01 )
		iCallKeyCnt++;

	if ( Set.iCallKey & 0x04 ) 
		iCallKeyCnt++;

	if ( Set.iCallKey & 0x02 )
		iCallKeyCnt++;

	if ( Set.iCallKey & 0x08 )
		iCallKeyCnt++;


	while ( *iScreenNo == MENU_CALL_KEY_NUM ) {

		if(iKeyCode > 0)
		{
			AreaClear(GAMEN_START_X+100,GAMEN_START_Y+27,GAMEN_START_X+124,GAMEN_START_Y+46,0);					/* �»�						 */
			AreaClear(GAMEN_START_X+213,GAMEN_START_Y+27,GAMEN_START_X+237,GAMEN_START_Y+46,0);					/* ���						 */
			AreaClear(GAMEN_START_X+100,GAMEN_START_Y+56,GAMEN_START_X+124,GAMEN_START_Y+75,0);					/* ����						 */
			AreaClear(GAMEN_START_X+213,GAMEN_START_Y+56,GAMEN_START_X+237,GAMEN_START_Y+75,0);					/* ����						 */

			if ( Set.iCallKey & 0x01 )
			{
//				DotTextOut(GAMEN_START_X+104,GAMEN_START_Y+29,"��",1,1, NON_TRANS, T_WHITE, T_BLACK);
/* KSC20070222 */
/*				DotTextOut(104,29,"��",1,1, NON_TRANS, T_WHITE, T_BLACK); */
				DotTextOut(GAMEN_START_X+104,GAMEN_START_Y+29,"\xff\x05",1,1, NON_TRANS, T_WHITE, T_BLACK); 
/*				DotWriteFont0(1,104,29,(unsigned char *)&TriangleFont[128],T_BLACK,1,1,NON_TRANS,0,0);			*/

				AreaRevers(GAMEN_START_X+100,GAMEN_START_Y+27,GAMEN_START_X+124,GAMEN_START_Y+46);
			}
			if ( Set.iCallKey & 0x04 ) 
			{
//				DotTextOut(GAMEN_START_X+217,GAMEN_START_Y+29,"��",1,1, NON_TRANS, T_WHITE, T_BLACK);
/*				DotTextOut(217,29,"��",1,1, NON_TRANS, T_WHITE, T_BLACK); */
				DotTextOut(GAMEN_START_X+217,GAMEN_START_Y+29,"\xff\x05",1,1, NON_TRANS, T_WHITE, T_BLACK); 
/*				DotWriteFont0(1,217,29,(unsigned char *)&TriangleFont[128],T_BLACK,1,1,NON_TRANS,0,0);			*/

				AreaRevers(GAMEN_START_X+213,GAMEN_START_Y+27,GAMEN_START_X+237,GAMEN_START_Y+46);
			}
			if ( Set.iCallKey & 0x02 )
			{
//				DotTextOut(GAMEN_START_X+104,GAMEN_START_Y+58,"��",1,1, NON_TRANS, T_WHITE, T_BLACK);
/*				DotTextOut(104,58,"��",1,1, NON_TRANS, T_WHITE, T_BLACK); */
				DotTextOut(GAMEN_START_X+104,GAMEN_START_Y+58,"\xff\x05",1,1, NON_TRANS, T_WHITE, T_BLACK); 
/*				DotWriteFont0(1,104,58,(unsigned char *)&TriangleFont[128],T_BLACK,1,1,NON_TRANS,0,0);			*/

				AreaRevers(GAMEN_START_X+100,GAMEN_START_Y+56,GAMEN_START_X+124,GAMEN_START_Y+75);
			}
			if ( Set.iCallKey & 0x08 )
			{
//				DotTextOut(GAMEN_START_X+217,GAMEN_START_Y+58,"��",1,1, NON_TRANS, T_WHITE, T_BLACK);
/*				DotTextOut(217,58,"��",1,1, NON_TRANS, T_WHITE, T_BLACK); */
				DotTextOut(GAMEN_START_X+217,GAMEN_START_Y+58,"\xFF\x05",1,1, NON_TRANS, T_WHITE, T_BLACK); 
/*				DotWriteFont0(1,217,58,(unsigned char *)&TriangleFont[128],T_BLACK,1,1,NON_TRANS,0,0);			*/
				
				AreaRevers(GAMEN_START_X+213,GAMEN_START_Y+56,GAMEN_START_X+237,GAMEN_START_Y+75);
			}
			DrawLcdBank1();
		}
		
		iKeyCode = KeyWaitData(iKeyFlag,MENU_CALL_KEY_NUM);							/* �Էµ� Ű���� �о��	 */
		iKeyFlag = 0;

		if ((iKeyCode >= KEY_13 && iKeyCode <= KEY_15 )||
			iKeyCode == KEY_01 || iKeyCode == KEY_02 ||
			iKeyCode == KEY_22 || iKeyCode == KEY_23 ||
			iKeyCode == KEY_29 || iKeyCode == KEY_30 ||
			iKeyCode == KEY_52 || iKeyCode == KEY_53 ||
			iKeyCode == KEY_59 || iKeyCode == KEY_60)
		{
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
		}

		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}

		if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) 
		{		
			mWriteSettei();
			*iScreenNo = USER_SCREEN_NUM;
		}else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) 
		{	
			mWriteSettei();									/*  END				 */
			*iScreenNo = SET_ENVIRONMENT_NUM;
		} else if (iKeyCode >= KEY_22 && iKeyCode <= KEY_23 ) /*  �»� ����		 */
		{
			if(Set.iCallKey & 0x01)
			{
				if(iCallKeyCnt != 1)
				{
					iCallKeyCnt--;	
					Set.iCallKey = Set.iCallKey ^ 0x01 ;
				}
			}else if(iCallKeyCnt < 2)
			{
				iCallKeyCnt++;
				Set.iCallKey = Set.iCallKey ^ 0x01 ;
			}else
				iKeyCode = -1;

		} else if (iKeyCode >= KEY_29 && iKeyCode <= KEY_30 ) /*  ��� ����		 */
		{
			if(Set.iCallKey & 0x04)
			{
				if(iCallKeyCnt != 1)
				{
					iCallKeyCnt--;	
					Set.iCallKey = Set.iCallKey ^ 0x04 ;
				}
			}else if(iCallKeyCnt < 2)
			{
				iCallKeyCnt++;
				Set.iCallKey = Set.iCallKey ^ 0x04 ;
			}else
				iKeyCode = -1;
		} else if (iKeyCode >= KEY_52 && iKeyCode <= KEY_53 ) /*  ���� ����		 */
		{	
			if(Set.iCallKey & 0x02)
			{
				if(iCallKeyCnt != 1)
				{
					iCallKeyCnt--;	
					Set.iCallKey = Set.iCallKey ^ 0x02 ;
				}
			}else if(iCallKeyCnt < 2)
			{
				iCallKeyCnt++;
				Set.iCallKey = Set.iCallKey ^ 0x02 ;
			}else
				iKeyCode = -1;
		} else if (iKeyCode >= KEY_59 && iKeyCode <= KEY_60 ) /*  ���� ����		 */
		{	
			if(Set.iCallKey & 0x08)
			{
				if(iCallKeyCnt != 1)
				{
					iCallKeyCnt--;	
					Set.iCallKey = Set.iCallKey ^ 0x08 ;
				}
			}else if(iCallKeyCnt < 2)
			{
				iCallKeyCnt++;
				Set.iCallKey = Set.iCallKey ^ 0x08 ;
			}else
				iKeyCode = -1;
		}else
			iKeyCode = -1;
	}

}
#endif
/* *******************************************************************************/
/*  �� �� �� : iMainCallSetValue()												 */
/*  ��    �� : ȭ�� ���ý� 														 */
/*  ��    �� :																	 */
/*  ��    �� : iEscFlag 0 : ESC ����											 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/

int iMainCallSetValue(int iKeyVal)
{
	int ReturnValue;
	int i;
	int iClockData;

	iClockData = 0x00;

	for(i=0;i<8;i++)
	{
		if(KeyTochData[i] == 0xFF || KeyTochData[i] == 0x00)
			break;
		iKeyVal = (int)KeyTochData[i];
		if(TateYoko == 0)
		{ 
			if(iKeyVal == KEY_YTOP_LEFT)		//KEY_01
				iClockData = iClockData | 0x01;
			if(iKeyVal == KEY_YTOP_RIGHT)	//KEY_15
				iClockData = iClockData | 0x04;
			if(iKeyVal == KEY_YBTM_LEFT)		//KEY_46
				iClockData = iClockData | 0x02;
			if(iKeyVal == KEY_YBTM_RIGHT)	//KEY_60
				iClockData = iClockData | 0x08;
		}else{
			if(iKeyVal == KEY_01)
				iClockData = iClockData | 0x01;
			if(iKeyVal == KEY_04)
				iClockData = iClockData | 0x04;
			if(iKeyVal == KEY_57)
				iClockData = iClockData | 0x02;
			if(iKeyVal == KEY_60)
				iClockData = iClockData | 0x08;
		}
	}
	
	ReturnValue = 0;
	if(Set.iCallKey == iClockData && Set.iCallKey != 0)
		ReturnValue = 1;
	return ReturnValue;
}
