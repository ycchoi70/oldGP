/********************************************************************************/
/* �� �� �� : GpTouchSwitchTask.cpp												*/
/* ��    �� : TouchSwitchTask													*/
/* �� �� �� : 2002�� 5�� 14�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"

/********************************************************************************/
/* �� �� �� : DrawTouchSwitch_Task												*/
/* ��    �� : TouchSwich ������ �ص��Ͽ� ȭ�鿡 ���						    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 30�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetTouchSwitch_Func(int iDispOrder,int mode, int iBackColor)
{
	_TOUCHSWICH_EVENT_TBL*	 TouchSwitchEventTbl;
	TouchSwitchEventTbl= (_TOUCHSWICH_EVENT_TBL*)TakeMemory(sizeof(_TOUCHSWICH_EVENT_TBL));
	DrawTouchSwitch_Func(0,TouchSwitchEventTbl,iDispOrder,mode,iBackColor);
	FreeMail((char *)TouchSwitchEventTbl);
	ScreenTagData[iDispOrder].uu.TouchSw.TouchKeyVal= OFF;
}
void	GetTouchAddr(int iOrder,short *sPx,short *sPy,short *ePx,short *ePy,short *iOptionRepeat,unsigned int *iKeyCode)
{
	unsigned char*	buffer;

	buffer= ScreenTagData[iOrder].TagPos;
	*sPx  = (unsigned int)(buffer[6] << 0x08);
	*sPx += (unsigned int)buffer[7] & 0xff;

	*sPy  = (unsigned int)(buffer[8] << 0x08);
	*sPy += (unsigned int)buffer[9] & 0xff;

	*ePx  = (unsigned int)(buffer[10] << 0x08);
	*ePx += (unsigned int)buffer[11] & 0xff;

	*ePy  = (unsigned int)(buffer[12] << 0x08);
	*ePy += (unsigned int)buffer[13] & 0xff;
	if(((unsigned int)buffer[16] & 0x40) == 0x40){	*iOptionRepeat= CHECKED;	}
	else{											*iOptionRepeat= UNCHECKED;	}
	*iKeyCode = (unsigned int)buffer[21] << 0x08;
	*iKeyCode += (unsigned int)buffer[22] & 0xff;
}
int	DrawTouchSwitch_Func(int type,_TOUCHSWICH_EVENT_TBL* TouchSwitchEventTbl,int iDispOrder,int mode, int iBackColor )
{
/*	unsigned int			iTagSizeOf;*/
	int						iOffset;
	int						i;
//	int						iCnt;
//	int						iLen;
	int						iDevAddress;
	short					iTotal;
	unsigned char			*buffer;
	char					cDeviceName[4];
	int						iExpressFlag;

/*	_TOUCH_SWITCH_WORD_DEVICE	*WPos;*/
/*	_TOUCH_SWITCH_BIT_DEVICE	*BPos;*/
/*	_TOUCHSWICH_EVENT_TBL*	 TouchSwitchEventTbl;

	if(CheckMailBox(sizeof(_TOUCHSWICH_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_TOUCHSWICH_EVENT_TBL));
	TouchSwitchEventTbl= (_TOUCHSWICH_EVENT_TBL*)IventTable[IventTableCnt];
*/
	buffer= ScreenTagData[iDispOrder].TagPos;
	memset((char *)TouchSwitchEventTbl, 0x00, sizeof(_TOUCHSWICH_EVENT_TBL));

//	iCnt = TouchSwitchDispCnt;

/*	iTagSizeOf	= 0x00;*/
	iOffset		= 0;
	i			= 0;
//	iLen		= 0;
/*
	iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
	iTagSizeOf += (unsigned int)buffer[1] & 0xff;
*/

	TouchSwitchEventTbl->sX  = (unsigned int)(buffer[6] << 0x08);
	TouchSwitchEventTbl->sX += (unsigned int)buffer[7] & 0xff;

	TouchSwitchEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
	TouchSwitchEventTbl->sY += (unsigned int)buffer[9] & 0xff;

	TouchSwitchEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
	TouchSwitchEventTbl->eX += (unsigned int)buffer[11] & 0xff;

	TouchSwitchEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
	TouchSwitchEventTbl->eY += (unsigned int)buffer[13] & 0xff;

	if(type == 0){
		ScreenTagData[iDispOrder].BeShapeUsed= 1;			/* 031121 */
	}
	if((unsigned int)buffer[14] == 0x02)
		TouchSwitchEventTbl->iOptionTriggerType = ON; 
	else if((unsigned int)buffer[14] == 0x04)
		TouchSwitchEventTbl->iOptionTriggerType = OFF; 
	else
		TouchSwitchEventTbl->iOptionTriggerType = 2;	/*  Ordinary ���� �� */

	TouchSwitchEventTbl->iDispTrigger = (unsigned int)buffer[15];	/* Key : 0x00(0) Bit : 0x80(128) */

	if(((unsigned int)buffer[16] & 0x04) == 0x04)
		TouchSwitchEventTbl->iShapeOption	= BASIC_FIGURE;
	else if(((unsigned int)buffer[16] & 0x08) == 0x08)
	{
		TouchSwitchEventTbl->iShapeOption	= PARTS;
/*		TouchSwitchEventTbl->BeShapeUsed	= 0;*/
		if(type == 0){
			ScreenTagData[iDispOrder].BeShapeUsed= 0;
		}
	}
	else
	{
		TouchSwitchEventTbl->iShapeOption	= NO;
/*		TouchSwitchEventTbl->BeShapeUsed	= 0;*/
		if(type == 0){
			ScreenTagData[iDispOrder].BeShapeUsed= 0;
		}
	}

	if(((unsigned int)buffer[16] & 0x40) == 0x40)
		TouchSwitchEventTbl->iOptionRepeat = CHECKED;
	else
		TouchSwitchEventTbl->iOptionRepeat = UNCHECKED;
	
	if(((unsigned int)buffer[16] & 0x80) == 0x80)
		TouchSwitchEventTbl->iSimultaneousPress = CHECKED;
	else
		TouchSwitchEventTbl->iSimultaneousPress = UNCHECKED;

	TouchSwitchEventTbl->iOnOffFlag = 0;						/* Now Key OnOff Data �ʱ�ȭ */
	/* Case Tab->Off Switch Color Infomation */
	TouchSwitchEventTbl->iOffSwitchColor = (unsigned int)buffer[17]; 
#ifdef	OLD		/* ksc20091217 */
	if((mode > 0) && (iBackColor != 0)){	/* 050426 */
		if(TouchSwitchEventTbl->iOffSwitchColor == 0){
			TouchSwitchEventTbl->iOffSwitchColor= 0xff;
		}else{
			TouchSwitchEventTbl->iOffSwitchColor= 0;
		}
	}
#endif
	/* Case Tab->On Switch Color Infomation */
	TouchSwitchEventTbl->iOnSwitchColor = (unsigned int)buffer[18];
#ifdef	OLD		/* ksc20091217 */
	if((mode > 0) && (iBackColor != 0)){	/* 050426 */
		if(TouchSwitchEventTbl->iOnSwitchColor == 0){
			TouchSwitchEventTbl->iOnSwitchColor= 0xff;
		}else{
			TouchSwitchEventTbl->iOnSwitchColor= 0;
		}
	}
#endif
	/* Action Set */
	TouchSwitchEventTbl->iActionBit		= OFF;
	TouchSwitchEventTbl->iActionWord	= OFF;

	TouchSwitchEventTbl->iBaseAction		= 0;

	if((0x04 & (unsigned int)buffer[19])==0x04)
		TouchSwitchEventTbl->iBaseAction	= 1;		/* Fixed	*/
	else if((0x08 & (unsigned int)buffer[19])==0x08)
		TouchSwitchEventTbl->iBaseAction	= 2;		/* Previous */
	else if((0x10 & (unsigned int)buffer[19])==0x10)
		TouchSwitchEventTbl->iBaseAction	= 3;		/* - 1		*/
	else if((0x20 & (unsigned int)buffer[19])==0x20)
		TouchSwitchEventTbl->iBaseAction	= 4;		/* + 1		*/

	if((0x01 & (unsigned int)buffer[19])==0x01)
		TouchSwitchEventTbl->iActionBit		= ON;
	if((0x02 & (unsigned int)buffer[19])==0x02)
			TouchSwitchEventTbl->iActionWord	= ON;

	/* Case Tab->On, Off Frame Color Infomation */
	TouchSwitchEventTbl->iOnOffFrameColor = (unsigned int)buffer[20];
#ifdef	OLD		/* ksc20091217 */
	if((mode > 0) && (iBackColor != 0)){	/* 050426 */
		if(TouchSwitchEventTbl->iOnOffFrameColor == 0){
			TouchSwitchEventTbl->iOnOffFrameColor= 0xff;
		}else{
			TouchSwitchEventTbl->iOnOffFrameColor= 0;
		}
	}
#endif
	/* Action Tab-> KeyCode Value */
	TouchSwitchEventTbl->iKeyCode = (unsigned int)buffer[21] << 0x08;
	TouchSwitchEventTbl->iKeyCode += (unsigned int)buffer[22] & 0xff;
	iOffset = 22;
	if(TouchSwitchEventTbl->iShapeOption != NO){
		TouchSwitchEventTbl->iOffImgNum  = (unsigned int)(buffer[++iOffset] << 0x08);
		TouchSwitchEventTbl->iOffImgNum += (unsigned int)buffer[++iOffset] & 0xff;
				
		TouchSwitchEventTbl->iOnImgNum = (unsigned int)(buffer[++iOffset] << 0x08);
		TouchSwitchEventTbl->iOnImgNum += (unsigned int)buffer[++iOffset] & 0xff;
		if(TouchSwitchEventTbl->iOffImgNum == 100)
		{
			if(type == 0){
				ScreenTagData[iDispOrder].sX  = ScreenTagData[iDispOrder].sX+1;
				ScreenTagData[iDispOrder].sY  = ScreenTagData[iDispOrder].sY+1;
				ScreenTagData[iDispOrder].eX  = ScreenTagData[iDispOrder].eX-1;
				ScreenTagData[iDispOrder].eY  = ScreenTagData[iDispOrder].eY-1;
			}
		}
	}
	ScreenTagData[iDispOrder].uu.TouchSw.iTriggerTypeSet = 0;
	if(TouchSwitchEventTbl->iDispTrigger != 0x00){		/* 0x80 */

		/*------------------------------------------------------------*/
		iOffset++;
		if(type == 0){
			GetDeviceSet((buffer+iOffset),
					TouchSwitchEventTbl->cDispBitTriggerDeviceName,
					&(TouchSwitchEventTbl->iDispBitTriggerDeviceNumber));
		}
		iOffset+=4;
		/*-------------------------------------------------------------*/	

	}
	
	if(TouchSwitchEventTbl->iOptionTriggerType != 2){
		/*------------------------------------------------------------*/
		iOffset++;
		GetDeviceSet((buffer+iOffset),
					TouchSwitchEventTbl->cOptionTriggerTypeDeviceName,
					&(TouchSwitchEventTbl->iOptionTriggerTypeDeviceNumber));
		iOffset+=4;
		/*-------------------------------------------------------------*/
		if(TouchSwitchEventTbl->cOptionTriggerTypeDeviceName[0] != 0x00)
			ScreenTagData[iDispOrder].uu.TouchSw.iTriggerTypeSet = NOT_ORDINARY;
	 }

	TouchSwitchEventTbl->iOffTextColor = (unsigned int)buffer[++iOffset];
#ifdef	OLD		/* ksc20091217 */
	if((mode > 0) && (iBackColor != 0)){	/* 050426 */
		if(TouchSwitchEventTbl->iOffTextColor == 0){
			TouchSwitchEventTbl->iOffTextColor= 0xff;
		}else{
			TouchSwitchEventTbl->iOffTextColor= 0;
		}
	}
#endif
	/* Off������ 6*8dot�÷��� */
	TouchSwitchEventTbl->iOff68DotFlag = (unsigned int)buffer[++iOffset];

	/* Off������ FontSize H���� */
	TouchSwitchEventTbl->iOffFontSizeH = (unsigned int)buffer[++iOffset];

	/* Off������ FontSize V���� */
	TouchSwitchEventTbl->iOffFontSizeV = (unsigned int)buffer[++iOffset];	//20101207
	if(TouchSwitchEventTbl->iOff68DotFlag != 0){
		TouchSwitchEventTbl->iOffFontSizeH = 0;
		TouchSwitchEventTbl->iOffFontSizeV = 0;		//20101207
	}
	
	if(type == 0){
		/* Off������ FontPosition */
/*		TouchSwitchEventTbl->iOffFontPosition = (unsigned int)buffer[++iOffset];*/
		ScreenTagData[iDispOrder].uu.TouchSw.iOffFontPosition= buffer[++iOffset];
	}else{
		iOffset++;
	}
	/* Off������ Text���� ���� */
	TouchSwitchEventTbl->iOffTextSize  = (unsigned int)(buffer[++iOffset] << 0x08);
	TouchSwitchEventTbl->iOffTextSize += (unsigned int)buffer[++iOffset] & 0xff;
	
	if(TouchSwitchEventTbl->iOffTextSize > 0){
		/* OffText���� */
		iOffset++;
		TouchSwitchEventTbl->cOffTextContent = (char *)(buffer + iOffset);
		iOffset += TouchSwitchEventTbl->iOffTextSize - 1;
	}

	/* On������ �ؽ�Ʈ�÷� */
	TouchSwitchEventTbl->iOnTextColor = (unsigned int)buffer[++iOffset];
#ifdef	OLD		/* ksc20091217 */
	if((mode > 0) && (iBackColor != 0)){	/* 050426 */
		if(TouchSwitchEventTbl->iOnTextColor == 0){
			TouchSwitchEventTbl->iOnTextColor= 0xff;
		}else{
			TouchSwitchEventTbl->iOnTextColor= 0;
		}
	}
#endif
	/* On������ 6*8dot�÷��� */
	TouchSwitchEventTbl->iOn68DotFlag = (unsigned int)buffer[++iOffset];

	/* On������ FontSize H���� */
	TouchSwitchEventTbl->iOnFontSizeH = (unsigned int)buffer[++iOffset];

	/* On������ FontSize V���� */
	TouchSwitchEventTbl->iOnFontSizeV = (unsigned int)buffer[++iOffset];	//20101207
	if(TouchSwitchEventTbl->iOn68DotFlag != 0){
		TouchSwitchEventTbl->iOnFontSizeH = 0;	
		TouchSwitchEventTbl->iOnFontSizeV = 0;		//20101207
	}

	if(type == 0){
		/* Off������ FontPosition */
/*		TouchSwitchEventTbl->iOnFontPosition = (unsigned int)buffer[++iOffset];*/
		ScreenTagData[iDispOrder].uu.TouchSw.iOnFontPosition= buffer[++iOffset];
	}else{
		iOffset++;
	}

	/* On������ Text���� ���� */
	TouchSwitchEventTbl->iOnTextSize  = (unsigned int)(buffer[++iOffset] << 0x08);
	TouchSwitchEventTbl->iOnTextSize += (unsigned int)buffer[++iOffset] & 0xff;

	/***********************************/
	TouchSwitchEventTbl->TouchType = 0;
	/***********************************/
	if(TouchSwitchEventTbl->iOnTextSize > 0){
		/* OnText���� */
		iOffset++;
		TouchSwitchEventTbl->cOnTextContent = (char *)(buffer + iOffset);
		iOffset += TouchSwitchEventTbl->iOnTextSize - 1;
	}	

	/**********************************************************/
	/* Action Data�߰� ���� ������ ��Ʈ�ȴ�.				  */
	/**********************************************************/
	if(TouchSwitchEventTbl->iActionBit == ON){/* Bit�� �߰����� ��� */			
		/* Mometary */
		TouchSwitchEventTbl->iMomentaryCnt	= (unsigned int)buffer[++iOffset];
		/* Set */
		TouchSwitchEventTbl->iSetCnt		= (unsigned int)buffer[++iOffset];
		/* ReSet */
		TouchSwitchEventTbl->iResetCnt		= (unsigned int)buffer[++iOffset];
		/* Alternate */
		TouchSwitchEventTbl->iAlternateCnt	= (unsigned int)buffer[++iOffset];
		TouchSwitchEventTbl->MemOffset = 0;
		/* Bit Action Device Position */
		TouchSwitchEventTbl->iBitPos= iOffset;
		if(type == 0){
			ScreenTagData[iDispOrder].uu.TouchSw.iBStartDataPos= iDeviceOffset;
		}
		/* Mometary Device Information Setting */
		iTotal = TouchSwitchEventTbl->iAlternateCnt + 
			     TouchSwitchEventTbl->iResetCnt +
				 TouchSwitchEventTbl->iSetCnt +
				 TouchSwitchEventTbl->iMomentaryCnt;
		if(iTotal > 0){
/*
			TouchSwitchEventTbl->posBit = (_TOUCH_SWITCH_BIT_DEVICE*)TakeMemory(sizeof(_TOUCH_SWITCH_BIT_DEVICE));
			BPos = TouchSwitchEventTbl->posBit;
*/
		}
		if(TouchSwitchEventTbl->iMomentaryCnt != 0){
			iOffset= iOffset+ TouchSwitchEventTbl->iMomentaryCnt*5;
			TouchSwitchEventTbl->MemOffset += TouchSwitchEventTbl->iMomentaryCnt;
		}

		/* Set Device Information Setting */
		if(TouchSwitchEventTbl->iSetCnt != 0){
			iOffset= iOffset+ TouchSwitchEventTbl->iSetCnt*5;
			TouchSwitchEventTbl->MemOffset += TouchSwitchEventTbl->iSetCnt;
		}
		/* ReSet Device Information Setting */
		if(TouchSwitchEventTbl->iResetCnt != 0){
			iOffset= iOffset+ TouchSwitchEventTbl->iResetCnt*5;
			TouchSwitchEventTbl->MemOffset += TouchSwitchEventTbl->iResetCnt;
		}
		/* Alternate Device Information Setting */
		if(TouchSwitchEventTbl->iAlternateCnt != 0){
			for(i=0;i<TouchSwitchEventTbl->iAlternateCnt;i++){

				if(i>0 || TouchSwitchEventTbl->iMomentaryCnt != 0 ||
					TouchSwitchEventTbl->iSetCnt != 0 || 
					TouchSwitchEventTbl->iResetCnt != 0)
				{
/*
					BPos->linkPos = (_TOUCH_SWITCH_BIT_DEVICE*)TakeMemory(sizeof(_TOUCH_SWITCH_BIT_DEVICE));
					BPos = (_TOUCH_SWITCH_BIT_DEVICE*)BPos->linkPos;
*/
				}

				/*------------------------------------------------------------*/
/*				BPos->iBitDeviceSetFlag = 4;*/	/* Alternate(4) */
				iOffset++;
				GetDeviceSet((buffer+iOffset),cDeviceName,&(iDevAddress));
/*				BPos->iBitDeviceNumber = (unsigned int) iDevAddress;*/
				iOffset+=4;
				/*-------------------------------------------------------------*/
				if(type == 0){
				/* leesi */
					DeviceDataHed[DeviceCnt].DevFlag = DEVICE_BIT;/* bit */
					DeviceDataHed[DeviceCnt].DevName[0] = cDeviceName[0];
					DeviceDataHed[DeviceCnt].DevName[1] = cDeviceName[1];
					DeviceDataHed[DeviceCnt].DevAddress = iDevAddress;
					DeviceDataHed[DeviceCnt].DevCnt = 1;						
					DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];
/*					BPos->iDeviceDataNum = DeviceCnt;*/
					/* 20020819 choijh add*/
/*					BPos->SuperVOffset= WatchingDevice(BPos->cBitDeviceName, 
													   BPos->iBitDeviceNumber, 
													   0,
													   BPos->iDeviceDataNum,
													   BIT,DeviceDataHed[DeviceCnt].DevCnt);
*/
					iDeviceOffset++;
					DeviceCnt++;
				}
			/* leesi */
				TouchSwitchEventTbl->MemOffset++;

			}
		}
/*		if(iTotal >0)*/
/*			BPos->linkPos = (_TOUCH_SWITCH_BIT_DEVICE*)-1;*/
	}
/********************Word�� �߰����� ���******************************/
	if(TouchSwitchEventTbl->iActionWord == ON){
		/* Word Action Device Position */
		TouchSwitchEventTbl->iWordPos= iOffset;
		if(type == 0){
			ScreenTagData[iDispOrder].uu.TouchSw.iWStartDataPos= iDeviceOffset;
		}

		TouchSwitchEventTbl->MemOffset2 = 0;
		/* Indirect�������� ���� Word���� */
		iOffset++;
		TouchSwitchEventTbl->iIndirectWordUnChkCnt = (unsigned int)buffer[++iOffset];
		/* Indirect������ Word���� */
		iOffset++;
		TouchSwitchEventTbl->iIndirectWordChkCnt = (unsigned int)buffer[++iOffset];
		/* Indirect Check���� �ʾ��� �� �߰��Ǵ� ���� */
		if(TouchSwitchEventTbl->iIndirectWordUnChkCnt != 0){
/*			TouchSwitchEventTbl->posWord = (_TOUCH_SWITCH_WORD_DEVICE*)TakeMemory(sizeof(_TOUCH_SWITCH_WORD_DEVICE));
			WPos = (_TOUCH_SWITCH_WORD_DEVICE*)TouchSwitchEventTbl->posWord;
*/
			iOffset= iOffset+ TouchSwitchEventTbl->iIndirectWordUnChkCnt*10;
		}
		/* Indirect Check & Initial Value Condition����(Indirect Check���� �� �߰��Ǵ� ����) */
		if(TouchSwitchEventTbl->iIndirectWordChkCnt != 0){
			if(TouchSwitchEventTbl->iIndirectWordUnChkCnt == 0)
			{
/*				TouchSwitchEventTbl->posWord = (_TOUCH_SWITCH_WORD_DEVICE*)TakeMemory(sizeof(_TOUCH_SWITCH_WORD_DEVICE));
				WPos = (_TOUCH_SWITCH_WORD_DEVICE*)TouchSwitchEventTbl->posWord;
*/
			}
			for(i=0;i<TouchSwitchEventTbl->iIndirectWordChkCnt;i++){
				if(i>0 || TouchSwitchEventTbl->iIndirectWordUnChkCnt != 0)
				{
/*
					WPos->linkPos = (_TOUCH_SWITCH_WORD_DEVICE*)TakeMemory(sizeof(_TOUCH_SWITCH_WORD_DEVICE));
					WPos = (_TOUCH_SWITCH_WORD_DEVICE*) WPos->linkPos;
*/
				}
				/* Indirect Check���θ� �˻��Ѵ� */	
				iExpressFlag = (unsigned int)buffer[++iOffset];
				iOffset++;
/*				GetDeviceSet((buffer+iOffset),
							WPos->cWordDeviceName,
							&(iDevAddress));
				WPos->iWordDeviceNumber = (unsigned int) iDevAddress;
*/
				iOffset+=4;
				/*-------------------------------------------------------------*/
				iOffset+=5;
				/* Indirect�� check�ϰ� Initial Value Condition������ �߰����� �ʾ����� */
				if((unsigned int)buffer[iOffset] == 0x08){
/*
					WPos->iIndirectChekFlag = CHECKED;
					WPos->iInitValueConditionCheckFlag = UNCHECKED;
*/
					/*------------------------------------------------------------*/
					iOffset++;
					GetDeviceSet((buffer+iOffset),cDeviceName,&(iDevAddress));
/*					WPos->iIndirectWordDeviceNumber = (unsigned int) iDevAddress;*/
					iOffset+=4;
					/*-------------------------------------------------------------*/
					
					if(type == 0){
						DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */
						DeviceDataHed[DeviceCnt].DevName[0] = cDeviceName[0];
						DeviceDataHed[DeviceCnt].DevName[1] = cDeviceName[1];
						DeviceDataHed[DeviceCnt].DevAddress = iDevAddress;
						DeviceDataHed[DeviceCnt].DevCnt = 1;
						DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];	

/*						WPos->iDeviceDataNum = DeviceCnt;*/

						/* 20020819 choijh add*/
/*						WPos->SuperVOffset= WatchingDevice(WPos->cIndirectWordDeviceName, 
														   WPos->iIndirectWordDeviceNumber, 
														   0,
														   WPos->iDeviceDataNum,
														   WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
						if(iExpressFlag == UNSIGN_32 ||
							iExpressFlag == SIGN_32)
						{
							DeviceDataHed[DeviceCnt].DevCnt = 2;
							iDeviceOffset+=2;
						}
						/*TouchSwitchEventTbl->iRegisterNumber = DeviceCnt;*/
						iDeviceOffset+=2;
						DeviceCnt++;
						TouchSwitchEventTbl->MemOffset2++;
					}					
				}
				/* Indirect�� check�ϰ� Initial Value Condition������ �߰����� �� */
				else if((unsigned int)buffer[iOffset] == 0x88){

/*
					WPos->iIndirectChekFlag = CHECKED;
					WPos->iInitValueConditionCheckFlag = CHECKED;
*/
					/*------------------------------------------------------------*/
					iOffset++;
					GetDeviceSet((buffer+iOffset),cDeviceName,&(iDevAddress));
/*					WPos->iIndirectWordDeviceNumber = (unsigned int) iDevAddress;*/
					iOffset+=4;
					/*-------------------------------------------------------------*/
					iOffset += 8;
					if(type == 0){
						DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */
						DeviceDataHed[DeviceCnt].DevName[0] = cDeviceName[0];
						DeviceDataHed[DeviceCnt].DevName[1] = cDeviceName[1];
						DeviceDataHed[DeviceCnt].DevAddress = iDevAddress;
						DeviceDataHed[DeviceCnt].DevCnt = 1;
						DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];	

/*						WPos->iDeviceDataNum = DeviceCnt;*/

						/* 20020819 choijh add*/
/*						WPos->SuperVOffset= WatchingDevice(WPos->cIndirectWordDeviceName, 
														   WPos->iIndirectWordDeviceNumber, 
														   0,
														   WPos->iDeviceDataNum,
														   WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
						if(iExpressFlag == UNSIGN_32 ||
							iExpressFlag == SIGN_32)
						{
							DeviceDataHed[DeviceCnt].DevCnt = 2;
							iDeviceOffset+=2;
						}

						/*TouchSwitchEventTbl->iRegisterNumber = DeviceCnt;*/
						iDeviceOffset+=2;
						DeviceCnt++;
		
						TouchSwitchEventTbl->MemOffset2++;
					}
				}						
			}
/*			if(TouchSwitchEventTbl->iIndirectWordChkCnt == 0)*/
/*				WPos->linkPos = (_TOUCH_SWITCH_WORD_DEVICE*) -1;*/
		}
	}
	/*********************************************************************/

	if(TouchSwitchEventTbl->iBaseAction == 1 ){
		TouchSwitchEventTbl->iScreenNo = (unsigned int)buffer[++iOffset] << 0x08;
		TouchSwitchEventTbl->iScreenNo += (unsigned int)buffer[++iOffset] & 0xff; 
		iOffset += 2;
	}else if(TouchSwitchEventTbl->iBaseAction == 2){
		TouchSwitchEventTbl->iScreenNo = 0;
	}
	if(type == 0){
		ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
		/* Basic Tab���� Display Trigger Type�� Bit�� ��� */
		if(TouchSwitchEventTbl->iDispTrigger != 0x00){
			DeviceDataHed[DeviceCnt].DevFlag = DEVICE_BIT;/* Bit */
			DeviceDataHed[DeviceCnt].DevName[0] = TouchSwitchEventTbl->cDispBitTriggerDeviceName[0];
			DeviceDataHed[DeviceCnt].DevName[1] = TouchSwitchEventTbl->cDispBitTriggerDeviceName[1];
			DeviceDataHed[DeviceCnt].DevAddress = TouchSwitchEventTbl->iDispBitTriggerDeviceNumber;	
			DeviceDataHed[DeviceCnt].DevCnt = 1;
			DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];		
/*			TouchSwitchEventTbl->iDispBitTriggerRegistNumber = DeviceCnt;*/
					
			/* 20020819 choijh add*/
/*			TouchSwitchEventTbl->SuperVOffset= WatchingDevice(TouchSwitchEventTbl->cDispBitTriggerDeviceName, 
											   TouchSwitchEventTbl->iDispBitTriggerDeviceNumber, 
											   0,
											   TouchSwitchEventTbl->iDispBitTriggerRegistNumber,
											   BIT,DeviceDataHed[DeviceCnt].DevCnt);
*/
			iDeviceOffset++;
			ScreenTagData[iDispOrder].DevCnt += DeviceDataHed[DeviceCnt].DevCnt;
			DeviceCnt++;
		}

		if(ScreenTagData[iDispOrder].uu.TouchSw.iTriggerTypeSet == NOT_ORDINARY){					
			ScreenTagData[iDispOrder].uu.TouchSw.iBActDataPos= iDeviceOffset;
			DeviceDataHed[DeviceCnt].DevFlag = DEVICE_BIT;/* Bit */
			DeviceDataHed[DeviceCnt].DevName[0] = TouchSwitchEventTbl->cOptionTriggerTypeDeviceName[0];
			DeviceDataHed[DeviceCnt].DevName[1] = TouchSwitchEventTbl->cOptionTriggerTypeDeviceName[1];
			DeviceDataHed[DeviceCnt].DevAddress = TouchSwitchEventTbl->iOptionTriggerTypeDeviceNumber;
			DeviceDataHed[DeviceCnt].DevCnt = 1;
			DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];			
			TouchSwitchEventTbl->iRegisterNumber = DeviceCnt;
			
			/* 20020819 choijh add*/
			/*
			WatchingDevice(TouchSwitchEventTbl->cOptionTriggerTypeDeviceName, 
						   TouchSwitchEventTbl->iOptionTriggerTypeDeviceNumber, 
						   0,
						   TouchSwitchEventTbl->iRegisterNumber,
						   BIT,DeviceDataHed[DeviceCnt].DevCnt);*/ /* Word : 1,    Bit : 0 */

			iDeviceOffset ++;
			DeviceCnt++;
		}

		TouchSwitchDispCnt++;
	}
/*	IventTableCnt++;*/

	return(0);
}
int	GetDispTouchSwitch_Func(_TOUCHSWICH_EVENT_TBL* TouchSwitchEventTbl,int iDispOrder,int mode, int iBackColor )
{
	int						iOffset;
//	int						i;
//	int						iLen;
	unsigned char			*buffer;

	buffer= ScreenTagData[iDispOrder].TagPos;

	iOffset		= 0;
//	i			= 0;
//	iLen		= 0;

	TouchSwitchEventTbl->sX  = (unsigned int)(buffer[6] << 0x08);
	TouchSwitchEventTbl->sX += (unsigned int)buffer[7] & 0xff;

	TouchSwitchEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
	TouchSwitchEventTbl->sY += (unsigned int)buffer[9] & 0xff;

	TouchSwitchEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
	TouchSwitchEventTbl->eX += (unsigned int)buffer[11] & 0xff;

	TouchSwitchEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
	TouchSwitchEventTbl->eY += (unsigned int)buffer[13] & 0xff;

	if((unsigned int)buffer[14] == 0x02)
		TouchSwitchEventTbl->iOptionTriggerType = ON; 
	else if((unsigned int)buffer[14] == 0x04)
		TouchSwitchEventTbl->iOptionTriggerType = OFF; 
	else
		TouchSwitchEventTbl->iOptionTriggerType = 2;	/*  Ordinary ���� �� */

	TouchSwitchEventTbl->iDispTrigger = (unsigned int)buffer[15];	/* Key : 0x00(0) Bit : 0x80(128) */

	if(((unsigned int)buffer[16] & 0x04) == 0x04){
		TouchSwitchEventTbl->iShapeOption	= BASIC_FIGURE;
	}else if(((unsigned int)buffer[16] & 0x08) == 0x08){
		TouchSwitchEventTbl->iShapeOption	= PARTS;
/*		TouchSwitchEventTbl->BeShapeUsed	= 0;
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed= 0;
		}
*/
	}else{
		TouchSwitchEventTbl->iShapeOption	= NO;
/*		TouchSwitchEventTbl->BeShapeUsed	= 0;
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed= 0;
		}
*/
	}

	if(((unsigned int)buffer[16] & 0x40) == 0x40)
		TouchSwitchEventTbl->iOptionRepeat = CHECKED;
	else
		TouchSwitchEventTbl->iOptionRepeat = UNCHECKED;
	
	if(((unsigned int)buffer[16] & 0x80) == 0x80)
		TouchSwitchEventTbl->iSimultaneousPress = CHECKED;
	else
		TouchSwitchEventTbl->iSimultaneousPress = UNCHECKED;

	TouchSwitchEventTbl->iOnOffFlag = 0;						/* Now Key OnOff Data �ʱ�ȭ */
	/* Case Tab->Off Switch Color Infomation */
	TouchSwitchEventTbl->iOffSwitchColor = (unsigned int)buffer[17]; 
#ifdef	OLD		/* ksc20091217 */
	if((mode > 0) && (iBackColor != 0)){	/* 050426 */
		if(TouchSwitchEventTbl->iOffSwitchColor == 0){
			TouchSwitchEventTbl->iOffSwitchColor= 0xff;
		}else{
			TouchSwitchEventTbl->iOffSwitchColor= 0;
		}
	}
#endif
	/* Case Tab->On Switch Color Infomation */
	TouchSwitchEventTbl->iOnSwitchColor = (unsigned int)buffer[18];
#ifdef	OLD		/* ksc20091217 */
	if((mode > 0) && (iBackColor != 0)){	/* 050426 */
		if(TouchSwitchEventTbl->iOnSwitchColor == 0){
			TouchSwitchEventTbl->iOnSwitchColor= 0xff;
		}else{
			TouchSwitchEventTbl->iOnSwitchColor= 0;
		}
	}
#endif
	/* Action Set */
	TouchSwitchEventTbl->iActionBit		= OFF;
	TouchSwitchEventTbl->iActionWord	= OFF;

	TouchSwitchEventTbl->iBaseAction		= 0;

	if((0x04 & (unsigned int)buffer[19])==0x04)
		TouchSwitchEventTbl->iBaseAction	= 1;		/* Fixed	*/
	else if((0x08 & (unsigned int)buffer[19])==0x08)
		TouchSwitchEventTbl->iBaseAction	= 2;		/* Previous */
	else if((0x10 & (unsigned int)buffer[19])==0x10)
		TouchSwitchEventTbl->iBaseAction	= 3;		/* - 1		*/
	else if((0x20 & (unsigned int)buffer[19])==0x20)
		TouchSwitchEventTbl->iBaseAction	= 4;		/* + 1		*/

	if((0x01 & (unsigned int)buffer[19])==0x01)
		TouchSwitchEventTbl->iActionBit		= ON;
	if((0x02 & (unsigned int)buffer[19])==0x02)
			TouchSwitchEventTbl->iActionWord	= ON;

	/* Case Tab->On, Off Frame Color Infomation */
	TouchSwitchEventTbl->iOnOffFrameColor = (unsigned int)buffer[20];
#ifdef	OLD		/* ksc20091217 */
	if((mode > 0) && (iBackColor != 0)){	/* 050426 */
		if(TouchSwitchEventTbl->iOnOffFrameColor == 0){
			TouchSwitchEventTbl->iOnOffFrameColor= 0xff;
		}else{
			TouchSwitchEventTbl->iOnOffFrameColor= 0;
		}
	}
#endif
	/* Action Tab-> KeyCode Value */
	TouchSwitchEventTbl->iKeyCode = (unsigned int)buffer[21] << 0x08;
	TouchSwitchEventTbl->iKeyCode += (unsigned int)buffer[22] & 0xff;
	iOffset = 22;
	if(TouchSwitchEventTbl->iShapeOption != NO){
		TouchSwitchEventTbl->iOffImgNum  = (unsigned int)(buffer[++iOffset] << 0x08);
		TouchSwitchEventTbl->iOffImgNum += (unsigned int)buffer[++iOffset] & 0xff;
				
		TouchSwitchEventTbl->iOnImgNum = (unsigned int)(buffer[++iOffset] << 0x08);
		TouchSwitchEventTbl->iOnImgNum += (unsigned int)buffer[++iOffset] & 0xff;
	}
/*	TouchSwitchEventTbl->iTriggerTypeSet = 0;*/

	if(TouchSwitchEventTbl->iDispTrigger != 0x00){		/* 0x80 */

		/*------------------------------------------------------------*/
		iOffset++;
/*		GetDeviceSet((buffer+iOffset),
					TouchSwitchEventTbl->cDispBitTriggerDeviceName,
					&(TouchSwitchEventTbl->iDispBitTriggerDeviceNumber));
*/
		iOffset+=4;
		/*-------------------------------------------------------------*/	

	}
	
	if(TouchSwitchEventTbl->iOptionTriggerType != 2){
		/*------------------------------------------------------------*/
		iOffset++;
/*		GetDeviceSet((buffer+iOffset),
					TouchSwitchEventTbl->cOptionTriggerTypeDeviceName,
					&(TouchSwitchEventTbl->iOptionTriggerTypeDeviceNumber));
*/
		iOffset+=4;
		/*-------------------------------------------------------------*/
/*		if(TouchSwitchEventTbl->cOptionTriggerTypeDeviceName[0] != 0x00)
			TouchSwitchEventTbl->iTriggerTypeSet = NOT_ORDINARY;
*/
	}

	TouchSwitchEventTbl->iOffTextColor = (unsigned int)buffer[++iOffset];
#ifdef	OLD		/* ksc20091217 */
	if((mode > 0) && (iBackColor != 0)){	/* 050426 */
		if(TouchSwitchEventTbl->iOffTextColor == 0){
			TouchSwitchEventTbl->iOffTextColor= 0xff;
		}else{
			TouchSwitchEventTbl->iOffTextColor= 0;
		}
	}
#endif
	/* Off������ 6*8dot�÷��� */
	TouchSwitchEventTbl->iOff68DotFlag = (unsigned int)buffer[++iOffset];

	/* Off������ FontSize H���� */
	TouchSwitchEventTbl->iOffFontSizeH = (unsigned int)buffer[++iOffset];
	
	/* Off������ FontSize V���� */
	TouchSwitchEventTbl->iOffFontSizeV = (unsigned int)buffer[++iOffset];	//20101207
	if(TouchSwitchEventTbl->iOff68DotFlag != 0){
		TouchSwitchEventTbl->iOffFontSizeH = 0;
		TouchSwitchEventTbl->iOffFontSizeV = 0;		//20101207
	}

	/* Off������ FontPosition */
/*	TouchSwitchEventTbl->iOffFontPosition = (unsigned int)buffer[++iOffset];*/
	iOffset++;

	/* Off������ Text���� ���� */
	TouchSwitchEventTbl->iOffTextSize  = (unsigned int)(buffer[++iOffset] << 0x08);
	TouchSwitchEventTbl->iOffTextSize += (unsigned int)buffer[++iOffset] & 0xff;
	
	if(TouchSwitchEventTbl->iOffTextSize > 0){
		/* OffText���� */
		iOffset++;
		TouchSwitchEventTbl->cOffTextContent = (char *)(buffer + iOffset);
		iOffset += TouchSwitchEventTbl->iOffTextSize - 1;
	}

	/* On������ �ؽ�Ʈ�÷� */
	TouchSwitchEventTbl->iOnTextColor = (unsigned int)buffer[++iOffset];
#ifdef	OLD		/* ksc20091217 */
	if((mode > 0) && (iBackColor != 0)){	/* 050426 */
		if(TouchSwitchEventTbl->iOnTextColor == 0){
			TouchSwitchEventTbl->iOnTextColor= 0xff;
		}else{
			TouchSwitchEventTbl->iOnTextColor= 0;
		}
	}
#endif
	/* On������ 6*8dot�÷��� */
	TouchSwitchEventTbl->iOn68DotFlag = (unsigned int)buffer[++iOffset];

	/* On������ FontSize H���� */
	TouchSwitchEventTbl->iOnFontSizeH = (unsigned int)buffer[++iOffset];

	/* On������ FontSize V���� */
	TouchSwitchEventTbl->iOnFontSizeV = (unsigned int)buffer[++iOffset];	//20101207

	if(TouchSwitchEventTbl->iOn68DotFlag != 0){
		TouchSwitchEventTbl->iOnFontSizeH = 0;	
		TouchSwitchEventTbl->iOnFontSizeV = 0;		//20101207
	}

	/* Off������ FontPosition */
/*	TouchSwitchEventTbl->iOnFontPosition = (unsigned int)buffer[++iOffset];*/
	iOffset++;

	/* On������ Text���� ���� */
	TouchSwitchEventTbl->iOnTextSize  = (unsigned int)(buffer[++iOffset] << 0x08);
	TouchSwitchEventTbl->iOnTextSize += (unsigned int)buffer[++iOffset] & 0xff;

	/***********************************/
	TouchSwitchEventTbl->TouchType = 0;
	/***********************************/
	if(TouchSwitchEventTbl->iOnTextSize > 0){
		/* OnText���� */
		iOffset++;
		TouchSwitchEventTbl->cOnTextContent = (char *)(buffer + iOffset);
		iOffset += TouchSwitchEventTbl->iOnTextSize - 1;
	}	
	return(0);
}
int	TouchswitchActinBit(int iOrder)
{
	int		iActionBit;
	unsigned char	*buffer;

	buffer= ScreenTagData[iOrder].TagPos;
	iActionBit= OFF;
	if((0x01 & (unsigned int)buffer[19])==0x01){
		iActionBit= ON;
	}
	return(iActionBit);
}
/****************************************/
/*	Momentary OFF Proc					*/
/*	2005.03.05							*/
/****************************************/
void	MomentaryOff(void)
{
	int		i,j;
	int		iActionBit;
/*	_TOUCH_SWITCH_BIT_DEVICE	*BPos;*/
	DEV_DATA		TouchKeyWriteDev;
	_TOUCHSWICH_EVENT_TBL* TouchSwitchEventTbl;
	char			cRetVal[5];
	unsigned char *buffer;
//	int		bCnt;
	int		iOffset;
	char	cDeviceName[4];
	int		iDevAddress;

	for(i= 0; i < iDispOrder; i++)
	{
		if(ScreenTagData[i].cObjects == TOUCH_SWITCH)
		{
/*			TouchSwitchEventTbl= (_TOUCHSWICH_EVENT_TBL*)IventTable[i];*/
			iActionBit= TouchswitchActinBit(i);
			if(iActionBit == ON){
				TouchSwitchEventTbl= (_TOUCHSWICH_EVENT_TBL*)TakeMemory(sizeof(_TOUCHSWICH_EVENT_TBL));
				DrawTouchSwitch_Func(1,TouchSwitchEventTbl,i,0,0);
				buffer= ScreenTagData[i].TagPos;
				iOffset= TouchSwitchEventTbl->iBitPos;
//				bCnt= 0;
				/* Momentary */
				for(j=0;j<TouchSwitchEventTbl->iMomentaryCnt;j++)
				{
					iOffset++;
					GetDeviceSet((buffer+iOffset),cDeviceName,&(iDevAddress));
					iOffset+=4;

					TouchKeyWriteDev.DevFlag	= 0;			/* Bit */
					TouchKeyWriteDev.DevName[0] = cDeviceName[0];
					TouchKeyWriteDev.DevName[1] = cDeviceName[1];
					TouchKeyWriteDev.DevAddress = iDevAddress;
					TouchKeyWriteDev.DevCnt		= 1;		/* Bit�̹Ƿ� 1���� Write�Ѵ�.*/
					TouchKeyWriteDev.DevData	= cRetVal;	
					cRetVal[0] = OFF;
					PLCWriteNoWait(&TouchKeyWriteDev); 
				}
				FreeMail((char *)TouchSwitchEventTbl);
			}
		}
	}
}
int	WriteBaseNo(int Num)
{
	DEV_DATA		TouchKeyWriteDev;
	char			cRetVal[5];
	char			cSaveRetVal[5];
	int				ret;

	ret= -1;
	TouchKeyWriteDev.DevFlag = 1;	
	TouchKeyWriteDev.DevName[0] = CommonArea.SystemDev.Switch_Base_DevName[0];
	TouchKeyWriteDev.DevName[1] = CommonArea.SystemDev.Switch_Base_DevName[1];
	TouchKeyWriteDev.DevName[2] = 0x00;
	TouchKeyWriteDev.DevAddress = CommonArea.SystemDev.Switch_Base_DevAdd;
	TouchKeyWriteDev.DevCnt = 1;
	TouchKeyWriteDev.DevData = cRetVal;
	memset(cRetVal,0x00,sizeof(cRetVal));
	//061124
//	cRetVal[1] = (Num >> 8) & 0xff;
//	cRetVal[0] = Num & 0xff;
	cRetVal[0] = (Num >> 8) & 0xff;
	cRetVal[1] = Num & 0xff;
	cSaveRetVal[0]= cRetVal[0];
	cSaveRetVal[1]= cRetVal[1];
	PLCWrite(&TouchKeyWriteDev);
	PLCRead(&TouchKeyWriteDev);
	if(memcmp(cRetVal,cSaveRetVal,2) == 0){
		iPreviousScreenNum = iNowScreenNum;
		BaseChangeFlag1= 1;			/* 040815 */
		BaseChangeFlag2= 1;
		ret= 0;
	}
	return(ret);
}
void	WordActionProc(int iOrder,_TOUCHSWICH_EVENT_TBL* TouchSwitchEventTbl)
{
	int		i,wCnt;
	int		iOffset;
	char	cDeviceName[4];
	int		iDevAddress;
	int		iExpressFlag;
//	int		iIndirectChekFlag;
	unsigned int	iFixedValue;
	int		fixPos;
	char	cRetVal[4];
	DEV_DATA		TouchKeyWriteDev;
	char	cDeviceVal[8];
	long			lValData;
	unsigned long	ulValData;
	long	iConditionValue;
	long	iResetValue;
	int		iInitValueConditionCheckFlag;
	unsigned char *buffer;

	buffer= ScreenTagData[iOrder].TagPos;
	iOffset= TouchSwitchEventTbl->iWordPos+ 5;
	wCnt= 0;
	for(i=0;i<TouchSwitchEventTbl->iIndirectWordUnChkCnt;i++){
		iExpressFlag = (unsigned int)buffer[iOffset];
		/*------------------------------------------------------------*/
//		iIndirectChekFlag = UNCHECKED;/* Check���� ���� */						
		iOffset++;
		GetDeviceSet((buffer+iOffset),cDeviceName,&(iDevAddress));
		iOffset+=4;
		/*-------------------------------------------------------------*/
#ifdef	WIN32
		iFixedValue = (unsigned int)buffer[++iOffset] << 0x18;
		fixPos= iOffset;
		iFixedValue += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		iFixedValue += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		iFixedValue += (unsigned int)buffer[++iOffset] & 0xff; 
		iOffset++;
#else
		iOffset++;
		fixPos= iOffset;
		memcpy(&iFixedValue,&buffer[iOffset],4);
		iOffset+=4;
#endif
		TouchKeyWriteDev.DevFlag = 1;/* Word */
		TouchKeyWriteDev.DevName[0] = cDeviceName[0];
		TouchKeyWriteDev.DevName[1] = cDeviceName[1];
		TouchKeyWriteDev.DevName[2] = 0x00;
		TouchKeyWriteDev.DevAddress = iDevAddress;
		if(iExpressFlag == UNSIGN_16 || iExpressFlag == SIGN_16){
			TouchKeyWriteDev.DevCnt		= 1;
			TouchKeyWriteDev.DevData = cRetVal;
			//061124
//			cRetVal[0] = buffer[fixPos+3];
//			cRetVal[1] = buffer[fixPos+2];
			cRetVal[0] = buffer[fixPos+2];
			cRetVal[1] = buffer[fixPos+3];
			PLCWriteNoWait(&TouchKeyWriteDev); 
		}
		else if(iExpressFlag == UNSIGN_32 || iExpressFlag == SIGN_32){
			TouchKeyWriteDev.DevCnt		= 2;
			TouchKeyWriteDev.DevData = cRetVal;
			//061124
//			cRetVal[0] = buffer[fixPos+3];
//			cRetVal[1] = buffer[fixPos+2];
//			cRetVal[2] = buffer[fixPos+1];
//			cRetVal[3] = buffer[fixPos+0];
			cRetVal[0] = buffer[fixPos+2];
			cRetVal[1] = buffer[fixPos+3];
			cRetVal[2] = buffer[fixPos+0];
			cRetVal[3] = buffer[fixPos+1];
			PLCWriteNoWait(&TouchKeyWriteDev); 
		}
	}
	for(i=0;i<TouchSwitchEventTbl->iIndirectWordChkCnt;i++){
		iExpressFlag = (unsigned int)buffer[iOffset];
		/*------------------------------------------------------------*/
//		iIndirectChekFlag = UNCHECKED;/* Check���� ���� */
		iOffset++;
		GetDeviceSet((buffer+iOffset),cDeviceName,&(iDevAddress));
		iOffset+=4;
#ifdef	WIN32
		iFixedValue = (unsigned int)buffer[++iOffset] << 0x18;
		iFixedValue += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		iFixedValue += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		iFixedValue += (unsigned int)buffer[++iOffset] & 0xff; 
		iOffset++;
#else
		iOffset++;
		memcpy(&iFixedValue,&buffer[iOffset],4);
		iOffset+=4;
#endif
		if((unsigned int)buffer[iOffset] == 0x08){
			iInitValueConditionCheckFlag= UNCHECKED;
			iOffset++;
/* 060919			iOffset+=4; */
			iOffset+=5;
		}else if((unsigned int)buffer[iOffset] == 0x88){
			iInitValueConditionCheckFlag= CHECKED;
			iOffset++;
#ifdef	WIN32
			iOffset+=4;
			iConditionValue  = (unsigned int)buffer[++iOffset] << 0x18;
			iConditionValue += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
			iConditionValue += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
			iConditionValue += (unsigned int)buffer[++iOffset] & 0xff; 

			iResetValue   = (unsigned int)buffer[++iOffset] << 0x18;
			iResetValue += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
			iResetValue += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
			iResetValue += (unsigned int)buffer[++iOffset] & 0xff;
#else
			iOffset+=5;
			memcpy(&iConditionValue,&buffer[iOffset],4);
			iOffset+=4;
			memcpy(&iResetValue,&buffer[iOffset],4);
/* 060919			iOffset+=3; */
			iOffset+=4;
#endif
		}
		TouchKeyWriteDev.DevFlag = 1;/* Word */
		TouchKeyWriteDev.DevName[0] = cDeviceName[0];
		TouchKeyWriteDev.DevName[1] = cDeviceName[1];
		TouchKeyWriteDev.DevAddress = iDevAddress;
		if(iExpressFlag == UNSIGN_16 || iExpressFlag == SIGN_16){
			TouchKeyWriteDev.DevCnt		= 1;
			TouchKeyWriteDev.DevData = cRetVal;
			memcpy(cDeviceVal,&DeviceData[ScreenTagData[iOrder].uu.TouchSw.iWStartDataPos+wCnt],2);
			wCnt+= 2;
			if(iExpressFlag == SIGN_16)
				lValData = ChangeChar2long(cDeviceVal,BIT16);
			else
				lValData = ChangeChar2Unsinlong(cDeviceVal,BIT16);

			lValData += iFixedValue;

			if(iInitValueConditionCheckFlag == CHECKED)
			{
/*				if(iConditionValue <= lValData)*/
				if(iConditionValue == lValData)
				{
					lValData = (long)iResetValue;
				}
			}
//061124
//			cRetVal[0] = lValData & 0xff;
//			cRetVal[1] = (lValData >> 8) & 0xff;
//			cRetVal[2] = 0x00;
			cRetVal[0] = (lValData >> 8) & 0xff;
			cRetVal[1] = lValData & 0xff;
			PLCWriteNoWait(&TouchKeyWriteDev); 
		}
		else if(iExpressFlag == UNSIGN_32 || iExpressFlag == SIGN_32){
			memcpy(cDeviceVal,&DeviceData[ScreenTagData[iOrder].uu.TouchSw.iWStartDataPos+wCnt],4);
			wCnt+= 4;
			if(iExpressFlag == UNSIGN_32){
				ulValData = ChangeChar2Unsinlong(cDeviceVal,BIT32);
				ulValData += iFixedValue;		/* 050428 */
				if(iInitValueConditionCheckFlag == CHECKED)
				{
					/* 060203 */
					if((unsigned long)iConditionValue == ulValData)
					{
						ulValData = (unsigned long) iResetValue;
					}
				}
				//061124
//				cRetVal[0] = (char)(ulValData & 0xff);
//				ulValData = ulValData >> 8;
//				cRetVal[1] = (char)(ulValData & 0xff);
//				ulValData = ulValData >> 8;
//				cRetVal[2] = (char)(ulValData & 0xff);
//				ulValData = ulValData >> 8;
//				cRetVal[3] = (char)(ulValData & 0xff);
				cRetVal[1] = (char)(ulValData & 0xff);
				ulValData = ulValData >> 8;
				cRetVal[0] = (char)(ulValData & 0xff);
				ulValData = ulValData >> 8;
				cRetVal[3] = (char)(ulValData & 0xff);
				ulValData = ulValData >> 8;
				cRetVal[2] = (char)(ulValData & 0xff);
			}else{
				lValData = ChangeChar2long(cDeviceVal,BIT32);
				lValData += iFixedValue;		/* 050428 */
				if(iInitValueConditionCheckFlag == CHECKED)
				{
					/* 060203 */
					if(iConditionValue == lValData)
					{
						lValData = (long) iResetValue;
					}
				}
				//061124
//				cRetVal[0] = lValData & 0xff;
//				lValData = lValData >> 8;
//				cRetVal[1] = lValData & 0xff;
//				lValData = lValData >> 8;
//				cRetVal[2] = lValData & 0xff;
//				lValData = lValData >> 8;
//				cRetVal[3] = lValData & 0xff;
				cRetVal[1] = lValData & 0xff;
				lValData = lValData >> 8;
				cRetVal[0] = lValData & 0xff;
				lValData = lValData >> 8;
				cRetVal[3] = lValData & 0xff;
				lValData = lValData >> 8;
				cRetVal[2] = lValData & 0xff;
			}
			TouchKeyWriteDev.DevCnt		= 2;
			TouchKeyWriteDev.DevData = cRetVal;

			PLCWriteNoWait(&TouchKeyWriteDev); 
		}
	}
}
void	BitActionProc(int iOrder,_TOUCHSWICH_EVENT_TBL* TouchSwitchEventTbl,int iKeyVal)
{
	int		i,bCnt;
	int		iOffset;
	char	cDeviceName[4];
	int		iDevAddress;
	char	cRetVal[4];
	DEV_DATA		TouchKeyWriteDev;
	unsigned char *buffer;
	int				iAlternateKeyVal;

	buffer= ScreenTagData[iOrder].TagPos;
	iOffset= TouchSwitchEventTbl->iBitPos;
	bCnt= 0;
	/* Momentary */
	for(i=0;i<TouchSwitchEventTbl->iMomentaryCnt;i++)
	{
		iOffset++;
		GetDeviceSet((buffer+iOffset),cDeviceName,&(iDevAddress));
		iOffset+=4;

		TouchKeyWriteDev.DevFlag	= 0;			/* Bit */
		TouchKeyWriteDev.DevName[0] = cDeviceName[0];
		TouchKeyWriteDev.DevName[1] = cDeviceName[1];
		TouchKeyWriteDev.DevAddress = iDevAddress;
		TouchKeyWriteDev.DevCnt		= 1;		/* Bit�̹Ƿ� 1���� Write�Ѵ�.*/
		TouchKeyWriteDev.DevData	= cRetVal;	
		if(iKeyVal == ON){
			cRetVal[0] = ON;
		}else{
			cRetVal[0] = OFF;
		}
		PLCWriteNoWait(&TouchKeyWriteDev); 
	}
	/* Set */
	for(i=0;i<TouchSwitchEventTbl->iSetCnt;i++){
		iOffset++;
		GetDeviceSet((buffer+iOffset),cDeviceName,&(iDevAddress));
		iOffset+=4;
		if(iKeyVal == ON){
			memset(cRetVal, 0x00, sizeof(cRetVal));
			TouchKeyWriteDev.DevFlag = 0;/* Bit */
			TouchKeyWriteDev.DevName[0] = cDeviceName[0];
			TouchKeyWriteDev.DevName[1] = cDeviceName[1];
			TouchKeyWriteDev.DevAddress = iDevAddress;
			TouchKeyWriteDev.DevCnt		= 1;/* Bit�̹Ƿ� 1���� Write�Ѵ�.*/
			TouchKeyWriteDev.DevData	= cRetVal;
			cRetVal[0] = ON;
			/*	itoa(ON, cRetVal, 10);*/
			PLCWriteNoWait(&TouchKeyWriteDev); 
		}
	}
	/* Reset */
	for(i=0;i<TouchSwitchEventTbl->iResetCnt;i++){
		iOffset++;
		GetDeviceSet((buffer+iOffset),cDeviceName,&(iDevAddress));
		iOffset+=4;
		if(iKeyVal == ON){
			memset(cRetVal, 0x00, sizeof(cRetVal));
			TouchKeyWriteDev.DevFlag = 0;/* Bit */
			TouchKeyWriteDev.DevName[0] = cDeviceName[0];
			TouchKeyWriteDev.DevName[1] = cDeviceName[1];
			TouchKeyWriteDev.DevAddress = iDevAddress;
			TouchKeyWriteDev.DevCnt		= 1;/* Bit�̹Ƿ� 1���� Write�Ѵ�.*/
			TouchKeyWriteDev.DevData	= cRetVal;
			cRetVal[0] = OFF;
			PLCWriteNoWait(&TouchKeyWriteDev); 
		}
	}
	/* Alternate */
	for(i=0;i<TouchSwitchEventTbl->iAlternateCnt;i++){
		iOffset++;
		GetDeviceSet((buffer+iOffset),cDeviceName,&(iDevAddress));
		iOffset+=4;
		if(iKeyVal == ON){
			TouchKeyWriteDev.DevFlag = 0;/* Bit */
			TouchKeyWriteDev.DevName[0] = cDeviceName[0];
			TouchKeyWriteDev.DevName[1] = cDeviceName[1];
			TouchKeyWriteDev.DevAddress = iDevAddress;
			TouchKeyWriteDev.DevCnt		= 1;/* Bit�̹Ƿ� 1���� Write�Ѵ�.*/
			TouchKeyWriteDev.DevData	= cRetVal;
			iAlternateKeyVal = DeviceData[ScreenTagData[iOrder].uu.TouchSw.iBStartDataPos+bCnt];
			bCnt++;
			if(iAlternateKeyVal == ON){
				iAlternateKeyVal = OFF;
			}else{
				iAlternateKeyVal = ON;
			}								
			cRetVal[0] = iAlternateKeyVal;
			PLCWriteNoWait(&TouchKeyWriteDev); 
		}
	}
}
/****************************************************/
/*	?�b?��̏���									*/
/****************************************************/
//20100706 Add
int	CheckSecurityLevelPW_Reset(int iScreenNow,int NexScreen)
{
	int			i,idx,idx1;

	for(i=0;i<iBaseScreenCnt;i++)
	{
		if(iScreenNow == Screen[i].iNum)
		{
			idx = i;
			break;
		}
	}
	for(i=0;i<iBaseScreenCnt;i++)
	{
		if(NexScreen == Screen[i].iNum)
		{
			idx1 = i;
			break;
		}
	}
	if(Screen[idx].iSecurity < Screen[idx1].iSecurity){
		return(-1);
	}else{
		return(0);
	}
}
////////////////////////////////////////////////////////
int TouchKeyWriteProc(int iOrder)
{
/*	T_MAIL			*mp;*/
//	int				i;
	int				k;
	DEV_DATA		TouchKeyWriteDev;
	int				iKeyVal;
	char			cRetVal[5];
	char			cSaveRetVal[5];
/*	char			cTextBuffer[5];*/
	char			*cScreenDisp;
	int				iDevWriteFlag;	/* TouchKey�� ���� ����� ���������� ���� �÷��� */
	unsigned int    iOrdinaryDevVal;
	int				iNum;
	int				ret;		/* 031128 */
/*ksc20040727_owashi*/
//	int				BaseOnFlag;	/* 040736 */
	int				iBackColor;
/*ksc20040727_owashi*/	
/*	_TOUCH_SWITCH_BIT_DEVICE	*BPos;
	_TOUCH_SWITCH_WORD_DEVICE	*WPos;
*/
	_TOUCHSWICH_EVENT_TBL*	 TouchSwitchEventTbl;

	int				BaseWriteFlag;			/* 050427 */

	iBackColor= NowBackColor(iNowScreenNum);

/*	TouchSwitchEventTbl= (_TOUCHSWICH_EVENT_TBL*)IventTable[iOrder];*/
	TouchSwitchEventTbl= (_TOUCHSWICH_EVENT_TBL*)TakeMemory(sizeof(_TOUCHSWICH_EVENT_TBL));
	DrawTouchSwitch_Func(1,TouchSwitchEventTbl,iOrder,0,iBackColor);
	ret				= -1;
//	i				= iOrder;
	iKeyVal = ScreenTagData[iOrder].uu.TouchSw.TouchKeyVal;
	/* ORDINARY�ȊO�̂Ƃ�?�b?��L���ɂ��邩?�F�b�N���� */
	iDevWriteFlag= TRUE;
	if(ScreenTagData[iOrder].uu.TouchSw.iTriggerTypeSet == NOT_ORDINARY){	
		iOrdinaryDevVal= DeviceData[ScreenTagData[iOrder].uu.TouchSw.iBActDataPos];
		if(TouchSwitchEventTbl->iOptionTriggerType == ON){
			if(iOrdinaryDevVal == OFF){
				iDevWriteFlag= OFF;
			}
		}else{
			if(iOrdinaryDevVal == ON){
				iDevWriteFlag= OFF;
			}
		}				
	}
	if(iDevWriteFlag == ON){
		/* Word Action Device */
		if(TouchSwitchEventTbl->iActionWord == ON){
			if(iKeyVal == ON){
				WordActionProc(iOrder,TouchSwitchEventTbl);
			}
		}
		/* Bit Action Device */
		if(TouchSwitchEventTbl->iActionBit == ON){
			BitActionProc(iOrder,TouchSwitchEventTbl,iKeyVal);
		}
		/* Base Action */
//		BaseOnFlag= 0;				/* 040726 */
		if(TouchSwitchEventTbl->iBaseAction == 1){		/* Fix */
			if(iKeyVal == ON){
				/* Screen��ȣ�� �޾� ������ �̸��� ã�� ��, FileTask�� ȣ���Ѵ�. */
				if(iNowScreenNum != TouchSwitchEventTbl->iScreenNo){
					for(k=0;k+1<=iBaseScreenCnt;k++){
						if(Screen[k].iNum == TouchSwitchEventTbl->iScreenNo){
//							if(CheckSecurityLevel(TouchSwitchEventTbl->iScreenNo) == 0){							//20100706 Del
							if(((TouchSwitchEventTbl->iKeyCode == PW_RESET) &&										//20100706 Add
								(CheckSecurityLevelPW_Reset(iNowScreenNum,TouchSwitchEventTbl->iScreenNo) != 0)) ||	//20100706 Add
							    (CheckSecurityLevel(TouchSwitchEventTbl->iScreenNo) != 0)){							//20100706 Add
								/* Password Inpu 050411 */
								PassWordSettingFg= TouchSwitchEventTbl->iScreenNo;
								PassWordSettingChg= 1;
								iPassFlag = 2;		/* CR Return */
							}else{
								TouchKeyWriteDev.DevFlag = 1;	
								TouchKeyWriteDev.DevName[0] = CommonArea.SystemDev.Switch_Base_DevName[0];
								TouchKeyWriteDev.DevName[1] = CommonArea.SystemDev.Switch_Base_DevName[1];
								TouchKeyWriteDev.DevName[2] = 0x00;
								TouchKeyWriteDev.DevAddress = CommonArea.SystemDev.Switch_Base_DevAdd;
								TouchKeyWriteDev.DevCnt = 1;
								TouchKeyWriteDev.DevData = cRetVal;
//								memset(cRetVal,0x00,sizeof(cRetVal));
								//061124
//								cRetVal[1] = (TouchSwitchEventTbl->iScreenNo >> 8) & 0xff;
//								cRetVal[0] = TouchSwitchEventTbl->iScreenNo & 0xff;
								cRetVal[0] = (TouchSwitchEventTbl->iScreenNo >> 8) & 0xff;
								cRetVal[1] = TouchSwitchEventTbl->iScreenNo & 0xff;
								cSaveRetVal[0]= cRetVal[0];
								cSaveRetVal[1]= cRetVal[1];
								PLCWrite(&TouchKeyWriteDev);
								PLCRead(&TouchKeyWriteDev);
								if(memcmp(cRetVal,cSaveRetVal,2) == 0){
									iPreviousScreenNum = iNowScreenNum;
	/*ksc20040727_owashi*/
									MomentaryOff();
//									BaseOnFlag= 1;				/* 040726 */
									BaseChangeFlag1= 1;			/* 040815 */
									BaseChangeFlag2= 1;
	/*ksc20040727_owashi*/
	/*							Delay(10);*/
								/*if(PlcConnectFlag==1)*/
									//061224
#ifdef	WIN32
									CommonArea.SwitchingData[0] = cRetVal[0] >> 8;
									CommonArea.SwitchingData[0] += cRetVal[1] << 8;
#else
									CommonArea.SwitchingData[0] = TouchSwitchEventTbl->iScreenNo;
#endif
									iOnSignalStart = ON;
									Key.iCode = -1;
									iKeyVal = ON;
									BaseWriteFlag= 1;			/* 050427 */
								}
//							}else{
//								/* Password Inpu 050411 */
//								PassWordSettingFg= TouchSwitchEventTbl->iScreenNo;
//								PassWordSettingChg= 1;
//								iPassFlag = 2;		/* CR Return */
							}
							break;
						}
					}
					/*************************03/12/17********************************/
					if(k+1 > iBaseScreenCnt)
					{
						cScreenDisp = (char*)TakeMemory(20);
						memset(cScreenDisp, 0x00, 20);
						sprintf(cScreenDisp,"(No.%d)",TouchSwitchEventTbl->iScreenNo);
						if(TateYoko == 0){
							iCaptionVerticalWindow(Dspname[COMMENT_SCREEN].chName[Set.iLang][0],
										Dspname[COMMENT_SCREEN].chName[Set.iLang][1],
										cScreenDisp,"","");/**/
						}
						else
						{
							iCaptionVerticalWindow(Dspname[COMMENT_SCREEN].chName[Set.iLang][2],
										Dspname[COMMENT_SCREEN].chName[Set.iLang][3],
										Dspname[COMMENT_SCREEN].chName[Set.iLang][4],
										Dspname[COMMENT_SCREEN].chName[Set.iLang][5],cScreenDisp);/**/
						}
						FreeMail((char*)cScreenDisp);
					}
					/***********************************************************/

				}
			}
		}
		else if(TouchSwitchEventTbl->iBaseAction == 2){				/* Previous */
			if(iKeyVal == ON){
				if(iPreviousScreenNum != iNowScreenNum){
					for(k=0;k+1<=iBaseScreenCnt;k++){
						if(Screen[k].iNum == iPreviousScreenNum){
							WaitBaseChange=1;
//							if(CheckSecurityLevel(iPreviousScreenNum) == 0){								//20100706 Del
							if(((TouchSwitchEventTbl->iKeyCode == PW_RESET) &&								//20100706 Add
								(CheckSecurityLevelPW_Reset(iNowScreenNum,iPreviousScreenNum) != 0)) ||		//20100706 Add
							    (CheckSecurityLevel(iPreviousScreenNum) != 0)){								//20100706 Add
								/* Password Inpu 050411 */
								PassWordSettingFg= iPreviousScreenNum;
								PassWordSettingChg= 1;
								iPassFlag = 2;		/* CR Return */
							}else{
								TouchKeyWriteDev.DevFlag = 1;	
								TouchKeyWriteDev.DevName[0] = CommonArea.SystemDev.Switch_Base_DevName[0];
								TouchKeyWriteDev.DevName[1] = CommonArea.SystemDev.Switch_Base_DevName[1];
								TouchKeyWriteDev.DevName[2] = 0x00;
								TouchKeyWriteDev.DevAddress = CommonArea.SystemDev.Switch_Base_DevAdd;
								TouchKeyWriteDev.DevCnt = 1;
								TouchKeyWriteDev.DevData = cRetVal;
								//061124
//								memset(cRetVal,0x00,sizeof(cRetVal));
//								cRetVal[1] = (iPreviousScreenNum >> 8) & 0xff;
//								cRetVal[0] = iPreviousScreenNum & 0xff;
								cRetVal[0] = (iPreviousScreenNum >> 8) & 0xff;
								cRetVal[1] = iPreviousScreenNum & 0xff;
								cSaveRetVal[0]= cRetVal[0];
								cSaveRetVal[1]= cRetVal[1];
								PLCWrite(&TouchKeyWriteDev);
								PLCRead(&TouchKeyWriteDev);
								if(memcmp(cRetVal,cSaveRetVal,2) == 0){
									iPreviousScreenNum = iNowScreenNum;
	/*ksc20040727_owashi*/
									MomentaryOff();
//									BaseOnFlag= 1;				/* 040726 */
									BaseChangeFlag1= 1;			/* 040815 */
									BaseChangeFlag2= 1;
	/*ksc20040727_owashi*/
							/*	Delay(10);*/
									iOnSignalStart = ON;
									Key.iCode = -1;
									iKeyVal = ON;
									BaseWriteFlag= 1;			/* 050427 */
								}
							/*	SwitchingScreenDevice.iBaseScreenFlag = 1;*/
//							}else{
//								/* Password Inpu 050411 */
//								PassWordSettingFg= iPreviousScreenNum;
//								PassWordSettingChg= 1;
//								iPassFlag = 2;		/* CR Return */
							}
							break;
						}
					}
				}
			}
		}
		/******************************* No Test -1,+1 ************************************/
		else if(TouchSwitchEventTbl->iBaseAction == 3 || TouchSwitchEventTbl->iBaseAction == 4)	/* +1,-1 �κ� �߰�. */
		{
			if(iKeyVal == ON){
			/*	if(iBaseScreenCnt > 1){*/
					for(k=0;k+1<=iBaseScreenCnt;k++){
						if(Screen[k].iNum == iNowScreenNum){
							if(TouchSwitchEventTbl->iBaseAction == 3 && k > 0) /*  -1 */
							{
								iNum = Screen[k-1].iNum;
							}else if(TouchSwitchEventTbl->iBaseAction == 4 && k+1 < iBaseScreenCnt)
							{
								iNum = Screen[k+1].iNum;
							}else
							{
								/***********************************************************/
								cScreenDisp = (char*)TakeMemory(20);
								memset(cScreenDisp, 0x00, 20);
								if(TouchSwitchEventTbl->iBaseAction == 4)
	/*										sprintf(cScreenDisp,"(%d+1)",iNowScreenNum);*/
									sprintf(cScreenDisp,"(%d)",iNowScreenNum+1);
								else
	/*										sprintf(cScreenDisp,"(%d-1)",iNowScreenNum);*/
									sprintf(cScreenDisp,"(%d)",iNowScreenNum-1);
								if(TateYoko == 0){
									iCaptionVerticalWindow(Dspname[COMMENT_SCREEN].chName[Set.iLang][0],
												Dspname[COMMENT_SCREEN].chName[Set.iLang][1],
												cScreenDisp,"","");/**/
								}
								else
								{
									iCaptionVerticalWindow(Dspname[COMMENT_SCREEN].chName[Set.iLang][2],
												Dspname[COMMENT_SCREEN].chName[Set.iLang][3],
												Dspname[COMMENT_SCREEN].chName[Set.iLang][4],
												Dspname[COMMENT_SCREEN].chName[Set.iLang][5],cScreenDisp);/**/
								}
								FreeMail((char*)cScreenDisp);
								break;
								/**********************************************************************/
							}
							WaitBaseChange=1;
							TouchKeyWriteDev.DevFlag = 1;	
							TouchKeyWriteDev.DevName[0] = CommonArea.SystemDev.Switch_Base_DevName[0];
							TouchKeyWriteDev.DevName[1] = CommonArea.SystemDev.Switch_Base_DevName[1];
							TouchKeyWriteDev.DevName[2] = 0x00;
							TouchKeyWriteDev.DevAddress = CommonArea.SystemDev.Switch_Base_DevAdd;
							TouchKeyWriteDev.DevCnt = 1;
							TouchKeyWriteDev.DevData = cRetVal;
//							memset(cRetVal,0x00,sizeof(cRetVal));

//							if(CheckSecurityLevel(iNum) == 0){																				//20100706 Del
							if(((TouchSwitchEventTbl->iKeyCode == PW_RESET) && (CheckSecurityLevelPW_Reset(iNowScreenNum,iNum) != 0)) ||	//20100706 Add
							    (CheckSecurityLevel(iNum) != 0)){																			//20100706 Add
								/* Password Inpu 050411 */
								PassWordSettingFg= iNum;
								PassWordSettingChg= 1;
								iPassFlag = 2;		/* CR Return */
							}else{
								//061124
//								cRetVal[1] = (iNum >> 8) & 0xff;
//								cRetVal[0] = iNum & 0xff;
								cRetVal[0] = (iNum >> 8) & 0xff;
								cRetVal[1] = iNum & 0xff;
								cSaveRetVal[0]= cRetVal[0];
								cSaveRetVal[1]= cRetVal[1];
								PLCWrite(&TouchKeyWriteDev);
								PLCRead(&TouchKeyWriteDev);
								if(memcmp(cRetVal,cSaveRetVal,2) == 0){
									iPreviousScreenNum = iNowScreenNum;
	/*ksc20040727_owashi*/
									MomentaryOff();
//									BaseOnFlag= 1;				/* 040726 */
									BaseChangeFlag1= 1;			/* 040815 */
									BaseChangeFlag2= 1;
	/*ksc20040727_owashi*/
						/*	Delay(10);*/
									iOnSignalStart = ON;
									Key.iCode = -1;
									iKeyVal = ON;
									BaseWriteFlag= 1;			/* 050427 */
								}
//							}else{
//								/* Password Inpu 050411 */
//								PassWordSettingFg= iNum;
//								PassWordSettingChg= 1;
//								iPassFlag = 2;		/* CR Return */
							}
							break;
						}
					}
			/*	}*/
			}
		}
		if(iKeyVal == 1 && 
			(iMainKeyCode == C_DAP || iMainKeyCode == C_AP || iMainKeyCode == UP_DISP ||
			iMainKeyCode == DOWN_DISP || iMainKeyCode == S_A_E || iMainKeyCode == A_A_E ||
			iMainKeyCode == DETAIL || iMainKeyCode == RESET))
		{
			AlarmHistSend();
			AlarmListSend();
		}else if(iKeyVal== ON && iMainKeyCode==PW_RESET){		/*  PassWordLevel zero Setting Code*/
			iPassLevel = 0;
			TouchKeyWriteDev.DevFlag = 1;	
			TouchKeyWriteDev.DevName[0] = CommonArea.SystemDev.Password_Dev.DevName[0];
			TouchKeyWriteDev.DevName[1] = CommonArea.SystemDev.Password_Dev.DevName[1];
			TouchKeyWriteDev.DevName[2] = 0x00;
			TouchKeyWriteDev.DevAddress = CommonArea.SystemDev.Password_Dev.DevAdd;
			TouchKeyWriteDev.DevCnt = 1;
			TouchKeyWriteDev.DevData = cRetVal;
			memset(cRetVal,0x00,sizeof(cRetVal));
			PLCWriteNoWait(&TouchKeyWriteDev);  
			iMainKeyCode = 0;
		}else if(iKeyVal== 1 && iMainKeyCode== PW){		/* PassWord TouchKey Call Code */
			if(BaseWriteFlag == 0){		/* 050427 */
				SwitchingScreenDevice.iBaseScreenFlag = 1;
				iPassFlag = 2;
				iMainKeyCode = 0;
				InputDisplay.iKeyOnOff = 0;
				memset(InputDisplay.cInputDispBuff,0x00,sizeof(InputDisplay.cInputDispBuff));
				BaseChangeFlag2= 1;		/* Revers 050427 */
			}
		}
	/*	TouchSwitchEventTbl->TouchType = 0;*/
	}
	FreeMail((char *)TouchSwitchEventTbl);
/*	iAlternateflag = 0x00; 031017 */
	iKeyVal = 0;
	return(ret);		/* 031128 */
}
/****************************************************/
/*	?�b?�X�C�b??������							*/
/****************************************************/
int TouchKeyDispWatch(int iOrder,int iBackColor)
{
/*	T_MAIL			*mp;*/
	int				i;
/*	int				k;*/
	int				sX;
	int				sY;
	int				eX;
	int				eY;
/*	int				iAlternateKeyVal;*/
/*	DEV_DATA		TouchKeyWriteDev;*/
/*	int				iKeyVal;*/
	int				iKeyVal1;
/*	char			cRetVal[5];*/
/*	char			cDeviceVal[10];*/
	char			cTextBuffer[5];
/*	char			*cScreenDisp;*/
/*	int				iDevWriteFlag;*/	/* TouchKey�� ���� ����� ���������� ���� �÷��� */
/*	int				iRegistNumber;	*/
//	int				iFontsY;
//	int				iFontsX;
/*	unsigned int    iOrdinaryDevVal;*/
/*	long			lValData;*/
/*	int				iNum;*/
/*	int				ret;*/		/* 031128 */
/*ksc20040727_owashi*/
/*	int				BaseOnFlag;*/	/* 040736 */
/*ksc20040727_owashi*/	
/*	_TOUCH_SWITCH_BIT_DEVICE	*BPos;*/
/*	_TOUCH_SWITCH_WORD_DEVICE	*WPos;*/
	_TOUCHSWICH_EVENT_TBL*	 TouchSwitchEventTbl;
	char*			cOffTextContent;
	char*			cOnTextContent;


/*	TouchSwitchEventTbl= (_TOUCHSWICH_EVENT_TBL*)IventTable[iOrder];*/
	TouchSwitchEventTbl= (_TOUCHSWICH_EVENT_TBL*)TakeMemory(sizeof(_TOUCHSWICH_EVENT_TBL));

	GetDispTouchSwitch_Func(TouchSwitchEventTbl,iOrder,1,iBackColor);

	cOffTextContent = (char *)TakeMemory((TouchSwitchEventTbl->iOffTextSize)+1);
	if(TouchSwitchEventTbl->iOffTextSize != 0){
		memcpy(cOffTextContent,TouchSwitchEventTbl->cOffTextContent,TouchSwitchEventTbl->iOffTextSize);
	}
	cOffTextContent[TouchSwitchEventTbl->iOffTextSize]= 0;

	EnterCutting(cOffTextContent);		/* ksc20090515 */

	cOnTextContent = (char *)TakeMemory((TouchSwitchEventTbl->iOnTextSize)+1);
	if(TouchSwitchEventTbl->iOnTextSize != 0){
		memcpy(cOnTextContent,TouchSwitchEventTbl->cOnTextContent,TouchSwitchEventTbl->iOnTextSize);
	}
	cOnTextContent[TouchSwitchEventTbl->iOnTextSize]= 0;

	EnterCutting(cOnTextContent);		/* ksc20090515 */

	i				= iOrder;

	sX = TouchSwitchEventTbl->sX;
	sY = TouchSwitchEventTbl->sY;
	eX = TouchSwitchEventTbl->eX;
	eY = TouchSwitchEventTbl->eY;
	if(TouchSwitchEventTbl->iDispTrigger == 0x00){	/* �L?�g���K? */
/*		iKeyVal1 = TouchSwitchEventTbl->iBefKeyVal;*/
		iKeyVal1= ScreenTagData[iOrder].uu.TouchSw.TouchKeyVal;
	}else{											/* Bit�g���K? */
/*		iKeyVal1 = TouchSwitchEventTbl->iBefKeyDispVal;*/
		iKeyVal1= DispDeviceData[ScreenTagData[iOrder].DevOrder];
	}
/* �V�F�C�v */
	switch(TouchSwitchEventTbl->iShapeOption){
	case NO:
		if(iKeyVal1 == ON){
			if(TouchSwitchEventTbl->iOnTextSize > 0){
//				iFontsX = (int)((eX + sX)/2) - ((int)(strlen(cOnTextContent)/2)*8);
//				iFontsY = (int)((eY + sY)/2) - 8;	

				vTextPositionDisp(&sX, &sY, &eX, &eY,  
					cOnTextContent, 
					TouchSwitchEventTbl->iOnFontSizeH,
					TouchSwitchEventTbl->iOnFontSizeV, 
					TouchSwitchEventTbl->iOnTextColor, 
					ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition);
				if(ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition == 1 || ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition == 3)
				{
					ScreenTagData[iOrder].sX = sX;
					ScreenTagData[iOrder].sY = sY;
					ScreenTagData[iOrder].eX = eX;
					ScreenTagData[iOrder].eY = eY;
				}
			}
		}else{
			if(TouchSwitchEventTbl->iOffTextSize > 0){
//				iFontsX = (int)((eX + sX)/2) - ((int)(strlen(cOffTextContent)/2)*8);
//				iFontsY = (int)((eY + sY)/2) - 8;
				vTextPositionDisp(&sX, &sY, &eX, &eY,  
					cOffTextContent,
					TouchSwitchEventTbl->iOffFontSizeH,
					TouchSwitchEventTbl->iOffFontSizeV,
					TouchSwitchEventTbl->iOffTextColor,
					ScreenTagData[iOrder].uu.TouchSw.iOffFontPosition);
				if(ScreenTagData[iOrder].uu.TouchSw.iOffFontPosition == 1 || ScreenTagData[iOrder].uu.TouchSw.iOffFontPosition == 3)
				{
					ScreenTagData[iOrder].sX = sX;
					ScreenTagData[iOrder].sY = sY;
					ScreenTagData[iOrder].eX = eX;
					ScreenTagData[iOrder].eY = eY;
				}

			}
/*			TouchSwitchEventTbl->iBefKeyDispVal = OFF;*/
		}
		break;

	case BASIC_FIGURE:					
		if(iKeyVal1 == ON){	
			DrawSwitchKey(sX, sY, eX, eY,
				TouchSwitchEventTbl->iOnImgNum,ON,
				TouchSwitchEventTbl->iOnOffFrameColor,
				TouchSwitchEventTbl->iOnSwitchColor );
			if(TouchSwitchEventTbl->iOnTextSize > 0){
//				iFontsX = (int)((eX + sX)/2) - ((int)(strlen(cOnTextContent)/2)*8);
//				iFontsY = (int)((eY + sY)/2) - 8;
				
				memset(cTextBuffer,0x00,sizeof(cTextBuffer));
				/* ASCII�R?�h���� */
				if( iAsciiKeyflag && (TouchSwitchEventTbl->iKeyCode >= 0x20 && TouchSwitchEventTbl->iKeyCode <= 0x37) && 
					CommonArea.KeyWindow.iKeyType == KEY_ASCII)
				{	
					cTextBuffer[0] = (TouchSwitchEventTbl->iKeyCode+(0x18*iAsciiKeyflag));
					cTextBuffer[1] = 0x00;
					vTextPositionDisp(&sX, &sY, &eX, &eY,  
						cTextBuffer, 1, 1, 
						TouchSwitchEventTbl->iOnTextColor, 
						ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition);									
				}else{
/* KSC20070222 �ǹ� ���� */						
#ifdef	OLD
					if(TouchSwitchEventTbl->iOnTextSize != 0x00 &&
						CommonArea.KeyWindow.iKeyType == KEY_ASCII &&
						((strcmp(cOnTextContent,"\xa2\xba") == 0 ||
						strcmp(cOnTextContent,"\xa2\xb8") == 0 ||
						strcmp(cOnTextContent,"\xa1\xe5") == 0 ||
						strcmp(cOnTextContent,"\xa1\xe3") == 0)))
					{
						if(strcmp(cOnTextContent,"\xa2\xba") == 0)
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][3]);
						else if(strcmp(cOnTextContent,"\xa2\xb8") == 0)
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][2]);
						else if(strcmp(cOnTextContent,"\xa1\xe5") == 0)
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][0]);
						else
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][1]);
#else
					if(TouchSwitchEventTbl->iOnTextSize != 0x00 &&
						CommonArea.KeyWindow.iKeyType == KEY_ASCII &&
						((strcmp((char *)cOnTextContent,"\xff\x04") == 0 ||
						strcmp((char *)cOnTextContent,"\xff\x03") == 0 ||
						strcmp((char *)cOnTextContent,"\xff\x02") == 0 ||
						strcmp((char *)cOnTextContent,"\xff\x01") == 0)))
					{
						if(strcmp((char *)cOnTextContent,"\xff\x04") == 0){
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][3]);
						}else if(strcmp((char *)cOnTextContent,"\xff\x03") == 0){
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][2]);
						}else if(strcmp((char *)cOnTextContent,"\xff\x02") == 0){
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][0]);
						}else if(strcmp((char *)cOnTextContent,"\xff\x01") == 0){
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][1]);
						}
#endif

						vTextPositionDisp(&sX, &sY, &eX, &eY,  
							cTextBuffer, 1, 1, 
							TouchSwitchEventTbl->iOnTextColor, 
							ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition);									
					}else{
						vTextPositionDisp(&sX, &sY, &eX, &eY,  
							cOnTextContent, 
							TouchSwitchEventTbl->iOnFontSizeH, 
							TouchSwitchEventTbl->iOnFontSizeV, 
							TouchSwitchEventTbl->iOnTextColor, 
							ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition);									
					}
				}
				if(ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition == 1 || 
					ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition == 3)
				{
					ScreenTagData[iOrder].sX = sX;
					ScreenTagData[iOrder].sY = sY;
					ScreenTagData[iOrder].eX = eX;
					ScreenTagData[iOrder].eY = eY;
				}
/*				TouchSwitchEventTbl->iBefDspSwitch = OFF;*/
			}						
		}else{
			DrawSwitchKey(sX, sY, eX, eY, 
				TouchSwitchEventTbl->iOffImgNum, OFF, 
				TouchSwitchEventTbl->iOnOffFrameColor,
				TouchSwitchEventTbl->iOffSwitchColor );
			if(TouchSwitchEventTbl->iOffTextSize > 0){
//				iFontsX = (int)((eX + sX+1)/2) - ((int)(strlen(cOffTextContent)/2)*8);
//				iFontsY = (int)((eY + sY)/2) - 8;
				memset(cTextBuffer,0x00,sizeof(cTextBuffer));		//2009.11.04
				if( iAsciiKeyflag && (TouchSwitchEventTbl->iKeyCode >= 0x20 && TouchSwitchEventTbl->iKeyCode <= 0x37) &&
					CommonArea.KeyWindow.iKeyType == KEY_ASCII)
				{
					cTextBuffer[0] = (TouchSwitchEventTbl->iKeyCode+(0x18*iAsciiKeyflag));
					cTextBuffer[1] = 0x00;
					vTextPositionDisp(&sX, &sY, &eX, &eY,  
						cTextBuffer, 1, 1, 						/* 1,0->1,1 070209 */
						TouchSwitchEventTbl->iOffTextColor, 
						ScreenTagData[iOrder].uu.TouchSw.iOffFontPosition);									
				}else{
/* KSC20070222 �ǹ� ���� */						
#ifdef	OLD
				if(TouchSwitchEventTbl->iOffTextSize != 0x00 &&
					CommonArea.KeyWindow.iKeyType == KEY_ASCII &&
						((strcmp(cOffTextContent,"\xa2\xba") == 0 ||
						strcmp(cOffTextContent,"\xa2\xb8") == 0 ||
						strcmp(cOffTextContent,"\xa1\xe5") == 0 ||
						strcmp(cOffTextContent,"\xa1\xe3") == 0)))
					{
						if(strcmp(cOffTextContent,"\xa2\xba") == 0 )
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][3]);
						else if(strcmp(cOffTextContent,"\xa2\xb8") == 0)
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][2]);
						else if(strcmp(cOffTextContent,"\xa1\xe5") == 0)
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][0]);
						else
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][1]);
#else
					if(TouchSwitchEventTbl->iOffTextSize != 0x00 &&
						CommonArea.KeyWindow.iKeyType == KEY_ASCII &&
						((strcmp((char *)cOffTextContent,"\xff\x04") == 0 ||
						strcmp((char *)cOffTextContent,"\xff\x03") == 0 ||
						strcmp((char *)cOffTextContent,"\xff\x02") == 0 ||
						strcmp((char *)cOffTextContent,"\xff\x01") == 0)))
					{
						if(strcmp((char *)cOnTextContent,"\xff\x04") == 0){
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][3]);
						}else if(strcmp((char *)cOnTextContent,"\xff\x03") == 0){
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][2]);
						}else if(strcmp((char *)cOnTextContent,"\xff\x02") == 0){
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][0]);
						}else if(strcmp((char *)cOnTextContent,"\xff\x01") == 0){
							strcpy(cTextBuffer,Dspname[ELSMESSAGE].chName[Set.iLang][1]);
						}
#endif


						vTextPositionDisp(&sX, &sY, &eX, &eY,  
							cTextBuffer, 
							1, 
							1, TouchSwitchEventTbl->iOffTextColor,
							ScreenTagData[iOrder].uu.TouchSw.iOffFontPosition);									
					}
					else
					{
						vTextPositionDisp(&sX, &sY, &eX, &eY,  
							cOffTextContent, 
							TouchSwitchEventTbl->iOffFontSizeH, 
							TouchSwitchEventTbl->iOffFontSizeV, 
							TouchSwitchEventTbl->iOffTextColor, 
							ScreenTagData[iOrder].uu.TouchSw.iOffFontPosition);									
					}
					
				}
				/*-------------------------------------------------------------------*/
				if(ScreenTagData[iOrder].uu.TouchSw.iOffFontPosition == 1 || 
					ScreenTagData[iOrder].uu.TouchSw.iOffFontPosition == 3)
				{
					ScreenTagData[iOrder].sX = sX;
					ScreenTagData[iOrder].sY = sY;
					ScreenTagData[iOrder].eX = eX;
					ScreenTagData[iOrder].eY = eY;
				}
			}
/*			TouchSwitchEventTbl->iBefDspSwitch = OFF;*/
		}
		break;

	case PARTS:
		if(iKeyVal1 == ON){
/* 060926			vPartDataSet(TouchSwitchEventTbl->iOnImgNum, i,2,-1);*/
			vPartDataSet(TouchSwitchEventTbl->sX,TouchSwitchEventTbl->sY,TouchSwitchEventTbl->eX,TouchSwitchEventTbl->eY,
						TouchSwitchEventTbl->iOnImgNum, i,2,-1);
				if(TouchSwitchEventTbl->iOnTextSize > 0){
//					iFontsX = (int)((eX + sX)/2) - ((int)(strlen(cOnTextContent)/2)*8);
//					iFontsY = (int)((eY + sY)/2) - 8;

					vTextPositionDisp(&sX, &sY, &eX, &eY,  
						cOnTextContent, 
						TouchSwitchEventTbl->iOnFontSizeH, 
						TouchSwitchEventTbl->iOnFontSizeV, 
						TouchSwitchEventTbl->iOnTextColor,
						ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition);										
					if(ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition == 1 ||
						ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition == 3)
					{
						ScreenTagData[iOrder].sX = sX;
						ScreenTagData[iOrder].sY = sY;
						ScreenTagData[iOrder].eX = eX;
						ScreenTagData[iOrder].eY = eY;
					}
				}
		}else{
/* 060926			vPartDataSet(TouchSwitchEventTbl->iOffImgNum, i,2,-1);*/
			vPartDataSet(TouchSwitchEventTbl->sX,TouchSwitchEventTbl->sY,TouchSwitchEventTbl->eX,TouchSwitchEventTbl->eY,
						TouchSwitchEventTbl->iOffImgNum, i,2,-1);
				if(TouchSwitchEventTbl->iOffTextSize > 0){
//					iFontsX = (int)((eX + sX)/2) - ((int)(strlen(cOffTextContent)/2)*8);
//					iFontsY = (int)((eY + sY)/2) - 8;

					vTextPositionDisp(&sX, &sY, &eX, &eY,  
						cOffTextContent, 
						TouchSwitchEventTbl->iOffFontSizeH, 
						TouchSwitchEventTbl->iOffFontSizeV,
						TouchSwitchEventTbl->iOffTextColor,
						ScreenTagData[iOrder].uu.TouchSw.iOffFontPosition);
					if(ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition == 1 ||
						ScreenTagData[iOrder].uu.TouchSw.iOnFontPosition == 3)
					{
						ScreenTagData[iOrder].sX = sX;
						ScreenTagData[iOrder].sY = sY;
						ScreenTagData[iOrder].eX = eX;
						ScreenTagData[iOrder].eY = eY;
					}
				}
		
		}
	}
	FreeMail(cOffTextContent);
	FreeMail(cOnTextContent);
	FreeMail((char *)TouchSwitchEventTbl);
	return(0);		/* 031128 */
}
int TouchAreaCheck(int sx,int sy,int ex,int ey,int ikeycode)
{
	int	isy;
	int	isx;
	int	iey;
	int	iex;
	int	ireturn;

	isy	= 0;
	isx	= 0;
	iey	= 0;
	iex	= 0;	
	ireturn	= 0;

	if(ikeycode == 0)
	{
		return 0;
	}
#ifdef	SIZE_3224
	if(TateYoko == 0)
	{
		/* �� */
		iex= ((ikeycode- 1)%MAX_COLUM_NO+ 1)*MESH_X- 1;		/* X(1->20) */
		iey= ((ikeycode- 1)/MAX_COLUM_NO+ 1)*MESH_Y- 1;		/* Y(1->12) */
		isx = iex - (MESH_X- 1);
		isy = iey - (MESH_Y- 1);

		if((sx-8) <= isx && (ex+8) >= iex && (sy-10) <= isy && (ey+10) >= iey) 
		{
			ireturn = 1;
		}
	}else
	{
		/* �c */
	}
#endif
#ifdef	SIZE_2480
	if(TateYoko == 0)
	{
//		if(ikeycode >= 46)
//		{
//			iex = ((ikeycode-45)*16)-1;
//			iey = 79;
//		}
//		else if(ikeycode >= 31)
//		{
//			iex = ((ikeycode-30)*16)-1;
//			iey = 59;
//		}
//		else if(ikeycode >= 16)
//		{
//			iex = ((ikeycode-15)*16)-1;
//			iey = 39;
//		}
//		else
//		{
//			iex = ((ikeycode)*16)-1;
//			iey = 19;
//		}
//		isx = iex - 15;
//		isy = iey - 19;

		isx= ((ikeycode- 1) % 15)* MESH_X;
		iex= isx+ (MESH_X- 1);
		isy= ((ikeycode- 1) / 15)* MESH_Y;
		iey= isy+ (MESH_Y- 1);

		if((sx-8) <= isx && (ex+8) >= iex && (sy-10) <= isy && (ey+10) >= iey) 
		{
			ireturn = 1;
		}
	}else
	{
		if((ikeycode%4)==1){
			isx = 0;
			iex = 19;
		}else if((ikeycode%4)==2)
		{
			isx = 20;
			iex = 39;
		}else if((ikeycode%4)==3)
		{
			isx = 40;
			iex = 59;
		}else
		{
			isx = 60;
			iex = 79;
		}
			isy = ((ikeycode-1)/4)*16;
			iey = isy + 15;
		if((sx-10) <= isx && (ex+10) >= iex && (sy-8) <= isy && (ey+8) >= iey) 
		{
			ireturn = 1;
		}
	}
#endif

	return ireturn;
}

/* J.S.LIM 2004/06/01 : ���� ��ƾ�� ������ ���� */
void	DrawSwitchKey(int sX, int sY, int eX, int eY, int ShapeNo, int iKeyVal, int FrameColor, int SwitchColor)
{

	_LINE_INFO		lnWhite;
	_LINE_INFO		lnBlack;
	_RECTANGLE_INFO	RECParam;
	_CIRCLE_INFO	cirParam;
	int				ax, ay, bx, by, cx, cy;
	int				width, height, mid;
	int				r1, r2, z;

	lnWhite.iLineColor = WHITE;
	lnWhite.iLineStyle = SOLID_LINE;

	lnBlack.iLineColor = BLACK;
	lnBlack.iLineStyle = SOLID_LINE;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iPattern	= PAT8;

#ifndef Old
	RECParam.iLineColor = FrameColor;
	RECParam.iForeColor = SwitchColor;
	RECParam.iBackColor = BLACK /* SwitchColor */ ;
#else
	RECParam.iLineColor = WHITE;
	RECParam.iForeColor = WHITE;
	RECParam.iBackColor = WHITE;
	SwitchColor= WHITE;
#endif

	switch(ShapeNo){
	case 1:
	case 2: /* 1st shape */
		RectAngleOut(sX, sY, eX, eY, &RECParam);/* frame color�� �簢�� ������ �׸���, switch color�� ���� ä�� */
		break;
	case 3:
	case 4:/* 2�� shape */
		/* frame color�� �簢�� ������ �׸���, switch color�� ���� ä�� */
		RectAngleOut(sX, sY, eX, eY, &RECParam);

		/* switch color�� �ݴ������ ���� �簢�� �׸� */
		if(SwitchColor==WHITE)
			RECParam.iLineColor = BLACK;
		else
			RECParam.iLineColor = WHITE;
		RectAngleOut(sX+2, sY+2, eX-2, eY-2, &RECParam);
		break;
	
	case 5:/* 3�� ON */
		/* frame color�� �簢�� ������ �׸���, switch color�� ���� ä�� */
		RectAngleOut(sX, sY, eX, eY, &RECParam);
		
		/* ������ ���¸� ǥ���ϴ� ���� �׸� */
		LineOut(sX+1, sY+1, eX-2, sY+1, &lnBlack);
		LineOut(sX+1, sY+1, sX+1, eY-2, &lnBlack);
		LineOut(sX+2, sY+2, eX-3, sY+2, &lnBlack);
		LineOut(sX+2, sY+2, sX+2, eY-3, &lnBlack);
		LineOut(sX+2, eY-2, eX-2, eY-2, &lnWhite);
		LineOut(eX-2, sY+2, eX-2, eY-2, &lnWhite);
		LineOut(sX+1, eY-1, eX-1, eY-1, &lnWhite);
		LineOut(eX-1, sY+1, eX-1, eY-1, &lnWhite);
		break;
	
	case 6:/* 3�� OFF */
		/* frame color�� �簢�� ������ �׸���, switch color�� ���� ä�� */
		RectAngleOut(sX, sY, eX, eY, &RECParam);
		
		/* ������������ ���¸� ǥ���ϴ� ���� �׸� */
		LineOut(sX+1, sY+1, eX-1, sY+1, &lnWhite);
		LineOut(sX+1, sY+1, sX+1, eY-1, &lnWhite);
		LineOut(sX+2, sY+2, eX-2, sY+2, &lnWhite);
		LineOut(sX+2, sY+2, sX+2, eY-2, &lnWhite);
		LineOut(sX+3, eY-2, eX-2, eY-2, &lnBlack);
		LineOut(eX-2, sY+3, eX-2, eY-2, &lnBlack);
		LineOut(sX+2, eY-1, eX-1, eY-1, &lnBlack);
		LineOut(eX-1, sY+2, eX-1, eY-1, &lnBlack);
		break;

	case 7:
	case 8:/* 4�� shape*/
		/* ���� 4��, ������ ������ �ٱ� �簢�� �׸� */
		RECParam.iForeColor = WHITE;
		RECParam.iBackColor = BLACK;
		RECParam.iPattern	= PAT4;
		RectAngleOut(sX, sY, eX, eY, &RECParam);
		
		/* �±� ũ�⿡ ���� ����ġ ��� */
		r1 = (eX-sX)/8+2;
		r2 = (eY-sY)/8+2;

		/* ���� �簢�� ��ǥ */
		ax = sX + r1;
		bx = eX - r1;
		ay = sY + r2;
		by = eY - r2;

		/* ����ġ ������ ���� �簢�� �׸� */
/* 060311
		if(iKeyVal == OFF){
			RECParam.iForeColor = BLACK;
			RECParam.iBackColor = WHITE;
		}
*/
		RECParam.iForeColor = SwitchColor;
		RECParam.iBackColor = FrameColor;

		RECParam.iPattern	= PAT8;
		RectAngleOut(ax, ay, bx, by, &RECParam);

		/* ON/OFF�� ���� ������ ���� */
		if(ShapeNo==7) {
			LineOut(ax, ay, bx, ay, &lnBlack);
			LineOut(ax, ay, ax, by, &lnBlack);
			LineOut(ax, by, bx, by, &lnWhite);
			LineOut(bx, ay, bx, by, &lnWhite);
		}
		else {
			LineOut(ax, ay, bx, ay, &lnWhite);
			LineOut(ax, ay, ax, by, &lnWhite);
			LineOut(ax, by, bx, by, &lnBlack);
			LineOut(bx, ay, bx, by, &lnBlack);
		}
		break;

	case 9:
	case 10:/* 5�� shape: �� */
		/* 3�� shape �׸� */ 
		RectAngleOut(sX, sY, eX, eY, &RECParam);
		if(ShapeNo == 9) {
			LineOut(sX+1, sY+1, eX-1, sY+1, &lnBlack);
			LineOut(sX+1, sY+1, sX+1, eY-1, &lnBlack);
			LineOut(sX+1, eY-1, eX-1, eY-1, &lnWhite);
			LineOut(eX-1, sY+1, eX-1, eY-1, &lnWhite);
		}
		else {
			LineOut(sX+1, sY+1, eX-1, sY+1, &lnWhite);
			LineOut(sX+1, sY+1, sX+1, eY-1, &lnWhite);
			LineOut(sX+1, eY-1, eX-1, eY-1, &lnBlack);
			LineOut(eX-1, sY+1, eX-1, eY-1, &lnBlack);
		}
		
		/* �ﰢ���� �׷��� ������ �ʺ�/���� ��� */
		width  = eX-sX-4;
		height = eY-sY-4;

		if(height/2<width) { /* ������ ���ݺ��� �ʺ� Ŭ �� */
			/* �ﰢ���� ������ ��ǥ��� */
			cx = (2*(sX+eX) + height)/4; /* (cx,cy) ������ ������ ��ǥ */
			cy = (sY+eY)/2;
			ax = cx - height/2;
			ay = cy	- height/2;
			bx = cx - height/2;
			by = cy	+ height/2;
			if(ax<=sX+2) {
				ax++; bx++; cx++;
			}
		}
		else {
			z=(width*5)/6;
			cx = (sX+eX+z)/2;
			cy = (sY+eY)/2;
			ax = cx - z;
			ay = cy	- z;
			bx = cx - z;
			by = cy	+ z;
		}
		/* ����ġ ���� �ٸ� ������ �ﰢ�� �׸� */
//2011.09.08		if(iKeyVal == OFF){
			if(SwitchColor==WHITE)
				DrawTriangleJS(ax,ay,bx,by,cx,cy,BLACK,BLACK,1);
			else
				DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,WHITE,1);
//2011.09.08		}else{
//2011.09.08			if(SwitchColor==WHITE)
//2011.09.08				DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,WHITE,1);
//2011.09.08			else
//2011.09.08				DrawTriangleJS(ax,ay,bx,by,cx,cy,BLACK,BLACK,1);
//2011.09.08		}
		break;

	case 11:
	case 12:/* 6�� shape: �� (5�� shape ����) */
		RectAngleOut(sX, sY, eX, eY, &RECParam);
		if(ShapeNo == 11) {
			LineOut(sX+1, sY+1, eX-1, sY+1, &lnBlack);
			LineOut(sX+1, sY+1, sX+1, eY-1, &lnBlack);
			LineOut(sX+1, eY-1, eX-1, eY-1, &lnWhite);
			LineOut(eX-1, sY+1, eX-1, eY-1, &lnWhite);
		}
		else {
			LineOut(sX+1, sY+1, eX-1, sY+1, &lnWhite);
			LineOut(sX+1, sY+1, sX+1, eY-1, &lnWhite);
			LineOut(sX+1, eY-1, eX-1, eY-1, &lnBlack);
			LineOut(eX-1, sY+1, eX-1, eY-1, &lnBlack);
		}

		width  = eX-sX-4;
		height = eY-sY-4;
		if(height/2<width) {
			cx = (2*(sX+eX) - height)/4;
			cy = (sY+eY)/2;
			ax = cx + height/2;
			ay = cy	- height/2;
			bx = cx + height/2;
			by = cy	+ height/2;
			if(ax<=sX+2) {
				ax++; bx++; cx++;
			}
		}
		else {
			z=(width*5)/6;
			cx = (sX+eX-z)/2;
			cy = (sY+eY)/2;
			ax = cx + z;
			ay = cy	- z;
			bx = cx + z;
			by = cy	+ z;
		}
//2011.09.08		if(iKeyVal == OFF){
			if(SwitchColor==WHITE)
				DrawTriangleJS(ax,ay,bx,by,cx,cy,BLACK,BLACK,2);
			else
				DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,WHITE,2);
//2011.09.08		}else{
//2011.09.08			if(SwitchColor==WHITE)
//2011.09.08				DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,WHITE,2);
//2011.09.08			else
//2011.09.08				DrawTriangleJS(ax,ay,bx,by,cx,cy,BLACK,BLACK,2);
//2011.09.08		}
		break;
	case 13:
	case 14:/* 7�� shape: �� (5�� shape ����) */
		RectAngleOut(sX, sY, eX, eY, &RECParam);
		if(ShapeNo == 13) {
			LineOut(sX+1, sY+1, eX-1, sY+1, &lnBlack);
			LineOut(sX+1, sY+1, sX+1, eY-1, &lnBlack);
			LineOut(sX+1, eY-1, eX-1, eY-1, &lnWhite);
			LineOut(eX-1, sY+1, eX-1, eY-1, &lnWhite);
		}
		else {
			LineOut(sX+1, sY+1, eX-1, sY+1, &lnWhite);
			LineOut(sX+1, sY+1, sX+1, eY-1, &lnWhite);
			LineOut(sX+1, eY-1, eX-1, eY-1, &lnBlack);
			LineOut(eX-1, sY+1, eX-1, eY-1, &lnBlack);
		}

		width  = eX-sX-4;
		height = eY-sY-4;
		if(width/2<height) {
			cx = (sX+eX)/2;
			cy = (2*(sY+eY) - width)/4;
			ax = cx - width/2;
			ay = cy	+ width/2;
			bx = cx + width/2;
			by = cy	+ width/2;
			if(ay>=eY-2) {
				ax--; bx--; cx--;
			}
		}
		else {
			z=(height*5)/6;
			cx = (sX+eX)/2;
			cy = (sY+eY-z)/2;
			ax = cx - z;
			ay = cy	+ z;
			bx = cx + z;
			by = cy	+ z;
		}
//2011.09.08		if(iKeyVal == OFF){
			if(SwitchColor==WHITE)
				DrawTriangleJS(ax,ay,bx,by,cx,cy,BLACK,BLACK,3);
			else
				DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,WHITE,3);
//2011.09.08		}else{
//2011.09.08			if(SwitchColor==WHITE)
//2011.09.08				DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,WHITE,3);
//2011.09.08			else
//2011.09.08				DrawTriangleJS(ax,ay,bx,by,cx,cy,BLACK,BLACK,3);
//2011.09.08		}
		break;
	case 15:
	case 16:/* 8�� shape:�� (5�� shape ����) */
		RectAngleOut(sX, sY, eX, eY, &RECParam);
		if(ShapeNo == 15) {
			LineOut(sX+1, sY+1, eX-1, sY+1, &lnBlack);
			LineOut(sX+1, sY+1, sX+1, eY-1, &lnBlack);
			LineOut(sX+1, eY-1, eX-1, eY-1, &lnWhite);
			LineOut(eX-1, sY+1, eX-1, eY-1, &lnWhite);
		}
		else {
			LineOut(sX+1, sY+1, eX-1, sY+1, &lnWhite);
			LineOut(sX+1, sY+1, sX+1, eY-1, &lnWhite);
			LineOut(sX+1, eY-1, eX-1, eY-1, &lnBlack);
			LineOut(eX-1, sY+1, eX-1, eY-1, &lnBlack);
		}

		width  = eX-sX-4;
		height = eY-sY-4;
		if(width/2<height) {
			cx = (sX+eX)/2;
			cy = (2*(sY+eY) + width)/4;
			ax = cx - width/2;
			ay = cy	- width/2;
			bx = cx + width/2;
			by = cy	- width/2;
			if(ay<=sY+2) {
				ay++; by++; cy++;
			}
		}
		else {
			z=(height*5)/6;
			cx = (sX+eX)/2;
			cy = (sY+eY-z)/2;
			ax = cx - z;
			ay = cy	+ z;
			bx = cx + z;
			by = cy	+ z;
		}
//2011.09.08		if(iKeyVal == OFF){
			if(SwitchColor==WHITE)
				DrawTriangleJS(ax,ay,bx,by,cx,cy,BLACK,BLACK,4);
			else
				DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,WHITE,4);
//2011.09.08		}else{
//2011.09.08			if(SwitchColor==WHITE)
//2011.09.08				DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,WHITE,4);
//2011.09.08			else
//2011.09.08				DrawTriangleJS(ax,ay,bx,by,cx,cy,BLACK,BLACK,4);
//2011.09.08		}
		break;
	case 17:
	case 18:
	case 19:
	case 20:/* 9,10�� shape */
		if(ShapeNo==17 || ShapeNo==18) {/* 9�� shape: �簢�� ���θ� ���������� ä�� */
			RECParam.iForeColor = BLACK;
			RectAngleOut(sX, sY, eX, eY, &RECParam);
		}
		else {/* 10�� shape: �簢�� ���θ� ������� ä�� */
			RECParam.iForeColor = WHITE;
			RectAngleOut(sX, sY, eX, eY, &RECParam);
		}
		
		/* �ʺ�/���̸� ���� "��Ʈ��"�� Ȧ���� �ǵ��� �ٱ� ���� �׷��� ���� ���� */
		width = eX-sX;
		if(width%2 != 0) {
			width--;
			eX--;
		}
		height= eY-sY;
		if(height%2 != 0) {
			height--;
			eY--;
		}
		/* �ʺ�/���̰� ���������� �ٱ� ���� �׷��� ���� ���� */
		if(width<height) {
			mid = (sY+eY)/2;
			sY = mid - width/2;
			eY = mid + width/2;
		}
		else {
			mid = (sX+eX)/2;
			sX = mid-height/2;
			eX = mid+height/2;
		}
		
		/* ���λ��� ���, ���δ� ���������� ä���� ���� �׸��� */
		cirParam.iLineColor = WHITE;
		cirParam.iPattern = PAT8;
		cirParam.iForeColor= BLACK;
		cirParam.iBackColor= BLACK;
		DrawCircle((sX+eX)/2, (sY+eY)/2, (eX-sX)/2, &cirParam);

		/* ON/OFF�� ���� ���� �簢���� �׷��� ��ġ ���� */
		if(ShapeNo==17 || ShapeNo==19) {/* ON�� �� ���Ϸ� ġ��ģ �� */
			sX+=4;
			sY+=4;
			eX-=2;
			eY-=2;
		}
		else {/* OFF�� �� �»����� ġ��ģ �� */
			sX+=2;
			sY+=2;
			eX-=4;
			eY-=4;
		}
		/* ����ġ������ ä���� ���ʿ� �׸� */
		cirParam.iForeColor= SwitchColor;
		DrawCircle((sX+eX)/2, (sY+eY)/2, (eX-sX)/2, &cirParam);
		break;
	case 100:
		RectAngleOut(sX, sY, eX, eY, &RECParam);
		break;
	default:
		RectAngleOut(sX+1, sY+1, eX-1, eY-1, &RECParam);
		break;
	}
}

/* J.S.LIM 2004/05/31 ---------------------------- */
/* ��ġŰ 5,6,7,8shape�� �ʿ��� �ﰢ�� �׸��� �Լ� */
//void DrawTriangleJS(short ax,short ay,short bx,short by,short cx,short cy,short LineColor,short FillColor, int iType)
void DrawTriangleJS(short ax,short ay,short bx,short by,short cx,short cy,unsigned long LineColor,unsigned long FillColor, int iType)
{
	_LINE_INFO	lnOutLine;
	_LINE_INFO	lnFill;
	int			length;
	int			x, y;
	
	lnOutLine.iLineColor = LineColor;
	lnOutLine.iLineStyle = SOLID_LINE;

	lnFill.iLineColor = FillColor;
	lnFill.iLineStyle = SOLID_LINE;

	switch(iType) {
	case 1:
		length=cx-ax;
		for(x=0; x<length; x++)
			LineOut(cx-x, cy-x, cx-x, cy+x, &lnFill);
		break;
	case 2:
		length=ax-cx;
		for(x=0; x<length; x++)
			LineOut(cx+x, cy-x, cx+x, cy+x, &lnFill);
		break;
	case 3:
		length=ay-cy;
		for(y=0; y<length; y++)
			LineOut(cx-y, cy+y, cx+y, cy+y, &lnFill);
		break;
	case 4:
		length=cy-ay;
		for(y=0; y<length; y++)
			LineOut(cx-y, cy-y, cx+y, cy-y, &lnFill);
		break;
	case 5:
		length=ay-cy+ 1;
		for(y=0; y<length; y++)
			LineOut(cx-y, cy+y, cx+y, cy+y, &lnFill);
		break;
	case 6:
		length=cy-ay+ 1;
		for(y=0; y<length; y++)
			LineOut(cx-y, cy-y, cx+y, cy-y, &lnFill);
		break;
	}
	
	if((iType == 5) || (iType == 6)){
	}else{
		LineOut(ax, ay, bx, by, &lnOutLine);
	}
	LineOut(bx, by, cx, cy, &lnOutLine);
	LineOut(cx, cy, ax, ay, &lnOutLine);
}
/* -------------------------------------------------------- */
