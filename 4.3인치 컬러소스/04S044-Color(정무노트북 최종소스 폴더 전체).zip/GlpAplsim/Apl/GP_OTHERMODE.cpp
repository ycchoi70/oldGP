/* ****************************************************************************** */
/*  �� �� �� : GP_OTHERMODE.CPP														 */
/*  ��    �� : HPP��� �޴� ó��												 */
/*  �� �� �� : 2002�� 2�� 15�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */

#include	"sgt.h"

#ifdef	SIZE_2480
/* ****************************************************************************** */
/*  ���� ���� ����																 */
/* ****************************************************************************** */

/* ****************************************************************************** */
/*  �Լ�																			 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �� �� �� : SetFuntionMode()													 */
/*  ��    �� : ��Ÿ ��ɵ� ���� .												 */
/*  ��    �� : iScreenNo(���� ȭ�� ��ȣ)										 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 6�� 27�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void	SetFuntionMode(int *iScreenNo){

	int			iKeyCode;
	int			iSetFlag; 
	short		i;
	short		j;
	short		iKeyFlag;
	short		ScreenNum;
	int			iflag;

	iSetFlag	= 1;
	iKeyFlag	= 1;
	ScreenNum   = SET_FUNTION_NUM*100+1;	//20091222
	while ( *iScreenNo == SET_FUNTION_NUM ) {
		if(iSetFlag == 2)
			AreaClear(0,0,GAMEN_X_SIZE-1,GAMEN_Y_SIZE-1,0);
		DefaultFormDisplay(4 , Dspname[SET_FUNTION].chTitle[Set.iLang]);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */

		i = 0;
		iKeyCode = -1;
		while (iKeyCode == -1 || iKeyCode == 0) {
			if(iSetFlag == 1 || iSetFlag == 2)
			{
				AreaClear(GAMEN_START_X+0,GAMEN_START_Y+23,GAMEN_START_X+197,GAMEN_START_Y+79,0);
				for(j=0;j<3;j++)
				{
					DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+(NLine_2+(j*18)),(Dspname[SET_FUNTION].chName[Set.iLang][i+j]),1,1, TRANS, T_WHITE, T_BLACK);		
				}
			/*	ScroolBarDisplay(4, i);*/
				ScroolBarDisplay(3, 0);

				DrawLcdBank1();	
				iSetFlag = 0;
			}

			iKeyCode = KeyWaitData(iKeyFlag,SET_FUNTION_NUM);
			iKeyFlag = 0;
			if(!((iKeyCode >= KEY_03 && iKeyCode <= KEY_12 ) ||
				 iKeyCode == KEY_28 || iKeyCode == KEY_43 || 
				 iKeyCode == KEY_58 || iKeyCode == 0))
			{
				iKeyFlag = 1;
				NormalBuzzer();										/*	Buzzer			*/
			}

			if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
			{												
				*iScreenNo = DOWN_TRANS;
				break;
			}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
			{
				*iScreenNo = UP_TRANS;
				break;
			}
			/* Ű ���� ó�� */		
			if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02)
			{
				*iScreenNo = USER_SCREEN_NUM;	
			}else if(iKeyCode >= KEY_13 && iKeyCode <= KEY_15) 
			{									/*  ����, ���� ��ưŬ���� */						
				*iScreenNo = SELECT_MEMU_NUM;	
			} else if (iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ) 
			{
				iflag = iSysSetretCheck(ScreenNum + i);
				if(iflag == DOWN_TRANS)		/* DownLoad */
					*iScreenNo = DOWN_TRANS;
				else if(iflag == UP_TRANS)	/* UPLoad */
					*iScreenNo = UP_TRANS;
				else if(iflag == 0)			/* ȭ���̵� ó�� */
					*iScreenNo = ScreenNum + i;										/*  ȭ�����			 */
				else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = SET_FUNTION_NUM;
					iSetFlag = 2;
					break;
				}
			} else if (iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ) 
			{
				iflag = iSysSetretCheck(ScreenNum + 1 + i);
				if(iflag == DOWN_TRANS)		/* DownLoad */
					*iScreenNo = DOWN_TRANS;
				else if(iflag == UP_TRANS)	/* UPLoad */
					*iScreenNo = UP_TRANS;
				else if(iflag == 0)			/* ȭ���̵� ó�� */
					*iScreenNo = ScreenNum + 1 + i;										/*  ȭ�����			 */
				else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = SET_FUNTION_NUM;
					iSetFlag = 2;
					break;
				}
			} else if (iKeyCode >= KEY_46 && iKeyCode <= KEY_57 ) 
			{
				iflag = iSysSetretCheck(ScreenNum + 2 + i);
				if(iflag == DOWN_TRANS)		/* DownLoad */
					*iScreenNo = DOWN_TRANS;
				else if(iflag == UP_TRANS)	/* UPLoad */
					*iScreenNo = UP_TRANS;
				else if(iflag == 0)			/* ȭ���̵� ó�� */
					*iScreenNo = ScreenNum + 2 + i;										/*  ȭ�����			 */
				else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = SET_FUNTION_NUM;
					iSetFlag = 2;
					break;
				}
			} else if (iKeyCode >= KEY_58 && iKeyCode <= KEY_60 ) 
			{
			/*	if(i != 1){
					iSetFlag = 1;
					i = 1;*/												/*  �޴� ���� ����		  */	
			/*	}						
				KerRepeatFlag = 1;*/
				iKeyCode = -1;
			} else if (iKeyCode >= KEY_28 && iKeyCode <= KEY_30 ) 
			{
			/*	if(i != 0){
					iSetFlag = 1;
					i = 0;*/												/*  �޴� ���� �ø�		  */	
				/*}						
				KerRepeatFlag = 1;*/
				iKeyCode = -1;
			}else{
				iKeyCode = -1;
			} 			
		} 	
	} 
	KerRepeatFlag = 0;
	return;
}
#endif

