/********************************************/
/*	System Message For English				*/
/********************************************/
#include	"Gpstruct.h"
#ifdef	WIN32
#define	const
#endif

#ifdef	LP_S044
extern	volatile	const _DISPLAY DspnameData[];
#ifdef	WIN32
volatile	const DISPLAY_TBL	DspnameTbl=
{
	2,
	{
		(_DISPLAY *)&DspnameData,
	}
};
#endif

volatile	const _DISPLAY DspnameData[] =
/*ksc20040727*/ /* ������ �޴��� ���� */
{
	{	/* 0 */
		{"[SELECT MENU]","[SELECT MENU]"},				/*0		0 ùȭ�� 0 */
		{
			{"MONITORING","SET ENVIRONMENT","DATA VIEW"   ,"SET FUNCTION","LP PARAMETER SETTING","","","","",},
			{"MONITORING","SET ENVIRONMENT","DATA VIEW"   ,"SET FUNCTION","LP PARAMETER SETTING","","","","",},
		}
	},
			
	{	/* 1 */
		{"[MONITORING]","[MONITORING]"},						/*2		1 HPP MODEȭ�� */
		{
				{"DEVICE MONITORING"  ,"DON`T MONITORING."           ,"I/O DEVICE MONITORING","","","","","","","",""},
				{"DEVICE MONITORING"  ,"DON`T MONITORING."           ,"I/O DEVICE MONITORING","","","","","","","",""},
		}
	},
/*ksc20040727*/ /* ��� = DEV, ���� = SET���� ���� */							
	{	/* 2 */
		{"[DEVICE MONITOR]","[DEVICE MONITOR]"},			/* 2-1	2 DEVICE MONITORTȭ�� */
		{
			{"DEV.","SET","ON ","OFF ","DEVICE ERROR" ,"CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""},
			{"DEV.","SET","ON ","OFF ","DEVICE ERROR" ,"CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""},
		}
	},

	{	/* 3 */
		{"[DATA VIEW]","[DATA VIEW]"},					/* 3	3 ACTIVE STATE MONTORȭ�� */
		{
			{"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE","MODEL & VERSION","","","","","",""},
			{"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE","MODEL & VERSION","","","","","",""},
		}
	},

	{	/* 4 */
		{"[BASE SCREEN]","[BASE SCREEN]"},					/* 3-1	4 PC DIAGNOSISȭ�� */
		{
			{"","","","","","","","","","",""},
			{"","","","","","","","","","",""}
		}
	},

	{	/* 5 */
		{"[WINDOW SCREEN]","[WINDOW SCREEN]"},				/* 3-2	5 TEST MODEȭ�� */
		{
			{"INVALID ","VALUE..." ,"","","","","","","","",""},
			{"INVALID ","VALUE..." ,"","","","","","","","",""},
		}
	},
/*ksc20040727*/ 
	{	/* 6 */
		{"[COMMENT]","[COMMENT]"},							/* 3-3	6 USER SCRRENȭ��			*/
		{
			{"DISPLAY SCREEN IS NOT","AVAILABLE ","DISPLAY ","SCREEN ","IS NOT"   ,"AVAILABLE ","PLC NO CONNECTION",         "PLC ","NO ","CONNECTION",""},
			{"DISPLAY SCREEN IS NOT","AVAILABLE ","DISPLAY ","SCREEN ","IS NOT"   ,"AVAILABLE ","PLC NO CONNECTION",         "PLC ","NO ","CONNECTION",""},
		}
	},

/*ksc20040517 */ /* ���� = ���� = ������� ���� */
	{	/* 7 */
		{"[MEMORY SIZE]","[MEMORY SIZE]"},				/* 4	7 OTHER MODEȭ��		*/
		{
			{"TOTAL MEMORY:","USER AREA   :","AVAILABLE   :","","","","","","","",""},
			{"TOTAL MEMORY:","USER AREA   :","AVAILABLE   :","","","","","","","",""},
		}
	},
/*ksc20040517*/	
						
	{	/* 8 */
		{"[SET FUNCTION]","[SET FUNCTION]"},					/* 4-1-1~8 8 SET TIME SWITCHȭ�� */
		{
			{"DATA TRANSFER","TIME SWITCH", "PRINT OUT",   "","SET ",   "NUMBER ","IS ",     "INCORRECT","","SET NUMBER IS INCORRECT.",""},
			{"DATA TRANSFER","TIME SWITCH", "PRINT OUT",   "","SET ",   "NUMBER ","IS ",     "INCORRECT","","SET NUMBER IS INCORRECT.",""},
		}
	},
						
/*ksc20040517 SET, ���� �߰� */
	{	/* 9 */
		{"[TIME SWITCH]","[TIME SWITCH]"},					/* 4-2	9 DATA TRANSFERȭ�� */
		{
			{"SUN","MON","TUE","WED","THU","FRI","SAT","ACT START TIME" ,"ACT END TIME"   ,"SET" ,""},
			{"SUN","MON","TUE","WED","THU","FRI","SAT","ACT START TIME" ,"ACT END TIME"   ,"SET" ,""},
		}
	},
/*ksc20040517*/	
/*ksc20040727*/ /* GP, PC �߰� */	
	{	/* 10 */
		{"[DATA TRANSFER]","[DATA TRANSFER]"},				/* 4-3	10 PRINT OUTȭ��			*/
		{
			{"TRANSFER STATE","WAITING...","DOWNLOADING...","UPLOADING...","NO PRINT MODE"          ,"","GP","PC","","",""},
			{"TRANSFER STATE","WAITING...","DOWNLOADING...","UPLOADING...","NO PRINT MODE"          ,"","GP","PC","","",""},
		}
	},
/*ksc20040727*/	
	{	/* 11 */
		{"[PRINT OUT]","[PRINT OUT]"},					/* 4-5	11 SET-UP MODEȭ�� */
		{
			{"ALARM HISTORY" ,"PRINT?"             ,"YES" ,"NO"      ,"" ,"" ,"" ,"" ,"" ,"" ,""},
			{"ALARM HISTORY" ,"PRINT?"             ,"YES" ,"NO"      ,"" ,"" ,"" ,"" ,"" ,"" ,""},
		}
	},

	{	/* 12 */
		{"[SET ENVIRONMENT]","[SET ENVIRONMENT]"},				/* 4-5-1	12 LANGUAGEȭ�� */
		{
			{"LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"CLEAR USER DATA"    ,"MENU CALL KEY","BUZZER" ,"OPENING"          ,"BACKLIGHT","BATTERY","CONTRAST"},
			{"LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"CLEAR USER DATA"    ,"MENU CALL KEY","BUZZER" ,"OPENING"          ,"BACKLIGHT","BATTERY","CONTRAST"},
		}
	},

	{	/* 13 */
		{"[CLOCK]","[CLOCK]"},							/* 4-5-2 13 PLC TYPEȭ�� */
		{
			{"","","","","","","","","","",""},
			{"","","","","","","","","","",""}
		}
	},

/*ksc20040517 GODIC, EPRCS �߰� */
	{	/* 14 */
		{"[LANGUAGE]","[LANGUAGE]"},						/* 4-5-3 14 SERIAL PORTȭ�� */
		{
			{"LANG ","ASCII " ,"SYSTEM LANG" ,"ENGLISH" ,"ENGLISH","GULIM","DODUM","","","",""}, /* "DON'T USE","USE" */
			{"LANG ","ASCII " ,"SYSTEM LANG" ,"ENGLISH" ,"ENGLISH","GULIM","DODUM","","","",""}, /* "DON'T USE","USE" */
		}
	}, /* "������ ","����� " */
/*ksc20040517*/	
	{	/* 15 */
		{"[BACKLIGHT]","[BACKLIGHT]"},						/* 4-5-4 15 OPENING SCREENȭ�� */
		{
			{"BACKLIGHT OFF" ,"MIN","","","","","","","","",""},
			{"BACKLIGHT OFF" ,"MIN","","","","","","","","",""},
		}
	},

	{	/* 16 */
		{"[BATTERY SIZE]","[BATTERY SIZE]"},						/* 4-5-5 16 MAIN MENU CALL KEYȭ�� */
		{
			{"","","","","","","","","","","PASSWORD IS INCORRECT"},
			{"","","","","","","","","","","PASSWORD IS INCORRECT"},
		}
	},

	{	/* 17 */
		{"[BUZZER]","[BUZZER]"},							/* 4-5-8 17 BUZZERȭ�� */
		{
			{"BUZZER ON"   ,"BUZZER OFF"  ,"OFF "      ,"ON "     ,"","","","","","",""},
			{"BUZZER ON"   ,"BUZZER OFF"  ,"OFF "      ,"ON "     ,"","","","","","",""},
		}
	},

	{	/* 18 */
		{"[OPENING TIME]","[OPENING TIME]"},			/* 4-5-7 18 SET BACKLIGHTȭ�� */
		{
			{"OPENING TIME","SEC","","","","","","","","",""},
			{"OPENING TIME","SEC","","","","","","","","",""},
		}
	},
/*ksc20040727*/ /* ADP - GP�� ���� */
	{	/* 19 */   /* ksc20070306 */
		{"[PLC SETTING]","[PLC SETTING]"},						/* 4-5-8 19 BUZZERȭ�� */
		{
			{"PLC1","PLC2","LP ST.#" ,"  CH1 ST.#" ,"NO USE","A PORT","B PORT","","","",""},
			{"PLC1","PLC2","LP ST.#" ,"  CH1 ST.#" ,"NO USE","A PORT","B PORT","","","",""},
		}
	},
/*ksc20040727*/
	{	/* 20 */
		{"[SERIAL PORT]","[SERIAL PORT]"},					/* 4-5-9 20 LCD CONTRASTȭ�� */
		{
			{"CON"  ,"B/R"  ,"DATA"   ,"STOP"     ,"PARITY","F/C "     ,"EDITOR"  ,"PRINTER" ,"BARCODE" ,"MONITOR","PLC2"},
			{"CON"  ,"B/R"  ,"DATA"   ,"STOP"     ,"PARITY","F/C "     ,"EDITOR"  ,"PRINTER" ,"BARCODE" ,"MONITOR","PLC2"},
		}
	},

	{	/* 21 */
		{"[MENU CALL KEY]","[MENU CALL KEY]"},				/* 4-5-10 21 CLEAR USER DATAȭ�� */
		{
			{"SELECT"    ,"CALL KEY"   ,"","","","","","","","",""},
			{"SELECT"    ,"CALL KEY"   ,"","","","","","","","",""},
		}
	},

	{	/* 22 */
		{"[CLEAR USER DATA]"," [CLEAR USER DATA] "},				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
		{
			{"CLEAR GP DATA? "          ,""                              ,"YES" ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""},
			{"CLEAR GP DATA? "          ,""                              ,"YES" ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""},
		}
	},

	{	/* 23 */
		{"[CONTRAST]","[CONTRAST]"},						/* 4-5-5 23 Contrast > */
		{
/*			{" �� "," �� "," �� "," �� ","�� ","","","","","",""}, */
/*			{" �� "," �� "," �� "," �� ","�� ","","","","","",""}  */
			{"\xff\x02","\xff\x01","\xff\x03","\xff\x04","\xff\x04","","","","","",""},
			{"\xff\x02","\xff\x01","\xff\x03","\xff\x04","\xff\x04","","","","","",""}
		}
	},

	{	/* 24 */
		{"[PLC SETTING]","[PLC SETTING]"},						/* 24 PLC SETTING */
		{
			{" CH1"," CH2","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"},
			{" CH1"," CH2","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"}
		}
	},

	{	/* 25 */
		{"END","���� "},						/* 25 RS-232C SETTING */
		{
#ifdef SBD0 
			{"UNIVERSAL","MK-200S(CPU)","RS422 ","RS232C"},
			{"UNIVERSAL","MK-200S(CPU)","RS422 ","RS232C"}
#endif
#ifdef SBD1
			{"UNIVERSAL","MK-200S(CPU)","RS232C","RS232C"},
			{"UNIVERSAL","MK-200S(CPU)","RS232C","RS232C"}
#endif
		}
	},
	{	/* 26 */
		{"ALARM","ALARM"},						/* 26 NO USER DATA */
		{
			{"USER "  ,"SCREEN ","IS NOT "   ,"FOUND","Exit" ,"Menu" },
			{"USER "  ,"SCREEN ","IS NOT "   ,"FOUND","Exit" ,"Menu" }
		}
	},
	{	/* 27 */
		{"[MODEL & VERSION]","[MODEL & VERSION]"},		/* 25 */				
		{
			{"MODEL NAME:","F/W VERSION:","","","","","","","","",""},
			{"MODEL NAME:","F/W VERSION:","","","","","","","","",""}
		}
	},
	{	/* 28 */
		{"[LP EXT BOARD]","[LP EXT BOARD]"},		/* GLP EXTEN BOARD SELECT	*/
		{
			{"Exit" ,"[LP EXT BOARD]","Menu" ,"","","","","","","","","","","",""},
			{"Exit" ,"[LP EXT BOARD]","Menu" ,"","","","","","","","","","","",""}
		}
	},
	{	/* 29 */
		{"[SET PARAMETER]","[SET PARAMETER]"},			/* EXTERN IO SELECT	*/
		{
			{"Exit" ,"[SET PARAMETER]","Menu" ,"FILTER","INTERRUPT","4 X 4 KEYPAD","7 SEGMENT DISPLAY","SYNCHRONOUS SERIAL","PULS","ENCODE","COUNTER","PATARN","","",""},
			{"Exit" ,"[SET PARAMETER]","Menu" ,"FILTER","INTERRUPT","4 X 4 KEYPAD","7 SEGMENT DISPLAY","SYNCHRONOUS SERIAL","PULS","ENCODE","COUNTER","PATARN","","",""}
		}
	},
	{	/* 30 */
		{"[SET FILTER]","[SET FILTER]"},			/* FILTER	*/
		{
			{"Exit" ,"[SET FILTER]","Menu" ,"DEVICE","DEV_CONT","","","","","","","","","",""},
			{"Exit" ,"[SET FILTER]","Menu" ,"DEVICE","DEV_CONT","","","","","","","","","",""}
		}
	},
	{	/* 31 */
		{"[SET INTERRUPT]","[SET INTERRUPT]"},		/* INTERRUPT	*/
		{
			{"Exit" ,"[SET INTERRUPT]","Menu" ,"NO INT ","RISING ","FALLING","DISABLE","","","","","","","",""},
			{"Exit" ,"[SET INTERRUPT]","Menu" ,"NO INT ","RISING ","FALLING","DISABLE","","","","","","","",""}
		}
	},
	{	/* 32 */
		{"[SET 4 X 4 KEYPAD]","[SET 4 X 4 KEYPAD]"},				/* 10KEY		*/
		{
			{"Exit" ,"[SET 4 X 4 KEYPAD]","Menu" ,"USE_INF","IN_PORT","OUT_PORT","DISABLE","ENABLE    ","X00->X03","X08->X0B","Y00->Y03","Y08->Y0B","","",""},
			{"Exit" ,"[SET 4 X 4 KEYPAD]","Menu" ,"USE_INF","IN_PORT","OUT_PORT","DISABLE","ENABLE    ","X00->X03","X08->X0B","Y00->Y03","Y08->Y0B","","",""}
		}
	},
	{	/* 33 */
		{"[SET 7 SEGMENT]","[SET 7 SEGMENT]"},				/* 7SEG		*/
		{
			{"Exit" ,"[SET 7 SEGMENT]"  ,"Menu" ,"USE_INF","COM_PORT","OUT_PORT","DISABLE","ENABLE    ","Y00->Y03","Y08->Y0B","Y00->Y07","Y08->Y0F","","","",""},
			{"Exit" ,"[SET 7 SEGMENT]"  ,"Menu" ,"USE_INF","COM_PORT","OUT_PORT","DISABLE","ENABLE    ","Y00->Y03","Y08->Y0B","Y00->Y07","Y08->Y0F","","","",""}
		}
	},
	{	/* 34 */
		{"[SYNCHRONOUS SERIAL]","[SYNCHRONOUS SERIAL]"},				/* SYNC		*/
		{
			{"Exit" ,"[SYNCHRONOUS]",     "Menu" ,"USE_INF","OUT_PORT","DATA BIT","COUNT","DEVICE","ADDRESS","DISABLE"  ,"ENABLE  ","Y04->X06","Y0C->Y0E","DEVICE"},
			{"Exit" ,"[SYNCHRONOUS]",     "Menu" ,"USE_INF","OUT_PORT","DATA BIT","COUNT","DEVICE","ADDRESS","DISABLE"  ,"ENABLE  ","Y04->X06","Y0C->Y0E","DEVICE"}
		}
	},
	{	/* 35 */
		{"[SET PULS]","[SET PULS]"},				/* PULS		*/
		{
			{"Exit" ,"[SET PULS]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y07","Y0F","","","","","",""},
			{"Exit" ,"[SET PULS]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y07","Y0F","","","","","",""}
		}
	},
	{	/* 36 */
		{"[SET ENCODE]","[SET ENCODE]"},				/* ENCODE		*/
		{
			{"Exit" ,"[SET ENCODE]","Menu" ,"USE_INF","IN_PORT","OUT_PORT","NOT USE","USE    ","X04->X06","X0C->X0E","Y03","Y0B","","","",""},
			{"Exit" ,"[SET ENCODE]","Menu" ,"USE_INF","IN_PORT","OUT_PORT","NOT USE","USE    ","X04->X06","X0C->X0E","Y03","Y0B","","","",""}
		}
	},
	{	/* 37 */
		{"[SET COUNT]","[SET COUNT]"},				/* COUNT		*/
		{
			{"Exit" ,"[SET COUNT]","Menu" ,"USE_INF","IN_PORT","NOT USE","USE    ","X07","X0F","","","","","",""},
			{"Exit" ,"[SET COUNT]","Menu" ,"USE_INF","IN_PORT","NOT USE","USE    ","X07","X0F","","","","","",""}
		}
	},
	{	/* 38 */
		{"[SET PATARN]","[SET PATARN]"},			/* PATARN		*/
		{
			{"Exit" ,"[SET PATARN]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y04->Y07","Y0C->Y0F","","","","","",""},
			{"Exit" ,"[SET PATARN]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y04->Y07","Y0C->Y0F","","","","","",""}
		}
	},
	{	/* 39 */
		{"[CLEAR USER DATA]","[CLEAR USER DATA]"},	/* 3	3 ACTIVE STATE MONTORȭ�� */
		{
			{"CLEAR GP DATA"   ,"CLEAR LP DATA"   ,"","","","","","","","",""},
			{"CLEAR GP DATA"   ,"CLEAR LP DATA"   ,"","","","","","","","",""}
		}
	},
	{	/* 40 */
		{"[CLEAR LP DATA]","[CLEAR LP DATA]"},				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
		{
			{"CLEAR LP DATA? "          ,""                              ,"YES" ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""},
			{"CLEAR LP DATA? "          ,""                              ,"YES" ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""}
		}
	},
	{	/* 41 */
		{"[I/O MONITORING] ","[I/O MONITORING]"},				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
		{
			{"","","","","","","","","","",""},
			{"","","","","","","","","","",""}
		}
	},
	{	/* 42 */
		{"[CONNECTION DETAIL]","[CONNECTION DETAIL]"},				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
		{
			{"CH1:" ,"CH2:" ,"" ,"" ,"" ,"","","","","",""},
			{"CH1:" ,"CH2:" ,"" ,"" ,"" ,"","","","","",""}
		}
	},

};
#endif

#ifdef	GP_S057
/****************************************************/
/*	GP_S057(320X240)									*/
/****************************************************/
extern	volatile	const _DISPLAY DspnameData[];
extern	volatile	const _DISPLAY1	LargDispName[];
#ifdef	WIN32
volatile	const DISPLAY_TBL	DspnameTbl=
{
	2,
	{
		(_DISPLAY *)&DspnameData,
		(_DISPLAY *)&LargDispName,
	}
};
#endif
volatile	const _DISPLAY DspnameData[] =
/*ksc20040727*/ /* ������ �޴��� ���� */
{
	{	/* 0 */
		{"[SELECT MENU]","[SELECT MENU]"},				/*0		0 ùȭ�� 0 */
			{
			{"Exit" ,"[SELECT MENU]"     ,"MONITORING","SET ENVIRONMENT","DATA VIEW"   ,"SET FUNCTION","Menu" ,},
			{"Exit" ,"[SELECT MENU]"     ,"MONITORING","SET ENVIRONMENT","DATA VIEW"   ,"SET FUNCTION","Menu" ,},
		}
	},
		
	{	/* 1 */
		{"[MONITORING]","[MONITORING]"},						/*2		1 HPP MODEȭ�� */
		{
			{"Exit" ,"[MONITORING]","DEVICE MONITOR"  ,"Menu" ,"DON`T MONITOR."           ,"","","","","","","","",""},
			{"Exit" ,"[MONITORING]","DEVICE MONITOR"  ,"Menu" ,"DON`T MONITOR."           ,"","","","","","","","",""},
		}
	},
/*ksc20040727*/ /* ��� = DEV, ���� = SET���� ���� */							
	{	/* 2 */
		{"[DEVICE MONITOR]","[DEVICE MONITOR]"},			/* 2-1	2 DEVICE MONITORTȭ�� */
		{
			{"Exit" ,"[DEVICE MONITOR]" ,"Menu" ,"DEVICE","SET","ON","OFF ","DEVICE ERROR" ,"CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""},
			{"Exit" ,"[DEVICE MONITOR]" ,"Menu" ,"DEVICE","SET","ON","OFF ","DEVICE ERROR" ,"CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""},
		}
	},
/*ksc20040727*/ /* ���� = ������� ����. �϶� ���� */
	{	/* 3 */
		{"[DATA VIEW]","[DATA VIEW]"},					/* 3	3 ACTIVE STATE MONTORȭ�� */
		{
			{"Exit" ,"[DATA VIEW]"  ,"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE"      ,"Menu" ,"MODEL & VERSION"  ,"","","",},
			{"Exit" ,"[DATA VIEW]"  ,"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE"      ,"Menu" ,"MODEL & VERSION"  ,"","","",},
		}
	},

	{	/* 4 */
		{"[BASE SCREEN]","[BASE SCREEN]"},					/* 3-1	4 PC DIAGNOSISȭ�� */
		{
			{"Exit" ,"[BASE SCREEN]","Menu" ,"","","","","","","","","","","",""},
			{"Exit" ,"[BASE SCREEN]","Menu" ,"","","","","","","","","","","",""},
		}
	},

	{	/* 5 */
		{"[WINDOW SCREEN]","[WINDOW SCREEN]"},				/* 3-2	5 TEST MODEȭ�� */
		{
			{"Exit" ,"[WINDOW SCREEN]","Menu" ,"INVALID ","VALUE...""","","","","","","","","",""},
			{"Exit" ,"[WINDOW SCREEN]","Menu" ,"INVALID ","VALUE...""","","","","","","","","",""},
		}
	},
	{	/* 6 */
		{"[COMMENT]","[COMMENT]"},							/* 3-3	6 USER SCRRENȭ��			*/
		{
			{"DISPLAY SCREEN IS NOT","AVAILABLE ","DISPLAY ","SCREEN ","IS NOT"   ,"AVAILABLE ","PLC NO CONNECTION",         "PLC ","NO ","CONNECTION",""},
			{"DISPLAY SCREEN IS NOT","AVAILABLE ","DISPLAY ","SCREEN ","IS NOT"   ,"AVAILABLE ","PLC NO CONNECTION",         "PLC ","NO ","CONNECTION",""},
		}
	},

/*ksc20040517 */ /* ���� = ���� = ������� ���� */
	{	/* 7 */
		{"[MEMORY SIZE]","[MEMORY SIZE]"},				/* 4	7 OTHER MODEȭ��		*/
		{
			{"Exit" ,"[MEMORY SIZE]"     ,"Menu" ,"TOTAL MEMORY:","USER AREA   :","AVAILABLE   :","","","","","","","",""},
			{"Exit" ,"[MEMORY SIZE]"     ,"Menu" ,"TOTAL MEMORY:","USER AREA   :","AVAILABLE   :","","","","","","","",""},
		}
	},
/*ksc20040517*/	
						
	{	/* 8 */
		{"[SET FUNCTION]","[SET FUNCTION]"},					/* 4-1-1~8 8 SET TIME SWITCHȭ�� */
		{
			{"DATA TRANSFER","TIME SWITCH", "PRINT OUT",   "","SET ",   "NUMBER ","IS ",     "INCORRECT","","SET NUMBER IS INCORRECT.",""},
			{"DATA TRANSFER","TIME SWITCH", "PRINT OUT",   "","SET ",   "NUMBER ","IS ",     "INCORRECT","","SET NUMBER IS INCORRECT.",""},
		}
	},
						
/*ksc20040517 SET, ���� �߰� */
	{	/* 9 */
		{"[TIME SWITCH]","[TIME SWITCH]"},					/* 4-2	9 DATA TRANSFERȭ�� */
		{
			{"Exit" ,"[TIME SWITCH]","Menu" ,"WEEK","SUN","MON","TUE","WED","THU","FRI","SAT","ACTION","START TIME"     ,"","END TIME"       ,""},
			{"Exit" ,"[TIME SWITCH]","Menu" ,"WEEK","SUN","MON","TUE","WED","THU","FRI","SAT","ACTION","START TIME"     ,"","END TIME"       ,""},
		}
	},
	{	/* 10 */
		{"[DATA TRANSFER]","[DATA TRANSFER]"},				/* 4-3	10 PRINT OUTȭ��			*/
		{
			{"Exit" ,"[DATA TRANSFER]","Menu" ,"TRANSFER STATE","GP","PC","WAITING...","DOWNLOADING...","UPLOADING...","NO PRINT MODE"          ,"","",""},
			{"Exit" ,"[DATA TRANSFER]","Menu" ,"TRANSFER STATE","GP","PC","WAITING...","DOWNLOADING...","UPLOADING...","NO PRINT MODE"          ,"","",""},
		}
	},
	{	/* 11 */
		{"[PRINT OUT]","[PRINT OUT]"},					/* 4-5	11 SET-UP MODEȭ�� */
		{
			{"Exit" ,"[PRINT OUT]"  ,"Menu" ,"ALARM HISTORY" ,"PRINT?"             ,"YES" ,"NO"      ,"" ,"" ,"" ,"" ,"" ,"" ,""},
			{"Exit" ,"[PRINT OUT]"  ,"Menu" ,"ALARM HISTORY" ,"PRINT?"             ,"YES" ,"NO"      ,"" ,"" ,"" ,"" ,"" ,"" ,""},
		}
	},

	{	/* 12 */
		{"[SET ENVIRONMENT]","[SET ENVIRONMENT]"},				/* 4-5-1	12 LANGUAGEȭ�� */
		{
			//0       1                  2            3             4            5               6       7         8                   9           10        11           12                    13
			{"Exit" ,"[SET ENVIRONMENT]","LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"MENU CALL KEY","Menu" ,"BUZZER" ,"OPENING"          ,"BACKLIGHT","BATTERY","CONTRAST"  ,"CLEAR USER DATA"    ,"13","14","15"},
			{"Exit" ,"[SET ENVIRONMENT]","LANGUAGE"  ,"PLC SETTING","CLOCK"     ,"MENU CALL KEY","Menu" ,"BUZZER" ,"OPENING"          ,"BACKLIGHT","BATTERY","CONTRAST"  ,"CLEAR USER DATA"    ,"13","14","15"},
		}
	},

	{	/* 13 */
		{"[CLOCK]","[CLOCK]"},							/* 4-5-2 13 PLC TYPEȭ�� */
		{
			{"","","","","","","","","","","","","","","",""},
			{"","","","","","","","","","","","","","","",""}
		}
	},

/*ksc20040517 GODIC, EPRCS �߰� */
	{	/* 14 */
		{"[LANGUAGE]","[LANGUAGE]"},						/* 4-5-3 14 SERIAL PORTȭ�� */
		{
//				{"Exit" ,"[LANGUAGE]" ,"Menu" ,"LANG ","ASCII " ,"" ,"KOREAN" ,"ENGLISH","GODIC","EPRCS","","ENGLISH","KOREAN" }, /* "DON'T USE","USE" */
//				{"Exit" ,"[LANGUAGE]" ,"Menu" ,"LANG ","ASCII " ,"" ,"KOREAN" ,"ENGLISH","GODIC","EPRCS","","ENGLISH","KOREAN" }, /* "DON'T USE","USE" */
			{"Exit" ,"[LANGUAGE]" ,"Menu" ,"LANG ","FONT","LANGUAGE","ENGLISH" ,"ASCII " ,"FONT","","","ENGLISH","ENGLISH" ,"GULIM","DODUM"},
			{"Exit" ,"[LANGUAGE]" ,"Menu" ,"LANG ","FONT","LANGUAGE","ENGLISH" ,"ASCII " ,"FONT","","","ENGLISH","ENGLISH" ,"GULIM","DODUM"},
		}
	}, /* "������ ","����� " */
/*ksc20040517*/	
													
	{	/* 15 */
		{"[BACKLIGHT]","[BACKLIGHT]"},						/* 4-5-4 15 OPENING SCREENȭ�� */
		{
			{"BACKLIGHT OFF" ,"MIN","","","","","","","","",""},
			{"BACKLIGHT OFF" ,"MIN","","","","","","","","",""},
		}
	},

	{	/* 16 */
		{"[BATTERY SIZE]","[BATTERY SIZE]"},						/* 4-5-5 16 MAIN MENU CALL KEYȭ�� */
		{
			{"Exit" ,"[BATTERY SIZE]" ,"Menu" ,"0","100","BATTERY :","","","","","PASSWORD IS INCORRECT"},
			{"Exit" ,"[BATTERY SIZE]" ,"Menu" ,"0","100","BATTERY :","","","","","PASSWORD IS INCORRECT"},
		}
	},

	{	/* 17 */
		{"[BUZZER]","[BUZZER]"},							/* 4-5-8 17 BUZZERȭ�� */
		{
			{"Exit" ,"[BUZZER]","Menu" ,"BUZZER SETTING","BUZZER ON"   ,"BUZZER OFF"  ,"OFF","ON ","","","","",""},
			{"Exit" ,"[BUZZER]","Menu" ,"BUZZER SETTING","BUZZER ON"   ,"BUZZER OFF"  ,"OFF","ON ","","","","",""},
		}
	},

	{	/* 18 */
		{"[OPENING TIME]","[OPENING TIME]"},			/* 4-5-7 18 SET BACKLIGHTȭ�� */
		{
			{"OPENING TIME","SEC","","","","","","","","",""},
			{"OPENING TIME","SEC","","","","","","","","",""}
		}
	},
/*ksc20040727*/ /* ADP - GP�� ���� */
	{	/* 19 */
		{"[PLC SETTING]","[PLC SETTING]"},						/* 4-5-8 19 BUZZERȭ�� */
		{
			{"PLC1","PLC2","GP ST.#" ,"  CH1 ST.#" ,"NO USE","","","","","",""},
			{"PLC1","PLC2","GP ST.#" ,"  CH1 ST.#" ,"NO USE","","","","","",""},
		}
	},
/*ksc20040727*/
	{	/* 20 */
		{"[SERIAL PORT]","[SERIAL PORT]"},					/* 4-5-9 20 LCD CONTRASTȭ�� */
		{
			{"CON"  ,"B/R"  ,"DATA"   ,"STOP"     ,"PARITY","F/C "     ,"EDITOR"  ,"PRINTER" ,"BARCODE" ,"MONITOR","PLC2"},
			{"CON"  ,"B/R"  ,"DATA"   ,"STOP"     ,"PARITY","F/C "     ,"EDITOR"  ,"PRINTER" ,"BARCODE" ,"MONITOR","PLC2"},
		}
	},

	{	/* 21 */
		{"[MENU CALL KEY]","[MENU CALL KEY]"},				/* 4-5-10 21 CLEAR USER DATAȭ�� */
		{
			{"Exit" ,"[MENU CALL KEY]","Menu" ,"SELECT CALL KEY"      ,""   ,"","","","","","","","",""},
			{"Exit" ,"[MENU CALL KEY]","Menu" ,"SELECT CALL KEY"      ,""   ,"","","","","","","","",""},
		}
	},

	{	/* 22 */
		{"[CLEAR USER DATA]","[CLEAR USER DATA]"},				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
		{
			{"Exit" ,"[CLEAR USER DATA]","    CLEAR USER DATA? "     ,"Menu" ,"      NOW CLEARING...."       ,"YES","  NO"   ,"","      NOW CLEARING....  "        ,"","","","",""},
			{"Exit" ,"[CLEAR USER DATA]","    CLEAR USER DATA? "     ,"Menu" ,"      NOW CLEARING...."       ,"YES","  NO"   ,"","      NOW CLEARING....  "        ,"","","","",""},
		}
	},

	{	/* 23 */
		{"[CONTRAST]","[CONTRAST]"},						/* 4-5-5 23 Contrast > */
		{
/*			{" �� "," �� "," �� "," �� ","�� ","","","","","",""}, */
/*			{" �� "," �� "," �� "," �� ","�� ","","","","","",""}  */
			{"\xff\x02","\xff\x01","\xff\x03","\xff\x04","\xff\x04","","","","","",""},
			{"\xff\x02","\xff\x01","\xff\x03","\xff\x04","\xff\x04","","","","","",""}
		}
	},

	{	/* 24 */
		{"[PLC SETTING]","[PLC SETTING]"},						/* 24 PLC SETTING */
		{
			{" CH1"," CH2","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"},
			{" CH1"," CH2","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"}
		}
	},
	{	/* 25 */
		{"END","END"},						/* 25 RS-232C SETTING */
		{
#ifdef SBD0 
			{"UNIVERSAL","MK-200S(CPU)","RS422 ","RS232C","A PORT","B PORT"},
			{"UNIVERSAL","MK-200S(CPU)","RS422 ","RS232C","A PORT","B PORT"}
#endif
#ifdef SBD1 
			{"UNIVERSAL","MK-200S(CPU)","RS232C","RS232C","A PORT","B PORT"},
			{"UNIVERSAL","MK-200S(CPU)","RS232C","RS232C","A PORT","B PORT"}
#endif
		}
	},
	{	/* 26 */
		{"ALARM","ALARM"},						/* 26 NO USER DATA */
		{
			{"USER "  ,"SCREEN ","IS NOT "   ,"FOUND","Exit" ,"Menu" },
			{"USER "  ,"SCREEN ","IS NOT "   ,"FOUND","Exit" ,"Menu" }
		}
	},
	{	/* 27 */
		{"[MODEL & VERSION]","[MODEL & VERSION]"},		/* 25 */				
		{
			{"Exit" ,"[MODEL & VERSION]"  ,"Menu" ,"MODEL NAME:","FIRMWARE VERSION:","","","","","","","","",""},
			{"Exit" ,"[MODEL & VERSION]"  ,"Menu" ,"MODEL NAME:","FIRMWARE VERSION:","","","","","","","","",""}
		}
	},
	{	/* 28 */
		{"[CONTRAST]","[CONTRAST]"},			/* 4-5-5 27 MAIN MENU CALL KEYȭ�� */
		{
			{"Exit" ,"[CONTRAST]" ,"Menu" ,"CONTRAST"},
			{"Exit" ,"[CONTRAST]" ,"Menu" ,"CONTRAST"}
		}
	},
	{	/* 29 */
		{"[COMMENT]","[COMMENT]"},									/* 3-3	6 USER SCRRENȭ��			*/
		{
			{"Exit" ,"[COMMENT]","Menu" ,"","","","","","","","","","","",""},
			{"Exit" ,"[COMMENT]","Menu" ,"","","","","","","","","","","",""}
		}
	},
	{	/* 30 */
		{"[SET FUNCTION]","[SET FUNCTION]"},			/* 4-1-1~8 8 SET TIME SWITCHȭ�� */
		{
			{"Exit" ,"[SET FUNCTION]","Menu" ,"DATA TRANSFER","TIME SWITCH", "PRINT OUT"  ,"","","","","","","",""},
			{"Exit" ,"[SET FUNCTION]","Menu" ,"DATA TRANSFER","TIME SWITCH", "PRINT OUT"  ,"","","","","","","",""}
		}
	},
	{	/* 31 */
		{"[TIME SWITCH]","[TIME SWITCH]"},							/* 4-2	9 DATA TRANSFERȭ�� */
		{
			{"SU" ,"MO" ,"TU" ,"WE" ,"TH" ,"FR" ,"SA" ,"","","",""},
			{"SU" ,"MO" ,"TU" ,"WE" ,"TH" ,"FR" ,"SA" ,"","","",""}
		}
	},
	{	/* 32 */
		{"[LATCH DEVICE]","[LATCH DEVICE]"},				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */	/* 20091222 */
		{
			{"Exit" ,"[LATCH DEVICE] ","Menu ","UW DEVICE LATCH SETTING  ","LATCH ON ","LATCH OFF ","OFF ","ON ","LATCH DEVICE ","","","","","",""},
			{"Exit" ,"[LATCH DEVICE] ","Menu ","UW DEVICE LATCH SETTING  ","LATCH ON ","LATCH OFF ","OFF ","ON ","LATCH DEVICE ","","","","","",""}
		}
	},
};


volatile	const	_DISPLAY1	LargDispName[]=
{
	{	/* 0 */
		{"[PLC SETTING]","[PLC SETTING]"  },			/* 4-5-5 0 PLC Setting */
		{
			{"Exit" ,"[PLC SETTING]","Menu" ,
				"CH1 INF","","","","B/R","DATA","   STOP","PARITY","FLOW/C","GP ST.#",
				"CH1 ST.#","","","","","","CH2 INF","","","B/R",
				"DATA","   STOP","PARITY","FLOW/C","","","","","","","","","","",},
			{"Exit" ,"[PLC SETTING]","Menu" ,
				"CH1 INF","","","","B/R","DATA","   STOP","PARITY","FLOW/C","GP ST.#",
				"CH1 ST.#","","","","","","CH2 INF","","","B/R",
				"DATA","   STOP","PARITY","FLOW/C","","","","","","","","","","",}
		}
	},
	{	/* 1 */
		{"[CLOCK]","[CLOCK]"},							/* 4-5-2 13 PLC TYPEȭ�� */
		{
			{"Exit" ,"[CLOCK]"    ,"Menu" ,"","","0","1","2","3","4","5","6","7","8","9","CLR","ENT",""},
			{"Exit" ,"[CLOCK]"    ,"Menu" ,"","","0","1","2","3","4","5","6","7","8","9","CLR","ENT",""}
		}
	},
	{	/* 2 */
		{"[OPENING TIME]","[OPENING TIME]"},				/* 4-5-7 18 SET BACKLIGHTȭ�� */
		{
			{"Exit" ,"[OPENING TIME]"    ,"Menu" ,"0","1","2","3","4","5","6","7","8","9","CLR","ENT","OPENING TIME","SEC",},
			{"Exit" ,"[OPENING TIME]"    ,"Menu" ,"0","1","2","3","4","5","6","7","8","9","CLR","ENT","OPENING TIME","SEC",}
		}
	},
	{	/* 3 */
		{"[OPENING TIME]","[OPENING TIME]"},				/* 4-5-7 18 SET BACKLIGHTȭ�� */
		{
			{"CLR","ENT"," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "},
			{"CLR","ENT"," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "}
		}
	},
	{	/* 4 */
		{"[TIME SWITCH]","[TIME SWITCH]"},							/* 4-2	9 DATA TRANSFERȭ�� */
		{
			{"Exit" ,"[TIME SWITCH]"    ,"Menu" ,
				"DEVICE","START","END",
				"1","","","",
				"2","","","",
				"3","","","",
				"4","","","",
				"5","","","",
				"6","","","",
				"7","","","",
				"8","","","",
				"NUM","",""},
			{"Exit" ,"[TIME SWITCH]"    ,"Menu" ,
				"DEVICE","START","END",
				"1","","","",
				"2","","","",
				"3","","","",
				"4","","","",
				"5","","","",
				"6","","","",
				"7","","","",
				"8","","","",
				"NUM","",""}
		}
	},
};
#endif

#ifdef	GP_S044
extern	volatile	const _DISPLAY DspnameData[];
#ifdef	WIN32
volatile	const DISPLAY_TBL	DspnameTbl=
{
	2,
	{
		(_DISPLAY *)&DspnameData,
	}
};
#endif

volatile	const _DISPLAY DspnameData[] =
/*ksc20040727*/ /* ������ �޴��� ���� */
{
	{	/* 0 */
		{"[SELECT MENU]","[SELECT MENU]"},				/*0		0 ùȭ�� 0 */
		{
			{"MONITORING","SET ENVIRONMENT","DATA VIEW","SET FUNCTION","USER ","SCREEN ","IS NOT ","FOUND","","Exit","Menu"},
			{"MONITORING","SET ENVIRONMENT","DATA VIEW","SET FUNCTION","USER ","SCREEN ","IS NOT ","FOUND","","Exit","Menu"}
		}
	},
			
	{	/* 1 */
		{"[MONITORING]","[MONITORING]"},						/*2		1 HPP MODEȭ�� */
		{
			{"DEVICE MONITOR","DON`T MONITOR.","","","","","","","","",""},
			{"DEVICE MONITOR","DON`T MONITOR.","","","","","","","","",""}
		}
	},
/*ksc20040727*/ /* ��� = DEV, ���� = SET���� ���� */							
	{	/* 2 */
		{"[DEVICE MONITOR]","[DEVICE MONITOR]"},			/* 2-1	2 DEVICE MONITORTȭ�� */
		{
			{"DEV.","SET","ON","OFF","DEVICE ERROR","CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""},
			{"DEV.","SET","ON","OFF","DEVICE ERROR","CAN NOT USE THE FUNCTION","WHILE PROTECTED.","","","",""}
		}
	},

	{	/* 3 */
		{"[DATA VIEW]","[DATA VIEW]"},					/* 3	3 ACTIVE STATE MONTORȭ�� */
		{
			{"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE","MODEL & VERSION","","","","","",""},
			{"BASE SCREEN","WINDOW SCREEN","COMMENT","MEMORY SIZE","MODEL & VERSION","","","","","",""}
		}
	},

	{	/* 4 */
		{"[BASE SCREEN]","[BASE SCREEN]"},					/* 3-1	4 PC DIAGNOSISȭ�� */
		{
			{"","","","","","","","","","",""},
			{"","","","","","","","","","",""}
		}
	},

	{	/* 5 */
		{"[WINDOW SCREEN]","[WINDOW SCREEN]"},				/* 3-2	5 TEST MODEȭ�� */
		{
			{"INVALID ","VALUE..." ,"","","","","","","","",""},
			{"INVALID ","VALUE...","","","","","","","","",""}
		}
	},
/*ksc20040727*/ 
	{	/* 6 */
		{"[COMMENT]","[COMMENT]"},							/* 3-3	6 USER SCRRENȭ��			*/
		{
			{"DISPLAY SCREEN IS NOT","AVAILABLE ","DISPLAY ","SCREEN ","IS NOT"   ,"AVAILABLE ","PLC NO CONNECTION",         "PLC ","NO ","CONNECTION",""},
			{"DISPLAY SCREEN IS NOT","AVAILABLE ","DISPLAY ","SCREEN ","IS NOT"   ,"AVAILABLE ","PLC NO CONNECTION","PLC ","NO ","CONNECTION",""}
		}
	},

/*ksc20040517 */ /* ���� = ���� = ������� ���� */
	{	/* 7 */
		{"[MEMORY SIZE]","[MEMORY SIZE]"},				/* 4	7 OTHER MODEȭ��		*/
		{
			{"TOTAL MEMORY:","USER AREA   :","AVAILABLE   :","","","","","","","",""},
			{"TOTAL MEMORY:","USER AREA   :","AVAILABLE   :","","","","","","","",""}
		}
	},
/*ksc20040517*/	
						
	{	/* 8 */
		{"[SET FUNCTION]","[SET FUNCTION]"},					/* 4-1-1~8 8 SET TIME SWITCHȭ�� */
		{
			{"DATA TRANSFER","TIME SWITCH", "PRINT OUT",   "","SET ",   "NUMBER ","IS ",     "INCORRECT","","SET NUMBER IS INCORRECT.",""},
			{"DATA TRANSFER","TIME SWITCH","PRINT OUT","","SET ","NUMBER ","IS ","INCORRECT","","SET NUMBER IS INCORRECT.",""}
		}
	},
						
/*ksc20040517 SET, ���� �߰� */
	{	/* 9 */
		{"[TIME SWITCH]","[TIME SWITCH]"},					/* 4-2	9 DATA TRANSFERȭ�� */
		{
			{"SUN","MON","TUE","WED","THU","FRI","SAT","ACT START TIME" ,"ACT END TIME"   ,"SET" ,""},
			{"SUN","MON","TUE","WED","THU","FRI","SAT","ACT START TIME","ACT END TIME","SET",""}
		}
	},
/*ksc20040517*/	
/*ksc20040727*/ /* GP, PC �߰� */	
	{	/* 10 */
		{"[DATA TRANSFER]","[DATA TRANSFER]"},				/* 4-3	10 PRINT OUTȭ��			*/
		{
			{"TRANSFER STATE","WAITING...","DOWNLOADING...","UPLOADING...","","","GP","PC","","",""},
			{"TRANSFER STATE","WAITING...","DOWNLOADING...","UPLOADING...","","","GP","PC","","",""}
		}
	},
/*ksc20040727*/	
	{	/* 11 */
		{"[PRINT OUT]","[PRINT OUT]"},					/* 4-5	11 SET-UP MODEȭ�� */
		{
			{"ALARM HISTORY","PRINT?","YES","NO","OK","NO PRINT MODE","","","","",""},
			{"ALARM HISTORY","PRINT?","YES","NO","OK","NO PRINT MODE","","","","",""}
		}
	},

	{	/* 12 */
		{"[SET ENVIRONMENT]","[SET ENVIRONMENT]"},				/* 4-5-1	12 LANGUAGEȭ�� */
		{
			{"LANGUAGE","PLC SETTING","CLOCK","CLEAR USER DATA","MENU CALL KEY","BUZZER","OPENING","BACKLIGHT","BATTERY","CONTRAST","LATCH DEVICE"},
			{"LANGUAGE","PLC SETTING","CLOCK","CLEAR USER DATA","MENU CALL KEY","BUZZER","OPENING","BACKLIGHT","BATTERY","CONTRAST","LATCH DEVICE"}
		}
	},

	{	/* 13 */
		{"[CLOCK]","[CLOCK]"},							/* 4-5-2 13 PLC TYPEȭ�� */
		{
			{"","","","","","","","","","",""},
			{"","","","","","","","","","",""}
		}
	},

/*ksc20040517 GODIC, EPRCS �߰� */
	{	/* 14 */
		{"[LANGUAGE]","[LANGUAGE]"},						/* 4-5-3 14 SERIAL PORTȭ�� */
		{
			{"LANG ","ASCII ","SYSTEM LANG","ENGLISH","ENGLISH","DODUM","DODUM","","","",""}, /* "DON'T USE","USE" */
			{"LANG ","ASCII ","SYSTEM LANG","ENGLISH","ENGLISH","DODUM","DODUM","","","",""}
		}
	}, /* "������ ","����� " */
/*ksc20040517*/	
													
	{	/* 15 */
		{"[BACKLIGHT]","[BACKLIGHT]"},						/* 4-5-4 15 OPENING SCREENȭ�� */
		{
			{"BACKLIGHT OFF" ,"MIN","","","","","","","","",""},
			{"BACKLIGHT OFF","MIN","","","","","","","","",""}
		}
	},

	{	/* 16 */
		{"[BATTERY SIZE]","[BATTERY SIZE]"},						/* 4-5-5 16 MAIN MENU CALL KEYȭ�� */
		{
			{"","","","","","","","","","","PASSWORD IS INCORRECT"},
			{"","","","","","","","","","","PASSWORD IS INCORRECT"}
		}
	},

	{	/* 17 */
		{"[BUZZER]","[BUZZER]"},							/* 4-5-8 17 BUZZERȭ�� */
		{
			{"BUZZER ON","BUZZER OFF","OFF","ON","","","","","","",""},
			{"BUZZER ON","BUZZER OFF","OFF","ON","","","","","","",""}
		}
	},

	{	/* 18 */
		{"[OPENING TIME]","[OPENING TIME]"},			/* 4-5-7 18 SET BACKLIGHTȭ�� */
		{
			{"OPENING TIME","SEC","","","","","","","","",""},
			{"OPENING TIME","SEC","","","","","","","","",""}
		}
	},
/*ksc20040727*/ /* ADP - GP�� ���� */
	{	/* 19 */   /* ksc20070306 */
		{"[PLC SETTING]","[PLC SETTING]"},						/* 4-5-8 19 BUZZERȭ�� */
		{
			{"PLC1","PLC2","GP ST.#","  CH1 ST.#","NO USE","","","","","",""},
			{"PLC1","PLC2","GP ST.#","  CH1 ST.#","NO USE","","","","","",""}
		}
	},
/*ksc20040727*/
	{	/* 20 */
		{"[SERIAL PORT]","[SERIAL PORT]"},					/* 4-5-9 20 LCD CONTRASTȭ�� */
		{
			{"CON"  ,"B/R"  ,"DATA"   ,"STOP"     ,"PARITY","F/C "     ,"EDITOR"  ,"PRINTER" ,"BARCODE" ,"MONITOR","PLC2"},
			{"CON","B/R","DATA","STOP","PARITY","F/C ","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"}
		}
	},

	{	/* 21 */
		{"[MENU CALL KEY]","[MENU CALL KEY]"},				/* 4-5-10 21 CLEAR USER DATAȭ�� */
		{
			{"SELECT"    ,"CALL KEY"   ,"","","","","","","","",""},
			{"SELECT","CALL KEY","","","","","","","","",""}
		}
	},

	{	/* 22 */
		{"[CLEAR USER DATA]"," [CLEAR USER DATA] "},				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
		{
			{"CLEAR USER DATA? ","","YES","NO","NOW CLEARING....","","","","","",""},
			{"CLEAR USER DATA? ","","YES","NO","NOW CLEARING....","","","","","",""}
		}
	},

	{	/* 23 */
		{"[CONTRAST]","[CONTRAST]"},						/* 4-5-5 23 Contrast > */
		{
/*			{" �� "," �� "," �� "," �� ","�� ","","","","","",""}, */
/*			{" �� "," �� "," �� "," �� ","�� ","","","","","",""}  */
			{"\xff\x02","\xff\x01","\xff\x03","\xff\x04","\xff\x04","","","","","",""},
			{"\xff\x02","\xff\x01","\xff\x03","\xff\x04","\xff\x04","","","","","",""}
		}
	},

	{	/* 24 */
		{"[PLC SETTING]","[PLC SETTING]"},						/* 24 PLC SETTING */
		{
			{" CH1"," CH2","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"},
			{" CH1"," CH2","EDITOR","PRINTER","BARCODE","MONITOR","PLC2"}
		}
	},

	{	/* 25 */
		{"[END]","[END] "},						/* 25 RS-232C SETTING */
		{
#ifdef SBD0 
			{"UNIVERSAL","MK-200S(CPU)","RS422 ","RS232C"},
			{"UNIVERSAL","MK-200S(CPU)","RS422 ","RS232C"}
#endif
#ifdef SBD1
			{"UNIVERSAL","MK-200S(CPU)","RS232C","RS232C"},
			{"UNIVERSAL","MK-200S(CPU)","RS232C","RS232C"}
#endif
		}
	},
	{	/* 26 */
		{"[ALARM]","[ALARM]"},						/* 26 NO USER DATA */
		{
			{"USER "  ,"SCREEN ","IS NOT "   ,"FOUND","Exit" ,"Menu" },
			{"USER "  ,"SCREEN ","IS NOT "   ,"FOUND","Exit" ,"Menu" }
		}
	},
	{	/* 27 */
		{"[MODEL & VERSION]","[MODEL & VERSION]"},		/* 25 */				
		{
			{"MODEL NAME:","F/W VERSION:","","","","","","","","",""},
			{"MODEL NAME:","F/W VERSION:","","","","","","","","",""}
		}
	},
	{	/* 28 */
		{"[LP EXT BOARD]","[LP EXT BOARD]"},		/* GLP EXTEN BOARD SELECT	*/
		{
			{"Exit" ,"[LP EXT BOARD]","Menu" ,"","","","","","","","","","","",""},
			{"Exit" ,"[LP EXT BOARD]","Menu" ,"","","","","","","","","","","",""}
		}
	},
	{	/* 29 */
		{"[SET PARAMETER]","[SET PARAMETER]"},			/* EXTERN IO SELECT	*/
		{
			{"Exit" ,"[SET PARAMETER]","Menu" ,"FILTER","INTERRUPT","4 X 4 KEYPAD","7 SEGMENT DISPLAY","SYNCHRONOUS SERIAL","PULS","ENCODE","COUNTER","PATARN","","",""},
			{"Exit" ,"[SET PARAMETER]","Menu" ,"FILTER","INTERRUPT","4 X 4 KEYPAD","7 SEGMENT DISPLAY","SYNCHRONOUS SERIAL","PULS","ENCODE","COUNTER","PATARN","","",""}
		}
	},
	{	/* 30 */
		{"[SET FILTER]","[SET FILTER]"},			/* FILTER	*/
		{
			{"Exit" ,"[SET FILTER]","Menu" ,"DEVICE","DEV_CONT","","","","","","","","","",""},
			{"Exit" ,"[SET FILTER]","Menu" ,"DEVICE","DEV_CONT","","","","","","","","","",""}
		}
	},
	{	/* 31 */
		{"[SET INTERRUPT]","[SET INTERRUPT]"},		/* INTERRUPT	*/
		{
			{"Exit" ,"[SET INTERRUPT]","Menu" ,"NO INT ","RISING ","FALLING","DISABLE","","","","","","","",""},
			{"Exit" ,"[SET INTERRUPT]","Menu" ,"NO INT ","RISING ","FALLING","DISABLE","","","","","","","",""}
		}
	},
	{	/* 32 */
		{"[SET 4 X 4 KEYPAD]","[SET 4 X 4 KEYPAD]"},				/* 10KEY		*/
		{
			{"Exit" ,"[SET 4 X 4 KEYPAD]","Menu" ,"USE_INF","IN_PORT","OUT_PORT","DISABLE","ENABLE    ","X00->X03","X08->X0B","Y00->Y03","Y08->Y0B","","",""},
			{"Exit" ,"[SET 4 X 4 KEYPAD]","Menu" ,"USE_INF","IN_PORT","OUT_PORT","DISABLE","ENABLE    ","X00->X03","X08->X0B","Y00->Y03","Y08->Y0B","","",""}
		}
	},
	{	/* 33 */
		{"[SET 7 SEGMENT]","[SET 7 SEGMENT]"},				/* 7SEG		*/
		{
			{"Exit" ,"[SET 7 SEGMENT]"  ,"Menu" ,"USE_INF","COM_PORT","OUT_PORT","DISABLE","ENABLE    ","Y00->Y03","Y08->Y0B","Y00->Y07","Y08->Y0F","","","",""},
			{"Exit" ,"[SET 7 SEGMENT]"  ,"Menu" ,"USE_INF","COM_PORT","OUT_PORT","DISABLE","ENABLE    ","Y00->Y03","Y08->Y0B","Y00->Y07","Y08->Y0F","","","",""}
		}
	},
	{	/* 34 */
		{"[SYNCHRONOUS SERIAL]","[SYNCHRONOUS SERIAL]"},				/* SYNC		*/
		{
			{"Exit" ,"[SYNCHRONOUS]",     "Menu" ,"USE_INF","OUT_PORT","DATA BIT","COUNT","DEVICE","ADDRESS","DISABLE"  ,"ENABLE  ","Y04->X06","Y0C->Y0E","DEVICE"},
			{"Exit" ,"[SYNCHRONOUS]",     "Menu" ,"USE_INF","OUT_PORT","DATA BIT","COUNT","DEVICE","ADDRESS","DISABLE"  ,"ENABLE  ","Y04->X06","Y0C->Y0E","DEVICE"}
		}
	},
	{	/* 35 */
		{"[SET PULS]","[SET PULS]"},				/* PULS		*/
		{
			{"Exit" ,"[SET PULS]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y07","Y0F","","","","","",""},
			{"Exit" ,"[SET PULS]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y07","Y0F","","","","","",""}
		}
	},
	{	/* 36 */
		{"[SET ENCODE]","[SET ENCODE]"},				/* ENCODE		*/
		{
			{"Exit" ,"[SET ENCODE]","Menu" ,"USE_INF","IN_PORT","OUT_PORT","NOT USE","USE    ","X04->X06","X0C->X0E","Y03","Y0B","","","",""},
			{"Exit" ,"[SET ENCODE]","Menu" ,"USE_INF","IN_PORT","OUT_PORT","NOT USE","USE    ","X04->X06","X0C->X0E","Y03","Y0B","","","",""}
		}
	},
	{	/* 37 */
		{"[SET COUNT]","[SET COUNT]"},				/* COUNT		*/
		{
			{"Exit" ,"[SET COUNT]","Menu" ,"USE_INF","IN_PORT","NOT USE","USE    ","X07","X0F","","","","","",""},
			{"Exit" ,"[SET COUNT]","Menu" ,"USE_INF","IN_PORT","NOT USE","USE    ","X07","X0F","","","","","",""}
		}
	},
	{	/* 38 */
		{"[SET PATARN]","[SET PATARN]"},			/* PATARN		*/
		{
			{"Exit" ,"[SET PATARN]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y04->Y07","Y0C->Y0F","","","","","",""},
			{"Exit" ,"[SET PATARN]","Menu" ,"USE_INF","OUT_PORT","NOT USE","USE    ","Y04->Y07","Y0C->Y0F","","","","","",""}
		}
	},
	{	/* 39 */
		{"[CLEAR USER DATA]","[CLEAR USER DATA]"},	/* 3	3 ACTIVE STATE MONTORȭ�� */
		{
			{"CLEAR GP DATA"   ,"CLEAR LP DATA"   ,"","","","","","","","",""},
			{"CLEAR GP DATA"   ,"CLEAR LP DATA"   ,"","","","","","","","",""}
		}
	},
	{	/* 40 */
		{"[CLEAR LP DATA]","[CLEAR LP DATA]"},				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
		{
			{"CLEAR LP DATA? "          ,""                              ,"YES" ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""},
			{"CLEAR LP DATA? "          ,""                              ,"YES" ,"NO"      ,"NOW CLEARING...."        ,"","","","","",""}
		}
	},
	{	/* 41 */
		{"[I/O MONITORING] ","[I/O MONITORING] "},				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
		{
			{"","","","","","","","","","",""},
			{"","","","","","","","","","",""}
		}
	},
	{	/* 42 */
		{"[CONNECTION DETAIL]","[CONNECTION DETAIL]"},				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */
		{
			{"CH1:" ,"CH2:" ,"" ,"" ,"" ,"","","","","",""},
			{"CH1:" ,"CH2:" ,"" ,"" ,"" ,"","","","","",""}
		}
	},
	{	/* 43 */
		{"[LATCH DEVICE]","[LATCH DEVICE]"},				/* 4-5-11 22 AUXILIARY SETTINGȭ�� */	/* 20091222 */
		{
			{"LATCH ON ","LATCH OFF ","OFF","ON","","","","","","",""},
			{"LATCH ON ","LATCH OFF ","OFF","ON","","","","","","",""}
		}
	},

};
#endif
