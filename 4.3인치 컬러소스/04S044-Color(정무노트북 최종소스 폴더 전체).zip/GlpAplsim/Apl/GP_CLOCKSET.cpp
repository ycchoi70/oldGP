/* ****************************************************************************** */
/*  �� �� �� : GP_CLOCKSET.CPP													 */
/*  ��    �� : ���� �ð� ����													 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

/* *******************************************************************************/
/*  �� �� �� : vClockSet()														 */
/*  ��    �� : ���� �ð� ���� ó��												 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 6�� 30�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
#ifdef	SIZE_2480
extern int iKeyAcceptReturn(int itype);
void		vClockSet(int* iScreenNo){	

	int		iKeyCode;
	int		iFocusFlag;				/*  0:��������1:�����2:������3:���ڼ���4:�ü���5:�м���6:�ʼ���  */
	int		iClock;					/*  0:�ð��� �� 1:�ð��� ���� */
	int		iXpoint;
	int		iYpoint;
	
	
	int		iLen;
	short	iInputFlag;
	short	iKeyFlag;
	short	iStDot1;
	short	iStDot2;
	char	chDsp_buff[6];
	char	chSetTemp[6];
	char	chDsp_Data[15];
	char	chDsp_Data1[15];
	char	chBufData[5];

	memset(chSetTemp, 0x00, sizeof(chSetTemp));
	memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
	memset(chDsp_Data, 0x00, sizeof(chDsp_Data));
	memset(chDsp_Data1, 0x00, sizeof(chDsp_Data1));
	memset(chBufData, 0x00, sizeof(chBufData));

	iInputFlag	= 0;

/*	iFocusFlag	= 0;	*/

/*ksc20040509 */
	iFocusFlag	= 1;		/*����Ͻú��� �������߿��� 1���翡 ��Ŀ���� �� */
/*ksc20040509 */

	iLen		= 0;
	iClock		= 0;
	iKeyCode	= -1;
	iKeyFlag	= 1;
	iStDot1		= 0;
	iStDot2		= 0;
	DefaultFormDisplay(KEY_FORM, Dspname[CLOCK_MENU].chTitle[Set.iLang]);

	if(Set.iDataFormat == 0 || Set.iDataFormat == 1)
	{
		iStDot1 = 0;
		iStDot2 = 0;
	}else if(Set.iDataFormat == 2 || Set.iDataFormat == 5)
	{
		iStDot1 = 16;
		iStDot2 = 0;
	}else
	{
		iStDot1 = 16;
		iStDot2 = 16;
	}

	while ( *iScreenNo == CLOCK_MENU_NUM ) {
	
		while(1)
		{
			/* leesi 040612 iKeyCode = KeyAccept();	*/						/*  �Էµ� Ű���� �о��	 */
			iKeyCode = iKeyAcceptReturn(CLOCK_MENU_NUM);
			if(iKeyCode == -1 || iKeyFlag == 0 ||
				iKeyCode == 0 || iKeyCode == PC_DNLOAD_START ||
				iKeyCode == PC_UPLOAD_START)
			{
				if(iKeyCode == 0)
					iKeyFlag = 0;
				break;
			}
		}
		if(iKeyCode > 0)
		{
			if ((iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) ||
				 iKeyCode == KEY_01 || iKeyCode == KEY_02   || 
				(iKeyCode >= KEY_16 && iKeyCode <= KEY_23)  ||
				(iKeyCode >= KEY_31 && iKeyCode <= KEY_38)  ||
				(iKeyCode >= KEY_40 && iKeyCode <= KEY_44)  ||
				(iKeyCode >= KEY_46 && iKeyCode <= KEY_53)  ||
				(iKeyCode >= KEY_56 && iKeyCode <= KEY_59)) 
			{
				iKeyFlag = 1;
				NormalBuzzer();				/*	Buzzer  */
			}
			
			if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
			{												
				*iScreenNo = DOWN_TRANS;
				break;
			}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
			{
				*iScreenNo = UP_TRANS;
				break;
			}
			
			memset(chSetTemp, 0x00, sizeof(chSetTemp));
			if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) 
			{
				*iScreenNo = USER_SCREEN_NUM;
			}else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) 
			{										/*  END				 */
				*iScreenNo = SET_ENVIRONMENT_NUM;
			} else if (iKeyCode == KEY_40 || (iKeyCode == KEY_41 && iStDot1 == 0))
			{										/*  �� ���� ��Ŀ��		 */
				if(iClock == 0)
				{
					iFocusFlag = 1;
					memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
				}
			} else if (iKeyCode == KEY_42 || (iKeyCode == KEY_43 && iStDot2 != 16) || (iKeyCode == KEY_41 && iStDot1 != 0)) 
			{										/*  �� ���� ��Ŀ��		 */
				if(iClock == 0)
				{
					iFocusFlag = 2;
					memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
				}
			} else if (iKeyCode == KEY_44 || (iKeyCode == KEY_43 && iStDot2 == 16)) 
			{										/*  �� ���� ��Ŀ��		 */
				if(iClock == 0)
				{
					iFocusFlag = 3;
					memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
				}
			} else if (iKeyCode == KEY_56 )	
			{										/*  �� ���� ��Ŀ��		 */
				if(iClock == 0)
				{
					iFocusFlag = 4;
					memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
				}
			} else if (iKeyCode == KEY_57 || iKeyCode == KEY_58) 
			{										/*  �� ���� ��Ŀ��		 */
				if(iClock == 0)
				{
					iFocusFlag = 5;
					memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
				}
			} else if (iKeyCode == KEY_59) 
			{										/*  �� ���� ��Ŀ��		 */
				if(iClock == 0)
				{
					iFocusFlag = 6;
					memset(chDsp_buff, 0x00, sizeof(chDsp_buff));
				}
			} else if (iKeyCode == KEY_33 || iKeyCode == KEY_34 ) 
			{										/*  5 ��ư			 */
				strcpy(chSetTemp, "5");
			} else if (iKeyCode == KEY_35 || iKeyCode == KEY_36 ) 
			{										/*  6 ��ư			 */
				strcpy(chSetTemp, "6");
			} else if (iKeyCode == KEY_37 || iKeyCode == KEY_38 ) 
			{										/*  7 ��ư			 */
				strcpy(chSetTemp, "7");
			} else if (iKeyCode == KEY_46 || iKeyCode == KEY_47)
			{										/*  8 ��ư			 */
				strcpy(chSetTemp, "8");
			} else if (iKeyCode == KEY_48 ||iKeyCode == KEY_49 ) 
			{										/*  9 ��ư			 */
				strcpy(chSetTemp, "9");
			} else if (iKeyCode == KEY_50 || iKeyCode == KEY_51 ) 
			{										/*  CLR ��ư		 */
				iClock		= 0;
				iInputFlag	= 0;
				iFocusFlag	= 0;
			} else if (iKeyCode == KEY_16 || iKeyCode == KEY_17 ) 
			{										/*  0 ��ư			 */
				strcpy(chSetTemp, "0");
			} else if (iKeyCode == KEY_18 || iKeyCode == KEY_19 ) 
			{										/*  1 ��ư			 */
				strcpy(chSetTemp, "1");
			} else if (iKeyCode == KEY_20 || iKeyCode == KEY_21 ) 
			{										/*  2 ��ư			 */
				strcpy(chSetTemp, "2");
			} else if (iKeyCode == KEY_22 || iKeyCode == KEY_23) 
			{										/*  3 ��ư			 */
				strcpy(chSetTemp, "3");
			} else if (iKeyCode == KEY_31 || iKeyCode == KEY_32) 
			{										/*  4 ��ư			 */
				strcpy(chSetTemp, "4");
			} else if (iKeyCode == KEY_52 || iKeyCode == KEY_53 ) 
			{										/*  ENT ��ư		 */
				if(iFocusFlag != 0)
				{	
					if(iClock != 0)
					{
						iClock = 0;
						if((iMaxCheck(iFocusFlag, gatoi(chDsp_buff))))
						{
							Delay(100);
						}

							iFocusFlag++;
							if(iFocusFlag > 6)
							{
								iFocusFlag = 1;
							}
							DefaultFormDisplay(KEY_FORM, Dspname[CLOCK_MENU].chTitle[Set.iLang]);

					}
					else
					{
						iFocusFlag++;
						if(iFocusFlag > 6)
						{
							iFocusFlag = 1;
						}
					}
					iInputFlag=0;
				}
				memset(chDsp_buff,0x00,sizeof(chDsp_buff));
			}
		}

		if(iFocusFlag != 0 && strlen(chSetTemp))
		{
			if(iInputFlag == 0){
				strcpy(chDsp_buff,chSetTemp);
				iInputFlag = 1;
			}
			else{
				strcat(chDsp_buff,chSetTemp);
			}
/*			if(strlen(chDsp_buff)>2 && (iFocusFlag == 1 && Set.iLang == 1)||(iFocusFlag == 3 && Set.iLang == 0))*/
			if(strlen(chDsp_buff)>2 && 
				((iFocusFlag == 1 && iStDot1 == 0) || 
				(iFocusFlag == 2 && iStDot1 == 16 && iStDot2 == 0) || 
				(iFocusFlag == 3 && iStDot2 == 16)))
			{
				if(strlen(chDsp_buff) > 4)
				{
					memset(chSetTemp,0x00,sizeof(chSetTemp));
					strncpy(chSetTemp,(chDsp_buff+1),4);
					strcpy(chDsp_buff,chSetTemp);
				}
			}
			else if(strlen(chDsp_buff)>2)
			{
				memset(chSetTemp,0x00,sizeof(chSetTemp));
				strncpy(chSetTemp,(chDsp_buff+1),2);
				strcpy(chDsp_buff,chSetTemp);
			}
			strcpy(chSetTemp,"");
			iClock = 1;


			switch(iFocusFlag)
				{
				case 1:
					iXpoint = 176-iStDot1;
					iYpoint = 40;
					break;
				case 2:
					iXpoint = 200-iStDot2;
					iYpoint = 40;
					break;
				case 3:
					iXpoint = 224;
					iYpoint = 40;
					break;
				case 4:
					iXpoint = 176;
					iYpoint = 60;
					break;
				case 5:
					iXpoint = 200;
					iYpoint = 60;
					break;
				case 6:
					iXpoint = 224;
					iYpoint = 60;
					break;
			}

			if((iFocusFlag == 1 && iStDot1 == 0) ||
				(iFocusFlag == 2 && iStDot1 == 16 && iStDot2 == 0) ||
				(iFocusFlag == 3 && iStDot2 == 16)){
				DotTextOut(GAMEN_START_X+iXpoint-32,GAMEN_START_Y+iYpoint,"    ",1,1, TRANS, T_WHITE, T_BLACK);
			}else{
				DotTextOut(GAMEN_START_X+iXpoint-16,GAMEN_START_Y+iYpoint,"  ",1,1, TRANS, T_WHITE, T_BLACK);
			}
			iLen = strlen(chDsp_buff);
			vLastDataReverse(iXpoint-(iLen*8),iYpoint,chDsp_buff);


		}
		if(iClock == 0)
		{
			switch(Set.iDataFormat)
			{
			case 0:
				sprintf(chDsp_Data, "%4d/%02d/%02d",SystemTime.year+START_YEAR ,SystemTime.mon ,SystemTime.day);				
				break;
			case 1:
				sprintf(chDsp_Data, "%4d/%02d/%02d",SystemTime.year+START_YEAR ,SystemTime.day ,SystemTime.mon);				
				break;
			case 2:
				sprintf(chDsp_Data, "%2d/%04d/%02d",SystemTime.day ,SystemTime.year+START_YEAR ,SystemTime.mon);				
				break;
			case 3:
				sprintf(chDsp_Data, "%2d/%02d/%04d",SystemTime.day ,SystemTime.mon ,SystemTime.year+START_YEAR);				
				break;
			case 4:
				sprintf(chDsp_Data, "%2d/%02d/%04d",SystemTime.mon ,SystemTime.day ,SystemTime.year+START_YEAR);				
				break;
			case 5:
				sprintf(chDsp_Data, "%2d/%04d/%02d",SystemTime.mon ,SystemTime.year+START_YEAR ,SystemTime.day);				
				break;
			}

			sprintf(chDsp_Data1, "%02d:%02d:%02d",SystemTime.hour,SystemTime.min,SystemTime.sec);				
			DotTextOut(GAMEN_START_X+144,GAMEN_START_Y+40,chDsp_Data,1,1, TRANS, T_WHITE, T_BLACK);
			DotTextOut(GAMEN_START_X+160,GAMEN_START_Y+60,chDsp_Data1,1,1, TRANS, T_WHITE, T_BLACK);
			sprintf(chDsp_buff,"");		
			if(iFocusFlag!=0)			/* ���ý� ���� */
			{
				memset(chDsp_Data,0x00,sizeof(chDsp_Data));
				
				switch(iFocusFlag)
					{
					case 1:
						iXpoint = 176 - iStDot1;
						iYpoint = 40;
						if(Set.iDataFormat == 0|| Set.iDataFormat == 1)
							itoa((SystemTime.year+START_YEAR),chDsp_buff,10);
						else if(Set.iDataFormat == 4|| Set.iDataFormat == 5)
							sprintf(chDsp_buff,"%02d",SystemTime.mon);
						else
							sprintf(chDsp_buff,"%02d",SystemTime.day);
						break;
					case 2:
						iXpoint = 200 - iStDot2;
						iYpoint = 40;
						if(Set.iDataFormat == 2|| Set.iDataFormat == 5)
							itoa((SystemTime.year+START_YEAR),chDsp_buff,10);
						else if(Set.iDataFormat == 0|| Set.iDataFormat == 3)
							sprintf(chDsp_buff,"%02d",SystemTime.mon);
						else
							sprintf(chDsp_buff,"%02d",SystemTime.day);
						
						break;
					case 3:
						iXpoint = 224;
						iYpoint = 40;
						if(Set.iDataFormat == 3|| Set.iDataFormat == 4)
							itoa((SystemTime.year+START_YEAR),chDsp_buff,10);
						else if(Set.iDataFormat == 1|| Set.iDataFormat == 2)
							sprintf(chDsp_buff,"%02d",SystemTime.mon);
						else
							sprintf(chDsp_buff,"%02d",SystemTime.day);
						break;
					case 4:
						iXpoint = 176;
						iYpoint = 60;
						sprintf(chDsp_buff,"%02d",SystemTime.hour);
						break;
					case 5:
						iXpoint = 200;
						iYpoint = 60;
						sprintf(chDsp_buff,"%02d",SystemTime.min);
						break;
					case 6:
						iXpoint = 224;
						iYpoint = 60;
						sprintf(chDsp_buff,"%02d",SystemTime.sec);
						break;
					}

				if((iFocusFlag == 1 && iStDot1 == 0) ||
					(iFocusFlag == 2 && iStDot1 == 16 && iStDot2 == 0) ||
					(iFocusFlag == 3 && iStDot2 == 16)){
					DotTextOut(GAMEN_START_X+iXpoint-32,GAMEN_START_Y+iYpoint,"    ",1,1, TRANS, T_WHITE, T_BLACK);
				}else{
					DotTextOut(GAMEN_START_X+iXpoint-16,GAMEN_START_Y+iYpoint,"  ",1,1, TRANS, T_WHITE, T_BLACK);
				}
				iLen = strlen(chDsp_buff);
				vLastDataReverse(iXpoint-(iLen*8),iYpoint,chDsp_buff);
			}
		}
		DrawLcdBank1();
		Delay(100);
	}

}
/* *******************************************************************************/
/*  �� �� �� : iMaxCheck()														 */
/*  ��    �� : SET�ϴ� �ð��� �����ϴ��� Check									 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 6�� 30�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
int iMaxCheck(int iFocusFlag, int iValue)
{
	int iMax, iMin;
	int iRet;
	RTC_DATA SetData;

	SetData.year = SystemTime.year + START_YEAR; 
	SetData.mon	 = SystemTime.mon;
	SetData.day	 = SystemTime.day;
	SetData.hour = SystemTime.hour;
	SetData.min  = SystemTime.min;
	SetData.sec  = SystemTime.sec;
	SetData.week = SystemTime.week;


	if(iFocusFlag>=1 && iFocusFlag<=3)			/* English */
	{
	/*	iData = Set.iDataFormat;*/
		switch(Set.iDataFormat){
			case 0x01:
				if(iFocusFlag == 2)
					iFocusFlag = 3;
				else if(iFocusFlag == 3)
					iFocusFlag = 2;

				break;
			case 0x02:
				if(iFocusFlag == 1)
					iFocusFlag = 3;
				else if(iFocusFlag == 2)
					iFocusFlag = 1;
				else
					iFocusFlag = 2;
				break;
			case 0x03:
				if(iFocusFlag == 1)
					iFocusFlag = 3;
				else if(iFocusFlag == 3)
					iFocusFlag = 1;
				break;
			case 0x04:
				if(iFocusFlag == 1)
					iFocusFlag = 2;
				else if(iFocusFlag == 2)
					iFocusFlag = 3;
				else
					iFocusFlag = 1;

				break;
			case 0x05:
				if(iFocusFlag == 1)
					iFocusFlag = 2;
				else if(iFocusFlag == 2)
					iFocusFlag = 1;
				break;
		}
		
	}
	switch(iFocusFlag)
	{
	case 1:
		iMax = 2099;
		iMin = START_YEAR;
		SetData.year = iValue;
		break;
	case 2:
		iMax = 12;
		iMin = 1;
		SetData.mon = iValue;
		break;
	case 3:
		switch(SystemTime.mon)
		{
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				iMax = 31;
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				iMax = 30;
				break;
			case 2:
				iMax = iLeapYear(SystemTime.year + START_YEAR);
				break;
		}
		iMin = 1;
		SetData.day = iValue ;
		break;
	case 4:
		iMax = 23;
		iMin = 0;
		SetData.hour = iValue;
		break;
	case 5:
		iMax = 59;
		iMin = 0;
		SetData.min = iValue ;
		break;
	case 6:
		iMax = 59;
		iMin = 0;
		SetData.sec = iValue ;
		break;
	}
	if(iValue>=iMin && iValue<=iMax)
	{	
/**********************�߰� �κ�.****************************/
		if(iFocusFlag==2 || iFocusFlag==1)
		{	
			if(DataChecking(&SetData))
			{
				SetData.year = SetData.year - START_YEAR;
				/*  ������ ��.  */
				SetData.week = iNowWeek(&SetData);
				DateTimeSet(&SetData,0);
				iRet=1;
				Delay(100);
			}
			else
			{
				iCaptionWindow(Dspname[SET_FUNTION].chName[Set.iLang][9],"");
				iRet=0;
			}
		}else
		{
/***********************************************************/
			SetData.year = SetData.year - START_YEAR;
			/*  ������ ��.  */
			SetData.week = iNowWeek(&SetData);
			DateTimeSet(&SetData,0);
			iRet=1;
			Delay(100);
		}
	}
	else
	{
		iCaptionWindow(Dspname[SET_FUNTION].chName[Set.iLang][9],"");
		iRet=0;
	}
	return iRet;
}
#endif
int DataChecking(RTC_DATA *SetData)
{
	int iMax;
	int iVal;
	iVal = 0;
	switch(SetData->mon)
	{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			iMax = 31;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			iMax = 30;
			break;
		case 2:
			iMax = iLeapYear(SetData->year);
			break;
	}
	if(SetData->day <= iMax)
		iVal = 1;
	return iVal;
}
/**********************************************************/
/*  �� �� �� �� */
/**********************************************************/
int		iLeapYear(int year){
	
	if((year % 4) == 0) {				
		if((year % 100) != 0) {				
			return 29;
		}
		else {
			if((year % 400) == 0) {		
				return 29;
			}
			else {
				return 28;				
			}
		}
	}
	else {
		return 28;
	}
}
int		iNowWeek(RTC_DATA *STime){
	int iWeek;
	int Datatotal;
	int i;

	if(STime->year!=0)
		Datatotal = (STime->year*365)+(STime->year/4)+1;
	else
		Datatotal = 1;
	if(STime->year%4 == 0 && STime->mon < 3)
		Datatotal--;
	for(i=1;i<STime->mon;i++)
	{
		if(i==1 || i==3 || i==5 || i==7|| i==8 || i==10 || i==12){
			Datatotal+=31;
		}
		else if(i==4 || i==6 || i==9 || i==11){
			Datatotal+=30;
		}
		else if(i==2){
			Datatotal+=28;			
		}

	}
	Datatotal += STime->day; 
	Datatotal += 5;
	iWeek = Datatotal % 7;

	return iWeek;
}
/* *******************************************************************************/
/*  �� �� �� : DefaultClockSet()												 */
/*  ��    �� : ����Ʈ �ð����� ��(�̻��� ���� �ð��� ���õǾ� ���� ��)			 */
/*  ��    �� :																	 */
/*  ��    �� : 																	 */
/*  �� �� �� : 2003_03_21														 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
void	DefaultClockSet()
{

	RTC_DATA SetData;
#ifndef	WIN32
	T_MAIL	*mp;
	int	mbx;
	int OldResp;

	mbx= TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RTC_READ;
	SendMail(T_RTCHAND,(char *)mp);
	mp= (T_MAIL *)ReceiveMail( mbx );
	ChangeMailResp( (char *)mp, OldResp );
	FreeMail( (char *)mp );
	FreeMbx( mbx );
#endif
	if(!(SystemTime.year>=0 && SystemTime.year <= 99) || 
		!(SystemTime.mon>=1 && SystemTime.mon <= 12) ||
		!(SystemTime.day>=1 && SystemTime.day <= 31) ||
		!(SystemTime.hour>=0 && SystemTime.hour <= 23) ||
		!(SystemTime.min>=0 && SystemTime.min <= 59) ||
		!(SystemTime.sec>=0 && SystemTime.sec <= 59))
	{
		SetData.year = 3;
		SetData.mon = 1;
		SetData.day = 1;
		SetData.hour = 0;
		SetData.min = 0;
		SetData.sec = 0;
		SetData.week = 3;
		DateTimeSet(&SetData,0);
	}
}
#ifdef	LP_S044
int	GetMaxDay(int year,int mon)
{
	int	iMax;
	switch(mon)
	{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			iMax = 31;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			iMax = 30;
			break;
		case 2:
			iMax = iLeapYear(year);
			break;
	}
	return(iMax);
}
#endif
