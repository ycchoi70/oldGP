/********************************************************************************/
/* �� �� �� : GpTrendGrpahTask.cpp												*/
/* ��    �� : TrendGraphTask													*/
/* �� �� �� : 2002�� 5�� 13�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"

/********************************************************************************/
/* �� �� �� : DrawTrendGraph_Task													*/
/* ��    �� : TrendGraph������ �ص��Ͽ� ȭ�鿡 ���								*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 30�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetTrendGraph_Func(int iDispOrder)
{
	_TRENDGRAPH_EVENT_TBL*	 TrendGraphEventTbl;
	TrendGraphEventTbl= (_TRENDGRAPH_EVENT_TBL*)TakeMemory(sizeof(_TRENDGRAPH_EVENT_TBL));
	DrawTrendGraph_Func(0,TrendGraphEventTbl,iDispOrder);
	FreeMail((char *)TrendGraphEventTbl);
}
int	DrawTrendGraph_Func(int mode,_TRENDGRAPH_EVENT_TBL* TrendGraphEventTbl,int iDispOrder)
{
/*	int					iTagSizeOf;*/
	int					i;
	int					iOffset;
	int					k;
	int					iDevAddress;
	unsigned char		*buffer;

	buffer= ScreenTagData[iDispOrder].TagPos;
/*
	_TRENDGRAPH_EVENT_TBL*	 TrendGraphEventTbl;

	if(CheckMailBox(sizeof(_TRENDGRAPH_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_TRENDGRAPH_EVENT_TBL));
	TrendGraphEventTbl= (_TRENDGRAPH_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)TrendGraphEventTbl, 0x00, sizeof(_TRENDGRAPH_EVENT_TBL));
	
/*	TrendGraphEventTbl = (_TRENDGRAPH_EVENT_TBL*)TakeMemory(sizeof(_TRENDGRAPH_EVENT_TBL));
	memset((char *)TrendGraphEventTbl, 0x00, sizeof(_TRENDGRAPH_EVENT_TBL));
*/
/*	iTagSizeOf	= 0;*/
	iOffset		= 0;
	k			= 0;
/*
	iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
	iTagSizeOf += (unsigned int)buffer[1] & 0xff;
	
	ScreenTagData[iDispOrder]->cObjects	= TrendGraphDispCnt;
	ScreenTagData[iDispOrder]->iCnt		= TrendGraphDispCnt;
	ScreenTagData[iDispOrder]->iWindowNo= TrendGraphDispCnt;
*/
	/* ��ǥ */
/*
	TrendGraphEventTbl->sX  = (unsigned int)(buffer[6]  << 0x08);
	TrendGraphEventTbl->sX += (unsigned int)buffer[7] & 0xff;


	TrendGraphEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
	TrendGraphEventTbl->sY += (unsigned int)buffer[9] & 0xff;

	TrendGraphEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
	TrendGraphEventTbl->eX += (unsigned int)buffer[11] & 0xff;

	TrendGraphEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
	TrendGraphEventTbl->eY += (unsigned int)buffer[13] & 0xff;	
*/

	/* Direction */
	TrendGraphEventTbl->iDirecition = (unsigned int)buffer[14];		/* Right : 0x01, Left : 0x02 */

	/* Frame Color */
	TrendGraphEventTbl->iFrameColor = (unsigned int)buffer[15];

	/* Number : ��Ʈ�� ��Ÿ�� ���� ���� */
	TrendGraphEventTbl->iNumber = (unsigned int)buffer[16];
	if(mode == 0){
		for(k=0;k<TrendGraphEventTbl->iNumber;k++){
			for(i=0;i<50;i++){
					TrendDisPoint[k][i]=50;
			}
		}
	}
	/* Points : ��Ʈ�� ���� ���̴� Ƚ�� */
	TrendGraphEventTbl->iPoints = (unsigned int)buffer[17];
	
	/* upper, lower���� �� signed, unsigned ���� */
	switch(buffer[18]){
		case 0x01:
			TrendGraphEventTbl->iCaseLoFixedVal = CHECKED;	
			TrendGraphEventTbl->iCaseUpFixedVal = CHECKED;
			break;
		case 0x02:
			TrendGraphEventTbl->iCaseLoFixedVal = UNCHECKED;
			TrendGraphEventTbl->iCaseUpFixedVal = UNCHECKED;
			break;
		case 0x03:
			TrendGraphEventTbl->iCaseLoFixedVal = UNCHECKED;
			TrendGraphEventTbl->iCaseUpFixedVal = CHECKED;
			break;
		case 0x04:
			TrendGraphEventTbl->iCaseLoFixedVal = CHECKED;
			TrendGraphEventTbl->iCaseUpFixedVal = UNCHECKED;
			break;
	}
	/* Plate Color */
	TrendGraphEventTbl->iPlateColor = (unsigned int)buffer[19];

	/* Frame üũ���� �� Scale Display üũ���� */
	switch((unsigned int)buffer[20]){
		case 0x01:
			TrendGraphEventTbl->iFrameChecked		= CHECKED;
			TrendGraphEventTbl->iScaleDispChecked	= CHECKED;
			break;
			
		case 0x02:
			TrendGraphEventTbl->iFrameChecked		= UNCHECKED;
			TrendGraphEventTbl->iScaleDispChecked	= CHECKED;
			break;

		case 0x03:
			TrendGraphEventTbl->iFrameChecked		= CHECKED;
			TrendGraphEventTbl->iScaleDispChecked	= UNCHECKED;
			break;

		case 0x04:
			TrendGraphEventTbl->iFrameChecked		= UNCHECKED;
			TrendGraphEventTbl->iScaleDispChecked	= UNCHECKED;
			break;
	}
	/* Case �ǿ��� Upper ���� */
	iOffset = 21;
	if(TrendGraphEventTbl->iCaseUpFixedVal == CHECKED){	/* Fixed�� ������� ��� */
#ifdef	WIN32
		TrendGraphEventTbl->lUpperFixedData  = (unsigned int)buffer[iOffset] << 0x18;
		TrendGraphEventTbl->lUpperFixedData += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		TrendGraphEventTbl->lUpperFixedData += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		TrendGraphEventTbl->lUpperFixedData += (unsigned int)buffer[++iOffset] & 0xff; 
		iOffset++;
#else
		memcpy(&TrendGraphEventTbl->lUpperFixedData,&buffer[iOffset],4);
		iOffset += 4;
#endif
	}
	else if(TrendGraphEventTbl->iCaseUpFixedVal == UNCHECKED){/* Device�� ������� ��� */	
		/*  ����̽� ���� */
		/*------------------------------------------------------------*/
		if(mode == 0){
			GetDeviceSet((buffer+iOffset),
					TrendGraphEventTbl->cUpperDeviceName,
					&(TrendGraphEventTbl->iUpperDeviceNumber));
		}
		/*-------------------------------------------------------------*/
		iOffset+=4;

	}
	/* Case �ǿ��� Lower ���� */
	if(TrendGraphEventTbl->iCaseLoFixedVal == CHECKED){	/* Fixed�� ������� ��� */
#ifdef	WIN32
		TrendGraphEventTbl->lLowerFixedData  = (unsigned int)buffer[++iOffset] << 0x18;
		TrendGraphEventTbl->lLowerFixedData += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		TrendGraphEventTbl->lLowerFixedData += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		TrendGraphEventTbl->lLowerFixedData += (unsigned int)buffer[++iOffset] & 0xff; 
		iOffset++;
#else
		iOffset++;			/* 080926 */
		memcpy(&TrendGraphEventTbl->lLowerFixedData,&buffer[iOffset],4);
		iOffset += 4;		/* 080926 */
#endif
	}
	/* Device�� ������� ��� */	
	/* 2009.07.09 */
/*	else if(TrendGraphEventTbl->iCaseUpFixedVal == UNCHECKED){*/
	else if(TrendGraphEventTbl->iCaseLoFixedVal == UNCHECKED){
		/* [26]~[27]�ι�° ����̽� ���� ���´�-> */
		/*------------------------------------------------------------*/
		iOffset++;
		if(mode == 0){
			GetDeviceSet((buffer+iOffset),
					TrendGraphEventTbl->cLowerDeviceName,
					&(TrendGraphEventTbl->iLowerDeviceNumber));
		}
		/*-------------------------------------------------------------*/
		iOffset+=4;

	}
	iOffset++;
	TrendGraphEventTbl->iStoreMemoryCode = 0;
	if(buffer[iOffset] != 0x00){			/* Store Memory check */
		TrendGraphEventTbl->iStoreMemoryCode = (unsigned int)buffer[++iOffset];
		/* 0x01(No clear trigger), 0x02(Clear on trgger rise), 0x03(Clear on trgger Fall) */
		if(TrendGraphEventTbl->iStoreMemoryCode != 1){
			/*------------------------------------------------------------*/
			iOffset++;
			if(mode == 0){
				GetDeviceSet((buffer+iOffset),
						TrendGraphEventTbl->cStMemoryDeviceName,
						&(TrendGraphEventTbl->iStMemoryDeviceNumber));
			}
			iOffset+=4;
			/*-------------------------------------------------------------*/

		}
	}else
		iOffset++;
	if(mode == 0){
/* 060926
		ScreenTagData[k].uu.Trend.iTriggerSec = (unsigned int)(buffer[++iOffset] << 0x08);
		ScreenTagData[k].uu.Trend.iTriggerSec += (unsigned int)buffer[++iOffset] & 0xff;
		if(ScreenTagData[k].uu.Trend.iTriggerSec==0)
		{
			ScreenTagData[k].uu.Trend.iTriggerSec = 1;
		}
		CommonArea.SystemDev.TrandTime = ScreenTagData[k].uu.Trend.iTriggerSec;
*/
		ScreenTagData[iDispOrder].uu.Trend.iTriggerSec = (unsigned int)(buffer[++iOffset] << 0x08);
		ScreenTagData[iDispOrder].uu.Trend.iTriggerSec += (unsigned int)buffer[++iOffset] & 0xff;
		if(ScreenTagData[iDispOrder].uu.Trend.iTriggerSec==0)
		{
			ScreenTagData[iDispOrder].uu.Trend.iTriggerSec = 1;
		}
		CommonArea.SystemDev.TrandTime = ScreenTagData[iDispOrder].uu.Trend.iTriggerSec;
	}else{
		iOffset+= 2;
	}
	/* Shape ������ ������� ��� */
	if(TrendGraphEventTbl->iScaleDispChecked == CHECKED){
		TrendGraphEventTbl->iScaleColor = (unsigned int)buffer[++iOffset];
		TrendGraphEventTbl->iScalePointsV = (unsigned int)buffer[++iOffset];
		TrendGraphEventTbl->iScalePointsH = (unsigned int)buffer[++iOffset];
		if(mode == 0){
			ScreenTagData[iDispOrder].sX += 4;
			ScreenTagData[iDispOrder].eY -= 4;
		}
	}
	if((unsigned int)buffer[++iOffset] == 0x00)
	{
/*		TrendGraphEventTbl->BeShapeUsed = UNCHECKED;*/
		TrendGraphEventTbl->ShapeNo = 0;
		iOffset++;
	}else
	{
/*		TrendGraphEventTbl->BeShapeUsed = CHECKED;*/
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed= CHECKED;
		}
		TrendGraphEventTbl->ShapeNo = (unsigned int)buffer[++iOffset];
	}
	if((unsigned int)buffer[++iOffset] < 4)	/* 1,2,3 -> 16Bit */
		TrendGraphEventTbl->i1632BitFlag = BIT16;
	else								/* 4,5,6 -> 32Bit */
		TrendGraphEventTbl->i1632BitFlag = BIT32;

	if((unsigned int)buffer[iOffset] == 0x01 || (unsigned int)buffer[iOffset] == 0x04)
		TrendGraphEventTbl->iSignedFlag = SIGNED;
	else if((unsigned int)buffer[iOffset] == 0x02 || (unsigned int)buffer[iOffset] == 0x05)
		TrendGraphEventTbl->iSignedFlag = UNSIGNED;
	else
		TrendGraphEventTbl->iSignedFlag = BCD;

	for(i=0 ; i<TrendGraphEventTbl->iNumber ; i++){
		TrendGraphEventTbl->tf[i].iLineType  = (unsigned int)buffer[++iOffset];
		TrendGraphEventTbl->tf[i].iLineType++;
		TrendGraphEventTbl->tf[i].iLineColor = (unsigned int)buffer[++iOffset];		
	}

	TrendGraphEventTbl->iStoreMemoryVal = -1;
	if(mode == 0){
		ScreenTagData[iDispOrder].uu.Trend.iStoreMemoryVal= -1;	/* 060921 */
	}
	if(TrendGraphEventTbl->iStoreMemoryCode == 0){
		/*------------------------------------------------------------*/
		iOffset++;
		if(mode == 0){
			GetDeviceSet((buffer+iOffset),
					CommonArea.SystemDev.Trand_Dev.DevName,
					&(iDevAddress));
			CommonArea.SystemDev.Trand_Dev.DevAdd = iDevAddress;
		}
		iOffset+=4;
		/*-------------------------------------------------------------*/

		if(mode == 0){
/* 060921			TrendGraphEventTbl->NoDeviceFlag = 0;*/
			ScreenTagData[iDispOrder].uu.Trend.NoDeviceFlag= 0;
			if(strlen(CommonArea.SystemDev.Trand_Dev.DevName))
/* 060921				TrendGraphEventTbl->NoDeviceFlag = 1;*/
				ScreenTagData[iDispOrder].uu.Trend.NoDeviceFlag= 1;

			CommonArea.SystemDev.Trand_Dev.DevCnt	= TrendGraphEventTbl->iNumber;
			CommonArea.SystemDev.TrandPoint = TrendGraphEventTbl->iPoints;
			CommonArea.SystemDev.TrandWordCnt = TrendGraphEventTbl->i1632BitFlag;
		}
	}else{
		if(mode == 0){	/* 060921 */
			for(i=0;i<16;i++){
				if(iStoreScreenNum[i] == iNowScreenNum){
/* 060921				TrendGraphEventTbl->iStoreMemoryVal = i;*/ /* StoreMemory Point Val*/
/* 060921				TrendGraphEventTbl->NoDeviceFlag = 1;*/
					ScreenTagData[iDispOrder].uu.Trend.iStoreMemoryVal = i; /* StoreMemory Point Val*/
					ScreenTagData[iDispOrder].uu.Trend.NoDeviceFlag = 1;
					break;
				}
			}
		}
	}
	if(mode == 0){
		ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
 		/* ���Ѱ��� Device�� ���� ��� */
		if(TrendGraphEventTbl->iCaseUpFixedVal == UNCHECKED){
			DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */	
			DeviceDataHed[DeviceCnt].DevName[0] = TrendGraphEventTbl->cUpperDeviceName[0];
			DeviceDataHed[DeviceCnt].DevName[1] = TrendGraphEventTbl->cUpperDeviceName[1];
			DeviceDataHed[DeviceCnt].DevAddress = TrendGraphEventTbl->iUpperDeviceNumber;
			if(TrendGraphEventTbl->i1632BitFlag == BIT16){/* 16bit */
				DeviceDataHed[DeviceCnt].DevCnt = 1;				
			}else{/* 32bit */
				DeviceDataHed[DeviceCnt].DevCnt = 2;				
			}
			DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];
/*				TrendGraphEventTbl->iUpperRegistNumber = DeviceCnt;*/
			ScreenTagData[iDispOrder].DevCnt= DeviceDataHed[DeviceCnt].DevCnt*2;
			if(TrendGraphEventTbl->i1632BitFlag == BIT16){/* 16bit */				
				iDeviceOffset += 2;
			}else{/* 32bit */				
				iDeviceOffset += 4;
			}
		
			/* 20020819 choijh add*/
/*				TrendGraphEventTbl->Up_SuperVOffset= WatchingDevice(TrendGraphEventTbl->cUpperDeviceName, 
										   TrendGraphEventTbl->iUpperDeviceNumber, 
										   TrendGraphEventTbl->i1632BitFlag,
										   TrendGraphEventTbl->iUpperRegistNumber,
										   WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
			DeviceCnt++;
		}
		/* ���Ѱ��� Device�� ���� ��� */
		if(TrendGraphEventTbl->iCaseLoFixedVal == UNCHECKED){
			DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */			
			DeviceDataHed[DeviceCnt].DevName[0] = TrendGraphEventTbl->cLowerDeviceName[0];
			DeviceDataHed[DeviceCnt].DevName[1] = TrendGraphEventTbl->cLowerDeviceName[1];
			DeviceDataHed[DeviceCnt].DevAddress = TrendGraphEventTbl->iLowerDeviceNumber;
			if(TrendGraphEventTbl->i1632BitFlag == BIT16){/* 16bit */
				DeviceDataHed[DeviceCnt].DevCnt = 1;
			}else{/* 32bit */
				DeviceDataHed[DeviceCnt].DevCnt = 2;				
			}
			DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];			
/*				TrendGraphEventTbl->iLowerRegistNumber = DeviceCnt;*/
			ScreenTagData[iDispOrder].DevCnt= DeviceDataHed[DeviceCnt].DevCnt*2;
			if(TrendGraphEventTbl->i1632BitFlag == BIT16){/* 16bit */				
				iDeviceOffset += 2;
			}else{/* 32bit */				
				iDeviceOffset += 4;
			}

			/* 20020819 choijh add*/
/*				TrendGraphEventTbl->Lw_SuperVOffset= WatchingDevice(TrendGraphEventTbl->cLowerDeviceName, 
										   TrendGraphEventTbl->iLowerDeviceNumber, 
										   TrendGraphEventTbl->i1632BitFlag,
										   TrendGraphEventTbl->iLowerRegistNumber,
										   WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
			DeviceCnt++;
		}
		TrendGraphDispCnt++;
	}
/*	IventTableCnt++;*/
	if(mode == 0){
		for(i=0;i<TrendGraphEventTbl->iNumber;i++){
			for(k=0;k<TrendGraphEventTbl->iPoints;k++){
				TrendDisPoint[i][k] = -1;
				}
		}
	}
	return(0);
}

/********************************************************************************/
/* �� �� �� : TrendGraphDispWatch												*/
/* ��    �� : Trend Graph�±������� ���� ȭ������� ���.						*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002Ҵ 6��  1��													*/
/* �� �� �� : �� � �� 															*/
/* ��    �� : 2002Ҵ 6�� 21�� (��)	����										*/
/********************************************************************************/
void TrendGraphDispWatch(int iOrder)
{
	int		k;
	int		j;
	int		m;
	float	iVSite;
	float	iHSite;
	int		iTemp;
	short	sX;
	int		sY;
	int		eX;
	int		eY;	
	short	sPosition;
	short   iPointVal;
/*	long	lMonitorDevVal[50];	*/
	long	lUpperDevVal;	
	long	lLowerDevVal;	
	long	lBufcheck;
	unsigned long	ulUpperDevVal;	
	unsigned long	ulLowerDevVal;	
	unsigned long	ulBufcheck;

	short	iShapeSize;

	float	fXGapVal;
	float	fYGapVal;
	float	fYGapPos;
	float	*fYGapCoordinates;
	float	*fXGapCoordinates;
	float	*fYGapDeviceValue;
	short	sMove2Type;				/* ���� ��Ÿ�� ����. */

	int				ssx;
	int				ssy;
	int				eex;
	int				eey;
	int				idx;

	_RECTANGLE_INFO				RECParam;
	_LINE_INFO					param;
	_TRENDGRAPH_EVENT_TBL*	 TrendGraphEventTbl;
#ifdef	SIZE_2480_COL
	COLOR_DT	ForLineColor;
#endif

/*	TrendGraphEventTbl= (_TRENDGRAPH_EVENT_TBL*)IventTable[iOrder];*/
	TrendGraphEventTbl= (_TRENDGRAPH_EVENT_TBL*)TakeMemory(sizeof(_TRENDGRAPH_EVENT_TBL));
	DrawTrendGraph_Func(1,TrendGraphEventTbl,iOrder);

	k				= 0;
	j				= 0;
	m				= 0;
	iVSite			= 0;
	iHSite			= 0;
	iTemp			= 0;
	lUpperDevVal	= 0;	
	lLowerDevVal	= 0;	
	fXGapVal		= 0;
	fYGapVal		= 0;
	fYGapPos		= 0;

	fYGapCoordinates= (float *)TakeMemory(sizeof(float)*81);
	fXGapCoordinates= (float *)TakeMemory(sizeof(float)*51);
	fYGapDeviceValue= (float *)TakeMemory(sizeof(float)*81);
	memset(fYGapCoordinates, 0x00, sizeof(float)*81);
	memset(fXGapCoordinates, 0x00, sizeof(float)*51);
	memset(fYGapDeviceValue, 0x00, sizeof(float)*81);
/*	memset(lMonitorDevVal,   0x00, sizeof(lMonitorDevVal));*/

	sX = ScreenTagData[iOrder].sX;
	sY = ScreenTagData[iOrder].sY;
	eX = ScreenTagData[iOrder].eX;
	eY = ScreenTagData[iOrder].eY;

	/* screen update */
/*	if(iOnSignalStart != OFF){*/
	idx= ScreenTagData[iOrder].DevOrder;
		if(TrendGraphEventTbl->iCaseUpFixedVal == CHECKED){
			lUpperDevVal = TrendGraphEventTbl->lUpperFixedData;
		}else{
/*			lUpperDevVal = TrendGraphEventTbl->lBefUpperDevVal;*/
			if(TrendGraphEventTbl->iSignedFlag == UNSIGNED){
				lUpperDevVal= ChangeChar2Unsinlong(&DispDeviceData[idx],TrendGraphEventTbl->i1632BitFlag);
			}else{
				lUpperDevVal= ChangeChar2long(&DispDeviceData[idx],TrendGraphEventTbl->i1632BitFlag);
				if(TrendGraphEventTbl->iSignedFlag == BCD)
					BCD_TO_BIN(&lUpperDevVal);		/* BCD�� �ٲٴ� �Լ� */
			}
			if(TrendGraphEventTbl->i1632BitFlag == BIT16){/* 16bit */
				idx += 2;
			}else{
				idx += 4;
			}
		}
		if(TrendGraphEventTbl->iCaseLoFixedVal == CHECKED){
			lLowerDevVal = TrendGraphEventTbl->lLowerFixedData;
		}else{
/*			lLowerDevVal = TrendGraphEventTbl->lBefLowerDevVal;*/
			if(TrendGraphEventTbl->iSignedFlag == UNSIGNED){
				lLowerDevVal= ChangeChar2Unsinlong(&DispDeviceData[idx],TrendGraphEventTbl->i1632BitFlag);
			}else{
				lLowerDevVal= ChangeChar2long(&DispDeviceData[idx],TrendGraphEventTbl->i1632BitFlag);
				if(TrendGraphEventTbl->iSignedFlag == BCD)
					BCD_TO_BIN(&lLowerDevVal);		/* BCD�� �ٲٴ� �Լ� */
			}
			if(TrendGraphEventTbl->i1632BitFlag == BIT16){/* 16bit */
				idx += 2;
			}else{
				idx += 4;
			}
		}
			if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){		/*	Shape		*/
				iShapeSize = DrawShape(TrendGraphEventTbl->ShapeNo, 
					(sX-4), 
					sY, 
					eX, 
					(eY+4),
					TrendGraphEventTbl->iFrameColor,
					TrendGraphEventTbl->iPlateColor);
				sX+=iShapeSize;
				sY+=iShapeSize;
				eX-=iShapeSize;
				eY-=iShapeSize;
			}
/* Frmae Display				
			if(TrendGraphEventTbl->iFrameChecked == CHECKED){
				RECParam.iLineStyle = SOLID_LINE;
				RECParam.iLineColor = WHITE;
				RECParam.iPattern	= PAT0;
				RECParam.iForeColor = BLACK;
				RECParam.iBackColor = BLACK;
			
				RectAngleOut(sX,
					sY,
					eX,
					eY,
					&RECParam);
			}*/
/* ----------------------- */		

			iVSite = (float)(eY - sY)/(TrendGraphEventTbl->iScalePointsV-1);
			iHSite = (float)(eX - sX)/(TrendGraphEventTbl->iScalePointsH-1);
/*	Scale Display ---------------- */
			if(TrendGraphEventTbl->iScaleDispChecked == CHECKED){	
				param.iLineColor = TrendGraphEventTbl->iScaleColor;
				param.iLineStyle = SOLID_LINE;
				iTemp = eY;
				for(k=1;k<TrendGraphEventTbl->iScalePointsV;k++){
					LineOut(sX - 4, iTemp, sX, iTemp, &param);
					iTemp = (int)(eY - (iVSite*k));
				}
				LineOut(sX - 4, sY, sX, sY, &param);
				iTemp = sX;
				for(k=1;k<TrendGraphEventTbl->iScalePointsH;k++){
					LineOut(iTemp, eY + 4, iTemp, eY, &param);
					iTemp = (int)(sX + (iHSite*k));
				}
				LineOut(eX, eY + 4, eX, eY, &param);
			}
/* ------------------------------- */
/* Graph Data Draw and Format Setting */
/*
		if(TrendGraphEventTbl->NoDeviceFlag == 1)
		{
*/
/*lsi20040529 ���� */

/* 060921		if(TrendGraphEventTbl->NoDeviceFlag == 1 && !(TrendGraphEventTbl->iSignedFlag == BCD && (lLowerDevVal < 0 || lUpperDevVal < 0)))*/ /* leesi 040525 MAE if(TrendGraphEventTbl->NoDeviceFlag == 1)*/
		if(ScreenTagData[iOrder].uu.Trend.NoDeviceFlag == 1 && !(TrendGraphEventTbl->iSignedFlag == BCD && (lLowerDevVal < 0 || lUpperDevVal < 0))) /* leesi 040525 MAE if(TrendGraphEventTbl->NoDeviceFlag == 1)*/
		{
/*lsi20040529*/
			if((TrendGraphEventTbl->i1632BitFlag != 0) && (TrendGraphEventTbl->iSignedFlag == UNSIGNED)){
				ulUpperDevVal= lUpperDevVal;	
				ulLowerDevVal= lLowerDevVal;	
				fYGapPos = (float)(eY - sY)/80;			
				fYGapVal  = (float)((float)ulUpperDevVal - (float)ulLowerDevVal)/80;
				for(k=0;k<81;k++){
					fYGapDeviceValue[k] = ulLowerDevVal + fYGapVal*k;				
					fYGapCoordinates[k] = eY - fYGapPos*k;
				}
				fYGapDeviceValue[80] = (float)ulUpperDevVal;
			}else{
				fYGapPos = (float)(eY - sY)/80;			
				fYGapVal  = (float)((float)lUpperDevVal - (float)lLowerDevVal)/80;
					
				for(k=0;k<81;k++){
					fYGapDeviceValue[k] = lLowerDevVal + fYGapVal*k;				
					fYGapCoordinates[k] = eY - fYGapPos*k;
				}
				fYGapDeviceValue[80] = (float)lUpperDevVal;
				
				if(sY==0)
					fYGapCoordinates[80] = 1;
				else
					fYGapCoordinates[80] = (float)sY;
			}
			fXGapVal = (float)(eX - sX)/(TrendGraphEventTbl->iPoints - 1);			
			for(k=0;k<TrendGraphEventTbl->iPoints;k++){
				if(TrendGraphEventTbl->iDirecition == RIGHT){
					fXGapCoordinates[k] = sX + fXGapVal * k;
				}else{
					fXGapCoordinates[k] = eX - fXGapVal * k;
				}
			}/* ���� ������ ���߾ ����. */
			
/* 060921			if(TrendGraphEventTbl->iStoreMemoryVal==-1){*/
			idx= ScreenTagData[iOrder].uu.Trend.iStoreMemoryVal;
			if(idx == -1){
				for(j=0;j<=TrendGraphEventTbl->iPoints;j++){
					if(j>=CommonArea.SystemDev.TrandEntryCnt)
						break;
					sPosition = CommonArea.SystemDev.TrandStartIdx+j;
					if(sPosition>50)
						sPosition -= 51;
					for(m=0;m<TrendGraphEventTbl->iNumber;m++){
						if((TrendGraphEventTbl->i1632BitFlag != 0) && (TrendGraphEventTbl->iSignedFlag == UNSIGNED)){
							ulBufcheck = CommonArea.TrandeData[m][sPosition];
							if(ulUpperDevVal == ulBufcheck){
								k = 80;
							}else if(ulLowerDevVal > ulBufcheck)
							{
								k = 81;
							
							}else
							{
								for(k=0;k<80;k++){
									if(fYGapDeviceValue[k] >= ulBufcheck){
										break;
									}
								}
								if(k>79 && (ulBufcheck>ulUpperDevVal))
									k++;
							}
							TrendDisPoint[m][j] = k;
						}else{
							lBufcheck = CommonArea.TrandeData[m][sPosition];
							if(TrendGraphEventTbl->iSignedFlag == UNSIGNED)
							{
								if(TrendGraphEventTbl->i1632BitFlag == BIT16)
									lBufcheck = lBufcheck & 0xffff;
								else
									lBufcheck = lBufcheck & 0xffffffff;
							}else if(TrendGraphEventTbl->iSignedFlag == BCD)
							{
								BCD_TO_BIN(&lBufcheck);
							}
							
							if(lUpperDevVal == lBufcheck){
								k = 80;
							}else if(lLowerDevVal > lBufcheck)
							{
								k = 81;
							
							}else
							{
								for(k=0;k<80;k++){
									if(fYGapDeviceValue[k] >= lBufcheck){
										break;
									}
								}
								if(k>79 && (lBufcheck>lUpperDevVal))
									k++;
							}
							TrendDisPoint[m][j] = k;
						}
					}
				}
			}else{
/* 060921				if(CommonArea.SystemDev.StoredInfo[TrendGraphEventTbl->iStoreMemoryVal].St.TrandeInfo.TrandEntryCnt == 0)*/
				if(CommonArea.SystemDev.StoredInfo[idx].St.TrandeInfo.TrandEntryCnt == 0)
				{
					for(j=0;j<TrendGraphEventTbl->iNumber;j++){
						for(m=0;m<TrendGraphEventTbl->iPoints;m++){
							TrendDisPoint[j][m] = -1;
							}
					}
				}
				for(j=0;j<=TrendGraphEventTbl->iPoints;j++){	
					
/* 060921					if(j>=CommonArea.SystemDev.StoredInfo[TrendGraphEventTbl->iStoreMemoryVal].St.TrandeInfo.TrandEntryCnt)*/
					if(j>=CommonArea.SystemDev.StoredInfo[idx].St.TrandeInfo.TrandEntryCnt)
						break;

					for(m=0;m<TrendGraphEventTbl->iNumber;m++){
/* 060921						iPointVal = CommonArea.SystemDev.StoredInfo[TrendGraphEventTbl->iStoreMemoryVal].St.TrandeInfo.TrandStartIdx+j;*/
						iPointVal = CommonArea.SystemDev.StoredInfo[idx].St.TrandeInfo.TrandStartIdx+j;
						if(iPointVal>50)
						{
							iPointVal -= 51;
						}
						if((TrendGraphEventTbl->i1632BitFlag != 0) && (TrendGraphEventTbl->iSignedFlag == UNSIGNED)){
/* 060921							ulBufcheck = CommonArea.StordMem[TrendGraphEventTbl->iStoreMemoryVal].TrandeData[m][iPointVal];*/
							ulBufcheck = CommonArea.StordMem[idx].TrandeData[m][iPointVal];
							if(ulUpperDevVal == ulBufcheck){	
								k = 80;
							}else if(ulLowerDevVal > ulBufcheck)
							{
								k = 81;
							}else{	
								for(k=0;k<80;k++){
									if(fYGapDeviceValue[k] >= ulBufcheck){
										break;
									}
								}
								if(k>79 && (ulBufcheck>ulUpperDevVal))
									k++;

							}
							TrendDisPoint[m][j] = k;
						}else{
/* 060921							lBufcheck = CommonArea.StordMem[TrendGraphEventTbl->iStoreMemoryVal].TrandeData[m][iPointVal];*/
							lBufcheck = CommonArea.StordMem[idx].TrandeData[m][iPointVal];
							if(TrendGraphEventTbl->iSignedFlag == UNSIGNED)
							{
								if(TrendGraphEventTbl->i1632BitFlag == BIT16)
									lBufcheck = lBufcheck & 0xffff;
								else
									lBufcheck = lBufcheck & 0xffffffff;
							}else if(TrendGraphEventTbl->iSignedFlag == BCD)
							{
								BCD_TO_BIN(&lBufcheck);
							}
							if(lUpperDevVal == lBufcheck){	
								k = 80;
							}else if(lLowerDevVal > lBufcheck)
							{
								k = 81;
							}else{	
								for(k=0;k<80;k++){
									if(fYGapDeviceValue[k] >= lBufcheck){
										break;
									}
								}
								if(k>79 && (lBufcheck>lUpperDevVal))
									k++;

							}
							TrendDisPoint[m][j] = k;
						}
					}
				}
			}
			m = 0;
			tt[m].isPosX = 0;
			tt[m].isPosY = 0;
			tt[m].iePosX = 0;
			tt[m].iePosY = 0;

/************************************************/
			
/************************************************/
			for(m = 0;m < TrendGraphEventTbl->iNumber;m++){
				sMove2Type = 1;
				SetDispSema();
				for(j=0;j<=TrendGraphEventTbl->iPoints;j++){
					k = TrendDisPoint[m][j];
/* 050426					if((k>=80 || k<0))*/
					if((k>80 || k<0))
					{
						tt[m].isPosX = 0;
						tt[m].isPosY = 0;
						tt[m].iePosX = 0;
						tt[m].iePosY = 0;
						continue;
					}
					if(j == 0){
						tt[m].iePosX = (int)(fXGapCoordinates[j]+ 0.5);
						tt[m].iePosY = (int)(fYGapCoordinates[k]+ 0.5);
					}else{
						if(j == TrendGraphEventTbl->iPoints){
							tt[m].isPosX = (int)(fXGapCoordinates[0]+ 0.5);
							tt[m].isPosY = tt[m].iePosY;
							tt[m].iePosX = (int)(fXGapCoordinates[0]+ 0.5);
							tt[m].iePosY = tt[m].iePosY;
						}else{
							tt[m].isPosX = tt[m].iePosX; 
							tt[m].isPosY = tt[m].iePosY; 
							tt[m].iePosX = (int)(fXGapCoordinates[j]+0.5);
							tt[m].iePosY  = (int)(fYGapCoordinates[k]+ 0.5);
						}
					}	
					if(tt[m].isPosX != 0 && tt[m].isPosY != 0){ 


/**************************/
						if(TateYoko == 0){
							ssx= tt[m].isPosX;
							ssy= tt[m].isPosY;
							eex= tt[m].iePosX;
							eey= tt[m].iePosY;

						}else{
							ssx= tt[m].isPosY;
							ssy= (GAMEN_Y_SIZE-1) - tt[m].isPosX;
							eex= tt[m].iePosY;
							eey= (GAMEN_Y_SIZE-1) - tt[m].iePosX;
						}
						if(sMove2Type == 1)
						{
							LineBit = 0;
							param.iLineColor= TrendGraphEventTbl->tf[m].iLineColor;
#ifdef	SIZE_2480_COL
							ForLineColor= ChgColorData(param.iLineColor);
							__MoveTo(ssx, ssy, TrendGraphEventTbl->tf[m].iLineType, 0, ForLineColor ); 
#else
							if(param.iLineColor == 0){
								DrawColor = param.iLineColor;
							}else{
								DrawColor = 3;
							}
							__MoveTo(ssx, ssy, TrendGraphEventTbl->tf[m].iLineType, 0 ); 
#endif
							sMove2Type = 0;
						}
						if(j != TrendGraphEventTbl->iPoints){
#ifdef	SIZE_2480_COL
							__LineToPrn(eex, eey,1,ForLineColor);
							__MoveTo(eex, eey, TrendGraphEventTbl->tf[m].iLineType, 0, ForLineColor ); 
#else
							__LineToPrn(eex, eey,1);
/*							if(TrendGraphEventTbl->tf[m].iLineType == 1){*/		/* 041213 Owashi */
								__MoveTo(eex, eey, TrendGraphEventTbl->tf[m].iLineType, 0 ); 
/*							}*/
#endif
						}
/**************************/

					/* leesi 04/06/10	*/

/*						param.iLineColor = TrendGraphEventTbl->tf[m].iLineColor; */
/*						param.iLineStyle = TrendGraphEventTbl->tf[m].iLineType;	*/ /* 1:�Ǽ� 2:�ļ� 3:���� 4:�����⼱ 5:�����⼱  */
/*						LineOut(tt[m].isPosX, tt[m].isPosY, tt[m].iePosX, tt[m].iePosY, &param); */
					}
					tt[m].isPosX = tt[m].iePosX;
					tt[m].isPosY = tt[m].iePosY;
					
				}
/*************************************/
				ResetDispSema();
/*************************************/
			}
		}
/* Frmae Display			*/			
		if(TrendGraphEventTbl->iFrameChecked == CHECKED){	/*    Frame Display	*/
			RECParam.iLineStyle = SOLID_LINE;
			RECParam.iLineColor = WHITE;
			RECParam.iPattern	= PAT0;
			RECParam.iForeColor = BLACK;
			RECParam.iBackColor = BLACK;
		
			RectAngleOut(sX,
				sY,
				eX,
				eY,
				&RECParam);
		}
/* ----------------------- */
	FreeMail((char *)fYGapCoordinates);
	FreeMail((char *)fXGapCoordinates);
	FreeMail((char *)fYGapDeviceValue);
	FreeMail((char *)TrendGraphEventTbl);
}
/* ??????????????????????????????????????????????????????????? */
typedef struct{
	unsigned long ChkTime;
	unsigned long NowTime;	
	unsigned int  iFlag;
} _TREND_DELAY_TIME;
