#include	"sgt.h"

#ifdef	SIZE_2480
/* ****************************************************************************** */
/*  �Լ�																			 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �� �� �� : WindowScreenList()													 */
/*  ��    �� : WindowScreen Listǥ��												 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 7�� 2�� (��)												 */
/*  �� �� �� : �� �� �� 														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void		WindowScreenList(int* iScreenNo)
{
	int				iKeyCode;
	short			i;
	short			iNumY;
	short			TLineCnt;			/* �� ���� ��		*/
	short			NowPoint;			/* ���� ȭ�� ����	*/
	short			iScreenNum;
	short	iKeyFlag;
	_RECTANGLE_INFO RECParam;


	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	iKeyFlag = 1;
	iUserScreenFlag = 0;
	NowPoint = 0;

	for(i=0;i<3;i++)
	{
		iNumY = (i*18);
		RectAngleOut(GAMEN_START_X+1,GAMEN_START_Y+24+iNumY,GAMEN_START_X+196,GAMEN_START_Y+40+iNumY,&RECParam);
	}

	/*	memcpy(chDsp_buff2, Screen[i+j].chTitle, 16);	*/

	DefaultFormDisplay(ARROW_FORM,Dspname[WINDOW_SCREEN].chTitle[Set.iLang]);

	TLineCnt = iWinScreenCnt;
	if(iWinScreenCnt<3)
		TLineCnt = 3;

	WindowScreenNumDisplay(TLineCnt,NowPoint);

	KerRepeatFlag = 1;	/* 040815 */

	while(*iScreenNo == WINDOW_SCREEN_NUM)
	{
		iKeyCode		= KeyWaitData(iKeyFlag,WINDOW_SCREEN_NUM);
		iKeyFlag = 0;
		iScreenNum		= 0;

		if(( iKeyCode == KEY_01 || iKeyCode == KEY_02  ||
			(iKeyCode >= KEY_03 && iKeyCode <= KEY_43) ||
			(iKeyCode >= KEY_46 && iKeyCode <= KEY_60)))
		{	
			iKeyFlag = 1;
			NormalBuzzer();	
		}
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}
		if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 )			/* ����		*/
		{
			*iScreenNo = USER_SCREEN_NUM;
		}
		else if(iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) 		/* ����		*/
		{				
			*iScreenNo = DATA_VIEW_NUM;
		}
		else if(iKeyCode >= KEY_16 && iKeyCode <= KEY_27 )		/*  ȭ��0	*/
		{				
			if(WinScreen[NowPoint].iNum)			
				iScreenNum = WinScreen[NowPoint].iNum;
		}
		else if(iKeyCode >= KEY_31 && iKeyCode <= KEY_42 )		 /*  ȭ��1	*/
		{				
			if(WinScreen[NowPoint+1].iNum)			
				iScreenNum = WinScreen[NowPoint+1].iNum;
		}
		else if(iKeyCode >= KEY_46 && iKeyCode <= KEY_57 )		 /*  ȭ��2	*/
		{				
			if(WinScreen[NowPoint+2].iNum)			
				iScreenNum = WinScreen[NowPoint+2].iNum;
		}
		else if(iKeyCode == KEY_29 || iKeyCode == KEY_30 ) 		/* UP_KEY	 */
		{				
			if(NowPoint > 0)
			{
				NowPoint--;
				WindowScreenNumDisplay(TLineCnt,NowPoint);
			}
		}
		else if(iKeyCode == KEY_59 || iKeyCode == KEY_60 )		/* DOWN_KEY */
		{				
			if(TLineCnt-NowPoint > 3)
			{
				NowPoint++;
				WindowScreenNumDisplay(TLineCnt,NowPoint);
			}
		}else if(iKeyCode == KEY_28)  /* ó  �� */ /************************************************************/
		{
			if(NowPoint != 0)
			{
				NowPoint = 0;
				WindowScreenNumDisplay(TLineCnt,NowPoint);
			}
			iKeyFlag = 0;
/*ksc20040624*/ /* ������ ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */
/*			KerRepeatFlag = 1;*/ 
/*ksc20040624*/
			
		}else if(iKeyCode == KEY_43)  /* ��  �� */
		{
			if(NowPoint != (TLineCnt/2-1) && (TLineCnt/2-1) > 3)
			{
				NowPoint = (TLineCnt/2-1);
				WindowScreenNumDisplay(TLineCnt,NowPoint);
			}
			iKeyFlag = 0;
/*ksc20040624*/ /* ������ ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */
/*			KerRepeatFlag = 1;*/ 
/*ksc20040624*/

		}else if(iKeyCode == KEY_58)  /* ������ */
		{
			
			if(TLineCnt-NowPoint > 3 && TLineCnt > 3)
			{
				NowPoint = TLineCnt-3;
				WindowScreenNumDisplay(TLineCnt,NowPoint);
			}
			iKeyFlag = 0;
/*ksc20040624*/ /* ������ ȭ�� ����Ʈ ���⿡�� ����ƮŰ�� �ǹ̾��� */
/*			KerRepeatFlag = 1;*/ 
/*ksc20040624*/

		}else
			iKeyCode= -1;
		iScreenDisp = 0;
		if(iScreenNum > 0 && iWinScreenCnt > 0)
		{
			iScreenDisp = iScreenNum;
			*iScreenNo = USER_SCREEN_NUM;
			iUserScreenFlag = 2;
		}
	}
}
/* ****************************************************************************** */
/*  �� �� �� : WindowScreenNumDisplay()											 */
/*  ��    �� : WindowScreen ��ȣ�� ǥ��											 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 7�� 2�� (��)												 */
/*  �� �� �� : �� �� �� 														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void		WindowScreenNumDisplay(int TLineCnt, int iStartNum)
{
	short		i;
	short		j;
	short		iCnt;
	short		iNumY;
	char		ScreenNum[25];
	char		WinTitle[33];

	if(iWinScreenCnt>0)
	{
		for(i=0;i<3;i++)
		{
			iCnt = 0;
			memset(ScreenNum,0x00,sizeof(ScreenNum));
			memset(WinTitle,0x00,sizeof(WinTitle));
			iNumY = (i*18);
			AreaClear(2,25+iNumY,195,39+iNumY,0);
			if(WinScreen[iStartNum+i].chTitle)
				memcpy(WinTitle,WinScreen[iStartNum+i].chTitle,32);
			sprintf(ScreenNum,"%3d %s",WinScreen[iStartNum+i].iNum,WinTitle);
			if(strlen(ScreenNum)>24)
			{
				memset(ScreenNum+24,0x00,2);
				for(j=0;j<24;j++)
				{
					if(ScreenNum[j]>0x00 && ScreenNum[j]<0x7f)
						iCnt++;
					else
						j++;

				}
				if(iCnt%2 == 1)	/* ������ �ڸ��� 2Byte �����̾... */
				{
					memset(ScreenNum+23,0x00,1);
				}
			}
			DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, ScreenNum, 1, 1, NON_TRANS,T_WHITE,T_BLACK);
			if(iStartNum+i+1 >= iWinScreenCnt)
				break;		
		}
	}
	ScroolBarDisplay(TLineCnt,iStartNum);
	DrawLcdBank1();
}
#endif
/* *******************************************************************************/
/*  �� �� �� : vScreenDataSet()													 */
/*  ��    �� : Screen Data ��ȣ�� Title�� ����									 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 3�� 28�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
void	vScreenDataSet()
{
	int				iSum;
	int				i;
	int				j;
	int				isize;
	int				ipos;
	int				iTagSiteInfo;	
	int				iScreenNow;
	int				iDevAddress;
	int				iBuffSum;
	char			chFileName[13];
	short			iStoreFlag;
	short			k;
	short			iTotalCnt;
	short			iTagCode;
	short			iOffset;
	struct find_t	finddata; 
	unsigned char	*AllTagBuf;	
	_SCREEN_DATA	BufferScreen;
	j = 0;

	memset(chFileName,0x00,sizeof(chFileName));

	for(i = 0; i<512 ; i++)
	{
		Screen[i].iNum = 0x00;
		Screen[i].chTitle=0x00;
	}
	for(i = 0; i<16 ; i++)
		iStoreScreenNum[i] = 0;

	i = 0;	
	j = m_findfirst("BAS*.*", ATTR_RDO, &finddata);
	CommonArea.SystemDev.StoredMemCnt = 0;

	/***********************************************/
	//061124
#ifdef	WIN32
	iScreenNow =  (CommonArea.SwitchingData[0] & 0xff) << 8;
	iScreenNow += (CommonArea.SwitchingData[0] & 0xff00) >> 8;
#else
	iScreenNow = CommonArea.SwitchingData[0];
#endif
	/***********************************************/
	if(iTransFlag == 0){
		memset(&CommonArea.SystemDev,0x00,sizeof(CommonArea.SystemDev));
		/* CommonArea.SystemDev �κ� Area�� ���� Ŭ������.  */
	}else{
		KansiHotClear(1);
	}
	while(j == OK)
	{
		memcpy(chFileName,finddata.name,strlen(finddata.name)); 
//		ret= mfileserch(chFileName,&ipos,&isize);
		mfileserch(chFileName,&ipos,&isize);
		
		AllTagBuf=(unsigned char *)TakeMemory(isize + 1);
		memset(AllTagBuf,0x00,isize + 1);
		memcpy(AllTagBuf,(char *)ipos,isize);

		Screen[i].iNum = (int)AllTagBuf[7]+((int)(AllTagBuf[6] & 0x7F)*256);
		/************���븮���� �߰��� ���ؼ� �߰���.(0x7f)********/
		/**************************************/

		if(iScreenNow == Screen[i].iNum){
			iPassPoint = i;
		}
		/**************************************/

		iSum = ((int)AllTagBuf[8]*256)+(int)AllTagBuf[9]+11;

		if(AllTagBuf[iSum]==0xa8)								/* 0xa8			*/
		{
			if(AllTagBuf[++iSum] != 0)
			{
				iSum++;											/* iSum += 2;	*/										
		/*		memcpy(Screen[i].chTitle,&AllTagBuf[iSum],32); */
				Screen[i].chTitle = (char *)(ipos+iSum);
			}else
			{
				iSum++;	
			}

		}
		iSum += 40;							/* */
		if(AllTagBuf[iSum]==0xAC){				/*		*/
			isize = (AllTagBuf[++iSum]<<8);
			isize += AllTagBuf[++iSum];
			iSum += isize;
			iStoreFlag = AllTagBuf[++iSum];
			iSum++;
		}
		iSum +=2;	/* ����(1), No(1) */
		if(AllTagBuf[iSum]==0xa7){
			iBuffSum = iSum;
			iSum += (unsigned int)AllTagBuf[++iBuffSum] << 0x18;
			iSum += (unsigned int)(AllTagBuf[++iBuffSum] & 0xffffff) << 0x10; 
			iSum += (unsigned int)(AllTagBuf[++iBuffSum] & 0xffff) << 0x08;
			iSum += (unsigned int)(AllTagBuf[++iBuffSum] & 0xff);
		
/*
			iSum+=4;
*/
			/* Screen Auxiliary Setting	*/

			Screen[i].iDefKeyAct = AllTagBuf[++iBuffSum];  /* Defined key action */
			Screen[i].iCarryFlag = AllTagBuf[++iBuffSum];  /* Carry out display of alarm flow */
			Screen[i].Sheetcolor = AllTagBuf[++iBuffSum];
			Screen[i].iSecurity  = AllTagBuf[++iBuffSum];
			Screen[i].KeyWinFlag = AllTagBuf[++iBuffSum];
			if(Screen[i].KeyWinFlag == 0xff)
			{
				Screen[i].KeyWinSx	 = (AllTagBuf[++iBuffSum]*256);
				Screen[i].KeyWinSx	+= AllTagBuf[++iBuffSum];
				Screen[i].KeyWinSy	 = (AllTagBuf[++iBuffSum]*256);
				Screen[i].KeyWinSy	+= AllTagBuf[++iBuffSum];
/*				iSum	+=	13;	*/		/*
											KeyWinEndXY(4),		PanelSize(8),
											OverScreenCount(1),	OverScreenNo(OverScreenCount*2),
											EndCode(1)			
										*/
/*				iSum	+=	(AllTagBuf[iSum]*2);
				iSum+=2;
				iSum+=9;*/		/* Edit ����ϴ� �����  */
			}else
			{
				Screen[i].KeyWinSx = 0;
				Screen[i].KeyWinSy = 0;
/*				iSum	+=	17;*/			/* KeyWinStartEndXY(8),PanelSize(8),OverScreenCount(1),OverScreenNo(4),EndCode(1) */
/*				iSum	+=	(AllTagBuf[iSum]*2);
				iSum+=2;
				iSum+=9;*/		/* Edit ����ϴ� �����  */
			}
		}
		/*				*/
		/*iSum++;			No(1)	*/

#ifdef	OLD
/**************************************************************************************************************************/
/* Observe_Screen					*/
/*		if(AllTagBuf[iSum] == 0xA2){
			isize  =  (int) (AllTagBuf[++iSum] << 24);
			isize +=  ((int)(AllTagBuf[++iSum] << 16) & 0xffffff);
			isize +=  ((int)(AllTagBuf[++iSum] << 8) & 0xffff);
			isize +=  (int)  AllTagBuf[++iSum] & 0xff;
			if(isize != 0x0A)
			{
				
				CommonArea.SystemDev.Screen_ObserveStatus = (int) AllTagBuf[++iSum];
				if(CommonArea.SystemDev.Screen_ObserveStatus == 0xFF){
					CommonArea.SystemDev.Screen_ObserveTime = (int) AllTagBuf[++iSum];
				}else{
					CommonArea.SystemDev.Screen_ObserveTime = 0;
					++iSum;
				}
				CommonArea.SystemDev.Observe_Screen_Cnt = (int)AllTagBuf[++iSum];
				for(k=0;k<CommonArea.SystemDev.Observe_Screen_Cnt;k++)
				{
					CommonArea.SystemDev.Observe_Screen_Dev[k].Dev1Inf = (int)AllTagBuf[++iSum];
					iSum++;
					GetDeviceSet((AllTagBuf+iSum),
								CommonArea.SystemDev.Observe_Screen_Dev[k].DevName1,
								&(iDevAddress));
					CommonArea.SystemDev.Observe_Screen_Dev[k].DevAdd1 = (short) iDevAddress;
					iSum+=4;	

					CommonArea.SystemDev.Observe_Screen_Dev[k].Dev2Inf = (int)AllTagBuf[++iSum];
					iSum++;
					GetDeviceSet((AllTagBuf+iSum),
								CommonArea.SystemDev.Observe_Screen_Dev[k].DevName2,
								&(iDevAddress));
					CommonArea.SystemDev.Observe_Screen_Dev[k].DevAdd2 = (short) iDevAddress;
					iSum+=4;


					CommonArea.SystemDev.Observe_Screen_Dev[k].Action = (int)AllTagBuf[++iSum]; 
					*//*Momentary : 0x00, Set : 0x01, Reset : 0x02, Alternate : 0x03, Word 16bit : 0x04, Word 32bit : 0x05
					
					CommonArea.SystemDev.Observe_Screen_Dev[k].point =	(int)AllTagBuf[++iSum];
					++iSum;*/			/* Type : signed - 0x00 unsigned - 0xff	


					iSum++;
					GetDeviceSet((AllTagBuf+iSum),
								CommonArea.SystemDev.Observe_Screen_Dev[k].DevName3,
								&(iDevAddress));
					CommonArea.SystemDev.Observe_Screen_Dev[k].DevAdd3 = (short) iDevAddress;
					iSum+=4;

					CommonArea.SystemDev.Observe_Screen_Dev[k].FixData = (AllTagBuf[++iSum] << 0x08);
					CommonArea.SystemDev.Observe_Screen_Dev[k].FixData += (AllTagBuf[++iSum] & 0xff);

					if(0xFF == AllTagBuf[++iSum]){*/			/* IndirectFlag						
						iSum++;
						GetDeviceSet((AllTagBuf+iSum),
									CommonArea.SystemDev.Observe_Screen_Dev[k].DevName4,
									&(iDevAddress));
						CommonArea.SystemDev.Observe_Screen_Dev[k].DevAdd4 = (short) iDevAddress;
						iSum+=4;
					}else
					{
						iSum += 5;
					}
					CommonArea.SystemDev.Observe_Screen_Dev[k].MoveType = AllTagBuf[++iSum];
				}
				
			}
		}*/
#endif
/**************************************************************************************************************************/


		if(iStoreFlag == 0xFF){			/*   Checkflag */
			k		=	0;	
			iSum	=	10;
			iTotalCnt  = (int)((AllTagBuf[iSum]) << 0x08);
			iTotalCnt += (int)(AllTagBuf[++iSum]);
			
			while(k < iTotalCnt){
				iTagSiteInfo  = (int)((AllTagBuf[++iSum]) << 0x18);
				iTagSiteInfo += (int)((AllTagBuf[++iSum]) << 0x10);
				iTagSiteInfo += (int)((AllTagBuf[++iSum]) << 0x08);
				iTagSiteInfo += (int)(AllTagBuf[++iSum]);
				iTagSiteInfo += 10;
				ipos = 0;
				/*memcpy(cTempBuff[0], AllTagBuf[iTagSiteInfo], 1);*/
				iTagCode = (unsigned int)AllTagBuf[iTagSiteInfo];
				if(iTagCode==0x70){		/* Alarm List Data���	*/
					ipos = (iTagSiteInfo-2);
					if(((unsigned int)AllTagBuf[ipos+30] & 0x01) == 0x01){  /* Storage check  */
						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].Kind = 0;				/* 0:Alarm List,1:Trand Graph*/
						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.AlarmInfo.StorelAlarm.DevCnt = (unsigned int)AllTagBuf[ipos+21];	/* Device Point No. */
						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.AlarmInfo.AlarmDevCnt = (unsigned int)AllTagBuf[ipos+21];			/* Device Point No. */


						/*------------------------------------------------------------*/
						GetDeviceSet((AllTagBuf+ipos+24),
									CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.AlarmInfo.StorelAlarm.DevName,
									&(iDevAddress));
						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.AlarmInfo.StorelAlarm.DevAdd = iDevAddress;
						/*-------------------------------------------------------------*/


						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.AlarmInfo.AlarmGno =  Screen[i].iNum;		/* Screen_Number */
						/*------------------------------*/
						if(((unsigned int)AllTagBuf[ipos+36] & 0xff) == 0xff){
							/*------------------------------------------------------------*/
							GetDeviceSet((AllTagBuf+ipos+37),
										CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.AlarmInfo.StorelAlarmCnt.DevName,
										&(iDevAddress));
							CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.AlarmInfo.StorelAlarmCnt.DevAdd = iDevAddress;
							/*-------------------------------------------------------------*/
						}
						/*------------------------------------------*/
						iStoreScreenNum[CommonArea.SystemDev.StoredMemCnt] = Screen[i].iNum;
						CommonArea.SystemDev.StoredMemCnt++;
					}
				}else if(iTagCode == 0x82){	/* Trend Graph Data���	*/
					ipos = (iTagSiteInfo-2);
					if(((unsigned int)AllTagBuf[ipos+31] & 0xff) == 0xff){
						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].Kind = 1;				/* 0:Alarm List,1:Trand Graph*/
						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.Trand_Dev.DevCnt = AllTagBuf[ipos+16];
						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.TrandPoint = AllTagBuf[ipos+17];
						/* Store Memory ���� -----*/
						iOffset = 33;
						
						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.TrandClearMode = ((unsigned int)AllTagBuf[ipos+32] & 0x03);
						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.TrandClearMode-=1;

						if(CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.TrandClearMode == 0x01 || 
							CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.TrandClearMode == 0x02)
						{
							/* 0x01(No clear trigger), 0x02(Clear on trgger rise), 0x03(Clear on trgger Fall) */
							/* short	TrandClearMode;	*/	/* Trend Clear Mode 0:none,1:up,2:down */
							/*DEVICE_TYPE	Trand_ClrDev;*/	/* Trend Clear Trigger Dev */
							GetDeviceSet((AllTagBuf+ipos+iOffset),
										CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.Trand_ClrDev.DevName,
										&(iDevAddress));
							CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.Trand_ClrDev.DevAdd = iDevAddress;
							iOffset += 5;		
						}

						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.TrandTime = (unsigned int)(AllTagBuf[ipos+iOffset] << 0x08);
						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.TrandTime += (unsigned int)AllTagBuf[ipos+iOffset+1] & 0xff;
						if(CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.TrandTime==0)
						{
							CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.TrandTime = 1;
						}
						/*------------------------*/
						if((unsigned int)AllTagBuf[ipos+20] < 3)
						{
							iOffset += 3;	
						}

						iOffset += (unsigned int)(AllTagBuf[ipos+16]*2) + 5;

						/*------------------------------------------------------------*/
						GetDeviceSet((AllTagBuf+ipos+iOffset),
									CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.Trand_Dev.DevName,
									&(iDevAddress));
						CommonArea.SystemDev.StoredInfo[CommonArea.SystemDev.StoredMemCnt].St.TrandeInfo.Trand_Dev.DevAdd = iDevAddress;
						/*-------------------------------------------------------------*/

						iStoreScreenNum[CommonArea.SystemDev.StoredMemCnt] = Screen[i].iNum;
						CommonArea.SystemDev.StoredMemCnt++;
					}
				} 
				k++;								   
			}
		}
		i++;
		j = m_findnext(&finddata);
		FreeMail((char*)AllTagBuf);
	}
	iBaseScreenCnt = i;
	isize = sizeof(_SCREEN_DATA);
	for(j=0;j<iBaseScreenCnt-1;j++)
	{
		for(i=j+1;i<iBaseScreenCnt;i++)
		{
			if(Screen[i].iNum < Screen[j].iNum)
			{
				BufferScreen = Screen[i];
				Screen[i] = Screen[j];
				Screen[j] = BufferScreen;
			}
		}
	}
		/* Window */
	iWinScreenCnt = 0;
	i = 0;
	isize = 0;
	j = m_findfirst("Win*.*", ATTR_RDO, &finddata);
	while(j == OK)
	{
		memcpy(chFileName,finddata.name,strlen(finddata.name)); 
		mfileserch(chFileName,&ipos,&isize);
		
		AllTagBuf=(unsigned char *)TakeMemory(isize + 1);
		memset(AllTagBuf,0x00,isize + 1);
		memcpy(AllTagBuf,(char *)ipos,isize);

		WinScreen[i].iNum = (int)AllTagBuf[7]+((int)(AllTagBuf[6]&0x7F)*256);
		iSum = ((int)AllTagBuf[8]*256)+(int)AllTagBuf[9]+11;

		if(AllTagBuf[iSum]==0xa8)								/* 0xa8			*/
		{
			if(AllTagBuf[++iSum] != 0)
			{
				iSum++;											/* iSum += 2;	*/										
				WinScreen[i].chTitle=(char *)(ipos+iSum); 
			}else
			{
				iSum++;	
			}

		}
		
		iSum += 45;
		if(AllTagBuf[iSum]==0xa7){
			iSum+=4;
			WinScreen[i].iDefKeyAct = AllTagBuf[++iSum];
			WinScreen[i].iCarryFlag = AllTagBuf[++iSum];
			WinScreen[i].Sheetcolor = AllTagBuf[++iSum];
			WinScreen[i].iSecurity  = AllTagBuf[++iSum];
			WinScreen[i].KeyWinFlag = AllTagBuf[++iSum];
			if(WinScreen[i].KeyWinFlag == 0xff){
				WinScreen[i].KeyWinSx	 = (AllTagBuf[++iSum]*256);
				WinScreen[i].KeyWinSx	+= AllTagBuf[++iSum];
				WinScreen[i].KeyWinSy	 = (AllTagBuf[++iSum]*256);
				WinScreen[i].KeyWinSy	+= AllTagBuf[++iSum];
			}else
			{
				WinScreen[i].KeyWinSx = 0;
				WinScreen[i].KeyWinSy = 0;
			}
		}
		
		i++;
		iWinScreenCnt++;
		j = m_findnext(&finddata);
		FreeMail((char*)AllTagBuf);
	}
	return;
}

/* *******************************************************************************/
/*  �� �� �� : Observe_ScreenSet()													 */
/*  ��    �� : Screen Data ��ȣ�� Title�� ����									 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 3�� 28�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
void	Observe_ScreenSet(short	iScreenNum)
{
	int				iSum;
	int				isize;
	int				ipos;
	int				iDevAddress;
	int				iBuffSum;
	char			chFileName[13];
	short			k;
	unsigned char	*AllTagBuf;	

	memset(chFileName,0x00,sizeof(chFileName));
	sprintf(chFileName,"Bas%05d.gp",iScreenNum);

	if(mfileserch(chFileName,&ipos,&isize) == OK)
	{
/*		AllTagBuf=(unsigned char *)TakeMemory(isize + 1);
		memset(AllTagBuf,0x00,isize + 1);
		memcpy(AllTagBuf,(char *)ipos,isize);
*/
		AllTagBuf = (unsigned char *)ipos;
		iSum = ((int)AllTagBuf[8]*256)+(int)AllTagBuf[9]+11;

		if(AllTagBuf[iSum]==0xa8)								/* 0xa8			*/
		{
			iSum+=2;											/* iSum += 2;	*/										
		}
		iSum += 40;							/* */
		if(AllTagBuf[iSum]==0xAC){				/*		*/
			isize = (AllTagBuf[++iSum]<<8);
			isize += AllTagBuf[++iSum];
			iSum += isize;
			iSum +=2;
		}
		iSum +=2;	/* ����(1), No(1) */
		if(AllTagBuf[iSum]==0xa7){
			iBuffSum = iSum;
			iSum += (unsigned int)AllTagBuf[++iBuffSum] << 0x18;
			iSum += (unsigned int)(AllTagBuf[++iBuffSum] & 0xffffff) << 0x10; 
			iSum += (unsigned int)(AllTagBuf[++iBuffSum] & 0xffff) << 0x08;
			iSum += (unsigned int)(AllTagBuf[++iBuffSum] & 0xff);
		}
		/* Observe_Screen	*/
		if(AllTagBuf[iSum] == 0xA2){
			isize  =  (int) (AllTagBuf[++iSum] << 24);
			isize +=  ((int)(AllTagBuf[++iSum] << 16) & 0xffffff);
			isize +=  ((int)(AllTagBuf[++iSum] << 8) & 0xffff);
			isize +=  (int)  AllTagBuf[++iSum] & 0xff;
			if(isize != 0x0A)
			{
				
				CommonArea.SystemDev.Screen_ObserveStatus = (int) AllTagBuf[++iSum];
				if(CommonArea.SystemDev.Screen_ObserveStatus == 0xFF){
					CommonArea.SystemDev.Screen_ObserveTime = (int) AllTagBuf[++iSum];
				}else{
					CommonArea.SystemDev.Screen_ObserveTime = 0;
					++iSum;
				}
				CommonArea.SystemDev.Observe_Screen_Cnt = (int)AllTagBuf[++iSum];
				for(k=0;k<CommonArea.SystemDev.Observe_Screen_Cnt;k++)
				{
					CommonArea.SystemDev.Observe_Screen_Dev[k].Dev1Inf = (int)AllTagBuf[++iSum];
					iSum++;
					GetDeviceSet((AllTagBuf+iSum),
								CommonArea.SystemDev.Observe_Screen_Dev[k].DevName1,
								&(iDevAddress));
					CommonArea.SystemDev.Observe_Screen_Dev[k].DevAdd1 = iDevAddress;
					iSum+=4;		/**/
/**/

					CommonArea.SystemDev.Observe_Screen_Dev[k].Dev2Inf = (int)AllTagBuf[++iSum];

					iSum++;
					GetDeviceSet((AllTagBuf+iSum),
								CommonArea.SystemDev.Observe_Screen_Dev[k].DevName2,
								&(iDevAddress));
					CommonArea.SystemDev.Observe_Screen_Dev[k].DevAdd2 = iDevAddress;
					iSum+=4;


					CommonArea.SystemDev.Observe_Screen_Dev[k].Action = (int)AllTagBuf[++iSum]; /*Momentary : 0x00, Set : 0x01, Reset : 0x02, Alternate : 0x03, Word 16bit : 0x04, Word 32bit : 0x05 */
					CommonArea.SystemDev.Observe_Screen_Dev[k].point =	(int)AllTagBuf[++iSum];
					++iSum;			/* Type : signed - 0x00 unsigned - 0xff	*/


					/*------------------------------------------------------------*/
					iSum++;
					GetDeviceSet((AllTagBuf+iSum),
								CommonArea.SystemDev.Observe_Screen_Dev[k].DevName3,
								&(iDevAddress));
					CommonArea.SystemDev.Observe_Screen_Dev[k].DevAdd3 = iDevAddress;
					iSum+=4;
					/*-------------------------------------------------------------*/
					CommonArea.SystemDev.Observe_Screen_Dev[k].FixData = (AllTagBuf[++iSum] << 24);
					CommonArea.SystemDev.Observe_Screen_Dev[k].FixData += (AllTagBuf[++iSum] << 16);
					CommonArea.SystemDev.Observe_Screen_Dev[k].FixData += (AllTagBuf[++iSum] << 8);
					CommonArea.SystemDev.Observe_Screen_Dev[k].FixData += (AllTagBuf[++iSum] & 0xff);

					if(0xFF == AllTagBuf[++iSum]){			/* IndirectFlag		*/				
						/*------------------------------------------------------------*/
						iSum++;
						GetDeviceSet((AllTagBuf+iSum),
									CommonArea.SystemDev.Observe_Screen_Dev[k].DevName4,
									&(iDevAddress));
						CommonArea.SystemDev.Observe_Screen_Dev[k].DevAdd4 = iDevAddress;
						iSum+=4;
						/*-------------------------------------------------------------*/
					}else
					{
						memset(CommonArea.SystemDev.Observe_Screen_Dev[k].DevName4,0x00,3);
						CommonArea.SystemDev.Observe_Screen_Dev[k].DevAdd4 = 0;
						iSum += 5;
					}
					CommonArea.SystemDev.Observe_Screen_Dev[k].MoveType = AllTagBuf[++iSum];
				}
			}else
			{
				CommonArea.SystemDev.Observe_Screen_Cnt = 0;
			}
		}else
		{
			CommonArea.SystemDev.Observe_Screen_Cnt = 0;
		}
	/*	FreeMail((char*)AllTagBuf);*/
	}
	return;
}
int NowBackColor(int iScreenNum)
{
	int		i;
	int		ReturnData;
	int		iScreenNow;
	ReturnData = 0;
/*
	iScreenNow =  (CommonArea.SwitchingData[1] << 8);
	iScreenNow += CommonArea.SwitchingData[0] & 0xff;
*/
	iScreenNow= iScreenNum;
	for(i=0;i<iBaseScreenCnt;i++)
	{
		if(Screen[i].iNum == iScreenNow)
		{
			ReturnData = Screen[i].Sheetcolor;
			break;
		}
	}
	return ReturnData;
}
