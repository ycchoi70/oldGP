/* *******************************************************************************/
/*  �� �� �� : GP_MODELVER.CPP													 */
/*  ��    �� : �� ���� ǥ��													 */
/*  �� �� �� : 2006�� 3�� 15�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : (��)Autonics														 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
#include	"sgt.h"

#ifdef	LP_S044
const	char	*device_name[]={"X0","X1","X2","X3","X4","X5","X6","X7","X8","X9","XA","XB","XC","XD","XE","XF",
							"Y0","Y1","Y2","Y3","Y4","Y5","Y6","Y7","Y8","Y9","YA","YB","YC","YD","YE","YF"};
const unsigned char	MornFont[2][8]={
	{
		0xff,0x81,0x81,0x81,0x81,0x81,0x81,0xff
	},
	{
		0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff
	}};
void		vXYDeviceMoni(int* iScreenNo)

{
	int		j;
	int		Start_flag;
	int		Cmp_Bit;
	int		iRetValue_X,iRetValue_Y;
	int		bf_iRetValue_X,bf_iRetValue_Y;
	int		DrawLcdflagX;
	int		DrawLcdflagY;
	int			iKeyCode;
	char		cDispMemory[32];

	_RECTANGLE_INFO RECParam;

#ifdef	SIZE_2480_COL
	COLOR_FRM color;
#endif

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;
	Start_flag = 0;
	bf_iRetValue_X = 0;
	bf_iRetValue_Y = 0;
	memset(cDispMemory,0x00,sizeof(cDispMemory));
	ClearDispBuff(SCREEN_0);


	DefaultFormDisplay(LINE_FORM,Dspname[XY_DEVICE_MONITORING].chTitle[Set.iLang]);
	RectAngleOut(1,24,18,50,&RECParam);
	RectAngleOut(1,52,18,78,&RECParam);
	RectAngleOut(20,24,238,50,&RECParam);	
	RectAngleOut(20,52,238,78,&RECParam);	
	DotTextOut(5,30,"I",1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(5,58,"O",1,1, NON_TRANS, T_WHITE, T_BLACK);

	for(j=0; j<16; j++){
		DotTextOut(26+(13*j),28,(char*)device_name[j],0,0, NON_TRANS, T_WHITE, T_BLACK);
		DotTextOut(26+(13*j),56,(char*)device_name[j+16],0,0, NON_TRANS, T_WHITE, T_BLACK);
	}
	DrawLcdBank1();
	while ( *iScreenNo == DEVICE_XY_MONITORING_NUM ) 
	{
		iKeyCode = iKeyAcceptReturn(DEVICE_MONITORING_NUM);

			/* Ű ���� ó�� */		
		if ((iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) ||	/*Exit*/
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ))	/*Menu*/
		{
			NormalBuzzer();				/*	Buzzer  */
		}
		if(iKeyCode == 0){
			iKeyCode = -1;
			continue;
		}
		switch(iKeyCode){
		case PC_DNLOAD_START:	/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			break;
		case PC_UPLOAD_START:	/* UPLoad	*/
			*iScreenNo = UP_TRANS;
			break;
		case KEY_01:
		case KEY_02:	/* EXIT */
				*iScreenNo = USER_SCREEN_NUM;
			break;
		case KEY_13:
		case KEY_14:
		case KEY_15:	/* MENU */
				*iScreenNo = MONITORING_NUM;
			break;
		default:

			break;
		}
			
		iRetValue_X =	(unsigned int)InDevArea.UW[Device_Length_X_ST];
		iRetValue_Y =	(unsigned int)InDevArea.UW[Device_Length_Y_ST];
	
		if(( bf_iRetValue_X != iRetValue_X ) || (Start_flag == 0)){	DrawLcdflagX= 1;	}
		else{														DrawLcdflagX= 0;	}
		if((bf_iRetValue_Y != iRetValue_Y) || (Start_flag == 0)){	DrawLcdflagY= 1;	}
		else{														DrawLcdflagY= 0;	}

		bf_iRetValue_X = iRetValue_X;
		bf_iRetValue_Y = iRetValue_Y;

		if(DrawLcdflagX == 1){
			AreaClear(28,38,230,45,0);
			Cmp_Bit=1;
#ifdef	SIZE_2480_COL
			memset(&color,0,sizeof(color));
			for(j=0; j<16; j++){
				if(( iRetValue_X & Cmp_Bit) == 0){
					DotWriteFont0(0,28+(13*j),38,(unsigned char *)&MornFont[0],T_BLACK,1,0,NON_TRANS,0,0,&color);
				}else{
					DotWriteFont0(0,28+(13*j),38,(unsigned char *)&MornFont[1],T_BLACK,1,0,NON_TRANS,0,0,&color);
				}
				Cmp_Bit <<= 1;
			}
#else
			for(j=0; j<16; j++){
				if(( iRetValue_X & Cmp_Bit) == 0){
					DotWriteFont0(0,28+(13*j),38,(unsigned char *)&MornFont[0],T_BLACK,1,0,NON_TRANS,0,0);
				}else{
					DotWriteFont0(0,28+(13*j),38,(unsigned char *)&MornFont[1],T_BLACK,1,0,NON_TRANS,0,0);
				}
				Cmp_Bit <<= 1;
			}
#endif
		}
		if(DrawLcdflagY == 1){
			AreaClear(28,66,230,73,0);
			Cmp_Bit=1;
#ifdef	SIZE_2480_COL
			memset(&color,0,sizeof(color));
			for(j=0; j<16; j++){
				if(( iRetValue_Y & Cmp_Bit) == 0){
					DotWriteFont0(0,28+(13*j),66,(unsigned char *)&MornFont[0],T_BLACK,1,0,NON_TRANS,0,0,&color);
				}else{
					DotWriteFont0(0,28+(13*j),66,(unsigned char *)&MornFont[1],T_BLACK,1,0,NON_TRANS,0,0,&color);
				}
				Cmp_Bit <<= 1;
			}
#else
			for(j=0; j<16; j++){
				if(( iRetValue_Y & Cmp_Bit) == 0){
					DotWriteFont0(0,28+(13*j),66,(unsigned char *)&MornFont[0],T_BLACK,1,0,NON_TRANS,0,0);
				}else{
					DotWriteFont0(0,28+(13*j),66,(unsigned char *)&MornFont[1],T_BLACK,1,0,NON_TRANS,0,0);
				}
				Cmp_Bit <<= 1;
			}
#endif
		}
		if((DrawLcdflagX == 1) || (DrawLcdflagY == 1)){
			DrawLcdBank1();
		}
		Start_flag = 1;
		Delay(50);

	} /*  end while  */
	return;
}


#endif
