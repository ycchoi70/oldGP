/* ****************************************************************************** */
/*  �� �� ��E: GP_DEVINPUT2.CPP													 */
/*  ��E   �� : ����̽� �Է� ������E2											 */
/*  �� �� �� : 2002��E2��E18�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��    �� : (��) LC Tech														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

/* ****************************************************************************** */
/*  �Լ�E																		 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  ��E��E��E: vDevInput2(char *chKey1, char *chKey2, int iSize, int iSize2)		 */
/*  ��E   �� : ����̽� �ּ� �Է¿�E������E										 */
/*  ��    �� : chKey1 : Ÿ��(X,Y,M,S,T,C,D16,D32,Z,V) ENTRY CODE������(DELETE...)  */	
/* 			  chKey2 : 								 */
/* 			  iSize1 : 1�̸�EENTRYCODE	0�̸�EDEVICEMONI						 */
/* 			  iSize2 : ��ȣ�� ����												 */
/*  ÁE   �� : iReFlag															 */	
/* 			1: CLR ����   0: ENT ����											 */
/*  �� �� �� : 2002��E2��E18�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
#ifdef	SIZE_2480
int		vDevInput2(char *chKey1, char *chKey2, int iSize1, int iSize2)
{														/* Ÿ��,�Էµ�����,��ġ��,�������� ���� */
	int		iReFlag;									/* 0:ENT,	1:CLR		 */
	int		iInfo;
	int		iNowInfo;
	int     iAdd;
	short	iTrue;
	char	chKey1_buff[10];									/* ��ȯ�� Ű ��			 */	
	char	chKey2_buff[10];

	iAdd = chKey1[0];
	iInfo = (Device_iType[iAdd]) & 0x000F;

	iNowInfo= 0;	/* 061029 */
/*	
	iSize2 = 4;
*/
/*ksc20040520*/
	iSize2 = 8;		//070822
/*ksc20040520*/
  switch(iInfo)
	{
		case 0:
			iSize2 = 3;
			break;
		case 1:
		case 3:
		case 4:
		case 9:
			iNowInfo = 1;
			break;
		case 2:
		case 5:
		case 6:
		case 7:
		case 8:
			iNowInfo = 2;
			break;

	}
	memset(chKey1_buff,0x00,10);
	memset(chKey2_buff,0x00,10);
	strcpy(chKey1_buff,chKey1);
	strcpy(chKey2_buff,chKey2);
	iReFlag = -1;
	while ( iReFlag == -1 ) {
		if(iNowInfo == 2)	/* 16 */
		{
			vDevInput2Disp(chKey1_buff, chKey2_buff, iSize1);					/*  ó��ȭ��E���		 */
			iReFlag = iDevInput2Select(chKey2_buff, iSize2, iNowInfo);		/*  ���� ó��			 */
		}else if(iNowInfo == 1)	/* 10 */
		{
			vDevInput10Disp(chKey1_buff, chKey2_buff);
			iReFlag = iDevInput10Select(chKey2_buff, iSize2, iNowInfo);		/*  ���� ó��			 */
		}else
		{
			vDevInput8Disp(chKey1_buff, chKey2_buff);
			iReFlag = iDevInput8Select(chKey2_buff, iSize2, iNowInfo);		/*  ���� ó��			 */
		}
		
		if(iReFlag == DOWN_TRANS || iReFlag == UP_TRANS)
		{
			break;
		}
		if(strlen(chKey2_buff))
			strcpy(chKey2,chKey2_buff);
		if(iReFlag == 0	&& iSize1 == 0 )
		{
			iTrue = 0;
			if(!(iInfo == 0 || iInfo == 4 || iInfo == 8 || iInfo == 9))
				iTrue = shDevInfoTypeChk(chKey2_buff,iInfo);
			if(iTrue != -1)
				iTrue = vErrorBox(chKey1_buff,chKey2_buff,1);/*  1�� �����޼����ڽ��� ǥ���ϱ�����  */
			if(iTrue == -1)
				iReFlag = -1;
		}
	} /*  end while  */

	return iReFlag;
}

/* ****************************************************************************** */
/*  ��E��E��E: vDevInput2Disp()													 */
/*  ��E   �� : ����̽� �Է� ������E ȭ��E���									 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E2��E18�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
void	vDevInput2Disp(char* chKey1, char* chKey2, int iSize1)
{	
	char	chDsp_buff[24];	
	int		iNum;
	
								/* �Է�â ǥ�� ������ŭ�� �κл��� */
								/* ���÷��� ���� �ʱ�ȭ	 */
								/* 0 : ����̽��Է��� , 1 : �����Է����� �׸� */
		
	if(iSize1 == 0)				/*  ����̽� ����� �Է� ȭ�鿡�� ��� */
	{
		vNumberInputPan_16(1);	
		iNum = (int)chKey1[0];
		sprintf(chDsp_buff,"%s", Device_Name[iNum]);		/*	sprintf(chDsp_buff,"%c", chKey1[0]); */				
/*
		DotTextOut(104,Line_1,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);
*/
/*ksc20040521 ��Ʈ ����̽� ǥ����ġ */ /* 20080822 NewGP�� ǥ����ġ ��Ȯ�� */
		DotTextOut(GAMEN_START_X+86,GAMEN_START_Y+Line_1,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);
/*ksc20040521*/
		DotTextOut(GAMEN_START_X+162,GAMEN_START_Y+Line_1," ",1,1, TRANS, T_WHITE, T_BLACK);
		AreaRevers(GAMEN_START_X+162,GAMEN_START_Y+Line_1,GAMEN_START_X+169,GAMEN_START_Y+Line_1+15);
	}
	else if(iSize1 == 1)		/* ENTRY CODE ȭ�鿡�� ��� */
	{
		AreaClear(GAMEN_START_X+4,GAMEN_START_Y+21,GAMEN_START_X+238,GAMEN_START_Y+78,0);		
		sprintf(chDsp_buff, chKey1);				
		DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+Line_2,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);
		vNumberInputPan_16(1);
	}

	/* �ԷµȰ� ��� */	
	sprintf(chDsp_buff, chKey2);				
	DotTextOut(GAMEN_START_X+150,GAMEN_START_Y+Line_1,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

	DrawLcdBank1();
	return;
}

/* ****************************************************************************** */
/*  ��E��E��E: iDevInput2Select()												 */
/*  ��    �� : ȭ��E���ý� ó��													 */
/*  ��    �� :				iSize2(�Է¹��� ������ ����)	 */
/*  ��    �� : iEscFlag 0 : ESC ����											 */
/*  �� �� �� : 2002��2��18��													 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
int		iDevInput2Select(char* chKey2, int iSize2, int iInfo)	/* ���� ����Ÿ, ����Ÿ�� ���� */
{

	int iKeyCode;
	int iReFlag;	
	int iLen;
	int iTotal;
	int isu;
	char chDsp_buff[24];
	char chBuffer[10];
	short	iKeyFlag;

	iKeyCode = -1;
	iReFlag = -1;	
	iKeyFlag = 0;
	memset(chDsp_buff,0x00,sizeof(chDsp_buff));
	memset(chBuffer,0x00,sizeof(chBuffer));
	switch(iInfo)
	{
		case 0:
			break;
	}
	while (iReFlag == -1) {
		iKeyCode = KeyWaitData(iKeyFlag,0xffff);							/* �Էµ� Ű���� �о���	 */
		iKeyFlag = 0;
		if ((iKeyCode >= KEY_14 && iKeyCode <= KEY_15 ) ||
			(iKeyCode >= KEY_12 && iKeyCode <= KEY_13 ) ||
			(iKeyCode >= KEY_20 && iKeyCode <= KEY_30 ) ||
			(iKeyCode >= KEY_35 && iKeyCode <= KEY_45 ) ||
			(iKeyCode >= KEY_50 && iKeyCode <= KEY_60 )) 
		{
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
		}		
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			iReFlag = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			iReFlag = UP_TRANS;
			break;
		}		/* Ű ���� ó�� */
		/* Ű ���� ó�� */		
		/* �� �׸񸶴� chKey2�� ���ڸ� ��ĭ�� �̴�ó�� ���� 2��E18�� */
		if (iKeyCode >= KEY_14 && iKeyCode <= KEY_15 ) {			/*  CLR				 */
			iReFlag = 1;
			memset(chKey2, 0x00, iSize2);
		} else if (iKeyCode >= KEY_12 && iKeyCode <= KEY_13 ) {		/*  F				 */
			if(iInfo != 0 && iInfo != 1)					/*  ���̰� 4�϶�10����E*/
				strcat(chKey2, "F");						/*  ���̰� 3�϶�8����E*/
		} else if (iKeyCode >= KEY_20 && iKeyCode <= KEY_21 ) {		/*  A				 */
			if(iInfo != 0 && iInfo != 1)
				strcat(chKey2, "A");		
		} else if (iKeyCode == KEY_22 ) {						/*  B				 */
			if(iInfo != 0 && iInfo != 1)
				strcat(chKey2, "B");			
		} else if (iKeyCode == KEY_24 ) {						/*  C				 */
			if(iInfo != 0 && iInfo != 1)
				strcat(chKey2, "C");
		} else if (iKeyCode >= KEY_25 && iKeyCode <= KEY_26 ) {		/*  D				 */
			if(iInfo != 0 && iInfo != 1)
				strcat(chKey2, "D");
		} else if (iKeyCode >= KEY_27 && iKeyCode <= KEY_28 ) {		/*  E				 */
			if(iInfo != 0 && iInfo != 1)
				strcat(chKey2, "E");
		} else if (iKeyCode >= KEY_29 && iKeyCode <= KEY_30 ) {		/*  ��				 */
			
		
		} else if (iKeyCode >= KEY_35 && iKeyCode <= KEY_36 ) {		/*  5				 */
			strcat(chKey2, "5");		
		} else if (iKeyCode == KEY_37 ) {						/*  6				 */
			strcat(chKey2, "6");
		} else if (iKeyCode == KEY_39 ) {						/*  7				 */
			strcat(chKey2, "7");
		} else if (iKeyCode >= KEY_40 && iKeyCode <= KEY_41 ) {		/*  8				 */
			if(iInfo != 0)									/*  ���̰� 3�϶�8����E*/
				strcat(chKey2, "8");
		} else if (iKeyCode >= KEY_42 && iKeyCode <= KEY_43 ) {		/*  9				 */
			if(iInfo != 0)									/*  ���̰� 3�϶�8����E*/
				strcat(chKey2, "9");
		} else if (iKeyCode >= KEY_44 && iKeyCode <= KEY_45 ) {		/*  �Ʒ�				 */
			
		
		} else if (iKeyCode >= KEY_50 && iKeyCode <= KEY_51 ) {		/*  0				 */
			strcat(chKey2, "0");		
		} else if (iKeyCode == KEY_52 ) {						/*  1				 */
			strcat(chKey2, "1");
		} else if (iKeyCode == KEY_54 ) {						/*  2				 */
			strcat(chKey2, "2");
		} else if (iKeyCode >= KEY_55 && iKeyCode <= KEY_56 ) {		/*  3				 */
			strcat(chKey2, "3");
		} else if (iKeyCode >= KEY_57 && iKeyCode <= KEY_58 ) {		/*  4				 */
			strcat(chKey2, "4");
		} else if (iKeyCode >= KEY_59 && iKeyCode <= KEY_60 ) {		/*  ENT				 */
			if(strlen(chDsp_buff)!=0)
			{
				if(iInfo == 0)
				{
					iTotal=0;
					isu = gatoi(chDsp_buff);
					if((isu/100)!=0)
					{
						iTotal=((isu/100)*64);
					}
					isu = isu%100;
					if((isu/10)!=0)
					{
						iTotal+=((isu/10)*8);
					}
					isu = isu%10;
					iTotal+=isu;
					itoa(iTotal,chDsp_buff,10);
				}

				iReFlag = 0;	
				strcpy(chKey2,chDsp_buff);
				break;
			}else
			{
				ErrorBuzzer();				/*	Buzzer  */
			}
		} /*  end if  */	
		
		
		iLen=strlen(chKey2);
		if(iLen>iSize2)
		{
			strncpy(chDsp_buff,chKey2+1,8);
			strcpy(chKey2,chDsp_buff);
		}
		else
			sprintf(chDsp_buff, chKey2);
		iLen=strlen(chKey2);
		if(iLen == 1)
		{
			DotTextOut(GAMEN_START_X+162,GAMEN_START_Y+Line_1,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
			AreaRevers(GAMEN_START_X+162,GAMEN_START_Y+Line_1,GAMEN_START_X+169,GAMEN_START_Y+Line_1+15);
		} 
		else if(iLen != 0)
		{
			DotTextOut(GAMEN_START_X+170-(8*iLen),GAMEN_START_Y+Line_1,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
			AreaRevers(GAMEN_START_X+162,GAMEN_START_Y+Line_1,GAMEN_START_X+169,GAMEN_START_Y+Line_1+15);
		}
		vBoxInLine(GAMEN_START_X+59,GAMEN_START_Y+0,GAMEN_START_X+179,GAMEN_START_Y+19);				
		DrawLcdBank1();
	} /*  end while  */	

	return iReFlag;
}
extern	int		GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address);
extern	void	Hexa_SignedChangeData(char* ChangeData,long* ReturnData);
extern	char	DeviceToIndexSet(int,char*);


/* ****************************************************************************** */
/*  ��E��E��E: vErrorCheck()													 */
/*  ��E   �� : Device Address Check												 */
/*  ��    �� : chKey1 , chKey2	,iData(�޼��� ǥ�� �� ��Ͻÿ� ��� 1)			 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2003�� 09   (ȭ)													 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */

short vErrorBox(char *chKey1, char *chKey2, int iData)
{
	char	chType[3];
	int		iUpNum;
	int		iValue;
	int		iTrue;
	int		i;
	int		j;
	int		iNum;
	int		iUpDown;

/*	memset(chType,0,sizeof(chType));	*/ /*20080822 */
	iNum		= (int)chKey1[0];
	j = 0;
	i = 0;
	if((Device_iType[iNum] & 0x40) != 0)
	{
		iUpNum = 4;				/* 1:Bit 2,3:Word 4:Bit+Word */
	}
	else if((Device_iType[iNum] & 0x100) != 0)
	{
		if((Device_iType[iNum] & 0x200) != 0)
			iUpNum = 3;				
		else
			iUpNum = 2;				
	}
	else
	{
		iUpNum = 1;				/* 1:Bit 2,3:Word 4:Bit+Word */
	}
	iValue		= gatoi(chKey2);
	strcpy(chType,chKey1);

	iUpDown = 0;

	if(iData == 0)
		iUpDown =_DOWN;
	
	iTrue = vErrorCheck(chKey1, chKey2,iUpDown);
	if(iData == 1 || iTrue == 2)
		iValue	= gatoi(chKey2);							/* Device Address */

 	if(iTrue == -1)										/* �ִ�E��?���� �� �ٽ� �Է� �޴´�. */
	{
		if(iData == 1)						/*  iData==1 �̸�E�޼���E�ڽ��� ��Ÿ����.  */
		{
			iCaptionWindow(Dspname[DEVICE_MONITORING].chName[Set.iLang][4],"");
			sprintf(chKey2,"");

		}
	}
	else
	{	
		if(iUpNum == 4)											/* BuffDip[].iDev_Type */ /* ����� ��Ʈ�� ���� �ִ� T,C ���� �͵�. */				
		{

			DeviceMonitorBuffClear(0,4);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */

			ReturnDeviceName(&(BuffDip[0].cDev_Now), chType, 2);	/* ������ */
			BuffDip[0].iDev_NowNum = iValue;
			BuffDip[0].iDev_NowPoint = 4;
			BuffDip[0].iDev_Type = iUpNum;

			NowDip.cDev_Now = BuffDip[0].cDev_Now;				/* ȭ��E��?���� ������ ���� */
			NowDip.iDev_NowNum = iValue;						/* ����E������ �Ϳ� ��E?������ ������E�ִ´�. */
			NowDip.iDev_NowPoint = 0;							/* ���õǾ�?E��ġ */
			NowDip.iDev_Type = BuffDip[0].iDev_Type;
		}
		else if(iUpNum == 2 || iUpNum == 3)										/* Word�� ��� */
		{
			if(BuffDip[0].iDev_NowPoint == 0)					/* ó������ �ԷµǴ� �濁E*/
			{
				ReturnDeviceName(&(BuffDip[0].cDev_Now), chType, 2);
				BuffDip[0].iDev_NowNum = iValue;
				BuffDip[0].iDev_NowPoint = 2;
	 			BuffDip[0].iDev_Type = iUpNum;

				NowDip.cDev_Now = BuffDip[0].cDev_Now;			/* ȭ��E��?���� ������ ���� */
				NowDip.iDev_NowNum = iValue;					/* ����E������ �Ϳ� ��E?������ ������E�ִ´�. */
				NowDip.iDev_NowPoint = 0;						/* ���õǾ�?E��ġ */
				NowDip.iDev_Type = BuffDip[0].iDev_Type;

				DeviceMonitorBuffClear(1,4);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */

			}
			else if(BuffDip[2].iDev_NowPoint == 0)
			{
				ReturnDeviceName(&(BuffDip[2].cDev_Now), chType, 2);
				BuffDip[2].iDev_NowNum = iValue;
				BuffDip[2].iDev_NowPoint = 2;
				BuffDip[2].iDev_Type = iUpNum;

				NowDip.cDev_Now = BuffDip[2].cDev_Now;	
				NowDip.iDev_NowNum = iValue;					/* ����E������ �Ϳ� ��E?������ ������E�ִ´�. */
				NowDip.iDev_NowPoint = 2;						/* ���õǾ�?E��ġ */
				NowDip.iDev_Type = BuffDip[2].iDev_Type;
			}
			else
			{
				for(i=0;i<2;i++)
				{
					BuffDip[i].cDev_Now = BuffDip[i+2].cDev_Now;
					BuffDip[i].iDev_NowNum = BuffDip[i+2].iDev_NowNum;
					BuffDip[i].iDev_NowPoint = BuffDip[i+2].iDev_NowPoint;
					BuffDip[i].iDev_Type = BuffDip[i+2].iDev_Type;
				}
				ReturnDeviceName(&(BuffDip[2].cDev_Now), chType, 2);
				BuffDip[2].iDev_NowNum = iValue;
				BuffDip[2].iDev_NowPoint = 2;
				BuffDip[2].iDev_Type = iUpNum;

				NowDip.cDev_Now = BuffDip[2].cDev_Now;
				NowDip.iDev_NowNum = iValue;					/* ����E������ �Ϳ� ��E?������ ������E�ִ´�. */
				NowDip.iDev_NowPoint = 2;						/* ���õǾ�?E��ġ */
				NowDip.iDev_Type = BuffDip[2].iDev_Type;

				BuffDip[3].cDev_Now = -1;
				BuffDip[3].iDev_NowNum = 0;
				BuffDip[3].iDev_NowPoint = 0;
				BuffDip[3].iDev_Type = 0;
			}
		}
		else if(iUpNum == 1)									/*  Bit�� ���.  */
		{
			for(i=0;i<4;i++)
			{
				if(BuffDip[i].iDev_NowPoint != 0)		
				{
					if(BuffDip[i].iDev_NowPoint != 1)
						i++;
					else if(BuffDip[2].iDev_NowPoint == 2 || BuffDip[2].iDev_NowPoint == 4)
						i++;
				}
				else
				{
					if(i==1 && BuffDip[2].iDev_NowPoint == 1)
						continue;
					BuffDip[i].iDev_NowPoint = 1;
					BuffDip[i].iDev_NowNum = iValue;
					ReturnDeviceName(&(BuffDip[i].cDev_Now), chType, 2);
					BuffDip[i].iDev_Type = iUpNum;

					NowDip.cDev_Now = BuffDip[i].cDev_Now;		/* ȭ��E��?���� ������ ���� */
					NowDip.iDev_NowNum = iValue;				/* ����E������ �Ϳ� ��E?������ ������E�ִ´�. */
					NowDip.iDev_NowPoint = i;					/* ���õǾ�?E��ġ */
					NowDip.iDev_Type = BuffDip[i].iDev_Type;
					break;
				}
				if(i==3)
				{
					for(j=0;j<2;j++)
					{
						BuffDip[j].cDev_Now = BuffDip[j+2].cDev_Now;
						BuffDip[j].iDev_NowNum = BuffDip[j+2].iDev_NowNum;
						BuffDip[j].iDev_NowPoint = BuffDip[j+2].iDev_NowPoint;
						BuffDip[j].iDev_Type = BuffDip[j+2].iDev_Type;
					}
					ReturnDeviceName(&(BuffDip[2].cDev_Now), chType, 2);
					BuffDip[2].iDev_NowNum = iValue;
					BuffDip[2].iDev_NowPoint = 1;
					BuffDip[2].iDev_Type = iUpNum;

					NowDip.cDev_Now = BuffDip[2].cDev_Now;		/* ȭ��E��?���� ������ ���� */
					NowDip.iDev_NowNum = iValue;				/* ����E������ �Ϳ� ��E?������ ������E�ִ´�. */
					NowDip.iDev_NowPoint = 2;					/* ���õǾ�?E��ġ */
					NowDip.iDev_Type = BuffDip[2].iDev_Type;
					
					BuffDip[3].cDev_Now = -1;
					BuffDip[3].iDev_NowNum = 0;
					BuffDip[3].iDev_NowPoint = 0;
					BuffDip[3].iDev_Type = 0;
				}
			}
		}
	}
/*	DrawLcdBank1();*/
	return iTrue;
}
/* ****************************************************************************** */
/*  ��E��E��E: vDevInput8Disp()													 */
/*  ��E   �� : ����̽� �Է� ������E ȭ��E���									 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E2��E18�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
void	vDevInput8Disp(char* chKey1, char* chKey2)
{	
	char	chDsp_buff[24];	
	int		iNum;
	short	iLine;

	vNumberInputPan8();	
	iLine = Line_1+1;
	iNum = (int)chKey1[0];
	sprintf(chDsp_buff,"%s", Device_Name[iNum]);		/*	sprintf(chDsp_buff,"%c", chKey1[0]); */				
	DotTextOut(GAMEN_START_X+124,GAMEN_START_Y+iLine,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+182,GAMEN_START_Y+iLine," ",1,1, TRANS, T_WHITE, T_BLACK);
	AreaRevers(GAMEN_START_X+182,GAMEN_START_Y+iLine,GAMEN_START_X+189,GAMEN_START_Y+iLine+15);

	/* �ԷµȰ� ��� */	
	sprintf(chDsp_buff, chKey2);				
	DotTextOut(GAMEN_START_X+170,GAMEN_START_Y+iLine,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

	DrawLcdBank1();
	return;
}
/* ****************************************************************************** */
/*  ��E��E��E: iDevInput8Select()												 */
/*  ��    �� : ȭ��E���ý� ó��													 */
/*  ��    �� :				iSize2(�Է¹��� ������ ����)	 */
/*  ��    �� : iEscFlag 0 : ESC ����											 */
/*  �� �� �� : 2002��2��18��													 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
int		iDevInput8Select(char* chKey2, int iSize2, int iInfo)	/* ���� ����Ÿ, ����Ÿ�� ���� */
{

	int		iKeyCode;
	int		iReFlag;	
	int		iLen;
	char	chDsp_buff[24];
	char	chBuffer[10];
	short	iKeyFlag;
	short	iLine;
	
	iLine		= Line_1 + 1;
	iKeyCode	= -1;
	iReFlag		= -1;	
	iKeyFlag	= 0;
	memset(chDsp_buff,0x00,sizeof(chDsp_buff));
	memset(chBuffer,0x00,sizeof(chBuffer));
	while (iReFlag == -1) {
		iKeyCode = KeyWaitData(iKeyFlag,0xffff);							/* �Էµ� Ű���� �о���	 */
		iKeyFlag = 0;
		if ((iKeyCode >= KEY_14 && iKeyCode <= KEY_15 ) ||
			(iKeyCode >= KEY_21 && iKeyCode <= KEY_30 ) ||
			(iKeyCode >= KEY_36 && iKeyCode <= KEY_45 ) ||
			(iKeyCode >= KEY_51 && iKeyCode <= KEY_60 )) 
		{
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
		}		
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			iReFlag = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			iReFlag = UP_TRANS;
			break;
		}		/* Ű ���� ó�� */
		/* Ű ���� ó�� */		
		/* �� �׸񸶴� chKey2�� ���ڸ� ��ĭ�� �̴�ó�� ���� 2��E18�� */
		if (iKeyCode == KEY_14 || iKeyCode == KEY_15 ) {			/*  CLR				 */
			iReFlag = 1;
			memset(chKey2, 0x00, iSize2);
		} else if (iKeyCode == KEY_23 || iKeyCode == KEY_24 ) {	
				strcat(chKey2, "0");		
		} else if (iKeyCode == KEY_25 || iKeyCode == KEY_26 ) {						/*  B				 */
				strcat(chKey2, "1");			
		} else if (iKeyCode == KEY_27 || iKeyCode == KEY_28 ) {						/*  C				 */
				strcat(chKey2, "2");
		} else if (iKeyCode == KEY_29 || iKeyCode == KEY_30 ) {		/*  ��				 */
	
		
		} else if (iKeyCode == KEY_38 || iKeyCode == KEY_39 ) {						/*  7				 */
				strcat(chKey2, "3");
		} else if (iKeyCode == KEY_40 || iKeyCode == KEY_41 ) {						/*  7				 */
				strcat(chKey2, "4");
		} else if (iKeyCode == KEY_42 || iKeyCode == KEY_43 ) {						/*  7				 */
				strcat(chKey2, "5");
		} else if (iKeyCode == KEY_44 || iKeyCode == KEY_45 ) {		/*  �Ʒ�				 */
			
		
		} else if (iKeyCode == KEY_53 || iKeyCode == KEY_54 ) {						/*  6				 */
				strcat(chKey2, "6");
		} else if (iKeyCode == KEY_55 || iKeyCode == KEY_56 ) {						/*  6				 */
				strcat(chKey2, "7");
		} else if (iKeyCode == KEY_57 || iKeyCode == KEY_58 ) {						/*  6				 */
			iLen = strlen(chDsp_buff);
			if(iLen != 0)
			{
				chKey2[iLen-1] = 0x00;
				DotTextOut(GAMEN_START_X+158,GAMEN_START_Y+iLine,"    ",1,1, TRANS, T_WHITE, T_BLACK);
			}
		} else if (iKeyCode == KEY_59 || iKeyCode == KEY_60 ) {		/*  ENT				 */
			if(strlen(chDsp_buff)!=0)
			{
				iReFlag = 0;	
				strcpy(chKey2,chDsp_buff);
				break;
			}else
			{
				ErrorBuzzer();				/*	Buzzer  */
			}
		} 
		
		iLen=strlen(chKey2);
		if(iLen>iSize2)
		{
			strncpy(chDsp_buff,chKey2+1,8);
			strcpy(chKey2,chDsp_buff);
		}
		else
			sprintf(chDsp_buff, chKey2);
		iLen=strlen(chKey2);
		if(iLen == 1)
		{
			DotTextOut(GAMEN_START_X+182,GAMEN_START_Y+iLine,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
			AreaRevers(GAMEN_START_X+182,GAMEN_START_Y+iLine,GAMEN_START_X+189,GAMEN_START_Y+iLine+15);
		} 
		else if(iLen != 0)
		{
			DotTextOut(GAMEN_START_X+190-(8*iLen),GAMEN_START_Y+iLine,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
			AreaRevers(GAMEN_START_X+182,GAMEN_START_Y+iLine,GAMEN_START_X+189,GAMEN_START_Y+iLine+15);
		}
		DrawLcdBank1();
	} /*  end while  */	

	return iReFlag;
}

/**********************************************************************************/
/* ****************************************************************************** */
/*  ��E��E��E: vDevInput10Disp()													 */
/*  ��E   �� : ����̽� �Է� ������E ȭ��E���									 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E2��E18�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
void	vDevInput10Disp(char* chKey1, char* chKey2)
{	
	char	chDsp_buff[24];	
	int		iNum;
	short	iLine;

	vNumberInputPan(2);	
	iLine = Line_1+1;
	iNum = (int)chKey1[0];
	sprintf(chDsp_buff,"%s", Device_Name[iNum]);		/*	sprintf(chDsp_buff,"%c", chKey1[0]); */				

/*
	DotTextOut(124,iLine,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(182,iLine," ",1,1, TRANS, T_WHITE, T_BLACK);
*/	
/*ksc20040521 ���� ����̽��� ǥ�� ��ġ */
	DotTextOut(GAMEN_START_X+84,GAMEN_START_Y+iLine,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+182,GAMEN_START_Y+iLine," ",1,1, TRANS, T_WHITE, T_BLACK);
/*ksc20040521*/

	AreaRevers(GAMEN_START_X+182,GAMEN_START_Y+iLine,GAMEN_START_X+189,GAMEN_START_Y+iLine+15);

	/* �ԷµȰ� ��� */	
	sprintf(chDsp_buff, chKey2);				
	DotTextOut(GAMEN_START_X+170,GAMEN_START_Y+iLine,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);
	DrawLcdBank1();
	return;
}
#endif
/* *******************************************************************************/
/*  ��E��E��E: shDevInfoTypeChk()												 */
/*  ��    �� : ������ ���� ���� üũ											 */
/*  ��    �� : iInfo(���� Ÿ��), cData(String)									 */
/*  ��    �� : 											 */
/*  �� �� �� : 2004��6��8��													 */
/*  �� �� �� : �� �� ��														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
short shDevInfoTypeChk(char* cData, int iInfo)
{
	short	shReturn;
	int		iLen;
	int		i;
	char	cAddressData[10];

	shReturn = 1;

	iLen = strlen(cData);

	if(iLen < 1)
		return -1;

	memset(cAddressData,0x00,sizeof(cAddressData));
	memcpy(cAddressData,cData,iLen);
	switch(iInfo)
	{
		case 1:					/*  8/10  */
		case 2:					/*  8/16  */
			for(i = 0 ; i<iLen-1 ; i++)
			{
				if(cData[i] < 0x30 || cData[i] > 0x37)	/*  8 */
				{
					shReturn = -1;
					break;
				}
			}
			break;
		case 5:					/*  10/16  */
			for(i = 0 ; i<iLen-1 ; i++)
			{
				if(cData[i] < 0x30 || cData[i] > 0x39)	/* 10 */
				{
					shReturn = -1;
					break;
				}
			}
			break;
		case 3:					/*  10/8  */
		case 6:					/*  16/8  */
			if(cData[iLen-1] < 0x30 || cData[iLen-1] > 0x37)	/* 10 */
				shReturn = -1;
			break;
		case 7:					/*  16/10  */	
			if(cData[iLen-1] < 0x30 || cData[iLen-1] > 0x37)	/* 10 */
				shReturn = -1;
			break;
	}
	if(shReturn == -1)
	{
#ifdef	SIZE_2480
		iCaptionWindow(Dspname[DEVICE_MONITORING].chName[Set.iLang][4],"");
#endif
#ifdef	SIZE_3224
		iCaptionWindow(Dspname[DEVICE_MONITORING].chName[Set.iLang][7],"");
#endif
		sprintf(cData,"");
	}

	return shReturn;
}
/* ****************************************************************************** */
/*  ��E��E��E: iDevInput10Select()												 */
/*  ��    �� : ȭ��E���ý� ó��													 */
/*  ��    �� :				iSize2(�Է¹��� ������ ����)	 */
/*  ��    �� : iEscFlag 0 : ESC ����											 */
/*  �� �� �� : 2002��2��18��													 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
int		iDevInput10Select(char* chKey2, int iSize2, int iInfo)	/* ���� ����Ÿ, ����Ÿ�� ���� */
{

	int		iKeyCode;
	int		iReFlag;	
	int		iLen;
	char	chDsp_buff[24];
	char	chBuffer[10];
	short	iKeyFlag;
	short	iLine;
	
	iLine		= Line_1 + 1;
	iKeyCode	= -1;
	iReFlag		= -1;	
	iKeyFlag	= 0;
	memset(chDsp_buff,0x00,sizeof(chDsp_buff));
	memset(chBuffer,0x00,sizeof(chBuffer));
	while (iReFlag == -1) {
		iKeyCode = KeyWaitData(iKeyFlag,0xffff);							/* �Էµ� Ű���� �о���	 */
		iKeyFlag = 0;
		if ((iKeyCode >= KEY_14 && iKeyCode <= KEY_15 ) ||
			(iKeyCode >= KEY_21 && iKeyCode <= KEY_30 ) ||
			(iKeyCode >= KEY_36 && iKeyCode <= KEY_45 ) ||
			(iKeyCode >= KEY_51 && iKeyCode <= KEY_60 )) 
		{
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
		}		
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			iReFlag = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			iReFlag = UP_TRANS;
			break;
		}		/* Ű ���� ó�� */
		/* Ű ���� ó�� */		
		/* �� �׸񸶴� chKey2�� ���ڸ� ��ĭ�� �̴�ó�� ���� 2��E18�� */
		if (iKeyCode == KEY_14 || iKeyCode == KEY_15 ) {			/*  CLR				 */
			iReFlag = 1;
			memset(chKey2, 0x00, iSize2);
		} else if (iKeyCode == KEY_21 || iKeyCode == KEY_22 ) {		/*  0				 */
				strcat(chKey2, "0");						
		} else if (iKeyCode == KEY_23 || iKeyCode == KEY_24 ) {		/*  1				 */
				strcat(chKey2, "1");		
		} else if (iKeyCode == KEY_25 || iKeyCode == KEY_26 ) {		/*  2				 */
				strcat(chKey2, "2");			
		} else if (iKeyCode == KEY_27 || iKeyCode == KEY_28 ) {		/*  3				 */
				strcat(chKey2, "3");
		} else if (iKeyCode == KEY_29 || iKeyCode == KEY_30 ) {		/*  ��				 */
			
		
		} else if (iKeyCode == KEY_36 || iKeyCode == KEY_37 ) {		/*  4				 */
				strcat(chKey2, "4");
		} else if (iKeyCode == KEY_38 || iKeyCode == KEY_39 ) {		/*  5				 */
				strcat(chKey2, "5");
		} else if (iKeyCode == KEY_40 || iKeyCode == KEY_41 ) {		/*  6				 */
				strcat(chKey2, "6");
		} else if (iKeyCode == KEY_42 || iKeyCode == KEY_43 ) {		/*  7				 */
				strcat(chKey2, "7");
		} else if (iKeyCode == KEY_44 || iKeyCode == KEY_45 ) {		/*  �Ʒ�				 */
			
		
		} else if (iKeyCode == KEY_51 || iKeyCode == KEY_52 ) {		/*  8				 */
				strcat(chKey2, "8");		
		} else if (iKeyCode == KEY_53 || iKeyCode == KEY_54 ) {		/*  9				 */
				strcat(chKey2, "9");
		} else if (iKeyCode == KEY_55 || iKeyCode == KEY_56 ) {		/*  6				 */

		} else if (iKeyCode == KEY_57 || iKeyCode == KEY_58 ) {		/*  BS				 */
			iLen = strlen(chDsp_buff);
			if(iLen != 0)
			{
				chKey2[iLen-1] = 0x00;
				if(iInfo != 100)
/*
					DotTextOut(158,iLine,"    ",1,1, TRANS, T_WHITE, T_BLACK);
*/
/*ksc20040520*/
					DotTextOut(126,iLine,"        ",1,1, TRANS, T_WHITE, T_BLACK);
/*ksc20040520*/
				else
					DotTextOut(126,iLine,"        ",1,1, TRANS, T_WHITE, T_BLACK);
			}
		} else if (iKeyCode == KEY_59 || iKeyCode == KEY_60 ) {		/*  ENT				 */
			if(strlen(chDsp_buff)!=0)
			{
				iReFlag = 0;	
				if(iInfo != 100)
					strcpy(chKey2,chDsp_buff);
				break;
			}else
			{
				ErrorBuzzer();				/*	Buzzer  */
			}
		} 
		
		iLen=strlen(chKey2);
		if(iLen>iSize2)
		{
			strncpy(chDsp_buff,chKey2+1,8);
			strcpy(chKey2,chDsp_buff);
		}
		else
			sprintf(chDsp_buff, chKey2);
		iLen=strlen(chKey2);
		if(iInfo == 100)
		{
			memcpy(chDsp_buff,"********",iLen);
		}

		if(iLen == 1)
		{
			if(iInfo == 100){
				DotTextOut(GAMEN_START_X+182-8*13,GAMEN_START_Y+iLine,"             ",1,1, TRANS, T_WHITE, T_BLACK);
			}
			DotTextOut(GAMEN_START_X+182,GAMEN_START_Y+iLine,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
			AreaRevers(GAMEN_START_X+182,GAMEN_START_Y+iLine,GAMEN_START_X+189,GAMEN_START_Y+iLine+15);		/* Cursor Revers */
		} 
		else if(iLen != 0)
		{
			DotTextOut(GAMEN_START_X+190-(8*iLen),GAMEN_START_Y+iLine,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
			AreaRevers(GAMEN_START_X+182,GAMEN_START_Y+iLine,GAMEN_START_X+189,GAMEN_START_Y+iLine+15);
		}
		DrawLcdBank1();
	} /*  end while  */	

	return iReFlag;
}
/* ****************************************************************************** */
/*  ��E��E��E: vErrorCheck()														 */
/*  ��E   �� : Device Address Check													 */
/*  ��    �� : chKey1 , chKey2	,iData												 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2003�� 09   (ȭ)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
int vErrorCheck(char *chKey1, char *chKey2, int	iUpDown) /*  */
{
	char	chType[3];
	char	chData[10];
	int		iUpNum;
	int		iNum;
	int		iTrue;
//	int		i;
	int		iVal;
	int		iInfo;
	int		iAddress1;
	int		iAddress2;
	int		iAddress3;
	long	Data;
	unsigned char	src[3];
	char	DevName[4];
extern	int	SetPLCUsrAddr(int DevInfo,int Address,unsigned char idx,int bFlag);
extern	int	CheckDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int Address);

	memset(src,0x00,3);
	memset(DevName,0x00,4);
	strcpy(chType,chKey1);
	strcpy(chData,chKey2);
	iNum		= (int)chKey1[0];

	if((Device_iType[iNum] & 0x40) != 0)
		iUpNum = 1;				/* Bit+Word */
	else if((Device_iType[iNum] & 0x100) != 0)
	/*	if((Device_iType[iNum] & 0x200) != 0)
			iUpNum = 3;				
		else
			iUpNum = 2;			*/	
		iUpNum = 1;/* Word */
	else
		iUpNum = 0;				/* Bit */

	if(iUpDown != 0){
		iVal = SetPLCUsrAddr(Device_iType[iNum],gatoi(chKey2),(unsigned char)DeviceToIndexSet(iUpNum,Device_Name[iNum]),iUpNum);
		iAddress3= gatoi(chKey2)+ 1;	/* Next Addr */
		iAddress3 = SetPLCUsrAddr(Device_iType[iNum],iAddress3,(unsigned char)DeviceToIndexSet(iUpNum,Device_Name[iNum]),iUpNum);
	}else{
		Hexa_SignedChangeData(chKey2,&Data);	/*Hex �Է��� Dec�� ��ȯ */
		iVal = Data;
		iAddress3= iVal+1;			/* Next Addr */
		//070828
		iAddress3 = SetPLCUsrAddr(Device_iType[iNum],iAddress3,(unsigned char)DeviceToIndexSet(iUpNum,Device_Name[iNum]),iUpNum);
	}
	iAddress1 = iVal;

//	i			= 0;


	memcpy(DevName,Device_Name[iNum],4);
	src[0] = DeviceToIndexSet(iUpNum,DevName);
	/* Device Address��?�F�b�N���� */
	if(CheckDevNamePLCAddr(iUpNum,src,chData,&iInfo,iVal) == 0){
		GetDevNamePLCAddr(iUpNum,src,chData,&iInfo,&iVal);
		iTrue = CheckPlcDevice(iUpNum,chData,&iAddress1,&iAddress2);
		/* 32Bit(2Word) */
		if((iTrue == 0) && (Device_iType[iNum] & 0x200)){
			iAddress1 = iAddress3;
			if(CheckDevNamePLCAddr(iUpNum,src,chData,&iInfo,iAddress3) == 0){
				GetDevNamePLCAddr(iUpNum,src,chData,&iInfo,&iAddress3);
				iTrue = CheckPlcDevice(iUpNum,chData,&iAddress1,&iAddress2);
			}else{
				iTrue= -1;
			}
		}
		if((iInfo & 0x0000f) == 0x0009 && iTrue != -1)
		{
			if((iVal%16) != 0)
				iTrue = -1;
		}
		//070827 999999->99999999
		else if(iTrue == -1 && (iAddress1 != -1 || iAddress2 != 99999999) && iUpDown != 0)
		{
			if(iUpDown == _UP && iAddress1 != -1)
			{
				iVal = iAddress1;
				GetDevNamePLCAddr(iUpNum,src,chData,&iInfo,&iVal);
				iTrue = 2;
			}
			//070827 999999->99999999
			else if(iUpDown == _DOWN && iAddress2 != 99999999)
			{
				iVal = iAddress2;
				GetDevNamePLCAddr(iUpNum,src,chData,&iInfo,&iVal);
				iTrue = 2;
			}
		}
	}else{
		iTrue = -1;
	}
	itoa(iVal,chKey2,10);
/********************************************/
	return iTrue;
}

