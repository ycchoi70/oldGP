/* ****************************************************************************** */
/*  �� �� �� : GP_LANGSET.CPP													 */
/*  ��    �� : �ý��� ��� ����													 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

/* ****************************************************************************** */
/*  �� �� �� : vLangSet()														 */
/*  ��    �� : ��� ���� ó��													 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#ifdef	SIZE_2480
void		vLangSet(int*	iScreenNo)
{

	char				*chDsp_buff;	
	char				*chFont;
	char				*chLang;
	int					iKeyCode;
	short				NowData;
	short				iKeyFlag;
	short				OldLang;
	_RECTANGLE_INFO		RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;	

	iKeyFlag = 1;
	NowData = -1;
	chDsp_buff = TakeMemory(32);
	chFont = TakeMemory(10);
	chLang = TakeMemory(12);
	memset(chLang,0x00,12);
	memset(chFont,0x00,10);
	memset(chDsp_buff,0x00,32);
	OldLang = Set.iLang;
	while ( *iScreenNo == LANGUAGE_NUM ) {
		if(Set.iLang != NowData)
		{
			AreaClear(0,0,GAMEN_X_SIZE-1,GAMEN_Y_SIZE-1,0);

			sprintf(chLang,Dspname[LANGUAGE].chName[Set.iLang][0]);

			Last_SP_Del(chLang);

			sprintf(chDsp_buff,"%s :",chLang);
			DotTextOut(GAMEN_START_X+0,GAMEN_START_Y+24,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);

/*ksc20040727*/ /* �ٿ�δ��� ��Ʈ�� ������� ����Ʈ ��Ʈ ���� */
			if(*Set.FontName == 0)
			{
				sprintf(chFont,Dspname[LANGUAGE].chName[Set.iLang][5]);
				Last_SP_Del(chFont);
			}
			else
			{
				sprintf(chFont,Set.FontName);
				Last_SP_Del(chFont);
			}
/*ksc20040727*/

			sprintf(chLang,Dspname[LANGUAGE].chName[Set.iLang][3]);
			Last_SP_Del(chLang);

			sprintf(chDsp_buff,"%s(%s)",chLang,chFont);
			DotTextOut(GAMEN_START_X+56,GAMEN_START_Y+24,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);

/*ksc20040727*/ /* �ٿ�δ��� ��Ʈ�� ������� ����Ʈ ��Ʈ ���� */
			if(*Set.FontName == 0)
			{
				sprintf(chFont,Dspname[LANGUAGE].chName[Set.iLang][6]);
				Last_SP_Del(chFont);
			}
			else
			{
				sprintf(chFont,Set.eFontName);
				Last_SP_Del(chFont);
			}
/*ksc20040727*/

			sprintf(chLang,Dspname[LANGUAGE].chName[Set.iLang][1]);
			Last_SP_Del(chLang);

			sprintf(chDsp_buff,"%s(%s)",chLang,chFont);
			DotTextOut(GAMEN_START_X+56,GAMEN_START_Y+43,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
			DotTextOut(GAMEN_START_X+0,GAMEN_START_Y+62,Dspname[LANGUAGE].chName[Set.iLang][2],1,1, TRANS, T_WHITE, T_BLACK);
			DefaultFormDisplay(LINE_FORM, Dspname[LANGUAGE].chTitle[Set.iLang]);
/*			
			CenterDisplay(120,61,238,78,Dspname[LANGUAGE].chName[Set.iLang][4-Set.iLang]);
*/
			if(Set.iLang == 0)
				Set.iLang = 1;
			else
				Set.iLang = 0;
/*ksc20040518*/					
			
//			CenterDisplay(GAMEN_START_X+120,GAMEN_START_Y+61,GAMEN_START_X+238,GAMEN_START_Y+78,Dspname[LANGUAGE].chName[Set.iLang][4-Set.iLang]);
/*ksc20070202*/								
/*			CenterDisplay(120,61,238,78,Dspname[LANGUAGE].chName[Set.iLang][4-Set.iLang]); */
			CenterDisplay(GAMEN_START_X+120,GAMEN_START_Y+61,GAMEN_START_X+238,GAMEN_START_Y+78,Dspname[LANGUAGE].chName[0][4-Set.iLang]);

			if(Set.iLang == 0)
				Set.iLang = 1;
			else
				Set.iLang = 0;			
/*ksc20040518*/
			
			/*	DotTextOut(130,62,Dspname[LANGUAGE].chName[Set.iLang][4-Set.iLang],1,1, TRANS, T_WHITE, T_BLACK);*/
			RectAngleOut(GAMEN_START_X+120,GAMEN_START_Y+60,GAMEN_START_X+238,GAMEN_START_Y+78,&RECParam);
			DrawLcdBank1();
			NowData = Set.iLang;
		}

		iKeyCode = KeyWaitData(iKeyFlag,LANGUAGE_NUM);							/* �Էµ� Ű���� �о��	 */
		iKeyFlag = 0;

		if(iKeyCode == 0x00)
		{
			continue;
		}
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}
		/* Ű ���� ó�� */	
		if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) {						/*  END					 */
			*iScreenNo = USER_SCREEN_NUM;
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
			break;
		}else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) {					/*  END					 */
			*iScreenNo = SET_ENVIRONMENT_NUM;
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
			break;
		} else if (iKeyCode >= KEY_54 && iKeyCode <= KEY_60 ) {	
			NormalBuzzer();				/*	Buzzer  */

			if(Set.iLang == 0)
				Set.iLang = 1;
			else
				Set.iLang = 0;

			iKeyFlag = 1;
			/*	mWriteSettei(); */
		}else
			iKeyCode = -1;
	} /*  end while  */
	if(OldLang != Set.iLang)
	{
		mWriteSettei();
	}
	FreeMail(chDsp_buff);
	FreeMail(chFont);
	FreeMail(chLang);
	return;
}
void Last_SP_Del(char* cBuffer)
{
	int iLen;

	iLen = strlen(cBuffer)-1;
	if(cBuffer[iLen]==0x20)
		cBuffer[iLen] = 0x00;
}
#endif
