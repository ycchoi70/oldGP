/* ****************************************************************************** */
/*  �� �� �� : GP_BUZZER.CPP														 */
/*  ��    �� : ������ ����														 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

/* ****************************************************************************** */
/*  �� �� �� : vBuzzerSet()														 */
/*  ��    �� : ������ ���� ó��													 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#ifdef	SIZE_2480
void		vBuzzerSet(int *iScreenNo)
{	
	int		iKeyCode;	
	short	iKeyFlag;
	_RECTANGLE_INFO RECParam;

	iKeyCode = -1;

	DefaultFormDisplay(LINE_FORM,Dspname[BUZZER].chTitle[Set.iLang]);


	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	iKeyFlag = 1;
	/* "BUZZER ON" */
	DotTextOut(GAMEN_START_X+17,GAMEN_START_Y+NLine_3,(Dspname[BUZZER].chName[Set.iLang][0]),1,1, NON_TRANS, T_WHITE, T_BLACK);

	/* "BUZZER OFF" */
	DotTextOut(GAMEN_START_X+134,GAMEN_START_Y+NLine_3,(Dspname[BUZZER].chName[Set.iLang][1]),1,1, NON_TRANS, T_WHITE, T_BLACK);

	RectAngleOut(GAMEN_START_X+11,GAMEN_START_Y+42,GAMEN_START_X+112,GAMEN_START_Y+59,&RECParam);					/* ������ NO					 */	
	RectAngleOut(GAMEN_START_X+127,GAMEN_START_Y+42,GAMEN_START_X+228,GAMEN_START_Y+59,&RECParam);					/* ������ OFF				 */	

	if ( Set.iBuzzer == 1 ) {
		AreaRevers(GAMEN_START_X+12,GAMEN_START_Y+43,GAMEN_START_X+111,GAMEN_START_Y+58); 
	} else {
		AreaRevers(GAMEN_START_X+128,GAMEN_START_Y+43,GAMEN_START_X+227,GAMEN_START_Y+58);
	}
	DrawLcdBank1();
	while (*iScreenNo == BUZZER_NUM) 
	{
		iKeyCode = KeyWaitData(iKeyFlag,BUZZER_NUM);							/* �Էµ� Ű���� �о��	 */
		iKeyFlag = 0;
		if ((iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) ||
			(iKeyCode >= KEY_32 && iKeyCode <= KEY_37 ) ||
			(iKeyCode >= KEY_39 && iKeyCode <= KEY_44 )) 
		{	
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
		}

		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}

		/* Ű ���� ó�� */		
		if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) 
		{
			*iScreenNo = USER_SCREEN_NUM;
		}else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 )
		{		
			*iScreenNo = SET_ENVIRONMENT_NUM; 	/*  END				 */
		} else if (iKeyCode >= KEY_32 && iKeyCode <= KEY_37 ) {	
			if(Set.iBuzzer == 0)
			{
				Set.iBuzzer = 1;
				AreaRevers(GAMEN_START_X+12,GAMEN_START_Y+43,GAMEN_START_X+111,GAMEN_START_Y+58);
				AreaRevers(GAMEN_START_X+128,GAMEN_START_Y+43,GAMEN_START_X+227,GAMEN_START_Y+58);		
			}else{
				iKeyCode = -1;
			}
		} else if (iKeyCode >= KEY_39 && iKeyCode <= KEY_44 ) {	
			if(Set.iBuzzer == 1)
			{
				Set.iBuzzer = 0;
				AreaRevers(GAMEN_START_X+12,GAMEN_START_Y+43,GAMEN_START_X+111,GAMEN_START_Y+58);
				AreaRevers(GAMEN_START_X+128,GAMEN_START_Y+43,GAMEN_START_X+227,GAMEN_START_Y+58);		
			}else{
				iKeyCode = -1;
			}
		}else
			iKeyCode = -1;
		
		if(iKeyCode > 0)
			DrawLcdBank1();

	} 	
	if(iKeyCode > 0)
		mWriteSettei();
	return;
}
#endif
