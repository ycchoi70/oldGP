/********************************************************************************/
/* �� �� �� : Gp_Reg.cpp														*/
/* ��    �� : Classfication_Task												*/
/* �� �� �� : 2002�� 5�� 21�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"

#define	MAX_ERASE_CNT	10

char	*FigureOnOFF[8];	/* Figure?Displayinfo 050618 */
int		BaseIdx;
void	PlcState1Loop(void);
int     WindowDispFreeMbx;         /* Window Display�p */

/********************************************************************************/
/*		iScreenNum	= mp->mpar;*/
/*		iOrderNum	= mp->mext;*/
/*		dflag		= mp->mpec;*/
/*		DrawBankFlag= mp->mcod;*/
/********************************************************************************/
void	WindowDisplay_Task_Send(int mode, int p1, int p2, int p3, int p4)
{
	T_MAIL	*mp;

/*	mp= (T_MAIL *)TakeMail();*/
    mp = (T_MAIL *)ReceiveMail( WindowDispFreeMbx );
	mp->mcmd= mode;
	mp->mpar= p1;
	mp->mext= p2;
	mp->mpec= p3;
	mp->mcod= p4;
	SendMail(T_DISP_TASK,(char *)mp);
}
void	WindowFristDisplay_Task_Send(int p1, int p2, int p3, int p4)
{
	T_MAIL	*mp;
	int		mbx;
	int		OldResp;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );

	mp->mcmd= WIN_BASE_DATA;
	mp->mpar= p1;
	mp->mext= p2;
	mp->mpec= p3;
	mp->mcod= p4;

	SendMail(T_DISP_TASK,(char *)mp);

	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	FreeMail((char *)mp);
	FreeMbx(mbx);
}
/* 060109 */
int	GetScreenIdx(int no)
{
	int		i;

	for(i=0;i<iBaseScreenCnt;i++)
	{
		if(Screen[i].iNum == no){
			break;
		}
	}
	return(i);
}
/********************************************************************************/
/* �� �� �� : Classfication_Task												*/
/* ��    �� : ������ �±� ������ ���� ��, ������ �½�ũ�� ���� ���ù� �׿� ���� */
/*			  ����Լ��� ȣ���Ͽ� ȭ���� �����Ѵ�.								*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 27�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : OnSignal()�� �⵿�ϱ� ���� ������̺��� ������					*/
/*			  üũ�ϰ� PLC�� �����Ѵ�											*/
/********************************************************************************/

void	Classification_Task( STTFrm* pSTT )
{	
	T_MAIL		*mp;
	int			k;
	int			iWinNum;		
//	int			iClockFlag;
	int			iVal;
	int			iLoopCnt;
	int			LoopCnt;
	int			SavePoint;
	int			iScreenUpdateFlag ;	
/*	_TRENDGRAPH_EVENT_TBL*	 TrendGraphEventTbl;*/
//	int		NewRec;
	int		idx;		/* 060109 */
	int		WinNoSave[8];	/* 060921 */
	int		ChangeFlag;
	int		i;

	iWinNum		= 0;		
//	iClockFlag	= 0;
	iVal		= 0;
	SetWindowNo(1);

	while(1){
		WaitClassifTask= 0;
		mp = (T_MAIL *)WaitRequest();
		WaitClassifTask= 1;
		iWinNum =mp->mpec;
		ResponseMail((char *)mp);


		BaseChangeFlag= 0;		/* 040815 */
		BaseChangeFlag1= 0;		/* 040815 */
		TrendClerFlag = 0;		/* TrendCler OFF Set 050313 */

		memcpy(DispDeviceData,DeviceData,sizeof(SaveDeviceData));
		/* ?�����Ԃ��X�V����B */
		NowTime.year = SystemTime.year; 
		NowTime.mon	 = SystemTime.mon;
		NowTime.day	 = SystemTime.day;
		NowTime.hour = SystemTime.hour;
		NowTime.min  = SystemTime.min;
		NowTime.sec  = SystemTime.sec;
		NowTime.week = SystemTime.week;
		memset(&DisplayNowTime,0xff,sizeof(DisplayNowTime));
		/* Window Disp */
		if(iWinStartPx > 0 || iWinStartPy > 0 || iWinNum == 2)
		{
			WindowFristDisplay_Task_Send(2,-1,0,0);

			/* Base Diplay */
			WindowFristDisplay_Task_Send(1,-1,0,1);
		}else if(iDispOrder > 0)
		{
			/* Base Diplay */
			WindowFristDisplay_Task_Send(1,-1,0,1);
		}
		iWinNum = 0;

		WaitBaseChange=0;

		iLoopCnt= 0;
		LoopCnt= 0;

		PLCCnNewRec= 0;
		PLCCnNewRec2= 0;

		OnSignal(S_SCREEN,1);		/* Screen Kansi ON */
		OnSignal(S_PROJECT,1);		/* Project Kansi ON */
/*		if(Screen[iNowScreenNum- 1].iCarryFlag != 0){*/
		idx= GetScreenIdx(iNowScreenNum);  /*   */
		if(Screen[idx].iCarryFlag != 0){
			FloatingAlarmOpenClose(1);
		}
		iDeviceScanFlag = ON;

		
/* 20080822  New�� Ÿ�̸� ���ͷ�Ʈ�� ���� ���� , LP�� ����Ʈ�� ���� ���� */		
//		NewRec= _TimeMSec;
#ifndef	WIN32
//		AplStateOn();
		ClearFlag();
#endif
		while(iOnSignalStart){
//#ifdef	WIN32
//			NewRec= _TimeMSec;
//#endif
//#ifndef	WIN32
//			while(1){
//				WaitFlag(1);
//				ScreenState(LoopCnt);		/* Screen Kansi */
//				if((NewRec + 50) <  _TimeMSec){
//					break;
//				}
//			}
//			NewRec= _TimeMSec;
//			LoopCnt++;
//			iLoopCnt++;
//#else
			ScreenState(LoopCnt);		/* Screen Kansi */
			LoopCnt++;
			iLoopCnt++;
//#endif

/*			PlcDevInitRead(1);*/
/*			PlcState1Loop();*/		/* PLCRead */

			iScreenUpdateFlag	= OFF;
			iDeviceScanFlag		= OFF;	/* ����̽��� �д� ó���� �����ϹǷ� ��ĵ�� ������Ų��. */
			if((((ScreenNumGetDevVal() == ON) && (iUserScreenFlag == 0) && iPassFlag != 1)) ||  /*  || Key.iCode ==0x7FMemory Clear     (iPassFlag == pass) */
				(PassWordSettingChg != 0))			/* Password Input 050411 */
			{
				if(PassWordSettingChg != 0){
					Key.iBuff= 0;				/* 050425 */
					TouchAreaCheckProc();
				}
				BaseChangeFlag= 1;			/* 040815 */
				if(InputDisplay.iKeyOnOff != 0x00)
				{
					CloseWindow(SCREEN_1);
					WindowPointDel();
					vWindowFreemeil();
					InputDisplay.iKeyOnOff = 0;
				}
				if(CommonArea.PcUpDownMode == 0){	/* 051103 */
					SwitchingScreenDevice.iBaseScreenFlag = 1;		/* Base Screen�� �ٲ���� �� */
				}
				break;
			}
			SavePoint	= 0;
			k			= iDispOrder - 1;
//			iClockFlag	= 0;

			/* ?���f??�ƌ��݃f??�Ƃ̔�r�p�ɕۑ����� */
			memcpy(SaveDeviceData,DeviceData,sizeof(SaveDeviceData));
			memset(WinNoSave,0,sizeof(WinNoSave));		/* 060920 */

			ClockDisplayed= OFF;
			while(k >= 0){

				iWinNum = ScreenTagData[k].iWindowNo;
				ChangeFlag= OFF;		/* 060920 */
				switch(ScreenTagData[k].cObjects){
				case NUMERICAL_DISPLAY:				/* Numeric Display */
						if(NumericDispGetDevVal(k) == ON){
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
						}
						break;
				case ASCII_DISPLAY:
						if(AsciiDispGetDevVal(k) == ON){
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
						}
						break;
				case CLOCK:
						if(ClockValCheck(k) == ON){
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
						}
						break;
				case COMMENT:	
						if(CommentDispGetDevVal(k) == ON){
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
						}
						break;
				case PART_DISPLAY:
						if(PartsDispGetDevVal(k) == ON){
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
						}
						break;
				case LAMP:
						if(LampDispGetDevVal(k) == ON){
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
						}
						break;
				case PANELMETER:
						if(PanelMeterDispGetDevVal(k) == ON){
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
						}
						break;
				case TREND_GRAPH:
					if(CommonArea.PcUpDownMode == 0){
						if(ScreenTagData[k].uu.Trend.iTriggerSec == 0){
							if((iLoopCnt % 10) == 0) 
							{
								ScreenTagData[k].UpdateFlag= ON;
								iScreenUpdateFlag = ON;
								ChangeFlag= ON;
							}
						}else{
							if((iLoopCnt % ScreenTagData[k].uu.Trend.iTriggerSec) == 0) 
							{
								ScreenTagData[k].UpdateFlag= ON;
								iScreenUpdateFlag = ON;
								ChangeFlag= ON;
							}
						}
					}
					break;
				case LINE_GRAPH:
						if(LineGraphDispGetDevVal(k) == ON){
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
						}
						break;
				case BAR_GRAPH:
						if(BarGraphDispGetDevVal(k) == ON){
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
						}
						break;
				case STATISTICS:
						if(StatisticsGetDevVal(k) == ON){
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
						}
						break;
				case TOUCH_SWITCH:
						iVal = TouchSwitchGetDevVal(k);
						if(iVal != OFF)
						{ 
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
							if(iVal == 2)			/* Window Screen �ٲ� �ٽ� Display �ؾ� �ϱ� ������ */
								iWinNum = 1;
							if(iWinNum == SCREEN_1 && iTouchFlag == 2) {
								iTouchFlag = 3;
								SavePoint= k;
							}
						}
						break;
				case NUMERICAL_INPUT:
						if(NumericalInputGetDevVal(k) == ON){
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
						}
						break;
				case ASCII_INPUT:
						if(AsciiInputGetDevVal(k) == ON){
							iScreenUpdateFlag = ON;
							ChangeFlag= ON;
						}
						break;
				}
				iDeviceScanFlag = ON; /* ����̽��� �д� ó���� �������Ƿ� ��ĵ�� �����Ѵ�. */
				if(iScreenUpdateFlag==ON){

					if(NumericInputCnt != 0){
						if(SwitchingScreenDevice.iBaseScreenFlag == 2)
							break;
					}
					if(TouchSwitchDispCnt != 0){
						if(SwitchingScreenDevice.iBaseScreenFlag == 1)
							break;
					}
				}
				/* Window No Save */
				if(ChangeFlag == ON){
					WinNoSave[iWinNum]= 1;
				}
				k--;
			}
			if(iScreenUpdateFlag==ON){
				if(((NumericInputCnt != 0) && (SwitchingScreenDevice.iBaseScreenFlag == 2)) ||
					((TouchSwitchDispCnt != 0) && (SwitchingScreenDevice.iBaseScreenFlag == 1))){
				}else{
					/* �Ď��f??��?���p�ɃR�s?���� */
					memcpy(DispDeviceData,SaveDeviceData,sizeof(DispDeviceData));
/* 080921					WindowDisplay_Task_Send(WIN_BASE_DATA,iWinNum,SavePoint,1,1);*/
					for(i= 1; i <= 3; i++){
						if(WinNoSave[i] != 0){
							WindowDisplay_Task_Send(WIN_BASE_DATA,i,SavePoint,1,1);
						}
					}
				}
				iScreenUpdateFlag=OFF;
				if(ClockDisplayed == ON){
					DisplayNowTime.year = NowTime.year; 
					DisplayNowTime.mon	 = NowTime.mon;
					DisplayNowTime.day	 = NowTime.day;
					DisplayNowTime.hour = NowTime.hour;
					DisplayNowTime.min  = NowTime.min;
					DisplayNowTime.sec  = NowTime.sec;
					DisplayNowTime.week = NowTime.week;
				}
				/* ?�����Ԃ��X�V����B */
				NowTime.year = SystemTime.year; 
				NowTime.mon	 = SystemTime.mon;
				NowTime.day	 = SystemTime.day;
				NowTime.hour = SystemTime.hour;
				NowTime.min  = SystemTime.min;
				NowTime.sec  = SystemTime.sec;
				NowTime.week = SystemTime.week;
			}
			if(NumericInputCnt != 0 || AsciiInputCnt != 0){
				if(SwitchingScreenDevice.iBaseScreenFlag == 2)
					break;
			}
			if(TouchSwitchDispCnt != 0){
				if(SwitchingScreenDevice.iBaseScreenFlag == 1)
					break;
			}
			k = 0;
//#ifdef	WIN32
			Delay(100);
//#else
//#endif
		}
		BaseChangeFlag= 1;			/* 040815 */

		OffSignal(S_SCREEN,1);			/* Screen Kansi OFF */
		if(PLCCnErrorDsp == ON){		/* PLC Error Display */

/*ksc20040623*/  
			PlcConnectDispClr(); /* PLC ����� �̿��� �޼��� ���� */
			PLCCnErrorDsp= OFF;  /* �̿��� �޼��� ǥ�� ��/�� �÷��� OFF */
/*ksc20040623*/
		}
		if((SwitchingScreenDevice.iBaseScreenFlag == 1) || (SwitchingScreenDevice.iBaseScreenFlag == 2)){
			OffSignal(S_PROJECT,1);		/* Project Kansi OFF */
		}
		
		FloatingAlarmOpenClose(0);
		iOnSignalStart = 0;
		if(CommonArea.PcUpDownMode == 0){	/* 051103 */
			if(SwitchingScreenDevice.iBaseScreenFlag == 1){
				SendKeyData(CHG_BASE1);
			}else if(SwitchingScreenDevice.iBaseScreenFlag == 2){
				SendKeyData(CHG_BASE2);
			}
		}
	}	
}
/************************************************/
/*	Alarm History Setting						*/
/************************************************/
void	AlarmHistSend( void )
{
	int	i;

	for(i= 0; i < iDispOrder; i++){
		if(ScreenTagData[i].cObjects == ALARM_HISTORY){
			ScreenTagData[i].UpdateFlag= ON;
			WindowDisplay_Task_Send(WIN_BASE_DATA,ScreenTagData[i].iWindowNo,i,1,1);
			break;	/* 050421 */
		}
	}
}
/************************************************/
/*	Alarm List Setting							*/
/************************************************/
void	AlarmListSend( void )
{
	int	i;

	for(i= 0; i < iDispOrder; i++){
		if(ScreenTagData[i].cObjects == ALARM_LIST){
			ScreenTagData[i].UpdateFlag= ON;
			WindowDisplay_Task_Send(WIN_BASE_DATA,ScreenTagData[i].iWindowNo,i,1,1);
			break;	/* 050421 */
		}
	}
}
/********************************************************/
/*	Duplication Check									*/
/********************************************************/
int	fordDupCheck(int idx,int csx,int csy,int cex,int cey,int iScreenNum)
{
	int		i;
	int		Cnt;
	SCREEN_TAG_DATA	*tag_hed;

	Cnt= 0;
	for(i = idx+ 1; i < iDispOrder; i++){
		if(ScreenTagData[i].iWindowNo != iScreenNum){
			continue;
		}
		tag_hed= &ScreenTagData[i];
		if(tag_hed->UpdateFlag != 0){
			continue;
		}
		if( ( ((csx >= tag_hed->sX) && (csx <= tag_hed->eX)) ||
			  ((cex >= tag_hed->sX) && (cex <= tag_hed->eX)) ||
			  ((csx < tag_hed->sX) && (cex > tag_hed->eX)) ) &&
			( ((csy >= tag_hed->sY) && (csy <= tag_hed->eY)) ||
			  ((cey >= tag_hed->sY) && (cey <= tag_hed->eY)) ||
			  ((csy < tag_hed->sY) && (cey > tag_hed->eY)) ) ){
			tag_hed->UpdateFlag= 1;
			Cnt++;
			Cnt+= fordDupCheck(i,tag_hed->sX,tag_hed->sY,tag_hed->eX,tag_hed->eY,iScreenNum);
			if(Cnt > MAX_ERASE_CNT){
				break;
			}
		}
	}
	return(Cnt);
}
int	BeforDupCheck(int idx,int csx,int csy,int cex,int cey,int iScreenNum)
{
	int		i;
	int		Cnt;
	SCREEN_TAG_DATA	*tag_hed;

	Cnt= 0;
	for(i = idx- 1; i >= 0; i--){
		if(ScreenTagData[i].iWindowNo != iScreenNum){
			continue;
		}
		tag_hed= &ScreenTagData[i];
		if(tag_hed->UpdateFlag != 0){
			continue;
		}
		if( ( ((csx >= tag_hed->sX) && (csx <= tag_hed->eX)) ||
			  ((cex >= tag_hed->sX) && (cex <= tag_hed->eX)) ||
			  ((csx < tag_hed->sX) && (cex > tag_hed->eX)) ) &&
			( ((csy >= tag_hed->sY) && (csy <= tag_hed->eY)) ||
			  ((cey >= tag_hed->sY) && (cey <= tag_hed->eY)) ||
			  ((csy < tag_hed->sY) && (cey > tag_hed->eY)) ) ){
			tag_hed->UpdateFlag= 1;
			Cnt++;
			if(tag_hed->BeShapeUsed == 0){	/* No Shape */
				Cnt+= BeforDupCheck(i,tag_hed->sX,tag_hed->sY,tag_hed->eX,tag_hed->eY,iScreenNum);
			}
			Cnt+= fordDupCheck(i,tag_hed->sX,tag_hed->sY,tag_hed->eX,tag_hed->eY,iScreenNum);
			if(Cnt > MAX_ERASE_CNT){
				break;
			}
		}
	}
	/* Figure Check */

	return(Cnt);
}
void	OpenFigureInfo(int iScreenNum)
{
	int					iTotalCnt;
	unsigned char *cTagBuf;
	int					iOffset;

	for(BaseIdx= 0; BaseIdx < TagFileCnt; BaseIdx++){
		if(TagFileInfo[BaseIdx].iScreenNo == iScreenNum){
			cTagBuf= TagFileInfo[BaseIdx].cTagBuf;
			iOffset= TagFileInfo[BaseIdx].iOffset;
			iTotalCnt  = (int)(*(cTagBuf+iOffset) << 0x08);
			iTotalCnt += (int)(*(cTagBuf+(++iOffset)));
			FigureOnOFF[BaseIdx]= (char *)TakeMemory(iTotalCnt);
			memset(FigureOnOFF[BaseIdx],0,iTotalCnt);
		}
	}
}
void	CloseFigureInfo(int iScreenNum)
{
	for(BaseIdx= 0; BaseIdx < TagFileCnt; BaseIdx++){
		if(TagFileInfo[BaseIdx].iScreenNo == iScreenNum){
			FreeMail(FigureOnOFF[BaseIdx]);
		}
	}
}
int	CheckDoubleTag( int iScreenNum )
{
	int		i,j;
	SCREEN_TAG_DATA	*tag_hed;
	int		csx,csy,cex,cey;
	int		ret;
	int		UpCnt;
/*	_TOUCHSWICH_EVENT_TBL*	 TouchSwitchEventTbl;
	_LAMP_EVENT_TBL*	 LampDispEventTbl;
*/
	ret= 0;
	UpCnt= 0;
	for(i = 0; i < iDispOrder; i++){
			if(ScreenTagData[i].iWindowNo != iScreenNum){
				continue;
			}
			tag_hed= &ScreenTagData[i];
			if(tag_hed->UpdateFlag != 0){		/* ON */
				UpCnt++;
				if(UpCnt > MAX_ERASE_CNT){
					ret = 1;
					break;
				}
				csx= tag_hed->sX;
				csy= tag_hed->sY;
				cex= tag_hed->eX;
				cey= tag_hed->eY;
				if(tag_hed->BeShapeUsed == 0){	/* No Shape */
					/* No Shape Under Check */
					UpCnt += BeforDupCheck(i,csx,csy,cex,cey,iScreenNum);
				}else{		/* Shape && Text Check */
					if(ScreenTagData[i].cObjects == TOUCH_SWITCH){
/*						TouchSwitchEventTbl= (_TOUCHSWICH_EVENT_TBL*)IventTable[i];*/
						if((ScreenTagData[i].uu.TouchSw.iOffFontPosition == 1) || (ScreenTagData[i].uu.TouchSw.iOffFontPosition == 3)){
							UpCnt += BeforDupCheck(i,csx,csy,cex,cey,iScreenNum);
						}
						if((ScreenTagData[i].uu.TouchSw.iOnFontPosition == 1) || (ScreenTagData[i].uu.TouchSw.iOnFontPosition == 3)){
							UpCnt += BeforDupCheck(i,csx,csy,cex,cey,iScreenNum);
						}
					}else if(ScreenTagData[i].cObjects == LAMP){
/*						LampDispEventTbl= (_LAMP_EVENT_TBL*)IventTable[i];*/
						if((ScreenTagData[i].uu.Lamp.cOffPosition == 1) ||
							(ScreenTagData[i].uu.Lamp.cOffPosition == 3)){
							UpCnt += BeforDupCheck(i,csx,csy,cex,cey,iScreenNum);
						}
						if((ScreenTagData[i].uu.Lamp.cOnPosition == 1) ||
							(ScreenTagData[i].uu.Lamp.cOnPosition == 3)){
							UpCnt += BeforDupCheck(i,csx,csy,cex,cey,iScreenNum);
						}
					}
				}
				if(UpCnt > MAX_ERASE_CNT){
					ret = 1;
					break;
				}
				/* Ford Check */
				for(j = i+ 1; j < iDispOrder; j++){
					if(ScreenTagData[j].iWindowNo != iScreenNum){
						continue;
					}
					tag_hed= &ScreenTagData[j];
					if(tag_hed->UpdateFlag != 0){
						continue;
					}
					if( ( ((csx >= tag_hed->sX) && (csx <= tag_hed->eX)) ||
						  ((cex >= tag_hed->sX) && (cex <= tag_hed->eX)) ||
						  ((csx < tag_hed->sX) && (cex > tag_hed->eX)) ) &&
						( ((csy >= tag_hed->sY) && (csy <= tag_hed->eY)) ||
						  ((cey >= tag_hed->sY) && (cey <= tag_hed->eY)) ||
						  ((csy < tag_hed->sY) && (cey > tag_hed->eY)) ) ){
						tag_hed->UpdateFlag= 1;
						if(tag_hed->BeShapeUsed == 0){	/* No Shape */
							UpCnt+= BeforDupCheck(i,tag_hed->sX,tag_hed->sY,tag_hed->eX,tag_hed->eY,iScreenNum);
						}
						UpCnt+= fordDupCheck(i,tag_hed->sX,tag_hed->sY,tag_hed->eX,tag_hed->eY,iScreenNum);
						if(UpCnt > MAX_ERASE_CNT){
							ret = 1;
							break;
						}
					}
				}
			}
		if(ret != 0){
			break;
		}
	}
	return(ret);
}
void	ClearTagArea( SCREEN_TAG_DATA *tag_hed,char cObjects,int color )
{
	switch(cObjects){
	case LINE:
	case RECTANGLE:
	case BITMAP_DATA:
	case CIRCLE:
	case TEXT_DISP:
		break;
	default:
		AreaClear(tag_hed->sX,tag_hed->sY,tag_hed->eX,tag_hed->eY,color);
		break;
	}
}
void TouchDataDisp(int iForColor,int iBackColor)
{
	int						len;
	char*					chData;
	short					iLenY;
	int						k;
	short					iLineTextCnt;

	if(TateYoko == 0)		/* ���� ȭ�� */
	{	
		len = strlen(InputDisplay.cInputDispBuff);	
		/****KEY_BINARY*******************************************************/					
		if(CommonArea.KeyWindow.iKeyType == KEY_BINARY && len ==1)
		{
			AreaClear(3,3,95,56,iBackColor);
		}
		if(CommonArea.KeyWindow.iKeyType == KEY_BINARY && len > 11)
		{
			chData = (char*)TakeMemory(12);
			iLenY = len/11;
			for(k=0;k<iLenY;k++)
			{
				DotTextOut(4, 3+(16*k), "           ", 1, 1, T_REPLACE, iForColor, iBackColor);							
				memset(chData,0x00,12);
				memcpy(chData,InputDisplay.cInputDispBuff+(k*11),11);
				DotTextOut(4, 3+(16*k), chData, 1, 1, T_REPLACE, iForColor, iBackColor);
			}

			DotTextOut(4, 3+(16*iLenY), "           ", 1, 1, T_REPLACE, iForColor, iBackColor);

			memset(chData,0x00,12);
			if(len == 22 && iLenY == 2)
			{
				iLenY = 1;	
				memcpy(chData,InputDisplay.cInputDispBuff+(iLenY*11),len-(iLenY*11));
				DotTextOut(4, 3+(16*iLenY), chData, 1, 1, T_REPLACE, iForColor, iBackColor);

				len = 11;
			}else if(len == 33 && iLenY == 3)
			{
				iLenY = 2;	
				memcpy(chData,InputDisplay.cInputDispBuff+(iLenY*11),len-(iLenY*11));
				DotTextOut(4, 3+(16*iLenY), chData, 1, 1, T_REPLACE, iForColor, iBackColor);

				len = 11;
			}else
			{
				memcpy(chData,InputDisplay.cInputDispBuff+(iLenY*11),len-(iLenY*11));
				DotTextOut(4, 3+(16*iLenY), chData, 1, 1, T_REPLACE, iForColor, iBackColor);

				len = len-(iLenY*11);
			}
			DotTextOut(4 + (len- 1)*8, 3+(16*iLenY), &chData[len- 1], 
					1, 1, T_REPLACE, iBackColor, iForColor);
			FreeMail(chData);
		/******************************************************************/
		}else
		{
			chData = (char*)TakeMemory(20);
			memset(chData,0x00,20);
			if(CommonArea.KeyWindow.iKeyType == KEY_OCTAL ||
				CommonArea.KeyWindow.iKeyType == KEY_HEX ||
				CommonArea.KeyWindow.iKeyType == KEY_DECIMAL ||
				CommonArea.KeyWindow.iKeyType == KEY_BINARY)
				memset(chData,' ',11);
			else
				memset(chData,' ',19);
			if(CommonArea.KeyWindow.iKeyType == KEY_BINARY &&
				len == 11)
			{
				DotTextOut(4, 19, "           ", 1, 1, T_REPLACE, iForColor, iBackColor);
			}
			DotTextOut(4, 3, chData, 
						1, 1, T_REPLACE, iForColor, iBackColor);
			/* Numeric KeyWindow */
			if(CommonArea.KeyWindow.iKeyType != KEY_ASCII)
			{
				DotTextOut(4, 3, InputDisplay.cInputDispBuff, 
						1, 1, T_REPLACE, iForColor, iBackColor);
				if(len > 0){
					/* CurSor */
					DotTextOut(4 + (len- 1)*8, 3, &InputDisplay.cInputDispBuff[len- 1], 
							1, 1, T_REPLACE, iBackColor, iForColor);
				}
			}else		/* Ascii KeyWindow */
			{
				if(len > 19)
				{
					memcpy(chData,(InputDisplay.cInputDispBuff)+(len-19),19);
					DotTextOut(4, 3,chData , 
							1, 1, T_REPLACE, iForColor, iBackColor);
					iLenY = 19;
				}else
				{
					DotTextOut(4, 3, InputDisplay.cInputDispBuff, 
							1, 1, T_REPLACE, iForColor, iBackColor);
					iLenY = len;
				}
				if(len > 0){
					/* CurSor */
					DotTextOut(4 + (iLenY- 1)*8, 3, &InputDisplay.cInputDispBuff[len- 1], 
							1, 1, T_REPLACE, iBackColor, iForColor);
				}
			}
			FreeMail(chData);
		}
	}else		/* ���� ȭ�� */
	{
		if(CommonArea.KeyWindow.iKeyType == KEY_BINARY ||
			CommonArea.KeyWindow.iKeyType == KEY_OCTAL)
			iLineTextCnt = 6;
		else if(CommonArea.KeyWindow.iKeyType == KEY_DECIMAL ||
			CommonArea.KeyWindow.iKeyType == KEY_HEX ||
			CommonArea.KeyWindow.iKeyType == KEY_REAL)
			iLineTextCnt = 8;
		else
			iLineTextCnt = 9;

		len = strlen(InputDisplay.cInputDispBuff);	

		if(CommonArea.KeyWindow.iKeyType == KEY_HEX)
			AreaClear(3,3,75,18,iBackColor);
		else if(CommonArea.KeyWindow.iKeyType == KEY_REAL ||
			CommonArea.KeyWindow.iKeyType == KEY_DECIMAL)
			AreaClear(3,3,75,36,iBackColor);
		else if(CommonArea.KeyWindow.iKeyType == KEY_OCTAL)
			AreaClear(3,3,56,36,iBackColor);
		else if(CommonArea.KeyWindow.iKeyType == KEY_BINARY)
			AreaClear(3,3,56,96,iBackColor);
		else
		{
			AreaClear(3,3,75,38,iBackColor);
			AreaClear(3,39,36,54,iBackColor);
		}		
		
		if(len > iLineTextCnt)
		{
			chData = (char*)TakeMemory(InputDisplay.iLen+5);

			iLenY = (len-1)/iLineTextCnt;
			for(k=0;k<iLenY;k++)
			{
				memset(chData,0x00,10);
				memcpy(chData,InputDisplay.cInputDispBuff+(iLineTextCnt*k),iLineTextCnt);
				DotTextOut(3, 3+(k*17), chData, 1, 1, T_REPLACE, iForColor, iBackColor);
			}
			memset(chData,0x00,10);
			memcpy(chData,InputDisplay.cInputDispBuff+(iLineTextCnt*k),(len-(iLineTextCnt*iLenY)));
			DotTextOut(3, 3+(k*17), chData, 1, 1, T_REPLACE, iForColor, iBackColor);
			DotTextOut(3 + ((len-(iLineTextCnt*iLenY)) -1)*8,	3+(iLenY*17), &InputDisplay.cInputDispBuff[len- 1], 
					1, 1, T_REPLACE, iBackColor, iForColor);		

			FreeMail(chData);
		}else{
			DotTextOut(3, 3, InputDisplay.cInputDispBuff, 
						1, 1, T_REPLACE, iForColor, iBackColor);
			iLenY = 0;
			DotTextOut(3 + (len- 1)*8, 3+(iLenY*17), &InputDisplay.cInputDispBuff[len- 1], 
					1, 1, T_REPLACE, iBackColor, iForColor);		
		}
	}
}
void	MakeTagCode_01(unsigned char *TagBuffer,int iBackColor,_FIGURE_EVENT_TBL *FigureEventTbl)
{
	FigureEventTbl->ST.LineInfo.LineType.iLineColor = (int)(*(TagBuffer+4));
#ifdef	OLD		/* ksc20091217 */
	if(iBackColor != 0){		/* 050426 */	
		if(FigureEventTbl->ST.LineInfo.LineType.iLineColor == 0){
			FigureEventTbl->ST.LineInfo.LineType.iLineColor = 0xff;
		}else{
			FigureEventTbl->ST.LineInfo.LineType.iLineColor = 0;
		}
	}
#endif	
	FigureEventTbl->ST.LineInfo.LineType.iLineStyle = (unsigned int)(*(TagBuffer+5) + 1);
}
void	MakeTagCode_09(unsigned char *TagBuffer,int iBackColor,_FIGURE_EVENT_TBL *FigureEventTbl)
{
	FigureEventTbl->ST.TextInfo.iTextColor = (int)(*(TagBuffer+4));
#ifdef	OLD		/* ksc20091217 */
	if(iBackColor != 0){		/* 050426 */
		if(FigureEventTbl->ST.TextInfo.iTextColor == 0){
			FigureEventTbl->ST.TextInfo.iTextColor = 0xff;
		}else{
			FigureEventTbl->ST.TextInfo.iTextColor = 0;
		}
	}
#endif
	FigureEventTbl->ST.TextInfo.iSizeH = (int)(*(TagBuffer+7));	
	FigureEventTbl->ST.TextInfo.iSizeV = (int)(*(TagBuffer+8));
	FigureEventTbl->ST.TextInfo.LineCnt = (unsigned char)(*(TagBuffer+21));

//	if((int)(*(TagBuffer+19)) == 0xFF && FigureEventTbl->ST.TextInfo.iSizeV == 0 ){
	if((int)(*(TagBuffer+19)) == 0xFF){
		FigureEventTbl->ST.TextInfo.iSizeH = 0;
		FigureEventTbl->ST.TextInfo.iSizeV = 0;		//20101207
	}
	FigureEventTbl->ST.TextInfo.TextSPoint = (char *)(TagBuffer+21);
}
void	MakeTagCode_03(unsigned char *TagBuffer,int iBackColor,_FIGURE_EVENT_TBL *FigureEventTbl)
{
	FigureEventTbl->ST.RectInfo.RectType.iLineColor	= (int)(*(TagBuffer+4));  /* leesi 0802*/
	FigureEventTbl->ST.RectInfo.RectType.iBackColor	= (int)(*(TagBuffer+5));
	FigureEventTbl->ST.RectInfo.RectType.iLineStyle	= (unsigned int)(*(TagBuffer+6)) + 1;
	FigureEventTbl->ST.RectInfo.RectType.iForeColor	= (int)(*(TagBuffer+7));
	FigureEventTbl->ST.RectInfo.RectType.iPattern	= (int)(*(TagBuffer+8));
#ifdef	OLD		/* ksc20091217 */
	if(iBackColor != 0){		/* 050426 */
		if(FigureEventTbl->ST.RectInfo.RectType.iLineColor == 0){
			FigureEventTbl->ST.RectInfo.RectType.iLineColor= 0xff;
		}else{
			FigureEventTbl->ST.RectInfo.RectType.iLineColor= 0;
		}
		if(FigureEventTbl->ST.RectInfo.RectType.iBackColor == 0){
			FigureEventTbl->ST.RectInfo.RectType.iBackColor= 0xff;
		}else{
			FigureEventTbl->ST.RectInfo.RectType.iBackColor= 0;
		}
		if(FigureEventTbl->ST.RectInfo.RectType.iForeColor == 0){
			FigureEventTbl->ST.RectInfo.RectType.iForeColor= 0xff;
		}else{
			FigureEventTbl->ST.RectInfo.RectType.iForeColor= 0;
		}
	}
#endif
}
void	MakeTagCode_06(unsigned char *TagBuffer,_FIGURE_EVENT_TBL *FigureEventTbl,int sX,int eX)
{
	FigureEventTbl->ST.CircleInfo.CircleType.iLineColor = (short)(*(TagBuffer+4));  
	FigureEventTbl->ST.CircleInfo.CircleType.iBackColor = (short)(*(TagBuffer+5)); 
	FigureEventTbl->ST.CircleInfo.CircleType.iForeColor = (short)(*(TagBuffer+6)); 
	FigureEventTbl->ST.CircleInfo.CircleType.iPattern = (short)(*(TagBuffer+7));
	FigureEventTbl->ST.CircleInfo.iRadius = (short)((eX - sX)/2);
}
void	MakeTagCode_0A_0B(unsigned char *TagBuffer,_FIGURE_EVENT_TBL *FigureEventTbl)
{
	FigureEventTbl->ST.BmpInfo.iTagSizeOf = (unsigned int)(*(TagBuffer+4) << 0x08);
	FigureEventTbl->ST.BmpInfo.iTagSizeOf += (unsigned int)(*(TagBuffer+5));
	FigureEventTbl->ST.BmpInfo.iTagSizeOf -= 76;	/* 82  78  76*/
	FigureEventTbl->ST.BmpInfo.BmpSPoint = (char *)(TagBuffer + 76);
}
void	IventDisplay(int k,int dflag,int *tFlag,int iScreenNum,unsigned short mpec,int iBackColor)
{
	SCREEN_TAG_DATA		*tag_hed;
	int			ret;

	if(ScreenTagData[k].iWindowNo == iScreenNum)
	{
/*		tag_hed= (TAG_HED *)IventTable[k];*/
		tag_hed= &ScreenTagData[k];
		if((dflag == 1) && (tag_hed->UpdateFlag1 == 0)){
			return;
		}
		if(dflag == 1){
			tag_hed->UpdateFlag1 = 0;
		}else{
			tag_hed->UpdateFlag = 0;
		}
		switch(ScreenTagData[k].cObjects){
			case LINE:
			case RECTANGLE:
			case BITMAP_DATA:
			case CIRCLE:
				FigureDisplay(k,iBackColor);
				break;
			case TEXT_DISP:
				TextDisplay(k,iBackColor);
				break;

			case NUMERICAL_DISPLAY:
					NumericDispWatch(k);
					break;
			case ASCII_DISPLAY:
					AsciiDispWatch(k);
					break;
			case CLOCK:
					ClockDispWatch(k);
					break;
			case COMMENT:	
				CommentDispWatch(k);
					break;
			case ALARM_HISTORY:
					AlarmHistoryDispWatch(k);
					break;
			case ALARM_LIST:
					AlarmListDispWatch(k);
					break;
			case PART_DISPLAY:
					PartsDispWatch(k);
					break;
			case LAMP:
					LampDispWatch(k);
					break;
			case PANELMETER:
					PanelMeterDispWatch(k);
					break;
			case TREND_GRAPH:
					TrendGraphDispWatch(k);
					break;
			case LINE_GRAPH:
					LineGraphDispWatch(k);
					break;
			case BAR_GRAPH:
					BarGraphDispWatch(k);
					break;
			case STATISTICS:
					StatisticsDispWatch(k);
					break;
			case TOUCH_SWITCH:
					ResetWinSema();			/* 050616 */
					ret= TouchKeyDispWatch(k,iBackColor);
					SetWinSema();			/* 050616 */
					if(*tFlag == -1){
						*tFlag= ret;
					}
					break;
			case NUMERICAL_INPUT:
					NumericInputWatch(0,k,(char *)NULL);
					break;
			case ASCII_INPUT:
					AsciiInputDispWatch(k);
					break;
		}
	}
}
long	ChangeChar2long(char *cDeviceVal,int i1632BitFlag)
{
	long	lDeviceValue;
	short	lDeviceValueTemp;

/* 20080822 Low/High �ݴ�� ó�� �κ� */
	if(i1632BitFlag == 0x00){
		//061124
//#ifdef	WIN32
		lDeviceValueTemp  =  (short)(cDeviceVal[0]  << 8);
		lDeviceValueTemp +=  (short)cDeviceVal[1] & 0xff;
		lDeviceValue= (long)lDeviceValueTemp;
//#else
//		lDeviceValue  =  *(unsigned short*)cDeviceVal;
//#endif
	}else{
		//061124
//#ifdef	WIN32
		lDeviceValue  =  (long)(cDeviceVal[2] << 24);
		lDeviceValue +=  ((long)(cDeviceVal[3] << 16) & 0xffffff);
		lDeviceValue +=  ((long)(cDeviceVal[0] << 8) & 0xffff);
		lDeviceValue +=  (long)cDeviceVal[1] & 0xff;
//#else
//		lDeviceValue  =  *(unsigned short *)cDeviceVal << 16;
//		lDeviceValue +=  *(unsigned short *)&cDeviceVal[2];
//#endif
	}
	return(lDeviceValue);
}
long	ChangeChar2Unsinlong(char *cDeviceVal,int i1632BitFlag)
{
	long	lDeviceValue;

	if(i1632BitFlag == 0x00){
		//061124
//#ifdef	WIN32
		lDeviceValue  =  (unsigned int)(cDeviceVal[0]  << 8) & 0xffff;
		lDeviceValue +=  (unsigned int)cDeviceVal[1] & 0xff;		
//#else
//		lDeviceValue  =  *(unsigned short*)cDeviceVal;
//#endif
	}else{
		//061124
//#ifdef	WIN32
		lDeviceValue  =  (unsigned long)(cDeviceVal[2] << 24)  & 0xffffffff;
		lDeviceValue +=  ((unsigned long)(cDeviceVal[3] << 16) & 0xffffff);
		lDeviceValue +=  ((unsigned long)(cDeviceVal[0] << 8) & 0xffff);
		lDeviceValue +=  (unsigned long)cDeviceVal[1] & 0xff;
//#else
//		lDeviceValue  =  *(unsigned short *)cDeviceVal << 16;
//		lDeviceValue +=  *(unsigned short *)&cDeviceVal[2];
//#endif
	}
	return(lDeviceValue);
}

/********************************************************************************/
/* �� �� �� : TextDisplay(int iOrder)[�迭�� ����]								*/
/* ��    �� : Text�� Display�Ѵ�.												*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2003�� 4�� 1�� (ȭ)												*/
/* �� �� �� : �� �� �� 															*/
/* �� �� ġ	:																	*/
/* ��    �� :																	*/
/********************************************************************************/
void	TextDisplay(int iOrder,int iBackColor)
{
	char*	cText;
//	short	iBack_Color;
	unsigned long	iBack_Color;
	short	iType;
	short	sX, sY;
	short	iTextSize;
	short	i;
//	int		iOffset;
	int		iStartPos;
	_FIGURE_EVENT_TBL*			FigureEventTbl;
	
/*	FigureEventTbl = (_FIGURE_EVENT_TBL*)IventTable[iOrder];*/
	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	MakeTagCode_09(ScreenTagData[iOrder].TagPos,iBackColor,FigureEventTbl);
		if(FigureEventTbl->ST.TextInfo.iTextColor == 0)
		{
			iBack_Color	= WHITE;	
			iType		= T_FRONT;
		}else
		{
			iBack_Color = BLACK;
			iType      = T_OR;
		}
		if((unsigned char)FigureEventTbl->ST.TextInfo.LineCnt == 0x01){
			iTextSize  = (int)(*(FigureEventTbl->ST.TextInfo.TextSPoint+3) << 0x08);
			iTextSize += (int)(*(FigureEventTbl->ST.TextInfo.TextSPoint+4));

			cText = (char*)TakeMemory(iTextSize+1);
			memset(cText, 0x00, (iTextSize+1));
			memcpy(cText, (FigureEventTbl->ST.TextInfo.TextSPoint+5), iTextSize);
			DotTextOut(ScreenTagData[iOrder].sX, ScreenTagData[iOrder].sY, cText,
					FigureEventTbl->ST.TextInfo.iSizeH, 
					FigureEventTbl->ST.TextInfo.iSizeV, iType,
					FigureEventTbl->ST.TextInfo.iTextColor,
					iBack_Color);
			FreeMail(cText);
		}else{
			i=0;
			iStartPos = 0;
			while(i < FigureEventTbl->ST.TextInfo.LineCnt){
				sX = (short)(*(FigureEventTbl->ST.TextInfo.TextSPoint+(++iStartPos)));				
				sY = (short)(*(FigureEventTbl->ST.TextInfo.TextSPoint+(++iStartPos)));
				iTextSize = (int)(*(FigureEventTbl->ST.TextInfo.TextSPoint+(++iStartPos)) << 0x08);
				iTextSize += (int)(*(FigureEventTbl->ST.TextInfo.TextSPoint+(++iStartPos)));
				iStartPos++;
				cText = (char*)TakeMemory(iTextSize+1);
				memset(cText, 0x00, (iTextSize+1));
				memcpy(cText, (FigureEventTbl->ST.TextInfo.TextSPoint + iStartPos), iTextSize);

				DotTextOut(ScreenTagData[iOrder].sX + sX,
					ScreenTagData[iOrder].sY + sY, 
					cText, 
					FigureEventTbl->ST.TextInfo.iSizeH, 
					FigureEventTbl->ST.TextInfo.iSizeV, iType ,
					FigureEventTbl->ST.TextInfo.iTextColor,
					iBack_Color);
				FreeMail((char*)cText);
				iStartPos += iTextSize;
//				iOffset = 4 + iTextSize;
/*				if(iOffset%4 !=0){
					iTake = (int)((iOffset/4)+1)*4;
					iStartPos += iTake - iOffset;					
				}*/
				iStartPos--;
				i++;				
			}
		}
	FreeMail((char *)FigureEventTbl);
	return;
}
/********************************************************************************/
/* �� �� �� : FigureDisplay(int iOrder)[�迭�� ����]							*/
/* ��    �� : Figure�� Display�Ѵ�.												*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2003�� 4�� 7�� (��)												*/
/* �� �� �� : �� �� �� 															*/
/* �� �� ġ	:																	*/
/* ��    �� :																	*/
/********************************************************************************/
void	FigureDisplay(int iOrder,int iBackColor)
{
	char*	chData;
	int		RadiusY;
	_FIGURE_EVENT_TBL*			FigureEventTbl;
	
/*	FigureEventTbl = (_FIGURE_EVENT_TBL*)IventTable[iOrder];*/
	FigureEventTbl = (_FIGURE_EVENT_TBL*)TakeMemory(sizeof(_FIGURE_EVENT_TBL));
	switch(ScreenTagData[iOrder].cObjects){
	case LINE:
		MakeTagCode_01(ScreenTagData[iOrder].TagPos,iBackColor,FigureEventTbl);
		LineOut(ScreenTagData[iOrder].sX, 
				ScreenTagData[iOrder].sY, 
				ScreenTagData[iOrder].eX, 
				ScreenTagData[iOrder].eY, 
				&(FigureEventTbl->ST.LineInfo.LineType));
		break;
	case RECTANGLE:
		MakeTagCode_03(ScreenTagData[iOrder].TagPos,iBackColor,FigureEventTbl);
		RectAngleOut(ScreenTagData[iOrder].sX, 
					 ScreenTagData[iOrder].sY, 
					 ScreenTagData[iOrder].eX, 
					 ScreenTagData[iOrder].eY, 
					 &(FigureEventTbl->ST.RectInfo.RectType));
		break;
	case CIRCLE:
		MakeTagCode_06(ScreenTagData[iOrder].TagPos,FigureEventTbl,ScreenTagData[iOrder].sX,ScreenTagData[iOrder].eX);
		RadiusY = (ScreenTagData[iOrder].eY-ScreenTagData[iOrder].sY)/2;
		DrawDaen(ScreenTagData[iOrder].sX + FigureEventTbl->ST.CircleInfo.iRadius, 
			ScreenTagData[iOrder].sY + RadiusY,
			FigureEventTbl->ST.CircleInfo.iRadius,RadiusY,
			&(FigureEventTbl->ST.CircleInfo.CircleType));
		break;
	case BITMAP_DATA:
		MakeTagCode_0A_0B(ScreenTagData[iOrder].TagPos,FigureEventTbl);
		chData = (char*)TakeMemory(FigureEventTbl->ST.BmpInfo.iTagSizeOf+1);
		memcpy(chData, FigureEventTbl->ST.BmpInfo.BmpSPoint, FigureEventTbl->ST.BmpInfo.iTagSizeOf);		
		PutImageGp(ScreenTagData[iOrder].sX, 
				ScreenTagData[iOrder].sY, 
				ScreenTagData[iOrder].eX, 
				ScreenTagData[iOrder].eY, 
				(char *)chData);
		FreeMail(chData);
		break;
	}
	FreeMail((char *)FigureEventTbl);
}

/********************************************************************************/
/* �� �� �� : NumericDispGetDevVal(int iOrder)[�迭�� ����]						*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
short	NumericDispGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ret= ON;
	}
	return(ret);
}
short	ClockValCheck(int iOrder)
{
	short		RetVal;
	if(DisplayNowTime.sec != SystemTime.sec){		/* 20080822 */
		/*		
		NowTime.year = SystemTime.year; 
		NowTime.mon	 = SystemTime.mon;
		NowTime.day	 = SystemTime.day;
		NowTime.hour = SystemTime.hour;
		NowTime.min  = SystemTime.min;
		NowTime.sec  = SystemTime.sec;
		NowTime.week = SystemTime.week;
		*/
		ScreenTagData[iOrder].UpdateFlag= ON;
		ClockDisplayed= ON;
		RetVal = ON;
	}else{
		RetVal = OFF;
	}
	return RetVal;
}

/********************************************************************************/
/* �� �� �� : AsciiDispGetDevVal(int iOrder)[�迭�� ����]						*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
short   AsciiDispGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ret= ON;
	}
	return(ret);
}
/********************************************************************************/
/* �� �� �� : AsciiInputGetDevVal(int iOrder)[�迭�� ����]						*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/

short AsciiInputGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ScreenTagData[iOrder].uu.AsciiIn.iTriggerVal = ON;
		ret= ON;
	}
	/* �g���K?�Ď� */
	return(ret);
}
/********************************************************************************/
/* �� �� �� : NumericalInputGetDevVal(int iOrder)[�迭�� ����]					*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
short NumericalInputGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ret= ON;
	}else{
		if(ScreenTagData[iOrder].UpdateFlag == ON){
			ret= ON;
		}
	}
	/* �g���K?�Ď� */
	return(ret);
}
/********************************************************************************/
/* �� �� �� : CommentDispGetDevVal(int iOrder)[�迭�� ����]						*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
short CommentDispGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ret= ON;
	}
	return(ret);
}

/********************************************************************************/
/* �� �� �� : PartsDispGetDevVal(int iOrder)[�迭�� ����]						*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/

short PartsDispGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ret= ON;
	}
	return(ret);
}

/********************************************************************************/
/* �� �� �� : LampDispGetDevVal(int iOrder)[�迭�� ����]						*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
short LampDispGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ret= ON;
	}
	return(ret);
}
/********************************************************************************/
/* �� �� �� : TouchSwitchGetDevVal(int iOrder)[�迭�� ����]						*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/*				�Ď�����														*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
short TouchSwitchGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ret= ON;
	}
	/* Display Triger */
	/* Action Triger */
	return(ret);
}

/* 20080822 */
void	SetRepeatInf(int iNum)
{
	int		i;
	int		j;
	int		sxidx;
	int		syidx;
	int		exidx;
	int		eyidx;
	int		idx;
	int		kNo;

	sxidx= ScreenTagData[iNum].sX/(GAMEN_X_SIZE/15);
	exidx= ScreenTagData[iNum].eX/(GAMEN_X_SIZE/15);
	syidx= ScreenTagData[iNum].sY/(GAMEN_Y_SIZE/4);
	eyidx= ScreenTagData[iNum].eY/(GAMEN_Y_SIZE/4);
	idx= sxidx;
	for(i= 0; i < 8; i++){
		if(i < 8){
			RepeatInfo.EntryCnt= i+ 1;
		}
		for(j= 0; j < 8; j++){
			kNo= syidx * 15+ idx+ 1;
			RepeatInfo.RepeatNo[i][j]= kNo;
			idx++;
			if(idx > exidx){
				idx= sxidx;
				syidx++;
				if(syidx > eyidx){
					break;
				}
			}
		}
		if(syidx > eyidx){
			break;
		}
	}
}
/********************************************************************************/
/* �� �� �� : PanelMeterDispGetDevVal(int iOrder)[�迭�� ����]					*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
short PanelMeterDispGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ret= ON;
	}
	return(ret);
}

/********************************************************************************/
/* �� �� �� : TrendGraphDispGetDevVal(int iOrder)[�迭�� ����]					*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
short TrendGraphDispGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ret= ON;
	}
	return(ret);
}

/********************************************************************************/
/* �� �� �� : LineGraphDispGetDevVal(int iOrder)[�迭�� ����]					*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
short LineGraphDispGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ret= ON;
	}
	return(ret);
}

/********************************************************************************/
/* �� �� �� : BarGraphDispGetDevVal(int iOrder)[�迭�� ����]					*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
short BarGraphDispGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ret= ON;
	}else{		/*20080822 �ٱ׷��� ���̽����� ����Ǿ����� �������� �ʴ� ������ �ٽ� ���� */
		if((ret == OFF) && (ScreenTagData[iOrder].uu.BarGraph.DevOrder[0] != -1)){
			if(memcmp(&DispDeviceData[ScreenTagData[iOrder].uu.BarGraph.DevOrder[0]],
						&SaveDeviceData[ScreenTagData[iOrder].uu.BarGraph.DevOrder[0]],
				ScreenTagData[iOrder].DevCnt) != 0){
				ScreenTagData[iOrder].UpdateFlag= ON;
				ret= ON;
			}
		}
		if((ret == OFF) && (ScreenTagData[iOrder].uu.BarGraph.DevOrder[1] != -1)){
			if(memcmp(&DispDeviceData[ScreenTagData[iOrder].uu.BarGraph.DevOrder[1]],
						&SaveDeviceData[ScreenTagData[iOrder].uu.BarGraph.DevOrder[1]],
				ScreenTagData[iOrder].DevCnt) != 0){
				ScreenTagData[iOrder].UpdateFlag= ON;
				ret= ON;
			}
		}
		if((ret == OFF) && (ScreenTagData[iOrder].uu.BarGraph.DevOrder[2] != -1)){
			if(memcmp(&DispDeviceData[ScreenTagData[iOrder].uu.BarGraph.DevOrder[2]],
						&SaveDeviceData[ScreenTagData[iOrder].uu.BarGraph.DevOrder[0]],
				ScreenTagData[iOrder].DevCnt) != 0){
				ScreenTagData[iOrder].UpdateFlag= ON;
				ret= ON;
			}
		}
	}
	return(ret);
}

/********************************************************************************/
/* �� �� �� : StatisticsGetDevVal(int iOrder)[�迭�� ����]						*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
short StatisticsGetDevVal(int iOrder)
{
	int		ret;

	ret= OFF;
	if(memcmp(&DispDeviceData[ScreenTagData[iOrder].DevOrder],&SaveDeviceData[ScreenTagData[iOrder].DevOrder],
		ScreenTagData[iOrder].DevCnt) != 0){
		ScreenTagData[iOrder].UpdateFlag= ON;
		ret= ON;
	}
	return(ret);
}
/********************************************************************************/
/* �� �� �� : ScreenNumGetDevVal()[�迭�� ����]									*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 9�� 13�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* �� �� ġ	: �����÷���														*/
/* ��    �� : ȭ�鰻�ſ��θ� �����ؼ� ������									*/
/********************************************************************************/
short ScreenNumGetDevVal(void)
{
	short			RetVal;
	short			i;
	int	iDevVal;

	RetVal = 0;
	/*PlcDevInit();*/
	/* 20080822 */
#ifdef	WIN32
	iDevVal  =  (CommonArea.SwitchingData[0] & 0xff)  << 8;
	iDevVal +=  (CommonArea.SwitchingData[0] & 0xff00) >> 8;
#else
	iDevVal = CommonArea.SwitchingData[0];
#endif
	if(iDevVal != iNowScreenNum && (iDevVal != 0 || iNowScreenNum != 1))
	{ 
		if(!((iDevVal == 1) && (iNowScreenNum == 0)))
		{
			RetVal = 1;
			if(iDevVal == 0){		/* 050425 */
				iDevVal= 1;
			}
/*			if(strlen(CommonArea.SystemDev.Switch_Base_DevName)!=0)*/
/*			{*/
			//061124
//				InDevArea.UB[INDEV_WRITE+0] = iDevVal & 0x00ff ;
//				InDevArea.UB[INDEV_WRITE+1] = (iDevVal >> 8) & 0x00ff;
				InDevArea.UW[INDEV_WRITE+0] = iDevVal;
				SendTimeAction(10,0,0,0);
/*			}*/
		/*	iScreenDisp = iDevVal; */
		}
	}
	/* Overlap 1 */
	if(strlen(CommonArea.SystemDev.Switch_Over1_DevName) != 0)
	{
		//061124
#ifdef	WIN32
		iDevVal = (CommonArea.SwitchingData[1] & 0xff) << 8;
		iDevVal += (CommonArea.SwitchingData[1] & 0xff00) >> 8;
#else
		iDevVal = CommonArea.SwitchingData[1];
#endif
		if(iDevVal != iSwitch_ScreenNum1)
		{ 
/*			if(!((iDevVal == 1) && (iSwitch_ScreenNum1 == 0)))*/
/*			{*/
				RetVal = 1;
/*				if(strlen(CommonArea.SystemDev.Write_Dev.DevName)!=0)*/
/*				{	*/
					if(iDevVal < 1){
						iDevVal = -1;
					}else{
						for(i=0;iBaseScreenCnt>i;i++)
						{
							if(Screen[i].iNum == iDevVal)
								break;
						}
					}
					if(i==iBaseScreenCnt)
						iDevVal = -1;
					//061124
//					InDevArea.UB[INDEV_WRITE+2] = iDevVal & 0x00ff ;
//					InDevArea.UB[INDEV_WRITE+3] = (iDevVal >> 8) & 0x00ff;
					InDevArea.UW[INDEV_WRITE+1] = iDevVal;
					SendTimeAction(10,0,0,0);
/*				}*/
/*			}*/
		}
	}
	if(strlen(CommonArea.SystemDev.Switch_Over2_DevName) != 0)
	{
		//061124
#ifdef	WIN32
		iDevVal = (CommonArea.SwitchingData[2] & 0xff) << 8;
		iDevVal += (CommonArea.SwitchingData[2] & 0xff00) >> 8;
#else
		iDevVal = CommonArea.SwitchingData[2];
#endif
		if(iDevVal != iSwitch_ScreenNum2)
		{ 
/*			if(!((iDevVal == 1) && (iSwitch_ScreenNum2 == 0)))*/
/*			{*/
				RetVal = 1;
/*				if(strlen(CommonArea.SystemDev.Write_Dev.DevName)!=0)*/
/*				{*/
					if(iDevVal < 1){
						iDevVal = -1;
					}else{
						for(i=0;iBaseScreenCnt>i;i++)
						{
							if(Screen[i].iNum == iDevVal)
								break;
						}
					}
					if(i==iBaseScreenCnt)
						iDevVal = -1;
					//061124
//					InDevArea.UB[INDEV_WRITE+4] = iDevVal & 0x00ff ;
//					InDevArea.UB[INDEV_WRITE+5] = (iDevVal >> 8) & 0x00ff;
					InDevArea.UW[INDEV_WRITE+2] = iDevVal;
					SendTimeAction(10,0,0,0);
/*				}*/
/*			}*/
		}
	}
	/* ���?�F���W�Ń�?����?��?���n�e�e���� 050314 */
	if(RetVal == 1){
		MomentaryOff();
	}
	return RetVal;
}
/********************************************************************************/
/* �� �� �� : GetDeviceSet														*/
/* ��    �� : ����̽��� ����̽����� ��巡���� �����Ѵ�.						*/
/* ��    �� : cBuffer(������)													*/
/* ��    �� : cTempBuff(����̽���), DevAddress(����̽� ��巡��)				*/
/* �� �� �� : 2003�� 6�� 11�� (��)												*/
/* �� �� �� : �� �� �� 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void GetDeviceSet(unsigned char* cBuffer, char* cDevName, int* iDevAddress)
{	
	unsigned int	Address;
//	int				bFlag;
//	unsigned char	idx;

//	idx = 0;
	*cDevName	=	cBuffer[0] ;/*& 0x7f*/
//	idx			=	cBuffer[0];

//	if(idx > 0x7f)
//		bFlag = 1;
//	else
//		bFlag = 0;

	Address		=	(int)(cBuffer[1] << 24);
	Address		+=	(int)(cBuffer[2] << 16);
	Address		+=	(int)(cBuffer[3] << 8);
	Address		+=	(int)(cBuffer[4] & 0xff);
	/*	*iDevAddress = GetPlcAddress(bFlag, idx, Address);*/
	*iDevAddress = Address;
	return;

}

void	WindowPointDel(void)
{
	iWinStartPy = 0;
	iWinStartPy = 0;
}
/********************************************************************************/
/* �� �� �� : Hexa_SignedChangeData												*/
/* ��    �� : ���ڷ� ���� Hex ���� Dec�� �ٲٴ� �Լ�			 				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� :																	*/
/* �� �� �� : �� �� �� 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	Hexa_SignedChangeData(char* ChangeData,long* ReturnData)
{
	int		iLen;
	int		i;
	long	lData;

	lData	= 0;
	iLen	= strlen(ChangeData);

	for(i=0;i<iLen;i++)
	{
		if(ChangeData[i] >= 0x30 &&	ChangeData[i] <= 0x39)
		{
			lData += (int)ChangeData[i] - 48;
			if(iLen > i+1)
				lData = lData * (16);
		}else if(ChangeData[i] >= 0x41 &&	ChangeData[i] <= 0x46)
		{
			lData += (int)ChangeData[i] - 55;
			if(iLen > i+1)
				lData = lData * 16;
		}
	}
	*ReturnData = lData;
}
/********************************************************************************/
/* �� �� �� : Octal_SignedChangeData											*/
/* ��    �� : ���ڷ� ���� Octal ���� ���� Dec �ٲٴ� �Լ�		 				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 																	*/
/* �� �� �� : �� �� �� 															*/
/* ��    �� :																	*/
/********************************************************************************/
void	Octal_SignedChangeData(char* ChangeData,long* ReturnData)
{
	int		iLen;
	int		i;
	long	lData;

	lData	= 0;
	iLen	= strlen(ChangeData);
	for(i=0;i<iLen;i++)
	{
		lData += (int)ChangeData[i] - 48;
		if(iLen > i+1)
			lData = lData * 8;
	}

	*ReturnData = lData;
}
/********************************************************************************/
/* �� �� �� : Binary_SignedChangeData											*/
/* ��    �� : ���ڷ� ���� Binary ���� Dec�� �ٲٴ� �Լ�			 				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� :																	*/
/* �� �� �� : �� �� �� 															*/
/* ��    �� :																	*/
/********************************************************************************/
void	Binary_SignedChangeData(char* ChangeData,long* ReturnData)
{
	int		iLen;
	int		i;
	long	lData;

	lData	= 0;
	iLen	= strlen(ChangeData);
	for(i=0;i<iLen;i++)
	{
		lData += (int)ChangeData[i] - 48;
		if(iLen > i+1)
			lData = lData * 2;
	}

	*ReturnData = lData;
}
/********************************************************************************/
/* �� �� �� : BCD_TO_BIN														*/
/* ��    �� : �Ϲ� Device ���� BCD�� �ٲٴ� �Լ�				 				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2003�� 1�� 15�� (��)												*/
/* �� �� �� : �� �� �� 															*/
/* ��    �� : BCD �̿��� �ڵ尪�� ���� ��� -1 ����							*/
/********************************************************************************/
void	BCD_TO_BIN(long *lReturnData)
{
	long	lData;
	long	lReturn;
	int		iVal;
	long	i = 1;
	lReturn = 0;
	lData =	*lReturnData;
/*	
	if(lData <= 0)
		return;
*/
/*lsi20040529 ���� */
	if(lData < 0)
	{
		*lReturnData = -1;
		return;
	}else if(lData == 0)
		return;
/*lsi20040529*/		

	while(lData != 0)
	{
		iVal = lData & 0x00000000f;

		if(iVal<10){
			lReturn = lReturn + (iVal*i);
		}
		else
		{
			lReturn = -1;				/* BCD �ڵ尪�� �ƴ� ��� ������ -1 ���� */
			break;
		}
		lData = lData>>4;
		i = i*10;
		if(i > 100000000)
			break;
	}
	*lReturnData = lReturn;
}
/*void SendTouchKan()
{
	T_MAIL *mp;
	char	code[8+1];
	extern	int     KeyFreeMbx;        

	memset(code,0,sizeof(code));

    
	mp = (T_MAIL *)ReceiveMail( KeyFreeMbx );
	memcpy(mp->mbuf,code,sizeof(code));
    SendMail( T_KEYHAND, (char *)mp);
}*/

/********************************************************************************/
/* �� �� �� : WindowDisplay_Task(int iScreenNum, int iOrderNum)					*/
/* ��    �� : 																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 10�� 05�� (��)												*/
/* �� �� �� : �� �� �� 															*/
/* �� �� ġ	: 																	*/
/* ��    �� :																	*/
/********************************************************************************/
void	WindowDisplay_Task(STTFrm* pSTT)
{
	T_MAIL					*mp;
	int						k;
	short					Sx,Sy;
	int						iScreenNum;
//	int						iOrderNum;
	int						dflag;
	SCREEN_TAG_DATA			*tag_hed;
	int						ret;
	int						DrawBankFlag;
	int						iBackColor;
	int						iForColor;
	int					tFlag= -1;		/* 031128 */
//	unsigned	int	OldTime;
//	unsigned	int	MaxTime= 0;
//	unsigned	int	NowTime= 0;

/*char	dsp_buff[8];*/
	/* WindowDisplay_Task Mail Get */
    WindowDispFreeMbx = TakeMbx();
//    for( k=0; k<20; k++ ) {
    for( k=0; k<5; k++ ) {
        mp= (T_MAIL *)TakeMail();
        ChangeMailResp( (char*)mp, WindowDispFreeMbx );
        SendMail( WindowDispFreeMbx, (char*)mp );
    }

	while(1){
		WaitDisplayTask= 0;
		mp = (T_MAIL *)WaitRequest();

		WaitDisplayTask= 1;
		if((WaitSetting != 0) || (iOnSignalStart != ON) ||(SwitchingScreenDevice.iBaseScreenFlag != 0)
			|| (BaseChangeFlag1 == 1) || (CommonArea.PcUpDownMode != 0) ){	/* 040815 */
			ResponseMail((char *)mp);
			continue;
		}
//		OldTime= _TimeMSec;		//??�X�N�̌o�ߎ��Ԃ��v�邽��

		SetWinSema();			/* 050428 */

		switch(mp->mcmd){
		case WIN_BASE_DATA:
			iScreenNum	= mp->mpar;
//			iOrderNum	= mp->mext;
			dflag		= mp->mpec;
			DrawBankFlag= mp->mcod;

			SetWindowNo(iScreenNum);
			
			k = 0;
			/* 050425 */
			iBackColor= NowBackColor(iNowScreenNum);
			if(iBackColor == WHITE){
				iForColor= BLACK;
			}else{
				iForColor= WHITE;
			}
			if(dflag == 0){
				ClearDispBuffBackColor(iScreenNum,iBackColor);
			}else{
				/* Area Dup Check */
				ret= CheckDoubleTag(iScreenNum);
				if((dflag == 1) && (ret == 1)&&(iScreenNum == 1)){	  
					/* Dup Over All Clear */
					dflag= 0;
					ClearDispBuffBackColor(iScreenNum,iBackColor);
				}
				if(dflag == 1){	
					for(k=0;k < iDispOrder;k++){
						if(ScreenTagData[k].iWindowNo == iScreenNum)
						{
							tag_hed= &ScreenTagData[k];
							tag_hed->UpdateFlag1= tag_hed->UpdateFlag;
							if(tag_hed->UpdateFlag1 == 0){
								continue;
							}
							tag_hed->UpdateFlag = 0;
							ClearTagArea(tag_hed,ScreenTagData[k].cObjects,iBackColor);
						}
					}
				}
			}
			/* Tag Display */
			for(k=0;k < iDispOrder;k++){
				if(CommonArea.PcUpDownMode == 1){
					break;
				}
				IventDisplay(k,dflag,&tFlag,iScreenNum,mp->mpec,iBackColor);
			}
			/* 031128 */
			if(tFlag == 0){
				iAlternateflag = 0x00;
			}

			if(iScreenNum == SCREEN_1 ) /* &&  */
			{
				if(iTouchFlag == 1){

						iTouchFlag = 2;
				}
				if(CommonArea.KeyWindow.iDefault == 0 || CommonArea.KeyWindow.iFlagData == 1){
					TouchDataDisp(iForColor,iBackColor);		/* 050426 */
				}
			}
			if(iOnSignalStart == ON){
				if(iScreenNum == 1){
					Sx = 0;
					Sy = 0;
				}else
				{
					Sx = iWinStartPx;
					Sy = iWinStartPy;				
				}
				SetStartPos(iScreenNum,Sx,Sy);
			}
			if(DrawBankFlag == 1){
				DrawLcdBank1();
			}
			if(iDispOrder == 0)
			{
			}else if(iTouchFlag == 3)
			{
				iTouchFlag = 2;
			}
			break;
		case FLOAT_DATA:
			DrawLcdBank1();
			break;
		}
		ResponseMail((char *)mp);
		
		ResetWinSema();
		//�o�ߎ��Ԍv�Z
//		NowTime= _TimeMSec- OldTime;
//		if(NowTime > MaxTime){
//			MaxTime= _TimeMSec- OldTime;
//		}
//		if(NowTime > 0x100){
//			Delay(50);			//����?�X�N�𑖂炷����Wait����B
//		}
	

	}
}
/********************************************/
/*	Base Figer Display						*/
/********************************************/
/* 20080822 GP_S057�� �ý���ȭ���� ���̽� ȭ�鿡�� �ٿ�δ��ϴ� ������ �����Ͽ��� ������ totalcnt�� �߰� �Ǿ��� */
int	DispBaseFiger(int FileNo,int *iTotalCnt)
{
	int			iPos,iSize;
	char		cPcTempFileName[16];
	int		i,TagPos;
	int		iOffset;
//	int		iTotalCnt;
	unsigned char *FlashTagPos;
	unsigned char *TagBuffer;
	unsigned char *cTagBuf;
	int		iBackColor;
	int		ret;
	unsigned char	*GamenData;
	int		TextFlag;


	TextFlag= ON;
	if(FileNo > 1000){		//���ݒ���
		TextFlag= OFF;
		FileNo -= 1001;		//Start Gamen No
#ifdef	WIN32
		GamenData= (unsigned char *)&GpFont[SET_DISP_ADDR];
#else
		GamenData= (unsigned char *)SET_DISP_ADDR;
#endif
		iSize = GamenData[FileNo*4] << 24;
		iSize += GamenData[FileNo*4+1] << 16;
		iSize += GamenData[FileNo*4+2] << 8;
		iSize += GamenData[FileNo*4+3];
		iPos= (int)&GamenData[iSize];
	}else{
		sprintf(cPcTempFileName,"BAS%05d.GP",FileNo);
		ret = mfileserch(cPcTempFileName, &iPos, &iSize);
		if(ret != OK){
			return(ret);
		}
//	}			//2011.11.21 Del(��?�U?��ʂ̂ݎg�p)
//2011.09.08 Add ////////////////////////////////
		iBackColor= NowBackColor(FileNo);
		ClearDispBuffBackColor(SCREEN_0,iBackColor);
	}
/////////////////////////////////////////////////
	
	cTagBuf= (unsigned char *)iPos;
//2011.09.08 Del	iBackColor= 0;
	iOffset= 10;
	*iTotalCnt  = (int)(*(cTagBuf+iOffset) << 0x08);
	*iTotalCnt += (int)(*(cTagBuf+(++iOffset)));
	iOffset++;
	FlashTagPos= (unsigned char *)(cTagBuf+iOffset);
	/* �ŏ��̗ޒl�����o�� */
	TagPos  = (int)(*FlashTagPos << 0x18);
	FlashTagPos++;
	TagPos += (int)(*FlashTagPos << 0x10);
	FlashTagPos++;
	TagPos += (int)(*FlashTagPos << 0x08);
	FlashTagPos++;
	TagPos += (int)(*FlashTagPos);
	FlashTagPos++;
	cTagBuf += 10;
	for(i= 0; i < *iTotalCnt; i++){
		TagBuffer= (unsigned char *)(cTagBuf+TagPos);
		switch(TagBuffer[0]){
		case 0x01:		/* Line */
			ScreenTagData[i].cObjects	= LINE;
			ScreenTagData[i].iWindowNo	= 1;
			ScreenTagData[i].TagPos= TagBuffer;
			ScreenTagData[i].sX  = (short)(*(TagBuffer+6) << 0x08);		/* Line Start X Point */
			ScreenTagData[i].sX += (short)(*(TagBuffer+7));
			ScreenTagData[i].sY  = (short)(*(TagBuffer+8) << 0x08);		/* Line Start Y Point */
			ScreenTagData[i].sY += (short)(*(TagBuffer+9));
			ScreenTagData[i].eX  = (short)(*(TagBuffer+10) << 0x08);		/* Line End X Point */
			ScreenTagData[i].eX += (short)(*(TagBuffer+11));
			ScreenTagData[i].eY  = (short)(*(TagBuffer+12) << 0x08);		/* Line End Y Point */
			ScreenTagData[i].eY += (short)(*(TagBuffer+13));
			ScreenTagData[i].BeShapeUsed= 0;
			FigureDisplay(i,iBackColor);
			break;
		case 0x09:		/* text */
			ScreenTagData[i].cObjects	= TEXT_DISP;
			ScreenTagData[i].iWindowNo	= 1;
			ScreenTagData[i].TagPos= TagBuffer;
			ScreenTagData[i].sX  = (short)(*(TagBuffer+9) << 0x08);		/* Line Start X Point */
			ScreenTagData[i].sX += (short)(*(TagBuffer+10));
			ScreenTagData[i].sY  = (short)(*(TagBuffer+11) << 0x08);		/* Line Start Y Point */
			ScreenTagData[i].sY += (short)(*(TagBuffer+12));
			ScreenTagData[i].eX  = (short)(*(TagBuffer+13) << 0x08);		/* Line End X Point */
			ScreenTagData[i].eX += (short)(*(TagBuffer+14));
			ScreenTagData[i].eY  = (short)(*(TagBuffer+15) << 0x08);		/* Line End Y Point */
			ScreenTagData[i].eY += (short)(*(TagBuffer+16));
			ScreenTagData[i].BeShapeUsed= 0;
			if(TextFlag == ON){		//���ݒ���
				TextDisplay(i,iBackColor);
			}
			break;
		case 0x03:		/* rectangle */
			ScreenTagData[i].cObjects	= RECTANGLE;
			ScreenTagData[i].iWindowNo	= 1;
			ScreenTagData[i].TagPos= TagBuffer;
			ScreenTagData[i].sX  = (short)(*(TagBuffer+9) << 0x08);		/* Line Start X Point */
			ScreenTagData[i].sX += (short)(*(TagBuffer+10));
			ScreenTagData[i].sY  = (short)(*(TagBuffer+11) << 0x08);		/* Line Start Y Point */
			ScreenTagData[i].sY += (short)(*(TagBuffer+12));
			ScreenTagData[i].eX  = (short)(*(TagBuffer+13) << 0x08);		/* Line End X Point */
			ScreenTagData[i].eX += (short)(*(TagBuffer+14));
			ScreenTagData[i].eY  = (short)(*(TagBuffer+15) << 0x08);		/* Line End Y Point */
			ScreenTagData[i].eY += (short)(*(TagBuffer+16));
			ScreenTagData[i].BeShapeUsed= 0;
			FigureDisplay(i,iBackColor);
			break;
		case 0x06:		/* circle */
			ScreenTagData[i].cObjects	= CIRCLE;
			ScreenTagData[i].iWindowNo	= 1;
			ScreenTagData[i].TagPos= TagBuffer;
			ScreenTagData[i].sX  = (short)(*(TagBuffer+8) << 0x08);		/* Line Start X Point */
			ScreenTagData[i].sX += (short)(*(TagBuffer+9));
			ScreenTagData[i].sY  = (short)(*(TagBuffer+10) << 0x08);		/* Line Start Y Point */
			ScreenTagData[i].sY += (short)(*(TagBuffer+11));
			ScreenTagData[i].eX  = (short)(*(TagBuffer+12) << 0x08);		/* Line End X Point */
			ScreenTagData[i].eX += (short)(*(TagBuffer+13));
			ScreenTagData[i].eY  = (short)(*(TagBuffer+14) << 0x08);		/* Line End Y Point */
			ScreenTagData[i].eY += (short)(*(TagBuffer+15));
			ScreenTagData[i].BeShapeUsed= 0;
			FigureDisplay(i,iBackColor);
			break;
		case 0x0A:		/* BMP */		
		case 0x0B:		/* DXF */
			ScreenTagData[i].cObjects	= BITMAP_DATA;
			ScreenTagData[i].iWindowNo	= 1;
			ScreenTagData[i].TagPos= TagBuffer;
			ScreenTagData[i].sX  = (short)(*(TagBuffer+6) << 0x08);		/* Line Start X Point */
			ScreenTagData[i].sX += (short)(*(TagBuffer+7));
			ScreenTagData[i].sY  = (short)(*(TagBuffer+8) << 0x08);		/* Line Start Y Point */
			ScreenTagData[i].sY += (short)(*(TagBuffer+9));
			ScreenTagData[i].eX  = (short)(*(TagBuffer+10) << 0x08);		/* Line End X Point */
			ScreenTagData[i].eX += (short)(*(TagBuffer+11));
			ScreenTagData[i].eY  = (short)(*(TagBuffer+12) << 0x08);		/* Line End Y Point */
			ScreenTagData[i].eY += (short)(*(TagBuffer+13));
			ScreenTagData[i].BeShapeUsed= 0;
			FigureDisplay(i,iBackColor);
			break;
		case 0x64:		/* Numeric Data			���	*/
		case 0x65:		/* ASCII Data			���	*/
		case 0x68:		/* Clock Data			���	*/
		case 0x6E:		/* Comment Data			���	*/
		case 0x70:		/* Alarm List Data		���	*/
		case 0x72:		/* Alarm History Data	���	*/
		case 0x78:		/* Part Data			���	*/
		case 0x7A:		/* Lamp Data			���	*/
		case 0x7B:		/* Panel Meter Data		���	*/
		case 0x82:		/* Trend Graph Data		���	*/
		case 0x84:		/* Bar Graph Data		���	*/
		case 0x85:		/* Statistics Data		���	*/
		case 0x87:		/* Line Graph Data		���	*/
		case 0x8C:		/* Touch Switch Data	���	*/
		case 0x96:		/* Numeric Input Data	���	*/
		case 0x97:		/* Ascii Input Data		���	*/
/*			IventDisplay(k++,dflag,tFlag,iScreenNum,mpec);*/
			break;
		}
		/* ����TAG�ʒu�����o�� */
		TagPos  = (int)(*FlashTagPos << 0x18);
		FlashTagPos++;
		TagPos += (int)(*FlashTagPos << 0x10);
		FlashTagPos++;
		TagPos += (int)(*FlashTagPos << 0x08);
		FlashTagPos++;
		TagPos += (int)(*FlashTagPos);
		FlashTagPos++;
	}
	return(0);
}
