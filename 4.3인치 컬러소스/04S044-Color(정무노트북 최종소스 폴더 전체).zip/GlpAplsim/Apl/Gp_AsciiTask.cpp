/********************************************************************************/
/* �� �� �� : Gp_AsciiTask.cpp													*/
/* ��    �� : AsciiDisplayTask													*/
/* �� �� �� : 2002�� 5�� 16�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"
/********************************************************************************/
/* �� �� �� : DrawAscii_Func													*/
/* ��    �� : Ascii������ �ص��Ͽ� ȭ�鿡 ���									*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 24�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetAscii_Func(int iDispOrder)
{
	_ASCII_EVENT_TBL*	 AsciiDispEventTbl;
	AsciiDispEventTbl= (_ASCII_EVENT_TBL*)TakeMemory(sizeof(_ASCII_EVENT_TBL));
	DrawAscii_Func(0,AsciiDispEventTbl,iDispOrder);
	FreeMail((char *)AsciiDispEventTbl);
}
int	DrawAscii_Func(int mode, _ASCII_EVENT_TBL* AsciiDispEventTbl, int iDispOrder)
{
/*	int							iTagSizeOf;*/
	int							iOffset;
	unsigned char				*buffer;

	buffer= ScreenTagData[iDispOrder].TagPos;
/*	_ASCII_EVENT_TBL*	 AsciiDispEventTbl;*/

	iOffset		= 0;
/*	iTagSizeOf	= 0;*/
/*
	if(CheckMailBox(sizeof(_ASCII_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_ASCII_EVENT_TBL));
	AsciiDispEventTbl= (_ASCII_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)AsciiDispEventTbl, 0x00, sizeof(_ASCII_EVENT_TBL));
/*	
		iTagSizeOf = (int)(buffer[0] << 0x08); 
		iTagSizeOf += (int)buffer[1] & 0xff; 
*/		
		/* ��ǥ ���� */	
/*
		AsciiDispEventTbl->sX  = (unsigned int)(buffer[6]  << 0x08);
		AsciiDispEventTbl->sX += (unsigned int)buffer[7] & 0xff; 

		AsciiDispEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
		AsciiDispEventTbl->sY += (unsigned int)buffer[9] & 0xff;

		AsciiDispEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
		AsciiDispEventTbl->eX += (unsigned int)buffer[11] & 0xff;

		AsciiDispEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
		AsciiDispEventTbl->eY += (unsigned int)buffer[13] & 0xff;	
*/		
		
		AsciiDispEventTbl->iFrameColor = (unsigned int)buffer[14];	/* FrameColor */
		AsciiDispEventTbl->iFontSizeH  = (unsigned int)buffer[15];	/* FontSizeH */
		AsciiDispEventTbl->iFontSizeV  = (unsigned int)buffer[16];	/* FontSizeV   6*8dot�� ����ϸ� �� ����Ʈ�� 0x00�� ��ȯ�ȴ� */
		iOffset = 17;
		/*------------------------------------------------------------*/

		GetDeviceSet((buffer+iOffset),
					AsciiDispEventTbl->cDeviceName,
					&(AsciiDispEventTbl->iDeviceNumber));

		/*-------------------------------------------------------------*/		
		iOffset += 5;
		AsciiDispEventTbl->iAlignment = (int)buffer[iOffset];/* Alignment *//* 22 */

		AsciiDispEventTbl->iTextColor = (unsigned int)buffer[++iOffset];	
		
		AsciiDispEventTbl->iPlateColor = (unsigned int)buffer[++iOffset];/* PlateColor */				
		AsciiDispEventTbl->iDigits = (int)buffer[++iOffset];/* Digits */
		
		if((unsigned int)(buffer[++iOffset]) == 0x00){ /* buffer[5] = 0x00�̸� Shape���þ���. buffer[5] = 0x04�̸� Shape������. */
			/*AsciiDispEventTbl->BeShapeUsed = UNCHECKED;*/
			AsciiDispEventTbl->ShapeNo = 0;
			iOffset++;
			if(mode == 0){
				ScreenTagData[iDispOrder].BeShapeUsed= UNCHECKED;
			}
		}
		else{
			/*AsciiDispEventTbl->BeShapeUsed = CHECKED;*/
			AsciiDispEventTbl->ShapeNo = (unsigned int)(buffer[++iOffset]);
			if(mode == 0){
				ScreenTagData[iDispOrder].BeShapeUsed= CHECKED;
			}
		}
		if((int)buffer[++iOffset] != 0){
			AsciiDispEventTbl->iFontSizeH = 0;
			AsciiDispEventTbl->iFontSizeV = 0;		//20101207
		}
		
/*
		AsciiDispEventTbl->cBefDevData = (char*)TakeMemory(AsciiDispEventTbl->iDigits + 1);		
		memset(AsciiDispEventTbl->cBefDevData, 0x00, sizeof(AsciiDispEventTbl->cBefDevData));
*/
		if(mode == 0){
			DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;
			DeviceDataHed[DeviceCnt].DevName[0] = AsciiDispEventTbl->cDeviceName[0];
			DeviceDataHed[DeviceCnt].DevName[1] = AsciiDispEventTbl->cDeviceName[1];
			DeviceDataHed[DeviceCnt].DevAddress = AsciiDispEventTbl->iDeviceNumber;		
			DeviceDataHed[DeviceCnt].DevCnt = (int)((AsciiDispEventTbl->iDigits+1)/2);		
			DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];
			ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
			ScreenTagData[iDispOrder].DevCnt= DeviceDataHed[DeviceCnt].DevCnt*2;
			iDeviceOffset += AsciiDispEventTbl->iDigits * 2;
			DeviceCnt++;
		}
/*		AsciiDispEventTbl->iRegisterNumber = DeviceCnt;		
*/		
		/* 20020819 choijh add*/		
/*		AsciiDispEventTbl->SuperVOffset= WatchingDevice(AsciiDispEventTbl->cDeviceName, 
										AsciiDispEventTbl->iDeviceNumber, 
										0,
										AsciiDispEventTbl->iRegisterNumber,
										(WORD+2), DeviceDataHed[DeviceCnt].DevCnt);
*/		
/*		IventTableCnt++;*/

		return(0);
}

void AsciiDispWatch(int iOrder)
{
	int				iFormatStyle;
	int				iFontsX;
	int				iFontsY;
	int				iType;
	int				Back_Color;
	int				iShape_Size;
	short			iSize;
	short			iLen;
	short			i;
	char			*dsp_buff;
extern	void	ChangeLowHighByte(char *buff,int cnt);

	_ASCII_EVENT_TBL*	 AsciiDispEventTbl;
/*	AsciiDispEventTbl= (_ASCII_EVENT_TBL*)IventTable[iOrder];*/
	AsciiDispEventTbl= (_ASCII_EVENT_TBL*)TakeMemory(sizeof(_ASCII_EVENT_TBL));
	DrawAscii_Func(1, AsciiDispEventTbl, iOrder);

	dsp_buff= TakeMemory(AsciiDispEventTbl->iDigits + 1+ 1);

	iFormatStyle	= 0;
	iFontsX			= 0;
	iFontsY			= 0;
	iType			= 0;
	Back_Color		= 0;
	iShape_Size		= 0;
	iLen			= 0;
		iFormatStyle = AsciiDispEventTbl->iAlignment;
		if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){
			iShape_Size = DrawShape(AsciiDispEventTbl->ShapeNo, 
						ScreenTagData[iOrder].sX, 
						ScreenTagData[iOrder].sY, 
						ScreenTagData[iOrder].eX, 
						ScreenTagData[iOrder].eY,
						AsciiDispEventTbl->iFrameColor,
						AsciiDispEventTbl->iPlateColor);
		}
		if(AsciiDispEventTbl->iFontSizeH >= 1){
			iSize = 8*AsciiDispEventTbl->iFontSizeH;
		}else{
			iSize = 6;
		}
		memcpy(dsp_buff,&DispDeviceData[ScreenTagData[iOrder].DevOrder],ScreenTagData[iOrder].DevCnt*2);
// Display Buff Low High Change 2008.06.19
		ChangeLowHighByte(dsp_buff,AsciiDispEventTbl->iDigits);

		/* ������ ������ġ�� ���� ��Ʈ�Ѵ�. */	
		for(i=0;i<AsciiDispEventTbl->iDigits;i++)
		{
/*			 if(AsciiDispEventTbl->cBefDevData[i] == 0x00)*/
			 if(dsp_buff[i] == 0x00)
			{
				break;
			}else if(!(dsp_buff[i]<0x80 && dsp_buff[i]>0x00))
			{
				i++;
				iLen++;
			}
			iLen++;
		}
		if(iFormatStyle == 0x00){/* Right Alignment */
			iFontsX = (ScreenTagData[iOrder].eX+1 - (iLen * iSize)) - iShape_Size;
			iFontsY = ScreenTagData[iOrder].sY + iShape_Size;
		}
		else if(iFormatStyle == 0x01){/* Left Alignment */
			iFontsX = ScreenTagData[iOrder].sX + iShape_Size;
			iFontsY = ScreenTagData[iOrder].sY + iShape_Size;
		}
		else if(iFormatStyle == 0x02){/* Center Alignment */
			iFontsX = (int)((ScreenTagData[iOrder].eX+1 + ScreenTagData[iOrder].sX)/2) - ((int)(iLen*iSize)/2);
			if(iFontsX<0)
				iFontsX=0;
			iFontsY = ScreenTagData[iOrder].sY + iShape_Size;
		}
		if(AsciiDispEventTbl->iTextColor == 0)
		{
			Back_Color	= WHITE;	
			iType		= T_FRONT;
		}else
		{
			Back_Color = BLACK;
			iType      = T_OR;
		}				
		DotTextOut(iFontsX,
						iFontsY, 
						dsp_buff, 
						AsciiDispEventTbl->iFontSizeH, 
						AsciiDispEventTbl->iFontSizeV, 
						iType, 
						AsciiDispEventTbl->iTextColor, 
						Back_Color);
		FreeMail((char *)AsciiDispEventTbl);
		FreeMail(dsp_buff);
}
