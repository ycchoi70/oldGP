/* ****************************************************************************** */
/*  �� �� �� : GP_HPPMODE.CPP														 */
/*  ��    �� : HPP��� �޴� ó��												 */
/*  �� �� �� : 2002�� 2�� 14�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */

#include	"sgt.h"

/* ****************************************************************************** */
/*  �Լ� ������ Ÿ�� ����														 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �Լ�																			 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �� �� �� : MonitoringMode()													 */
/*  ��    �� : 																	 */
/*  ��    �� : iScreenNo														 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 6�� 27�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#ifdef	SIZE_2480
void	MonitoringMode(int* iScreenNo)
{
	int		iKeyCode;
	short	BuzzerValue;
	short	iKeyFlag;
	int		iflag;

	DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+NLine_2,(Dspname[MONITORING].chName[Set.iLang][0]),1,1, TRANS, T_WHITE, T_BLACK);
	DefaultFormDisplay(1,Dspname[MONITORING].chTitle[Set.iLang]);
	DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+NLine_3,(Dspname[MONITORING].chName[Set.iLang][2]),1,1, TRANS, T_WHITE, T_BLACK);
	DrawLcdBank1();

	iKeyFlag = 1;
	BuzzerValue	= 0;
	iKeyCode	= -1;
	while (*iScreenNo == MONITORING_NUM) {

		iKeyCode = KeyWaitData(iKeyFlag,MONITORING_NUM);
		iKeyFlag = 0;
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}
		else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}
		/* Ű ���� ó�� */		
		if(iKeyCode >= KEY_01 && iKeyCode <= KEY_02)		/* */				
		{
			
			*iScreenNo = USER_SCREEN_NUM;
			BuzzerValue = 1;
		}
		else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) 
		{									/*  ESC					 */
			*iScreenNo = SELECT_MEMU_NUM;	
			BuzzerValue = 1;
		}
		else if (iKeyCode >= KEY_16 && iKeyCode <= KEY_30 ) 
		{
			iflag = iSysSetretCheck(DEVICE_MONITORING_NUM);		/* Password */
			if(iflag == DOWN_TRANS)		/* DownLoad */
				*iScreenNo = DOWN_TRANS;
			else if(iflag == UP_TRANS)	/* UPLoad */
				*iScreenNo = UP_TRANS;
			else if(iflag == 0)			/* ȭ���̵� ó�� */
			{
				*iScreenNo = DEVICE_MONITORING_NUM;											/*  ����̽� �����		 */
				BuzzerValue = 1;
			}else	/* ���� ȭ�� ��� */
			{
				*iScreenNo = MONITORING_NUM;
				break;
			}
		}
#ifdef	LP_S044    /* 2009.09.22 */
		else if (iKeyCode >= KEY_31 && iKeyCode <= KEY_45 ) 
		{
			iflag = iSysSetretCheck(DEVICE_XY_MONITORING_NUM);		/* Password */
			if(iflag == DOWN_TRANS)		/* DownLoad */
				*iScreenNo = DOWN_TRANS;
			else if(iflag == UP_TRANS)	/* UPLoad */
				*iScreenNo = UP_TRANS;
			else if(iflag == 0)			/* ȭ���̵� ó�� */
			{
				*iScreenNo = DEVICE_XY_MONITORING_NUM;											/*  XY ����̽� �����		 */
				BuzzerValue = 1;
			}else	/* ���� ȭ�� ��� */
			{
				*iScreenNo = MONITORING_NUM;
				break;
			}
		}
#endif
		
		if(BuzzerValue == 1)
		{
			iKeyFlag = 1;
			if(Set.iBuzzer == 1)
			{
				NormalBuzzer();	
				BuzzerValue = 0;
			}
		}
	}
}
#endif

