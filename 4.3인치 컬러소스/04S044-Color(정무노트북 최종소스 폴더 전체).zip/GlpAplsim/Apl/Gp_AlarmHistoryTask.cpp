/********************************************************************************/
/* �� �� �� : Gp_AlarmHistoryTask.cpp											*/
/* ��    �� : AlarmHistoryTask													*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"

/********************************************************************************/
/* �� �� �� : DrawAlarmHistory_Task												*/
/* ��    �� : Alarm Histroy ������ �ص��Ͽ� ȭ�鿡 ���						    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetAlarmHistory_Func (int iOrder)
{
	unsigned char		*buffer;

	buffer= ScreenTagData[iOrder].TagPos;
	iHistoryPositionVal	= 0;			/* AlarmHistory �� �����ؾ� �� ��ġ��	*/
	iHistoryOnOff		= 1;			/* AlarmHistory�� ���� ����				*/
	iHistoryDisCnt		= 0;

	if((unsigned int)buffer[19] != 0x00){
		ScreenTagData[iOrder].BeShapeUsed = CHECKED;
	}
}
int	DrawAlarmHistory_Func (_ALARM_HISTORY_EVENT_TBL* AlarmHistoryEventTbl,int iOrder)
{
/*	int					iTagSizeOf;*/
	int					iOffset;
	unsigned int		iOccuredContentsInfo[8];
	unsigned int		iRstContents[8];
	unsigned char		*buffer;

	buffer= ScreenTagData[iOrder].TagPos;
/*	_ALARM_HISTORY_EVENT_TBL*	 AlarmHistoryEventTbl;

	if(CheckMailBox(sizeof(_ALARM_HISTORY_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_ALARM_HISTORY_EVENT_TBL));
	AlarmHistoryEventTbl= (_ALARM_HISTORY_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)AlarmHistoryEventTbl, 0x00, sizeof(_ALARM_HISTORY_EVENT_TBL));

/*	iHistoryPositionVal	= 0;*/			/* AlarmHistory �� �����ؾ� �� ��ġ��	*/
/*	iHistoryOnOff		= 1;*/			/* AlarmHistory�� ���� ����				*/
/*	iHistoryDisCnt		= 0;*/

/*
	AlarmHistoryEventTbl->sX  = (unsigned int)(buffer[6] << 0x08);
	AlarmHistoryEventTbl->sX += (unsigned int)buffer[7] & 0xff;

	AlarmHistoryEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
	AlarmHistoryEventTbl->sY += (unsigned int)buffer[9] & 0xff;

	AlarmHistoryEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
	AlarmHistoryEventTbl->eX += (unsigned int)buffer[11] & 0xff;

	AlarmHistoryEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
	AlarmHistoryEventTbl->eY += (unsigned int)buffer[13] & 0xff;
*/	
	/* Form->Sort : 0x01 : Oldest,	0x02 : Latest */
	AlarmHistoryEventTbl->iSortInfomation	= (unsigned int)buffer[14];
	/* 0x02 : Occurrences		0x13 : Restorations		0x?? : Occur Frequency */
	AlarmHistoryEventTbl->iDispStyle		= (unsigned int)buffer[15];

	AlarmHistoryEventTbl->iDispRows			= (unsigned int)buffer[16];

	AlarmHistoryEventTbl->iFontSizeH		= (unsigned int)buffer[17];
	AlarmHistoryEventTbl->iFontSizeV		= (unsigned int)buffer[18];

	if((unsigned int)buffer[19] != 0x00){
/*		if(mode == 0){
			ScreenTagData[iOrder].BeShapeUsed = CHECKED;
		}
*/
		AlarmHistoryEventTbl->ShapeNo = (unsigned int)buffer[20];
	}else{
/*
		if(mode == 0){
			ScreenTagData[iOrder].BeShapeUsed = UNCHECKED;
		}
*/
		AlarmHistoryEventTbl->ShapeNo = 0x00;
	}
	if((unsigned int)buffer[21] != 0)
	{
			AlarmHistoryEventTbl->iFontSizeH = 0;
			AlarmHistoryEventTbl->iFontSizeV = 0;
	}

	AlarmHistoryEventTbl->iTitleColor = (unsigned int)buffer[22];
	AlarmHistoryEventTbl->iFrameColor = (unsigned int)buffer[23];
	AlarmHistoryEventTbl->iPlateColor = (unsigned int)buffer[24];
	AlarmHistoryEventTbl->iMessageWide = (unsigned int)buffer[25];
	AlarmHistoryEventTbl->iMessgaeTitleSize  = (unsigned int)(buffer[26]);

	iOffset=27;
	if(AlarmHistoryEventTbl->iMessgaeTitleSize > 0){
		AlarmHistoryEventTbl->cMsgTitleContents = (char *)(buffer + iOffset);	
		iOffset += AlarmHistoryEventTbl->iMessgaeTitleSize;
	}

	iOccuredContentsInfo[0] = (unsigned int)(buffer[iOffset] & 0x80);
	iOccuredContentsInfo[1] = (unsigned int)(buffer[iOffset] & 0x40);
	iOccuredContentsInfo[2] = (unsigned int)(buffer[iOffset] & 0x20);
	iOccuredContentsInfo[3] = (unsigned int)(buffer[iOffset] & 0x10);

	iOccuredContentsInfo[4] = (unsigned int)(buffer[iOffset] & 0x08);
	iOccuredContentsInfo[5] = (unsigned int)(buffer[iOffset] & 0x04);
	iOccuredContentsInfo[6] = (unsigned int)(buffer[iOffset] & 0x02);
	iOccuredContentsInfo[7] = (unsigned int)(buffer[iOffset] & 0x01);

	AlarmHistoryEventTbl->iMainContentInfo = iOccuredContentsInfo[7] + iOccuredContentsInfo[6];
	AlarmHistoryEventTbl->iDateContentInfo = iOccuredContentsInfo[3] + iOccuredContentsInfo[4];
	AlarmHistoryEventTbl->iTimeContentInfo = iOccuredContentsInfo[0] + iOccuredContentsInfo[1];
	/*
	iMainContentInfo		iDateContentInfo			iTimeContentInfo			
	0x00 : Date, Time		0x00 : YY/MM/DD				0x00 : HH:MM:SS
	0x01 : Date				0x08 : MM/DD/YY				0x64 : HH:MM
	0x02 : Time				0x16 : DD/MM/YY
	0x03 : String			0x24 : MM/DD
	*/		
	AlarmHistoryEventTbl->iOccurredColor = (unsigned int)buffer[++iOffset];
	AlarmHistoryEventTbl->iOccurredWide = (unsigned int)buffer[++iOffset];

/* 2009.07.09 Dell & Add */
/*	AlarmHistoryEventTbl->iOccurredTitleSize += (unsigned int)buffer[++iOffset] & 0xff;*/
	AlarmHistoryEventTbl->iOccurredTitleSize = (unsigned int)buffer[++iOffset] & 0xff;
	iOffset++;
	if(AlarmHistoryEventTbl->iOccurredTitleSize > 0){
		AlarmHistoryEventTbl->cOccurredTitleContents = (char *)(buffer + iOffset);
		iOffset += AlarmHistoryEventTbl->iOccurredTitleSize;

	}
	AlarmHistoryEventTbl->iOccurredTextSize = (unsigned int)buffer[iOffset];
	if(AlarmHistoryEventTbl->iOccurredTextSize > 0){
		iOffset++;
		AlarmHistoryEventTbl->cOccurredTextContents = (char *)(buffer + iOffset);
		iOffset += AlarmHistoryEventTbl->iOccurredTextSize;
	}else
		iOffset++;

	if((AlarmHistoryEventTbl->iDispStyle & 0x02) == 0x02){
		iRstContents[0] = (unsigned int)(buffer[iOffset] & 0x80);
		iRstContents[1] = (unsigned int)(buffer[iOffset] & 0x40);
		iRstContents[2] = (unsigned int)(buffer[iOffset] & 0x20);
		iRstContents[3] = (unsigned int)(buffer[iOffset] & 0x10);

		iRstContents[4] = (unsigned int)(buffer[iOffset] & 0x08);
		iRstContents[5] = (unsigned int)(buffer[iOffset] & 0x04);
		iRstContents[6] = (unsigned int)(buffer[iOffset] & 0x02);
		iRstContents[7] = (unsigned int)(buffer[iOffset] & 0x01);

		AlarmHistoryEventTbl->iRestorationInfo = iRstContents[7] + iRstContents[6];
		AlarmHistoryEventTbl->iRestorationDateInfo = iRstContents[3] + iRstContents[4];
		AlarmHistoryEventTbl->iRestorationTimeInfo = iRstContents[0] + iRstContents[1];
		/*
		iRstTotalInfo				iRstDateInfo				iRstTimeInfo			
		0x00 : Date, Time			0x00 : YY/MM/DD				0x00 : HH:MM:SS
		0x01 : Date					0x08 : MM/DD/YY				0x40 : HH:MM
		0x02 : Time					0x16 : DD/MM/YY
		0x03 : String				0x24 : MM/DD
		*/
		AlarmHistoryEventTbl->iRestorationColor = (unsigned int)buffer[++iOffset];
		AlarmHistoryEventTbl->iRestorationWide = (unsigned int)buffer[++iOffset];/*38*/
		AlarmHistoryEventTbl->iRestoredTitleSize = (unsigned int)buffer[++iOffset];

		if(AlarmHistoryEventTbl->iRestoredTitleSize > 0){
			iOffset++;
			AlarmHistoryEventTbl->cRestoredTitleContents = (char *)(buffer + iOffset);
			iOffset += AlarmHistoryEventTbl->iRestoredTitleSize;
			iOffset--;
		}

		AlarmHistoryEventTbl->iRestoredTextSize = (unsigned int)buffer[++iOffset];
		if(AlarmHistoryEventTbl->iRestoredTextSize > 0){
			iOffset++; 
			AlarmHistoryEventTbl->cRestoredTextContents = (char *)(buffer + iOffset);
			iOffset += AlarmHistoryEventTbl->iRestoredTextSize;
/* 060926			iOffset--;*/
		}else{				/* 060926 */
			iOffset++;		/* 060926 */
		}
	}
	if((AlarmHistoryEventTbl->iDispStyle & 0x04) == 0x04)
	{
		/* Frequence */
		AlarmHistoryEventTbl->iFreqTitleSize = (unsigned int)buffer[++iOffset];
/* 060926		iOffset++;*/
		if(AlarmHistoryEventTbl->iFreqTitleSize > 0){
			AlarmHistoryEventTbl->cFreqTitleContents = (char *)(buffer + iOffset);
			iOffset += AlarmHistoryEventTbl->iFreqTitleSize;
		}
	}
	return(0);
}

/********************************************************************************/
/* �� �� �� : AlarmHistoryDispWatch												*/
/* ��    �� : AlarmHistory�±������� ���� ȭ������� ���.						*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 28�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void AlarmHistoryDispWatch(int iOrder)
{		
/*	T_MAIL			*mp;*/
	int				j;
	int				sX;
	int				sY;
	int				eX;
	int				eY;
	short			iCnt;
	short			iDispCnt;
	char*			cDispBuffer;		/* ��¿���� */	
	int				iFontSizeV;
	int				iFontSizeH;
	int				iDispColor;
	int				Back_Color;	
	int				T_Type;
	int				iNum;
	char			cRetVal[3];
	char			cCommentName[12];
	short			iShapeSize;
	DEV_DATA		AlarmHistoryWriteDev;
//	unsigned char	*buffer;
	_ALARM_HISTORY_EVENT_TBL*		AlarmHistoryEventTbl;
	_LINE_INFO						param;
	int				iwColor,iwBack;

	AlarmHistoryEventTbl= (_ALARM_HISTORY_EVENT_TBL*)TakeMemory(sizeof(_ALARM_HISTORY_EVENT_TBL));
	DrawAlarmHistory_Func (AlarmHistoryEventTbl, iOrder);

//	buffer= ScreenTagData[iOrder].TagPos;
	iCnt = 0;
	iDispCnt = 0;

	memset(cCommentName, 0x00, sizeof(cCommentName));
	memset(cRetVal,0x00,sizeof(cRetVal));
	iFontSizeH = AlarmHistoryEventTbl->iFontSizeH;
	iFontSizeV = AlarmHistoryEventTbl->iFontSizeV;
	sX = ScreenTagData[iOrder].sX;
	sY = ScreenTagData[iOrder].sY;
	eX = ScreenTagData[iOrder].eX;
	eY = ScreenTagData[iOrder].eY;

		if(iMainKeyCode != 0x0000){
			switch(iMainKeyCode){ 
				case C_AP:		/* ����ǥ�� */
					iHistoryOnOff = 1;
					iHistoryPositionVal = 0;
					break;
				
				case C_DAP:		/* �����Ұ� */
					iHistoryOnOff = 0;
					iHistoryPositionVal = 0;
					break;
				
				case UP_DISP:		/* ��������� �̵� */
					if(iHistoryPositionVal == 0 && iHistoryDisCnt > 0 && iHistoryOnOff == 1)
						iHistoryDisCnt--;
					if(iHistoryPositionVal > 0)
						iHistoryPositionVal--;
					break;
				
				case DOWN_DISP:		/* ��������� �̵� */
					if(iHistoryPositionVal == (AlarmHistoryEventTbl->iDispRows-1) && 
						iHistoryDisCnt < (CommonArea.EntryCnt-AlarmHistoryEventTbl->iDispRows) && 
						iHistoryOnOff == 1)

						iHistoryDisCnt++;/* ������ ���� */

					if(((iHistoryPositionVal+1) < AlarmHistoryEventTbl->iDispRows) && ((iHistoryPositionVal+1+iHistoryDisCnt) < CommonArea.EntryCnt))
						iHistoryPositionVal++; /* ���� ��ġ ���� */
					break;
				case S_A_E:
					if(iHistoryOnOff == 1){
						if(CommonArea.EntryCnt>0){
							iNum = iHistoryPositionVal+iHistoryDisCnt;
/**********************************/
							if(AlarmHistoryEventTbl->iSortInfomation == 0x02)
								iNum = CommonArea.EntryCnt-iNum-1; 
/**********************************/
							SendTimeAction(8,iNum,0,0);	/* AlarmHistory Select One Line Dll */
							if((CommonArea.EntryCnt < (iHistoryPositionVal+1)|| CommonArea.EntryCnt == (iHistoryDisCnt+iHistoryPositionVal)) && iHistoryPositionVal>0)
								iHistoryPositionVal--;
							else if(CommonArea.EntryCnt == iHistoryDisCnt && iHistoryDisCnt>0)
								iHistoryDisCnt--;
						}
					}
					break;
				case A_A_E:					/* AlarmHistory Dll */
					SendTimeAction(7,0,0,0);
					break;
				case DETAIL:
					if(iHistoryOnOff == 1 && CommonArea.EntryCnt > 0){
						if(AlarmHistoryEventTbl->iSortInfomation == 0x02){
							iNum = AlarmHistItem->iDisplayNo[CommonArea.AlarmHistRec[CommonArea.EntryCnt - (iHistoryPositionVal+iHistoryDisCnt)-1].DevNo];
						}else{
							iNum = AlarmHistItem->iDisplayNo[CommonArea.AlarmHistRec[iHistoryPositionVal+iHistoryDisCnt].DevNo];
						}
						if(CommonArea.SystemDev.iDetailDisp == 2 && ComWinKey.iVal == 0 && CommonArea.EntryCnt > 0)			/* Comment Window display */
						{
							if(iCommentPointOnOff(iNum) > -1)
							{
								SendInitTask(INI_COMMENT,iNum);
							}
						}
						else if(CommonArea.SystemDev.iDetailDisp == 3)		/* Base screen ȭ�� �̵� */
						{	
							if(CheckSecurityLevel(iNum) == 0){
								AlarmHistoryWriteDev.DevFlag = 1;	
								AlarmHistoryWriteDev.DevName[0] = CommonArea.SystemDev.Switch_Base_DevName[0];
								AlarmHistoryWriteDev.DevName[1] = CommonArea.SystemDev.Switch_Base_DevName[1];
								AlarmHistoryWriteDev.DevName[2] = 0x00;
								AlarmHistoryWriteDev.DevAddress = CommonArea.SystemDev.Switch_Base_DevAdd;
								AlarmHistoryWriteDev.DevCnt = 1;
								AlarmHistoryWriteDev.DevData = cRetVal;
								memset(cRetVal,0x00,sizeof(cRetVal));
								//061124
//								cRetVal[1] = (iNum >> 8) & 0xff;
//								cRetVal[0] = iNum & 0xff;
								cRetVal[0] = (iNum >> 8) & 0xff;
								cRetVal[1] = iNum & 0xff;
								iPreviousScreenNum = iNowScreenNum;
								PLCWrite(&AlarmHistoryWriteDev); 
							}else{	/* Password Input 050425 */
								PassWordSettingFg= iNum;
								PassWordSettingChg= 1;
								iPassFlag = 2;		/* 050719 for CLR */
							}
						}
					}
					break;
				
				case RESET:		/* Device Reset�� ���� �Ǿ��ִ� ����̽��� ������. */
					if(iHistoryOnOff == 1){
						iNum = iHistoryPositionVal+iHistoryDisCnt;
						
						if(CommonArea.ResetCheck[CommonArea.AlarmHistRec[iNum].DevNo] == CHECKED)
						{
							/* Form->Sort : 0x01 : Oldest,	0x02 : Latest */
							if(AlarmHistoryEventTbl->iSortInfomation == 0x02)
								iNum = CommonArea.EntryCnt-iNum-1; 
							SendTimeAction(9,iNum,0,0);
						}
					}
					break;
			}
			iMainKeyCode = 0x0000;
		}
		if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){
			iShapeSize = DrawShape(AlarmHistoryEventTbl->ShapeNo, 
				sX, 
				sY, 
				eX, 
				eY, 
				AlarmHistoryEventTbl->iFrameColor,
				AlarmHistoryEventTbl->iPlateColor);
			sX = sX + iShapeSize;
			sY = sY + iShapeSize;
			eX -= iShapeSize;
			eY -= iShapeSize;
		}
			iDispCnt =	AlarmHistoryEventTbl->iRestorationWide + 
					AlarmHistoryEventTbl->iOccurredWide +
					AlarmHistoryEventTbl->iMessageWide + 1;
		if((AlarmHistoryEventTbl->iDispStyle & 0x04) == 0x04)	/* Occur frequency */
			iDispCnt+=5;
		cDispBuffer = (char*)TakeMemory(512);	/* 40->512 060926 */
		memset(cDispBuffer,0x00,512);			/* 40->512 060926 */
		memset(cDispBuffer,' ',iDispCnt-1);

		memcpy(cDispBuffer,
				AlarmHistoryEventTbl->cOccurredTitleContents,
				AlarmHistoryEventTbl->iOccurredTitleSize);

		iCnt =	AlarmHistoryEventTbl->iOccurredWide+1;
		memcpy(cDispBuffer+iCnt,
				AlarmHistoryEventTbl->cMsgTitleContents,
				AlarmHistoryEventTbl->iMessgaeTitleSize);

		if((AlarmHistoryEventTbl->iDispStyle & 0x02) == 0x02){	/* Restorations */
			iCnt += AlarmHistoryEventTbl->iMessageWide + 1;
			memcpy(cDispBuffer+iCnt,
					AlarmHistoryEventTbl->cRestoredTitleContents,
					AlarmHistoryEventTbl->iRestoredTitleSize);
		}
		if((AlarmHistoryEventTbl->iDispStyle & 0x04) == 0x04){ /* Occur frequency */
			if((AlarmHistoryEventTbl->iDispStyle & 0x02) == 0x02){	/* Restorations *//* 060926 */
				iCnt += AlarmHistoryEventTbl->iRestorationWide+1;
			}else{													/* 060926 */
				iCnt += AlarmHistoryEventTbl->iMessageWide + 1;		/* 060926 */
			}														/* 060926 */
			memcpy(cDispBuffer+iCnt,
					AlarmHistoryEventTbl->cFreqTitleContents,
					AlarmHistoryEventTbl->iFreqTitleSize);
		}
		if(AlarmHistoryEventTbl->iTitleColor == 0){
			Back_Color	= WHITE;	
			T_Type		= T_FRONT;
		}else{
			Back_Color = BLACK;
			T_Type      = T_OR;
		}
		DotTextOut(sX,
				sY, 
				cDispBuffer, 
				iFontSizeH, 
				iFontSizeV, 
				T_Type,
				AlarmHistoryEventTbl->iTitleColor,
				Back_Color);
/*		param.iLineColor = WHITE;*/
		param.iLineColor = AlarmHistoryEventTbl->iTitleColor;
		param.iLineStyle = SOLID_LINE;
		if(iFontSizeH == 0 || iFontSizeV == 0){
			LineOut(sX, (sY + 8), eX, (sY + 8),&param);
		}else{
			LineOut(sX, (sY + (iFontSizeV*16)), eX, (sY + (iFontSizeV*16)),&param);
		}
		sY+=1;
		/* leesi 04/06/10 */
		if(CommonArea.EntryCnt == 0)
		{
			iHistoryDisCnt = 0;
			iHistoryPositionVal = 0;
		}

		for(j=0;j<CommonArea.EntryCnt;j++){
			memset(cDispBuffer,0x00,40);

				/* Form->Sort : 0x01 : Oldest,	0x02 : Latest */
			if(AlarmHistoryEventTbl->iSortInfomation == 0x01)
				iCnt = j + iHistoryDisCnt;
			else
				iCnt = (CommonArea.EntryCnt-1) - (j + iHistoryDisCnt);
			vHistoryDataSet(AlarmHistoryEventTbl, iCnt, cDispBuffer, iOrder);
			if(strlen(cDispBuffer) == 0)
				continue;

			if(iFontSizeH == 0 || iFontSizeV == 0){
				sY = (sY + 8);
			}else{
				sY = (sY + (iFontSizeV*16));
			}

			iDispColor = AlarmHistoryEventTbl->iOccurredColor;

			if(iDispColor == 0){
/* 060311				Back_Color	= WHITE;	*/
				T_Type		= T_FRONT;
			}else{
/* 060311				Back_Color = BLACK;*/
				T_Type      = T_OR;
			}
			Back_Color= AlarmHistoryEventTbl->iPlateColor;	/* 060204 */
			/* Area Clear 040605 */
			if(iFontSizeH == 0 || iFontSizeV == 0)
			{
				eY = (sY + 8)-1;
			}else
			{
				eY = (sY + (iFontSizeV*16))-1;
			}
/* 050426			AreaClear(sX,sY,eX,eY,Back_Color);*/
			/**************/
			DotTextOut(sX,
					sY, 
					cDispBuffer, 
					iFontSizeH, 
					iFontSizeV, 
					T_Type,
					iDispColor,
					Back_Color);

			if(iHistoryOnOff == 1 && iHistoryPositionVal == j)
			{
				if(AlarmHistoryEventTbl->iPlateColor == iDispColor){
					if(iDispColor == BLACK){
/*						iwColor= BLACK;
						iwBack= WHITE;
*/
						iwColor= WHITE;
						iwBack= BLACK;
					}else{
/*						iwColor= WHITE;
						iwBack= BLACK;
*/
						iwColor= BLACK;
						iwBack= WHITE;
					}
					T_Type      = T_FRONT;
					DotTextOut(sX,
							sY, 
							cDispBuffer, 
							iFontSizeH, 
							iFontSizeV, 
							T_Type,
							iwColor,
							iwBack);
				}
				if(iFontSizeH == 0 || iFontSizeV == 0)
				{
					eY = (sY + 8)-1;
				}else
				{
					eY = (sY + (iFontSizeV*16))-1;
				}
				AreaRevers(sX,sY,eX,eY);
			}
			if(j >= AlarmHistoryEventTbl->iDispRows-1)
				break;
			if(j+1 >= (CommonArea.EntryCnt-iHistoryDisCnt))
				break;
		}
		FreeMail((char *)cDispBuffer);
		FreeMail((char *)AlarmHistoryEventTbl);
}

/********************************************************************************/
/* �� �� �� : CommonFileSet														*/
/* ��    �� : Common���� ���������� �̾Ƴ���.									*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 28�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void CommonFileSet(void)
{
	int				iPos;
	int				iSize;
	int				i;
	int				k;
	int				iDevAddress;
	unsigned int	iOffset;
	unsigned int	iOffsetbuf;
	unsigned char*	cTempBuffer;
	int				iCnt;
	int				iTemp;
	int				iDataSize;
	int				iFOffset;
	unsigned int	iFOffsetVal;
	int				iOnOffFlag;
	int				iTimeSetData;
	short			UninitializeFlag;
	short			iHistStoreChkFlag;
	short			iHistEraseChkFlag;
	DEV_DATA		WriteDev;
	char			cRetVal[3];	
	short			UtilityCnt;
	short			iMax;
//	short			iBuffer;
	/*
	#define SWITCHING_SCREEN_DEVICE	0x11
	#define PASSWORD				0x12
	#define BARCODE					0x13
	#define SYSTEM_INFOMATION		0x14
	#define TIME_ACTION				0x15
	#define ALARM_HISTORY_COMMON	0x16
	#define FLOATING_ALARM			0x17
	#define RECIPE					0x18
	#define UTILITY					0x19
	*/

	iPos				= 0;
	iSize				= 0;
	i					= 0;
	k					= 0;
	iDevAddress			= 0;
	iCnt				= 0;
	iTemp				= 0;
	iDataSize			= 0;
	iFOffset			= 0;
	iOnOffFlag			= 0;
	iTimeSetData		= 0;
	UninitializeFlag	= 0;
	iHistStoreChkFlag	= 0;
	iHistEraseChkFlag	= 0;
	UtilityCnt			= 0;
	iMax				= 0;
//	iBuffer				= 0;
	iFOffsetVal			= 0;
	iOffset				= 0;
	iOffsetbuf			= 0;

	if(mfileserch("COMMON.GP",&iPos,&iSize) == OK){

/*		cTempBuffer = (unsigned char*)TakeMemory(iSize + 1);*/
/*		memset(cTempBuffer, 0x00, iSize + 1);*/
/*		memcpy(cTempBuffer, (char *)iPos, iSize);*/
		cTempBuffer= (unsigned char *)iPos;
		iCnt = (unsigned int)cTempBuffer[26];
		/*************************************************************/
		/*iOffset�� 20�� ���� ���� ������ (Edit���� PLC_TYPE�� ����.)*/
		/*************************************************************/
		iOffset = 28;
		if(iCnt > 0){
			CommonArea.UtilityLevel[30] = 0;
			i = 0;
			while(i < iCnt){			
				if((unsigned int)cTempBuffer[iOffset] == SWITCHING_SCREEN_DEVICE){				
					iDataSize  =  (int) (cTempBuffer[++iOffset] << 24);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 16) & 0xffffff);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 8) & 0xffff);
					iDataSize +=  (int)  cTempBuffer[++iOffset] & 0xff;
					/* �ʿ��� ������ �����ϴ� �κп� ���� �ڵ��� �߰��� ��, �Ʒ� Offset�� �����ϴ� �κ��� ���� �� */
				/*	iOffset += iDataSize - 4;*/
					for(k=0; k<3; k++)
					{
						iTemp=(2-k)+(5*k);
						iOnOffFlag = (int)  cTempBuffer[++iOffset] & 0xff;	
						if(iOnOffFlag == 0xff || k==0)
						{
							iFOffset = iOffset + iTemp;
							iFOffset++;
							if(k==0)
							{
								UninitializeFlag = iOnOffFlag;/* Uninitialize üũ�� ����Ʈ������ ���� ����. (check : 0xff) k==0 �� ��*/

								/*------------------------------------------------------------*/
								GetDeviceSet((cTempBuffer+iFOffset),
											CommonArea.SystemDev.Switch_Base_DevName,
											&(iDevAddress));
								CommonArea.SystemDev.Switch_Base_DevAdd = iDevAddress;
								/*-------------------------------------------------------------*/

							}
							else if(k==1)
							{
								/*------------------------------------------------------------*/
								GetDeviceSet((cTempBuffer+iFOffset),
											CommonArea.SystemDev.Switch_Over1_DevName,
											&(iDevAddress));
								CommonArea.SystemDev.Switch_Over1_DevAdd = iDevAddress;
								/*-------------------------------------------------------------*/

							}
							else if(k==2)
							{
								/*------------------------------------------------------------*/
								GetDeviceSet((cTempBuffer+iFOffset),
											CommonArea.SystemDev.Switch_Over2_DevName,
											&(iDevAddress));
								CommonArea.SystemDev.Switch_Over2_DevAdd = iDevAddress;
								/*-------------------------------------------------------------*/

							}
/* 060926							iDeviceOffset+=2; */
							
						}

					}
//2011.12.05					if(iTransFlag == 0 && UninitializeFlag != 0xff){
					if((iTransFlag == 0) || (iTransFlag == 2)){			//2011.12.07
						WriteDev.DevFlag = 1;	
						WriteDev.DevName[0] = CommonArea.SystemDev.Switch_Base_DevName[0];
						WriteDev.DevName[1] = CommonArea.SystemDev.Switch_Base_DevName[1];
						WriteDev.DevName[2] = 0x00;
						WriteDev.DevAddress = CommonArea.SystemDev.Switch_Base_DevAdd;
						WriteDev.DevCnt = 1;
						WriteDev.DevData = cRetVal;
						//061124
//						memset(cRetVal,0x00,sizeof(cRetVal));
//						cRetVal[0] = 0x01;
//						cRetVal[1] = 0x00;
//						cRetVal[2] = 0x00;
						if(UninitializeFlag != 0xff){
							cRetVal[1] = 0x01;
							cRetVal[0] = 0x00;
						//061124
#ifdef	WIN32
							CommonArea.SwitchingData[0] = 0x0100;
#else
							CommonArea.SwitchingData[0] = 0x0001;
#endif
							iNowScreenNum = 1;
						}else{																//2011.12.07
#ifdef	WIN32
							iNowScreenNum = ((CommonArea.SwitchingData[0] >> 8) & 0xff);			//2011.12.07
							iNowScreenNum += ((CommonArea.SwitchingData[0] & 0xff) << 8);			//2011.12.07
#else
							iNowScreenNum= CommonArea.SwitchingData[0];			//2011.12.07
#endif
							cRetVal[1] = iNowScreenNum & 0xff;					//2011.12.07
							cRetVal[0] = (iNowScreenNum >> 8) & 0xff;			//2011.12.07
						}
						PLCWrite(&WriteDev); 
						if(strlen(CommonArea.SystemDev.Switch_Over1_DevName) != 0){
							WriteDev.DevFlag = 1;	
							WriteDev.DevName[0] = CommonArea.SystemDev.Switch_Over1_DevName[0];
							WriteDev.DevName[1] = CommonArea.SystemDev.Switch_Over1_DevName[1];
							WriteDev.DevName[2] = 0x00;
							WriteDev.DevAddress = CommonArea.SystemDev.Switch_Over1_DevAdd;
							WriteDev.DevCnt = 1;
							WriteDev.DevData = cRetVal;
//							memset(cRetVal,0x00,sizeof(cRetVal));
/*
							cRetVal[0] = (char)0xFF;
							cRetVal[1] = (char)0xFF;
*/
							if(UninitializeFlag != 0xff){
								cRetVal[0] = (char)0x00;	/*0xff -> 0x00 change Autonic 040524 leesi */
								cRetVal[1] = (char)0x00;	/*0xff -> 0x00 change Autonic 040524 leesi */
								iSwitch_ScreenNum1 =-1;
								CommonArea.SwitchingData[1] = 0x0000;
							}else{
#ifdef	WIN32
								iSwitch_ScreenNum1 = ((CommonArea.SwitchingData[1] >> 8) & 0xff);	//2011.12.07
								iSwitch_ScreenNum1 += ((CommonArea.SwitchingData[1] & 0xff) << 8);	//2011.12.07
#else
								iSwitch_ScreenNum1= CommonArea.SwitchingData[1];					//2011.12.07
#endif
								cRetVal[1] = iSwitch_ScreenNum1 & 0xff;								//2011.12.07
								cRetVal[0] = (iSwitch_ScreenNum1 >> 8) & 0xff;						//2011.12.07
							}
							PLCWrite(&WriteDev); 
						}
						if(strlen(CommonArea.SystemDev.Switch_Over2_DevName) != 0){

							WriteDev.DevFlag = 1;	
							WriteDev.DevName[0] = CommonArea.SystemDev.Switch_Over2_DevName[0];
							WriteDev.DevName[1] = CommonArea.SystemDev.Switch_Over2_DevName[1];
							WriteDev.DevName[2] = 0x00;
							WriteDev.DevAddress = CommonArea.SystemDev.Switch_Over2_DevAdd;
							WriteDev.DevCnt = 1;
							WriteDev.DevData = cRetVal;
//							memset(cRetVal,0x00,sizeof(cRetVal));
/*
							cRetVal[0] = (char)0xFF;
							cRetVal[1] = (char)0xFF;
*/
							if(UninitializeFlag != 0xff){
								cRetVal[0] = (char)0x00;	/*0xff -> 0x00 change Autonic 040524 leesi */
								cRetVal[1] = (char)0x00;	/*0xff -> 0x00 change Autonic 040524 leesi */
								iSwitch_ScreenNum2 = -1;
								CommonArea.SwitchingData[2] = 0x0000;
							}else{
#ifdef	WIN32
								iSwitch_ScreenNum2 = ((CommonArea.SwitchingData[2] >> 8) & 0xff);
								iSwitch_ScreenNum2 += ((CommonArea.SwitchingData[2] & 0xff) << 8);
#else
								iSwitch_ScreenNum2= CommonArea.SwitchingData[2];
#endif
								cRetVal[1] = iSwitch_ScreenNum2 & 0xff;
								cRetVal[0] = (iSwitch_ScreenNum2 >> 8) & 0xff;
							}
							PLCWrite(&WriteDev); 
						}
					}
					iOffset += (iDataSize-7);
				}
				else if((unsigned int)cTempBuffer[iOffset] == PASSWORD){
					iDataSize  =  (int) (cTempBuffer[++iOffset] << 24);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 16) & 0xffffff);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 8) & 0xffff);
					iDataSize +=  (int)  cTempBuffer[++iOffset] & 0xff;
				

					iOffsetbuf = iOffset;
					CommonArea.SystemDev.DispPassinputchk = cTempBuffer[++iOffsetbuf];		/* Display password input error�� Check Flag(check : 0xFF, Uncheck : 0x00)*/
					if(0xFF == cTempBuffer[++iOffsetbuf]){			/* Level device�� Check Flag */
						/*------------------------------------------------------------*/
						++iOffsetbuf;
						GetDeviceSet((cTempBuffer+iOffsetbuf),
									CommonArea.SystemDev.Password_Dev.DevName,
									&(iDevAddress));
						CommonArea.SystemDev.Password_Dev.DevAdd = iDevAddress;
						iOffsetbuf+=4;
						/*-------------------------------------------------------------*/

						CommonArea.SystemDev.Password_Dev.DevCnt	=	1;

/*lsi20040524 �߰� */
						/* 040424 leesi  Autonics Download Pass Device data clear */
						if(iTransFlag == 0)	/* �ٿ�ε� �� ��� */
						{	
							WriteDev.DevFlag = 1;	
							WriteDev.DevName[0] = CommonArea.SystemDev.Password_Dev.DevName[0];
							WriteDev.DevName[1] = CommonArea.SystemDev.Password_Dev.DevName[1];
							WriteDev.DevName[2] = 0x00;
							WriteDev.DevAddress = CommonArea.SystemDev.Password_Dev.DevAdd;
							WriteDev.DevCnt = 1;
							WriteDev.DevData = cRetVal;
							memset(cRetVal,0x00,sizeof(cRetVal));
//							cRetVal[0] = (char)0x00;
//							cRetVal[1] = (char)0x00;
//							cRetVal[2] = 0x00;
							PLCWrite(&WriteDev); 
						}
						/* -------------------------------------------------------- */
/*lsi20040524*/						
						
					}
					else{
						iOffsetbuf += 5;
					}
					/* memcpy(.DataTrans,cTempBuffer[++iOffsetbuf],16);*/   /*Project�� �̵�*/
					iOffsetbuf += 16;
					iTemp = (int)cTempBuffer[++iOffsetbuf];
					for(k=0;k<iTemp;k++){
						iSize = (cTempBuffer[++iOffsetbuf])-1;
						iOffsetbuf++;
#ifdef	PASSWORD_NO_CHANGE
						memcpy(CommonArea.SystemDev.Password[iSize],(cTempBuffer+iOffsetbuf),8);	/* 20081023 */
#else
						memcpy(CommonArea.SystemDev.Password[iSize],(cTempBuffer+iOffsetbuf),15);
#endif
						iOffsetbuf += 15;
					}
/*
					iPassLevel = 0;  Pass Level �ʱ�ȭ 					
*/
/*lsi20040524 ���� */
					if(iTransFlag != 2)
					{
						iPassLevel = 0; 	/* Pass Level �ʱ�ȭ */	
						CommonArea.PassWordDevData[0] = 0x00;
					}
					else{
/* 050428						iPassLevel = (short)CommonArea.PassWordDevData[0];*/
						iPassLevel = 0; 	/* Pass Level �ʱ�ȭ */	
						CommonArea.PassWordDevData[0] = 0x00;
					}
/*lsi20040524*/

					/* �ʿ��� ������ �����ϴ� �кп� ���� �ڵ��� �߰��� ��, �Ʒ� Offset�� �����ϴ� �κ��� ���� �� */

					iOffset += iDataSize - 4;
				}
				else if((unsigned int)cTempBuffer[iOffset] == BARCODE){
					iDataSize  =  (int) (cTempBuffer[++iOffset] << 24);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 16) & 0xffffff);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 8) & 0xffff);
					iDataSize +=  (int)  cTempBuffer[++iOffset] & 0xff;
					
					
					iOffsetbuf = iOffset;

					/*------------------------------------------------------------*/
					++iOffsetbuf;
					GetDeviceSet((cTempBuffer+iOffsetbuf),
								CommonArea.SystemDev.Barcode_Dev.DevName,
								&(iDevAddress));
					CommonArea.SystemDev.Barcode_Dev.DevAdd = iDevAddress;
					iOffsetbuf+=4;
					/*-------------------------------------------------------------*/

					CommonArea.SystemDev.Barcode_Dev.DevCnt	=	(cTempBuffer[++iOffsetbuf] << 0x08);
					CommonArea.SystemDev.Barcode_Dev.DevCnt	+=	(cTempBuffer[++iOffsetbuf] & 0xff);
					

					/* �ʿ��� ������ �����ϴ� �кп� ���� �ڵ��� �߰��� ��, �Ʒ� Offset�� �����ϴ� �κ��� ���� �� */	
					iOffset += iDataSize - 4;
				}
				else if((unsigned int)cTempBuffer[iOffset] == SYSTEM_INFOMATION){
					iDataSize  =  (int) (cTempBuffer[++iOffset] << 24);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 16) & 0xffffff);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 8) & 0xffff);
					iDataSize +=  (int)  cTempBuffer[++iOffset] & 0xff;
					
					iOffsetbuf = iOffset;
					iTemp = cTempBuffer[++iOffsetbuf];

					/*------------------------------------------------------------*/
					++iOffsetbuf;
					GetDeviceSet((cTempBuffer+iOffsetbuf),
								CommonArea.SystemDev.Read_Dev.DevName,
								&(iDevAddress));
					CommonArea.SystemDev.Read_Dev.DevAdd = iDevAddress;
					iOffsetbuf+=4;
					/*-------------------------------------------------------------*/

					if(iTemp == 0xff)
						CommonArea.SystemDev.Read_Dev.DevCnt = 2;
					else
						CommonArea.SystemDev.Read_Dev.DevCnt = 1;

					/*------------------------------------------------------------*/
					++iOffsetbuf;
					GetDeviceSet((cTempBuffer+iOffsetbuf),
								CommonArea.SystemDev.Write_Dev.DevName,
								&(iDevAddress));
					CommonArea.SystemDev.Write_Dev.DevAdd = iDevAddress;
					iOffsetbuf+=4;
					/*-------------------------------------------------------------*/

/*					if(strlen(CommonArea.SystemDev.Write_Dev.DevName)!=0)*/
/*					{*/
					//061124
//						InDevArea.UB[INDEV_WRITE+0] = 0x01;
//						InDevArea.UB[INDEV_WRITE+1] = 0x00;
//						InDevArea.UB[INDEV_WRITE+2] = 0xff;
//						InDevArea.UB[INDEV_WRITE+3] = 0xff;
//						InDevArea.UB[INDEV_WRITE+4] = 0xff;
//						InDevArea.UB[INDEV_WRITE+5] = 0xff;
						InDevArea.UW[INDEV_WRITE+0] = 0x0001;
						InDevArea.UW[INDEV_WRITE+1] = 0xffff;
						InDevArea.UW[INDEV_WRITE+2] = 0xffff;
						SendTimeAction(10,0,0,0);
/*					}*/
					/* �ʿ��� ������ �����ϴ� �кп� ���� �ڵ��� �߰��� ��, �Ʒ� Offset�� �����ϴ� �κ��� ���� �� */
					iOffset += iDataSize - 4;
				}
				else if((unsigned int)cTempBuffer[iOffset] == TIME_ACTION){
					iDataSize  =  (int)(cTempBuffer[++iOffset] << 24);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 16) & 0xffffff);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 8) & 0xffff);
					iDataSize +=  (int)cTempBuffer[++iOffset] & 0xff;

					if(iTransFlag == 0){	
						iFOffsetVal = iOffset;
/*-----------------------------------------------------------------------------------------------*/						
						++iFOffsetVal;
						GetDeviceSet((cTempBuffer+iFOffsetVal),
									CommonArea.SystemDev.TimeSwitch_DevName,
									&(iDevAddress));
						CommonArea.SystemDev.TimeSwitch_DevAdd = iDevAddress;
						iFOffsetVal+=4;
/*-----------------------------------------------------------------------------------------------*/						

/* ksc20050805 Setting Area Copy - Common Area �ܿ� Setting �������� ī���ؼ� �÷����� ������. */
/* Time Switch Device Display */
/*-----------------------------------------------------------------------------------------------*/						
/*						Set.TimeSwitch_DevName[0] = CommonArea.SystemDev.TimeSwitch_DevName[0];	*/
/*						Set.TimeSwitch_DevName[1] = CommonArea.SystemDev.TimeSwitch_DevName[1];	*/
/*						Set.TimeSwitch_DevName[2] = CommonArea.SystemDev.TimeSwitch_DevName[2];	*/
/*						Set.TimeSwitch_DevAdd = CommonArea.SystemDev.TimeSwitch_DevAdd;			*/
/*-----------------------------------------------------------------------------------------------*/
						
						for(k=0;k<8;k++)
						{
							Set._TIMESWITCH[k].iWeek = cTempBuffer[++iFOffsetVal];
							if(Set._TIMESWITCH[k].iWeek == 0)
							{
								iFOffsetVal+=6;
								/* 041213 */
								memset(&Set._TIMESWITCH[k],0,sizeof(Set._TIMESWITCH[k]));
								continue;
							}

							CommonArea.SystemDev._TIMESWITCH[k].iWeek = Set._TIMESWITCH[k].iWeek;

							itoa(((int)cTempBuffer[++iFOffsetVal]),Set._TIMESWITCH[k].chSHour,10);
							iTimeSetData = ((int)cTempBuffer[iFOffsetVal]) * 3600;
							sprintf(Set._TIMESWITCH[k].chSMinute,"%02d",((int)cTempBuffer[++iFOffsetVal]));
							iTimeSetData += ((int)cTempBuffer[iFOffsetVal]) * 60;
							sprintf(Set._TIMESWITCH[k].chSSecond,"%02d",((int)cTempBuffer[++iFOffsetVal]));
							iTimeSetData += ((int)cTempBuffer[iFOffsetVal]);
							CommonArea.SystemDev._TIMESWITCH[k].StartTime  = iTimeSetData;

							itoa(((int)cTempBuffer[++iFOffsetVal]),Set._TIMESWITCH[k].chEHour,10);
							iTimeSetData = ((int)cTempBuffer[iFOffsetVal]) * 3600;
							sprintf(Set._TIMESWITCH[k].chEMinute,"%02d",((int)cTempBuffer[++iFOffsetVal]));
							iTimeSetData += ((int)cTempBuffer[iFOffsetVal]) * 60;
							sprintf(Set._TIMESWITCH[k].chESecond,"%02d",((int)cTempBuffer[++iFOffsetVal]));
							iTimeSetData += ((int)cTempBuffer[iFOffsetVal]);
							CommonArea.SystemDev._TIMESWITCH[k].EndTime  = iTimeSetData;
							CommonArea.SystemDev._TIMESWITCH[k].OnOffFlag = 0;
						}
					}
					/* �ʿ��� ������ �����ϴ� �κп� ���� �ڵ��� �߰��� ��, �Ʒ� Offset�� �����ϴ� �κ��� ���� �� */
					iOffset += iDataSize - 4;
				}
				else if((unsigned int)cTempBuffer[iOffset] == ALARM_HISTORY_COMMON){
					if((iAlarmHistFlag & 0x01) != 0){
						FreeMail((char*)AlarmHistItem);
						iAlarmHistFlag &= ~0x01;
					}
					if((iAlarmHistFlag & 0x02) != 0){
						FreeMail((char*)AlarmHistoryMainInfo);
						iAlarmHistFlag &= ~0x02;
					}

					AlarmHistoryMainInfo = (_ALARM_HISTORY_MAIN_INFO*)TakeMemory(sizeof(_ALARM_HISTORY_MAIN_INFO));
					iAlarmHistFlag |= 2;
					memset(AlarmHistoryMainInfo, 0x00, sizeof(AlarmHistoryMainInfo));

					iDataSize  =  (int)(cTempBuffer[++iOffset] << 24);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 16) & 0xffffff);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 8) & 0xffff);
					iDataSize +=  (int)cTempBuffer[++iOffset] & 0xff;
					iOffsetbuf = iOffset;
					AlarmHistoryMainInfo->iMode = (unsigned int)cTempBuffer[++iOffsetbuf];
						 
					CommonArea.SystemDev.Alarm_Dev.DevCnt  = (unsigned int)(cTempBuffer[++iOffsetbuf] << 0x08); /* Alarm ���� */
					CommonArea.SystemDev.Alarm_Dev.DevCnt += (unsigned int)cTempBuffer[++iOffsetbuf] & 0xff;

					CommonArea.SystemDev.Alarm_Time  = (unsigned int)(cTempBuffer[++iOffsetbuf] << 0x08);	/* Watch cycle */
					CommonArea.SystemDev.Alarm_Time += (unsigned int)cTempBuffer[++iOffsetbuf] & 0xff;

					CommonArea.SystemDev.iDetailDisp   = (unsigned int)cTempBuffer[++iOffsetbuf];			/* Detailed display (1 : No ,2 : Window ,3 : Base screen */
					
					if((int)cTempBuffer[++iOffsetbuf] == 0xff){
						iHistStoreChkFlag = CHECKED;
					}else{
						iHistStoreChkFlag = UNCHECKED;
					}

					if(iHistStoreChkFlag == CHECKED){


						/*------------------------------------------------------------*/
						++iOffsetbuf;
						GetDeviceSet((cTempBuffer+iOffsetbuf),
									CommonArea.SystemDev.Alarm_DevStore.DevName,
									&(iDevAddress));
						CommonArea.SystemDev.Alarm_DevStore.DevAdd = iDevAddress;
						iOffsetbuf+=4;
						/*-------------------------------------------------------------*/

					}else{
						memset(CommonArea.SystemDev.Alarm_DevStore.DevName, 0x00, 2);
						iOffsetbuf += 5;
					}

					if((int)cTempBuffer[++iOffsetbuf] == 0xff){
						iHistEraseChkFlag = CHECKED;
					}else{
						iHistEraseChkFlag = UNCHECKED;
					}

					if(iHistEraseChkFlag == CHECKED){
						/*------------------------------------------------------------*/
						++iOffsetbuf;
						GetDeviceSet((cTempBuffer+iOffsetbuf),
									CommonArea.SystemDev.Alarm_DevErase.DevName,
									&(iDevAddress));
						CommonArea.SystemDev.Alarm_DevErase.DevAdd = iDevAddress;
						iOffsetbuf+=4;
						/*-------------------------------------------------------------*/
					}else{
						memset(CommonArea.SystemDev.Alarm_DevErase.DevName, 0x00, 2);
						iOffsetbuf += 5;
					}
					if((int)cTempBuffer[++iOffsetbuf] == 0xff){
						AlarmHistoryMainInfo->iDelModeChkFlag = CHECKED;
					}else{
						AlarmHistoryMainInfo->iDelModeChkFlag = UNCHECKED;
					}
					/*------------------------------------------------------------*/
					++iOffsetbuf;
					GetDeviceSet((cTempBuffer+iOffsetbuf),
								CommonArea.SystemDev.Alarm_Dev.DevName,
								&(iDevAddress));
					CommonArea.SystemDev.Alarm_Dev.DevAdd = iDevAddress;
					iOffsetbuf+=4;
					/*-------------------------------------------------------------*/

					CommonArea.SystemDev.iCommentNo	 	    = (unsigned int)cTempBuffer[++iOffsetbuf];
					AlarmHistoryMainInfo->iDispNoSel		    = (unsigned int)cTempBuffer[++iOffsetbuf]; 
 					/*--------------------------------------------------*/
					/* ���� �����ͼ����� ���� �Ⱦ��� ��쿡�� �ٿ�ε尡 �Ǳ� ������ Ŭ���� ��. */
					if(strlen(CommonArea.SystemDev.Alarm_Dev.DevName)==0)
					{
						CommonArea.SystemDev.Alarm_Dev.DevCnt = 0;
					}
					/*--------------------------------------------------*/

					if(CommonArea.SystemDev.Alarm_Dev.DevCnt > 0){
						k=0;
						AlarmHistItem = (_ALARM_HIST_ITEM*)TakeMemory(sizeof(_ALARM_HIST_ITEM));
						iAlarmHistFlag |= 1;			
						while(k < CommonArea.SystemDev.Alarm_Dev.DevCnt){
							AlarmHistItem->iSunbun = k + 1;
							AlarmHistItem->iDisplayNo[k]  = (unsigned int)(cTempBuffer[++iOffsetbuf] << 0x08);
							AlarmHistItem->iDisplayNo[k] += (unsigned int)cTempBuffer[++iOffsetbuf] & 0xff;
							iTemp = (unsigned int)cTempBuffer[++iOffsetbuf];
							if(iTemp == 0xff){
								CommonArea.ResetCheck[k] = CHECKED;
							}
							else if(iTemp == 0x00){
								CommonArea.ResetCheck[k] = UNCHECKED;
							}
							k++;
						}
					}
					iOffset += iDataSize - 4;		/* iOffset += 3 */
				}
				else if((unsigned int)cTempBuffer[iOffset] == FLOATING_ALARM){
					iDataSize  =  (int) (cTempBuffer[++iOffset] << 24);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 16) & 0xffffff);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 8) & 0xffff);
					iDataSize +=  (int)  cTempBuffer[++iOffset] & 0xff;
					
					iOffsetbuf = iOffset;
					CommonArea.SystemDev.fAlarm_Dev.DevCnt =  (cTempBuffer[++iOffsetbuf]<<0x08);
					CommonArea.SystemDev.fAlarm_Dev.DevCnt += cTempBuffer[++iOffsetbuf] & 0xff;

					/*------------------------------------------------------------*/
					++iOffsetbuf;
					GetDeviceSet((cTempBuffer+iOffsetbuf),
								CommonArea.SystemDev.fAlarm_Dev.DevName,
								&(iDevAddress));
					CommonArea.SystemDev.fAlarm_Dev.DevAdd = iDevAddress;
					iOffsetbuf+=4;
					/*-------------------------------------------------------------*/

					CommonArea.SystemDev.CommentStartNo	=	(cTempBuffer[++iOffsetbuf] << 0x08);
					CommonArea.SystemDev.CommentStartNo	+=	(cTempBuffer[++iOffsetbuf] & 0xff);	
					CommonArea.SystemDev.fFont_V		= cTempBuffer[++iOffsetbuf];
					CommonArea.SystemDev.fFont_H		= cTempBuffer[++iOffsetbuf];
				
					/* �ʿ��� ������ �����ϴ� �кп� ���� �ڵ��� �߰��� ��, �Ʒ� Offset�� �����ϴ� �κ��� ���� �� */
					iOffset += iDataSize - 4;
				}
				else if((unsigned int)cTempBuffer[iOffset] == RECIPE){
					iDataSize  =  (int) (cTempBuffer[++iOffset] << 24);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 16) & 0xffffff);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 8) & 0xffff);
					iDataSize +=  (int)  cTempBuffer[++iOffset] & 0xff;

					iOffsetbuf = iOffset;
					CommonArea.SystemDev.RecipCnt =  cTempBuffer[++iOffsetbuf];
					CommonArea.SystemDev.RecipReadFlag = cTempBuffer[++iOffsetbuf];

					/*------------------------------------------------------------*/
					++iOffsetbuf;
					GetDeviceSet((cTempBuffer+iOffsetbuf),
								CommonArea.SystemDev.Recip_Read_DevName,
								&(iDevAddress));
					CommonArea.SystemDev.Recip_Read_DevAdd = iDevAddress;
					iOffsetbuf+=4;
					/*-------------------------------------------------------------*/

					CommonArea.SystemDev.RecipWriteFlag = cTempBuffer[++iOffsetbuf];

					/*------------------------------------------------------------*/
					++iOffsetbuf;
					GetDeviceSet((cTempBuffer+iOffsetbuf),
								CommonArea.SystemDev.Recip_Write_DevName,
								&(iDevAddress));
					CommonArea.SystemDev.Recip_Write_DevAdd = iDevAddress;
					iOffsetbuf+=4;
					/*-------------------------------------------------------------*/

					CommonArea.SystemDev.RecipPoint =  (cTempBuffer[++iOffsetbuf]<<0x08);
					CommonArea.SystemDev.RecipPoint += cTempBuffer[++iOffsetbuf] & 0xff;

					iOffsetbuf++;
					CommonArea.SystemDev.RecipStart =(unsigned char*) (iPos + iOffsetbuf);				/* Recip Start Address */
	/*				for(k=0;k<CommonArea.SystemDev.RecipCnt;k++){
						RecipeNameSize = cTempBuffer[++iOffsetbuf];
						
						iOffsetbuf  +=RecipeNameSize+1;
						iFOffsetVal = cTempBuffer[iOffsetbuf];
						iSOffsetVal = cTempBuffer[++iOffsetbuf];
						GetDeviceSet(iFOffsetVal, iSOffsetVal, cTempBuff);
						memcpy(CommonArea.SystemDev.Recip_Dev[k].DevName, cTempBuff, 2);
						CommonArea.SystemDev.Recip_Dev[k].DevAdd  = (cTempBuffer[++iOffsetbuf] << 0x08);
						CommonArea.SystemDev.Recip_Dev[k].DevAdd += (cTempBuffer[++iOffsetbuf] & 0xff);
					
						++iOffsetbuf;
						memcpy(InDevice+(CommonArea.SystemDev.RecipPoint*k*2),cTempBuffer+(++iOffsetbuf),(CommonArea.SystemDev.RecipPoint*2));
						iOffsetbuf += (CommonArea.SystemDev.RecipPoint*2);
					}*/
					
					/* �ʿ��� ������ �����ϴ� �кп� ���� �ڵ��� �߰��� ��, �Ʒ� Offset�� �����ϴ� �κ��� ���� �� */
					iOffset += iDataSize - 4;
				}
				else if((unsigned int)cTempBuffer[iOffset] == UTILITY){
					iDataSize  =  (int) (cTempBuffer[++iOffset] << 24);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 16) & 0xffffff);
					iDataSize +=  ((int)(cTempBuffer[++iOffset] << 8) & 0xffff);
					iDataSize +=  (int)  cTempBuffer[++iOffset] & 0xff;
					UtilityCnt =  (int)  cTempBuffer[++iOffset];
//					iBuffer	= 0;
					iMax	= 0;
					iOffset++;
					memcpy(CommonArea.UtilityLevel,(cTempBuffer+iOffset),UtilityCnt);
					for(k=0;k<UtilityCnt;k++)
					{
						if(iMax<CommonArea.UtilityLevel[k])
							iMax=CommonArea.UtilityLevel[k];
					}
					CommonArea.UtilityLevel[30] = (char)iMax;
					/* �ʿ��� ������ �����ϴ� �кп� ���� �ڵ��� �߰��� ��, �Ʒ� Offset�� �����ϴ� �κ��� ���� �� */
					iOffset += iDataSize - 4;
				}
				
				i++;
			}
		}
	}	
}
/********************************************************************************/
/* �� �� �� : ProjectSet														*/
/* ��    �� : ������Ʈ���� ���������� �̾Ƴ���.									*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 28�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
int ProjectSet(void)		/* 20090610 */
{
	int				iPos;
	int				iSize;
	int				iPort;
//	int				iType;
	int				iTemp;
	int				iDataSize;
	int				iOnOffFlag;
	int				iDevAddress;
	char			cTempBuff[3];
	char			ProjIDchk[5];
	short			k;
	unsigned int	iOffset;
//	unsigned int	iPlcCnt;
	unsigned char*	cTempBuffer;
	int			i,j;
	unsigned	int	StationInf;
	int			Kyokuban;
	int			KyokuCnt;
	int		EditSerealSetFlag = FALSE;			/* 20090610 */

	iPos		= 0;
	iSize		= 0;
	iDataSize	= 0;
	iTemp		= 0;
	iOnOffFlag	= 0;
	iOffset		= 0;
//	iPlcCnt		= 0;
	/* Project ȭ�Ͽ� ���� Data */
 	if(mfileserch("PROJECT.GP",&iPos,&iSize) == OK){
/*		cTempBuffer = (unsigned char*)TakeMemory(iSize + 1);		
		memset(cTempBuffer, 0x00, iSize + 1);
		memcpy(cTempBuffer, (char *)iPos, iSize);
*/
		cTempBuffer = (unsigned char *)iPos;
		iOffset = 7;
		memcpy(ProjIDchk,CommonArea.ProjID,4);
		memcpy(CommonArea.ProjID,cTempBuffer+iOffset,4);
		iOffset += 5;
		/*ALARMHISTORY ���� */
		if(strncmp(CommonArea.ProjID,ProjIDchk,4)!=0){
			CommonArea.SystemDev.AlarmSetFlag = 1;
			SendTimeAction(3,0,0,0);

		}
		iDataSize = (int)cTempBuffer[iOffset];		/* Project Title Size */
		iOffset += 34;

		iDataSize = (int)cTempBuffer[iOffset];		/* Project �󼼼��� Size */
		iDataSize += (int)cTempBuffer[++iOffset];		/* Project �󼼼��� Size */

		iOffset += (iDataSize + 2);

		iDataSize = (int)cTempBuffer[iOffset];		/* Project ���ڸ� Size */
		iOffset += (iDataSize + 1);
/*
		iDataSize = (int)cTempBuffer[iOffset];*/		/* PLCTYPE Size */
/*		iOffset += (iDataSize + 1);
*/
		
		iOffset++;
		if(memcmp(Set.cPlcTypeAdd, &cTempBuffer[iOffset],20) != 0){
			memcpy(Set.cPlcTypeAdd, &cTempBuffer[iOffset],20);
			mWriteSettei();			/* PlcType Write */
		}
		iOffset += 20;
		/*	PLCTYPE CODE 1Byte, PLCTYPE DATA 20Byte */
		

		CommonArea.PasswordOnOff=cTempBuffer[iOffset];
		iOffset++;
		memcpy(CommonArea.ProjPassword,&cTempBuffer[iOffset],16);			/* PASSWORD */
		iOffset+=16;/**/
		/****************************************************************/
		iOffset+=3; /* EDIT���� ��� (ACTIVE SCREEN KIND 1Byte,ACTIVE SCREEN NO 2Byte)*/
		/* GP GROUP CODE,PLC CODE 051109 */
		memcpy(Set.cPlcTypeCode,&cTempBuffer[iOffset],6);
		iOffset+=6;		/* GROUP CODE */
		iOffset+=6;		/* OLD TYPE SKIP COUNT */
		/*****************************���� �������� Ǯ�����.***********************************/
		CommonArea.ProjectAuxSet.OpenKeyWinCkeck = (int)cTempBuffer[++iOffset];/* 6 : Open key window at the same time (Check : 0xff, UnCheck : 0x00)			*/

		iOnOffFlag = (int)cTempBuffer[++iOffset];/* 7 : Use serial port, Setup, Language, Menu key(Check : 0xff Uncheck : 0x00)	*/

		CommonArea.ProjectAuxSet.DispCursorWindow = (int)cTempBuffer[++iOffset];/* 8 : Action when switching screens( Don't display cursor and key window : 0x00
										  Display cursor only : 0x01
										  Display cursor and key window : 0x02		*/
		CommonArea.ProjectAuxSet.DispFormat =!((int)cTempBuffer[++iOffset]);/* 9 : Screen format(vertical : 0x00, horizontal : 0x01) */
		CommonArea.KeyWindow.iDefault = (int)cTempBuffer[++iOffset];/* 10 : Key window setting(Use default key window : 0x00, Select key window sheet no : 0xff) */

		if(CommonArea.KeyWindow.iDefault == 0xff)
		{
			CommonArea.KeyWindow.iDecNo =  (int)(cTempBuffer[++iOffset] << 8);			/* 11 ~ 12 : DEC key sheet No */
			CommonArea.KeyWindow.iDecNo +=  (int)  cTempBuffer[++iOffset] & 0xff;

			CommonArea.KeyWindow.iHexNo =  (int)(cTempBuffer[++iOffset] << 8);			/* 13 ~ 14 : HEX key sheet No */
			CommonArea.KeyWindow.iHexNo +=  (int)  cTempBuffer[++iOffset] & 0xff;

			CommonArea.KeyWindow.iAsciiNo =  (int)(cTempBuffer[++iOffset] << 8);		/* 15 ~ 16 : ASCII key sheet No */
			CommonArea.KeyWindow.iAsciiNo +=  (int)  cTempBuffer[++iOffset] & 0xff;
		}else
		{
			iOffset += 6;
		}
		if(iOnOffFlag == 0xff && iTransFlag == 0)
		{
			EditSerealSetFlag = TRUE;		/* 20090610 */
/* 20060623 */
			//PLC Boadrate
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed =  (int)(cTempBuffer[++iOffset] << 8);	/* 17 ~ 18 : Serial Port Speed */
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed +=  (int)  cTempBuffer[++iOffset] & 0xff;

			Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2 = (int)cTempBuffer[++iOffset];			/* 19 : Serial Port Handshaking (XON/XOFF : 0x00, DSR/DTR : 0xFF) */
			if(Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2 == 0xff)
				Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2 = 1;
			
			Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity = (int)cTempBuffer[++iOffset];			/* 20 : Serial Port Parity(None : 0x00, Even : 0x01, Odd : 0x02) */
	
			if(Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity == 1)
				Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity = 2;
			else if(Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity == 2)
				Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity = 1;

			Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1 = (int)cTempBuffer[++iOffset];			/* 21 : Serial Port Data Bit(7Bit : 0x00, 8Bit : 0xFF)*/
			if(Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1 == 0xff)
				Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1 = 1;

			Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop = (int)cTempBuffer[++iOffset];			/* 22 : Serial Port Stop Bit(1Bit : 0x00, 2Bit : 0xFF)*/
			if(Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop == 0xff)
				Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop = 1;

			Set.iTitleDispTime = (int)cTempBuffer[++iOffset];	/*  23 : Opening Screen Time*/
			Set.iBackLightTime = (int)cTempBuffer[++iOffset];	/*  24 : Backlighy off Time */
			Set.OpenBaseNo= cTempBuffer[++iOffset]*256;
			Set.OpenBaseNo += cTempBuffer[++iOffset];
			iPort = (int)cTempBuffer[++iOffset];				/* 25 : Connection Port(RS232 : 0x00, RS422 : 0xFF)*/
//			iType = (int)cTempBuffer[++iOffset];				/* 26 : Connection Type(CPU : 0x00, LINK:0xFF)*/
			++iOffset;				/* 26 : Connection Type(CPU : 0x00, LINK:0xFF)*/

			if(iPort == 0x00){
/* 061017			Set.Ch1_iConnect = CH_CH1;*/
				Set.Ch1_iConnect = CH_CH1;
				Set.Ch2_iConnect = CH_CH0;
//				Set.Ch1_iConnect = CH_CH0;
//				Set.Ch2_iConnect = CH_CH1;
			}else{
/* 061017				Set.Ch1_iConnect = CH_CH0;*/
				Set.Ch1_iConnect = CH_CH0;
				Set.Ch2_iConnect = CH_CH1;
//				Set.Ch1_iConnect = CH_CH1;
//				Set.Ch2_iConnect = CH_CH0;
			}

			/*Set.iConnect = 0 : CPU PORT(232),1 :CPU PORT(422) ,2 : LINK PORT(232),3 : LINK PORT(422) */
			Set.iDstSta = (int)cTempBuffer[++iOffset];			/* 27 : Connection Station No*/
			Set.iGPSta = (int)cTempBuffer[++iOffset];			/* 27 : GP Station No*/
			Set.iBuzzer = (int)cTempBuffer[++iOffset];			/* 28 : Buzzer ON/OFF(ON : 0xff, OFF : 0x00)*/
			if(Set.iBuzzer==0xff)
				Set.iBuzzer = 1;

			iTemp = (int)cTempBuffer[++iOffset];				/* 29 : System Language(Korean:0x00, English:0xff)*/
			if(iTemp==0x00)
			{
				Set.iLang = 1;
			}
			else
			{ 
				Set.iLang = 0;
			}

/*			Set.iChar		= (int)cTempBuffer[++iOffset];*/	/* 30 : Character Set(Korea : 0x00, Japan : 0x01, Chinese : 0x02, English : 0x03)*/
			++iOffset;										/* 30 : Character Set(Korea : 0x00, Japan : 0x01, Chinese : 0x02, English : 0x03)*/
			Set.iDataFormat = (int)cTempBuffer[++iOffset];	/* 31 : (YY/MM/DD),(YY/DD/MM),(DD/YY/MM),(DD/MM/YY),(MM/DD/YY),(MM/YY/DD) */
			Set.iDataFormat-- ;
			if(Set.iDataFormat<0)
				Set.iDataFormat =0;
			Set.iLang		= (int)cTempBuffer[++iOffset];  /* 32 : System Lang  */

			if(Set.iLang == 3)
				Set.iLang = 0;
			else
				Set.iLang = 1;

/*			Set.eFontCode	= (int)cTempBuffer[++iOffset];*/  /* 33 : engfont Type 1 :���� 2: ���� (���ͽû��� ������.) */
			++iOffset;

			Set.iCallKey = (int)cTempBuffer[++iOffset];		/* 34 : Menu Key Position,OR Bit 1��°Bit:LeftTop, 2��°Bit:RightTop, 
																							3��°Bit:LeftBottom, 4��°Bit:RightBottom */		
			/* ������ �ʿ��� �ҽ��� ������ �޶�� �ؾ��� �ϴ��� �ӽ÷� �ҽ� ����.  */
	
		}else if(iTransFlag == 0)
		{
			iOffset += 16;		/* 17 ~ 18 : Serial Port Speed */
								/* 19 : Serial Port Handshaking (XON/XOFF : 0x00, DSR/DTR : 0xFF) */
								/* 20 : Serial Port Parity(None : 0x00, Even : 0x01, Odd : 0x02) */
								/* 21 : Serial Port Data Bit(7Bit : 0x00, 8Bit : 0xFF)*/
								/* 22 : Serial Port Stop Bit(1Bit : 0x00, 2Bit : 0xFF)*/
								/* 23 : Opening Screen Time*/
								/* 24 : Backlighy off Time */
								/* 25 : Connection Port(RS232 : 0x00, RS422 : 0xFF)*/
								/* 26 : Connection Type(CPU : 0x00, LINK:0xFF)*/
								/* 27 : Connection Station No*/
								/* 28 : Buzzer ON/OFF(ON : 0xff, OFF : 0x00)*/
								/* 29 : System Language(Korean:0x00, English:0xff)*/
		/*	Set.iChar		= (int)cTempBuffer[++iOffset];*/	/* 30 : Character Set(Korea : 0x00, Japan : 0x01, Chinese : 0x02, English : 0x03)*/
			++iOffset;	/* 30 : Character Set(Korea : 0x00, Japan : 0x01, Chinese : 0x02, English : 0x03)*/
			Set.iDataFormat = (int)cTempBuffer[++iOffset];	/* 31 : Data Format (YY/MM/DD),(YY/DD/MM),(DD/YY/MM),(DD/MM/YY),(MM/DD/YY),(MM/YY/DD) */
			Set.iDataFormat-- ;
			if(Set.iDataFormat<0)
				Set.iDataFormat =0;
			Set.iLang		= (int)cTempBuffer[++iOffset];  /* 32 : System Lang  */

			if(Set.iLang == 3)
				Set.iLang = 0;
			else
				Set.iLang = 1;

			++iOffset;  /* 33 : engfont Type 1 :���� 2: ���� */
			iOffset += 1;
			/* PLC1,2 Set */
		}else
		{
				iOffset += 21;
		}
		/*********************************************************************/
		CommonArea.PlcType1.PlcUserFlag= (char)cTempBuffer[++iOffset];		/* 35 : Plc1 used Flag(Use : 0x0ff, Not Use : 0x00) */
		CommonArea.PlcType2.AuxPlcUserFlag= (char)cTempBuffer[++iOffset];	/* 36 : Aux Plc used Flag(Use : 0x0ff, Not Use : 0x00) */
/****************************************2008.12.10****************/
//		if(CommonArea.PlcType2.AuxPlcUserFlag == 0){		/* Not Use */
//			if(Set.Ch2_iKind == PLCTYPE2){
//				Set.Ch2_iKind= PRINTER;
//				mWriteSettei();
//			}
//		}

/*******************************************************/
		iOffset++;
		if(CommonArea.PlcType1.PlcUserFlag != 0x00)
		{				/* PLC1 USE */
			/* 2006.07.25 */
			memset(&CommonArea.PlcType1.DevInf[0],0,sizeof(CommonArea.PlcType1.DevInf));

			GetDeviceSet((cTempBuffer+iOffset),								/* 37 : Plc1 GP Device Name							*/
						&CommonArea.PlcType1.GpDevName,						/* 38 ~ 41 : Link Address1 Device Name				*/
						(int *)&CommonArea.PlcType1.GpDevAddr);
			iOffset += 5;
			CommonArea.PlcType1.MasterSlave= (char)cTempBuffer[iOffset++];	/* 42 : Plc1 Maste/Slave(1:Master,2:Slave)			*/
			for(i= 0; i< MAX_PLC_LINK_DEVNO; i++){
				CommonArea.PlcType1.DevInf[i].ReadWrite= (char)cTempBuffer[iOffset++];	/* 43+5*i : Plc1 Read/Write(0:No Use,1:Read,2:Write)			*/
				GetDeviceSet((cTempBuffer+iOffset),								/* 37 : Plc1 GP Device Name							*/
							&CommonArea.PlcType1.DevInf[i].DevName,						/* 38 ~ 41 : Link Address1 Device Name				*/
							(int *)&CommonArea.PlcType1.DevInf[i].DevAddr);
				iOffset += 5;
				CommonArea.PlcType1.DevInf[i].DevCnt= (int)cTempBuffer[iOffset++]*256;	/* 43+5*i : Plc1 Read/Write(0:No Use,1:Read,2:Write)			*/
				CommonArea.PlcType1.DevInf[i].DevCnt += (int)cTempBuffer[iOffset++];	/* 43+5*i : Plc1 Read/Write(0:No Use,1:Read,2:Write)			*/
				CommonArea.PlcType1.DevInf[i].DevFlag= (char)cTempBuffer[iOffset++];	/* 43+5*i : Plc1 Read/Write(0:No Use,1:Read,2:Write)			*/
			}
		}
		if(CommonArea.PlcType2.AuxPlcUserFlag != 0x00)		//2008.12.10	//2011.12.08
		{				/* PLC2 USE */
			/* 2006.07.25 */
			memset(&CommonArea.PlcType2.DevInf[0],0,sizeof(CommonArea.PlcType2.DevInf));

			memcpy(CommonArea.PlcType2.AuxPlcGroupName,cTempBuffer+iOffset,20);	/* PLC2 Group Name */
			iOffset += 20;
			memcpy(CommonArea.PlcType2.AuxPlcTypeName,cTempBuffer+iOffset,20);	/* PLC2 Type Name */
			strcpy(Set.cPlcTypeAdd2,CommonArea.PlcType2.AuxPlcTypeName);
			iOffset += 20;
			memcpy(CommonArea.PlcType2.AuxPlcGroupCode,cTempBuffer+iOffset,4);	/* PLC2 Group,Type Code */
			memcpy(Set.cPlcTypeCode2,CommonArea.PlcType2.AuxPlcGroupCode,4);
			iOffset += 4;
			if(CommonArea.PlcType2.AuxPlcUserFlag != 0x00)		//2008.12.10
			{				/* PLC2 USE */
				GetDeviceSet((cTempBuffer+iOffset),								/* 37 : Plc1 GP Device Name							*/
							&CommonArea.PlcType2.GpDevName,						/* 38 ~ 41 : Link Address1 Device Name				*/
							(int *)&CommonArea.PlcType2.GpDevAddr);
				iOffset += 5;
				CommonArea.PlcType2.MasterSlave= (char)cTempBuffer[iOffset++];	/* 42 : Plc1 Maste/Slave(1:Master,2:Slave)			*/
				StationInf= (unsigned int)cTempBuffer[iOffset++] << 24;
				StationInf += (unsigned int)cTempBuffer[iOffset++] << 16;
				StationInf += (unsigned int)cTempBuffer[iOffset++] << 8;
				StationInf += (unsigned int)cTempBuffer[iOffset++];
				KyokuCnt= cTempBuffer[iOffset++];					/* �ǔ� */
				for(i= 0; i< KyokuCnt; i++){
					Kyokuban= cTempBuffer[iOffset++];					/* �ǔ� */
					for(j= 0; j< MAX_PLC_LINK_DEVNO; j++){
						CommonArea.PlcType2.DevInf[Kyokuban][j].ReadWrite= (char)cTempBuffer[iOffset++];	/* 43+5*i : Plc1 Read/Write(0:No Use,1:Read,2:Write)			*/
						GetDeviceSet((cTempBuffer+iOffset),								/* 37 : Plc1 GP Device Name							*/
									&CommonArea.PlcType2.DevInf[Kyokuban][j].DevName,						/* 38 ~ 41 : Link Address1 Device Name				*/
									(int *)&CommonArea.PlcType2.DevInf[Kyokuban][j].DevAddr);
						iOffset += 5;
						CommonArea.PlcType2.DevInf[Kyokuban][j].DevCnt= (int)cTempBuffer[iOffset++]*256;	/* 43+5*i : Plc1 Read/Write(0:No Use,1:Read,2:Write)			*/
						CommonArea.PlcType2.DevInf[Kyokuban][j].DevCnt += (int)cTempBuffer[iOffset++];	/* 43+5*i : Plc1 Read/Write(0:No Use,1:Read,2:Write)			*/
						CommonArea.PlcType2.DevInf[Kyokuban][j].DevFlag= (char)cTempBuffer[iOffset++];	/* 43+5*i : Plc1 Read/Write(0:No Use,1:Read,2:Write)			*/
					}
				}
				Plc2ChanelNo= 0;		/* Plc Type2 Chanel No Clear 20081025 */
			}
		}
		/*-------------------------------------------------------------*/		

		/*********************************************************************/
		iOffset += 2;
		if(cTempBuffer[iOffset] == 0xA2){
			iDataSize  =  (int) (cTempBuffer[++iOffset] << 24);
			iDataSize +=  ((int)(cTempBuffer[++iOffset] << 16) & 0xffffff);
			iDataSize +=  ((int)(cTempBuffer[++iOffset] << 8) & 0xffff);
			iDataSize +=  (int)  cTempBuffer[++iOffset] & 0xff;
			if(iDataSize != 0x0A)
			{
				/*---------------------*/
				CommonArea.SystemDev.Proj_ObserveStatus = (int) cTempBuffer[++iOffset];
				if(CommonArea.SystemDev.Proj_ObserveStatus == 0xFF){
					CommonArea.SystemDev.Proj_ObserveTime = (int) cTempBuffer[++iOffset];
				}else{
					CommonArea.SystemDev.Proj_ObserveTime = 0;
					++iOffset;
				}
				CommonArea.SystemDev.Observe_Proj_Cnt = (short)cTempBuffer[++iOffset];
				for(k=0;k<CommonArea.SystemDev.Observe_Proj_Cnt;k++)
				{
					memset(cTempBuff,0x00,3);
					CommonArea.SystemDev.Observe_Proj_Dev[k].Dev1Inf = (int)cTempBuffer[++iOffset];
					/*------------------------------------------------------------*/
					++iOffset;
					GetDeviceSet((cTempBuffer+iOffset),
								CommonArea.SystemDev.Observe_Proj_Dev[k].DevName1,
								&(iDevAddress));
					CommonArea.SystemDev.Observe_Proj_Dev[k].DevAdd1 = iDevAddress;
					iOffset+=4;
					/*-------------------------------------------------------------*/

					memset(cTempBuff,0x00,3);
					CommonArea.SystemDev.Observe_Proj_Dev[k].Dev2Inf = (int)cTempBuffer[++iOffset];

					/*------------------------------------------------------------*/
					++iOffset;
					GetDeviceSet((cTempBuffer+iOffset),
								CommonArea.SystemDev.Observe_Proj_Dev[k].DevName2,
								&(iDevAddress));
					CommonArea.SystemDev.Observe_Proj_Dev[k].DevAdd2 = iDevAddress;
					iOffset+=4;
					/*-------------------------------------------------------------*/

					memset(cTempBuff,0x00,3);
					CommonArea.SystemDev.Observe_Proj_Dev[k].Action = (int)cTempBuffer[++iOffset]; /*Momentary  0x00, Set : 0x01, Reset : 0x02, Alternate : 0x03, Word 16bit : 0x04, Word 32bit : 0x05 */
					CommonArea.SystemDev.Observe_Proj_Dev[k].point =	(int)cTempBuffer[++iOffset];
					++iOffset;			/* Type : signed - 0x00 unsigned - 0xff*/

					/*------------------------------------------------------------*/
					++iOffset;
					GetDeviceSet((cTempBuffer+iOffset),
								CommonArea.SystemDev.Observe_Proj_Dev[k].DevName3,
								&(iDevAddress));
					CommonArea.SystemDev.Observe_Proj_Dev[k].DevAdd3 = iDevAddress;
					iOffset+=4;
					/*-------------------------------------------------------------*/
					CommonArea.SystemDev.Observe_Proj_Dev[k].FixData = (cTempBuffer[++iOffset] << 24);
					CommonArea.SystemDev.Observe_Proj_Dev[k].FixData += (cTempBuffer[++iOffset] << 16);
					CommonArea.SystemDev.Observe_Proj_Dev[k].FixData += (cTempBuffer[++iOffset] << 8);
					CommonArea.SystemDev.Observe_Proj_Dev[k].FixData += (cTempBuffer[++iOffset] & 0xff);

					if(0xFF == cTempBuffer[++iOffset]){			/* IndirectFlag		*/
						memset(cTempBuff,0x00,3);
						/*------------------------------------------------------------*/
						++iOffset;
						GetDeviceSet((cTempBuffer+iOffset),
									CommonArea.SystemDev.Observe_Proj_Dev[k].DevName4,
									&(iDevAddress));
						CommonArea.SystemDev.Observe_Proj_Dev[k].DevAdd4 = iDevAddress;
						iOffset+=4;
						/*-------------------------------------------------------------*/

					}else
					{
						iOffset += 5;
					}
					CommonArea.SystemDev.Observe_Proj_Dev[k].MoveType = cTempBuffer[++iOffset];		/* FMOV:0x00, BMOVG:0xFF */
				}
				/*----------------------------------*/
			}
		}
		if(iTransFlag == 0)
			mWriteSettei();
		iTransFlag = 1;
	/*	FreeMail((char*)cTempBuffer); */
	}

	return(EditSerealSetFlag);		/* 20090610 */
}

void vHistoryDataSet(_ALARM_HISTORY_EVENT_TBL* AlarmHistoryEventTbl,int iNum, char *cDataBuffer, int iOrder)
{
	int				iLen;
	int 			iColor; /* leesi */
	short			iDataSize;
	short			iNowSize;
	short			i;
	short			iCnt;
	char			cReturnData[40];
	char			cStime[20];
	char			cEtime[20];
	char			*cTempBuffer;
	int		iPoint;
	char*	LineData;


	iLen	= 0;
	iColor	= 0;
	cTempBuffer = (char *)TakeMemory(512+1);

	memset(cTempBuffer,0x00,512+1);			/* strlen->40 */
	memset(cReturnData,0x00,sizeof(cReturnData));
	memset(cStime,0x00,20);
	memset(cEtime,0x00,20);

	vAlarmHistoryTimeSetting(AlarmHistoryEventTbl, cStime, 0, iOrder, iNum);
	memset(cReturnData,' ',AlarmHistoryEventTbl->iOccurredWide+1);
	iDataSize = strlen(cStime);
	memcpy(cReturnData,cStime,iDataSize);
	iNowSize = AlarmHistoryEventTbl->iOccurredWide;
	memset(cReturnData+iNowSize,' ',AlarmHistoryEventTbl->iMessageWide+1);
	if(AlarmHistoryEventTbl->iMessageWide>0){
		iLen = AlarmHistoryEventTbl->iMessageWide;
		vCommentDataSet((CommonArea.AlarmHistRec[iNum].DevNo+CommonArea.SystemDev.iCommentNo),cTempBuffer,&iColor,&iLen);
		/******************** 0x0d Over Code Cut ***********/
		if(AlarmHistoryEventTbl->iMessageWide<iLen)
		{
			iLen = AlarmHistoryEventTbl->iMessageWide;
		}
		LineData = 0x00;
		LineData = strchr(cTempBuffer,0x0D);
		if(((int)LineData) != 0)
		{
			iPoint = ((int)LineData)-((int)cTempBuffer);
		}else
			iPoint = 0;
		if(iPoint>0)
		{
			memset(cTempBuffer+iPoint,0x00,iLen-iPoint);
			iLen = iPoint;
		}
		/********************************/
		iCnt = 0;
		for(i=0;i<iLen;i++)
		{
			if((unsigned char)cTempBuffer[i] < 0x7f && 0x00 < (unsigned char)cTempBuffer[i])
			{
				iCnt++;
			}
		}
		if(iCnt%2 != iLen%2)
			cTempBuffer[iLen-1] = 0x00;
		/********************************/
	}
	if(AlarmHistoryEventTbl->iMainContentInfo != 0x03)
		iDataSize++;
	else
		iDataSize = AlarmHistoryEventTbl->iOccurredWide+1;

	if(iLen != 0)
	{	
		if(iLen>=AlarmHistoryEventTbl->iMessageWide)
			memcpy(cReturnData+iDataSize,cTempBuffer,AlarmHistoryEventTbl->iMessageWide);
		else
			memcpy(cReturnData+iDataSize,cTempBuffer,iLen);
		
	}
	if(AlarmHistoryEventTbl->iMessageWide > 0)
		iNowSize++;
	iNowSize += AlarmHistoryEventTbl->iMessageWide;
	if((AlarmHistoryEventTbl->iDispStyle & 0x02) == 0x02)
	{
		memset(cReturnData+iNowSize,' ',AlarmHistoryEventTbl->iRestorationWide+2);
		iNowSize++;
		if(CommonArea.AlarmHistRec[iNum].flag==0x01){
			memset(cEtime,0x00,sizeof(cEtime));
			vAlarmHistoryTimeSetting(AlarmHistoryEventTbl, cEtime, 1, iOrder, iNum);
			iDataSize = strlen(cEtime);
			memcpy(cReturnData+iNowSize,cEtime,AlarmHistoryEventTbl->iRestorationWide);
		}
		iNowSize += AlarmHistoryEventTbl->iRestorationWide+1;
	}

	if((AlarmHistoryEventTbl->iDispStyle & 0x04) == 0x04)	/* Occur frequency */
	{
		memset(cEtime,0x00,sizeof(cEtime));
		memset(cReturnData+iNowSize,' ',5);
		itoa(CommonArea.AlarmHistRec[iNum].Cnt,cEtime,10);
		iDataSize = strlen(cEtime);
		memcpy(cReturnData+iNowSize+(5-iDataSize),cEtime,iDataSize);
		iNowSize += 5;
	}
	memcpy(cDataBuffer,cReturnData,iNowSize);
	FreeMail((char *)cTempBuffer);

}
/********************************************************************************/
/* �� �� �� : vAlarmHistoryTimeSetting()													*/
/* ��    �� : �±׿��� ����̽��� ���� �о� ���ſ��θ� �����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 9�� �� 													*/
/* �� �� �� : �� �� ��															*/
/* �� �� ġ	:																	*/
/* ��    �� :																	*/
/********************************************************************************/
void	vAlarmHistoryTimeSetting(_ALARM_HISTORY_EVENT_TBL* AlarmHistoryEventTbl,char* cReturnData,short iOnOffType, int iOrder,int iNum)
{
	int	iTimeType;
	int	iDateType;
	int	iMainType;
	char cDate[9];
	char cTime[9];
	short iyear;
	short imon;	
	short iday;
	short ihour;
	short imin;
	short isec;
	unsigned int	iDataBuffer;
/*	_ALARM_HISTORY_EVENT_TBL*	 AlarmHistoryEventTbl;*/


/*	AlarmHistoryEventTbl= (_ALARM_HISTORY_EVENT_TBL*)IventTable[iOrder];*/

	if(iOnOffType == 0){		/* Occurred */
		iTimeType	= AlarmHistoryEventTbl->iTimeContentInfo;
		iDateType	= AlarmHistoryEventTbl->iDateContentInfo;
		iMainType	= AlarmHistoryEventTbl->iMainContentInfo;
		iDataBuffer = CommonArea.AlarmHistRec[iNum].sDateTime;
	}
	else if(iOnOffType == 1)
	{					/* Restored */
		iTimeType	= AlarmHistoryEventTbl->iRestorationTimeInfo;
		iDateType	= AlarmHistoryEventTbl->iRestorationDateInfo;
		iMainType	= AlarmHistoryEventTbl->iRestorationInfo;
		iDataBuffer = CommonArea.AlarmHistRec[iNum].eDateTime;
	}
	else if(iOnOffType == 2)
	{					/* AlarmList */
		iTimeType	= 0x00;
		iDateType	= 0x00;
		iMainType	= 0x00;
		iDataBuffer = CommonArea.AlarmListRec[iNum].DateTime;
	}
	else
	{					/* StoreAlarmList */
		iTimeType	= 0x00;
		iDateType	= 0x00;
		iMainType	= 0x00;
		iDataBuffer = CommonArea.StordMem[iOrder].Alarm.StoreAlarmListRec[iNum].DateTime;
	}
	/*year : 6bit, mon : 4bit, day : 5bit, hour : 5bit, min : 6bit, sec : 6bit*/

	isec		= (short)iDataBuffer & 0x0000003F;
	iDataBuffer = iDataBuffer >> 6;
	imin		= (short)iDataBuffer & 0x0000003F;
	iDataBuffer = iDataBuffer >> 6;
	ihour		= (short)iDataBuffer & 0x0000001F;
	iDataBuffer = iDataBuffer >> 5;
	iday		= (short)iDataBuffer & 0x0000001F;
	iDataBuffer = iDataBuffer >> 5;
	imon		= (short)iDataBuffer & 0x0000000F;
	iDataBuffer = iDataBuffer >> 4;
	iyear		= (short)iDataBuffer & 0x0000003F;

	/*
			iMainType				iDateType					iTimeType			
			0x00 : Date, Time		0x00 : YY/MM/DD				0x00 : HH:MM:SS
			0x01 : Date				0x08 : MM/DD/YY				0x64 : HH:MM
			0x02 : Time				0x16 : DD/MM/YY
			0x03 : String			0x24 : MM/DD
			*/
	memset(cTime,0x00,sizeof(cTime));
	memset(cDate,0x00,sizeof(cDate));
	if(iDateType==0x00)
	{
			sprintf(cDate,"%02d/%02d/%02d",
					iyear, 
					imon, 
					iday);
	}
	else if(iDateType==0x08)
	{
			sprintf(cDate,"%02d/%02d/%02d",
					imon, 
					iday,
					iyear);
	}
	else if(iDateType==0x10)
	{
			sprintf(cDate,"%02d/%02d/%02d",
					iday,
					imon, 
					iyear);
	}
	else if(iDateType==0x18)
	{
			sprintf(cDate,"%02d/%02d", 
					imon, 
					iday);
	}
	if(iTimeType==0x00)
	{
		sprintf(cTime,"%02d:%02d:%02d",					
					ihour,
					imin,
					isec);
	}
	else if(iTimeType==0x40)
	{
		sprintf(cTime,"%02d:%02d",					
					ihour,
					imin);
	}
	switch(iMainType){
		case 0x00:	/* Date, Time */
			if(iOnOffType == 2 || iOnOffType == 3){
				sprintf(cReturnData,"%s %s ",cDate,cTime);
			}else{		
				sprintf(cReturnData,"%s %s",cDate,cTime);
			}
			break;
		case 0x01:	/* Date */
			sprintf(cReturnData,"%s",cDate);
			break;
		case 0x02:	/* Time */
			sprintf(cReturnData,"%s",cTime);
			break;
		case 0x03:	/* String */
			if(iOnOffType == 0){		/* Occurred */
				memcpy(cReturnData,
					AlarmHistoryEventTbl->cOccurredTextContents,
					AlarmHistoryEventTbl->iOccurredTextSize);
			}else{
				memcpy(cReturnData,
					AlarmHistoryEventTbl->cRestoredTextContents,
					AlarmHistoryEventTbl->iRestoredTextSize);
			}
			break;
	}

}

