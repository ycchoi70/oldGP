/********************************************************************************/
/* �� �� �� : Gp_CommentTask.cpp												*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"

/********************************************************************************/
/* �� �� �� : DrawComment_Func													*/
/* ��    �� : Comment������ �ص��Ͽ� ȭ�鿡 ���							    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetComment_Func(int iDispOrder)
{
	_COMMENT_EVENT_TBL*	 CommentEventTbl;
	CommentEventTbl= (_COMMENT_EVENT_TBL*)TakeMemory(sizeof(_COMMENT_EVENT_TBL));
	DrawComment_Func(0,CommentEventTbl,iDispOrder);
	FreeMail((char *)CommentEventTbl);
}
int	DrawComment_Func(int mode,_COMMENT_EVENT_TBL* CommentEventTbl,int iDispOrder)
{
/*		unsigned int		iTagSizeOf;	*/
		int					iOffset  = 0;
		unsigned char *buffer;

		buffer= ScreenTagData[iDispOrder].TagPos;
/*		_COMMENT_EVENT_TBL*	 CommentEventTbl;*/
/*
		if(CheckMailBox(sizeof(_COMMENT_EVENT_TBL)) == -1){
			return(-1);
		}
		if(IventTableCnt >= MAX_IVENT_CNT){
			return(-1);
		}
		IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_COMMENT_EVENT_TBL));
		CommentEventTbl= (_COMMENT_EVENT_TBL*)IventTable[IventTableCnt];
*/
		memset((char *)CommentEventTbl, 0x00, sizeof(_COMMENT_EVENT_TBL));
/*
		CleanComment.iMax = 0;
		CleanComment.iLine = 0;
		CleanComment.iTopY = 0;

		iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
		iTagSizeOf += (unsigned int)buffer[1] & 0xff;
		CommentEventTbl->sX  = (unsigned int)(buffer[6] << 0x08);
		CommentEventTbl->sX += (unsigned int)buffer[7] & 0xff;

		CommentEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
		CommentEventTbl->sY += (unsigned int)buffer[9] & 0xff;

		CommentEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
		CommentEventTbl->eX += (unsigned int)buffer[11] & 0xff;

		CommentEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
		CommentEventTbl->eY += (unsigned int)buffer[13] & 0xff;
*/		
		
		CommentEventTbl->iFrameColor = (unsigned int)buffer[14];
		CommentEventTbl->iFontSizeH  = (unsigned int)buffer[15];
		CommentEventTbl->iFontSizeV  = (unsigned int)buffer[16];
		
		if((unsigned int)buffer[22] == 0x02){/*  iBitWordFlag Bit  : 0x02(Bit����) */
			CommentEventTbl->iBitWordFlag = BITFLAG;
			/* Basic Device Infomation */
			iOffset = 17;
			/*------------------------------------------------------------*/
			GetDeviceSet((buffer+iOffset),
						CommentEventTbl->cDeviceName,
						&(CommentEventTbl->iDeviceNumber));
			/*-------------------------------------------------------------*/		
			iOffset+=6;
			/* Off ���� */
			CommentEventTbl->iOffTextColor = (unsigned int)buffer[iOffset];

			CommentEventTbl->iOffPlateColor = (unsigned int)buffer[++iOffset];
			CommentEventTbl->iOffAttrChecked = (unsigned int)buffer[++iOffset];
			CommentEventTbl->iOffDirectChecked = (unsigned int)buffer[++iOffset];

			if(CommentEventTbl->iOffDirectChecked == 0x02){		/* Direct */
				CommentEventTbl->iOffTextLength = (unsigned int)(buffer[++iOffset] << 0x08);
				CommentEventTbl->iOffTextLength += (unsigned int)buffer[++iOffset] & 0xff;
				iOffset ++;
/*				CommentEventTbl->cOffTextBuffer = (char *)TakeMemory(CommentEventTbl->iOffTextLength);
				memcpy(CommentEventTbl->cOffTextBuffer,
					buffer + iOffset, 
					CommentEventTbl->iOffTextLength);		
*/
				CommentEventTbl->cOffTextBuffer = (char *)&buffer[iOffset];
				iOffset += CommentEventTbl->iOffTextLength;
			}else{												/* No. */
				CommentEventTbl->iOffNo = (unsigned int)(buffer[++iOffset] << 0x08);
				CommentEventTbl->iOffNo += (unsigned int)buffer[++iOffset] & 0xff;
				iOffset++;
			}
			CommentEventTbl->iOnTextColor = (unsigned int)buffer[iOffset];
			iOffset++;
			CommentEventTbl->iOnPlateColor = (unsigned int)buffer[iOffset];
			iOffset++;
			CommentEventTbl->iOnAttrChecked = (unsigned int)buffer[iOffset];
			iOffset++;			
			CommentEventTbl->iOnDirectChecked = (unsigned int)buffer[iOffset];
			iOffset++;	

			if(CommentEventTbl->iOnDirectChecked == 0x02){		/* Direct */
				CommentEventTbl->iOnTextLength = (unsigned int)(buffer[iOffset] << 0x08);
				iOffset++;	
				CommentEventTbl->iOnTextLength += (unsigned int)buffer[iOffset] & 0xff;
				iOffset++;
/*
				CommentEventTbl->cOnTextBuffer = (char *)TakeMemory(CommentEventTbl->iOnTextLength);
				memcpy(CommentEventTbl->cOnTextBuffer,
					buffer + iOffset, 
					CommentEventTbl->iOnTextLength);		
*/
				CommentEventTbl->cOnTextBuffer = (char *)&buffer[iOffset];
				iOffset += CommentEventTbl->iOnTextLength;
			}else{												/* No. */
				CommentEventTbl->iOnNo = (unsigned int)(buffer[iOffset] << 0x08);
				iOffset++;	
				CommentEventTbl->iOnNo += (unsigned int)buffer[iOffset] & 0xff;
				iOffset++;	
			}
			
			if((unsigned int)buffer[iOffset] != 0x00){
				if(mode == 0){
					ScreenTagData[iDispOrder].BeShapeUsed = CHECKED;
				}
				iOffset++;
				CommentEventTbl->ShapeNo =  (unsigned int)buffer[iOffset];
				iOffset++;
			}else{
				if(mode == 0){
					ScreenTagData[iDispOrder].BeShapeUsed = UNCHECKED;
				}
				iOffset++;
				CommentEventTbl->ShapeNo =  0x00;
				iOffset++;
			}
			if((unsigned int)buffer[iOffset] != 0){
				CommentEventTbl->iFontSizeH = 0;
				CommentEventTbl->iFontSizeV = 0;		//20101207
			}
			if(mode == 0){
				DeviceDataHed[DeviceCnt].DevFlag = DEVICE_BIT;/* Bit */
				DeviceDataHed[DeviceCnt].DevName[0] = CommentEventTbl->cDeviceName[0];
				DeviceDataHed[DeviceCnt].DevName[1] = CommentEventTbl->cDeviceName[1];
				DeviceDataHed[DeviceCnt].DevAddress = CommentEventTbl->iDeviceNumber;						
				DeviceDataHed[DeviceCnt].DevCnt = 1;			
				DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];			
				CommentEventTbl->iRegisterNumber = DeviceCnt;

				/* 20020819 choijh add*/
/*				CommentEventTbl->SuperVOffset= WatchingDevice(CommentEventTbl->cDeviceName, 
											CommentEventTbl->iDeviceNumber, 
											0,
											CommentEventTbl->iRegisterNumber,
											BIT,DeviceDataHed[DeviceCnt].DevCnt);
*/
				ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
				ScreenTagData[iDispOrder].DevCnt= DeviceDataHed[DeviceCnt].DevCnt;
				iDeviceOffset++;
				DeviceCnt++;
			}
		}
		/* iBitWordFlag Word : 0x01(Word����) */
		else if((unsigned int)buffer[22] == 0x01){
			CommentEventTbl->iBitWordFlag = WORDFLAG;
			/* Basic Device Infomation */
			iOffset = 17;
			/*------------------------------------------------------------*/
			GetDeviceSet((buffer+iOffset),
						CommentEventTbl->cDeviceName,
						&(CommentEventTbl->iDeviceNumber));
			/*-------------------------------------------------------------*/		
			iOffset += 6;
			/* 24��°�� �˻��� �ʿ䰡 ����-> */
			CommentEventTbl->iEdtTextColor = (unsigned int)buffer[iOffset];		/* 23 */
			CommentEventTbl->iEdtPlateColor = (unsigned int)buffer[++iOffset];	/* 24 */
			if((unsigned int)buffer[++iOffset] == 0x09){						/* 25 */
				CommentEventTbl->iEdtAttrChecked = CHECKED;
			}
			else{
				CommentEventTbl->iEdtAttrChecked = UNCHECKED;
			}

			CommentEventTbl->iStartNo  =(short)(buffer[++iOffset] << 8) & 0xffff;	/* 26 */
			CommentEventTbl->iStartNo += (short)buffer[++iOffset] & 0xff;			/* 27 */

			if((unsigned int)buffer[++iOffset] != 0x00){							/* 28 */
				if(mode == 0){
					ScreenTagData[iDispOrder].BeShapeUsed = CHECKED;
				}
				CommentEventTbl->ShapeNo =  (unsigned int)buffer[++iOffset];		/* 29 */
			}else{
				if(mode == 0){
					ScreenTagData[iDispOrder].BeShapeUsed = UNCHECKED;
				}
				CommentEventTbl->ShapeNo =  0x00;
				iOffset++;															/* 29 */
			}

			if((short)buffer[++iOffset] != 0){
				CommentEventTbl->iFontSizeH = 0;
				CommentEventTbl->iFontSizeV = 0;		//20101207
			}
			if(mode == 0){
				DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */
				DeviceDataHed[DeviceCnt].DevName[0] = CommentEventTbl->cDeviceName[0];
				DeviceDataHed[DeviceCnt].DevName[1] = CommentEventTbl->cDeviceName[1];
				DeviceDataHed[DeviceCnt].DevAddress = CommentEventTbl->iDeviceNumber;						
				DeviceDataHed[DeviceCnt].DevCnt = 1;			
				DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];			
				CommentEventTbl->iRegisterNumber = DeviceCnt;

			/* 20020819 choijh add*/
/*			CommentEventTbl->SuperVOffset= WatchingDevice(CommentEventTbl->cDeviceName, 
											CommentEventTbl->iDeviceNumber, 
											0,
											CommentEventTbl->iRegisterNumber,
											WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/

				ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
				ScreenTagData[iDispOrder].DevCnt= DeviceDataHed[DeviceCnt].DevCnt*2;
				iDeviceOffset+=2;
				DeviceCnt++;
			}
		}
		if(mode == 0){
			CommentDispCnt++;
		}
/*		IventTableCnt++;*/

		return(0);
}

/********************************************************************************/
/* �� �� �� : CommentDispWatch													*/
/* ��    �� : Comment�±������� ����  ȭ�鿡 ����� ����Ѵ�.					*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	CommentDispWatch(int iOrder)
{
		int				i;				
		int				iFontsX;
		int				iFontsY;
		int				iColor;
//		int				iLen;
		int				iSize;
		int				Font_Color;
		char*			cDispBuffer;
		long			lDeviceValue;
		short			iShapeSize;
		int				BefBitDevVal;
		char			work[8];

		_COMMENT_EVENT_TBL*	 CommentEventTbl;

/*		CommentEventTbl= (_COMMENT_EVENT_TBL*)IventTable[iOrder];*/
		CommentEventTbl= (_COMMENT_EVENT_TBL*)TakeMemory(sizeof(_COMMENT_EVENT_TBL));
		DrawComment_Func(1,CommentEventTbl,iOrder);

		iFontsX		 = 0;
		iFontsY		 = 0;
		iColor		 = 0;
//		iLen		 = 0;
		iSize		 = 0;
		Font_Color	 = 0;
		iShapeSize   = 0;

		i = iOrder;
		cDispBuffer = (char*)TakeMemory(512);
		memset(cDispBuffer, 0x00, 512);
		iSize = 511;
		/* BIT */
		if(CommentEventTbl->iBitWordFlag == BITFLAG){
			BefBitDevVal= DispDeviceData[ScreenTagData[iOrder].DevOrder];
			if(BefBitDevVal == OFF){/* OFF */
				if(CommentEventTbl->iOffDirectChecked == 0x02){/* ���� ������ �Է����� ��� */
					memcpy(cDispBuffer, CommentEventTbl->cOffTextBuffer, CommentEventTbl->iOffTextLength);
					Font_Color = CommentEventTbl->iOffTextColor;
				}else{/* �ڸ�Ʈ���Ͽ��� ������ �޾ƾ� �� ��� */
					vCommentDataSet(CommentEventTbl->iOffNo, cDispBuffer, &iColor, &iSize);
					Font_Color = iColor;
				}
				if(CommentEventTbl->iOffAttrChecked != 0)
					Font_Color = CommentEventTbl->iOffTextColor;
			}else{/* ON */
				if(CommentEventTbl->iOnDirectChecked == 0x02){/* ���� �ڸ�Ʈ ������ �Է����� ��� */					
					memcpy(cDispBuffer, CommentEventTbl->cOnTextBuffer, CommentEventTbl->iOnTextLength);
					Font_Color = CommentEventTbl->iOnTextColor;
				}else{/* �ڸ�Ʈ���Ͽ��� ������ �޾ƾ� �� ��� */					
					vCommentDataSet(CommentEventTbl->iOnNo, cDispBuffer, &iColor, &iSize);
					Font_Color = iColor;
				}
				if(CommentEventTbl->iOnAttrChecked != 0)
					Font_Color = CommentEventTbl->iOnTextColor;
			}
			iFontsX = ScreenTagData[iOrder].sX;
			iFontsY = ScreenTagData[iOrder].sY;
			iShapeSize = 0;
			if(ScreenTagData[iOrder].BeShapeUsed == CHECKED ){

//				if(CommentEventTbl->BefBitDevVal == OFF)			//20091216
				if(BefBitDevVal == OFF)								//20091216
					iColor	= CommentEventTbl->iOffPlateColor;
				else
					iColor	= CommentEventTbl->iOnPlateColor;
				
			iShapeSize =	DrawShape(CommentEventTbl->ShapeNo, 
					ScreenTagData[iOrder].sX, 
					ScreenTagData[iOrder].sY, 
					ScreenTagData[iOrder].eX, 
					ScreenTagData[iOrder].eY,
					CommentEventTbl->iFrameColor,
					iColor);
				iFontsX += iShapeSize;
				iFontsY += iShapeSize;
			}

			vCommentDisplayFormat(i ,cDispBuffer,  CommentEventTbl->iFontSizeV ,CommentEventTbl->iFontSizeH);

			vMultiTextDisp(iFontsX, 
					iFontsY, 
					ScreenTagData[iOrder].eX-iShapeSize, 
					ScreenTagData[iOrder].eY-iShapeSize,
					cDispBuffer,
					CommentEventTbl->iFontSizeH, 
					CommentEventTbl->iFontSizeV,
					Font_Color,
					TOP_LEFT);
		}
		/* WORD */
		else if(CommentEventTbl->iBitWordFlag == WORDFLAG){
/*			lDeviceValue = CommentEventTbl->BefWordDevVal;*/
			memcpy(work,&DispDeviceData[ScreenTagData[iOrder].DevOrder],ScreenTagData[iOrder].DevCnt);
			lDeviceValue= ChangeChar2long(work,BIT16);
			iFontsX = ScreenTagData[iOrder].sX;
			iFontsY = ScreenTagData[iOrder].sY;
			if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){
				iShapeSize = DrawShape(CommentEventTbl->ShapeNo, 
					ScreenTagData[iOrder].sX, 
					ScreenTagData[iOrder].sY, 
					ScreenTagData[iOrder].eX, 
					ScreenTagData[iOrder].eY,
					CommentEventTbl->iFrameColor,
					CommentEventTbl->iEdtPlateColor);
				iFontsX+=iShapeSize;
				iFontsY+=iShapeSize;
			}
			if((CommentEventTbl->iStartNo+lDeviceValue)>0){

				vCommentDataSet((lDeviceValue+CommentEventTbl->iStartNo), cDispBuffer, &iColor, &iSize);
				if(CommentEventTbl->iEdtAttrChecked == CHECKED){
					Font_Color = CommentEventTbl->iEdtTextColor;
				}
				else{
					Font_Color = iColor;
				}

				
			/*	if(iOnSignalStart != OFF){				*/
//						iLen = strlen(cDispBuffer);						
					/*	Font_Color = NumericEventTbl->iTextColor;*/

					/*	if(CommentEventTbl->BeShapeUsed == CHECKED){
							DrawShape(CommentEventTbl->ShapeNo, 
								CommentEventTbl->sX, 
								CommentEventTbl->sY, 
								CommentEventTbl->eX, 
								CommentEventTbl->eY,
								CommentEventTbl->iFrameColor,
								CommentEventTbl->iEdtPlateColor);
								iFontsX += SHAPE_DISTANCE;
						}*/

						vCommentDisplayFormat(i ,cDispBuffer, CommentEventTbl->iFontSizeV, CommentEventTbl->iFontSizeH);

						vMultiTextDisp(iFontsX, 
								ScreenTagData[iOrder].sY, 
								ScreenTagData[iOrder].eX, 
								ScreenTagData[iOrder].eY,
								cDispBuffer,
								CommentEventTbl->iFontSizeH, 
								CommentEventTbl->iFontSizeV,
								Font_Color,
								TOP_LEFT);
			/*	}				*/
			}

		}
		FreeMail((char*)cDispBuffer);
/*
 		if(CommentEventTbl->cOffTextBuffer != NULL){
			FreeMail((char *)CommentEventTbl->cOffTextBuffer);
		}
		if(CommentEventTbl->cOnTextBuffer != NULL){
			FreeMail((char *)CommentEventTbl->cOnTextBuffer);
		}
*/
		FreeMail((char *)CommentEventTbl);
}
/********************************************************************************/
/* �� �� �� : vMultiTextDisp													*/
/* ��    �� : MultiText�� ���� ���÷��� �ϴ� �Լ�.							*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 29�� (��)												*/
/* �� �� �� :  																	*/
/* ��    �� : 																	*/
/********************************************************************************/
void vMultiTextDisp(int sX, int sY, int eX, int eY, char * cDispData,int xbai,int ybai, int iColor, int iType)
{
	char*   cDispBuffer;
	char*	LineData;
	char*	cTextBuffer[10];
	int		iCenter		= 0;
	int		iCnt		= 0;
	int		iLen		= 0;
	int		i			= 0;
	int		CenterX;
	int		CenterY;
	int		iVal;
	int		iDataCen;
	int		Font_Color	= 0;
	int		Back_Color	= 0;
	int		T_Type		= 0;
	int		iMaxData	= 0;


	iCenter		= 0;
	iCnt		= 0;
	iLen		= 0;
	i			= 0;
	Font_Color	= 0;
	Back_Color	= 0;
	T_Type		= 0;
	iMaxData	= GAMEN_Y_SIZE-1;

	if(TateYoko == 1)
		iMaxData = GAMEN_X_SIZE-1;
	iLen = (strlen(cDispData)+1);
	cDispBuffer = (char *)TakeMemory(iLen);
	memset(cDispBuffer,0x00,iLen);
	strncpy(cDispBuffer,cDispData,strlen(cDispData));	
	CenterX = (int)(((sX+eX)/2)+0.5);
	CenterY = (int)(((eY+sY)/2)+0.5);
	CleanComment.iTopY = GAMEN_Y_SIZE-1;
	CleanComment.iLine = 0;
	for(i=0;i<10;i++)	
	{
		LineData = strchr(cDispBuffer,0x0D);
		if(((int)LineData)==0x00)
		{
			iLen = strlen(cDispBuffer);
			iLen++;
			cTextBuffer[i] = (char *)TakeMemory((iLen));
			memset(cTextBuffer[i],0x00,(iLen));
			strcpy(cTextBuffer[i],cDispBuffer);
			iLen--;
			if(CleanComment.iMax<iLen || i==0){
				CleanComment.iMax = iLen;
			}
			break;
		}
		iLen = (int)(LineData-cDispBuffer);
		if(CleanComment.iMax<iLen || i == 0)
			CleanComment.iMax = iLen;
		iLen++;
		cTextBuffer[i] = (char *)TakeMemory((iLen));
		memset(cTextBuffer[i],0x00,(iLen));
		iLen--;
		strncpy(cTextBuffer[i],cDispBuffer,iLen);

		strcpy(cDispBuffer,LineData+2);

		iCnt++;
	}

	if(i<10)
		iCnt += 1;

	iCenter = (int)(iCnt/2);
	if(((iCnt)%2)!=0){
		if(ybai!=5 && ybai != 0)
			CenterY = CenterY + ((ybai*16)/2);			
		else
			CenterY = CenterY + (8/2);
		iCenter++;
	}
	for(i=0;i<iCnt;i++)
	{	
		if(ybai!=5)
		{
			if(ybai !=0 )
				iLen = CenterY+1 - (((iCenter-i)*(ybai*16)));	/* iLen = CenterY - (((iCenter-i)*(ybai*16))-1); */
			else
				iLen = CenterY+1 - (((iCenter-i)*8));			/* iLen = CenterY - (((iCenter-i)*8)-1); */
			iVal = (iLen+(ybai*16))-1;
			iDataCen = ((strlen(cTextBuffer[i]) * (xbai*8))/2) + sX;
		}
		else
		{
			iLen = CenterY+1 - (((iCenter-i)*8));  /* iLen = CenterY - (((iCenter-i)*8)-1); */
			iVal = (iLen+8)-1;
			iDataCen = ((strlen(cTextBuffer[i]) * (xbai*6))/2) + sX;
		}
		if(iLen>=0 && iVal<=iMaxData)
		{

			Font_Color = iColor;
			if(CleanComment.iTopY > iLen)
				CleanComment.iTopY = iLen;

			if(Font_Color == 0)
			{
				Back_Color	= WHITE;	
				T_Type		= T_FRONT ; /* T_FRONT 5 �̰��� ������ ���ڱ� �ȵȴ�. */
			}else
			{
				Back_Color = BLACK;
				T_Type      = T_OR;
			}
			
			CleanComment.iLine++;
			if(CenterX == iDataCen || iType == 0)
				DotTextOut(sX, iLen, cTextBuffer[i], xbai, ybai, T_Type, Font_Color, Back_Color);
			else if(CenterX > iDataCen)
				DotTextOut(sX + (CenterX-iDataCen), iLen, cTextBuffer[i], xbai, ybai, T_Type, Font_Color, Back_Color);
			else if(CenterX < iDataCen)
				DotTextOut(sX - (iDataCen-CenterX), iLen, cTextBuffer[i], xbai, ybai, T_Type, Font_Color, Back_Color);
		}
	}	 
	for(i=0;i<iCnt;i++)
		FreeMail((char *)cTextBuffer[i]);
	FreeMail((char *)cDispBuffer);
}

/********************************************************************************/
/* �� �� �� : vCommentDataSet													*/
/* ��    �� : Commentȭ�Ͽ��� ��ȣ�� �´� CommentData�� �ҷ���.					*/
/* ��    �� : iNum(ǥ���� Com��ȣ)												*/
/* ��    �� :																	*/
/* �� �� �� :																	*/
/* �� �� �� :  																	*/
/* ��    �� : 																	*/
/********************************************************************************/
int vCommentDataSet(int inowNum, char *cDataBuffer, int *iColor, int *iLen)
{
	int				ipos;
	int				isize; 
	int				iSite;
	int				iNum;
	int				i;	
	int				iOffset;
	short			sLen;
	short			sReturnData;
	char			*AllTagBuffer;

	sLen		= *iLen;
	*iColor		= 0;
	*iLen		= 0;
	ipos		= 0;
	isize		= 0; 
	sReturnData = 0;

	if(inowNum > 0){

		if(mfileserch("COMMENT.GP",&ipos,&isize) == OK){
		/*	AllTagBuffer=(char *)TakeMemory(isize + 1);*/
		/*	memset(AllTagBuffer,0x00,isize + 1);*/
		/*	memcpy(AllTagBuffer,(char *)ipos,isize);*/
			AllTagBuffer =(char *)ipos;
			iComCnt  = (int)(AllTagBuffer[6] << 0x08);
			iComCnt += (int)(AllTagBuffer[7]) & 0xff;
			iOffset = 8;

			for(i=0 ; i < iComCnt ; i++){
				iNum = (unsigned int)(AllTagBuffer[iOffset] << 0x08);
				iOffset++;	/* comment No 2byte */
				iNum += (unsigned int)(AllTagBuffer[iOffset]& 0xff);
				iOffset++;
				
				if(inowNum == iNum)
				{
					*iLen = (unsigned int)(AllTagBuffer[iOffset] << 0x08);
					iOffset ++;
					*iLen += (unsigned int)(AllTagBuffer[iOffset] & 0xff);
					iOffset ++;

					*iColor = (unsigned int)(AllTagBuffer[iOffset] & 0xff);
					iOffset ++;
					sReturnData = 1;
					if(sLen==0 || sLen > *iLen)
						memcpy(cDataBuffer, AllTagBuffer+iOffset, *iLen);
					else
					{	
						memcpy(cDataBuffer, AllTagBuffer+iOffset, sLen);	
					}
					break;
				}
				iSite = (unsigned int)(AllTagBuffer[iOffset] << 0x08);
				iOffset ++;
				iSite += (unsigned int)(AllTagBuffer[iOffset] & 0xff);
				iOffset ++;
				iOffset ++;			
				iOffset+=iSite;
			}
		/*	FreeMail((char *)AllTagBuffer);*/
		}else
			iComCnt = 0;
	}
	return sReturnData;
}
int		GetCommentShapeNo(int no)
{
	int				ShapeNo;
	unsigned char	*buffer;

	buffer= ScreenTagData[no].TagPos;
	if((unsigned int)buffer[35] != 0x00){			/* 28 */		//20091216
		ShapeNo =  (unsigned int)buffer[36];		/* 29 */		//20091216
	}else{
		ShapeNo =  0x00;
	}
	return(ShapeNo);
}
/********************************************************************************/
/* �� �� �� : vCommentDisplayFormat()											*/
/* ��    �� : Comment������ �´� �����͸� ���.									*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� :																	*/
/* �� �� �� :  																	*/
/* ��    �� : 																	*/
/********************************************************************************/
void vCommentDisplayFormat(int i ,char* Data, short SizeH ,short SizeV )
{
	char		*AllTagBuffer;
	short		ixLen;
	short		iyLen;
	short		iCnt;
	short		iLen;
	char		*Point;	
	char		*RetData;
	short		x;
	short		y;
	short		iflag;
	short		iData;
	short		iData1;
	int			ShapeNo;

/*	_COMMENT_EVENT_TBL*	 CommentEventTbl;*/

/*	CommentEventTbl= (_COMMENT_EVENT_TBL*)IventTable[i];*/

	AllTagBuffer = (char *)TakeMemory(512);
	RetData = (char *)TakeMemory(512);
	memset(AllTagBuffer,0x00,512);
	memset(RetData,0x00,512);

	ixLen = ScreenTagData[i].eX+1 - ScreenTagData[i].sX;
	iyLen = ScreenTagData[i].eY+1 - ScreenTagData[i].sY;
	if(ScreenTagData[i].BeShapeUsed == 1)
	{
		ShapeNo= GetCommentShapeNo(i);
/*		switch(CommentEventTbl->ShapeNo){*/
		switch(ShapeNo){
			case 1:
				ixLen -= 6;		/* 3 */
				iyLen -= 6;		/* 3 */
				break;
			case 2:
			case 6:
				ixLen -= 8;		/* 4 */
				iyLen -= 8;		/* 4 */
				break;
			case 3:
			case 4:
			case 5:
				ixLen -= 10;	/* 5 */
				iyLen -= 10;	/* 5 */
				break;
		}

	}

	if(SizeH==0 && SizeV==0){
		ixLen = ixLen / 6;
		iyLen = iyLen / 8;
	}else if(SizeH==0){
		ixLen = ixLen / 8;
		iyLen = iyLen / 8;
	}else{
		ixLen = ixLen / (SizeV * 8);
		iyLen = iyLen / (SizeH * 16);
	}
	iCnt = 0;
	iLen = 0;
	strcpy(AllTagBuffer,Data);
	iData1 =0;
	for(y=0; y<iyLen; y++){
		iflag = 0;
		for(x=0; x<ixLen; x++){
			if(AllTagBuffer[x+iCnt]==0x0D){
				iflag = 1;
				iCnt+=2;
				break;
				}
			memcpy(RetData+iLen,AllTagBuffer+(x+iCnt),1);
			iLen++;
		}
		if(iflag==0){
			Point = strchr(AllTagBuffer+iCnt,0x0D);
			if(((int)Point) != 0x00){
				iCnt = (int)(Point-AllTagBuffer);
				iCnt+=2;
			}
			else
				break;
		}else
			iCnt+=x;
		if(iyLen==(y+1))
			break;
/*********************************************/
		iData = 0;
		for(i=iData1;i<iLen;i++)
		{
			if((unsigned char)RetData[i] < 0x7f && 0x00 < (unsigned char)RetData[i])
			{
				iData++;
			}
		}
		if(iData%2 != (iLen-iData1)%2)
			RetData[iLen-1] = 0x20;
/*********************************************/		
		memset(RetData+iLen,0x0D,1);
		iLen++;
		memset(RetData+iLen,0x0A,1);
		iLen++;
		iData1 = iLen;
	}

	iData = 0;
	for(i=iData1;i<iLen;i++)
	{
		if((unsigned char)RetData[i] < 0x7f && 0x00 < (unsigned char)RetData[i])
		{
			iData++;
		}
	}
	if(iData%2 != (iLen-iData1)%2)
		RetData[iLen-1] = 0x20;

/*	memset(Data,0x00,strlen(Data)); 040610*/
	Data[0]= 0;
	strcpy(Data,RetData);
	FreeMail((char*)RetData);
	FreeMail((char*)AllTagBuffer);
}
