/* *******************************************************************************/
/*  �� �� �� : GP_GlpSet.cpp													 */
/*  ��    �� : 													 */
/*  �� �� �� : 											 */
/*  �� �� �� : 															 */
/*  ��    �� : (��)Autonics														 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
#include	"sgt.h"

//#define	SET_TEST	1
#ifdef	LP_S044
/* *******************************************************************************/
/*  �Լ� ������ Ÿ�� ����														 */
/* *******************************************************************************/
int	IoSlotNo;
#ifdef	OLD
/* *******************************************************************************/
/*  �Լ�																		 */
/* *******************************************************************************/
void	DisplayExtName(int TLineCnt, int iStartNum)
{
	short		i;
	short		iNumY;
	char		ScreenNum[40];
	char		BaseTitle[33];
	unsigned char*	TitleAddr;

	for(i=0;i<3;i++)
	{
		memset(ScreenNum,0x00,sizeof(ScreenNum));
		memset(BaseTitle,0x00,sizeof(BaseTitle));
		iNumY = (i*18);
		AreaClear(2,25+iNumY,195,39+iNumY,0);
		if((extSlotInfo.ExtInfo[iStartNum+i].ID != 00) && (extSlotInfo.ExtInfo[iStartNum+i].ID != 0xff)){
#ifdef	WIN32
			TitleAddr= (unsigned char*)&GpFont[(PARAM_MODULE_NAME+ (extSlotInfo.ExtInfo[iStartNum+i].ID* 16))];
#else
			TitleAddr= (unsigned char*)(PARAM_MODULE_NAME+ (extSlotInfo.ExtInfo[iStartNum+i].ID* 16));
#endif
			memcpy(BaseTitle,TitleAddr,16);
		}else{	strcpy(BaseTitle,"XXXXXXXXXXXXXXXX");	}

		sprintf(ScreenNum,"%3d %s",i+iStartNum,BaseTitle);
		DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, ScreenNum, 1, 1, NON_TRANS,T_WHITE,T_BLACK);
		if(iStartNum+i+1 >= MAX_EXT_CNT)
			break;
	}
	ScroolBarDisplay(TLineCnt,iStartNum);
	DrawLcdBank1();
}
/* *******************************************************************************/
/*  �� �� �� : ModelVerDisp()													 */
/*  ��    �� : GP Model name, ver display										 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2006�� 03�� 15�� (��)											 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
void	GlpExtBoadDisp(int* iScreenNo)
{
	int				iKeyCode;
	short			TLineCnt;			/* �� ���� ��		*/
	short			NowPoint;			/* ���� ȭ�� ����	*/
	short			iKeyFlag;
	
	iKeyFlag = 1;
	iUserScreenFlag = 0;
	NowPoint = 0;

	DefaultFormDisplay(ARROW_FORM,Dspname[GLP_BOARD].chTitle[Set.iLang]);
	GlpItemLine();

	TLineCnt = MAX_EXT_CNT;		//Board Count

	DisplayExtName(TLineCnt,NowPoint);

	while(*iScreenNo == SET_GLP_NUM)
	{
		while(1)
		{
			/* leesi 040612  iKeyCode = KeyWait();  */
			iKeyCode = iKeyReturn(SET_GLP_NUM);
			if(iKeyFlag == 0 || iKeyCode == PC_DNLOAD_START || iKeyCode == PC_UPLOAD_START || iKeyCode == 0){	break;	}
		}
		iKeyFlag = 0;

		if(( iKeyCode == KEY_01 || iKeyCode == KEY_02  ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_43) ||
			(iKeyCode >= KEY_46 && iKeyCode <= KEY_60))) {	iKeyFlag = 1;	NormalBuzzer();	}
		switch(iKeyCode){
		case PC_DNLOAD_START:							*iScreenNo = DOWN_TRANS;		break;		/* DownLoad	*/
		case PC_UPLOAD_START:							*iScreenNo = UP_TRANS;			break;		/* UPLoad	*/
		case KEY_01: case KEY_02:				*iScreenNo = USER_SCREEN_NUM;	break;
		case KEY_13: case KEY_14: case KEY_15:	*iScreenNo = SELECT_MEMU_NUM;	break;
		case KEY_29: case KEY_30:  		/* UP_KEY */
			if(NowPoint > 0){	NowPoint--;	DisplayExtName(TLineCnt,NowPoint);	}
			iKeyFlag = 0;
			break;
		case KEY_59: case KEY_60:		/* DOWN_KEY	 */
			if(TLineCnt-NowPoint > 3){	NowPoint++;	DisplayExtName(TLineCnt,NowPoint);	}
			iKeyFlag = 0;
			break;
		case KEY_28:  /* Gage UP ó  �� */ /************************************************************/
			if(NowPoint != 0){	NowPoint = 0;	DisplayExtName(TLineCnt,NowPoint);	}
			iKeyFlag = 0;
			break;
		case KEY_43:  /* Gage Midle ��  �� */
			if(NowPoint != (TLineCnt/2-1) && (TLineCnt/2-1) > 3){
				NowPoint = (TLineCnt/2-1);
				DisplayExtName(TLineCnt,NowPoint);
			}
			iKeyFlag = 0;
			break;
		case KEY_58:  /* Gage DOWN ������ */
			if(TLineCnt-NowPoint > 3 && TLineCnt > 3)
			{
				NowPoint = TLineCnt-3;
				DisplayExtName(TLineCnt,NowPoint);
			}
			iKeyFlag = 0;
			break;
		default:
			//1Line
			if(iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ){
				if((extSlotInfo.ExtInfo[NowPoint].ID & 0xf0) == EXT_IO_IO){
					IoSlotNo= extSlotInfo.ExtInfo[NowPoint].SlotNo;
					*iScreenNo = SELECT_IO_NUM;
				}
			}
			//2Line
			else if(iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ){
				if((extSlotInfo.ExtInfo[NowPoint+1].ID & 0xf0) == EXT_IO_IO){
					IoSlotNo= extSlotInfo.ExtInfo[NowPoint+1].SlotNo;
					*iScreenNo = SELECT_IO_NUM;
				}
			}
			//3Line
			else if(iKeyCode >= KEY_46 && iKeyCode <= KEY_57 ){
				if((extSlotInfo.ExtInfo[NowPoint+2].ID & 0xf0) == EXT_IO_IO){
					IoSlotNo= extSlotInfo.ExtInfo[NowPoint+2].SlotNo;
					*iScreenNo = SELECT_IO_NUM;
				}
			}
			else{	iKeyCode= -1;	}
			break;
		}
		iScreenDisp = 0;
	}
}
#endif
void	GlpItemLine(void)
{
	int				i;
	int		iNumY;
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;
	for(i=0;i<3;i++)
	{
		iNumY = (i*18);
		RectAngleOut(GAMEN_START_X+1,GAMEN_START_Y+24+iNumY,GAMEN_START_X+196,GAMEN_START_Y+40+iNumY,&RECParam);
	}
}
void	SelectIoSettingMenu(int *iScreenNo)
{

	int		iKeyCode;
	int		iSetFlag ; 
	int		i;
	int		j;
	short	iKeyFlag;

	iKeyFlag	= 1;  /* iKeyFlag	= 1�϶� ���� ȭ���� ��������, 0�϶� ���� ȭ�� ��� ���� */
	iSetFlag	= 1;  /* up/down �� ǥ�� ���� ���� �÷��� */

	while ( *iScreenNo == SELECT_IO_NUM ) {
		DefaultFormDisplay(4 , Dspname[GLP_IO_SEL].chTitle[Set.iLang]);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */

		IoSlotNo= 0;
		i = 0;
		iKeyCode = -1;
		while (iKeyCode == -1 || iKeyCode == 0) {
			if(iSetFlag != 0)
			{
				AreaClear(GAMEN_START_X+0,GAMEN_START_Y+23,GAMEN_START_X+197,GAMEN_START_Y+79,0);
				for(j=0;j<3;j++)
				{
					DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+(NLine_2+(j*18)),(Dspname[GLP_IO_SEL].chName[Set.iLang][i+j+3]),1,1, TRANS, T_WHITE, T_BLACK);		
				}
				ScroolBarDisplay(5, i);
				DrawLcdBank1();	
				iSetFlag = 0;
			}
			
			while(1)
			{
				iKeyCode = iKeyReturn(GLP_IO_SEL);
				if(iKeyFlag == 0 || iKeyCode == PC_DNLOAD_START || iKeyCode == PC_UPLOAD_START || iKeyCode == 0){	break;	}
			}
			iKeyFlag = 0;
			if(!((iKeyCode >= KEY_03 && iKeyCode <= KEY_12 ) ||
				 iKeyCode == KEY_44 || iKeyCode == KEY_45 ||
				 iKeyCode == 0)){
				iKeyFlag = 1;
				if(iKeyCode != PC_DNLOAD_START){
					NormalBuzzer();			/*	Buzzer			*/
				}
			}
			switch(iKeyCode){
			case PC_DNLOAD_START:				*iScreenNo = DOWN_TRANS;		break;	/* DownLoad	*/
			case PC_UPLOAD_START:				*iScreenNo = UP_TRANS;			break;	/* UPLoad	*/
			case KEY_01: case KEY_02:	*iScreenNo = USER_SCREEN_NUM;	break;
			case KEY_13: case KEY_14: case KEY_15:	*iScreenNo = SELECT_MEMU_NUM;		break;
			case KEY_28:  /* Gage UP ó  �� */ /************************************************************/
				if(i != 0){	i = 0;	iSetFlag= 1;	}
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
			case KEY_43:  /* Gage Midle?? �� */
				i= 1;
				iSetFlag= 1;
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
			case KEY_58:  /* Gage Down ������ */
				i= 2;
				iSetFlag= 1;
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
			default:
				if (iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ){	*iScreenNo = SELECT_IO_FILTER_NUM + i;	break;	}
				if (iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ){	*iScreenNo = SELECT_IO_INT_NUM + i;		break;	}
				if (iKeyCode >= KEY_46 && iKeyCode <= KEY_57 ){	*iScreenNo = SELECT_IO_10KEY_NUM + i;	break;	}
				if (iKeyCode >= KEY_59 && iKeyCode <= KEY_60 ){
					if(i < 2){	i++;	iSetFlag = 1;	}						
					iKeyCode = -1;
					iKeyFlag = 0;
				}
				if (iKeyCode >= KEY_29 && iKeyCode <= KEY_30 ){
					if(i > 0){	i--;	iSetFlag = 1;	}						
					iKeyCode = -1;
					iKeyFlag = 0;
				}else{	iKeyCode = -1;	}
				break;
			}
		} 	
	} 
	KerRepeatFlag = 0;
	return;
}
char*	FilterMess[16]={
	"Direct","1ms","2ms","3ms","4ms","5ms","6ms","7ms",
	"8ms","9ms","10ms","11-15ms","16-20ms","21-25ms",

};
void	DispParaDevice(int y,int Use,unsigned short* DevAddr)
{
	char*	DevName;
	int		SioDevAddr;
	char	DispBuff[40];
	//Device Use
	DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+y, 
		Dspname[GLP_IO_FILTER].chName[Set.iLang][3], 1, 1, TRANS,T_WHITE,T_BLACK);
	if(Use == 0){		//No Use
		DotTextOut(GAMEN_START_X+90, GAMEN_START_Y+25+y, "NO USE", 1, 1, TRANS,T_WHITE,T_BLACK);
	}else{
		if(DeviceCode2Name((Get16Bit(DevAddr[0]) & 0xff00) >> 8,&DevName) == OK){
			SioDevAddr = (Get16Bit(DevAddr[0]) & 0x00ff << 24)+ Get16Bit(DevAddr[1]);
			sprintf(DispBuff,"%s%04d",DevName,SioDevAddr);
			DotTextOut(GAMEN_START_X+90, GAMEN_START_Y+25+y, DispBuff, 1, 1, TRANS,T_WHITE,T_BLACK);
		}
	}
}
unsigned char	ChangeFilterIdx(unsigned short data);
void	DisplayFilterSet(int idx,GLP_IO_INFO* IoSetData,int MaxCnt)
{
	int		i;
	int		iaddr;
	int		kind;
	int		iNumY;
	char	ScreenNum[40];
	char	IoTitle[10];

	for(i=0;i<2;i++,idx++)
	{
		sprintf(IoTitle,"X");
#ifdef	OLD		//20081027
		if(idx % 2){
			iaddr= 8;
			kind= IoSetData->FilterVal[idx/2] >> 4;
		}else{
			iaddr= 0;
			kind= IoSetData->FilterVal[idx/2] & 0x0f;
		}
		memset(ScreenNum,0x00,sizeof(ScreenNum));
		sprintf(ScreenNum,"%s%02X - %s%02X  %s",IoTitle,iaddr,IoTitle,iaddr+7,FilterMess[kind]);
#else
		if(idx % 2){	iaddr= 8;	}
		else{			iaddr= 0;	}
		kind= IoSetData->FilterVal[idx] & 0x7f;
		memset(ScreenNum,0x00,sizeof(ScreenNum));
		sprintf(ScreenNum,"%s%02X - %s%02X %3d[%s]",IoTitle,iaddr,IoTitle,iaddr+7,kind,FilterMess[ChangeFilterIdx(kind)]);
#endif
		iNumY = (i*18);
		DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, ScreenNum, 1, 1, TRANS,T_WHITE,T_BLACK);
	}
	iNumY = (i*18);
	DispParaDevice(iNumY,IoSetData->FilterDevUse,&IoSetData->FilterDev[0]);
	ScroolBarDisplay(MaxCnt,idx-3);
	DrawLcdBank1();
}
void	SetFilterUp(int idx,GLP_IO_INFO* IoSetData)
{
	int	kind;
	int	pos= idx/2;

	if(idx % 2){	kind= (IoSetData->FilterVal[pos] & 0xf0) >> 4;	}
	else{			kind= IoSetData->FilterVal[pos] & 0x0f;				}
	kind++;
	if(kind > 13){	kind= 0;	}
	if(idx % 2){	IoSetData->FilterVal[pos]= (IoSetData->FilterVal[pos] & 0x0f) + (kind << 4);	}
	else{			IoSetData->FilterVal[pos]= (IoSetData->FilterVal[pos] & 0xf0) + kind;			}
}
int		GetSlotParamidx(int slot)
{
	int	i;
	int	ret= NG;
	PARA_IO*	param;
	int	cnt;
	unsigned char*	CntBuf;

#ifdef	WIN32
	param= (PARA_IO*)&GpFont[PARAM_SLOT_START];
	CntBuf= (unsigned char*)&GpFont[PARAM_SLOT_CNT];
#else
	param= (PARA_IO*)PARAM_SLOT_START;
	CntBuf= (unsigned char*)PARAM_SLOT_CNT;
#endif
	cnt= CntBuf[2] << 8;
	cnt += CntBuf[3];
	for(i= 0; i < cnt; i++){
		if(param->slotNo == slot){			//I/O
			ret= i;
			break;
		}
		param++;
	}
	return(ret);
}
void	GetIoData(int slot,GLP_IO_INFO* IoSetData)
{
	unsigned char*	src;
	int	idx;


	idx= GetSlotParamidx(slot);
	if(idx != NG){
		src= (unsigned char*)&PlcDataSram.GlpIoInfo[idx];
		memcpy(IoSetData,src,sizeof(GLP_IO_INFO));
	}else{
		memset(IoSetData,0,sizeof(GLP_IO_INFO));
	}
}
void	GlpSetFilter(int* iScreenNo)
{
	int				iKeyCode;
	short			NowPoint;			/* ���� ȭ�� ����	*/
	short			iKeyFlag;
	GLP_IO_INFO*		IoSetData;
	GLP_IO_INFO*		SaveIoSetData;

	IoSetData= (GLP_IO_INFO*)TakeMemory(sizeof(GLP_IO_INFO));
	SaveIoSetData= (GLP_IO_INFO*)TakeMemory(sizeof(GLP_IO_INFO));
	GetIoData(IoSlotNo,IoSetData);
	memcpy(SaveIoSetData,IoSetData,sizeof(GLP_IO_INFO));

	iKeyFlag = 1;
	iUserScreenFlag = 0;
	NowPoint = 0;

	DefaultFormDisplay(ARROW_FORM,Dspname[GLP_IO_FILTER].chTitle[Set.iLang]);

	DisplayFilterSet(NowPoint,IoSetData,2);

	while(*iScreenNo == SELECT_IO_FILTER_NUM)
	{
		while(1)
		{
			/* leesi 040612  iKeyCode = KeyWait();  */
			iKeyCode = iKeyReturn(SELECT_IO_NUM);
			if(iKeyFlag == 0 || iKeyCode == PC_DNLOAD_START || iKeyCode == PC_UPLOAD_START || iKeyCode == 0){	break;	}
		}
		iKeyFlag = 0;
#ifdef	SET_TEST
		if(( iKeyCode == KEY_01 || iKeyCode == KEY_02  ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_43) ||
			(iKeyCode >= KEY_46 && iKeyCode <= KEY_60))) {	iKeyFlag = 1;	NormalBuzzer();	}
#else
		if( (iKeyCode == KEY_01 || iKeyCode == KEY_02) ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_15) ){	iKeyFlag = 1;	NormalBuzzer();	}
#endif

		switch(iKeyCode){
		case PC_DNLOAD_START:				*iScreenNo = DOWN_TRANS;		break;		/* DownLoad	*/
		case PC_UPLOAD_START:				*iScreenNo = UP_TRANS;			break;		/* UPLoad	*/
		case KEY_01: case KEY_02:	*iScreenNo = USER_SCREEN_NUM;	break;
		case KEY_13: case KEY_14: case KEY_15:	*iScreenNo = SELECT_IO_NUM;		break;
		case KEY_29: case KEY_30:										 		/* UP_KEY */
//			if(NowPoint > 0){	NowPoint--;	DisplayFilterSet(NowPoint,IoSetData,4);	}
			iKeyFlag = 0;
			break;
		case KEY_59: case KEY_60:												/* DOWN_KEY	 */
//			if(NowPoint < 5){	NowPoint++;	DisplayFilterSet(NowPoint,IoSetData);	}
//			if(NowPoint < (4-3)){	NowPoint++;	DisplayFilterSet(NowPoint,IoSetData,4);	}
			iKeyFlag = 0;
			break;
		case KEY_28:  /* Gage UP ó  �� */ /************************************************************/
//			if(NowPoint != 0){	NowPoint = 0;	DisplayFilterSet(NowPoint,IoSetData,4);	}
			iKeyFlag = 0;
			break;
		case KEY_43:  /* Gage Midle ��  �� */
//			NowPoint= 2;
//			NowPoint= 1;
//			DisplayFilterSet(NowPoint,IoSetData,2);
			iKeyFlag = 0;
			break;
		case KEY_58:  /* Gage Down ������ */
//			if(NowPoint < 3){	NowPoint = 3;	DisplayFilterSet(NowPoint,IoSetData);	}
//			if(NowPoint < 1){	NowPoint = 1;	DisplayFilterSet(NowPoint,IoSetData,4);	}
			iKeyFlag = 0;
			break;
		default:
			//1Line
			if(iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ){
#ifdef	SET_TEST
				SetFilterUp(NowPoint,IoSetData);
				DisplayFilterSet(NowPoint,IoSetData,2);
#endif
				break;
			}
			//2Line
			if(iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ){
#ifdef	SET_TEST
				SetFilterUp(NowPoint+1,IoSetData);
				DisplayFilterSet(NowPoint,IoSetData,2);
#endif
				break;
//			}
			//3Line
//			if(iKeyCode >= KEY_46 && iKeyCode <= KEY_57 ){
//				SetFilterUp(NowPoint+2,IoSetData);
//				DisplayFilterSet(NowPoint,IoSetData,4);
			}else{	iKeyCode= -1;	}
		}
		iScreenDisp = 0;
	}
//	if(memcmp(SaveIoSetData,IoSetData,sizeof(PARA_IO)) != 0){
		//Write Param
//		WriteParaData(IoSlotNo,IoSetData);
//	}
	FreeMail((char*)IoSetData);
	FreeMail((char*)SaveIoSetData);
}
char*	InterruptMess[4]={
	"No Int        ",
	"Rising        ",
	"Falling       ",
	"Rising/Falling",

};
void	DisplayInterSet(int idx,GLP_IO_INFO* IoSetData,int MaxCnt)
{
	int		i;
	int		iaddr;
	int		kind;
	int		iNumY;
	char	ScreenNum[40];
	char	IoTitle[10];
	int		pos,cnt,andData;

	for(i=0;i<3 && idx < MaxCnt-1;i++,idx++)
	{
		iaddr= idx* 2;
		pos= idx / 4;
		cnt= idx % 4;
		sprintf(IoTitle,"X");

		andData= 0x03 << (cnt*2);
		kind= (IoSetData->InterVal[pos] & andData) >> (cnt*2);

		memset(ScreenNum,0x00,sizeof(ScreenNum));
		sprintf(ScreenNum,"%s%02X-%s%02X %s",IoTitle,iaddr,
			IoTitle,iaddr+1,
			InterruptMess[kind]);
		iNumY = (i*18);
		DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, ScreenNum, 1, 1, TRANS,T_WHITE,T_BLACK);
	}
	if((idx == 8) && (i < 3)){		//Device Display
		idx++;
		iNumY = (i*18);
		//?���̈���N���A����B
		DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, "                      ", 1, 1, TRANS,T_WHITE,T_BLACK);
		DispParaDevice(iNumY,IoSetData->InterruptDevUse,&IoSetData->IntDev[0]);
	}
	ScroolBarDisplay(MaxCnt,idx-3);
	DrawLcdBank1();
}
void	SetInterUp(int idx,GLP_IO_INFO* IoSetData)
{
	int	kind;
	int	pos= idx/4;
	int	cnt= idx%4;
	int	andData;


	andData = 0x03 << (cnt*2);
	kind= (IoSetData->InterVal[pos] & andData) >> (cnt*2);
	kind++;
	if(kind > 3){	kind= 0;	}
	IoSetData->InterVal[pos]= (IoSetData->InterVal[pos] & ~andData) + (kind << (cnt*2));
}

void	GlpSetInterrupt(int* iScreenNo)
{
	int				iKeyCode;
	short			NowPoint;			/* ���� ȭ�� ����	*/
	short			iKeyFlag;
	GLP_IO_INFO*		IoSetData;
	GLP_IO_INFO*		SaveIoSetData;
	int		MaxDispCnt= 9;

	IoSetData= (GLP_IO_INFO*)TakeMemory(sizeof(GLP_IO_INFO));
	SaveIoSetData= (GLP_IO_INFO*)TakeMemory(sizeof(GLP_IO_INFO));
	GetIoData(IoSlotNo,IoSetData);
	memcpy(SaveIoSetData,IoSetData,sizeof(GLP_IO_INFO));
	iKeyFlag = 1;
	iUserScreenFlag = 0;
	NowPoint = 0;
	DefaultFormDisplay(ARROW_FORM,Dspname[GLP_IO_INT].chTitle[Set.iLang]);

	DisplayInterSet(NowPoint,IoSetData,MaxDispCnt);

	while(*iScreenNo == SELECT_IO_INT_NUM)
	{
		while(1)
		{
			/* leesi 040612  iKeyCode = KeyWait();  */
			iKeyCode = iKeyReturn(SELECT_IO_NUM);
			if(iKeyFlag == 0 || iKeyCode == PC_DNLOAD_START || iKeyCode == PC_UPLOAD_START || iKeyCode == 0){	break;	}
		}
		iKeyFlag = 0;
#ifdef	SET_TEST
		if(( iKeyCode == KEY_01 || iKeyCode == KEY_02  ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_43) ||
			(iKeyCode >= KEY_46 && iKeyCode <= KEY_60))) {	iKeyFlag = 1;	NormalBuzzer();	}
#else
		if( (iKeyCode == KEY_01 || iKeyCode == KEY_02) ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_15) ||
			(iKeyCode >= KEY_29 && iKeyCode <= KEY_30) ||
			(iKeyCode >= KEY_59 && iKeyCode <= KEY_60) ||
			(iKeyCode == KEY_28 || iKeyCode == KEY_43) ||
			(iKeyCode == KEY_58)) {	iKeyFlag = 1;	NormalBuzzer();	}
#endif

		switch(iKeyCode){
		case PC_DNLOAD_START:				*iScreenNo = DOWN_TRANS;		break;		/* DownLoad	*/
		case PC_UPLOAD_START:				*iScreenNo = UP_TRANS;			break;		/* UPLoad	*/
		case KEY_01: case KEY_02:	*iScreenNo = USER_SCREEN_NUM;	break;
		case KEY_13: case KEY_14: case KEY_15:	*iScreenNo = SELECT_IO_NUM;		break;
		case KEY_29: case KEY_30: 					/* UP_KEY */
			if(NowPoint > 0){	NowPoint--;	DisplayInterSet(NowPoint,IoSetData,MaxDispCnt);	}
			iKeyFlag = 0;
			break;
		case KEY_59: case KEY_60:					/* DOWN_KEY	 */
//			if(NowPoint < 13){	NowPoint++;	DisplayInterSet(NowPoint,IoSetData);	}
			if(NowPoint < (MaxDispCnt-3)){	NowPoint++;	DisplayInterSet(NowPoint,IoSetData,MaxDispCnt);	}
			iKeyFlag = 0;
			break;
		case KEY_28:  /* Gage UP ó  �� */ /************************************************************/
			if(NowPoint != 0){	NowPoint = 0;	DisplayInterSet(NowPoint,IoSetData,MaxDispCnt);	}
			iKeyFlag = 0;
			break;
		case KEY_43:  /* Gage Midle?? �� */
//			NowPoint= 3;
			NowPoint= 2;
			DisplayInterSet(NowPoint,IoSetData,MaxDispCnt);
			iKeyFlag = 0;
			break;
		case KEY_58:  /* Gage Down ������ */
//			if(NowPoint < 13){	NowPoint = 13;	DisplayInterSet(NowPoint,IoSetData);	}
			if(NowPoint < (MaxDispCnt-3)){	NowPoint = (MaxDispCnt-3);	DisplayInterSet(NowPoint,IoSetData,MaxDispCnt);	}
			iKeyFlag = 0;
			break;
		default:
			//1Line
			if(iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ){
#ifdef	SET_TEST
				SetInterUp(NowPoint,IoSetData);
				DisplayInterSet(NowPoint,IoSetData,MaxDispCnt);
#endif
				break;
			}
			//2Line
			if(iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ){
#ifdef	SET_TEST
				SetInterUp(NowPoint+1,IoSetData);
				DisplayInterSet(NowPoint,IoSetData,MaxDispCnt);
#endif
				break;
			}
			//3Line
			if(iKeyCode >= KEY_46 && iKeyCode <= KEY_57 ){
#ifdef	SET_TEST
				SetInterUp(NowPoint+2,IoSetData);
				DisplayInterSet(NowPoint,IoSetData,MaxDispCnt);
#endif
			}
			else{	iKeyCode= -1;	}
			break;
		}
		iScreenDisp = 0;
	}
//	if(memcmp(SaveIoSetData,IoSetData,sizeof(PARA_IO)) != 0){
		//Write Param
//		WriteParaData(IoSlotNo,IoSetData);
//	}
	FreeMail((char*)IoSetData);
	FreeMail((char*)SaveIoSetData);
}
void	DispCtlDevice(int y,int Use)
{
	//Device Control
	DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+y, 
		Dspname[GLP_IO_FILTER].chName[Set.iLang][4], 1, 1, TRANS,T_WHITE,T_BLACK);
	if(Use == 0){		//No Use
		DotTextOut(GAMEN_START_X+90, GAMEN_START_Y+25+y, "NO USE", 1, 1, TRANS,T_WHITE,T_BLACK);
	}else{
		DotTextOut(GAMEN_START_X+90, GAMEN_START_Y+25+y, "USE", 1, 1, TRANS,T_WHITE,T_BLACK);
	}
}
void	Display10KeySet(int NowPos,GLP_IO_INFO* IoSetData,int MaxCnt)
{
	int		i;
	int		iNumY;
	int		xOffSet= 90;

	for(i= 0; i < 3; i++,NowPos++){
		//USE_FLAG
		iNumY = i*18;
		AreaClear(2,25+iNumY,195,39+iNumY,0);
		switch(NowPos){
		case 0:
			//USE_FLAG
			DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_10KEY].chName[Set.iLang][3], 1, 1, TRANS,T_WHITE,T_BLACK);
			DotTextOut(GAMEN_START_X+xOffSet, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_10KEY].chName[Set.iLang][IoSetData->TenkeyUse+6], 1, 1, TRANS,T_WHITE,T_BLACK);
			break;
		case 1:
			DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_10KEY].chName[Set.iLang][4], 1, 1, TRANS,T_WHITE,T_BLACK);
			DotTextOut(GAMEN_START_X+xOffSet, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_10KEY].chName[Set.iLang][IoSetData->Tenkey_Inreg+8], 1, 1, TRANS,T_WHITE,T_BLACK);
			break;
		case 2:
			DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_10KEY].chName[Set.iLang][5], 1, 1, TRANS,T_WHITE,T_BLACK);
			DotTextOut(GAMEN_START_X+xOffSet, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_10KEY].chName[Set.iLang][IoSetData->Tenkey_Outreg+10], 1, 1, TRANS,T_WHITE,T_BLACK);
			break;
		case 3:		//Device
			DispParaDevice(iNumY,IoSetData->TenkeyUse,&IoSetData->TenkeyDev[0]);
			break;
		case 4:		//Set Use
			DispCtlDevice(iNumY,IoSetData->TenkeyDevUse);
			break;
		}
	}
	GlpItemLine();
//	ScroolBarDisplay(3,0);
	ScroolBarDisplay(MaxCnt,NowPos-3);
	DrawLcdBank1();
}
void	Display7SegSet(int NowPos,GLP_IO_INFO* IoSetData,int MaxCnt)
{
	int		i;
	int		iNumY;
	int		DataOutPort;
	int		xOffSet= 90;

	DataOutPort= IoSetData->Seg7_Outreg == 0 ? 1 : 0;
	for(i= 0; i < 3; i++,NowPos++){
		//USE_FLAG
		iNumY = i*18;
		AreaClear(2,25+iNumY,195,39+iNumY,0);
		switch(NowPos){
		case 0:
			DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_7SEG].chName[Set.iLang][3], 1, 1, TRANS,T_WHITE,T_BLACK);
			DotTextOut(GAMEN_START_X+xOffSet, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_7SEG].chName[Set.iLang][IoSetData->Seg7Use+6], 1, 1, TRANS,T_WHITE,T_BLACK);
			break;
		case 1:
			DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_7SEG].chName[Set.iLang][4], 1, 1, TRANS,T_WHITE,T_BLACK);
			DotTextOut(GAMEN_START_X+xOffSet, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_7SEG].chName[Set.iLang][IoSetData->Seg7_Outreg+8], 1, 1, TRANS,T_WHITE,T_BLACK);
			break;
		case 2:
			DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_7SEG].chName[Set.iLang][5], 1, 1, TRANS,T_WHITE,T_BLACK);
			DotTextOut(GAMEN_START_X+xOffSet, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_7SEG].chName[Set.iLang][DataOutPort+10], 1, 1, TRANS,T_WHITE,T_BLACK);
			break;
		case 3:		//Device
			DispParaDevice(iNumY,IoSetData->Seg7Use,&IoSetData->Seg7Dev[0]);
			break;
		case 4:		//Set Use
			DispCtlDevice(iNumY,IoSetData->Seg7DevUse);
			break;
		}
	}
	GlpItemLine();
//	ScroolBarDisplay(3,0);
	ScroolBarDisplay(MaxCnt,NowPos-3);
	DrawLcdBank1();
}
void	DisplayItemSet(int NowPos,int iScreenNo,GLP_IO_INFO* IoSetData,int MaxCnt)
{
	switch(iScreenNo){
	case SELECT_IO_10KEY_NUM:	Display10KeySet(NowPos,IoSetData,MaxCnt);	break;
	case SELECT_IO_7SEG_NUM:	Display7SegSet(NowPos,IoSetData,MaxCnt);	break;
//	case SELECT_IO_PULS_NUM:	DisplayPulsSet(IoSetData);	break;
//	case SELECT_IO_ENCODE_NUM:	DisplayEncSet(IoSetData);	break;
//	case SELECT_IO_CNT_NUM:		DisplayCntSet(IoSetData);	break;
//	case SELECT_IO_PATRN_NUM:	DisplayPatrnSet(IoSetData);	break;
	}
}
#ifdef	XXXXX
void	SetItem10Key(int no,GLP_IO_INFO* IoSetData)
{
	switch(no){
	case 0:
		IoSetData->TenkeyUse= (IoSetData->TenkeyUse+1)%2;
		Display10KeySet(IoSetData);
		break;
	case 1:
		IoSetData->Tenkey_Inreg= (IoSetData->Tenkey_Inreg+1)%2;
		Display10KeySet(IoSetData);
		break;
	case 2:
		IoSetData->Tenkey_Outreg= (IoSetData->Tenkey_Outreg+1)%2;
		Display10KeySet(IoSetData);
		break;
	}
}
void	SetItem7Seg(int no,GLP_IO_INFO* IoSetData)
{
	switch(no){
	case 0:
		IoSetData->Seg7Use= (IoSetData->Seg7Use+1)%2;
		Display7SegSet(IoSetData);
		break;
	case 1:
	case 2:
		IoSetData->Seg7_Outreg= (IoSetData->Seg7_Outreg+1)%2;
		Display7SegSet(IoSetData);
		break;
	}
}
void	SetItem(int no,GLP_IO_INFO* IoSetData,int iScreenNo)
{
	switch(iScreenNo){
	case SELECT_IO_10KEY_NUM:	SetItem10Key(no,IoSetData);		break;
	case SELECT_IO_7SEG_NUM:	SetItem7Seg(no,IoSetData);		break;
//	case SELECT_IO_PULS_NUM:	SetItemPuls(no,IoSetData);		break;
//	case SELECT_IO_ENCODE_NUM:	SetItemEncode(no,IoSetData);	break;
//	case SELECT_IO_CNT_NUM:		SetItemCnt(no,IoSetData);		break;
//	case SELECT_IO_PATRN_NUM:	SetItemPatrn(no,IoSetData);		break;
	}
}
#endif
void	SetItemDefaultDisp(int iScreenNo)
{
	switch(iScreenNo){
	case SELECT_IO_10KEY_NUM:	DefaultFormDisplay(ARROW_FORM,Dspname[GLP_IO_10KEY].chTitle[Set.iLang]);	break;
	case SELECT_IO_7SEG_NUM:	DefaultFormDisplay(ARROW_FORM,Dspname[GLP_IO_7SEG].chTitle[Set.iLang]);		break;
//	case SELECT_IO_PULS_NUM:	DefaultFormDisplay(ARROW_FORM,Dspname[GLP_IO_PULS].chTitle[Set.iLang]);		break;
//	case SELECT_IO_ENCODE_NUM:	DefaultFormDisplay(ARROW_FORM,Dspname[GLP_IO_ENC].chTitle[Set.iLang]);		break;
//	case SELECT_IO_CNT_NUM:		DefaultFormDisplay(ARROW_FORM,Dspname[GLP_IO_CNT].chTitle[Set.iLang]);		break;
//	case SELECT_IO_PATRN_NUM:	DefaultFormDisplay(ARROW_FORM,Dspname[GLP_IO_PATRN].chTitle[Set.iLang]);	break;
	}
	
}

void	GlpSetItem(int* iScreenNo)
{
	int				iKeyCode;
	short			iKeyFlag;
	GLP_IO_INFO*		IoSetData;
	GLP_IO_INFO*		SaveIoSetData;
	int				SetScreenNo;
	int		MaxCnt= 5;
	int		NowPoint= 0;

	SetScreenNo= *iScreenNo;
	IoSetData= (GLP_IO_INFO*)TakeMemory(sizeof(GLP_IO_INFO));
	SaveIoSetData= (GLP_IO_INFO*)TakeMemory(sizeof(GLP_IO_INFO));
	GetIoData(IoSlotNo,IoSetData);
	memcpy(SaveIoSetData,IoSetData,sizeof(GLP_IO_INFO));
	iKeyFlag = 1;
	iUserScreenFlag = 0;
	/**************************/

	SetItemDefaultDisp(SetScreenNo);

	DisplayItemSet(NowPoint,SetScreenNo,IoSetData,MaxCnt);

	while(*iScreenNo == SetScreenNo){
		while(1){
			/* leesi 040612  iKeyCode = KeyWait();  */
			iKeyCode = iKeyReturn(SELECT_IO_NUM);
			if(iKeyFlag == 0 || iKeyCode == PC_DNLOAD_START || iKeyCode == PC_UPLOAD_START || iKeyCode == 0){	break;	}
		}
		iKeyFlag = 0;
#ifdef	SET_TEST
		if(( iKeyCode == KEY_01 || iKeyCode == KEY_02  ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_43) ||
			(iKeyCode >= KEY_46 && iKeyCode <= KEY_60))) {	iKeyFlag = 1;	NormalBuzzer();	}
#else
		if( iKeyCode == KEY_01 || iKeyCode == KEY_02   ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_15) ||
			(iKeyCode >= KEY_29 && iKeyCode <= KEY_30) ||
			(iKeyCode >= KEY_59 && iKeyCode <= KEY_60) ||
			iKeyCode == KEY_28 || iKeyCode == KEY_43   ||
			iKeyCode == KEY_58 ) {	iKeyFlag = 1;	NormalBuzzer();	}
#endif
		switch(iKeyCode){
		case PC_DNLOAD_START:				*iScreenNo = DOWN_TRANS;		break;		/* DownLoad	*/
		case PC_UPLOAD_START:				*iScreenNo = UP_TRANS;			break;		/* UPLoad	*/
		case KEY_01: case KEY_02:	*iScreenNo = USER_SCREEN_NUM;	break;
		case KEY_13: case KEY_14: case KEY_15:	*iScreenNo = SELECT_IO_NUM;		break;
		case KEY_29: case KEY_30:										 		/* UP_KEY */
			if(NowPoint > 0){	NowPoint--;	DisplayItemSet(NowPoint,SetScreenNo,IoSetData,MaxCnt);	}
			iKeyFlag = 0;
			break;
		case KEY_59: case KEY_60:												/* DOWN_KEY	 */
			if(NowPoint < MaxCnt-3){	NowPoint++;	DisplayItemSet(NowPoint,SetScreenNo,IoSetData,MaxCnt);	}
			iKeyFlag = 0;
			break;
		case KEY_28:  /* Gage UP ó  �� */ /************************************************************/
			if(NowPoint != 0){	NowPoint = 0;	DisplayItemSet(NowPoint,SetScreenNo,IoSetData,MaxCnt);	}
			iKeyFlag = 0;
			break;
		case KEY_43:  /* Gage Midle ��  �� */
			NowPoint = (MaxCnt-3)/2;	DisplayItemSet(NowPoint,SetScreenNo,IoSetData,MaxCnt);
			iKeyFlag = 0;
			break;
		case KEY_58:  /* Gage Down������ */
			NowPoint = MaxCnt-3;	DisplayItemSet(NowPoint,SetScreenNo,IoSetData,MaxCnt);
			iKeyFlag = 0;
			break;
		default:
#ifdef	SET_TEST
			//1Line
			if(iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ){	SetItem(0,IoSetData,SetScreenNo);	break;	}
			//2Line
			if(iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ){	SetItem(1,IoSetData,SetScreenNo);	break;	}
			//3Line
			if(iKeyCode >= KEY_46 && iKeyCode <= KEY_57 ){	SetItem(2,IoSetData,SetScreenNo);	break;	}
#endif
			iKeyCode= -1;
			break;
		}
		iScreenDisp = 0;
	}
//	if(memcmp(SaveIoSetData,IoSetData,sizeof(PARA_IO)) != 0){
		//Write Param
//		WriteParaData(IoSlotNo,IoSetData);
//	}

	FreeMail((char*)IoSetData);
	FreeMail((char*)SaveIoSetData);
}
const	int	SyncDataBit[8]={
	0,1,2,3,4,5,6,7
};
const	int	SyncDataCnt[8]={
	0,1,2,3,4,5,6,7
};
void	DisplaySycSet(int NowPos,GLP_IO_INFO* IoSetData,int MaxCnt)
{
	int		i;
	int		iNumY;
	char	DspBuff[40];
	int		xOffSet= 90;

	for(i= 0; i < 3; i++,NowPos++){
		//USE_FLAG
		iNumY = i*18;
		AreaClear(2,25+iNumY,195,39+iNumY,0);
		switch(NowPos){
		case 0:		//Use Flag
			DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_SYNC].chName[Set.iLang][3], 1, 1, TRANS,T_WHITE,T_BLACK);
			DotTextOut(GAMEN_START_X+xOffSet, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_SYNC].chName[Set.iLang][IoSetData->SyncSioUse+9], 1, 1, TRANS,T_WHITE,T_BLACK);
			break;
		case 1:		//Out Reg
			DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_SYNC].chName[Set.iLang][4], 1, 1, TRANS,T_WHITE,T_BLACK);
			DotTextOut(GAMEN_START_X+xOffSet, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_SYNC].chName[Set.iLang][IoSetData->Sync_Outreg+11], 1, 1, TRANS,T_WHITE,T_BLACK);
			break;
		case 2:		//DataBit
			DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_SYNC].chName[Set.iLang][5], 1, 1, TRANS,T_WHITE,T_BLACK);
			sprintf(DspBuff,"%d",SyncDataBit[IoSetData->Sync_Bit]);
			DotTextOut(GAMEN_START_X+xOffSet, GAMEN_START_Y+25+iNumY, DspBuff, 1, 1, TRANS,T_WHITE,T_BLACK);
			break;
		case 3:		//Count
			DotTextOut(GAMEN_START_X+3, GAMEN_START_Y+25+iNumY, 
				Dspname[GLP_IO_SYNC].chName[Set.iLang][6], 1, 1, TRANS,T_WHITE,T_BLACK);
			sprintf(DspBuff,"%d",SyncDataCnt[IoSetData->Sync_DataCnt]);
			DotTextOut(GAMEN_START_X+xOffSet, GAMEN_START_Y+25+iNumY, DspBuff, 1, 1, TRANS,T_WHITE,T_BLACK);
			break;
		case 4:		//Device
			DispParaDevice(iNumY,IoSetData->SyncSioUse,&IoSetData->SyncSioDev[0]);
			break;
		case 5:		//Set Use
			DispCtlDevice(iNumY,IoSetData->SyncSioDevUse);
			break;
		}
	}
	ScroolBarDisplay(MaxCnt,NowPos-3);
	GlpItemLine();
	DrawLcdBank1();
}
void	SetItemSync(int no,GLP_IO_INFO* IoSetData)
{
	switch(no){
	case 0:	IoSetData->SyncSioUse= (IoSetData->SyncSioUse+1)%2;	break;
	case 1:	IoSetData->Sync_Outreg= (IoSetData->Sync_Outreg+1)%2;		break;
	case 2:	IoSetData->Sync_Bit= (IoSetData->Sync_Bit+1)%4;	break;
	case 3:	IoSetData->SyncSioDataCnt= (IoSetData->SyncSioDataCnt+1)%7;		break;
	}
}
void	GlpSetSync(int* iScreenNo)
{
	int				iKeyCode;
	short			NowPoint;			/* ���� ȭ�� ����	*/
	short			iKeyFlag;
	GLP_IO_INFO*		IoSetData;
	GLP_IO_INFO*		SaveIoSetData;
	int				maxcnt;

	IoSetData= (GLP_IO_INFO*)TakeMemory(sizeof(GLP_IO_INFO));
	SaveIoSetData= (GLP_IO_INFO*)TakeMemory(sizeof(GLP_IO_INFO));
	GetIoData(IoSlotNo,IoSetData);
	memcpy(SaveIoSetData,IoSetData,sizeof(GLP_IO_INFO));
	iKeyFlag = 1;
	iUserScreenFlag = 0;
	NowPoint = 0;
	maxcnt= 6;
	DefaultFormDisplay(ARROW_FORM,Dspname[GLP_IO_SYNC].chTitle[Set.iLang]);

	DisplaySycSet(NowPoint,IoSetData,maxcnt);

	while(*iScreenNo == SELECT_IO_SYC_NUM)
	{
		while(1)
		{
			/* leesi 040612  iKeyCode = KeyWait();  */
			iKeyCode = iKeyReturn(SELECT_IO_NUM);
			if(iKeyFlag == 0 || iKeyCode == PC_DNLOAD_START || iKeyCode == PC_UPLOAD_START || iKeyCode == 0){	break;	}
		}
		iKeyFlag = 0;
#ifdef	SET_TEST
		if(( iKeyCode == KEY_01 || iKeyCode == KEY_02  ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_43) ||
			(iKeyCode >= KEY_46 && iKeyCode <= KEY_60))) {	iKeyFlag = 1;	NormalBuzzer();	}
#else
		if( iKeyCode == KEY_01 || iKeyCode == KEY_02   ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_15) ||
			(iKeyCode >= KEY_29 && iKeyCode <= KEY_30) ||
			(iKeyCode >= KEY_59 && iKeyCode <= KEY_60) ||
			iKeyCode == KEY_28 || iKeyCode == KEY_43   ||
			iKeyCode == KEY_58 ) {	iKeyFlag = 1;	NormalBuzzer();	}
#endif
		switch(iKeyCode){
		case PC_DNLOAD_START:							*iScreenNo = DOWN_TRANS;		break;		/* DownLoad	*/
		case PC_UPLOAD_START:							*iScreenNo = UP_TRANS;			break;		/* UPLoad	*/
		case KEY_01: case KEY_02:				*iScreenNo = USER_SCREEN_NUM;	break;
		case KEY_13: case KEY_14: case KEY_15:	*iScreenNo = SELECT_IO_NUM;		break;
		case KEY_29: case KEY_30:										 		/* UP_KEY */
			if(NowPoint > 0){	NowPoint--;	DisplaySycSet(NowPoint,IoSetData,maxcnt);	}
			iKeyFlag = 0;
			break;
		case KEY_59: case KEY_60:												/* DOWN_KEY	 */
			if(NowPoint < maxcnt-3){	NowPoint++;	DisplaySycSet(NowPoint,IoSetData,maxcnt);	}
			iKeyFlag = 0;
			break;
		case KEY_28:  /* Gage UP ó  �� */ /************************************************************/
			if(NowPoint != 0){	NowPoint = 0;	DisplaySycSet(NowPoint,IoSetData,maxcnt);	}
			iKeyFlag = 0;
			break;
		case KEY_43:  /* Gage Midle ��  �� */
			NowPoint = (maxcnt-3)/2;	DisplaySycSet(NowPoint,IoSetData,maxcnt);
			iKeyFlag = 0;
			break;
		case KEY_58:  /* Gage Down������ */
			NowPoint = maxcnt-3;	DisplaySycSet(NowPoint,IoSetData,maxcnt);
			iKeyFlag = 0;
			break;
		default:
#ifdef	SET_TEST
			//1Line
			if(iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ){
				SetItemSync(NowPoint,IoSetData);
				DisplaySycSet(NowPoint,IoSetData,maxcnt);
			}
			//2Line
			else if(iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ){
				SetItemSync(NowPoint+1,IoSetData);
				DisplaySycSet(NowPoint,IoSetData,maxcnt);
			}
			//3Line
			else if(iKeyCode >= KEY_46 && iKeyCode <= KEY_57 ){
				SetItemSync(NowPoint+2,IoSetData);
				DisplaySycSet(NowPoint,IoSetData,maxcnt);
			}
			else{	iKeyCode= -1;	}
#else
			iKeyCode= -1;
			break;
#endif
		}
		iScreenDisp = 0;
	}
//	if(memcmp(SaveIoSetData,IoSetData,sizeof(PARA_IO)) != 0){
		//Write Param
//		WriteParaData(IoSlotNo,IoSetData);
//	}
	FreeMail((char*)IoSetData);
	FreeMail((char*)SaveIoSetData);
}

#endif
