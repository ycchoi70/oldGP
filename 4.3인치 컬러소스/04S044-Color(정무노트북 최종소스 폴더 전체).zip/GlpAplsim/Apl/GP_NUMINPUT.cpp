/* ****************************************************************************** */
/*  �� �� ��E: GP_NUMINPUT.CPP													 */
/*  ��E   �� : 16����E�Է� ������E											 */
/*  �� �� �� : 2002��E2��E18�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��    �� : (��) LC Tech														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

#ifdef	SIZE_2480
/* ***************************************************************************** */
/*  �Լ�E																		 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  ��E��E��E: vNumInput()														 */
/*  ��E   �� : 10����E�Է� ������E											 */
/*  ��    �� : chKey	: �Է°� ����E�� ��ȯ										 */	
/* 			  iSize : char�� ũ��E											 */
/*  ÁE   �� : iReFlag															 */	
/* 			1: CLR ����   0: ENT ����											 */
/*  �� �� �� : 2002��E2��E18�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
int		iNumInput1(char *chKey, char *chKey1, int *iSize){
	
	int		iFont;
	int		iReFlag;									/* 0:ENT,	1:CLR		 */
	char	chReKey[10];									/* ��ȯ�� Ű ��			 */
	int		isX;
	memset(chReKey, 0x00, sizeof(chReKey));
	strcpy(chReKey,chKey);

	iReFlag = -1;									/* 0:ENT,	1:CLR		 */
	isX		= 0;
	if(*iSize == 2 || *iSize == 3)			/* GPA,DSA */
		isX = 76;
	iFont = 1;
	while ( iReFlag == -1 ) {
		vNumInputDisp1(chReKey, isX);					/*  ó��ȭ��E���		 */
		iReFlag = iNumInputSelect1(chKey, chKey1, iSize, isX, iFont,iFont);	/*  ���� ó��		 */
		if(iReFlag == DOWN_TRANS || iReFlag == UP_TRANS)
		{
			break;
		}
	} /*  end while  */

	return iReFlag;
}

/* ****************************************************************************** */
/*  ��E��E��E: vNumInputDisp()													 */
/*  ��E   �� : 10����E�Է¿�E������E											 */
/*  ��    �� :																	 */
/*  ÁE   �� :																	 */
/*  �� �� �� : 2002��E2��E18�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
void	vNumInputDisp1(char* chKey, int isX)

{	
	char	chDsp_buff[24];	
	int		iNum;
	int		iPosition;
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;
	iNum  = 0;
	memset(chDsp_buff,0x00,sizeof(chDsp_buff));
	/* �Է�â ǥ�� ������ŭ�� �κл��� */
	iNum = strlen(chKey);
	if(iNum == 0)
	{
		sprintf(chDsp_buff,"0");
		iNum = 1;
	}
	else
	{
		sprintf(chDsp_buff, chKey);
	}
	if(NowDip.iDev_NowPoint == 2)
		iPosition = 1;
	else
		iPosition = 0;
	if(isX == 0)
	{
/* ksc20050622 ���� ���� �߰� */
		AreaRevers(GAMEN_START_X+164,GAMEN_START_Y+NLine_2+((iPosition)*18),GAMEN_START_X+195,GAMEN_START_Y+NLine_2+((iPosition)*18)+15);
		
		DotTextOut(GAMEN_START_X+164,GAMEN_START_Y+NLine_2+((iPosition)*18),"   ",1,1, TRANS, T_WHITE, T_BLACK);

/* ksc20050622 Ŀ�� ���� ǥ�� ��ġ ���� */
		vLastDataReverse(188-(iNum*8),NLine_2+((iPosition)*18),chDsp_buff);

		vNumberInputPan(1);				/* �����Է�â */	
	}else
		vNumberInputPan(2);				/* �����Է�â */	

	RectAngleOut(2+isX,2,128+isX,19,&RECParam);
	/* �ԷµȰ� ��� */
		vLastDataReverse(111-(iNum*8)+isX,Line_1+1,chDsp_buff);
	/*vBoxInLine(0,0,120,19);*/				/* �Է°� ��� ȭ��E		 */	

	DrawLcdBank1();	
	return;
}

/* ****************************************************************************** */
/*  ��E��E��E: iNumInputSelect()													 */
/*  ��E   �� : ȭ��E���ý� ó��													 */
/*  ��    �� :																	 */
/*  ÁE   �� : iReFlag 0 : ENT 1:CLR												 */
/*  �� �� �� : 2002��E2��E18�� (��E												 */
/*  �� �� �� : ȫ �� ��E														 */
/*  ��E   ��E: 																	 */
/* ****************************************************************************** */
int		iNumInputSelect1(char* chData, char* chData1, int* iSizeData, int isX, int iFont,int is)
{
	
	int			iKeyCode;
	int			iReFlag;
	int			iKeyPositon;
	int			iNum;
	int			iSize;
	int			iFlag;
	int			iMax;
	int			iMin;
	short		iLen;
	short	iKeyFlag;
	double long	iLong;

	char	chValue[14];
	char	chKeyData[14];
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;
	iLong		= 0;
	iKeyPositon = 0;
	iNum		= 0;
	iFlag		= 0;
	iKeyCode	= -1;
	iReFlag		= -1;
	iSize		= *iSizeData;
	iKeyFlag	= 1;
	if(*iSizeData == 11)
	{
		iMax = 2147483647;
		iMin = -2147483647;
	}
	else if(*iSizeData == 6)
	{
		iMax = 32767;
		iMin = -32768;
	}else if(*iSizeData == 2){
		iMax = 31;
		iMin = 0;
	}else{
		iMax = 255;
		iMin = 0;
	}
	if(NowDip.iDev_NowPoint == 2)
		*iSizeData = 1;
	else
		*iSizeData = 0;

	memset(chValue, 0x00, sizeof(chValue));
	memset(chKeyData, 0x00, sizeof(chKeyData));
	if ( isX == 0 ) {
		iKeyPositon = 5;
	} else if ( isX == 76 ) {
		iFlag = 4;
		iKeyPositon = 0;
	} /* end if */

	
	while (iReFlag != 0 && iReFlag != 1) {
		iKeyCode = KeyWaitData(iKeyFlag,0xffff);							/* �Էµ� Ű���� �о���	 */
		iKeyFlag = 0;
		if (iKeyCode == (KEY_14-iKeyPositon) || iKeyCode == (KEY_15-iKeyPositon) ||
			(iKeyCode >= (KEY_21-iKeyPositon) && iKeyCode <= (KEY_30-iKeyPositon) ) ||
			(iKeyCode >= (KEY_36-iKeyPositon) && iKeyCode <= (KEY_45-iKeyPositon) ) ||
			(iKeyCode >= (KEY_51-iKeyPositon) && iKeyCode <= (KEY_60-iKeyPositon) )) 
			{
				iKeyFlag = 1;
				NormalBuzzer();				/*	Buzzer  */
			}		
			if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
			{												
				iReFlag = DOWN_TRANS;
				break;
			}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
			{
				iReFlag = UP_TRANS;
				break;
			}

		/* Ű ���� ó�� */		
		if (iKeyCode >= KEY_14 - iKeyPositon && iKeyCode <= KEY_15 - iKeyPositon ) {			/*  CLR				 */
			iReFlag = 1;
			memset(chKeyData, 0x00, sizeof(chKeyData));
			* iSizeData = 2;
			break;
		} else if (iKeyCode == KEY_40 - iKeyPositon || iKeyCode == KEY_41 - iKeyPositon) {		/*  6				 */
			strcat(chKeyData, "6");	
			iFlag = 1;
		} else if (iKeyCode == KEY_42 - iKeyPositon || iKeyCode == KEY_43 - iKeyPositon) {		/*  7				 */
			strcat(chKeyData, "7");
			iFlag = 1;
		} else if (iKeyCode >= KEY_51 - iKeyPositon && iKeyCode <= KEY_52 - iKeyPositon) {		/*  8				 */
			strcat(chKeyData, "8");
			iFlag = 1;
		} else if (iKeyCode >= KEY_53 - iKeyPositon && iKeyCode <= KEY_54 - iKeyPositon ) {		/*  9				 */
			strcat(chKeyData, "9");
			iFlag = 1;
		} else if (iKeyCode >= KEY_29 - iKeyPositon&& iKeyCode <= KEY_30 - iKeyPositon) {		/*  ��				 */
		/*		if((iFlag == 0) && ((NowDip.cDev_Now[0]=='C' && (Dev_C[NowDip.iDev_NowNum].iDev_Set != 999999)) || (NowDip.cDev_Now[0]=='T' && (Dev_T[NowDip.iDev_NowNum].iDev_Set != 999999))) )*//*  Ű����E */
				if((iFlag == 0) && (NowDip.iDev_Type == 4) && RetrunSetVal(NowDip.iDev_NowNum)==1)
				{
					if(*iSizeData == 0){
						iNum = strlen(chData);
						DotTextOut(GAMEN_START_X+190-(iNum*8),GAMEN_START_Y+NLine_2+((*iSizeData)*18),chData,1,1, TRANS, T_WHITE, T_BLACK);
					}else{
						iNum = strlen(chData1);
						DotTextOut(GAMEN_START_X+190-(iNum*8),GAMEN_START_Y+NLine_2+((*iSizeData)*18),chData1,1,1, TRANS, T_WHITE, T_BLACK);
					}
					*iSizeData = (*iSizeData==1 ? 0 : 1);
					iFlag = 3;
				}
		} else if (iKeyCode == KEY_25 - iKeyPositon || iKeyCode == KEY_26 - iKeyPositon) {		/*  2				 */
			strcat(chKeyData, "2");
			iFlag = 1;
		} else if (iKeyCode == KEY_27 - iKeyPositon || iKeyCode == KEY_28 - iKeyPositon) {		/*  3				 */
			strcat(chKeyData, "3");
			iFlag = 1;
		} else if (iKeyCode >= KEY_36 - iKeyPositon && iKeyCode <= KEY_37 - iKeyPositon) {		/*  4				 */
			strcat(chKeyData, "4");
			iFlag = 1;
		} else if (iKeyCode >= KEY_38 - iKeyPositon && iKeyCode <= KEY_39 - iKeyPositon) {		/*  5				 */
			strcat(chKeyData, "5");
			iFlag = 1;
		} else if (iKeyCode >= KEY_44 - iKeyPositon && iKeyCode <= KEY_45 - iKeyPositon) {		/*  �Ʒ�				 */
	/*			if( && ((NowDip.cDev_Now[0]=='C' && (Dev_C[NowDip.iDev_NowNum].iDev_Set != 999999)) || (NowDip.cDev_Now[0]=='T' && (Dev_T[NowDip.iDev_NowNum].iDev_Set != 999999))) )*//*  Ű��  */
				if((iFlag == 0) && (NowDip.iDev_Type == 4) &&  RetrunSetVal(NowDip.iDev_NowNum)==1){
					if(*iSizeData == 0){
						iNum = strlen(chData);
						DotTextOut(GAMEN_START_X+190-(iNum*8),GAMEN_START_Y+NLine_2+((*iSizeData)*18),chData,1,1, TRANS, T_WHITE, T_BLACK);
					}else{
						iNum = strlen(chData1);
						DotTextOut(GAMEN_START_X+190-(iNum*8),GAMEN_START_Y+NLine_2+((*iSizeData)*18),chData1,1,1, TRANS, T_WHITE, T_BLACK);
					}
					*iSizeData = (*iSizeData==1 ? 0 : 1);
					iFlag = 3;
				}
				
		} else if (iKeyCode == KEY_21 - iKeyPositon || iKeyCode == KEY_22 - iKeyPositon) {		/*  0				 */
			if((strcmp(chKeyData,"-0")) == 0 || (strcmp(chKeyData,"-")) == 0)
				strcpy(chKeyData, "0");
			else
				strcat(chKeyData, "0");
			iFlag = 1;
		} else if (iKeyCode == KEY_23 - iKeyPositon || iKeyCode == KEY_24 - iKeyPositon) {		/*  1				 */
			strcat(chKeyData, "1");
			iFlag = 1;
		} else if (iKeyCode >= KEY_55 - iKeyPositon && iKeyCode <= KEY_56 - iKeyPositon) {		/*  -				 */
			
			strcpy(chKeyData, "-");
			iFlag = 1;
		} else if (iKeyCode >= KEY_57 - iKeyPositon && iKeyCode <= KEY_58 - iKeyPositon) {		/*  BS 				 */

/* ksc20050622 �߰� */	/* SET Ŭ���� Ű�Էµ���Ÿ�� ��� ���� ����Ÿ�� �״�� ��밡���ϵ��� ���� */
			if(chKeyData[0] != 0){		/* Ű�Է� ����Ÿ�� ������ chData ���� ���� */
				memset(chData, 0x00, sizeof(chData));
			}
			if(chKeyData[0] == 0){		/* Ű�Է� ����Ÿ�� ������ chData ������ Ű���۷� �ű�� chData ���� ���� */
				strcpy(chKeyData, chData);
				memset(chData, 0x00, sizeof(chData));
			}			
			iLen = strlen(chKeyData);
			if(iLen>0)
			{
				chKeyData[iLen-1] = 0x00;
			}
			iFlag = 1;
		} else if (iKeyCode >= KEY_59 - iKeyPositon && iKeyCode <= KEY_60 - iKeyPositon) {		/*  ENT				 */
			if(strlen(chKeyData)!=0)
			{
				iNum = gatoi(chKeyData);
				if(iMax>=iNum && iMin<=iNum)
				{
					if(iFlag == 0)
						* iSizeData = 2;
					if(*iSizeData == 0)
						strcpy(chData,chValue);
					else
						strcpy(chData1,chValue);
					iReFlag = 0;
				}else
				{
					ErrorBuzzer();				/*	Buzzer  */
					memset(chValue, 0x00, sizeof(chValue));
					strcpy(chValue,chData);
					iCaptionWindow(Dspname[SET_FUNTION].chName[Set.iLang][9],"");			/*  ��ư �ϳ��� �޼���E�ڽ�	 */	
					vNumInputDisp1(chData, isX);
					memset(chValue, 0x00, sizeof(chValue));
					memset(chKeyData, 0x00, sizeof(chKeyData));
				}
			}else
			{
				ErrorBuzzer();				/*	Buzzer  */
			}

		} /*  end if  */			
		
		/* ���� �ű�E*/ 			
		iLen = strlen(chKeyData);
		
		if (iLen > iSize) {
			memset(chValue, 0x00, sizeof(chValue));
			strncpy(chValue, chKeyData+1, iSize);				
		} else {
			memset(chValue, 0x00, sizeof(chValue));
			strcpy(chValue, chKeyData);
		} /* end if */				

		/* �Ϻ� ���� */
		if((!((strcmp(chValue,"-0"))==0 || (strcmp(chValue,"-"))==0)) && (chValue[0] == '0'))
		{
			iLong = (long)gatoi(chValue);
			itoa((long)iLong, chValue, 10); 
		}

		if(iFlag == 1 || iFlag == 3){	/* iFlag=1�϶� ����, iFlag=3�϶� UP/DOWN */ 
			if(iFlag == 3)
				iFlag=0;
			else
				iFlag=2;

			iNum = strlen(chValue);					/*  ���ڸ��� ���߾�ح �����Ϸ���E  */
			if(isX==0)
			{
/* ksc20050622 */
/*				if(iSize>6 || (iNum == 1) || (iLen > iNum) && iFlag == 2)	*/
				if(iFlag == 2)
				{
					strcpy(chKeyData, "   ");
					DotTextOut(GAMEN_START_X+190-(26),GAMEN_START_Y+NLine_2+((*iSizeData)*18),chKeyData,1,1, TRANS, T_WHITE, T_BLACK);
				}
				if(iFlag == 0 && iNum == 0){
					if(*iSizeData == 0){
/* ksc20050622 Ŀ�� ���� ǥ�� ��ġ ���� */						
						vLastDataReverse(188-((strlen(chData))*8),NLine_2+((*iSizeData)*18),chData);
					}else{
/* ksc20050622 Ŀ�� ���� ǥ�� ��ġ ���� */						
						vLastDataReverse(188-((strlen(chData1))*8),NLine_2+((*iSizeData)*18),chData1);
					}
				}else{
					strcpy(chKeyData, chValue);
/* ksc20050622 Ŀ�� ���� ǥ�� ��ġ ���� */					
					vLastDataReverse(188-(iNum*8),NLine_2+((*iSizeData)*18),chValue);
				}				/**/
			}else
				strcpy(chKeyData, chValue);
			DotTextOut(GAMEN_START_X+iFont+38+isX,GAMEN_START_Y+Line_1+1,chValue,1,1, TRANS, T_WHITE, T_BLACK);
			if(isX==0)
				vNumberInputPan(1);				/* �����Է�â */	
			else
				vNumberInputPan(2);				/* �����Է�â PLC ���� ��� */	
			vLastDataReverse(iFont+110-(iNum*8)+isX,Line_1+1,chValue);
			RectAngleOut(2+isX,2,128+isX,19,&RECParam);
		/*	vBoxInLine(0,0,120,19);*/				/* �Է°� ��� ȭ��E		 */	
		}

		DrawLcdBank1();
	} /*  end while  */	

	return iReFlag;
}


#endif
