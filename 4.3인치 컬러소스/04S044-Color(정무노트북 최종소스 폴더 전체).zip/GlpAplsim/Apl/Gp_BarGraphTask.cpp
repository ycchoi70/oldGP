/********************************************************************************/
/* �� �� �� : GpBarGraphTask.cpp												*/
/* ��    �� : BarGraphTask														*/
/* �� �� �� : 2002�� 5�� 13�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include    "sgt.h"

/********************************************************************************/
/* �� �� �� : DrawBarGraph_Task													*/
/* ��    �� : BarGraph ������ �ص��Ͽ� ȭ�鿡 ���							    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 30�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetBarGraph_Func(int iDispOrder)
{
	_BARGRAPH_EVENT_TBL* BarGraphEventTbl;

	BarGraphEventTbl= (_BARGRAPH_EVENT_TBL*)TakeMemory(sizeof(_BARGRAPH_EVENT_TBL));
	DrawBarGraph_Func(0,BarGraphEventTbl,iDispOrder);
	FreeMail((char *)BarGraphEventTbl);
}
/* 060926 */
int	CheckEntryDevice(DEV_DATA* EntDev)
{
	int		i,ret;

	ret= -1;
	for(i= 0; i < DeviceCnt; i++){
		if( (DeviceDataHed[i].DevFlag == EntDev->DevFlag)		&&	/* Word */
			(DeviceDataHed[i].DevName[0] == EntDev->DevName[0])	&&
			(DeviceDataHed[i].DevAddress == EntDev->DevAddress)	&&
			(DeviceDataHed[i].DevCnt == EntDev->DevCnt) ){
			ret= i;
			break;
		}
	}
	return(ret);
}
int	DrawBarGraph_Func(int mode,_BARGRAPH_EVENT_TBL* BarGraphEventTbl,int iDispOrder)
{
/*	unsigned int		iTagSizeOf;*/
	int					iOffset;
	int					iDevAddress;
	unsigned char *buffer;
	DEV_DATA	EntryDevice;	/* 060926 */
	int		Dev_idx;

	buffer= ScreenTagData[iDispOrder].TagPos;
/*	_BARGRAPH_EVENT_TBL*	 BarGraphEventTbl;*/
/*
	if(CheckMailBox(sizeof(_BARGRAPH_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_BARGRAPH_EVENT_TBL));
	BarGraphEventTbl= (_BARGRAPH_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)BarGraphEventTbl, 0x00, sizeof(_BARGRAPH_EVENT_TBL));

/*	iTagSizeOf = 0x00;*/
	iOffset = 0;
/*
	iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
	iTagSizeOf += (unsigned int)buffer[1] & 0xff;
*/
/*
	BarGraphEventTbl->sX  = (unsigned int)(buffer[6]  << 0x08);
	BarGraphEventTbl->sX += (unsigned int)buffer[7] & 0xff;

	BarGraphEventTbl->sX += 4;

	BarGraphEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
	BarGraphEventTbl->sY += (unsigned int)buffer[9] & 0xff;

	BarGraphEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
	BarGraphEventTbl->eX += (unsigned int)buffer[11] & 0xff;

	BarGraphEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
	BarGraphEventTbl->eY += (unsigned int)buffer[13] & 0xff;	

	BarGraphEventTbl->sX -= 4;
*/
	/* Direction */
	BarGraphEventTbl->iDirecition = (unsigned int)buffer[14];

	/* Frame Color */
	BarGraphEventTbl->iFrameColor = (unsigned int)buffer[15];

	/*
	Case����
	��Base
	��Upper		
	��Lower
	*/
	switch(buffer[16]){
		case 0x01:
			BarGraphEventTbl->iBaseCaseInfo		= USED_DEVICE;
			BarGraphEventTbl->iUpperCaseInfo	= USED_DEVICE;
			BarGraphEventTbl->iLowerCaseInfo	= USED_DEVICE;
			break;
		case 0x02:
			BarGraphEventTbl->iBaseCaseInfo		= USED_DEVICE;
			BarGraphEventTbl->iUpperCaseInfo	= USED_FIXED;
			BarGraphEventTbl->iLowerCaseInfo	= USED_FIXED;
			break;
		case 0x03:
			BarGraphEventTbl->iBaseCaseInfo		= USED_FIXED;
			BarGraphEventTbl->iUpperCaseInfo	= USED_DEVICE;
			BarGraphEventTbl->iLowerCaseInfo	= USED_FIXED;
			break;
		case 0x04:
			BarGraphEventTbl->iBaseCaseInfo		= USED_FIXED;
			BarGraphEventTbl->iUpperCaseInfo	= USED_FIXED;
			BarGraphEventTbl->iLowerCaseInfo	= USED_DEVICE;
			break;
		case 0x05:
			BarGraphEventTbl->iBaseCaseInfo		= USED_DEVICE;
			BarGraphEventTbl->iUpperCaseInfo	= USED_DEVICE;
			BarGraphEventTbl->iLowerCaseInfo	= USED_FIXED;
			break;
		case 0x06:
			BarGraphEventTbl->iBaseCaseInfo		= USED_DEVICE;
			BarGraphEventTbl->iUpperCaseInfo	= USED_FIXED;
			BarGraphEventTbl->iLowerCaseInfo	= USED_DEVICE;
			break;
		case 0x07:
			BarGraphEventTbl->iBaseCaseInfo		= USED_FIXED;
			BarGraphEventTbl->iUpperCaseInfo	= USED_DEVICE;
			BarGraphEventTbl->iLowerCaseInfo	= USED_DEVICE;
			break;
		case 0x08:
			BarGraphEventTbl->iBaseCaseInfo		= USED_FIXED;
			BarGraphEventTbl->iUpperCaseInfo	= USED_FIXED;
			BarGraphEventTbl->iLowerCaseInfo	= USED_FIXED;
			break;
	}
	switch((unsigned int)buffer[17]){
		case 1:
			BarGraphEventTbl->iFrameChecked		= CHECKED;
			BarGraphEventTbl->BeScaleDisp		= CHECKED;
			break;
		
		case 2:
			BarGraphEventTbl->iFrameChecked		= UNCHECKED;
			BarGraphEventTbl->BeScaleDisp		= CHECKED;
			break;

		case 3:
			BarGraphEventTbl->iFrameChecked		= CHECKED;
			BarGraphEventTbl->BeScaleDisp		= UNCHECKED;
			break;

		case 4:
			BarGraphEventTbl->iFrameChecked		= UNCHECKED;
			BarGraphEventTbl->BeScaleDisp		= UNCHECKED;
			break;
	}		
	BarGraphEventTbl->iPlateColor = (unsigned int)buffer[18];
		iOffset = 19;
	if(BarGraphEventTbl->iUpperCaseInfo == USED_DEVICE){
		/*------------------------------------------------------------*/
		if(mode == 0){
			GetDeviceSet((buffer+iOffset),
					BarGraphEventTbl->cUpDeviceName,
					&(iDevAddress));
			BarGraphEventTbl->iUpDeviceNumber = (unsigned int) iDevAddress;
		}
		/*-------------------------------------------------------------*/	
		iOffset+= 5;
	}
	else if(BarGraphEventTbl->iUpperCaseInfo == USED_FIXED){
#ifdef	WIN32
		BarGraphEventTbl->lBefUpDevVal = (unsigned int)(buffer[iOffset]) << 0x18;
		BarGraphEventTbl->lBefUpDevVal += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		BarGraphEventTbl->lBefUpDevVal += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		BarGraphEventTbl->lBefUpDevVal += (unsigned int)buffer[++iOffset] & 0xff; 
		iOffset+=2;
#else
		memcpy(&BarGraphEventTbl->lBefUpDevVal,&buffer[iOffset],4);
		iOffset+=5;
#endif
	}

	if(BarGraphEventTbl->iLowerCaseInfo == USED_DEVICE){			
		/*------------------------------------------------------------*/
		if(mode == 0){
			GetDeviceSet((buffer+iOffset),
					BarGraphEventTbl->cDwDeviceName,
					&(iDevAddress));
			BarGraphEventTbl->iDwDeviceNumber = (unsigned int) iDevAddress;
		}
		/*-------------------------------------------------------------*/
		iOffset+=5;

	}
	else if(BarGraphEventTbl->iLowerCaseInfo == USED_FIXED){
#ifdef	WIN32
		BarGraphEventTbl->lBefDwDevVal = (unsigned int)buffer[iOffset] << 0x18;
		BarGraphEventTbl->lBefDwDevVal += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		BarGraphEventTbl->lBefDwDevVal += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		BarGraphEventTbl->lBefDwDevVal += (unsigned int)buffer[++iOffset] & 0xff; 
		iOffset+=2;
#else
		memcpy(&BarGraphEventTbl->lBefDwDevVal,&buffer[iOffset],4);
		iOffset+=5;
#endif
	}

	if(BarGraphEventTbl->iBaseCaseInfo == USED_DEVICE){			
		/*------------------------------------------------------------*/
		GetDeviceSet((buffer+iOffset),
					BarGraphEventTbl->cBaseDeviceName,
					&(BarGraphEventTbl->iBaseDeviceNumber));
		/*-------------------------------------------------------------*/		
		iOffset+=5;
	}	
	else if(BarGraphEventTbl->iBaseCaseInfo == USED_FIXED){
#ifdef	WIN32
		BarGraphEventTbl->lBefBeDevVal = (unsigned int)buffer[iOffset] << 0x18;
		BarGraphEventTbl->lBefBeDevVal  += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10; 
		BarGraphEventTbl->lBefBeDevVal  += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
		BarGraphEventTbl->lBefBeDevVal  += (unsigned int)(buffer[++iOffset] & 0xff); 
		iOffset+=2;
#else
		memcpy(&BarGraphEventTbl->lBefBeDevVal,&buffer[iOffset],4);
		iOffset+=5;
#endif
	}
	if(BarGraphEventTbl->BeScaleDisp == CHECKED){
		BarGraphEventTbl->iScaleColor = (unsigned int)buffer[iOffset];
		BarGraphEventTbl->iScalePoint = (unsigned int)buffer[++iOffset];
		iOffset++;
	}
	BarGraphEventTbl->iBarColor = (unsigned int)buffer[iOffset];
	BarGraphEventTbl->iScalePosition = (unsigned int)buffer[++iOffset];

	if((unsigned int)buffer[++iOffset] == 0x00)
	{
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed = UNCHECKED;
		}
		BarGraphEventTbl->ShapeNo = 0;
		iOffset++;
	}else
	{
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed = CHECKED;
		}
		BarGraphEventTbl->ShapeNo = (unsigned int)buffer[++iOffset];
	}
	if((unsigned int)buffer[++iOffset] < 4)	/* 1,2,3 -> 16Bit */
		BarGraphEventTbl->iMonitorBitFlag = 0;
	else								/* 4,5,6 -> 32Bit */
		BarGraphEventTbl->iMonitorBitFlag = 1;

	if((unsigned int)buffer[iOffset] == 0x01 || (unsigned int)buffer[iOffset] == 0x04)
		BarGraphEventTbl->iSignedFlag = SIGNED;
	else if((unsigned int)buffer[iOffset] == 0x02 || (unsigned int)buffer[iOffset] == 0x05)
		BarGraphEventTbl->iSignedFlag = UNSIGNED;
	else
		BarGraphEventTbl->iSignedFlag = BCD;	

	/*------------------------------------------------------------*/
	iOffset++;
/*	if(mode == 0){*/
		GetDeviceSet((buffer+iOffset),
				BarGraphEventTbl->cMonitorDeviceName,
				&(iDevAddress));
		BarGraphEventTbl->iMonitorDeviceNumber = (unsigned int) iDevAddress;
/*	}*/
	iOffset+=4;
	/*-------------------------------------------------------------*/		
	if(mode == 0){
		memset(&EntryDevice,0,sizeof(EntryDevice));
		EntryDevice.DevFlag = 1;/* Word */
		EntryDevice.DevName[0] = BarGraphEventTbl->cMonitorDeviceName[0];
		EntryDevice.DevName[1] = BarGraphEventTbl->cMonitorDeviceName[1];
		EntryDevice.DevAddress = BarGraphEventTbl->iMonitorDeviceNumber;
		if(BarGraphEventTbl->iMonitorBitFlag == 0){/* 16bit */
			EntryDevice.DevCnt = 1;		
		}else{/* 32bit */
			EntryDevice.DevCnt = 2;
		}
		Dev_idx= CheckEntryDevice(&EntryDevice);
		if(Dev_idx == -1){		/* New Entry */
			memcpy(&DeviceDataHed[DeviceCnt],&EntryDevice,sizeof(DEV_DATA));
			DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];	
			ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
			ScreenTagData[iDispOrder].DevCnt= EntryDevice.DevCnt*2;
			if(BarGraphEventTbl->iMonitorBitFlag == 0){/* 16bit */			
				iDeviceOffset +=2;
			}else{/* 32bit */			
				iDeviceOffset +=4;
			}
			DeviceCnt++;
		}else{
			ScreenTagData[iDispOrder].DevOrder= (int)(DeviceDataHed[Dev_idx].DevData- &DeviceData[0]);
			ScreenTagData[iDispOrder].DevCnt= EntryDevice.DevCnt*2;
		}
		ScreenTagData[iDispOrder].uu.BarGraph.DevOrder[0]= -1;
		ScreenTagData[iDispOrder].uu.BarGraph.DevOrder[1]= -1;
		ScreenTagData[iDispOrder].uu.BarGraph.DevOrder[2]= -1;
		/* Base�� Device�� ���� ��� */		
		if(BarGraphEventTbl->iBaseCaseInfo == USED_DEVICE){		
			EntryDevice.DevFlag = 1;/* Word */
			EntryDevice.DevName[0] = BarGraphEventTbl->cBaseDeviceName[0];
			EntryDevice.DevName[1] = BarGraphEventTbl->cBaseDeviceName[1];
			EntryDevice.DevAddress = BarGraphEventTbl->iBaseDeviceNumber;
			if(BarGraphEventTbl->iMonitorBitFlag == 0){/* 16bit */
				EntryDevice.DevCnt = 1;		
			}else{/* 32bit */
				EntryDevice.DevCnt = 2;
			}
			Dev_idx= CheckEntryDevice(&EntryDevice);
			if(Dev_idx == -1){		/* New Entry */
				memcpy(&DeviceDataHed[DeviceCnt],&EntryDevice,sizeof(DEV_DATA));
				DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];	
				ScreenTagData[iDispOrder].uu.BarGraph.DevOrder[0]= iDeviceOffset;
				if(BarGraphEventTbl->iMonitorBitFlag == 0){/* 16bit */			
					iDeviceOffset +=2;
				}else{/* 32bit */			
					iDeviceOffset +=4;
				}
				DeviceCnt++;
			}else{
				ScreenTagData[iDispOrder].uu.BarGraph.DevOrder[0]= (int)(DeviceDataHed[Dev_idx].DevData- &DeviceData[0]);
			}
		}
		
		/* Upper�� Device�� ���� ��� */
		if(BarGraphEventTbl->iUpperCaseInfo == USED_DEVICE){	
			EntryDevice.DevFlag = 1;/* Word */
			EntryDevice.DevName[0] = BarGraphEventTbl->cUpDeviceName[0];
			EntryDevice.DevName[1] = BarGraphEventTbl->cUpDeviceName[1];
			EntryDevice.DevAddress = BarGraphEventTbl->iUpDeviceNumber;
			if(BarGraphEventTbl->iMonitorBitFlag == 0){/* 16bit */
				EntryDevice.DevCnt = 1;		
			}else{/* 32bit */
				EntryDevice.DevCnt = 2;
			}
			Dev_idx= CheckEntryDevice(&EntryDevice);
			if(Dev_idx == -1){		/* New Entry */
				memcpy(&DeviceDataHed[DeviceCnt],&EntryDevice,sizeof(DEV_DATA));
				DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];	
				ScreenTagData[iDispOrder].uu.BarGraph.DevOrder[1]= iDeviceOffset;
				if(BarGraphEventTbl->iMonitorBitFlag == 0){/* 16bit */			
					iDeviceOffset +=2;
				}else{/* 32bit */			
					iDeviceOffset +=4;
				}
				DeviceCnt++;
			}else{
				ScreenTagData[iDispOrder].uu.BarGraph.DevOrder[1]= (int)(DeviceDataHed[Dev_idx].DevData- &DeviceData[0]);
			}
		}
		/* Lower�� Device�� ���� ��� */
		if(BarGraphEventTbl->iLowerCaseInfo == USED_DEVICE){			
			EntryDevice.DevFlag = 1;/* Word */
			EntryDevice.DevName[0] = BarGraphEventTbl->cDwDeviceName[0];
			EntryDevice.DevName[1] = BarGraphEventTbl->cDwDeviceName[1];
			EntryDevice.DevAddress = BarGraphEventTbl->iDwDeviceNumber;
			if(BarGraphEventTbl->iMonitorBitFlag == 0){/* 16bit */
				EntryDevice.DevCnt = 1;		
			}else{/* 32bit */
				EntryDevice.DevCnt = 2;
			}
			Dev_idx= CheckEntryDevice(&EntryDevice);
			if(Dev_idx == -1){		/* New Entry */
				memcpy(&DeviceDataHed[DeviceCnt],&EntryDevice,sizeof(DEV_DATA));
				DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];	
				ScreenTagData[iDispOrder].uu.BarGraph.DevOrder[2]= iDeviceOffset;
				if(BarGraphEventTbl->iMonitorBitFlag == 0){/* 16bit */			
					iDeviceOffset +=2;
				}else{/* 32bit */			
					iDeviceOffset +=4;
				}
				DeviceCnt++;
			}else{
				ScreenTagData[iDispOrder].uu.BarGraph.DevOrder[2]= (int)(DeviceDataHed[Dev_idx].DevData- &DeviceData[0]);
			}
		}
		BarGraphDispCnt++;
	}
/*	IventTableCnt++;*/
	return(0);
}

/********************************************************************************/
/* �� �� �� : BarGraphDispWatch													*/
/* ��    �� : BarGraph�±������� ����  ȭ�鿡 ����� ����Ѵ�.					*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	BarGraphDispWatch(int iOrder)
{
	int				k, iLen, iTemp;
	int				sX, sY, eX, eY;
	int				iCenterPosX;
	int				iCenterPosY;
	int				iPoint;
	float			iSite;
	int				sPoint;
	int				ePoint;
/*	unsigned short		sworkDevVal;*/
	long			lMonitorDevVal;
	long			lBaseDevVal;
	long			lUpperDevVal;
	long			lLowerDevVal;
	unsigned long	ulMonitorDevVal;
	unsigned long	ulBaseDevVal;
	unsigned long	ulUpperDevVal;
	unsigned long	ulLowerDevVal;
	float			fGapVal;
	int				*iDisplayPos;
	float			*fPosVal;
	short			iShapeSize;
	int				idx;
	int				CheckFlag;		/* V202 */
/*	short			iColor1;
	short			iColor2;
iColor1 = WHITE;
iColor2 = BLOCK;
*/
	_LINE_INFO			LineInfo;
	_RECTANGLE_INFO		RectInfo;
	_BARGRAPH_EVENT_TBL*	 BarGraphEventTbl;

	BarGraphEventTbl= (_BARGRAPH_EVENT_TBL*)TakeMemory(sizeof(_BARGRAPH_EVENT_TBL));
	DrawBarGraph_Func(1,BarGraphEventTbl,iOrder);

	iPoint	= 0;
	iSite	= 0;
	sX = ScreenTagData[iOrder].sX;
	sY = ScreenTagData[iOrder].sY;
	eX = ScreenTagData[iOrder].eX;
	eY = ScreenTagData[iOrder].eY;
	
	iDisplayPos= (int *)TakeMemory(sizeof(int)*101);
	fPosVal= (float *)TakeMemory(sizeof(float)*101);
	memset(fPosVal,	0x00, sizeof(float)*101);

/*	if(iOnSignalStart != OFF){*/
/*
		lMonitorDevVal	= BarGraphEventTbl->lBefDevVal;
		lBaseDevVal		= BarGraphEventTbl->lBefBeDevVal;
		lUpperDevVal	= BarGraphEventTbl->lBefUpDevVal;
		lLowerDevVal	= BarGraphEventTbl->lBefDwDevVal;
*/
	idx= ScreenTagData[iOrder].DevOrder;
	if(BarGraphEventTbl->iSignedFlag == UNSIGNED){
		lMonitorDevVal= ChangeChar2Unsinlong(&DispDeviceData[idx],BarGraphEventTbl->iMonitorBitFlag);
	}else{
		lMonitorDevVal= ChangeChar2long(&DispDeviceData[idx],BarGraphEventTbl->iMonitorBitFlag);
	}
	if(BarGraphEventTbl->iSignedFlag == BCD)
			BCD_TO_BIN(&lMonitorDevVal);		/* BCD�� �ٲٴ� �Լ� */
	if(BarGraphEventTbl->iBaseCaseInfo == USED_DEVICE){		
		idx= ScreenTagData[iOrder].uu.BarGraph.DevOrder[0];		/* 060926 */
		if(BarGraphEventTbl->iSignedFlag == UNSIGNED){
			lBaseDevVal= ChangeChar2Unsinlong(&DispDeviceData[idx],BarGraphEventTbl->iMonitorBitFlag);
		}else{
			lBaseDevVal= ChangeChar2long(&DispDeviceData[idx],BarGraphEventTbl->iMonitorBitFlag);
		}
		if(BarGraphEventTbl->iSignedFlag == BCD)
			BCD_TO_BIN(&lBaseDevVal);		/* BCD�� �ٲٴ� �Լ� */
	}else{
		lBaseDevVal= BarGraphEventTbl->lBefBeDevVal;
	}
	if(BarGraphEventTbl->iUpperCaseInfo == USED_DEVICE){	
		idx= ScreenTagData[iOrder].uu.BarGraph.DevOrder[1];		/* 060926 */
		if(BarGraphEventTbl->iSignedFlag == UNSIGNED){
			lUpperDevVal= ChangeChar2Unsinlong(&DispDeviceData[idx],BarGraphEventTbl->iMonitorBitFlag);
		}else{
			lUpperDevVal= ChangeChar2long(&DispDeviceData[idx],BarGraphEventTbl->iMonitorBitFlag);
		}
		if(BarGraphEventTbl->iSignedFlag == BCD)
			BCD_TO_BIN(&lUpperDevVal);		/* BCD�� �ٲٴ� �Լ� */
	}else{
		lUpperDevVal= BarGraphEventTbl->lBefUpDevVal;
	}
	if(BarGraphEventTbl->iLowerCaseInfo == USED_DEVICE){
		idx= ScreenTagData[iOrder].uu.BarGraph.DevOrder[2];		/* 060926 */
		if(BarGraphEventTbl->iSignedFlag == UNSIGNED){
			lLowerDevVal= ChangeChar2Unsinlong(&DispDeviceData[idx],BarGraphEventTbl->iMonitorBitFlag);
		}else{
			lLowerDevVal= ChangeChar2long(&DispDeviceData[idx],BarGraphEventTbl->iMonitorBitFlag);
		}
		if(BarGraphEventTbl->iSignedFlag == BCD)
			BCD_TO_BIN(&lLowerDevVal);		/* BCD�� �ٲٴ� �Լ� */
		if(BarGraphEventTbl->iMonitorBitFlag == 0){	/* 16 Bit */
			idx += 2;
		}else{
			idx += 4;
		}
	}else{
		lLowerDevVal= BarGraphEventTbl->lBefDwDevVal;
	}


	/*	if()
		BCD_TO_BIN(&lMonitorDevVal);*/		/* BCD�� �ٲٴ� �Լ� */
	
		/* Shape Draw */
		iShapeSize = 0;
		if(ScreenTagData[iOrder].BeShapeUsed == CHECKED){ 
			iShapeSize = DrawShape(BarGraphEventTbl->ShapeNo, 
				ScreenTagData[iOrder].sX, 
				ScreenTagData[iOrder].sY, 
				ScreenTagData[iOrder].eX , 
				ScreenTagData[iOrder].eY,
				BarGraphEventTbl->iFrameColor,
				BarGraphEventTbl->iPlateColor);
			sX += iShapeSize;
			sY += iShapeSize;
			eX -= iShapeSize;
			eY -= iShapeSize;
		}	
		if(BarGraphEventTbl->BeScaleDisp == CHECKED)
		{
			if(BarGraphEventTbl->iScalePosition == _LEFT){
				sX = sX + 4;
			}
			else if(BarGraphEventTbl->iScalePosition == _RIGHT){
				eX = eX - 4;
			}
			else if(BarGraphEventTbl->iScalePosition == _DOWN){
				eY = eY - 4;
			}
			else if(BarGraphEventTbl->iScalePosition == _UP){
				sY = sY + 4;
			}
		}
		if(BarGraphEventTbl->BeScaleDisp == CHECKED){		
			iPoint = BarGraphEventTbl->iScalePoint;
			
			if(BarGraphEventTbl->iScalePosition == _LEFT){
				iLen = eY - sY; 
				iSite = (float)iLen/(iPoint-1);
				iTemp = sY;
				LineInfo.iLineStyle = SOLID_LINE;
				LineInfo.iLineColor = BarGraphEventTbl->iScaleColor;
				for(k=1;k<iPoint;k++){
/* 060313					LineOut(ScreenTagData[iOrder].sX + iShapeSize , iTemp, sX, iTemp, &LineInfo);*/
					LineOut(ScreenTagData[iOrder].sX + iShapeSize , iTemp, sX-1, iTemp, &LineInfo);
					iTemp = (int)(sY + (iSite*k));
				}
				LineOut(ScreenTagData[iOrder].sX + iShapeSize , eY, sX, eY, &LineInfo);
			}
			else if(BarGraphEventTbl->iScalePosition == _RIGHT){

				iLen = eY - sY;
				iSite = (float)iLen/(iPoint-1);
				iTemp = sY;
				LineInfo.iLineStyle = SOLID_LINE;
				LineInfo.iLineColor = BarGraphEventTbl->iScaleColor;
				for(k=1;k<iPoint;k++){
					LineOut(eX , iTemp, ScreenTagData[iOrder].eX - iShapeSize, iTemp, &LineInfo);
					iTemp = (int)(sY + (iSite*k));
				}
				LineOut(eX , eY, ScreenTagData[iOrder].eX - iShapeSize, eY, &LineInfo);

			}
			else if(BarGraphEventTbl->iScalePosition == _DOWN){

				iLen = eX - sX;
				iSite = (float)iLen/(iPoint-1);
				iTemp = sX;
				LineInfo.iLineStyle = SOLID_LINE;
				LineInfo.iLineColor = BarGraphEventTbl->iScaleColor;
				for(k=1;k<iPoint;k++){
					LineOut(iTemp , eY, iTemp, ScreenTagData[iOrder].eY- iShapeSize, &LineInfo);
					iTemp = (int)(sX + (iSite*k));
				}
				LineOut(eX , eY, eX, ScreenTagData[iOrder].eY- iShapeSize, &LineInfo);
			}
			else if(BarGraphEventTbl->iScalePosition == _UP){

				iLen = eX - sX;
				iSite = (float)iLen/(iPoint-1);
				iTemp = sX;
				LineInfo.iLineStyle = SOLID_LINE;
				LineInfo.iLineColor = BarGraphEventTbl->iScaleColor;
				for(k=0;k<iPoint;k++){
					LineOut(iTemp , ScreenTagData[iOrder].sY+iShapeSize, iTemp, sY, &LineInfo);
					iTemp = (int)(sX + (iSite*k));
				}
				LineOut(eX , ScreenTagData[iOrder].sY+iShapeSize, eX, sY, &LineInfo);
			}
		}
		if(BarGraphEventTbl->iFrameChecked == CHECKED){	/* Frame Display */
			RectInfo.iLineStyle = SOLID_LINE;
			RectInfo.iLineColor = WHITE; 
			RectInfo.iPattern = PAT0;
			RectInfo.iForeColor = BarGraphEventTbl->iPlateColor;
			RectInfo.iBackColor = BarGraphEventTbl->iPlateColor;
			RectAngleOut(sX, sY, eX, eY, &RectInfo);
			sX = sX + 1;	/* 20040108 */
			eX = eX - 1;
			eY = eY - 1;
			sY = sY + 1;
		}
	if(strlen(BarGraphEventTbl->cMonitorDeviceName))
	{
		if((BarGraphEventTbl->iMonitorBitFlag != 0) && (BarGraphEventTbl->iSignedFlag == UNSIGNED)){
			ulUpperDevVal= lUpperDevVal;
			ulLowerDevVal= lLowerDevVal;
			ulMonitorDevVal= lMonitorDevVal;
			ulBaseDevVal= lBaseDevVal;
			fGapVal = (float)((float)ulUpperDevVal - (float)ulLowerDevVal)/100;
			for(k=0;k<=100;k++){
				fPosVal[k] = ulUpperDevVal - fGapVal * k; 
			}
			fPosVal[100] = (float)ulLowerDevVal; 
		}else{
			fGapVal = (float)((float)lUpperDevVal - (float)lLowerDevVal)/100;
			for(k=0;k<=100;k++){
				fPosVal[k] = lUpperDevVal - fGapVal * k; 
			}
			fPosVal[100] = (float)lLowerDevVal; 
		}
/*		
		if(lLowerDevVal > lMonitorDevVal || lUpperDevVal< lMonitorDevVal || 
			(lUpperDevVal == 0 && lLowerDevVal == 0)){				
			 Data ������ �Ѿ��� ��� 
*/
/*lsi20040524 ���� */
/*
		if(lBaseDevVal < lLowerDevVal || lBaseDevVal > lUpperDevVal ||
			lLowerDevVal > lMonitorDevVal || lUpperDevVal< lMonitorDevVal || 
			lLowerDevVal >= lUpperDevVal || (lUpperDevVal == 0 && lLowerDevVal == 0)){				
			 Data ������ �Ѿ��� ��� 
*/
/*lsi20040524*/
/*lsi20040529 ���� */
		CheckFlag= 0;
		if((BarGraphEventTbl->iMonitorBitFlag != 0) && (BarGraphEventTbl->iSignedFlag == UNSIGNED)){
			if((ulBaseDevVal < ulLowerDevVal) || (ulBaseDevVal > ulUpperDevVal) ||
				(ulLowerDevVal > ulMonitorDevVal) || (ulUpperDevVal< ulMonitorDevVal) || 
				(ulLowerDevVal >= ulUpperDevVal) || (ulUpperDevVal == 0 && ulLowerDevVal == 0)){
				CheckFlag= 1;
			}
		}else{
			if(lBaseDevVal < lLowerDevVal || lBaseDevVal > lUpperDevVal ||
				lLowerDevVal > lMonitorDevVal || lUpperDevVal< lMonitorDevVal || 
				lLowerDevVal >= lUpperDevVal || (lUpperDevVal == 0 && lLowerDevVal == 0)
				||(BarGraphEventTbl->iSignedFlag == BCD && (lUpperDevVal == -1 ||
				lLowerDevVal == -1 || lBaseDevVal == -1 || lMonitorDevVal == -1))){
				CheckFlag= 1;			/* 060921 */
			}
		}
		if(CheckFlag == 1){
			/* Data ������ �Ѿ��� ��� */
/*lsi20040529*/


			LineInfo.iLineStyle = SOLID_LINE;
			LineInfo.iLineColor = WHITE;
			LineOut(sX, sY, eX, eY, &LineInfo);
		}else{			
			if(BarGraphEventTbl->iDirecition == VERTICAL){	

/* 050422				fGapVal = (float)(eY-sY-1)/100;*/
				fGapVal = (float)(eY-sY)/100;
				for(k=0;k<100;k++){
/* 050422					iDisplayPos[k] = (int)(sY + fGapVal * k);*/	/* 2004/01/08 OLD: iDisplayPos[k] = (int)((sY+1) + fGapVal * k); */
					iDisplayPos[k] = (int)(sY + fGapVal * k + 0.5);	/* 2004/01/08 OLD: iDisplayPos[k] = (int)((sY+1) + fGapVal * k); */
				}
				iDisplayPos[100] = eY;							/* 2004/01/08 OLD:iDisplayPos[100] = (eY-1); */
				for(k=0;k<=100;k++){
					if((BarGraphEventTbl->iMonitorBitFlag != 0) && (BarGraphEventTbl->iSignedFlag == UNSIGNED)){
						if(ulBaseDevVal >= fPosVal[k]){
							iCenterPosY = iDisplayPos[k];
							LineInfo.iLineStyle = SOLID_LINE;
							LineInfo.iLineColor = WHITE;						
							LineOut(sX, iCenterPosY, eX, iCenterPosY, &LineInfo);
							break;
						}
					}else{
						if(lBaseDevVal >= fPosVal[k]){
							iCenterPosY = iDisplayPos[k];
							LineInfo.iLineStyle = SOLID_LINE;
							LineInfo.iLineColor = WHITE;						
							LineOut(sX, iCenterPosY, eX, iCenterPosY, &LineInfo);
							break;
						}
					}
				}
				for(k=0;k<=100;k++){
					CheckFlag= 0;
					if((BarGraphEventTbl->iMonitorBitFlag != 0) && (BarGraphEventTbl->iSignedFlag == UNSIGNED)){
						if(ulMonitorDevVal >= fPosVal[k]){
							CheckFlag= 1;
						}
					}else{
						if(lMonitorDevVal >= fPosVal[k]){
							CheckFlag= 1;
						}
					}
					if(CheckFlag == 1){
						RectInfo.iLineStyle = SOLID_LINE;
						RectInfo.iLineColor = BarGraphEventTbl->iBarColor;
						RectInfo.iPattern = PAT8;
						RectInfo.iForeColor = BarGraphEventTbl->iBarColor;
						RectInfo.iBackColor = BarGraphEventTbl->iBarColor;
						if((BarGraphEventTbl->iMonitorBitFlag != 0) && (BarGraphEventTbl->iSignedFlag == UNSIGNED)){
							if(ulMonitorDevVal < ulBaseDevVal){	
								RectAngleOut(sX,iCenterPosY,eX,iDisplayPos[k],&RectInfo);
							}else{
								RectAngleOut(sX,iDisplayPos[k],eX,iCenterPosY,&RectInfo);
							}
						}else{
							if(lMonitorDevVal < lBaseDevVal){	
								RectAngleOut(sX,iCenterPosY,eX,iDisplayPos[k],&RectInfo);
							}else{
								RectAngleOut(sX,iDisplayPos[k],eX,iCenterPosY,&RectInfo);
							}
						}
						/* Graph�� ���ݱ׸��� �߰��κ� -----S */
						if(eY == iCenterPosY) /* Data�� ���÷��� �� �� ���� ��ĥ �� */
						{
							sPoint = iCenterPosY;
							ePoint = iCenterPosY-1;
						}else if(sY == iCenterPosY)
						{
							sPoint = iCenterPosY+1;
							ePoint = iCenterPosY;
						}else
						{
							sPoint = iCenterPosY+1;
							ePoint = iCenterPosY-1;
						}
						if(ScreenTagData[iOrder].BeShapeUsed != CHECKED)
						{ 
/*
							sX = sX + 1;
							eX = eX - 1;
*/
/*lsi20040524 ���� */

/*lsi20040524*/
						}
						if(iDisplayPos[k]==iCenterPosY){
							if(BarGraphEventTbl->iScalePosition == _RIGHT){
								/* 060313 */
								LineInfo.iLineColor= RectInfo.iForeColor;
								LineOut(sX, sPoint, sX, ePoint, &LineInfo); /* sX+1 */
								if(RectInfo.iLineColor != BLACK){
									LineInfo.iLineColor = BLACK;
								}else{
									LineInfo.iLineColor = WHITE;
								}
								LineOut(sX, iCenterPosY, sX+1, iCenterPosY, &LineInfo);
							}else
							{
								/* 060313 */
								LineInfo.iLineColor= RectInfo.iForeColor;
								LineOut(eX, sPoint, eX, ePoint, &LineInfo); /* eX-1 */
								if(RectInfo.iLineColor != BLACK){
									LineInfo.iLineColor = BLACK;
								}else{
									LineInfo.iLineColor = WHITE;
								}
								LineOut(eX-1, iCenterPosY, eX, iCenterPosY, &LineInfo);
							}
						}
						else{
							if(BarGraphEventTbl->iScalePosition == _RIGHT){
								if(RectInfo.iLineColor != BLACK){
									LineInfo.iLineColor = BLACK;
								}else{
									LineInfo.iLineColor = WHITE;
								}
								LineOut(sX, sPoint, sX, ePoint, &LineInfo);
								LineOut(sX, iCenterPosY, sX+1, iCenterPosY, &LineInfo);	
							}else
							{
								if(RectInfo.iLineColor != BLACK){
									LineInfo.iLineColor = BLACK;
								}else{
									LineInfo.iLineColor = WHITE;
								}
								LineOut(eX, sPoint, eX, ePoint, &LineInfo);
								LineOut(eX-1, iCenterPosY, eX, iCenterPosY, &LineInfo);
							}
						}
						/*--------------------------------------E*/
						break;
					}
				}
			}
				
			else if(BarGraphEventTbl->iDirecition == HORIZONTAL){
/* 050422				fGapVal = (float)(eX-sX-1)/100;*/
				fGapVal = (float)(eX-sX)/100;
				for(k=0;k<100;k++){
/* 050422					iDisplayPos[k] = (int)(sX + fGapVal * k);*/ /* 2004/01/08 OLD: iDisplayPos[k] = (int)((sX+1) + fGapVal * k);*/
					iDisplayPos[k] = (int)(sX + fGapVal * k + 0.5); /* 2004/01/08 OLD: iDisplayPos[k] = (int)((sX+1) + fGapVal * k);*/
				}
				iDisplayPos[100] = eX; /* 2004/01/08 (OLD:iDisplayPos[100] = (eX-1);) */
				for(k=0;k<=100;k++){
					if((BarGraphEventTbl->iMonitorBitFlag != 0) && (BarGraphEventTbl->iSignedFlag == UNSIGNED)){
						if(ulBaseDevVal >= fPosVal[k]){
							iCenterPosX = iDisplayPos[100-k];
							LineInfo.iLineStyle = SOLID_LINE;
							LineInfo.iLineColor = WHITE;						
							LineOut(iCenterPosX, sY, iCenterPosX, eY,&LineInfo);
							break;
						}
					}else{
						if(lBaseDevVal >= fPosVal[k]){
							iCenterPosX = iDisplayPos[100-k];
							LineInfo.iLineStyle = SOLID_LINE;
							LineInfo.iLineColor = WHITE;						
							LineOut(iCenterPosX, sY, iCenterPosX, eY,&LineInfo);
							break;
						}
					}
				}
				for(k=0;k<=100;k++){
					CheckFlag= 0;
					if((BarGraphEventTbl->iMonitorBitFlag != 0) && (BarGraphEventTbl->iSignedFlag == UNSIGNED)){
						if(ulMonitorDevVal >= fPosVal[k]){
							CheckFlag= 1;
						}
					}else{
						if(lMonitorDevVal >= fPosVal[k]){
							CheckFlag= 1;
						}
					}
					if(CheckFlag == 1){
						RectInfo.iLineStyle = SOLID_LINE;
						RectInfo.iLineColor = BarGraphEventTbl->iBarColor;
						RectInfo.iPattern = PAT8;
						RectInfo.iForeColor = BarGraphEventTbl->iBarColor;
						RectInfo.iBackColor = BarGraphEventTbl->iBarColor;
						if((BarGraphEventTbl->iMonitorBitFlag != 0) && (BarGraphEventTbl->iSignedFlag == UNSIGNED)){
							if(ulMonitorDevVal < ulBaseDevVal){	
								RectAngleOut(iDisplayPos[100-k],sY,iCenterPosX,eY,&RectInfo);
							}else{
								RectAngleOut(iCenterPosX,sY,iDisplayPos[100-k],eY,&RectInfo);
							}
						}else{
							if(lMonitorDevVal < lBaseDevVal){	
								RectAngleOut(iDisplayPos[100-k],sY,iCenterPosX,eY,&RectInfo);
							}else{
								RectAngleOut(iCenterPosX,sY,iDisplayPos[100-k],eY,&RectInfo);
							}
						}
						/* Graph�� ���ݱ׸��� �߰��κ� -----S */
						if(eX == iCenterPosX) /* Data�� ���÷��� �� �� ���� ��ĥ �� */
						{
							sPoint = iCenterPosX;
							ePoint = iCenterPosX-1;
						}else if(sX == iCenterPosX)
						{
							sPoint = iCenterPosX+1;
							ePoint = iCenterPosX;
						}else
						{
							sPoint = iCenterPosX+1;
							ePoint = iCenterPosX-1;
						}
						if(iDisplayPos[100-k]==iCenterPosX){
							if(BarGraphEventTbl->iScalePosition == _DOWN){
/*								
								LineOut(sPoint, sY+1, ePoint, sY+1, &LineInfo);
								LineInfo.iLineColor = BLACK;
								LineOut(iCenterPosX, sY+1, iCenterPosX, sY+2,&LineInfo);
*/
/*lsi20040524 ���� */
							/*leesi 040524 */
								/* 060313 */
								LineInfo.iLineColor= RectInfo.iForeColor;
								LineOut(sPoint, sY, ePoint, sY, &LineInfo);
								if(RectInfo.iLineColor != BLACK){
									LineInfo.iLineColor = BLACK;
								}else{
									LineInfo.iLineColor = WHITE;
								}
								LineOut(iCenterPosX, sY, iCenterPosX, sY+1,&LineInfo);
/*lsi20040524*/								
							}else
							{
/*
								LineOut(sPoint, eY-1, ePoint, eY-1, &LineInfo);
								LineInfo.iLineColor = BLACK;
								LineOut(iCenterPosX, eY-1, iCenterPosX, eY-2,&LineInfo);
*/
/*lsi20040524 ���� */
							/*leesi 040524 */
								/* 060313 */
								LineInfo.iLineColor= RectInfo.iForeColor;
								LineOut(sPoint, eY, ePoint, eY, &LineInfo);
								if(RectInfo.iLineColor != BLACK){
									LineInfo.iLineColor = BLACK;
								}else{
									LineInfo.iLineColor = WHITE;
								}
								LineOut(iCenterPosX, eY, iCenterPosX, eY-1,&LineInfo);
/*lsi20040524*/
							}
						}
						else{
							if(BarGraphEventTbl->iScalePosition == _DOWN){
/*
								LineInfo.iLineColor = BLACK;
								LineOut(sPoint, sY+1, ePoint, sY+1, &LineInfo);
								LineOut(iCenterPosX, sY+1, iCenterPosX, sY+2,&LineInfo);
*/
/*lsi20040524 ���� */
							/*leesi 040524	*/
								if(RectInfo.iLineColor != BLACK){
									LineInfo.iLineColor = BLACK;
								}else{
									LineInfo.iLineColor = WHITE;
								}
								LineOut(sPoint, sY, ePoint, sY, &LineInfo);
								LineOut(iCenterPosX, sY, iCenterPosX, sY+1,&LineInfo);
/*lsi20040524*/
							}else
							{
/*								
								LineInfo.iLineColor = BLACK;
								LineOut(sPoint, eY-1, ePoint, eY-1, &LineInfo);
								LineOut(iCenterPosX, eY-1, iCenterPosX, eY-2,&LineInfo);
*/
/*lsi20040524 ���� */
							/*leesi 040524	*/
								if(RectInfo.iLineColor != BLACK){
									LineInfo.iLineColor = BLACK;
								}else{
									LineInfo.iLineColor = WHITE;
								}
								LineOut(sPoint, eY, ePoint, eY, &LineInfo);
								LineOut(iCenterPosX, eY, iCenterPosX, eY-1,&LineInfo);
/*lsi20040524*/
							}
						}
						/*--------------------------------------E*/
						break;
					}
				}
			}
		}
	}
	FreeMail((char *)iDisplayPos);
	FreeMail((char *)fPosVal);
	FreeMail((char *)BarGraphEventTbl);
}

