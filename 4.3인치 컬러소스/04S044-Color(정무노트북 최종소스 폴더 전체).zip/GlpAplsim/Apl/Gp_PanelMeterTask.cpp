/********************************************************************************/
/* �� �� �� : Gp_AlarmListTask.cpp												*/
/* ��    �� : NumericTask														*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"

/********************************************************************************/
/* �� �� �� : DrawPanel_Task													*/
/* ��    �� : Panel Meter ������ �ص��Ͽ� ȭ�鿡 ���						    */
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetPanel_Func(int iDispOrder)
{
	_PANEL_METER_EVENT_TBL*	 PanelMeterEventTbl;
	PanelMeterEventTbl= (_PANEL_METER_EVENT_TBL*)TakeMemory(sizeof(_PANEL_METER_EVENT_TBL));
	DrawPanel_Func(0,PanelMeterEventTbl,iDispOrder);
	FreeMail((char *)PanelMeterEventTbl);
}
int	DrawPanel_Func(int mode,_PANEL_METER_EVENT_TBL* PanelMeterEventTbl,int iDispOrder)
{
//		unsigned int iTagSizeOf = 0x00;
//		int					i;
		int					iOffset;	
		int					iDevAddress;
		unsigned char		*buffer;

		buffer= ScreenTagData[iDispOrder].TagPos;
/*		_PANEL_METER_EVENT_TBL*	 PanelMeterEventTbl;*/

//		i = 0;
		iOffset = 0;
/*
		if(CheckMailBox(sizeof(_PANEL_METER_EVENT_TBL)) == -1){
			return(-1);
		}
		if(IventTableCnt >= MAX_IVENT_CNT){
			return(-1);
		}
		IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_PANEL_METER_EVENT_TBL));
		PanelMeterEventTbl= (_PANEL_METER_EVENT_TBL*)IventTable[IventTableCnt];
*/
		memset((char *)PanelMeterEventTbl, 0x00, sizeof(_PANEL_METER_EVENT_TBL));
		/* 16bit, 32bit, Signed BIN, UnSigned BIN���� ����̽��� ������� ��� ù��° ����Ʈ ������ ��ȭ�Ѵ�. */
/*		PanelMeterEventTbl = (_PANEL_METER_EVENT_TBL*)TakeMemory(sizeof(_PANEL_METER_EVENT_TBL));
		memset((char *)PanelMeterEventTbl, 0x00, sizeof(_PANEL_METER_EVENT_TBL));
*/
/*
		iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
		iTagSizeOf += (unsigned int)buffer[1] & 0xff;
		
		PanelMeterEventTbl->sX  = (unsigned int)(buffer[6]  << 0x08);
		PanelMeterEventTbl->sX += (unsigned int)buffer[7] & 0xff;

		PanelMeterEventTbl->sY  = (unsigned int)(buffer[8] << 0x08);
		PanelMeterEventTbl->sY += (unsigned int)buffer[9] & 0xff;

		PanelMeterEventTbl->eX  = (unsigned int)(buffer[10] << 0x08);
		PanelMeterEventTbl->eX += (unsigned int)buffer[11] & 0xff;

		PanelMeterEventTbl->eY  = (unsigned int)(buffer[12] << 0x08);
		PanelMeterEventTbl->eY += (unsigned int)buffer[13] & 0xff;
*/
		iOffset = 14;
		/*------------------------------------------------------------*/
		if(mode == 0){
			GetDeviceSet((buffer+iOffset),
						PanelMeterEventTbl->cDeviceName,
						&(PanelMeterEventTbl->iDeviceNumber));
		}
		iOffset += 5;
		/*-------------------------------------------------------------*/		
		
		/* [24]~ [27] : �������� ��ǥ */
		PanelMeterEventTbl->iJutX = (unsigned int)(buffer[iOffset] << 0x08);
		PanelMeterEventTbl->iJutX += (unsigned int)buffer[++iOffset] & 0xff;

		PanelMeterEventTbl->iJutY = (unsigned int)(buffer[++iOffset] << 0x08);
		PanelMeterEventTbl->iJutY = (unsigned int)buffer[++iOffset] & 0xff;
		/*
		[28]����̽������� �����ߴ��� Fix������ �����ߴ����� ���� ������ ����
		0001	0001	Upper : Device		Lower : Device
		0001	0010	Upper : Fixed		Lower : Device
		0010	0001	Upper : Device		Lower : Fixed
		0010	0010	Upper : Fixed		Lower : Fixed

		iUpSel = 0x01 : Device		0x00 : Fixed
		iDwSel = 0x01 : Device		0x00 : Fixed
		*/
		++iOffset;
		if((unsigned int)buffer[iOffset] == 0x11){
			PanelMeterEventTbl->iUpSel = DEV;
			PanelMeterEventTbl->iDwSel = DEV;
		}
		else if((unsigned int)buffer[iOffset] == 0x12){
			PanelMeterEventTbl->iUpSel = FIXED;
			PanelMeterEventTbl->iDwSel = DEV;
		}
		else if((unsigned int)buffer[iOffset] == 0x21){
			PanelMeterEventTbl->iUpSel = DEV;
			PanelMeterEventTbl->iDwSel = FIXED;
		}
		else if((unsigned int)buffer[iOffset] == 0x22){
			PanelMeterEventTbl->iUpSel = FIXED;
			PanelMeterEventTbl->iDwSel = FIXED;
		}

		/* [29]		Direction	0x00 : Clockwise		0x04 : CounterClockwise */	

		switch(((unsigned int)buffer[++iOffset])){
		case 1:
			PanelMeterEventTbl->iType = TOP14;
			break;

		case 2:
			PanelMeterEventTbl->iType = BOTTOM14;
			break;

		case 3:
			PanelMeterEventTbl->iType = LEFT14;
			break;

		case 4:
			PanelMeterEventTbl->iType = RIGHT14;
			break;

		case 5:
			PanelMeterEventTbl->iType = TOP_RIGHT14;
			break;

		case 6:
			PanelMeterEventTbl->iType = TOP_LEFT14;
			break;

		case 7:
			PanelMeterEventTbl->iType = BOTTOM_LEFT14;
			break;

		case 8:
			PanelMeterEventTbl->iType = BOTTOM_RIGHT14;
			break;

		case 9:
			PanelMeterEventTbl->iType = TOP12;
			break;

		case 10:
			PanelMeterEventTbl->iType = BOTTOM12;
			break;

		case 11:
			PanelMeterEventTbl->iType = LEFT12;
			break;

		case 12:
			PanelMeterEventTbl->iType = RIGHT12;
			break;

		case 13:
			PanelMeterEventTbl->iType = FULL34;
			break;
		
		/* �����׷����� ��� */
		case 14:
			PanelMeterEventTbl->iType = FULL;
			PanelMeterEventTbl->iPoint = (unsigned int)buffer[iOffset+1];	
			break;
		}
		iOffset+=2;
		if((unsigned int)buffer[iOffset] == 0x00)
			PanelMeterEventTbl->iDirection = CLOCKWISE;
		else 
			PanelMeterEventTbl->iDirection = COUNTERCLOCKWISE;

		PanelMeterEventTbl->iNeedleColor = (unsigned int)buffer[++iOffset];		
		PanelMeterEventTbl->iMeterPanColor = (unsigned int)buffer[++iOffset];
		
		if(PanelMeterEventTbl->iUpSel == DEV){			
			/* 16bit Ȥ�� 32bit, Signed BIN, UnSigned GIN ���ÿ� ���� �� ����Ʈ ���� ��ȭ�Ѵ�. */
			iOffset++;
			/*------------------------------------------------------------*/
			if(mode == 0){
				GetDeviceSet((buffer+iOffset),
							PanelMeterEventTbl->cUpDeviceName,
							&(iDevAddress));
				PanelMeterEventTbl->iUpDeviceNumber = (unsigned int) iDevAddress;
			}
			/*-------------------------------------------------------------*/		
			iOffset+=4;
		}else{
#ifdef	WIN32
			PanelMeterEventTbl->iUpFixedValue =  (unsigned int)buffer[++iOffset] << 0x18;
			PanelMeterEventTbl->iUpFixedValue += (unsigned int)(buffer[++iOffset] & 0xffffff) << 0x10;
			PanelMeterEventTbl->iUpFixedValue += (unsigned int)(buffer[++iOffset] & 0xffff) << 0x08;
			PanelMeterEventTbl->iUpFixedValue += (unsigned int)buffer[++iOffset] & 0xff;
			++iOffset;
#else
			iOffset++;
			memcpy(&PanelMeterEventTbl->iUpFixedValue,&buffer[iOffset],4);
			iOffset += 4;
#endif
		}

		if(PanelMeterEventTbl->iDwSel == DEV){
			iOffset++;	
			/*------------------------------------------------------------*/
			if(mode == 0){
				GetDeviceSet((buffer+iOffset),
						PanelMeterEventTbl->cDwDeviceName,
						&(iDevAddress));
				PanelMeterEventTbl->iDwDeviceNumber = (unsigned int)iDevAddress;
			}
			/*-------------------------------------------------------------*/		
			iOffset+=5;
		}else{
#ifdef	WIN32
			PanelMeterEventTbl->iDwFixedValue  = (unsigned int)buffer[++iOffset] <<0x18;
			PanelMeterEventTbl->iDwFixedValue += (unsigned int)(buffer[++iOffset] & 0xffffff) <<0x10;
			PanelMeterEventTbl->iDwFixedValue += (unsigned int)(buffer[++iOffset] & 0xffff) <<0x08;
			PanelMeterEventTbl->iDwFixedValue += (unsigned int)buffer[++iOffset] & 0xff;
			iOffset+=2;
#else
			iOffset++;
			memcpy(&PanelMeterEventTbl->iDwFixedValue,&buffer[iOffset],4);
			iOffset+=5;
#endif
		}

/*		PanelMeterEventTbl->BeShapeUsed = (unsigned int)buffer[iOffset+2];*/
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed= buffer[iOffset+2];
		}
		if(ScreenTagData[iDispOrder].BeShapeUsed != 0){
			PanelMeterEventTbl->iFrameColor = (unsigned int)buffer[iOffset];
			PanelMeterEventTbl->iPlateColor = (unsigned int)buffer[++iOffset];
			iOffset+=2;
			PanelMeterEventTbl->ShapeNo = (unsigned int)buffer[iOffset];
			iOffset+=2;
		}else
		{
			iOffset += 5;
		}
		if(buffer[iOffset- 1] == 0){	/* 040920 */
			PanelMeterEventTbl->iScalePnts = (unsigned int)0;
		}else{
			PanelMeterEventTbl->iScalePnts = (unsigned int)buffer[iOffset];
		}
		PanelMeterEventTbl->iScaleColor = (unsigned int)buffer[++iOffset];
		++iOffset;
		if(((unsigned int)buffer[iOffset] & 0x01) == 0x01)
			PanelMeterEventTbl->iChkSigned = 0;  /* Signed */
		else
			PanelMeterEventTbl->iChkSigned = 1;  /* Unsigned */
		if((unsigned int)buffer[iOffset] < 3)
			PanelMeterEventTbl->iChkBit = 0;
		else
			PanelMeterEventTbl->iChkBit = 1;
		if(mode == 0){
			DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */
			DeviceDataHed[DeviceCnt].DevName[0] = PanelMeterEventTbl->cDeviceName[0];
			DeviceDataHed[DeviceCnt].DevName[1] = PanelMeterEventTbl->cDeviceName[1];
			DeviceDataHed[DeviceCnt].DevAddress = PanelMeterEventTbl->iDeviceNumber;
			
			if(PanelMeterEventTbl->iChkBit == 0){/* 0x00 : 16bit			0x01 : 32bit */
				DeviceDataHed[DeviceCnt].DevCnt = 1;			
			}else{/* 32bit */
				DeviceDataHed[DeviceCnt].DevCnt = 2;			
			}
			DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];		
/*			PanelMeterEventTbl->iRegisterNumber = DeviceCnt;*/
			ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
			ScreenTagData[iDispOrder].DevCnt= DeviceDataHed[DeviceCnt].DevCnt*2;
			if(PanelMeterEventTbl->iChkBit == 0){/* 0x00 : 16bit			0x01 : 32bit */			
				iDeviceOffset += 2; 
			}else{/* 32bit */			
				iDeviceOffset += 4; 
			}

			/* 20020819 choijh add*/
/*			PanelMeterEventTbl->SuperVOffset= WatchingDevice(PanelMeterEventTbl->cDeviceName, 
											   PanelMeterEventTbl->iDeviceNumber, 
											   PanelMeterEventTbl->iChkBit,
											   PanelMeterEventTbl->iRegisterNumber,
											   WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
			DeviceCnt++;
			
			
			/* ���Ѱ��� Device�� ���� ��� */
			if(PanelMeterEventTbl->iUpSel == DEV){	
				DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */
				DeviceDataHed[DeviceCnt].DevName[0] = PanelMeterEventTbl->cUpDeviceName[0];
				DeviceDataHed[DeviceCnt].DevName[1] = PanelMeterEventTbl->cUpDeviceName[1];
				DeviceDataHed[DeviceCnt].DevAddress = PanelMeterEventTbl->iUpDeviceNumber;
				if(PanelMeterEventTbl->iChkBit == 0){/* 0x00 : 16bit			0x01 : 32bit */
					DeviceDataHed[DeviceCnt].DevCnt = 1;				
				}else{/* 32bit */
					DeviceDataHed[DeviceCnt].DevCnt = 2;				
				}
				DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];			

				/*  leesi */
	/*			PanelMeterEventTbl->lBefDevVal = DeviceDataHed[DeviceCnt].DevData;*/
				
/*				PanelMeterEventTbl->iUpRegisterNumber = DeviceCnt;*/
				if(PanelMeterEventTbl->iChkBit == 0){/* 0x00 : 16bit			0x01 : 32bit */				
					iDeviceOffset += 2; 
				}else{/* 32bit */				
					iDeviceOffset += 4; 
				}
							
				/* 20020819 choijh add*/
/*				PanelMeterEventTbl->Up_SuperVOffset= WatchingDevice(PanelMeterEventTbl->cUpDeviceName, 
												   PanelMeterEventTbl->iUpDeviceNumber, 
												   PanelMeterEventTbl->iChkBit,
												   PanelMeterEventTbl->iUpRegisterNumber,
												   WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
				ScreenTagData[iDispOrder].DevCnt += DeviceDataHed[DeviceCnt].DevCnt*2;
				DeviceCnt++;
			}
			/* ���Ѱ��� Device�� ���� ��� */
			if(PanelMeterEventTbl->iDwSel == DEV){			
				DeviceDataHed[DeviceCnt].DevFlag = DEVICE_WORD;/* Word */
				DeviceDataHed[DeviceCnt].DevName[0] = PanelMeterEventTbl->cDwDeviceName[0];
				DeviceDataHed[DeviceCnt].DevName[1] = PanelMeterEventTbl->cDwDeviceName[1];
				DeviceDataHed[DeviceCnt].DevAddress = PanelMeterEventTbl->iDwDeviceNumber;
				if(PanelMeterEventTbl->iChkBit == 0){/* 0x00 : 16bit			0x01 : 32bit */
					DeviceDataHed[DeviceCnt].DevCnt = 1;				
				}else{/* 32bit */
					DeviceDataHed[DeviceCnt].DevCnt = 2;				
				}
				DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];
				/*  leesi */
	/*			PanelMeterEventTbl->lBefDevVal = DeviceDataHed[DeviceCnt].DevData;*/

/*				PanelMeterEventTbl->iDwRegisterNumber = DeviceCnt;*/
				if(PanelMeterEventTbl->iChkBit == 0){/* 0x00 : 16bit			0x01 : 32bit */				
					iDeviceOffset += 2; 
				}else{/* 32bit */				
					iDeviceOffset += 4; 
				}
							
				/* 20020819 choijh add*/
/*				PanelMeterEventTbl->Dw_SuperVOffset= WatchingDevice(PanelMeterEventTbl->cDwDeviceName, 
											   PanelMeterEventTbl->iDwDeviceNumber, 
											   PanelMeterEventTbl->iChkBit,
											   PanelMeterEventTbl->iDwRegisterNumber,
											   WORD,DeviceDataHed[DeviceCnt].DevCnt);
*/
				ScreenTagData[iDispOrder].DevCnt += DeviceDataHed[DeviceCnt].DevCnt*2;
				DeviceCnt++;
				PanelMeterDispCnt++;
			}
		}
/*		IventTableCnt++;*/
		return(0);
}
/* 060311 */
int	RoundFloat(double data)
{
	int		ret;

	if(data >= 0){
		ret= (int)(data+0.5);
	}else{
		ret= (int)(data-0.5);
	}
	return(ret);
}

/********************************************************************************/
/* �� �� �� : PanelMeterDispWatch												*/
/* ��    �� : PanelMeter�±������� ����  ȭ�鿡 ����� ����Ѵ�.				*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	PanelMeterDispWatch(int iOrder)
{
	int				iRadius	;/* �ݰ� */
	short			ScaleLen;
	int				iSide;
	long			lDeviceValue;
	long			lUpDeviceValue;
	long			lDwDeviceValue;
	unsigned long	ulDeviceValue;
	unsigned long	ulUpDeviceValue;
	unsigned long	ulDwDeviceValue;
	int				iScalePointChecked;/* ScalePoint�� �Բ� ������� �ƴ����� �����ϴ� �÷��� */
	int				iScalepointCnt;/* ScalePoint���� */
	short			iShapeSize;
	short			sX,sY,eX,eY;
	float			NowAngle;
	float			Angle;
	int				iStartX;
	int				iStartY;
	int				PointX;
	int				PointY;
	int				iEndY;
	int				iEndX;
/*	float			iTemp[50];
	int				k;
	int				iScalePtn;
	float			lTempVal;*/
	int				idx;
#ifdef	SIZE_2480_COL
	COLOR_DT	ForLineColor;
#endif

	_LINE_INFO		LineInfo;
	_ORGGATA_INFO	OrggataInfo;
	
	_PANEL_METER_EVENT_TBL*	 PanelMeterEventTbl;

/*
	k					= 0;
	memset(iTemp, 0x00, sizeof(iTemp));*/
	iRadius				= 0;
	iSide				= 0;
	lDeviceValue		= 0;
	lUpDeviceValue		= 0;
	lDwDeviceValue		= 0;
	iScalePointChecked	= 0;
	iScalepointCnt		= 0;
	ScaleLen			= 5;
/*	PanelMeterEventTbl= (_PANEL_METER_EVENT_TBL*)IventTable[iOrder];*/
	PanelMeterEventTbl= (_PANEL_METER_EVENT_TBL*)TakeMemory(sizeof(_PANEL_METER_EVENT_TBL));
	DrawPanel_Func(1,PanelMeterEventTbl,iOrder);

	idx= ScreenTagData[iOrder].DevOrder;
	if(PanelMeterEventTbl->iChkSigned == 0){
		lDeviceValue= ChangeChar2long(&DispDeviceData[idx],PanelMeterEventTbl->iChkBit);
	}else{
		lDeviceValue= ChangeChar2Unsinlong(&DispDeviceData[idx],PanelMeterEventTbl->iChkBit);
	}
	if(PanelMeterEventTbl->iChkBit == 0){/* 0x00 : 16bit			0x01 : 32bit */
		idx += 2;
	}else{
		idx += 4;
	}
	if(PanelMeterEventTbl->iUpSel == DEV){
		if(PanelMeterEventTbl->iChkSigned == 0){
			lUpDeviceValue= ChangeChar2long(&DispDeviceData[idx],PanelMeterEventTbl->iChkBit);
		}else{
			lUpDeviceValue= ChangeChar2Unsinlong(&DispDeviceData[idx],PanelMeterEventTbl->iChkBit);
		}
		if(PanelMeterEventTbl->iChkBit == 0){/* 0x00 : 16bit			0x01 : 32bit */
			idx += 2;
		}else{
			idx += 4;
		}
	}else{
		lUpDeviceValue = (long)PanelMeterEventTbl->iUpFixedValue;		
	}
	if(PanelMeterEventTbl->iDwSel == DEV){
		if(PanelMeterEventTbl->iChkSigned == 0){
			lDwDeviceValue= ChangeChar2long(&DispDeviceData[idx],PanelMeterEventTbl->iChkBit);
		}else{
			lDwDeviceValue= ChangeChar2Unsinlong(&DispDeviceData[idx],PanelMeterEventTbl->iChkBit);
		}
	}else{
		lDwDeviceValue = (long)PanelMeterEventTbl->iDwFixedValue;		
	}
/*
	lDeviceValue = PanelMeterEventTbl->lBefDevVal;
	lUpDeviceValue = PanelMeterEventTbl->lBefUpDevVal;
	lDwDeviceValue = PanelMeterEventTbl->lBefDwDevVal;
*/
	/* Scale Points�� ǥ���� ������ �ƴ����� ��Ÿ���� �÷��� */
	if(PanelMeterEventTbl->iScalePnts > 0){
		iScalePointChecked = 1;
		ScaleLen			= 5;		/* 040920 */
	}else{
		iScalePointChecked = 0;
		ScaleLen			= 0;		/* 040920 */
	}

	if(PanelMeterEventTbl->iScalePnts == 0){/* ScalePoint���� */
		iScalepointCnt = 50;
	}else{
		iScalepointCnt = PanelMeterEventTbl->iScalePnts;
	}
	sX = ScreenTagData[iOrder].sX;
	sY = ScreenTagData[iOrder].sY;
	eX = ScreenTagData[iOrder].eX;
	eY = ScreenTagData[iOrder].eY;
	/* Drawing */
		if(ScreenTagData[iOrder].BeShapeUsed != 0)
		{
			iShapeSize = DrawShape(PanelMeterEventTbl->ShapeNo,
								sX,	sY,	eX,	eY,
								PanelMeterEventTbl->iFrameColor,
								PanelMeterEventTbl->iPlateColor);
			sX += iShapeSize;
			sY += iShapeSize;
			eX -= iShapeSize;
			eY -= iShapeSize;
		}

	/* �ð� ���� */
/*	if(PanelMeterEventTbl->iDirection == CLOCKWISE){			
		lTempVal = (float)(lUpDeviceValue - lDwDeviceValue)/iScalepointCnt;
		for(k=0;k<=iScalepointCnt;k++){
			iTemp[k] = lDwDeviceValue + lTempVal * k;
			if(iTemp[k] >= lDeviceValue){
				if(k==0)
					iScalePtn = k;
				else
					iScalePtn = k- 1; 							
				break;
			}else if(k==iScalepointCnt)
				iScalePtn = k - 1;
		}
	}
*/	
	/* �ð�� ���� */
/*	else if(PanelMeterEventTbl->iDirection == COUNTERCLOCKWISE){
		lTempVal = (float)(lUpDeviceValue - lDwDeviceValue)/iScalepointCnt;
		for(k=0;k<iScalepointCnt;k++){
			iTemp[k] = lDwDeviceValue + lTempVal * k;
			if(iTemp[k] >= lDeviceValue){
				if(k==0)
					iScalePtn = k + 1;
				else
					iScalePtn = k;		
				break;
			}else if(k==iScalepointCnt-1){
				iScalePtn = k+1;
			}
		}
		iScalePtn = iScalepointCnt - iScalePtn;				
	}*/

	OrggataInfo.iColor = PanelMeterEventTbl->iMeterPanColor;
	OrggataInfo.iScaleColor = PanelMeterEventTbl->iScaleColor;

	switch(PanelMeterEventTbl->iType){
	case TOP14:
		iRadius = abs(eY - sY)-ScaleLen;
/*		iSide = (int)(sqrt((PanelMeterEventTbl->iJutX - PanelMeterEventTbl->sX)*(PanelMeterEventTbl->iJutX - PanelMeterEventTbl->sX) + 
			               (PanelMeterEventTbl->iJutY - PanelMeterEventTbl->eY)*(PanelMeterEventTbl->iJutY - PanelMeterEventTbl->eY)));*/
		iSide = (int)(iRadius*(sin((3.141592465/4))));
		/*iSide = (int)(sqrt((iRadius/2)*(iRadius/2) + (0)*(0)));
		iHeight = (int)sqrt(iRadius*iRadius - iSide*iSide);*/
			
		Angle = (float)(3.141592465/2);
		iStartX = -iSide;
		iStartY = iSide;
		iEndX = iSide;
		iEndY =	iSide;
		break;
	case BOTTOM14:
		iRadius = abs(eY - sY)-ScaleLen;
		iSide = (int)(iRadius*(sin((3.141592465/4))));

		Angle = (float)(3.141592465/2);
		iStartX = iSide;
		iStartY = -iSide;
		iEndX = -iSide;
		iEndY =	-iSide;
		break;
	case LEFT14:
		iRadius = abs(eX - sX)-ScaleLen;
		iSide = (int)(iRadius*(sin((3.141592465/4))));

		Angle = (float)(3.141592465/2);
		iStartX = -iSide;
		iStartY = -iSide;
		iEndX = -iSide;
		iEndY =	iSide;
		break;
	case RIGHT14:
		iRadius = abs(eX - sX)-ScaleLen;

		iSide = (int)(iRadius*(sin((3.141592465/4))));

		Angle = (float)(3.141592465/2);
		iStartX = iSide;
		iStartY = iSide;		
		iEndX = iSide;
		iEndY =	-iSide;
		break;
	case TOP_RIGHT14:
		iRadius = abs(eY - sY)-ScaleLen;

		Angle = (float)(3.141592465/2);
		iStartX = 0;
		iStartY = iRadius;
		iEndX = iRadius;
		iEndY =	0;
		break;
	case TOP_LEFT14:
		iRadius = abs(eY - sY)-ScaleLen;

		Angle = (float)(3.141592465/2);
		iStartX = -iRadius;
		iStartY = 0;
		iEndX = 0;
		iEndY =	iRadius;
		break;
	case BOTTOM_LEFT14:
		iRadius = abs(eY - sY)-ScaleLen;

		Angle = (float)(3.141592465/2);
		iStartX = 0;
		iStartY = -iRadius;
		iEndX = -iRadius;
		iEndY =	0;
		break;
	case BOTTOM_RIGHT14:
		iRadius = abs(eY - sY)-ScaleLen;

		Angle = (float)(3.141592465/2);
		iStartX = iRadius;
		iStartY = 0;
		iEndX = 0;
		iEndY =	-iRadius;
		break;
	case TOP12:
		iRadius = abs(eY - sY) - ScaleLen;

		Angle = (float)(3.141592465);
		iStartX = -iRadius;
		iStartY = 0;
		iEndX = iRadius;
		iEndY =	0;
		break;
	case BOTTOM12:
		iRadius = abs(eY - sY)-ScaleLen;

		iStartX = iRadius;
		iStartY = 0;
		iEndX = -iRadius;
		iEndY =	0;
		Angle = (float)(3.141592465);
		break;
	case LEFT12:

		iRadius = abs(eX - sX)-ScaleLen;

		Angle = (float)(3.141592465);
		iStartX = 0;
		iStartY = -iRadius;
		iEndX = 0;
		iEndY =	iRadius;
		break;
	case RIGHT12:
		iRadius = abs(eX - sX)-ScaleLen;

		Angle = (float)(3.141592465);
		iStartX = 0;
		iStartY = iRadius;
		iEndX = 0;
		iEndY =	-iRadius;
		break;
	case FULL34:
		iRadius = abs(eY - sY);
		iRadius = (iRadius/2)-ScaleLen;
			
		Angle = (float)(3.141592465*3)/2;
		iStartX = 0;
		iStartY = -iRadius;
		iEndX = iRadius;
		iEndY =	0;
		break;
	case FULL:
		iRadius = abs(eY - sY);
		iRadius = (iRadius/2)-ScaleLen;

		if(PanelMeterEventTbl->iPoint == DEGREE_0)
		{
			iStartX = iRadius;
			iStartY = 0;
		}else if(PanelMeterEventTbl->iPoint == DEGREE_90)
		{
			iStartX = 0;
			iStartY = iRadius;
		}else if(PanelMeterEventTbl->iPoint == DEGREE_180)
		{
			iStartX = -iRadius;
			iStartY = 0;
		}else
		{
			iStartX = 0;
			iStartY = -iRadius;
		}
		Angle = (float)(3.141592465)*2;
		iEndX = iStartX;
		iEndY =	iStartY;
		break;
	}
	DrawOrggata(PanelMeterEventTbl->iJutX,
					PanelMeterEventTbl->iJutY,
					iRadius, 
					iStartX, 
					iStartY, 
					iEndX, 
					iEndY,						
					iScalepointCnt,
					iScalePointChecked,
					&OrggataInfo);
	if((PanelMeterEventTbl->iChkBit != 0) && (PanelMeterEventTbl->iChkSigned == UNSIGNED)){
		ulDeviceValue= lDeviceValue;
		ulUpDeviceValue= lUpDeviceValue;
		ulDwDeviceValue= lDwDeviceValue;
		if(ulDeviceValue <= ulUpDeviceValue &&
			ulDeviceValue >= ulDwDeviceValue){
			LineInfo.iLineStyle = SOLID_LINE;
			LineInfo.iLineColor = PanelMeterEventTbl->iNeedleColor;
			/**/
			NowAngle = (Angle/((float)ulUpDeviceValue-(float)ulDwDeviceValue)*((float)ulDeviceValue-(float)ulDwDeviceValue));
			if(PanelMeterEventTbl->iDirection == CLOCKWISE){
				PointX	= (int)RoundFloat((iStartX*cos(NowAngle))+(iStartY*sin(NowAngle)));
				PointY	= (int)RoundFloat(-(iStartX*sin(NowAngle))+(iStartY*cos(NowAngle)));
			}else{
				PointX	= (int)RoundFloat((iEndX*cos(NowAngle))-(iEndY*sin(NowAngle)));
				PointY	= (int)RoundFloat((iEndX*sin(NowAngle))+(iEndY*cos(NowAngle)));
			}

			LineOut(PanelMeterEventTbl->iJutX, 
					PanelMeterEventTbl->iJutY, 
					PanelMeterEventTbl->iJutX + PointX, 
					PanelMeterEventTbl->iJutY - PointY, 
				&LineInfo);
#ifdef	SIZE_2480_COL
			ForLineColor= ChgColorData(LineInfo.iLineColor);
			if(TateYoko == 0){
				__MoveTo( PanelMeterEventTbl->iJutX, PanelMeterEventTbl->iJutY, SOLID_LINE, 0, ForLineColor );
			}else{
				__MoveTo( PanelMeterEventTbl->iJutY, 79- PanelMeterEventTbl->iJutX, SOLID_LINE, 0, ForLineColor );
			}
#else
			if(OrggataInfo.iScaleColor != 0){
				DrawColor= T_WHITE;
			}else{
				DrawColor= T_BLACK;
			}
			if(TateYoko == 0){
				__MoveTo( PanelMeterEventTbl->iJutX, PanelMeterEventTbl->iJutY, SOLID_LINE, 0 );
			}else{
				__MoveTo( PanelMeterEventTbl->iJutY, 79- PanelMeterEventTbl->iJutX, SOLID_LINE, 0 );
			}
#endif
		}
	}else{
		if(lDeviceValue <= lUpDeviceValue &&
			lDeviceValue >= lDwDeviceValue){
			LineInfo.iLineStyle = SOLID_LINE;
			LineInfo.iLineColor = PanelMeterEventTbl->iNeedleColor;
			/**/
			NowAngle = (Angle/((float)lUpDeviceValue-(float)lDwDeviceValue)*((float)lDeviceValue-(float)lDwDeviceValue));
			if(PanelMeterEventTbl->iDirection == CLOCKWISE){
				PointX	= (int)RoundFloat((iStartX*cos(NowAngle))+(iStartY*sin(NowAngle)));
				PointY	= (int)RoundFloat(-(iStartX*sin(NowAngle))+(iStartY*cos(NowAngle)));
			}else{
				PointX	= (int)RoundFloat((iEndX*cos(NowAngle))-(iEndY*sin(NowAngle)));
				PointY	= (int)RoundFloat((iEndX*sin(NowAngle))+(iEndY*cos(NowAngle)));
			}

			LineOut(PanelMeterEventTbl->iJutX, 
					PanelMeterEventTbl->iJutY, 
					PanelMeterEventTbl->iJutX + PointX, 
					PanelMeterEventTbl->iJutY - PointY, 
				&LineInfo);
#ifdef	SIZE_2480_COL
			ForLineColor= ChgColorData(LineInfo.iLineColor);
			if(TateYoko == 0){
				__MoveTo( PanelMeterEventTbl->iJutX, PanelMeterEventTbl->iJutY, SOLID_LINE, 0, ForLineColor );
			}else{
				__MoveTo( PanelMeterEventTbl->iJutY, (GAMEN_Y_SIZE-1)- PanelMeterEventTbl->iJutX, SOLID_LINE, 0, ForLineColor );
			}
#else
			if(OrggataInfo.iScaleColor != 0){
				DrawColor= T_WHITE;
			}else{
				DrawColor= T_BLACK;
			}
			if(TateYoko == 0){
				__MoveTo( PanelMeterEventTbl->iJutX, PanelMeterEventTbl->iJutY, SOLID_LINE, 0 );
			}else{
				__MoveTo( PanelMeterEventTbl->iJutY, (GAMEN_Y_SIZE-1)- PanelMeterEventTbl->iJutX, SOLID_LINE, 0 );
			}
#endif
		}
	}
/*
	LineOut(PanelMeterEventTbl->iJutX, 
			PanelMeterEventTbl->iJutY, 
			PanelMeterEventTbl->iJutX + ScalePoin[iScalePtn].x1, 
			PanelMeterEventTbl->iJutY + ScalePoin[iScalePtn].y1, 
			&LineInfo);


	PanelMeterEventTbl->iBefeX = PanelMeterEventTbl->iJutX + ScalePoin[iScalePtn].x1;
	PanelMeterEventTbl->iBefeY = PanelMeterEventTbl->iJutY + ScalePoin[iScalePtn].y1;
*/
	FreeMail((char *)PanelMeterEventTbl);
}
