/* ****************************************************************************** */
/*  �� �� �� : GP_SERIALSET.CPP													 */
/*  ��    �� : �ø��� ���														 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

/* ****************************************************************************** */
/* �迭																			 */
/* ****************************************************************************** */
char *cSpeed[10]		= {"300bps","600bps","1200bps","2400bps","4800bps","9600bps","19200bps","38400bps","57600bps","115200bps"};
/*							  0        1         2         3         4         5          6         7           8          9  */
char *cParity[3]	= {"NONE","ODD","EVEN"};
char *cData[2]		= {"7BIT","8BIT"};
char *cFlow[2]		= {"XON/XOFF","DSR/DTR"};
char *cStop[2]		= {"1BIT","2BIT"};
#ifdef	SIZE_2480

/* ****************************************************************************** */
/*  �Լ�																			 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �� �� �� : vSerialSet()															 */
/*  ��    �� : �ø��� ��� ���� ó��												 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 7��  1�� (ȭ)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void		vSerialSet(int* iScreenNo,int chanel)
{	
	int		iKeyCode;
	short	iKeyFlag;
	short	iSize;
	_RECTANGLE_INFO		RECParam;
	short	iSpeed;						/* 0:300, 1:600, 2:1200, 3:2400, 4:4800, 5:9600, 6:19200 7:38400bps 8:57600bps */
	short	iParity;					/* 0:NONE 1:EVEN 2:ODD */
	short	iData1;						/* 0: 7BITS 1:8BITS */
	short	iData2;						/* 0:XON/XOFF 1:DSR/DTR */
	short	iStop;						/* 0:1BITS 1:2BITS */
	char	*chDsp_buff;	
	char	*chDsp_Ver;	

	ClearDispBuff(SCREEN_0);								/*  ���÷��� ���� �ʱ�ȭ	 */
	OffSignal(SGN_PLC,1);

	chDsp_buff = TakeMemory(32);
	chDsp_Ver = TakeMemory(32);
/* 20060623 */
	if(chanel == CH_CH0){

			iSpeed = Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed;			/* 9600 */
			iParity = Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity;			/* 0:NONE,1:ODD,2:EVEN */
			iData1 = Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1;			/* 0:7,1:8 */
			iData2 = Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2;			/* 0:XON/XOFF 1:DSR/DTR */		
			iStop = Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop;				/* 0:1BITS 1:2BITS */		

		switch(Set.Ch1_iKind){
		case UNIVERSAL:
		case DEFAULT_PLC:
		case ELSE_PLC:
			GetCh1Name(chDsp_buff,chDsp_Ver);
			break;
		default:
			strcpy(chDsp_buff,Dspname[PLC_ADD_SETTING].chName[Set.iLang][Set.Ch1_iKind-EDITER+2]);
			memset(chDsp_Ver,0,32);
			break;
		}

	}else{
		iSpeed = Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed;			/* 9600 */
		iParity = Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity;			/* 0:NONE,1:ODD,2:EVEN */
		iData1 = Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1;			/* 0:7,1:8 */
		iData2 = Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2;			/* 0:XON/XOFF 1:DSR/DTR */		
		iStop = Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop;				/* 0:1BITS 1:2BITS */		

		switch(Set.Ch2_iKind){
		case PLCTYPE2:
			strcpy(chDsp_buff,CommonArea.PlcType2.AuxPlcTypeName);
			GetPlc2Ver(chDsp_Ver);
			break;
		default:
			strcpy(chDsp_buff,Dspname[PLC_ADD_SETTING].chName[Set.iLang][Set.Ch2_iKind-EDITER+2]);
			memset(chDsp_Ver,0,32);
			break;
		}
	}
	iKeyCode = 80;
	iKeyFlag = 1;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	RectAngleOut(GAMEN_START_X+40,GAMEN_START_Y+24,GAMEN_START_X+238,GAMEN_START_Y+41,&RECParam);
	RectAngleOut(GAMEN_START_X+55,GAMEN_START_Y+43,GAMEN_START_X+97,GAMEN_START_Y+60,&RECParam);
	RectAngleOut(GAMEN_START_X+196,GAMEN_START_Y+43,GAMEN_START_X+238,GAMEN_START_Y+60,&RECParam);
	RectAngleOut(GAMEN_START_X+55,GAMEN_START_Y+62,GAMEN_START_X+97,GAMEN_START_Y+79,&RECParam);
	RectAngleOut(GAMEN_START_X+165,GAMEN_START_Y+62,GAMEN_START_X+238,GAMEN_START_Y+79,&RECParam);

/*	DotTextOut(1,25,Dspname[SERIAL_PORT].chName[Set.iLang][0],1,1, NON_TRANS, T_WHITE, T_BLACK);*/
	DotTextOut(GAMEN_START_X+1,GAMEN_START_Y+25,Dspname[SERIAL_PORT].chName[Set.iLang][1],1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+1,GAMEN_START_Y+44,Dspname[SERIAL_PORT].chName[Set.iLang][2],1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+123,GAMEN_START_Y+44,Dspname[SERIAL_PORT].chName[Set.iLang][3],1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+1,GAMEN_START_Y+63,Dspname[SERIAL_PORT].chName[Set.iLang][4],1,1, NON_TRANS, T_WHITE, T_BLACK);
	
	if(Set.iLang == 0)
		DotTextOut(GAMEN_START_X+123,GAMEN_START_Y+63,Dspname[SERIAL_PORT].chName[Set.iLang][5],1,1, NON_TRANS, T_WHITE, T_BLACK);
	else
	{
		if(strlen(Dspname[SERIAL_PORT].chName[Set.iLang][5]) > 4 )
			DotTextOut(GAMEN_START_X+102,GAMEN_START_Y+63,Dspname[SERIAL_PORT].chName[Set.iLang][5],1,1, NON_TRANS, T_WHITE, T_BLACK);
		else
			DotTextOut(GAMEN_START_X+123,GAMEN_START_Y+63,Dspname[SERIAL_PORT].chName[Set.iLang][5],1,1, NON_TRANS, T_WHITE, T_BLACK);
	}

/*	DefaultFormDisplay(LINE_FORM, Dspname[SERIAL_PORT].chTitle[Set.iLang]);*/
	DefaultFormDisplay(LINE_FORM, chDsp_buff);
	iSize = strlen(chDsp_Ver);
	if(iSize != 0){
	}
/*031120	if(Set.iConnect == 0 || Set.iPrint == EDITER || Set.iPrint == MONITOR || Set.iPrint == PLCTYPE2)*/
/*	if(Set.Ch1_iKind == EDITER || Set.Ch1_iKind == MONITOR || Set.Ch1_iKind == PLCTYPE2)*/
	while ( *iScreenNo == SERIAL_PORT_NUM ) {
		/* PRINTER */
		AreaClear(GAMEN_START_X+41, GAMEN_START_Y+25, GAMEN_START_X+115, GAMEN_START_Y+40, 0);
		AreaClear(GAMEN_START_X+161, GAMEN_START_Y+25, GAMEN_START_X+237, GAMEN_START_Y+40, 0);
		AreaClear(GAMEN_START_X+56, GAMEN_START_Y+44, GAMEN_START_X+96, GAMEN_START_Y+59, 0);
		AreaClear(GAMEN_START_X+197, GAMEN_START_Y+44, GAMEN_START_X+237, GAMEN_START_Y+59, 0);
		AreaClear(GAMEN_START_X+56, GAMEN_START_Y+63, GAMEN_START_X+96, GAMEN_START_Y+78, 0);
		AreaClear(GAMEN_START_X+166, GAMEN_START_Y+63, GAMEN_START_X+237, GAMEN_START_Y+78, 0);

		DotTextOut(GAMEN_START_X+48, GAMEN_START_Y+25, cSpeed[iSpeed],1,1, NON_TRANS, T_WHITE, T_BLACK);
		/* DATA1 */
		CenterDisplay(GAMEN_START_X+55,GAMEN_START_Y+44,GAMEN_START_X+97,GAMEN_START_Y+59,cData[iData1]);
		
		/* STOP */
		CenterDisplay(GAMEN_START_X+196,GAMEN_START_Y+44,GAMEN_START_X+238,GAMEN_START_Y+59,cStop[iStop]);

		/* Parity */
		CenterDisplay(GAMEN_START_X+55,GAMEN_START_Y+63,GAMEN_START_X+97,GAMEN_START_Y+78,cParity[iParity]);

		/* DATA2 */
		CenterDisplay(GAMEN_START_X+165,GAMEN_START_Y+63,GAMEN_START_X+238,GAMEN_START_Y+78,cFlow[iData2]);

		if(iKeyCode >0)
			DrawLcdBank1();

		iKeyCode = KeyWaitData(iKeyFlag,SERIAL_PORT_NUM);							/* �Էµ� Ű���� �о��	 */
		iKeyFlag = 0;

		if ((iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) ||	/*Exit*/
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) ||	/*Menu*/
			(iKeyCode >= KEY_18 && iKeyCode <= KEY_30 ) ||	/*Boadrate*/
			(iKeyCode >= KEY_34 && iKeyCode <= KEY_36 ) ||
			(iKeyCode >= KEY_43 && iKeyCode <= KEY_45 ) || 
			(iKeyCode >= KEY_49 && iKeyCode <= KEY_51 ) ||
			(iKeyCode >= KEY_56 && iKeyCode <= KEY_60 )) 
		{
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
		}
		if(iKeyCode == 0){
			iKeyCode = -1;
			continue;
		}
		switch(iKeyCode){
		case PC_DNLOAD_START:	/* DownLoad	*/
			*iScreenNo = DOWN_TRANS;
			break;
		case PC_UPLOAD_START:	/* UPLoad	*/
			*iScreenNo = UP_TRANS;
			break;
		case KEY_01:
		case KEY_02:	/* EXIT */
			*iScreenNo = USER_SCREEN_NUM;
			break;
		case KEY_13:
		case KEY_14:
		case KEY_15:	/* MENU */
			*iScreenNo = SET_ENVIRONMENT_NUM;
			break;
		default:
			if (iKeyCode >= KEY_18 && iKeyCode <= KEY_30 ) /* SPEED */
			{										
				if (iSpeed > 8 ) {
					iSpeed = 0;
				} else {
					iSpeed++;
				}
				AreaClear(GAMEN_START_X+48, GAMEN_START_Y+25, GAMEN_START_X+237, GAMEN_START_Y+40, 0);
				DotTextOut(GAMEN_START_X+48, GAMEN_START_Y+25, cSpeed[iSpeed],1,1, NON_TRANS, T_WHITE, T_BLACK);

			} else if (iKeyCode >= KEY_34 && iKeyCode <= KEY_36 ) 
			{											
				/*  Data1 ����			 */
				if (iData1 > 0 ) {
					iData1 = 0;
				} else {
					iData1++;
				}
				AreaClear(GAMEN_START_X+56, GAMEN_START_Y+44, GAMEN_START_X+96, GAMEN_START_Y+59, 0);
				CenterDisplay(GAMEN_START_X+55,GAMEN_START_Y+44,GAMEN_START_X+97,GAMEN_START_Y+59,cData[iData1]);
		
			} else if (iKeyCode >= KEY_43 && iKeyCode <= KEY_45 ) 
			{											
				/*  Stop ����			 */
				if (iStop > 0 ) {
					iStop = 0;
				} else {
					iStop++;
				}
				AreaClear(GAMEN_START_X+197, GAMEN_START_Y+44, GAMEN_START_X+237, GAMEN_START_Y+59, 0);
				CenterDisplay(GAMEN_START_X+196,GAMEN_START_Y+44,GAMEN_START_X+238,GAMEN_START_Y+59,cStop[iStop]);	
			} else if (iKeyCode >= KEY_49 && iKeyCode <= KEY_51 ) 
			{										
				/*  Parity ����			 */
				if (iParity > 1 ) {
					iParity = 0;
				} else {
					iParity++;
				}	
				AreaClear(GAMEN_START_X+56, GAMEN_START_Y+63, GAMEN_START_X+96, GAMEN_START_Y+78, 0);
				CenterDisplay(GAMEN_START_X+55,GAMEN_START_Y+63,GAMEN_START_X+97,GAMEN_START_Y+78,cParity[iParity]);

			} else if (iKeyCode >= KEY_56 && iKeyCode <= KEY_60 ) 
			{										
				/*  Data2 ����			 */
				if (iData2 > 0 ) {
					iData2 = 0;
				} else {
					iData2++;
				}
				AreaClear(GAMEN_START_X+166, GAMEN_START_Y+63, GAMEN_START_X+237, GAMEN_START_Y+78, 0);
				CenterDisplay(GAMEN_START_X+165,GAMEN_START_Y+63,GAMEN_START_X+238,GAMEN_START_Y+78,cFlow[iData2]);	
			}else
			{
				iKeyCode = -1;
			}
			break;
		}
	}
	if(chanel == CH_CH0){
/* 20060623 */
		Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed= iSpeed;			/* 9600 */
		Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity= iParity;			/* 0:NONE,1:ODD,2:EVEN */
		Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1= iData1;			/* 0:7,1:8 */
		Set.Ch1_Serial_Param[Set.Ch1_iKind].iData2= iData2;			/* 0:XON/XOF,1:DSR/DTR */
		Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop= iStop;
	}else{
/* 20060623 */
		Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed= iSpeed;			/* 9600 */
		Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity= iParity;			/* 0:NONE,1:ODD,2:EVEN */
		Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1= iData1;			/* 0:7,1:8 */
		Set.Ch2_Serial_Param[Set.Ch2_iKind].iData2= iData2;			/* 0:XON/XOF,1:DSR/DTR */
		Set.Ch2_Serial_Param[Set.Ch2_iKind].iStop= iStop;
	}
	if((iKeyCode == PC_DNLOAD_START) || 		/* DownLoad	*/
		(iKeyCode == PC_UPLOAD_START)){	/* UPLoad	*/
	}else{
/*
		Rs232cBordrateSet();
		PC_CommMode= 0;
		OnSignal(SGN_PLC,1);
*/
	}
	FreeMail(chDsp_buff);
	FreeMail(chDsp_Ver);
	return;
}
#endif

