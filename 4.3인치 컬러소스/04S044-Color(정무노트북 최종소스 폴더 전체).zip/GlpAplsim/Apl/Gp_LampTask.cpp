/********************************************************************************/
/* �� �� ��: Gp_LampTask.cpp													*/
/* ��    �� : DrawLamp_Task														*/
/* �� �� �� : 2002��5��9��														*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"
/********************************************************************************/
/* �� �� �� : DrawLamp_Task														*/
/* ��    �� : Lamp ������ �ص��Ͽ� ȭ�鿡 ���									*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 4�� 29��													*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	SetLamp_Func(int iDispOrder)
{
	_LAMP_EVENT_TBL*	 LampDispEventTbl;
	LampDispEventTbl= (_LAMP_EVENT_TBL*)TakeMemory(sizeof(_LAMP_EVENT_TBL));
	DrawLamp_Func(0,LampDispEventTbl,iDispOrder);
	FreeMail((char *)LampDispEventTbl);
}
int	DrawLamp_Func(int mode,_LAMP_EVENT_TBL* LampDispEventTbl,int iDispOrder)
{
/*	unsigned int		iTagSizeOf = 0;*/
	int					iStartpt = 0;
	unsigned char		*buffer;

	buffer= ScreenTagData[iDispOrder].TagPos;
/*	_LAMP_EVENT_TBL*	 LampDispEventTbl;*/
/*
	if(CheckMailBox(sizeof(_LAMP_EVENT_TBL)) == -1){
		return(-1);
	}
	if(IventTableCnt >= MAX_IVENT_CNT){
		return(-1);
	}
	IventTable[IventTableCnt] = (void*)TakeMemory(sizeof(_LAMP_EVENT_TBL));
	LampDispEventTbl= (_LAMP_EVENT_TBL*)IventTable[IventTableCnt];
*/
	memset((char *)LampDispEventTbl, 0x00, sizeof(_LAMP_EVENT_TBL));
/*
	iTagSizeOf = (unsigned int)(buffer[0] << 0x08);
	iTagSizeOf += (unsigned int)buffer[1] & 0xff;
*/

	ScreenTagData[iDispOrder].sX  = (unsigned int)(buffer[6]  << 0x08);
	ScreenTagData[iDispOrder].sX += (unsigned int)buffer[7] & 0xff;

	ScreenTagData[iDispOrder].sY  = (unsigned int)(buffer[8] << 0x08);
	ScreenTagData[iDispOrder].sY += (unsigned int)buffer[9] & 0xff;

	ScreenTagData[iDispOrder].eX  = (unsigned int)(buffer[10] << 0x08);
	ScreenTagData[iDispOrder].eX += (unsigned int)buffer[11] & 0xff;

	ScreenTagData[iDispOrder].eY  = (unsigned int)(buffer[12] << 0x08);
	ScreenTagData[iDispOrder].eY += (unsigned int)buffer[13] & 0xff;	

	/* buffer[16] �±� �м��ȵ� */
	if((unsigned int)buffer[14] == 0x04){
		LampDispEventTbl->iShapeSelect = BASIC_FIGURE;
	}else{
		LampDispEventTbl->iShapeSelect = PARTS;
	}
	LampDispEventTbl->iOffFrameColor = (unsigned int) buffer[15];
	LampDispEventTbl->iOnFrameColor = (unsigned int) buffer[16];
	iStartpt = 17;
	/*------------------------------------------------------------*/
	GetDeviceSet((buffer+iStartpt),
				LampDispEventTbl->cDeviceName,
				&(LampDispEventTbl->iDeviceNumber));
	/*-------------------------------------------------------------*/		
	iStartpt+=5;
	if(LampDispEventTbl->iShapeSelect == BASIC_FIGURE){
		LampDispEventTbl->OffShapeNo      = (unsigned int)buffer[iStartpt];
		LampDispEventTbl->OffLampColor    = (unsigned int)buffer[++iStartpt];
		LampDispEventTbl->iOff68DotFlag   = (unsigned int)buffer[++iStartpt];
		LampDispEventTbl->OnShapeNo       = (unsigned int)buffer[++iStartpt];
		LampDispEventTbl->OnLampColor     = (unsigned int)buffer[++iStartpt];
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed	  = 1;	  /* And Or�� ���� Ŭ����. */
		}
		LampDispEventTbl->iOn68DotFlag    = (unsigned int)buffer[++iStartpt];	
	}
	else if(LampDispEventTbl->iShapeSelect == PARTS){
		LampDispEventTbl->OffPartsNo	  = (unsigned int)(buffer[iStartpt]  << 0x08);
		LampDispEventTbl->OffPartsNo	 += (unsigned int)buffer[++iStartpt] & 0xff;
		LampDispEventTbl->iOff68DotFlag   = (unsigned int)buffer[++iStartpt];
		LampDispEventTbl->OnPartsNo	      = (unsigned int)(buffer[++iStartpt]  << 0x08);
		LampDispEventTbl->OnPartsNo	     += (unsigned int)buffer[++iStartpt] & 0xff;
		if(mode == 0){
			ScreenTagData[iDispOrder].BeShapeUsed     = 0;	  /* And Or�� ���� Ŭ����. */
		}
		LampDispEventTbl->iOn68DotFlag    = (unsigned int)buffer[++iStartpt];	
	}

	LampDispEventTbl->iOffTxtColor    = (unsigned int)buffer[++iStartpt];
	LampDispEventTbl->iOffFontSizeH   = (unsigned int)buffer[++iStartpt];
	LampDispEventTbl->iOffFontSizeV   = (unsigned int)buffer[++iStartpt];	//20101207
	if(LampDispEventTbl->iOff68DotFlag != 0){
		LampDispEventTbl->iOffFontSizeH = 0;
		LampDispEventTbl->iOffFontSizeV = 0;		//20101207
	}
	if(mode == 0){
		ScreenTagData[iDispOrder].uu.Lamp.cOffPosition    = (unsigned int)buffer[++iStartpt];
	}else{
		iStartpt++;
	}
	LampDispEventTbl->iOffTxtLen      = (unsigned int)buffer[++iStartpt];
    iStartpt++;

	if(LampDispEventTbl->iOffTxtLen>0){
		LampDispEventTbl->cOffTxtBuffer = (char *)(buffer + iStartpt);
/*		EnterCutting(LampDispEventTbl->cOffTxtBuffer);*/
		iStartpt += LampDispEventTbl->iOffTxtLen;
	}
	LampDispEventTbl->iOnTxtColor    = (unsigned int)buffer[iStartpt];
	LampDispEventTbl->iOnFontSizeH   = (unsigned int)buffer[++iStartpt];
	LampDispEventTbl->iOnFontSizeV   = (unsigned int)buffer[++iStartpt];	//20101207
	if(LampDispEventTbl->iOn68DotFlag != 0){
		LampDispEventTbl->iOnFontSizeH = 0;
		LampDispEventTbl->iOnFontSizeV = 0;		//20101207
	}
	if(mode == 0){
		ScreenTagData[iDispOrder].uu.Lamp.cOnPosition   = (unsigned int)buffer[++iStartpt];	/* ���ο� ��� �߰���    */
	}else{
		iStartpt++;
	}
	LampDispEventTbl->iOnTxtLen      = (unsigned int)buffer[++iStartpt];
	if(LampDispEventTbl->iOnTxtLen>0){
		iStartpt++;
		LampDispEventTbl->cOnTxtBuffer = (char *)(buffer + iStartpt);
	}
	if(mode == 0){
		DeviceDataHed[DeviceCnt].DevFlag = DEVICE_BIT;/* Bit */
		DeviceDataHed[DeviceCnt].DevName[0] = LampDispEventTbl->cDeviceName[0];
		DeviceDataHed[DeviceCnt].DevName[1] = LampDispEventTbl->cDeviceName[1];
		DeviceDataHed[DeviceCnt].DevAddress = LampDispEventTbl->iDeviceNumber;	
		DeviceDataHed[DeviceCnt].DevCnt = 1;	
		DeviceDataHed[DeviceCnt].DevData = &DeviceData[iDeviceOffset];		
/*		LampDispEventTbl->iRegisterNumber = DeviceCnt;*/
			
		/* 20020819 choijh add*/
/*		LampDispEventTbl->SuperVOffset= WatchingDevice(LampDispEventTbl->cDeviceName, 
										LampDispEventTbl->iDeviceNumber,
										0,
										LampDispEventTbl->iRegisterNumber,
										BIT, DeviceDataHed[DeviceCnt].DevCnt);
*/
		ScreenTagData[iDispOrder].DevOrder= iDeviceOffset;
		ScreenTagData[iDispOrder].DevCnt= DeviceDataHed[DeviceCnt].DevCnt;
		DeviceCnt++;
		iDeviceOffset++;
		LampDispCnt++;
	}
/*	IventTableCnt++;*/
	return(0);
}

/********************************************************************************/
/* �� �� �� : LampDispWatch														*/
/* ��    �� : Lamp�±������� ����  ȭ�鿡 ����� ����Ѵ�.						*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 31�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
void	LampDispWatch(int iOrder)
{
	char*   cOffTextBuffer;
	char*   cOnTextBuffer;
	int		i;
	int		iDeviceValue;
//	int		iOnFontsX;
//	int		iOnFontsY;
//	int		iOffFontsX;
//	int		iOffFontsY;
	int		iFlag;
	
	int		sX;
	int		sY;
	int		eX;
	int		eY;
	_LAMP_EVENT_TBL*	 LampDispEventTbl;

/*	LampDispEventTbl= (_LAMP_EVENT_TBL*)IventTable[iOrder];*/
	LampDispEventTbl= (_LAMP_EVENT_TBL*)TakeMemory(sizeof(_LAMP_EVENT_TBL));
	DrawLamp_Func(1,LampDispEventTbl,iOrder);
	iDeviceValue	= 0;
//	iOnFontsX		= 0;
//	iOnFontsY		= 0;
//	iOffFontsX		= 0;
//	iOffFontsY		= 0;
	iFlag			= 0;

	sX = ScreenTagData[iOrder].sX;
	sY = ScreenTagData[iOrder].sY;
	eX = ScreenTagData[iOrder].eX;
	eY = ScreenTagData[iOrder].eY;

	i = iOrder;
/*	iDeviceValue = LampDispEventTbl->iBefDevVal;*/
	iDeviceValue= DispDeviceData[ScreenTagData[iOrder].DevOrder];
//	iOffFontsX = (int)((ScreenTagData[iOrder].eX + ScreenTagData[iOrder].sX)/2) - ((int)(LampDispEventTbl->iOffTxtLen/2)*8);
//	iOffFontsY = (int)((ScreenTagData[iOrder].eY - ScreenTagData[iOrder].sY)/2) + 2;
//	iOnFontsX = (int)((ScreenTagData[iOrder].eX + ScreenTagData[iOrder].sX)/2) - ((int)(LampDispEventTbl->iOnTxtLen/2)*8);
//	iOnFontsY = (int)((ScreenTagData[iOrder].eY - ScreenTagData[iOrder].sY)/2) + 2;

/*	if(iOnSignalStart != OFF){*/
		if(iDeviceValue == 0){/* OFF */
			iFlag = OFF;
			if(LampDispEventTbl->iShapeSelect == BASIC_FIGURE){
				LampDraw(sX, sY, eX, eY,
					 LampDispEventTbl->OffShapeNo,
					 iFlag, i
					 ,LampDispEventTbl->iOffFrameColor
					 ,LampDispEventTbl->OffLampColor );
			}
			else if(LampDispEventTbl->iShapeSelect == PARTS){

/* 060926				vPartDataSet(LampDispEventTbl->OffPartsNo, i, 1,-1);*/	/* 0 : Part, 1 : Lamp, 2 : Touch */
//2011.09.08				vPartDataSet(ScreenTagData[iOrder].sX,ScreenTagData[iOrder].sY,ScreenTagData[iOrder].eX,ScreenTagData[iOrder].eY,
//2011.09.08							LampDispEventTbl->OffPartsNo, i, 1,-1);	/* 0 : Part, 1 : Lamp, 2 : Touch */
				vPartDataSet(sX,sY,eX,eY,LampDispEventTbl->OffPartsNo, i, 1,-1);	/* 0 : Part, 1 : Lamp, 2 : Touch */
			}

			if(LampDispEventTbl->iOffTxtLen > 0){
				cOffTextBuffer = (char *)TakeMemory(LampDispEventTbl->iOffTxtLen+1);
				memcpy(cOffTextBuffer, LampDispEventTbl->cOffTxtBuffer, (LampDispEventTbl->iOffTxtLen+1));
				cOffTextBuffer[LampDispEventTbl->iOffTxtLen]= 0;
				EnterCutting(cOffTextBuffer);
				if(*cOffTextBuffer == 0){
				}else{
					if(((ScreenTagData[iOrder].uu.Lamp.cOffPosition != 0) && (ScreenTagData[iOrder].uu.Lamp.cOffPosition != 2)) &&
						((LampDispEventTbl->OffLampColor == BLACK) && (LampDispEventTbl->iOffTxtColor == BLACK))){
					}else{
						vTextPositionDisp(&sX, &sY, &eX, &eY, 
							cOffTextBuffer,
							LampDispEventTbl->iOffFontSizeH, 
							LampDispEventTbl->iOffFontSizeV, 
							LampDispEventTbl->iOffTxtColor, 
							ScreenTagData[iOrder].uu.Lamp.cOffPosition);

						/* Text �Ѵ� ������ ���� Ŭ���� --------------------------------------------*/
						if(ScreenTagData[iOrder].uu.Lamp.cOffPosition == 1 ||
							ScreenTagData[iOrder].uu.Lamp.cOffPosition == 3)
						{
							ScreenTagData[iOrder].sX = sX;
							ScreenTagData[iOrder].sY = sY;
							ScreenTagData[iOrder].eX = eX;
							ScreenTagData[iOrder].eY = eY;
						}
						/*--------------------------------------------------------------------------*/
					}
				}
				FreeMail(cOffTextBuffer);
			}
		}else{
			iFlag = ON;
			if(LampDispEventTbl->iShapeSelect == BASIC_FIGURE){
				LampDraw(sX, sY, eX, eY,
					 LampDispEventTbl->OnShapeNo,
					 iFlag, i					 
					 ,LampDispEventTbl->iOnFrameColor
					 ,LampDispEventTbl->OnLampColor);
			}
			else if(LampDispEventTbl->iShapeSelect == PARTS){						
/* 060926				vPartDataSet(LampDispEventTbl->OnPartsNo, i, 1,-1);*/	/* 0 : Part, 1 : Lamp, 2 : Touch */
//2011.09.08				vPartDataSet(ScreenTagData[iOrder].sX,ScreenTagData[iOrder].sY,ScreenTagData[iOrder].eX,ScreenTagData[iOrder].eY,
//2011.09.08							LampDispEventTbl->OnPartsNo, i, 1,-1);	/* 0 : Part, 1 : Lamp, 2 : Touch */
				vPartDataSet(sX,sY,eX,eY,LampDispEventTbl->OnPartsNo, i, 1,-1);	/* 0 : Part, 1 : Lamp, 2 : Touch */

			}
				
			if(LampDispEventTbl->iOnTxtLen > 0){
				cOnTextBuffer = (char *)TakeMemory(LampDispEventTbl->iOnTxtLen+1);
				memcpy(cOnTextBuffer, LampDispEventTbl->cOnTxtBuffer, (LampDispEventTbl->iOnTxtLen+1));
//				cOnTextBuffer[LampDispEventTbl->iOffTxtLen]= 0;
				cOnTextBuffer[LampDispEventTbl->iOnTxtLen]= 0;
				EnterCutting(cOnTextBuffer);
				if(*cOnTextBuffer == 0){
				}else{
					if(((ScreenTagData[iOrder].uu.Lamp.cOnPosition != 0) && (ScreenTagData[iOrder].uu.Lamp.cOnPosition != 2)) &&
						((LampDispEventTbl->OnLampColor == BLACK) && (LampDispEventTbl->iOnTxtColor == BLACK))){
					}else{
						vTextPositionDisp(&sX, &sY, &eX, &eY, 
							cOnTextBuffer,
							LampDispEventTbl->iOnFontSizeH, 
							LampDispEventTbl->iOnFontSizeV,
							LampDispEventTbl->iOnTxtColor,
							ScreenTagData[iOrder].uu.Lamp.cOnPosition);

						/* Text �Ѵ� ������ ���� Ŭ���� --------------------------------------------*/
						if(ScreenTagData[iOrder].uu.Lamp.cOnPosition == 1 ||
							ScreenTagData[iOrder].uu.Lamp.cOnPosition == 3)
						{
							ScreenTagData[iOrder].sX = sX;
							ScreenTagData[iOrder].sY = sY;
							ScreenTagData[iOrder].eX = eX;
							ScreenTagData[iOrder].eY = eY;
						}
						/*--------------------------------------------------------------------------*/
					}
				}
				FreeMail(cOnTextBuffer);
			}
		}
		FreeMail((char *)LampDispEventTbl);
/*	}*/
}

/********************************************************************************/
/* �� �� �� : LampDraw															*/
/* ��    �� : Lamp������  ȭ�鿡 ���											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 27��													*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
/* J.S.LIM 2004/06/02  �Լ� ��ü ���� */
void	LampDraw(int sX, int sY, int eX, int eY, int iLampNumber, int Flag, int iTagNumber, int iFrameColor, int iLampColor)
{
	_RECTANGLE_INFO	RtInf;
	_LINE_INFO		lnWhite;
	_LINE_INFO		lnBlack;
	_CIRCLE_INFO	cirParam;

	int ax, ay, bx, by, cx, cy;
	int width, height, mid;
	int r1, r2, z;

	lnWhite.iLineColor = WHITE;
	lnWhite.iLineStyle = SOLID_LINE;
	lnBlack.iLineColor = BLACK;
	lnBlack.iLineStyle = SOLID_LINE;

	RtInf.iLineStyle = SOLID_LINE;
	RtInf.iLineColor = iFrameColor;
	RtInf.iForeColor = iLampColor;
	RtInf.iBackColor = BLACK;	
	RtInf.iPattern = PAT8;
	switch(iLampNumber){
	case 1:
	case 2:/* 1�� ���� */
		/* frame color�� �簢�� �׵θ� �׸���, ���������� ���� ä�� */
		RectAngleOut(sX, sY, eX, eY, &RtInf);
		break;
	case 3:
	case 4:/* 2�� ���� */
		/* frame color�� �簢�� �׵θ� �׸���, ���������� ���� ä�� */
		RtInf.iForeColor = BLACK;
		RectAngleOut(sX, sY, eX, eY, &RtInf);
		
		/* ��� ������, ���������� ä���� ���� �簢�� �׸� */
		r1 = (eX-sX)/4;
		r2 = (eY-sY)/4;
		RtInf.iLineColor = WHITE;
		RtInf.iForeColor = iLampColor;
		RectAngleOut(sX+r1, sY+r2, eX-r1, eY-r2, &RtInf);
		break;
	case 5:
	case 6:
	case 7:
	case 8: /* 3,4�� ���� */
		if(iLampNumber<7)  
			/* 3�� SHAPE: frame color�� �簢�� �׵θ� �׸���, �簢�� ���θ� ���������� ä�� */
			RtInf.iForeColor = BLACK;
		else /* 4�� SHAPE: �簢�� ���θ� ������� ä�� */
			RtInf.iForeColor = WHITE;
		RectAngleOut(sX, sY, eX, eY, &RtInf);
		
		/* �ʺ� Ȧ���̸� ¦�����ǵ��� ���� : �ʺ��� ���� ��Ʈ���� Ȧ���� �ǵ��� ���� */
		width = eX-sX;
		if(width%2 != 0) {
			width--;
			eX--;
		}
		/* ���̰� Ȧ���̸� ¦�����ǵ��� ���� : ������ ���� ��Ʈ���� Ȧ���� �ǵ��� ���� */
		height= eY-sY;
		if(height%2 != 0) {
			height--;
			eY--;
		}
		
		/* ���� �ʺ� �� ���� �Ϳ� �°� ���� �׷��� �簢 ���� ���� */
		if(width<height) {
			mid = (sY+eY)/2;
			sY  = mid - width/2;
			eY  = mid + width/2;
			r1  = width/6;
		}
		else {
			mid = (sX+eX)/2;
			sX = mid-height/2;
			eX = mid+height/2;
			r1 = height/6;
		}
		/* �ٱ��� �� �׸� : ���� = ���, ä��=������ */
		cirParam.iLineColor = WHITE;
		cirParam.iPattern   = PAT8;
		cirParam.iForeColor = BLACK;
		cirParam.iBackColor = BLACK;
		DrawCircle((sX+eX)/2, (sY+eY)/2, (eX-sX)/2, &cirParam);
		
		/*���� �� : ���� = ���, ä��= ������ */
		cirParam.iForeColor = iLampColor;
		DrawCircle((sX+eX)/2, (sY+eY)/2, (eX-sX)/2-r1, &cirParam);
		break;
	case 9:
	case 10:/* 5�� ���� */
		/* frame color�� �簢�� �׵θ� �׸���, �������� ���� ä�� */
		RtInf.iForeColor = BLACK;
		RectAngleOut(sX, sY, eX, eY, &RtInf);

		mid   = (sY+eY)/2;
		width = eX - sX;
		height= eY - sY;
		r1 = (width)/4;
		r2 = (height)/4;
		
		/* Draw  --|  |--- 	*/
		LineOut(sX, mid, sX+r1, mid, &lnWhite);
		LineOut(eX, mid, eX-r1, mid, &lnWhite);
		LineOut(sX+r1, sY+r2, sX+r1, eY-r2, &lnWhite);
		LineOut(eX-r1, sY+r2, eX-r1, eY-r2, &lnWhite);
		
		/* Draw inner rectangle filled with lamp color */
		r1 = (width*3)/8;
		r2 = (height)/4;
		sX += r1;
		eX -= r1;
		sY += r2;
		eY -= r2;
		RtInf.iLineColor = iLampColor;
		RtInf.iForeColor = iLampColor;
		RtInf.iBackColor = BLACK;
		RectAngleOut(sX, sY, eX, eY, &RtInf);
		break;
	case 11:
	case 12:/* 6�� ���� */
		/* frame color�� �簢�� �׵θ� �׸���, ������� ���� ä�� */
		RtInf.iForeColor = WHITE;
		RectAngleOut(sX, sY, eX, eY, &RtInf);

		mid   = (sY+eY)/2;
		width = eX - sX;
		height= eY - sY;
		r1 = (width)/4;
		r2 = (height)/4;
		
		/* Draw  --|  |--- 	*/
		LineOut(sX, mid, sX+r1, mid, &lnBlack);
		LineOut(eX, mid, eX-r1, mid, &lnBlack);
		LineOut(sX+r1, sY+r2, sX+r1, eY-r2, &lnBlack);
		LineOut(eX-r1, sY+r2, eX-r1, eY-r2, &lnBlack);
		
		/* Draw inner rectangle filled with lamp color */
		r1 = (width*3)/8;
		r2 = (height)/4;
		sX += r1;
		eX -= r1;
		sY += r2;
		eY -= r2;
		RtInf.iLineColor = iLampColor;
		RtInf.iForeColor = iLampColor;
		RtInf.iBackColor = BLACK;
		RectAngleOut(sX, sY, eX, eY, &RtInf);
		break;
	case 13:
	case 14:/* 7�� ���� */
		/* frame color�� �簢�� �׵θ� �׸���, �簢�� ���θ� ���������� ä�� */
		RtInf.iForeColor = BLACK;
		RectAngleOut(sX, sY, eX, eY, &RtInf);

		r1 = (eX-sX)/4;
		r2 = (eY-sY)/4;
		sX += r1;
		eX -= r1;
		sY += r2;
		eY -= r2;
		/* ���� �簢���� ���� 4�� �׸� */
		RtInf.iForeColor = iLampColor;
		RtInf.iPattern = PAT4;
		RectAngleOut(sX, sY, eX, eY, &RtInf);
		break;
	case 15:
	case 16:
	case 17:
	case 18:/* 8,9�� ���� : DIAMOND */
		if(iLampNumber<17)  /* 8�� SHAPE: frame color�� �簢�� �׵θ� �׸���, �簢�� ���θ� ���������� ä�� */
			RtInf.iForeColor = BLACK;
		else /* 9�� SHAPE: �簢�� ���θ� ������� ä�� */
			RtInf.iForeColor = WHITE;
		RectAngleOut(sX, sY, eX, eY, &RtInf);
		
		/* �ʺ� Ȧ���̸� ¦�����ǵ��� ���� : �ʺ��� ���� ��Ʈ���� Ȧ���� �ǵ��� ���� */
		width = eX-sX;
		if(width%2 != 0) {
			width--;
			eX--;
		}
		/* ���̰� Ȧ���̸� ¦�����ǵ��� ���� : ������ ���� ��Ʈ���� Ȧ���� �ǵ��� ���� */
		height= eY-sY;
		if(height%2 != 0) {
			height--;
			eY--;
		}
		
		/* ���� �ʺ� �� ���� �Ϳ� �°� �׷��� �簢 ���� ���� */
		if(width<height) {
			mid = (sY+eY)/2;
			sY  = mid - width/2;
			eY  = mid + width/2;
		}
		else {
			mid = (sX+eX)/2;
			sX = mid-height/2;
			eX = mid+height/2;
		}
		cx = (sX+eX)/2;
		cy = sY+1;
		ax = sX+1;
		by = ay = (sY+eY)/2;
		bx = eX-1;
		
		if(iLampNumber<17) {
			DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,iLampColor,5);
			cy = eY-1;
			DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,iLampColor,6); 
		}
		else {
			DrawTriangleJS(ax,ay,bx,by,cx,cy,BLACK,iLampColor,5);
			cy = eY-1;
			DrawTriangleJS(ax,ay,bx,by,cx,cy,BLACK,iLampColor,6);
		} 
/*		if(iLampColor == WHITE)
			LineOut(ax+1, ay, bx-1, by, &lnWhite);
		else
			LineOut(ax+1, ay, bx-1, by, &lnBlack); 
*/
		break;
	case 19:
	case 20:/* 10�� shape: �� */
		/* frame color�� �簢�� �׵θ� �׸���, �簢�� ���������� ���θ� ä�� */
		RtInf.iForeColor = BLACK;
		RectAngleOut(sX, sY, eX, eY, &RtInf);
		
		/* �ﰢ���� �׷��� ������ �ʺ�/���� ��� */
		width  = eX-sX-4;
		height = eY-sY-4;

		if(height/2<width) { /* ������ ���ݺ��� �ʺ� Ŭ �� */
			/* �ﰢ���� ������ ��ǥ��� */
			cx = (2*(sX+eX) + height)/4; /* (cx,cy) ������ ������ ��ǥ */
			cy = (sY+eY)/2;
			ax = cx - height/2;
			ay = cy	- height/2;
			bx = cx - height/2;
			by = cy	+ height/2;
			if(ax<=sX+2) {
				ax++; bx++; cx++;
			}
		}
		else {
			z=(width*5)/6;
			cx = (sX+eX+z)/2;
			cy = (sY+eY)/2;
			ax = cx - z;
			ay = cy	- z;
			bx = cx - z;
			by = cy	+ z;
		}
		/* �ﰢ���׸�: �ܰ���=���, ä��=������ */
		DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,iLampColor,1);
		break;

	case 21:
	case 22:/* 11�� shape: �� (10�� shape ����) */
		RtInf.iForeColor = BLACK;
		RectAngleOut(sX, sY, eX, eY, &RtInf);
		
		width  = eX-sX-4;
		height = eY-sY-4;
		if(height/2<width) {
			cx = (2*(sX+eX) - height)/4;
			cy = (sY+eY)/2;
			ax = cx + height/2;
			ay = cy	- height/2;
			bx = cx + height/2;
			by = cy	+ height/2;
			if(ax<=sX+2) {
				ax++; bx++; cx++;
			}
		}
		else {
			z=(width*5)/6;
			cx = (sX+eX-z)/2;
			cy = (sY+eY)/2;
			ax = cx + z;
			ay = cy	- z;
			bx = cx + z;
			by = cy	+ z;
		}
		DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,iLampColor,2);
		break;
	case 23:
	case 24:/* 12�� shape: �� (10�� shape ����) */
		RtInf.iForeColor = BLACK;
		RectAngleOut(sX, sY, eX, eY, &RtInf);

		width  = eX-sX-4;
		height = eY-sY-4;
		if(width/2<height) {
			cx = (sX+eX)/2;
			cy = (2*(sY+eY) - width)/4;
			ax = cx - width/2;
			ay = cy	+ width/2;
			bx = cx + width/2;
			by = cy	+ width/2;
			if(ay>=eY-2) {
				ax--; bx--; cx--;
			}
		}
		else {
			z=(height*5)/6;
			cx = (sX+eX)/2;
			cy = (sY+eY-z)/2;
			ax = cx - z;
			ay = cy	+ z;
			bx = cx + z;
			by = cy	+ z;
		}
		DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,iLampColor,3);
		break;
	case 25:
	case 26:/* 13�� shape:�� (10�� shape ����) */
		RtInf.iForeColor = BLACK;
		RectAngleOut(sX, sY, eX, eY, &RtInf);

		width  = eX-sX-4;
		height = eY-sY-4;
		if(width/2<height) {
			cx = (sX+eX)/2;
			cy = (2*(sY+eY) + width)/4;
			ax = cx - width/2;
			ay = cy	- width/2;
			bx = cx + width/2;
			by = cy	- width/2;
			if(ay<=sY+2) {
				ay++; by++; cy++;
			}
		}
		else {
			z=(height*5)/6;
			cx = (sX+eX)/2;
			cy = (sY+eY-z)/2;
			ax = cx - z;
			ay = cy	+ z;
			bx = cx + z;
			by = cy	+ z;
		}
		DrawTriangleJS(ax,ay,bx,by,cx,cy,WHITE,iLampColor,4);
		break;

	default:
		if(Flag == OFF)
			RtInf.iForeColor = BLACK;
		else
			RtInf.iForeColor = WHITE;
		RectAngleOut(sX, sY, eX, eY, &RtInf);
		break;
	}
}

void DrawTriangle(short x1,short y1,short x2,short y2,short x3,short y3,short LineColor,short FarmeColor,short	iType)
{
	short				i;
	short				iCnt;
	unsigned char*		xyBuff;
	_LINE_INFO			param;

	param.iLineColor = LineColor;
	param.iLineStyle = SOLID_LINE;
	xyBuff = (unsigned char*)TakeMemory(512);
	memset(xyBuff,0x00,512);
	if(LineColor == FarmeColor){
		iCnt = y3-y1;
		if(iType==0){
			CalcAddrLine(x2,y2,x3,y3,(char*)xyBuff);
			for(i=0;i<=iCnt;i++){	/* ���� */
				LineOut(x1, y1+i, (int)(xyBuff[i*2]),(int) xyBuff[(i*2)+1], &param);		
			}
		}else if(iType==1){
			CalcAddrLine(x1,y1,x3,y3,(char*)xyBuff);
			for(i=0;i<=iCnt;i++){	/* ��� */
				LineOut((int) xyBuff[i*2],(int) xyBuff[(i*2)+1],x2,y2+i, &param);		
			}
		}else if(iType==2){
			CalcAddrLine(x3,y3,x1,y1,(char*)xyBuff);
			for(i=0;i<=iCnt;i++){	/* ���� */
				LineOut(x2, y2-i, (int) xyBuff[i*2],(int) xyBuff[(i*2)+1], &param);		
			}
		}else if(iType==3){
			CalcAddrLine(x2,y2,x1,y1,(char*)xyBuff);
			for(i=0;i<=iCnt;i++){	/* �Ͽ� */
				LineOut((int) xyBuff[i*2],(int) xyBuff[(i*2)+1],x3,y3-i, &param);		
			}
		}
	}else{
		LineOut(x1, y1, x2, y2, &param);	
		LineOut(x2, y2, x3, y3, &param);
		LineOut(x1, y1, x3, y3, &param);

		/*
		LineOut(x1+20, y1, x2+20, y2, &param);	
		LineOut(x2+20, y2, x3+20, y3, &param);
		LineOut(x1+20, y1, x3+20, y3, &param);
		*/

		param.iLineColor = FarmeColor;
		iCnt = y3-y1-2;
		if(iType==0){
			CalcAddrLine(x2-2,y2+1,x3+1,y3-2,(char*)xyBuff);
			for(i=0;i<iCnt;i++){	/* ���� */
/*				LineOut(x1+1, y1+1+i, x2-i-2, y2+i+1, &param);		*/
				LineOut(x1+1, y1+i+1, (int)(xyBuff[i*2]),(int) xyBuff[(i*2)+1], &param);		
			}
		}else if(iType==1){
			CalcAddrLine(x1+2,y1+1,x3-1,y3-2,(char*)xyBuff);
			for(i=0;i<iCnt;i++){	/* ��� */
/*				LineOut(x1+i+2, y1+i+1, x2-1, y2+i+1, &param);		*/
				LineOut((int) xyBuff[i*2],(int) xyBuff[(i*2)+1],x2-1,y2+i+1, &param);		
			}
		}else if(iType==2){
			CalcAddrLine(x3-2,y3-1,x1+1,y1+2,(char*)xyBuff);
			for(i=0;i<iCnt;i++){	/* ���� */
/*				LineOut(x2+1, y2-1-i, x3-i-2, y3-i-1, &param);		*/
				LineOut(x2+1, y2-i-1, (int) xyBuff[i*2],(int) xyBuff[(i*2)+1], &param);		
			}
		}else if(iType==3){
			CalcAddrLine(x2+2,y2-1,x1-1,y1+2,(char*)xyBuff);
			for(i=0;i<iCnt;i++){	/* �Ͽ� */
/*				LineOut(x2+i+2, y2-i-1, x3-1, y3-1-i, &param);		*/
				LineOut((int) xyBuff[i*2],(int) xyBuff[(i*2)+1],x3-1,y3-i-1, &param);		
			}
		}
	}
	FreeMail((char*)xyBuff);
}
int	CheckStartKanji(unsigned char *buff,int cnt)
{
	int		i;
	int		flag;

	flag = 0;
	for(i= 0; i < cnt; i++){
		if(buff[i] & 0x80){		/* Kanji Code */
			if(flag == 0){		/* First Byte */
				flag = 1;
			}else{
				flag = 0;
			}
		}
	}
	if(flag == 1){
		return(NG);
	}else{
		return(OK);
	}
}
/********************************************************************************/
/* �� �� �� : vTextPositionDisp													*/
/* ��    �� : MultiText�� ���� ���÷��� �ϴ� �Լ�.							*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 29�� (��)												*/
/* �� �� �� :  																	*/
/* ��    �� : 																	*/
/********************************************************************************/
void vTextPositionDisp(int *PointsX, int *PointsY, int *PointeX, int *PointeY, char * cDispData,int xbai,int ybai, int iColor, int iType)
{
	volatile	short	sX;
	volatile	short	sY;
	volatile	short	eX;
	volatile	short	eY;
	short	CenterX;
	short	StartY;
	short	iLen;
	short	iDisplayLen;
	short	iCheckData;
	short	iDotX;
	short	iDotY;
	short	PointX;
	short	PointY;
	short	iCnt;
	short	i;
//	short	Back_Color;
	unsigned long	Back_Color;
	short	T_Type;
	short	iDataCen;
	short	iMex;
	char*	cTextBuffer[10];
	char*	LineData;
	char*	cDispBuffer;
	short	iMaxLen;

	int		Gamen_MaxX,Gamen_MaxY;			/* 060926 */
	
	sX = *PointsX;
	sY = *PointsY;
	eX = *PointeX;
	eY = *PointeY;

	if(TateYoko == 0)
	{
		iMaxLen = (GAMEN_Y_SIZE-1);
		Gamen_MaxX= GAMEN_X_SIZE;		/* 60926 */
		Gamen_MaxY= GAMEN_Y_SIZE;		/* 60926 */
	}else
	{
		iMaxLen = GAMEN_X_SIZE-1;
		Gamen_MaxX= GAMEN_Y_SIZE;		/* 60926 */
		Gamen_MaxY= GAMEN_X_SIZE;		/* 60926 */
	}

	PointX		= 0;
	PointY		= 0;
	Back_Color	= 0;
	T_Type		= 0;
	iMex		= 0;

	iLen = (strlen(cDispData)+1);
	cDispBuffer = (char *)TakeMemory(iLen);
	memset(cDispBuffer,0x00,iLen);
	strncpy(cDispBuffer,cDispData,strlen(cDispData));	
	iCnt = 0;
	for(i=0;i<10;i++)	
	{
		LineData = strchr(cDispBuffer,0x0D);
		if(((int)LineData)==0x00)
		{
			iLen = strlen(cDispBuffer);
			if(iLen > iMex)
				iMex = iLen;
			iLen++;
			cTextBuffer[i] = (char *)TakeMemory((iLen));
			memset(cTextBuffer[i],0x00,(iLen));
			strcpy(cTextBuffer[i],cDispBuffer);
			iLen--;
			iCnt++;			/* 040605 */
			break;
		}
		iLen = (int)(LineData-cDispBuffer);
		if(iLen > iMex)
			iMex = iLen;
		iLen++;
		cTextBuffer[i] = (char *)TakeMemory((iLen));
		memset(cTextBuffer[i],0x00,(iLen));
		iLen--;
		strncpy(cTextBuffer[i],cDispBuffer,iLen);

		strcpy(cDispBuffer,LineData+2);

		iCnt++;
	}

	if(ybai==0 && xbai==0)			/* �̿��� ��Ʈ	*/
	{
		iDotY = 8;
		iDotX = 6;
	}
	else				/* 6x8 Dot		*/
	{
		if(ybai !=0 )
		{
			iDotY = ybai * 16;
			iDotX = xbai * 8;
		}
		else			/* 0.5 x 1      */
		{
			iDotY = 8;
			iDotX = 8;
		}
	}
	switch(iType)
	{
		case 1:				/*  OverTop		*/
			StartY = sY - (iCnt*iDotY);
			break;
		case 2:				/*  Top			*/
			StartY = sY;
			break;
		case 3:				/*  OverBotton	*/
			StartY = eY+1;
			break;
		case 4:				/*  Botton		*/
			StartY = eY - (iCnt*iDotY)+1;
			break;
		case 5:				/*  Center		*/
			StartY = (int)((float)(sY+eY+1)/2+0.5);
			StartY = StartY - ((iDotY*iCnt)/2);
			break;  
	}

	if(iColor == 0)
	{
		Back_Color	= WHITE;	
		T_Type		= T_FRONT ; 
	}else
	{
		Back_Color = BLACK;
		T_Type      = T_OR;
/*		T_Type      = T_XOR;*/
	}
	CenterX = (int)((float)(sX+eX+1)/2+0.5);
	for(i=0;i<iCnt;i++)
	{
		iLen	= strlen(cTextBuffer[i]);
		iDataCen = ((iLen * iDotX)/2);
		PointX = CenterX - iDataCen;
		PointY = StartY+(i*iDotY);
		if(!(PointY < 0 || (PointY+iDotY-1) > iMaxLen))
			if(iType == 1 || iType == 3)
				DotTextOut(PointX, PointY, cTextBuffer[i], xbai, ybai, T_Type, iColor, Back_Color);
			else if(!(PointY < sY || (PointY+iDotY) > eY+1))
			{
				iDisplayLen = (eX-sX+1)/iDotX;
				if(iLen > iDisplayLen)
				{
					iCheckData = (eX-sX+1)%iDotX;
					if((iLen%2==0 && iDisplayLen%2==1) && iDisplayLen > 0 && iCheckData < iDotX-1)
						iDisplayLen--;
					else if((iLen%2==1 && iDisplayLen%2==0) && iDisplayLen > 0 && iCheckData < iDotX-1)
						iDisplayLen--;
					iLen = (iLen-iDisplayLen)/2;
					memset(cDispBuffer,0x00,strlen(cDispBuffer));
					memcpy(cDispBuffer,cTextBuffer[i]+iLen,iDisplayLen);
/* V202 Edit 060120 */
					if(CheckStartKanji((unsigned char *)cTextBuffer[i],iLen)== NG){
						cDispBuffer[0]= ' ';
					}
					if(CheckStartKanji((unsigned char *)cDispBuffer,iDisplayLen)== NG){
						cDispBuffer[iDisplayLen-1]= ' ';
					}
					DotTextOut(PointX+(iLen*iDotX), PointY, cDispBuffer, xbai, ybai, T_Type, iColor, Back_Color);
/********************/
					DotTextOut(PointX+(iLen*iDotX), PointY, cDispBuffer, xbai, ybai, T_Type, iColor, Back_Color);

				}else
					DotTextOut(PointX, PointY, cTextBuffer[i], xbai, ybai, T_Type, iColor, Back_Color);
			}
	}
	if(iType == 1)							/* Over Top */
	{
		if((iMex*iDotX)/2 > CenterX)		/* Ŭ���� �� ��쿡 ���� ���� ����. */
			*PointsX = 0;
		else
		{
//			if(*PointsX > (CenterX - ((iLen*iDotX)/2)))		/* 2009.05.26 Del */
//				*PointsX = CenterX - ((iLen*iDotX)/2);		/* 2009.05.26 Del */
			if(*PointsX > (CenterX - ((iMex*iDotX)/2)))		/* 2009.05.26 Add */
				*PointsX = CenterX - ((iMex*iDotX)/2);		/* 2009.05.26 Add */
		}

		if(StartY >= 0)
			*PointsY = StartY;
		else 
			*PointsY = 0;

/* 060926 
		if((((iMex*iDotX)/2) + CenterX) < GAMEN_X_SIZE-1){
			if(*PointeX < (((iMex*iDotX)/2) + CenterX))
				*PointeX = ((iMex*iDotX)/2) + CenterX;
		}else
			*PointeX = GAMEN_X_SIZE-1;
*/
		if((((iMex*iDotX)/2) + CenterX) < Gamen_MaxX-1){
			if(*PointeX < (((iMex*iDotX)/2) + CenterX))
				*PointeX = ((iMex*iDotX)/2) + CenterX;
		}else
			*PointeX = Gamen_MaxX-1;

		/*		*PointeY = eY;	*/

	}else if(iType == 3)					/* Over Botton */
	{
		if((iMex*iDotX)/2 > CenterX)		/* Ŭ���� �� ��쿡 ���� ���� ����. */
			*PointsX = 0;
		else
			if(*PointsX > (CenterX - ((iMex*iDotX)/2)))
				*PointsX = CenterX - ((iMex*iDotX)/2);
		
		/* *PointsY = sY; */

/* 060926
		if((((iMex*iDotX)/2) + CenterX) < GAMEN_X_SIZE-1)
			if(*PointeX < ((iMex*iDotX)/2) + CenterX)
				*PointeX = ((iMex*iDotX)/2) + CenterX;
		else
			*PointeX = GAMEN_X_SIZE-1;
		if(StartY+(iCnt*iDotY) >= (GAMEN_Y_SIZE-1))
			*PointeY = (GAMEN_Y_SIZE-1);
		else
			*PointeY = StartY+(iCnt*iDotY);
*/
		if((((iMex*iDotX)/2) + CenterX) < Gamen_MaxX-1)
			if(*PointeX < ((iMex*iDotX)/2) + CenterX)
				*PointeX = ((iMex*iDotX)/2) + CenterX;
		else
			*PointeX = Gamen_MaxX-1;
		if(StartY+(iCnt*iDotY) >= (Gamen_MaxY-1))
			*PointeY = (Gamen_MaxY-1);
		else
			*PointeY = StartY+(iCnt*iDotY);
	}
	for(i=0;i<iCnt;i++)
		FreeMail((char *)cTextBuffer[i]);
	FreeMail((char *)cDispBuffer);
}
