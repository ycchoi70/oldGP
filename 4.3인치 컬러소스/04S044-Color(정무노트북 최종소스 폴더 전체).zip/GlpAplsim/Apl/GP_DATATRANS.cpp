/* ****************************************************************************** */
/*  �� �� �� : GP_DATATRANS.CPP													 */
/*  ��    �� : PC ���� ó��														 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

#ifdef	SIZE_2480		/* 20080822	4.4��ġ GP�� 5.7��ġ GP�� �ý��� ȭ�� �ҽ��� �ٸ��� ������ */
/* *******************************************************************************/
/*  �� �� �� : vDataTrans()														 */
/*  ��    �� : PC �۽�															 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 2�� 15�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
void		vDataTrans(int* iScreenNo){

	int					iKeyCode;
	short				iDisplayNo;
	short				iKeyFlag;
	_RECTANGLE_INFO		RECParam;
	_LINE_INFO			param;
	_LINE_INFO			param1;
	int					pUpDownMode;				/* 2009.05.26 */
	
	pUpDownMode= CommonArea.PcUpDownMode;		/* 2009.05.26 */
	iKeyFlag = 1;
	while ( *iScreenNo == DATA_TRANSFER_NUM || *iScreenNo == DOWN_TRANS || *iScreenNo == UP_TRANS) {
		iKeyCode = -1;

		param.iLineColor	= WHITE;
		param1.iLineColor	= WHITE;
		param.iLineStyle	= SOLID_LINE;		/* DOTTED_LINE */

		RECParam.iLineStyle = SOLID_LINE;
		RECParam.iLineColor = WHITE;
		RECParam.iPattern	= PAT0;
		RECParam.iForeColor = BLACK;
		RECParam.iBackColor = BLACK;

		if((*iScreenNo == DOWN_TRANS) || (*iScreenNo == UP_TRANS)){
//			Delay(200);
			NormalBuzzer();				/*	Buzzer  */
			iTransFlag		= 0;
			iUserScreenFlag = 0;
			if(*iScreenNo == DOWN_TRANS)
				iFirstScreen = 1;
		}else{
			iTransFlag = 1;
		}

		RectAngleOut(GAMEN_START_X+1,GAMEN_START_Y+24,GAMEN_START_X+120,GAMEN_START_Y+78,&RECParam);
		RectAngleOut(GAMEN_START_X+160,GAMEN_START_Y+25,GAMEN_START_X+200,GAMEN_START_Y+47,&RECParam);
		RectAngleOut(GAMEN_START_X+160,GAMEN_START_Y+58,GAMEN_START_X+200,GAMEN_START_Y+77,&RECParam);
		LineOut( GAMEN_START_X+2, GAMEN_START_Y+50, GAMEN_START_X+120, GAMEN_START_Y+50, &param );
		LineOut( GAMEN_START_X+153, GAMEN_START_Y+30, GAMEN_START_X+158, GAMEN_START_Y+35, &param);			/* PC --> GP ȭ��ǥ */
		LineOut( GAMEN_START_X+153, GAMEN_START_Y+40, GAMEN_START_X+158, GAMEN_START_Y+35, &param);			/* PC --> GP ȭ��ǥ */
		LineOut( GAMEN_START_X+203, GAMEN_START_Y+68, GAMEN_START_X+208, GAMEN_START_Y+63, &param);			/* GP --> PC ȭ��ǥ */
		LineOut( GAMEN_START_X+203, GAMEN_START_Y+68, GAMEN_START_X+208, GAMEN_START_Y+73, &param);			/* GP --> PC ȭ��ǥ */

		if(*iScreenNo == DOWN_TRANS){				/* DOWNLOADING...*/
			param.iLineStyle	= SOLID_LINE;		/* SOLID_LINE */
			param1.iLineStyle	= DOTTED_LINE;		/* DOTTED_LINE */
			iDisplayNo = 2;

			DeviceMonitorBuffClear(0,BUFF_DISP_CNT);  /* 20090703 */ /* ����̽� ����͸� ȭ���ʱ�ȭ ������ ���۸� �������. */

			iOverFlagNum = 0;
			AreaClear(GAMEN_START_X+2,GAMEN_START_Y+51,GAMEN_START_X+119,GAMEN_START_Y+77,0);

		}else if(*iScreenNo == UP_TRANS){			/* UPLOADING...*/
			param.iLineStyle	= DOTTED_LINE;		/* DOTTED_LINE */
			param1.iLineStyle	= SOLID_LINE;		/* SOLID_LINE */
			iDisplayNo = 3;
			iOverFlagNum = 0;
			AreaClear(GAMEN_START_X+2,GAMEN_START_Y+51,GAMEN_START_X+119,GAMEN_START_Y+77,0);
		}else{										/* WAITING...  */
			param.iLineStyle	= DOTTED_LINE;		/* DOTTED_LINE */
			param1.iLineStyle	= DOTTED_LINE;		/* DOTTED_LINE */
			iDisplayNo = 1;
			AreaClear(GAMEN_START_X+2,GAMEN_START_Y+51,GAMEN_START_X+119,GAMEN_START_Y+77,0);
		}

		LineOut( GAMEN_START_X+137, GAMEN_START_Y+35, GAMEN_START_X+158, GAMEN_START_Y+35, &param );		/* PC --> GP */
		LineOut( GAMEN_START_X+137, GAMEN_START_Y+36, GAMEN_START_X+137, GAMEN_START_Y+67, &param );
		LineOut( GAMEN_START_X+137, GAMEN_START_Y+68, GAMEN_START_X+158, GAMEN_START_Y+68, &param );

		LineOut( GAMEN_START_X+203, GAMEN_START_Y+35, GAMEN_START_X+224, GAMEN_START_Y+35, &param1 );		/* GP --> PC */
		LineOut( GAMEN_START_X+224, GAMEN_START_Y+36, GAMEN_START_X+224, GAMEN_START_Y+67, &param1 );
		LineOut( GAMEN_START_X+203, GAMEN_START_Y+68, GAMEN_START_X+224, GAMEN_START_Y+68, &param1 );

		CenterDisplay(GAMEN_START_X+160,GAMEN_START_Y+29,GAMEN_START_X+200,GAMEN_START_Y+47,Dspname[DATA_TRANSFER].chName[Set.iLang][6]);
		CenterDisplay(GAMEN_START_X+160,GAMEN_START_Y+60,GAMEN_START_X+200,GAMEN_START_Y+77,Dspname[DATA_TRANSFER].chName[Set.iLang][7]);
		CenterDisplay(GAMEN_START_X+1,GAMEN_START_Y+29,GAMEN_START_X+120, GAMEN_START_Y+50,Dspname[DATA_TRANSFER].chName[Set.iLang][0]);

		CenterDisplay(GAMEN_START_X+1,GAMEN_START_Y+57,GAMEN_START_X+120, GAMEN_START_Y+50,Dspname[DATA_TRANSFER].chName[Set.iLang][iDisplayNo]);

		if(*iScreenNo == DOWN_TRANS){
			AreaRevers(GAMEN_START_X+160,GAMEN_START_Y+25,GAMEN_START_X+200,GAMEN_START_Y+47);
		}else if(*iScreenNo == UP_TRANS){
			AreaRevers(GAMEN_START_X+160,GAMEN_START_Y+58,GAMEN_START_X+200,GAMEN_START_Y+77);
		}

		DefaultFormDisplay(LINE_FORM,Dspname[DATA_TRANSFER].chTitle[Set.iLang]);
		DrawLcdBank1();

		while(iKeyCode == -1){
			iKeyCode = KeyWaitData(iKeyFlag,DATA_TRANSFER_NUM);							/* �Էµ� Ű���� �о��	 */
			iKeyFlag = 0;
			if(iKeyCode == PC_DNLOAD_START){			/* DownLoad	*/
				*iScreenNo = DOWN_TRANS;
				break;
			}else if(iKeyCode == PC_UPLOAD_START){		/* UPLoad	*/
				*iScreenNo = UP_TRANS;
				break;
			}else if (iKeyCode == PC_UPDOWN_END){
				NormalBuzzer();					/*	Buzzer  */
				*iScreenNo = CONFIG_NEXT;
			}else if(iKeyCode == PC_CONT){		/* Reverse Blink */
				AreaRevers(GAMEN_START_X+4,GAMEN_START_Y+53,GAMEN_START_X+117,GAMEN_START_Y+75);
				if(param.iLineColor == WHITE){
					param.iLineColor = BLACK;
					param1.iLineColor = BLACK;
				}else{
					param.iLineColor = WHITE;
					param1.iLineColor = WHITE;
				}
				param.iLineStyle	= SOLID_LINE;		/* DOTTED_LINE */
				if(iDisplayNo == 2){
																/* UPLOADING...*/
					LineOut( GAMEN_START_X+137, GAMEN_START_Y+35, GAMEN_START_X+158, GAMEN_START_Y+35, &param );		/* PC --> GP */
					LineOut( GAMEN_START_X+137, GAMEN_START_Y+36, GAMEN_START_X+137, GAMEN_START_Y+67, &param );
					LineOut( GAMEN_START_X+137, GAMEN_START_Y+68, GAMEN_START_X+158, GAMEN_START_Y+68, &param );
					LineOut( GAMEN_START_X+153, GAMEN_START_Y+30, GAMEN_START_X+158, GAMEN_START_Y+35, &param1);			/* PC --> GP ȭ��ǥ */
					LineOut( GAMEN_START_X+153, GAMEN_START_Y+40, GAMEN_START_X+158, GAMEN_START_Y+35, &param1);			/* PC --> GP ȭ��ǥ */
					AreaClear(GAMEN_START_X+203,GAMEN_START_Y+30,GAMEN_START_X+224,GAMEN_START_Y+73,0);					
				
				}else{	
															/* DOWNLOADING...*/
					LineOut( GAMEN_START_X+203, GAMEN_START_Y+35, GAMEN_START_X+224, GAMEN_START_Y+35, &param );		/* GP --> PC */
					LineOut( GAMEN_START_X+224, GAMEN_START_Y+36, GAMEN_START_X+224, GAMEN_START_Y+67, &param );
					LineOut( GAMEN_START_X+203, GAMEN_START_Y+68, GAMEN_START_X+224, GAMEN_START_Y+68, &param );
					LineOut( GAMEN_START_X+203, GAMEN_START_Y+68, GAMEN_START_X+208, GAMEN_START_Y+63, &param1);			/* GP --> PC ȭ��ǥ */
					LineOut( GAMEN_START_X+203, GAMEN_START_Y+68, GAMEN_START_X+208, GAMEN_START_Y+73, &param1);			/* GP --> PC ȭ��ǥ */
					AreaClear(GAMEN_START_X+137,GAMEN_START_Y+30,GAMEN_START_X+158,GAMEN_START_Y+73,0);
				}
				DrawLcdBank1();
				iKeyCode = -1;
/*-------------------------------------------------------------------------------------*/
			}else if((iKeyCode >= KEY_01 && iKeyCode <= KEY_02) && (CommonArea.PcUpDownMode == 0)){	/* Not Comm */
				*iScreenNo = USER_SCREEN_NUM;
				NormalBuzzer();					/*	Buzzer  */
			}else if((iKeyCode >= KEY_13 && iKeyCode <= KEY_15) && (CommonArea.PcUpDownMode == 0)){	/* Not Comm */
				*iScreenNo = SET_FUNTION_NUM;
				NormalBuzzer();					/*	Buzzer  */
/*-------------------------------------------------------------------------------------*/			
			}else{
				iKeyCode = -1;
			}
		}
	} /*  end while  */

//	if(Key.iCode == PC_DNLOAD_START){		/* ksc20090518 */
	if(pUpDownMode == 1){					/* 2009.05.26 */
		Key.iCode = PC_DNLOAD_END;
	}else{
//	if(Key.iCode == PC_UPLOAD_START){
		Key.iCode = PC_UPLOAD_END;
	}
/*	PC_UPLOAD_END	*/ /* ksc20090518 */
	return;
}

#endif
