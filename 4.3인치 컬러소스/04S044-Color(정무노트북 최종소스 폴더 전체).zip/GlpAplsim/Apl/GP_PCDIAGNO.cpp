/* ****************************************************************************** */
/*  �� �� �� : GP_PCDIAGNO.CPP													 */
/*  ��    �� : PLC ���� ó��														 */
/*  �� �� �� : 2002�� 2�� 15�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"
#ifdef	SIZE_2480

/* ****************************************************************************** */
/*  �Լ� ������ Ÿ�� ����														 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �Լ�																			 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �� �� �� : MemorySizeDisp()													 */
/*  ��    �� : �޸𸮾� ǥ��													 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 7�� 1�� (ȭ)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void		MemorySizeDisp(int* iScreenNo)
{
	int			iKeyCode;
	int			iTotalMemoryData;
	int			iUserMemoryData;
	int			iAvailableMemoryData;
	short		iKeyFlag;
	char		cDispMemory[10];


	iTotalMemoryData = MAX_MEMORY_SIZE;

	iKeyFlag = 1;
	memset(cDispMemory,0x00,sizeof(cDispMemory));
	ClearDispBuff(SCREEN_0);

/*ksc20040514 ��ġ ���� */
	DefaultFormDisplay(LINE_FORM,Dspname[MEMORY_SIZE].chTitle[Set.iLang]);
	DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+25,Dspname[MEMORY_SIZE].chName[Set.iLang][0],1,1, TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+43,Dspname[MEMORY_SIZE].chName[Set.iLang][1],1,1, TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+61,Dspname[MEMORY_SIZE].chName[Set.iLang][2],1,1, TRANS, T_WHITE, T_BLACK);
	
	iUserMemoryData = (int)((CheckUserArea())/2);
	iAvailableMemoryData = iTotalMemoryData - iUserMemoryData;

	sprintf(cDispMemory,"%3dKbyte",iTotalMemoryData);
	DotTextOut(GAMEN_START_X+164,GAMEN_START_Y+25,cDispMemory,1,1, TRANS, T_WHITE, T_BLACK);

	sprintf(cDispMemory,"%3dKbyte",iUserMemoryData);
	DotTextOut(GAMEN_START_X+164,GAMEN_START_Y+43,cDispMemory,1,1, TRANS, T_WHITE, T_BLACK);

	sprintf(cDispMemory,"%3dKbyte",iAvailableMemoryData);
	DotTextOut(GAMEN_START_X+164,GAMEN_START_Y+61,cDispMemory,1,1, TRANS, T_WHITE, T_BLACK);
/*ksc20040514 */

	DrawLcdBank1();
	while(*iScreenNo == MEMORY_SIZE_NUM)
	{
		iKeyCode = KeyWaitData(iKeyFlag,MEMORY_SIZE_NUM);							/* �Էµ� Ű���� �о��	 */
		iKeyFlag = 0;
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}
		/* Ű ���� ó�� */		
		if(iKeyCode >= KEY_01 && iKeyCode <= KEY_02 )
		{
			NormalBuzzer();				/*	Buzzer  */
			*iScreenNo = USER_SCREEN_NUM;
		}else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) 
		{									/*  END					 */
			NormalBuzzer();				/*	Buzzer  */
			*iScreenNo = DATA_VIEW_NUM;
		}
	}
}

#endif

#ifdef GP_S044

//20091222
void		vUwLatchSetDisp(int* iScreenNo)
{

	int		iKeyCode;	
	short	iKeyFlag;
	_RECTANGLE_INFO RECParam;

	iKeyCode = -1;

	DefaultFormDisplay(LINE_FORM,Dspname[UWLATCH].chTitle[Set.iLang]);


	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	iKeyFlag = 1;
	/* "Backup ON" */
//	DotTextOut(GAMEN_START_X+17,GAMEN_START_Y+NLine_3,(Dspname[UWLATCH].chName[Set.iLang][0]),1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+28,GAMEN_START_Y+NLine_3,(Dspname[UWLATCH].chName[Set.iLang][0]),1,1, NON_TRANS, T_WHITE, T_BLACK);

	/* "Backup OFF" */
//	DotTextOut(GAMEN_START_X+134,GAMEN_START_Y+NLine_3,(Dspname[UWLATCH].chName[Set.iLang][1]),1,1, NON_TRANS, T_WHITE, T_BLACK);
	DotTextOut(GAMEN_START_X+142,GAMEN_START_Y+NLine_3,(Dspname[UWLATCH].chName[Set.iLang][1]),1,1, NON_TRANS, T_WHITE, T_BLACK);
	RectAngleOut(GAMEN_START_X+11,GAMEN_START_Y+42,GAMEN_START_X+112,GAMEN_START_Y+59,&RECParam);					/* ������ NO					 */	
	RectAngleOut(GAMEN_START_X+127,GAMEN_START_Y+42,GAMEN_START_X+228,GAMEN_START_Y+59,&RECParam);					/* ������ OFF				 */	

	if ( Set.iuwLatch == 1 ) {
		AreaRevers(GAMEN_START_X+12,GAMEN_START_Y+43,GAMEN_START_X+111,GAMEN_START_Y+58); 
	} else {
		AreaRevers(GAMEN_START_X+128,GAMEN_START_Y+43,GAMEN_START_X+227,GAMEN_START_Y+58);
	}
	DrawLcdBank1();
	while (*iScreenNo == UWLATCH_NUM) 
	{
		iKeyCode = KeyWaitData(iKeyFlag,UWLATCH_NUM);							/* �Էµ� Ű���� �о��	 */
		iKeyFlag = 0;
		if ((iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) ||
			(iKeyCode >= KEY_32 && iKeyCode <= KEY_37 ) ||
			(iKeyCode >= KEY_39 && iKeyCode <= KEY_44 )) 
		{	
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
		}

		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}

		/* Ű ���� ó�� */		
		if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ) 
		{
			*iScreenNo = USER_SCREEN_NUM;
		}else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 )
		{		
			*iScreenNo = SET_ENVIRONMENT_NUM; 	/*  END				 */
		} else if (iKeyCode >= KEY_32 && iKeyCode <= KEY_37 ) {	
			if(Set.iuwLatch == 0)
			{
				Set.iuwLatch = 1;
				AreaRevers(GAMEN_START_X+12,GAMEN_START_Y+43,GAMEN_START_X+111,GAMEN_START_Y+58);
				AreaRevers(GAMEN_START_X+128,GAMEN_START_Y+43,GAMEN_START_X+227,GAMEN_START_Y+58);		
			}else{
				iKeyCode = -1;
			}
		} else if (iKeyCode >= KEY_39 && iKeyCode <= KEY_44 ) {	
			if(Set.iuwLatch == 1)
			{
				Set.iuwLatch = 0;
				AreaRevers(GAMEN_START_X+12,GAMEN_START_Y+43,GAMEN_START_X+111,GAMEN_START_Y+58);
				AreaRevers(GAMEN_START_X+128,GAMEN_START_Y+43,GAMEN_START_X+227,GAMEN_START_Y+58);		
			}else{
				iKeyCode = -1;
			}
		}else
			iKeyCode = -1;
		
		if(iKeyCode > 0)
			DrawLcdBank1();

	} 	
	if(iKeyCode > 0)
		mWriteSettei();
	return;

}


#endif

