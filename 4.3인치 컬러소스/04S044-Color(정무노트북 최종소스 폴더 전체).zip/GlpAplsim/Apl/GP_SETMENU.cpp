/* ****************************************************************************** */
/*  �� �� �� : GPSETMENU.CPP														 */
/*  ��    �� : ���� ���� �޴� ó��												 */
/*  �� �� �� : 2002�� 2�� 7�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */

#include	"sgt.h"

/* ****************************************************************************** */
/*  �Լ� ������ Ÿ�� ����														 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  ���� ���� ����																 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �Լ�																			 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �� �� �� : SelectMenu()														 */
/*  ��    �� : ����ó�� �޴�ȭ���� ���											 */
/*  ��    �� : iScreenNo(���� ȭ�� ��ȣ)										 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 6�� 27�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#ifdef	SIZE_2480
void	SelectMenu(int *iScreenNo){

	int		iKeyCode;
	int		iSetFlag ; 
	int		i;
	int		j;
	short	iKeyFlag;

/*ksc20040727*/ /* �ڸ�Ʈ �߰� */
	iKeyFlag	= 1;  /* iKeyFlag	= 1�϶� ���� ȭ���� ��������, 0�϶� ���� ȭ�� ��� ���� */
	iSetFlag	= 1;  /* up/down �� ǥ�� ���� ���� �÷��� */

	/*ksc20040727*/
	/**************************/
	RepeatInfo.EntryCnt = 2;
	RepeatInfo.RepeatNo[0][0] = (char)KEY_29;
	RepeatInfo.RepeatNo[0][1] = (char)KEY_30;
	RepeatInfo.RepeatNo[1][0] = (char)KEY_59;
	RepeatInfo.RepeatNo[1][1] = (char)KEY_60;
	/**************************/
	KerRepeatFlag = 1;	/* 040815 */
	while ( *iScreenNo == SELECT_MEMU_NUM ) {
		DefaultFormDisplay(4 , Dspname[SELECT_MEMU].chTitle[Set.iLang]);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */

		i = 0;
		iKeyCode = -1;
		while (iKeyCode == -1 || iKeyCode == 0) {
			if(iSetFlag == 1)
			{
				AreaClear(GAMEN_START_X+0,GAMEN_START_Y+23,GAMEN_START_X+197,GAMEN_START_Y+79,0);
				for(j=0;j<3;j++)
				{
					DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+(NLine_2+(j*18)),(Dspname[SELECT_MEMU].chName[Set.iLang][i+j]),1,1, TRANS, T_WHITE, T_BLACK);		
				}

#ifdef	GP_S044
				ScroolBarDisplay(4, i);
#endif
#ifdef	LP_S044
				ScroolBarDisplay(5, i);
#endif
				DrawLcdBank1();	
				iSetFlag = 0;
			}
			
			while(1)
			{
				/*  iKeyCode = KeyWait();  leesi 040612 */
				iKeyCode = iKeyReturn(SELECT_MEMU_NUM);

				if(iKeyFlag == 0 || iKeyCode == PC_DNLOAD_START || 
					iKeyCode == PC_UPLOAD_START || iKeyCode == 0)
					break;
			}
			iKeyFlag = 0;
#ifdef	LP_S044
			if(!((iKeyCode >= KEY_03 && iKeyCode <= KEY_12 ) ||
				 iKeyCode == KEY_44 || iKeyCode == KEY_45 ||
				 iKeyCode == 0))
#endif
#ifdef	GP_S044
			if(!((iKeyCode >= KEY_03 && iKeyCode <= KEY_12 ) ||
				 iKeyCode == KEY_44 || iKeyCode == KEY_45 ||
				 iKeyCode == 0))
#endif
			{
				iKeyFlag = 1;
				if(iKeyCode != PC_DNLOAD_START){	/* 051213 */
					NormalBuzzer();										/*	Buzzer			*/
				}
			}
			switch(iKeyCode){
			case PC_DNLOAD_START:	*iScreenNo = DOWN_TRANS;	break;	/* DownLoad	*/
			case PC_UPLOAD_START:	*iScreenNo = UP_TRANS;		break;	/* UPLoad	*/
#ifdef	LP_S044
			case KEY_28:  /* Gage UP ó  �� */ /************************************************************/
				if(i != 0){	i = 0;	iSetFlag= 1;	}
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
			case KEY_43:  /* Gage Midle?? �� */
				i= 1;
				iSetFlag= 1;
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
			case KEY_58:  /* Gage Down ������ */
				i= 2;
				iSetFlag= 1;
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
#endif
#ifdef	GP_S044
			case KEY_28:  /* Gage UP ó  �� */ /************************************************************/
				if(i != 0){	i = 0;	iSetFlag= 1;	}
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
			case KEY_43:  /* Gage Midle?? �� */
			case KEY_58:  /* Gage Down ������ */		/* ksc20091221 */
				i= 1;
				iSetFlag= 1;
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
#endif
			default:
				if ((iKeyCode >= KEY_01 && iKeyCode <= KEY_02) || 
					(iKeyCode >= KEY_13 && iKeyCode <= KEY_15) ) 
				{									/*  ����, ���� ��ưŬ���� */						
					*iScreenNo = USER_SCREEN_NUM;	
				} else if (iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ) 
				{
					*iScreenNo = MONITORING_NUM + 0 + i;										
				} else if (iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ) 
				{
					*iScreenNo = MONITORING_NUM + 1 + i;										
				} else if (iKeyCode >= KEY_46 && iKeyCode <= KEY_57 ) 
				{
					*iScreenNo = MONITORING_NUM + 2 + i;									
				} else if (iKeyCode >= KEY_59 && iKeyCode <= KEY_60 ) 
				{
	//				if(i != 1){
#ifdef	LP_S044
					if(i < 2){
#endif
#ifdef	GP_S044
					if(i < 1){
#endif
						i++;
						iSetFlag = 1;
	//					i = 1;												/*  Line Down	  */	
					}						
	/*ksc20040727*/ /* �������� */
					iKeyCode = -1;
					iKeyFlag = 0;
	/*ksc20040727*/
				} else if (iKeyCode >= KEY_29 && iKeyCode <= KEY_30 ) 
				{
	//				if(i != 0){
					if(i > 0){
						i--;
						iSetFlag = 1;
	//					i = 0;												/*  Line Up		  */	
					}						
	/*ksc20040727*/ /* �������� */
					iKeyCode = -1;
					iKeyFlag = 0;
	/*				KerRepeatFlag = 1;*/
	/*ksc20040727*/
				}else{
					iKeyCode = -1;
				} 
				break;
			}
		} 	
	} 
	KerRepeatFlag = 0;
	return;
}
#endif

