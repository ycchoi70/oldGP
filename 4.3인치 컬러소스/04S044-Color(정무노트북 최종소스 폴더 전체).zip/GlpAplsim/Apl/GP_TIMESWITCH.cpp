/* ****************************************************************************** */
/*  �� �� �� : GP_TIMESWITCH.CPP													 */
/*  ��    �� : PC ���� ó��														 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

#ifdef	SIZE_2480
/* ****************************************************************************** */
/*  �Լ�																			 */
/* ****************************************************************************** */
/* ****************************************************************************** */
/*  �� �� �� : vTimeSwitch()														 */
/*  ��    �� : Ÿ�� ����ġ ���� ���												 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void		vTimeSwitch(int* iScreenNo){
	
	while ( *iScreenNo == TIME_SWITCH_NUM ) {
		vTiemSwiDisp(iScreenNo);								/*  ó��ȭ�� ���			 */
	} /*  end while  */
	SwitchScrenSetting();
	return;
}
/* ****************************************************************************** */
/*  �� �� �� : vTiemSwiDisp()														 */
/*  ��    �� : PC ���� ȭ�� ���													 */
/*  ��    �� :																	 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void	vTiemSwiDisp(int* iScreenNo)
{	
	char	chDsp_buff[16];	
	int		iNum1;
	int		iNum2;
	int		i;
	int		j;
	short	x;
	short	iKeyFlag;
	int		iKeyCode;
	int		iStructNo;
	int		ivalue;
	int		DevInfo,TimeDevFlag;
	int		UsAddr;	
//	int		work,UsAddr,k;		/* 071102 */
	char	chChName[6];
	
	

	_RECTANGLE_INFO RECParam;
//	_LINE_INFO param;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

//	param.iLineColor	= WHITE;							/* Line Data Set		*/
//	param.iLineStyle	= SOLID_LINE;

	iKeyCode	= -1;
	iStructNo	= -1;
	ivalue		= 0;
	x = 1;
	iKeyFlag = 1;

	ClearDispBuff(SCREEN_0);								/*  ���÷��� ���� �ʱ�ȭ	 */

/* ksc20050805 Time Switch Device Display */
/*----------------------------------------------------------------------------------------*/
	if((unsigned char)CommonArea.SystemDev.TimeSwitch_DevName[0] > 0){
		ivalue= CommonArea.SystemDev.TimeSwitch_DevAdd;			/* Bin */
/*		TimeDevFlag= GetDevNamePLCAddr(0,(unsigned char *)CommonArea.SystemDev.TimeSwitch_DevName,chChName,&DevInfo,&ivalue);*/
		TimeDevFlag= GetDevName(0,(char *)CommonArea.SystemDev.TimeSwitch_DevName,chChName,&DevInfo);
	}else{
		TimeDevFlag= -1;
	}
/*----------------------------------------------------------------------------------------*/

	for(i=0;i<2;i++){
		for(j=0;j<4;j++){
			iNum1 = (j*60);
			iNum2 = (i*23);

			sprintf(chDsp_buff, "ACT%d",x);				
			DotTextOut(GAMEN_START_X+2+iNum1,GAMEN_START_Y+27+iNum2,chDsp_buff,1,0, NON_TRANS, T_WHITE, T_BLACK);
			
/*
			sprintf(chDsp_buff, "ACT %d",x);				
			DotTextOut(9+iNum1,26+iNum2,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);
*/
/*ksc20040514 �ð� ����ġ ����̽� ǥ�� */
			if(TimeDevFlag == 0){		/* Device OK */

				UsAddr= SetPLCUsrAddr(DevInfo,ivalue,Device2Index(0,chChName),0);
				ivalue++;

				if(strlen(chChName) == 2){
					sprintf(chDsp_buff,"%s",chChName);
					DotTextOut(GAMEN_START_X+2+ 40 +iNum1,GAMEN_START_Y+27+iNum2,chDsp_buff,1,0, NON_TRANS, T_WHITE, T_BLACK);
				}else{
					sprintf(chDsp_buff,"%s",chChName);
					DotTextOut(GAMEN_START_X+2+ 46 +iNum1,GAMEN_START_Y+27+iNum2,chDsp_buff,1,0, NON_TRANS, T_WHITE, T_BLACK);
				}
				sprintf(chDsp_buff,"%07X",UsAddr);
				DotTextOut(GAMEN_START_X+2+iNum1,GAMEN_START_Y+35+iNum2,chDsp_buff,1,0, NON_TRANS, T_WHITE, T_BLACK); 

			}else{

				DotTextOut(GAMEN_START_X+2+iNum1,GAMEN_START_Y+35+iNum2,"Device",1,0, NON_TRANS, T_WHITE, T_BLACK); 
			}
/*ksc20040514*/
			RectAngleOut(1+iNum1,24+iNum2,58+iNum1,44+iNum2,&RECParam);
			x++;
		}

	}
	DefaultFormDisplay(LINE_FORM,Dspname[TIME_SWITCH].chTitle[Set.iLang]);
	DrawLcdBank1();


	while (iKeyCode == -1) {
		iKeyCode = KeyWaitData(iKeyFlag,TIME_SWITCH_NUM);							/* �Էµ� Ű���� �о��	 */
		iKeyFlag = 0;
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			*iScreenNo = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			*iScreenNo = UP_TRANS;
			break;
		}
		memset(chChName, 0x00, sizeof(chChName));
		iStructNo = -1;
		/* Ű ���� ó�� */		
		if(iKeyCode >= KEY_01 && iKeyCode <= KEY_02 ){
			*iScreenNo = USER_SCREEN_NUM;
			iStructNo = -2;
		}else if(iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) {		/*  END				 */
			*iScreenNo = SET_FUNTION_NUM;
			iStructNo = -2;
		} else if (iKeyCode >= KEY_16 && iKeyCode <= KEY_19 ) {		/*  CH1				 */
			iStructNo = 0;

		} else if (iKeyCode >= KEY_20 && iKeyCode <= KEY_22 ) {		/*  CH2				 */
			iStructNo = 1;

		} else if (iKeyCode >= KEY_23 && iKeyCode <= KEY_26 ) {		/*  CH3				 */
			iStructNo = 2;

		} else if (iKeyCode >= KEY_27 && iKeyCode <= KEY_30 ) {		/*  CH4				 */
			iStructNo = 3;

		} else if (iKeyCode >= KEY_31 && iKeyCode <= KEY_34 ) {		/*  CH5				 */
			iStructNo = 4;

		} else if (iKeyCode >= KEY_35 && iKeyCode <= KEY_37 ) {		/*  CH6				 */
			iStructNo = 5;

		} else if (iKeyCode >= KEY_38 && iKeyCode <= KEY_41 ) {		/*  CH7				 */
			iStructNo = 6;

		} else if (iKeyCode >= KEY_42 && iKeyCode <= KEY_45 ) {		/*  CH8				 */
			iStructNo = 7;

		}else{
			iKeyCode = -1;
		}

		if(iStructNo!=-1)
		{
			iKeyFlag = 1;
			NormalBuzzer();	
			/*	Buzzer  */
		}
		sprintf(chChName, "ACT %d",iStructNo+1);
				
		if ( iKeyCode != -1 && iStructNo >= 0 ) {	
			ivalue = iTImeSwiRegist(chChName, iStructNo);
			if(ivalue == DOWN_TRANS || ivalue == UP_TRANS)
			{
				*iScreenNo = ivalue;
				break;
			}else if(ivalue == 1)
			{
				*iScreenNo = USER_SCREEN_NUM;
			}
			memset(chChName, 0, sizeof(chChName));
		} /*  end if */
		
	} /*  end while  */	

}
/* ****************************************************************************** */
/*  �� �� �� : iTImeSwiRegist(char chChNo)										 */
/*  ��    �� : ȭ�� ���ý� ó��													 */
/*  ��    �� : chChNo : ä�� ��ȣ												 */
/*  ��    �� : iEscFlag 0 : ESC ����												 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
int		iTImeSwiRegist(char *chChNo, int iStructNo)
{

	int		iEscFlag;
	int		i;
	char	chDsp_buff[5];

	iEscFlag = 1;
	while ( iEscFlag != 0 ) {
		vTImeSwiRegistDisp(chChNo, iStructNo);					/*  �ð� ��� ȭ�� ���		 */
		iEscFlag = iTImeSwiRegistSelect(iStructNo);		/*  ���� ó��				 */
		if(iEscFlag == DOWN_TRANS || iEscFlag == UP_TRANS || iEscFlag == 1)
		{
			break;
		}
	} /*  end while  */
	for(i=0;i<3;i++)				/* "??" �Էµ� ���� �������·� �ǵ���. */
	{
		VDateCall(chDsp_buff, i, iStructNo,0);
		if(strcmp(chDsp_buff,"??")==0)
		{
			VDateCall("", i, iStructNo,2);
		}
		VDateCall(chDsp_buff, i, iStructNo,1);
		if(strcmp(chDsp_buff,"??")==0)
		{
			VDateCall("", i, iStructNo,3);
		}
	}
	mWriteSettei();
	return iEscFlag;	
}

/* ****************************************************************************** */
/*  �� �� �� : vTImeSwiRegistDisp(char chChNo)									 */
/*  ��    �� : ȭ�� ���ý� ó��													 */
/*  ��    �� : chChNo : ä�� ��ȣ												 */
/*  ��    �� :																	 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
void		vTImeSwiRegistDisp(char *chChNo, int iStructNo)
{
	int				i;
	short			SumData;
	int				BitData;
	char			chDsp_buff[24];	
	char			chChName[15];
	_RECTANGLE_INFO RECParam;

	_LINE_INFO param;

	param.iLineColor	= WHITE;							/* Line Data Set		*/
	param.iLineStyle	= SOLID_LINE;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;
	/* leesi 3.20 */	
	ClearDispBuff(SCREEN_0);								/*  ���÷��� ���� �ʱ�ȭ	 */
	BitData = 1;
/*
	memset(chChName, 0x00, sizeof(chChName));
	if(Set.iLang == 1)
		sprintf(chChName,"[ %s ���� ]", chChNo);
	else
		sprintf(chChName,"[ SET %s  ]", chChNo);
*/
/*ksc20040517*/
	memset(chChName, 0x00, sizeof(chChName));
	if(Set.iLang == 1)
		sprintf(chChName,"[%s %s]", chChNo, (Dspname[TIME_SWITCH].chName[Set.iLang][9]));
	else
		sprintf(chChName,"[%s %s]", (Dspname[TIME_SWITCH].chName[Set.iLang][9]), chChNo);
/*ksc20040517*/

	AreaClear(0,0,GAMEN_X_SIZE-1,GAMEN_Y_SIZE-1,0);	
	/* Y 19���� 79���� ������ �ٽñ׸� */

	DefaultFormDisplay(LINE_FORM,chChName);
	
	for(i=0;i<7;i++)
	{
		SumData = i*34;
		CenterDisplay(GAMEN_START_X+2+SumData, GAMEN_START_Y+23, GAMEN_START_X+33+SumData, GAMEN_START_Y+40,(Dspname[TIME_SWITCH].chName[Set.iLang][i]));
		RectAngleOut(GAMEN_START_X+2+SumData,GAMEN_START_Y+22,GAMEN_START_X+33+SumData,GAMEN_START_Y+40,&RECParam);	
		LineOut(GAMEN_START_X+3+SumData, GAMEN_START_Y+39, GAMEN_START_X+32+SumData, GAMEN_START_Y+39, &param);
		LineOut(GAMEN_START_X+32+SumData,GAMEN_START_Y+23, GAMEN_START_X+32+SumData, GAMEN_START_Y+39, &param);

		if((Set._TIMESWITCH[iStructNo].iWeek & BitData) == BitData)
		{
			AreaRevers(GAMEN_START_X+3+SumData,GAMEN_START_Y+23,GAMEN_START_X+32+SumData,GAMEN_START_Y+39);
		}
		BitData = BitData<<1;
	}
	
	RectAngleOut(GAMEN_START_X+2,GAMEN_START_Y+42,GAMEN_START_X+119,GAMEN_START_Y+60,&RECParam);					/* START TIME BUTTON		*/
	LineOut(GAMEN_START_X+3, GAMEN_START_Y+59, GAMEN_START_X+118, GAMEN_START_Y+59, &param);
	LineOut(GAMEN_START_X+118,GAMEN_START_Y+43, GAMEN_START_X+118, GAMEN_START_Y+59, &param);

	RectAngleOut(GAMEN_START_X+2,GAMEN_START_Y+61,GAMEN_START_X+119,GAMEN_START_Y+79,&RECParam);					/* END TIME BUTTON			*/
	LineOut(GAMEN_START_X+3, GAMEN_START_Y+78, GAMEN_START_X+118, GAMEN_START_Y+78, &param);
	LineOut(GAMEN_START_X+118,GAMEN_START_Y+62, GAMEN_START_X+118, GAMEN_START_Y+78, &param);

	LineOut(GAMEN_START_X+120,GAMEN_START_Y+60, GAMEN_START_X+238, GAMEN_START_Y+60, &param);						/* Time Line				*/

	sprintf(chDsp_buff, Dspname[TIME_SWITCH].chName[Set.iLang][7]);	/* START TIME FONT */			
	DotTextOut(GAMEN_START_X+5,GAMEN_START_Y+NLine_3,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

	sprintf(chDsp_buff, Dspname[TIME_SWITCH].chName[Set.iLang][8]);	/* END TIME FONT */			
	DotTextOut(GAMEN_START_X+5,GAMEN_START_Y+62,chDsp_buff,1,1, NON_TRANS, T_WHITE, T_BLACK);

	/* �� �ð�����Ÿ�� ?? ����... */
	for(i=0;i<3;i++)
	{	
		VDateCall(chDsp_buff, i, iStructNo,0);
		if(strlen(chDsp_buff)==0)
		{
			VDateCall("??", i, iStructNo,2);
		}
		VDateCall(chDsp_buff, i, iStructNo,1);
		if(strlen(chDsp_buff)==0)
		{
			VDateCall("??", i, iStructNo,3);
		}
	}
	/* ------------------------------ */

	/*  START TIME ��ϵǾ��ִ� �ð� ��� */
	/*  Set._TIMESWICH[iStructNo].chStime�� �� */
	sprintf(chDsp_buff,"%2s:%2s:%2s",Set._TIMESWITCH[iStructNo].chSHour
									,Set._TIMESWITCH[iStructNo].chSMinute
									,Set._TIMESWITCH[iStructNo].chSSecond);
	DotTextOut(GAMEN_START_X+168,GAMEN_START_Y+NLine_3,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);

	/*  END TIME ��ϵǾ��ִ� �ð� ��� */
	/*  Set._TIMESWICH[iStructNo].chStime�� �� */
	sprintf(chDsp_buff,"%2s:%2s:%2s",Set._TIMESWITCH[iStructNo].chEHour
									,Set._TIMESWITCH[iStructNo].chEMinute
									,Set._TIMESWITCH[iStructNo].chESecond);
	DotTextOut(GAMEN_START_X+168,GAMEN_START_Y+63,chDsp_buff,1,1, TRANS, T_WHITE, T_BLACK);
	return;
}

/* *******************************************************************************/
/*  �� �� �� : iTImeSwiRegistSelect(char chChName)								 */
/*  ��    �� : ȭ�� ���ý� ó��													 */
/*  ��    �� : chChNo : ä�� ��ȣ(����� ä�� ����								 */
/*  ��    �� : iEscFlag 0 : ESC ����											 */
/*  �� �� �� : 2002�� 2�� 16�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
int iTImeSwiRegistSelect(int iStructNo)
{
	int iKeyCode = -1;
	int iEscFlag = 1;		
//	int iEntFlag = -1;
	short	iKeyFlag;
	char chKey[10];
	memset(chKey, 0x00, 10);
	iKeyFlag = 1;
	while (iKeyCode == -1) 
	{
		iKeyCode = KeyWaitData(iKeyFlag,50);							/* �Էµ� Ű���� �о��	 */
		iKeyFlag = 0;


/*ksc20040517*/		
		if((iKeyCode >= KEY_01 && iKeyCode <= KEY_02) ||
			(iKeyCode >= KEY_13 && iKeyCode <= KEY_30) ||
			(iKeyCode >= KEY_31 && iKeyCode <= KEY_37) ||
			(iKeyCode >= KEY_46 && iKeyCode <= KEY_52) ||
			(iKeyCode >= KEY_41 && iKeyCode <= KEY_44) ||
			(iKeyCode >= KEY_56 && iKeyCode <= KEY_59))
/*ksc20040517*/

		{
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
		}
		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			iEscFlag = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			iEscFlag = UP_TRANS;
			break;
		}
		/* Ű ���� ó�� */		
		if(iKeyCode >= KEY_01 && iKeyCode <= KEY_02 )
		{
			iEscFlag = iTimeContrast(iStructNo);
		} else if (iKeyCode >= KEY_13 && iKeyCode <= KEY_15 ) 				/*  END				 */
		{		
			iEscFlag = iTimeContrast(iStructNo);
			if(iEscFlag == 1)
				iEscFlag = 0;
		} else if (iKeyCode >= KEY_16 && iKeyCode <= KEY_17 ) {		/*  SUN				 */
			if ( Set._TIMESWITCH[iStructNo].iWeek & 0x01 )
			{
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek & 0x7e;
			}else 
			{
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek | 0x01;
			} 
			AreaRevers(GAMEN_START_X+3,GAMEN_START_Y+23,GAMEN_START_X+32,GAMEN_START_Y+39);
			iKeyCode = -1;
		} else if (iKeyCode >= KEY_18 && iKeyCode <= KEY_19 ) {		/*  MON				 */
			if ( Set._TIMESWITCH[iStructNo].iWeek & 0x02 )
			{
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek & 0x7d;
			}else 
			{
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek | 0x02;
			}
			AreaRevers(GAMEN_START_X+37,GAMEN_START_Y+23,GAMEN_START_X+66,GAMEN_START_Y+39);
			iKeyCode = -1;
		} else if (iKeyCode >= KEY_20 && iKeyCode <= KEY_21 ) {						/*  TUE				 */
			if ( Set._TIMESWITCH[iStructNo].iWeek & 0x04 )
			{
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek & 0x7b;
			}else 
			{
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek | 0x04;
			}
			AreaRevers(GAMEN_START_X+71,GAMEN_START_Y+23,GAMEN_START_X+100,GAMEN_START_Y+39);
			iKeyCode = -1;
		} else if (iKeyCode == KEY_23 && iKeyCode <= KEY_24) {						/*  WED				 */
			if ( Set._TIMESWITCH[iStructNo].iWeek & 0x08 ){
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek & 0x77;
			}else {
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek | 0x08;
			}
			AreaRevers(GAMEN_START_X+105,GAMEN_START_Y+23,GAMEN_START_X+134,GAMEN_START_Y+39);
			iKeyCode = -1;
		} else if (iKeyCode >= KEY_25 && iKeyCode <= KEY_26 ) {		/*  THU				 */
			if ( Set._TIMESWITCH[iStructNo].iWeek & 0x10 )
			{
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek & 0x6f;
			}else 
			{
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek | 0x10;
			}
			AreaRevers(GAMEN_START_X+139,GAMEN_START_Y+23,GAMEN_START_X+168,GAMEN_START_Y+39);
			iKeyCode = -1;
		} else if (iKeyCode >= KEY_27 && iKeyCode <= KEY_28 ) {		/*  FRI				 */
			if ( Set._TIMESWITCH[iStructNo].iWeek & 0x20 )
			{
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek & 0x5f;
			}else 
			{
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek | 0x20;
			} 
			AreaRevers(GAMEN_START_X+173,GAMEN_START_Y+23,GAMEN_START_X+202,GAMEN_START_Y+39);
			iKeyCode = -1;
		} else if (iKeyCode >= KEY_29 && iKeyCode <= KEY_30 ) {		/*  SAT				 */
			if ( Set._TIMESWITCH[iStructNo].iWeek & 0x40 )
			{
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek & 0x3f;
			}else 
			{
				Set._TIMESWITCH[iStructNo].iWeek = Set._TIMESWITCH[iStructNo].iWeek | 0x40;
			}
			AreaRevers(GAMEN_START_X+207,GAMEN_START_Y+23,GAMEN_START_X+236,GAMEN_START_Y+39);
			iKeyCode = -1;
		} else if (iKeyCode >= KEY_31 && iKeyCode <= KEY_37 ) {		/*  ���۽ð� ��Ϲ�ư */
			/* �ð� ��� ó�� ȣ�� */			
			strcpy(chKey, Set._TIMESWITCH[iStructNo].chSHour);		
			iEscFlag = iNumInput(chKey, 0, iStructNo,0);		
			iKeyCode = -1;
		} else if (iKeyCode >= KEY_46 && iKeyCode <= KEY_52 ) {		/*  ���ð� ��Ϲ�ư	 */
			/* �ð� ��� ó�� ȣ�� */
			strcpy(chKey, Set._TIMESWITCH[iStructNo].chEHour);
			iEscFlag = iNumInput(chKey, 0, iStructNo,1);			
			iKeyCode = -1;

/*		
		} else if (iKeyCode == KEY_41) {							  ���۽�	 ����	 
			 �� ��� ó�� ȣ�� 
			strcpy(chKey,Set._TIMESWITCH[iStructNo].chSHour);
			iEscFlag = iNumInput(chKey, 0, iStructNo,0);			 �� ��� ó��  
			iKeyCode = -1;
		} else if (iKeyCode == KEY_56) {							  ���� ����		 
			strcpy(chKey,Set._TIMESWITCH[iStructNo].chEHour);
			iEscFlag = iNumInput(chKey, 0, iStructNo,1);
			iKeyCode = -1;
			 �� ��� ó�� ȣ�� 
		} else if (iKeyCode == KEY_42|| iKeyCode == KEY_43 {						  ���ۺ�	 ����	 
			strcpy(chKey,Set._TIMESWITCH[iStructNo].chSMinute);
			iEscFlag =iNumInput(chKey, 1, iStructNo,0);
			iKeyCode = -1;
			 �� ��� ó�� ȣ�� 
		} else if (iKeyCode == KEY_57|| iKeyCode == KEY_58 {						  ���� ����		 
			strcpy(chKey,Set._TIMESWITCH[iStructNo].chEMinute);
			iEscFlag = iNumInput(chKey, 1, iStructNo,1);
			iKeyCode = -1;
			 �� ��� ó�� ȣ�� 
*/		

/*ksc20040518*/ /* ��ġŰ ���� ���� */			
		} else if (iKeyCode == KEY_41 || iKeyCode == KEY_42 ) {							/*  ���۽�	 ����	 */
			/* �� ��� ó�� ȣ�� */
			strcpy(chKey,Set._TIMESWITCH[iStructNo].chSHour);
			iEscFlag = iNumInput(chKey, 0, iStructNo,0);			/* �� ��� ó��  */
			iKeyCode = -1;
		} else if (iKeyCode == KEY_56 || iKeyCode == KEY_57 ) {							/*  ���� ����		 */
			strcpy(chKey,Set._TIMESWITCH[iStructNo].chEHour);
			iEscFlag = iNumInput(chKey, 0, iStructNo,1);
			iKeyCode = -1;
			/* �� ��� ó�� ȣ�� */
		} else if (iKeyCode == KEY_43 || iKeyCode == KEY_44) {						/*  ���ۺ�	 ����	 */
			strcpy(chKey,Set._TIMESWITCH[iStructNo].chSMinute);
			iEscFlag =iNumInput(chKey, 1, iStructNo,0);
			iKeyCode = -1;
			/* �� ��� ó�� ȣ�� */
		} else if (iKeyCode == KEY_58 || iKeyCode == KEY_59) {						/*  ���� ����		 */
			strcpy(chKey,Set._TIMESWITCH[iStructNo].chEMinute);
			iEscFlag = iNumInput(chKey, 1, iStructNo,1);
			iKeyCode = -1;
			/* �� ��� ó�� ȣ�� */
/*ksc20040518*/		

		} else {
			iKeyCode = -1;
		}
		if(iEscFlag == UP_TRANS || iEscFlag == DOWN_TRANS)
		{
			break;
		}
/* ksc20050805 ���� �Լ����� ������ Write�ϹǷ� ���⼭�� Write ���� ����. */
/*------------------------------------------------------------------------------------*/
/*		if(iKeyCode > 0)	*/
/*			mWriteSettei();	*/
/*------------------------------------------------------------------------------------*/
		DrawLcdBank1();		
		
	}

	return iEscFlag;
}
/* *******************************************************************************/
/*  �� �� �� : vNumInput()														 */
/*  ��    �� : 10���� �Է� ������												 */
/*  ��    �� : chKey	: �Է°� ���� �� ��ȯ									 */	
/* 			  iSize : char�� ũ��												 */
/*  ��    �� : iReFlag															 */	
/* 			1: CLR ����   0: ENT ����											 */
/*  �� �� �� : 2002�� 2�� 18�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : 																	 */
/* ******************************************************************************
*/
int		iNumInput(char* chKey, int iTime, int iStructNo, int iStartEnd){ /* ����Ǿ��ִ½ð�, ����(��,��,��), ä�� */
	
	int iReFlag;									/* 0:ENT,	1:CLR		 */
	char chData[9]; 
	char chDip[6];

	iReFlag = -1;
	sprintf(chDip,"ACT %d",iStructNo+1);
	strcpy(chData,chKey);
	while ( iReFlag == -1 || iReFlag == 0 ) {
		vNumberInputPan(1);												/*  ó��ȭ�� ���		*/
		iReFlag = iNumInputSelect(chData,&iTime,iStructNo,iStartEnd);	/*  ���� ó��			*/
		if(iReFlag == DOWN_TRANS || iReFlag == UP_TRANS)
		{
			break;
		}
		if(iStructNo != 100)
		{
			ClearDispBuff(SCREEN_0);
			vTImeSwiRegistDisp(chDip,iStructNo);
		}
	} /*  end while  */

	return iReFlag;
}
/* ****************************************************************************** */
/*  �� �� �� : iNumInputSelect()													 */
/*  ��    �� : ȭ�� ���ý� ó��													 */
/*  ��    �� :																	 */
/*  ��    �� : iReFlag 0 : ENT 1:CLR												 */
/*  �� �� �� : 2002�� 3�� 20�� (��)	����										 */
/*  �� �� �� : ȫ �� ��	-> �� �� �� 											 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
int		iNumInputSelect(char* chKey, int* iTimeorg, int iStructNo, int iStartEnd)
{
	int		isX;
	int		iMax;
	int		iData;
	int		iLong;
	int		iFlag;
	int		iTime;
	int		iSize;
	int		iReFlag;
	int		iKeyCode; 
	int		iKeyPositon;
	short	iKeyFlag;
	short	JumpSize;
	char	chValue[9];
	char	chBuffer[9];
	_RECTANGLE_INFO RECParam;

	RECParam.iLineStyle = SOLID_LINE;
	RECParam.iLineColor = WHITE;
	RECParam.iPattern	= PAT0;
	RECParam.iForeColor = BLACK;
	RECParam.iBackColor = BLACK;

	iSize		= 2;
	isX			= 0;
	iKeyCode	= -1;
	iReFlag		= -1;
	iLong		= 0;
	iKeyPositon = 0;
	iFlag		= 1;
	JumpSize	= 24;
	iKeyFlag = 1;
	memset(chValue, 0x00, sizeof(chValue));
	if ( isX == 0 ) {
		iKeyPositon = 5;
	} else if ( isX == 89 ) {
		iKeyPositon = 0;
	} /* end if */

	iTime = *iTimeorg;

	VDateCall(chKey, iTime, iStructNo, iStartEnd);
	vLastDataReverse((strlen(chKey)==1 ? 108:100),Line_1+1,chKey);
	RectAngleOut(GAMEN_START_X+isX+2,GAMEN_START_Y+2,GAMEN_START_X+isX+128,GAMEN_START_Y+19,&RECParam);
/*	vBoxInLine(isX,0,isX+120,19); */
	if(strlen(chKey)==2)
		vLastDataReverse(168+((iTime*JumpSize)==0 ? 0:(iTime*JumpSize)),NLine_3+(iStartEnd*20),chKey);
	else
		vLastDataReverse(168+((iTime*JumpSize)==0 ? 8:(iTime*JumpSize)),NLine_3+(iStartEnd*20),chKey);

	strcpy(chKey,"");
	while (iReFlag == -1) {
		iKeyCode = KeyWaitData(iKeyFlag,0xffff);							/* �Էµ� Ű���� �о��	 */
		iKeyFlag = 0;
		if(((iKeyCode >= KEY_09 && iKeyCode <= KEY_10 ) ||
			(iKeyCode >= KEY_16 && iKeyCode <= KEY_25 ) ||
			(iKeyCode >= KEY_31 && iKeyCode <= KEY_40 ) ||
			(iKeyCode >= KEY_46 && iKeyCode <= KEY_55 )))
		{
			iKeyFlag = 1;
			NormalBuzzer();				/*	Buzzer  */
		}

		if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
		{												
			iReFlag = DOWN_TRANS;
			break;
		}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
		{
			iReFlag = UP_TRANS;
			break;
		}

		/* Ű ���� ó�� */		
		if (iKeyCode >= KEY_14 - iKeyPositon && iKeyCode <= KEY_15 - iKeyPositon ) /*  CLR */
		{			
			iReFlag = 1;
		} 
		else if (iKeyCode == KEY_40 - iKeyPositon || iKeyCode == KEY_41 - iKeyPositon)								/*  6 */
		{						
			if(strcmp(chKey,"??")==0)
				strcpy(chKey, "6");
			else
				strcat(chKey, "6");			
		}
		else if (iKeyCode == KEY_42 - iKeyPositon || iKeyCode == KEY_43 - iKeyPositon)								/*  7 */
		{	
			if(strcmp(chKey,"??")==0)
				strcpy(chKey, "7");
			else
				strcat(chKey, "7");
		}
		else if (iKeyCode >= KEY_51 - iKeyPositon && iKeyCode <= KEY_52 - iKeyPositon) /*  8	 */
		{	
			if(strcmp(chKey,"??")==0)
				strcpy(chKey, "8");
			else
				strcat(chKey, "8");
		}
		else if (iKeyCode >= KEY_53 - iKeyPositon && iKeyCode <= KEY_54 - iKeyPositon )/*  9	 */
		{	
			if(strcmp(chKey,"??")==0)
				strcpy(chKey, "9");
			else
				strcat(chKey, "9");
		}
		else if (iKeyCode >= KEY_29 - iKeyPositon&& iKeyCode <= KEY_30 - iKeyPositon) /*  ��	 */
		{	
				VDateCall(chKey, iTime, iStructNo, iStartEnd);				/* ���õǾ� �ִ� �ð� ������ �� ������ �ʸ� ���������� �ҷ�������. */

				if(strlen(chKey) == 1 && iTime == 0)
					DotTextOut(GAMEN_START_X+168+((iTime*JumpSize)==0 ? 8:(iTime*JumpSize)),GAMEN_START_Y+NLine_3+(iStartEnd*20),chKey,1,1, TRANS, T_WHITE, T_BLACK);
				else{
					DotTextOut(GAMEN_START_X+168+((iTime*JumpSize)==0 ? 0:(iTime*JumpSize)),GAMEN_START_Y+NLine_3+(iStartEnd*20),chKey,1,1, TRANS, T_WHITE, T_BLACK);
				}
				iTime--;
				if(iTime < 0)
					iTime = 2;
				VDateCall(chKey, iTime, iStructNo, iStartEnd);				/* ���õǾ� �ִ� �ð� ������ �� ������ �ʸ� ���������� �ҷ�������. */
		}
		else if (iKeyCode == KEY_25 - iKeyPositon || iKeyCode == KEY_26 - iKeyPositon)							/*  2 */
		{	
			if(strcmp(chKey,"??")==0)
				strcpy(chKey, "2");
			else
				strcat(chKey, "2");
		}
		else if (iKeyCode == KEY_27 - iKeyPositon || iKeyCode == KEY_28 - iKeyPositon)							/*  3 */
		{	
			if(strcmp(chKey,"??")==0)
				strcpy(chKey, "3");
			else
				strcat(chKey, "3");
		} 
		else if (iKeyCode >= KEY_36 - iKeyPositon && iKeyCode <= KEY_37 - iKeyPositon) 	/*  4 */
		{	
			if(strcmp(chKey,"??")==0)
				strcpy(chKey, "4");
			else
				strcat(chKey, "4");
		}
		else if (iKeyCode >= KEY_38 - iKeyPositon && iKeyCode <= KEY_39 - iKeyPositon) 	/*  5 */
		{	
			if(strcmp(chKey,"??")==0)
				strcpy(chKey, "5");
			else
				strcat(chKey, "5");
		}
		else if (iKeyCode >= KEY_44 - iKeyPositon && iKeyCode <= KEY_45 - iKeyPositon) 	/*  �Ʒ�	 */
		{	
				VDateCall(chKey, iTime, iStructNo, iStartEnd);				/* ���õǾ� �ִ� �ð� ������ �� ������ �ʸ� ���������� �ҷ�������. */
				if(strlen(chKey) == 1 && iTime == 0){
					DotTextOut(GAMEN_START_X+168,GAMEN_START_Y+NLine_3+(iStartEnd*20),"  ",1,1, TRANS, T_WHITE, T_BLACK);
					DotTextOut(GAMEN_START_X+168+((iTime*JumpSize)==0 ? 8:(iTime*JumpSize)),GAMEN_START_Y+NLine_3+(iStartEnd*20),chKey,1,1, TRANS, T_WHITE, T_BLACK);
				}else{
					DotTextOut(GAMEN_START_X+168+((iTime*JumpSize)==0 ? 0:(iTime*JumpSize)),GAMEN_START_Y+NLine_3+(iStartEnd*20),chKey,1,1, TRANS, T_WHITE, T_BLACK);
				}
				iTime++;
				if(iTime >= 3)
					iTime = 0;		
				VDateCall(chKey, iTime, iStructNo, iStartEnd);				/* ���õǾ� �ִ� �ð� ������ �� ������ �ʸ� ���������� �ҷ�������. */
		}
		else if (iKeyCode == KEY_21 - iKeyPositon || iKeyCode == KEY_22 - iKeyPositon)							/*  0 */
		{			
			if(strcmp(chKey,"??")==0)
				strcpy(chKey, "0");
			else if(strcmp(chKey,"-0") != 0)
				strcat(chKey, "0");
		} 
		else if (iKeyCode == KEY_23 - iKeyPositon || iKeyCode == KEY_24 - iKeyPositon)							/*  1 */
		{	
			if(strcmp(chKey,"??")==0)
				strcpy(chKey, "1");
			else
				strcat(chKey, "1");
		} 
		else if (iKeyCode >= KEY_55 - iKeyPositon && iKeyCode <= KEY_56 - iKeyPositon) 	/*  -  */
		{	
				if(iTime == 0)		/* �ð� �϶� - ���̱�... */
				{
					DotTextOut(GAMEN_START_X+30,GAMEN_START_Y+Line_1+1,"  ",1,1, TRANS, T_WHITE, T_BLACK);
					strcpy(chKey, "-");		
				}
				else if(iTime == 1 || iTime == 2)		/* �� �� �϶� - ���̱�... */
				{
					strcpy(chKey, "-0");		
				}

		}else if(iKeyCode >= KEY_57 - iKeyPositon && iKeyCode <= KEY_58 - iKeyPositon) /* B S */
		{
			iLong = strlen(chKey);
			if(iLong == 2)
				chKey[1] = 0x00;
			else if(iLong == 1)
				chKey[0] = 0x00;
		}
		else if (iKeyCode >= KEY_59 - iKeyPositon && iKeyCode <= KEY_60 - iKeyPositon) /*  ENT */
		{	
		/*	DotTextOut(30,Line_1,"  ",1,1, TRANS);*/
			iData = gatoi(chValue);
			memset(chBuffer,0x00,9);
			strncpy(chBuffer, chValue, 1);

				if(iTime == 0){
					if(iStartEnd == 0)
						iMax = 23;
					else
						iMax = 24;
				}else{
					if((strcmp(Set._TIMESWITCH[iStructNo].chEHour,"24")==0) && iStartEnd == 1)
						iMax = 0;
					else
						iMax = 59;
				}
				if((iData > iMax)||(strcmp(chBuffer,"-")==0))
				{
					iCaptionWindow(Dspname[SET_FUNTION].chName[Set.iLang][9],"");
					iReFlag = 0;
					VDateCall(chKey, iTime, iStructNo, iStartEnd);
					*iTimeorg = iTime;	
					if(strlen(chKey) == 1 && iTime == 0)
						DotTextOut(GAMEN_START_X+168+((iTime*JumpSize)==0 ? 8:(iTime*JumpSize)),GAMEN_START_Y+NLine_3+(iStartEnd*20),chKey,1,1, TRANS, T_WHITE, T_BLACK);
					else
						DotTextOut(GAMEN_START_X+168+((iTime*JumpSize)==0 ? 0:(iTime*JumpSize)),GAMEN_START_Y+NLine_3+(iStartEnd*20),chKey,1,1, TRANS, T_WHITE, T_BLACK);
					continue;
				}
				else
				{
					if(strlen(chKey) != 0 && strcmp(chKey,"??") != 0)
					{
						if(iStartEnd == 0)
						{
							VDateCall(chKey, iTime, iStructNo, 2);				/* �Է��� ���� �ð� �� �� �����ϱ� ����. */
						}
						else if(iStartEnd == 1)
						{
							VDateCall(chKey, iTime, iStructNo, 3);				/* �Է��� �� �ð� �� �� �����ϱ� ����. */
						}
					}
					VDateCall(chKey, iTime, iStructNo, iStartEnd);

					if(strlen(chKey) == 1 && iTime == 0)
						DotTextOut(GAMEN_START_X+168+((iTime*JumpSize)==0 ? 8:(iTime*JumpSize)),GAMEN_START_Y+NLine_3+(iStartEnd*20),chKey,1,1, TRANS, T_WHITE, T_BLACK);
					else
					{
						DotTextOut(GAMEN_START_X+168+((iTime*JumpSize)==0 ? 0:(iTime*JumpSize)),GAMEN_START_Y+NLine_3+(iStartEnd*20),chKey,1,1, TRANS, T_WHITE, T_BLACK);
					}

					iTime++;
					if(iTime >= 3)												/* �ð�(0) ��(1) ��(2)�� �����ϱ� ���� */
						iTime = 0;	
					VDateCall(chKey, iTime, iStructNo, iStartEnd);				/* ���õǾ� �ִ� �ð� ������ �� ������ �ʸ� ���������� �ҷ�������. */
					iFlag = 0;
				}

		} /*  end if  */			

		if(iReFlag != 1)
		{
			/* ���� �ű� */ 			
			iLong = strlen(chKey);
		
			if (iLong > iSize) 
			{
				memset(chBuffer,0x00,9);
				strncpy(chBuffer, chKey, 2);
				if((strcmp(chBuffer,"-0")==0))						/* �а� �ʺκп� -0���� �ԷµǴ� �κ��� ���� */
				{
					memset(chBuffer,0x00,9);
					strncpy(chBuffer, chKey+2, 1);
					sprintf(chValue,"-%s",chBuffer);
				}
				else
					strncpy(chValue, chKey+1, iSize);							/* 2�ڸ����� ���ڸ��� �����ϱ� ���� */		
			} else 
			{
				strcpy(chValue, chKey);
			} /* end if */				

			if(iTime==0 && strlen(chValue)==2)	
			{
				memset(chBuffer,0x00,9);
				strncpy(chBuffer, chValue, 1);
				if(strcmp(chBuffer,"0")==0)
				{
					strncpy(chBuffer, chValue+1, 1);
					strcpy(chValue, chBuffer);
				}
			}
		/* �Ϻ� ���� */
			strcpy(chKey, chValue);
			if(strlen(chKey)==1)
			{
				if(iTime != 0)
					sprintf(chKey,"0%s",chValue);
				DotTextOut(GAMEN_START_X+100,GAMEN_START_Y+Line_1+1,"  ",1,1, TRANS, T_WHITE, T_BLACK);
				vLastDataReverse((iTime==0 ? 108:100),Line_1+1,chKey);
				if(iTime==0)
					DotTextOut(GAMEN_START_X+168,GAMEN_START_Y+NLine_3+(iStartEnd*20),"  ",1,1, TRANS, T_WHITE, T_BLACK);
				vLastDataReverse(168+((iTime*JumpSize)==0 ? 8:(iTime*JumpSize)),NLine_3+(iStartEnd*20),chKey);
				RectAngleOut(GAMEN_START_X+isX+2,GAMEN_START_Y+2,GAMEN_START_X+isX+128,GAMEN_START_Y+19,&RECParam);

			/*	vBoxInLine(isX,0,isX+120,19); */
			}
			else if(strlen(chKey)==2)
			{
				vLastDataReverse(100,Line_1+1,chKey);
				RectAngleOut(GAMEN_START_X+isX+2,GAMEN_START_Y+2,GAMEN_START_X+isX+128,GAMEN_START_Y+19,&RECParam);
		/*		vBoxInLine(isX,0,isX+120,19);*/				/* �Է°� ��� ȭ��E		 */	
				vLastDataReverse(168+((iTime*JumpSize)==0 ? 0:(iTime*JumpSize)),NLine_3+(iStartEnd*20),chKey);
			}else if(iKeyCode >= KEY_57 - iKeyPositon && iKeyCode <= KEY_58 - iKeyPositon)
			{
				sprintf(chKey," ");
				DotTextOut(GAMEN_START_X+100,GAMEN_START_Y+Line_1+1,"  ",1,1, TRANS, T_WHITE, T_BLACK);
				vLastDataReverse((iTime==0 ? 108:100),Line_1+1,chKey);
				if(iTime==0)
					DotTextOut(GAMEN_START_X+168,GAMEN_START_Y+NLine_3+(iStartEnd*20),"  ",1,1, TRANS, T_WHITE, T_BLACK);
				vLastDataReverse(168+((iTime*JumpSize)==0 ? 8:(iTime*JumpSize)),NLine_3+(iStartEnd*20),chKey);
				strcpy(chKey,"");
			}
			if(iFlag == 0)
			{
				strcpy(chKey,"");
				iFlag = 1;
			}
		}

		DrawLcdBank1();
		/*Delay(100);*/
	} /*  end while  */	
	return iReFlag;
}
int iTimeContrast(int iType)
{
	int retData;
	int iSHour;
	int	iSMin;
	int	iSSec;
	int iEHour;
	int	iEMin;
	int	iESec;
	iESec =	strcmp(Set._TIMESWITCH[iType].chSHour,"??");
	iEMin =	strcmp(Set._TIMESWITCH[iType].chSHour,"11");
	if(strcmp(Set._TIMESWITCH[iType].chSHour,"??") == 0 && strcmp(Set._TIMESWITCH[iType].chSMinute,"??") == 0 &&
		strcmp(Set._TIMESWITCH[iType].chSSecond,"??") == 0 && strcmp(Set._TIMESWITCH[iType].chEHour,"??") == 0 &&
		strcmp(Set._TIMESWITCH[iType].chEMinute,"??") == 0 && strcmp(Set._TIMESWITCH[iType].chESecond,"??") == 0)
	{
		retData = 1;
	}
	else if(strcmp(Set._TIMESWITCH[iType].chSHour,"??") == 0 || strcmp(Set._TIMESWITCH[iType].chSMinute,"??") == 0 ||
		strcmp(Set._TIMESWITCH[iType].chSSecond,"??") == 0 || strcmp(Set._TIMESWITCH[iType].chEHour,"??") == 0 ||
		strcmp(Set._TIMESWITCH[iType].chEMinute,"??") == 0 || strcmp(Set._TIMESWITCH[iType].chESecond,"??") == 0)
	{
		retData = -1;
	}else
	{
		retData = -1;
		iSHour = gatoi(Set._TIMESWITCH[iType].chSHour);
		iSMin = gatoi(Set._TIMESWITCH[iType].chSMinute);
		iSSec = gatoi(Set._TIMESWITCH[iType].chSSecond);

		iEHour = gatoi(Set._TIMESWITCH[iType].chEHour);
		iEMin = gatoi(Set._TIMESWITCH[iType].chEMinute);
		iESec = gatoi(Set._TIMESWITCH[iType].chESecond);
		if(iSHour < iEHour){
			retData = 1;
		}else if(iSHour == iEHour)
		{
			if(iSMin < iEMin){
				retData = 1;
			}else if(iSMin == iEMin)
			{
				if(iSSec < iESec)
					retData = 1;
			}
		}
	}

	if(retData == -1)
		iCaptionWindow(Dspname[SET_FUNTION].chName[Set.iLang][9],"");
	return retData;
}
#endif
void	SwitchScrenSetting(void)
{
	short	i;
	short   iBuff;
	int		iTimeSetData;

	for(i=0;i<8;i++)
	{
		CommonArea.SystemDev._TIMESWITCH[i].iWeek = Set._TIMESWITCH[i].iWeek;
		if(!(strlen(Set._TIMESWITCH[i].chSHour) == 0 || strlen(Set._TIMESWITCH[i].chSMinute) == 0 ||
			strlen(Set._TIMESWITCH[i].chSSecond) == 0)){

			iBuff = gatoi(Set._TIMESWITCH[i].chSHour);
			iTimeSetData = iBuff * 3600;
			iBuff = gatoi(Set._TIMESWITCH[i].chSMinute);
			iTimeSetData += iBuff * 60;
			iBuff = gatoi(Set._TIMESWITCH[i].chSSecond);
			iTimeSetData += iBuff;
			CommonArea.SystemDev._TIMESWITCH[i].StartTime  = iTimeSetData;
		}
		if(!(strlen(Set._TIMESWITCH[i].chEHour) == 0 || strlen(Set._TIMESWITCH[i].chEMinute) == 0 ||
			strlen(Set._TIMESWITCH[i].chESecond) == 0)){
			iBuff = gatoi(Set._TIMESWITCH[i].chEHour);
			iTimeSetData = iBuff * 3600;
			iBuff = gatoi(Set._TIMESWITCH[i].chEMinute);
			iTimeSetData += iBuff * 60;
			iBuff = gatoi(Set._TIMESWITCH[i].chESecond);
			iTimeSetData += iBuff;
			CommonArea.SystemDev._TIMESWITCH[i].EndTime  = iTimeSetData;
			CommonArea.SystemDev._TIMESWITCH[i].OnOffFlag = 0;
		}
	}
}
/* *******************************************************************************/
/*  �� �� �� : VDateCall()														 */
/*  ��    �� : �ð� ���� �� �Է�												 */
/*  ��    �� :																	 */
/*  ��    �� : iReFlag 0 : ENT 1:CLR											 */
/*  �� �� �� : 2002�� 3�� 21�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* *******************************************************************************/
void		VDateCall(char* chKey, int iTime, int iStructNo, int iStartEnd)
{
	char chData[9];
	memset(chData,0x00,sizeof(chData));

	if(iStartEnd == 0)
	{
		switch(iTime)
		{
		case 0 :
			strcpy(chData, Set._TIMESWITCH[iStructNo].chSHour);
			break;
		case 1 :
			strcpy(chData, Set._TIMESWITCH[iStructNo].chSMinute);
			break;
		case 2:
			strcpy(chData, Set._TIMESWITCH[iStructNo].chSSecond);
			break;
		}
		strcpy(chKey,chData);
	}
	else if(iStartEnd == 1)
	{
		switch(iTime)
		{
		case 0 :
			strcpy(chData, Set._TIMESWITCH[iStructNo].chEHour);
			break;
		case 1 :
			strcpy(chData, Set._TIMESWITCH[iStructNo].chEMinute);
			break;
		case 2:
			strcpy(chData, Set._TIMESWITCH[iStructNo].chESecond);
			break;
		}
		strcpy(chKey,chData);
	}
	else if(iStartEnd == 2)
	{
		switch(iTime)
		{
			case 0 :
				strcpy(Set._TIMESWITCH[iStructNo].chSHour, chKey);
				break;
			case 1 :
				strcpy(Set._TIMESWITCH[iStructNo].chSMinute, chKey);
				break;
			case 2:
				strcpy(Set._TIMESWITCH[iStructNo].chSSecond, chKey);
				break;
		}
	}
	else if(iStartEnd == 3)
	{
		switch(iTime)
		{
			case 0 :
				strcpy(Set._TIMESWITCH[iStructNo].chEHour, chKey);
				if(strcmp(chKey,"24")==0){
					strcpy(Set._TIMESWITCH[iStructNo].chEMinute, "00");
					strcpy(Set._TIMESWITCH[iStructNo].chESecond, "00");
				}
				break;
			case 1 :
				strcpy(Set._TIMESWITCH[iStructNo].chEMinute, chKey);
				break;
			case 2:
				strcpy(Set._TIMESWITCH[iStructNo].chESecond, chKey);
				break;
		}
	}
}
