/* ****************************************************************************** */
/*  �� �� �� : GPACTSTATEMONI.CPP													 */
/*  ��    �� : ����̽� ����� ó��												 */
/*  �� �� �� : 2002�� 2�� 15�� (��)												 */
/*  �� �� �� : ȫ �� ��															 */
/*  ��    �� : (��) LC Tech														 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#include	"sgt.h"

#ifdef	SIZE_2480
/* ****************************************************************************** */
/*  �� �� �� : DataViewMenu()													 */
/*  ��    �� : Data�� �ǽð����� �����ִ� �޴���.								 */
/*  ��    �� : iScreenNo(���� ȭ�� ��ȣ)										 */
/*  ��    �� :																	 */
/*  �� �� �� : 2003�� 6�� 27�� (��)												 */
/*  �� �� �� : �� �� ��															 */
/*  ��    �� : 																	 */
/* ****************************************************************************** */
#ifdef	OLD
void	DataViewMenu(int *iScreenNo)
{
	int			iKeyCode;
	int			iSetFlag; 
	int			iUserMemoryData;
	short		i;
	short		j;
	short		iKeyFlag;
	short		iScreenNum;
	char		*LineDataBuffer;
	int			iflag;
	iSetFlag	= 1;
	iKeyFlag	= 1;
	/**************************/
	RepeatInfo.EntryCnt = 2;
	RepeatInfo.RepeatNo[0][0] = (char)KEY_29;
	RepeatInfo.RepeatNo[0][1] = (char)KEY_30;
	RepeatInfo.RepeatNo[1][0] = (char)KEY_59;
	RepeatInfo.RepeatNo[1][1] = (char)KEY_60;
	/**************************/
	iScreenNum = DATA_VIEW_NUM * 100 + 1;	//20091222
	LineDataBuffer = TakeMemory(30);
	while ( *iScreenNo == DATA_VIEW_NUM ) {
		if(iSetFlag == 2)
			AreaClear(0,0,GAMEN_X_SIZE-1,GAMEN_Y_SIZE-1,0);
		DefaultFormDisplay(4 , Dspname[DATA_VIEW].chTitle[Set.iLang]);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */

		i = 0;
		iKeyCode = -1;
		while (iKeyCode == -1 || iKeyCode == 0) {
			if(iSetFlag == 1 || iSetFlag == 2)
			{
				AreaClear(GAMEN_START_X+0,GAMEN_START_Y+23,GAMEN_START_X+197,GAMEN_START_Y+79,0);
				for(j=0;j<3;j++)
				{
					if((i+j) == 3)
					{
						memset(LineDataBuffer,0x00,30);
						iUserMemoryData = (int)((CheckUserArea())/2);
						sprintf(LineDataBuffer,"%s[%dKB]",Dspname[DATA_VIEW].chName[Set.iLang][i+j],(MAX_MEMORY_SIZE - iUserMemoryData));
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+(NLine_2+(j*18)),LineDataBuffer,1,1, TRANS, T_WHITE, T_BLACK);		
					}
					else
						DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+(NLine_2+(j*18)),(Dspname[DATA_VIEW].chName[Set.iLang][i+j]),1,1, TRANS, T_WHITE, T_BLACK);		
				}
				ScroolBarDisplay(5, i);
				DrawLcdBank1();	
				iSetFlag = 0;
			}
			while(1)
			{
				/*leesi 040612 	iKeyCode = KeyWait(); */
				iKeyCode = iKeyReturn(DATA_VIEW_NUM);

				if(iKeyFlag == 0 || iKeyCode == PC_DNLOAD_START || 
					iKeyCode == PC_UPLOAD_START || iKeyCode == 0)
					break;
			}
			iKeyFlag = 0;
			if(!((iKeyCode >= KEY_03 && iKeyCode <= KEY_12 ) ||
				 iKeyCode == KEY_28 || iKeyCode == KEY_43 || 
				 iKeyCode == KEY_44 || iKeyCode == KEY_45 ||
				 iKeyCode == KEY_58 || iKeyCode == 0) )
			{
				iKeyFlag = 1;
				NormalBuzzer();										/*	Buzzer			*/
			}

			if(iKeyCode == PC_DNLOAD_START)		/* DownLoad	*/
			{												
				*iScreenNo = DOWN_TRANS;
				break;
			}else if(iKeyCode == PC_UPLOAD_START)	/* UPLoad	*/
			{
				*iScreenNo = UP_TRANS;
				break;
			}
			/********************************************************/
			/*
				41 : Base Screen
				42 : Window Screen 
				43 : Comment Screen
				44 : Memory Size
				������¥[2003/10/18]								*/
			/********************************************************/

			/* Ű ���� ó�� */		
			if (iKeyCode >= KEY_01 && iKeyCode <= KEY_02)
			{
				*iScreenNo = USER_SCREEN_NUM;	
			}else if(iKeyCode >= KEY_13 && iKeyCode <= KEY_15) 
			{									/*  ����, ���� ��ưŬ���� */						
				*iScreenNo = SELECT_MEMU_NUM;	
			} else if (iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ) 
			{
				iflag = iSysSetretCheck(iScreenNum + i);
				if(iflag == DOWN_TRANS)		/* DownLoad */
					*iScreenNo = DOWN_TRANS;
				else if(iflag == UP_TRANS)	/* UPLoad */
					*iScreenNo = UP_TRANS;
				else if(iflag == 0)			/* ȭ���̵� ó�� */
					*iScreenNo = iScreenNum + i;										/*  ȭ�����			 */
				else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = DATA_VIEW_NUM;
					iSetFlag = 2;
					break;
				}
			} else if (iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ) 
			{
				iflag = iSysSetretCheck(iScreenNum + 1 + i);
				if(iflag == DOWN_TRANS)		/* DownLoad */
					*iScreenNo = DOWN_TRANS;
				else if(iflag == UP_TRANS)	/* UPLoad */
					*iScreenNo = UP_TRANS;
				else if(iflag == 0)			/* ȭ���̵� ó�� */
					*iScreenNo = iScreenNum + 1 + i;										/*  ȭ�����			 */
				else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = DATA_VIEW_NUM;
					iSetFlag = 2;
					break;
				}
			} else if (iKeyCode >= KEY_46 && iKeyCode <= KEY_57 ) 
			{
				iflag = iSysSetretCheck(iScreenNum + 2 + i);
				if(iflag == DOWN_TRANS)		/* DownLoad */
					*iScreenNo = DOWN_TRANS;
				else if(iflag == UP_TRANS)	/* UPLoad */
					*iScreenNo = UP_TRANS;
				else if(iflag == 0)			/* ȭ���̵� ó�� */
					*iScreenNo = iScreenNum + 2 + i;										/*  ȭ�����			 */
				else	/* ���� ȭ�� ��� */
				{
					*iScreenNo = DATA_VIEW_NUM;
					iSetFlag = 2;
					break;
				}
			} else if (iKeyCode >= KEY_59 && iKeyCode <= KEY_60 ) 
			{
				if(i < 2){
					iSetFlag = 1;
					i++;												/*  Line Down		  */	
				}
/*
				iKeyFlag = 0;
				KerRepeatFlag = 1;
				iKeyCode = -1;
*/
/*ksc20040727*/ /* ���� �ٲ� */
				iKeyCode = -1;
				KerRepeatFlag = 1;
				iKeyFlag = 0;
/*				KerRepeatFlag = 1;*/
/*ksc20040727*/
			} else if (iKeyCode >= KEY_29 && iKeyCode <= KEY_30 ) 
			{
				if(i > 0){
					iSetFlag = 1;
					i--;												/*  Line Up		  */	
				}
/*
				iKeyFlag = 0;
				iKeyCode = -1;
				KerRepeatFlag = 1;
*/
/*ksc20040727*/ /* ���� �ٲ� */
				iKeyCode = -1;
				KerRepeatFlag = 1;
				iKeyFlag = 0;
/*				KerRepeatFlag = 1;*/
/*ksc20040727*/
			}else{
				iKeyCode = -1;
			} 			
		} 	
	} 
	FreeMail(LineDataBuffer);
	KerRepeatFlag = 0;
	memset(&RepeatInfo,0x00,sizeof(RepeatInfo));
	return;
}



#else



void	DataViewMenu(int *iScreenNo){

	int		iKeyCode;
	int		iSetFlag ; 
	int		i;
	int		j;
	short	iKeyFlag;
	int	iflag;

/*ksc20040727*/ /* �ڸ�Ʈ �߰� */
	iKeyFlag	= 1;  /* iKeyFlag	= 1�϶� ���� ȭ���� ��������, 0�϶� ���� ȭ�� ��� ���� */
	iSetFlag	= 1;  /* up/down �� ǥ�� ���� ���� �÷��� */

	/*ksc20040727*/
	/**************************/
	RepeatInfo.EntryCnt = 2;
	RepeatInfo.RepeatNo[0][0] = (char)KEY_29;
	RepeatInfo.RepeatNo[0][1] = (char)KEY_30;
	RepeatInfo.RepeatNo[1][0] = (char)KEY_59;
	RepeatInfo.RepeatNo[1][1] = (char)KEY_60;
	/**************************/
	KerRepeatFlag = 1;	/* 040815 */
	while ( *iScreenNo == DATA_VIEW_NUM ) {
		if(iSetFlag == 2)										//2012.08.16
			AreaClear(0,0,GAMEN_X_SIZE-1,GAMEN_Y_SIZE-1,0);		//2012.08.16
		else													//2012.08.16
			i = 0;												//2012.08.16
		DefaultFormDisplay(4 , Dspname[DATA_VIEW].chTitle[Set.iLang]);		/* ȭ��ǥ �ִ� ȭ��Ʋ �׸� */
//		i = 0;
		iKeyCode = -1;
		while (iKeyCode == -1 || iKeyCode == 0) {
			if(iSetFlag == 1)
			{
				AreaClear(GAMEN_START_X+0,GAMEN_START_Y+23,GAMEN_START_X+197,GAMEN_START_Y+79,0);
				for(j=0;j<3;j++)
				{
					DotTextOut(GAMEN_START_X+4,GAMEN_START_Y+(NLine_2+(j*18)),(Dspname[DATA_VIEW].chName[Set.iLang][i+j]),1,1, TRANS, T_WHITE, T_BLACK);		
				}

#ifdef	GP_S044
				ScroolBarDisplay(5, i);
#endif
#ifdef	LP_S044
				ScroolBarDisplay(5, i);
#endif
				DrawLcdBank1();	
				iSetFlag = 0;
			}
			
			while(1)
			{
				/*  iKeyCode = KeyWait();  leesi 040612 */
				iKeyCode = iKeyReturn(DATA_VIEW_NUM);

				if(iKeyFlag == 0 || iKeyCode == PC_DNLOAD_START || 
					iKeyCode == PC_UPLOAD_START || iKeyCode == 0)
					break;
			}
			iKeyFlag = 0;
#ifdef	LP_S044
			if(!((iKeyCode >= KEY_03 && iKeyCode <= KEY_12 ) ||
				 iKeyCode == KEY_44 || iKeyCode == KEY_45 ||
				 iKeyCode == 0))
#endif
#ifdef	GP_S044
			if(!((iKeyCode >= KEY_03 && iKeyCode <= KEY_12 ) ||
				 iKeyCode == KEY_44 || iKeyCode == KEY_45 ||
				 iKeyCode == 0))
#endif
			{
				iKeyFlag = 1;
				if(iKeyCode != PC_DNLOAD_START){	/* 051213 */
					NormalBuzzer();										/*	Buzzer			*/
				}
			}
			switch(iKeyCode){
			case PC_DNLOAD_START:	*iScreenNo = DOWN_TRANS;	break;	/* DownLoad	*/
			case PC_UPLOAD_START:	*iScreenNo = UP_TRANS;		break;	/* UPLoad	*/
#ifdef	LP_S044
			case KEY_28:  /* Gage UP ó  �� */ /************************************************************/
				if(i != 0){	i = 0;	iSetFlag= 1;	}
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
			case KEY_43:  /* Gage Midle?? �� */
				i= 1;
				iSetFlag= 1;
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
			case KEY_58:  /* Gage Down ������ */
				i= 2;
				iSetFlag= 1;
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
#endif
#ifdef	GP_S044
			case KEY_28:  /* Gage UP ó  �� */ /************************************************************/
				if(i != 0){	i = 0;	iSetFlag= 1;	}
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
			case KEY_43:  /* Gage Midle?? �� */
				i= 1;
				iSetFlag= 1;
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
			case KEY_58:  /* Gage Down ������ */
				i= 2;
				iSetFlag= 1;
				iKeyFlag = 0;
				iKeyCode = -1;
				break;
#endif
			default:
				if ((iKeyCode >= KEY_01 && iKeyCode <= KEY_02) || 
					(iKeyCode >= KEY_13 && iKeyCode <= KEY_15) ) 
				{									/*  ����, ���� ��ưŬ���� */						
					*iScreenNo = SELECT_MEMU_NUM;	
				} else if (iKeyCode >= KEY_16 && iKeyCode <= KEY_27 ) 
				{
					iflag = iSysSetretCheck(DATA_VIEW_NUM * 100 + 1 + i);		//2012.08.16
					if(iflag == 0){												//2012.08.16
						*iScreenNo = DATA_VIEW_NUM * 100 + 1 + i;				//2012.08.16
					}else{														//2012.08.16
						*iScreenNo = DATA_VIEW_NUM;								//2012.08.16
						iSetFlag= 2;											//2012.08.16
					}															//2012.08.16
//					*iScreenNo = DATA_VIEW_NUM * 100 + 1 + i;					//2012.08.16			
				} else if (iKeyCode >= KEY_31 && iKeyCode <= KEY_42 ) 
				{
					*iScreenNo = DATA_VIEW_NUM * 100 + 2 + i;										
				} else if (iKeyCode >= KEY_46 && iKeyCode <= KEY_57 ) 
				{
					*iScreenNo = DATA_VIEW_NUM * 100 + 3 + i;									
				} else if (iKeyCode >= KEY_59 && iKeyCode <= KEY_60 ) 
				{
	//				if(i != 1){
#ifdef	LP_S044
					if(i < 2){
#endif
#ifdef	GP_S044
					if(i < 2){
#endif
						i++;
						iSetFlag = 1;
	//					i = 1;												/*  Line Down	  */	
					}						
	/*ksc20040727*/ /* �������� */
					iKeyCode = -1;
					iKeyFlag = 0;
	/*ksc20040727*/
				} else if (iKeyCode >= KEY_29 && iKeyCode <= KEY_30 ) 
				{
	//				if(i != 0){
					if(i > 0){
						i--;
						iSetFlag = 1;
	//					i = 0;												/*  Line Up		  */	
					}						
	/*ksc20040727*/ /* �������� */
					iKeyCode = -1;
					iKeyFlag = 0;
	/*				KerRepeatFlag = 1;*/
	/*ksc20040727*/
				}else{
					iKeyCode = -1;
				} 
				break;
			}
		} 	
	} 
	KerRepeatFlag = 0;
	return;
}

#endif
#endif

