/********************************************************************************/
/* �� �� �� : Gp_SearchDevice.cpp												*/
/* ��    �� : Device Searching													*/
/* �� �� �� : 2002�� 8�� 15�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : (��) LC Tech														*/
/* ��    �� : 																	*/
/********************************************************************************/
#include	"sgt.h"

/********************************************************************************/
/*  �Լ� ����																	*/
/********************************************************************************/
#ifdef	OLD
int WatchingDevice(char *cDevBuff, int iDeviceNumber, unsigned short iFlag, int iRegistNumber, int iBitFlag, int iCnt)
{
	int			i;
	int			k;
	char		cDevName[2];
	int			retVal;

	cDevName[0] = cDevBuff[0];
	cDevName[1] = cDevBuff[1];
	cDevName[2] = 0x00;
	k = 0;

	/* ������ �̹� ��ϵ� ���� Device�� �ִ����� �˻��Ѵ�. */
	if(!(iDeviceSearchCnt == 0 || iBitFlag > 1)){
		i = 0;
		while(i<iDeviceSearchCnt){
			if((strcmp(DevSupervisorTbl[i]->cDevName, cDevName) == 0) && 
				DevSupervisorTbl[i]->iDevNumber == iDeviceNumber && 
				DevSupervisorTbl[i]->iDevFlag == iFlag && 
				DevSupervisorTbl[i]->iCnt == iCnt){
				k = OFF;
				retVal= i;
				break;
			}else{
				k = ON; /* ������ ����̽��� �о������ ����ؾ� �ϴ� ��� */
			}
			i++;
		}
		if(k == ON){
			DevSupervisorTbl[iDeviceSearchCnt] = (_DEV_SUPERVISOR_TBL*)TakeMemory(sizeof(_DEV_SUPERVISOR_TBL));
			memset(DevSupervisorTbl[iDeviceSearchCnt], 0x00, sizeof(_DEV_SUPERVISOR_TBL));
			memcpy(DevSupervisorTbl[iDeviceSearchCnt]->cDevName, cDevName, sizeof(cDevName));
			DevSupervisorTbl[iDeviceSearchCnt]->iDevNumber = iDeviceNumber;
			DevSupervisorTbl[iDeviceSearchCnt]->iRegNumber = iRegistNumber;
			DevSupervisorTbl[iDeviceSearchCnt]->iDevFlag = iFlag;
			DevSupervisorTbl[iDeviceSearchCnt]->iBitFlag = iBitFlag;
			DevSupervisorTbl[iDeviceSearchCnt]->cpDevVal = (char*)(char*)DeviceDataHed[iRegistNumber].DevData;
			DevSupervisorTbl[iDeviceSearchCnt]->iCnt = iCnt;
			iDeviceSearchCnt++;
			retVal= iDeviceSearchCnt- 1;
		}
	}else{
		if(iBitFlag>1)
			iBitFlag = iBitFlag-2;
		DevSupervisorTbl[iDeviceSearchCnt] = (_DEV_SUPERVISOR_TBL*)TakeMemory(sizeof(_DEV_SUPERVISOR_TBL));
		memset(DevSupervisorTbl[iDeviceSearchCnt], 0x00, sizeof(_DEV_SUPERVISOR_TBL));
		memcpy(DevSupervisorTbl[iDeviceSearchCnt]->cDevName, cDevName, sizeof(cDevName));
		DevSupervisorTbl[iDeviceSearchCnt]->iDevNumber = iDeviceNumber;
		DevSupervisorTbl[iDeviceSearchCnt]->iRegNumber = iRegistNumber;
		DevSupervisorTbl[iDeviceSearchCnt]->iDevFlag = iFlag;
		DevSupervisorTbl[iDeviceSearchCnt]->iBitFlag = iBitFlag;
		DevSupervisorTbl[iDeviceSearchCnt]->cpDevVal = (char*)DeviceDataHed[iRegistNumber].DevData;
		DevSupervisorTbl[iDeviceSearchCnt]->iCnt = iCnt;
		iDeviceSearchCnt++;
		retVal= iDeviceSearchCnt- 1;
	}
	return(retVal);
}
#endif
/*
void GetDeviceValue()
{
	int			iRegistNumber;
	char*		cDeviceVal;
	int			i;

	if(iDeviceScanFlag == ON){
		cDeviceVal = (char*)TakeMemory(128);	
		i = 0;
		while(i<iDeviceSearchCnt){
			memset(cDeviceVal, 0x00, 128);
			iRegistNumber = DevSupervisorTbl[i]->iRegNumber;

			*//* Word : 1,    Bit : 0 *//*
			if(DevSupervisorTbl[i]->iBitFlag == WORD){
				memcpy(cDeviceVal, DeviceDataHed[iRegistNumber].DevData, (DeviceDataHed[iRegistNumber].DevCnt*2));
			}
			else if(DevSupervisorTbl[i]->iBitFlag == BIT){
				memcpy(cDeviceVal, DeviceDataHed[iRegistNumber].DevData, (DeviceDataHed[iRegistNumber].DevCnt));
			}
			
			memcpy(DevSupervisorTbl[i]->cpDevVal, cDeviceVal, 128);		
			i++;
		}
		FreeMail((char*)cDeviceVal);
	}
}
*/
/*
int	CompareDeviceAddr(char *cDevName, int iDevNumber, unsigned short iFlag)
{
	int	i;
	int	iRetVal;

	i		= 0;
	iRetVal = -1;
	while(i<iDeviceSearchCnt){
		if(strcmp(cDevName, DevSupervisorTbl[i]->cDevName) == 0 && 
			                DevSupervisorTbl[i]->iDevNumber == iDevNumber && 
							DevSupervisorTbl[i]->iDevFlag == iFlag){
			iRetVal = i;
			break;
		}
		i++;
	}
	return iRetVal;
}
leesi 040609
*/
/*
int	CompareDeviceAddr(char *cDevName, int iDevNumber, unsigned short iCnt)
{
	int	i;
	int	iRetVal;

	i		= 0;
	iRetVal = -1;
	while(i<iDeviceSearchCnt){
		if(strcmp(cDevName, DevSupervisorTbl[i]->cDevName) == 0 && 
			                DevSupervisorTbl[i]->iDevNumber == iDevNumber && 
							DevSupervisorTbl[i]->iCnt == DeviceDataHed[iCnt].DevCnt){
			iRetVal = i;
			break;
		}
		i++;
	}
	return iRetVal;
}

int	AsciiCompareDeviceAddr(char *cDevName, int iDevNumber, int iDevcnt)
{
	int	i;
	int	iRetVal;

	i		= 0;
	iRetVal = -1;
	while(i<iDeviceSearchCnt){
		if(strcmp(cDevName, DevSupervisorTbl[i]->cDevName) == 0 && 
			                DevSupervisorTbl[i]->iDevNumber == iDevNumber){
			if(DeviceDataHed[DevSupervisorTbl[i]->iRegNumber].DevCnt == iDevcnt)
			{
				iRetVal = i;
				break;
			}
		}
		i++;
	}
	return iRetVal;
}

*/
