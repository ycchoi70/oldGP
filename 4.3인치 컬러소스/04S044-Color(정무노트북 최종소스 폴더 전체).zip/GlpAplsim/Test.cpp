
#ifdef _WINDOWS
//#include    "stdafx.h"
#endif
#include	<stdio.h>
#include	<string.h>

#include	"define.h"
#include	"mts.h"
#include	"mtscifp.h"
#include	"mail.h"
#include	"taskhed.h"
#define	MAIN
#include	"CommBuff.h"
#include	"bios.h"
#include	"filesys.h"
#include	"taskhed.h"
#include	"gpstruct.h"

extern	void	IoPortRam( void );
void    BuzOn();
void    BuzOff();
#ifdef	WIN32
extern	char	LcdBuff[GAMEN_Y_SIZE][320/8];
/*extern	char	LcdBuff1[256][320/8];*/
#else
extern	unsigned short	LcdBuff[GAMEN_Y_SIZE][GAMEN_X_SIZE/8];
/*extern	unsigned short	LcdBuff1[80][240/8];*/
#endif

extern	int		TateYoko;			/* �c�E�� */
extern	int		PcThruWCnt;
extern	int		PcThruBCnt;

extern	unsigned long MakeCheckDigit(unsigned long rData);
extern	void	DrawLcdBank1(void);
extern	void	CashOn( void );
extern	void	CashOff( void );
extern	int   KeyAccept( void );
extern	void	LcdStart( void );
extern	void	DateTimeSet(RTC_DATA *SetTime,int Reset);
extern	void	PutImageGp( int sx, int sy, int ex, int ey, char *ScrBuff);
extern	void	SetStartPos(int no, int x, int y);
extern	void	OpenWindow(int no, int width, int hight);
extern	void	CloseWindow(int no);
extern	void	AreaRevers(int x1,int y1,int x2,int y2);
extern	void	AreaClear(int x1,int y1,int x2,int y2,int back);
extern	int   KeyWait( void );
extern	void	mBaseClear( void );
extern	void	DrawOrggataProc(int x0, int y0, int r, int x1, int y1, int x20, int y20,int Scale, int iSel,_ORGGATA_INFO *param);
extern	void	SendTimeAction(int p1,int p2,int p3,int p4);
extern	void	DrawDaen(int x0, int y0, int x,int y, _CIRCLE_INFO *param);

extern	int DModeFlag;
/*extern	int		AutoBrateFlag;*/


_SETUP		Set;					/* ������ ����E����ü						*/

_CIRCLE_INFO	CircleParam;
_ORGGATA_INFO	OogigataParam;
extern	void	mReadSettei( void );

void	IniTask( STTFrm* pSTT )
{
	int		i;
	int		signal;
	char	buff[32];
	struct{
		char	x;
		char	y;
	}dem_data[32];



	int DMst= 12;
	int DSlave= 7;

    int     Dlt;
    int     DMst2;
    int     DSlave2;

	memset(dem_data,0,sizeof(dem_data));
    Dlt= 0;
    DSlave2= DSlave + DSlave;
    DMst2= DMst + DMst;
	int	y= 1;
	int	x= 1;
    for( i= 0; i < DMst; i++ ) {
        Dlt -= DSlave2;
        if ( Dlt + DMst < 0 ) {
			y++;
            Dlt += DMst2;
        }
		x++;
		dem_data[i].x= x;
		dem_data[i].y= y;
    }
	i= 0;
#ifdef	OLD
	int	a1,a2,a3,a4,a5,a6,a7,a8,a9,a10;
	int	a11,a12,a13,a14,a15,a16,a17,a18,a19;
a1= sizeof(_LINEGRAPH_EVENT_TBL);
a2= sizeof(_LAMP_EVENT_TBL);
a3= sizeof(_ASCII_EVENT_TBL);	
a4= sizeof(_NUMERIC_EVENT_TBL); 
a5= sizeof(_CLOCK_EVENT_TBL); 
a6= sizeof(_ALARM_HISTORY_EVENT_TBL); 
a7= sizeof(_ALARM_LIST_EVENT_TBL); 
a8= sizeof(_PARTS_EVENT_TBL); 
a9= sizeof(_PANEL_METER_EVENT_TBL); 
a10= sizeof(_TRENDGRAPH_EVENT_TBL); 
a11= sizeof(_BARGRAPH_EVENT_TBL); 
a12= sizeof(_STATISTICS_EVENT_TBL); 
a13= sizeof(_TOUCHSWICH_EVENT_TBL); 
a14= sizeof(_COMMENT_EVENT_TBL); 
a15= sizeof(_NUMERIC_INPUT_EVENT_TBL); 
a16= sizeof(_ASCIIINPUT_EVENT_TBL); 
a17= sizeof(_FIGURE_EVENT_TBL); 

#endif

	TateYoko= 0;
	CashOn();
	memset(buff,0x00,sizeof(buff));
	IoPortRam();
	InitDispSema();
	i = 0;

#ifdef	OLD
	Set.iBackLightTime= 0;
	Set.iConnect= 0;
#else
	mReadSettei();
#endif
	LangageFlag = 1;			/* Hangle */
	DeviceCnt = 0;		/* �Ď��p�f�o�C�X�� */
	signal = 0xffffffff;
	OffSignal(SGN_PLC,signal);
	LcdStart();
	KerRepeatFlag= 0;

	Set.iPrint= 0;			/*0:EDITOR,1:Printer,2:Bardode*/
	Set.iSpeed= 5;			/* 9600 */
	Set.iParity= 0;			/* 0:NONE,1:ODD,2:EVEN */
	Set.iData1= 1;			/* 0:7,1:8 */
	Set.iData2= 0;			/* 0:XON/XOF,1:DSR/DTR */
	Set.iStop= 0;
	Set.iConnect= 1;		/* 0:RS-232C,1:RS-422 */
	Set.iPlcType= 1;		/* 0:Universal,1:Fx-Seriase */
	Set.LcdReverseOn= 0;
/*	data= MakeCheckDigit(0x45fcd500);*/


/*	FontSet();*/

	while(1){
#ifdef	OLD
		mp = (T_MAIL *)TakeMail();
		mp->mcmd =1;
		mp->mcod =i;
		SendMail(T_DISPANALYSIS,(char *)mp);
#endif
		Delay(1000);
		i++;
	}

}
extern	char	AlarmData[256];
void	FileTask( STTFrm* pSTT )
{
	T_MAIL	*mp;
	int		ret;
	int		i,j;
	_LINE_INFO	param;
	_RECTANGLE_INFO	param1;
	char	dsp_buff[48];
	RTC_DATA SetTimeData;
	DEV_DATA	DevInfo;
#ifdef	OLD
	ClearDispBuff(2);
	OpenWindow(2,70,80);
	SetStartPos(2,150,0);
	i = 0;
/*	AreaRevers(0,0,69,99);*/
/*	AreaRevers(0,0,99,47);*/
	param1.iBackColor= T_WHITE;
	param1.iForeColor= T_WHITE;
	param1.iLineColor= 255;
	param1.iLineStyle= 1;
	param1.iPattern= 0;
	param.iLineColor= 255;
	param.iLineStyle= 1;
/*	LineOut( 0, 40, 69, 40, &param );*/
	RectAngleOut(0,0,69,79,&param1);
#endif
	j= 0;
	while(1){
		ret = KeyWait();
		if(ret != 0){
			if(j == 0){
				DevInfo.DevFlag= DEVICE_BIT;
				DevInfo.DevName[0]= 'Y';
				DevInfo.DevName[1]= 0;
				DevInfo.DevAddress= 1;
				DevInfo.DevCnt= 1;
				DevInfo.DevData= &dsp_buff[0];
				dsp_buff[0]= 1;
				PLCWrite(&DevInfo);
			}else{
				DevInfo.DevFlag= DEVICE_BIT;
				DevInfo.DevName[0]= 'Y';
				DevInfo.DevName[1]= 0;
				DevInfo.DevAddress= 1;
				DevInfo.DevCnt= 1;
				DevInfo.DevData= &dsp_buff[0];
				dsp_buff[0]= 0;
				PLCWrite(&DevInfo);
			}
			j= (j+1)%2;
		}

#ifdef	OLD
		sprintf(dsp_buff,"%2d",ret);
		DotTextOut(0, i*16,dsp_buff,1,1,T_REPLACE,3,0);
		if(ret != 0){
#ifdef	OLD
			dsp_buff[0]= (char)ret;
			WriteDev.DevFlag = 1;
			WriteDev.DevName[0] = 'D';
			WriteDev.DevName[1] = 0;
			WriteDev.DevAddress = 200;
			WriteDev.DevCnt = 1;
			WriteDev.DevData = (char *)&dsp_buff[0];
			PLCWrite(&WriteDev);
#else
			if(ret == 1){		/* Open */
#ifndef	OLD
				SetTimeData.year= 3;
				SetTimeData.mon= 2;
				SetTimeData.day= 17;
				SetTimeData.hour= 10;
				SetTimeData.min= 0;
				SetTimeData.sec= 0;	
				SetTimeData.week= 6;
				DateTimeSet(&SetTimeData,0);
#endif
				mp= (T_MAIL *)TakeMail();
				mp->mcmd= 1;	/* Open */
				mp->mcod= 1;
				mp->mpec= 1;
				SendMail(T_MSG_TASK,(char *)mp);
				
				mp= (T_MAIL *)TakeMail();
				mp->mcmd= 2;	/* Message */
				mp->mcod= 1;
				mp->mext= 14;
				memcpy(mp->mbuf,"\xb0\xb1\xb0\xb2\xb0\xb3\xb0\xb4\xb0\xb5\xb0\xb6\xb0\xb7",14);
				SendMail(T_MSG_TASK,(char *)mp);
				mp= (T_MAIL *)TakeMail();
				mp->mcmd= 2;	/* Message */
				mp->mcod= 2;
				mp->mext= 40;
				memcpy(mp->mbuf,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ9999",40);
				SendMail(T_MSG_TASK,(char *)mp);
			}
			if(ret == 60){
				mp= (T_MAIL *)TakeMail();
				mp->mcmd= 3;	/* Delete */
				mp->mcod= 2;
				SendMail(T_MSG_TASK,(char *)mp);
			}
#endif
		}
#endif
		i= (i+ 1) % 2;
	}
}
#ifdef	OLD
	char	wbuff[1024+12];
	char	rbuff[512];
#endif

unsigned char	bMapData[5][8];

extern	int		BoardRateFlag;		/* 0:9600.7.E,1:38400.8.E,2:19200.8.E,3:9600.8.E,4:BarCode,5:Printer */
extern	int		loopScreen,loopProj,loopPc;
extern	void	SystemDevEntry( void );
extern	int		PlcKansiFlag;

void	DispAnalysis( STTFrm* pSTT )
{
	int		i,j;
	int		LoopCnt;
	int		sIdx,flag,idx;
	unsigned	NewRec;
	char	dsp_buff[64];
	_RECTANGLE_INFO	param1;
	_LINE_INFO	param;
	DEV_DATA	DevInfo;
	int		work;

	ClearDispBuff(1);
	init_filesystem();

	DeviceCnt= 0;
	memset(DeviceDataHed,0,sizeof(DeviceDataHed));
	j= 0;
	DeviceDataHed[j].DevFlag = DEVICE_WORD;
	DeviceDataHed[j].DevName[0] = 'D';
	DeviceDataHed[j].DevName[1] = 0;
	DeviceDataHed[j].DevAddress = 100;
	DeviceDataHed[j].DevCnt = 1;
	DeviceDataHed[j].DevData = &DeviceData[2];
	j++;
	DeviceDataHed[j].DevFlag = DEVICE_WORD;
	DeviceDataHed[j].DevName[0] = 'T';
	DeviceDataHed[j].DevName[1] = 0;
	DeviceDataHed[j].DevAddress = 0;
	DeviceDataHed[j].DevCnt = 1;
	DeviceDataHed[j].DevData = &DeviceData[4];
	j++;
	DeviceDataHed[j].DevFlag = DEVICE_WORD;
	DeviceDataHed[j].DevName[0] = 'T';
	DeviceDataHed[j].DevName[1] = 'S';
	DeviceDataHed[j].DevAddress = 0;
	DeviceDataHed[j].DevCnt = 1;
	DeviceDataHed[j].DevData = &DeviceData[6];
	j++;
	DeviceDataHed[j].DevFlag = DEVICE_BIT;
	DeviceDataHed[j].DevName[0] = 'T';
	DeviceDataHed[j].DevName[1] = 0;
	DeviceDataHed[j].DevAddress = 0;
	DeviceDataHed[j].DevCnt = 1;
	DeviceDataHed[j].DevData = &DeviceData[8];
	j++;
	DeviceDataHed[j].DevFlag = DEVICE_BIT;
	DeviceDataHed[j].DevName[0] = 'T';
	DeviceDataHed[j].DevName[1] = 'R';
	DeviceDataHed[j].DevAddress = 0;
	DeviceDataHed[j].DevCnt = 1;
	DeviceDataHed[j].DevData = &DeviceData[9];
	j++;
	DeviceCnt= j;

#ifdef	OLD
	memset(&CommonArea,0,sizeof(CommonArea));
	CommonArea.SystemDev.Barcode_Dev.DevName[0]= 'D';
	CommonArea.SystemDev.Barcode_Dev.DevName[1]= 0;
	CommonArea.SystemDev.Barcode_Dev.DevAdd= 10;
	CommonArea.SystemDev.Barcode_Dev.DevCnt= 6;
	/****************************************************/
	/*	Alarm History Device Entry						*/
	/****************************************************/
	CommonArea.SystemDev.AlarmSetFlag= 1;
	CommonArea.SystemDev.Alarm_Dev.DevName[0]= 'X';
	CommonArea.SystemDev.Alarm_Dev.DevName[1]= 0;
	CommonArea.SystemDev.Alarm_Dev.DevAdd= 0;

	CommonArea.SystemDev.Alarm_Dev.DevCnt= 5;
	CommonArea.SystemDev.Alarm_DevErase.DevName[0]= 'X';
	CommonArea.SystemDev.Alarm_DevErase.DevName[1]= 0;
	CommonArea.SystemDev.Alarm_DevErase.DevAdd= 6;
	CommonArea.SystemDev.Alarm_DevErase.DevCnt= 1;

	CommonArea.SystemDev.Alarm_DevStore.DevName[0]= 0;
	CommonArea.SystemDev.Alarm_DevStore.DevName[1]= 0;
	CommonArea.SystemDev.Alarm_DevStore.DevAdd= 101;
	CommonArea.SystemDev.Alarm_DevStore.DevCnt= 1;
	CommonArea.SystemDev.Alarm_Time= 1;
	/****************************************************/
	/*	Observe Device Entry							*/
	/****************************************************/
	CommonArea.SystemDev.Observe_Proj_Cnt= 0;
	CommonArea.SystemDev.Observe_Screen_Cnt= 1;
	CommonArea.SystemDev.Observe_Screen_Dev[0].DevName1[0]= 'X';
	CommonArea.SystemDev.Observe_Screen_Dev[0].DevName1[1]= 0;
	CommonArea.SystemDev.Observe_Screen_Dev[0].DevAdd1= 2;
	CommonArea.SystemDev.Observe_Screen_Dev[0].Dev1Inf= 1;
	CommonArea.SystemDev.Observe_Screen_Dev[0].DevName2[0]= 0;
	CommonArea.SystemDev.Observe_Screen_Dev[0].DevName2[1]= 0;
	CommonArea.SystemDev.Observe_Screen_Dev[0].DevAdd2= 4;
	CommonArea.SystemDev.Observe_Screen_Dev[0].Dev2Inf= 1;
	CommonArea.SystemDev.Observe_Screen_Dev[0].Action= 5;
	CommonArea.SystemDev.Observe_Screen_Dev[0].Condition= 0;
	CommonArea.SystemDev.Observe_Screen_Dev[0].DevName3[0]= 'D';
	CommonArea.SystemDev.Observe_Screen_Dev[0].DevName3[1]= 0;
	CommonArea.SystemDev.Observe_Screen_Dev[0].DevAdd3= 101;
	CommonArea.SystemDev.Observe_Screen_Dev[0].point= 3;
	CommonArea.SystemDev.Observe_Screen_Dev[0].FixData= 15;
	CommonArea.SystemDev.Observe_Screen_Dev[0].MoveType= 0;

	CommonArea.SystemDev.Observe_Screen_Dev[0].DevName4[0]= 'D';
	CommonArea.SystemDev.Observe_Screen_Dev[0].DevName4[1]= 0;
	CommonArea.SystemDev.Observe_Screen_Dev[0].DevAdd4= 100;

	/* D100��ǂݍ��� */
	j= DeviceCnt;
	DeviceDataHed[j].DevFlag = DEVICE_WORD;
	DeviceDataHed[j].DevName[0] = 'D';
	DeviceDataHed[j].DevName[1] = 0;
	DeviceDataHed[j].DevAddress = 100;
	DeviceDataHed[j].DevCnt = 4;
	DeviceDataHed[j].DevData = &DeviceData[0];
	DeviceCnt += 4;

	/****************************************************/
	/*	Floating Alarm Entry							*/
	/****************************************************/
	CommonArea.SystemDev.fAlarm_Dev.DevName[0]= 'X';
	CommonArea.SystemDev.fAlarm_Dev.DevName[1]= 0;
	CommonArea.SystemDev.fAlarm_Dev.DevAdd= 16;
	CommonArea.SystemDev.fAlarm_Dev.DevCnt= 2;
	CommonArea.SystemDev.fAlarm_Time= 0;
	/****************************************************/
	/*	Recipe Entry									*/
	CommonArea.SystemDev.RecipCnt= 6;
	CommonArea.SystemDev.Recip_Read_DevName[0]= 'X';
	CommonArea.SystemDev.Recip_Read_DevName[1]= 0;
	CommonArea.SystemDev.Recip_Read_DevAdd= 0;
	CommonArea.SystemDev.RecipReadFlag= -1;
	CommonArea.SystemDev.Recip_Write_DevName[0]= 'X';
	CommonArea.SystemDev.Recip_Write_DevName[1]= 0;
	CommonArea.SystemDev.Recip_Write_DevAdd= 1;
	CommonArea.SystemDev.RecipWriteFlag= 1;			/* ON Triger */
	CommonArea.SystemDev.Recip_Dev[0].DevName[0] = 'D';
	CommonArea.SystemDev.Recip_Dev[0].DevName[1] = 0;
	CommonArea.SystemDev.Recip_Dev[0].DevAdd = 100;
	for(i= 0;i < 12; i++){
		InDevice[i*2]= i+ 1;
		InDevice[i*2+ 1]= 0;
	}
	/****************************************************/
	/*	Read Device Entry								*/
	/****************************************************/
	CommonArea.SystemDev.Read_Dev.DevName[0]= 'D';
	CommonArea.SystemDev.Read_Dev.DevName[1]= 0;
	CommonArea.SystemDev.Read_Dev.DevAdd= 0;
	CommonArea.SystemDev.Read_Dev.DevCnt= 2;
	/****************************************************/
	/*	Stored Memory Entry								*/
	/****************************************************/
	CommonArea.SystemDev.StoredMemCnt= 1;
	CommonArea.SystemDev.StoredInfo[0].Kind= 1;
	CommonArea.SystemDev.StoredInfo[0].St.TrandeInfo.TrandTime= 2;
	CommonArea.SystemDev.StoredInfo[0].St.TrandeInfo.Trand_Dev.DevName[0]= 'G';
	CommonArea.SystemDev.StoredInfo[0].St.TrandeInfo.Trand_Dev.DevName[1]= 'D';
	CommonArea.SystemDev.StoredInfo[0].St.TrandeInfo.Trand_Dev.DevName[2]= 0;
	CommonArea.SystemDev.StoredInfo[0].St.TrandeInfo.Trand_Dev.DevAdd= 0;
	CommonArea.SystemDev.StoredInfo[0].St.TrandeInfo.Trand_Dev.DevCnt= 1;
	/****************************************************/
	i= 0;
	j= DeviceCnt;
	for(i = 0; i < 15; i++,j++){
		DeviceDataHed[j].DevFlag = DEVICE_BIT;
		DeviceDataHed[j].DevName[0] = 'X';
		DeviceDataHed[j].DevName[1] = 0;
		DeviceDataHed[j].DevAddress = i;
		DeviceDataHed[j].DevCnt = 1;
		DeviceDataHed[j].DevData = &DeviceData[i];
	}
	for(i = 0; i < 6; i++, j++){
		DeviceDataHed[j].DevFlag = DEVICE_WORD;
		DeviceDataHed[j].DevName[0] = 'D';
		DeviceDataHed[j].DevName[1] = 0;
		DeviceDataHed[j].DevAddress = 8013+i;
		DeviceDataHed[j].DevCnt = 1;
		DeviceDataHed[j].DevData = &DeviceData[(i* 2)+15];
	}
	/* D100��ǂݍ��� */
	DeviceDataHed[j].DevFlag = DEVICE_WORD;
	DeviceDataHed[j].DevName[0] = 'D';
	DeviceDataHed[j].DevName[1] = 0;
	DeviceDataHed[j].DevAddress = 100;
	DeviceDataHed[j].DevCnt = 1;
	DeviceDataHed[j].DevData = &DeviceData[i+15];
	DeviceCnt= j+ 1;
	DeviceDataHed[j].DevFlag = DEVICE_WORD;
	DeviceDataHed[j].DevName[0] = 'D';
	DeviceDataHed[j].DevName[1] = 0;
	DeviceDataHed[j].DevAddress = 101;
	DeviceDataHed[j].DevCnt = 1;
	DeviceDataHed[j].DevData = &DeviceData[22];
	DeviceCnt++;
#endif
#ifdef	OLD
	j= DeviceCnt;
	for(i = 0; i < 1; i++,j++){
		DeviceDataHed[j].DevFlag = DEVICE_BIT;
		DeviceDataHed[j].DevName[0] = 'X';
		DeviceDataHed[j].DevName[1] = 0;
		DeviceDataHed[j].DevAddress = i;
		DeviceDataHed[j].DevCnt = 1;
		DeviceDataHed[j].DevData = &DeviceData[0];
	}
	DeviceCnt=1;
	DeviceDataHed[j].DevFlag = DEVICE_WORD;
	DeviceDataHed[j].DevName[0] = 'D';
	DeviceDataHed[j].DevName[1] = 0;
	DeviceDataHed[j].DevAddress = 100;
	DeviceDataHed[j].DevCnt = 1;
	DeviceDataHed[j].DevData = &DeviceData[1];
	DeviceCnt++;
#endif
	SystemDevEntry();
	OnSignal(S_SCREEN,1);

	DrawLcdBank1();
	Set.iBuzzer = 1;
	LoopCnt= 0;
	sIdx= CommonArea.EntryIdx;
	flag= -1;

	while(1){
		NewRec= _TimeMSec;
#ifdef	OLD
		DevInfo.DevFlag= DEVICE_BIT;
		DevInfo.DevName[0]= 'G';
		DevInfo.DevName[1]= 'B';
		DevInfo.DevAddress= 10;
		DevInfo.DevCnt= 3;
		DevInfo.DevData= &dsp_buff[0];
		dsp_buff[0]= 1;
		dsp_buff[1]= 2;
		dsp_buff[2]= 3;
		dsp_buff[3]= 4;
		dsp_buff[4]= 5;
		dsp_buff[5]= 6;
		PLCWrite(&DevInfo);
		DevInfo.DevAddress= 10;
		PLCRead(&DevInfo);
#endif
#ifndef	OLD
		for(i = 0; i < 15; i++){
			if(DeviceData[i] == 0){
				dsp_buff[i]= '0';
			}else{
				dsp_buff[i]= '1';
			}
		}
		dsp_buff[i]= 0;
/*		DotTextOut(0,0,dsp_buff,1,5,T_REPLACE,3,0);*/
		sprintf(dsp_buff,"%02d",DeviceData[15]);
/*		DotTextOut(0,16,dsp_buff,1,1,T_REPLACE,3,0);*/
		LoopCnt++;
		sprintf(dsp_buff,"%4d",LoopCnt/10);
/*		DotTextOut(32,16,dsp_buff,1,1,T_REPLACE,3,0);*/
		sprintf(dsp_buff,"%4d",LoopCnt);
/*		DotTextOut(160,16,dsp_buff,1,1,T_REPLACE,3,0);*/
		sprintf(dsp_buff,"%4d",_TimeMSec- NewRec);
/*		DotTextOut(96,16,dsp_buff,1,1,T_REPLACE,3,0);*/

		sprintf(dsp_buff,"%02d/%02d/%02d %d %02d:%02d:%02d",
			SystemTime.year,
			SystemTime.mon,
			SystemTime.day,
			SystemTime.week,
			SystemTime.hour,
			SystemTime.min,
			SystemTime.sec);
/*		DotTextOut(0,32,dsp_buff,1,1,T_REPLACE,3,0);*/
/*		sprintf(dsp_buff,"P=%d(%d)",CommonArea.BatteryLevel,AutoBrateFlag);*/
/*		DotTextOut(88,0,dsp_buff,1,1,T_REPLACE,3,0);*/

#ifdef	OLD
		idx= CommonArea.EntryIdx- 1;
		if(idx < 0){
			idx= 0;
		}
		if((CommonArea.EntryIdx != sIdx) || (CommonArea.AlarmHistRec[idx].flag != flag)){
			sIdx= CommonArea.EntryIdx;
			flag= CommonArea.AlarmHistRec[idx].flag;
			sprintf(dsp_buff,"%02d/%02d/%02d %02d:%02d:%02d-",
				CommonArea.AlarmHistRec[idx].s_year,
				CommonArea.AlarmHistRec[idx].s_mon,
				CommonArea.AlarmHistRec[idx].s_day,
				CommonArea.AlarmHistRec[idx].s_hour,
				CommonArea.AlarmHistRec[idx].s_min,
				CommonArea.AlarmHistRec[idx].s_sec);
			DotTextOut(0,48,dsp_buff,1,1,T_REPLACE,3,0);
			sprintf(dsp_buff,"%02d/%02d/%02d %02d:%02d:%02d %03d",
				CommonArea.AlarmHistRec[idx].e_year,
				CommonArea.AlarmHistRec[idx].e_mon,
				CommonArea.AlarmHistRec[idx].e_day,
				CommonArea.AlarmHistRec[idx].e_hour,
				CommonArea.AlarmHistRec[idx].e_min,
				CommonArea.AlarmHistRec[idx].e_sec,
				CommonArea.AlarmHistRec[idx].Cnt);
			DotTextOut(0,64,dsp_buff,1,1,T_REPLACE,3,0);
		}
#endif
#else
		if(flag != DeviceData[0]){
/*			flag = LoopCnt++ % 2;*/
			flag = DeviceData[0];
			if(flag == 0){
				AreaClear(83,0,115,32,0);
				AreaClear(123,0,155,32,0);
				AreaClear(163,0,195,32,0);
				AreaClear(3,35,35,67,0);
				AreaClear(43,35,75,67,0);
				AreaClear(83,35,115,67,0);
				AreaClear(123,35,155,67,0);
				AreaClear(163,35,195,67,0);
			}
			param1.iBackColor= T_WHITE;
			param1.iForeColor= T_WHITE;
			param1.iLineColor= 1;
			param1.iLineStyle= 1;
			if(flag == 0){
				param1.iPattern= 0;
			}else{
				param1.iPattern= 7;
			}
			RectAngleOut(83,0,115,32,&param1);
			RectAngleOut(123,0,155,32,&param1);
			RectAngleOut(163,0,195,32,&param1);
			RectAngleOut(3,35,35,67,&param1);
			RectAngleOut(43,35,75,67,&param1);
			RectAngleOut(83,35,115,67,&param1);
			RectAngleOut(123,35,155,67,&param1);
			RectAngleOut(163,35,195,67,&param1);
		}
		sprintf(dsp_buff,"%4d",_TimeMSec- NewRec);
		DotTextOut(0,0,dsp_buff,1,1,T_REPLACE,3,0);
		sprintf(dsp_buff,"%3d",CommonArea.ReadDevData[0]);
		DotTextOut(48,0,dsp_buff,1,1,T_REPLACE,3,0);
#endif
#ifdef	OLD
		idx= CommonArea.SystemDev.StoredInfo[0].St.TrandeInfo.TrandStartIdx;
		for(i = 0; i < 10; i++){
			work= CommonArea.StordMem[0].TrandeData[0][idx];
			sprintf(&dsp_buff[i*3],"%02d,",work);
			idx++;
			if(idx >= 50){
				idx= 0;
			}
		}
		DotTextOut(0,0,dsp_buff,1,1,T_REPLACE,3,0);
		for(i = 0; i < 10; i++){
			work= CommonArea.StordMem[0].TrandeData[0][idx];
			sprintf(&dsp_buff[i*3],"%02d,",work);
			idx++;
			if(idx >= 50){
				idx= 0;
			}
		}
		DotTextOut(0,16,dsp_buff,1,1,T_REPLACE,0,3);
		for(i = 0; i < 10; i++){
			work= CommonArea.StordMem[0].TrandeData[0][idx];
			sprintf(&dsp_buff[i*3],"%02d,",work);
			idx++;
			if(idx >= 50){
				idx= 0;
			}
		}
		DotTextOut(0,32,dsp_buff,1,1,T_REPLACE,0,3);
		for(i = 0; i < 10; i++){
			work= CommonArea.StordMem[0].TrandeData[0][idx];
			sprintf(&dsp_buff[i*3],"%02d,",work);
			idx++;
			if(idx >= 50){
				idx= 0;
			}
		}
		DotTextOut(0,48,dsp_buff,1,1,T_REPLACE,0,3);
		for(i = 0; i < 10; i++){
			work= CommonArea.StordMem[0].TrandeData[0][idx];
			sprintf(&dsp_buff[i*3],"%02d,",work);
			idx++;
			if(idx >= 50){
				idx= 0;
			}
		}
		DotTextOut(0,64,dsp_buff,1,1,T_REPLACE,0,3);

		AreaClear(0,0,100,80,1);
		param.iLineColor= 0;
		param.iLineStyle= 1;
		LineOut( 2, 0, 2, 0, &param );
		LineOut( 2, 2, 3, 2, &param );
		LineOut( 2, 4, 4, 4, &param );
		LineOut( 2, 6, 5, 6, &param );
		LineOut( 2, 8, 6, 8, &param );
		LineOut( 2, 10, 7, 10, &param );
		LineOut( 2, 12, 8, 12, &param );
		LineOut( 2, 14, 9, 14, &param );
		LineOut( 3, 16, 3, 16, &param );
		LineOut( 3, 18, 4, 18, &param );
		LineOut( 3, 20, 5, 20, &param );
		LineOut( 3, 22, 6, 22, &param );
		LineOut( 3, 24, 7, 24, &param );
		LineOut( 3, 26, 8, 26, &param );
		LineOut( 3, 28, 9, 28, &param );
		LineOut( 4, 30, 4, 30, &param );
		LineOut( 4, 32, 5, 32, &param );
		LineOut( 4, 34, 6, 34, &param );
		LineOut( 4, 36, 7, 36, &param );
		LineOut( 4, 38, 8, 38, &param );
		LineOut( 4, 40, 9, 40, &param );

		LineOut( 90, 48, 91, 48, &param );
		LineOut( 1, 46, 1, 46, &param );
		LineOut( 1, 48, 2, 48, &param );
		LineOut( 1, 50, 3, 50, &param );
		LineOut( 1, 52, 4, 52, &param );
		LineOut( 1, 54, 5, 54, &param );
		LineOut( 1, 56, 6, 56, &param );
		LineOut( 1, 58, 7, 58, &param );
		LineOut( 1, 60, 8, 60, &param );
		LineOut( 1, 62, 9, 62, &param );

		sprintf(dsp_buff,"D100=%d",DeviceData[1]+DeviceData[2]*256);
		DotTextOut(0,0,dsp_buff,1,1,T_REPLACE,3,0);
		sprintf(dsp_buff,"X0=%d",DeviceData[0]);
		DotTextOut(0,16,dsp_buff,1,1,T_REPLACE,3,0);
		DotTextOut(0,0,"\xb0\xb1",1,1,T_REPLACE,3,0);
		DotTextOut(0,16,"\xb0\xb1",2,1,T_REPLACE,3,0);
		DotTextOut(0,32,"\xb0\xb1",3,1,T_REPLACE,3,0);
		DotTextOut(0,48,"\xb0\xb1",4,1,T_REPLACE,3,0);
		DotTextOut(0,64,"\xb0\xb1",6,1,T_REPLACE,3,0);
		DotTextOut(100,0,"\xb0\xb1",8,1,T_REPLACE,3,0);
#endif
		CircleParam.iBackColor= 0;
		CircleParam.iForeColor= 255;
		CircleParam.iLineColor= 255;
		CircleParam.iPattern= 8;
		DrawDaen(37, 44, 28, 28, &CircleParam);

		DrawLcdBank1();

		if((NewRec+ 300) > _TimeMSec){
			Delay((NewRec+ 300) - _TimeMSec);
		}else{
			Delay(20);
		}
	}
}
/*************************************************************************/
/*	Aplication Proc */
/*************************************************************************/
void vCommentDataSet(int iNum, char *cDataBuffer, int *iColor, int *iLen)
{
}
void	AlarmHistSend( void )
{
}
void	AlarmListSend( void )
{
}
void	WindowDisplay_Task( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
void	AlarmDetail_Task( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
void	Classification_Task( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
void GetWordDevice(unsigned int iFOffsetVal, unsigned int iSOffsetVal, char* cTempBuff)
{
}
