/******************************************************************************
*                Copyright(c)World Digital 2001,2002
*******************************************************************************
* System             :SerialComm
* FileName           :CommThread.cpp
* Summary            :Serial�ʐM�֘A�֐���?
* Programmer         :�S�ωp
* Create Date        :2002/02/26
******************************************************************************/
#include "stdafx.h"
#include "CommThread.h"

/* CQueue Constructor */
CQueue::CQueue()
{
	Clear();
}

/******************************************************************************
'Procedure          :Clear
'Summary            :Queue������
'Parameters         :�Ȃ�
'Return Value       :�Ȃ�
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
void CQueue::Clear()
{
	m_iHead = m_iTail = 0;
	memset(buff, 0, BUFF_SIZE);
}

/******************************************************************************
'Procedure          :GetSize
'Summary            :Queue���̃f??�T�C�Y�����߂�
'Parameters         :�Ȃ�
'Return Value       :�f??�T�C�Y
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int CQueue::GetSize()
{
	return (m_iHead - m_iTail + BUFF_SIZE) % BUFF_SIZE;
}

/******************************************************************************
'Procedure          :PutByte
'Summary            :Queue�ւP�o�C�g������
'Parameters         :�f??
'Return Value       :TRUE?FALSE
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
BOOL CQueue::PutByte(BYTE b)
{
	/* Queue Full*/
	if (GetSize() == (BUFF_SIZE-1)) return FALSE;
	
	buff[m_iHead++] = b;
	m_iHead %= BUFF_SIZE;
	return TRUE;
}

/******************************************************************************
'Procedure          :GetByte
'Summary            :Queue����P�o�C�g�Ǎ���
'Parameters         :�Ǎ��ݐ�?�C��??
'Return Value       :TRUE?FALSE
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
BOOL CQueue::GetByte(BYTE* pb)
{
	if (GetSize() == 0) return FALSE;

	*pb = buff[m_iTail++];
	m_iTail %= BUFF_SIZE;
	return TRUE;
}

/******************************************************************************
'Procedure          :OpenPort
'Summary            :CommPort Open
'Parameters         :(I)sPortName :COM1,COM2.....
'                    (I)dwBaud    :2400,4800,9600,19200,38400....
'                    (I)wPortID   :����??�gOpen������ID
'                                  COM1->0,COM2->1..... 
'Return Value       :TRUE?FALSE
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
/*
 The COMMTIMEOUTS structure is used in the SetCommTimeouts and GetCommTimeouts
functions to set and query the time-out parameters for a communications device. 
The parameters determine the behavior of ReadFile, WriteFile, ReadFileEx, and 
WriteFileEx operations on the device. 

typedef struct _COMMTIMEOUTS {  
    DWORD ReadIntervalTimeout; 
    DWORD ReadTotalTimeoutMultiplier; 
    DWORD ReadTotalTimeoutConstant; 
    DWORD WriteTotalTimeoutMultiplier; 
    DWORD WriteTotalTimeoutConstant; 
} COMMTIMEOUTS,*LPCOMMTIMEOUTS; 

 The DCB structure defines the control setting for a serial communications device. 

typedef struct _DCB { // dcb 
    DWORD DCBlength;           // sizeof(DCB) 
    DWORD BaudRate;            // current baud rate 
    DWORD fBinary: 1;          // binary mode, no EOF check 
    DWORD fParity: 1;          // enable parity checking 
    DWORD fOutxCtsFlow:1;      // CTS output flow control 
    DWORD fOutxDsrFlow:1;      // DSR output flow control 
    DWORD fDtrControl:2;       // DTR flow control type 
    DWORD fDsrSensitivity:1;   // DSR sensitivity 
    DWORD fTXContinueOnXoff:1; // XOFF continues Tx 
    DWORD fOutX: 1;            // XON/XOFF out flow control 
    DWORD fInX: 1;             // XON/XOFF in flow control 
    DWORD fErrorChar: 1;       // enable error replacement 
    DWORD fNull: 1;            // enable null stripping 
    DWORD fRtsControl:2;       // RTS flow control 
    DWORD fAbortOnError:1;     // abort reads/writes on error 
    DWORD fDummy2:17;          // reserved 
    WORD wReserved;            // not currently used 
    WORD XonLim;               // transmit XON threshold 
    WORD XoffLim;              // transmit XOFF threshold 
    BYTE ByteSize;             // number of bits/byte, 4-8 
    BYTE Parity;               // 0-4=no,odd,even,mark,space 
    BYTE StopBits;             // 0,1,2 = 1, 1.5, 2 
    char XonChar;              // Tx and Rx XON character 
    char XoffChar;             // Tx and Rx XOFF character 
    char ErrorChar;            // error replacement character 
    char EofChar;              // end of input character 
    char EvtChar;              // received event character 
    WORD wReserved1;           // reserved; do not use 
} DCB; 

 The OVERLAPPED structure contains information used in asynchronous input and output (I/O). 

typedef struct _OVERLAPPED { 
    DWORD  Internal; 
    DWORD  InternalHigh; 
    DWORD  Offset; 
    DWORD  OffsetHigh; 
    HANDLE hEvent; 
} OVERLAPPED; 

*/
BOOL CCommThread::OpenPort(CString sPortName, DWORD dwBaud, WORD wParity, WORD wData, WORD wPortID)
{
	COMMTIMEOUTS	timeouts;   /* for Timeout Value*/
	DCB				dcb;        /* for Serial Port*/
	DWORD			dwThreadID; /* Thread ID*/
	
	/* ����Open*/
	if(m_bConnected==TRUE && m_wPortID==wPortID ){
		ClosePort();
		Sleep(1000);
	}
	/* �ϐ��ݒ�*/
	m_bConnected = FALSE;
	m_wPortID	= wPortID; /* COM1-> 1, COM2->2,,,,,*/
	/* overlapped structure */
	m_osRead.Offset = 0;
	m_osRead.OffsetHigh = 0;
	if (! (m_osRead.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL))){	
		return FALSE;
	}
	m_osWrite.Offset = 0;
	m_osWrite.OffsetHigh = 0;
	if (! (m_osWrite.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL))){
		return FALSE;
	}
	/* Port�I?�v��*/
	m_sPortName = sPortName;
	m_hComm = CreateFile( m_sPortName, 
		GENERIC_READ | GENERIC_WRITE, 0, NULL,
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED, 
		NULL);
	if (m_hComm == (HANDLE) -1) return FALSE;

	/* EV_RXCHAR event�ݒ� */
	SetCommMask( m_hComm, EV_RXCHAR);	
	/* InQueue, OutQueue�T�C�Y�ݒ�*/
	SetupComm( m_hComm, 4096, 4096);	
	/* Port��InQueue, OutQueue������*/
	PurgeComm( m_hComm,					
		PURGE_TXABORT | PURGE_TXCLEAR | PURGE_RXABORT | PURGE_RXCLEAR);
	/* timeout*/ 
	timeouts.ReadIntervalTimeout = 0xFFFFFFFF;
	timeouts.ReadTotalTimeoutMultiplier = 0;
	timeouts.ReadTotalTimeoutConstant = 0;
//	timeouts.WriteTotalTimeoutMultiplier = 2*CBR_9600 / dwBaud;
	timeouts.WriteTotalTimeoutMultiplier = 0;
	timeouts.WriteTotalTimeoutConstant = 0;
	SetCommTimeouts( m_hComm, &timeouts);
	/* dcb */
	dcb.DCBlength = sizeof(DCB);
	GetCommState( m_hComm, &dcb);/*���݂�DCB��� Read */
	/*-----------------------------------------------------------------------*/
	dcb.BaudRate = dwBaud;
	dcb.ByteSize = (unsigned char)wData;
	dcb.Parity = (unsigned char)(wParity & 0x00ff);			//2009.09.04
	dcb.StopBits = (unsigned char)(wParity & 0xff00) >> 8;	//2009.09.04
/*	dcb.fBinary = 1;*/
/*	dcb.fOutxDsrFlow = 1;*/
/*	dcb.fDtrControl= TRUE;*/

	/*-----------------------------------------------------------------------*/
//	dcb.fInX = dcb.fOutX = 1;		/* Xon, Xoff*/
	dcb.fInX = dcb.fOutX = 0;		/* Xon, Xoff*/
	dcb.XonChar = ASCII_XON;
	dcb.XoffChar = ASCII_XOFF;
	dcb.XonLim = 100;
	dcb.XoffLim = 100;
	if (!SetCommState( m_hComm, &dcb))	return FALSE;
	
	/* Port�Ď�Thread����*/
	m_bConnected = TRUE;
	m_hThreadWatchComm = CreateThread( NULL, 0, 
		(LPTHREAD_START_ROUTINE)ThreadWatchComm, this, 0, &dwThreadID);
	if (! m_hThreadWatchComm){
		ClosePort();
		return FALSE;
	}

	return TRUE;
}

/******************************************************************************
'Procedure          :ClosePort
'Summary            :�ʐM??�gClose
'Parameters         :�Ȃ�
'Return Value       :�Ȃ�
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
void CCommThread::ClosePort()
{
	m_bConnected = FALSE;
	/* Event mask�폜*/
	SetCommMask( m_hComm, 0);
	/* �ʐMQueue������*/
	PurgeComm( m_hComm,					
		PURGE_TXABORT | PURGE_TXCLEAR | PURGE_RXABORT | PURGE_RXCLEAR);
	/* File Handle Close*/
	CloseHandle( m_hComm);
}

/******************************************************************************
'Procedure          :WriteComm
'Summary            :??�g�փf??���������݂܂��B
'Parameters         :pBuff - �������ރf??���������o�b�t?�ւ�?�C��?
'                   :nToWrite - �������ރo�C�g��
'Return Value       :���ۂɏ������񂾃o�C�g��
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
/*
The COMSTAT structure contains information about a communications device. 
This structure is filled by the ClearCommError function. 

typedef struct _COMSTAT { 
    DWORD fCtsHold : 1;   // Tx waiting for CTS signal 
    DWORD fDsrHold : 1;   // Tx waiting for DSR signal 
    DWORD fRlsdHold : 1;  // Tx waiting for RLSD signal 
    DWORD fXoffHold : 1;  // Tx waiting, XOFF char received 
    DWORD fXoffSent : 1;  // Tx waiting, XOFF char sent 
    DWORD fEof : 1;       // EOF character sent 
    DWORD fTxim : 1;      // character waiting for Tx 
    DWORD fReserved : 25; // reserved 
    DWORD cbInQue;        // bytes in input buffer 
    DWORD cbOutQue;       // bytes in output buffer 
} COMSTAT, *LPCOMSTAT; 

*/
DWORD CCommThread::WriteComm(BYTE *pBuff, DWORD nToWrite)
{
	DWORD	dwWritten, dwError, dwErrorFlags;
	COMSTAT	comstat;

	if (! WriteFile( m_hComm, pBuff, nToWrite, &dwWritten, &m_osWrite))	{	
		if (GetLastError() == ERROR_IO_PENDING){	
			/* timeout���ԕ�wait*/
			while (! GetOverlappedResult( m_hComm, &m_osWrite, &dwWritten, TRUE)){
				dwError = GetLastError();
				if (dwError != ERROR_IO_INCOMPLETE){	
					ClearCommError( m_hComm, &dwErrorFlags, &comstat);
					break;
				}
			}
//DTR�L���ɂ�������?�C?�A�E�g��̏o��
//			WriteFile( m_hComm, pBuff, nToWrite, &dwWritten, &m_osWrite);	
		}else{
			dwWritten = 0;
			ClearCommError( m_hComm, &dwErrorFlags, &comstat);
		}
	}
	return dwWritten;
}

/******************************************************************************
'Procedure          :ReadComm
'Summary            :�ʐM??�g�Ǎ���
'Parameters         :pBuff   - �o�b�t?�ւ�?�C��?�A
'                   :nToRead - �ǂݎ��o�C�g��
'Return Value       :���ۂɓǂݎ��ꂽ�o�C�g��
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
DWORD CCommThread::ReadComm(BYTE *pBuff, DWORD nToRead)
{
	DWORD	dwRead, dwError, dwErrorFlags;
	COMSTAT	comstat;
	
	ClearCommError( m_hComm, &dwErrorFlags, &comstat);
	/* input Queue�̃f??�T�C�Y*/
	dwRead = comstat.cbInQue;
	if (dwRead > 0){	
		if (! ReadFile( m_hComm, pBuff, nToRead, &dwRead, &m_osRead)){	
			if (GetLastError() == ERROR_IO_PENDING){	
				/* Input����data������ꍇtimeout���ԕ�wait*/
				while (! GetOverlappedResult( m_hComm, &m_osRead, &dwRead, TRUE)){	
					dwError = GetLastError();
					if (dwError != ERROR_IO_INCOMPLETE){	
						ClearCommError( m_hComm, &dwErrorFlags, &comstat);
						break;
					}
				}
			}else{	
				dwRead = 0;
				ClearCommError( m_hComm, &dwErrorFlags, &comstat);
			}
		}
	}
	return dwRead;
}

/******************************************************************************
'Procedure          :SetWindowHandler
'Summary            :���b�Z?�W��M��Handle�ݒ�
'Parameters         :CommWndH(I):���b�Z?�W��MWindow��m_hWnd
'Return Value       :�Ȃ�
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
void CCommThread::SetWindowHandler(HWND CommWndH)
{
	 m_hCommWnd=CommWndH;
}

/******************************************************************************
'Procedure          :ThreadWatchComm
'Summary            :Port�Ď��AWM_COMM_READ���b�Z?�W���M
'Parameters         :�ʐM�pClass?�C��??
'Return Value       :TRUE?FALSE
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
DWORD	ThreadWatchComm(CCommThread* pComm)
{
	DWORD		dwEvent;
	OVERLAPPED	os;
	BOOL		bOk = TRUE;
	BYTE		buff[2048];	  
	DWORD		dwRead;	     
	
	/* Event,Overlapped structure�ݒ� */
	memset( &os, 0, sizeof(OVERLAPPED));
	if (! (os.hEvent = CreateEvent( NULL, TRUE, FALSE, NULL))){
		bOk = FALSE;
	}
	if (! SetCommMask( pComm->m_hComm, EV_RXCHAR)){
		bOk = FALSE;
	}
	if (! bOk){	
		AfxMessageBox("Error while creating ThreadWatchComm, " + pComm->m_sPortName);
		return FALSE;
	}
	/* Port�Ď���?�v*/
	while (pComm->m_bConnected){	
		dwEvent = 0;
		/* Port���烁�b�Z?�W����������܂ő҂�*/
		WaitCommEvent( pComm->m_hComm, &dwEvent, NULL);
		if ((dwEvent & EV_RXCHAR) == EV_RXCHAR){	
			do{	
				/* �f??�Ǎ���*/
				dwRead = pComm->ReadComm( buff, 2048);
				/* Queue Full����*/
				if (BUFF_SIZE - pComm->m_QueueRead.GetSize() > (int)dwRead){	
					for ( WORD i = 0; i < dwRead; i++)
					pComm->m_QueueRead.PutByte(buff[i]);
				}else{
					AfxMessageBox("m_QueueRead FULL!");
				}
			} while (dwRead);
			/*---------------------------------------------------------------*/
			/* �e�v���Z�X�փ��b�Z?�W���M*/
			::PostMessage(pComm->m_hCommWnd,WM_COMM_READ, pComm->m_wPortID, 0);
			/*---------------------------------------------------------------*/
		}
	}	
	CloseHandle( os.hEvent);
	pComm->m_hThreadWatchComm = NULL;
	return TRUE;
}

/*********************************** END OF FILE *****************************/