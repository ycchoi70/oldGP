void	SetFuntionMode(int *iScreenNo);
