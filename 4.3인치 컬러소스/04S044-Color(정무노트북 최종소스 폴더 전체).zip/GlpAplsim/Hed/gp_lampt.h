void	SetLamp_Func(int iDispOrder);
int	DrawLamp_Func(int mode,_LAMP_EVENT_TBL* LampDispEventTbl,int iDispOrder);
void	LampDispWatch(int iOrder);
void	LampDraw(int sX, int sY, int eX, int eY, int iLampNumber, int Flag, int iTagNumber, int iFrameColor, int iLampColor);
void DrawTriangle(short x1,short y1,short x2,short y2,short x3,short y3,short LineColor,short FarmeColor,short	iType);
void vTextPositionDisp(int *PointsX, int *PointsY, int *PointeX, int *PointeY, char * cDispData,int xbai,int ybai, int iColor, int iType);
