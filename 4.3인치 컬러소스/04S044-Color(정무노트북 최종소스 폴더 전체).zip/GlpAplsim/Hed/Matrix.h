#ifdef	MATRIX_PROC
	char	Jikyoku_Hex[2] ;
	int		Matrix_Mode ;
	int	LinkEstablish ;
	unsigned char BCC_DATA ;
	char	BCC_Check[2],BCC_Check2[3] ;
	int	DenubTimeoutMode;
	int	MatrixTimeoutCnt ;
	int	DenubTimeoutCnt;
	int	MatrixRetryCnt;
#else
	extern	char	Jikyoku_Hex[2] ;
	extern	int		Matrix_Mode ;
	extern	int	LinkEstablish ;
	extern	unsigned char BCC_DATA ;
	extern	char	BCC_Check[2],BCC_Check2[3] ;
	extern	int	DenubTimeoutMode;
	extern	int	MatrixTimeoutCnt ;
	extern	int	DenubTimeoutCnt;
	extern	int	MatrixRetryCnt;
#endif

void	MatrixTimeoutProc(void);
