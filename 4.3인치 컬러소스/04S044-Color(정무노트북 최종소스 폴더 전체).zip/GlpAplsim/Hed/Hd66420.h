/********************************************/
/*	HD66420 Register						*/
/********************************************/
#define	LCD_CONT1M	0x00C00000
#define	LCD_CONT2M	0x00C00011
#define	LCD_CONT1S	0x00C00022
#define	LCD_CONT2S	0x00C00033
#define	LCD_R0		0x00
#define	LCD_R1		0x01
#define	LCD_R2		0x02
#define	LCD_R3		0x03
#define	LCD_R4		0x04
#define	LCD_R5		0x05
#define	LCD_R6		0x06
#define	LCD_R7		0x07
#define	LCD_R8		0x08
#define	LCD_R9		0x09
#define	LCD_R10		0x0a
#define	LCD_R11		0x0b
#define	LCD_R12		0x0c
#define	LCD_R13		0x0d
#define	LCD_R14		0x0e
#define	LCD_R15		0x0f
#define	LCD_R16		0x10
