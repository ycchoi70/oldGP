void	SetAlarmHistory_Func (int iDispOrder);
int	DrawAlarmHistory_Func (_ALARM_HISTORY_EVENT_TBL* AlarmHistoryEventTbl,int iOrder);
void AlarmHistoryDispWatch(int iOrder);
void CommonFileSet(void);
int ProjectSet(void);		/* 20090610 */
void vHistoryDataSet(_ALARM_HISTORY_EVENT_TBL* AlarmHistoryEventTbl,int iNum, char *cDataBuffer, int iOrder);
void	vAlarmHistoryTimeSetting(_ALARM_HISTORY_EVENT_TBL* AlarmHistoryEventTbl,char* cReturnData,short iOnOffType, int iOrder,int iNum);

