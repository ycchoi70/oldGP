/* *******************************************************************************/
/*  �� �� �� : GPSTRUCT.H														*/
/*  ��    �� : ���� ����ü ����													*/
/*  �� �� �� : 2002�� 2�� 8�� (��)												*/
/*  �� �� �� : ȫ �� ��															*/
/*  ��    �� : (��) LC Tech														*/
/*  ��    �� : 																	*/
/* *******************************************************************************/
/* #define		ITITLEDISPTIME	5 */
//#define		Message1001		SET NUMBER IS INCORRECT.
//#define		Message1002		SET NUMBER IS INCORRECT.

/* *******************************************************************************/
/*  �� �� ü														             */
/* *******************************************************************************/

/*  #define */		/*  leesi */
#define		LINE_FORM	1					/* ȯ�漳�� Form Display Type */
#define		KEY_FORM	3					/* ȯ�漳�� Form Display Type */
#define		ARROW_FORM	4					/* ȯ�漳�� Form Display Type */

/*  �۾��� ��µǴ� ���� ���� ����ϴ� ����*/
#define		Line_1		2
#define		Line_2		22
#define		Line_3		42
#define		Line_4		62

#define		NLine_1		2
#define		NLine_2		25
#define		NLine_3		43
#define		NLine_4		61

/* Bit, Word */
#define		D_BIT		0
#define		D_WORD		1

#define		D_ENTBUT	"ENT"
#define		D_CLRBUT	"CLR"
typedef struct{
		short		iHour;					/*  �� ǥ�ÿ�	*/
		short		iMinute;				/*  �� ǥ�ÿ�	*/
		short		iSecond;				/*  �� ǥ�ÿ�	*/
		short		iYear;					/*  �� ǥ�ÿ�	*/
		short		iMonth;					/*  �� ǥ�ÿ�	*/
		short		iDay;					/*  �� ǥ�ÿ�	*/
} _TIMESET;		/* DEL------- */

/* ******************************************************************************/
/*  ����ü�� : _TOUCHKEY														*/
/*  ��    �� : Ű �Է°� ������ ���� ����ü										*/
/*  �� �� �� : 2002�� 2�� 8�� (��)												*/
/*  �� �� �� : ȫ �� ��															*/
/*  ��    �� : 																	*/
/* ******************************************************************************/
typedef struct{
	int				iCode;					/*  �Էµ� Ű �� ����					*/
	int				iBuff;					/*  �Էµ� Ű �� ���� (������ �����ϰ�)	*/
	int				OldData;				/*  X */
} _TOUCHKEY;

/* ******************************************************************************/
/*  ����ü�� : _DISPLAY															*/
/*  ��    �� : ���ÿ� ���� ȭ�� ���÷��̸� ���� ����ü(ȯ�漳��)			*/
/*  �� �� �� : 2002�� 3�� 19��													*/
/*  �� �� �� : �� �� ��															*/
/*  ��    �� : 																	*/
/* ******************************************************************************/
typedef struct{
	char			*chTitle[2];			/*  Ÿ��Ʋ �Է� */
	char			*chName[2][16];			/*  ���� �Է�   */	
}  _DISPLAY;
typedef struct{
	char			*chTitle[2];			/*  Ÿ��Ʋ �Է� */
	char			*chName[2][50];			/*  ���� �Է�   */	
}  _DISPLAY1;
typedef struct{
	int	cnt;
	_DISPLAY	*DspnameAddr[2];
}DISPLAY_TBL;
/* ******************************************************************************/
/*  ����ü�� : _ENDBUTT															*/
/*  ��    �� : END��ư�� PLCŸ�Կ� ���� ���÷��̸� ���� ����ü				*/
/*  �� �� �� : 2002�� 3�� 22��													*/
/*  �� �� �� : �� �� ��															*/
/*  ��    �� : 																	*/
/* ******************************************************************************/
typedef struct{
	char			*chEnd[2];			/*  END �Է�      */
	char			*chPlcType[2][2];	/*  PLC Ÿ�� �Է� */
	char			*chPlcConnect[2][2];
} _ENDBUTT;

typedef struct{
	short	cDev_Now;					/* Device Name */
	int		iDev_NowNum;				
	int		iDev_NowPoint;
	int		iDev_Count;
	short	iDev_Type;					/* Device Type Bit(1), Word(16Bit:2, 32Bit:3), Bit_Word(4)*/
	int		iPlus;						/* 2006.11.3 */
} _NOWDEV;

/* ******************************************************************************/
/*  ����ü�� : _SCREEN_DATA														*/
/*  ��    �� : SCREEN list														*/
/*  �� �� �� : 2002�� 5�� 15��													*/
/*  �� �� �� : �� �� ��															*/
/*  ��    �� : 																	*/
/* ******************************************************************************/
typedef struct {
	int			iNum;
/*	char		chTitle[32];*/
	char		*chTitle;
	int			iEndFilePointer;/* 0x02�� ��ġ�� */
	/*  */
	short		iDefKeyAct;
	short		iCarryFlag;
	short		Sheetcolor;
	short		iSecurity;
	short		KeyWinFlag;
	short		KeyWinSy;
	short		KeyWinSx;
	/*  */
}_SCREEN_DATA;

/* ******************************************************************************/
/*  ����̽� �̺�Ʈ �½�ũ														*/
/*  ��    �� : �̺�Ʈ �½�ũ ���� ���� �÷���									*/
/*  �� �� �� : 2002�� 5�� 8�� (��)												*/
/*  �� �� �� : �� �� ȣ															*/
/*  ��    �� : 																	*/
/* ******************************************************************************/
#define		OFF			0
#define		ON			1
#define		BIT			0
#define		WORD		1

/* ******************************************************************************/
/*  �ؽ�Ʈ �������																*/
/*  ��    �� : �ؽ�Ʈ �������													*/
/*  �� �� �� : 2002�� 5�� 8�� (��)												*/
/*  �� �� �� : �� �� ȣ															*/
/*  ��    �� : 																	*/
/* ******************************************************************************/
#define		TRANS		0
#define		NON_TRANS	1

/* ******************************************************************************/
/*  TAG ����(��������, �÷�����, ��������, ��������.....)						*/
/*  ��    �� : ȭ������															*/
/*  �� �� �� : 2002�� 3�� 26�� (ȭ)												*/
/*  �� �� �� : �� �� ȣ															*/
/*  ��    �� : 																	*/
/* ******************************************************************************/

/* �÷����� */
#ifdef	SIZE_2480_COL
	#define		BLACK				0x00000000					/* ������ */
	#define		BLUE				0x000000ff					/* �Ķ��� */
	#define		GREEN				0x0000ff00					/* ��  �� */
	#define		SKY					0x000000ff					/* �ϴû� */
	#define		RED					0x00ff0000					/* ������ */
	#define		PURPLE				0xE3					/* ����� */
	#define		YELLOW				0x0000ffff					/* ����� */
	#define		WHITE				0x00ffffff					/* ��  �� */
#else
	#define		BLACK				0x00					/* ������ */
	#define		BLUE				0x03					/* �Ķ��� */
	#define		GREEN				0x1c					/* ��  �� */
	#define		SKY					0x1F					/* �ϴû� */
	#define		RED					0xE1					/* ������ */
	#define		PURPLE				0xE3					/* ����� */
	#define		YELLOW				0xF3					/* ����� */
	#define		WHITE				0xFF					/* ��  �� */
#endif
/* ����Ÿ������ */
#define		NO_LINE				0x00					/* ��   �� */
#define		SOLID_LINE			0x01					/* ��   �� */
#define		DOTTED_LINE			0x02					/* ��   �� */
#define		DASHED_LINE			0x03					/* ��   �� */	
#define		DASH_DOT_LINE		0x04					/* 1���⼱ */
#define		DASH_DOT_DOT_LINE	0x05					/* 2���⼱ */

/* ����Ÿ������(�簢��, ��) */
#define		PAT0				0x00					/* ���Ͼ��� */
#define		PAT1				0x01					/* ����1 */
#define		PAT2				0x02					/* ����2 */
#define		PAT3				0x03					/* ����3 */
#define		PAT4				0x04					/* ����4 */
#define		PAT5				0x05					/* ����5 */
#define		PAT6				0x06					/* ����6 */
#define		PAT7				0x07					/* ����7 */
#define		PAT8				0x08					/* ����8 */

/* ȭ�� ���� */
#define		CONFIG_NEXT			999
#define		CONFIG_SCREEN		0x00					/* ȯ�漳��ȭ�� */
#define		USER_SCREEN			0x01					/* ���������ȭ�� */

/* �ð���������±��� �������� */
#define		YYMMDD				0x01
#define		DDMMYY				0x02
#define		MMDDYY				0x03
#define		DATETYPE1			0x04
#define		DATETYPE2			0x05

#define		TIMETYPE1			0x01
#define		TIMETYPE2			0x02
/* 051125 */
#define		TIMETYPE3			0x03
#define		TIMETYPE4			0x04

#define		DATE_FORMAT			0x01
#define		TIME_FORMAT			0x02
/* Alarm List Number */
#define		SINGLE				0x02
#define		PLURAL				0x01
/* Alarm List  Sort */
#define		ASCENDING			0x01
#define		DESCENDNIG			0x02
#define		OLDEST				0x03
#define		LATEST				0x04

#define		CHECKED				1
#define		UNCHECKED			0

/*//////////Parts Data////////////// */
/* Position Infomation */
#define		TOP_LEFT			0x00
#define		CENTER				0x08

/* Type Infomation */
#define		TYPE_MARK			0x01
#define		TYEP_PART			0x02

/* BitWordFlag Infomation */
#define		BITFLAG				0x02
#define		WORDFLAG			0x01

/* Statistics Chart Information */
#define		RECTANGLE_GRAPH		0x00
#define		CIRCLE_GRAPH		0x01
#define		DIRECTION_UP		0x00
#define		DIRECTION_RIGHT		0x01

#define		SIGN_16				0x01
#define		UNSIGN_16			0x02
#define		SIGN_32				0x03
#define		UNSIGN_32			0x04

/* Device Check Time */
#define		DEVICE_CHECK_TIME	100

/* Line Chart Tag */
#define		RIGHT				0x01
#define		LEFT				0x02
#define		VERTICAL			0x01
#define		HORIZONTAL			0x02

/* Bar Chart Tag */
#define		USED_DEVICE			0x00
#define		USED_FIXED			0x01

/* Bar Graph ScalePosition */
#define		_LEFT				0x01
#define		_DOWN				0x02
#define		_RIGHT				0x03
#define		_UP					0x04



#define		ORDINARY			0x00
#define		NOT_ORDINARY		0x01
/* Numeric Input Tag */
#define		SIGNED_DECIMAL		0x00
#define		UNSIGNED_DECIMAL	0x01
#define		HEXA_DECIMAL		0x02
#define		OCTAL				0x03
#define		BINARY				0x04
#define		REAL				0x05
/* Numeric Alignment	*/
#define		RIGHT_ALIGN			0x00
#define		LEFT_ALIGN			0x01
#define		CENTER_ALIGN		0x02
#define		DISPALLCHK_ALIGN	0x03

/* Touch Switch */
#define		NO					0x00
#define		BASIC_FIGURE		0x01
#define		PARTS				0x02

/* Menu Data Buffer (Buffer)*/
#define		SELECT_MEMU				0
#define		MONITORING				1
#define		DEVICE_MONITORING		2
#define		DATA_VIEW				3
#define		BASE_SCREEN				4
#define		WINDOW_SCREEN			5
#define		COMMENT_SCREEN			6
#define		MEMORY_SIZE				7
#define		SET_FUNTION				8
#define		TIME_SWITCH				9
#define		DATA_TRANSFER			10
#define		PRINT_OUT				11
#define		SET_ENVIRONMENT			12
#define		CLOCK_MENU				13
#define		LANGUAGE				14
#define		BACKLIGHT				15
#define		BATTERY					16
#define		BUZZER					17
#define		OPENNING				18
#define		PLC_SETTING				19
#define		SERIAL_PORT				20
#define		MENU_CALL_KEY			21
#define		CLEAR_GP_DATA			22
#define		ELSMESSAGE				23
#define		PLC_ADD_SETTING			24

#define		RS232C_SETTING			25
#define		NO_USE_MESS				26
#define		MODEL_VER				27 /*hsh 20060315*/


#ifdef	GP_S057
	#define		CLEAR_DATA				22
	#define		UWLATCH					31		/* 20091222 */

	#define		LCDCONTRAST				28
	#define		LG_COMMENT_SCREEN		29
	#define		LG_SET_FUNTION			 8
	#define		LG_TIME_SWITCH			32	//���b�Z?�W�e?�u���͖��g�p

	#define		DEVMON_SELECT			33	//LARG GAMEN

	#define		L_PLC_SETTING			0
	#define		L_CLOCK_MENU			1
	#define		L_OPENNING				2
	#define		L_LG_TIME_SWITCH		4
#endif

#ifdef	GP_S044
	#define		CONNECTION_DETAIL		28
	#define		UWLATCH					29		/* 20091222 */
	#define		CLEAR_DATA				30
#endif

#ifdef	LP_S044
	#define		GLP_BOARD				28	/* */
	#define		GLP_IO_SEL				29
	#define		GLP_IO_FILTER			30
	#define		GLP_IO_INT				31
	#define		GLP_IO_10KEY			32
	#define		GLP_IO_7SEG				33
	#define		GLP_IO_SYNC				34
	#define		GLP_IO_PULS				35
	#define		GLP_IO_ENC				36
	#define		GLP_IO_CNT				37
	#define		GLP_IO_PATRN			38
	#define		CLEAR_DATA				39
	#define		CLEAR_GLP_DATA			40
	#define		XY_DEVICE_MONITORING	41	
	#define		CONNECTION_DETAIL		42
#endif




/* Menu Data Number (input)*/
#define		USER_SCREEN_NUM				0
#define		SELECT_MEMU_NUM				1

#define		MONITORING_NUM				2
#define		DEVICE_MONITORING_NUM		201
#define		DEVICE_XY_MONITORING_NUM	202	/*hsh 20080924*/

#define		SET_ENVIRONMENT_NUM			3
#define		LANGUAGE_NUM				300
#define		SERIAL_PORT_NUM				301
#define		PLC_SETTING_NUM				302
#define		CLOCK_MENU_NUM				303
#define		CLEAR_DATA_NUM				304
#define		MENU_CALL_KEY_NUM			305
#define		BUZZER_NUM					306
#define		OPENNING_NUM				307
#define		BACKLIGHT_NUM				308
#define		BATTERY_NUM					309
#define		LCDCONTRAST_NUM				310
#define		UWLATCH_NUM				311			/* 20091222 */

#define		DATA_VIEW_NUM				4
#define		BASE_SCREEN_NUM				401
#define		WINDOW_SCREEN_NUM			402
#define		COMMENT_SCREEN_NUM			403
#define		MEMORY_SIZE_NUM				404
#define		MODEL_VER_NUM				405 /*hsh 20060315*/

#define		SET_FUNTION_NUM				5
#define		DATA_TRANSFER_NUM			501
#define		TIME_SWITCH_NUM				502
#define		PRINT_OUT_NUM				503

//#define		SET_GLP_NUM					6
#define		SELECT_IO_NUM				6
#define		SELECT_IO_FILTER_NUM		601
#define		SELECT_IO_INT_NUM			602
#define		SELECT_IO_10KEY_NUM			603
#define		SELECT_IO_7SEG_NUM			604
#define		SELECT_IO_SYC_NUM			605
//#define		SELECT_IO_PULS_NUM			66
//#define		SELECT_IO_ENCODE_NUM		67
//#define		SELECT_IO_CNT_NUM			68
//#define		SELECT_IO_PATRN_NUM			69

#define		CLEAR_GP_DATA_NUM		340
#define		CLEAR_GLP_DATA_NUM		341

#define		PLC_SETTING_MODELTYPE_NUM		320  


/* Ser031027 */
#define		UNIVERSAL					0
#define		DEFAULT_PLC					1
#define		ELSE_PLC					2
#define		EDITER						3
#define		PRINTER						4
#define		BAR_CODE					5
#define		MONITOR						6
#define		PLCTYPE2					7
#define		RS_232C						0
#define		RS_422						1
#define		CH_CH0				0
#define		CH_CH1				1
/* Panel Meter */
#define		TOP14				0x00
#define		BOTTOM14			0x08
#define		LEFT14				0x10
#define		RIGHT14				0x18
#define		TOP_RIGHT14			0x20
#define		TOP_LEFT14			0x28
#define		BOTTOM_LEFT14		0x30
#define		BOTTOM_RIGHT14		0x38
#define		TOP12				0x40
#define		BOTTOM12			0x48
#define		LEFT12				0x50
#define		RIGHT12				0x58
#define		FULL34				0x60
#define		FULL				0x68

#define		CLOCKWISE			0x00
#define		COUNTERCLOCKWISE	0x01

#define		DEGREE_0			0x00
#define		DEGREE_90			0x01
#define		DEGREE_180			0x02
#define		DEGREE_270			0x03

/* Lamp Disp */
#define		BASIC_FIGURE		0x01
#define		PARTS				0x02
/* ����κ� */
#define		TASK_BUFFER_SIZE	256
#define		SIGNED				0x00
#define		UNSIGNED			0x01
#define		BCD					0x02
#define		FIXED				0x00
#define		DEV					0x01
#define		FIGURE				1
#define		OBJECT				2
#define     BIT16				0
#define		BIT32				1

#define     IMAGE_PARTS			0
#define     TAG_PARTS			1

/* Key Touch �κ� */
#ifdef	GP_S057
	//#define		KEY_OFFSET1			82
	//#define		KEY_OFFSET2			87
	//#define		KEY_OFFSET3			92
	//#define		KEY_OFFSET4			97
	#define		KEY_OFFSET1			0
	#define		KEY_OFFSET2			16
	#define		KEY_OFFSET3			32
	#define		KEY_OFFSET4			48
#endif
#ifdef	LP_S044
	#define		KEY_OFFSET1			0
	#define		KEY_OFFSET2			15
	#define		KEY_OFFSET3			30
	#define		KEY_OFFSET4			45
#endif
#ifdef	GP_S044
	#define		KEY_OFFSET1			0
	#define		KEY_OFFSET2			15
	#define		KEY_OFFSET3			30
	#define		KEY_OFFSET4			45
#endif

#define	X_SPAN(n)	(int)((float)(16*n)/(float)MESH_X+0.5)

#define		KEY_01				(X_SPAN(1)+KEY_OFFSET1)
#define		KEY_02				(X_SPAN(2)+KEY_OFFSET1)
#define		KEY_03				(X_SPAN(3)+KEY_OFFSET1)
#define		KEY_04				(X_SPAN(4)+KEY_OFFSET1)
#define		KEY_05				(X_SPAN(5)+KEY_OFFSET1)
#define		KEY_06				(X_SPAN(6)+KEY_OFFSET1)
#define		KEY_07				(X_SPAN(7)+KEY_OFFSET1)
#define		KEY_08				(X_SPAN(8)+KEY_OFFSET1)
#define		KEY_09				(X_SPAN(9)+KEY_OFFSET1)
#define		KEY_10				(X_SPAN(10)+KEY_OFFSET1)
#define		KEY_11				(X_SPAN(11)+KEY_OFFSET1)
#define		KEY_12				(X_SPAN(12)+KEY_OFFSET1)
#define		KEY_13				(X_SPAN(13)+KEY_OFFSET1)
#define		KEY_14				(X_SPAN(14)+KEY_OFFSET1)
#define		KEY_15				(X_SPAN(15)+KEY_OFFSET1)
#define		KEY_16				(X_SPAN(1)+KEY_OFFSET2)
#define		KEY_17				(X_SPAN(2)+KEY_OFFSET2)
#define		KEY_18				(X_SPAN(3)+KEY_OFFSET2)
#define		KEY_19				(X_SPAN(4)+KEY_OFFSET2)
#define		KEY_20				(X_SPAN(5)+KEY_OFFSET2)
#define		KEY_21				(X_SPAN(6)+KEY_OFFSET2)
#define		KEY_22				(X_SPAN(7)+KEY_OFFSET2)
#define		KEY_23				(X_SPAN(8)+KEY_OFFSET2)
#define		KEY_24				(X_SPAN(9)+KEY_OFFSET2)
#define		KEY_25				(X_SPAN(10)+KEY_OFFSET2)
#define		KEY_26				(X_SPAN(11)+KEY_OFFSET2)
#define		KEY_27				(X_SPAN(12)+KEY_OFFSET2)
#define		KEY_28				(X_SPAN(13)+KEY_OFFSET2)
#define		KEY_29				(X_SPAN(14)+KEY_OFFSET2)
#define		KEY_30				(X_SPAN(15)+KEY_OFFSET2)
#define		KEY_31				(X_SPAN(1)+KEY_OFFSET3)
#define		KEY_32				(X_SPAN(2)+KEY_OFFSET3)
#define		KEY_33				(X_SPAN(3)+KEY_OFFSET3)
#define		KEY_34				(X_SPAN(4)+KEY_OFFSET3)
#define		KEY_35				(X_SPAN(5)+KEY_OFFSET3)
#define		KEY_36				(X_SPAN(6)+KEY_OFFSET3)
#define		KEY_37				(X_SPAN(7)+KEY_OFFSET3)
#define		KEY_38				(X_SPAN(8)+KEY_OFFSET3)
#define		KEY_39				(X_SPAN(9)+KEY_OFFSET3)
#define		KEY_40				(X_SPAN(10)+KEY_OFFSET3)
#define		KEY_41				(X_SPAN(11)+KEY_OFFSET3)
#define		KEY_42				(X_SPAN(12)+KEY_OFFSET3)
#define		KEY_43				(X_SPAN(13)+KEY_OFFSET3)
#define		KEY_44				(X_SPAN(14)+KEY_OFFSET3)
#define		KEY_45				(X_SPAN(15)+KEY_OFFSET3)
#define		KEY_46				(X_SPAN(1)+KEY_OFFSET4)
#define		KEY_47				(X_SPAN(2)+KEY_OFFSET4)
#define		KEY_48				(X_SPAN(3)+KEY_OFFSET4)
#define		KEY_49				(X_SPAN(4)+KEY_OFFSET4)
#define		KEY_50				(X_SPAN(5)+KEY_OFFSET4)
#define		KEY_51				(X_SPAN(6)+KEY_OFFSET4)
#define		KEY_52				(X_SPAN(7)+KEY_OFFSET4)
#define		KEY_53				(X_SPAN(8)+KEY_OFFSET4)
#define		KEY_54				(X_SPAN(9)+KEY_OFFSET4)
#define		KEY_55				(X_SPAN(10)+KEY_OFFSET4)
#define		KEY_56				(X_SPAN(11)+KEY_OFFSET4)
#define		KEY_57				(X_SPAN(12)+KEY_OFFSET4)
#define		KEY_58				(X_SPAN(13)+KEY_OFFSET4)
#define		KEY_59				(X_SPAN(14)+KEY_OFFSET4)
#define		KEY_60				(X_SPAN(15)+KEY_OFFSET4)

#define		DOWN_TRANS			1004
#define		UP_TRANS			1005

