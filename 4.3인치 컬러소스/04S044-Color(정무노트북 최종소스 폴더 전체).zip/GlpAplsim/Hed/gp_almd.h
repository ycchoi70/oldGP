void	AlarmDetail_Task(STTFrm* pSTT );
