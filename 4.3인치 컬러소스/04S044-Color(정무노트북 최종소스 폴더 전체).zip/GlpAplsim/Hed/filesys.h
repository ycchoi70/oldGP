/******************************************************************************
*                         (�L)�R���e�b�N 2001,2002                             
*******************************************************************************
* System             :FlashRom Filesystem                                     
* FileName           :Gb_filesys.h                                            
* Summary            :�t�@�C���V�X�e���֘A��`���s���܂��B                       
* Programmer         :�S�ωp                                                   
* Create Date        :2002/02/26                                              
******************************************************************************/
#define _ON_DEBUG      0

#define MAX_FILE    2 /*�I�[�v���\�ȃt�@�C����*/
#define MAX_SIZE    1024

#define NOTFOUND    1
#define OK          0

#define GP_ERROR      -1

/* �t�@�C���I�[�v�����[�h*/
#define _O_RDONLY   0x04
#define _O_WRONLY   0x08
#define _O_APPEND   0x10

#define MODE_READ   1
#define MODE_WRITE  2
#define MODE_APPEND 4

/* �t�@�C���|�C���^�[�ړ������ʒu*/
#define M_SEEK_SET    0
#define M_SEEK_CUR    1
#define M_SEEK_END    2

/* �t�@�C������*/
#define ATTR_RDO    0x01
#define ATTR_HID    0x02
#define ATTR_SYS    0x04
#define ATTR_VOL    0x08
#define ATTR_DIR    0x10
#define ATTR_ARC    0x20

/******************************************************************************
* �f�B���N�g���̓��e(32�o�C�g)                                                *
******************************************************************************/
struct  dir {
    unsigned char   name_ext[8+3];         /* �t�@�C�����{�g���q*/
    unsigned char   attr;                  /* ����*/
    char            rsv0[10];              /* �\��̈�*/
    unsigned short  time;                  /* �ŏI�ҏW����*/
    unsigned short  date;                  /* �ŏI�ҏW���t*/
    unsigned short  f_top;                 /* �J�n�N���X�^*/
    unsigned long   f_size;                /* �t�@�C���T�C�Y(�o�C�g�P��)*/
    };
/******************************************************************************
* �f�B���N�g��I/O BUFFER                                                      *
******************************************************************************/
struct iobuf {
    unsigned char   device_no;             /* �f�o�C�X�ԍ�(mopen��0x01)*/
    unsigned char   name[8+3];             /* �t�@�C�������g���q*/
    unsigned char   mode;                  /* �t�@�C�����[�h*/
    unsigned short  time;                  /* ����*/
    unsigned short  date;                  /* ���t*/
    unsigned long   size;                  /* �S�t�@�C���T�C�Y*/
    unsigned long   pos;                   /* ���ݓǂ݂������̐�΃|�W�V���� */
    unsigned long   top_cluster;           /* �擪�̃N���X�^*/
    unsigned long   current;               /* ���݂̃N���X�^�ʒu*/
    unsigned long   dir_sect;              /* ���΃Z�N�^�ԍ�*/
    unsigned short  dir_pos;               /* �Z�N�^���̃f�B���N�g���̈ʒu*/
    unsigned short  data;                  /* �ǂݏ����|�C���^*/
    unsigned char   attr;                  /* �t�@�C������*/
    unsigned char   readf;                 /* �ǂݏo�����f�[�^�̎��P*/
    unsigned char   dtbuf[MAX_SIZE];       /* �f�[�^*/
    };
typedef struct iobuf I_FILE;

struct find_t {
    unsigned char	reserved[21];
	unsigned char	attrib;
    unsigned int	wr_time;
	unsigned int	wr_date;
	long			size;
    char			name[13];
};

/******************************************************************************
*   ̧�ټ��ъ֐�                                                              *
******************************************************************************/
void  init_filesystem(void);
int   isfilename(char c);
int   name_ana(char dst[],char name[]);
int   chkdupopen(char f_name[]);
int   mopen(char name[],int mode);
int   mclose(int hdl);
int   mread(int hdl, void *buf,unsigned int lcnt);
int   mwrite(int hdl, void *buf,unsigned int lcnt);
long  mseek(int hdl, long offset,short mode);
int   mgetdiskfree(short *bx,short *cx,short *dx);
int   mformat(void);
int   mformat2(void);
long  mtell(int handle);
short GetCurrentDate( void );
short GpGetCurrentTime( void );
void  exit_filesystem(void);
int	mfileDelete(int flag,int hdl);

/******************************************************************************
*   �ׯ����ذ�֐�                                                             *
******************************************************************************/
void  FM_init(void);
short FM_read1sect(long pos,char buf[]);
short FM_write1sect(long pos,char buf[]);
short FM_search_dir(char name[],I_FILE *id);
short FM_search_new_dir(I_FILE *id);
void  FM_put_fat(void);
short FM_put_dir(I_FILE *id);
short FM_next_sector(I_FILE *id,int mode);
short  FM_GetFileInfo(int devno,char name[],long *sectp,short *attr,long *size);
short FM_DeleteDirectryEntry(char name[]);
short FM_GetDiskSpace(int devno,short *bx,short *cx,short *dx);
short FM_Open(I_FILE *id);
int FM_WriteHandle(char buf[],unsigned int cnt,I_FILE *id);
int FM_ReadHandle(char buf[],unsigned int cnt,I_FILE *id);
long  FM_MoveFilePointer(long offset,short mode,I_FILE *id);
short FM_Close(I_FILE *id);
int   FM_fmt_write(void);
short FM_Open2(I_FILE *id);
int FM_WriteHandle2(char buf[],unsigned int cnt,I_FILE *id);
int FM_ReadHandle2(char buf[],unsigned int cnt,I_FILE *id);
long  FM_MoveFilePointer2(long offset,short mode,I_FILE *id);
short FM_Close2(I_FILE *id);
int   FM_fmt_write2(void);
int	SetMemAddr(int sectp);
int	SetMemAddr2(int sectp);
short  FM_find_dir(char name[],I_FILE *id,int FirstSec,int FirstPos);
int	mfileserch(char *filename,int *pos,int *size);
int	mfileserch2(char *filename,int *pos,int *size);
int	m_findfirst(char *wildspec, unsigned attr, struct find_t *finddata);
int	m_findnext(struct find_t *finddata);
void	mWriteSettei( void );
void	mReadSettei( void );
void	mBaseClear( void );
char *DeleteFileOpen( void );
void	DeleteFile( char *Name, char *mp );
void	DeleteFileClose( char *mp );
char *DeleteFileOpen2( void );
void	DeleteFile2( char *Name, char *mp );
void	DeleteFileClose2( char *mp );
int	CheckUserArea( void );
int	CheckNoUseArea( void );
unsigned char *GetKeyWinAddr(int kind);
int	GetUsrArea(void);
int	GetUserFileArea(void);

/*********************************** END OF FILE *****************************/
