void    NormalBuzzer(void);
void    ErrorBuzzer(void);
void    StopBuzzer(void);
void    FlashBuzzer(void);
void    FlashBuzzer2(void);
void    AlarmBuzzer0(void);
void    AlarmBuzzer1(void);
void    AlarmBuzzer2(void);
void    FlashBuzzer3(void);
void    StopBuzzerElse(void);
int   KeyWait( void );
int   KeyAccept( void );
int	CheckReptKey(void);
void    KeyHand(STTFrm* pSTT );
int KeyGet( void );
void    KeyDrv(STTFrm* pSTT);
void BuzDrv(STTFrm* pSTT);
#ifndef	WIN32
char	*itoa(int data, char *buff, int p);
#endif

