/**********************************************/
#define	PLC_PROC	'1'
#define	PLC_PARAM	'2'
#define	PLC_LCOMENT	'3'
#define	PLC_RCOMENT	'4'
#define	PLC_VAL		'5'
#define	PLC_LABEL	'6'
#define	PLC_PROJ	'7'

#define	WDT_INIT	200		//200ms
#define	WDT_MAX_CNT	200		//200ms
#define	SC_CNT_INIT	200		//200ms
#define	SC_MAX_CNT	200		//200ms

#define	PLC_PASS_CNT	16

enum{BR_COMM,WR_COMM,BW_COMM,WW_COMM,MR_COMM,RB_COMM,RW_COMM,
	UW_READ,UW_WRITE,UW_READ_ALL,
};

#define	MAX_PARAM_AREA		0x4000
#define	MAX_PROGRAM_AREA	0x6000+0x100

#define	WIN_UV_DEVICE	0x20ff		//for Bit Device
#define	WIN_UV_WORD		0x2000		//for Word Device
#define	WIN_S_DEVICE	0x10ff		//for Bit Device
#define	UV_DEVICE		0xff20		//for Bit Device
#define	S_DEVICE		0xff10		//for Bit Device

#define	DEVICE_PT		0x0080		//POINT
#define	DEVICE_IX		0x0040		//INDEX
#define	UV_DEVICE_B		0x0020		//UV-DEVICE
#define	SP_DEVICE_S		0x0010		//S-DEVICE
#define	SP_DEVICE		0xff00


#define	MAX_LOAD_CNT	32		//LOAD NESTING
#define	MAX_PUSH_CNT	16		//MAX MPUSH
#define	MAX_CALL_CNT	8		//MAX CALL
#define	MAX_MC_CNT		256		//MAX MC
#define	MAX_FCALL_PARA	32		//FCALL Para Count
#define	MAX_LABEL_CNT	256		//MAX LABEL
#define	MAX_IO_INT		16
#define	MAX_TIME_INT	8

#define	MAX_BP_PRG		64
#define	MAX_BP_BIT		32
#define	MAX_BP_WRD		32
#define	MAX_IO_SET		64
#ifdef	WIN32
	#define	TIMER_CNT		10
#else
	#define	TIMER_CNT		10
#endif

enum{INT_OFF,INT_TIMER,INT_EXTIO};
enum{TIM_1MS,TIM_10MS,TIM_100MS};

#define	TINT_START_NO	0
#define	EINT_START_NO	0

//PLC DEVICE CODE
#define	DEV_BV	0x0f
#define	DEV_BX	0x10
#define	DEV_BY	0x14
#define	DEV_BM	0x18
#define	DEV_BF	0x1b
#define	DEV_BS	0x20
#define	DEV_BL	0x28
#define	DEV_BT	0x30
#define	DEV_BC	0x50
#define	DEV_UB	0x7f
#define	DEV_BK	0xff

#define	DEV_WX	0x80
#define	DEV_WY	0x84
#define	DEV_WM	0x88
#define	DEV_WF	0x8b
#define	DEV_WS	0x90
#define	DEV_WL	0x98
#define	DEV_WT	0xa0
#define	DEV_WC	0xb0
#define	DEV_WD	0xc0
#define	DEV_WR	0xc2
#define	DEV_WZ	0xc8
#define	DEV_UW	0xef
#define	DEV_WV	0xf0
#define	DEV_WK	0xff



//PLC DEVICE(SEQUECE CODE)
#define	B_UV	0
#define	B_UX	1
#define	B_UY	2
#define	B_UM	3
#define	B_UF	4
#define	B_US	5
#define	B_UL	6
#define	B_UT	7
#define	B_UC	8
#define	B_UB	9
#define	B_UK	99

#define	W_UX	20
#define	W_UY	21
#define	W_UM	22
#define	W_UF	23
#define	W_US	24
#define	W_UL	25
#define	W_UT	26
#define	W_UC	27
#define	W_UD	28
#define	W_UR	29
#define	W_UZ	30
#define	W_UW	31
#define	W_UV	32
#define	W_UK	99

#define	PLC_PROG_NAME		"B:PLCPROG.DAT"
#define	PLC_PROG_NAME_DIR	"PLCPROG DAT"
#define	PLC_PARAM_NAME		"B:PLCPARAM.DAT"
#define	PLC_PARAM_NAME_DIR	"PLCPARAMDAT"
#define	PLC_LCOM_NAME		"B:PLCLCOM.DAT"
#define	PLC_LCOM_NAME_DIR	"PLCLCOM DAT"
#define	PLC_RCOM_NAME		"B:PLCRCOM.DAT"
#define	PLC_RCOM_NAME_DIR	"PLCRCOM DAT"
#define	PLC_VAL_NAME		"B:PLCVAL.DAT"
#define	PLC_VAL_NAME_DIR	"PLCVAL  DAT"
#define	PLC_LABEL_NAME		"B:PLCLABEL.DAT"
#define	PLC_LABEL_NAME_DIR	"PLCLABELDAT"
#define	PLC_PROJ_NAME		"B:PLCPROJ.DAT"
#define	PLC_PROJ_NAME_DIR	"PLCPROJ DAT"

#define	MAX_EXT_CNT		16
#define	EXT_IO_ADDR		0x0e000000
#define	EXT_IO_I32O00	0x01
#define	EXT_IO_I28O04	0x02
#define	EXT_IO_I24O08	0x03
#define	EXT_IO_I20O12	0x04
#define	EXT_IO_I16O16	0x05
#define	EXT_IO_I12O20	0x06
#define	EXT_IO_I08O24	0x07
#define	EXT_IO_I04O28	0x08
#define	EXT_IO_I00O32	0x09

#define	EXT_IO_IO		0x00
#define	EXT_IO_COM		0x10
#define	EXT_IO_TEMP		0x20

//External IO Address
#define	EXT_IO_IN_ADDR		0x08
#define	EXT_IO_OUT_ADDR		0x0a
#define	EXT_IO_FILT_ADDR	0x20
#define	EXT_IO_INT_DATA		0x30
#define	EXT_IO_INT_ADDR		0x38
//#define	EXT_IO_OFFSET		0x40
#define	EXT_IO_OFFSET		0x100

#define	GLP_SYS_RUN_DBG_DI_OUT		0x0040			//From Param File

/////////////////////////////////////////////////
//	System DEVICE Info
/////////////////////////////////////////////////
//#define	GLP_SYSTEM_DEVICE	6800
#define	GLP_SYSTEM_DEVICE	Device_Length_F_ST	//6400
//Bit Device
#define	GLP_SYS_MODE		(GLP_SYSTEM_DEVICE+0)
#define	GLP_SYS_MODE_RUN		0x0001
#define	GLP_SYS_MODE_STOP		0x0002
#define	GLP_SYS_MODE_PAUS		0x0004
#define	GLP_SYS_MODE_DEBUG		0x0008
#define	GLP_SYS_SIGNAL		(GLP_SYSTEM_DEVICE+1)
#define	GLP_SYS_SIG_ON			0x0001
#define	GLP_SYS_SIG_OFF			0x0002
#define	GLP_SYS_SIG_1SC_ON		0x0004
#define	GLP_SYS_SIG_1SC_OFF		0x0008
#define	GLP_SYS_SIG_SC_PULS		0x0010
#define	GLP_SYS_SIG_1S_PULS		0x0020			//Sec Puls
#define	GLP_SYS_STATE		(GLP_SYSTEM_DEVICE+2)
#define	GLP_SYS_STATE_IO_IN		0x0001
#define	GLP_SYS_STATE_IO_OUT	0x0002
#define	GLP_SYS_STATE_CNT_RUN	0x0010
#define	GLP_SYS_STATE_DB_DI_OUT	0x0020
#define	GLP_SYS_STATE_LOW_BATT	0x1000
#define	GLP_SYS_STATE_LOW_BAT_SET	0x2000
#define	GLP_SYS_ERROR		(GLP_SYSTEM_DEVICE+3)
#define	GLP_SYS_ERR_ERROR		0x0001			//Hardware, Os Error
#define	GLP_SYS_ERR_PLC			0x0010			//PLC Address Error
#define	GLP_SYS_ERR_SC_OVR		0x0020
#define	GLP_SYS_ERR_TIME_WRITE		0x0040		//Rtc Time Error(���Ԃ̊Ď�),Write OK Clear
#define	GLP_SYS_ERR_COMM		0x0100			//Communication Error
#define	GLP_SYS_ERR_IO			0x0200			//IO_Error
#define	GLP_SYS_ERR_WDT			0x0400			//WDT_Error
#define	GLP_SYS_MODULE_STS	(GLP_SYSTEM_DEVICE+4)
#define	GLP_SYS_CLOCK		(GLP_SYSTEM_DEVICE+5)
#define	GLP_SYS_CLOCK001S		0x0010
#define	GLP_SYS_CLOCK002S		0x0020
#define	GLP_SYS_CLOCK005S		0x0040
#define	GLP_SYS_CLOCK01S		0x0080
#define	GLP_SYS_CLOCK02S		0x0100
#define	GLP_SYS_CLOCK05S		0x0200
#define	GLP_SYS_CLOCK1S			0x0400
#define	GLP_SYS_CLOCK2S			0x0800
#define	GLP_SYS_CLOCK5S			0x1000
#define	GLP_SYS_CLOCK10S		0x2000
#define	GLP_SYS_CLOCK60S		0x4000
#define	GLP_SYS_CULC		(GLP_SYSTEM_DEVICE+6)
#define	GLP_SYS_CULC_ZERO	0x0001					// F0060
#define	GLP_SYS_CULC_CARRY	0x0002					// F0061
#define	GLP_SYS_CULC_BORROW	0x0004					// F0062
#define	GLP_SYS_CULC_ERR	0x0100					//���݃G��?STOP����STOP�ȊO�ɂȂ�����
													//Program Download,Power ON
#define	GLP_SYS_CULC_ERR_ED	0x0200					//Power ON�Ń��Z�b�g

#define	GLP_SYS_RUN_MODE	(GLP_SYSTEM_DEVICE+7)	//
#define	GLP_SYS_RUN_NO_OUT	0x0001					//F070�S�o�͂��Ȃ��B�iPORT�̂݁j
//#define	GLP_SYS_RUN_NO_RST	0x0002					//F071�S���Z�b�g���Ȃ��B(PORT�̂݁j
#define	GLP_SYS_RUN_CST_SC	0x0010					//F074�����??
//#define	GLP_SYS_RUN_STP_OUT			0x0080			//F077STOP��I/O�o��
#define	GLP_SYS_RUN_STP_EXT			0x0100			//F078STOP��I/O�o�͂���(Parameter)
#define	GLP_SYS_RUN_FILTER_SET		0x0200			//F079 Defalt Filter Setting
#define	GLP_SYS_TIME_MODE	(GLP_SYSTEM_DEVICE+8)	//
#define	GLP_SYS_TIME_TIME	0x0001					//F080 RTC Timer Stop Flag
#define	GLP_SYS_TIME_30S	0x0002					//F081 Adjust(�b���O�ŏ���)
													//�O?�Q�X�b�͂O�ɂR�O?�T�X�͂P���A�b�v�ŕb�O�ŏ�������
#define	GLP_SYS_MODULE_SET	(GLP_SYSTEM_DEVICE+9)	//Module Param Setting

//Word Device
//#define	GLP_SERIES_CODE		(GLP_SYSTEM_DEVICE+100)		//Series Code(2W)
#define	GLP_MODEL_CODE		(GLP_SYSTEM_DEVICE+100)		//Model Code(2W)
#define	GLP_SYS_VERSION		(GLP_SYSTEM_DEVICE+101)		//Version(2W)
#define	GLP_SYS_V_DATE		(GLP_SYSTEM_DEVICE+106)		//Date(2W)

#define	GLP_SYS_NOW_SC		(GLP_SYSTEM_DEVICE+110)		//Now Scan Time
#define	GLP_SYS_MIN_SC		(GLP_SYSTEM_DEVICE+111)		//Min Scan Time
#define	GLP_SYS_MAX_SC		(GLP_SYSTEM_DEVICE+112)		//Max Scan Time
#define	GLP_SYS_AVR_SC		(GLP_SYSTEM_DEVICE+113)		//Avrage Scan Time
#define	GLP_SYS_SCN_CNT		(GLP_SYSTEM_DEVICE+114)		//Scan Count
#define	GLP_SYS_CULC_ERR_STEP	(GLP_SYSTEM_DEVICE+120)	//Culc Error
#define	GLP_SYS_CULC_ERRED_STEP	(GLP_SYSTEM_DEVICE+121)	//Culc Error
#define	GLP_SYS_ERROR_STEP	(GLP_SYSTEM_DEVICE+130)		//Error Step(Error Stop��)
#define	GLP_SYS_BREAK_STEP	(GLP_SYSTEM_DEVICE+131)		//Break Step
#define	GLP_SYS_SELF_TEST	(GLP_SYSTEM_DEVICE+140)		//Self Test Error Code
#define	GLP_SYS_SELF_WDT	0x0010
#define	GLP_SYS_SELF_MEM	0x0020
#define	GLP_SYS_SELF_BATT	0x0021
#define	GLP_SYS_SELF_RTC	0x0022
#define	GLP_SYS_SELF_PROG	0x0030
#define	GLP_SYS_SELF_NUM	0x0031
#define	GLP_SYS_SELF_PARA	0x0040
#define	GLP_SYS_SELF_SCAN	0x0041
#define	GLP_SYS_SELF_EXT	0x0050
#define	GLP_SYS_SELF_BOAD	0x0051
#define	GLP_SYS_SELF_NAK	0x0060
#define	GLP_SYS_SELF_SUM	0x0061



#define	GLP_SYS_YY			(GLP_SYSTEM_DEVICE+150)
#define	GLP_SYS_MM			(GLP_SYSTEM_DEVICE+151)
#define	GLP_SYS_DD			(GLP_SYSTEM_DEVICE+152)
#define	GLP_SYS_HH			(GLP_SYSTEM_DEVICE+153)
#define	GLP_SYS_MIN			(GLP_SYSTEM_DEVICE+154)
#define	GLP_SYS_SS			(GLP_SYSTEM_DEVICE+155)
#define	GLP_SYS_WW			(GLP_SYSTEM_DEVICE+156)
#define	GLP_SYS_INP_FILTER	(GLP_SYSTEM_DEVICE+160)		//Input Fillter(Default)
#define	GLP_SYS_SCN_TIME	(GLP_SYSTEM_DEVICE+161)		//Const Scan Time
#define	GLP_SYS_WDT_COUNT	(GLP_SYSTEM_DEVICE+162)		//WDT Timer
#define	GLP_SYS_TIME_INTVAL	(GLP_SYSTEM_DEVICE+170)		//Timer Interrupt Value(16Word)





//I/O Parameter Struct
typedef	struct{
	unsigned char	UseFlag;
	unsigned char	DevUseFlag;
	unsigned char	Val[4];
	unsigned char	DevAddr[4];
	unsigned char	dumy[2];
}PARA_FILTER;
typedef	struct{
	unsigned char	UseFlag;
	unsigned char	DevUseFlag;
	unsigned char	Val[8];
	unsigned char	DevAddr[4];
	unsigned char	Label[16][14];
	unsigned char	dumy[18];
}PARA_INT;
typedef	struct{
	unsigned char	UseFlag;
	unsigned char	DevUseFlag;
	unsigned char	Inreg;
	unsigned char	Outreg;
	unsigned char	DevAddr[4];
	unsigned char	dumy[4];
}PARA_MATRIX;
typedef	struct{
	unsigned char	UseFlag;
	unsigned char	DevUseFlag;
	unsigned char	Outreg;
	unsigned char	Dumy;
	unsigned char	DevAddr[4];
	unsigned char	dumy[4];
}PARA_7SEG;
typedef	struct{
	unsigned char	UseFlag;
	unsigned char	DevUseFlag;
	unsigned char	Outreg;		//Y??�g�ԍ�
	unsigned char	DataBit;
	unsigned char	Count;
	unsigned char	Dumy;
	unsigned char	DevAddr[4];
	unsigned char	dumy[2];
}PARA_SIO;
typedef struct{
	unsigned char		slotNo;
	unsigned char		ModuleID;
	unsigned char		Version[2];
	PARA_FILTER	filter;
	PARA_INT	intctl;
	PARA_MATRIX	matrix;
	PARA_7SEG	seg7;
	PARA_SIO	syncSio;
	unsigned char	dumy[204];		//
}PARA_IO;
typedef struct{
	unsigned char	Password[16];
	unsigned char	DebugIoUse;			//080116
	unsigned char	DebugIoOut;			//0:1Scan Out,1:No Out
	unsigned char	DefFilter;			//DEfault Filter
	unsigned char	IoOut;				//Stop���o�͂���A���Ȃ�(FPGA�ɐݒ�)
//	unsigned char	Dumy1;
	unsigned char	ScanTime[4];		//������X�L��������
	struct{
		unsigned char	TimerTime[2];	//Timer Int Cycle
		unsigned char	Label[14];		
	}tInt[8];							//16*8=128Byte
	unsigned char	DevLen[2];
	unsigned short	ClearDevUse[2];
	unsigned short	ClearDev[16][4];	//8*16=128Byte
	unsigned short	TimerKind[3][2];	//0:100ms,1:10ms,2:1ms
	unsigned char	Dumy2[198];		//248-150
}GLP_COMM;

typedef struct{
	int			len;
	char		ver[12];
	GLP_COMM	comm;
	int			slotNum;
	char		SlotName[256][16];
	PARA_IO		io;
}PARAM_FILE;

typedef	struct{
	int	FilterUse;
	int	FilterDevUse;
	char	FilterVal[2];
	unsigned short*	FilterDevAddr;
	unsigned short	FilterDev[2];
	int	InterruptUse;
	int	InterruptDevUse;
	char	InterVal[4];
	unsigned short*	IntDevAddr;
	unsigned short	IntDev[2];
	int	TenkeyUse;
	int	TenkeyDevUse;
	unsigned short*	TenkeyDevAddr;
	unsigned short	TenkeyDev[2];
	int	Tenkey_Inreg;
	int	Tenkey_Outreg;
	int	Seg7Use;
	int	Seg7DevUse;
	unsigned short*	Seg7DevAddr;
	unsigned short	Seg7Dev[2];
	int	Seg7_Outreg;
	int	SyncSioUse;
	int	SyncSioDevUse;
	unsigned short*	SyncSioDevAddr;
	unsigned short	SyncSioDev[2];
	int	Sync_Outreg;
	int	Sync_DataCnt;
	int	Sync_Bit;
	int	SyncSioDataCnt;//Byte Count
	unsigned short	SyncSioData[16];
}GLP_IO_INFO;

#define	PARAM_GLP_COMM		(PLC_PARAM_FILE+ 0x10)
#define	PARAM_MODULE_NAME	(PLC_PARAM_FILE+ 512+4)		//+Slot Module Cnt
#define	PARAM_SLOT_CNT		(PLC_PARAM_FILE+ 512)
#define	PARAM_SLOT_START	(PARAM_MODULE_NAME+ 0x1000)
#define	PARAM_1SLOT_SIZE	512
#define	MAX_SLOT_CNT		16
#define	PARAM_COMMON_SIZE	(512-16)
#define	PARAM_MODULE_NAME_SIZE	0x10000
//Register Define
#define	FPG_ID_ADDR		0x00
#define	FPG_VERSION		0x02
#define	FPG_IO_A		0x08	//PortA
#define	FPG_IO_B		0x09	//PortB
#define	FPG_IO_C		0x0a	//PortC
#define	FPG_IO_D		0x0b	//PortD
#define	FPG_PC_REG00	0x10	//Port Control
#define	FPG_PC_REG01	0x11
#define	FPG_PC_REG02	0x12
#define	FPG_PC_REG03	0x13
#define	FPG_PC_REG04	0x14
#define	FPG_PC_REG05	0x15
#define	FPG_PC_REG06	0x16
#define	FPG_PC_REG07	0x17
#define	FPG_FC_REG00	0x20	//Filter Control
#define	FPG_FC_REG01	0x21
#define	FPG_FC_REG02	0x22
#define	FPG_FC_REG03	0x23
#define	FPG_IS_REG00	0x30	//Interrupt Status
#define	FPG_IS_REG01	0x31
#define	FPG_IS_REG02	0x32
#define	FPG_IS_REG03	0x33
#define	FPG_IC_REG00	0x38	//Interrupt Control
#define	FPG_IC_REG01	0x39
#define	FPG_IC_REG02	0x3a
#define	FPG_IC_REG03	0x3b
#define	FPG_HS_REG00	0x40	//High Speed Counter
#define	FPG_HS_REG01	0x41
#define	FPG_HS_REG02	0x42
#define	FPG_HS_REG03	0x43
#define	FPG_HS_REG04	0x44	//High Speed Counter Setting
#define	FPG_HS_REG05	0x45
#define	FPG_HS_REG06	0x46
#define	FPG_HS_REG07	0x47
#define	FPG_HS_REG08	0x48	//High Speed Counter Flag
#define	FPG_SW_REG00	0x4a	//Tenkey Low Data
#define	FPG_SW_REG01	0x4b	//Tenkey Upper Data
#define	FPG_7S_REG00	0x4c	//7seg Data
#define	FPG_7S_REG01	0x4d	//7seg Data
#define	FPG_7S_REG02	0x4e	//7seg Data
#define	FPG_7S_REG03	0x4f	//7seg Data
#define	FPG_PW_REG00	0x50	//Puls Width
#define	FPG_PW_REG01	0x51
#define	FPG_PW_REG02	0x52
#define	FPG_PW_REG03	0x53
#define	FPG_PW_REG04	0x54	//Puls period
#define	FPG_PW_REG05	0x55
#define	FPG_PW_REG06	0x56
#define	FPG_PW_REG07	0x57
#define	FPG_EN_REG00	0x58	//Encode Count Input Register
#define	FPG_EN_REG01	0x59
#define	FPG_EN_REG02	0x5a
#define	FPG_EN_REG03	0x5b
#define	FPG_EN_REG04	0x5c	//Encode Flag Input Register
#define	FPG_SI_REG00	0x70	//Sync Count
#define	FPG_SI_REG01	0x71	//Sync Bit Count
#define	FPG_SI_REG02	0x72	//Sync Data
#define	FPG_DP_REG00	0x80	//Patarn Data


//----------------------------------------------------
//	Numonic Check Const
//----------------------------------------------------
#define	CNST_ACMP_N			32





enum{IO_NOUSE,IO_USE};



typedef struct{
	void     (*RsCall)( void );
}INST_PROC;
typedef struct{
	INST_PROC	func[16][16];
}INST_PROC_TBL;
typedef struct{
	int     (*RsCall)( int );
}INST_LEN_PROC;
typedef struct{
	int     (*RsCall)( unsigned short* );
}INST_DBG_PROC;
typedef struct{
	INST_LEN_PROC	func[16][16];
}INST_LEN_PROC_TBL;

typedef	struct{
	int		DevCode;
	int		DevAddr;
	int		flag;
	unsigned short *DeviceAddr;
	int		andData;
	int		kind;
}DEV_BP;


typedef	struct{
	unsigned short	TimeOnOff[Device_Length_BT] ;
	unsigned short	TimeMode[Device_Length_T] ;
	unsigned short	TimeTMR[Device_Length_BT] ;
	unsigned short	BefTimeOnOff[Device_Length_BT] ;
	unsigned short	CountOnOff[Device_Length_BC] ;
	unsigned short	BefCntOnOff[Device_Length_BC] ;
	unsigned short	BefCntOnOff2[Device_Length_BC] ;
}TIME_CNT_INF;

typedef	struct{
	char	password[16];
	int	CodeTableCnt;
	unsigned int	CodeTableSum; 
	int	ParamTableCnt;
	int	LComentTableCnt;
	int	RComentTableCnt;
	int	ValTableCnt;
	int	LabelTableCnt;
	int	ProjTableCnt;

	int	MaxStepNo;				/* �ő�X�e�b�v�� */
	int	Inst_Point_Table[MAX_STEP] ;  /* �X�e�b�v����A�h���X�ϊ��e?�u�� */
	int Load_Count ; /* ����&�I�y�����h��?�h�� */

	char	PLC_Pass[16];

	//Param Common
	unsigned short	CommDebugIoUse;
	unsigned short	CommDebugIoOut;
	unsigned short	CommDefFilter;
	unsigned short	CommIoOut;
	GLP_IO_INFO	GlpIoInfo[MAX_SLOT_CNT];	

	unsigned short	Inst_Operand_Area[MAX_PROGRAM_AREA] ;	/* LOAD AREA */
	unsigned short	Inst_Address2Step[MAX_PROGRAM_AREA] ;	/* �A�h���X����X�e�b�v�ϊ��e?�u�� */
	unsigned short	Inst_Operand_Program[32*1024] ;			/* LOAD AREA(Original) */
	unsigned char	Inst_Operand_BitIdx[MAX_PROGRAM_AREA] ;	/* Bit Dev Idx(0->) */
}PLC_DATA_SRAM;
typedef struct{
	int	extCnt;				//�O�����
	struct{
		unsigned int	ID;				//0:I/O,1:�ʐM���W��?��,2:���x�v,���̑�
		unsigned char*	address;	//�擪�A�h���X
		int	SlotNo;
		char	Version[8];
		char	Model[16];
	}ExtInfo[MAX_EXT_CNT];
}EXT_IO_INF;


#ifdef	INTER_PROC
#define	__EXT
#else
#define	__EXT	extern
#endif

	__EXT	int	ProcMode;			/* �q�t�m��?�h */
	__EXT	int	PlcProcRunning;		/* �q�t�m?�� */
	__EXT	int	GLP_STCommFlag;		/* ��?��� */
	__EXT	int	GLP_STScanFlag;		/* �X�L�����X�g�b�v��� */
	__EXT	int	GLP_STStopFlag;		/* �����X�g�b�v��� */
	__EXT	int	GLP_StopFlag;		/* �f�k�o�X�g�b�v��� */
	__EXT	int	GLP_StopStep;		/* GLP�X�g�b�v�X�e�b�v */
	__EXT	int	GLP_StopAddr;		/* GLP�X�g�b�v�A�h���X */
	__EXT	int	ScanRunCnt;			/* Scan Run				*/
	__EXT	int	ScanStartStep;		/* Scan Start Step		*/
	__EXT	unsigned short *CodeData;	/* �R?�h�̈���s�ʒu */
	__EXT	unsigned short *StepCodeData;	/* �R?�h�̈���s�ʒu */

	__EXT	unsigned char	BeforeDevInfo[MAX_STEP/8];
	__EXT	unsigned char	BeforeDevInfo2[MAX_STEP/8];
			/* PLC Data Area */
	__EXT	int				ParaDevCnt;			/* Vertual Device Entry Count */
	__EXT	unsigned short  ParaDevInf[MAX_FCALL_PARA][5] ;		/* �֐��p�f�o�C�X */
	__EXT	unsigned short	*InstArea;			/* Step Check */

	__EXT	int				EditCnt;
	
	__EXT	int	PatchCodeTableCnt;
	__EXT	int	StartStepNo;

	
	__EXT	volatile	int CulcCurrent_Addr ;                              /* ���ݏ������̖��߂̑��Έʒu */

	__EXT	int	*Load_BoolAddr;
	__EXT	int Load_Bool[MAX_LOAD_CNT] ;
	__EXT	int	PushLoadBoll[MAX_PUSH_CNT];
	__EXT	int *PushLoad_BoolAddr[MAX_LOAD_CNT] ;

	__EXT	int	GlpRunMode;
	__EXT	int	DeviceAddrError;					//0:OK,1:Address Error
	__EXT	volatile	int	PlcSignalInf;			//0:Stop,1:Start
	__EXT	volatile	int	PlcMainRunFlag;			//0:Stop,1:Start
	__EXT	int	PlcCulcStepFlag;
	__EXT	int	ParaDevIdx;							//Parameter No(FCALL)
	__EXT	int	PathcOnFlag;						//Patch Flag

	__EXT	int	TimeloopCnt;
	__EXT	unsigned int	Time1msloopCnt;			//2008.04.08

	__EXT	struct{
		int	BpCnt;
		int	BpPos[MAX_BP_PRG];
		int	BpBit;
		DEV_BP	Bit_Dev[MAX_BP_BIT];
		int	BpWord;
		DEV_BP	Word_Dev[MAX_BP_WRD];
		int	I_O_Cnt;
		DEV_BP	I_O_Dev[MAX_IO_SET];
	}Mon_Info;
	__EXT	char	PLC_Pass[16];
	__EXT	TIME_CNT_INF	TimCnt;		/* Timer Counter Info */
	__EXT	EXT_IO_INF		extSlotInfo;	/* �O���ڑ���� */
	__EXT	EXT_IO_INF		extInfo;	/* �O���ڑ���� */
	__EXT	unsigned short*	EndCodePos;
	__EXT	int				DeviceError;	//�f�o�C�X�G��?
	//Interrupt ���
	__EXT	int	GlpSysInterrupt;				//0:EI,1:DI
	__EXT	unsigned	int	GlpSysInterruptTimer;			//0:EI,1:DI
	__EXT	unsigned	int	GlpSysInterruptIO[2];			//0:EI,1:DI

	__EXT	volatile	unsigned	int	Plc1msCnt;
	//Special Register Address
	__EXT	unsigned short* GlpSysMode;
	__EXT	unsigned short*	GlpSysSignal;
	__EXT	unsigned short*	GlpSysState;
	__EXT	unsigned short*	GlpSysError;
	__EXT	unsigned short*	GlpSysModukeSts;
	__EXT	unsigned short*	GlpSysClock;
	__EXT	unsigned short*	GlpSysCulc;
	__EXT	unsigned short*	GlpSysRunMode;
	__EXT	unsigned short*	GlpSysTimeMode;
	__EXT	unsigned short*	GlpSysModuleSet;

	__EXT	unsigned short*	GlpModelCode;
	__EXT	unsigned short*	GlpSysVersion;
	__EXT	unsigned short*	GlpVDate;
	__EXT	unsigned short*	GlpSysMaxSc;
	__EXT	unsigned short*	GlpSysMinSc;
	__EXT	unsigned short*	GlpSysNowSc;
	__EXT	unsigned short*	GlpSysAvrSc;
	__EXT	unsigned short*	GlpSysCulcErrSetep;
	__EXT	unsigned short*	GlpSysCulcErredSetep;
	__EXT	unsigned short*	GlpSysErredSetep;
	__EXT	unsigned short*	GlpSysErrorStep;
	__EXT	unsigned short*	GlpSysBreakStep;
	__EXT	unsigned short*	GlpSysSelfTest;
	__EXT	unsigned short*	GlpSysYY;
	__EXT	unsigned short*	GlpSysMM;
	__EXT	unsigned short*	GlpSysDD;
	__EXT	unsigned short*	GlpSysHH;
	__EXT	unsigned short*	GlpSysMIN;
	__EXT	unsigned short*	GlpSysSS;
	__EXT	unsigned short*	GlpSysWW;
	__EXT	unsigned short*	GlpSysInpFilter;
	__EXT	unsigned short*	GlpSysScnCnt;
	__EXT	unsigned short*	GlpSysCscTime;
	__EXT	unsigned short*	GlpSysWDTCnt;
	__EXT	unsigned short*	GlpSysTimeIntrval;


	//GLP IO Contorol
	__EXT	unsigned short	GlpDbgInf;
	__EXT	unsigned short	GlpSysIoInit;
	__EXT	struct{
		unsigned short	TimerValu[Device_Length_T/16];
	}TimerCost[3];			//0:1ms,1:10ms,2:100ms
	__EXT	unsigned char	Timer1msCnt[Device_Length_T];		//2008.04.08
	__EXT	unsigned short	BefTimeOnOffInt[Device_Length_BT] ;
	__EXT	unsigned short	ResetTimeOnOffInt[Device_Length_BT] ;

	__EXT	unsigned short LabelTable[MAX_LABEL_CNT];
	__EXT	unsigned short *StackArea[MAX_CALL_CNT];
	__EXT	int		StackPointer;
	__EXT	unsigned short McTable[MAX_MC_CNT];
	__EXT	unsigned short *IntStackArea;
	__EXT	int				TimerIntEntryCnt;		//?�C??���荞�ݓo?��
	__EXT	int				Intrrupt_IRET;
	__EXT	struct{
				int		lebel;
				unsigned short	TimerIntEnt;
			}EntryTimerInt[MAX_TIME_INT];
	__EXT	unsigned short	EntryIoInt[MAX_IO_INT];
//	__EXT	int				InterruptKind;			//���荞�ݎ�� 1;Timer,2:I/O
//	__EXT	int				InterruptItem;			//���荞��?�ڎ��
	//���荞�݃��x���X?�b�N
	__EXT	int				InterruputCnt;
	__EXT	int				InterruputIn_idx;
	__EXT	int				InterruputOut_idx;
	__EXT	struct{
		int			IntKind;
		int			IntItem;
	}IntLebel[8];
	__EXT	int	*IntLoad_BoolAddr;
	__EXT	int IntLoad_Bool[MAX_LOAD_CNT] ;
	__EXT	unsigned short IntSaveVArea[Device_Length_V];
	//V Device Area
	__EXT	unsigned short SaveVArea[MAX_CALL_CNT][Device_Length_V];

	
	__EXT	int	ForTblCnt;
	__EXT	struct{
		int	ForCnt;
		unsigned short*	ForAddr;
		unsigned short*	NextAddr;
	}ForTbl[100];
	__EXT	int	McNestCnt;
	__EXT	int	McNestBool[256];

//	__EXT	unsigned char	EditBuff[0x8000];	/* For Edit Buffer */
//	__EXT	unsigned short	Inst_Operand_AreaBack[32*1024] ;  /* LOAD AREA */

	__EXT	int	WdtNowCnt;					//Now WDT Counter
	__EXT	int	WdtCnt;						//Setting WDT Counter
	__EXT	int	ResetWdtCnt;				//Reset Counter
	__EXT	int	WdtStartFlag;				//WDT State Flasg

	__EXT	int	TimerPuseFlag;				//Timer State Flag 2008.05.23

	__EXT	int	WordDevMaxCnt;				//Word Dev Max Count 2008.05.24
	__EXT	int	WordCodeIdx;				//Word Dev Code 2008.05.24

	__EXT	int	CulcStepPos;
	__EXT	int	CulcStepSubPos;

	__EXT	int	InterTskFlag;			//Interrupt Task Runnning(1)

	//Latch Area Index
	__EXT	int	StartCTAddr;		//Latch Area
	__EXT	int	EndCTAddr;			//Latch Area
	__EXT	int	StartCCAddr;		//Latch Area
	__EXT	int	EndCCAddr;			//Latch Area

	extern	PLC_DATA_SRAM	PlcDataSram;

#ifdef	WIN32
extern	unsigned char GLPIndexTable[256];
extern	unsigned char GLPIndexChangeTable[256];
#else
extern	const	unsigned char GLPIndexTable[256];
extern	const	unsigned char GLPIndexChangeTable[256];
#endif
/***********************************************************/
//�֐��v���g?�C�v
/***********************************************************/
void	ExtBordCheck(void);
void	SetParamdata(char *wBuff);
int	GetPioSlotNo(void);
void	SetLedMode(void);
void	InitParamFile(void);
void	SetInterruptKind(void);
void	PlcSpecialDevClear(int mode1,int mode2,int mode3);
void	PlcDevAllClear(void);
void	CheckLoopTime(void);
int	GetStopInf(void);


