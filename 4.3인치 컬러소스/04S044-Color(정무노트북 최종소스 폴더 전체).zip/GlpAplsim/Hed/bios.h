/****************************************/
#define	ESC	0x1b
/* #define	PC_START	0xfe */
#define	PC_DNLOAD_START	0xfe		/* Download ���� *//* ksc20090518 */
#define	KEY_EVENT	0xfd			
/* #define	UP_START	0xfc */
#define	PC_UPLOAD_START	0xfc		/* Upload ���� *//* ksc20090518 */
#define	CHG_BASE1	0xfb
#define	CHG_BASE2	0xfa
#define	PC_CONT		0xf9			/* Download Continue blink */
/* #define	PC_ON	0xf8	*/		/* ksc20090518 */
#define	PC_UPDOWN_END	0xf8		/* Download/Upload �Ϸ� */
#define	PC_DNLOAD_END	0xf7		/* Download �Ϸ� */
#define	PC_UPLOAD_END	0xf6		/* Upload �Ϸ� */
/****************************************/
/* Text Draw Mode						*/
/****************************************/
#define	T_REPLACE	0
#define	T_OR		1
#define	T_XOR		2
#define	T_FRONT		3

#ifdef	SIZE_2480_COL
	#define	T_BLACK		0x00000000
	#define	T_RED		0x00ff0000
	#define	T_YELLOW	0x0000ffff
	#define	T_GREEN		0x0000ff00
	#define	T_BLUE		0x000000ff
	#define	T_GRAY		8
	#define	T_SILVER	9
	#define	T_LIME		10
	#define	T_WHITE		0x00ffffff
#else
	#define	T_BLACK		0
	#define	T_HBLACK	1
	#define	T_HWHITE	2
	#define	T_WHITE		3
#endif
/****************************************/
/* Paint Mode							*/
/****************************************/
#define	P_NONE		0
#define	P_PTRN1		1
#define	P_PTRN2		2
#define	P_PTRN3		3
#define	P_PTRN4		4
#define	P_PTRN5		5
#define	P_PTRN6		6
#define	P_PTRN7		7
#define	P_PTRN8		8

#define	CLOCK05	0x20
#define	CLOCK10	0x40
#define	CLOCK20	0x80
/****************************************/
/*	BIOS ProtoType						*/
/****************************************/
extern	void	_di(void);
extern	void	_ei(void);
extern	char	*GP_SYSVER;
extern	char	*GP_RELEASE;
extern	char	*GP_RELEASE_DATE;
extern	char	*dVersion;
extern	char	*GP_MODEL;
extern	char	*PlcPassword;  /* GLP Data Area Password */
//extern	int	CheckMailBox(unsigned int size);

extern	int DModeFlag;
extern	int	IntFlag;
extern	void	DebugSend(void);
#ifdef	WIN32
extern	int		SioPLCDlgCommCnt;
extern	int		SioPCDlgCommCnt;
extern	int		PlcRecData;			/* PLC Rec Compleat */
extern	int		PcRecData;			/* PC Rec Compleat */
#endif
/****************************************/
void DModeSendOneMsg( char *ptr );
void DModeSendPriod( void );

/****************************************/
void	Wait200us( int Cnt );
void	DataWrite(int data,int mode);
void	RTCRead(unsigned char *rtcbuf);
void	RTCWrite(unsigned char *rtcbuf,int rRest);
int	CmdWrite(unsigned char cmd);
int	DataWrite1(unsigned char data);
int	DataWrite2(unsigned short data);
int	AutoWrite(unsigned char data);
int	CheckAutoWrite(void);
void	ClearText(void);
void	ClearLcdGraph(void);
void	Init6963( void );
void	CursorSet(int x,int y);
void	TextWrite(char *text);
void	LCDWrite(unsigned char gData,int offset);
void	CusorAddrSet(int x, int y);
void	CusorOnOff(int mode);
void	Draw1GamenT6963(unsigned char *buff);
void	_T6963Handler( void );
void	SetContrastT6963(int data);
void	LCD_Clear(void);
void	DrawLcd( char* pBitmapBits );
void	_LCDHandler( void );
void	BackLightOnOff(int mode);
void	LCDDisplayEnable(int mode);		//20080814
int   ScanKey(void);
void    BuzOn(void);
void    BuzOff(void);
void	Cmt1IntClear(void);
void	Cmt0IntClear(void);
int	BatteryRead( void );
void	StartMtu2(void);
void	StopMtu2(void);
int		_Mtu2Proc(void);
void	_Mtu2InterruptHandler(void);
void	AplStateOn(void);
int	_WDTProc(void);
void	_WDTInterruptHandler(void);
void	WDT_Reset(void);
void	WDT_Init(void);
void	WDT_Off(void);
void	PcStateOn(void);
void	PasswordLevelWrite(void);
int	Bin2Hex1(int data);
void	Bin2Hex(int data,int cnt,char *buff);
int	ConnectPc(unsigned char rs_input_data);
int	PlcCommCheck(char *buff,char *SndBuff,int cnt);
int	PlcConnect(unsigned char data);
int	gatoi(char *buff);
float	gatof(char *buff);
//int	IsGlpType(void);
void	RamFlashEraze(short *addr);
void	SetContrast(int data);
void	RunLed(int mode);
void	ErrorLed(int mode);
void	DebugLed(int mode);
int	RunSWReadProc( void );
int	RunSWRead( void );
int	DenbunTimeoutProc(void);
void	SetRunStopSwitch(int OnOff);
void	RamFlashEraze(short *addr);
void	RamFlashWrite(short *addr,short *data, long count);
int	RamFlashWriteProc(char *addr,char *data,int size);
int	RamFlashCashWriteProc(char *addr,char *data,int size);
void	PlcStartOutDevClear(void);
void	PlcStartOutStopDevClear(void);
void	PlcMainTaskStopWait(void);
int	DeviceCode2Name(int code, char** Name);
void	Vmemcpy(volatile char *obj,volatile char *src,int cnt);
void	SetEditorBoadrate( int connect, int set_ch );
int	GetEditBoadrate( void );
void	SetLowBattery(int mode);
void	SetPlcTimeError(void);
void	PlcSpDeviceClear(void);
void	SetPlcStationNo(void);
void	StateSignal3(void);
int	ChangeUWAddr(int bit_word,unsigned long* address);
int	CheckPlcDevAccess(int StartAddr,int EndAddr);
unsigned short BINtoBCD16(unsigned short bin_data);
void	ParcentEProc(char* buff,float data);
void	ParcentfProc(char* buff,float data,int keta,int sho);
int	CheckPlc2Connect(void);
void	mWritePlcPass( char* pass );
char*	GetPlcPassAddr(void);
//20100806 add
char*	GetLcdTypeAddr(void);


int	IsPlc1Protocol(void);
int	IsPlc2Protocol(void);
int	GetMsSel(void);
void	GetPlc2Ver(char* chDsp_Ver);
//void	RsModeSetChanel(int Kind,int ch, _SERIALPARAM* pParam);
void	RsModeSetChanel(int Port, _SERIALPARAM* pParam);		//2009.12.21
