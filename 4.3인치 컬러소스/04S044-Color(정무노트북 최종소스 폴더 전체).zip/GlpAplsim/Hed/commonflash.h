/*** Common flash definitions for RVD ***
  /  
 / /
/ / /\
\\\/ /// CLABSYS
 \\ ///  Cyber Lab System
  \\//
   \/
Revision history____
2004-4-28 John

*/


#ifndef __COMMONFLASH_H__
#define __COMMONFLASH_H__


extern WORD GetManID_clablib(WORD FlashBase, WORD FlashManID, WORD BusType); 
extern WORD GetDevID_clablib(WORD FlashBase, WORD Device, WORD BusType);     
extern WORD FlashErase_clablib(WORD BlockAddress, WORD Device, WORD BusType);
extern WORD FlashWrite_clablib(WORD BlockAddr,WORD BufAddr,WORD Count, WORD VerifyFlag, WORD BusType, WORD Device);
extern void Data2Addr( WORD wData,WORD wAddr, WORD width );                  
extern WORD Addr2Data( WORD wAddr, WORD width );                             
extern void Addr2Addr(WORD wAddr1,WORD wAddr2, WORD width );                 
#endif
//			x			x
