void		vScreenSet(int* iScreenNo);
