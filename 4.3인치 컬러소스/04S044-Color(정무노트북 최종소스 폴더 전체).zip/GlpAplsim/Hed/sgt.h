#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<math.h>
#ifdef	WIN32
#include	<time.h>
#define	const
#endif

#include	"define.h"
#include	"mts.h"
#include	"mtscifp.h"
#include	"mail.h"
#include	"mtstimep.h"
#include	"taskhed.h"
#include	"gpstruct.h"
#include	"filesys.h"
#include	"CommBuff.h"
#include	"plcCommBuff.h"
#include	"bios.h"
#include	"piodrv.h"
#ifndef	SIZE_2480_COL
	#include	"disp.h"
#else
	#include	"disp_color.h"
	#include	"dispsim_color.h"
#endif
#include	"kansi.h"
#include	"plchand.h"
#include	"rtc.h"
#include	"rs232c.h"
#include	"rs232c_pc.h"
#include	"plc_func.h"
#include	"iohand.h"
#include	"rs_232cbuff.h"
/********************************************/
/*	Application								*/
/********************************************/
#include	"gp_sysmes.h"
#include	"gp_actst.h"
#include	"gp_almd.h"
#include	"gp_almh.h"
#include	"gp_alml.h"
#include	"gp_asci.h"
#include	"gp_asct.h"
#include	"gp_backl.h"
#include	"gp_barg.h"
#include	"gp_batt.h"
#include	"gp_buzz.h"
#include	"gp_cation.h"
#include	"gp_class.h"
#include	"gp_clrd.h"
#include	"gp_clock.h"
#include	"gp_clkt.h"
#include	"gp_cmta.h"
#include	"gp_cmtt.h"
#include	"gp_dattrn.h"
#include	"gp_devmon.h"
#include	"gp_devin1.h"
#include	"gp_devin2.h"
#include	"gp_lcdcnt.h"
#include	"gp_srch.h"
#include	"gp_toucht.h"
#include	"gp_usrs.h"
#include	"gp_numt.h"
#include	"gp_parts.h"
#include	"gp_lampt.h"
#include	"gp_panelm.h"
#include	"gp_trdg.h"
#include	"gp_lineg.h"
#include	"gp_statis.h"
#include	"gp_numi.h"
#include	"gp_numinp.h"
#include	"gp_langs.h"
#include	"gp_hppmode.h"
#include	"gp_mainc.h"
#include	"gp_other.h"
#include	"gp_pcdg.h"
#include	"gp_plctset.h"
#include	"gp_prtout.h"
#include	"gp_screen.h"
#include	"gp_seriset.h"
#include	"gp_testmode.h"
#include	"gp_setmen.h"
#include	"gp_setup.h"
#include	"gp_timesw.h"
#include	"gp_title.h"
#include	"gp_modelver.h"
#include	"gp_xydevmon.h"

#include	"comlib.h"

#include "IPDefines.h"
#include "EachRoutins.h"
#include "matrix.h"
#include	"Intepreter.h"
#include	"gp_env.h"

#ifdef	MAIN
	extern	_SETUP			Set;					/* set value save struct */


	_DISPLAY *Dspname;
	_DISPLAY1 *LDspname;
	/* kansi.c */
	extern	unsigned	PLCCnNewRec;		/* Main PLC Timeout */
	extern	unsigned	PLCCnNewRec2;		/* Sub PLC Timeout */
	extern	int		PLCCnErrorDsp;
	/* plchand.c */
	extern	int		PlcConnectFlag;				/* PLC�ڑ��t���O */
	extern	int		PlcConnectFlag2[32];			/* PLC�ڑ��t���O(PLC TYPE2) 20081007 */

#else
	extern	_DISPLAY *Dspname;
	extern	_DISPLAY1 *LDspname;

#endif
/************************************************************/
void	vPrintOutMain(int* iScreenNo);
void	SendTaskAnal(int p1);
void	SendTaskSet( int p1,int p2 );
void	SendTaskFile( int p1 );
void	IniTask( STTFrm* pSTT );
void	SetTask( int p1,int p2 );
void	DispAnalysis( STTFrm* pSTT );
void	PlcConnectDisp(void);
void	PlcConnectDispClr(void);
unsigned long Encrypt(char *s);
void Decrypt(unsigned long x, char *s);
void	FileTask( int mode );
void	DrawLine_Func( int iTagSize, unsigned char *ucTagBuff, int iColor);
void	DrawRect_Func(  int iTagSize, unsigned char *ucTagBuff , int iColor);
void	DrawCircle_Func(  int iTagSize, unsigned char *ucTagBuff , int iColor);
void	DrawText_Func( int iTagSize, unsigned char *ucTagBuff , int iColor);
int	DrawShape(int ShapeNo, int sX, int sY, int eX, int eY, int iFrameC, int iPlateC);
void	vFreemeilAll(void);
void	vWindowFreemeil(void);
void	ClearTagInfo(void);
int	CheckSecurityLevel(int iScreenNow);

int	FontLoad(char *SaveAddr,char **base_adr);
void	SendInitTask(int mcod,int mcmd);
void	ClearDeviceMonInfo(void);
void	GlpExtBoadDisp(int* iScreenNo);
void	SelectIoSettingMenu(int *iScreenNo);
void	GlpSetFilter(int* iScreenNo);
void	GlpSetInterrupt(int* iScreenNo);
void	GlpSetItem(int* iScreenNo);
void	GlpSetSync(int* iScreenNo);
