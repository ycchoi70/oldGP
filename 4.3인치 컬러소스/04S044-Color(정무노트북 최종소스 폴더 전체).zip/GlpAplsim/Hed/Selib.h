/***********************************************
 * NAME    : 44BLIB.H                          *
 * Version : 17.Apr.00                         *
 ***********************************************/


#ifndef __44blib_h__
#define __44blib_h__

#ifdef __cplusplus
extern "C" {
#endif

#define DebugOut Uart_Printf

#define min(x1,x2) ((x1<x2)? x1:x2)
#define max(x1,x2) ((x1>x2)? x1:x2)

#define ONESEC0 (62500)	//16us resolution, max 1.04 sec
#define ONESEC1 (31250)	//32us resolution, max 2.09 sec
#define ONESEC2 (15625)	//64us resolution, max 4.19 sec
#define ONESEC3 (7812)	//128us resolution, max 8.38 sec
#define ONESEC4 (MCLK/128/(0xff+1))  //@60Mhz, 128*4us resolution, max 32.53 sec

#define NULL 0

#define EnterPWDN(clkcon) ((void (*)(int))0xe0)(clkcon)


/*44blib.c*/
//void Delay(int time); //Watchdog Timer is used.

//void *malloc(unsigned nbyte); 
//void free(void *pt);

void Port_Init(void);
void Cache_Flush(void);
void Uart_Select(int ch);
//void Uart_Init(int mclk,int baud);
void Uart_SendByte0(int data);
void Uart_SendByte1(int data);


void Led_Display(int data);

void ChangePllValue(int m,int p,int s);

void ChangeMemCon(unsigned *pMemCfg);
void EnableInterrupt(void);
void DisableInterrupt(void);

unsigned char Uart0_RxInt(void);
unsigned char Uart1_RxInt(void);
void	Usrt0TxMode(int mode);
void	Usrt1TxMode(int mode);
void	SetIntMask(int MskData);
void	ReSetIntMask(int MskData);
unsigned int	GetCountTimer4(void);


#ifdef __cplusplus
}
#endif

#endif /*__44blib_h__*/
