void	SetAlarmList_Func(int iDispOrder);
int DrawAlarmList_Func(int mode,_ALARM_LIST_EVENT_TBL* AlarmListEventTbl, int iDispOrder);
int	 GetLineCnt(int iFontSizeH, int iFontSizeV, int sY,  int eY);
void AlarmListDispWatch(int iOrder);
void	TextSizeCut(int iLen, short ShapeNo, short XDot,short YDot, char* cBuffer);
