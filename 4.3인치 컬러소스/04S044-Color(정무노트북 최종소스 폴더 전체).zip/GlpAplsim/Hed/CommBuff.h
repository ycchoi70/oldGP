/*****************************************/
/*	Common Buffer Area                   */
/*****************************************/
#define	BUFF_DISP_CNT	16
#ifdef	MAIN
#define	___EXT
#else
#define	___EXT	extern
#endif


/******************************************************
	Data Area Structure
******************************************************/
typedef struct{
	int				year;			/* year[0]:10,year[1]:1 */
	int				mon;			/* mon[0]:10,mon[1]:1 */
	int				day;			/* day[0]:10,day[1]:1 */
	int				week;			/* week               */
	int				hour;			/* hour[0]:10,hour[1]:1 */
	int				min;			/* min[0]:10,min[1]:1 */
	int				sec;			/* sec[0]:10,sec[1]:1 */
} RTC_DATA;

typedef struct{
	unsigned short		iLineStyle;				/* Line Style */
	unsigned long		iLineColor;				/* Line Color */
} _LINE_INFO;

typedef struct{
	unsigned short		iLineStyle;				/* Rectangle Line Style */
	unsigned long		iLineColor;				/* Rectangle Line Color */
	unsigned short		iPattern;				/* Rectangle Pattern */
	unsigned long		iForeColor;				/* Rectangle Foreground Color */
	unsigned long		iBackColor;				/* Rectangle Background Color */
} _RECTANGLE_INFO;

typedef struct{
	unsigned long		iLineColor;				/* Circle Line Color */
	unsigned short		iPattern;				/* Circle Pattern */
	unsigned long		iForeColor;				/* Circle Foreground Color */
	unsigned long		iBackColor;				/* Circle Background Color */
} _CIRCLE_INFO;

typedef struct{
	unsigned long		iColor;					/* FanShape Color */
	unsigned long		iScaleColor;			/* Scale Color */
} _ORGGATA_INFO;

typedef struct{
	char*				cpDevVal;
	char				cDevName[2];
	unsigned short		iDevFlag;				/* 16 or 32 bit ������ */
	int					iDevNumber;
	int					iRegNumber;
	int					iBitFlag;				/* bit, word Flag */
	short				iOnOff;					/* AlarmHistory���� ���� ���� Ȯ�ο��� �����.*/					
	short				iCnt;
	
} _DEV_SUPERVISOR_TBL;

typedef struct{
	short		sx;
	short		sy;
	short		ex;
	short		ey;
} _AREA_INFO;

/********************************************************************************/
/* ����ü�� : _ALARM_HISTORY_MAIN_INFO											*/
/* ��    �� : ALARM_HISTORY�� ���̴� PROJECT ������ ���� ����ü					*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 26�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� :																	*/
/********************************************************************************/
typedef struct{
/*	short			iDetailDisp;*/		/* Detailed Display (1:Not Display, 2:Comment Window, 3:Base Screen)		 */
/*	int				iCommentNo;  */
	short			iMode;				/* History or Cumulation */
	short			iDelModeChkFlag;	
	int				iDispNoSel;
} _ALARM_HISTORY_MAIN_INFO;


typedef struct{
	int				iSunbun;
	int				iDisplayNo[256];
} _ALARM_HIST_ITEM;


/********************************************************************************/
/* �� �� ü ��: _ALARM_HISTORY_EVENT_TBL										*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
*/
	unsigned int		ShapeNo;
	short				iFontSizeH;
	short				iFontSizeV;
	short				iSortInfomation;		/* Form->Sort : 0x00 : Oldest,	0x01 : Latest */
	short				iDispStyle;				/* 0x02 : Occurrences		0x11 : Restorations		0x?? : Occur Frequency */
	short				iDispRows;
	short				iTitleColor;
	short				iMainContentInfo;
	short				iDateContentInfo;
	short				iTimeContentInfo;
	short				iOccurredColor;	
	short				iFrameColor;
	short				iPlateColor;
	short				iRestorationInfo;
	short				iRestorationDateInfo;
	short				iRestorationTimeInfo;
	short				iRestorationColor;		
	short				iOccurredWide;
	short				iMessageWide;
	short				iRestorationWide;
	short				iMessgaeTitleSize;		
	short				iRestoredTitleSize;
	short				iFreqTitleSize;	
	short				iOccurredTitleSize;
	short				iOccurredTextSize;
	short				iRestoredTextSize;
	char*			cMsgTitleContents;
	char*			cFreqTitleContents;
	char*			cRestoredTitleContents;
	char*			cOccurredTitleContents;
	char*			cOccurredTextContents;
	char*			cRestoredTextContents;
	int					SuperVOffset;
} _ALARM_HISTORY_EVENT_TBL;

/********************************************************************************/
/* �� �� ü ��: _ALARM_LIST_EVENT_TBL											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
*/
	char				cStorgeDeviceName[2];
	int					iStorageDeviceNumber;
	unsigned int		ShapeNo;
	short				iFontSizeH;
	short				iFontSizeV;
	short				iStorgeChecked;			/* 0x14: Checked    0x10: UnChecked */
	int					iDetailDispChecked;		/* Detail Display Check 0 : No Check, 1 : Comment Window, 2 : Base Screen */
	int					iDevicePointers;		/*iDevicePointers[10];*/	/* Detail Display Number*/
	int					iScrollOnFlag;
	short				iStoreMemoryFlag;
	short				iDisplayDateFlag;
	int					iDevicePnt;
	unsigned int		iCommentStartNo;		/* Comment���۹�ȣ */	
	short				iPlateColor;
	short				iFrameColor;	
	short				iNumber;
	short				iSort;
	short				iStoreMemoryVal;		/* Store Memory*/
	int					SuperVOffset;
} _ALARM_LIST_EVENT_TBL;
typedef struct{
	short	x1;
	short	y1;
	short	x2;
	short	y2;
} SCALE_POIN;

typedef struct{
	unsigned int	iLineColor;
	unsigned int	iLineType;
} _GRAPH_INFO; 

typedef struct{
	short		isPosX;
	short		isPosY;
	short		iePosX;
	short		iePosY;
} _TT;
/********************************************************************************/
/* �� �� ü ��: _NUMERIC_EVENT_TBL												*/
/* ��    �� : Numeric ������ ���� ����ü										*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
*/
	int					iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	char				cDeviceName[2];					
	int					iDeviceNumber;
	short 				iPlateColor;			/* Plate �÷����� */
	short 				iFrameColor;			/* Frame �÷����� */
	short			 	iTextColor;				/* Text	�÷����� */
	short			 	iDecimalPnt;			/* �Ҽ����� ���� ��ġ */
	short			 	iDigits;				/* ǥ���� ��ġ�� ���̰� */
	int					ShapeNo;				/* Shape�� ����ߴٸ� �׿� �ش��ϴ� shape��ȣ */
	int					iGain1;					/* Gain1���� */
	int					iGain2;					/* Gain2���� */
	int					iOffset;				/* Offset���� */
	short				iSignFlag;				/* 0 : Signed BIN		1 : Unsigned BIN */
	short				i1632BitFlag;			/* 0 : 16bit			1 : 32bit */
	short				iFontSizeH;
	short				iFontSizeV;
	short				iFormat;				/* 0x00 : Signed decimal */
												/* 0x01 : Unsigned decimal */
												/* 0x02 : Hexadecimal */
												/* 0x03 : Octal */
												/* 0x04 : Binary */
												/* 0x05 : Real */
	short				iAlignment;				/* 0 : Right Alignment */
												/* 1 : Left Alignment */
												/* 2 : Cneter Alignment */
												/* 3 : Disp All Digits Checked */
	/* char			cDispData[256]; */
	long				lBefDevBal;/* ������ �о�� ����̽� ���� �����Ѵ�. */
	short				iHighQuality;
	int					SuperVOffset;
} _NUMERIC_EVENT_TBL;

/********************************************************************************/
/* �� �� ü ��: _ASCII_EVENT_TBL												*/
/* ��    �� : Ascii Display Tag ������ ���� ����ü								*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 16�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
*/
	int					iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	short				iFontSizeH;
	short				iFontSizeV;				/* Font�� ũ������ */
	short				iPlateColor;			/* Plate �÷����� */
	short				iFrameColor;			/* Frame �÷����� */
	short				iTextColor;				/* Text	�÷����� */
	int					ShapeNo;				/* Shape�� ����ߴٸ� �׿� �ش��ϴ� shape��ȣ */
	short				iAlignment;				/* 0 : Right Alignment    1 : Left Alignment    2 : Cneter Alignment */						
	short				iDigits;				/* ǥ���� ��ġ�� ���̰� */
	char				cDeviceName[2];					
	int					iDeviceNumber;
	char*				cBefDevData;			/* choijh 20020811 add */
	int					SuperVOffset;
} _ASCII_EVENT_TBL;


/********************************************************************************/
/* �� �� ü ��: _NUMERIC_INPUT_EVENT_TBL										*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : PLC�� ������ �������Ƿ� ����̽��� �������� �ʴ´�.				*/
/********************************************************************************/
typedef struct{
/*	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
*/
	int					iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	char				cDeviceName[2];			/* ����̽� ������ */
	int					iDeviceNumber;			/* ����̽� ��ȣ */
	int					ShapeNo;				/* Shape�� ����ߴٸ� �׿� �ش��ϴ� shape��ȣ */
	short				iFormSizeV;
	short				iFormSizeH;				/* Form Tab���� ������ ���� */
	short				iFormFormat;
	short				iAlignment;
	short				iBasicNumColor;
	short				iDecimalPoint;
	short				iDigits;
	unsigned	int		iUser_id;
	unsigned	int		iMoveDest_id;
	int					iGain1;
	int					iGain2; 
	int					Offset;
	short				iUpperFlag;
	short				iLowerFlag;
	short				iPlateColor;
	short				iFrameColor;		
	char				cUpperDeviceName[2];
	char				cLowerDeviceName[2];
	int					iUpperDeviceNumber;
	int					iLowerDeviceNumber;
	int					iUpperFixedVal, iLowerFixedVal;	
/*	short				iTriggerTypeVal;*//* ON, OFF */
	char				cTriggerDeviceName[2];
	int					iTriggerDeviceNumber;
	short				iSignFlag;    /* signed unsigned */
	short				i1632BitFlag; /* 16 or 32 */
	int					iUpperRegistNumber;
	int					iLowerRegistNumber;
	int					iTriggerRegistNumber;
	char				cTempBuffer[32];
	long				lBefDevBal;
/*	int					iTriggerVal;*/
	int					iHighQuality;
	short				SuperVOffset;
	short				Up_SuperVOffset;
	short				Lw_SuperVOffset;
	short				Tr_SuperVOffset;
} _NUMERIC_INPUT_EVENT_TBL;


/********************************************************************************/
/* �� �� ü ��: _ASCIIINPUT_EVENT_TBL											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
*/
	int					iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	int					iTriggerRegistNumber;
	char				cDeviceName[2];			/* ����̽� ������ */
	int					iDeviceNumber;			/* ����̽� ��ȣ */	
/*	short				iTriggerTypeSet;*/
	short				iFrameColor;
	short				iFontSizeH;
	short				iFontSizeV;
	short				iAlignment;
	short				iTextColor;
	short				iPlateColor;
	int					ShapeNo;
	short				iDigits;
	unsigned	int		iUser_id;
	unsigned	int		iMoveDest_id;
/*	int					iTriggerTypeVal;*/
	char				cTriggerDeviceName[2];
	int					iTriggerDeviceNumber;
/*	int					iTriggerVal;*/
/*	char*				cBefDevData;*/
	short				Dev_SuperVOffset;
	short				Trig_SuperVOffset;
} _ASCIIINPUT_EVENT_TBL;


/********************************************************************************/
/* �� �� ü ��: _CLOCK_EVENT_TBL												*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 28�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	unsigned short		BeShapeUsed;
*/
	short				iFontSizeV;
	short				iFontSizeH;
	unsigned int		iPlateColor;
	unsigned int		iFrameColor;
	unsigned int		iTextColor;
	unsigned int		ShapeNo;
	unsigned int		iFormatTag;
	unsigned int		iFormatFlag;
	char				sec;
	int					SuperVOffset;
} _CLOCK_EVENT_TBL;
/********************************************************************************/
/* �� �� ü ��: SCREEN_TAG_DATA													*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 14�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
		char			cObjects;
		char			UpdateFlag;
		char			UpdateFlag1;
		short			iWindowNo;
		short			DevOrder;
		short			DevCnt;
		short			BeShapeUsed;
		short			sX;
		short			sY;
		short			eX;
		short			eY;
		unsigned char*	TagPos;
		union{
			struct{
				short			iTriggerSec;			/* TrendGraph */
				short			iStoreMemoryVal;
				short			NoDeviceFlag;
			}Trend;
			struct{
				char			iOffFontPosition;
				char			iOnFontPosition;
				char			iTriggerTypeSet;
				char			TouchKeyVal;
				short			iBStartDataPos;
				short			iWStartDataPos;
				short			iBActDataPos;
			}TouchSw;
			struct{
				short			cOffPosition;
				short			cOnPosition;
			}Lamp;
			struct{
				short			iTriggerTypeVal;
				short			iBStartDataPos;
				short			iTriggerVal;
			}NumIn;
			struct{
				short			iTriggerTypeVal;
				short			iBStartDataPos;
				short			iTriggerVal;
			}AsciiIn;
			struct{
				short			ScalePos;
			}Statics;
			struct{
				short			StoreMemNo;
			}AlarmList;
			struct{
				short			DevOrder[3];
			}BarGraph;
		}uu;
} SCREEN_TAG_DATA;
/********************************************************************************/
/* �� �� ü ��: _PANEL_METER_EVENT_TBL											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 28�� (ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	unsigned short		sX;
	unsigned short		sY;
	unsigned short		eX;
	unsigned short		eY;
	unsigned short		BeShapeUsed;
*/
	int					iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	int					iUpRegisterNumber;
	int					iDwRegisterNumber;
	char				cDeviceName[2];			/* ����̽� ������ */
	int					iDeviceNumber;			/* ����̽� ��ȣ */	
	unsigned int		ShapeNo;
	unsigned short		iUpSel;
	char				cUpDeviceName[2];
	unsigned int		iUpDeviceNumber;
	unsigned short		iDwSel;
	char				cDwDeviceName[2];
	unsigned int		iDwDeviceNumber; 
	unsigned int		iScalePnts;
	unsigned short		iScaleColor;
	unsigned short		iNeedleColor;
	unsigned short		iMeterPanColor;
	unsigned int		iDirection;
	unsigned int		iType;
	short				iChkSigned;				/* 0x00 : Signed BIN		0x01 : UnSigned BIN */
	short				iChkBit;				/* 0x00 : 16bit			0x01 : 32bit */
	unsigned short		iScaleDispChk;
	unsigned short		iFrameColor;
	unsigned short		iPlateColor;
	int					iUpFixedValue;
	int					iDwFixedValue;	
	unsigned short		iJutX;
	unsigned short		iJutY;
	short				iPoint;

	long				lBefDevVal;
	long				lBefUpDevVal;
	long				lBefDwDevVal;
	short				SuperVOffset;
	short				Up_SuperVOffset;
	short				Dw_SuperVOffset;
} _PANEL_METER_EVENT_TBL;

/* Touch Switch */
typedef struct{
	void				*linkPos;
	short				iIndirectChekFlag;				/* Indirect�� �����ߴ��� ���ߴ����� ����(������ 1, �������� 0) */
	short				iInitValueConditionCheckFlag;	/* Initial Value Condition����(������ 1, �������� 0) */
	char				cWordDeviceName[2];				/* Device Name */
	unsigned int		iWordDeviceNumber;				/* Device Number */
	char				cIndirectWordDeviceName[2];
	unsigned int		iIndirectWordDeviceNumber;
	long				iConditionValue;
	long				iResetValue;
	long				iFixedValue;
	short				iExpressFlag;					/* Signed BIN, Unsigned BIN, 16, 32 bit */
	short				iDeviceDataNum;
	int					SuperVOffset;
} _TOUCH_SWITCH_WORD_DEVICE; 

/* Touch Switch */
typedef struct{
	void			*linkPos;
	short			iBitDeviceSetFlag;				/* Bit Device ������ ������ Flag   (Momentary(1), Set(2), Reset(3), Alternate(4)) */
	char			cBitDeviceName[2];					/* Device Name */
	unsigned int	iBitDeviceNumber;					/* Device Number */
	short			iDeviceDataNum;
	char			cMomentaryFlag;						/* */
	int				SuperVOffset;
	int				MomentSw;						/* 0:OFF,1:ON */
} _TOUCH_SWITCH_BIT_DEVICE; 

typedef struct{
	short		sX;
	short		sY;
	short		eX;
	short		eY;
	short		iVal;
} _COMMENT_WINDOW_KEYVAL; 
/********************************************************************************/
/* �� �� ü ��: _TOUCHSWICH_EVENT_TBL											*/
/* ��    �� :  ������ ���� ����ü												*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 9�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
*/
	short				sX;
	short				sY;
	short				eX;
	short				eY;
/*
	short				BeShapeUsed;
*/
	int				iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	int				iDispBitTriggerRegistNumber;
	char			cDeviceName[2];			/* ����̽� ������ */
	int				iDeviceNumber;			/* ����̽� ��ȣ */
	
/*	_TOUCH_SWITCH_WORD_DEVICE	tswd[20];
	_TOUCH_SWITCH_BIT_DEVICE	tsbd[50];*/

	_TOUCH_SWITCH_WORD_DEVICE				*posWord;
	_TOUCH_SWITCH_BIT_DEVICE				*posBit;

/*	short				iTriggerTypeSet;*/
	short				TouchType;
	int					iDispTrigger;
	short				iShapeOption;/* Basic�ǿ��� Shape�������� */
	int					iOptionRepeat;
	short				iSimultaneousPress;
	short				iOffSwitchColor;
	short				iOnSwitchColor;
	short				iOnOffFrameColor;
	short				iIsOffText;
	short				iIsOnText;
	unsigned int		iKeyCode;	
	int					iOffImgNum;
	int					iOnImgNum;
	char				cDispBitTriggerDeviceName[2];
	int					iDispBitTriggerDeviceNumber;
	int					iOptionTriggerType;
	char				cOptionTriggerTypeDeviceName[2];
	int					iOptionTriggerTypeDeviceNumber;	
	int					iOffTextStart;
	int					iOnTextStart;
	short				iOffTextColor;
	short				iOnTextColor;
	short				iOff68DotFlag;
	short				iOn68DotFlag;
	short				iOffFontSizeV;
	short				iOffFontSizeH;
	short				iOnFontSizeV;
	short				iOnFontSizeH;
	short				iOffTextSize;
	short				iOnTextSize;
	char*			cOffTextContent;
	char*			cOnTextContent;
	int				iMomentaryCnt;
	int				iSetCnt;
	int				iResetCnt;
	int				iAlternateCnt;
	int				MemOffset;/* Bit���� */
	int				MemOffset2;/* Word���� */
	int				iIndirectWordUnChkCnt;
	int				iIndirectWordChkCnt;  /* Indirect�������� ���� Word����, Indirect������ Word���� */
	int				iScreenNo;
	int				iActionBit;
	int				iActionWord;
	short			iBaseAction;
	short			iBefKeyDispVal;		/* Key Display On Off*/
	int				iBefKeyVal;			/* Touch On Off */
/*	short			iOffFontPosition;
	short			iOnFontPosition;
*/
/*	short			BsX;
	short			BsY;
	short			BeX;
	short			BeY;
*/
	short			iOnOffFlag;
	short			iBefSwitch;				/* 040606 */
	short			iBefDspSwitch;			/* 040606 */
	int				SuperVOffset;
	short			iBitPos;
	short			iWordPos;
} _TOUCHSWICH_EVENT_TBL;


/********************************************************************************/
/* �� �� ü ��: _BARGRAPH_EVENT_TBL  											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 29�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	unsigned short	sX;
	unsigned short	sY;
	unsigned short	eX;
	unsigned short	eY;	
	unsigned short	BeShapeUsed;
*/
	int				iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	int				iBaseRegistNumber;
	int				iUpperRegistNumber;
	int				iLowerRegistNumber;
	char			cBaseDeviceName[2];		/* ����̽� ������ */
	int				iBaseDeviceNumber;		/* ����̽� ��ȣ */	
	unsigned int	ShapeNo;
	unsigned short	BeScaleDisp;
	unsigned short	iScalePoint;	
	unsigned short	iDirecition;/* Direction */
	unsigned short	iFrameColor;
	unsigned short	iBaseCaseInfo;
	unsigned short	iUpperCaseInfo;
	unsigned short	iLowerCaseInfo;
	unsigned short	IsSigned;
	unsigned short	iFrameChecked;
	unsigned short	iScaleDispChecked;
	unsigned short	iScalePosition;
	unsigned short	iPlateColor;
	unsigned short	iScaleColor;	
	char			cDwDeviceName[2];
	unsigned int	iDwDeviceNumber;
	char			cUpDeviceName[2];
	unsigned int	iUpDeviceNumber;
	char			cMonitorDeviceName[2];
	unsigned int	iMonitorDeviceNumber;
	short			iSignedFlag;			/*	SIGNED 0x00, UNSIGNED 0x01, BCD	0x02 */
	short			iMonitorBitFlag;		/*  16Bit = 0, 32Bit = 1 */
	unsigned short	iBarColor;		

	long			lBefDevVal;
	long			lBefBeDevVal;
	long			lBefUpDevVal;
	long			lBefDwDevVal;
	short			Bas_SuperVOffset;
	short			Dw_SuperVOffset;
	short			Up_SuperVOffset;
	short			Mon_SuperVOffset;
} _BARGRAPH_EVENT_TBL;

/********************************************************************************/
/* �� �� ü ��: _COMMENT_EVENT_TBL  											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 30�� (��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	unsigned short	sX;
	unsigned short	sY;
	unsigned short	eX;
	unsigned short	eY;	
	unsigned short	BeShapeUsed;
*/
	unsigned short	iSwitch;				/* ȭ�鰻���÷��� ȭ�鰻���� �ʿ��Ѱ�� ON, ȸ���� ������ �ʿ䰡 ���� ��� OFF */
	int				iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	char			cDeviceName[2];			/* ����̽� ������ */
	int				iDeviceNumber;			/* ����̽� ��ȣ */
	short				iBitWordFlag;
	unsigned short	iFontSizeH;
	unsigned short	iFontSizeV;
	unsigned short	iFrameColor;
	unsigned int	ShapeNo;
	unsigned short	iOffTextColor;
	unsigned short	iOffPlateColor;
	unsigned int	iOffNo;
	unsigned short	iOnTextColor;
	unsigned short	iOnPlateColor;
	unsigned int	iOnNo;
	unsigned short	iOffTxtSize;
	unsigned short	iOnTxtSize; 		
	char*			cOffTextBuffer;
	char*			cOnTextBuffer;
	short				iOffAttrChecked;
	short				iOnAttrChecked;
	short				iOffDirectChecked;
	short				iOnDirectChecked;
/*	int				iOnTextStartPtn;
	int				iOffTextStartPtn;
*/	short				iOnTextLength;
	short				iOffTextLength;

	short			iStartNo;
	short				iEdtTextColor;
	short				iEdtPlateColor;
	short				iEdtAttrChecked;
	/*long			lDispData;*/

	unsigned short	BefBitDevVal;
	long			BefWordDevVal;
	int				SuperVOffset;
} _COMMENT_EVENT_TBL;
/********************************************************************************/
/* �� �� ü ��: _LAMP_EVENT_TBL													*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 31��(��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
*/
	int				iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	char			cDeviceName[2];			/* ����̽� ������ */
	int				iDeviceNumber;			/* ����̽� ��ȣ */
	short				iOnFontSizeH;
	short				iOnFontSizeV;
	short				iOffFontSizeH;
	short				iOffFontSizeV;
	short				iOnFrameColor;
	short				iOffFrameColor;
	int				OffShapeNo;
	int				OnShapeNo;
	int				OffPartsNo;
	int				OnPartsNo;
	short				OffLampColor;
	short				OnLampColor;
	short				iOffTxtColor;
	short				iOnTxtColor;
	short				iOffTxtLen;
	short				iOnTxtLen;
	short				iOff68DotFlag;
	short				iOn68DotFlag;
	short				iShapeSelect;
	char*			cOffTxtBuffer;
	char*			cOnTxtBuffer;
/*	char			cOffPosition;
	char			cOnPosition;
*/
	int				iBefDevVal;				/* 20020815 choijh add */ 
/*
	short				BsX;
	short				BsY;
	short				BeX;
	short				BeY;
*/
	/***************************************/
/*	short				iDevOrder;*/
	int				SuperVOffset;
} _LAMP_EVENT_TBL;

/********************************************************************************/
/* �� �� ü ��: _LINEGRAPH_EVENT_TBL											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 31��(��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
*/
	int				iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	int				iLowerRegistNumber;
	int				iUpperRegistNumber;
	char			cDeviceName[2];			/* ����̽� ������ */
	int				iDeviceNumber;			/* ����̽� ��ȣ */
	char			cUpperDeviceName[2];
	char			cLowerDeviceName[2];
	int				iUpperDeviceNumber;
	int				iLowerDeviceNumber;
	int				ShapeNo;
	short				iScalePosition;
	short				iPoints;
	short				iDirecition;/* Direction */
	short				IsChkVNDisplayed;
	int				VNDisplayedVal;/* Value not Displayed */
	short				iFrameColor;
	short				iPlateColor;
	short				iNumber/* Number : ��Ʈ�� ��Ÿ�� ���� ����(�ִ� 8������ ��Ÿ���� �ִ�) */;
	short				iCaseUpFixedVal;
	short				iCaseLoFixedVal;
	short				iSignedFlag;
	short				i1632BitFlag;
	long			lUpperFixedData;
	long			lLowerFixedData;	
	short				iFrameChecked;
	short				iScaleDispChecked;
	short				iScaleColor;
	short				iScalePointsV;
	short				iScalePointsH;
	_GRAPH_INFO		lf[8];

	long			lBefUpperDevVal;
	long			lBefLowerDevVal;
	char*			cBefMonitorDevVal;/* ������ 400������ ����*/
	short			SuperVOffset;
	short			Up_SuperVOffset;
	short			Lw_SuperVOffset;
} _LINEGRAPH_EVENT_TBL;

typedef struct{
	short	x1;
	short	y1;
} SCALE_POINT;
/********************************************************************************/
/* �� �� ü ��: _STATISTICS_EVENT_TBL											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 1��(��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
*/
	int				iRegisterNumber;		/* ����̽� ��Ϲ�ȣ */
	char			cDeviceName[2];			/* ����̽� ������ */
	int				iDeviceNumber;			/* ����̽� ��ȣ */
	int				ShapeNo;
	short				iScalePnts;
	short				iScaleColor;
	short				iScaleDispChk;
	short				iPartitionNo;
	short				iFrameColor;
	short				iPlateColor;
	short				iGraphType;
	short				iDirection;	
	short				iSignedFlag; /* signed unsigned ������ */
	short				i1632BitFlag; /* 16, 32bit ������ */
	short				iPartitionColor[8]; 
	long			lBefDeviceValue[8];
	/* Memory ������ ������ ���� ����. */
/*	SCALE_POINT		ScalePoint[52];*/
	int				SuperVOffset;
} _STATISTICS_EVENT_TBL;
	/* Memory ������ ������ ���� ����. */

/********************************************************************************/
/* �� �� ü ��: _PARTS_EVENT_TBL												*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 6�� 4��(ȭ)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short			sX;
	short			sY;
	short			eX;
	short			eY;
	short				BeShapeUsed;
*/
	int					iRegisterNumber;			/* ����̽� ��Ϲ�ȣ	*/
	char				cDeviceName[2];				/* ����̽� ������		*/
	int					iDeviceNumber;				/* ����̽� ��ȣ		*/	
	short				iPositionInfo;			/* iPositionInfo	0x00 : Top-Left,    0x08 : Center	*/ 
	short				iBitWordFlag;			/* iBitWordFlag		0x02 : Bit			0x01 : Word		 0x03 : Fixed*/
	short				iType;
	int					BitOnNo;
	short				BitOnColor;
	int					BitOffNo;
	short				BitOffColor;
	int					iPartsSwitchingNo;
	short				iFixedColor;
	int					iMarkNo;
	short				iStartNo;
	int					iPreComment;
	/*short 			iDispData;*/
/*	short				sX;
	short				sY;
	short				eX;
	short				eY;
*/
	int				iBefDevVal;
	int				SuperVOffset;
} _PARTS_EVENT_TBL;
	
/********************************************************************************/
/* �� �� ü ��: _TRENDGRAPH_EVENT_TBL											*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 31��(��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
*/
	int					iLowerRegistNumber;
	int					iUpperRegistNumber;
	char				cUpperDeviceName[2];
	char				cLowerDeviceName[2];
	char				cStMemoryDeviceName[2];
	int					iStMemoryDeviceNumber;
	int					iUpperDeviceNumber;
	int					iLowerDeviceNumber;	
	int					ShapeNo;
	short				iScalePosition;
	short				iPoints;
	short				iDirecition;		/* Direction */
	short				IsChkVNDisplayed;
	int					VNDisplayedVal;		/* Value not Displayed */
	short				iFrameColor;
	short				iPlateColor;
	short				iNumber				/* Number : ��Ʈ�� ��Ÿ�� ���� ����(�ִ� 8������ ��Ÿ���� �ִ�) */;
	short				iCaseUpFixedVal;
	short				iCaseLoFixedVal;
	short				iSignedFlag;
	short				i1632BitFlag;
	long				lUpperFixedData;
	long				lLowerFixedData;	
	short				iFrameChecked;
	short				iScaleDispChecked;
	short				iScaleColor;
	short				iScalePointsV;
	short				iScalePointsH;
	_GRAPH_INFO			tf[8];
/*	unsigned int		iTriggerSec;*/
	int					iStoreMemoryCode;
/*	short				DisPoint[8][51];*/	/* GT_Designer������ 8������ ������ Gp������ 4�������� Display �ȴ�. */

	long				lBefMonitorDevVal[50];
	long				lBefUpperDevVal;
	long				lBefLowerDevVal;
	short				iStoreMemoryVal;
	short				NoDeviceFlag;
	short				Up_SuperVOffset;
	short				Lw_SuperVOffset;
	short				Mon_SuperVOffset;
} _TRENDGRAPH_EVENT_TBL;



/********************************************************************************/
/* �� �� ü ��: _FIGURE_EVENT_TBL												*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 5�� 31��(��)												*/
/* �� �� �� : �� �� ȣ 															*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
/*
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
*/
	short				iDrawType; /* Line : 0x01, Circle : 0x06, Rectangle : 0x03, Text :0x09 , Bmp : 0x0A	*/
		union{
			struct{			/* LINE			*/
				_LINE_INFO			LineType;
			}LineInfo;

			struct{			/* CIRCLE 	*/
				_CIRCLE_INFO		CircleType;
				short	iRadius;	
			}CircleInfo;

			struct{			/* RECTANGLE 	*/
				_RECTANGLE_INFO		RectType;

			}RectInfo;

			struct{			/* TEXT	*/
				short				iTextColor;
				short				iSizeH;
				short				iSizeV;
				short				LineCnt;
				char*				TextSPoint;
			}TextInfo;

			struct{			/* BMP	*/
				int					iTagSizeOf;
				char*				BmpSPoint;
			}BmpInfo;
		}ST;
	int				SuperVOffset;
}_FIGURE_EVENT_TBL;

/********************************************************************************/
/* �� �� ü ��: TIME_ACTION_DB													*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 11�� 19��(ȭ)												*/
/* �� �� �� : �� �� ��  														*/
/* ��    �� : 																	*/
/********************************************************************************/
typedef struct{
	short		iMax;
	short		iLine;
	short		iTopY;
} _CLEAN_AREA;
typedef struct{
	char				cInputDispBuff[41];
	char				cBufferData[41];
	short				iInputNo;			/* ���� ��Ŀ���� �ִ� IventTableCnt*/
	short				iFirstflag;			/* ��ġŰ�� ���� ���� 1 : �׷�������, 0 : �� �׷��� ����	*/
	short				iFlag;				/* Cursor ���� flag */
/*	short				iDispOrder;			*/
	short				iKeyOnOff;
	short				iLen;				/* ǥ�� ���� */
	short				iKeyType;			/* ���� �Է��ϰ� �ִ� Ű�� Ÿ���� ���Ѵ�. */
} _INPUT_DISPLAY_BUFF;


/********************************************************************************/
/* ����ü�� : _SWITCHING_SCREEN_DEVICE											*/
/* ��    �� : PROJECT ���������� SYSTEM������ ���� ����ü						*/
/* ��    �� :																	*/
/* ��    �� :																	*/
/* �� �� �� : 2002�� 8�� 30�� (��)												*/
/* �� �� �� : �� ���� 															*/
/* ��    �� :																	*/
/********************************************************************************/
typedef struct{
	short			iBaseScreenFlag;
} _SWITCHING_SCREEN_DEVICE;
/****************************/
/*	TAG Common Struct		*/
/****************************/
typedef struct{
	volatile	char	UpdateFlag;
	volatile	char	UpdateFlag1;
	short				SaveUpdateFlag;
	short				sX;
	short				sY;
	short				eX;
	short				eY;
	short				BeShapeUsed;
}TAG_HED;
typedef	struct{
	int	kind;
	int	addr;
	unsigned short *DevAddr;
	int	idx;
}MON_DEV_ITEM;
typedef struct{
	int	flag;
	int	cnt;
	MON_DEV_ITEM Device[80];
}MON_DEV_TYPE;


	/* Device �Ď��̈� */
extern	int					gDeviceCnt;
extern	int					gDeviceCntBit;
extern	int					gDeviceCntWord;
extern	int					DeviceCnt;
extern	char				DeviceData[512*4];
extern	int					DeviceCntSys;
extern	DEV_DATA			DeviceDataHed[512];	/* [32] */
extern	DEV_DATA			DeviceDataSys[512];  /* System  */

	___EXT	unsigned int	IntMaskData;
	___EXT	volatile	int		TaskStartFlag;



	___EXT	int				SioLFFlag;
	___EXT	int				SioEchoFlag;
	___EXT	RTC_DATA		SystemTime;
	___EXT	RTC_DATA		NowTime;
	___EXT	RTC_DATA		DisplayNowTime;
	___EXT	int		ClockDisplayed;
	___EXT	int		RsTimeOutCnt[2];
	___EXT	int		RsTimeOutTask[2];

/*	___EXT	int				pcFileSize[16];*/
	___EXT	char			pcFileName[16][16];
/*	___EXT	unsigned char  pcData[1][1024];*/

	___EXT  char			cPcTempFileName[16];/* ���Ϻм��½�ũ���� �о�� ������ �̸� */
	___EXT	int				pcFileCnt;
	___EXT	int				pcNewRec;
	___EXT	int				iBaseScreenCnt;
	___EXT	int				iWinScreenCnt;
	/* Device �Ď��̈� */

	___EXT	int				iNowScreenNum;
	___EXT	short				iSwitch_ScreenNum1;
	___EXT	short				iSwitch_ScreenNum2;
	___EXT	int				iPreviousScreenNum;
	___EXT	int				iScreenPosition;


/*	___EXT	KEYWINDOW_SET				KeyWindow;*/
	___EXT	_COMMENT_WINDOW_KEYVAL		ComWinKey;
	___EXT  SCALE_POIN ScalePoin[52];
	___EXT	short		TrendDisPoint[8][51];	/* GT_Designer������ 8������ ������ Gp������ 4�������� Display �ȴ�. */
	___EXT _CLEAN_AREA					CleanComment;
	/* �� ȭ���  AscDisplayTag�� �ִ� 50������ ǥ���Ҽ� �ִ�. */
	
	___EXT _TT						tt[8];
/*	___EXT _LINEGRAPH_EVENT_TBL*		LineGraphEventTbl[50];
	___EXT _LAMP_EVENT_TBL*				LampDispEventTbl[50];
	___EXT _ASCII_EVENT_TBL*			AsciiDispEventTbl[50];	
	___EXT _NUMERIC_EVENT_TBL*			NumericEventTbl[50];
	___EXT _CLOCK_EVENT_TBL*			ClockEventTbl[50];
	___EXT _ALARM_HISTORY_EVENT_TBL*	AlarmHistoryEventTbl[1];
	___EXT _ALARM_LIST_EVENT_TBL*		AlarmListEventTbl[1];
	___EXT _PARTS_EVENT_TBL*			partsDispEventTbl[50];
	___EXT _PANEL_METER_EVENT_TBL*		PanelMeterEventTbl[50];
	___EXT _TRENDGRAPH_EVENT_TBL*		TrendGraphEventTbl[50];
	___EXT _STATISTICS_EVENT_TBL*		StatisticsEventTbl[50];
	___EXT _BARGRAPH_EVENT_TBL*			BarGraphEventTbl[50];
	___EXT _TOUCHSWICH_EVENT_TBL*		TouchSwitchEventTbl[50];
	___EXT _COMMENT_EVENT_TBL*			CommentEventTbl[50];
	___EXT _NUMERIC_INPUT_EVENT_TBL*	NumericInputEventTbl[50];
	___EXT _ASCIIINPUT_EVENT_TBL*		AsciiInputEventTbl[50];*/
	/* 2003/03/31	Figure 
	___EXT	_FIGURE_EVENT_TBL*			FigureEventTbl[50];*/
	/***********************/

	/*----------------------------------*/
/*	___EXT int				IventTableCnt;*/
/*	___EXT int				IventTableCnt1;*/
/*	___EXT void*			IventTable[512];*/
	/*----------------------------------*/
	___EXT _SWITCHING_SCREEN_DEVICE	SwitchingScreenDevice;
/*	___EXT _DEV_SUPERVISOR_TBL*			DevSupervisorTbl[256];*/
	___EXT _ALARM_HISTORY_MAIN_INFO*	AlarmHistoryMainInfo;
	___EXT _ALARM_HIST_ITEM*			AlarmHistItem;/* �ִ� 256�������� */


	___EXT 	SCREEN_TAG_DATA				ScreenTagData[MAX_TAG_NO];

	___EXT 	_INPUT_DISPLAY_BUFF			InputDisplay;			/* Numeric,AsciiInput���� ���ڸ� ���÷��� �ϱ� ����. */


	___EXT	short				iHistoryPositionVal;	/* AlarmHistory �� �����ؾ� �� ��ġ��		*/
	___EXT	short				iHistoryOnOff;			/* AlarmHistory�� ���� ����					*/
	___EXT  short				iHistoryDisCnt;			/* AlarmHistory ���÷��� �ϱ� ���� ī���� */

	___EXT  short				iAlarmListDisCnt;		/* AlarmList ���÷��� �ϱ� ���� ī���� */
	
	___EXT  short				iPositionVal;			/* AlarmList �� �����ؾ� �� ��ġ��			*/
	___EXT  short				iAlarmOnOff;			/* AlarmList�� ���� ����					*/
	___EXT  int					iMainKeyCode;
	___EXT	short				PassWordSettingFg;		/* Password Setting Flag 050411 */
	___EXT	short				PassWordSettingChg;		/* Password Setting Flag 050411 */
	___EXT  short					iAlarmHistFlag;

	___EXT  short				iUserScreenFlag;	/* ȭ���϶��� ���� ó��. */
	___EXT	short				iFirstScreen;
	___EXT	short				iTransFlag;			/* �ٿ�ε尡 �Ǿ����� */
	___EXT  int					iScreenDisp;		/* ȯ�漳������ ��ũ���� ���÷����ϱ� ����... */

	___EXT	int					iOverFlagNum;		/* overlap �ؾ� �ϴ� ��ũ���� ����. */


	___EXT  int					iGlobleOrder;		/* ���� Tag�� ���� */

	___EXT  short				iDeviceScanFlag;		/* ��ĵ����: ON, ��ĵ���� OFF */
	___EXT  short					iDeviceSearchCnt;
	___EXT  int					iDispOrder;				/* Object�� ��¼��� */
	___EXT  int					iDataFlag;				/* Touch Key�� Signed Unsigned 16, 32bit�÷��� */
	___EXT  short					AsciiDispCnt;		/* AsciiDisplayTag�� ���� */
	___EXT  short					NumericDispCnt;		/* NumericDisplayTag�� ���� */
	___EXT  short					ClockDispCnt;
	___EXT  short					CommentDispCnt;		/* CommentDisplayTag�� ���� */
	___EXT  short					AlarmHistoryDispCnt;/* AlarmHistoryDisplayTag�� ���� */
	___EXT  short					AlarmListDispCnt;	/* AlarmListDisplayTag�� ���� */
	___EXT  short					PartDispCnt;		/* PartDisplayTag�� ���� */
	___EXT  short					LampDispCnt;		/* LampDisplayTag�� ���� */
	___EXT  short					PanelMeterDispCnt;	/* PanelMeterTag�� ���� */
	___EXT  short					TrendGraphDispCnt;	/* TrendGraphDisplayTag�� ���� */
	___EXT  short					LineGraphDispCnt;	/* LineGraphDisplayTag�� ���� */
	___EXT  short					BarGraphDispCnt;	/* BarGraphDisplayTag�� ���� */
	___EXT  short					StatisticsDispCnt;	/* StatisticsDisplayTag�� ���� */
	___EXT  short					TouchSwitchDispCnt;	/* TouchSwitchDisplayTag�� ���� */
	___EXT  short					NumericInputCnt;	/* NumericInputTag�� ���� */
	___EXT  short					AsciiInputCnt;		/* AsciiInputisplayTag�� ���� */
	___EXT  int					iOnSignalStart;
	___EXT  int					iDeviceOffset;
	___EXT	short					iFigureCnt;				/* Figure�� ���� */
/*	leesi 10.02	*/
	___EXT  short				AsciiDispCnt1;			/* AsciiDisplayTag Counter */
	___EXT  short				NumericDispCnt1;		/* NumericDisplayTag Counter */
	___EXT  short				ClockDispCnt1;
	___EXT  short				CommentDispCnt1;		/* CommentDisplayTag Counter */
	___EXT  short				AlarmHistoryDispCnt1;	/* AlarmHistoryDisplayTag Counter */
	___EXT  short				AlarmListDispCnt1;		/* AlarmListDisplayTag Counter */
	___EXT  short				PartDispCnt1;			/* PartDisplayTag Counter */
	___EXT  short				LampDispCnt1;			/* LampDisplayTag Counter */
	___EXT  short				PanelMeterDispCnt1;		/* PanelMeterTag Counter */
	___EXT  short				TrendGraphDispCnt1;		/* TrendGraphDisplayTag Counter */
	___EXT  short				LineGraphDispCnt1;		/* LineGraphDisplayTag Counter */
	___EXT  short				BarGraphDispCnt1;		/* BarGraphDisplayTag Counter */
	___EXT  short				StatisticsDispCnt1;		/* StatisticsDisplayTag Counter */
	___EXT  short				TouchSwitchDispCnt1;	/* TouchSwitchDisplayTag Counter */
	___EXT  short				NumericInputCnt1;		/* NumericInputTag Counter */
	___EXT  short				AsciiInputCnt1;			/* AsciiInputisplayTag Counter */	
	___EXT  short				iDeviceSearchCnt1;
	___EXT  int				DeviceCnt1;

	___EXT	short				iPassFlag;					/* Pass Word Flag		*/
	___EXT	char				cPassBuff[9];				/* Input Pass Word Save Buff	*/
	___EXT	short				iPassLevel;					/* Pass Level */
	___EXT	short				iPassPoint;					/* Pass ���� ȭ�� ��ũ���� �迭��° �� */
	___EXT	char				iAlternateflag;				/* Keyflag	*/
	___EXT	char				iPass1Id;					/* Pass1�� ������Ű�� ���� �����÷��� */

	/* leesi 10.02 */
	___EXT  short			iWinStartPx;   /* Window Start Point X */
	___EXT  short			iWinStartPy;   /* Window Start Point Y */
	___EXT  short			iWinEndPx;   /* Window Start Point X */
	___EXT  short			iWinEndPy;   /* Window Start Point Y */

	___EXT  short			iTouchFlag;


	/* leesi 2003.01.09 */
	___EXT	short				iComCnt;					/* Comment�� ����.			*/

	/* leesi 2003.08.20 */
	___EXT	short				iAsciiKeyflag;				/* AsciiKey Display �� ��� Ŀ���� ���� Ű ǥ�� flag	*/
	___EXT	short				iAsciiReDispflag;			/*  */
	___EXT	int					iTaskActFlag;							/* ��ɺ� Ÿ��ũ Ȱ��ȭ �÷��� */
	/**************************************************************************/
	___EXT	short				DownloadFileInfo;			/* 0:NewFile,1:Openning		*/
	/**************************************************************************/
	/* Tag Info								*/
	___EXT	short				TagFileCnt;
	___EXT	struct{
		short				iScreenNo;
		short				iOffset;
		unsigned char		*cTagBuf;
		short				iFilePointer;
		short				iPos;
	}TagFileInfo[8];
	/**************************************************************************/
	___EXT	short	PlchandTask;		/* �^�X�N������ */		
	___EXT	short	Plc2handTask;		/* �^�X�N������ */		
	___EXT	short	PlcstateTask;		/* �^�X�N������ */		
	___EXT	short	ConnectTask;		/* �^�X�N������ */
	/**************************************************************************/
	/* PC Work */
	___EXT  int		PcFilefp;
	___EXT	int		UpLoadMode;		/* */
	___EXT	int		RetryCnt;			/* Retry Count */
	___EXT  char*	UpdateProjectInf;	/* 2008.09.03 */
	___EXT  int		UpdateProjectBaseCnt;	/* 2008.09.03 */
	___EXT  int		UpdateProjectWindowCnt;	/* 2008.09.03 */
	___EXT  int		UpdateProjectBlkNo;	/* 2008.09.03 */
	___EXT  int		UpdateProjectSendCnt;	/* 2008.09.03 */

	/* leesi 2003.02.27 */
	___EXT	char*				iPartPoint;

	___EXT	short				iStoreScreenNum[16];			/* TrendGraph ScreenNum */

	/* KeyData�̈� */
	___EXT	char				KerRepeatFlag;		/* 020917 */
	___EXT	unsigned char				KeyTochData[8+2];
	___EXT	struct {
		int		EntryCnt;
		char	RepeatNo[8][8+2];
	}RepeatInfo;
	___EXT	char	PlcDataReadBuff[512];		/* PLC Read Temp */
	___EXT	short			ScalePosCnt;
	___EXT	short			ScalePosCnt1;
	___EXT	SCALE_POINT		ScalePoint[8][52];
	/********************************/
	/*	FONT						*/
	/********************************/
#ifdef	WIN32
	___EXT	unsigned char			GpFont[0x200000];
#endif
	/*******************************/
	___EXT	int		DebugLoop;
	___EXT	volatile	int	GLP_MyTaskNo;

	/* PlcComm.c */
	___EXT	int	SmtStoRecCnt;
	___EXT	int	WpFlag;
	___EXT	char	*WpWriteBuff;
	___EXT	int	*TableCnt;
	___EXT	char	*SWpWriteBuff;
	___EXT	int		ProgDownFlag;
	___EXT	MON_DEV_TYPE	DevMon[16];

	___EXT	unsigned int SubsModeFlag;		/* �r�t�a�r���[�h�t���O */
	___EXT	unsigned int PloadFlag;			/* �v���O�������[�h�t���O */
	___EXT	unsigned long DefaultAdress;			/* �A�h���X�����͎��̃f�t�H���g�l */

	___EXT	int DModeFlag;
	___EXT	int	PlcEditorPort;				//PLC Editor Connect Port
	___EXT	volatile	unsigned int	PcTimeout;
	___EXT	volatile	unsigned int	PcTimeout1Char;
	___EXT	volatile	unsigned int	PcTimeout1Char0;
	___EXT	volatile	unsigned int	PlcTimeout;
	___EXT	volatile	unsigned int	PlcTimeout1Char;
	___EXT	volatile	unsigned int	PlcTimeout1Char0;
	___EXT	volatile	unsigned int	MonTimeout;
	___EXT	volatile	unsigned int	SavePcTimeout;
	___EXT	volatile	unsigned int	SavePcTimeout1Char;
	___EXT	volatile	unsigned int	SavePcTimeout1Char0;
	___EXT	volatile	unsigned int	SavePlcTimeout;
	___EXT	volatile	unsigned int	SavePlcTimeout1Char;
	___EXT	volatile	unsigned int	SavePlcTimeout1Char0;
	___EXT	volatile	unsigned int	SaveMonTimeout;
	___EXT	volatile	unsigned int	GlpTimeout;

	___EXT	_TOUCHKEY		Key;
	___EXT	_SCREEN_DATA	Screen[514];	
	___EXT	_SCREEN_DATA	WinScreen[3];			/* Max = 3 */				
	___EXT	_NOWDEV			BuffDip[BUFF_DISP_CNT];
	___EXT	_NOWDEV			NowDip;

	___EXT	int		WaitDisplayTask;
	___EXT	int		WaitClassifTask;
	___EXT	int		WaitBaseChange;
	___EXT	int		WaitSetting;
	___EXT	int		WaitFileTask;
	___EXT	short			iScreen;					/* ȯ�漳��ȭ��EiScreen = 0	�翁E� ���� ȭ��EiScreen = 1 */	

	___EXT	int iScreenNum;
	___EXT	int		SaveiLampNumber;

	/*********************************/
	/*	PC Recive Watch              */
	/*********************************/
	___EXT	volatile	int	BaseChangeFlag;			/* Base Change Flag 0:normal,1:Changing */
	___EXT	volatile	int	BaseChangeFlag1;			/* Base Change Flag 0:normal,1:Changing */
	___EXT	volatile	int	BaseChangeFlag2;			/* Base Change Flag 0:normal,1:Changing */
	___EXT	volatile	int	TrendClerFlag;		/* TrendCler OFF Set 050313 */

	___EXT	int		loopProj;
	/************************************/
	/*	1�o�b�N���C�g					*/
	/************************************/
	___EXT	int	BackLitsCnt;		/* �b */
	___EXT	int	BackLitmCnt;		/* �� */
	___EXT	int	BackLitSec;
	___EXT	int	BackLitFlag;
	___EXT	int	BuzzerOnFlag;
	/************************************/
/*	___EXT	int		ProtocalDownLoad;		ksc20090516 */  
	/************************************/
	/*	PLC Connect Error State			*/
	/************************************/
	___EXT	int		PLCCnErrorDsp;
	___EXT	int		PLCCnErrorOff;
	___EXT	unsigned	PLCCnNewRec;		/* Main PLC Timeout */
	___EXT	unsigned	PLCCnNewRec2;		/* Sub PLC Timeout */
	___EXT	int		AlarmHistryOutData;			/* Alarm History On/OFF */
	___EXT	int		displayTime;

	___EXT	unsigned int	In100MSecCnt;		/* 100ms Countor */
	___EXT	int		InSecCnt;		/* 1s Countor */
	___EXT	struct find_t UpFinddata;
	___EXT	int		SerchFirstFlag;
	___EXT	int		BlockNo;
	___EXT	int		UpFileSize;
	___EXT	int		UpFileIdx;
	#ifndef	WIN32
	___EXT	char	*UpBaseNo;
	___EXT	char	*UpWinNo;
	#else
	___EXT	char	UpBaseNo[MAX_BASE_NO];
	___EXT	char	UpWinNo[MAX_WIN_NO];
	#endif
	___EXT	char	UpParts;
	___EXT	char	UpComment;
	___EXT	char	UpHist;
	___EXT	char	UpFreq;
	___EXT	int		CommModeData;
	___EXT	int		PcHistryFlag;
	/*int		PcCommonFlag;*/
	___EXT	int		HistIdx;
	___EXT	unsigned char	*CommonSendBuf;
	___EXT	char	*f_base_adr;	/* Font Base Address */
	___EXT	int		FontCnt;		/* Font Load Count */
	___EXT	int		Hexidx;
	___EXT	int		FontFirstFlag;
	#ifdef	WIN32
	___EXT	unsigned char	RecpRBuff[0x10000];
	___EXT	unsigned char	RecpRSubBuff[0x8000];
	#endif
	___EXT	int		FileRetVal;				/* File Write Flag */
	___EXT	char sLanguageCode;
	___EXT	char sFontCode;
	___EXT	char seFontCode;
	___EXT	char sFontName[12];
	___EXT	char seFontName[12];

	___EXT	int		PlcKansiFlag;				/* PLC�Ď��t���O */
	___EXT	int		KansiFirst;		
	___EXT	int		PlcErrorFlag;
	___EXT	int		PlcConnectFlag;				/* PLC�ڑ��t���O */
//	___EXT	int		ElsPlcOK;					/* PLC Prog Info 0:NOT,1:YES */
	___EXT	int		PlcType;

	___EXT	int		Plc2ChanelNo;				/* 20081025 */
	___EXT	int		PlcConnectFlag2[32];		/* PLC�ڑ��t���O(PLC TYPE2) 20081007 */
	___EXT	int		PlcType2Flag;
	___EXT	int	PlcKansiOkFlag;
	___EXT	unsigned	char	rDataFx[512];
	___EXT	unsigned	char	rDataPlc2[512];
	___EXT	int		ProtocolDownloadFlag;		/* �������� �ٿ�ε� Flag */ /* 20090610 */



//	___EXT	int		SecTimeCnt;				/* �b�P�ʂŃC���N�������g */
	___EXT	char	Hexbuff[256+2];
	___EXT	char	DataBuf[64];

	___EXT	int	Sio1OutCnt;
	___EXT	char	*Sio1OutBuf;
	___EXT	int	Sio0OutCnt;
	___EXT	char	*Sio0OutBuf;
	___EXT	int		Sci0ErrorFlag;
	___EXT	volatile	unsigned	BerRecTime;		/* 040608 */
	___EXT	volatile	int		BoardRateFlag;		/* 0:9600.7.E,1:38400.8.E,2:19200.8.E,3:9600.8.E,4:Else */
	___EXT	volatile	int		BoardRateChangingFlag;
	___EXT	int	CommResult;
	___EXT	int	CommResult0;
	___EXT	int	CommRecKind;
	___EXT	int	CommRecKind0;
	___EXT	int	wCommRecKind;
	___EXT	int	wCommRecKind0;
#ifdef	WIN32
	___EXT	int	CommRecWinKind;
	___EXT	int		OutDispFlag;
#endif

	___EXT	int  KeyData;
	___EXT	unsigned short          KeyRptFlag;
	___EXT	unsigned char           KeyPrev;
	___EXT	unsigned        RptTime1;
	___EXT	unsigned        RptTime2;

	___EXT	int     KeyFreeMbx;         /* Key���͗p */
	___EXT	int		MousXaddr;
	___EXT	int		MousYaddr;
	___EXT	int		MousXaddr1;
	___EXT	int		MousYaddr1;
	___EXT	long   lMouseX;
	___EXT	long   lMouseY;
	___EXT	int    lMouseKey;
	___EXT	int    lMouseAction;
	___EXT	char	KeyTochDataWork[8+2];
	___EXT	char	BefKeyTochDataWork[8+2];
	___EXT	int		RunStopSwitch;		/* 061127 Run Switch */
	___EXT	int		LedModeFlag;		/* 080115 Led Mode */
	___EXT	int		LedSettingFlag;		/* 080115 Led Mode */
	___EXT	unsigned int	LedBlinkTime;
	___EXT	int		StartUpFlag;		//�����オ����
	___EXT	int		DownloadStopFlag;		/* Gp Download */

	___EXT	volatile	unsigned int RecTimeOut;

	//2008.08.14
	___EXT	int		KeyWinCheck_sx;		//Numeric,Adci Input Area
	___EXT	int		KeyWinCheck_sy;		//Numeric,Adci Input Area
	___EXT	int		KeyWinCheck_ex;		//Numeric,Adci Input Area
	___EXT	int		KeyWinCheck_ey;		//Numeric,Adci Input Area


	/* Write Area Save	2008.05.22 */
	___EXT	unsigned short	SaveWriteArea[WRT_DEV_CNT];


#include	"GpCommon.h"
