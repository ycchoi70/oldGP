/*** Intel NOR Type flash definitions for RVD ***
  /  
 / /
/ / /\
\\\/ /// CLABSYS
 \\ ///  Cyber Lab System
  \\//
   \/
 
Revision history___
2004-4-28 John
2004-8-25 John
	change HWORD to WORD
*/

#ifndef __INTELSHARP_H__
#define __INTELSHARP_H__
#define INTEL_EXIT	0xffffffff	// Read Array
#define INTEL_ID	0x90909090	// Read Identifier
#define INTEL_CFI	0x98989898	// CFI Query
#define INTEL_STAT	0x70707070	// Read Status Register
#define INTEL_CLEAR_STAT	0x50505050	// Clear Status Regiter
#define INTEL_ERASE	0x20202020	// Block Erase
#define INTEL_CONFIRM	0xD0D0D0D0	// Command confirmation
#define INTEL_WRITE	0x40404040	// Program
#define INTEL_LOCK	0x60606060	// Lock Control
#define INTEL_UNLOCK	0x01010101	// Unlock
#define INTEL_PAGE	0x41414141	// Page programming 
#define INTEL_BUFFER	0xe8e8e8e8	// buffer to flash programming
#define INTEL_SINGLE	0x74747474	// Single buffer Programming
#define DATA_POLLING	0x0080
#define FUSING_OK	0x0080	// Fusing Test
#define ERASE_OK	0x0020	// Erase Test
#define MITSUBISHI_BUFFER	0x0e0e0e0e	// buffer to flash programming
#define BUFFER_AVAILABLE	0x80	//Buffer available

WORD Intel16ClearState(volatile WORD Address);
unsigned Intel16FlashGetManID( volatile WORD /*Flash BaseAddress */ );
unsigned Intel16FlashIsBlockLocked(volatile WORD /*Block Base Address */);
unsigned Intel16FlashBlockUnlock(volatile WORD /* Block Base Address */);
unsigned Intel16FlashBlockLock(volatile WORD /* Block Base Address */);
unsigned Intel16WaitState(volatile WORD /*Write Address*/);
unsigned Intel16FlashErase(volatile WORD /*Block Address*/);
unsigned Intel16FlashWrite( volatile WORD /*Write Address*/, WORD /*Buffer Address*/, const WORD /*Count*/, const WORD /*VerifyFlag*/ );
unsigned  Intel16FlashWriteBuffer( volatile WORD /*Write Address*/, WORD /*Buffer Address*/, WORD /*Count*/, WORD /*BufferSize*/, const WORD /*VerifyFlag*/);
unsigned  Mitsubishi16FlashWritePage( volatile WORD /*WriteAddress*/, WORD /*BufferAddress*/, WORD /*Count*/, const WORD /*PageSize*/, const WORD /*VerifyFlag*/);
unsigned  Mitsubishi16FlashWriteLockedPage( volatile WORD /*WriteAddress*/, WORD /*BufferAddress*/, WORD /*Count*/, const WORD /*PageSize*/, const WORD /*VerifyFlag*/);
unsigned Mitsubishi16FlashPageProgram(volatile WORD /*WriteAddress*/, WORD /*BufferAddress*/, const WORD /*PageSize*/);
unsigned  Mitsubishi16SingleBufferWrite(volatile WORD /*WriteAddress*/, WORD /*BufferAddress*/);
void Mitsubishi16FlashSoftwareLockRelease( volatile  WORD /*BlockBase*/);
#endif // #ifndef __INTELSHARP_H__
