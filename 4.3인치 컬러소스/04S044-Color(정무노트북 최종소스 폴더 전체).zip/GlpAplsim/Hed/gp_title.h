void	vInit(void);
int		iGPTitleDisp(int mode);
