void	SelectMenu(int *iScreenNo);

