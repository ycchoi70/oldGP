//#define	TEST_PROT	1 /* Protocol Include */   /* �ڸ�Ʈ�� �ٿ�δ� ���������� ���, �߿��� �ۼ��� �ڸ�Ʈ ó�� */
//                        �ڸ�Ʈ ������� ICE������ c10000�������� �����ϴ� �߿���� �ҽ��� ���������� ���
#ifndef	DEFINE_PROC
#define	DEFINE_PROC

//�ý��� �޼��� ����� ���
//GlpAplsim ���丮���� Message.bat ����. GlpMessage���丮���� ������


//LCD CONTRAST SETTING [ KJC / ��Ƽ���̿��� ]
//#define		KJC		1

/****************************************/
/*	CPU MODE							*/
/****************************************/
/* **********************************************************************************************************/
/* hsh 20060314 �𵨸� define	*//* GP New Size Selection */
/* ���ڵ� define													 */	
/* GP_S044_SBD0	0x8011 */										 
/* GP_S044_SBD1	0x8012 */										 
/* GP_S057_SBD0	0x8021 */										 
/* GP_S057_SBD1	0x8022 */										 
/* LP_S044_SBD0	0x8201 */										 
/* LP_S044_SBD1	0x8202 */										 
/* **********************************************************************************************************/
#define	LP_S044_SBD0_FIRM	1			//LP-S044S1D0_FIRM	
//#define	LP_S044_SBD0_FULL	1			//LP-S044S1D0_FULL	
//#define	LP_S044_SBD1_FIRM	1			//LP-S044S1D1_FIRM	
//#define	LP_S044_SBD1_FULL	1			//LP-S044S1D1_FULL

//#define	GP_S057_SBD0_FIRM	1			//GP-S057S1D0_FIRM
//#define	GP_S057_SBD0_FULL	1			//GP-S057S1D0_FULL
//#define	GP_S057_SBD1_FIRM	1			//GP-S057S1D1_FIRM
//#define	GP_S057_SBD1_FULL	1			//GP-S057S1D1_FULL

//#define	GP_S044_SBD0_FIRM	1			//GP-S044S1D0_FIRM
//#define	GP_S044_SBD0_FULL	1			//GP-S044S1D0_FULL
//#define	GP_S044_SBD1_FIRM	1			//GP-S044S1D1_FIRM
//#define	GP_S044_SBD1_FULL	1			//GP-S044S1D1_FULL


/* **********************************************************************************************************/
/* **********************************************************************************************************/
/* KOREA, JAPAN, CHINA, ENGLISH, TAIWAN */
/* **********************************************************************************************************/
#define		KOREA	1				
//#define		JAPAN	1				
//#define		CHINA	1				
//#define		ENGLISH	1				
//#define		TAIWAN	1
//#define		RUSSIAN	1

//#define		RUS_SIM				1
//#define		RUS_MESS			1
#define		RUS_MESS_SIMPLE		1
/* **********************************************************************************************************/
/* Version Check 0x0x1201  */
/* Bit15, Bit14, Bit13, Bit12 = 1 : SH,			 2 : ARM												*/
/* Bit11, Bit10, Bit09, Bit08 = 1 : mid Version, 2 : last Version										*/
/* Bit07, Bit06, Bit05, Bit04 = 0 : KOREA, 1 : JAPAN,	2 : CHINA, 3 : ENGLISH, 4 : TAIWAN, 5 : RUSSIAN     */	
/* Bit03, Bit02, Bit01, Bit00 = 1 : Firmware Version, 2 : Full Version		                        */
/* **********************************************************************************************************/
#define	SIZE_2480_COL

#ifdef	LP_S044_SBD0_FIRM
#define	LP_S044_SBD0
#define FIRM_FULL_CODE 1
#endif
#ifdef	LP_S044_SBD0_FULL
#define	LP_S044_SBD0
#define FIRM_FULL_CODE 2
#endif
#ifdef	LP_S044_SBD1_FIRM
#define	LP_S044_SBD1
#define FIRM_FULL_CODE 1
#endif
#ifdef	LP_S044_SBD1_FULL
#define	LP_S044_SBD1
#define FIRM_FULL_CODE 2
#endif
#ifdef	GP_S057_SBD0_FIRM
#define	GP_S057_SBD0
#define FIRM_FULL_CODE 1
#endif
#ifdef	GP_S057_SBD0_FULL
#define	GP_S057_SBD0
#define FIRM_FULL_CODE 2
#endif
#ifdef	GP_S057_SBD1_FIRM
#define	GP_S057_SBD1
#define FIRM_FULL_CODE 1
#endif
#ifdef	GP_S057_SBD1_FULL
#define	GP_S057_SBD1
#define FIRM_FULL_CODE 2
#endif
#ifdef	GP_S044_SBD0_FIRM
#define	GP_S044_SBD0
#define FIRM_FULL_CODE 1
#endif
#ifdef	GP_S044_SBD0_FULL
#define	GP_S044_SBD0
#define FIRM_FULL_CODE 2
#endif
#ifdef	GP_S044_SBD1_FIRM
#define	GP_S044_SBD1
#define FIRM_FULL_CODE 1
#endif
#ifdef	GP_S044_SBD1_FULL
#define	GP_S044_SBD1
#define FIRM_FULL_CODE 2
#endif


#ifdef	KOREA	
	#define LANG_CODE 0
#elif	JAPAN	
	#define LANG_CODE 1
#elif	CHINA	
	#define LANG_CODE 2
#elif	ENGLISH	
	#define LANG_CODE 3
#elif	TAIWAN	
	#define LANG_CODE 4
#elif	RUSSIAN	
	#define LANG_CODE 5
#endif		

/* **********************************************************************************************************/
#define		VER_CHECK_CODE	((2 << 12) | (2 << 8) | (Set.LanguageCode << 4) | (FIRM_FULL_CODE << 0))
/* **********************************************************************************************************/




#ifdef	GP_S044_SBD0
	#define	SIZE_2480
	#define	GP_S044
	#define	SBD0
	#define	GP_TYPE_CODE	0x8011		/* 0x8001:240*80, 0x8002:320*240, 0x8401:GLP(240*80) */ /* 2009.09.22 */
	#define	MAX_FLOAT_CNT	28
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_GP
#endif
#ifdef	GP_S044_SBD1
	#define	SIZE_2480
	#define	GP_S044
	#define	SBD1
	#define	GP_TYPE_CODE	0x8012		/* 0x8001:240*80, 0x8002:320*240, 0x8401:GLP(240*80) */ /* 2009.09.22 */ 
	#define	MAX_FLOAT_CNT	28
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_GP
#endif
#ifdef	GP_S057_SBD0
	#define	SIZE_3224
	#define	GP_S057
	#define	SBD0
	#define	GP_TYPE_CODE	0x8021		/* 0x8001:240*80, 0x8002:320*240, 0x8401:GLP(240*80) */ 
	#define	MAX_FLOAT_CNT	38
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_GP
#endif
#ifdef	GP_S057_SBD1
	#define	SIZE_3224
	#define	GP_S057
	#define	SBD1
	#define	GP_TYPE_CODE	0x8022		/* 0x8001:240*80, 0x8002:320*240, 0x8401:GLP(240*80) */ 
	#define	MAX_FLOAT_CNT	38
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_GP
#endif
#ifdef	LP_S044_SBD0
	#define	SIZE_2480
	#define	LP_S044
	#define	SBD0
	#define	GP_TYPE_CODE	0x8201		/* 0x8001:240*80, 0x8002:320*240, 0x8401:GLP(240*80) */ 
	#define	MAX_FLOAT_CNT	28
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_LP
#endif
#ifdef	LP_S044_SBD1
	#define	SIZE_2480
	#define	LP_S044
	#define	SBD1
	#define	GP_TYPE_CODE	0x8202		/* 0x8001:240*80, 0x8002:320*240, 0x8401:GLP(240*80) */ 
	#define	MAX_FLOAT_CNT	28
	#define SIO_INTRUPT
//	#define SIO_SENSE
	#define MODELTYPE_LP
#endif


#define PLC1STATUS "PLCPROC"
#define PLC2STATUS "PLCPROC2"



/* LCD �o�b�t??�̈�(240/8*80,320/8*240)*/
/************************************/
/*	�ő�?�O��						*/
/************************************/
#define	MAX_TAG_NO		1024
#define	MAX_DEV_CNT		512
/************************************/
/* ��ʃT�C�Y						*/
/************************************/

#ifdef	GP_S057
//	#define	GAMEN_START_X	45			//?�b?�Ƃ��킷����
//	#define	GAMEN_START_Y	70-20
	#define	GAMEN_START_X	0			//?�b?�Ƃ��킷����
	#define	GAMEN_START_Y	0
	#define	G_START_X	45			//?�b?�Ƃ��킷����
	#define	G_START_Y	50
	#define	GAMEN_X_SIZE	320		/* 051027 */
	#define	GAMEN_Y_SIZE	240		/* 051027 */
	#define	WINDOW_Y_SIZE	80		/* 051027 */
	#define	MESH_X		20
	#define	MESH_Y		20
	#define	MAX_MEMORY_SIZE	512


	#define		KEYSWITCH_X_OFFSET_DOT		40		//�޽� ������� ���� �ʿ� 
	#define		KEYSWITCH_Y_OFFSET_DOT		60		//�޽� ������� ���� �ʿ� 

	#define		KEYSWITCH_X_OFFSET_MESH		(KEYSWITCH_X_OFFSET_DOT/MESH_X - 1)	
	#define		KEYSWITCH_Y_OFFSET_MESH		(KEYSWITCH_Y_OFFSET_DOT/MESH_Y - 2)

#endif
#ifdef	LP_S044
	#define	GAMEN_START_X	0			//?�b?�Ƃ��킷����
	#define	GAMEN_START_Y	0
	#define	G_START_X	0			//?�b?�Ƃ��킷����
	#define	G_START_Y	0
	#define	GAMEN_X_SIZE	240		/* 051027 */
	#define	GAMEN_Y_SIZE	80		/* 051027 */
	#define	WINDOW_Y_SIZE	80		/* 051027 */
	#define	MESH_X		16
	#define	MESH_Y		20
	#define	MAX_MEMORY_SIZE	384
#endif
#ifdef	GP_S044
	#define	GAMEN_START_X	0			//?�b?�Ƃ��킷����
	#define	GAMEN_START_Y	0
	#define	G_START_X	0			//?�b?�Ƃ��킷����
	#define	G_START_Y	0
	#define	GAMEN_X_SIZE	240		/* 051027 */
	#define	GAMEN_Y_SIZE	80		/* 051027 */
	#define	WINDOW_Y_SIZE	80		/* 051027 */
	#define	MESH_X		16
	#define	MESH_Y		20
	#define	MAX_MEMORY_SIZE	512
#endif

#ifdef	OLD

#ifdef	GP_S057		//20070110
//	#define		DEF_CONTRAST			148
//	#define		DEF_LCDCLK  			22
//	#define		DEF_CONTRAST			120                // �ʱ� LCD ���
//	#define		DEF_LCDCLK  			19
//	#define		DEF_CONTRAST			157                // ���� LCD ���
	#define		DEF_CONTRAST			166                // ���� LCD ���
	#define		DEF_LCDCLK  			17
	//20100806
	#define		MAX_CONT	32
	#define		CONTRAST_OFFSET			(DEF_CONTRAST- MAX_CONT/2)
#endif



#ifdef	LP_S044
#ifdef	KJC
	#define		DEF_CONTRAST			50
//	#define		DEF_LCDCLK  			43  //        767Khz
	#define		DEF_LCDCLK  			55	//070524  600Khz
//	#define		DEF_LCDCLK  			100	//080530  330KHz
//	#define		DEF_LCDCLK  			35	//080530

	#define		CONST_OFFSET			33
	#define		MAX_CONT				32

#else
	#define		DEF_CONTRAST			20
	#define		DEF_LCDCLK  			70	//100806

	#define		CONST_OFFSET			3
	#define		MAX_CONT				32

#endif
#endif
#ifdef	GP_S044
#ifdef	KJC
	#define		DEF_CONTRAST			50
//	#define		DEF_LCDCLK  			43  //        767Khz
	#define		DEF_LCDCLK  			55	//070524  600Khz
//	#define		DEF_LCDCLK  			100	//080530  330KHz
//	#define		DEF_LCDCLK  			35	//080530

	#define		CONST_OFFSET			33
	#define		MAX_CONT				32

#else
	#define		DEF_CONTRAST			20
	#define		DEF_LCDCLK  			70	//100806

	#define		CONST_OFFSET			3
	#define		MAX_CONT				32

#endif
#endif

#endif


#ifdef	SIZE_2480

	#define		LCD_TYPE_NAME				"OPTIMA"

	//20100806 add
	#define		OPTIMA_LCD_CONTRAST			20 
	#define		OPTIMA_LCD_CLK				70 
	#define		OPTIMA_MAX_CONTRAST			32
	#define		OPTIMA_CONTRAST_OFFSET		(OPTIMA_LCD_CONTRAST- OPTIMA_MAX_CONTRAST/2)


	#define		KJC_LCD_CONTRAST			50
	#define		KJC_LCD_CLK					55
	#define		KJC_MAX_CONTRAST			32
	#define		KJC_CONTRAST_OFFSET			(KJC_LCD_CONTRAST- KJC_MAX_CONTRAST/2)
#endif

#ifdef	SIZE_3224
	#define		DEF_CONTRAST				166                // ���� LCD ���
	#define		DEF_LCDCLK  				17
	#define		MAX_CONTRAST				32
	#define		CONTRAST_OFFSET				(DEF_CONTRAST- MAX_CONTRAST/2)
#endif


#ifdef	MAIN
	int		lcd_contrast;
	int		lcd_clk;
	int		contrast_offset;
	int		max_contrast;
#else
	extern	int		lcd_contrast;
	extern	int		lcd_clk;
	extern	int		contrast_offset;
	extern	int		max_contrast;
#endif




/* �����P�� */
#define	MAX_CHAR		(GAMEN_X_SIZE/8)
#define	MAX_LINE		(GAMEN_Y_SIZE/16)

/* ?�b?�̈� */
#define	MAX_COLUM_NO	(GAMEN_X_SIZE/MESH_X)
#define	MAX_LINE_NO		(GAMEN_Y_SIZE/MESH_Y)
#define	MAX_TOUCH_NO	(MAX_COLUM_NO*MAX_LINE_NO)

#ifdef	GP_S057
	#define	TOUCH_X_SIZE	20
#endif
#ifdef	LP_S044
	#define	TOUCH_X_SIZE	16
#endif
#ifdef	GP_S044
	#define	TOUCH_X_SIZE	16
#endif
#define	TOUCH_Y_SIZE	20

#define		KEY_YTOP_LEFT		1
#define		KEY_YTOP_RIGHT		(GAMEN_X_SIZE/TOUCH_X_SIZE)
#define		KEY_YBTM_LEFT		(KEY_YTOP_RIGHT*((GAMEN_Y_SIZE/TOUCH_Y_SIZE)-1))+1
#define		KEY_YBTM_RIGHT		(KEY_YTOP_RIGHT*(GAMEN_Y_SIZE/TOUCH_Y_SIZE))


#define	PLC_BUF_MAX	1280
#define	MAX_BOADRATE_CNT	6	/* �v����??�� */
/************************************/
/* Battery Level					*/
/************************************/

#define	BATT_MAX_REVEL	840		//AD Value(High)
#define	BATT_MIN_REVEL	740		//AD Value(Low)

/************************************/
/* Maxt Ivent Table					*/
/************************************/
#define	MAX_IVENT_CNT	512
//2008.05.22
#define	READ_DEV_CNT	3			/* Read Area Count */
#define	WRT_DEV_CNT		13

#define	OK	0
#define	NG	-1
#define	ON	1
#define	OFF	0
#ifndef	TRUE
#define	TRUE	1
#define	FALSE	0
#endif
#define	ENQ			0x05
#define	STX			0x02
#define	ETX			0x03
#define	EOT			0x04
#define	ACK			0x06
#define	LF			0x0A
#define	CR			0x0D
#define DLE			0x10
#define	NAK			0x15
#define	ETB			0x17
#define	DC1			0x11
#define	DC2			0x12




#define	BAUDRATE300		181		/* n=2 */
#define	BAUDRATE600		92
#define	BAUDRATE1200	181		/* n=1 */
#define	BAUDRATE2400	92
#define	BAUDRATE4800	181		/* n=0 */
#define	BAUDRATE9600	92
#define	BAUDRATE19200	 45
#define	BAUDRATE38400	 22
#define	BAUDRATE57600	 14
#define	BAUDRATE115200	  7
/****************************************/
#define	MAX_BASE_NO	512
#define	MAX_WIN_NO	512

/*****************************************/
/*	PC Command			                 */
/*****************************************/
#define	PC_DOWNLD	0x0101
#define	PC_COMMON	0x0102
#define	PC_PROJC	0x0103
#define	PC_BASE		0x0104
#define	PC_WINDW	0x0105
#define	PC_UPLOAD	0x0106
#define	PC_PROJHED	0x0107
#define	PC_COMENT	0x0108
#define	PC_PARTS	0x0109
#define	PC_DOWNLDED	0x010A
#define	PC_PROJEXT	0x010B
#define	PC_PROJDEL	0x010C
#define	PC_ALMHIST	0x010D
#define	PC_ALMFREQ	0x010E
#define	PC_PROJID	0x0201
#define	PC_PASSWD	0x0202
#define	PC_TABLEDW	0x0203
#define	PC_FONT		0x0204
#define	PC_PRG1		0x0205
#define	PC_PRG2		0x0206
#define	PC_PRG3		0x0207
#define	PC_PLC_CTL	0x0208		//LP_S044

#define	PC_MODE_DWNLD	0
#define	PC_MODE_DWNOK	1
#define	PC_MODE_UPLD	2
#define	PC_MODE_UPOK	3
#define	PC_MODE_ERR		9

#define	PC_RCV_START	1
#define	PC_RCV_LENG1	2
#define	PC_RCV_LENG2	3
#define	PC_RCV_DATA		4
#define	PC_RCV_IDLE		5
#define	PC_RCV_OK		0
#define	PC_RCV_THRUE	9
#define	PC_RCV_ERROR	-9

#define	PC_SEND_PROJECT	1
#define	PC_SEND_COMMON	0
#define	PC_SEND_BASE	2
#define	PC_SEND_WINDOW	3
#define	PC_SEND_COMMENT	4
#define	PC_SEND_PARTS	5
#define	PC_SEND_HIST	6
#define	PC_SEND_FREQ	7

#define	PC_SEND_END		8
#define	PC_SEND_PRJHED	9
#define	PC_SEND_PRJEXT	10
#define	PC_SEND_ELSE	11

/* 20020813 choijh add */
#define	NUMERICAL_DISPLAY	21
#define	ASCII_DISPLAY		1
#define	CLOCK				2
#define	COMMENT				3
#define	ALARM_HISTORY		4
#define	ALARM_LIST			5
#define	PART_DISPLAY		6
#define	LAMP				7
#define	PANELMETER			8
#define	TREND_GRAPH			9
#define	LINE_GRAPH			10
#define	BAR_GRAPH			11
#define	STATISTICS			12
#define	TOUCH_SWITCH		13
#define	NUMERICAL_INPUT		14
#define	ASCII_INPUT			15
#define	LINE				16
#define	RECTANGLE			17
#define	CIRCLE				18
#define	TEXT_DISP			19
#define BITMAP_DATA			20


/* 20020821 choijh add */
#define SWITCHING_SCREEN_DEVICE	0x11
#define PASSWORD				0x12
#define BARCODE					0x13
#define SYSTEM_INFOMATION		0x14
#define TIME_ACTION				0x15
#define ALARM_HISTORY_COMMON	0x16
#define FLOATING_ALARM			0x17
#define RECIPE					0x18
#define UTILITY					0x19
/* leesi030827  */
#define CLR						0xFFA1
#define	ENT						0xFFA2
#define BS						0xFFA3
#define C_AP					0xFFA4
#define C_DAP					0xFFA5
#define DETAIL					0xFFA6	
#define PW						0xFFA7
#define S_A_E					0xFFA8
#define A_A_E					0xFFA9
#define RESET					0xFFAA
#define UP_DISP					0xFFAB
#define DOWN_DISP				0xFFAC
#define PW_RESET				0xFFAD
#define LEFT_DISP				0x84
#define RIGHT_DISP				0x85

/* ------------- */
/* leesi 030829 CommonArea.KeyWindow.iKeyType "KeyWindow Type Setting" */
#define KEY_BINARY					1
#define KEY_OCTAL					2
#define KEY_DECIMAL					3
#define KEY_HEX						4
#define KEY_REAL					5
#define KEY_ASCII					6

#define	OVER_CODE					300
/**/

#define SCREEN_0				1
#define SCREEN_1				2
#define	MESSAGE_SCREEN			3


#define ALARM_WIDTH				192
#define ALARM_HEIGHT			74
#define	START_YEAR				2000
/*****************************************/
/*	Common Buffer Area                   */
/*****************************************/
#define	DEVICE_BIT		0
#define	DEVICE_WORD		1

typedef	struct{
	short	DevFlag;		/* 0:Bit,1:Word */
	short	Continus;
	unsigned char	DevName[3];
	int		DevAddress;
	short	DevCnt;
	short	Order;
	char	*DevData;
	short	SameDevInf;
	short	Patarn;
}DEV_DATA;
typedef struct{
	char	*Device;
	int		StartAddr;
	int		flag;		/* 0:EXT,1:INT */
}DEV_TBL;
typedef struct{
	char	*Device;
	int		DevCode;
	int		StartAddr;
	int		flag;		/* 0:EXT,1:INT */
}DEV_CODE_TBL;
typedef struct{
	char	Kubun;							/* NO USE */
	char	Index;							/* Device Code */
	char	DevName[5];						/* Device Name */
	unsigned char DevInfo;					/* 1 1 1 1 1 1 1 1 */
	                                        /*         ------- */
	                                        /*           0:  8/ 8 */
	                                        /*           1:  8/10 */
	                                        /*           2:  8/18 */
	                                        /*           3: 10/ 8 */
	                                        /*           4: 10/10 */
	                                        /*           5: 10/16 */
	                                        /*           6: 16/ 8 */
	                                        /*           7: 16/10 */
	                                        /*           8: 16/16 */
	                                        /*           9: 10    */
	                                        /* 0 0 1 0 -------    */
											/*     32Bit Word Use */
	                                        /* 0 1 0 0 -------    */
											/*   Word+Bit         */
	unsigned int		DeviceMin;
	unsigned int		DeviceMax;
	int		LowDeviceMin;
	int		LowDeviceMax;
	int		LowKeta;
	int		WordType;
}DEV_PC_TBL;

typedef struct{
	int		cnt;
	unsigned char	frame[50];
}DATA_FRAME;

/****************************************/
/*	Read Device Bit						*/
/****************************************/
/* Signal 1								*/
#define	R_RST_ON	0x0001
#define	R_BLK_ON	0x0002
#define	R_PLC_ON	0x0004				/* PLC Error ?�� */
#define	R_PLC_ON2	0x0008				/* SUB PLC Error ?�� */
#define	R_BAR_DI	0x0010
#define	R_BAR_ON	0x0020
#define	R_INPUT_ON	0x0080				/* Input End Bit */
/* Signal 3								*/
#define	R_BZR_ON	0x0001
#define	R_BZR_S_ON	0x0002
#define	R_BLK_P_ON	0x0010
#define	R_PRT_ON	0x0020
/****************************************/
/*	Write Device Bit					*/
/****************************************/
/* Signal 2								*/
#define	W_ALM_ON	0x0001
#define	W_NUM_IN	0x0010
#define	W_BAR_ON	0x0100
#define	W_LOW_ON	0x1000
/* Signal 4								*/
#define	W_PRT_ON	0x0001
#define	W_RS1E_F	0x0100
#define	W_RS1E_P	0x0200
#define	W_RS1E_O	0x0400
#define	W_RS2E_F	0x1000
#define	W_RS2E_P	0x2000
#define	W_RS2E_O	0x4000
/****************************************/
/*	Trend Buffer Max Size				*/
/****************************************/
#define	TREND_MAX	51
/************************************/
/*	RS-232C DRV						*/
/************************************/
#define	RS_CNTL		0
#define	RS_SEND		1
#define	RS_INIT		0
#define	RS_RTSON	1
#define	RS_RTSOFF	2
#define	RS_300		0
#define	RS_600		1
#define	RS_1200		2
#define	RS_2400		3
#define	RS_4800		4
#define	RS_9600		5
#define	RS_19200	6
#define	RS_38400	7
#define	RS_57600	8
#define	RS_115200	9
#define	RS_NONE		0
#define	RS_ODD		1
#define	RS_EVEN		2
#define	RS_DATA7	0
#define	RS_DATA8	1
#define	RS_STOP01	0		/* 1 bit */
/* #define	RS_STOP15	1	*/	/* 1.5bit */  
#define	RS_STOP02	1		/* 2 bit */
#define	RS_XONOFF	0
#define	RS_DTRDSR	1
#define	RS_PLC		0
#define	RS_PC		1
/************************************/
/*	PLC HAND						*/
/************************************/
#define	PLC_CNTL		0
#define	PLC_READ		1
#define	PLC_WRITE		2
#define	PLC_CHK			3
#define	PLC_THRUE		4
#define	PLC_GROOP		5
#define	PLC_GR_MAK		6
#define	PLC_CNECT		7
#define	PLC_GET_NAME	8
#define	PLC_READ2		9
#define	PLC_WRITE2		10
#define	PLC_CNECT2		11
#define	PLC_THRUE_PLC	12
#define	PLC_MONIT_OFF	13
#define	PLC_CON			14

#define	PLC_BIT		0
#define	PLC_WORD	1

/************************************/
/*	RTC HAND						*/
/************************************/
#define	RTC_READ_I	0
#define	RTC_READ	1
#define	RTC_WRITE	2
#define	PRT_WRITE	3
#define	RTC_RUN_LED	4


#define	DEV_CR	0xf0
#define	DEV_TR	0xf1
#define	DEV_CS	0xf8
#define	DEV_TS	0xf9

/************************************/
/*	GLP COMM						*/
/************************************/
enum{IDLE,STX_WAIT,DATA_RECEIVE_COMPLETE_WAIT,BCC1_RECEIVE_WAIT,
	BCC2_RECEIVE_WAIT,ENQ_ANS_WAIT,DATA_SEND_WAIT
};
/* 20060615 Program index */
/************************************/
/*	INDEX TABLE						*/
/************************************/

#define		APL_PROGRAM_START_ADDR	0x010000
#define		PROGRAM_INDEX_ADDR		0x010020
#define		PROGRAM_INDEX_SIZE		0x000004

#define		APL_PROGRAM_ADDR		0x010200

#define		SET_DISP_ADDR			0x0A8000	//Gamen Data

#define		SYS_MESSAGE_ADDR		0x0B8000
#define		APL_LOAD_ADDR			0x0BC000
#define		APL_LOAD_SIZE			0x004000

#define		PLC1_DEV_TABLE			0x0C0000        /* 20060614 */
#define		PLC1_PROTOCOL			0x0C1200  
#define		PLC2_DEV_TABLE			0x0C8000        /* 20060614 */
#define		PLC2_PROTOCOL			0x0C9200  

#define		KEY_WINDOW				0x0D0000		/* 20060614 */
#define		KEY_WINDOW_BIN_H		0x0D0000
#define		KEY_WINDOW_OCT_H		0x0D0300
#define		KEY_WINDOW_DEC_H		0x0D0700
#define		KEY_WINDOW_HEX_H		0x0D0C00
#define		KEY_WINDOW_REAL_H		0x0D1100
#define		KEY_WINDOW_ASCII_H		0x0D1600
#define		KEY_WINDOW_BIN_V		0x0D1D00
#define		KEY_WINDOW_OCT_V		0x0D2000
#define		KEY_WINDOW_DEC_V		0x0D2400
#define		KEY_WINDOW_HEX_V		0x0D2900
#define		KEY_WINDOW_REAL_V		0x0D2F00
#define		KEY_WINDOW_ASCII_V		0x0D3400

#define		FONT_ASCII68			0x0D3C00
#define		FONT_ASCII88			0x0D3F00
#define		FONT_ASCII816			0x0D4200
#define		FONT_HEXA2432			0x0D4800
#define		FONT_HEXA2448			0x0D4F00
#define		FONT_HEXA2464			0x0D5900
#define		FONT_HEXA3232			0x0D6600
#define		FONT_HEXA3248			0x0D6F00
#define		FONT_HEXA3264			0x0D7C00
#define		FONT_HEXA4832			0x0D8D00
#define		FONT_HEXA4848			0x0D9A00
#define		FONT_HEXA4864			0x0DAE00
#define		FONT_HEXA6432			0x0DC800
#define		FONT_HEXA6448			0x0DD900
#define		FONT_HEXA6464			0x0DF300

#define		FONT_NATION 			0x0E1500
#define		NEWFONT					1

#define		GP_USER_DATA 			0x170000
#ifdef	LP_S044
	#define		GP_USER_DATA_SIZE		0x060000	/* 768*512 */
#endif
#ifdef	GP_S057
	#define		GP_USER_DATA_SIZE		0x080000	/* 768*512 */
#endif
#ifdef	GP_S044
	#define		GP_USER_DATA_SIZE		0x080000	/* 768*512 */
#endif
#define		PLC_USER_DATA 				0x1D0000
#define		PLC_USER_DATA_SIZE			0x020000	/* 256*512 */
#define		GP_FILE_DIR 				0x1F0000
#define		GP_FILE_DIR_SIZE 			0x006000	/* 768*32 */
#define		PLC_FILE_DIR 				0x1F6000
#define		PLC_FILE_DIR_SIZE 			0x002000	/* 256*32 */
#define		GP_SETTING_AREA 			0x1F8000
#define		GP_SETTING_AREA_SIZE		0x001000
#define		PLC_SETTING_AREA			0x1F9000
#define		PLC_SETTING_AREA_SIZE		0x000800

//20100806 add
#define		LCD_TYPE_SETTING_AREA		0x1F9800
#define		LCD_TYPE_SETTING_AREA_SIZE	0x000800

#define		GP_FAT_DIR 					0x1FA000
#define		GP_FAT_DIR_SIZE				0x001000	/* 768*2= 0x600 */
#define		PLC_FAT_DIR 				0x1FB000
#define		PLC_FAT_DIR_SIZE			0x001000	/* 256*2= 0x200 */

#define		PLC_PARAM_FILE				0x1FC000
#define		PLC_PARAM_SIZE				0x004000

#define		GP_USER_DATA_BLOCK		( GP_USER_DATA_SIZE / 0x10000 )
#define		PLC_USER_DATA_BLOCK		( PLC_USER_DATA_SIZE / 0x10000 )
/******************************************************************/
/* File System */
//FLASH ADDRESS+++++++++++++++++++++++++++++++++
#ifdef	WIN32
#define	FLASH_START			0x00000000
#else
#define	FLASH_START			0x00000000
#endif
#define	F_FILE_AREA			(GP_USER_DATA+FLASH_START)
#define	F_DIR_AREA			(GP_FILE_DIR+FLASH_START)
#define	F_SETTEIFILE_AREA	(GP_SETTING_AREA+FLASH_START)
#define	F_PLC_SETTEIFILE_AREA	(PLC_SETTING_AREA+FLASH_START)
//20100806 add
#define	F_LCD_TYPE_SETTING_AREA	(LCD_TYPE_SETTING_AREA+FLASH_START)
#define	F_FAT_AREA			(GP_FAT_DIR+FLASH_START)

#define	F_FILE_AREA2		(PLC_USER_DATA+FLASH_START)
#define	F_DIR_AREA2			(PLC_FILE_DIR+FLASH_START)
#define	F_FAT_AREA2			(PLC_FAT_DIR+FLASH_START)
//++++++++++++++++++++++++++++++++++++++++++++++
#define	F_FAT_SIZE			0x00002000		/* 8KB  */
#define	F_DIR_SIZE			0x00008000		/* 32KB */
#define	F_FILE_BLOCK		8
#define SECT_SIZE   512
#define SECT_CLST   1
#define RESV_SECT   0
#define NOOFFAT     1
#define GP_TOTAL_SECT  (GP_USER_DATA_SIZE/SECT_SIZE)		/* 256KB-24KB(0x3A000/512) */
#define PLC_TOTAL_SECT  (PLC_USER_DATA_SIZE/SECT_SIZE)		/* 256KB-24KB(0x3A000/512) */
#define FAT_SECT    2			/* 40000(512FAT) */
#define SECT_TRCK   1

#define DIR_BASE    0                    /*   2  */
#define CLAST_BASE  0			                          /*  2  */
#define GP_TOTAL_CLAST (GP_TOTAL_SECT-CLAST_BASE)                         /* 358  */
#define PLC_TOTAL_CLAST (PLC_TOTAL_SECT-CLAST_BASE)                         /* 358  */
#define DELETED     0xff

/*******************/
#define	APLDW_START			0x04000000
#define	APLDW_SIZE			0x00004000
#define	APL_BOADRATE		0x040efff0
#define	APL_CONTRAST		0x040efff4
#define	APL_CONTRAST_LCDCLK	0x040efff8


typedef struct{
	char	*strData;
	int		dumy;
}PLC_CONST;

typedef struct{
	int		strData;
	int		dumy;
}PLC_INT_CONST;


#define	BACK_LIGHT		0x0001

#ifdef	GP_S044
#define	LCD_DISPLAY		0x0040		//20080814
#endif
#ifdef	LP_S044
#define	LCD_DISPLAY		0x0040		//20080814
#endif
#ifdef	GP_S057
#define	LCD_DISPLAY		0x0200		//20080814
#endif

#define	RS422_DIR0		0x0100
#define	LED_RUN			0x0200
#define	LED_ERROR		0x0100

//LED MODE
#define	LED_MODE_OFF	0x0000
#define	LED_MODE_RUN	0x0001
#define	LED_MODE_ERR	0x0002
#define	LED_MODE_DBG	0x0004
#define	LED_MODE_PSE	0x0008


typedef struct{
	int		iScreenNo;
	void	(*RsCall)( int* );
}SET_PROC;

#ifndef	COLOR_DT_DEFINE
#define	COLOR_DT_DEFINE

#define	COLOR_DT	unsigned int
#endif

#endif
/******************************************************************/
