void		vBuzzerSet(int *iScreenNo);
