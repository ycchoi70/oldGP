extern unsigned short	mouse_font[64];
extern unsigned short	mouse_focus[64];
extern unsigned short	mouse_move[64];
extern unsigned short	mouse_move1[64];
extern unsigned short	mouse_clear[64];
extern unsigned short	text_move[64];
extern unsigned char 	font_data_jpn[128][16];
extern	unsigned char Font8_8[256][8];
