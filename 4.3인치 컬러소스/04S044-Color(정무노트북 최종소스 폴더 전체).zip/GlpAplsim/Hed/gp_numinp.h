int		iNumInput1(char *chKey, char *chKey1, int *iSize);
void	vNumInputDisp1(char* chKey, int isX);
int		iNumInputSelect1(char* chData, char* chData1, int* iSizeData, int isX, int iFont,int is);
int	GetUsrId(int mode,int No);
int	GetMoveDestId(int mode,int No);
