/************************************************************/
/*	PLC TYPE 2												*/
/************************************************************/
#define	ARM_CPU		1
#define	PLCTYPE_CH2	1


#define FX1S	1


/* �Ʒ� ������ SH CPU �϶� App�� Protocol ���α׷��� ������ �����ϵǾ� ��ũ�ȴ�.	*/
/* SH ��ũ ȯ�濡�� ������ �������� ����� ���� �Ʒ��� �̸����� ����ϱ� �����̴�.    */
#ifdef	SH_CPU
#ifndef	WIN32
#pragma	section PlcProc2
#endif
#endif
/****************************** START **********************/
#ifdef	WIN32
#ifdef	SH_CPU
#define	const
#endif

#ifdef	FX	
#define		TYPE_FX1N	1								/* 01 */
/* #include	"PlcTypeFx.cpp" */
#include	"Plc_Mitsubishi-FX.cpp"
#endif
#ifdef	FX1S
#define		TYPE_FX1S	1					/* 02 */
/* #include	"PlcTypeFx.cpp" */
#include	"Plc_Mitsubishi-FX.cpp"
#endif
#ifdef	MK10S1								/* 03 */
/* #include	"PLgmk10s1.cpp" */
#include	"Plc_LS-MK10S1.cpp"
#endif
#ifdef	MK200S								/* 04 */
/* #include	"PlcTypeLg.cpp" */
#include	"Plc_LS-MK200S.cpp"
#endif
#ifdef	N70 /* FPG PLC SAME */				/* 05 */
#define		PLC_SPEED	RS_19200
/* #include	"Plcsm_70n.cpp" */
#include	"Plc_Samsung-N70.cpp"
#endif
#ifdef	N70PLUS								/* 06 */
/* #include	"Plcsm2_70p.cpp" */
#include	"Plc_Samsung-N70PLUS.cpp"
#endif
#ifdef	THD_MODBUS							/* 07 */
/* #include	"PlcThdM.cpp" */
#include	"Plc_Autonics-THD_MODBUS.cpp"
#endif
#ifdef	TZ									/* 08 */
/* #include	"PlcTypeTZ.cpp" */
#include	"Plc_Autonics-TZ.cpp"
#endif
#ifdef	MT									/* 09 */
/* #include	"PlcTypeMT.cpp" */
#include	"Plc_Autonics-MT.cpp"
#endif
#ifdef	MP									/* 10 */
/* #include	"PlcTypeMP.cpp" */
#include	"Plc_Autonics-MP.cpp"
#endif
#ifdef	MASTER_MODBUS						/* 11 */
/* #include	"PlcModMS.cpp" */
#include	"Plc_Modicon-MASTER_MODBUS.cpp"
#endif
#ifdef	MK_CNET								/* 12 */
/* #include	"PlcLGcnet.cpp" */
#include	"Plc_LS-MK_CNET.cpp"
#endif

#ifdef	UNIS_MODBUS							/* 13 */	
/* #include	"Plc_UniS.cpp" */
#include	"Plc_Autonics-UNIS_MODBUS.cpp"
#endif
#ifdef	FP0									/* 14 */
#define		PLC_SPEED	RS_9600
/* #include	"Plcsm_70n.cpp" */
#include	"Plc_Samsung-N70.cpp"
#endif
#ifdef	GM4									/* 15 */
#define	MAX_UR_CNT	 25 /* Max Monitor ��� ���� */
#define MAX_MOR_CNT 100
/* #include	"PlcTypeGM.cpp" */
#include	"Plc_LS-GM.cpp"
#endif
#ifdef	GM6									/* 16 */
#define	MAX_UR_CNT	 25 /* Max Monitor ��� ���� */
#define MAX_MOR_CNT 100
/* #include	"PlcTypeGM.cpp" */
#include	"Plc_LS-GM.cpp"
#endif
#ifdef	GM7U								/* 17 */
#define	MAX_UR_CNT	 16  /* Max Monitor ��� ���� */
#define MAX_MOR_CNT  64	
/* #include	"PlcTypeGM.cpp" */
#include	"Plc_LS-GM.cpp"
#endif
#ifdef	E5XX_MODBUS							/* 18 */	
/* #include	"PlcOmronE5CN_Mod.cpp" */
#include	"Plc_Omron-E5CN_MODBUS.cpp"
#endif
#ifdef	CPM1A								/* 19 */
/* #include	"PlcTypeCPM1A.cpp" */
#include	"Plc_Omron-CPM1A.cpp"
#endif
#ifdef	DTB_MODBUS							/* 20 */
/* #include	"PlcDeltaB_Mod.cpp" */
#include	"Plc_Delta-DTB_MODBUS.cpp"
#endif
#ifdef	FPG									/* 21 */
#define		PLC_SPEED	RS_19200
/* #include	"Plcsm_70n.cpp" */
#include	"Plc_Samsung-N70.cpp"
#endif
#ifdef	XGT_CNET							/* 22 */
/* #include	"PlcXGTcnet.cpp" */
#include	"Plc_LS-XGT_CNET.cpp"
#endif
#ifdef	DPU_MODBUS							/* 23 */
/* #include	"Plc_Konics_Mod2.cpp" */
#include	"Plc_Konics-DPU_MODBUS.cpp"
#endif
#ifdef	TB42_MODBUS							/* 24 */
/* #include	"Plc_Tb42_Mod.cpp" */
#include	"Plc_Autonics-TB42_MODBUS.cpp"
#endif

#ifdef	S7_200								/* 25 */
#include	"Plc_Simens-S7_200.cpp"
#endif
#ifdef	S7_300								/* 26 */
#include	"Plc_Simens-S7_300.cpp"
#endif
#ifdef	MICROLOGIC1000						/* 27 */
#include	"Plc_Allenbradley-MICROLOGIC1000.cpp"
#endif
#ifdef	MICROLOGIC1200						/* 28 */
#include	"Plc_Allenbradley-MICROLOGIC1200.cpp"
#endif
#ifdef	FX3U								/* 29 */
#include	"Plc_Mitsubishi-FX3U.cpp"
#endif
#ifdef	MT_MODBUS							/* 30 */
#include	"Plc_Autonics-MT_MODBUS.cpp"
#endif
#ifdef	PMS_HS								/* 31 */
#include	"Plc_Autonics-PMS_HS.cpp"
#endif
#ifdef	Q00J								/* 32 */
#include	"Plc_Mitsubishi-Q00J.cpp"
#endif


#else


#ifdef	FX	
#define		TYPE_FX1N	1								/* 01 */
/* #include	"PlcTypeFx.c" */
#include	"Plc_Mitsubishi-FX.c"
#endif
#ifdef	FX1S
#define		TYPE_FX1S	1					/* 01 */
/* #include	"PlcTypeFx.c" */
#include	"Plc_Mitsubishi-FX.c"
#endif
#ifdef	MK10S1
/* #include	"PLgmk10s1.c" */
#include	"Plc_LS-MK10S1.c"
#endif
#ifdef	MK200S
/* #include	"PlcTypeLg.c" */
#include	"Plc_LS-MK200S.c"
#endif
#ifdef	N70 /* FPG PLC SAME */				/* 04 */
#define		PLC_SPEED	RS_19200
/* #include	"Plcsm_70n.c" */
#include	"Plc_Samsung-N70.c"
#endif
#ifdef	N70PLUS
/* #include	"Plcsm2_70p.c" */
#include	"Plc_Samsung-N70PLUS.c"
#endif
#ifdef	THD_MODBUS
/* #include	"PlcThdM.c" */
#include	"Plc_Autonics-THD_MODBUS.c"
#endif
#ifdef	TZ
/* #include	"PlcTypeTZ.c" */
#include	"Plc_Autonics-TZ.c"
#endif
#ifdef	MT
/* #include	"PlcTypeMT.c" */
#include	"Plc_Autonics-MT.c"
#endif
#ifdef	MP
/* #include	"PlcTypeMP.c" */
#include	"Plc_Autonics-MP.c"
#endif
#ifdef	MASTER_MODBUS
/* #include	"PlcModMS.c" */
#include	"Plc_Modicon-MASTER_MODBUS.c"
#endif
#ifdef	MK_CNET
/* #include	"PlcLGcnet.c" */
#include	"Plc_LS-MK_CNET.c"
#endif

#ifdef	UNIS_MODBUS
/* #include	"Plc_UniS.c" */
#include	"Plc_Autonics-UNIS_MODBUS.c"
#endif
#ifdef	FP0
#define		PLC_SPEED	RS_9600
/* #include	"Plcsm_70n.c" */
#include	"Plc_Samsung-N70.c"
#endif
#ifdef	GM4									
#define	MAX_UR_CNT	 25 /* Max Monitor ��� ���� */
#define MAX_MOR_CNT 100
/* #include	"PlcTypeGM.c" */
#include	"Plc_LS-GM.c"
#endif
#ifdef	GM6									
#define	MAX_UR_CNT	 25 /* Max Monitor ��� ���� */
#define MAX_MOR_CNT 100
/* #include	"PlcTypeGM.c" */
#include	"Plc_LS-GM.c"
#endif
#ifdef	GM7U								
#define	MAX_UR_CNT	 16  /* Max Monitor ��� ���� */
#define MAX_MOR_CNT  64	
/* #include	"PlcTypeGM.c" */
#include	"Plc_LS-GM.c"
#endif
#ifdef	E5XX_MODBUS
/* #include	"PlcOmronE5CN_Mod.c" */
#include	"Plc_Omron-E5CN_MODBUS.c"
#endif
#ifdef	CPM1A
/* #include	"PlcTypeCPM1A.c" */
#include	"Plc_Omron-CPM1A.c"
#endif
#ifdef	DTB_MODBUS									/* 16 */
/* #include	"PlcDeltaB_Mod.c" */
#include	"Plc_Delta-DTB_MODBUS.c"
#endif
#ifdef	FPG									/* 17 */
#define		PLC_SPEED	RS_19200
/* #include	"Plcsm_70n.c" */
#include	"Plc_Samsung-N70.c"
#endif
#ifdef	XGT_CNET								/* 19 */
/* #include	"PlcXGTcnet.c" */
#include	"Plc_LS-XGT_CNET.c"
#endif
#ifdef	DPU_MODBUS									/* 20 */
/* #include	"Plc_Konics_Mod2.c" */
#include	"Plc_Konics-DPU_MODBUS.c"
#endif
#ifdef	TB42_MODBUS									/* 21 */
/* #include	"Plc_Tb42_Mod.cpp" */
#include	"Plc_Autonics-TB42_MODBUS.cpp"
#endif

#ifdef	S7_200
#include	"Plc_Simens-S7_200.c"
#endif
#ifdef	S7_300
#include	"Plc_Simens-S7_300.c"
#endif
#ifdef	MICROLOGIC1000
#include	"Plc_Allenbradley-MICROLOGIC1000.c"
#endif
#ifdef	MICROLOGIC1200
#include	"Plc_Allenbradley-MICROLOGIC1200.c"
#endif
#ifdef	FX3U
#include	"Plc_Mitsubishi-FX3U.c"
#endif
#ifdef	MT_MODBUS
#include	"Plc_Autonics-MT_MODBUS.c"
#endif
#ifdef	PMS_HS
#include	"Plc_Autonics-PMS_HS.c"
#endif
#ifdef	Q00J
#include	"Plc_Mitsubishi-Q00J.c"
#endif
#endif
/****************************** END **********************/


/* SH_CPU�� ARM_CPU�� �ҽ��� �����ϰ� ��� 	#define���� ���� */
/* PLCTYPE_CH1�� PLCTYPE_CH2�� �ҽ��� �����ϰ� ��� 	#define���� ���� */
/* #ifdef PLCTYPE_ELSE2 �� PLCTYPE_CH2�� ���� */
/* #ifndef PLCTYPE_ELSE2 �� PLCTYPE_CH1�� ���� */
/* #ifdef PLCTYPE_ELSE2�� #else �κ��� PLCTYPE_CH1�� ���� */
