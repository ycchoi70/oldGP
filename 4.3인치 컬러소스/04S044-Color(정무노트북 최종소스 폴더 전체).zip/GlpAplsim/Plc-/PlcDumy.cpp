
#include	"define.h"
#define		MAIN
#include	"GpCommon.h"


#ifdef	WIN32
/*********************************/
int		SioPLCMode;
int		SioPCMode;
int		SioPLCOpenFlag;
int		SioPCOpenFlag;
#endif

#ifdef	WIN32
int	Hex2nBin(char *buff,int cnt)
{
	return(0);
}
int	Hex2Bin(char *buff)
{
	return(0);
}
unsigned int LHexAsToBin(char *buff, int cnt)
{
	return(0);
}
void	SendPLCPCData( void )
{
}
int	SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode)
{
	return(0);
}
int	SendPLC2PCData( int mode )
{
	return(0);
}
int	SendPC2PLCData( int mode )
{
	return(0);
}
int	Delay(int p)
{
	return(0);
}
unsigned int	ReadSignal(int p)
{
	return(0);
}
int	main()
{
	return(0);
}
void	RsModeSet(int type,int mode,int bordrate,int ldata,int parity)
{
}
void	PlcDevInit( void )
{
}
void	SendPLCGroup(void)
{
}
int	GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address)
{
	return(0);
}
void	RtsOnOffSet(int type,int mode)
{
}
void	Rs422Enable(int mode)
{
}
int	SendThruePLC(int cnt,char *sBuff)
{
	return(0);
}
unsigned int	GetNowTime()		/* 20060203 */
{
	return(0);
}
unsigned char			GpFont[0x60000];
#endif
