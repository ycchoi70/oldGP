/************************************************/
//�����v���g�R��
//061023:�ėp�v���g�R���ő��M�C���i�Q��ȏ�łԂ��邽�߁j
/************************************************/
#include	"sgt.h"
#include	"PlcHed.h"
/************************************************************************/
/* UNIVERSAL															*/
/************************************************************************/
/************************************************/
/*	�ėp�ʐM�f??�̈�							*/
/************************************************/
#ifdef	LP_S044

#define	UNVERS_WRITE_START	15
#define	UNVERS_WRITE_END	59999
#define	UNVERS_READ_START	0
#define	UNVERS_READ_END		59999

#define	UNVERS_1_START	0
#define	UNVERS_1_END	14
#define	UNVERS_2_START	15
#define	UNVERS_2_END	29
#define	UNVERS_3_START	30
#define	UNVERS_3_END	1999
#define	UNVERS_R_START	2000
#define	UNVERS_R_END	5999
#define	UNVERS_4_START	6000
#define	UNVERS_4_END	6047
#define	UNVERS_5_START	6048
#define	UNVERS_5_END	6099
#define	UNVERS_V_START	6100
#define	UNVERS_V_END	6355
#define	UNVERS_F_START	6400
#define	UNVERS_F_END	6655
#define	UNVERS_Z_START	6700
#define	UNVERS_Z_END	6955
#define	UNVERS_X_START	7000
#define	UNVERS_X_END	7255
#define	UNVERS_Y_START	8000
#define	UNVERS_Y_END	8255
#define	UNVERS_6_START	9000
#define	UNVERS_6_END	9999
#define	UNVERS_T_START	10000
#define	UNVERS_T_END	10031
#define	UNVERS_TC_START	11000
#define	UNVERS_TC_END	11255
#define	UNVERS_TS_START	13000
#define	UNVERS_TS_END	13255
#define	UNVERS_C_START	15000
#define	UNVERS_C_END	15031
#define	UNVERS_CC_START	16000
#define	UNVERS_CC_END	16255
#define	UNVERS_CS_START	18000
#define	UNVERS_CS_END	18255
#define	UNVERS_M_START	20000
#define	UNVERS_M_END	29999
#define	UNVERS_S_START	36000
#define	UNVERS_S_END	36255
#define	UNVERS_L_START	38000
#define	UNVERS_L_END	38999
#define	UNVERS_D_START	40000
#define	UNVERS_D_END	49999
#define	UNVERS_7_START	60000
#define	UNVERS_7_END	65279
#endif
#ifdef	GP_S044
#define	UNVERS_WRITE_START	15
#define	UNVERS_WRITE_END	6047
#define	UNVERS_READ_START	0
#define	UNVERS_READ_END		6047
#endif
#ifdef	GP_S057
#define	UNVERS_WRITE_START	15
#define	UNVERS_WRITE_END	6047
#define	UNVERS_READ_START	0
#define	UNVERS_READ_END		6047
#endif
#define UNVERS_UB_W_START   0x150 // ub150
#define UNVERS_UB_END	0x6047F   // ub6047F
#define UNVERS_UW_END	0x6047    // uw6047

#define	UNVERS_ERR_FNC	0x01
#define	UNVERS_ERR_ADR	0x02
#define	UNVERS_ERR_DAT	0x03

#define	MDBUS_READ_COIL_STATUS				0x01
#define	MDBUS_READ_INPUT_STATUS				0x02
#define	MDBUS_READ_HOLDING_REG				0x03
#define	MDBUS_READ_INPUT_REG				0x04
#define	MDBUS_FORCE_SINGLE_COIL				0x05
#define	MDBUS_PRESET_SINGLE_REG				0x06
#define	MDBUS_DIAGNOSTICS					0x08
#define	MDBUS_FETCH_COMM_EVENT_CNT			0x0B
#define	MDBUS_FETCH_COMM_EVENT_LOG			0x0C
#define	MDBUS_FORCE_MULTIPLE_COILS			0x0F
#define	MDBUS_PRESET_MULTIPLE_REG			0x10

#ifdef	WIN32
unsigned char U_IndexTable[256]={
#else
const	unsigned char U_IndexTable[256]={
#endif
	/* BIT */
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,
	/* WORD */
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
};
#ifdef	WIN32
int U_LowHighFlag= 0;				/* 0:L-H,1:H-L */
int	U_K3P_SereaseByteCnt= 14;
DEV_PC_TBL	U_K3P_SereaseByte[32]=
#else
const	int U_LowHighFlag= 0;				/* 0:L-H,1:H-L */
const	int	U_K3P_SereaseByteCnt= 14;
const	DEV_PC_TBL	U_K3P_SereaseByte[32]=
#endif
	{
		{1,0x01,{'?',  0, 0},0x88,0x00000000,0x00000000,0x0000,0x0000,0x0001},
//		{1,0x7f,{'U','B', 0},0x85,0x00000000,0x0032767f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00000000,0x0007255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00080000,0x0008255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00100000,0x0010031f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00110000,0x0011255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00130000,0x0013255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00150000,0x0015031f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00160000,0x0016255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00180000,0x0018255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00200000,0x0029999f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00360000,0x0036255f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00380000,0x0038999f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00400000,0x0049999f,0x0000,0x000f,0x0001},
		{2,0x7f,{'U','B', 0},0x85,0x00600000,0x0061511f,0x0000,0x000f,0x0001},
	};
#ifdef	WIN32
int	U_K3P_SereaseWordCnt= 14;
DEV_PC_TBL	U_K3P_SereaseWord[32]=
#else
const	int	U_K3P_SereaseWordCnt= 14;
const	DEV_PC_TBL	U_K3P_SereaseWord[32]=
#endif
	{
		{2,(unsigned char)0x01,{'?',  0, 0},0x88,0x00000000,0x00000000,0x0000,0x0000,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00000000,0x00007255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00008000,0x00008255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00010000,0x00010031,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00011000,0x00011255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00013000,0x00013255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00015000,0x00015031,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00016000,0x00016255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00018000,0x00018255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00020000,0x00029999,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00036000,0x00036255,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00038000,0x00038999,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00040000,0x00049999,0x0000,0x0009,0x0001},
		{2,(unsigned char)0xef,{'U','W', 0},0x84,0x00060000,0x00061511,0x0000,0x0009,0x0001},
	};

void	UN_SetPLCDevAddr(int *PLCByteCnt,int *PLCWordCnt,DEV_PC_TBL **ByteTbl,DEV_PC_TBL **WordTbl,unsigned char **PLCIndex)
{
	*PLCByteCnt= (int)U_K3P_SereaseByteCnt;
	*PLCWordCnt= (int)U_K3P_SereaseWordCnt;		/*  */
	*ByteTbl= (DEV_PC_TBL *)&U_K3P_SereaseByte[0];
	*WordTbl= (DEV_PC_TBL *)&U_K3P_SereaseWord[0];
	*PLCIndex= (unsigned char *)&U_IndexTable[0];
}

int	UN_GetDevNamePLC(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	UN_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			memcpy(obj,ByteTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= ByteTbl[PLCIndex[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			memcpy(obj,WordTbl[PLCIndex[src[0]]].DevName,3);
			*DevInfo= WordTbl[PLCIndex[src[0]]].DevInfo;
			/* 16/32/48/64�ǉ� */
			*DevInfo= *DevInfo | (WordTbl[PLCIndex[src[0]]].WordType << 16);
			ret= 0;
		}
	}
	return(ret);
}
int		UN_CheckDevice_Addr(int bwflag,char *DevName,unsigned int *Address1,unsigned int *Address2)
{
	int		i;
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;
	unsigned int		Max,Min;

	UN_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);
	ret= -1;
	Max= 0;
	Min= 99999999;		//070827 999999->99999999
	if(bwflag == 0){	/* Bit */
		for(i= 0; i< PLCByteCnt; i++){
			if(strcmp(ByteTbl->DevName,DevName) == 0){
				if((*Address1 >= ByteTbl->DeviceMin) && (*Address1 <= ByteTbl->DeviceMax)&& (*Address2 <= ByteTbl->DeviceMax)){
					ret= 0;
				}else{
					if((ByteTbl->DeviceMin > *Address1) && (ByteTbl->DeviceMin < Min)){
						Min= ByteTbl->DeviceMin;
					}
					if((ByteTbl->DeviceMax < *Address1) && (ByteTbl->DeviceMax > Max)){
						Max= ByteTbl->DeviceMax;
					}
				}
			}
			ByteTbl++;
		}
	}else{
		
		for(i= 0; i< PLCWordCnt; i++){
			if(strcmp(WordTbl->DevName,DevName) == 0){
				if((*Address1 >= WordTbl->DeviceMin) && (*Address1 <= WordTbl->DeviceMax)){
					ret= 0;
				}else{
					if((WordTbl->DeviceMin > *Address1) && (WordTbl->DeviceMin < Min)){
						Min= WordTbl->DeviceMin;
					}
					if((WordTbl->DeviceMax < *Address1) && (WordTbl->DeviceMax > Max)){
						Max= WordTbl->DeviceMax;
					}
				}
			}
			WordTbl++;
		}
	}
	*Address1= Max;
	*Address2= Min;
	return(ret);
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		UN_Device2IndexPLC(int bwflag,char *Name)
{
	int		ret;
	int		i;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	UN_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < PLCByteCnt; i++){
			if(strcmp(Name,(char *)ByteTbl[i].DevName) == 0){
				ret= ByteTbl[i].Index;
			}
		}
	}else{
		for(i= 0; i < PLCWordCnt; i++){
			if(strcmp(Name,(char *)WordTbl[i].DevName) == 0){
				ret= WordTbl[i].Index;
			}
		}
	}
	return(ret);
}
/****************************************************/
/*	�ėp�ʐM����									*/
/****************************************************/
/***********************************************/
void	Uni_Get_Plc1_Ver(char *name)
{
	strcpy(name,"V1.4S");
}

/* Table of CRC values for high.order byte */
unsigned char Unv_auchCRCHi[] = {
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
} ;
/* Table of CRC values for low.order byte */
unsigned char Unv_auchCRCLo[] = {
    0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 
    0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 
    0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 
    0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, 0x11, 0xD1, 0xD0, 0x10, 
    0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 
    0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 
    0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 
    0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, 0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 
    0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 
    0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 
    0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 
    0xB4, 0x74, 0x75, 0xB5, 0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 
    0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 
    0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 
    0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
    0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80, 0x40
} ;
unsigned short Unv_crc16(unsigned char *puchMsg, int usDataLen)
{
    unsigned char uchCRCHi = 0xFF ; /* high byte of CRC initialized */
    unsigned char uchCRCLo = 0xFF ; /* low byte of CRC initialized */
    int uIndex ; /* will index into CRC lookup table */
	if(usDataLen <= 0){	return(0); }		/* 20090527 */
    while (usDataLen--) /* pass through message buffer */
    {
        uIndex = uchCRCHi ^ *puchMsg++ ; /* calculate the CRC */
        uchCRCHi = uchCRCLo ^ Unv_auchCRCHi[uIndex] ;
        uchCRCLo = Unv_auchCRCLo[uIndex] ;
    }
    return (uchCRCHi << 8 | uchCRCLo) ;
}
/****************************************************************/
/*	FUNC    :�ėp�ʐM�i���R?�h�����j							*/
/*	����	:char *RecBuff:��M�o�b�t?							*/
/*			:int RecCnt:��M�����O�X							*/
/*			:char *SndBuff:���M�o�b�t?							*/
/*			:int *SndCnt:���M�����O�X							*/
/*			   STX,DATA,ETX,SUM									*/
/*			   STX,DATA,CR										*/
/****************************************************************/
void	UniversalError(unsigned char *RecBuff,char *SndBuff,int *SndCnt,int Code)
{
	int		idx;
	unsigned short	_crc16;

	idx= 0;
	SndBuff[idx++]= RecBuff[0];	/* �ǔ� */
	SndBuff[idx++]= RecBuff[1] | 0x80;;	/* Command */
	SndBuff[idx++]= Code;  		/* Code */
	_crc16= Unv_crc16((unsigned char *)SndBuff,idx);
	SndBuff[idx++]= (char)(_crc16 >> 8);
	SndBuff[idx++]= (char)_crc16;
	*SndCnt= idx;
}
void	UniversalRead(unsigned char *RecBuff,char *SndBuff,int *SndCnt,int mode)
{
	int		Cnt;
	int		i,idx;
	unsigned int	Useraddress,taddr;
	int		Realaddress;
	int		Endaddress;
	int		AddrCheck;
	int		EndAddrCheck;
	unsigned short	_crc16;

	int uwAddr;
	int ubAddr;
	int CmpBit;
	char sendBuff;
	int tBit;

	unsigned int Address1, Address2;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;
	
	UN_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	idx= 0;
	SndBuff[idx++]= RecBuff[0];	/* �ǔ� */
	SndBuff[idx++]= RecBuff[1];	/* Command */

	Useraddress= (RecBuff[2] << 8) + RecBuff[3];
	Cnt= (RecBuff[4] << 8) + RecBuff[5];
	
	switch(RecBuff[1]){
	case	MDBUS_READ_COIL_STATUS:
	case	MDBUS_READ_INPUT_STATUS:
		/* Bit */
		SndBuff[idx++]= (Cnt-1)/8 + 1;	/* Count */
		Endaddress= Useraddress+ Cnt - 1;

		// User �ּҸ�  ���� �ּҷ� ���� �ϴ� ��ƾ �ʿ� 
		
		//Address������A�h���X�ɂ���B
		Realaddress = Endaddress;
		EndAddrCheck = ChangeUWAddr(PLC_BIT,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */		

		Realaddress = Useraddress;
		AddrCheck = ChangeUWAddr(PLC_BIT,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */

		Address1 = Useraddress;
		Address2 = Endaddress;
		Address1 = SetPLCUsrAddr(ByteTbl[PLCIndex[0x7F]].DevInfo, Address1, 0x7F, 0);
		Address2 = SetPLCUsrAddr(ByteTbl[PLCIndex[0x7F]].DevInfo, Address2, 0x7F, 0);

//		if(UN_CheckDevice_Addr(0,"UB",&Address1, &Address2)==0){
		if((Address1 >= UNVERS_READ_START) && (Address1 <= UNVERS_UB_END) && ( Address2 <= UNVERS_UB_END)){
			if((AddrCheck == 0) && (EndAddrCheck == 0)){
				uwAddr = Realaddress>>4;
				ubAddr = Realaddress &0x0f;
				sendBuff=0x00;
				//���� �� ��Ʈ 
				CmpBit = 0x01 << ubAddr;
				for(i=1; i<=Cnt; i++)
				{
					tBit=0x00;
					if((InDevArea.UW[uwAddr+(ubAddr/16)] & CmpBit)!=0)
					{
						tBit=0x01;
					}
					ubAddr++;
					CmpBit<<=1;

					sendBuff = sendBuff | (tBit<<(i-1)%8);
					if( i % 8==0 || i == Cnt)
					{
						SndBuff[idx++]=sendBuff;
						sendBuff=0x00;
					}
					
					if(CmpBit==0x10000){CmpBit=0x01;}
				}
				_crc16= Unv_crc16((unsigned char *)SndBuff,idx);
				SndBuff[idx++]= (char)(_crc16 >> 8);
				SndBuff[idx++]= (char)_crc16;
				*SndCnt= idx;
				break;

/*				for(i= 0; i < Cnt; i++){
					SndBuff[idx++]= (char)(InDevArea.UW[Realaddress] >> 8);
					SndBuff[idx++]= (char)InDevArea.UW[Realaddress++];
				}
				_crc16= Unv_crc16((unsigned char *)SndBuff,idx);
				SndBuff[idx++]= (char)(_crc16 >> 8);
				SndBuff[idx++]= (char)_crc16;
				*SndCnt= idx;
*/
			}else{
				UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
			}
		}else{
			UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}
		break;
	case	MDBUS_READ_HOLDING_REG:
	case	MDBUS_READ_INPUT_REG:
		SndBuff[idx++]= Cnt*2;	/* Count */
		Endaddress= Useraddress+ Cnt - 1;

		//Address������A�h���X�ɂ���B
		Realaddress = Endaddress;
		EndAddrCheck = ChangeUWAddr(PLC_WORD,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */		

		Realaddress = Useraddress;
		AddrCheck = ChangeUWAddr(PLC_WORD,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */
	
		Address1 = Useraddress;
		Address2 = Endaddress;
		Address1 = SetPLCUsrAddr(WordTbl[PLCIndex[0xEF]].DevInfo, Address1, 0xEF, 1);
		Address2 = SetPLCUsrAddr(WordTbl[PLCIndex[0xEF]].DevInfo, Address2, 0xEF, 1);
//		if(UN_CheckDevice_Addr(1,"UW",&Address1, &Address2)==0){
		if((Address1 >= UNVERS_READ_START) && (Address1 <= UNVERS_UW_END) && (Address2 <= UNVERS_UW_END)){
			if((AddrCheck == 0) && (EndAddrCheck == 0)){
				for(i= 0; i < Cnt; i++){
					SndBuff[idx++]= (char)(InDevArea.UW[Realaddress] >> 8);
					SndBuff[idx++]= (char)InDevArea.UW[Realaddress++];
				}
				_crc16= Unv_crc16((unsigned char *)SndBuff,idx);
				SndBuff[idx++]= (char)(_crc16 >> 8);
				SndBuff[idx++]= (char)_crc16;
				*SndCnt= idx;
			}else{
				UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
			}
		}else{
			UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}
		break;
	case	MDBUS_FETCH_COMM_EVENT_CNT:		
		break;
	case	MDBUS_FETCH_COMM_EVENT_LOG:		
		break;		
	}
}

void	UniversalWrite(unsigned char *RecBuff,int RecCnt,char *SndBuff,int *SndCnt,int mode)
{
	int		Cnt;
	int		i,idx;
	unsigned int	Useraddress, Endaddress;
	int		Realaddress;
	int		AddrCheck;
	int		EndAddrCheck;
	unsigned short	_crc16;
	unsigned int taddr;

	int CmpBit;
	int uwAddr;
	int ubAddr;
	int ret;

	unsigned int Address1, Address2;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;
	
	UN_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	switch(RecBuff[1]){
	case	MDBUS_FORCE_SINGLE_COIL:
				idx= 0;
		SndBuff[idx++]= RecBuff[0];	/* ���� */
		SndBuff[idx++]= RecBuff[1];	/* Command */

		Useraddress= (RecBuff[2] << 8) + RecBuff[3];
		SndBuff[idx++]= RecBuff[2]; /* ���� �ּ� Hi */
		SndBuff[idx++]= RecBuff[3]; /* ���� �ּ� Lo */

		//Address������A�h���X�ɂ���B
		Realaddress = Useraddress;
		AddrCheck = ChangeUWAddr(PLC_BIT,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */

		Address1 = Useraddress;
		Address2 = Useraddress;
		Address1 = SetPLCUsrAddr(ByteTbl[PLCIndex[0x7F]].DevInfo, Address1, 0x7F, 0);
		Address2 = SetPLCUsrAddr(ByteTbl[PLCIndex[0x7F]].DevInfo, Address2, 0x7F, 0);

//		if(UN_CheckDevice_Addr(0,"UB",&Address1, &Address2)==0){
		if((Address1 >= UNVERS_UB_W_START) && (Address1 <= UNVERS_UB_END) && ( Address2 <= UNVERS_UB_END)){
			if(AddrCheck == 0){
#ifdef LP_S044
				if(CheckPlcDevAccess((Realaddress>>4),(Realaddress>>4)) == OK){
#endif
					uwAddr = Realaddress >>4;
					ubAddr = Realaddress & 0x0f;

					CmpBit = 0x01 << ubAddr;
					
					if(RecBuff[4]==0xff){
						InDevArea.UW[uwAddr]=InDevArea.UW[uwAddr] | CmpBit;
					}else{
						InDevArea.UW[uwAddr]=InDevArea.UW[uwAddr] &(~CmpBit);
					}
					
					SndBuff[idx++]= RecBuff[4];	/* Register Cnt */
					SndBuff[idx++]= RecBuff[5];	/*  */
					_crc16= Unv_crc16((unsigned char *)SndBuff,idx);
					SndBuff[idx++]= (char)(_crc16 >> 8);
					SndBuff[idx++]= (char)_crc16;
					*SndCnt= idx;
					break;
#ifdef LP_S044
				}else{
					UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
				}
#endif

			}else{
				UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
			}
		}else{
			UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}
		break;	
	case	MDBUS_PRESET_SINGLE_REG:
		Useraddress= (RecBuff[2] << 8) + RecBuff[3];
		idx= 4;

		//Address������A�h���X�ɂ���B
		Realaddress = Useraddress;
		AddrCheck = ChangeUWAddr(PLC_WORD,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */
		
		Address1 = Useraddress;
		Address2 = Useraddress;
		Address1 = SetPLCUsrAddr(WordTbl[PLCIndex[0xEF]].DevInfo, Address1, 0xEF, 1);
		Address2 = SetPLCUsrAddr(WordTbl[PLCIndex[0xEF]].DevInfo, Address2, 0xEF, 1);
		
//		if(UN_CheckDevice_Addr(0,"UW",&Address1, &Address2)==0){
		if((Address1 >= UNVERS_WRITE_START) && (Address1 <= UNVERS_UW_END) && (Address2 <= UNVERS_UW_END)){
			if(AddrCheck == 0){
	#ifdef	LP_S044
				if(CheckPlcDevAccess((Realaddress>>4),(Realaddress>>4)) == OK){
	#endif
					InDevArea.UW[Realaddress]= RecBuff[idx++] << 8;
					InDevArea.UW[Realaddress++] += RecBuff[idx++];

					idx= 0;
					SndBuff[idx++]= RecBuff[0];	/* �ǔ� */
					SndBuff[idx++]= RecBuff[1];	/* Command */
					SndBuff[idx++]= RecBuff[2];	/* Start Addr */
					SndBuff[idx++]= RecBuff[3];	/*  */
					SndBuff[idx++]= RecBuff[4];	/* Register Cnt */
					SndBuff[idx++]= RecBuff[5];	/*  */
					_crc16= Unv_crc16((unsigned char *)SndBuff,idx);
					SndBuff[idx++]= (char)(_crc16 >> 8);
					SndBuff[idx++]= (char)_crc16;
					*SndCnt= idx;
	#ifdef	LP_S044
				}else{
					UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
				}
	#endif
			}else{
				UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
			}
		}else{
			UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}
		break;
	case	MDBUS_DIAGNOSTICS:		
		break;		
	case	MDBUS_FORCE_MULTIPLE_COILS:
		idx= 0;
		SndBuff[idx++]= RecBuff[0];	/* ���� */
		SndBuff[idx++]= RecBuff[1];	/* Command */

		Useraddress= (RecBuff[2] << 8) + RecBuff[3];
		SndBuff[idx++]= RecBuff[2]; /* ���� �ּ� Hi */
		SndBuff[idx++]= RecBuff[3]; /* ���� �ּ� Lo */

		Cnt = (RecBuff[4]<<8)+RecBuff[5];
		SndBuff[idx++]= RecBuff[4]; // bit Count Hi
		SndBuff[idx++]= RecBuff[5]; // bit Count Low

		//Address������A�h���X�ɂ���B
		Endaddress= Useraddress+ Cnt-1;

		Realaddress = Endaddress;
		EndAddrCheck = ChangeUWAddr(PLC_BIT,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */		

		Realaddress = Useraddress;
		AddrCheck = ChangeUWAddr(PLC_BIT,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */

		Address1 = Useraddress;
		Address2 = Endaddress;
		Address1 = SetPLCUsrAddr(ByteTbl[PLCIndex[0x7F]].DevInfo, Address1, 0x7F, 0);
		Address2 = SetPLCUsrAddr(ByteTbl[PLCIndex[0x7F]].DevInfo, Address2, 0x7F, 0);

//		if(UN_CheckDevice_Addr(0,"UB",&Address1, &Address2)==0){
		if((Address1 >= UNVERS_UB_W_START) && (Address1 <= UNVERS_UB_END) && (Address2 <= UNVERS_UB_END)){
			if(AddrCheck == 0 && EndAddrCheck == 0){
#ifdef LP_S044
				if(CheckPlcDevAccess((Realaddress>>4),((Realaddress+Cnt-1)>>4)) == OK){
#endif
				uwAddr = Realaddress >>4;  
					ubAddr = Realaddress & 0x0f;

					CmpBit = 0x01 << ubAddr;
					
					for(i=0; i<Cnt; i++)
					{
						if((RecBuff[7+i/8]&(0x01<<(i%8)))==0x00){
							InDevArea.UW[uwAddr]&=~CmpBit;
						}else{
							InDevArea.UW[uwAddr]|=CmpBit;
						}
						CmpBit<<=0x01;
						if(CmpBit== 0x10000){
							CmpBit=0x01;
							uwAddr++;
						}
					}	
					_crc16= Unv_crc16((unsigned char *)SndBuff,idx);
					SndBuff[idx++]= (char)(_crc16 >> 8);
					SndBuff[idx++]= (char)_crc16;
					*SndCnt= idx;
					break;
#ifdef LP_S044
				}else{
					UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
				}
#endif

			}else{
				UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
			}
		}else{
			UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}

		break;		
	case	MDBUS_PRESET_MULTIPLE_REG:
		Useraddress= (RecBuff[2] << 8) + RecBuff[3];
		Cnt= ((RecBuff[4] << 8) + RecBuff[5])* 2;
		idx= 7;
		Endaddress= Useraddress+ (Cnt/2 - 1);

		//Address������A�h���X�ɂ���B
		Realaddress = Endaddress;
		EndAddrCheck = ChangeUWAddr(PLC_WORD,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */		

		Realaddress = Useraddress;
		AddrCheck = ChangeUWAddr(PLC_WORD,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */

		Address1 = Useraddress;
		Address2 = Endaddress;
		Address1 = SetPLCUsrAddr(WordTbl[PLCIndex[0xEF]].DevInfo, Address1, 0xEF, 1);
		Address2 = SetPLCUsrAddr(WordTbl[PLCIndex[0xEF]].DevInfo, Address2, 0xEF, 1);

//		if(UN_CheckDevice_Addr(1,"UW",&Address1, &Address2)==0){
		if((Address1 >= UNVERS_WRITE_START) && (Address1 <= UNVERS_UW_END) && (Address2 <=UNVERS_UW_END)){		
			if((AddrCheck == 0) && (EndAddrCheck == 0)){		
				Endaddress= Realaddress+ (Cnt/2 - 1);
	#ifdef	LP_S044
				if(CheckPlcDevAccess(Realaddress,Realaddress+(Cnt/2-1)) == OK){
	#endif
					for(i= 0; i < Cnt/2; i++){
						InDevArea.UW[Realaddress]= RecBuff[idx++] << 8;
						InDevArea.UW[Realaddress++] += RecBuff[idx++];
					}
					idx= 0;
					SndBuff[idx++]= RecBuff[0];	/* �ǔ� */
					SndBuff[idx++]= RecBuff[1];	/* Command */
					SndBuff[idx++]= RecBuff[2];	/* Start Addr */
					SndBuff[idx++]= RecBuff[3];	/*  */
					SndBuff[idx++]= RecBuff[4];	/* Register Cnt */
					SndBuff[idx++]= RecBuff[5];	/*  */
					_crc16= Unv_crc16((unsigned char *)SndBuff,idx);
					SndBuff[idx++]= (char)(_crc16 >> 8);
					SndBuff[idx++]= (char)_crc16;
					*SndCnt= idx;
	#ifdef	LP_S044
				}else{
					UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
				}
	#endif
			}else{
				UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
			}
		}else{
			UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}
		break;
	}
}
/*ksc 20050307 */
void	UniversalBroadWrite(unsigned char *RecBuff,int RecCnt,char *SndBuff,int *SndCnt,int mode)
{
	int		Cnt,i;
	int		idx;
	int		didx;
	unsigned int	address,Endaddress;

	int Realaddress;
	int AddrCheck, EndAddrCheck;
	int uwAddr, ubAddr, CmpBit;
	
	unsigned int Address1, Address2;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;
	
	UN_SetPLCDevAddr(&PLCByteCnt,&PLCWordCnt,&ByteTbl,&WordTbl,&PLCIndex);

	switch(RecBuff[1]){
	case	MDBUS_FORCE_MULTIPLE_COILS:
		address= (RecBuff[2] << 8) + RecBuff[3];
		Cnt = (RecBuff[4]<<8)+RecBuff[5];
		//Address������A�h���X�ɂ���B
		Endaddress= address+ Cnt-1;

		Realaddress = Endaddress;
		EndAddrCheck = ChangeUWAddr(PLC_BIT,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */		

		Realaddress = address;
		AddrCheck = ChangeUWAddr(PLC_BIT,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */
	
		Address1 = address;
		Address2 = Endaddress;
		Address1 = SetPLCUsrAddr(ByteTbl[PLCIndex[0x7F]].DevInfo, Address1, 0x7F, 0);
		Address2 = SetPLCUsrAddr(ByteTbl[PLCIndex[0x7F]].DevInfo, Address2, 0x7F, 0);
		
//		if(UN_CheckDevice_Addr(0,"UB",&Address1, &Address2)==0){
		if((Address1 >= UNVERS_UB_W_START) && (Address1 <= UNVERS_UB_END) && (Address2 <= UNVERS_UB_END)){
			if(AddrCheck == 0 && EndAddrCheck == 0){
#ifdef LP_S044
				if(CheckPlcDevAccess((Realaddress>>4),((Realaddress+Cnt-1)>>4)) == OK){
#endif
					uwAddr = Realaddress >>4;  
					ubAddr = Realaddress & 0x0f;
					
					CmpBit = 0x01 << ubAddr;
					
					for(i=0; i<Cnt; i++)
					{
						if((RecBuff[7+i/8]&(0x01<<(i%8)))==0x00){
							InDevArea.UW[uwAddr]&=~CmpBit;
						}else{
							InDevArea.UW[uwAddr]|=CmpBit;
						}
						CmpBit<<=0x01;
						if(CmpBit== 0x10000){
							CmpBit=0x01;
							uwAddr++;
						}
					}	
					*SndCnt= 0;
					break;
#ifdef LP_S044
				}else{
					UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
				}
#endif
			}else{
				UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
			}
		}else{
			UniversalError(RecBuff,SndBuff,SndCnt,UNVERS_ERR_ADR);
		}

		break;		
	case	MDBUS_PRESET_MULTIPLE_REG:
		address= (RecBuff[2] << 8) + RecBuff[3];
		Cnt= ((RecBuff[4] << 8) + RecBuff[5])* 2;
		idx= 7;
		Endaddress= address+ (Cnt/2 - 1);

		//Address������A�h���X�ɂ���B
		Realaddress = Endaddress;
		EndAddrCheck = ChangeUWAddr(PLC_WORD,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */		

		Realaddress = address;
		AddrCheck = ChangeUWAddr(PLC_WORD,(unsigned long*)&Realaddress);	/* ���� ����̽��� ��������̽��� ��ȯ */

		Address1 = address;
		Address2 = Endaddress;
		Address1 = SetPLCUsrAddr(WordTbl[PLCIndex[0xEF]].DevInfo, Address1, 0xEF, 1);
		Address2 = SetPLCUsrAddr(WordTbl[PLCIndex[0xEF]].DevInfo, Address2, 0xEF, 1);

		//if(UN_CheckDevice_Addr(1,"UW",&Address1, &Address2)==0){
		if((Address1 >= UNVERS_WRITE_START) && (Address1 <= UNVERS_UW_END)&& (Address2 <= UNVERS_UW_END) ){		
			if((AddrCheck == 0) && (EndAddrCheck == 0)){		
				Endaddress= Realaddress+ (Cnt/2 - 1);
	#ifdef	LP_S044
				if(CheckPlcDevAccess(Realaddress,Realaddress+(Cnt/2-1)) == OK){
	#endif
					for(i= 0; i < Cnt/2; i++){
						InDevArea.UW[Realaddress]= RecBuff[idx++] << 8;
						InDevArea.UW[Realaddress++] += RecBuff[idx++];
					}
					*SndCnt= 0;
	#ifdef	LP_S044
				}
	#endif
			}
		}
		break;
/*	case MDBUS_PRESET_MULTIPLE_REG:			// Preset Multiple Registers 
		address= (RecBuff[2] << 8) + RecBuff[3];
		Cnt= ((RecBuff[4] << 8) + RecBuff[5])* 2;
		idx= 7;
		Endaddress= address+ (Cnt/2 - 1);
		if((address >= UNVERS_WRITE_START) && (address <= UNVERS_WRITE_END) && (Endaddress <= UNVERS_WRITE_END)){
			didx= address;
			for(i= 0; i < Cnt/2; i++){
				InDevArea.UW[didx]= RecBuff[idx++];
				InDevArea.UW[didx++] += RecBuff[idx++] << 8;
			}

		}
		*SndCnt= 0; // *SndCnt = 0 No response 
		break;*/
	}
}
/*ksc 20050307 */

int	HanyouComm(char	*RecBuff,int RecCnt,char *SndBuff,int *SndCnt)
{
	int		ret;
	unsigned short	_crc16;
	unsigned short	sum1;
	unsigned char work;


	PcTimeout1Char= 0;			/* Timer Clear */
	PcTimeout1Char0= 0;			/* Timer Clear */
	ret = 0;


/* ID(����) Err check */
	if(Set.iGPSta != RecBuff[0]){ 	/* Address = 0 ok Broadcast */
		ret = -1;
	}

	if(ret == 0){		/* Id Error */
		/* Check SUM Check */
		*SndCnt= 0;			/* 061023 */
		_crc16= Unv_crc16((unsigned char *)RecBuff,RecCnt- 2);
		work= (unsigned char)RecBuff[RecCnt- 2];
		sum1= (work << 8)+ (unsigned char)RecBuff[RecCnt- 1];
		if(_crc16 != sum1){
			ret = -1;
		}
		if(ret == 0){			/* ��MOK */
			switch(RecBuff[1]){
/*			case MDBUS_FETCH_COMM_EVENT_CNT:		
			case MDBUS_FETCH_COMM_EVENT_LOG:	*/	
			case MDBUS_READ_COIL_STATUS:		
			case MDBUS_READ_INPUT_STATUS:		
			case MDBUS_READ_HOLDING_REG:		
			case MDBUS_READ_INPUT_REG:		
				UniversalRead((unsigned char *)RecBuff,SndBuff,SndCnt,0);
				break;
/*			case MDBUS_DIAGNOSTICS:		*/
			case MDBUS_FORCE_SINGLE_COIL:			
			case MDBUS_PRESET_SINGLE_REG:	
			case MDBUS_FORCE_MULTIPLE_COILS:			
			case MDBUS_PRESET_MULTIPLE_REG:	
				UniversalWrite((unsigned char *)RecBuff,RecCnt,SndBuff,SndCnt,0);
				break;
			default:
				UniversalError((unsigned char *)RecBuff,SndBuff,SndCnt,UNVERS_ERR_FNC);
				break;
			}
		}else{		/* Data Error */
			if(ret == -1){
				UniversalError((unsigned char *)RecBuff,SndBuff,SndCnt,UNVERS_ERR_DAT); 
			}else{
				*SndCnt= 0;
			}
		}
	}else{
		*SndCnt= 0;
	}
	return(ret);
}

