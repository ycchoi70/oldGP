/************************************************/
/*	PLC�ʐM�v���g�R��							*/
/************************************************/
#define	MATRIX_PROC	1
#include	"sgt.h"
#ifdef	WIN32
#include <time.h>
#endif
extern	_SETUP			Set;					/* set value save struct */
#define	LOG_FILE	"GLP_Log.txt"
#define	MAX_LOG_SIZE	64*1024
/*********************************************************************/
extern	int		ReceiveCount ;
#ifdef	WIN32
//extern	int	SioPCDlgCommCnt;
#endif
/* ���ǔ�?����ǔ� */
char	RecStationno[4];
void	LhtInitLog(void);

void	SetPlcStationNo(void)
{
	sprintf(Jikyoku_Hex,"%02X",Set.iGPSta);
}
void	Rs232c_Receive_Init(void)
{
	int		iKind2;

//Debug
//Set.iGPSta= 1;
	SetPlcStationNo();			//Set My Station No
	LinkEstablish = FALSE ;
	BCC_DATA = 0 ;
	MatrixTimeoutCnt= 0 ;
	DenubTimeoutCnt= 0;
	MatrixRetryCnt= 0;
	LhtInitLog();
//Editor Port Check
	PlcEditorPort= 1;
	if(Set.Ch1_iConnect == CH_CH0){
		iKind2= Set.Ch1_iKind;
	}else{
		iKind2= Set.Ch2_iKind;
	}
	if(iKind2 == EDITER){
		PlcEditorPort= 0;
	}
	if(PlcEditorPort == 0){
		Sio0RecCnt = 0 ;
		memset(Sio0RecBuff,0,sizeof(Sio0RecBuff)) ;
	}else{
		Sio1RecCnt = 0 ;
		memset(Sio1RecBuff,0,sizeof(Sio1RecBuff)) ;
	}
	Matrix_Mode = IDLE ;
}

int		LogStartFlag;
#ifdef	WIN32
int		Log_Pos;
char	LogBuff[0x10000];
#endif
/*----------------------------------------------------------------------*/
/*	�֐���	: LhtInitLog												*/
/*	??	: �k�g�s���M����											*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	LhtInitLog(void)
{
#ifdef	WIN32
	int		i,cnt,ChkCnt,j;
	int		TotalSize;
	FILE	*log_fp;

	log_fp= fopen(LOG_FILE,"r+b");
	if(log_fp == NULL){
		log_fp= fopen(LOG_FILE,"w+b");
		Log_Pos= 0;
	}else{
		Log_Pos= 0;
		TotalSize= 0;
		ChkCnt= 0;
		while(1){
			cnt= fread(LogBuff,1,sizeof(LogBuff),log_fp);
			if(cnt == 0){
				break;
			}
			/* ------��T�� */
			for(i= 0; i< cnt; i++){
				if(LogBuff[i] == '-'){
					if(ChkCnt == 0){
						ChkCnt++;
						Log_Pos = TotalSize+ i;
					}else{
						ChkCnt++;
						if(ChkCnt > 5){
							break;
						}
					}
				}else{
					ChkCnt= 0;
				}
			}
			TotalSize += cnt;
			if(ChkCnt > 5){
				break;
			}
		}
		if(ChkCnt > 5){	/* ------���������� */
			if(Log_Pos == 0){		/* �ŏI�f??��?�F�b�N���� */
				fseek(log_fp,0,SEEK_END);
				fseek(log_fp,-128,SEEK_CUR);
				cnt= fread(LogBuff,1,sizeof(LogBuff),log_fp);
				if(cnt != 0){
					/* ------����납��T�� */
					for(i= cnt- 1,j= 0; i >= 0; i--,j++){
						if(LogBuff[i] == '-'){
						}else{
							if(j == 0){
							}else{
								Log_Pos= MAX_LOG_SIZE- j;
							}
							break;
						}
					}
				}
			}
		}else{
			Log_Pos= TotalSize;	/* �ŏI�ʒu��ݒ肷�� */
		}
	}
	fclose(log_fp);
	LogStartFlag= 0;
#endif
}
/*----------------------------------------------------------------------*/
/*	�֐���	: LhtRcvLog													*/
/*	??	: ��M���O��������											*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	PlcLogWrite(int mode,int cnt,unsigned char *buff)
{
#ifdef	WIN32
	int		i,idx,cwork;
	char	work[2048];
	int		len;
	FILE	*fp;
    time_t tt;
    struct tm  *tp;


	fp= fopen(LOG_FILE,"r+b");
	if(fp == NULL){
		fp= fopen(LOG_FILE,"w+b");
	}

	if(fp == 0){
		return;
	}
	fseek(fp,Log_Pos,SEEK_SET);
	if(LogStartFlag == 0){		/* ���Ԃ��������� */
		LogStartFlag= 1;
		time(&tt);
		tp = localtime(&tt);
		sprintf(work,"%04d/%02d/%02d %02d:%02d:%02d",
			tp->tm_year+ 1900,tp->tm_mon + 1,tp->tm_mday,
			tp->tm_hour,tp->tm_min,tp->tm_sec);
		len= strlen(work);
		work[len++]= '\x0d';
		work[len++]= '\x0a';
		if((Log_Pos+ len) > MAX_LOG_SIZE){
			cwork= MAX_LOG_SIZE- Log_Pos;
			fwrite(work,1,cwork,fp);
			fseek(fp,0,SEEK_SET);
			fwrite(&work[cwork],1,len- cwork,fp);
			Log_Pos= len- cwork;
		}else{
			fwrite(work,1,len,fp);
			Log_Pos += len;
		}
	}
	if(mode == 0){	/* Send */
		sprintf(LogBuff,"S:");
	}else{
		sprintf(LogBuff,"R:");
	}

	idx= 2;
	for(i= 0; i< cnt; i++){
		if(((unsigned char)buff[i] < ' ') || ((unsigned char)buff[i] >= 0x80)){
			LogBuff[idx++]= '<';
			switch(buff[i]){
			case 2:	/* STX */
				LogBuff[idx++]= 'S';
				LogBuff[idx++]= 'T';
				LogBuff[idx++]= 'X';
				break;
			case 3:	/* ETX */
				LogBuff[idx++]= 'E';
				LogBuff[idx++]= 'T';
				LogBuff[idx++]= 'X';
				break;
			case 5:	/* ENQ */
				LogBuff[idx++]= 'E';
				LogBuff[idx++]= 'N';
				LogBuff[idx++]= 'Q';
				break;
			case 6:	/* ACK */
				LogBuff[idx++]= 'A';
				LogBuff[idx++]= 'C';
				LogBuff[idx++]= 'K';
				break;
			case 0x15:	/* NAK */
				LogBuff[idx++]= 'N';
				LogBuff[idx++]= 'A';
				LogBuff[idx++]= 'K';
				break;
			default:
				sprintf(work,"%02X",buff[i]);
				LogBuff[idx++]= '$';
				LogBuff[idx++]= work[0];
				LogBuff[idx++]= work[1];
				break;
			}
			LogBuff[idx++]= '>';
		}else{
			LogBuff[idx++]= buff[i];
		}
	}
	LogBuff[idx++]= '\x0d';
	LogBuff[idx++]= '\x0a';
	strcpy(&LogBuff[idx],"---------------\x0d\x0a");
	len= strlen(LogBuff);
	fseek(fp,Log_Pos,SEEK_SET);
	if((Log_Pos+ len) > MAX_LOG_SIZE){
		cwork= MAX_LOG_SIZE- Log_Pos;
		fwrite(LogBuff,1,cwork,fp);
		fseek(fp,0,SEEK_SET);
		fwrite(&LogBuff[cwork],1,len- cwork,fp);
	}else{
		fwrite(LogBuff,1,len,fp);
	}
	if((Log_Pos+ idx) > MAX_LOG_SIZE){
		Log_Pos= (Log_Pos+ idx)- MAX_LOG_SIZE;
	}else{
		Log_Pos += idx;
	}

	fclose(fp);
#endif
}
int Ascii2_Hexa_Check(char *Dat)
{
	if(   ((Dat[0] >= '0' && Dat[0] <= '9') || ( Dat[0] >= 'A' && Dat[0] <= 'F'))   &&
		  ((Dat[1] >= '0' && Dat[1] <= '9') || ( Dat[1] >= 'A' && Dat[1] <= 'F'))) {
		return TRUE ;
	}
	return FALSE ;
}
/*----------------------------------------------------------------------*/
/*	�֐���	: CheckMyStation											*/
/*	??	: �X�e?�V�����ԍ�?�F�b�N����								*/
/*			  GP�X�e?�V�����ԍ���FF�͗L��								*/
/*	����	: int *recCnt:��M�J�E���g									*/
/*			  unsigned char* recBuff:��M�o�b�t??						*/
/*	�߂�l	: TRUE:OK,FALSE:NG											*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	CheckMyStation(int *recCnt,unsigned char* recBuff)
{
	int		i;
	int		ret;
	int		idx;
	int		cnt;

	ret= FALSE;
	if(*recCnt >= 4){
		cnt= *recCnt;
		for(i= 0;i < 4; i++){
			cnt--;
			idx= cnt%PLC_BUF_MAX;
			RecStationno[3-i]= recBuff[idx--];
		}
		if((Jikyoku_Hex[0] == RecStationno[0] && Jikyoku_Hex[1] == RecStationno[1]) ||
		   (RecStationno[0] == 'F' && RecStationno[1] == 'F')) {
			memcpy(&RecStationno[0],&Jikyoku_Hex[0],2);		// 20081007 
			ret= TRUE;
			if(cnt > 0){
				memcpy(recBuff,RecStationno,4);
				*recCnt= 4;
			}
		}
	}
	return(ret);
}
void	Set1char2buff(char ch,int *recCnt,unsigned char* recBuff)
{
	recBuff[*recCnt] = ch ;
	(*recCnt)++;
	*recCnt= *recCnt%PLC_BUF_MAX;
	PlcLogWrite(1,*recCnt,recBuff);
	LogStartFlag= 0;
	*recCnt = 0 ;
}
//----------------------------
//	2008.09.28
//	�ǔԂ͎����̋ǔԂ�Ԃ�
//----------------------------
void	SetRecKyokuBan(unsigned char* sndBuff,unsigned char* recBuff)
{
	memcpy(sndBuff,&recBuff[2],2) ;
	memcpy(&sndBuff[2],&Jikyoku_Hex[0],2) ;
}
/*----------------------------------------------------------------------*/
/*	�֐���	: Rs232c_Char_Proc											*/
/*	??	: PLC?�g���N�X����											*/
/*	����	: char ch:��M����											*/
/*			  int* sndCnt:���M������									*/
/*			  unsigned char* sndBuff:���M�����o�b�t??					*/
/*			  int *recCnt:��M������									*/
/*			  unsigned char* recBuff:��M�����o�b�t??					*/
/*	�߂�l	: -1:�p��,ELSE:�d�����ߌ���									*/
/*				0:BCC�܂Ŏ�M�n�j										*/
/*				1:���M���?�b�j��M									*/
/*				2:���M��̂m?�j��M									*/
/*				3:���M�d������											*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int  Rs232c_Char_Proc(char ch,int* sndCnt,unsigned char* sndBuff,int *recCnt,unsigned char* recBuff) 
{
	int	result;
	unsigned char	RecBcc;

	result= -1 ;
	switch(Matrix_Mode) {
		case IDLE :
			switch(ch) {
				/******************************************** ENQ **********************************/
				case ENQ:
					if(CheckMyStation(recCnt,recBuff) == TRUE){
						// ���M��ǔԈ�v
						//memcpy(sndBuff,&recBuff[2],2) ;
						//memcpy(&sndBuff[2],Jikyoku_Hex,2) ;
						SetRecKyokuBan(sndBuff,recBuff);	//2008.09.28
						sndBuff[4] = ACK ;
						*sndCnt= 5;
						result= 3;
						*recCnt = 0 ;
						Matrix_Mode = STX_WAIT ;
					}
					Set1char2buff(ch,recCnt,recBuff);
					break ;
				case STX: //���ǔԃf??��������A���R
					if(CheckMyStation(recCnt,recBuff) == TRUE){
						// ���M��ǔԈ�v
						Matrix_Mode = DATA_RECEIVE_COMPLETE_WAIT ;
						MatrixTimeoutCnt= 30;	/* */
						BCC_DATA = 0 ;
					}
					Set1char2buff(ch,recCnt,recBuff);
					break ;
				case DC1:
					if(CheckMyStation(recCnt,recBuff) == TRUE){
						// ���M��ǔԈ�v
						//memcpy(sndBuff,&recBuff[2],2) ;
						//memcpy(&sndBuff[2],Jikyoku_Hex,2) ;
						SetRecKyokuBan(sndBuff,recBuff);	//2008.09.28
						sndBuff[4] = DC2 ;
						*sndCnt= 5;
						result= 3;
						*recCnt = 0 ;
					}
					Set1char2buff(ch,recCnt,recBuff);
					break;
				default:
					recBuff[*recCnt] = ch ;
					(*recCnt)++;
					*recCnt= *recCnt%PLC_BUF_MAX;
					break ;
			}
			break ;
		case STX_WAIT:
			switch(ch) {
				case ENQ: //���ǔԃf??��������A?�b�j���M���Q
					if(CheckMyStation(recCnt,recBuff) == TRUE){
						// ���M��ǔԈ�v
						//memcpy(sndBuff,&recBuff[2],2) ;
						//memcpy(&sndBuff[2],Jikyoku_Hex,2) ;
						SetRecKyokuBan(sndBuff,recBuff);	//2008.09.28
						sndBuff[4] = ACK ;
						*sndCnt= 5;
						result= 3;
						*recCnt = 0 ;
						Matrix_Mode = STX_WAIT ;
					}
					Set1char2buff(ch,recCnt,recBuff);
					break ;
				case STX: //���ǔԃf??��������A���R
					if(CheckMyStation(recCnt,recBuff) == TRUE){
						// ���M��ǔԈ�v
						Matrix_Mode = DATA_RECEIVE_COMPLETE_WAIT ;
						MatrixTimeoutCnt= 30;	/* */
						BCC_DATA = '\0' ;
					}
					Set1char2buff(ch,recCnt,recBuff);
					break;
				case DC1:
					if(CheckMyStation(recCnt,recBuff) == TRUE){
						// ���M��ǔԈ�v
						//memcpy(sndBuff,&recBuff[2],2) ;
						//memcpy(&sndBuff[2],Jikyoku_Hex,2) ;
						SetRecKyokuBan(sndBuff,recBuff);	//2008.09.28
						sndBuff[4] = DC2 ;
						*sndCnt= 5;
						result= 3;
						*recCnt = 0 ;
					}
					Set1char2buff(ch,recCnt,recBuff);
					break;
				default:
					recBuff[*recCnt] = ch ;
					(*recCnt)++;
					*recCnt= *recCnt%PLC_BUF_MAX;
					break ;
			}
			break ;
		case DATA_RECEIVE_COMPLETE_WAIT:
			if(*recCnt < PLC_BUF_MAX- 3){
				switch(ch) {
				case ETB: //�f??��M���� ���S
				case ETX: 
					recBuff[(*recCnt)++] = ch ;
					BCC_DATA ^= (unsigned char)ch ;
					Matrix_Mode = BCC1_RECEIVE_WAIT ;
					break;
				default:
					recBuff[(*recCnt)++] = ch ;
					BCC_DATA ^= (unsigned char)ch ;
					break;
				}
			}
			break ;
		case BCC1_RECEIVE_WAIT:
			recBuff[(*recCnt)++] = ch ;
			BCC_Check[0] = ch ;
			Matrix_Mode = BCC2_RECEIVE_WAIT ;
			break ;
		case BCC2_RECEIVE_WAIT:
			recBuff[(*recCnt)++] = ch ;
			PlcLogWrite(1,*recCnt,recBuff);
			LogStartFlag= 0;
			BCC_Check[1] = ch ;
			RecBcc= Hex2nBin(BCC_Check,2);
			if(RecBcc == BCC_DATA) { // BCC OK ACK
				Matrix_Mode = IDLE ;
				MatrixTimeoutCnt= 0;	/* */
				result= 0 ;
				DenubTimeoutCnt= 0;
			}else{	// BCC NG NAK
				//memcpy(sndBuff,&recBuff[2],2) ;
				//memcpy(&sndBuff[2],Jikyoku_Hex,2) ;
				SetRecKyokuBan(sndBuff,(unsigned char*)RecStationno);	//2008.09.28
				sndBuff[4] = NAK ;
				*sndCnt= 5;
				result= 3;
				*recCnt = 0 ;
				memset(recBuff,'\0',sizeof(recBuff)) ;
				Matrix_Mode = IDLE ;
				MatrixTimeoutCnt= 0;	/* */
			}
			break ;
		case ENQ_ANS_WAIT:
			switch(ch) {
				case ENQ: //���ǔԂ�������?�b�j���M���P
					if(CheckMyStation(recCnt,recBuff) == TRUE){
						//memcpy(sndBuff,&recBuff[2],2) ;
						//memcpy(&sndBuff[2],Jikyoku_Hex,2) ;
						SetRecKyokuBan(sndBuff,recBuff);	//2008.09.28
						sndBuff[4] = ACK ;
						*sndCnt= 5;
						result= 3;
						Matrix_Mode = IDLE;
					}
					Set1char2buff(ch,recCnt,recBuff);
					break ;
				case ACK: //���ǔԂ������烊���N�m�����P
					PlcLogWrite(1,*recCnt,recBuff);
					if(CheckMyStation(recCnt,recBuff) == TRUE){
						LinkEstablish = TRUE ;
						Matrix_Mode = IDLE ;
					}
					Set1char2buff(ch,recCnt,recBuff);
					break ;
				case DC1:
					if(CheckMyStation(recCnt,recBuff) == TRUE){
						// ���M��ǔԈ�v
						//memcpy(sndBuff,&recBuff[2],2) ;
						//memcpy(&sndBuff[2],Jikyoku_Hex,2) ;
						SetRecKyokuBan(sndBuff,recBuff);	//2008.09.28
						sndBuff[4] = DC2 ;
						*sndCnt= 5;
						result= 3;
						*recCnt = 0 ;
					}
					Set1char2buff(ch,recCnt,recBuff);
					break;
				default:
					recBuff[*recCnt] = ch ;
					(*recCnt)++;
					*recCnt= *recCnt%PLC_BUF_MAX;
					break ;
			}
			break ;
		case DATA_SEND_WAIT:
			switch(ch) {
				case ACK:
					PlcLogWrite(1,*recCnt,recBuff);
					if(CheckMyStation(recCnt,recBuff) == TRUE){
						// ���M��ǔԈ�v
						//memcpy(sndBuff,&recBuff[2],2) ;
						//memcpy(&sndBuff[2],Jikyoku_Hex,2) ;
						SetRecKyokuBan(sndBuff,recBuff);	//2008.09.28
//KSC20090112
//						*recCnt = 0 ;
						result= 1 ;
						DenubTimeoutCnt= 0;		/* Time Out Clear */
						if(SndCodeCnt < CodeCnt){
						}else{
							Matrix_Mode = IDLE ;
						}
					}
					Set1char2buff(ch,recCnt,recBuff);
					break ;
				case NAK:
					PlcLogWrite(1,*recCnt,recBuff);
					if(CheckMyStation(recCnt,recBuff) == TRUE){
						// ���M��ǔԈ�v
						//memcpy(sndBuff,&recBuff[2],2) ;
						//memcpy(&sndBuff[2],Jikyoku_Hex,2) ;
						SetRecKyokuBan(sndBuff,recBuff);	//2008.09.28
						*recCnt = 0 ;
						result= 2 ;
					}
					Set1char2buff(ch,recCnt,recBuff);
					break ;
				case DC1:
					if(CheckMyStation(recCnt,recBuff) == TRUE){
						// ���M��ǔԈ�v
						//memcpy(sndBuff,&recBuff[2],2) ;
						//memcpy(&sndBuff[2],Jikyoku_Hex,2) ;
						SetRecKyokuBan(sndBuff,recBuff);	//2008.09.28
						sndBuff[4] = DC2 ;
						*sndCnt= 5;
						result= 3;
						*recCnt = 0 ;
					}
					Set1char2buff(ch,recCnt,recBuff);
					break;
				default:
					recBuff[*recCnt] = ch ;
					(*recCnt)++;
					*recCnt= *recCnt%PLC_BUF_MAX;
					break ;
			}
			break ;
		default:
			break ;
	}
	return (result) ;
}
void	MatrixTimeoutProc(void)
{
	if(PlcEditorPort == 0){
		Sio0RecCnt = 0 ;
		memset(Sio0RecBuff,0,sizeof(Sio0RecBuff)) ;
	}else{
		Sio1RecCnt = 0 ;
		memset(Sio1RecBuff,0,sizeof(Sio1RecBuff)) ;
	}
	Matrix_Mode = IDLE ;
}

