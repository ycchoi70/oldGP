/********************************************/
/*	IN-RAM Program							*/
/********************************************/
#include	<string.h>
#include	"define.h"
#include	"S3c44b0x.h"
#include	"mts.h"
#include	"mail.h"
#include	"mtscifp.h"
#include	"PlcProtType.h"
#include	"option.h"


#define	FFLASH_PROC	0x0000F000
#define	SFLASH_PROC	0x040F0000

#define	FLASH_PROC_START	0x040F0000
#define	PLC1_PROC_START	PLC1_PROTOCOL
#define	PLC2_PROC_START	PLC2_PROTOCOL

/********************************************************/
/*	FULASH Control										*/
/********************************************************/
#ifdef	WIN32
	extern	unsigned char			GpFont[0x200000];
	void	_ei(void)
	{
	}
	void	_di(void)
	{
	}
#else
	extern	void	_ei(void);
	extern	void	_di(void);
#endif

extern	void	SetSystemMessegeTbl(void);
int	RamFlashWriteProc(char *addr,char *data,int size)
{
#ifdef	WIN32
	unsigned char	*obj;

	obj= (unsigned char *)&GpFont[(int)addr];
	memcpy(obj,data,size);
	return(0);
#else
	int		ret;
	int	(*func)(char *addr,char *data,int size);

	func= (int (*)(char *,char *,int))(FLASH_PROC_START+4);
	_di();
//	rSYSCFG		= 0x00000001;
    ret= func(addr,data,(long)size);
//	rSYSCFG=CACHECFG;
	//2008.03.05
	if((int)addr == 0xb0000){	//System Message Area
		SetSystemMessegeTbl();
	}


	_ei();
	return(ret);
#endif
}
int	RamFlashCashWriteProc(char *addr,char *data,int size)
{
#ifdef	WIN32
	unsigned char	*obj;

	obj= (unsigned char *)&GpFont[(int)addr];
	memcpy(obj,data,size);
	return(0);
#else
	int		ret;
	int	(*func)(char *addr,char *data,int size);

	func= (int (*)(char *,char *,int))(FLASH_PROC_START+4);
	_di();
	rSYSCFG		= 0x00000001;
    ret= func(addr,data,(long)size);
	rSYSCFG=CACHECFG;
	//2008.03.05
	if((int)addr == 0xb0000){	//System Message Area
		SetSystemMessegeTbl();
	}


	_ei();
	return(ret);
#endif
}
//int	FlashErr;
void	RamFlashWrite(short *addr,short *data, long count)
{
#ifdef	WIN32
	unsigned char	*obj;

	obj= (unsigned char *)&GpFont[(int)addr];
	memcpy(obj,data,count);
#else
	void	(*func)(short *addr,short *data,long count);
//	int	i;
//	int	j;

//	volatile unsigned short*	sAddr;
//	volatile unsigned short*	oAddr;
//	chkAddr= (unsigned short*)addr;
//	FlashErr= 0;
//	for(i= 0; i < count/2; i++){
//		chkdata= *chkAddr++;
//		if(chkdata != (unsigned short)0xffff){
//			FlashErr= 1;
//			break;
//		}
//	}
//	if((count > 32) && (FlashErr == 1)){
//		FlashErr= 2;
//		return;
//	}
	func= (void (*)(short *,short *,long))(FLASH_PROC_START+12);
//	j= 0;
//	while(1){
		_di();
//		rSYSCFG		= 0x00000001;
		func(addr,data,count);
//		rSYSCFG=CACHECFG;   
		_ei();
//		sAddr= (volatile unsigned short*)addr;
//		oAddr= (volatile unsigned short*)data;
//		for(i= 0; i < count/2; i++){
//			if(*sAddr++ != *oAddr++){
//				break;
//			}
//		}
//		if(i >= count/2){
//			break;
//		}
//		j++;
//	}
#endif
}
void	RamFlashEraze(short *addr)
{
#ifdef	WIN32
	unsigned char	*obj;
	int		cnt;

	obj= (unsigned char *)&GpFont[(int)addr];
	cnt= 0x10000;
	if((int)addr < (0x1f0000+FLASH_START)){
		cnt= 0x10000;
	}else if((int)addr < (0x1f8000+FLASH_START)){
		cnt= 0x8000;
	}else if((int)addr < (0x1fc000+FLASH_START)){
		cnt= 0x2000;
	}else if((int)addr < (0x200000+FLASH_START)){
		cnt= 0x4000;
	}
	memset(obj,0xff,cnt);
#else
	void	(*func)(short *addr);

	func= (void (*)(short *))(FLASH_PROC_START+8);
	_di();
//	rSYSCFG		= 0x00000001;
	func(addr);
//	rSYSCFG=CACHECFG;   
	_ei();
#endif


}
void	FlashProcMoce(void)
{
	int		i;
	unsigned int	*src;
	unsigned int	*obj;

	src= (unsigned int *)FFLASH_PROC;
	obj= (unsigned int *)SFLASH_PROC;
	for(i= 0; i < 0x1000/4; i++){
		*obj++ = *src++;
	}
}
#ifndef	TEST_PROT
/********************************************************/
/*	PLC1 Control										*/
/********************************************************/
int	PLC_CONNECT(int *PlcType,int iConnect)
{
	int	(*func)(int *,int);
#ifdef	WIN32
	func= Connection;
#else
	func= (int (*)(int *,int))(PLC1_PROC_START+8+32);
#endif
	return(func(PlcType,iConnect));
}
int	GET_PLC_NAME(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int	(*func)(int,unsigned char*,char*,int*);
#ifdef	WIN32
	func= GetDevNamePLC;
#else
	func= (int (*)(int,unsigned char*,char*,int*))(PLC1_PROC_START+12+32);
#endif
	return(func(bFlag,src,obj,DevInfo));
}
int	PLC1CHAR_READ(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	(*func)(unsigned char,int*,int*,unsigned char*);
#ifdef	WIN32
	func= PlcReadProc;
#else
	func= (int (*)(unsigned char,int*,int*,unsigned char*))(PLC1_PROC_START+16+32);
#endif
	return(func(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int	(*func)(T_MAIL *,unsigned char*,int);
#ifdef	WIN32
	func= PLCCommRead;
#else
	func= (int (*)(T_MAIL *,unsigned char*,int))(PLC1_PROC_START+20+32);
#endif
	return(func(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int	(*func)(T_MAIL *,unsigned char*,int);
#ifdef	WIN32
	func= PLCCommWrite;
#else
	func= (int (*)(T_MAIL *,unsigned char*,int))(PLC1_PROC_START+24+32);
#endif
	return(func(mp,rDataFx,PlcType));
}
int	PLCPCDOWN(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	(*func)(unsigned char,int*,int*,unsigned char*);
#ifdef	WIN32
	func= PLCPCDownThrue;
#else
	func= (int (*)(unsigned char,int*,int*,unsigned char*))(PLC1_PROC_START+28+32);
#endif
	return(func(data,CommMode,RecCnt,RecBuff));
}
int	GET_PLC_MAX(int bFlag,int idx)
{
	int	(*func)(int,int);
#ifdef	WIN32
	func= GetDevMaxPLC;
#else
	func= (int (*)(int,int))(PLC1_PROC_START+32+32);
#endif
	return(func(bFlag,idx));
}
int	GET_PLC_MIN(int bFlag,int idx)
{
	int	(*func)(int,int);
#ifdef	WIN32
	func= GetDevMinPLC;
#else
	func= (int (*)(int,int))(PLC1_PROC_START+36+32);
#endif
	return(func(bFlag,idx));
}
int		DEVICE_2_INDEX(int bwflag,char *Name)
{
	int	(*func)(int,char*);
#ifdef	WIN32
	func= Device2IndexPLC;
#else
	func= (int (*)(int,char*))(PLC1_PROC_START+40+32);
#endif
	return(func(bwflag,Name));
}
int		CHECK_PLC_ADDR(int bwflag,char *Name,int *Address1,int *plctype)
{
	int	(*func)(int,char*,int*,int*);
#ifdef	WIN32
	func= CheckPLC_Addr;
#else
	func= (int (*)(int,char*,int*,int*))(PLC1_PROC_START+44+32);
#endif
	return(func(bwflag,Name,Address1,plctype));
}
void	GET_MON_BAUDRATE(int *Speed,int *DataBit,int *Parity)
{
	void	(*func)(int*,int*,int*);
#ifdef	WIN32
	func= GetMonBaudrate;
#else
	func= (void (*)(int*,int*,int*))(PLC1_PROC_START+48+32);
#endif
	func(Speed,DataBit,Parity);
}
int	GET_SEND_REC_TIME(void)
{
	int	(*func)(void);
#ifdef	WIN32
	func= GetSendRecTime;
#else
	func= (int (*)(void))(PLC1_PROC_START+52+32);
#endif
	return(func());
}
void	GET_PLC1_VER(char *Name)
{
	void	(*func)(char*);
#ifdef	WIN32
	func= Get_Plc1_Ver;
#else
	func= (void (*)(char*))(PLC1_PROC_START+56+32);
#endif
	func(Name);
}
int	PLC_MAKE_GROUP(int PlcType)
{
	int	(*func)(int);
#ifdef	WIN32
	func= MakeGroupDevPLC;
#else
	func= (int (*)(int))(PLC1_PROC_START+60+32);
#endif
	return(func(PlcType));
}
int	PLC_GROUP_READ(int PlcType)
{
	int	(*func)(int);
#ifdef	WIN32
	func= RecGroupPLCDev;
#else
	func= (int (*)(int))(PLC1_PROC_START+64+32);
#endif
	return(func(PlcType));
}
void	PLC_THRU_PROC(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt,int PlcConnectFlag,int PlcType)
{
	void	(*func)(char*,int*,char*,int*,int,int);
#ifdef	WIN32
	func= PLCFxThruProc;
#else
	func= (void (*)(char*,int*,char*,int*,int,int))(PLC1_PROC_START+68+32);
#endif
	func(CommBuff,RecCommCnt,OutBuff,OutCnt,PlcConnectFlag,PlcType);
}
int	GET_MS_SEL(void)
{
	int	(*func)(void);
#ifdef	WIN32
	func= Get_Ms_Sel;
#else
	func= (int (*)(void))(PLC1_PROC_START+72+32);
#endif
	return(func());
}
/********************************************************/
/*	PLC2 Control										*/
/********************************************************/

int	PLC_CONNECT2(int *PlcType,int iConnect)
{
	int	(*func)(int *,int);
#ifdef	WIN32
	func= Connection2;
#else
	func= (int (*)(int *,int))(PLC2_PROC_START+8+32);
#endif
	return(func(PlcType,iConnect));
}
int	PLC1CHAR_READ2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	(*func)(unsigned char,int*,int*,unsigned char*);
#ifdef	WIN32
	func= PlcReadProc2;
#else
	func= (int (*)(unsigned char,int*,int*,unsigned char*))(PLC2_PROC_START+12+32);
#endif
	return(func(data,CommMode,RecCnt,RecBuff));
}
int	PLC_DEV_READ2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int	(*func)(T_MAIL *,unsigned char*,int);
#ifdef	WIN32
	func= PLCCommRead2;
#else
	func= (int (*)(T_MAIL *,unsigned char*,int))(PLC2_PROC_START+16+32);
#endif
	return(func(mp,rDataFx,PlcType));
}
int	PLC_DEV_WRITE2(T_MAIL *mp,unsigned char *rDataFx,int PlcType)
{
	int	(*func)(T_MAIL *,unsigned char*,int);
#ifdef	WIN32
	func= PLCCommWrite2;
#else
	func= (int (*)(T_MAIL *,unsigned char*,int))(PLC2_PROC_START+20+32);
#endif
	return(func(mp,rDataFx,PlcType));
}
int	GET_SEND_REC_TIME2(void)
{
	int	(*func)(void);
#ifdef	WIN32
	func= GetSendRecTime2;
#else
	func= (int (*)(void))(PLC2_PROC_START+24+32);
#endif
	return(func());
}
void	GET_PLC2_VER(char *Name)
{
	void	(*func)(char*);
#ifdef	WIN32
	func= Get_Plc2_Ver;
#else
	func= (void (*)(char*))(PLC2_PROC_START+28+32);
#endif
	func(Name);
}
int	GET_MS_SEL2(void)
{
	int	(*func)(void);
#ifdef	WIN32
	func= Get_Ms_Sel2;
#else
	func= (int (*)(void))(PLC2_PROC_START+32+32);
#endif
	return(func());
}
void	GET_MON_BAUDRATE2(int *Speed,int *DataBit,int *Parity)
{
	void	(*func)(int*,int*,int*);
#ifdef	WIN32
	func= GetMonBaudrate2;
#else
	func= (void (*)(int*,int*,int*))(PLC2_PROC_START+36+32);
#endif
	func(Speed,DataBit,Parity);
}
#endif
