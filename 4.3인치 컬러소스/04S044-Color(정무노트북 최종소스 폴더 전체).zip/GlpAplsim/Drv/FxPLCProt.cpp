 /************************************************/
/*	FX�V��?�Y�R���g��?���v���O��?			*/
/************************************************/
#include	<string.h>
#include	<stdio.h>
#include	<stdlib.h>

#include	"mts.h"
#include	"mtscifp.h"
#include	"taskhed.h"
#include	"mail.h"
#include	"define.h"
#include	"GpCommon.h"

/*#define	XP	1*/

#ifndef	WIN32
#pragma	section DefPlcProc
#endif

#define	PLCMAIN
#include	"PlcCommBuff.h"

/*********************************/
extern	void	PLCSendProc(T_MAIL *mp);
extern	int	Hex2nBin(char *buff,int cnt);
extern	int	Hex2Bin(char *buff);
extern	unsigned int LHexAsToBin(char *buff, int cnt);
extern	void	InitSci1( int borate, int ldata, int parity );
extern	void	InitSci0( int borate, int ldata, int parity );
extern	int	SendPLC2PCData( int mode );
extern	int	SendPC2PLCData( int mode );
extern	int	SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode);
/* 20081003 */
extern	int	SendPLCPCData( void );
extern	int	GetDevNameFX(int bFlag,unsigned char *src,char *obj,int *DevInfo);
extern	int	GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address);
extern	int		Device2IndexFX(int bwflag,char *Name);

extern	void	PlcDevInit( void );
extern	void	SendPLCGroup(void);

/*********************************/
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPLCOpenFlag;
extern	int		SioPCOpenFlag;
/*********************************/
extern	int		PlcErrorFlag;
extern	int		PlcConnectFlag;				/* PLC�ڑ��t���O */
/************************************/
extern	int		PlcType;
/************************************/
char	FX1N_00E0202[4+4];
/* Fx1n								*/
const char *ConnectHed= "10EEC04";
char	FX1N_00EE804[8+4];
/* Fx1s								*/
/********************************/
/*	FX Serease					*/
/********************************/
const	unsigned char IndexTable[256]={
	/* BIT */
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x00,0xff,0xff,0xff,0x01,0xff,0xff,0xff,0x02,0xff,0x03,0x04,0xff,0xff,0xff,0xff,
	0xff,0xff,0x05,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x08,0xff,0x07,0xff,0x06,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x09,0x0a,0xff,0xff,0x0b,0x0c,0x0d,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x0e,
	/* WORD */
	0x00,0xff,0xff,0xff,0x01,0xff,0xff,0xff,0x02,0xff,0x03,0x04,0xff,0xff,0xff,0xff,
	0xff,0xff,0x05,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x06,0xff,0x07,0xff,0x08,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x09,0x0a,0xff,0xff,0x0b,0x0c,0x0d,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0x0e,0x0f,0x10,0x11,0xff,0xff,0xff,0xff,0x12,0x13,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x14,
	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
};
const	int LowHighFlag= 0;				/* 0:L-H,1:H-L */
const	int	FX_SereaseByteCnt= 15;
const	DEV_PC_TBL	FX_SereaseByte[32]=
	{
		{1,0x10,{'X',  0, 0},0x80,0x00000000,0x00000017},
		{1,0x14,{'Y',  0, 0},0x80,0x00000000,0x00000015},
		{1,0x18,{'M',  0, 0},0x84,0x00000000,0x00000383},
		{1,0x1a,{'M',  0, 0},0x84,0x00000384,0x00000511},
		{1,0x1b,{'M',  0, 0},0x84,0x00008000,0x00008255},
		{1,0x22,{'S',  0, 0},0x84,0x00000000,0x00000127},
		{1,0x34,{'T',  0, 0},0x84,0x00000000,0x00000031},
		{1,0x32,{'T',  0, 0},0x84,0x00000000,0x00000062},
		{1,0x30,{'T',  0, 0},0x84,0x00000000,0x00000063},
		{1,0x50,{'C',  0, 0},0xC4,0x00000000,0x00000015},
		{1,0x51,{'C',  0, 0},0xC4,0x00000000,0x00000031},
		{1,0x54,{'C',  0, 0},0xC4,0x00000000,0x00000245},
		{1,0x55,{'C',  0, 0},0xC4,0x00000000,0x00000250},
		{1,0x56,{'C',  0, 0},0xC4,0x00000000,0x00000255},
		{1,0x7f,{'G','B', 0},0x84,0x00000000,0x00001024},
	};
const	int	FX_SereaseWordCnt= 21;
const	DEV_PC_TBL	FX_SereaseWord[32]=
	{
		{2,(unsigned char)0x80,{'X',  0, 0},0x80,0x00000000,0x00000010},
		{2,(unsigned char)0x84,{'Y',  0, 0},0x80,0x00000000,0x00000010},
		{2,(unsigned char)0x88,{'M',  0, 0},0x89,0x00000000,0x00000363},
		{2,(unsigned char)0x8a,{'M',  0, 0},0x89,0x00000384,0x00000496},
		{2,(unsigned char)0x8b,{'M',  0, 0},0x89,0x00008000,0x00008240},
		{1,(unsigned char)0x92,{'S',  0, 0},0x89,0x00000000,0x00000112},
		{2,(unsigned char)0xa0,{'T',  0, 0},0x84,0x00000063,0x00000063},
		{2,(unsigned char)0xa2,{'T',  0, 0},0x84,0x00000032,0x00000062},
		{2,(unsigned char)0xa4,{'T',  0, 0},0x84,0x00000000,0x00000031},
		{2,(unsigned char)0xb0,{'C',  0, 0},0xc4,0x00000000,0x00000015},
		{2,(unsigned char)0xb1,{'C',  0, 0},0xc4,0x00000016,0x00000031},
		{2,(unsigned char)0xb4,{'C',  0, 0},0xc4,0x00000235,0x00000245},
		{2,(unsigned char)0xb5,{'C',  0, 0},0xc4,0x00000246,0x00000250},
		{2,(unsigned char)0xb6,{'C',  0, 0},0xc4,0x00000251,0x00000255},
		{2,(unsigned char)0xc0,{'D',  0, 0},0xA4,0x00000000,0x00000127},
		{2,(unsigned char)0xc1,{'D',  0, 0},0xA4,0x00000128,0x00000255},
		{2,(unsigned char)0xc2,{'D',  0, 0},0xA4,0x00001000,0x00002499},
		{2,(unsigned char)0xc3,{'D',  0, 0},0xA4,0x00008000,0x00008255},
		{2,(unsigned char)0xc8,{'V',  0, 0},0x84,0x00000000,0x00000007},
		{2,(unsigned char)0xc9,{'Z',  0, 0},0x84,0x00000000,0x00000007},
		{2,(unsigned char)0xef,{'G','D', 0},0x84,0x00000000,0x00001024},
	};

DEV_TBL bDeviceTbl[4][16] = {
	{						/* FX1N */
		{"M" ,0x0000,7},		/* 0 */
		{"M2",0x0E00,0},		/* 1 */
		{"Y" ,0x0C00,0},		/* 2 */
		{"C" ,0x0F00,11},		/* 3(�J�E��?��?) */
		{"CR",0x3700,0},		/* 4(�J�E��?���Z�b�g) */
		{"T" ,0x1000,10},		/* 5 */
		{"TR",0x3800,0},		/* 5 */
		{"X" ,0x1200,0},		/* 6 */
		{"S" ,0x1400,0},		/* 7 */
		{"GB",0x0000,1},		/* 8 */
	},
	{						/* FX1S */
		{"M" ,0x0800,7},		/* 0 */
		{"M2",0x0F00,0},		/* 1 */
		{"Y" ,0x0500,0},		/* 2 */
		{"C" ,0x0E00,11},		/* 3 */
		{"CR",0x2E00,0},		/* 4 */
		{"T" ,0x0600,10},		/* 5 */
		{"TR",0x2600,0},		/* 6 */
		{"X" ,0x0400,0},		/* 7 */
		{"S" ,0x0000,0},		/* 8 */
		{"GB",0x0000,1},		/* 9 */
	}
};
DEV_TBL	wDeviceTbl[4][16] = {
	{						/* FX1N */
		{"Y" ,0x0180,9},		/* 0 */
		{"M" ,0x0000,8},		/* 0 */
		{"X" ,0x0240,9},		/* 0 */
		{"C" ,0x0A00,3},		/* 0 */
		{"C2",0x0C00,0},		/* 1 */
		{"CS",0x4190,2},		/* 2 */
		{"D" ,0x4000,4},		/* 6 */
		{"D2",0x0E00,0},		/* 3 */
		{"T" ,0x1000,10},		/* 4 */
		{"TS",0x41B8,2},		/* 5 */
		{"Z" ,0x0F68,5},		/* 7 */
		{"V" ,0x0F68,6},		/* 8 */
		{"GD",0x0000,1},		/* 9 */
	},
	{						/* FX1S */
		{"Y" ,0x00A0,9},		/* 0 */
		{"M" ,0x0100,8},		/* 0 */
		{"X" ,0x0080,9},		/* 0 */
		{"C" ,0x0A00,3},		/* 0 */
		{"C2",0x0C00,0},		/* 1 */
		{"CS",0x10C8,2},		/* 2 */
		{"D" ,0x1000,4},		/* 3 */
		{"D2",0x1100,0},		/* 4 */
		{"T" ,0x0800,10},		/* 5 */
		{"TS",0x10C8,2},		/* 6 */
		{"Z" ,0x0E38,5},		/* 7 */
		{"V" ,0x0E38,6},		/* 8 */
		{"GD",0x0000,1},		/* 9 */
	}

};
/****************************/
/* PLC ENQ Check(FX1N)		*/
/****************************/
int	PlcEnqCheck(void)
{
	int		ret;

	PlcCommCnt= 1;
	PlcSendBuff[0]= ENQ;
	ret= SendPC2PLCData(1);		/* ENQ ���M */
	return(ret);
}
/****************************/
/* Make Check SUM For PLC	*/
/****************************/
int SetPlcDataBCC(char *buff,int cnt,unsigned char *OutBuf)
{
	int		i;
	unsigned char bcc;

	OutBuf[0] = STX;
	for(i = 0; i < cnt; i++){
		OutBuf[i+1] = buff[i];
	}
	OutBuf[i+1] = ETX;
	bcc = 0;
	for(i = 0; i < cnt+ 1; i++){
		bcc += OutBuf[i+1];
	}
	sprintf((char *)&OutBuf[cnt+2],"%02X",bcc&0x00ff);
	return(cnt + 4);
}
/************************************/
/*	PLC Send						*/
/************************************/
int	SendRecPLCBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode)
{
	int		ret;

	PlcCommCnt= SetPlcDataBCC((char *)combuf,strlen(combuf),PlcSendBuff);
	ret= SendRecPLC(mode,rData,Cnt,rmode);
	return(ret);
}
/************************************/
/*	PLC �O��?�v�f??�̍쐬		*/
/************************************/
void	CheckTSCS_FX1N(DEV_DATA *DevData)
{
	int		idx;
	int		OrBit;
	int		ret;
	int		Cnt;
	char	DeviceName[4];
	char	dBuff[16];

	/* Start Address Read */
	GetDevNamePLCAddr(DevData->DevFlag,(unsigned char *)DevData->DevName,DeviceName,&idx,&DevData->DevAddress);
	if(((CommonArea.TS_StartAddr == 0) && (DeviceName[0] == 'T')) ||
		((CommonArea.CS_StartAddr == 0) && (DeviceName[0] == 'C'))){
		strcpy(dBuff,"E41805C");
		if(DeviceName[0] == 'T'){
			sprintf(&dBuff[7],"%02X06",0);
		}else{
			sprintf(&dBuff[7],"%02X0E",0);
		}
		ret= SendRecPLCBCC(2,dBuff,PLCcombuf,&Cnt,0);
		if(ret == 0){
			if(DeviceName[0] == 'T'){
				CommonArea.TS_StartAddr= Hex2nBin((char *)&PLCcombuf[1],Cnt- 4);
				if(CommonArea.TS_StartAddr != (unsigned int)0xfffff){
					CommonArea.TS_StartAddr += 2;
				}
			}else{
				CommonArea.CS_StartAddr= Hex2nBin((char *)&PLCcombuf[1],Cnt- 4);
				if(CommonArea.CS_StartAddr != (unsigned int)0xfffff){
					CommonArea.CS_StartAddr += 2;
				}
			}
		}
	}
	strcpy(dBuff,"E41805C");
	if(DeviceName[0] == 'T'){
		sprintf(&dBuff[7],"%02X06",DevData->DevAddress);
	}else{
		sprintf(&dBuff[7],"%02X0E",DevData->DevAddress);
	}
	idx= DevData->DevAddress / 8;
	OrBit= 0x01 << (DevData->DevAddress % 8);
	ret= SendRecPLCBCC(2,dBuff,PLCcombuf,&Cnt,0);
	if(DeviceName[0] == 'T'){
		if(ret == OK){
			if(strncmp((char *)&PLCcombuf[1],"FFFFF",5) == 0){
				CommonArea.TS_Inf[idx] &= ~OrBit;
			}else{
				CommonArea.TS_Inf[idx] |= OrBit;
			}
		}else{
			CommonArea.TS_Inf[idx] &= ~OrBit;
		}
	}else{
		if(ret == OK){
			if(strncmp((char *)&PLCcombuf[1],"FFFFF",5) == 0){
				CommonArea.CS_Inf[idx] &= ~OrBit;
			}else{
				CommonArea.CS_Inf[idx] |= OrBit;
			}
		}else{
			CommonArea.CS_Inf[idx] &= ~OrBit;
		}
	}
}
void	CheckTSCS_FX1S(DEV_DATA *DevData)
{
	int		idx;
	int		OrBit;
	int		ret;
	int		Cnt;
	char	DeviceName[4];
	char	dBuff[16];

	/* Start Address Read */
	GetDevNamePLCAddr(DevData->DevFlag,(unsigned char *)DevData->DevName,DeviceName,&idx,&DevData->DevAddress);
	if(((CommonArea.TS_StartAddr == 0) && (DeviceName[0] == 'T')) ||
		((CommonArea.CS_StartAddr == 0) && (DeviceName[0] == 'C'))){
		strcpy(dBuff,"4805C");
		if(DeviceName[0] == 'T'){
			sprintf(&dBuff[5],"%02X06",0);
		}else{
			sprintf(&dBuff[5],"%02X0E",0);
		}
		ret= SendRecPLCBCC(2,dBuff,PLCcombuf,&Cnt,0);
		if(ret == 0){
			if(DeviceName[0] == 'T'){
				CommonArea.TS_StartAddr= Hex2nBin((char *)&PLCcombuf[1],Cnt- 4)+ 2;
				if(CommonArea.TS_StartAddr != (unsigned int)0xfffff){
					CommonArea.TS_StartAddr += 2;
				}
			}else{
				CommonArea.CS_StartAddr= Hex2nBin((char *)&PLCcombuf[1],Cnt- 4)+ 2;
				if(CommonArea.CS_StartAddr != (unsigned int)0xfffff){
					CommonArea.CS_StartAddr += 2;
				}
			}
		}
	}
	strcpy(dBuff,"4805C");
	if(DeviceName[0] == 'T'){
		sprintf(&dBuff[5],"%02X06",DevData->DevAddress);
	}else{
		sprintf(&dBuff[5],"%02X0E",DevData->DevAddress);
	}
	idx= DevData->DevAddress / 8;
	OrBit= 0x01 << (DevData->DevAddress % 8);
	ret= SendRecPLCBCC(2,dBuff,PLCcombuf,&Cnt,0);
	if(DeviceName[0] == 'T'){
		if(ret == OK){
			if(strncmp((char *)&PLCcombuf[1],"FFFF",5) == 0){
				CommonArea.TS_Inf[idx] &= ~OrBit;
			}else{
				CommonArea.TS_Inf[idx] |= OrBit;
			}
		}else{
			CommonArea.TS_Inf[idx] &= ~OrBit;
		}
	}else{
		if(ret == OK){
			if(strncmp((char *)&PLCcombuf[1],"FFFF",5) == 0){
				CommonArea.CS_Inf[idx] &= ~OrBit;
			}else{
				CommonArea.CS_Inf[idx] |= OrBit;
			}
		}else{
			CommonArea.CS_Inf[idx] &= ~OrBit;
		}
	}
}
/*********************************/
/*	PLC GROP(FX1N)		         */
/*********************************/
int	MakeDeviceAddr(int BitWord, char *pDevice, int Address, char *buff)
{
	int		i;
	int		ret;
	int		sAddress;
	char	Device[4];
	 char	buff1[32];

	ret= -1;
	sAddress= Address;
	/* Device Name */
	if(GetDevNamePLCAddr(BitWord,(unsigned char *)pDevice,Device,&i,&Address) == -1){
		return(ret);
	}
	if(BitWord == 0){		/* Bit */
		for(i = 0; ; i++){
			if(bDeviceTbl[PlcType][i].Device == (char *)NULL){
				DeviceFlag= -1;
				break;
			}else{
				if(strcmp(bDeviceTbl[PlcType][i].Device,Device) == 0){
					DeviceFlag= bDeviceTbl[PlcType][i].flag;
					if(DeviceFlag == 1){
						ret = 1;		/* GB */
					}else{
						if((DeviceFlag == 7) && (Address >= 8000)){
							i++;
							Address -= 8000;
						}
						Address += bDeviceTbl[PlcType][i].StartAddr;
						sprintf(&buff[0],"%02X",Address & 0x00ff);
						sprintf(&buff[2],"%02X",(Address & 0xff00) >> 8);
						ret = 0;
					}
					break;
				}
			}
		}
	}else{			/* Word */
		for(i = 0; ; i++){
			if(wDeviceTbl[PlcType][i].Device == (char *)NULL){
				DeviceFlag= -1;
				break;
			}else{
				if(strcmp(wDeviceTbl[PlcType][i].Device,Device) == 0){
					DeviceFlag= wDeviceTbl[PlcType][i].flag;
					if(DeviceFlag == 1){
						ret = 1;		/* GD */
					}else{
						if(DeviceFlag == 2){
							if(PlcType == 0){
								sprintf(buff,"E0");
							}else{
								sprintf(buff,"0");
							}
							if(Device[0] == 'T'){
								sprintf(buff1,"%05X",CommonArea.TS_StartAddr+ Address*6);
							}else{
								sprintf(buff1,"%05X",CommonArea.CS_StartAddr+ Address*6);
							}
							strcat(buff,buff1);
						}else{
							if((wDeviceTbl[PlcType][i].flag == 3) && (Address >= 200)){	/*C200->*/
								i++;
								Address -= 200;
							}
							if((wDeviceTbl[PlcType][i].flag == 4) && (Address >= 8000)){	/*D8000->*/
								i++;
								Address -= 8000;
							}
							if((wDeviceTbl[PlcType][i].flag == 5) || (wDeviceTbl[PlcType][i].flag == 6)){		/* Z,V */
								if(Address == 0){
									Address= 0x0E38;
								}else{
									Address = Address* 4 + wDeviceTbl[PlcType][i].StartAddr;
								}
								if(wDeviceTbl[PlcType][i].flag == 6){
									Address += 2;
								}
							}else{
								if(DeviceFlag == 9){	/* Bit DEVICE(8) */
									sAddress= sAddress << 4;
									GetDevNamePLCAddr(BitWord,(unsigned char *)pDevice,Device,&i,&sAddress);
									Address= sAddress / 8;
									Address = Address + wDeviceTbl[PlcType][i].StartAddr;
								}else if(DeviceFlag == 8){	/* Bit Device (8) */
									Address = Address + wDeviceTbl[PlcType][i].StartAddr;
								}else{
									Address = Address* 2 + wDeviceTbl[PlcType][i].StartAddr;
								}
							}
							Address = (Address/ 256)+ ((Address% 256) << 8);
							sprintf(buff,"%04X",Address & 0xffff);
						}
						ret = 0;
					}
					break;
				}
			}
		}
	}
	return(ret);
}
/***********************************/
const char	*FX1NHed  = "E1014000000810000";
const char	*FX1NHed1 = "E10144000";
int	MakeGroupDevFX1N( void )
{
	int		i,j;
	int		idx;
	int		AllCnt;
	char	work[4+ 1];
	int		ret= 0;
	int		Cnt;

	/* Ts,Cs Start Addr Clear */
	CommonArea.TS_StartAddr= 0;
	CommonArea.CS_StartAddr= 0;
	memset(CommonArea.TS_Inf,0,sizeof(CommonArea.TS_Inf));
	memset(CommonArea.CS_Inf,0,sizeof(CommonArea.CS_Inf));
	/* Same Device Check */
	memset(GrpPLCcombuf, 0, sizeof(GrpPLCcombuf));
	DeviceDataSys[0].SameDevInf= 0;
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		for(j = 0; j < i; j++){
			if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
				(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
/*				(DeviceDataSys[j].DevName[1] == DeviceDataSys[i].DevName[1]) &&*/
				(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
				(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) &&
				(DeviceDataSys[j].DevCnt == 1) ){
				break;
			}
		}
		if(j != i){		/* Same Device */
			DeviceDataSys[i].SameDevInf= j+ 1;
		}
	}
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	strcpy((char *)GrpPLCcombuf,(char *)FX1NHed);
	if(PcThru1014 != 0){		/* Thru Device ON *//*?????????????*/
		if(PcThruWCnt > 0){
			memcpy((char *)&GrpPLCcombuf[17],PcThruWData,PcThruWCnt*4);
			memcpy((char *)&PlcSendDevData[0],PcThruWData,PcThruWCnt*4);
		}
		idx= PcThruWCnt*4;
	}else{
		idx= 0;
	}
	/*Word Device Set*/
	gDeviceCnt= 0;
	for(i = 0; i < DeviceCntSys; i++){
		/* CS,TS Check */
		if((DeviceDataSys[i].DevFlag == 1) && (DeviceDataSys[i].SameDevInf == 0)){
#ifdef	OLD
			(((DeviceDataSys[i].DevName[0] == 'T') || 
			  (DeviceDataSys[i].DevName[0] == 'C')) &&
				(DeviceDataSys[i].DevName[1] == 'S')) 
				){
#else
			if(MakeDeviceAddr(DeviceDataSys[i].DevFlag, DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work) != 0){
				continue;
			}
			if(DeviceFlag == 2){		/* 'TS','CS' */
#endif
				CheckTSCS_FX1N(&DeviceDataSys[i]);
			}else{
				if((DeviceDataSys[i].DevCnt == 1) &&
					(DeviceDataSys[i].DevFlag == 1) &&
					(DeviceDataSys[i].SameDevInf == 0) ){
					if(DeviceFlag != 9){		/* NOT Bit DEVICE */
						strcpy((char *)&GrpPLCcombuf[17 + idx+ gDeviceCnt*4],work);
						strcpy((char *)&PlcSendDevData[0 + idx+ gDeviceCnt*4],work);
						gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
						gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
						DeviceDataSys[i].SameDevInf= -1;
						gDeviceCnt++;
						gDeviceCntWord++;
						if((idx+ gDeviceCnt*4) >= 256){
							break;						/* MAX */
						}
					}
				}
			}
		}
	}
	if(PcThru1014 != 0){		/* Thru Device ON *//*?????????????*/
		if(PcThruBCnt > 0){
			memcpy((char *)&GrpPLCcombuf[17 + idx+ gDeviceCnt*4],PcThruBData,PcThruBCnt*4);
			memcpy((char *)&PlcSendDevData[0 + idx+ gDeviceCnt*4],PcThruBData,PcThruBCnt*4);
		}
		idx= (PcThruWCnt+ PcThruBCnt)*4;
	}else{
		idx= 0;
	}
	for(i = 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].DevCnt == 1) &&
			(DeviceDataSys[i].DevFlag == 0) &&
			(DeviceDataSys[i].SameDevInf == 0) ){
			if(MakeDeviceAddr(DeviceDataSys[i].DevFlag, DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work) == 0){
				strcpy((char *)&GrpPLCcombuf[17 + idx+ gDeviceCnt*4],work);
				strcpy((char *)&PlcSendDevData[0 + idx+ gDeviceCnt*4],work);
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
				gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
				DeviceDataSys[i].SameDevInf= -1;
				gDeviceCnt++;
				gDeviceCntBit++;
				if((idx+ gDeviceCnt*4) >= 256){
					break;						/* MAX */
				}
			}
		}
	}
	if((gDeviceCnt != 0) || (PcThru1014 != 0)){
		if(PcThru1014 != 0){
			idx= PcThruWCnt+ PcThruBCnt+ gDeviceCnt;
		}else{
			idx= gDeviceCnt;
		}
		AllCnt= idx;
		if(AllCnt > 30){
			idx= 30;
		}
		/* Data Count */
		sprintf(work,"%02X",idx* 2+ 4);
		strncpy((char *)&GrpPLCcombuf[7], work, 2);
		/* Word Count */
		if(PcThru1014 != 0){
			idx= PcThruWCnt+ gDeviceCntWord;
		}else{
			idx= gDeviceCntWord;
		}
		sprintf(work,"%02X",idx);
		strncpy((char *)&GrpPLCcombuf[9], work, 2);
		/* Bit Count */
		if(PcThru1014 != 0){
			idx= PcThruBCnt+ gDeviceCntBit;
		}else{
			idx= gDeviceCntBit;
		}
		sprintf(work,"%02X",idx);
		strncpy((char *)&GrpPLCcombuf[13], work, 2);
		if(AllCnt > 30){
			GrpPLCcombuf[17+60*2]= 0;
			SendRecPLCBCC(1,(char *)&GrpPLCcombuf[0],(unsigned char *)work,&Cnt,1);
			memset(GrpPLCcombuf, 0, sizeof(GrpPLCcombuf));
			strcpy((char *)GrpPLCcombuf,(char *)FX1NHed1);
			idx= AllCnt- 30;
			/* Data Count */
			sprintf(work,"%02X",idx* 2);
			strncpy((char *)&GrpPLCcombuf[7], work, 2);
			memcpy(&GrpPLCcombuf[9], &PlcSendDevData[60*2], idx* 4); 
			ret= SendRecPLCBCC(1,(char *)&GrpPLCcombuf[0],(unsigned char *)work,&Cnt,1);
		}else{
			ret= SendRecPLCBCC(1,(char *)&GrpPLCcombuf[0],(unsigned char *)work,&Cnt,1);
		}
		if(PcThru1014 != 0){
			PcThru1014Rec = 1;
		}
	}
	return(ret);
}
const char	*FX1SHedW = "11800000001";
const char	*FX1SHedB = "11826000000";
extern	void	SetWindowNo(int WinNo);
int	MakeGroupDevFX1S( void )
{
	int		i,j;
	int		idx;
	char	work[4+ 1];
	int		Cnt;
	int		ret= 0;

	/* Same Device Check */
	memset(GrpPLCcombuf, 0, sizeof(GrpPLCcombuf));
	DeviceDataSys[0].SameDevInf= 0;
	for(i = 1; i < DeviceCntSys; i++){
		DeviceDataSys[i].SameDevInf= 0;
		for(j = 0; j < i; j++){
			if( (DeviceDataSys[j].DevFlag == DeviceDataSys[i].DevFlag) &&
				(DeviceDataSys[j].DevName[0] == DeviceDataSys[i].DevName[0]) &&
				(DeviceDataSys[j].DevName[1] == DeviceDataSys[i].DevName[1]) &&
				(DeviceDataSys[j].DevCnt == DeviceDataSys[i].DevCnt) &&
				(DeviceDataSys[j].DevAddress == DeviceDataSys[i].DevAddress) &&
				(DeviceDataSys[j].DevCnt == 1) ){
				break;
			}
		}
		if(j != i){		/* Same Device */
			DeviceDataSys[i].SameDevInf= j+ 1;
		}
	}
	/* Word Device Set */
	gDeviceCntWord= 0;
	gDeviceCntBit= 0;
	strcpy((char *)GrpPLCcombuf,(char *)FX1SHedW);
	if(PcThru1014 != 0){		/* Thru Device ON *//*?????????????*/
		if(PcThruWCnt > 0){
			memcpy((char *)&GrpPLCcombuf[11],PcThruWData,PcThruWCnt*4);
		}
		idx= PcThruWCnt*4;
	}else{
		idx= 0;
	}
	gDeviceCnt= 0;
	for(i = 0; i < DeviceCntSys; i++){
		/* CS,TS Check */
		if((DeviceDataSys[i].DevFlag == 1) && (DeviceDataSys[i].SameDevInf == 0)){
#ifdef	OLD
			if(((DeviceDataSys[i].DevName[0] == 'T') || 
				(DeviceDataSys[i].DevName[0] == 'C')) &&
				(DeviceDataSys[i].DevName[0] == 'S')){
#else
			if(MakeDeviceAddr(DeviceDataSys[i].DevFlag, DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work) != 0){
				continue;
			}
			if(DeviceFlag == 2){		/* 'TS','CS' */
#endif
				CheckTSCS_FX1S(&DeviceDataSys[i]);
			}else{
				if((DeviceDataSys[i].DevCnt == 1) &&
					(DeviceDataSys[i].DevFlag == 1) &&
					(DeviceDataSys[i].SameDevInf == 0) ){
					if((DeviceFlag != 9) && (DeviceFlag != 8)){		/* NOT Bit DEVICE(NOT X,Y,M) */
						strcpy((char *)&GrpPLCcombuf[11 + idx+ gDeviceCnt*4],work);
						gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
						gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
						DeviceDataSys[i].SameDevInf= -1;
						gDeviceCnt++;
						gDeviceCntWord++;
						if((idx + gDeviceCntWord) >= 19){
							break;
						}
					}
				}
			}
		}
	}
	if((gDeviceCntWord != 0) || (PcThruWCnt != 0)){
		sprintf(work,"%02X",(PcThruWCnt+gDeviceCntWord)* 2+ 2);
		strncpy((char *)&GrpPLCcombuf[5], work, 2);
		sprintf(work,"%02X",(PcThruWCnt+gDeviceCntWord));
		strncpy((char *)&GrpPLCcombuf[7], work, 2);
		ret= SendRecPLCBCC(1,(char *)&GrpPLCcombuf[0],(unsigned char *)work,&Cnt,1);
	}
	/************************/
	/* Byte Device Set		*/
	/************************/
	strcpy((char *)GrpPLCcombuf,(char *)FX1SHedB);
	if(PcThru1014 != 0){		/* Thru Device ON *//*?????????????*/
		if(PcThruBCnt > 0){
			memcpy((char *)&GrpPLCcombuf[11],PcThruBData,PcThruBCnt*4);
		}
		idx= PcThruBCnt*4;
	}else{
		idx= 0;
	}
	for(i = 0; i < DeviceCntSys; i++){
		if((DeviceDataSys[i].DevCnt == 1) &&
			(DeviceDataSys[i].DevFlag == 0) &&
			(DeviceDataSys[i].SameDevInf == 0) ){
			if(MakeDeviceAddr(DeviceDataSys[i].DevFlag, DeviceDataSys[i].DevName, DeviceDataSys[i].DevAddress, work) == 0){
				strcpy((char *)&GrpPLCcombuf[11 + idx+ gDeviceCntBit*4],work);
				gDeviceAddr[gDeviceCnt]= DeviceDataSys[i].DevData;
				gDeviceFlag[gDeviceCnt]= (char)DeviceDataSys[i].DevFlag;
				DeviceDataSys[i].SameDevInf= -1;
				gDeviceCnt++;
				gDeviceCntBit++;
				if((idx + gDeviceCntBit) >= 18){
					break;
				}
			}
		}
	}
	if((gDeviceCntBit != 0) || (PcThruBCnt != 0)){
		sprintf(work,"%02X",(PcThruBCnt+gDeviceCntBit)* 2+ 2);
		strncpy((char *)&GrpPLCcombuf[5], work, 2);
		sprintf(work,"%02X",(PcThruBCnt+gDeviceCntBit));
		strncpy((char *)&GrpPLCcombuf[7], work, 2);
		ret= SendRecPLCBCC(1,(char *)&GrpPLCcombuf[0],(unsigned char *)work,&Cnt,1);
	}
	if(PcThru1014 != 0){
		PcThru1014Rec = 1;
	}
	return(ret);
}
/************************************/
/*	FX Serase Connect Check			*/
/************************************/
unsigned long MakeCheckDigit(unsigned long rData)
{
	int		i;
	unsigned long sData;
	unsigned long sData1;

	sData = (rData & 0xff000000) >> 8;
	sData |= (rData & 0x00ff0000) << 8;
	sData |= (rData & 0x0000ff00) >> 8;
	sData |= (rData & 0x000000ff) << 8;

	sData1 = (rData & 0xff000000) >> 24;
	sData1 |= (rData & 0x00ff0000) >> 8;
	sData1 |= (rData & 0x0000ff00) << 8;
	sData1 |= (rData & 0x000000ff) << 24;

	for(i = 0; i < 2; i++){
		if((sData & 0x80000000) == 0){
			sData= sData << 1;
		}else{
			sData= sData << 1;
			sData |= 1;
		}
	}
	sData+= sData1;
	for(i = 0; i < 2; i++){
		if((sData & 0x80000000) == 0){
			sData= sData << 1;
		}else{
			sData= sData << 1;
			sData |= 1;
		}
	}
	sData= sData ^ sData1;
	sData1 = (sData & 0xff000000) >> 24;
	sData1 |= (sData & 0x00ff0000) >> 8;
	sData1 |= (sData & 0x0000ff00) << 8;
	sData1 |= (sData & 0x000000ff) << 24;
	return(sData1);
}
int	FxConnect( int iConnect )
{
	unsigned long data;
	int		ret;
	int		Cnt;

	/* ��������??��?�g */
	if((iConnect & 1) == 0){		/* RS-232C */
#ifdef	WIN32
		SioPCMode= 1;
		SioPCOpenFlag= 1;
#else
		RsModeSet(RS_PC,RS_INIT,RS_9600,RS_DATA7,RS_EVEN);
#endif
	}else{						/* RS-422 */
#ifdef	WIN32
		SioPLCMode= 0;
		SioPLCOpenFlag= 1;
#else
		RsModeSet(RS_PLC,RS_INIT,RS_9600,RS_DATA7,RS_EVEN);
#endif
	}
#ifdef	WIN32
	while(1){
		if(SioPLCOpenFlag == 0){
			break;
		}
		Delay(10);
	}
#endif
	Delay(500);

	/* PLC Connect Check */
	if(PlcEnqCheck() != OK){
		return(0);
	}
	ret= SendRecPLCBCC(2,"00E0202",GrpPLCcombuf,&Cnt,0);
	if(ret < 0){
		return(0);
	}
	memset(FX1N_00E0202,0,sizeof(FX1N_00E0202));
	memcpy(FX1N_00E0202,&GrpPLCcombuf[0],8);
	data = (unsigned char)(Hex2Bin((char *)&GrpPLCcombuf[3]) & 0x3f);
/*	if((data == 37) || (data == 30)){	*/	/* Fx-1N,FX-2NC */
	if(data == 22){	/* Fx-1S */
		ret= SendRecPLCBCC(2,"0804808",GrpPLCcombuf,&Cnt,0);
		ret= SendRecPLCBCC(2,"0800002",GrpPLCcombuf,&Cnt,0);
		ret= SendRecPLCBCC(2,"0800808",GrpPLCcombuf,&Cnt,0);
		ret= SendRecPLCBCC(1,"11800020001",GrpPLCcombuf,&Cnt,0);
		ret= SendRecPLCBCC(1,"11826020000",GrpPLCcombuf,&Cnt,0);
		PlcType= 1;
		ret= 1;
	}else{			/* Fx-1N,FX-2NC */
		ret= SendRecPLCBCC(2,"00EE804",GrpPLCcombuf,&Cnt,0);
		if(ret == 0){
			memset(FX1N_00EE804,0,sizeof(FX1N_00EE804));
			memcpy(FX1N_00EE804,&GrpPLCcombuf[0],12);
			data = (unsigned char)Hex2Bin((char *)&GrpPLCcombuf[1]) << 24;
			data += (unsigned char)Hex2Bin((char *)&GrpPLCcombuf[3]) << 16;
			data += (unsigned char)Hex2Bin((char *)&GrpPLCcombuf[5]) << 8;
			data += (unsigned char)Hex2Bin((char *)&GrpPLCcombuf[7]);
			data= MakeCheckDigit(data);
			strcpy((char *)PLCcombuf,(char *)ConnectHed);
			sprintf((char *)&PLCcombuf[7],"%08X",data);
			ret= SendRecPLCBCC(1,(char *)PLCcombuf,GrpPLCcombuf,&Cnt,0);
		}else{
			return(0);
		}
#ifndef	XP
		ret= SendRecPLCBCC(1,"A1",GrpPLCcombuf,&Cnt,0);
#endif
		PlcType= 0;
		ret= 2;
	}
	if(ret == 2){		/* FX1N */
		/* ����ڑ�����??��?�g */
		Delay(100);
		if((iConnect & 1) == 0){	/* RS-232C */
#ifdef	WIN32
#ifndef	XP
		SioPCMode= 1;
		SioPCOpenFlag= 1;
#endif
#else
			RsModeSet(RS_PC,RS_INIT,RS_19200,RS_DATA7,RS_EVEN);
#endif
		}else{
#ifdef	WIN32
#ifndef	XP
		SioPLCMode= 1;
		SioPLCOpenFlag= 1;
#endif
#else
			RsModeSet(RS_PLC,RS_INIT,RS_19200,RS_DATA7,RS_EVEN);
#endif
		}
#ifdef	WIN32
	while(1){
		if(SioPLCOpenFlag == 0){
			break;
		}
		Delay(10);
	}
#endif
		Delay(500);
	}
	if(ret > 0){
		ret= 1;
	}
	return(ret);
}
/*********************************/
/* PC Monitor Check(FX1N)		 */
/*********************************/
int	PcMonitorCheckFX1N(char *buff,char *oBuff,int *Cnt)
{
	int		ret;
	char	work[10];

	ret= 9;		/* THRUE COMMAND */
	if(PlcConnectFlag == 0){
		oBuff[0]= NAK;
		*Cnt= 1;
		return(-1);
	}
	if(buff[0] == ENQ){		/* ENQ Recieve */
		if(PlcConnectFlag == 1){
			oBuff[0]= ACK;
		}else{
			oBuff[0]= NAK;
		}
		*Cnt= 1;
		ret= 3;
	}else if(memcmp(&buff[1],"00E0202",7) == 0){		/* PLC Type Read */
		memcpy(oBuff,FX1N_00E0202,8);
		*Cnt= 8;
		ret= 5;
	}else if(memcmp(&buff[1],"00EE804",7) == 0){		/* PLC Type Read */
		memcpy(oBuff,FX1N_00EE804,12);
		*Cnt= 12;
		ret= 5;
	}else if(memcmp(&buff[1],ConnectHed,7) == 0){
		oBuff[0]= ACK;
		*Cnt= 1;
		ret= 3;
	}else if(memcmp(&buff[1],"A1",2) == 0){		/* PLC Type Read */
		oBuff[0]= ACK;
		*Cnt= 1;
		ret= 4;
	}else if(memcmp(&buff[1],"E1014",5) == 0){		/* Group Command */
		if(memcmp(&buff[6],"00",2) == 0){
			work[0]= buff[8];
			work[1]= buff[9];
			work[2]= 0;
			PcThruAllCnt= LHexAsToBin(work,2)- 4;
			memcpy(PcThruAllData,&buff[18],PcThruAllCnt*2);
			work[0]= buff[10];
			work[1]= buff[11];
			work[2]= 0;
			PcThruWCnt= LHexAsToBin(work,2);
			work[0]= buff[14];
			work[1]= buff[15];
			work[2]= 0;
			PcThruBCnt= LHexAsToBin(work,2);
			if(PcThruAllCnt >= ((PcThruWCnt+ PcThruBCnt)* 2)){
				memcpy(PcThruWData,&buff[18],PcThruWCnt*4);
				memcpy(PcThruBData,&buff[18+PcThruWCnt*4],PcThruBCnt*4);
				ret= 1;
				PcThru1014= 1;
				PcThru1014Rec= 0;
			}else{
				oBuff[0]= ACK;
				*Cnt= 1;
				ret= 0;
			}
		}else{
			work[0]= buff[8];
			work[1]= buff[9];
			work[2]= 0;
			ret= LHexAsToBin(work,2);
			memcpy(&PcThruAllData[PcThruAllCnt*2],&buff[10],ret*2);
			memcpy(PcThruWData,&PcThruAllData[0],PcThruWCnt*4);
			memcpy(PcThruBData,&PcThruAllData[0+PcThruWCnt*4],PcThruBCnt*4);
			ret= 1;
			PcThru1014= 1;
			PcThru1014Rec= 0;
		}
	}else if(memcmp(&buff[1],"E0017",5) == 0){		/* Group Command */
		work[0]= buff[6];
		work[1]= buff[7];
		PcThruByteCntStr= LHexAsToBin(work,2);
		work[0]= buff[8];
		work[1]= buff[9];
		PcThruByteCnt179= LHexAsToBin(work,2);
		ret= 2;
	}
	return(ret);
}
/*********************************/
/* PC Monitor Check(FX1S)		 */
/*********************************/
int	PcMonitorCheckFX1S(char *buff,char *oBuff,int *Cnt)
{
	int		ret;
	char	work[10];

	ret= 9;		/* THRUE COMMAND */
	if(PlcConnectFlag == 0){
		oBuff[0]= NAK;
		*Cnt= 1;
		return(-1);
	}
	if(buff[0] == ENQ){		/* ENQ Recieve */
		if(PlcConnectFlag == 1){
			oBuff[0]= ACK;
		}else{
			oBuff[0]= NAK;
		}
		*Cnt= 1;
		ret= 3;
	}else if(memcmp(&buff[1],"00E0202",7) == 0){		/* PLC Type Read */
		memcpy(oBuff,FX1N_00E0202,8);
		*Cnt= 8;
		ret= 5;
	}else if(memcmp(&buff[1],"11800",5) == 0){		/* Word Group Command */
		if(memcmp(&buff[8],"00",2) == 0){
			ret= 0;
		}else{
			work[0]= buff[8];
			work[1]= buff[9];
			work[2]= 0;
			PcThruWCnt= LHexAsToBin(work,2);
			memcpy(PcThruWData,&buff[12],PcThruWCnt*4);

			PcThruBCnt= 1;
			memcpy((char *)PcThruBData,(char *)&buff[12+0x26*2],PcThruBCnt*4);
			ret= 1;
			PcThru1014= 1;
			PcThru1014Rec= 0;
		}
	}else if(memcmp(&buff[1],"01958",5) == 0){		/* word Read Group Command */
		work[0]= buff[6];
		work[1]= buff[7];
		PcThruByteCnt1SW= LHexAsToBin(work,2);
		ret= 6;
	}else if(memcmp(&buff[1],"019A0",5) == 0){		/* bit Read Group Command */
		work[0]= buff[6];
		work[1]= buff[7];
		PcThruByteCnt1SB= LHexAsToBin(work,2);
		ret= 7;
	}
	return(ret);
}
int	PcMonitorCheck(char *buff,char *oBuff,int *Cnt)
{
	int		ret;
	int		signal;

	ret = 3;
#ifndef	WIN32
	signal = ReadSignal(SGN_PLC);	/* */
#else
	signal= 1;
#endif
	if((signal & 1) == 0){
		return(3);				/* Allway Thrue */
	}
	switch(PlcType){
	case 0:				/* FX1N */
		ret= PcMonitorCheckFX1N(buff,oBuff,Cnt);
		break;
	case 1:				/* FX1S */
		ret= PcMonitorCheckFX1S(buff,oBuff,Cnt);
		break;
	}
	return(ret);
}
/****************************/
/* Make Check SUM For PC	*/
/****************************/
int MakePcFXData(char *buff,int cnt)
{
	int		i;
	unsigned char bcc;

	SendBuff[0] = STX;
	for(i = 0; i < cnt; i++){
		SendBuff[i+1] = buff[i];
	}
	SendBuff[i+1] = ETX;
	bcc = 0;
	for(i = 0; i < cnt+ 1; i++){
		bcc += SendBuff[i+1];
	}
	sprintf((char *)&SendBuff[cnt+2],"%02X",bcc&0x00ff);
	return(cnt + 4);
}
/****************************/
/* Make Read Device			*/
/****************************/
int	MakeReadData(int mode, char *pDevice, int Address, char *combuff, int sCnt)
{
	int		i,j;
	int		ret;
	int		idx;
	int		OrBit;
	int		sAddress;
	char	Device[4];
	char	buff[32];
	char	buff1[32];

	ret = -2;
	sAddress= Address;
	/* Device Name */
	if(GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&i,&Address) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		for(i = 0; ; i++){
			if(bDeviceTbl[PlcType][i].Device == (char *)NULL){
				DeviceFlag= -1;
				break;
			}else{
				if(strcmp(bDeviceTbl[PlcType][i].Device,Device) == 0){
					DeviceFlag= bDeviceTbl[PlcType][i].flag;
					if(DeviceFlag == 1){
						ret = 1;		/* GB */
					}else{
						if((DeviceFlag == 7) && (Address >= 8000)){
							i++;
							Address -= 8000;
						}
						ret = Address % 8;
						BitAndData = 1;
						for(j = 0; j < ret; j++){
							BitAndData <<= 1;
						}
						ret += sCnt;
						ret = ret / 8 + 1;
						BitRecCnt = ret;
						Address = (Address + (bDeviceTbl[PlcType][i].StartAddr)) / 8;
						if(PlcType == 0){
							sprintf(buff,"E00");
						}else{
							sprintf(buff,"0");
						}
						sprintf(buff1,"%04X",Address & 0xffff);
						strcat(buff,buff1);
						sprintf(buff1,"%02X",ret);
						strcat(buff,buff1);
						strcpy(combuff,buff);
						ret = 0;
					}
					break;
				}
			}
		}
	}else{
		for(i = 0; ; i++){
			if(wDeviceTbl[PlcType][i].Device == (char *)NULL){
				DeviceFlag= -1;
				break;
			}else{
				if(strcmp(wDeviceTbl[PlcType][i].Device,Device) == 0){
					DeviceFlag= wDeviceTbl[PlcType][i].flag;
					if(DeviceFlag == 1){
						ret = 1;		/* GD */
					}else{
						if(DeviceFlag == 2){
							ret= 0;
							idx= Address / 8;
							OrBit= 0x01 << (Address % 8);
							if(PlcType == 0){
								sprintf(buff,"E0");
								if((Device[0] == 'T') && ((CommonArea.TS_Inf[idx] & OrBit) != 0)){
									Address = Address * 2 + wDeviceTbl[PlcType][i].StartAddr;
									sprintf(buff1,"%05X",Address);
								}else if((Device[0] == 'C') && ((CommonArea.CS_Inf[idx] & OrBit) != 0)){
									if(Address == 0){
										sprintf(buff1,"%05X",CommonArea.CS_StartAddr+ Address*6);
									}else{
										Address = Address * 2 + wDeviceTbl[PlcType][i].StartAddr;
										sprintf(buff1,"%05X",Address);
									}
								}else{
									ret= -2;
								}
							}else{
								sprintf(buff,"0");
								if((Device[0] == 'T') && ((CommonArea.TS_Inf[idx] & OrBit) != 0)){
									Address = Address * 2 + wDeviceTbl[PlcType][i].StartAddr;
									sprintf(buff1,"%04X",Address);
								}else if((Device[0] == 'C') && ((CommonArea.CS_Inf[idx] & OrBit) != 0)){
									Address = Address * 2 + wDeviceTbl[PlcType][i].StartAddr;
									sprintf(buff1,"%04X",Address);
								}else{
									ret= -2;
								}
							}
							if(ret == 0){
								strcat(buff,buff1);
								sprintf(buff1,"%02X",sCnt*4);
								strcat(buff,buff1);
								strcpy(combuff,buff);
							}
						}else{
							if((DeviceFlag == 3) && (Address >= 200)){	/*C200->*/
								i++;
								Address -= 200;
							}
							if((DeviceFlag == 4) && (Address >= 8000)){	/*D800->*/
								i++;
								Address -= 8000;
							}
							if(DeviceFlag == 9){	/* Bit DEVICE */
								sAddress= sAddress << 4;
								GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&idx,&sAddress);
								Address= sAddress / 8;
								Address = Address + wDeviceTbl[PlcType][i].StartAddr;
							}else if(DeviceFlag == 8){
								Address = (Address / 16)* 2 + wDeviceTbl[PlcType][i].StartAddr;
							}else if((DeviceFlag == 5) || (DeviceFlag == 6)){		/* Z,V */
								if(Address == 0){
									Address= 0x0E38;
								}else{
									Address = Address* 4 + wDeviceTbl[PlcType][i].StartAddr;
								}
								if(DeviceFlag == 6){
									Address += 2;
								}
							}else{
								Address = Address * 2 + wDeviceTbl[PlcType][i].StartAddr;
							}
							if(PlcType == 0){
								sprintf(buff,"E00");
							}else{
								sprintf(buff,"0");
							}
							sprintf(buff1,"%04X",Address & 0xffff);
							strcat(buff,buff1);
							if(DeviceFlag == 9){	/* Bit DEVICE */
								sprintf(buff1,"%02X",sCnt);
							}else{
								sprintf(buff1,"%02X",sCnt*2);
							}
							strcat(buff,buff1);
							strcpy(combuff,buff);
							ret = 0;
						}
					}
					break;
				}
			}
		}
	}
	return(ret);
}
/************************************************/
/*	FX Sisiase									*/
/************************************************/
int	FxCommRead(T_MAIL *mp,unsigned char *rDataFx)
{
	int		ret;
	int		i,j;
	int		Cnt;
	int		rCnt;
	unsigned char	*SaveAddr;
#ifdef	OLD
	int		InAddr;
#endif
	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = MakeReadData(0,(char *)mp->mbuf,mp->mpar,(char *)PLCcombuf,mp->mext);
		Cnt = mp->mext;
		rCnt = BitRecCnt;
		break;
	case PLC_WORD:		/* Word Device */
		ret = MakeReadData(1,(char *)mp->mbuf,mp->mpar,(char *)PLCcombuf,mp->mext);
		if(DeviceFlag == 2){		/* TS,CS */
			Cnt = mp->mext* 4;
			rCnt = mp->mext* 4;
		}else if(DeviceFlag == 9){	/* Bit Dev (X,Y) */
			Cnt = mp->mext;
			rCnt = mp->mext;
		}else{
			Cnt = mp->mext* 2;
			rCnt = mp->mext* 2;
		}
		break;
	}
	SaveAddr = (unsigned char *)mp->mptr;
	if(ret == 0){
		if(SendRecPLCBCC(2,(char *)PLCcombuf,(unsigned char *)rDataFx,&rCnt,1) == 0){
			if(mp->mpec == PLC_BIT){		/* Bit Device */
				for(i = 0,j = 0; i < Cnt; i++){
					if(rDataFx[j] & BitAndData){
						*(unsigned char *)SaveAddr++ = 1;
					}else{
						*(unsigned char *)SaveAddr++ = 0;
					}
					BitAndData <<= 1;
					if(BitAndData > 128){
						BitAndData = 1;
						j++;
					}
				}
			}else{
				if((PlcType == 0) && (mp->mbuf[0] == 0xf8) && (mp->mpar == 0)){		/* CS0 */
					for(i = 0,j = 0; i < Cnt; i++){
						if((i % 2) == 0){
							*(unsigned char *)SaveAddr++ = rDataFx[i];
						}
					}
				}else if(DeviceFlag == 9){		/* BitAddr(X,Y) */
					*(unsigned char *)SaveAddr++ = rDataFx[0];
					for(i = 1; i < Cnt; i++){
						*(unsigned char *)SaveAddr++ = 0;
					}
				}else{
					for(i = 0,j = 0; i < Cnt; i++){
						*(unsigned char *)SaveAddr++ = rDataFx[i];
					}
				}
			}
		}else{
			ret = -1;
		}
	}else if(ret == 1){		/* ����Device */
		ret= 0;
	}
	return(ret);
}
/****************************/
/* Make Write Device		*/
/****************************/
int	MakeWriteData(int mode, char *pDevice, int Address,int Cnt, char *combuff, char *data)
{
	int		i;
	int		ret;
	int		sAddress;
	char	Device[4];
	char	buff1[32];

	ret = -2;
	sAddress= Address;
	/* Device Name */
	if(GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&i,&Address) == -1){
		return(ret);
	}
	if(mode == 0){			/* Bit Device */
		for(i = 0; ; i++){
			if(bDeviceTbl[PlcType][i].Device == (char *)NULL){
				DeviceFlag= -1;
				break;
			}else{
				if(strcmp(bDeviceTbl[PlcType][i].Device,Device) == 0){
					DeviceFlag= bDeviceTbl[PlcType][i].flag;
					if(DeviceFlag == 1){
						ret = 1;		/* GB */
					}else{
						if((DeviceFlag == 7) && (Address >= 8000)){
							i++;
							Address -= 8000;
						}
						Address += bDeviceTbl[PlcType][i].StartAddr;
						if(Cnt == 1){
							if(PlcType == 0){
								sprintf(combuff,"E");
							}else{
								combuff[0]= 0;
							}
							if(*data == 1){	/* ON */
								strcat(combuff,"7");
							}else{
								strcat(combuff,"8");
							}
							sprintf(buff1,"%02X",Address & 0x00ff);
							strcat(combuff,buff1);
							sprintf(buff1,"%02X",(Address & 0xff00) >> 8);
							strcat(combuff,buff1);
						}else{
						}
						ret = 0;
					}
					break;
				}
			}
		}
	}else{
		for(i = 0; ; i++){
			if(wDeviceTbl[PlcType][i].Device == (char *)NULL){
				DeviceFlag= -1;
				break;
			}else{
				if(strcmp(wDeviceTbl[PlcType][i].Device,Device) == 0){
					DeviceFlag= wDeviceTbl[PlcType][i].flag;
					if(wDeviceTbl[PlcType][i].flag == 1){
						ret = 1;		/* GD */
					}else{
						if(DeviceFlag == 2){
							if(PlcType == 0){
								sprintf(combuff,"E1");
							}else{
								sprintf(combuff,"1");
							}
							ret= 0;
							if((Device[0] == 'T') && (CommonArea.TS_StartAddr != 0)){
								Address = Address* 2 + wDeviceTbl[PlcType][i].StartAddr;
								sprintf(buff1,"%05X",Address);
							}else if((Device[0] == 'C') && (CommonArea.CS_StartAddr != 0)){
								if(Address == 0){
									sprintf(buff1,"%05X",CommonArea.CS_StartAddr+ Address*6);
								}else{
									Address = Address* 2 + wDeviceTbl[PlcType][i].StartAddr;
									sprintf(buff1,"%05X",Address);
								}
							}
							if(ret == 0){
								strcat(combuff,buff1);
								if((PlcType == 0) && (Address == 0) && (Device[0] == 'C')){
									sprintf(buff1,"%02X",Cnt*4);
									strcat(combuff,buff1);
									for(i = 0; i < Cnt*4; i++){
										if((i % 2) == 0){
											sprintf(buff1,"%02X",*data++ & 0x00ff);
										}else{
											sprintf(buff1,"%02X",0x80 & 0x00ff);
										}
										strcat(combuff,buff1);
									}
								}else{
									sprintf(buff1,"%02X",Cnt*2);
									strcat(combuff,buff1);
									for(i = 0; i < Cnt*2; i++){
										sprintf(buff1,"%02X",*data++ & 0x00ff);
										strcat(combuff,buff1);
									}
								}
							}
						}else{
							if((DeviceFlag == 3) && (Address >= 200)){	/*C200->*/
								i++;
								Address -= 200;
							}
							if((DeviceFlag == 4) && (Address >= 8000)){	/*D800->*/
								i++;
								Address -= 8000;
							}
							if(DeviceFlag == 9){	/* BIT DEVICE */
								sAddress= sAddress << 4;
								GetDevNamePLCAddr(mode,(unsigned char *)pDevice,Device,&i,&sAddress);
								Address= sAddress / 8;
								Address = Address + wDeviceTbl[PlcType][i].StartAddr;
							}else if(DeviceFlag == 8){
								Address = (Address / 16)* 2 + wDeviceTbl[PlcType][i].StartAddr;
							}else if((DeviceFlag == 5) || (DeviceFlag == 6)){		/* Z,V */
								if(Address == 0){
									Address= 0x0E38;
								}else{
									Address = Address* 4 + wDeviceTbl[PlcType][i].StartAddr;
								}
								if(DeviceFlag == 6){
									Address += 2;
								}
							}else{
								Address = Address* 2 + wDeviceTbl[PlcType][i].StartAddr;
							}
							if(PlcType == 0){
								sprintf(combuff,"E10");
							}else{
								sprintf(combuff,"1");
							}
							sprintf(buff1,"%04X",Address & 0xffff);
							strcat(combuff,buff1);
							if(DeviceFlag == 9){	/* BIT DEVICE(X,Y) */
								sprintf(buff1,"%02X",Cnt);
								strcat(combuff,buff1);
								for(i = 0; i < Cnt; i++){
									sprintf(buff1,"%02X",*data++ & 0x00ff);
									strcat(combuff,buff1);
								}
							}else{
								sprintf(buff1,"%02X",Cnt*2);
								strcat(combuff,buff1);
								for(i = 0; i < Cnt*2; i++){
									sprintf(buff1,"%02X",*data++ & 0x00ff);
									strcat(combuff,buff1);
								}
							}
							ret = 0;
						}
					}
					break;
				}
			}
		}
	}
	return(ret);
}
int	FxCommWrite(T_MAIL *mp,unsigned char *rDataFx)
{
	int		ret;
	int		Cnt;
#ifdef	OLD
	int		i,j;
	unsigned char	*SaveAddr;
	int		InAddr;
#endif
	switch(mp->mpec){
	case PLC_BIT:		/* Bit Device */
		ret = MakeWriteData(0,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCcombuf,(char *)mp->mptr);
		Cnt = mp->mext;
		break;
	case PLC_WORD:		/* Word Device */
		ret = MakeWriteData(1,(char *)mp->mbuf,mp->mpar,mp->mext,(char *)PLCcombuf,(char *)mp->mptr);
		if(DeviceFlag == 2){		/* TS,CS */
			Cnt = mp->mext* 4;
		}else if(DeviceFlag == 9){		/* BIT DEVICE(X,Y) */
			Cnt= mp->mext;
		}else{
			Cnt = mp->mext* 2;
		}
		break;
	}
	if(ret == 0){
		if(SendRecPLCBCC(1,(char *)PLCcombuf,rDataFx,&Cnt,1) == 0){
		}else{
			ret = -1;
		}
	}else if(ret == 1){		/* ����Address */
		ret= 0;
	}
	return(ret);
}
/************************************/
/*	PLC Group DEVICE Read			*/
/************************************/
int	RecGroupDevFX1N( void )
{
	int		ret;
	int		wIdx;
	int		idx;
	int		i,j;
	int		BitCnt;
	int		wBitCnt;
	int		WordCnt;
	int		AndData;
	unsigned char wData;
	char	work[16];

	if((gDeviceCntBit == 0) && (gDeviceCntWord == 0) && (PcThru1014 == 0)){
		return(0);
	}
	ret= 0;
	if(PcThru1014 != 0){
		WordCnt= gDeviceCntWord+ PcThruWCnt;
		if((gDeviceCntBit != 0) || (PcThruBCnt != 0)){
			BitCnt= ((gDeviceCntBit+PcThruBCnt)- 1)/ 8+ 1;
		}else{
			BitCnt= 0;
		}
	}else{
		WordCnt= gDeviceCntWord;
		if(gDeviceCntBit != 0){
			BitCnt= (gDeviceCntBit- 1)/ 8+ 1;
		}else{
			BitCnt= 0;
		}
	}
	if((WordCnt*2+ BitCnt) >= 0x40){
		sprintf(work,"E001790%02X",0x40);
	}else{
		sprintf(work,"E001790%02X",WordCnt*2+ BitCnt);
	}
	if((WordCnt*2+ BitCnt) > 0x40){
		PlcCommCnt= SetPlcDataBCC(work,strlen(work),PlcSendBuff);
		ret= SendRecPLC(2,PlcSendDevData,&idx,0);
		if(ret == OK){
			idx -= 3;
			sprintf(work,"E0017D0%02X",(WordCnt*2+ BitCnt) - 0x40);
			PlcCommCnt= SetPlcDataBCC(work,strlen(work),PlcSendBuff);
			ret= SendRecPLC(2,&PlcSendDevData[idx],&j,0);
			if(ret == OK){
				/* STX Delete */
				memcpy(&PlcSendDevData[idx], &PlcSendDevData[idx+1], j-1);
			}
		}
	}else{
		PlcCommCnt= SetPlcDataBCC(work,strlen(work),PlcSendBuff);
		ret= SendRecPLC(2,PlcSendDevData,&idx,0);
	}

	if(ret == OK){
		if(PcThru1014 != 0){
			memcpy(&PcThruRecData[0],(char *)&PlcSendDevData[1],PcThruWCnt*4);
			wIdx= PcThruWCnt*4;
		}else{
			wIdx= 0;
		}
		for(i = 0; i < gDeviceCntWord; i++){
			*gDeviceAddr[i] = (unsigned char)Hex2Bin((char *)&PlcSendDevData[i*4+ 1+ wIdx]);
			*(gDeviceAddr[i]+ 1) = (unsigned char)Hex2Bin((char *)&PlcSendDevData[i*4+ 3+ wIdx]);
		}
		if(PcThru1014 != 0){
			wIdx= (PcThruWCnt+ gDeviceCntWord)*4;
			if(PcThruBCnt != 0){
				wBitCnt= (PcThruBCnt- 1)/ 8+ 1;
			}else{
		
				wBitCnt= 0;
			}
			PcThruByteCnt= wBitCnt;
			memcpy(&PcThruRecData[PcThruWCnt*4],(char *)&PlcSendDevData[1+ (gDeviceCntWord+ PcThruWCnt)*4],wBitCnt*2);
		}else{
			wIdx= gDeviceCntWord*4;
			wBitCnt= 0;
		}
		idx= 0;
		for(i = 0; i < BitCnt; i++){
			wData= (unsigned char)Hex2Bin((char *)&PlcSendDevData[i*2+ wIdx+ 1]);
			AndData= 1;
			for(j = 0; j < 8; j++){
				if((i*8+ j) >= wBitCnt){
					if((i*8+ j) < (wBitCnt+ gDeviceCntBit)){
						if((wData & AndData) == 0){
							*gDeviceAddr[idx+ gDeviceCntWord] = 0;
						}else{
							*gDeviceAddr[idx+ gDeviceCntWord] = 1;
						}
						AndData= AndData << 1;
					}
					idx++;
				}else{
					AndData= AndData << 1;
				}
			}
		}
		if((PcThru1014 != 0) && (PcThru1014Rec == 1)){
			PcThru1014Rec= 2;
		}
	}else{			/* Send Error */
		Comm0RecMode= 0;
		PlcConnectFlag= 0;
	}
	return(ret);
}

int	RecGroupDevFX1S( void )
{
	int		ret;
	int		wIdx;
	int		idx;
	int		i,j;
	int		BitCnt;
	int		wBitCnt;
	int		WordCnt;
	int		AndData;
	unsigned char wData;
	char	work[16];

	if((gDeviceCntBit == 0) && (gDeviceCntWord == 0) && (PcThru1014 == 0)){
		return(0);
	}
	ret= 0;
	/* Word data Read */
	if((PcThruWCnt != 0) || (gDeviceCntWord != 0)){
		WordCnt= gDeviceCntWord+ PcThruWCnt;
		sprintf(work,"01958%02X",WordCnt*2);
		PlcCommCnt= SetPlcDataBCC(work,strlen(work),PlcSendBuff);
		ret= SendRecPLC(2,PlcSendDevData,&ret,0);
		if(ret == OK){
			if(PcThruWCnt != 0){
				/* Word Data Save */
				memcpy(&PcThruRecData[0],(char *)&PlcSendDevData[1],PcThruWCnt*4);
				wIdx= PcThruWCnt*4;
			}else{
				wIdx= 0;
			}
			for(i = 0; i < gDeviceCntWord; i++){
				*gDeviceAddr[i] = (unsigned char)Hex2Bin((char *)&PlcSendDevData[i*4+ 1+ wIdx]);
				*(gDeviceAddr[i]+ 1) = (unsigned char)Hex2Bin((char *)&PlcSendDevData[i*4+ 3+ wIdx]);
			}
			if((PcThru1014 != 0) && (PcThru1014Rec == 1)){
				PcThru1014Rec= 2;
			}
		}else{			/* Send Error */
			Comm0RecMode= 0;
			PlcConnectFlag= 0;
		}
	}
	/* Bit data Read */
	if((gDeviceCntBit != 0) || (PcThruBCnt != 0)){
		BitCnt= ((gDeviceCntBit+PcThruBCnt)- 1)/ 8+ 1;
		sprintf(work,"019A0%02X",BitCnt);
		PlcCommCnt= SetPlcDataBCC(work,strlen(work),PlcSendBuff);
		ret= SendRecPLC(2,PlcSendDevData,&ret,0);

		if(ret == 0){
			if(PcThruBCnt != 0){
				wBitCnt= (PcThruBCnt- 1)/ 8+ 1;
			}else{
				wBitCnt= 0;
			}
			/* Bit Data Save */
			memcpy(&PcThruRecData[256],(char *)&PlcSendDevData[1],wBitCnt*2);
			idx= 0;
			for(i = 0; i < BitCnt; i++){
				wData= (unsigned char)Hex2Bin((char *)&PlcSendDevData[i*2+ 1]);
				AndData= 1;
				for(j = 0; j < 8; j++){
					if((i*8+ j) >= wBitCnt){
						if((i*8+ j) < (PcThruBCnt+ gDeviceCntBit)){
							if((wData & AndData) == 0){
								*gDeviceAddr[idx+ gDeviceCntWord] = 0;
							}else{
								*gDeviceAddr[idx+ gDeviceCntWord] = 1;
							}
							AndData= AndData << 1;
						}
						idx++;
					}else{
						AndData= AndData << 1;
					}
				}
			}
			if((PcThru1014 != 0) && (PcThru1014Rec == 1)){
				PcThru1014Rec= 2;
			}
		}else{			/* Send Error */
			Comm0RecMode= 0;
			PlcConnectFlag= 0;
		}
	}
	return(ret);
}
/****************************************************/
/*	Device2Index									*/
/****************************************************/
int		Device2IndexFX(int bwflag,char *Name)
{
	int		ret;
	int		i;

	ret= -1;
	if(bwflag == 0){
		for(i= 0; i < FX_SereaseByteCnt; i++){
			if(strcmp(Name,FX_SereaseByte[i].DevName) == 0){
				ret= FX_SereaseByte[i].Index;
			}
		}
	}else{
		for(i= 0; i < FX_SereaseWordCnt; i++){
			if(strcmp(Name,FX_SereaseWord[i].DevName) == 0){
				ret= FX_SereaseWord[i].Index;
			}
		}
	}
	return(ret);
}
/********************************************/
int		MakeGroupDevFX(void)
{
	int	ret;

	switch(PlcType){
	case 0:				/* FX1N */
		ret= MakeGroupDevFX1N();
		break;
	case 1:				/* FX1S */
		ret= MakeGroupDevFX1S();
		break;
	}
	return(ret);
}
int		RecGroupDevFX(void)
{
	int	ret;

	switch(PlcType){
	case 0:
		ret= RecGroupDevFX1N();
		break;
	case 1:
		ret= RecGroupDevFX1S();
		break;
	}
	return(ret);
}
/****************************************************/
/* FX-�V��?�Y										*/
/****************************************************/
void	PC232_CommProc(char *CommBuff,int *RecCommCnt,char *OutBuff,int *OutCnt)
{
	int		ret;

	CommMode= 0;
	*OutBuff= 0;
	/* PLC�֑��M */
	ret= PcMonitorCheck(CommBuff,OutBuff,OutCnt);
	switch(ret){
	case 0:
		if(*OutBuff != 0){
			SendPLC2PCData(0);		/* ACK ���M */
		}
		break;
	case 1:			/* Group Set */
		SendPLCGroup();		/* Group Read */
		*OutCnt= 1;
		OutBuff[0]= ACK;
		SendPLC2PCData(0);		/* ACK ���M */
		break;
	case 2:
		if((PcThru1014 == 1) && (PcThru1014Rec == 2)){		/* �O��?�v��M�ς� */
			if(PcThruByteCntStr == 0x90){
				*OutCnt= SetPlcDataBCC((char *)PcThruRecData,PcThruByteCnt179*2,(unsigned char *)OutBuff);
			}else{
				*OutCnt= SetPlcDataBCC((char *)&PcThruRecData[0x40*2],PcThruByteCnt179*2,(unsigned char *)OutBuff);
			}
		}else{
			memset(PcThruRecDataWork,'0',sizeof(PcThruRecDataWork));
			*OutCnt= SetPlcDataBCC((char *)PcThruRecDataWork,PcThruByteCnt179*2,(unsigned char *)OutBuff);
		}
		if(*OutBuff != 0){
			SendPLC2PCData(0);		/* E100179 ���� ���M */
		}
		break;
	case -1:				/* Error */
	case 3:					/* ENQ Response */
		break;
	case 4:					/* A1 Response */
		if(*OutBuff != 0){
			SendPLC2PCData(0);		/* A1���� ���M */
		}
		Delay(50);
#ifdef	WIN32
		SioPLCMode= 1;
		SioPLCOpenFlag= 1;
		while(1){
			if(SioPLCOpenFlag == 0){
				break;
			}
			Delay(10);
		}
#else
		RsModeSet(RS_PLC,RS_INIT,RS_19200,RS_DATA7,RS_EVEN);
#endif
		break;
	case 5:
		if(*OutBuff != 0){
			SendPLC2PCData(0);		/* ELSE���� ���M */
		}
		break;
	case 6:							/* FX1S GROUP */
		if((PcThru1014 == 1) && (PcThru1014Rec == 2)){		/* �O��?�v��M�ς� */
			*OutCnt= SetPlcDataBCC((char *)PcThruRecData,PcThruByteCnt1SW*2,(unsigned char *)OutBuff);
		}else{
			memset((char *)PcThruRecDataWork,'0',sizeof(PcThruRecDataWork));
			*OutCnt= SetPlcDataBCC((char *)PcThruRecDataWork,PcThruByteCnt1SW*2,(unsigned char *)OutBuff);
		}
		if(*OutBuff != 0){
			SendPLC2PCData(0);		/* E100179 ���� ���M */
		}
		break;
	case 7:							/* FX1S GROUP */
		if((PcThru1014 == 1) && (PcThru1014Rec == 2)){		/* �O��?�v��M�ς� */
			*OutCnt= SetPlcDataBCC((char *)&PcThruRecData[256],PcThruByteCnt1SB*2,(unsigned char *)OutBuff);
		}else{
			memset((char *)PcThruRecDataWork,'0',sizeof(PcThruRecDataWork));
			*OutCnt= SetPlcDataBCC((char *)PcThruRecDataWork,PcThruByteCnt1SB*2,(unsigned char *)OutBuff);
		}
		if(*OutBuff != 0){
			SendPLC2PCData(0);		/* E100179 ���� ���M */
		}
		break;
	default:
		memcpy(OutBuff,CommBuff,*RecCommCnt);
		*OutCnt= *RecCommCnt;
		SendPLCPCData();
		break;
	}
}
/********************************************/
/*	PLC Protocol Clear						*/
/********************************************/
void	PlcBufCrear(void)
{
	PcThru1014= 0;
	PcThru1014Rec= 0;
}
/********************************************/
/*	PC Port Recieve							*/
/********************************************/
int PCDownThrueFX(unsigned char data,int *PC_CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff)
{
	int				i;
	unsigned char	bcc;
	int	ret;

	ret = -1;
	switch(*PC_CommMode){
	case 0:		/* Normal */
		if(data == STX){
			*PC_CommMode = 4;
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}else if(data == ENQ){
			*PC_CommMode = 99;			/* True Mode */
			ret = 0;	/* Pendding Req */
			*Sio1RecCnt = 0;
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
		}
		break;
	case 4:		/* Thru Mode */
		if(*Sio1RecCnt < PLC_BUF_MAX){
			Sio1RecBuff[(*Sio1RecCnt)++] = data;
			if(data == ETX){
				*PC_CommMode = 5;
			}
		}else{
			*PC_CommMode = 0;
		}
		break;
	case 5:		/* BCC1 */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		*PC_CommMode = 6;
		break;
	case 6:		/* BCC2 */
		Sio1RecBuff[(*Sio1RecCnt)++] = data;
		/* BCC ?�F�b�N */
		bcc = 0;
		for(i = 0; i < *Sio1RecCnt- 3; i++){
			bcc += Sio1RecBuff[i+ 1];
		}
		if(bcc == (unsigned char)LHexAsToBin((char *)&Sio1RecBuff[*Sio1RecCnt- 2],2)){
			*PC_CommMode = 99;
			ret = 0;	/* Pendding Req */
		}
		break;
	}
	return(ret);
}
/****************************************************
*   FUNC  : PLC Recieve Handler						*
*	In    :											*
*	Out   : 										*
*   DATE  : 2002.10.01                              *
*****************************************************/
int	PlcRecRS(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int				i;
	unsigned char	bcc;
	int	ret= -1;

	switch(data){
	case ACK:
		RecBuff[(*RecCnt)++] = data;
		ret = 0;
		break;
	case STX:
		*RecCnt = 0;
		*CommMode = 1;
		RecBuff[(*RecCnt)++] = data;
		break;
	case ETX:
		RecBuff[(*RecCnt)++] = data;
		*CommMode = 2;
		break;
	case NAK:
		ret = 0;
		break;
	default:
		if(*CommMode > 1){
			if(*RecCnt < PLC_BUF_MAX){
				RecBuff[(*RecCnt)++] = data;
			}
			if(*CommMode == 2){
				*CommMode = 3;
			}else if(*CommMode == 3){
				*CommMode = 0;
				/* BCC ?�F�b�N */
				bcc = 0;
				for(i = 0; i < *RecCnt- 3; i++){
					bcc += RecBuff[i+ 1];
				}
				if(bcc == (unsigned char)LHexAsToBin((char *)&RecBuff[*RecCnt- 2],2)){
					*CommMode = 99;
					ret = 0;	/* Pendding Req */
				}
				ret = 0;
			}
		}else if(*CommMode == 1){
			RecBuff[(*RecCnt)++] = data;
		}
		break;
	}
	return(ret);
}
/********************************/
/*	DEVICE �����o��			*/
/********************************/
/****************************/
/*	Get Device Name			*/
/****************************/
int	GetDevNameFX(int bFlag,unsigned char *src,char *obj,int *DevInfo)
{
	int		ret;
	char	Device[4];
	unsigned char	sDevice;

	if(src[0] == 1){     /* No Device */
		return(-1);
	}
	ret= -1;
	sDevice= src[0];
	if(sDevice >= 0xf0){
		Device[1]= 0;
		switch(sDevice){
		case DEV_CR:
			Device[0]= 'C';
			break;
		case DEV_TR:
			Device[0]= 'T';
			break;
		case DEV_CS:
			Device[0]= 'C';
			break;
		case DEV_TS:
			Device[0]= 'T';
			break;
		}
		ret= Device2IndexFX(bFlag,Device);
		if(ret != -1){
			src[0]= (char)ret;
		}
	}
	if(bFlag == 0){	/* Bit */
		if(IndexTable[src[0]] != 0xff){
			memcpy(obj,FX_SereaseByte[IndexTable[src[0]]].DevName,3);
			*DevInfo= FX_SereaseByte[IndexTable[src[0]]].DevInfo;
			ret= 0;
		}
	}else{
		if(IndexTable[src[0]] != 0xff){
			memcpy(obj,FX_SereaseWord[IndexTable[src[0]]].DevName,3);
			*DevInfo= FX_SereaseWord[IndexTable[src[0]]].DevInfo;
			ret= 0;
		}
	}
	if(ret == 0){
		if(sDevice >= 0xf0){
			src[0]= sDevice;
			obj[2]= 0;
			switch(sDevice){
			case DEV_CR:
				obj[0]= 'C';
				obj[1]= 'R';
				break;
			case DEV_TR:
				obj[0]= 'T';
				obj[1]= 'R';
				break;
			case DEV_CS:
				obj[0]= 'C';
				obj[1]= 'S';
				break;
			case DEV_TS:
				obj[0]= 'T';
				obj[1]= 'S';
				break;
			}
		}
	}
	return(ret);
}
int	GetDevMaxFX(int bFlag,int idx)
{
	int		ret;

	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(IndexTable[idx] != 0xff){
			ret= FX_SereaseByte[IndexTable[idx]].DeviceMax;
		}
	}else{
		if(IndexTable[idx] != 0xff){
			ret= FX_SereaseWord[IndexTable[idx]].DeviceMax;
		}
	}
	return(ret);
}
int	GetDevMinFX(int bFlag,int idx)
{
	int		ret;

	ret= -1;
	if(bFlag == 0){	/* Bit */
		if(IndexTable[idx] != 0xff){
			ret= FX_SereaseByte[idx].DeviceMin;
		}
	}else{
		if(IndexTable[idx] < 0xff){
			ret= FX_SereaseWord[IndexTable[idx]].DeviceMin;
		}
	}
	return(ret);
}
int		CheckDevice_Addr(int bwflag,char *src,int *Address1,int *PlcType)
{
	int		i;
	int		ret;
	char	obj[5];
	int		iDeviceFlag;
	unsigned char	idx;

	idx= (unsigned char)src[0];
	if(idx == 1){     /* No Device */
		return(-1);
	}
	ret= -1;
	memset(obj,0,sizeof(obj));
	if(bwflag == 0){	/* Bit */
		if(IndexTable[idx] != 0xff){
			memcpy(obj,FX_SereaseByte[IndexTable[idx]].DevName,3);
			ret= 0;
		}
	}else{
		if(IndexTable[idx] != 0xff){
			memcpy(obj,FX_SereaseWord[IndexTable[idx]].DevName,3);
			ret= 0;
		}
	}
	if(ret == 0){
		if(bwflag == 0){			/* Bit Device */
			for(i = 0; ; i++){
				if(bDeviceTbl[*PlcType][i].Device == (char *)0){
					ret= -1;
					break;
				}else{
					if(strcmp(bDeviceTbl[*PlcType][i].Device,obj) == 0){
						iDeviceFlag= bDeviceTbl[*PlcType][i].flag;
						if(iDeviceFlag == 10){			/* T */
							*Address1= DEV_TR;
						}else if(iDeviceFlag == 11){	/* C */
							*Address1= DEV_CR;
						}else{
							ret= -1;
						}
						break;
					}
				}
			}
		}
		else{
			for(i = 0; ; i++){
				if(wDeviceTbl[*PlcType][i].Device == (char *)0){
					ret= -1;
					break;
				}else{
					if(strcmp(wDeviceTbl[*PlcType][i].Device,obj) == 0){
						iDeviceFlag= wDeviceTbl[*PlcType][i].flag;
						if(iDeviceFlag == 10){			/* T */
							*Address1= DEV_TS;
						}else if(iDeviceFlag == 3){	/* C */
							*Address1= DEV_CS;
						}else{
							ret= -1;
						}
						break;
					}
				}
			}
		}
	}
	return(ret);
}


