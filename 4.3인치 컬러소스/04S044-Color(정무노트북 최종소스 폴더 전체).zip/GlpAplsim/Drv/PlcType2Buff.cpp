#define	PLCTYPE_CH1_BUF	1
#include	"plched.h"
