/*****************************************/
#ifndef	WIN32
//#pragma	section CommArea
#endif

#define	COMM_AREA	1
#include	"define.h"
#include	"GpCommon.h"


COMMON_AREA	CommonArea;
_SETUP			Set;					/* set value save struct */
/* Device_Name Buffer 2003/06/03 */
char		Device_Name[16][5];
short		Device_iType[16];
union{
	unsigned short	UW[MAX_UW_WORD];
	unsigned char	UB[(2048+4356)*2];
	PLC_DEV	PlcDev;
}InDevArea;

