/****************************************/
/*      ���[�_�v���O����                */
/****************************************/
/*	Buffer                              */ 
#include	<string.h>
#include	"define.h"
//#include	"cpu7014.h"
#include	"bios.h"

#define	MAX_SIO_CNT	64
#define		RTS1		0x0200		/* PORTA */
#define	APL_START	0x0001000

#ifndef	WIN32
#pragma	section	LOAD
#endif
extern		unsigned short	PortA;
extern		unsigned short	PortB;

int	time_flag[8];
int	time_data[8];
unsigned char sio_ib[MAX_SIO_CNT];	/* Sio  In Buff                         */
int	sio_cnt;		/* Sio0 In Buff Input Index             */
int	sio_inq;		/* Sio0 In Buff Input Index             */
int	sio_ouq;		/* Sio0 In Buff Input Index             */

extern	int DebugTask( int cmd, char *msg );
#ifndef	WIN32
#pragma interrupt  ( ERInterruptHandler )
#pragma interrupt  ( RXInterruptHandler )
#pragma interrupt  ( TimerProc )
#endif

/********************************************************/
/*	�A�v���P�[�V�����W�����v							*/
/********************************************************/
void	(*func)();

void	Sci1Reset( void )
{
	unsigned char	data;

	data = 0x00;
	*(unsigned char *)CPU_SMR1 = data;		/*  */
	*(unsigned char *)CPU_BRR1 = (unsigned char)BAUDRATE9600;
	*(unsigned short*)CPU_PADRL = 0x0200;	/* RTS ON */
	*(char *)CPU_SCR1 = 0x70;			/* RIE,TE,RE ON */
}
/****************************************/ 
/* Timer Interruput                     */
/****************************************/
void	TimerInit( void )
{
	int		i;
	
	for(i = 0; i < 8; i++){
		time_flag[i] = 0;
		time_data[i] = 0;
	}
}   
void	TimerStart(int no,int cnt)
{
	di();
	time_flag[no] = 0;
	time_data[no] = cnt;
	ei();
}
void	TimerStop(int no)
{
	di();
	time_flag[no] = 0;
	time_data[no] = 0;
	ei();
}
void	TimerProc( void )
{
	int		i;

	for(i = 0; i < 8; i++){
		if(time_data[i] != 0){
			time_data[i]--;
			if(time_data[i] == 0){
				time_flag[i] = 1;
			}
		}
	}
	*(unsigned short *)CPU_CMCSR0 &= 0x007f;
}




int	IsGetSio( void )
{
	return(sio_cnt);
}
int	GetSio( void )
{
	int	ret;

	ret= 0;
	if(sio_cnt != 0){
		ret= sio_ib[sio_ouq];
		sio_ouq= ( sio_ouq + 1 ) & ( sizeof sio_ib - 1 );
		di();
		sio_cnt--;
		ei();
	}
	return( ret );
}
/****************************************************
*   FUNC  : Rts ON/OFF                              *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
void	RtsOn(void)
{
	PortA |= RTS1;                    
	*(unsigned short*)CPU_PADRL = PortA;	/* RTS ON */
}
void	RtsOff(void)
{                    
	PortA &= ~RTS1;                    
	*(unsigned short*)CPU_PADRL = PortA;	/* RTS OFF */
}

/****************************************************
*   FUNC  : Sio1 Error Handler                      *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
void	ERInterruptHandler( void )
{
	unsigned char	status;

    status= *(unsigned char *)CPU_SSR1;			/* Input Status  */
    if((status & 0x38) == 0){
		*(char *)CPU_SSR1 = status & 0x87;		/* Input Status  */
        status= *(char *)CPU_RDR1;	/* Reciever Data */
    }else{      /* Error */
		*(char *)CPU_SSR1 = status & 0x87;		/* Input Status  */
    }
}
/****************************************************
*   FUNC  : Sio1 Recieve Handler                    *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
void	RXInterruptHandler( void )
{
	unsigned char	status;
    unsigned char rs_input_data;

	status= *(unsigned char *)CPU_SSR1;		/* Input Status  */
	if((status & 0x40) != 0){
		rs_input_data= *(char *)CPU_RDR1;	/* Reciever Data */
		status= *(unsigned char *)CPU_SSR1;		/* Input Status  */
		*(char *)CPU_SSR1 = status & 0x87;		/* Input Status  */
		rs_input_data= *(char *)CPU_RDR1;	/* Reciever Data */
		if(sio_cnt < MAX_SIO_CNT){
			sio_ib[sio_inq]= (unsigned char)rs_input_data;
			sio_inq= ( sio_inq + 1 ) & ( sizeof sio_ib - 1 );
			sio_cnt++;
		}
    }else{      /* Error */
		status= *(unsigned char *)CPU_SSR1;		/* Input Status  */
		*(unsigned char *)CPU_SSR1 = status & 0x87;		/* Input Status  */
    }
}
/************************************************************/
/*	�P�������M												*/
/************************************************************/
int Send1Char( unsigned char ch )
{
	unsigned char s;

	while(1){
		s= *(unsigned char *)CPU_SSR1;
		if( (s & 0x80) != 0 ){
			break;
		}
	}
	*(unsigned char *)CPU_TDR1= ch;
	*(unsigned char *)CPU_SSR1 = 0;
	return( TRUE );
}
int	GetMessage( char *ptr )
{
	int c, no;
#ifdef _19991027
#else
	extern int DModeFlag;
	extern int PloadFlag;
	extern int Send1Char( unsigned char ch );
#endif

	no= 0;
	if(sio_cnt != 0){
		while( TRUE ){
			if( (c= GetSio()) != 0 ){
				switch( c ){
				case 0x0A:
				case 0x0D:
					*(ptr+ no)= c;
					no++;
					return( no );
				case 0x08:
					if( no > 0 ){	no--;	}
					break;
				case 0x04:
					*ptr= c;
					return( 1 );
				default:
					*(ptr+ no)= c;
					no++;
					break;
				}
#ifdef _19991027
#else
				if( DModeFlag == 0x10 /*OK_LOGIN*/ ){
				}
#endif
			}
		}
	}
	return( 0 );
}

#define	TIME_INIDMODE	1
int DModeFlag= 0x00;
void DubugMain( void )
{
	char msg[256];

/*	InitCPU();*/
	TimerStart( TIME_INIDMODE, 500 );		/* Wait 5Sec */  
	while( TRUE ){
		if( DModeFlag != 0x10 ){  
			if( time_flag[TIME_INIDMODE] != 0 ){
				return;
			}
		}
		if( GetMessage( msg ) != 0 ){
			DModeFlag= DebugTask( DModeFlag, msg );
		}
	}
}
/****************************************/ 
/* Loader Main Prog                     */
/****************************************/

#ifndef	WIN32
extern	void InitCPU( void );
extern	int	*_D_ROM, *_B_BGN, *_B_END, *_D_BGN, *_D_END;

void	_LINITSCT( void )
{
	int	*p, *q;
	
	InitCPU();

	for(p = _B_BGN; p < _B_END; p++){
		*p = 0;
	}
	for(p = _D_BGN, q = _D_ROM; p < _D_END; p++, q++){
		*p = *q;
	}
}
void	_LINIT( void )
{
	_LINITSCT();
}
#endif
void    main_start(void)
{
#ifndef	WIN32
	_INIT();
#endif
	Sci1Reset();
	*(unsigned short *)CPU_IPRA = 0x0000;   /*  */
	*(unsigned short *)CPU_IPRB = 0x0000;
	*(unsigned short *)CPU_IPRC = 0x0000;
	*(unsigned short *)CPU_IPRD = 0x0000;
	*(unsigned short *)CPU_IPRE = 0x0000;
	*(unsigned short *)CPU_IPRF = 0x000f;
	*(unsigned short *)CPU_IPRG = 0x0000;
	*(unsigned short *)CPU_IPRH = 0x0000;

	TimerInit();

	*(unsigned short*)CPU_CMSTR = 0x0001;		/* 10ms Timer Start */
    ei();

	TimerStart(1,100);		/* 1S Start */
	while(1){        
		if(time_flag[1] != 0){
			break;
		}  
		if(IsGetSio( ) != 0){
			DubugMain();
		}
	}
	di();
/*	func = (void (*)())APL_START;*/
/*	func();*/				/* Jmp to Apl */
}
