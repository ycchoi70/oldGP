#include	<string.h>

#include	"define.h"
#include	"typedefs.h"
#include	"rvd.h"
#include	"deviceid.h"
#include	"s3c44b0x.h"

#define		A1FADR5555	0x0000AAAA
#define		A1FADR2AAA	0x00005554

#define	FLASH_BLOC	0x10000

#define	TBQ(a)			(sizeof(a)/sizeof(a[0]))


typedef struct{
	void	*addr;			/* Border Address */
	int		type;			/* ROM Type 0:Word,1:Byte */
	int		cnt;			/* Byte,Word */
}FLASH_ADDR;
const FLASH_ADDR	FRom1Tbl[] = {
	{(void *)0x00000000,1,0x10000},		/* 64kb */
	{(void *)0x00010000,1,0x10000},		/* 64kb */
	{(void *)0x00020000,1,0x10000},		/* 64kb */
	{(void *)0x00030000,1,0x10000},		/* 64kb */
	{(void *)0x00040000,1,0x10000},		/* 64kb */
	{(void *)0x00050000,1,0x10000},		/* 64kb */
	{(void *)0x00060000,1,0x10000},		/* 64kb */
	{(void *)0x00070000,1,0x10000},		/* 64kb */
	{(void *)0x00080000,1,0x10000},		/* 64kb */
	{(void *)0x00090000,1,0x10000},		/* 64kb */

	{(void *)0x000a0000,1,0x10000},		/* 64kb */
	{(void *)0x000b0000,1,0x10000},		/* 64kb */
	{(void *)0x000c0000,1,0x10000},		/* 64kb */
	{(void *)0x000d0000,1,0x10000},		/* 64kb */
	{(void *)0x000e0000,1,0x10000},		/* 64kb */
	{(void *)0x000f0000,1,0x10000},		/* 64kb */
	{(void *)0x00100000,1,0x10000},		/* 64kb */
	{(void *)0x00110000,1,0x10000},		/* 64kb */
	{(void *)0x00120000,1,0x10000},		/* 64kb */
	{(void *)0x00130000,1,0x10000},		/* 64kb */

	{(void *)0x00140000,1,0x10000},		/* 64kb */
	{(void *)0x00150000,1,0x10000},		/* 64kb */
	{(void *)0x00160000,1,0x10000},		/* 64kb */
	{(void *)0x00170000,1,0x10000},		/* 64kb */
	{(void *)0x00180000,1,0x10000},		/* 64kb */
	{(void *)0x00190000,1,0x10000},		/* 64kb */
	{(void *)0x001a0000,1,0x10000},		/* 64kb */
	{(void *)0x001b0000,1,0x10000},		/* 64kb */
	{(void *)0x001c0000,1,0x10000},		/* 64kb */
	{(void *)0x001d0000,1,0x10000},		/* 64kb */
	{(void *)0x001e0000,1,0x10000},		/* 64kb */

	{(void *)0x001f0000,1,0x08000},		/* 32kb */
	{(void *)0x001f8000,1,0x02000},		/*  8kb */
	{(void *)0x001fa000,1,0x02000},		/*  8kb */
	{(void *)0x001fc000,1,0x04000},		/* 16kb */
	{(void *)0x00200000,1, 0	 },		/* END */
};
#ifdef	WIN32
void	_ei(void)
{
}
void	_di(void)
{
}
void	main()
{
}
#else
extern	void	_ei(void);
extern	void	_di(void);
#endif
/********************************************************
*   FUNC  : Flash Rom Write                         	*
*	In    :												*
*	Out   : 											*
*   AUTHOR : M.Owashi                                	*
*   DATE  : 1996.8.28                               	*
*   DATE  : 1996.8.28									*
*	Update:97.03.13 kf									*
*********************************************************/
WORD FlashEraseAmd(volatile WORD BlockAddress, WORD BusType, WORD DevID);
WORD FlashWriteAmd(volatile WORD WriteAddress, WORD BufferAddress, const WORD Count, const WORD VerifyFlag, WORD BusType, WORD DevID);
void	FlashWriteSub(short *addr,short *data, long count,int flag)
{
	FlashEraseAmd((WORD)addr,WIDTH_HWORD,AM29LV160DB);
	FlashWriteAmd((WORD)addr,(WORD)data,(WORD)count,(WORD)1,WIDTH_HWORD,AM29LV160DB);
}
void	FlashEraze(short *addr)
{
	FlashEraseAmd((WORD)addr,WIDTH_HWORD,AM29LV160DB);
}
void	FlashWrite(short *addr,short *data, long count)
{
	FlashWriteAmd((WORD)addr,(WORD)data,(WORD)count,(WORD)1,WIDTH_HWORD,AM29LV160DB);
}
int	FlashWriteProc(char *addr,char *data,int size)
{
	int		i,ret;
	char	*waddr;
    FLASH_ADDR	*FRomTbl;

	ret = OK;
#ifdef	WIN32
	return(ret);
#endif
	FRomTbl = (FLASH_ADDR *)&FRom1Tbl[0];
	for(i = 0; i < TBQ(FRom1Tbl); i++){
		waddr = (char *)FRomTbl[i].addr;
		if(addr < waddr){
			break;
		}
	}
	if(i < TBQ(FRom1Tbl)){
		waddr = (char *)FRomTbl[i-1].addr;
		if(addr == waddr){
			ret = 0;
		}else{
			ret = 1;
		}
		FlashWriteSub((short *)addr,(short *)data,size,ret);
	}
	return(ret);
}
unsigned int Verify(unsigned int StartAddr, unsigned int BufferAddr, unsigned int Number)	//OK returns 0, False returns 1
{
	int		i;
	int		ret;
	unsigned short *src;
	unsigned short *obj;

	src= (unsigned short *)StartAddr;
	obj= (unsigned short *)BufferAddr;
	ret= NO_ERR;
	for(i= 0; i < (int)(Number/2); i++){
		if(*src++ != *obj++){
			ret= ERROR;
			break;
		}
	}
	return(ret);
}
