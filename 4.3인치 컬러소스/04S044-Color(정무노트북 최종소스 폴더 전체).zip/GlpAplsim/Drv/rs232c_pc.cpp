/****************************************************/
/*    FUNC   : SCI1 Program                    */
/*    AUTHOR : M.Owashi                             */
/*    DATE   : 2002.4.10                            */
/*    Update :                                      */
/****************************************************/
#include    "sgt.h"
#include    "mtsschdp.h"
#include    "mtsscid.h"
#include "Selib.h"
#include "s3c44b0x.h"
#include "plched.h"			//2012.07.04


/*#define	MITUBISHI		1*/
/*#define	LOG	1*/

#define		CTS1		0x0001		/* PORTA */
#define		RTS1		0x0001		/* PORTA */


/**********************************/

static	int	PC_MyTaskNo;	/* Recieve Drive */
static	int	PC_MyTaskNo1;
extern	volatile	int	PLC_MyTaskNo1;
extern	volatile	int	PLC_MyTaskNo;
#ifdef	LOG
int		volatile	rs1Cnt;
int		volatile	rs1SaveCnt;
char	rs1log[2048];
//KSC20090112
//char	rs1Mtrixlog[1024];
//int		volatile	rs1OutCnt;
//int		volatile	rs1SaveOutCnt;
//char	rs1Outlog[1024];
#endif
/*********************************/
#ifdef	WIN32
extern	int		PcRecData;			/* PC Rec Compleat */
//extern	int		Sio11SndCnt;
#endif

#ifdef	WIN32
/* �V?����??�ŃG��?���邽�߃�?�v�ɓ���� */
extern	int		SioLoopIdx;
extern	int		SioLoopOutIdx;
extern	unsigned char	SioLoopRecBuff[4][PLC_BUF_MAX];
extern	int		SioLoopRecCnt[4];
extern	int		CommLoopRecMode[4];		/* Rec Mode par 1 Record */
extern	int		CommLoopResult[4];
extern	int		CommRecKindSave[4];
#endif
/*extern	int		PcCommonFlag;*/
volatile	int		Init232CFlag;		//061228
extern	volatile	int	Init232CFlag0;
volatile	int		Sending232C;
unsigned char	Sio11SndBuff[PLC_BUF_MAX];
int		Sio11SndCnt;
/****************************************/
/****************************************/
/*	Init(SCI1)                          */
/****************************************/
void	InitSci1( int speed, int ldata, int parity )
{
#ifndef	WIN32
	int	mode;
	int	mclk;
	int	i;
	int	BoadRate;

	Init232CFlag= 1;		//061228

    mclk=MCLK;
//    rUFCON1=0x97;     	// FIFO Enable(T,S=8Byte)
//    rUFCON1=0x17;     	// FIFO Enable(T,S=8Byte)
    rUFCON1=0x07;     	// FIFO Enable(T,S=4Byte)
    rUMCON1=0x1;		//RTS-ON
//#ifdef	XXX
	if(ldata == RS_DATA7){
		mode= 0x02;
	}else{
		mode= 0x03;
	}
	switch(parity & 0xff){
	case RS_NONE:
		break;
	case RS_ODD:
		mode |= 0x04 << 3;
		break;
	case RS_EVEN:
		mode |= 0x05 << 3;
		break;
	}
//#else
//	mode= 0x03;
//	mode |= 0x05 << 3;
//#endif
	switch((parity & 0xff00) >> 8){      /* STOP 20090527 */
	case RS_STOP01:
		mode |= 0x00 << 2;
		break;
	case RS_STOP02:
		mode |= 0x01 << 2;
		break;
	}

    rULCON1= mode;     	//Normal,No parity,1 stop,8 bit
#ifdef	SIO_SENSE
    rUCON1=0x2c5;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
#endif
#ifdef	SIO_INTRUPT
    rUCON1=0x0c1;    	//rx=edge,tx=level,disable timeout int.,enable rx error int.,normal,interrupt or polling
#endif
//#ifdef	XXX
	switch(speed){
	case RS_300:
		BoadRate= 300;
		break;
	case RS_600:
		BoadRate= 600;
		break;
	case RS_1200:
		BoadRate= 1200;
		break;
	case RS_2400:
		BoadRate= 2400;
		break;
	case RS_4800:
		BoadRate= 4800;
		break;
	case RS_9600:
		BoadRate= 9600;
		break;
	case RS_19200:
		BoadRate= 19200;
		break;
	case RS_38400:
		BoadRate= 38400;
		break;
	case RS_57600:
		BoadRate= 57600;
		break;
	case RS_115200:
		BoadRate= 115200;
		break;
	}
//#else
//	BoadRate= 115200;
//#endif
    rUBRDIV1=( (int)(mclk/16./BoadRate + 0.5) -1 );
    for(i=0;i<100;i++);
	Init232CFlag= 0;		//061228
#endif
}
//KSC20090112
void	Rs1FifoMde8(void)
{
    rUFCON1=0x17;     	// FIFO Enable(T,S=8Byte)
}
/****************************************/
/*	Editor Boadrate Setting				*/
/****************************************/
void	SetEditorBoadrate( int connect, int set_ch )		/* 20091222 */
{
	int		Kind;
//#ifndef	WIN32
/*	int		Speed;*/
/*	int		DataBit;*/
/*	int		Parity;*/
//#endif

	if(connect == CH_CH0){
		Kind= RS_PLC;
	}else{
		Kind= RS_PC;
	}
//#ifdef	WIN32
//	RsModeSet(Kind,RS_INIT,RS_38400, RS_DATA8, RS_EVEN);
//#else
	if(set_ch == 0){
/*		Speed = Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed;*/			/* 9600 */
/*		Parity = Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity;*/			/* 0:NONE,1:ODD,2:EVEN */
/*		DataBit = Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1;*/			/* 0:7,1:8 */
//		RsModeSet(Kind,RS_INIT,Speed, DataBit, Parity);
		RsModeSetChanel(Kind,&Set.Ch1_Serial_Param[Set.Ch1_iKind]);		/* 2009.09.04 Add Stop */
	}else{
/*		Speed = Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed;*/			/* 9600 */
/*		Parity = Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity;*/			/* 0:NONE,1:ODD,2:EVEN */
/*		DataBit = Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1;*/			/* 0:7,1:8 */
//		RsModeSet(Kind,RS_INIT,Speed, DataBit, Parity);
		RsModeSetChanel(Kind,&Set.Ch2_Serial_Param[Set.Ch2_iKind]);		/* 2009.09.04 Add Stop */
	}
/*	RsModeSet(Kind,RS_INIT,Speed, DataBit, Parity); 2009.09.04 */
//#endif
}
#ifdef	LP_S044
void	SetRsPortPriority(int ch,int kind)
{
	if(kind == EDITER){
		if(ch == 0){
			ChangeTaskPriority(T_SIO0DRV,0x19);				/* AlarmDetail Task */
		}else{
			ChangeTaskPriority(T_SIO1DRV,0x19);				/* AlarmDetail Task */
		}
	}else{
		if(ch == 0){
			ChangeTaskPriority(T_SIO0DRV,0x15);				/* AlarmDetail Task */
		}else{
			ChangeTaskPriority(T_SIO1DRV,0x15);				/* AlarmDetail Task */
		}
	}
}
#endif
void	Rs232cBordrateSet( void )		/* 20091222 */
{
	int		Speed;
	int		DataBit;
	int		Parity;
	int		Kind;

	/* CH1 Boarate Set */
	if(Set.Ch1_iConnect == CH_CH0){	/* PLC = RS-422 */
		Kind= RS_PLC;
	}else{
		Kind= RS_PC;
	}
#ifdef	LP_S044
	//Set RsPort Priority
	SetRsPortPriority(Set.Ch1_iConnect,Set.Ch1_iKind);
#endif
	switch(Set.Ch1_iKind){
	case EDITER:
		SetEditorBoadrate(Set.Ch1_iConnect,0);
//		if(IsGlpType() == OK){		//GLP TYPE
//			RsModeSet(Kind,RS_INIT,RS_38400, RS_DATA8, RS_EVEN);
//		}else{
//			RsModeSet(Kind,RS_INIT,RS_9600, RS_DATA7, RS_EVEN);
//		}
		BoardRateFlag= 0;
		BoardRateChangingFlag= 0;
		PlcConnectFlag= 0;
		//Editor Port Check
		if(Kind == RS_PC){
			PlcEditorPort= 1;
		}else{
			PlcEditorPort= 0;
		}
		break;
	case MONITOR:
		break;
	case DEFAULT_PLC:
		if((Def_Get_Ms_Sel() & 0xFF00) == 0x0100){		/* Apl Serial Set */
/*			Speed = Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed;*/			/* 9600 */
/*			Parity = Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity;*/			/* 0:NONE,1:ODD,2:EVEN */
/*			DataBit = Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1;*/			/* 0:7,1:8 */
/*			RsModeSet(Kind,RS_INIT,Speed, DataBit, Parity);*/
			RsModeSetChanel(Kind,&Set.Ch1_Serial_Param[Set.Ch1_iKind]);		/* 2009.09.04 Add Stop */

		}else{									/* Protocol Serial Set */
		}
		BoardRateFlag= MAX_BOADRATE_CNT;
		break;
	case ELSE_PLC:
		if(IsPlc1Protocol() == OK){	/* 2008.12.10 */

			if((GET_MS_SEL() & 0xFF00) == 0x0100){		/* Apl Serial Set */
/*				Speed = Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed;*/			/* 9600 */
/*				Parity = Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity;*/			/* 0:NONE,1:ODD,2:EVEN */
/*				DataBit = Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1;*/			/* 0:7,1:8 */
/*				RsModeSet(Kind,RS_INIT,Speed, DataBit, Parity);*/
				RsModeSetChanel(Kind,&Set.Ch1_Serial_Param[Set.Ch1_iKind]);		/* 2009.09.04 Add Stop */
			}else{									/* Protocol Serial Set */
				;		
			}
		}

		BoardRateFlag= MAX_BOADRATE_CNT;
		break;
	case PLCTYPE2:
		break;
	default:
/*		RsModeSet(Kind,RS_INIT,Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed, Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1, Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity);*/
		RsModeSetChanel(Kind,&Set.Ch1_Serial_Param[Set.Ch1_iKind]);		/* 2009.09.04 Add Stop */
		BoardRateFlag= MAX_BOADRATE_CNT;
		break;
	}
	/* CH2 Boarate Set */
#ifdef	LP_S044
	//Set RsPort Priority
	SetRsPortPriority(Set.Ch2_iConnect,Set.Ch2_iKind);
#endif
	if(Set.Ch2_iConnect == CH_CH0){	/* PLC = RS-422 */
		Kind= RS_PLC;
	}else{
		Kind= RS_PC;
	}
	switch(Set.Ch2_iKind){
	case EDITER:
		SetEditorBoadrate(Set.Ch2_iConnect,1);
//		if(IsGlpType() == OK){		//GLP TYPE
//			RsModeSet(Kind,RS_INIT,RS_38400, RS_DATA8, RS_EVEN);
//		}else{
//#ifdef	WIN32
//			RsModeSet(Kind,RS_INIT,RS_38400, RS_DATA8, RS_EVEN);
//#else
//			RsModeSet(Kind,RS_INIT,RS_9600, RS_DATA7, RS_EVEN);
//#endif
//		}
		BoardRateFlag= 0;
		BoardRateChangingFlag= 0;
		PlcConnectFlag= 0;
		//Editor Port Check
		if(Kind == RS_PC){
			PlcEditorPort= 1;
		}else{
			PlcEditorPort= 0;
		}
		break;
	case MONITOR:
		switch(Set.Ch1_iKind){
		case UNIVERSAL:
/*			Speed = Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed;*/			/* 9600 */
/*			Parity = Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity;*/			/* 0:NONE,1:ODD,2:EVEN */
/*			DataBit = Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1;*/			/* 0:7,1:8 */
/*			RsModeSet(Kind,RS_INIT,Speed, DataBit, Parity);*/
			RsModeSetChanel(Kind,&Set.Ch1_Serial_Param[Set.Ch1_iKind]);		/* 2009.09.04 Add Stop */
			break;
		case DEFAULT_PLC:
			if((Def_Get_Ms_Sel() & 0xFF00) == 0x0100){		/* Apl Serial Set */
/*				Speed = Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed;*/			/* 9600 */
/*				Parity = Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity;*/			/* 0:NONE,1:ODD,2:EVEN */
/*				DataBit = Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1;*/			/* 0:7,1:8 */
/*				RsModeSet(Kind,RS_INIT,Speed, DataBit, Parity);*/
				RsModeSetChanel(Kind,&Set.Ch1_Serial_Param[Set.Ch1_iKind]);		/* 2009.09.04 Add Stop */
			}else{
				LG_GetMonBaudrate(&Speed,&DataBit,&Parity);
				RsModeSet(Kind,RS_INIT,Speed, DataBit, Parity);
			}
			break;
		case ELSE_PLC:
			if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
				if((GET_MS_SEL() & 0xFF00) == 0x0100){		/* Apl Serial Set */
/*					Speed = Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed;*/			/* 9600 */
/*					Parity = Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity;*/			/* 0:NONE,1:ODD,2:EVEN */
/*					DataBit = Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1;*/			/* 0:7,1:8 */
/*					RsModeSet(Kind,RS_INIT,Speed, DataBit, Parity);*/
					RsModeSetChanel(Kind,&Set.Ch1_Serial_Param[Set.Ch1_iKind]);		/* 2009.09.04 Add Stop */
				}else{
					GET_MON_BAUDRATE(&Speed,&DataBit,&Parity);
					RsModeSet(Kind,RS_INIT,Speed, DataBit, Parity);
				}
				GroopSema= 0;			//2012.07.04 Add
			}
			break;
		}
		BoardRateFlag= MAX_BOADRATE_CNT;
		break;
	case PLCTYPE2:

		if(IsPlc2Protocol == OK){	/* 2008.12.10 */
			if((GET_MS_SEL2() & 0xFF00) == 0x0100){		/* Apl Serial Set */
/*				Speed = Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed;*/			/* 9600 */
/*				Parity = Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity;*/			/* 0:NONE,1:ODD,2:EVEN */
/*				DataBit = Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1;*/			/* 0:7,1:8 */
/*				RsModeSet(Kind,RS_INIT,Speed, DataBit, Parity);*/
				RsModeSetChanel(Kind,&Set.Ch2_Serial_Param[Set.Ch2_iKind]);		/* 2009.09.04 Add Stop */
			}
			BoardRateFlag= MAX_BOADRATE_CNT;
		}
		break;
	default:
/*		RsModeSet(Kind,RS_INIT,Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed, Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1, Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity);*/
		RsModeSetChanel(Kind,&Set.Ch2_Serial_Param[Set.Ch2_iKind]);		/* 2009.09.04 Add Stop */
		break;
	}
	if((Set.Ch1_iKind == EDITER) || (Set.Ch2_iKind == EDITER)){
		BoardRateFlag= 0;
		BoardRateChangingFlag= 0;
		PlcConnectFlag= 0;
	}else{
		BoardRateFlag= MAX_BOADRATE_CNT;
	}
}
/****************************************************
*   FUNC  : Rts ON/OFF                              *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
void	Sio1RtsOn(void)
{
	rUMCON1 = 0x0001;
}
void	Sio1RtsOff(void)
{                    
	rUMCON1 = 0x0000;
}

/****************************************************
*   FUNC  : Sio1 Error Handler                      *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
int	_Sci1ERProc( void )
{
	volatile unsigned	status;
	
	status= rUERSTAT1;
    if((status & 0x07) == 0){
    }else{      /* Error */
		/* �V�X�e?�C���t�H��?�V������ݒ肷�� */
		if((status & 0x01) != 0){			/* Overrun */
			InDevArea.UW[5] |= 0x2000;
		}
		if((status & 0x04) != 0){			/* Framing */
			InDevArea.UW[5] |= 0x0800;
		}
		if((status & 0x02) != 0){			/* Parity */ 
			InDevArea.UW[5] |= 0x1000;
		}
		if(Init232CFlag == 1){
			return(-1);
		}
    }
	return(-1);
}
#ifdef	WIN32
void	_Sci1ERInterruptHandler( void )
#else
void	__irq _Sci1ERInterruptHandler( void )
#endif
{
//	int	Ret;

	_Sci1ERProc();
    rI_ISPC= rI_ISPC | BIT_UERR01 ;   //clear pending bits,Default value=0x0000000
/*	070917 Fix Boadrate
	if(Ret == 0){
   		_PendingRequest( ID_PAddFlag | PC_MyTaskNo << 16 | 1 );
	}else if(Ret == 1){
   		_PendingRequest( ID_PAddFlag | PLC_MyTaskNo << 16 | 1 );
	}
*/
}
/****************************************************
*   FUNC  : Sio1 Recieve Handler                    *
*	In    :											*
*	Out   : 										*
*   DATE  : 1999.10.01                              *
*****************************************************/
//int	RecError;
//int	StartRecProc;
int	_Sci1RXInterruptProc( void )
{
	int		ret;
    unsigned char rs_input_data;
	int		rCnt;
	int		rc;

	ret = -1;

//	if(Sending232C == ON){
//		RecError++;
//	}
	while(1){
		rCnt= rUFSTAT1 & 0x10f;
		if(rCnt == 0){
			break;
		}
		rs_input_data= Uart1_RxInt();

//		Uart_SendByte1(rs_input_data);
#ifdef	LOG
rs1log[rs1Cnt]= rs_input_data;
rs1SaveCnt = rs1Cnt;
//KSC20090112
//rs1Mtrixlog[rs1Cnt]= Matrix_Mode;
rs1Cnt= (rs1Cnt+ 1) % 2048;
#endif
		if((DModeFlag != 0) && (SioEchoFlag != 0)){		//ECHO OUT
			Uart_SendByte1(rs_input_data);
		}
//		if((BoardRateChangingFlag == 0) && (Sending232C == 0)){
		if(BoardRateChangingFlag == 0){
//			if(Sending232C == OFF){		//070326
				rc= ConnectPc(rs_input_data);
				if(rc < 0){
				}else{
//KSC20090112
//					if(Sending232C == 0){	// Recieve Buff OK
//						memcpy(Sio11RecBuff,Sio1RecBuff,Sio1RecCnt);
//						Sio11RecCnt= Sio1RecCnt;
//						Comm11RecMode= Comm1RecMode;
						SetPC1CharTimeOut(0);		/*20090117*/

						memcpy(Sio11sRecBuff[Sio11BufIdx],Sio1RecBuff,Sio1RecCnt);
						Sio11sRecCnt[Sio11BufIdx]= Sio1RecCnt;
						Comm11sRecMode[Sio11BufIdx]= Comm1RecMode;
						Comm11Result[Sio11BufIdx]= rc;
						Comm11RecKind[Sio11BufIdx]= wCommRecKind;
						Sio11BufIdx= (Sio11BufIdx+1)&1;
						Sio1RecCnt= 0;
						Comm1RecMode= 0;
						RetryCnt= 0;
						ret= 0;
//						CommResult= rc;
//						StartRecProc= 1;
//					}else{
//						RecError++;
//					}
//					break;
				}
//			}
		}
	}
/*	SetPCTimeOut((unsigned int)(_TimeMSec+ 3000)); 061024 */
//	if(BoardRateFlag < MAX_BOADRATE_CNT){
//		SetPCTimeOut(15000);
//	}
	if(Sio1RecCnt > 0){					/*20090117*/
		SetPC1CharTimeOut(3000);		/*20090117*/
	}									/*20090117*/
	return(ret);
}
#ifdef	WIN32
void	_Sci1RXInterruptHandler( void )
#else
void	__irq _Sci1RXInterruptHandler( void )
#endif
{
	int	Ret;

	Ret = _Sci1RXInterruptProc();
	if(Ret == 0){
   		_PendingRequest( ID_PAddFlag | PC_MyTaskNo << 16 | 1 );
	}
    rI_ISPC= rI_ISPC | BIT_URXD1 ;   //clear pending bits,Default value=0x0000000
}
int	_Sci1TXInterruptProc(void)
{
	int		ret;

	ret = -1;
	if(Sio1OutCnt > 0){
		Uart_SendByte1((int)*Sio1OutBuf++);
		Sio1OutCnt--;
	}else{
		while(!(rUTRSTAT1 & 0x4));
		Usrt1TxMode(0);
		ReSetIntMask(BIT_UTXD1);
		if(Sio1OutCnt == 0){
			ret = 0;
//			Sending232C= OFF;		//070326
		}
		Sio1OutCnt--;
	}
	return(ret);
}
#ifdef	WIN32
void	_Sci1TXInterruptHandler( void )
#else
void	__irq _Sci1TXInterruptHandler( void )
#endif
{
	int	Ret;

	Ret = _Sci1TXInterruptProc();
	if(Ret == 0){
   		_PendingRequest( ID_PAddFlag | PC_MyTaskNo1 << 16 | 1 );
	}
    rI_ISPC= rI_ISPC | BIT_UTXD1 ;   //clear pending bits,Default value=0x0000000
}
/************************************************************/
/*	�P�������M												*/
/************************************************************/
int Sio1SendChar( unsigned char ch )
{
	Uart_SendByte1(ch);
	return( TRUE );
}
void	SendPCData( unsigned char *SendBuff,int *SendCommCnt );
int	RP_CommNext(char *buff,char *SndBuff);
void Uart_Printf(char *fmt,...);
/***********************************************************/
void	Sio1RecDrv( STTFrm* pSTT )     /* SIO���M�h���C�o?�X�N */
{
	int		iKind;
#ifdef	LP_S044
//KSC20090112
//	unsigned char	*GlpSendBuff;
	int		GlpSendCnt;
#endif

//	RecError= 0;
	RecTimeOut= 0;
//KSC20090112
	Sio11BufIdx= 0;		//20090112

	BerRecTime= 0;		/* 040608 */	
	CommMode = 0;
	Comm1RecMode = 0;
	CommCnt = 0;
	CommKind = 0;
	CommonArea.PcUpDownMode= 0;		/* DownLoad Mode */
	PcHistryFlag= 0;		/* 021018 */

	DownloadFileInfo= 0;			/* 0:NewFile,1:Openning		*/

	while(1){
		if(TaskStartFlag == ON){
			break;
		}
		Delay(100);
	}

#ifndef	WIN32
/*	Rs232cBordrateOrgSet();	*//* Mode Set */
//	Uart_Init(0,38400);    			// Init UART
//	Uart_Printf("SioInit\r\n");
#endif
#ifndef	WIN32
	_ei();
#endif

	PC_MyTaskNo = _RunTaskNo;
	ClearFlag();
	SetPCTimeOut((unsigned int)0);
	Sio1RecCnt= 0;
	PC_CommMode= 0;
#ifdef	LOG
	rs1Cnt= 0;
#endif
	CommRecKind= 0;
//KSC20090112
	wCommRecKind= 0;


	SetWindowNo(1);


	while(1){
Sending232C= OFF;
#ifdef	WIN32
		while(1){
			if(SioLoopIdx != SioLoopOutIdx){
				memcpy(Sio11RecBuff,SioLoopRecBuff[SioLoopOutIdx],SioLoopRecCnt[SioLoopOutIdx]);
				Comm11RecMode= CommLoopRecMode[SioLoopOutIdx];
				Sio11RecCnt= SioLoopRecCnt[SioLoopOutIdx];
				CommResult= CommLoopResult[SioLoopOutIdx];
				CommRecKind= CommRecKindSave[SioLoopOutIdx];
				SioLoopOutIdx= (SioLoopOutIdx+ 1)%4;
				PcRecData= 0;
				break;
			}
			Delay(20);
		}
#else
		WaitFlag(1);
		//20090112
		if(Sio11BufIdx == 0){
			memcpy(Sio11RecBuff,Sio11sRecBuff[1],Sio11sRecCnt[1]);
			Comm11RecMode= Comm11sRecMode[1];
			Sio11RecCnt= Sio11sRecCnt[1];
			CommResult= Comm11Result[1];
			CommRecKind= Comm11RecKind[1];
		}else{
			memcpy(Sio11RecBuff,Sio11sRecBuff[0],Sio11sRecCnt[0]);
			Comm11RecMode= Comm11sRecMode[0];
			Sio11RecCnt= Sio11sRecCnt[0];
			CommResult= Comm11Result[0];
			CommRecKind= Comm11RecKind[0];
		}
		if(Sio11RecCnt > PLC_BUF_MAX){
			Sio11RecCnt= PLC_BUF_MAX;
		}

#endif
//StartRecProc= 0;
Sending232C= ON;
//		SetPCTimeOut((unsigned int)0);		//20090117
//sprintf(buff,"Comm(%2d)",loop++);
//DotTextOut(10*8,12*16,buff,1,1, TRANS, T_WHITE, T_BLACK);							
//DrawLcdBank1();
		if(Set.Ch1_iConnect == CH_CH1){
			iKind= Set.Ch1_iKind;
		}else{
			iKind= Set.Ch2_iKind;
		}
		if(DModeFlag == 0){
			switch(iKind){
			case UNIVERSAL:		/* �ėp�ʐM */
				if(CommonArea.PcUpDownMode != 0){		/* 081024 */
					break;
				}
				CommMode= Comm11RecMode;
				memcpy(CommBuff,Sio11RecBuff,Sio11RecCnt);
				RecCommCnt= Sio11RecCnt;
				HanyouComm((char *)CommBuff,RecCommCnt,(char *)SendBuff,(int *)&SendCommCnt);
				if(SendCommCnt != 0){
					SendPLCData(SendBuff,(int *)&SendCommCnt);
				}
				break;
			case DEFAULT_PLC:						/* FX-PLC */
				if(CommonArea.PcUpDownMode != 0){		/* 081024 */
					break;
				}
				if(Def_Get_Ms_Sel() == 1){		/* MASTER */
					AddFlag(PC_MyTaskNo1,1);
				}else{
					CommMode= Comm11RecMode;
					memcpy(CommBuff,Sio11RecBuff,Sio11RecCnt);
					RecCommCnt= Sio11RecCnt;
					LG_PLCFxThruProc((char *)CommBuff,(int *)&RecCommCnt,(char *)PlcThrueBuff,(int *)&PlcThrueCnt,PlcConnectFlag,PlcType);
				}
				break;
			case ELSE_PLC:					/* ���̑� */
				if(CommonArea.PcUpDownMode != 0){		/* 081024 */
					break;
				}
				if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
					if((GET_MS_SEL() & 0x00ff) == 1){			/* MASTER */
						AddFlag(PC_MyTaskNo1,1);
					}else{
						CommMode= Comm11RecMode;
						memcpy(CommBuff,Sio11RecBuff,Sio11RecCnt);
						RecCommCnt= Sio11RecCnt;
						PLC_THRU_PROC((char *)CommBuff,(int *)&RecCommCnt,(char *)PlcThrueBuff,(int *)&PlcThrueCnt,PlcConnectFlag,PlcType);
					}
				}
				break;
			case EDITER:		/* EDITOR */
				if(CommRecKind != 0){
					CommRecKind= 0;
//				if(IsGlpType() == OK){		//GLP TYPE
#ifdef	LP_S044
//					if(RecError != 0){
//						RecError= 0;
//					}
					GlpTimeout= _TimeMSec;
//KSC20090112
//					GlpSendBuff= (unsigned char*)TakeMemory(sizeof(Sio1SndBuff));
					switch(CommResult){
					case 0:
//						Sio1SndCnt= PlcCommCheck((char *)Sio11RecBuff,(char *)Sio1SndBuff,Sio11RecCnt);
//KSC20090112
//						GlpSendCnt= PlcCommCheck((char *)Sio11RecBuff,(char *)GlpSendBuff,Sio11RecCnt);
						GlpSendCnt= PlcCommCheck((char *)Sio11RecBuff,(char *)Sio11SndBuff,Sio11RecCnt);
						Sending232C= OFF;
						if(GlpSendCnt > 0){
							if(GlpSendCnt < PLC_BUF_MAX){
								Sio11SndCnt= GlpSendCnt;						//For Retry		2008.12.08
//KSC20090112
//								memcpy(Sio11SndBuff,GlpSendBuff,Sio11SndCnt);	//For Retry		2008.12.08
								SendPCData(Sio11SndBuff,(int *)&GlpSendCnt);
							}
						}else if(GlpSendCnt == 0){
							//ACK���M
//KSC20090112
							Sio11SndBuff[4]= ACK;
							GlpSendCnt= 5;
							SendPCData(Sio11SndBuff,(int *)&GlpSendCnt);
						}else{
							//NAK���M
//KSC20090112
							Sio11SndBuff[4]= NAK;
							GlpSendCnt= 5;
							SendPCData(Sio11SndBuff,(int *)&GlpSendCnt);
						}
						break;
					case 1:		/* ACK��M */
//						Sio1SndCnt= RP_CommNext((char *)Sio11RecBuff,(char *)Sio1SndBuff);
//KSC20090112
						GlpSendCnt= RP_CommNext((char *)Sio11RecBuff,(char *)Sio11SndBuff);
						Sending232C= OFF;
						if(GlpSendCnt > 0){
//KSC20090112
							SendPCData(Sio11SndBuff,(int *)&GlpSendCnt);
						}
						break;
					case 2:		/* NAK��M */
						if(RetryCnt++ < 3){
//KSC20090112
//							memcpy(GlpSendBuff,Sio11SndBuff,Sio11SndCnt);
							GlpSendCnt= Sio11SndCnt;
//KSC20090112
							SendPCData(Sio11SndBuff,(int *)&GlpSendCnt);
						}
						break;
					case 3:		/* �P�������M */
//KSC20090112
						memcpy(Sio11SndBuff,Sio1SndBuff,Sio1SndCnt);
						GlpSendCnt= Sio1SndCnt;
//KSC20090112
						SendPCData(Sio11SndBuff,(int *)&GlpSendCnt);
						Sio1SndCnt= 0;
						break;
					default:
						break;
					}
//KSC20090112
//					FreeMail((char *)GlpSendBuff);
//					ClearFlag();
#endif
				}else{
					CommMode= Comm11RecMode;
					if(Sio11RecCnt != 0){
						memcpy(CommBuff,Sio11RecBuff,Sio11RecCnt);
					}
					RecCommCnt= Sio11RecCnt;
					PC_CommProc();		/* DownLoad & UpLoad */
				}
				break;
			case MONITOR:
				CommMode= Comm11RecMode;
				if(Sio11RecCnt != 0){
					memcpy(CommBuff,Sio11RecBuff,Sio11RecCnt);
				}
				RecCommCnt= Sio11RecCnt;
				PC_CommProc();		/* DownLoad & UpLoad */
				break;
			case BAR_CODE:	/* BarCode */
				BarcodeIn((char *)Sio11RecBuff);
				break;
			case PLCTYPE2:	/* PLC Type2 */
				AddFlag(PC_MyTaskNo1,1);
				break;
			}
		}else{
/* 20081002 */
			if(iKind == EDITER){		/* 2008.09.18 */
				CommMode= Comm11RecMode;
				memcpy(CommBuff,Sio11RecBuff,Sio11RecCnt);
				RecCommCnt= Sio11RecCnt;
				DebugSend();
			}
		}
	}
}
extern	void	Tx1DMAStart(unsigned char *SendAddr,int cnt);
void	Sio1Drv( STTFrm* pSTT )     /* SIO���M�h���C�o?�X�N */
{
	T_MAIL	*pMail;
	int		ret;
	extern	int	ConnectMode;
#ifndef	WIN32
#ifdef	SIO_SENSE
	int		i;
#endif
#ifdef	LOG
	int		i;
#endif
#endif

	PC_MyTaskNo1 = _RunTaskNo;

#ifndef	WIN32
	_ei();
#endif
#ifdef	LOG
//	rs1OutCnt= 0;
#endif
	ClearFlag();
	Sio1OutCnt = -1;
	ConnectMode= 0;
	Sio1SndCnt= 0;
	Init232CFlag= 0;		//061228
	Sio11SndCnt= 0;
	while(1){
//		Sending232C= OFF;
		pMail = (T_MAIL *)WaitRequest();
		switch(pMail->mcmd){
		case RS_CNTL:			/* Control */
			switch(pMail->mext){
			case RS_INIT:		/* Initial */
				InitSci1(pMail->mpar,pMail->mpec,pMail->mcod);
				break;
			case RS_RTSON:		/* RTS ON */
				Sio1RtsOn();
				break;
			case RS_RTSOFF:		/* RTS OFF */
				Sio1RtsOff();
				break;
			}
			pMail->mpec = 0;
			break;
		case RS_SEND:					/* ���M */
//			Sending232C= ON;
			ClearFlag();
#ifdef	WIN32
			extern	int	PcSndData;		//20090827	add
			PcRecData= 0;
			while(1){
//				if(Sio11SndCnt == 0){	
				if(PcSndData == 0){		//20090827	modification
					break;
				}
				Delay(20);
			}
			memcpy(Sio11SndBuff,(char *)pMail->mptr,pMail->mpar);
			Sio11SndCnt = pMail->mpar;
			PcSndData= 1;			//20090827 add
			SetTimeOut(500);		/* 500ms */
			ret = WaitFlag(1);		/*  */
#else
			Comm1RecMode= 0;
//			Sending232C= ON;		//070326
			//Retry Data Save
			memcpy(Sio11SndBuff,(char *)pMail->mptr,pMail->mpar);
			Sio1OutCnt = pMail->mpar;
			Sio1OutBuf = (char *)Sio11SndBuff;
#ifdef	SIO_SENSE
			for(i= 0; i < pMail->mpar; i++){
				Sio1SendChar(*Sio1OutBuf++);
			}
			ret= 0;
#endif
#ifdef	LOG
for(i= 0; i < pMail->mpar; i++){
//rs1Outlog[rs1OutCnt]= Sio1OutBuf[i];
//rs1OutCnt= (rs1OutCnt+ 1) % 1024;
rs1log[rs1Cnt]= Sio1OutBuf[i];
rs1Cnt= (rs1Cnt+ 1) % 2048;
}
//rs1SaveOutCnt = rs1OutCnt;
#endif
#ifdef	SIO_INTRUPT
			if(Sio1OutCnt == 1){
				Usrt1TxMode(1);				//20081108
				Sio1SendChar(*Sio1OutBuf++);
				Sio1OutCnt--;
				ret= 0;						//20081108
				while(!(rUTRSTAT1 & 0x4));	//20081108
				Usrt1TxMode(0);				//20081108
			}else{
//				Sio1OutCnt--;
//				Sio1SendChar(*Sio1OutBuf++);
				Usrt1TxMode(1);
				SetIntMask(BIT_UTXD1);
				SetTimeOut(500);		/* 500ms */
				ret= WaitFlag(1);
			}
#endif
#endif
			pMail->mpec = 0;		//2008.05.26
			if((ret == 0) && (pMail->mext != 0)){				/* Recieve Wait */
#ifndef	WIN32
				SetTimeOut(pMail->mwrk);		/* (3s) */
				ret = WaitFlag(1);		/*  */
				if((ret == 0) && (CommonArea.PcUpDownMode == 0)){		/* 070205 */
#else
				if(CommonArea.PcUpDownMode == 0){		/* 070205 */
#endif
					switch(pMail->mext){
					case 1:		/* ACK */
						if(Sio11RecBuff[0] != ACK){
							pMail->mpec = (unsigned short)-1;
						}
						break;
					case 2:		/* DaTa Rec */
						pMail->mptr = Sio11RecBuff;
						pMail->mext = Sio11RecCnt;
						pMail->mpec = 0;
						break;
					case 3:		/* ACK & Data */
						if(Sio11RecBuff[0] != ACK){
							pMail->mpec = (unsigned short)-1;
						}else{
							SetTimeOut(pMail->mwrk);		/* Mail Count(500ms) */
#ifndef	WIN32
							ret = WaitFlag(1);		/*  */
#endif
							pMail->mptr = Sio11RecBuff;
							pMail->mext = Sio11RecCnt;
							pMail->mpec = ret;
						}
						break;
					}
				}else{
					pMail->mpec = (unsigned short)-1;
				}
			}else{
				if(ret != 0){	pMail->mpec = (unsigned short)-1;	}
				else{			pMail->mpec = 0;					}
			}
 			break;
		}
		ResponseMail((char *)pMail);
	}
}
