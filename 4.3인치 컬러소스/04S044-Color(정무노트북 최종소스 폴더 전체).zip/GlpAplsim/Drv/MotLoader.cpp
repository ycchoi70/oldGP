#include	"sgt.h"

#define	KEY_START	0x0000000
#define	KEY_END		0x0010000
#define	APL_START	0x00B0000			/* 20090701 */
#define	APL_END		0x0200000
#define	PROG_1_BLOCK	0x00010000

extern	void	TimerStart(int no,int cnt);
extern	void	Wait( int Cnt )			;

extern	int	time_flag[8];
#ifdef	WIN32
/*extern	char	KeyPadArea[0x10000];*/
extern	unsigned char  *gfmbuf;          /*�t���b�V���������̈�  */
#endif

/***********************************************/
/*  16�i�E2�i�ϊ�����   		                  */
/*       1995.11.8                             */
/***********************************************/
extern	unsigned char LHexToBin(char as_data);
/***********************************************/
/*  16�i�E2�i�ϊ�����   		                  */
/*       1995.11.8                             */
/***********************************************/
extern	unsigned int LHexAsToBin(char *buff, int cnt);
extern	void	Bin2Hex2(char data, char *buf);
void	Bin2Hex4(unsigned short data, char *buf)
{
	char	high,low;

	high = (data & 0xff00) >> 8;
	low	= data & 0xff;
	Bin2Hex2(high,buf);
	Bin2Hex2(low,&buf[2]);
}

/***********************************************/
/*  �ް�ں��???��?��?                     */
/*       1995.11.8                             */
/***********************************************/
int	DataSet(char *buff, char *data_adr, int cnt)
{
	int		i;
	
	for(i = 0; i < cnt; i++){
						/* ���ސ� */
		data_adr[i] = (unsigned char)LHexAsToBin(&buff[i*2],2);
	}
	return(0);
}

extern	int Send1Char( unsigned char ch );
extern	void DModeSendPriod( void );
extern	void DModeSendOneMsg( char *ptr );
void	FlashIFProc(char *addr,char *data,int size)
{
#ifdef	WIN32
/*	if(((int)addr >= (int)&gfmbuf[0x30000]) && ((int)addr < (int)&gfmbuf[0x40000])){*/
		memcpy(&GpFont[(int)addr],data,size);	/* 2006.05.19 */
/*	}*/
#else
/*    RamFlashCashWriteProc(addr,data,size);  */  /* 20090630 */
	if((int)addr >= APL_START){		/* 20090701 */
	    RamFlashWriteProc(addr,data,size);
	}
#endif
}

void	FlashCashIFProc(char *addr,char *data,int size)		/* 20090630 */
{
#ifdef	WIN32
/*	if(((int)addr >= (int)&gfmbuf[0x30000]) && ((int)addr < (int)&gfmbuf[0x40000])){*/
		memcpy(&GpFont[(int)addr],data,size);	/* 2006.05.19 */
/*	}*/
#else
    RamFlashCashWriteProc(addr,data,size);

#endif
}
/************************************************/
/* Load the Hex data from RS232C to Flash-ROM	*/
/* Update:97.06.10 kf							*/
/************************************************/
int	HexLoad(void)
{
	int		i;
	char	*data_adr;
	int		len;
	unsigned int	location;
	char	type;
	unsigned int	chksum;
	int		end_flag;
	int		DispCount= 0;	/* 19991118UOI */
#ifndef	WIN32
	int		j;
	char	*mp;
#else
	FILE	*fp;
	FILE	*fpw;
	char	FileName[32];
#endif
	char	*base_adr;
	char *SaveAddr;

#ifdef	WIN32
		sprintf(FileName,"KeyPad.mot");
		fp= fopen(FileName,"r");
		if(fp == NULL){
			return(-1);
		}
#endif
		SaveAddr= (char *)TakeMemory(0x10000);
		base_adr = (char *)0xffffffff;
		location = 0;
		end_flag = 0;				/* End Flag */
		DModeSendOneMsg("START");
		while(end_flag == 0){
#ifdef	WIN32
			if(fp == NULL){
				break;
			}
			if(fgets(Hexbuff,sizeof(Hexbuff),fp)== 0){
				break;
			}
			i= strlen(Hexbuff);
			Hexbuff[i-1]= 0;
#else
			SetTimeOut(30000);		/* 30�b */
			mp= WaitRequest();
			if((int)mp == R_TimeOut){
				break;
			}
			for(i = 0; i < (int)strlen(mp); i++){
				if(mp[i] == 'S'){
					break;
				}
			}
			if(i >= (int)strlen(mp)){
				ResponseMail(mp);
				continue;
			}
			for(j= 0; (i < (int)strlen(mp)) && (i < 256); i++){
				Hexbuff[j++]= mp[i];
				if(mp[i] == 0x0d){
					break;
				}
			}
			Hexbuff[j++]= 0;
			ResponseMail(mp);
#endif
			if((DispCount++ % 100) == 0){
				DModeSendPriod();
			}
									/* ��?����? */
			len = strlen(Hexbuff);
			chksum = 0;
			for(i = 0; i < len/2 - 1; i++){
				chksum += LHexAsToBin(&Hexbuff[i*2+2],2);
			}
			if((chksum & 0xff) != 0xff){
				break;			/*��?�Ѵ�?*/
			}
			len = LHexAsToBin(&Hexbuff[2],2);		/* ���ސ� */
			type = Hexbuff[1];			/* �ް����� */
			switch(type){
			case '1':			/* 2�o�C�g����?*/
				location = LHexAsToBin(&Hexbuff[4],4);
/*				if(((int)location < KEY_START) || ((int)location >= KEY_END)){*/	/* 0x10000< || 0x80000>= */
				if(((int)location < KEY_START) || ((int)location >= APL_END)){	/* 0x10000< || 0x80000>= */
					break;
				}
				if((int)base_adr == 0xffffffff){
					base_adr = (char *)((unsigned int)location & 0xffff0000);
#ifdef	WIN32
					memcpy(SaveAddr,(char *)&GpFont[(int)base_adr],(long)PROG_1_BLOCK);
#else
					memcpy(SaveAddr,(char *)base_adr,(long)PROG_1_BLOCK);
#endif
				}
				if((location >= ((unsigned int)base_adr + PROG_1_BLOCK)) ||
					(location < (unsigned int)base_adr)){				 /* �P�Q�W�j�͈̔͂𒴂��� */
        			FlashCashIFProc((char *)base_adr,SaveAddr,(long)PROG_1_BLOCK);
					memset(SaveAddr,0xff,PROG_1_BLOCK);
					base_adr = (char *)((unsigned int)location & 0xffff0000);
					memcpy(SaveAddr,(char *)base_adr,(long)PROG_1_BLOCK);
				}
	            data_adr = (char *)(location- (unsigned int)base_adr+ (unsigned int)SaveAddr);		/* ���ސ� */
				DataSet(&Hexbuff[8],DataBuf,len - 3);
				memcpy(data_adr,DataBuf,len - 3);
				break;
			case '2':			/* 3�o�C�g����?*/
				location = LHexAsToBin(&Hexbuff[4],6);
/*				if(((int)location < KEY_START) || ((int)location >= KEY_END)){*/	/* 0x10000< || 0x80000>= */
				if(((int)location < KEY_START) || ((int)location >= APL_END)){	/* 0x10000< || 0x80000>= */
					break;
				}
				if((int)base_adr == 0xffffffff){
					base_adr = (char *)(location & 0xffff0000);
#ifdef	WIN32
					memcpy(SaveAddr,(char *)&GpFont[(int)base_adr],(long)PROG_1_BLOCK);
#else
					memcpy(SaveAddr,(char *)base_adr,(long)PROG_1_BLOCK);
#endif
				}
				data_adr = (char *)(location- (unsigned int)base_adr+ (unsigned int)SaveAddr);		/* ���ސ� */
				DataSet(&Hexbuff[10],DataBuf,len - 4);
				memcpy(data_adr,DataBuf,len - 4);
				break;
			case '3':			/* 4�o�C�g����?*/
				location = LHexAsToBin(&Hexbuff[4],8);
/*				if(((int)location < KEY_START) || ((int)location >= KEY_END)){*/	/* 0x10000< || 0x80000>= */
				if(((int)location < KEY_START) || ((int)location >= APL_END)){	/* 0x10000< || 0x80000>= */
					break;
				}
				if((int)base_adr == 0xffffffff){
					base_adr = (char *)((unsigned int)location & 0xffff0000);
#ifdef	WIN32
					memcpy(SaveAddr,(char *)&GpFont[(int)base_adr],(long)PROG_1_BLOCK);
#else
					memcpy(SaveAddr,(char *)base_adr,(long)PROG_1_BLOCK);
#endif
				}
				if((location >= ((unsigned int)base_adr + PROG_1_BLOCK)) ||
					(location < (unsigned int)base_adr)){				 /* �P�Q�W�j�͈̔͂𒴂��� */
        			FlashCashIFProc((char *)base_adr,SaveAddr,(long)PROG_1_BLOCK);
					memset(SaveAddr,0xff,PROG_1_BLOCK);
					base_adr = (char *)(location & 0xffff0000);
					memcpy(SaveAddr,(char *)base_adr,(long)PROG_1_BLOCK);
				}
	            data_adr = (char *)(location- (unsigned int)base_adr+ (unsigned int)SaveAddr);		/* ���ސ� */
				DataSet(&Hexbuff[12],DataBuf,len - 5);
				memcpy(data_adr,DataBuf,len - 5);
				break;
			case '7':	  		/* �I��ں��?*/
			case '8':	  		/* �I��ں��?*/
			case '9':	  		/* �I��ں��?*/
				end_flag = 1;
#ifdef	WIN32
				fpw= fopen("KeyDat.dat","wb");
				if(fpw != NULL){
					fwrite(SaveAddr,1,0x10000,fpw);
					fclose(fpw);
				}
#else
        		FlashCashIFProc((char *)base_adr,SaveAddr,(long)PROG_1_BLOCK);
#endif
				break;
			}
		}
		if(end_flag == 0){
			DModeSendOneMsg("ERROR");
		}
		FreeMail(SaveAddr);
#ifdef	WIN32
		if(fp != NULL){
			fclose(fp);
		}
/*	}*/
#endif
	return(0);
}
/************************************************/
/* Load the Hex data from Editor to Flash-ROM	*/
/************************************************/
int	FontLoad(char *SaveAddr,char **base_adr)
{
	int		i;
	char	*data_adr;
	int		len;
	unsigned int	location;
	char	type;
	unsigned int	chksum;
	int		ret;
	
	ret= OK;
	location = 0;
									/* ��?����? */
	len = strlen(Hexbuff);
	chksum = 0;
	for(i = 0; i < len/2 - 1; i++){
		chksum += LHexAsToBin(&Hexbuff[i*2+2],2);
	}
	if((chksum & 0xff) != 0xff){
		return(ret);			/*��?�Ѵ�?*/
	}
	len = LHexAsToBin(&Hexbuff[2],2);		/* ���ސ� */
	type = Hexbuff[1];			/* �ް����� */
	switch(type){
	case '1':			/* 2�o�C�g����?*/
		location = LHexAsToBin(&Hexbuff[4],4);
		if(((int)location < APL_START) || ((int)location >= APL_END)){	/* 0x10000< || 0x80000>= */
			break;
		}
		if((int)*base_adr == 0xffffffff){
#ifdef	WIN32
			*base_adr = (char *)&GpFont[((unsigned int)location & 0xffff0000)];
#else
			*base_adr = (char *)((unsigned int)location & 0xffff0000);
#endif
			memcpy(SaveAddr,(char *)*base_adr,(long)PROG_1_BLOCK);
		}
#ifdef	WIN32
		if(((int)&GpFont[(int)location] >= (int)((unsigned int)*base_adr + PROG_1_BLOCK)) ||
			((int)&GpFont[(int)location] < (unsigned int)*base_adr)){				 /* �P�Q�W�j�͈̔͂𒴂��� */
        	FlashIFProc((char *)*base_adr,SaveAddr,(long)PROG_1_BLOCK);
			memset(SaveAddr,0xff,PROG_1_BLOCK);
			*base_adr = (char *)&GpFont[((unsigned int)location & 0xffff0000)];
#else
		if((location >= ((unsigned int)*base_adr + PROG_1_BLOCK)) ||
			(location < (unsigned int)*base_adr)){				 /* �P�Q�W�j�͈̔͂𒴂��� */
        	FlashIFProc((char *)*base_adr,SaveAddr,(long)PROG_1_BLOCK);
			memset(SaveAddr,0xff,PROG_1_BLOCK);
			*base_adr = (char *)(location & 0xffff0000);
#endif
			memcpy(SaveAddr,(char *)*base_adr,(long)PROG_1_BLOCK);
		}
#ifdef	WIN32
	    data_adr = (char *)(location- 0xf0000+ (unsigned int)SaveAddr);		/* ���ސ� */
#else
	    data_adr = (char *)(location- (unsigned int)*base_adr+ (unsigned int)SaveAddr);		/* ���ސ� */
#endif
		DataSet(&Hexbuff[8],DataBuf,len - 3);
		memcpy(data_adr,DataBuf,len - 3);
		break;
	case '2':			/* 3�o�C�g����?*/
		location = LHexAsToBin(&Hexbuff[4],6);
		if(((int)location < APL_START) || ((int)location >= APL_END)){	/* 0x10000< || 0x80000>= */
			break;
		}
		if((int)*base_adr == 0xffffffff){
#ifdef	WIN32
			*base_adr = (char *)(location & 0xffff0000);
			memcpy(SaveAddr,(char *)&GpFont[(int)*base_adr],(long)PROG_1_BLOCK);
#else
			*base_adr = (char *)(location & 0xffff0000);
			memcpy(SaveAddr,(char *)*base_adr,(long)PROG_1_BLOCK);
#endif
		}
		if((location >= ((unsigned int)*base_adr + PROG_1_BLOCK)) ||
			(location < (unsigned int)*base_adr)){				 /* �P�Q�W�j�͈̔͂𒴂��� */
        	FlashIFProc((char *)*base_adr,SaveAddr,(long)PROG_1_BLOCK);
			memset(SaveAddr,0xff,PROG_1_BLOCK);
			*base_adr = (char *)(location & 0xffff0000);
#ifdef	WIN32
			memcpy(SaveAddr,(char *)&GpFont[(int)*base_adr],(long)PROG_1_BLOCK);
#else
			memcpy(SaveAddr,(char *)*base_adr,(long)PROG_1_BLOCK);
#endif
		}
		data_adr = (char *)(location- (unsigned int)*base_adr+ (unsigned int)SaveAddr);		/* ���ސ� */
		DataSet(&Hexbuff[10],DataBuf,len - 4);
		memcpy(data_adr,DataBuf,len - 4);
		break;
	case '3':			/* 4�o�C�g����?*/
		location = LHexAsToBin(&Hexbuff[4],8);
		if(((int)location < APL_START) || ((int)location >= APL_END)){	/* 0x10000< || 0x80000>= */
			break;
		}
		if((int)*base_adr == 0xffffffff){
#ifdef	WIN32
			*base_adr = (char *)&GpFont[((unsigned int)location & 0xffff0000)];
#else
			*base_adr = (char *)((unsigned int)location & 0xffff0000);
#endif
			memcpy(SaveAddr,(char *)*base_adr,(long)PROG_1_BLOCK);
		}
#ifdef	WIN32
		if(((int)&GpFont[(int)location] >= (int)((unsigned int)*base_adr + PROG_1_BLOCK)) ||
			((int)&GpFont[(int)location] < (unsigned int)*base_adr)){				 /* �P�Q�W�j�͈̔͂𒴂��� */
        	FlashIFProc((char *)*base_adr,SaveAddr,(long)PROG_1_BLOCK);
			memset(SaveAddr,0xff,PROG_1_BLOCK);
			*base_adr = (char *)&GpFont[((unsigned int)location & 0xffff0000)];
#else
		if((location >= ((unsigned int)*base_adr + PROG_1_BLOCK)) ||
			(location < (unsigned int)*base_adr)){				 /* �P�Q�W�j�͈̔͂𒴂��� */
        	FlashIFProc((char *)*base_adr,SaveAddr,(long)PROG_1_BLOCK);
			memset(SaveAddr,0xff,PROG_1_BLOCK);
			*base_adr = (char *)(location & 0xffff0000);
#endif
			memcpy(SaveAddr,(char *)*base_adr,(long)PROG_1_BLOCK);
		}
#ifdef	WIN32
		data_adr = (char *)(location+ (unsigned int)SaveAddr);		/* ���ސ� */
#else
	    data_adr = (char *)(location- (unsigned int)*base_adr+ (unsigned int)SaveAddr);		/* ���ސ� */
#endif
		DataSet(&Hexbuff[12],DataBuf,len - 5);
		memcpy(data_adr,DataBuf,len - 5);
		break;
	case '7':	  		/* �I��ں��?*/
	case '8':	  		/* �I��ں��?*/
	case '9':	  		/* �I��ں��?*/
        FlashIFProc((char *)*base_adr,SaveAddr,(long)PROG_1_BLOCK);
		*base_adr = (char *)0xffffffff;
		break;
	}
	return(ret);
}

