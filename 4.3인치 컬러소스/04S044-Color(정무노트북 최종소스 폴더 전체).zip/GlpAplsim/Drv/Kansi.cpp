/************************************/
/*	�Ď��v���O��?					*/
/*	2004.05.25Recipe �C��			*/
/************************************/
#include	"sgt.h"

//#define	READ_DEV_CNT	3			/* Read Area Count */
//#define	WRT_DEV_CNT		13
/*********************************/
//061124
//#define	SIGNAL3		4
#define	SIGNAL3		5
/*********************************/
static	int	TimeswitchFreeMbx;		/* 070918 */

void	SetPCTimeOut(unsigned int sTime)			/* frame Timeout */
{
	if(sTime == 0){				/* 20090701 */
		PcTimeout= sTime;
		SavePcTimeout= _TimeMSec;	/* 061024 */
	}else{
		SavePcTimeout= _TimeMSec;	/* 061024 */
		PcTimeout= sTime;
	}
}
void	SetPC1CharTimeOut(unsigned int sTime)		/* pc 1char Timeout */
{
	if(sTime == 0){				/* 20090701 */
		PcTimeout1Char= sTime;
		SavePcTimeout1Char= _TimeMSec;	/* 061024 */
	}else{
		SavePcTimeout1Char= _TimeMSec;	/* 061024 */
		PcTimeout1Char= sTime;
	}
}
void	SetPC1CharTimeOut0(unsigned int sTime)		/* plc 1char Timeout */
{
	if(sTime == 0){					/* 20090701 */
		PcTimeout1Char0= sTime;
		SavePcTimeout1Char0= _TimeMSec;	/* 061024 */
	}else{
		SavePcTimeout1Char0= _TimeMSec;	/* 061024 */
		PcTimeout1Char0= sTime;
	}
}
/************************************************/
/*	Kansi Hot Clear								*/
/************************************************/
void	KansiHotClear(int mode)
{
	int		i;

	//Protocol Area Initialize20120704
#ifndef	WIN32
	memset((char *)0x407000,0,0x10000);
#endif
	/* Time Switch ON Inf */
	for(i= 0; i < 8; i++){
		CommonArea.SystemDev._TIMESWITCH[i].OnOffFlag= 0;
	}
	/* Observe Inf(Proj) */
	for(i= 0;i < CommonArea.SystemDev.Observe_Proj_Cnt; i++){
		CommonArea.SystemDev.Observe_Proj_Dev[i].Condition= 0;
	}
	/* Observe Inf(SCreen) */
	for(i= 0; i < CommonArea.SystemDev.Observe_Screen_Cnt; i++){
		CommonArea.SystemDev.Observe_Screen_Dev[i].Condition= 0;
	}
	memset(CommonArea.OvservDataProj,0,sizeof(CommonArea.OvservDataProj));
	memset(CommonArea.OvservDataScrren,0,sizeof(CommonArea.OvservDataScrren));
#ifdef	LP_S044
	memset(&InDevArea.UW[0],0,DUMY_DEV*2);		//UW Only
	if(mode == 0){		//Power On Reset
		PlcDeviceClear();							//Plc Device
	}
#endif
#ifdef	GP_S044		/* 20091222 */
	if(Set.iuwLatch == 0){
		memset(&InDevArea.UW[0],0,sizeof(InDevArea));
	}
#endif
#ifdef	GP_S057		/* 20091222 */
	if(Set.iuwLatch == 0){
		memset(&InDevArea.UW[0],0,sizeof(InDevArea));
	}
#endif
}
/************************************************/
/*	Alarm History Proc							*/
/************************************************/
void	ClearHistry(void)
{
	CommonArea.EntryCnt= 0;
	CommonArea.EntryIdx= 0;
	CommonArea.StartIdx= 0;
	CommonArea.AlarmTotalCnt= 0;
	CommonArea.AlarmTotalOnCnt= 0;
	memset(CommonArea.TotalCnt,0,sizeof(CommonArea.TotalCnt));
	memset(CommonArea.DevIdx,0,sizeof(CommonArea.DevIdx));
	memset((char *)&CommonArea.AlarmHistRec,0,sizeof(ALARM_REC));
	memset(CommonArea.SaveAlarm,0x00,sizeof(CommonArea.SaveAlarm));
	memset(CommonArea.AlarmData,0x00,sizeof(CommonArea.AlarmData));
}
void	HotStartCheck(void)
{
	if(strncmp(CommonArea.System,dVersion,6) != 0){
		memset(&CommonArea,0,sizeof(CommonArea));
		memset(&InDevArea,0,sizeof(InDevArea));
		//Commnucation Area Clear
#ifdef	WIN32
		DeviceCnt= 0;
		DeviceCntSys= 0;
		gDeviceCnt= 0;
		gDeviceCntBit= 0;
		gDeviceCntWord= 0;
		memset(gDeviceFlag,0,sizeof(gDeviceFlag));
		memset(DeviceData,0,sizeof(DeviceData));
		memset(DispDeviceData,0,sizeof(DispDeviceData));
		memset(DeviceDataHed,0,sizeof(DeviceDataHed));
#else
/* 20080822 ���������� �޸� �۾� ������ �ʱ�ȭ */
		memset((char *)0x407000,0,0x10000);
#endif
		strncpy(CommonArea.System,dVersion,6);
#ifdef	LP_S044
		PlcSpDeviceClear();	//���ꃌ�W�X??�N���A
#endif
	}else{
		KansiHotClear(0);		/* Kansi Info Clear */
	}
}
/*********************************/
/*	Alarm History Delete         */
/*********************************/
void	ClearHistryOffDev(void)
{
	int		i;
	int		idx;
	int		sidx;
	int		sCnt;

	sCnt= 0;
	sidx= CommonArea.StartIdx;
	idx= CommonArea.StartIdx;
	for(i= 0;i < CommonArea.EntryCnt; i++){
		/* Device ON */
		if(CommonArea.AlarmHistRec[idx].flag == 0){
			CommonArea.DevIdx[CommonArea.AlarmHistRec[idx].DevNo]= sidx;
			memcpy((char *)&CommonArea.AlarmHistRec[sidx++],
				(char *)&CommonArea.AlarmHistRec[idx],sizeof(ALARM_REC));
			sCnt++;
			if(sidx > 1023){
				sidx= 0;
			}
		}else{
			/* Alarm ON-OFF */
/* 050823			CommonArea.TotalCnt[CommonArea.AlarmHistRec[idx].DevNo]--;*/
		}
		idx++;
		if(idx > 1023){
			idx= 0;
		}
	}
	CommonArea.EntryCnt= sCnt;
	CommonArea.EntryIdx= sidx;
	CommonArea.AlarmTotalCnt= sCnt;
	CommonArea.AlarmTotalOnCnt= sCnt;
}
void	DeleteHistry(int didx)
{
	int		idx;
	int		chkIdx;

	idx= didx;
	chkIdx= CommonArea.EntryIdx- 1;
	if(chkIdx < 0){
		chkIdx= 1023;
	}
	/* History Data Del */
/* 050823	CommonArea.TotalCnt[CommonArea.AlarmHistRec[idx].DevNo]--;*/
	while(1){
		if(idx == chkIdx){
			break;
		}
		if(idx < 1023){
			memcpy((char *)&CommonArea.AlarmHistRec[idx],
				(char *)&CommonArea.AlarmHistRec[idx+ 1],sizeof(ALARM_REC));
		}else{
			memcpy((char *)&CommonArea.AlarmHistRec[idx],
				(char *)&CommonArea.AlarmHistRec[0],sizeof(ALARM_REC));
		}
		if(CommonArea.AlarmHistRec[idx].flag == 0){
			CommonArea.DevIdx[CommonArea.AlarmHistRec[idx].DevNo]= idx;
		}
		idx++;
		if(idx > 1023){
			idx= 0;
		}
	}
	/* Count Dec */
	CommonArea.EntryCnt--;
	CommonArea.EntryIdx--;
	if(CommonArea.EntryIdx < 0){
		CommonArea.EntryIdx= 1023;
	}
	/* Save Index Dec */
}
void	ResetHistryDev(int didx)
{
	DEV_DATA DevInfo;
	char	data;

	data= 0;
	memcpy(DevInfo.DevName,CommonArea.SystemDev.Alarm_Dev.DevName,3);
	DevInfo.DevAddress= CommonArea.SystemDev.Alarm_Dev.DevAdd+
		CommonArea.AlarmHistRec[didx].DevNo;
	DevInfo.DevCnt= 1;
	DevInfo.DevFlag= DEVICE_BIT;
	data= 0;
	DevInfo.DevData= &data;
	PLCWrite(&DevInfo);
}
/*********************************/
/*	Alarm History Device Entry   */
/*********************************/
void	SetAlarmHistDev( int mode )
{
	if(CommonArea.SystemDev.Alarm_Dev.DevCnt > 0){
		if(CommonArea.SystemDev.AlarmSetFlag == 0){
			memcpy(CommonArea.AlarmData,CommonArea.SaveAlarm,sizeof(CommonArea.AlarmData));
		}else{
			CommonArea.SystemDev.AlarmSetFlag = 0;
			ClearHistry();
		}
		if(mode == 1){
			CommonArea.AlarmHistDelDat= 0;
			CommonArea.sAlarmHistDelDat= 0;
		}
		DeviceDataSys[DeviceCntSys].DevFlag = 0;
		DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.Alarm_Dev.DevName[0];
		DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.Alarm_Dev.DevName[1];
		DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.Alarm_Dev.DevAdd;
		DeviceDataSys[DeviceCntSys].DevCnt = CommonArea.SystemDev.Alarm_Dev.DevCnt;
		DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.AlarmData[0];
		DeviceCntSys++;
		if(CommonArea.SystemDev.Alarm_DevErase.DevName[0] != 0){
			DeviceDataSys[DeviceCntSys].DevFlag = 0;
			DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.Alarm_DevErase.DevName[0];
			DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.Alarm_DevErase.DevName[1];
			DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.Alarm_DevErase.DevAdd;
			DeviceDataSys[DeviceCntSys].DevCnt = 1;
			DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.AlarmHistDelDat;
			DeviceCntSys++;
		}
	}
}
void	FloatingAlarmOpenClose( int mode )
{
	T_MAIL	*mp;

	mp= (T_MAIL *)TakeMail();
	mp->mcmd= mode;		/* Open */
	mp->mcod= CommonArea.SystemDev.fFont_H;
	mp->mpec= CommonArea.SystemDev.fFont_V;
	SendMail(T_MSG_TASK,(char *)mp);
}
/*****************************************/
/*	FloatingAlarm Device Entry			 */
/*****************************************/
void	SetfAlarmHistDev( int mode )
{
	if((CommonArea.SystemDev.fAlarm_Dev.DevCnt > 0) && 
		(CommonArea.SystemDev.fAlarm_Dev.DevName[0] != 0)){
		if(mode == 1){
			memset(CommonArea.fSaveAlarm,0x00,sizeof(CommonArea.fSaveAlarm));
			memset(CommonArea.fAlarmData,0x00,sizeof(CommonArea.fAlarmData));
		}
		DeviceDataSys[DeviceCntSys].DevFlag = 0;
		DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.fAlarm_Dev.DevName[0];
		DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.fAlarm_Dev.DevName[1];
		DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.fAlarm_Dev.DevAdd;
		DeviceDataSys[DeviceCntSys].DevCnt = CommonArea.SystemDev.fAlarm_Dev.DevCnt;
		DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.fAlarmData[0];
		DeviceCntSys++;
	}
}
/****************************************/
/*	Recipe Device Entry					*/
/****************************************/
void	SetRecipeDevEntry( int mode )
{
	if(CommonArea.SystemDev.RecipCnt != 0){		/* Recipe ON */
		if(mode == 1){
			CommonArea.rRecipeData= 0;
			CommonArea.rSaveRecipeData= 0;
			CommonArea.wRecipeData= 0;
			CommonArea.wSaveRecipeData= 0;
		}
		if(CommonArea.SystemDev.Recip_Write_DevName[0] != 0){
			DeviceDataSys[DeviceCntSys].DevFlag = 0;
			DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.Recip_Write_DevName[0];
			DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.Recip_Write_DevName[1];
			DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.Recip_Write_DevAdd;
			DeviceDataSys[DeviceCntSys].DevCnt = 1;
			DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.wRecipeData;
			DeviceCntSys++;
		}
		if(CommonArea.SystemDev.Recip_Read_DevName[0] != 0){		/* Recipe Read Use */
			DeviceDataSys[DeviceCntSys].DevFlag = 0;	/* Byte */
			DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.Recip_Read_DevName[0];
			DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.Recip_Read_DevName[1];
			DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.Recip_Read_DevAdd;
			DeviceDataSys[DeviceCntSys].DevCnt = 1;
			DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.rRecipeData;
			DeviceCntSys++;
		}
	}
}
/****************************************/
/*	Read Device Entry					*/
/****************************************/
void	SetReadDevEntry( int mode )
{
	if(mode == 1){
		CommonArea.BackLightData= 0;		/* BackLit */
		CommonArea.AlarmHistData= 0;		/* Alarm History */
		//061124
//		memset(CommonArea.ReadDevData,0,sizeof(CommonArea.ReadDevData));
		memset(CommonArea.Read.ReadDevData,0,sizeof(CommonArea.Read.ReadDevData));
	}
	if(CommonArea.SystemDev.Read_Dev.DevCnt != 0){		/* Read Sevice ON */
		DeviceDataSys[DeviceCntSys].DevFlag = 1;		/* Word */
		DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.Read_Dev.DevName[0];
		DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.Read_Dev.DevName[1];
		DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.Read_Dev.DevAdd;
/*		DeviceDataSys[DeviceCntSys].DevCnt = CommonArea.SystemDev.Read_Dev.DevCnt;*/
		DeviceDataSys[DeviceCntSys].DevCnt = READ_DEV_CNT;
/*		DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.ReadDevData[0];*/
		DeviceDataSys[DeviceCntSys].DevData = (char *)&InDevArea.UW[INDEV_READ];
		DeviceCntSys++;
	}
}
/****************************************/
/*	PassWoord Device Entry				*/
/****************************************/
void	SetPasswordDevEntry( void )
{
	if(CommonArea.SystemDev.Password_Dev.DevName[0] != 0){		/* Read Sevice ON */
		DeviceDataSys[DeviceCntSys].DevFlag = 1;		/* Word */
		DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.Password_Dev.DevName[0];
		DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.Password_Dev.DevName[1];
		DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.Password_Dev.DevAdd;
		DeviceDataSys[DeviceCntSys].DevCnt = 1;
		DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.PassWordDevData[0];
		DeviceCntSys++;
	}
}
/****************************************/
/*	Switching Screen Device Entry		*/
/****************************************/
void	SetSwitchingScreenDev( void )
{
	if(CommonArea.SystemDev.Switch_Base_DevName[0] != 0){
/*		memset(CommonArea.SwitchingData,0,sizeof(CommonArea.SwitchingData));*/
		DeviceDataSys[DeviceCntSys].DevFlag = 1;		/* Word */
		DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.Switch_Base_DevName[0];
		DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.Switch_Base_DevName[1];
		DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.Switch_Base_DevAdd;
		DeviceDataSys[DeviceCntSys].DevCnt = 1;
		DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.SwitchingData[0];
		DeviceCntSys++;
	}
	if(CommonArea.SystemDev.Switch_Over1_DevName[0] != 0){
		DeviceDataSys[DeviceCntSys].DevFlag = 1;		/* Word */
		DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.Switch_Over1_DevName[0];
		DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.Switch_Over1_DevName[1];
		DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.Switch_Over1_DevAdd;
		DeviceDataSys[DeviceCntSys].DevCnt = 1;
		//061124
//		DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.SwitchingData[2];
		DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.SwitchingData[1];
		DeviceCntSys++;
	}
	if(CommonArea.SystemDev.Switch_Over2_DevName[0] != 0){
		DeviceDataSys[DeviceCntSys].DevFlag = 1;		/* Word */
		DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.Switch_Over2_DevName[0];
		DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.Switch_Over2_DevName[1];
		DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.Switch_Over2_DevAdd;
		DeviceDataSys[DeviceCntSys].DevCnt = 1;
		//061124
//		DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.SwitchingData[4];
		DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.SwitchingData[2];
		DeviceCntSys++;
	}
}
/****************************************/
/*	Observe Device Entry				*/
/****************************************/
int		ObservProjCnt;
int		ObservScreenCnt;
DEV_DATA	*ObservProjDev;
DEV_DATA	*ObservScreenDev;
void	SetObserveDevEntry( int mode )
{
	int	i;
	
	/* Project */
	if(mode == 1){
		memset(CommonArea.OvservDataProj,0,sizeof(CommonArea.OvservDataProj));
		memset(CommonArea.OvservDataScrren,0,sizeof(CommonArea.OvservDataScrren));
		/* Observe Inf(Proj) */
		for(i= 0;i < CommonArea.SystemDev.Observe_Proj_Cnt; i++){
			CommonArea.SystemDev.Observe_Proj_Dev[i].Condition= 0;
		}
		/* Observe Inf(SCreen) */
		for(i= 0; i < CommonArea.SystemDev.Observe_Screen_Cnt; i++){
			CommonArea.SystemDev.Observe_Screen_Dev[i].Condition= 0;
		}
	}
	ObservProjCnt= 0;
	ObservScreenCnt= 0;
	if(CommonArea.SystemDev.Observe_Proj_Cnt != 0){		/* Project Observe */
		for(i= 0;i < CommonArea.SystemDev.Observe_Proj_Cnt; i++){
			if(CommonArea.SystemDev.Observe_Proj_Dev[i].Dev1Inf != 0){
				CommonArea.SystemDev.Observe_Proj_Dev[i].Dev1Inf= 1;
			}
			if(CommonArea.SystemDev.Observe_Proj_Dev[i].DevName2[0] != 0){
				if(CommonArea.SystemDev.Observe_Proj_Dev[i].Dev2Inf != 0){
					CommonArea.SystemDev.Observe_Proj_Dev[i].Dev2Inf= 1;
				}
			}
		}
	}
	if(CommonArea.SystemDev.Observe_Screen_Cnt != 0){		/* Project Observe */
		for(i= 0;i < CommonArea.SystemDev.Observe_Screen_Cnt; i++){
			if(CommonArea.SystemDev.Observe_Screen_Dev[i].Dev1Inf != 0){
				CommonArea.SystemDev.Observe_Screen_Dev[i].Dev1Inf= 1;
			}
			if(CommonArea.SystemDev.Observe_Screen_Dev[i].DevName2[0] != 0){
				if(CommonArea.SystemDev.Observe_Screen_Dev[i].Dev2Inf != 0){
					CommonArea.SystemDev.Observe_Screen_Dev[i].Dev2Inf= 1;
				}
			}
		}
	}
}
/*****************************************/
/*	Alarm List Device Entry				 */
/*****************************************/
void	SetAlarmListDev( int mode )
{
	int		i;

	if(CommonArea.SystemDev.lAlarm_Dev.DevCnt > 0){
//		if(mode == 1){		//2011.09.19
			for(i = 0; i < CommonArea.SystemDev.lAlarm_Dev.DevCnt; i++)
				CommonArea.AlarmListRec[i].OnOff = 0;

			memset(CommonArea.sAlarmListData,0x00,sizeof(CommonArea.sAlarmListData));
			memset(CommonArea.AlarmListData,0x00,sizeof(CommonArea.AlarmListData));
			CommonArea.AlarmlistTotalCnt= 0;
//		}					//2011.09.19
		DeviceDataSys[DeviceCntSys].DevFlag = 0;
		DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.lAlarm_Dev.DevName[0];
		DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.lAlarm_Dev.DevName[1];
		DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.lAlarm_Dev.DevAdd;
		DeviceDataSys[DeviceCntSys].DevCnt = CommonArea.SystemDev.lAlarm_Dev.DevCnt;
		DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.AlarmListData[0];
		DeviceCntSys++;
	}
	if(CommonArea.SystemDev.Trand_Dev.DevCnt > 0){
		DeviceDataSys[DeviceCntSys].DevFlag = 1;
		DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.Trand_Dev.DevName[0];
		DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.Trand_Dev.DevName[1];
		DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.Trand_Dev.DevAdd;
		if(CommonArea.SystemDev.TrandWordCnt == 0){
			DeviceDataSys[DeviceCntSys].DevCnt = CommonArea.SystemDev.Trand_Dev.DevCnt;
		}else{
			DeviceDataSys[DeviceCntSys].DevCnt = CommonArea.SystemDev.Trand_Dev.DevCnt*2;
		}
		DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.TrandDevData[16][0];
		DeviceCntSys++;
		if(TrendClerFlag == 0){
			CommonArea.SystemDev.TrandStartIdx= 0;
			CommonArea.SystemDev.TrandEntryCnt= 0;
			CommonArea.SystemDev.TrandEntryIdx= 0;
			memset(&CommonArea.TrandDevData[16][0],0,16);
		}
	}
}
/*****************************************/
/*	Stored Mem State Device Entry		 */
/*****************************************/
void	SetAlarmListStoredDev( int mode )
{
	int		i;
	int		j;

	for(i= 0; i < CommonArea.SystemDev.StoredMemCnt; i++){
		if(CommonArea.SystemDev.StoredInfo[i].Kind == 0){		/* Alarm */
			if(CommonArea.SystemDev.StoredInfo[i].St.AlarmInfo.AlarmDevCnt > 0){
				DeviceDataSys[DeviceCntSys].DevFlag = 0;
				DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.StoredInfo[i].St.AlarmInfo.StorelAlarm.DevName[0];
				DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.StoredInfo[i].St.AlarmInfo.StorelAlarm.DevName[1];
				DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.StoredInfo[i].St.AlarmInfo.StorelAlarm.DevAdd;
				DeviceDataSys[DeviceCntSys].DevCnt = CommonArea.SystemDev.StoredInfo[i].St.AlarmInfo.StorelAlarm.DevCnt;
				DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.AlarmListStoreData[i][0];
				DeviceCntSys++;
			}
			if(mode == 1){
				for(j = 0; j < CommonArea.SystemDev.StoredInfo[i].St.AlarmInfo.AlarmDevCnt; j++)
					CommonArea.StordMem[i].Alarm.StoreAlarmListRec[j].OnOff = 0;
				
				CommonArea.StordMem[i].Alarm.TotalCnt= 0;
				memset(&CommonArea.sAlarmListStoreData[i],0x00,256);
				memset(&CommonArea.AlarmListStoreData[i],0x00,256);
			}
		}else{										/* Trande */
			if(CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.Trand_Dev.DevCnt > 0){
				DeviceDataSys[DeviceCntSys].DevFlag = 1;
				DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.Trand_Dev.DevName[0];
				DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.Trand_Dev.DevName[1];
				DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.Trand_Dev.DevAdd;
				if(CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandWordCnt == 0){
					DeviceDataSys[DeviceCntSys].DevCnt = CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.Trand_Dev.DevCnt;
				}else{
					DeviceDataSys[DeviceCntSys].DevCnt = CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.Trand_Dev.DevCnt*2;
				}
				DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.TrandDevData[i][0];
				DeviceCntSys++;
				/* Trand Data Clear Info */
				if(CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandClearMode != 0){
					DeviceDataSys[DeviceCntSys].DevFlag = 0;		/* Bit Dev */
					DeviceDataSys[DeviceCntSys].DevName[0] = CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.Trand_ClrDev.DevName[0];
					DeviceDataSys[DeviceCntSys].DevName[1] = CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.Trand_ClrDev.DevName[1];
					DeviceDataSys[DeviceCntSys].DevAddress = CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.Trand_ClrDev.DevAdd;
					DeviceDataSys[DeviceCntSys].DevCnt = 1;
					DeviceDataSys[DeviceCntSys].DevData = (char *)&CommonArea.TrandDevClrData[i];
					DeviceCntSys++;
				}
			}
			if(mode == 1){
				CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandStartIdx= 0;
				CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandEntryCnt= 0;
				CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandEntryIdx= 0;
				memset(CommonArea.TrandDevClrData,0,sizeof(CommonArea.TrandDevClrData));
				memset(CommonArea.sTrandDevClrData,0,sizeof(CommonArea.sTrandDevClrData));
			}
		}
	}
}
//void	SetUniversal( int mode )
//{
	/* �ėp�ʐM�̕ω��Ď� */
//	if(mode == 1){
//		memcpy(CommonArea.InDeviceSave, &InDevArea.UB[INDEV_UN_B+0x2200],8);
//	}
//}
/****************************************/
/*	System Device Entry					*/
/****************************************/
/*	mode 0:No Clear,1:Clear				*/
/****************************************/
void	SystemDevOnlyEntry( int mode )
{
	DeviceCntSys= 0;
	SetAlarmHistDev(mode);
	SetfAlarmHistDev(mode);
	SetRecipeDevEntry(mode);
	SetReadDevEntry(mode);
	SetPasswordDevEntry();
	SetSwitchingScreenDev();
	SetObserveDevEntry(mode);
	SetAlarmListDev(mode);
	SetAlarmListStoredDev(mode);
/*	SetUniversal(mode);*/
}
void	SortDeviceData(void)
{
	int		i,j;
	int		idx,idx1;
	int		BitCnt;
	int		WordCnt;
	DEV_DATA	*DevHed;

	DevHed= (DEV_DATA *)TakeMemory(sizeof(DeviceDataHed));
	memcpy(DevHed,DeviceDataHed,sizeof(DeviceDataHed));
	/* Sort DEVICE */
	for(i= 0,idx= 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag == 0){
			memcpy(&DevHed[idx++],&DeviceDataSys[i],sizeof(DEV_DATA));
		}
	}
	BitCnt= idx;
	for(i= 0; i < DeviceCntSys; i++){
		if(DeviceDataSys[i].DevFlag == 1){
			memcpy(&DevHed[idx++],&DeviceDataSys[i],sizeof(DEV_DATA));
		}
	}
	WordCnt= idx;
	/* Bit Sort */
	for(i= 0,idx= 0; i < BitCnt; i++){
		for(j= 0; j < BitCnt; j++){
			if(DevHed[j].DevName[0] != (unsigned char)0xff){
				idx1= j;
				j++;
				break;
			}
		}
		for(; j < BitCnt; j++){
			if(DevHed[j].DevName[0] < DevHed[idx1].DevName[0]){
				idx1= j;
			}else if(DevHed[j].DevName[0] == DevHed[idx1].DevName[0]){
				if(DevHed[j].DevAddress < DevHed[idx1].DevAddress){
					idx1= j;
				}
			}
		}
		memcpy(&DeviceDataSys[idx++],&DevHed[idx1],sizeof(DEV_DATA));
		DevHed[idx1].DevName[0]= 0xff;
	}
	/* Word Sort */
	for(i= 0; i < WordCnt; i++){
		for(j= BitCnt; j < DeviceCntSys; j++){
			if(DevHed[j].DevName[0] != (unsigned char)0xff){
				idx1= j;
				j++;
				break;
			}
		}
		for(; j < DeviceCntSys; j++){
			if(DevHed[j].DevName[0] < DevHed[idx1].DevName[0]){
				idx1= j;
			}else if(DevHed[j].DevName[0] == DevHed[idx1].DevName[0]){
				if(DevHed[j].DevAddress < DevHed[idx1].DevAddress){
					idx1= j;
				}
			}
		}
		memcpy(&DeviceDataSys[idx++],&DevHed[idx1],sizeof(DEV_DATA));
		DevHed[idx1].DevName[0]= 0xff;
	}
	FreeMail((char *)DevHed);
}
void	SystemDevEntry( void )
{
	memset(DeviceDataSys,0,sizeof(DeviceDataSys));
	SystemDevOnlyEntry(1);
	if(DeviceCnt != 0){
		/* Device Cnt Check 2008.09.29 */
		if((DeviceCntSys+DeviceCnt) > MAX_DEV_CNT){
			DeviceCnt= MAX_DEV_CNT- DeviceCntSys;
			memcpy(&DeviceDataSys[DeviceCntSys],&DeviceDataHed[0],sizeof(DEV_DATA)*DeviceCnt);
			DeviceCntSys += DeviceCnt;
		}else{		/* 2008.09.29 */
			memcpy(&DeviceDataSys[DeviceCntSys],&DeviceDataHed[0],sizeof(DEV_DATA)*DeviceCnt);
			DeviceCntSys += DeviceCnt;
		}
	}
	SortDeviceData();		/* DEVICE SORT */
/*	OnSignal(SGN_PLC,1);*/
/*	OnSignal(S_PROJECT,1);*/
}
void	SystemDevNoClearEntry( void )
{
	memset(DeviceDataSys,0,sizeof(DeviceDataSys));
	SystemDevOnlyEntry(0);
	if(DeviceCnt != 0){
		/* Device Cnt Check 2008.09.29 */
		if((DeviceCntSys+DeviceCnt) > MAX_DEV_CNT){
			DeviceCnt= MAX_DEV_CNT- DeviceCntSys;
			memcpy(&DeviceDataSys[DeviceCntSys],&DeviceDataHed[0],sizeof(DEV_DATA)*DeviceCnt);
			DeviceCntSys += DeviceCnt;
		}else{		/* 2008.09.29 */
			memcpy(&DeviceDataSys[DeviceCntSys],&DeviceDataHed[0],sizeof(DEV_DATA)*DeviceCnt);
			DeviceCntSys += DeviceCnt;
		}
	}
	SortDeviceData();		/* DEVICE SORT */
/*	OnSignal(SGN_PLC,1);*/
/*	OnSignal(S_PROJECT,1);*/
}
void	SendTimeAction(int p1,int p2,int p3,int p4)
{
	T_MAIL	*mp;

/*	mp= (T_MAIL *)TakeMail();*/
	mp= (T_MAIL *)ReceiveMail(TimeswitchFreeMbx);	/* 070918 */
	mp->mcod= p1;	/* Alarm History Set */
	mp->mext= p2;
	mp->mpar= p3;
	mp->mpec= p4;
	SendMail(T_TIME_PROC,(char*)mp);
}
void	WaitSendTimeAction(int p1,int p2,int p3,int p4)
{
	T_MAIL	*mp;
	int		mbx;
	int		OldResp;

	mbx = TakeMbx();
	mp= (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcod= p1;	/* Alarm History Set */
	mp->mext= p2;
	mp->mpar= p3;
	mp->mpec= p4;
	SendMail(T_TIME_PROC,(char*)mp);
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	FreeMail((char *)mp);
	FreeMbx(mbx);
}
/************************************/
/*  Time Switch ACTION				*/
/*	Recipe ACTION					*/
/*	Alarm History Set				*/
/************************************/
unsigned short ChangeShortLH(unsigned short data)
{
	unsigned short ret;

	ret= data >> 8;
	ret += data << 8;
	return(ret);
}
unsigned long ChangeLongLH(unsigned long data)
{
	unsigned long ret;

	ret= data >> 24;
	ret += (data & 0x00ff0000) >> 8;
	ret += (data & 0x0000ff00) << 8;
	ret += data << 24;
	return(ret);
}
void	ObserveAction(OBS_DEV *ObserveDev,int OnOff)
{
	DEV_DATA DevInfo;
	char	data;
	int		i;
	unsigned short	*Data16;
	unsigned int	*Data32;
	int		ivalue;
	char	*dBuff;
#ifdef	WIN32		//2011.12.08
	unsigned short	*sData16;
	unsigned int	*sData32;
#endif

	switch(ObserveDev->Action){
	case 0:			/* Moment */
		DevInfo.DevName[0]= ObserveDev->DevName3[0];
		dBuff= TakeMemory(ObserveDev->point);
		memset(dBuff,OnOff,ObserveDev->point);
		DevInfo.DevAddress= ObserveDev->DevAdd3;
		DevInfo.DevCnt= ObserveDev->point;
		DevInfo.DevFlag= DEVICE_BIT;
		DevInfo.DevData= dBuff;
		PLCWrite(&DevInfo);
		FreeMail(dBuff);
		break;
	case 1:			/* Set */
		if(OnOff == 1){
			DevInfo.DevName[0]= ObserveDev->DevName3[0];
			dBuff= TakeMemory(ObserveDev->point);
			memset(dBuff,1,ObserveDev->point);
			DevInfo.DevAddress= ObserveDev->DevAdd3;
			DevInfo.DevCnt= ObserveDev->point;
			DevInfo.DevFlag= DEVICE_BIT;
			data= (char)OnOff;
			DevInfo.DevData= dBuff;
			PLCWrite(&DevInfo);
			FreeMail(dBuff);
		}
		break;
	case 2:			/* Reset */
		if(OnOff == 1){
			DevInfo.DevName[0]= ObserveDev->DevName3[0];
			dBuff= TakeMemory(ObserveDev->point);
			memset(dBuff,0,ObserveDev->point);
			DevInfo.DevAddress= ObserveDev->DevAdd3;
			DevInfo.DevCnt= ObserveDev->point;
			DevInfo.DevFlag= DEVICE_BIT;
			data= (char)0;
			DevInfo.DevData= dBuff;
			PLCWrite(&DevInfo);
			FreeMail(dBuff);
		}
		break;
	case 3:			/* Alternate */
		if(OnOff == 1){
			ivalue= ObserveDev->DevAdd3;			/* Bin */
			DevInfo.DevName[0]= ObserveDev->DevName3[0];
			for(i= 0; i < ObserveDev->point; i++){
				DevInfo.DevAddress= ivalue++;
				DevInfo.DevCnt= 1;
				DevInfo.DevFlag= DEVICE_BIT;
				DevInfo.DevData= &data;
				PLCRead(&DevInfo);
				data= (~data & 0x01);
				PLCWrite(&DevInfo);
			}
		}
		break;
	case 4:			/* 16bit */
		if(OnOff == 1){
			Data16= (unsigned short *)TakeMemory(ObserveDev->point*2);
			DevInfo.DevFlag= DEVICE_WORD;
			if(ObserveDev->DevName4[0] == 0){	/* �Œ�l�̂� */
				for(i = 0; i < ObserveDev->point; i++){
					Data16[i]= ObserveDev->FixData;
				}
			}else{
				memcpy(DevInfo.DevName,ObserveDev->DevName4,3);
				DevInfo.DevAddress= ObserveDev->DevAdd4;
				if(ObserveDev->MoveType == 0){		/* FMOVE */
					DevInfo.DevCnt= 1;
					DevInfo.DevData= (char *)Data16;
					PLCRead(&DevInfo);
					for(i = 0; i < ObserveDev->point; i++){
						if(i == 0){
#ifdef	WIN32			//2011.12.08
							Data16[i]= ChangeShortLH(Data16[i]);  /* 20080822 Arm �� �ʿ���� */
#else
							//061124
//							Data16[i]= ChangeShortLH(Data16[i]);  /* 20080822 Arm �� �ʿ���� */
#endif
							Data16[i] += ObserveDev->FixData;
						}else{
							Data16[i]= Data16[0];
						}
					}
				}else{					/* BMOVE */
					DevInfo.DevCnt= ObserveDev->point;
					DevInfo.DevData= (char *)Data16;
					PLCRead(&DevInfo);
					for(i = 0; i < ObserveDev->point; i++){
#ifdef	WIN32			//2011.12.08
						Data16[i]= ChangeShortLH(Data16[i]);	/* 20080822 Arm �� �ʿ���� */
#else
						//061124
//						Data16[i]= ChangeShortLH(Data16[i]);	/* 20080822 Arm �� �ʿ���� */
#endif
						Data16[i] += ObserveDev->FixData;
					}
				}
			}
#ifdef	WIN32
#else
			//061124
//			for(i = 0; i < ObserveDev->point; i++){		/* 20080822 Arm �� �ʿ���� */
//				Data16[i]= ChangeShortLH(Data16[i]);	/* 20080822 Arm �� �ʿ���� */
//			}
#endif
			memcpy(DevInfo.DevName,ObserveDev->DevName3,3);
			DevInfo.DevAddress= ObserveDev->DevAdd3;
			DevInfo.DevCnt= ObserveDev->point;
//061124
#ifdef	WIN32
			sData16= (unsigned short *)TakeMemory(ObserveDev->point*2);
			for(i= 0; i < ObserveDev->point; i++){
				sData16[i]= ((Data16[i] & 0xff) << 8)+ ((Data16[i] & 0xff00) >> 8);
			}
			DevInfo.DevData= (char *)sData16;
//			DevInfo.DevData= (char *)&Data16;
#else
			DevInfo.DevData= (char *)Data16;
#endif
			PLCWrite(&DevInfo);
			FreeMail((char *)Data16);
#ifdef	WIN32
			FreeMail((char *)Data16);
#endif
		}
		break;
	case 5:			/* 32bit */
		if(OnOff == 1){
			Data32= (unsigned int *)TakeMemory(ObserveDev->point*4);
			DevInfo.DevFlag= DEVICE_WORD;
			if(ObserveDev->DevName4[0] == 0){	/* �Œ�l�̂� */
				for(i = 0; i < ObserveDev->point; i++){
					Data32[i]= ObserveDev->FixData;
				}
			}else{
				memcpy(DevInfo.DevName,ObserveDev->DevName4,3);
				DevInfo.DevAddress= ObserveDev->DevAdd4;
				if(ObserveDev->MoveType == 0){		/* FMOVE */
					DevInfo.DevCnt= 2;
					DevInfo.DevData= (char *)Data32;
					PLCRead(&DevInfo);
					for(i = 0; i < ObserveDev->point; i++){
						if(i == 0){
#ifdef	WIN32			//2011.12.08
							Data32[i] = ((Data32[i] & 0xff000000) >> 8)+
										((Data32[i] & 0x00ff0000) << 8)+
										((Data32[i] & 0x0000ff00) >> 8)+
										((Data32[i] & 0x000000ff) << 8);
#else
							//061124
//							Data32[i]= ChangeLongLH(Data32[i]);	/* 20080822 Arm �� �ʿ���� */
							Data32[i]= ((Data32[i] & 0xffff0000) >> 16)+
										((Data32[i] & 0xffff) << 16);
#endif
							Data32[i] += ObserveDev->FixData;
						}else{
							Data32[i]= Data32[0];
						}
					}
				}else{					/* BMOVE */
					DevInfo.DevCnt= ObserveDev->point*2;
					DevInfo.DevData= (char *)Data32;
					PLCRead(&DevInfo);
					for(i = 0; i < ObserveDev->point; i++){
#ifdef	WIN32		//2011.12.08
						Data32[i] = ((Data32[i] & 0xff000000) >> 8)+
									((Data32[i] & 0x00ff0000) << 8)+
									((Data32[i] & 0x0000ff00) >> 8)+
									((Data32[i] & 0x000000ff) << 8);
#else
						//061124
//						Data32[i]= ChangeLongLH(Data32[i]);	/* 20080822 Arm �� �ʿ���� */
						Data32[i]= ((Data32[i] & 0xffff0000) >> 16)+
									((Data32[i] & 0xffff) << 16);
#endif
						Data32[i] += ObserveDev->FixData;
					}
				}
			}
#ifdef	WIN32
#else
			for(i = 0; i < ObserveDev->point; i++){
				//061124
//				Data32[i]= ChangeLongLH(Data32[i]);	/* 20080822 Arm �� �ʿ���� */
				Data32[i]= ((Data32[i] & 0xffff0000) >> 16) + ((Data32[i] & 0xffff) << 16);
			}
#endif
			memcpy(DevInfo.DevName,ObserveDev->DevName3,3);
			DevInfo.DevAddress= ObserveDev->DevAdd3;
			DevInfo.DevCnt= ObserveDev->point*2;
#ifdef	WIN32	//2011.12.08	/* 20080822 Arm �ùķ��̼ǿ����� �ʿ�, S-H�� �ùķ��̼ǰ� ������ Low/High�̹Ƿ� �ʿ����  */
			sData32= (unsigned int *)TakeMemory(ObserveDev->point*4);
			for(i= 0; i < ObserveDev->point; i++){
//				sData32[i] = (Data32[i] & 0xff000000) >> 24;
//				sData32[i] += (Data32[i] & 0x00ff0000) >> 8;
//				sData32[i] += (Data32[i] & 0x0000ff00) << 8;
//				sData32[i] += (Data32[i] & 0x000000ff) << 24;
				sData32[i] = (Data32[i] & 0xff000000) >> 8;
				sData32[i] += (Data32[i] & 0x00ff0000) << 8;
				sData32[i] += (Data32[i] & 0x0000ff00) >> 8;
				sData32[i] += (Data32[i] & 0x000000ff) << 8;
			}
			DevInfo.DevData= (char *)sData32;
#else
			DevInfo.DevData= (char *)Data32;
#endif
			PLCWrite(&DevInfo);
			FreeMail((char *)Data32);
#ifdef	WIN32	//2011.12.08
			FreeMail((char *)sData32);
#endif
		}
		break;
	}
}
void	SendHost(char *buff,int cnt)
{
	int		mbx;
	T_MAIL *mp;
	int		OldResp;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RS_SEND;	/* ���M */
	mp->mpar = cnt;		/* Length */
	mp->mext = 0;		/* Send Only */
	mp->mptr = buff;
	PLCSendProc(mp);
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	FreeMbx(mbx);
	FreeMail((char *)mp);
}
void	SetTotalCnt(DEVICE_TYPE *Device,int cnt)
{
	DEV_DATA	DevInfo;
	char	wdata[8];

	/* Total Cnt Store */
	if(Device->DevName[0] != 0){
		DevInfo.DevFlag= DEVICE_WORD;		/* Word */
		DevInfo.DevName[0]= Device->DevName[0];
		DevInfo.DevName[1]= Device->DevName[1];
		DevInfo.DevAddress= Device->DevAdd;
		//061124
//		wdata[0]= cnt % 256;
//		wdata[1]= cnt / 256;
		wdata[1]= cnt % 256;
		wdata[0]= cnt / 256;
		DevInfo.DevData= (char *)wdata;
		DevInfo.DevCnt= 1;
		PLCWrite(&DevInfo);
	}
}
/********************************************/
/*	Each Proc								*/
/********************************************/
void	Write_WriteDev( void )
{
	DEV_DATA	DevInfo;
/* 2008082 PlcConnectFlag == 1 �� ������ ��ġ�� ȭ����ȯ�� �ӵ��� ���� */
	if((CommonArea.SystemDev.Write_Dev.DevName[0] != 0) && (PlcConnectFlag == 1)){
		memcpy(DevInfo.DevName,CommonArea.SystemDev.Write_Dev.DevName,3);
		DevInfo.DevFlag= DEVICE_WORD;		/* Word */
		DevInfo.DevAddress= CommonArea.SystemDev.Write_Dev.DevAdd;
		DevInfo.DevCnt= WRT_DEV_CNT;
/*		DevInfo.DevData= (char *)CommonArea.WriteDevData;*/
		DevInfo.DevData= (char *)&InDevArea.UW[INDEV_WRITE];
		PLCWriteNoWait(&DevInfo);
	}
}
void	Write_AlarmBit( int mode )
{
	if(mode == 0){		/* OFF */
		//061124
//		InDevArea.UB[INDEV_WRITE+4*2] &= ~W_ALM_ON;
		InDevArea.UW[INDEV_WRITE+4] &= ~W_ALM_ON;
	}else{
//		InDevArea.UB[INDEV_WRITE+4*2] |= W_ALM_ON;
		InDevArea.UW[INDEV_WRITE+4] |= W_ALM_ON;
	}
	Write_WriteDev();
}
void	Write_LowBatteryBit( int mode )
{
	if(mode == 0){	/* OFF */
		//061124
//		InDevArea.UB[INDEV_WRITE+9] &= ~W_LOW_ON;
		InDevArea.UW[INDEV_WRITE+4] &= ~W_LOW_ON;
	}else{			/* ON */
		//061124
//		InDevArea.UB[INDEV_WRITE+9] |= W_LOW_ON;
		InDevArea.UW[INDEV_WRITE+4] |= W_LOW_ON;
	}
	Write_WriteDev();
}
/********************************************/
/*	Recipe Write Proc						*/
/********************************************/
void	WriteRecipeData(int iOffset,char *RecipData)
{
	int		len;
	char	*fRecipWrite;
	unsigned char *wRecipWrite;

	fRecipWrite= TakeMemory(0x10000);
	wRecipWrite= &CommonArea.SystemDev.RecipStart[iOffset];
	iOffset= (int)(&CommonArea.SystemDev.RecipStart[iOffset]) & 0x0ffff;
	wRecipWrite = (unsigned char *)((unsigned int)wRecipWrite & 0xffff0000);
	memcpy(fRecipWrite,wRecipWrite,0x10000);
	if((0x10000- iOffset) < CommonArea.SystemDev.RecipPoint*2){
		len= (0x10000- iOffset);
	}else{
		len= CommonArea.SystemDev.RecipPoint*2;
	}
	memcpy(&fRecipWrite[iOffset],RecipData,len);
#ifdef	WIN32
	memcpy(wRecipWrite,fRecipWrite,0x10000);
#else
	RamFlashEraze((short *)wRecipWrite);
	RamFlashWrite((short *)wRecipWrite,(short *)fRecipWrite,0x10000);
#endif
	if((0x10000- iOffset) < CommonArea.SystemDev.RecipPoint*2){
		iOffset= len;
		len= CommonArea.SystemDev.RecipPoint*2- (0x10000- iOffset);
		wRecipWrite = (unsigned char *)((unsigned int)wRecipWrite + 0x10000);
		memcpy(fRecipWrite,wRecipWrite,0x10000);
		memcpy(&fRecipWrite,&RecipData[iOffset],len);
#ifdef	WIN32
		memcpy(wRecipWrite,fRecipWrite,0x10000);
#else
		RamFlashEraze((short *)wRecipWrite);
		RamFlashWrite((short *)wRecipWrite,(short *)fRecipWrite,0x10000);
#endif
	}
	FreeMail(fRecipWrite);
}
/**********************************************************/
void	WriteRecipLast(void)
{
	int idx,i;
	int		iOffset;
	char	*RecipData;
//	char	wdata[8];

	/* Read Dev & Recipe Read Triger ON */
	if((CommonArea.SystemDev.Read_Dev.DevCnt == 2) &&
	  (CommonArea.SystemDev.Recip_Read_DevName[0] != 0)){
		//061124
//		idx= InDevArea.UB[INDEV_READ_B+3] * 256+ InDevArea.UB[INDEV_READ_B+2];
		idx= InDevArea.UW[(INDEV_READ_B+2)/2];
		if(idx > CommonArea.SystemDev.RecipCnt){
			return;
		}
		if(idx > 0){
			idx -= 1;
		}else{
			return;
		}
		iOffset= 0;
		for(i = 0; i < idx; i++){
			iOffset += CommonArea.SystemDev.RecipStart[iOffset+ 1]+ 8;
			iOffset += CommonArea.SystemDev.RecipPoint*2;
		}
		iOffset += CommonArea.SystemDev.RecipStart[iOffset+ 1]+ 2;
		/*------------------------------------------------------------*/
		iOffset+=5;
		/*-------------------------------------------------------------*/
		iOffset++;				/* Data Type */
		RecipData= (char *)TakeMemory(8000);
		memcpy(RecipData,&InDevArea.UW[2048],CommonArea.SystemDev.RecipPoint*2);
//		for(i = 0; i < CommonArea.SystemDev.RecipPoint; i++){
//			wdata[0]= RecipData[i*2];
//			RecipData[i*2]= RecipData[i*2+ 1];
//			RecipData[i*2+ 1]= wdata[0];
//		}
		WriteRecipeData(iOffset,(char *)RecipData);
		FreeMail(RecipData);
	}
}
/********************************************/
/*	TimeSwitchTask							*/
/********************************************/
void	TimeSwitchTask( STTFrm* pSTT )
{
	int idx;
	char data;
	int	eidx;
	T_MAIL	*mp;
	DEV_DATA	DevInfo;
	char	wdata[8];
	int		iOffset;
	char	*RecipData;
	int		i,j;
	int		DevAdd;

	/* Time Swicth Task Mail Use 070918 */
    TimeswitchFreeMbx = TakeMbx();
    for( i=0; i<2; i++ ) {
        mp= (T_MAIL *)TakeMail();
        ChangeMailResp( (char*)mp, TimeswitchFreeMbx );
        SendMail( TimeswitchFreeMbx, (char*)mp );
    }

	SetWindowNo(1);
	while(1){
		mp= (T_MAIL *)WaitRequest();
		switch(mp->mcod){
		case 0:				/* Time Switch */
			if(mp->mext == 0){		/* OFF */
				data= 0;
			}else{					/* ON */
				data= 1;
			}
			DevInfo.DevFlag= DEVICE_BIT;		/* Bit */
			DevInfo.DevName[0]= CommonArea.SystemDev.TimeSwitch_DevName[0];
			DevInfo.DevName[1]= CommonArea.SystemDev.TimeSwitch_DevName[1];
			DevInfo.DevAddress= CommonArea.SystemDev.TimeSwitch_DevAdd+ mp->mpar;
			DevInfo.DevData= &data;
			DevInfo.DevCnt= 1;
			PLCWrite(&DevInfo);
			break;
		case 1:				/* Recipe Action */
			/* Recipe No */
			if(CommonArea.SystemDev.Read_Dev.DevCnt == 2){
				if(CommonArea.SystemDev.RecipPoint != 0){
					//061124
//					idx= InDevArea.UB[INDEV_READ_B+3] * 256+ InDevArea.UB[INDEV_READ_B+2];
					idx= InDevArea.UW[(INDEV_READ_B+2)/2];
					if(idx > CommonArea.SystemDev.RecipCnt){
						if(mp->mext != 2){
							break;
						}
					}
					if(idx > 0){
						idx -= 1;
					}else{
						if(mp->mext != 2){
							break;
						}
					}
					iOffset= 0;
					for(i = 0; i < idx; i++){
						iOffset += CommonArea.SystemDev.RecipStart[iOffset+ 1]+ 8;
						iOffset += CommonArea.SystemDev.RecipPoint*2;
					}
					iOffset += CommonArea.SystemDev.RecipStart[iOffset+ 1]+ 2;
					/*------------------------------------------------------------*/
					wdata[0]= CommonArea.SystemDev.RecipStart[iOffset];
					wdata[1]= CommonArea.SystemDev.RecipStart[iOffset+1];
					wdata[2]= CommonArea.SystemDev.RecipStart[iOffset+2];
					DevAdd= CommonArea.SystemDev.RecipStart[iOffset+3] * 256 + 
						CommonArea.SystemDev.RecipStart[iOffset+4];
					iOffset+=5;
					/*-------------------------------------------------------------*/
					iOffset++;				/* Data Type */
					switch(mp->mext){
					case 0:		/* Write */
//						RecipData= (char *)TakeMemory(8000);
//						memcpy(RecipData,&InDevArea.UW[2048],CommonArea.SystemDev.RecipPoint*2);
//						for(i = 0; i < CommonArea.SystemDev.RecipPoint; i++){
//							wdata[0]= RecipData[i*2];
//							RecipData[i*2]= RecipData[i*2+ 1];
//							RecipData[i*2+ 1]= wdata[0];
//						}
						DevInfo.DevFlag= DEVICE_WORD;		/* Word */
						DevInfo.DevName[0]= wdata[0];
						DevInfo.DevName[1]= wdata[1];
						DevInfo.DevAddress= DevAdd;
						DevInfo.DevData= (char *)&InDevArea.UW[2048];
						DevInfo.DevCnt= CommonArea.SystemDev.RecipPoint;
						PLCWrite(&DevInfo);
//						FreeMail(RecipData);
						break;
					case 1:					/* Read */
						DevInfo.DevFlag= DEVICE_WORD;		/* Word */
						DevInfo.DevName[0]= wdata[0];
						DevInfo.DevName[1]= wdata[1];
						DevInfo.DevAddress= DevAdd;
						RecipData= (char *)TakeMemory(8000);
						DevInfo.DevData= (char *)RecipData;
						DevInfo.DevCnt= CommonArea.SystemDev.RecipPoint;
						PLCRead(&DevInfo);
						/* 2004.05.21 */
						memcpy(&InDevArea.UW[2048],RecipData,CommonArea.SystemDev.RecipPoint*2);
//						for(i = 0; i < CommonArea.SystemDev.RecipPoint; i++){
//							wdata[0]= RecipData[i*2];
//							RecipData[i*2]= RecipData[i*2+ 1];
//							RecipData[i*2+ 1]= wdata[0];
//						}
						WriteRecipeData(iOffset,&RecipData[0]);
						FreeMail(RecipData);
						break;
					case 2:				/* UW2048 Area Load */
						//061124
//						idx= InDevArea.UB[INDEV_READ_B+3] * 256+ InDevArea.UB[INDEV_READ_B+2];
						idx= InDevArea.UW[(INDEV_READ_B+2)/2];
						if((idx > CommonArea.SystemDev.RecipCnt) || (idx < 1)){	/* Error No */
							memset(&InDevArea.UW[2048],0,CommonArea.SystemDev.RecipPoint*2);
						}else{
//							RecipData= (char *)TakeMemory(8000);
//							for(i = 0; i < CommonArea.SystemDev.RecipPoint; i++){
//								RecipData[i*2]= CommonArea.SystemDev.RecipStart[iOffset++];
//								RecipData[i*2+1]= CommonArea.SystemDev.RecipStart[iOffset++];
//							}
							/* 2004.05.21 */
							memcpy(&InDevArea.UW[2048],&CommonArea.SystemDev.RecipStart[iOffset],CommonArea.SystemDev.RecipPoint*2);
//							FreeMail(RecipData);
						}
						break;
					}
				}
			}
			break;
		case 2:		/* Alarm Hist Entry */
			idx= mp->mpar;
			data= (char)mp->mext;
			if(data != 0){					/* Alarm ON */
				if(CommonArea.AlarmTotalCnt < 32767){
					CommonArea.AlarmTotalCnt++;
				}
				eidx= CommonArea.EntryIdx;
				/* Alarm Total */
				CommonArea.TotalCnt[idx]++;
				/* Alarm Item */
				CommonArea.AlarmHistRec[eidx].DevNo= idx;
				CommonArea.AlarmHistRec[eidx].sDateTime= 
					(SystemTime.year << 26) + (SystemTime.mon << 22) + (SystemTime.day << 17) +
					(SystemTime.hour << 12) + (SystemTime.min << 6) + SystemTime.sec;
				CommonArea.AlarmHistRec[eidx].eDateTime= 0;
				CommonArea.AlarmHistRec[eidx].Cnt= CommonArea.TotalCnt[idx];
				CommonArea.AlarmHistRec[eidx].flag= 0;
				CommonArea.DevIdx[idx]= eidx;
				CommonArea.EntryIdx= (eidx+ 1) % 1024;
				if(CommonArea.EntryCnt < 1024){
					CommonArea.EntryCnt++;
				}else{
					CommonArea.StartIdx= (CommonArea.StartIdx+ 1) % 1024;
				}
				/* Total Cnt Store */
/*				SetTotalCnt(&CommonArea.SystemDev.Alarm_DevStore,CommonArea.AlarmTotalCnt);*/
				SetTotalCnt(&CommonArea.SystemDev.Alarm_DevStore,CommonArea.EntryCnt);
				CommonArea.AlarmTotalOnCnt++;
/*				Write_AlarmBit();*/
			}else{							/* Alarm OFF */
				eidx= CommonArea.DevIdx[idx];
				/* Alarm Item */
				CommonArea.AlarmHistRec[eidx].eDateTime= 
					(SystemTime.year << 26) + (SystemTime.mon << 22) + (SystemTime.day << 17) +
					(SystemTime.hour << 12) + (SystemTime.min << 6) + SystemTime.sec;
				CommonArea.AlarmHistRec[eidx].flag= 1;
				CommonArea.AlarmTotalOnCnt--;
				if(CommonArea.AlarmTotalOnCnt < 0){
					CommonArea.AlarmTotalOnCnt= 0;
				}
			}
			AlarmHistSend();		/* Alarm Hist Display */
			break;
		case 3:							/* All Delete */
			ClearHistry();
			/* Total Cnt Store */
/*			SetTotalCnt(&CommonArea.SystemDev.Alarm_DevStore,CommonArea.AlarmTotalCnt);*/
			SetTotalCnt(&CommonArea.SystemDev.Alarm_DevStore,CommonArea.EntryCnt);
			AlarmHistSend();		/* Alarm Hist Display */
/*			Write_AlarmBit();*/
			break;
		case 4:				/* Alarm List ON Set */
			if(mp->mpec == 0){		/* Non Stored Memory OFF */
				idx= mp->mext;
				CommonArea.AlarmListRec[idx].DateTime= 
					(SystemTime.year << 26) + (SystemTime.mon << 22) + (SystemTime.day << 17) +
					(SystemTime.hour << 12) + (SystemTime.min << 6) + SystemTime.sec;
				CommonArea.AlarmlistTotalCnt++;
				SetTotalCnt(&CommonArea.SystemDev.lAlarmCnt_Dev,CommonArea.AlarmlistTotalCnt);
			}else{
				idx= mp->mpar;
				CommonArea.StordMem[mp->mext].Alarm.StoreAlarmListRec[idx].DateTime= 
					(SystemTime.year << 26) + (SystemTime.mon << 22) + (SystemTime.day << 17) +
					(SystemTime.hour << 12) + (SystemTime.min << 6) + SystemTime.sec;
				CommonArea.StordMem[mp->mext].Alarm.TotalCnt++;
				SetTotalCnt(&CommonArea.SystemDev.StoredInfo[mp->mext].St.AlarmInfo.StorelAlarmCnt,CommonArea.StordMem[mp->mext].Alarm.TotalCnt);
			}
			AlarmListSend();
			break;
		case 5:					/* Observe Action */
#ifdef	GP_S044
			if(mp->mext == 0){		/* Project */
				ObserveAction(&CommonArea.SystemDev.Observe_Proj_Dev[mp->mpar],mp->mpec);
			}else{
				ObserveAction(&CommonArea.SystemDev.Observe_Screen_Dev[mp->mpar],mp->mpec);
			}
#endif
#ifdef	GP_S057
			if(mp->mext == 0){		/* Project */
				ObserveAction(&CommonArea.SystemDev.Observe_Proj_Dev[mp->mpar],mp->mpec);
			}else{
				ObserveAction(&CommonArea.SystemDev.Observe_Screen_Dev[mp->mpar],mp->mpec);
			}
#endif
			break;
		case 6:					/* BarCode In -> OFF */
			/* b5 OFF */
			//061124
//			InDevArea.UB[INDEV_WRITE+9] &= ~W_BAR_ON;
			InDevArea.UW[INDEV_WRITE+4] &= ~W_BAR_ON;
		case 7:					/* Alarm History OF DEvice Clear */
			ClearHistryOffDev();
/*			Write_AlarmBit();*/
			SetTotalCnt(&CommonArea.SystemDev.Alarm_DevStore,CommonArea.EntryCnt);
			AlarmHistSend();		/* Alarm Hist Display */
			break;
		case 8:					/* Alarm History Delete 1 line */
			/* OFF-Device Delete */
			if(CommonArea.AlarmHistRec[mp->mext].flag == 1){
				DeleteHistry(mp->mext);
				SetTotalCnt(&CommonArea.SystemDev.Alarm_DevStore,CommonArea.EntryCnt);
				AlarmHistSend();		/* Alarm Hist Display */
			}
			break;
		case 9:					/* Reset Alarm Device 1 line */
			ResetHistryDev(mp->mext);
			break;
		case 10:				/* Write Device Write */
			Write_WriteDev();
			break;
		case 11:			/* �ėp�ʐM���荞�� */
			switch(mp->mext){		/* Kind 0?6�FM8000?M8049 7:Display Change 8:Input 9:Data Tran End */
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
				idx= 1;
				for(i = 0,j= 0; i < 8; i++){
					if((mp->mext == 6) && (j > 1)){
						break;
					}
					if((mp->mpar & idx) != 0){
						wdata[j]= 0x50+ (char)mp->mext* 8+ j;
						j++;
					}
				}
				idx= j;
				break;
			case 7:
				idx= 1;
				wdata[0]= 0x20;
				break;
			case 8:
				idx= 1;
				wdata[0]= 0x21;
				break;
			case 9:
				idx= 1;
				wdata[0]= 0x22;
				break;
			}
			if(idx > 0){
				SendHost(wdata,idx);
			}
			break;
		case 12:				/* Alarm List OFF Set */
			if(mp->mpec == 0){		/* Non Stored Memory OFF */
				CommonArea.AlarmlistTotalCnt--;
				if(CommonArea.AlarmlistTotalCnt < 0){
					CommonArea.AlarmlistTotalCnt= 0;
				}
				SetTotalCnt(&CommonArea.SystemDev.lAlarmCnt_Dev,CommonArea.AlarmlistTotalCnt);
			}else{
				CommonArea.StordMem[mp->mext].Alarm.TotalCnt--;
				if(CommonArea.StordMem[mp->mext].Alarm.TotalCnt < 0){
					CommonArea.StordMem[mp->mext].Alarm.TotalCnt= 0;
				}
				SetTotalCnt(&CommonArea.SystemDev.StoredInfo[mp->mext].St.AlarmInfo.StorelAlarmCnt,CommonArea.StordMem[mp->mext].Alarm.TotalCnt);
			}
			AlarmListSend();
			break;
		case 13:				/* Low Battery Set */
			Write_LowBatteryBit(mp->mext);
			break;
		case 14:				/* Printing */
			PrintDataDisplay();
			break;
		case 15:				/* PLC Connect Error */
			if(mp->mext == 1){
				PlcConnectDisp();  /* PLC ����� �̿��� �޼��� ǥ�� */
			}else{
				PlcConnectDispClr(); /* PLC ����� �̿��� �޼��� ���� */
			}
			break;
		}
		ResponseMail((char *)mp);
	}
}
/************************************/
void	SendAnalsys(int mode)
{
	T_MAIL	*mp;

	mp = (T_MAIL *)TakeMail();
	mp->mcmd = mode;
	SendMail(T_DISPANALYSIS,(char *)mp);
}
void	SendKeyData(int mode)
{
	T_MAIL	*mp;

	mp = (T_MAIL*)ReceiveMail( KeyFreeMbx );
	mp->mext = mode;
	mp->mbuf[0] = mode;
	mp->mbuf[1] = 0;
	SendMail( T_KEYHAND, (char *)mp);
}
void	SendMsg(int Com,int no,int mode)
{
	T_MAIL	*mp;
	int		iColor;

	mp= (T_MAIL *)TakeMemory(0x1000);
	mp->mcmd= Com;	/* Message */
	mp->mcod= no;
	mp->mext = 0;
	if(mode == 0){
		vCommentDataSet(CommonArea.SystemDev.CommentStartNo+ no,(char *)mp->mbuf,&iColor,(int *)&mp->mext);
		if(mp->mext != 0){
			SendMail(T_MSG_TASK,(char *)mp);
		}else{
			FreeMail((char *)mp);
		}
	}else{
		SendMail(T_MSG_TASK,(char *)mp);
	}
}
int	CheckPlcDeviceUse(void)
{
/*	int		i;*/
	int		ret= 0;
	ret= 1;
	return(ret);
}
/************************************/
/*  Trende & AlarmList State		*/
/*	100ms							*/
/************************************/
void	ScreenState( int loopCnt )
{
	int		signal;
	int		idx;
	int		i,j;
	unsigned char*	sAlarmListData;
	unsigned char*	AlarmListData;
	unsigned char	WorkData;

#ifdef		KSC		/*ksc20041125*/
#else
	if(loopCnt == 0){
		displayTime=0;
	}
#endif

	signal = ReadSignal(S_SCREEN);	/* */
	if((signal & 0x0001) != 0){		/* */
		/* Alarm List Non Store */
		sAlarmListData= &CommonArea.sAlarmListData[0];
		AlarmListData= &CommonArea.AlarmListData[0];
		for(i = 0; i < CommonArea.SystemDev.lAlarm_Dev.DevCnt; i++){
/* 20080822 ���߿� ����Ÿ�� ���� ��찡 �����Ƿ� ���� �۾������� �������� �� �ϵ��� ���� */
/*			if(CommonArea.sAlarmListData[i] != CommonArea.AlarmListData[i]){	*/
			WorkData= *AlarmListData;
			if(*sAlarmListData != WorkData){
/*				CommonArea.sAlarmListData[i] = CommonArea.AlarmListData[i];		*/
				*sAlarmListData = WorkData;
/*				if(CommonArea.sAlarmListData[i] != 0){		*/
				if(*sAlarmListData != 0){
					CommonArea.AlarmListRec[i].OnOff= 1;
					SendTimeAction(4,i,0,0);		/* Alarm List ON */
				}else{
					if(CommonArea.AlarmListRec[i].OnOff == 1){
						CommonArea.AlarmListRec[i].OnOff= 0;
						SendTimeAction(12,i,0,0);		/* Alarm List OFF */
					}
				}
			}
			sAlarmListData++;
			AlarmListData++;
		}
		/* Trend Non Stored */
		if(CommonArea.SystemDev.Trand_Dev.DevCnt > 0){
			if((loopCnt % CommonArea.SystemDev.TrandTime) == 0){
				idx= CommonArea.SystemDev.TrandEntryIdx;
				for(j= 0; j < CommonArea.SystemDev.Trand_Dev.DevCnt; j++){
					if(CommonArea.SystemDev.TrandWordCnt == 0){
//						CommonArea.TrandeData[j][idx]= (short)(CommonArea.TrandDevData[16][j*2]+
//													CommonArea.TrandDevData[16][j*2+1]* 256);
						CommonArea.TrandeData[j][idx]= (short)(CommonArea.TrandDevData[16][j*2+1]+
													CommonArea.TrandDevData[16][j*2]* 256);
					}else{
//						CommonArea.TrandeData[j][idx]= (int)(CommonArea.TrandDevData[16][j*4]+
//								(CommonArea.TrandDevData[16][j*4+1] << 8)+ 
//								(CommonArea.TrandDevData[16][j*4+2] << 16)+
//								(CommonArea.TrandDevData[16][j*4+3] << 24));
//20091222
						CommonArea.TrandeData[j][idx]= (int)((CommonArea.TrandDevData[16][j*4] << 8)+
								 CommonArea.TrandDevData[16][j*4+1]+ 
								(CommonArea.TrandDevData[16][j*4+2] << 24)+
								(CommonArea.TrandDevData[16][j*4+3] << 16));
					}
				}
				CommonArea.SystemDev.TrandEntryIdx= (idx+ 1) % TREND_MAX;
				if(CommonArea.SystemDev.TrandEntryCnt < TREND_MAX){
					CommonArea.SystemDev.TrandEntryCnt++;
				}
				if(CommonArea.SystemDev.TrandEntryCnt > CommonArea.SystemDev.TrandPoint){
					CommonArea.SystemDev.TrandStartIdx= (CommonArea.SystemDev.TrandStartIdx+ 1) % TREND_MAX;
				}
			}
		}
		/* PLC Connect Error ksc20041123*/

#ifdef	KSC		/*ksc20041124  PlcConnectFlag = 0 : NG, PlcConnectFlag2 = 0 NG, */
		
		if(((PlcConnectFlag == 0) || (PlcConnectFlag2 == 0) && (Set.iPrint == PLCTYPE2)) && (loopCnt > 50)){			/* �ŏ��̂T�b�͌��o���Ȃ�Connect Error */
			signal = ReadSignal(SGN_PLC);	
			if((signal & 0x0001) != 0){
				if(PlcConnectFlag == 0){
					if((CommonArea.ReadDevData[0] & R_PLC_ON) == 0){
						if(PLCCnErrorDsp == OFF){
							if((PLCCnNewRec == 0) || ((PLCCnNewRec+ 5000) < _TimeMSec)){
								SendTimeAction(15,1,0,0);		/* Display ON */
								PLCCnErrorDsp= ON;
							}else{
							}
						}
					}
				}
				if((PlcConnectFlag2 == 0) && (Set.iPrint == PLCTYPE2)){
					if((CommonArea.ReadDevData[0] & R_PLC_ON2) == 0){
						if(PLCCnErrorDsp == OFF){
							if((PLCCnNewRec2 == 0) || ((PLCCnNewRec2+ 5000) < _TimeMSec)){
								SendTimeAction(15,1,0,0);		/* Display ON */
								PLCCnErrorDsp= ON;
							}else{
							}
						}
					}
				}
			}			
		}else{
			if(PLCCnErrorDsp == ON){            /* �̿��� �޼��� ǥ�� ��/�� �÷��� ON�϶� */ 
				SendTimeAction(15,0,0,0);		/* ODisplay OFF */
				PLCCnErrorDsp= OFF;             /* �̿��� �޼��� ǥ�� ��/�� �÷��� OFF */
			}
		}
#else

		if(loopCnt > 50){			/* �ŏ��̂T�b�͌��o���Ȃ�Connect Error */
			//061124
//			if((PlcConnectFlag == 0) && ((CommonArea.ReadDevData[0] & R_PLC_ON) != 0)){
			if((PlcConnectFlag == 0) && ((CommonArea.Read.ReadDevWord[0] & R_PLC_ON) != 0)){

				signal = ReadSignal(SGN_PLC);	
				if((signal & 0x0001) != 0){

				
					if(PLCCnErrorDsp == OFF){
/* 061024							if((PLCCnNewRec == 0) || ((PLCCnNewRec+ 5000) < _TimeMSec)){*/
						if((PLCCnNewRec == 0) || ((_TimeMSec- PLCCnNewRec) >= 5000)){
							SendTimeAction(15,1,0,0);		/* Display ON */
							PLCCnErrorDsp= ON;
						}else{
						}
					}
				}

/*				}else if((PlcConnectFlag2 == 0) && (Set.Ch1_iKind == PLCTYPE2) && ((CommonArea.ReadDevData[0] & R_PLC_ON2) != 0)){*/
			//061124
//			}else if((PlcConnectFlag2 == 0) && ((CommonArea.ReadDevData[0] & R_PLC_ON2) != 0)){
/*			}else if((PlcConnectFlag2 == 0) && ((CommonArea.Read.ReadDevWord[0] & R_PLC_ON2) != 0)){*/	/*20081007*/
			}else if((CheckPlc2Connect() == 0) && ((CommonArea.Read.ReadDevWord[0] & R_PLC_ON2) != 0)){	/*20081007*/

				signal = ReadSignal(SGN_PLC);	
				if((signal & 0x0001) != 0){

					if(PLCCnErrorDsp == OFF){
/* 061024							if((PLCCnNewRec2 == 0) || ((PLCCnNewRec2+ 5000) < _TimeMSec)){*/
						if((PLCCnNewRec2 == 0) || ((_TimeMSec- PLCCnNewRec2) >= 5000)){
							SendTimeAction(15,1,0,0);		/* Display ON */
							PLCCnErrorDsp= ON;
						}else{
						}
					}
				}

			}else{
				if(PLCCnErrorDsp == ON){            /* �̿��� �޼��� ǥ�� ��/�� �÷��� ON�϶� */ 
					displayTime++;
					if(displayTime > 20){
						SendTimeAction(15,0,0,0);		/* ODisplay OFF */
						PLCCnErrorDsp= OFF;             /* �̿��� �޼��� ǥ�� ��/�� �÷��� OFF */
						displayTime=0;
					}
				}
			}
		}

#endif

	}
}
/********************************/
/*	Project �Ď�			*/
/********************************/
const int	ChangeWeekBit[7]= {1,2,4,8,0x10,0x20,0x40};
void	ProjectState( int loopCnt )
{
	int		signal;
	int		i,j;
	int		idx;
	int		NowTime;
	int		BefWeekBit;
	int		WeekBit;
	int		AlarmHistryOn;
	int		wAlarmData;		//071102

	signal = ReadSignal(S_PROJECT);	/* */
	if((signal & 0x0001) != 0){		/* */
		if((loopCnt % (3+CommonArea.SystemDev.Alarm_Time)) == 0){
			/* AlarmHistory �Ď�(Alarm Dev Dev == 0�̎�)) */
			if(CommonArea.sAlarmHistDelDat == 0){
				AlarmHistryOn= OFF;
				for(i = 0; i < CommonArea.SystemDev.Alarm_Dev.DevCnt; i++){
					wAlarmData= CommonArea.AlarmData[i];		//071102
					if(CommonArea.SaveAlarm[i] != wAlarmData){
						SendTimeAction(2,CommonArea.AlarmData[i],i,0);
						CommonArea.SaveAlarm[i] = wAlarmData;
					}
					/* �S��OFF��AlarmBitOFF 041213 */
					if(CommonArea.AlarmData[i] == 1){
						AlarmHistryOn= ON;
					}
				}
				/* Alarm Bit Out Cgange 040920 */
				if(AlarmHistryOutData != AlarmHistryOn){
					Write_AlarmBit(AlarmHistryOn);
					AlarmHistryOutData= AlarmHistryOn;
				}
			}
		}
		/* AlarmHistory Clear�Ď� */
		/* 1:Del Alarm Device */
		wAlarmData= CommonArea.AlarmHistDelDat;		//071102
//		if(CommonArea.AlarmHistDelDat != CommonArea.sAlarmHistDelDat){
		if(CommonArea.sAlarmHistDelDat != wAlarmData){
			CommonArea.sAlarmHistDelDat= wAlarmData;
			if(CommonArea.sAlarmHistDelDat == 1){
				SendTimeAction(3,0,0,0);
			}
		}
		/* Stored Memory State */
		for(i= 0; i < CommonArea.SystemDev.StoredMemCnt; i++){
			if(CommonArea.SystemDev.StoredInfo[i].Kind == 0){		/* Alarm list */
				/* Alarm List StoreMem */
				for(j = 0; j < CommonArea.SystemDev.StoredInfo[i].St.AlarmInfo.AlarmDevCnt; j++){
					wAlarmData= CommonArea.AlarmListStoreData[i][j];		//071102
					if(CommonArea.sAlarmListStoreData[i][j] != wAlarmData){
						CommonArea.sAlarmListStoreData[i][j] = wAlarmData;
						if(CommonArea.sAlarmListStoreData[i][j] != 0){
							if(CommonArea.StordMem[i].Alarm.StoreAlarmListRec[j].OnOff == 0){
								CommonArea.StordMem[i].Alarm.StoreAlarmListRec[j].OnOff = 1;
								SendTimeAction(4,i,j,1);		/* Alarm List */
							}
						}else{
							CommonArea.StordMem[i].Alarm.StoreAlarmListRec[j].OnOff = 0;
							SendTimeAction(12,i,j,1);		/* Alarm List OFF */
						}
					}
				}
			}else{										/* Trand State */
				if((CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandTime == 0) ||
					((loopCnt % CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandTime) == 0)){
					/* Data Save */
					idx= CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandEntryIdx;
					for(j= 0; j < CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.Trand_Dev.DevCnt; j++){
						if(CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandWordCnt == 0){	/* 16Bit */
//							CommonArea.StordMem[i].TrandeData[j][idx]= (short)(CommonArea.TrandDevData[i][j*2]+			//20091221
//														CommonArea.TrandDevData[i][j*2+1]* 256);						//20091221
							CommonArea.StordMem[i].TrandeData[j][idx]= (short)(CommonArea.TrandDevData[i][j*2]* 256+	//20091221
														CommonArea.TrandDevData[i][j*2+1]);								//20091221
						}else{							/* 32 Bit */
//							CommonArea.StordMem[i].TrandeData[j][idx]= (int)(CommonArea.TrandDevData[i][j*4]+			//20091221
//											(CommonArea.TrandDevData[i][j*4+1] << 8)+									//20091221
//											(CommonArea.TrandDevData[i][j*4+2] << 16)+									//20091221
//											(CommonArea.TrandDevData[i][j*4+3] << 24));									//20091221
							CommonArea.StordMem[i].TrandeData[j][idx]= (int)((CommonArea.TrandDevData[i][j*4] << 8)+			//20091221
											 CommonArea.TrandDevData[i][j*4+1]+									//20091221
											(CommonArea.TrandDevData[i][j*4+2] << 24)+									//20091221
											(CommonArea.TrandDevData[i][j*4+3] << 16));									//20091221
						}
					}
					CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandEntryIdx= (idx+ 1) % TREND_MAX;
					if(CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandEntryCnt < TREND_MAX){
						CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandEntryCnt++;
					}
					if(CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandEntryCnt > 
						CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandPoint){
						CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandStartIdx= 
							(CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandStartIdx+ 1) % TREND_MAX;
					}
					/* Stored Mem Clear State */
					if(CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandClearMode != 0){
						if(CommonArea.sTrandDevClrData[i] != CommonArea.TrandDevClrData[i]){
							CommonArea.sTrandDevClrData[i]= CommonArea.TrandDevClrData[i];
							if(CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandClearMode == 1){	/* UP */
								if(CommonArea.sTrandDevClrData[i] == 1){
									CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandStartIdx= 0;
									CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandEntryCnt= 0;
									CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandEntryIdx= 0;
								}
							}else{																		/* Fall */
								if(CommonArea.sTrandDevClrData[i] == 0){
									CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandStartIdx= 0;
									CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandEntryCnt= 0;
									CommonArea.SystemDev.StoredInfo[i].St.TrandeInfo.TrandEntryIdx= 0;
								}
							}
						}
					}
				}
			}
		}
		/*	Time Switch Check				*/
		NowTime= SystemTime.hour*3600+	SystemTime.min*60+ SystemTime.sec;
		WeekBit= ChangeWeekBit[SystemTime.week];
		for(i= 0; i < 8; i++){
			if(CommonArea.SystemDev._TIMESWITCH[i].iWeek != 0){
				if(CommonArea.SystemDev._TIMESWITCH[i].StartTime > 
					CommonArea.SystemDev._TIMESWITCH[i].EndTime){
					idx= SystemTime.week- 1;
					if(idx < 0){
						idx= 6;
					}
					BefWeekBit= ChangeWeekBit[idx];
					idx= 0;
					if(CommonArea.SystemDev._TIMESWITCH[i].iWeek & WeekBit){				/* Today */
						if(NowTime >= CommonArea.SystemDev._TIMESWITCH[i].StartTime){
							idx= 1;
						}
					}else if(CommonArea.SystemDev._TIMESWITCH[i].iWeek & BefWeekBit){		/* Yestaday */
						if(NowTime < CommonArea.SystemDev._TIMESWITCH[i].EndTime){
							idx= 1;
						}
					}
					if(idx == 1){
						if(CommonArea.SystemDev._TIMESWITCH[i].OnOffFlag == 0){
							CommonArea.SystemDev._TIMESWITCH[i].OnOffFlag= 1;
							SendTimeAction(0,1,i,0);			/* ON */
						}
					}else{
						if(CommonArea.SystemDev._TIMESWITCH[i].OnOffFlag == 1){
							CommonArea.SystemDev._TIMESWITCH[i].OnOffFlag= 0;
							SendTimeAction(0,0,i,0);			/* OFF */
						}
					}
				}else{
					if(CommonArea.SystemDev._TIMESWITCH[i].iWeek & WeekBit){
						if((NowTime >= CommonArea.SystemDev._TIMESWITCH[i].StartTime) &&
							(NowTime < CommonArea.SystemDev._TIMESWITCH[i].EndTime)){
							if(CommonArea.SystemDev._TIMESWITCH[i].OnOffFlag == 0){
								CommonArea.SystemDev._TIMESWITCH[i].OnOffFlag= 1;
								SendTimeAction(0,1,i,0);		/* ON */
							}
						}else{
							if(CommonArea.SystemDev._TIMESWITCH[i].OnOffFlag == 1){
								CommonArea.SystemDev._TIMESWITCH[i].OnOffFlag= 0;
								SendTimeAction(0,0,i,0);		/* OFF */
							}
						}
					}
				}
			}
		}
		/* Recipe Check */		/* 20080822 ������ ó�� */
		if(CommonArea.SystemDev.RecipCnt != 0){		/* Recipe ON */
			/* Recipe No Change Check V0526 */
			//061124
//			if((CommonArea.ReadDevData[2] != InDevArea.UB[INDEV_READ_B+2]) ||
//				(CommonArea.ReadDevData[3] != InDevArea.UB[INDEV_READ_B+3])){
//				CommonArea.ReadDevData[2] = InDevArea.UB[INDEV_READ_B+2];
//				CommonArea.ReadDevData[3] = InDevArea.UB[INDEV_READ_B+3];
			wAlarmData= InDevArea.UW[(INDEV_READ_B+2)/2];		//080814
//			if(CommonArea.Read.ReadDevWord[2] != InDevArea.UW[(INDEV_READ_B+2)/2]){
			if(CommonArea.Read.ReadDevWord[2] != wAlarmData){
				CommonArea.Read.ReadDevWord[2] = wAlarmData;
				SendTimeAction(1,2,0,0);		/* UW2048 Load */
			}
			/*	Recipe Write Check				*/
			if(CommonArea.SystemDev.Recip_Write_DevName[0] != 0){
				wAlarmData= CommonArea.wRecipeData;
/*				if(CommonArea.wRecipeData != CommonArea.wSaveRecipeData){	*/
				if(CommonArea.wSaveRecipeData != wAlarmData){
/*					CommonArea.wSaveRecipeData = CommonArea.wRecipeData;	*/
					CommonArea.wSaveRecipeData = wAlarmData;
					/* TRIGER */
//					if((CommonArea.wRecipeData == 1) && (CommonArea.SystemDev.RecipWriteFlag == 0)){
					if((wAlarmData == 1) && (CommonArea.SystemDev.RecipWriteFlag == 0)){
						SendTimeAction(1,0,0,0);		/* Write */
//					}else if((CommonArea.wRecipeData == 0) && (CommonArea.SystemDev.RecipWriteFlag != 0)){
					}else if((wAlarmData == 0) && (CommonArea.SystemDev.RecipWriteFlag != 0)){
						SendTimeAction(1,0,0,0);		/* Write */
					}
				}
			}
			/*	Recipe Read Check				*/
			if(CommonArea.SystemDev.Recip_Read_DevName[0] != 0){		/* Recipe Read Use */
				wAlarmData= CommonArea.rRecipeData;		//080814
//				if(CommonArea.rRecipeData != CommonArea.rSaveRecipeData){
				if(CommonArea.rSaveRecipeData != wAlarmData){
					CommonArea.rSaveRecipeData = wAlarmData;
					/* TRIGER ON */
//					if((CommonArea.rRecipeData == 1) && (CommonArea.SystemDev.RecipReadFlag == 0)){
					if((wAlarmData == 1) && (CommonArea.SystemDev.RecipReadFlag == 0)){
						SendTimeAction(1,1,0,0);		/* Read */
					/* TRIGER OFF */
//					}else if((CommonArea.rRecipeData == 0) && (CommonArea.SystemDev.RecipReadFlag != 0)){
					}else if((wAlarmData == 0) && (CommonArea.SystemDev.RecipReadFlag != 0)){
						SendTimeAction(1,1,0,0);		/* Read */
					}
				}
			}
		}
		/* Floating Alarm State �ω��̂�����̂̂ݑ��M */
		/* �f�o�C�X���̂�?�F�b�N������� 060202 */
		if(CommonArea.SystemDev.fAlarm_Dev.DevName[0] != 0){
			for(i = 0; i < CommonArea.SystemDev.fAlarm_Dev.DevCnt; i++){
				wAlarmData= CommonArea.fAlarmData[i];		//080814
//				if(CommonArea.fSaveAlarm[i] != CommonArea.fAlarmData[i]){
				if(CommonArea.fSaveAlarm[i] != wAlarmData){
					CommonArea.fSaveAlarm[i] = wAlarmData;
//					if(CommonArea.fAlarmData[i] == 1){		/* ON */
					if(wAlarmData == 1){		/* ON */
						SendMsg(2,i,0);
					}else{
						SendMsg(3,i,1);
					}
				}
			}
		}
		/*****�ėp�ʐM�̊Ď�******/
//		if(Set.Ch1_iKind == UNIVERSAL){					/* �ėp */
//			for(i = 0; i < 7; i++){
//				if(InDevArea.UB[INDEV_UN_B+i] != InDevArea.UB[INDEV_UN_B+0x2200+i]){
//					SendTimeAction(11,i,CommonArea.InDeviceSave[i]^InDevArea.UB[INDEV_UN_B+0x2200+i],0);		/* Interrupt ON */
//					CommonArea.InDeviceSave[i] = InDevArea.UB[INDEV_UN_B+0x2200+i];
//				}
//			}
//		}
		/* BarCode Kansi */
		//061124
//		if(((InDevArea.UB[INDEV_WRITE+9] & W_BAR_ON) != 0) &&
//			((InDevArea.UB[INDEV_READ_B] & R_BAR_ON) != 0)){
		if(((InDevArea.UW[INDEV_WRITE+4] & W_BAR_ON) != 0) &&
			((InDevArea.UW[(INDEV_READ_B)/2] & R_BAR_ON) != 0)){
			SendTimeAction(6,0,0,0);		/* Bar ON->OFF */
		}
		/* Input End Kansi 050306 */
		//061124
//		if(((InDevArea.UB[INDEV_WRITE+8] & W_NUM_IN) != 0) &&
//			((InDevArea.UB[INDEV_READ_B] & R_INPUT_ON) != 0)){
//			InDevArea.UB[INDEV_WRITE+8] &= ~W_NUM_IN;
		if(((InDevArea.UW[INDEV_WRITE+4] & W_NUM_IN) != 0) &&
			((InDevArea.UW[(INDEV_READ_B)/2] & R_INPUT_ON) != 0)){
			InDevArea.UW[INDEV_WRITE+4] &= ~W_NUM_IN;
			SendTimeAction(10,0,0,0);		/* INPUT ON->OFF */
		}
		/* Switching Screen State */
		/* BASE */
		if(CommonArea.SystemDev.Switch_Base_DevName[0] != 0){
			//061124
//			if((CommonArea.SwitchingData[0] != InDevArea.UB[INDEV_WRITE+0]) ||
//				(CommonArea.SwitchingData[1] != InDevArea.UB[INDEV_WRITE+1])){
//				if(CommonArea.SwitchingData[0] == 0){	/* 040610 */
//					InDevArea.UB[INDEV_WRITE+0]= 1;
//				}else{
//					InDevArea.UB[INDEV_WRITE+0]= CommonArea.SwitchingData[0];
//				}
//				InDevArea.UB[INDEV_WRITE+1]= CommonArea.SwitchingData[1];
//			}
			if(CommonArea.SwitchingData[0] != InDevArea.UW[INDEV_WRITE+0]){
				if(CommonArea.SwitchingData[0] == 0){	/* 040610 */
					InDevArea.UW[INDEV_WRITE+0]= 1;
				}else{
					InDevArea.UW[INDEV_WRITE+0]= CommonArea.SwitchingData[0];
				}
			}
		}
		/* Overap1 */
		if(CommonArea.SystemDev.Switch_Over1_DevName[0] != 0){
			//061124
//			if((CommonArea.SwitchingData[2] != InDevArea.UB[INDEV_WRITE+2]) ||
//				(CommonArea.SwitchingData[3] != InDevArea.UB[INDEV_WRITE+3])){
//				InDevArea.UB[INDEV_WRITE+2]= CommonArea.SwitchingData[2];
//				InDevArea.UB[INDEV_WRITE+3]= CommonArea.SwitchingData[3];
//			}
			if(CommonArea.SwitchingData[1] != InDevArea.UW[INDEV_WRITE+1]){
				InDevArea.UW[INDEV_WRITE+1]= CommonArea.SwitchingData[1];
			}
		}
		/* Overap2 */
		if(CommonArea.SystemDev.Switch_Over2_DevName[0] != 0){
			//061124
//			if((CommonArea.SwitchingData[4] != InDevArea.UB[INDEV_WRITE+4]) ||
//				(CommonArea.SwitchingData[5] != InDevArea.UB[INDEV_WRITE+5])){
//				InDevArea.UB[INDEV_WRITE+4]= CommonArea.SwitchingData[4];
//				InDevArea.UB[INDEV_WRITE+5]= CommonArea.SwitchingData[5];
//			}
			if(CommonArea.SwitchingData[2] != InDevArea.UW[INDEV_WRITE+2]){
				InDevArea.UW[INDEV_WRITE+2]= CommonArea.SwitchingData[2];
			}
		}
		if(CommonArea.SystemDev.Write_Dev.DevName[0] != 0){
			/* Write Save Area 2008.05.22 */
			if(memcmp(&SaveWriteArea[0],&InDevArea.UW[INDEV_WRITE],sizeof(SaveWriteArea)) != 0){
				memcpy(&SaveWriteArea[0],&InDevArea.UW[INDEV_WRITE],sizeof(SaveWriteArea));
				SendTimeAction(10,0,0,0);
			}
		}
	}
}
/****************************************/
/*	System State						*/
/****************************************/
extern	void	MonitorOffSet(void);
/********************************************/
/*	Signal1 State							*/
/********************************************/
void	StateSignal1(void)
{
	if(CommonArea.Read.ReadDevData[1] != InDevArea.UB[INDEV_READ_B+1]){
		/* History(Read Device) */
		//061124
		if(((CommonArea.Read.ReadDevWord[0] & R_BLK_ON) == 0) && ((InDevArea.UW[(INDEV_READ_B)/2] & R_RST_ON) != 0)){
			CommonArea.AlarmHistData = 1;
			SendTimeAction(3,1,0,0);
		}
		/* �o�b�N���C�g�Ď� */
		//061124
		if( ((CommonArea.Read.ReadDevWord[0] & R_BLK_ON) == 0) &&	/* ��?�h�f�o�C�X���O�ω������o�̂���*/
			((InDevArea.UW[(INDEV_READ_B)/2] & R_BLK_ON) != 0) &&	/* UB��?�h�f??���P*/
			(BackLitFlag == ON)){								/* �o�b�N���C�g��ON  */
			CommonArea.BackLightData= 1;
			BackLitSec= SystemTime.sec;
			BackLitsCnt= 0;			/* 021207 */
			BackLitmCnt= 0;			/* 021207 */
		}else{
			CommonArea.BackLightData= 0;
		}
		//061124
		CommonArea.Read.ReadDevWord[0] = InDevArea.UW[(INDEV_READ_B)/2];
	}else{
		if(CommonArea.BackLightData == 1){
			if(SystemTime.sec != BackLitSec){
				if(BackLitFlag == ON){
					/* �b�̌v�Z */
					BackLitSec= SystemTime.sec;
					BackLitsCnt++;
					if(BackLitsCnt >= 60){
						BackLitmCnt++;
						BackLitsCnt= 0;
					}
					/* �o�b�N���C�g���Ԃ��O�łȂ��o�b�N���C�g���ԂɂȂ��� */
					if((Set.iBackLightTime > 0) && (BackLitmCnt >= Set.iBackLightTime)){
						//061124
						if((InDevArea.UW[(INDEV_READ_B)/2] & R_BLK_ON) != 0){
							BackLightOnOff(OFF);
							BackLitFlag= OFF;
						}
						CommonArea.BackLightData= 0;
					}
				}
			}
		}
	}
}
/********************************************/
/*	Signal3 State							*/
/********************************************/
void	StateSignal3(void)
{
	//061124
	if(CommonArea.Read.ReadDevData[3] != InDevArea.UB[INDEV_READ_B+SIGNAL3]){
		/* Buzzer ON */
		//061124
		if(((CommonArea.Read.ReadDevWord[1] & R_BZR_ON) == 0) && 
			((InDevArea.UW[(INDEV_READ_B+SIGNAL3)/2] & R_BZR_ON) != 0)){
			BuzOn();
			BuzzerOnFlag= 1;
		//061124
		}else if(((CommonArea.Read.ReadDevWord[1] & R_BZR_ON) != 0) && 
			((InDevArea.UW[(INDEV_READ_B+SIGNAL3)/2] & R_BZR_ON) == 0)){
			BuzOff();
			BuzzerOnFlag= 0;
		}
		/* Backlit */
		//061124
		if(((CommonArea.Read.ReadDevWord[1] & R_BLK_P_ON) == 0) && 
			((InDevArea.UW[(INDEV_READ_B+SIGNAL3)/2] & R_BLK_P_ON) != 0)){
			BackLightOnOff(OFF);
			BackLitFlag= OFF;
		//061124
		}else if(((CommonArea.Read.ReadDevWord[1] & R_BLK_P_ON) != 0) &&
			((InDevArea.UW[(INDEV_READ_B+SIGNAL3)/2] & R_BLK_P_ON) == 0)){
			BackLightOnOff(ON);
			BackLitFlag= ON;
		}
		/* Print */
		//061124
		if((CommonArea.Read.ReadDevWord[1] & R_PRT_ON) != 
			(InDevArea.UW[(INDEV_READ_B+SIGNAL3)/2] & R_PRT_ON)){
			//061124
			if((InDevArea.UW[(INDEV_READ_B+SIGNAL3)/2] & R_PRT_ON) == 0){
			}else{
				SendTimeAction(14,0,0,0);		/* Printing */
			}
		}
		//061124
		CommonArea.Read.ReadDevWord[1] = InDevArea.UW[(INDEV_READ_B+SIGNAL3)/2];
	}
}

/**********************************************************/
extern	void	PcStateOn(void);
int		PcDownloadStart;		/* 070207 */
extern	unsigned char	Sio00SndBuff[PLC_BUF_MAX];
extern	int		Sio00SndCnt;
extern	unsigned char	Sio11SndBuff[PLC_BUF_MAX];
extern	int		Sio11SndCnt;
void	PcEditTimeOutProc(int *PcStart)
{
	int	PcSendEnd= 0;

	if((PcDownloadStart == 1) || (CommonArea.PcUpDownMode == 2)){		/* PC��MStart */
		PcSendEnd= 1;
		PcDownloadStart= 0;				/* 20090117 */
	}
	PcTimeout= 0;
	*PcStart= 0;
	BoardRateChangingFlag= 0;
	UpLoadMode= 0;
/*	ProtocalDownLoad= 0;  ksc20090516 */
	initEditPort();		/* ??�g������������ */
	if(CommonArea.PcUpDownMode != 0){		/* DownLoad Mode */
		OnSignal(SGN_PLC,1);		/* E-PLC ��� ���� */
		OnSignal(S_PROJECT,1);
		OnSignal(S_SCREEN,1);
	}
	ClearPcCom();
	init_filesystem();
	pcNewRec = 0;
/* 050407					}*/
	if((int)CommonSendBuf != -1){
#ifndef	WIN32
		FreeMail((char *)CommonSendBuf);
#endif
		CommonSendBuf= (unsigned char *)-1;
	}
#ifndef	WIN32
	if((int)UpBaseNo != -1){
		FreeMail((char *)UpBaseNo);
		FreeMail((char *)UpWinNo);
		UpBaseNo= (char *)-1;
		UpWinNo= (char *)-1;
	}
#endif
	if(PcFilefp != -1){
		mclose(PcFilefp);
		PcFilefp= -1;
	}
	/* 060121 */
	DownloadFileInfo= 0;			/* 0:NewFile,1:Openning		*/
	FontFirstFlag= 0;				/* 2009.07.01 add */

	if(PcSendEnd == 1){
		SendKeyData(PC_UPDOWN_END);
		SendAnalsys(0);
	}
//070326 Add Start
#ifdef	LP_S044		/* 20080822 PLC Ÿ��ũ ���� */
/*				if(PlcSignalInf == OFF){	*/
/*					PlcSignalInf= ON;		*/		//PLC PROC Start
/*				}	*/
#endif
	if(UpdateProjectInf != NULL){			/* 20080903 Add */
		FreeMail((char*)UpdateProjectInf);
		UpdateProjectInf= NULL;
		UpdateProjectBaseCnt= 0;
		UpdateProjectWindowCnt= 0;
	}
//070326 Add End
}

void	PcState( STTFrm* pSTT )
{
	int		PcStart;
	int		LoopCnt;
	int		DownloadCnt;
/*	int		sBoardRateFlag;	*//* 050406 */
	volatile	unsigned int	SavePcTimeoutWork;		/* 20090701 */
	volatile	unsigned int	PcTimeoutWork;			/* 20090701 */


	int		iKind;		//20090117

	PcDownloadStart= 0;			/* 070207 */
	pcNewRec = 0;
	PcStart= 0;
	PcTimeout= 0;
	GlpTimeout= 0;			//Glp�ʐM��
	PcTimeout1Char= 0;
	PcTimeout1Char0= 0;
	CommonArea.BatteryLevel= BATT_MAX_REVEL;		/* Initialize */
	BackLitSec= SystemTime.sec;
	BackLitsCnt= 0;			/* 021207 */
	BackLitmCnt= 0;			/* 021207 */
	BackLitFlag= ON;
	BuzzerOnFlag= 0;

	MonTimeout= 0;			/* Monitor Time Out */

/*	ProtocalDownLoad= 0;  ksc20090516  */
	DownloadCnt= 0;
	CommonSendBuf= (unsigned char *)-1;
#ifndef	WIN32
	UpBaseNo= (char *)-1;
	UpWinNo= (char *)-1;
#endif
	/* Write Save Area 2008.05.22 */
	memset(SaveWriteArea,0xff,sizeof(SaveWriteArea));

	LoopCnt= 0;
	AlarmHistryOutData= 0;			/* Alarm History On/OFF */
	/* 050407 */
	CommonSendBuf= (unsigned char *)-1;
	PcFilefp= -1;

	while(1){
		Delay(100);
		if(PcStart == 0){
/*			if((CommonArea.PcUpDownMode == 1) || (CommonArea.PcUpDownMode == 2)){ 070207 */		/* PC��MStart */
			if((PcDownloadStart == 1) || (CommonArea.PcUpDownMode == 2)){		/* PC��MStart */
				DownloadCnt= 0;
				PcStart= 1;
				if(CommonArea.PcUpDownMode == 1){
					SendKeyData(PC_DNLOAD_START);
				}else{
					SendKeyData(PC_UPLOAD_START);
				}
			}
		}else{
			if((++DownloadCnt % 10) == 0){
				SendKeyData(PC_CONT);
			}
		}
		if(pcNewRec != 0){			/* PC��MEND */
			pcNewRec = 0;
			PcStart= 0;
			PcTimeout= 0;
			UpLoadMode= 0;

/*			if(ProtocalDownLoad != 0){		ksc20090516 */
/*				ProtocalDownLoad= 0;	ksc20090516 */






/*			}		ksc20090516 */

			SendKeyData(PC_UPDOWN_END);
			SendAnalsys(0);
			if(UpdateProjectInf != NULL){			/* 20080903 Add */
				FreeMail((char*)UpdateProjectInf);
				UpdateProjectInf= NULL;
				UpdateProjectBaseCnt= 0;
				UpdateProjectWindowCnt= 0;
			}
		}
		SavePcTimeoutWork= SavePcTimeout;		/* 2009.07.01 add */
		PcTimeoutWork= PcTimeout;				/* 2009.07.01 add */
/*		if(PcTimeout != 0){						2009.07.01 del */
		if(PcTimeoutWork != 0){					/* 2009.07.01 add */
/*			if((_TimeMSec- SavePcTimeout) > PcTimeout){	2009.07.01 Del */
			if((_TimeMSec- SavePcTimeoutWork) > PcTimeoutWork){	/* 2009.07.01 add */
				PcEditTimeOutProc(&PcStart);
			}
		}
		SavePcTimeoutWork= SavePcTimeout1Char;		/* 2009.07.01 add(pc 1char Timeout) */
		PcTimeoutWork= PcTimeout1Char;				/* 2009.07.01 add */
/*		if(PcTimeout1Char != 0){				2009.07.01 del */
		if(PcTimeoutWork != 0){					/* 2009.07.01 add */
/*			if((_TimeMSec- SavePcTimeout1Char) > PcTimeout1Char){	2009.07.01 del */
			if((_TimeMSec- SavePcTimeoutWork) > PcTimeoutWork){
				PcTimeout1Char= 0;
				if(Set.Ch1_iConnect == CH_CH0){	/* PLC = RS-422 */
					if(Set.Ch1_iKind == UNIVERSAL){		/* UNIVERSAL */
						Comm0RecMode= 0;
					}
				}else{
					if(Set.Ch1_iKind == UNIVERSAL){		/* UNIVERSAL */
						Comm1RecMode= 0;
					}
				}
				//20090117
				if(Set.Ch1_iConnect == CH_CH1){
					iKind= Set.Ch1_iKind;
				}else{
					iKind= Set.Ch2_iKind;
				}
				if(iKind == EDITER){
					PcEditTimeOutProc(&PcStart);
				}
			}
		}
		SavePcTimeoutWork= SavePcTimeout1Char0;		/* 2009.07.01 add(plc 1char Timeout) */
		PcTimeoutWork= PcTimeout1Char0;				/* 2009.07.01 add */
/*		if(PcTimeout1Char0 != 0){					2009.07.01 del */
		if(PcTimeoutWork != 0){					/* 2009.07.01 add */
/*			if((_TimeMSec- SavePcTimeout1Char0) > PcTimeout1Char0){	2009.07.01 del */
			if((_TimeMSec- SavePcTimeoutWork) > PcTimeoutWork){
				PcTimeout1Char0= 0;
				if(Set.Ch1_iConnect == CH_CH0){	/* PLC = RS-422 */
					if(Set.Ch1_iKind == UNIVERSAL){		/* UNIVERSAL */
						Comm0RecMode= 0;
					}
				}else{
					if(Set.Ch1_iKind == UNIVERSAL){		/* UNIVERSAL */
						Comm1RecMode= 0;
					}
				}
				//20090117
				if(Set.Ch1_iConnect == CH_CH0){
					iKind= Set.Ch1_iKind;
				}else{
					iKind= Set.Ch2_iKind;
				}
				if(iKind == EDITER){
					PcEditTimeOutProc(&PcStart);
				}
			}
		}
		SavePcTimeoutWork= SaveMonTimeout;		/* 2009.07.01 add */
		PcTimeoutWork= MonTimeout;				/* 2009.07.01 add */
		/* Monitor Time Out */
/*		if(MonTimeout != 0){					2009.07.01 del */
		if(PcTimeoutWork != 0){					/* 2009.07.01 add */
/*			if((_TimeMSec- SaveMonTimeout) > MonTimeout){		2009.07.01 del */
			if((_TimeMSec- SavePcTimeoutWork) > PcTimeoutWork){	/* 2009.07.01 add */
				MonTimeout= 0;
				MonitorOffSet();
			}
		}
		/* Battery Check */
		if(CommonArea.BatteryLevel < BATT_MIN_REVEL){
			//061124
//			if((InDevArea.UB[INDEV_WRITE+9] & W_LOW_ON) == 0){
			if((InDevArea.UW[INDEV_WRITE+4] & W_LOW_ON) == 0){
				SendTimeAction(13,1,0,0);		/* Low Battery ON */
			}
		}else{
			//061124
//			if((InDevArea.UB[INDEV_WRITE+9] & W_LOW_ON) != 0){
			if((InDevArea.UW[INDEV_WRITE+4] & W_LOW_ON) != 0){
				SendTimeAction(13,0,0,0);		/* Low Battery OFF */
			}
		}
		/* Signal 1 */
		StateSignal1();

#ifdef	GP_S044
		/* Signal 3 */
		StateSignal3();
#endif
#ifdef	GP_S057
		/* Signal 3 */
		StateSignal3();
#endif

		/* Project State */
		ProjectState(LoopCnt);
#ifdef	LP_S044
			/* PLC�ʐM�Ď� */
#ifdef	WIN32
#else
		if(MatrixTimeoutCnt != 0){
			MatrixTimeoutCnt--;
			if(MatrixTimeoutCnt == 0){
				MatrixTimeoutProc();
			}
		}
		if(DenubTimeoutCnt != 0){
			DenubTimeoutCnt--;
			if(DenubTimeoutCnt == 0){
				if(DenbunTimeoutProc() == OK){
					if(PlcEditorPort == 0){
						SendPCData(Sio00SndBuff,(int *)&Sio00SndCnt);
					}else{
						SendPCData(Sio11SndBuff,(int *)&Sio11SndCnt);
					}
				}
			}
		}
#endif
		if(GlpTimeout != 0){		//�f�k�o�ʐM��
			if((_TimeMSec- GlpTimeout) > 30000){	GlpTimeout= 0;	}
		}
#endif

		LoopCnt++;
	}
}
/****************************************/
/****************************************/
#ifdef	OLD
void	ObservProc(int loopCnt)
{
	int		signal;
	int		i;
	int		flag;

	signal = ReadSignal(S_PROJECT);	/* OBSERV Project */
	if((signal & 0x0001) != 0){		/* */
		/* Observe State */
		if(CommonArea.SystemDev.Observe_Proj_Cnt != 0){
			/* Project */
			if((CommonArea.SystemDev.Proj_ObserveStatus == 0) || (CommonArea.SystemDev.Proj_ObserveTime == 0) ||
				(((loopCnt % 10) == 0) && (((loopCnt / 10) % CommonArea.SystemDev.Proj_ObserveTime) == 0))){
				for(i= 0; i < CommonArea.SystemDev.Observe_Proj_Cnt; i++){
					flag= 0;
					if(CommonArea.SystemDev.Observe_Proj_Dev[i].Dev1Inf == CommonArea.OvservDataProj[i*2]){
						if((CommonArea.SystemDev.Observe_Proj_Dev[i].DevName2[0] == 0) ||
						  ((CommonArea.SystemDev.Observe_Proj_Dev[i].DevName2[0] != 0) &&
						   (CommonArea.SystemDev.Observe_Proj_Dev[i].Dev2Inf == CommonArea.OvservDataProj[i*2+ 1]))){
							flag= 1;
							if(CommonArea.SystemDev.Observe_Proj_Dev[i].Condition == 0){
								CommonArea.SystemDev.Observe_Proj_Dev[i].Condition= 1;
								SendTimeAction(5,0,i,1);		/* Observ ON */
							}
						}
					}
					if((flag == 0) && (CommonArea.SystemDev.Observe_Proj_Dev[i].Condition == 1)){
						CommonArea.SystemDev.Observe_Proj_Dev[i].Condition= 0;
						SendTimeAction(5,0,i,0);		/* Observ OFF */
					}
				}
			}
		}
	}
	/* Observe State */
	if(CommonArea.SystemDev.Observe_Screen_Cnt != 0){
		/* Screen */
		if((CommonArea.SystemDev.Screen_ObserveStatus == 0) || (((loopCnt / 10) % CommonArea.SystemDev.Screen_ObserveTime) == 0)){
			for(i= 0; i < CommonArea.SystemDev.Observe_Screen_Cnt; i++){
				flag= 0;
				if(CommonArea.SystemDev.Observe_Screen_Dev[i].Dev1Inf == CommonArea.OvservDataScrren[i*2]){
					if((CommonArea.SystemDev.Observe_Screen_Dev[i].DevName2[0] == 0) ||
					  ((CommonArea.SystemDev.Observe_Screen_Dev[i].DevName2[0] != 0) &&
						(CommonArea.SystemDev.Observe_Screen_Dev[i].Dev2Inf == CommonArea.OvservDataScrren[i*2+ 1]))){
						flag= 1;
						if(CommonArea.SystemDev.Observe_Screen_Dev[i].Condition == 0){
							CommonArea.SystemDev.Observe_Screen_Dev[i].Condition= 1;
							SendTimeAction(5,1,i,1);		/* Observ ON */
						}
					}
				}
				if((flag == 0) && (CommonArea.SystemDev.Observe_Screen_Dev[i].Condition == 1)){
					CommonArea.SystemDev.Observe_Screen_Dev[i].Condition= 0;
					SendTimeAction(5,1,i,0);		/* Observ OFF */
				}
			}
		}
	}
}
#endif
void	ReadObservDev(void)
{
	int		i;

	for(i= 0; i < ObservProjCnt; i++){
		PLCRead(&ObservProjDev[i]);
	}
	for(i= 0; i < ObservScreenCnt; i++){
		PLCRead(&ObservScreenDev[i]);
	}
}
/****************************************/
/*	OBSERV TASK							*/
/****************************************/
void    ObservTask(STTFrm* pSTT)
{
	int		signal;
	int		loopCnt;
	DEV_DATA	DevDara;
	int		i;
	int		SetFlag;

	ClearFlag();
/*	WDT_Init();*/
/*	AplStateOn();*/
	loopCnt= 0;



	
	while(1){

		signal = ReadSignal(S_PROJECT);	/* OBSERV Project */

		if((signal & 0x0001) != 0){		/* */
			/* Observe State */
			if(CommonArea.SystemDev.Observe_Proj_Cnt != 0){
				/* Project */
				if((CommonArea.SystemDev.Proj_ObserveStatus == 0) || (CommonArea.SystemDev.Proj_ObserveTime == 0) ||
					(((loopCnt % 10) == 0) && (((loopCnt / 10) % CommonArea.SystemDev.Proj_ObserveTime) == 0))){
					for(i= 0; i < CommonArea.SystemDev.Observe_Proj_Cnt; i++){
						if(BaseChangeFlag1 != 0){		/* 040815 */
							break;
						}
						SetFlag= 0;
						DevDara.DevFlag= 0;		/* 0:Byte,1:Word */
						DevDara.DevName[0]= CommonArea.SystemDev.Observe_Proj_Dev[i].DevName1[0];
						DevDara.DevAddress= CommonArea.SystemDev.Observe_Proj_Dev[i].DevAdd1;
						DevDara.DevCnt= 1;
						DevDara.DevData= (char *)&CommonArea.OvservDataProj[i*2];
						PLCRead(&DevDara);
						if(CommonArea.SystemDev.Observe_Proj_Dev[i].DevName2[0] != 0){
							DevDara.DevFlag= 0;		/* 0:Byte,1:Word */
							DevDara.DevName[0]= CommonArea.SystemDev.Observe_Proj_Dev[i].DevName2[0];
							DevDara.DevAddress= CommonArea.SystemDev.Observe_Proj_Dev[i].DevAdd2;
							DevDara.DevCnt= 1;
							DevDara.DevData= (char *)&CommonArea.OvservDataProj[i*2+1];
							PLCRead(&DevDara);
						}
						if(CommonArea.SystemDev.Observe_Proj_Dev[i].Dev1Inf == CommonArea.OvservDataProj[i*2]){
							if((CommonArea.SystemDev.Observe_Proj_Dev[i].DevName2[0] == 0) ||
							  ((CommonArea.SystemDev.Observe_Proj_Dev[i].DevName2[0] != 0) &&
							   (CommonArea.SystemDev.Observe_Proj_Dev[i].Dev2Inf == CommonArea.OvservDataProj[i*2+ 1]))){
								SetFlag= 1;
							}
						}
						if(CommonArea.SystemDev.Observe_Proj_Dev[i].Condition != SetFlag){
							CommonArea.SystemDev.Observe_Proj_Dev[i].Condition= SetFlag;
							WaitSendTimeAction(5,0,i,SetFlag);		/* Observ ON/OFF */
						}
					}
				}
			}
		}

		signal = ReadSignal(S_SCREEN);	/* OBSERV Project */


		if((signal & 0x0001) != 0){		/* */
			/* Observe State */
			if(CommonArea.SystemDev.Observe_Screen_Cnt != 0){
				/* Screen */
				if((CommonArea.SystemDev.Screen_ObserveStatus == 0) || (((loopCnt / 10) % CommonArea.SystemDev.Screen_ObserveTime) == 0)){
					for(i= 0; i < CommonArea.SystemDev.Observe_Screen_Cnt; i++){
						if(BaseChangeFlag1 != 0){		/* 040815 */
							break;
						}
						SetFlag= 0;
						DevDara.DevFlag= 0;		/* 0:Byte,1:Word */
						DevDara.DevName[0]= CommonArea.SystemDev.Observe_Screen_Dev[i].DevName1[0];
						DevDara.DevAddress= CommonArea.SystemDev.Observe_Screen_Dev[i].DevAdd1;
						DevDara.DevCnt= 1;
						DevDara.DevData= (char *)&CommonArea.OvservDataScrren[i*2];
						PLCRead(&DevDara);
						if(CommonArea.SystemDev.Observe_Screen_Dev[i].DevName2[0] != 0){
							DevDara.DevFlag= 0;		/* 0:Byte,1:Word */
							DevDara.DevName[0]= CommonArea.SystemDev.Observe_Screen_Dev[i].DevName2[0];
							DevDara.DevAddress= CommonArea.SystemDev.Observe_Screen_Dev[i].DevAdd2;
							DevDara.DevCnt= 1;
							DevDara.DevData= (char *)&CommonArea.OvservDataScrren[i*2+1];
							PLCRead(&DevDara);
						}
						if(CommonArea.SystemDev.Observe_Screen_Dev[i].Dev1Inf == CommonArea.OvservDataScrren[i*2]){
							if((CommonArea.SystemDev.Observe_Screen_Dev[i].DevName2[0] == 0) ||
							  ((CommonArea.SystemDev.Observe_Screen_Dev[i].DevName2[0] != 0) &&
								(CommonArea.SystemDev.Observe_Screen_Dev[i].Dev2Inf == CommonArea.OvservDataScrren[i*2+ 1]))){
								SetFlag= 1;
							}
						}
						if(CommonArea.SystemDev.Observe_Screen_Dev[i].Condition != SetFlag){
							CommonArea.SystemDev.Observe_Screen_Dev[i].Condition= SetFlag;
							WaitSendTimeAction(5,1,i,SetFlag);		/* Observ ON/OFF */
						}
					}
				}
			}
		}
		loopCnt++;
		Delay(100);


	}
}




