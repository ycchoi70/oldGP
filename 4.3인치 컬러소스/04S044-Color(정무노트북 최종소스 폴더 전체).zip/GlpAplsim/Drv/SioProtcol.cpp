/************************************/
/*	SIO�P�v���g�R��					*/
/************************************/
#include    "sgt.h"

/****************************************************/
/*	���̑�PLC����									*/
/****************************************************/
extern	int	PLC1CHAR_READ(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff);
extern	int PCDownThrueLG(unsigned char rs_input_data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff);
extern	int	PlcRecRS(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff);
extern	int	PLCPCDOWN(unsigned char data,int *CommMode,int *Sio1RecCnt,unsigned char *Sio1RecBuff);
extern	int	PLC1CHAR_READ2(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff);
extern	int  Rs232c_Char_Proc(char ch,int* sndCnt,unsigned char* sndBuff,int *recCnt,unsigned char* recBuff) ;
/***************************************************/
extern	_SETUP		Set;					/* ������ ����E����ü						*/
//extern	int		ElsPlcOK;					/* PLC Prog Info 0:NOT,1:YES */
extern unsigned int sync_time;	/* 20061025 */

int		UnvPlcRecCnt;
int		UnvPlcRecCmd;
/****************************************************/
/*	PC-Connect(Barcode)								*/
/****************************************************/
int	ConnectPcBarcode(unsigned char rs_input_data,unsigned char *SioRecBuff,int *SioRecCnt)
{
	int	ret;

	ret = -1;
	if((rs_input_data == 0x0d) ||
		((rs_input_data >= 0x20) && (rs_input_data <= 0x7f))){
		if(*SioRecCnt < 1024){
			SioRecBuff[(*SioRecCnt)++] = rs_input_data;
		}
		if(rs_input_data == 0x0d){
			ret = 0;	/* Pendding Req */
		}
	}
	return(ret);
}
///////////////////////////////////////////////////////////////
// Recive is Fix(EDITOR,MONITOR 2012.07.04
///////////////////////////////////////////////////////////////
//int PCDownThrue(unsigned char data,int *CommMode,int *SioRecCnt,unsigned char *SioRecBuff,int *CommCnt)
int PCDownThrue(int type,unsigned char data,int *CommMode,int *SioRecCnt,unsigned char *SioRecBuff,int *CommCnt)
{
	int				i;
	unsigned char	bcc;
	int		ret;
	extern	volatile	unsigned	BerRecTime;		/* 040608 */
	
	/*******************040608*******/
/*	if((BerRecTime+100) < _TimeMSec){ 061024 */	/* Time Out */
#ifdef	WIN32
	if((_TimeMSec- BerRecTime) >= 500){	/* Time Out */
#else
	if((_TimeMSec- BerRecTime) >= 100){	/* Time Out */
#endif
		*CommMode = 0;
		*SioRecCnt = 0;
	}
	BerRecTime= _TimeMSec;
	/*******************************/
	ret = -1;
	if(type == EDITER){				//2012.07.04
		switch(*CommMode){
		case 0:		/* Normal */
			if(data == 0xfe){		/* DownLoad Header */
				*CommMode = 1;
				*SioRecCnt = 0;
//2012.07.04			}else{
//2012.07.04				switch(Set.Ch1_iKind){
//2012.07.04				case UNIVERSAL:
//2012.07.04				case DEFAULT_PLC:
//2012.07.04					ret= PCDownThrueLG(data,(int *)&PC_CommMode,SioRecCnt,SioRecBuff);
//2012.07.04					break;
//2012.07.04				case ELSE_PLC:
//2012.07.04					if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
//2012.07.04						ret= PLCPCDOWN(data,(int *)&PC_CommMode,SioRecCnt,SioRecBuff);
//2012.07.04					}
//2012.07.04					break;
//2012.07.04				}
			}
			break;
		case 1:		/* Length1 */
			*CommCnt = data;
			*CommMode = 2;
			SioRecBuff[(*SioRecCnt)++] = data;
			break;
		case 2:		/* Length2 */
			*CommCnt = *CommCnt + data* 256 + 2;
	//KSC20090112
			if(*CommCnt > PLC_BUF_MAX-10){			//20090112
				*CommCnt= PLC_BUF_MAX-10;			//20090112
			}										//20090112
			*CommMode = 3;
			SioRecBuff[(*SioRecCnt)++] = data;
			break;
		case 3:		/* Data */
			if(*SioRecCnt < *CommCnt){
				SioRecBuff[(*SioRecCnt)++] = data;
				if(*SioRecCnt >= *CommCnt){
					/* BCC ?�F�b�N */
					bcc = 0;
					for(i = 0; i < *CommCnt- 1; i++){
						bcc += SioRecBuff[i];
					}
					if(bcc == SioRecBuff[i]){
						ret = 0;	/* Pendding Req */
					}else{
						ret = -1;	/* BCC Error */
					}
				}
			}
			break;
		}
	}else{						//2012.07.04(Thru Mode= PC_CommMode) CommMode is 0
		switch(Set.Ch1_iKind){	//2012.07.04
		case UNIVERSAL:			//2012.07.04
		case DEFAULT_PLC:		//2012.07.04
			ret= PCDownThrueLG(data,(int *)&PC_CommMode,SioRecCnt,SioRecBuff);	//2012.07.04
			break;				//2012.07.04
		case ELSE_PLC:			//2012.07.04
			if(IsPlc1Protocol() == OK){	//2012.07.04
				ret= PLCPCDOWN(data,(int *)&PC_CommMode,SioRecCnt,SioRecBuff);	//2012.07.04
			}					//2012.07.04
			break;				//2012.07.04
		}						//2012.07.04
	}
	return(ret);
}
/****************************************/
/*	�ėp�ʐM��M�v���g�R��				*/
/****************************************/
/* 20060202 */
	extern	unsigned	_TimeMSec;

int	RxCommProc(unsigned char data,int *CommMode,int *RecCnt,unsigned char *RecBuff)
{
	int	ret;

/* 20060202 */
	if(PlcTimeout != 0){
		if(sync_time < _TimeMSec - PlcTimeout){		/* 20061025 */
			*CommMode =0;
			*RecCnt = 0;
		}
	}
	PlcTimeout = _TimeMSec;
	
/***********************************/
	ret = -1;
	switch(*CommMode){
	case 0:		/* Idle */
		*CommMode = 1;
		*RecCnt = 0;
		RecBuff[(*RecCnt)++] = data;		/* Slave Address */
		break;
	case 1:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		UnvPlcRecCnt= 6;
		UnvPlcRecCmd= data;					/* Command */
		switch(UnvPlcRecCmd){
		case 0x01:
		case 0x02:
		case 0x03:
		case 0x04:
		case 0x05:
		case 0x06:
			UnvPlcRecCnt= 6;
			break;
		case 0x07:
		case 0x0b:
		case 0x0c:
			UnvPlcRecCnt= 2;
			break;
//			break;
		case 0x0f:	/* �A��DO */
			UnvPlcRecCnt= 5;
			break;
		case 0x10:	/* �A���ێ����W�X? */
			UnvPlcRecCnt= 5;
			break;
		case 0x11:	/*  */
			UnvPlcRecCnt= 2;
			break;
		default:
			UnvPlcRecCnt= 6;
			break;
		}
		*CommMode = 2;
		break;
	case 2:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		UnvPlcRecCnt--;
		if(UnvPlcRecCnt <= 0){
			if((UnvPlcRecCmd == 0x0f) || (UnvPlcRecCmd == 0x10)){
				UnvPlcRecCnt= data+ 2;		/* Write Cnt + CRC */
				*CommMode = 3;
			}else{
				ret= 0;		/* Command End */
				PlcTimeout= 0;
			}
		}
		break;
	case 3:
		if(*RecCnt < PLC_BUF_MAX){
			RecBuff[(*RecCnt)++] = data;
		}
		UnvPlcRecCnt--;
		if(UnvPlcRecCnt <= 0){
			ret= 0;		/* Command End */
			PlcTimeout= 0;
		}
		break;
	}
	return(ret);
}
/****************************************************/
/*	Sio1-PC-Connect									*/
/****************************************************/
int	ConnectMode;
extern	int DModeFlag;
extern	void	Rs1FifoMde8(void);		//20090106
const char DebugPass[13]= {
	0x04,'a','u','t','o','n','i','c','s','h','m','i',CR};
//	0x04,'a',CR};
int	ConnectPc(unsigned char rs_input_data)
{
	int	ret;
	int	iKind;

	ret = -1;
	if(DModeFlag == 0){
		if(rs_input_data == DebugPass[ConnectMode]){
			ConnectMode++;
			if(ConnectMode == 13){
/*			if(ConnectMode == 3){	*/
				DModeFlag= 0x10;
				Rs1FifoMde8();			//20090106
				Sio1RecCnt= 0;
#ifdef	LP_S044
				PlcSignalInf= OFF;
#endif
			}
		}else{
			ConnectMode= 0;
		}
	}
	if(DModeFlag != 0){
		if(rs_input_data == 0x08){		//BS
			if(Sio1RecCnt > 0){
				Sio1RecCnt--;
			}
			return(-1);
		}else{
			Sio1RecBuff[Sio1RecCnt++] = rs_input_data;
			if(rs_input_data == CR){
				return(0);
			}else{
				return(-1);
			}
		}
	}
	if(Set.Ch1_iConnect == CH_CH1){
		iKind= Set.Ch1_iKind;
	}else{
		iKind= Set.Ch2_iKind;
	}
	switch(iKind){
	case UNIVERSAL:		/* UNIVERSAL */
		ret= RxCommProc(rs_input_data,(int *)&Comm1RecMode,(int *)&Sio1RecCnt,Sio1RecBuff);
		break;
	case DEFAULT_PLC:			/* FX-Serease */
		ret= PlcRecRS(rs_input_data,(int *)&Comm1RecMode,(int *)&Sio1RecCnt,Sio1RecBuff);
		break;
	case ELSE_PLC:
		if(CommonArea.PlcType1.PlcUserFlag != 0){	/* 2008.12.10 */
			ret= PLC1CHAR_READ(rs_input_data,(int *)&Comm1RecMode,(int *)&Sio1RecCnt,Sio1RecBuff);
		}
		break;
	case EDITER:		/* Editor */
#ifdef	LP_S044
//		if(IsGlpType() == OK){		//GLP TYPE
			if((_TimeMSec- RecTimeOut) > 500){
				if(Matrix_Mode < ENQ_ANS_WAIT){
					Sio1RecCnt= 0;
					Comm1RecMode= 0;
					Matrix_Mode= IDLE;
				}
			}
			RecTimeOut= _TimeMSec;
			if((Comm1RecMode == 0) && (rs_input_data != 0xfe)){
				ret= Rs232c_Char_Proc(rs_input_data,(int *)&Sio1SndCnt,Sio1SndBuff,(int *)&Sio1RecCnt,Sio1RecBuff);
	#ifdef	WIN32
				CommRecWinKind= 1;
	#else
//KSC20090112
				wCommRecKind= 1;
	#endif
			}else{
//2012.07.04				ret= PCDownThrue(rs_input_data,(int *)&Comm1RecMode,(int *)&Sio1RecCnt,Sio1RecBuff,(int *)&CommCnt);
				ret= PCDownThrue(EDITER,rs_input_data,(int *)&Comm1RecMode,(int *)&Sio1RecCnt,Sio1RecBuff,(int *)&CommCnt);
	#ifdef	WIN32
				CommRecWinKind= 0;
	#else
//KSC20090112
				wCommRecKind= 0;
	#endif
			}
#endif
//		}else{
#ifdef	GP_S044
//2012.07.04			ret= PCDownThrue(rs_input_data,(int *)&Comm1RecMode,(int *)&Sio1RecCnt,Sio1RecBuff,(int *)&CommCnt);
			ret= PCDownThrue(EDITER,rs_input_data,(int *)&Comm1RecMode,(int *)&Sio1RecCnt,Sio1RecBuff,(int *)&CommCnt);
	#ifdef	WIN32
			CommRecWinKind= 0;
	#else
//KSC20090112
			wCommRecKind= 0;
	#endif
#endif
#ifdef	GP_S057
//2012.07.04			ret= PCDownThrue(rs_input_data,(int *)&Comm1RecMode,(int *)&Sio1RecCnt,Sio1RecBuff,(int *)&CommCnt);
			ret= PCDownThrue(EDITER,rs_input_data,(int *)&Comm1RecMode,(int *)&Sio1RecCnt,Sio1RecBuff,(int *)&CommCnt);
	#ifdef	WIN32
			CommRecWinKind= 0;
	#else
//KSC20090112
			wCommRecKind= 0;
	#endif
#endif
//		}
		break;
	case MONITOR:		/* PLC Monitor */
//2012.07.04		ret= PCDownThrue(rs_input_data,(int *)&Comm1RecMode,(int *)&Sio1RecCnt,Sio1RecBuff,(int *)&CommCnt);
		ret= PCDownThrue(MONITOR,rs_input_data,(int *)&Comm1RecMode,(int *)&Sio1RecCnt,Sio1RecBuff,(int *)&CommCnt);
		break;
	case BAR_CODE:		/* BarCode */
		ret= ConnectPcBarcode(rs_input_data,Sio1RecBuff,(int *)&Sio1RecCnt);
		break;
	case PLCTYPE2:		/* BarCode */
		if(CommonArea.PlcType2.AuxPlcUserFlag != 0){	/* 2008.12.10 */
			ret= PLC1CHAR_READ2(rs_input_data,(int *)&Comm1RecMode,(int *)&Sio1RecCnt,Sio1RecBuff);
		}
		break;
	}
	RsTimeOutCnt[1]= 5;
	RsTimeOutTask[1]= T_SIO1RCV;
	return(ret);
}
/********************************************************************/
/********************************************/
/*	Sio0(PLC)Connect						*/
/********************************************/
int	PlcConnect(unsigned char data)
{
	int	ret;
	int	iKind;

	ret = -1;
	if(Set.Ch1_iConnect == CH_CH0){
		iKind= Set.Ch1_iKind;
	}else{
		iKind= Set.Ch2_iKind;
	}
	switch(iKind){
	case UNIVERSAL:						/* UNIVERSAL */
		ret= RxCommProc(data,(int *)&Comm0RecMode,(int *)&Sio0RecCnt,Sio0RecBuff);
		break;
	case DEFAULT_PLC:
		ret= PlcRecRS(data,(int *)&Comm0RecMode,(int *)&Sio0RecCnt,Sio0RecBuff);
		break;
	case ELSE_PLC:				/* ���̑�PLC */
//		if(ElsPlcOK == 1){
		if(CommonArea.PlcType1.PlcUserFlag != 0){	/* 2008.12.10 */
			ret= PLC1CHAR_READ(data,(int *)&Comm0RecMode,(int *)&Sio0RecCnt,Sio0RecBuff);
		}
		break;
	case EDITER:		/* Editor */
#ifdef	LP_S044
//		if(IsGlpType() == OK){		//GLP TYPE
			if((Comm0RecMode == 0) && (data != 0xfe)){
				ret= Rs232c_Char_Proc(data,(int *)&Sio0SndCnt,Sio0SndBuff,(int *)&Sio0RecCnt,Sio0RecBuff);
//KSC20090112
				wCommRecKind0= 1;
			}else{
//2012.07.04				ret= PCDownThrue(data,(int *)&Comm0RecMode,(int *)&Sio0RecCnt,Sio0RecBuff,(int *)&CommCnt);
				ret= PCDownThrue(EDITER,data,(int *)&Comm0RecMode,(int *)&Sio0RecCnt,Sio0RecBuff,(int *)&CommCnt);
//KSC20090112
				wCommRecKind0= 0;
			}
#endif
//		}else{
#ifdef	GP_S044
//2012.07.04			ret= PCDownThrue(data,(int *)&Comm0RecMode,(int *)&Sio0RecCnt,Sio0RecBuff,(int *)&CommCnt);
			ret= PCDownThrue(EDITER,data,(int *)&Comm0RecMode,(int *)&Sio0RecCnt,Sio0RecBuff,(int *)&CommCnt);
//KSC20090112
			wCommRecKind0= 0;
#endif
#ifdef	GP_S057
//2012.07.04			ret= PCDownThrue(data,(int *)&Comm0RecMode,(int *)&Sio0RecCnt,Sio0RecBuff,(int *)&CommCnt);
			ret= PCDownThrue(EDITER,data,(int *)&Comm0RecMode,(int *)&Sio0RecCnt,Sio0RecBuff,(int *)&CommCnt);
//KSC20090112
			wCommRecKind0= 0;
#endif
//		}
		break;
	case MONITOR:		/* PLC Monitor */
//2012.07.04		ret= PCDownThrue(data,(int *)&Comm0RecMode,(int *)&Sio0RecCnt,Sio0RecBuff,(int *)&CommCnt);
		ret= PCDownThrue(MONITOR,data,(int *)&Comm0RecMode,(int *)&Sio0RecCnt,Sio0RecBuff,(int *)&CommCnt);
		break;
	case BAR_CODE:		/* BarCode */
		ret= ConnectPcBarcode(data,Sio0RecBuff,(int *)&Sio0RecCnt);
		break;
	case PLCTYPE2:		/* BarCode */
		if(CommonArea.PlcType2.AuxPlcUserFlag != 0){	/* 2008.12.10 */
			ret= PLC1CHAR_READ2(data,(int *)&Comm0RecMode,(int *)&Sio0RecCnt,Sio0RecBuff);
		}
		break;
	}
	RsTimeOutCnt[0]= 5;
	RsTimeOutTask[0]= T_SIO0RCV;
	return(ret);
}
