/*************************************************
    FUNC  : Display Program(Simuration)
    Create: 2002.4.28	M.Owash
**************************************************/
#include	"define.h"
#ifdef	SIZE_2480_COL

#define	DISPSIM_PROC
#include "sgt.h"
#include "graphics.h"



#define __TEXT(quote) quote         // r_winnt
#define TEXT(quote) __TEXT(quote)   // r_winnt


#define	VECT_ENTRY

/****************************************************/
/*	Draw Line										*/
/****************************************************/
void    XInc( void )
{
    pGraphicMemory++;
}
void    XDec( void )
{
    pGraphicMemory--;
}
void    YInc( void )
{
	pGraphicMemory += GAMEN_X_SIZE;
}
void    YDec( void )
{
	pGraphicMemory -= GAMEN_X_SIZE;
}
#ifdef	XXXX
void * malloc(size_t p)
{
	return(TakeMemory(p));
}
void   free(void * p)
{
	FreeMail((char*)p);
}
#endif

void	__MoveTo( int sx, int sy, int Pattern, int Mode, COLOR_DT Color )
{
	int	WinNo;

	WinNo= TaskWindowNo[_RunTaskNo];
    LastPos.x= (short)sx;
    LastPos.y= (short)sy;
	if( LastPos.x <    0 ){	LastPos.x= 0;	}
	if( LastPos.x >= GAMEN_X_SIZE ){	LastPos.x= GAMEN_X_SIZE-1;	}
	if( LastPos.y <    0 ){	LastPos.y= 0;	}
	if( LastPos.y >= GAMEN_Y_SIZE ){	LastPos.y= GAMEN_Y_SIZE-1;	}
	DrawPtn= Pattern;

    pGraphicMemory= &LcdBuff[WinNo][LastPos.y][LastPos.x];
	*pGraphicMemory= Color;
}
void    DrawHorizontal( int sx, int ex, int y, COLOR_DT color )
{
	for( ;sx <= ex; sx++ ) {
		if(ColorPat[DrawPtn][LineBit] != 0){
			*pGraphicMemory++ = color;
		}else{
			*pGraphicMemory++;
		}
		LineBit= (LineBit + 1) % 24;
	}
}
void    DrawHorizontalPrn( int sx, int ex, int y, COLOR_DT color )
{
    for( ;sx <= ex;  sx++) {
		if(ColorPat[DrawPtn][LineBit] != 0){
			*pGraphicMemory++ = color;
		}else{
			*pGraphicMemory++;
		}
		LineBit= (LineBit + 1) % 24;
	}
    LastPos.x= (short)sx;
    LastPos.y= (short)y;

}
void    RDrawHorizontal( int sx, int ex, int y, COLOR_DT color )
{
	int	WinNo;

	WinNo= TaskWindowNo[_RunTaskNo];
	pGraphicMemory= &LcdBuff[WinNo][LastPos.y][sx];
	for( ;sx >= ex; sx-- ){
		if(ColorPat[DrawPtn][LineBit] != 0){
			*pGraphicMemory= color;
		}
		pGraphicMemory--;
	    LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
	}
}
void    RDrawHorizontalPrn( int sx, int ex, int y, COLOR_DT color )
{
	for( ;sx >= ex; sx--){
		if(ColorPat[DrawPtn][LineBit] != 0){
			*pGraphicMemory-- = color;
		}else{
			*pGraphicMemory--;
		}
		LineBit= (LineBit + 1) % 24;
	}
    LastPos.x= (short)sx;
    LastPos.y= (short)y;

}
void    DrawVertical( int x, int sy, int ey, COLOR_DT color )
{
    for( ;sy <= ey; sy++ ) {
		if(ColorPat[DrawPtn][LineBit] != 0){
		    *pGraphicMemory= color;
		}
		pGraphicMemory += GAMEN_X_SIZE;
		LineBit= (LineBit + 1) % 24;
     }
}
void    DrawVerticalPrn( int x, int sy, int ey, COLOR_DT color )
{
    for( ;sy <= ey; sy++ ) {
		if(ColorPat[DrawPtn][LineBit] != 0){
		    *pGraphicMemory= color;
		}
		pGraphicMemory += GAMEN_X_SIZE;
        LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
	}
	LastPos.x= (short)x;
	LastPos.y= (short)ey;
}
void    RDrawVertical( int x, int sy, int ey, COLOR_DT color )
{
	int	WinNo;

	WinNo= TaskWindowNo[_RunTaskNo];
	pGraphicMemory= &LcdBuff[WinNo][sy][x];
    for( ;sy >= ey; sy-- ) {
		if(ColorPat[DrawPtn][LineBit] != 0){
			*pGraphicMemory= color;
		}
		pGraphicMemory -= GAMEN_X_SIZE;
        LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
     }
}
void    RDrawVerticalPrn( int x, int sy, int ey, COLOR_DT color )
{
    for( ;sy >= ey; sy-- ) {
		if(ColorPat[DrawPtn][LineBit] != 0){
			*pGraphicMemory= color;
		}
		pGraphicMemory -= GAMEN_X_SIZE;
        LineBit= LineBit < 23 ? LineBit + 1 : LineBit - 23;
     }
	LastPos.x= (short)x;
	LastPos.y= (short)ey;
}

void    DrawFnc( int DMst, int DSlave, void (*pMainMoveFnc)(void), void (*pSlaveMoveFnc)(void ), COLOR_DT color )
{
    int     i;
    int     Dlt;
    int     DMst2;
    int     DSlave2;

    Dlt= 0;
    DSlave2= DSlave + DSlave;
    DMst2= DMst + DMst;
    for( i= 0; i < DMst; i++ ) {
        Dlt -= DSlave2;
        if ( Dlt + DMst < 0 ) {
            (*pSlaveMoveFnc)();
            Dlt += DMst2;
        }
        (*pMainMoveFnc)();
		if(ColorPat[DrawPtn][LineBit] != 0){
		    *pGraphicMemory= color;
		}
		LineBit = (LineBit + 1) % 24;
    }
}
/********************************************************************************************/
/*	Text Disp Proc																			*/
/********************************************************************************************/
void	XNonSetFont(int mode,COLOR_DT **LcdPos,unsigned char **FontPos,int cnt,COLOR_FRM *color)
{
	int	i;
	int	andData;
	unsigned char c;

	andData= 0;
	for(i= 0; i < cnt; i++){
		if(andData == 0){
			c= *(*FontPos)++;
			andData= 0x80;
		}
		switch(mode){
		case T_REPLACE:
			if(c & andData){
				*(*LcdPos)++ = color->forColor;
			}else{
				*(*LcdPos)++ = color->backColor;
			}
			break;
		case T_FRONT:
		case T_OR:
			if(c & andData){
				*(*LcdPos)++ = color->forColor;
			}else{
				(*LcdPos)++;
			}
			break;
		case T_XOR:
			break;
		}
		andData >>= 1;
	}
}

unsigned char *SetHanFontPos(int xbai,int ybai,int idx)
{
	unsigned char *ret;
	int		AddrIdx;
	int		ByteCnt;

	AddrIdx= MitudoFont[xbai- 3][ybai-2].addr;
	ByteCnt= MitudoFont[xbai- 3][ybai-2].ByteCnt;
	if(idx == 0x0e){		/* . */
//		ret = (unsigned char *)&FontArea[AddrIdx+ 15*ByteCnt];
		ret = (unsigned char *)&GpFont[AddrIdx+ 15*ByteCnt];
	}else if(idx < 0x20){	/* 0->9 */
//		ret = (unsigned char *)&FontArea[AddrIdx+ (idx- 0x10)*ByteCnt];
		ret = (unsigned char *)&GpFont[AddrIdx+ (idx- 0x10)*ByteCnt];
	}else{					/* A->F */
		if(idx == 0x26){
//			ret = (unsigned char *)&FontArea[AddrIdx+ 16*ByteCnt];
			ret = (unsigned char *)&GpFont[AddrIdx+ 16*ByteCnt];
		}else{
//			ret = (unsigned char *)&FontArea[AddrIdx+ (idx- 0x21+ 10)*ByteCnt];
			ret = (unsigned char *)&GpFont[AddrIdx+ (idx- 0x21+ 10)*ByteCnt];
		}
	}
	return(ret);
}

int	DotWriteFont0(int type,int x,int y,unsigned char *addr,int back,int xbai,int ybai,int mode,int idx,int mitudo, COLOR_FRM* color)
{
	COLOR_DT	*LcdPos;
	unsigned char	*FontPos;
	unsigned char	*TateFontPos;
	int		i,j;
	int		Xcnt,Ycnt;
	int		WinNo;
	int		mflag;

	WinNo= TaskWindowNo[_RunTaskNo];
	mflag= 0;
	if(type == 0){				/* ASCII(���p����) */
		FontPos = addr;
		if(xbai == 0){								/* 6*8 */
			Xcnt = 6;
			Ycnt = 8;
		}else if((xbai == 1) && (ybai == 0)){		/* 8*8 */
			Xcnt = 8;
			Ycnt = 8;
		}else if((xbai == 1) && (ybai == 1)){		/* 8*16 */
			Xcnt = 8;
			Ycnt = 16;
		}else{
			Xcnt = 8*xbai;
			Ycnt = 16*ybai;
			if((mitudo == 1) && (CheckHan(idx) == 1) && 
				((xbai == 3) || (xbai == 4) || (xbai == 6) || (xbai == 8)) && ((ybai > 1) && (ybai < 5))){
				/* HEX FONT */
				FontPos= SetHanFontPos(xbai,ybai,idx);
			}else{
				FontData= (unsigned char *)TakeMemory(2*8*16*8);
				mflag= 1;
				memset(FontData,0,2*8*16*8);
				BaiFont(addr,xbai,ybai,1);
				FontPos = (unsigned char *)FontData;
			}
		}
	}else{					/* �S�p���� */
		if(xbai == 0){
			Xcnt= 6*2;
			Ycnt= 8;
		}else{
			Xcnt = 16*xbai;
			if(ybai == 0){
				Ycnt= 8;
			}else{
				Ycnt = 16*ybai;
			}
		}
		FontData= (unsigned char *)TakeMemory(2*8*16*8);
		mflag= 1;
		memset(FontData,0,2*8*16*8);
		BaiFont((unsigned char *)addr,xbai,ybai,2);
		FontPos = (unsigned char *)FontData;
	}
	/* �c?���ϊ�?�F�b�N */
	if(TateYoko != 0){
		TateFontPos= (unsigned char *)TakeMemory(2*8*16*8);
		ChangeTateYoko(TateFontPos,FontPos,Xcnt,Ycnt);
		if(mflag == 1){
			FreeMail((char *)FontData);
		}
		FontData= TateFontPos;
		FontPos= TateFontPos;
		i = Xcnt;
		Xcnt= Ycnt;
		Ycnt= i;
		y-= Ycnt;
		if(y < 0){
			FreeMail((char *)FontData);
			return(-1);
		}
		if(Ycnt == 6){
			memcpy(TateFontPos,(TateFontPos+2),6);
		}
	}else{
		if(x+ Xcnt > GAMEN_X_SIZE){
			if(mflag == 1){
				FreeMail((char *)FontData);
			}
			return(-1);
		}
	}
	if(x >= 0){			/* X Address */
		for(j = 0; j < Ycnt; j++){
			LcdPos= &LcdBuff[WinNo][y+j][x];
			XNonSetFont(mode,&LcdPos,&FontPos,Xcnt,color);
		}
	}
	if((TateYoko != 0) || (mflag == 1)){
		FreeMail((char *)FontData);
	}
	if(TateYoko != 0){	return(Ycnt);	}
	else{				return(Xcnt);	}
}
void	DotWriteFont2(int x,int y,unsigned char *addr,int back, int xbai, int ybai, int mode, int mitudo, COLOR_FRM *color)
{
	unsigned char	*FontPos;
	int		i;
	int		XCurPos;
	int		ret;
	int		idx;
//	int		WinNo;

//	WinNo= TaskWindowNo[_RunTaskNo];
	XCurPos = 0;
	for(i = 0; ; i++){
		if(addr[i] == 0){
			break;
		}
		if(addr[i] < 0x80){					/* ���p���� */
			idx= addr[i];
			if(idx < 0x20){					/* �R���g��?���R?�h */
				FontPos= (unsigned char *)&BlackFont[0];
			}else{
				idx -= 0x20;
				if(xbai == 0){								/* 6(x)*8(y) */
//					FontPos = (unsigned char *)&FontArea[FONT_ASCII68+ idx*8];
					FontPos = (unsigned char *)&GpFont[FONT_ASCII68+ idx*8];
				}else if((xbai == 1) && (ybai == 0)){		/* 8(x)*8(y) */
//					FontPos = (unsigned char *)&FontArea[FONT_ASCII88+ idx*8];
					FontPos = (unsigned char *)&GpFont[FONT_ASCII88+ idx*8];
				}else{										/* 8(x)*16(y) */
//					FontPos = (unsigned char *)&FontArea[FONT_ASCII816+ idx*16];
					FontPos = (unsigned char *)&GpFont[FONT_ASCII816+ idx*16];
				}
			}
			if(TateYoko == 0){
				ret = DotWriteFont0(0,x+XCurPos,y,FontPos,back,xbai,ybai,mode,idx,mitudo,color);
			}else{
				ret = DotWriteFont0(0,y,(GAMEN_Y_SIZE- x)-XCurPos,FontPos,back,xbai,ybai,mode,idx,mitudo,color);
			}
			if(ret < 0){
				return;
			}
			XCurPos += ret;
		}else{						/* �S�p���� */
			if(xbai == 0){			/* 6*8 */
				FontPos = (unsigned char *)BlackFont;
			}else{
				FontPos = (unsigned char *)GetZenkakuFont((unsigned char *)&addr[i]);
			}
			i++;
			if(TateYoko == 0){
				ret = DotWriteFont0(1,x+XCurPos,y,FontPos,back,xbai,ybai,mode,0,0,color);
			}else{
				ret = DotWriteFont0(1,y,(GAMEN_Y_SIZE- x)-XCurPos,FontPos,back,xbai,ybai,mode,0,0,color);
			}
			if(ret < 0){
				return;
			}
			XCurPos += ret;
		}
	}

}
void	PaintPatarn1Line(int sx,int ex,int y,int Paint,int Fcolor,int Bcolor,int mode)
{
	int		i,j;
	int		AndBit;
	int		*PatarnAddr;
	int		pidx;
	COLOR_DT	*LcdPos;
	COLOR_DT	*SrcLcdPos;
	int	WinNo;
	int		sxx,yy,eyy;
	COLOR_FRM	color;

	color.forColor= ChgColorData(Fcolor);
	color.backColor= ChgColorData(Bcolor);
	WinNo= TaskWindowNo[_RunTaskNo];
	if(TateYoko == 0){
		sxx= sx;
		yy= y;
	}else{
		sxx= y;
		yy= (GAMEN_Y_SIZE-1)- sx;
		eyy= (GAMEN_Y_SIZE-1)- ex;
		if(yy < eyy){
			eyy= (GAMEN_Y_SIZE-1)- sx;
			yy= (GAMEN_Y_SIZE-1)- ex;
		}
	}
	if((TateYoko == 0) || (mode == 0)){
//		AndBit= 0x80 >> (sx % 8);
//		PatarnAddr= (int *)&PaintPatarn[Paint][y% 8];
		AndBit= sx % 8;
		PatarnAddr= (int *)&PaintPatarn[Paint][(y% 8)*8];
		LcdPos= &LcdBuff[WinNo][y][sx];
		for(i= 0,j = sx; j <= ex; j++, i++){
			if(i < 8){
//				if((*PatarnAddr & AndBit) != 0){	*LcdPos= color.forColor;	}
				if(PatarnAddr[AndBit]){	*LcdPos= color.forColor;	}
				else{						*LcdPos= color.backColor;}
				LcdPos++;
//				AndBit= AndBit >> 1;
//				if(AndBit == 0){					AndBit= 0x80;			}
				AndBit= (AndBit+1)&7;
			}else{
				break;
			}
		}
		SrcLcdPos= &LcdBuff[WinNo][y][sx];
		for(; j <= ex; j++){
			*LcdPos++ = *SrcLcdPos++;
		}
	}else{
		LcdPos= &LcdBuff[WinNo][yy][sxx];
//		AndBit= 0x80 >> (sx % 8);
//		pidx= y % 8;
		AndBit= sx % 8;
		pidx= (y % 8)*8;
		PatarnAddr= (int *)&PaintPatarn[Paint][pidx];
		for(j = sx; j <= ex; j++){
//			if((*PatarnAddr & AndBit) != 0){
			if(PatarnAddr[AndBit]){
				*LcdPos= color.forColor;
			}else{
				*LcdPos= color.backColor;
			}
//			AndBit= AndBit >> 1;
//			if(AndBit == 0){
//				AndBit= 0x80;
//			}
			AndBit= (AndBit+1)&7;
			LcdPos -= GAMEN_X_SIZE;
		}
	}
}
/*************************************************
*   FUNC   : Put Image Memory                    *
*	In     : 									 *
*	Out    : 									 *
*   AUTHOR :                                     *
*   DATE   : 1996.11.7                           *
**************************************************/
void	PutImage( int ssx, int ssy, int eex, int eey, COLOR_DT *pScrBuff)
{
    int     x;
    int     y;
	COLOR_DT* Pos;
	COLOR_DT* pMem;
	int	WinNo;
	int		lenX;
	int		lenY;
	COLOR_DT *ScrBuff;
	COLOR_DT *mp;
	int sx, sy, ex, ey;
//	COLOR_FRM	color;

	WinNo= TaskWindowNo[_RunTaskNo];
//	FrontColor= T_WHITE;
//	BackColor= T_BLACK;
//	color.forColor= ChgColorData(T_WHITE);
//	color.backColor= ChgColorData(T_BLACK);
	if(TateYoko == 0){
		ScrBuff= pScrBuff;
		sx= ssx;
		sy= ssy;
		ex= eex;
		ey= eey;
	}else{		/* Tate->Yoko */
		lenX= eex- ssx+ 1;
		lenY= eey- ssy+ 1;
		mp= (COLOR_DT *)TakeMemory(lenY*lenX*sizeof(unsigned int));
		ChangeTateYoko((unsigned char *)mp,(unsigned char *)pScrBuff,lenX*8,lenY*8);
		ScrBuff= mp+ (8- ((eex- ssx+ 1) % 8))* lenY;
		sx= ssy;
		sy= (GAMEN_Y_SIZE-1)- ssx;
		ex= eey;
		ey= (GAMEN_Y_SIZE-1)- eex;
		if(sx > ex){
			sx= eey;
			ex= ssy;
		}
		if(sy > ey){
			sy= (GAMEN_Y_SIZE-1)- eex;
			ey= (GAMEN_Y_SIZE-1)- ssx;
		}
	}
	SetDispSema();
    for( y= sy; y <= ey; y++ ) {
        Pos= ScrBuff + ( y - sy ) * ( (ex - sx) + 1 );
        pMem= &LcdBuff[WinNo][y][sx];
		for(x= sx; x <= ex; x++){
			*pMem++= *Pos;
		}
    }
	if(TateYoko != 0){
		FreeMail((char *)mp);
	}
	ResetDispSema();
}
/*************************************************
*   FUNC   : Put Image Memory                    *
*	In     : 									 *
*	Out    : 									 *
*   AUTHOR :                                     *
*   DATE   : 1996.11.7                           *
**************************************************/
void	PutImageGp( int ssx, int ssy, int eex, int eey, char *pScrBuff)
{
    int     x;
    int     y;

	int		Cnt;
	char* Pos;
	COLOR_DT* pMem;
	int	WinNo;
	char *ScrBuff;
	int sx, sy, ex, ey;
	int	andData;
	unsigned char	ch;
	COLOR_FRM	color;

	WinNo= TaskWindowNo[_RunTaskNo];
//	FrontColor= T_WHITE;
//	BackColor= T_BLACK;
	color.forColor= ChgColorData(T_WHITE);
	color.backColor= ChgColorData(T_BLACK);
	Cnt= (eex - ssx + 1) / 8;
	if((eex - ssx + 1) % 8){
		Cnt++;
	}
	if(Cnt % 4){
		Cnt=((Cnt / 4)+1)*4;
	}
	ScrBuff= pScrBuff;
	SetDispSema();
	if(TateYoko == 0){
		sx= ssx;
		sy= ssy;
		ex= eex;
		ey= eey;
		for( y= ey; y >= sy; y-- ) {
			Pos= ScrBuff + ( ey - y ) * Cnt;
			pMem= &LcdBuff[WinNo][y][sx];
			andData= 0x80;
			ch= *Pos++;
			for(x= sx; x <= ex; x++){
				if(ch & andData){
					*pMem++= color.forColor;
				}else{
					*pMem++= color.backColor;
				}
				andData >>= 1;
				if(andData == 0){
					andData= 0x80;
					ch= *Pos++;	
				}
			}
		}
	}else{				/* TATE */
		sx= ssy;
		sy= (GAMEN_Y_SIZE-1)- ssx;
		ex= eey;
		ey= (GAMEN_Y_SIZE-1)- eex;
		if(sx > ex){
			sx= eey;
			ex= ssy;
		}
		if(sy > ey){
			sy= (GAMEN_Y_SIZE-1)- eex;
			ey= (GAMEN_Y_SIZE-1)- ssx;
		}
		/* 0->40 */
		for(y= sx; y <= ex; y++){
			Pos= ScrBuff + ( ex - y ) * Cnt;
			/*79->36 */
			pMem= &LcdBuff[WinNo][x][y];
			andData= 0x80;
			ch= *Pos++;
			for( x= ey; x >= sy; x-- ) {
				if(ch & andData){
					*pMem++= color.forColor;
				}else{
					*pMem++= color.backColor;
				}
				andData >>= 8;
				if(andData == 0){	ch= *Pos++;	}
				
			}
		}
	}
	ResetDispSema();
}
/*************************************************
*   FUNC   : Get Image Memory                    *
*	In     : 									 *
*	Out    : 									 *
*   AUTHOR :                                     *
*   DATE   : 1996.11.7                           *
**************************************************/
void	GetImage( int sx, int sy, int ex, int ey, COLOR_DT *ScrBuff)
{
	int		i,j;
	int		cnt_x,cnt_y;
	COLOR_DT	*g_adr;
	COLOR_DT	*pos;
	int	WinNo;

	WinNo= TaskWindowNo[_RunTaskNo];
	pos = ScrBuff;		/* Unsigned Short Change */
	cnt_x = ex - sx + 1;	/* X-Dir Byte Count */
	cnt_y = ey - sy + 1;
	for(i = 0; i < cnt_y; i++){
		g_adr = &LcdBuff[WinNo][sy + i][0];	/* Y Dir Memory Addr */
		for(j = 0; j < cnt_x; j++){
			pos[i * cnt_x + j] = g_adr[sx + j];
		}
	}
}
/****************************************************
*  Draw Dot											*
*													*
*****************************************************/
void	Dot(int	x, int y,COLOR_DT color)
{
	int		xx,yy;
	int	WinNo;

	WinNo= TaskWindowNo[_RunTaskNo];
	if(TateYoko == 0){
		xx= x;
		yy= y;
	}else{
		xx= y;
		yy= (GAMEN_Y_SIZE-1)- x;
	}
	if((xx < 0) || (xx > GAMEN_X_SIZE-1)){
		return;
	}
	if((yy < 0) || (yy > (GAMEN_Y_SIZE-1))){
		return;
	}
	if(yy < minY){
		minY= yy;
	}
	if(yy > maxY){
		maxY= yy;
	}
	pGraphicMemory= &LcdBuff[WinNo][yy][xx];
    *pGraphicMemory= color;
}
void	AreaClear(int ssx,int ssy,int eex,int eey,int back)
{
	int		i,k;
	int		sx,sy,ex,ey;
	COLOR_DT *LcdPos;
	COLOR_DT *SrcLcdPos;
	int	WinNo;
	COLOR_DT BackColor;
	int	xCnt;

	BackColor= ChgColorData(back);
	if(TateYoko == 0){
		sx= ssx;
		sy= ssy;
		ex= eex;
		ey= eey;
	}else{
		sx= ssy;
		sy= (GAMEN_Y_SIZE-1)- ssx;
		ex= eey;
		ey= (GAMEN_Y_SIZE-1)- eex;
	}
	if(sx > ex){
		i= sx;
		sx= ex;
		ex= i;
	}
	if(sy > ey){
		i= sy;
		sy= ey;
		ey= i;
	}
	WinNo= TaskWindowNo[_RunTaskNo];
	SetDispSema();

	i = sy;
	SrcLcdPos= &LcdBuff[WinNo][i][sx];
	LcdPos= &LcdBuff[WinNo][i][sx];
	for(k= sx; k <= ex; k++){
		*LcdPos++ = BackColor;
	}
	xCnt= (ex- sx+ 1)*sizeof(COLOR_DT);
	for(i = sy+1; i <= ey && i < GAMEN_Y_SIZE; i++){
		LcdPos= &LcdBuff[WinNo][i][sx];
#ifdef	USE_DMA
		DmaCopy((unsigned int)LcdPos,(unsigned int)SrcLcdPos,xCnt);
#else
		memcpy(LcdPos,SrcLcdPos,xCnt);
#endif
	}
	ResetDispSema();
}
void	AreaRevers(int ssx,int ssy,int eex,int eey)
{
	int		i,k;
	int		sx,sy,ex,ey;
	COLOR_DT *LcdPos;
	int	WinNo;
//	COLOR_DT	data;

	if(TateYoko == 0){
		sx= ssx;
		sy= ssy;
		ex= eex;
		ey= eey;
	}else{
		sx= ssy;
		sy= (GAMEN_Y_SIZE-1)- ssx;
		ex= eey;
		ey= (GAMEN_Y_SIZE-1)- eex;
		if(ex < sx){
			sx= eey;
			ex= ssy;
		}
		if(ey < sy){
			sy= (GAMEN_Y_SIZE-1)- eex;
			ey= (GAMEN_Y_SIZE-1)- ssx;
		}
	}
	WinNo= TaskWindowNo[_RunTaskNo];
	SetDispSema();
	for(i = sy; i <= ey && i < GAMEN_Y_SIZE; i++){
		LcdPos= &LcdBuff[WinNo][i][sx];
		for(k= sx; k <= ex; k++){

			*LcdPos= ~*LcdPos;
			LcdPos++;
		}
	}
	ResetDispSema();
}
/************************************************/
/*	Window Move(OR)								*/
/************************************************/
void	PutWindow( int sx, int sy, int ex, int ey,int no,int Start,LCD_BUF *lcdb)
//void	PutWindow( _AREA_INFO* darea,int no,_AREA_INFO* sarea,LCD_BUF *lcdb)
{
	int		i;
//    int     x;		//2011.05.24
    int     y;
	int		cnt;		//2011.05.24

	COLOR_DT* Pos;
	COLOR_DT* pMem;

	cnt= ex- sx+ 1;		//2011.05.24
    for( y= Start,i= sy; y <= ey; y++, i++ ) {
        Pos= &LcdBuff[no][i][sx];
        pMem= &lcdb->lbuff[y][sx];
//		for( x= darea->sx; x <= darea->ex; x++){	//2011.05.24
//			scolor= *Pos++;
//			ocolor= *pMem;
//			ocolor.r |= scolor.r;
//			ocolor.g |= scolor.g;
//			ocolor.b |= scolor.b;
//			*pMem++= ocolor;
//			*pMem++ |= *Pos++;
//		}
#ifdef	USE_DMA
		DmaCopy((unsigned int)pMem,(unsigned int)Pos,sizeof(COLOR_DT)*cnt);
#else
		memcpy(pMem,Pos,sizeof(COLOR_DT)*cnt);		//2011.05.24
#endif
    }
}

void	PutWindowForward( _AREA_INFO* darea,int no,_AREA_INFO* sarea,LCD_BUF *lcdb)
{
	int		i;
    int     x;
    int     y;

	COLOR_DT* Pos;
	COLOR_DT* pMem;

    for( y= darea->sy,i= sarea->sy; y <= darea->ey; y++, i++ ) {
        Pos= &LcdBuff[no][i][sarea->sx];
        pMem= &lcdb->lbuff[y][darea->sx];
		for( x= darea->sx; x <= darea->ex; x++){
			if(*Pos != 0){
				*pMem= *Pos;
			}
			pMem++;
			Pos++;
		}
    }
}
//2011.09.19 Add/////////////////////////////////////////////////
void	PutWindowRev( int sx, int sy, int ex, int ey,int no,int Start,LCD_BUF *lcdb)
{
}

void	PutWindowReplace( int sx, int sy, int ex, int ey,int no,int Start,LCD_BUF *lcdb)
//void	PutWindowReplace( _AREA_INFO* darea,int no,_AREA_INFO* sarea,LCD_BUF *lcdb)
{
	int		i;
//    int     x;
    int     y;
	int		cnt;

	COLOR_DT* Pos;
	COLOR_DT* pMem;

	cnt= (ex- sx+ 1)*sizeof(COLOR_DT);
    for( y= Start,i= sy; y <= ey; y++, i++ ) {
        Pos= &LcdBuff[no][i][sx];
        pMem= &lcdb->lbuff[y][sx];
//		memcpy(pMem,Pos,(ex- sx+ 1)*sizeof(COLOR_DT));
#ifdef	USE_DMA
		DmaCopy((unsigned int)pMem,(unsigned int)Pos,cnt);
#else
		memcpy(pMem,Pos,cnt);
#endif
    }
}
#ifdef	USE_DMA
void DmaCopy(unsigned int dst, unsigned int src, unsigned int cnt)			// src=fix, dst=increment, cnt=byte
{
	unsigned int	sCnt;
	volatile DMA_REG* pDmaReg= (DMA_REG*)DMA_BASE;

	cnt /= 4;

	while(1){
//		if(cnt > 0xFFFFF){	sCnt= 0xFFFFF;	}
		if(cnt > 0x7FFF){	sCnt= 0x7FFF;	}
		else{				sCnt= cnt;		}

		pDmaReg->rDISRCC0=(0<<1)+(0<<0);					// AHB, Increment 
		pDmaReg->rDISRC0=(src&0x7FFFFFFF);
		pDmaReg->rDIDSTC0=(0<<1)+(0<<0);					// AHB, Increment
		pDmaReg->rDIDST0=(dst&0x7FFFFFFF);

//		pDmaReg->rDCON0=(0<<31)+(1<<30)+(0<<29)+(0<<28)+(1<<27)+(0<<24)+(0<<23)+(0<<22)+(0<<20)+(sCnt&0xFFFFF);
		pDmaReg->rDCON0=(0<<31)+(1<<30)+(0<<29)+(0<<28)+(1<<27)+(0<<24)+(0<<23)+(0<<22)+(2<<20)+(sCnt&0xFFFFF);		//WORD

		pDmaReg->rDMASKTRIG0=(1<<1)+(1<<0);				// Start DMA Operation
		
		while(1){
			if((pDmaReg->rDSTAT0 & 0x00300000) == 0){
				break;
			}
		}

		cnt -= sCnt;
		if(cnt <= 0){	break;	}
		dst += (sCnt*4);
		src += (sCnt*4);
	}
}
void DmaClear(unsigned int dst, unsigned int clrData, unsigned int cnt)			// src=fix, dst=increment, cnt=byte
{
	unsigned int	sCnt;
	volatile DMA_REG* pDmaReg= (DMA_REG*)DMA_BASE;

	cnt /= 4;

	while(1){
//		if(cnt > 0xFFFFF){	sCnt= 0xFFFFF;	}
		if(cnt > 0x7FFF){	sCnt= 0x7FFF;	}
		else{				sCnt= cnt;		}

		pDmaReg->rDISRCC0=(0<<1)+(1<<0);					// AHB, Fix 
		pDmaReg->rDISRC0=(((unsigned int)&clrData)&0x7FFFFFFF);
		pDmaReg->rDIDSTC0=(0<<1)+(0<<0);					// AHB, Increment
		pDmaReg->rDIDST0=(dst&0x7FFFFFFF);

//		pDmaReg->rDCON0=(0<<31)+(1<<30)+(0<<29)+(0<<28)+(1<<27)+(0<<24)+(0<<23)+(0<<22)+(0<<20)+(sCnt&0xFFFFF);
		pDmaReg->rDCON0=(0<<31)+(1<<30)+(0<<29)+(0<<28)+(1<<27)+(0<<24)+(0<<23)+(0<<22)+(2<<20)+(sCnt&0xFFFFF);		//WORD

		pDmaReg->rDMASKTRIG0=(1<<1)+(1<<0);				// Start DMA Operation
		
		while(1){
			if((pDmaReg->rDSTAT0 & 0x00300000) == 0){
				break;
			}
		}

		cnt -= sCnt;
		if(cnt <= 0){	break;	}
		dst += (sCnt*4);
	}
}
#endif
void	MemoryAreaCopy(void* objMem,void* srcMem,int cnt)
{
#ifdef	USE_DMA
	DmaCopy((unsigned int)objMem,(unsigned int)srcMem,cnt);
#else
	memcpy(objMem,srcMem,cnt);
#endif
}
//void	MoveFloatArae1ToArea0(void)
//{
//	COLOR_DT* objMem;
//	COLOR_DT* srcMem;
//	int	cnt;
//
//	cnt= GAMEN_X_SIZE*wHight[FLOAT_SCREEN]*sizeof(COLOR_DT);
//	srcMem= &LcdBuff[1][wDspY[FLOAT_SCREEN]][0];
//	objMem= &LcdBuff[0][wDspY[FLOAT_SCREEN]][0];
//
//	MemoryAreaCopy(objMem,srcMem,cnt);					//2012.06.29
//}

/************************************************/
/*	Window Move									*/
/************************************************/
void	DrawLcdBank1(void)
{
	int		i;
	int		ex,ey;
	int		pos;		/* 060926 */
	LCD_BUF*	LcdBufAddr;
	unsigned int	*srcData;
	unsigned int	*objData;
#ifndef	WIN32
	#ifdef	GP_S057
//		int		j;
	#endif
#endif
	int		iBackColor;			//2011.09.19

	SetDispSema();
	memcpy((char *)&LcdBuff[0][0][0],(char *)&LcdBuff[1],sizeof(LcdBuff[0]));
	LcdBufAddr= (LCD_BUF *)&LcdBuff[0];
	for(i= 0; i < 3; i++){
		if(wWidth[i+ 2] > 0){		/* Window1�`4 */
			if((wDspX[i+ 2]+ wWidth[i+ 2]) > GAMEN_X_SIZE-1){
				ex= GAMEN_X_SIZE-1;
			}else{
				ex= wDspX[i+ 2]+ wWidth[i+ 2];
			}
			if((wDspY[i+ 2]+ wHight[i+ 2]) > (GAMEN_Y_SIZE-1)){
				ey= (GAMEN_Y_SIZE-1);
			}else{
				ey= wDspY[i+ 2]+ wHight[i+ 2];
			}
			if(WindowInfo[i+ 2] == 0){		/* AND */
				if(TateYoko == 0){
					PutWindowReplace(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,0,LcdBufAddr);
				}else{
/* 060926					PutWindowReplace(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,wDspY[i+ 2],LcdBufAddr);*/
					pos= wDspY[i+ 2]+ (GAMEN_Y_SIZE- wDspY[i+ 2]- wHight[i+ 2]- 1);		/* 060926 */
					if(pos < 0){
						pos= 0;
					}
					PutWindowReplace(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,pos,LcdBufAddr);
				}
			}else{							/* OR */
				iBackColor= NowBackColor(1);			//2011.09.19
#ifdef	SIZE_2480_COL
				if(TateYoko == 0){
					PutWindow(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,0,LcdBufAddr);
				}else{
					PutWindow(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,wDspY[i+ 2],LcdBufAddr);
				}
#else
				if( (iBackColor == WHITE) && ((i+ 2) == MSG_WINDOW) ){
					if(TateYoko == 0){
						PutWindowRev(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,0,LcdBufAddr);
					}else{
						PutWindowRev(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,wDspY[i+ 2],LcdBufAddr);
					}
				}else{
					if(TateYoko == 0){
						PutWindow(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,0,LcdBufAddr);
					}else{
						PutWindow(wDspX[i+ 2],wDspY[i+ 2],ex,ey,i+ 2,wDspY[i+ 2],LcdBufAddr);
					}
				}
#endif
			}
		}
	}
#ifndef	WIN32
	if(Set.LcdReverseOn == 0){
/* ȭ�� ǥ�� 3224�� 2480�� �ݴ�� �Ǿ� �ִ� �κ� ����ġ ��Ŵ.
	#ifdef	GP_S057
		objData= (unsigned int *)BaseLcd_Buffer;
		for(i= 0; i < GAMEN_Y_SIZE; i++){
			memcpy(objData,&LcdBuff[0][i][20],20);
			objData += 5;
			memcpy(objData,&LcdBuff[0][i][0],20);
			objData += 5;
		}
	#endif
	#ifdef	LP_S044
*/
		memcpy((char *)BaseLcd_Buffer,(char *)&LcdBuff[0],sizeof(LcdBuff[0]));
/*	#endif
*/
	}else{
		srcData= (unsigned int *)&LcdBuff[0][0][0];
		objData= (unsigned int *)BaseLcd_Buffer;
/*
	#ifdef	GP_S057
		for(i= 0; i < GAMEN_Y_SIZE; i++){
			srcData= (unsigned int *)&LcdBuff[0][i][20];
			for(j= 0; j < 5; j++){
				*objData++= ~*srcData++;
			}
			srcData= (unsigned int *)&LcdBuff[0][i][0];
			for(j= 0; j < 5; j++){
				*objData++= ~*srcData++;
			}
		}
	#endif
	#ifdef	LP_S044
*/
		for(i= 0; i < sizeof(LcdBuff[0])/4; i++){
			*objData++= ~*srcData++;
		}
/*
	#endif
*/
	}
#else
	if(Set.LcdReverseOn != 0){
		objData= (unsigned int *)&LcdBuff[0][0][0];
		srcData= (unsigned int *)&LcdBuff[0][0][0];
		for(i= 0; i < sizeof(LcdBuff[0])/4; i++){
			*objData++= ~*srcData++;
		}
	}
#endif
	ResetDispSema();
	DrawLcd((char *)LcdBufAddr);
}
void	ClearDispBuff(int WinNo)
{
	SetDispSema();
	TaskWindowNo[_RunTaskNo]= WinNo;
	DrawMode= 0;
//	ForGrandColor= ChgColorData(T_WHITE);
//	BackGrandColor= ChgColorData(T_BLACK);
#ifdef	USE_DMA
	DmaClear((unsigned int)&LcdBuff[WinNo], 0, sizeof(LcdBuff[WinNo]));
#else
	memset(&LcdBuff[WinNo], 0, sizeof(LcdBuff[WinNo]));
#endif
	ResetDispSema();
}
void	ClearDispBuffBackColor(int WinNo,int Color)
{
	int		i;
	COLOR_DT*	pos;
	int		cnt;
	COLOR_DT	backColor;

	SetDispSema();
	TaskWindowNo[_RunTaskNo]= WinNo;
	DrawMode= 0;
	backColor= ChgColorData(Color);
	cnt= sizeof(LcdBuff[WinNo][0])/sizeof(COLOR_DT);		//4Byte/Pixel
//First Line
	pos= &LcdBuff[WinNo][0][0];
	for(i= 0; i < cnt; i++){
		*pos++= backColor;
	}
	for(i= 0; i < GAMEN_Y_SIZE- 1; i++){
		MemoryAreaCopy(pos,&LcdBuff[WinNo],GAMEN_X_SIZE*sizeof(COLOR_DT));					//2012.06.29
		pos+= GAMEN_X_SIZE;
	}
	ResetDispSema();
}
#endif

