/****************************************/
/*	PLC�ʐM�v���O��?					*/
/****************************************/
/**************************************************************
*   Update:07.10.17 M.Owashi
*           [keyword:GLP_071017] ���ꃌ�W�X?�A���荞�ݏ����Ή�
***************************************************************/
#include	"sgt.h"
#ifdef	WIN32
	#define	const
	extern	void BitRunOnOffWin32C(int nOnBits);
#endif

extern	char	RecStationno[4];
extern	int		Matrix_Mode ;
#ifdef	WIN32
extern	int	AndTable[16];
#else
extern	const int	AndTable[16];
#endif

int	ChangeDeviceAddr(int flag,char *buff);
int	ChangeDeviceAddrDec(int flag,char *buff,int paddr);
int	GetCurr2Step(int pos);

#define	COM1BLK	0x10000

#ifdef	LP_S044

/**************************************/
//���j??�R?���h
int	BR_Comm(char *buff,char *SndBuff);
int	WR_Comm(char *buff,char *SndBuff);
int	BW_Comm(char *buff,char *SndBuff);
int	WW_Comm(char *buff,char *SndBuff);
int	ME_Comm(char *buff,char *SndBuff);
int	MR_Comm(char *buff,char *SndBuff);
int	MC_Comm(char *buff,char *SndBuff);
int	RW_Comm(char *buff,char *SndBuff);
int	RB_Comm(char *buff,char *SndBuff);

int	WP_Comm(char *buff,char *SndBuff);
int	EP_Comm(char *buff,char *SndBuff);
int	RP_Comm(char *buff,char *SndBuff);
int	PP_Comm(char *buff,char *SndBuff);
int	RI_Comm(char *buff,char *SndBuff);
int	RV_Comm(char *buff,char *SndBuff);
int	RA_Comm(char *buff,char *SndBuff);
int	WS_Comm(char *buff,char *SndBuff);
int	CP_Comm(char *buff,char *SndBuff);
int	CN_Comm(char *buff,char *SndBuff);
int	RM_Comm(char *buff,char *SndBuff);
int	PM_Comm(char *buff,char *SndBuff);
int	RS_Comm(char *buff,char *SndBuff);
int	RC_Comm(char *buff,char *SndBuff);
int	SR_Comm(char *buff,char *SndBuff);
//�f�o�b�O�R?���h
int	GO_Comm(char *buff,char *SndBuff);
int	ST_Comm(char *buff,char *SndBuff);
int	SG_Comm(char *buff,char *SndBuff);
int	SB_Comm(char *buff,char *SndBuff);
int	CB_Comm(char *buff,char *SndBuff);
int	DB_Comm(char *buff,char *SndBuff);
int	DW_Comm(char *buff,char *SndBuff);
int	DR_Comm(char *buff,char *SndBuff);
int	SC_Comm(char *buff,char *SndBuff);
int	IO_Comm(char *buff,char *SndBuff);

const	struct{
	char	*CommChar;
	int     (*RsCall)( char* buff,char *SndBuff );
}RsCommTbl[]={
//���j??�R?���h
	{"BR",(int(*)(char *,char *))BR_Comm},		//Bit Read
	{"WR",(int(*)(char *,char *))WR_Comm},		//Word Read
	{"BW",(int(*)(char *,char *))BW_Comm},		//Bit Write
	{"WW",(int(*)(char *,char *))WW_Comm},		//Word Write
	{"ME",(int(*)(char *,char *))ME_Comm},		//Monitor Entry
	{"MR",(int(*)(char *,char *))MR_Comm},		//Monitor Read
	{"MC",(int(*)(char *,char *))MC_Comm},		//Monitor Clear
	{"RW",(int(*)(char *,char *))RW_Comm},		//Continus Word Read
	{"RB",(int(*)(char *,char *))RB_Comm},		//Continus Bit Read
//���̑��R?���h
	{"WP",(int(*)(char *,char *))WP_Comm},		//Program Write
	{"EP",(int(*)(char *,char *))EP_Comm},		//File Edit
	{"RP",(int(*)(char *,char *))RP_Comm},		//File Read
	{"PP",(int(*)(char *,char *))PP_Comm},		//Program Puch
	{"RI",(int(*)(char *,char *))RI_Comm},		//IO Set Read
	{"RV",(int(*)(char *,char *))RV_Comm},		//Version Read
	{"RA",(int(*)(char *,char *))RA_Comm},		//Password Read
	{"WS",(int(*)(char *,char *))WS_Comm},		//Password Set
	{"CP",(int(*)(char *,char *))CP_Comm},		//Device Clear
	{"CN",(int(*)(char *,char *))CN_Comm},		//Connect
	{"RM",(int(*)(char *,char *))RM_Comm},		//Module Info Read
	{"PM",(int(*)(char *,char *))PM_Comm},		//Mode Set(RUN,STOP)
	{"RS",(int(*)(char *,char *))RS_Comm},		//Mode Read
	{"RC",(int(*)(char *,char *))RC_Comm},		//Program Sum Read
	{"SR",(int(*)(char *,char *))SR_Comm},		//Status Read
//�f�o�b�O�R?���h
	{"GO",(int(*)(char *,char *))GO_Comm},		//Execute
	{"ST",(int(*)(char *,char *))ST_Comm},		//Stop
	{"SG",(int(*)(char *,char *))SG_Comm},		//Step
	{"SB",(int(*)(char *,char *))SB_Comm},		//Set Break
	{"CB",(int(*)(char *,char *))CB_Comm},		//Clear Break
	{"DB",(int(*)(char *,char *))DB_Comm},		//Bit Device Break
	{"DW",(int(*)(char *,char *))DW_Comm},		//Word Device Break
	{"DR",(int(*)(char *,char *))DR_Comm},		//Reset Device Break
	{"SC",(int(*)(char *,char *))SC_Comm},		//Scan Exe
	{"IO",(int(*)(char *,char *))IO_Comm},		//Set IO

};
//Devaice Code Table

const	unsigned char GLPIndexTable[256]={
	/* BIT */
  /*       0    1    2    3    4    5    6    7    8    9    a    b    c    d    e    f */
/*0*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,B_UV,
/*1*/	B_UX,0xff,0xff,0xff,B_UY,0xff,0xff,0xff,B_UM,0xff,0xff,B_UF,0xff,0xff,0xff,0xff,
/*2*/	B_US,0xff,0xff,0xff,0xff,0xff,0xff,0xff,B_UL,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*3*/	B_UT,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*4*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*5*/	B_UC,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*6*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*7*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,B_UB,
	/* WORD */
/*8*/	W_UX,0xff,0xff,0xff,W_UY,0xff,0xff,0xff,W_UM,0xff,0xff,W_UF,0xff,0xff,0xff,0xff,
/*9*/	W_US,0xff,0xff,0xff,0xff,0xff,0xff,0xff,W_UL,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*a*/	W_UT,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*b*/	W_UC,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*c*/	W_UD,0xff,W_UR,0xff,0xff,0xff,0xff,0xff,W_UZ,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*d*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*e*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,W_UW,
/*f*/	W_UV,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,W_UK,
};
const	unsigned char GLPIndexChangeTable[256]={
	/* BIT */
  /*       0    1    2    3    4    5    6    7    8    9    a    b    c    d    e    f */
/*0*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,W_UV,
/*1*/	W_UX,0xff,0xff,0xff,W_UY,0xff,0xff,0xff,W_UM,0xff,0xff,W_UF,0xff,0xff,0xff,0xff,
/*2*/	W_US,0xff,0xff,0xff,0xff,0xff,0xff,0xff,W_UL,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*3*/	W_UT,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*4*/	W_UC,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*5*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*6*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*7*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,W_UW,
	/* WORD */
/*8*/	B_UX,0xff,0xff,0xff,B_UY,0xff,0xff,0xff,B_UM,0xff,0xff,B_UF,0xff,0xff,0xff,0xff,
/*9*/	B_US,0xff,0xff,0xff,0xff,0xff,0xff,0xff,B_UL,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*a*/	B_UT,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*b*/	B_UC,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*c*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*d*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
/*e*/	0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,B_UB,
/*f*/	B_UV,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,B_UK,
};
/*----------------------------------------------------------------------*/
/*	�֐���	: PlcCommCheck()											*/
/*	??	: ��M�R?���h?�F�b�N����									*/
/*			  ���M�̈�ɋǔԂ��i?����B								*/
/*	����	: char *buff->��M�̈�										*/
/*			  char *SndBuff->���M�f??�i?�̈�							*/
/*			  int cnt->��M��											*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	PlcCommCheck(char *buff,char *SndBuff,int cnt)
{
	int		i;
	int		ret;

	/* ���M�p�f??�쐬 */
	memcpy(&SndBuff[0],&RecStationno[2],2);
	memcpy(&SndBuff[2],&RecStationno[0],2);
	SmtStoRecCnt= cnt;
	if(WpFlag != 0){		/* �ŏ��̃��R?�h */
		switch(WpFlag){
		case 1:	ret= WP_Comm(&buff[0],&SndBuff[4]);	break;
		case 2:	ret= PP_Comm(&buff[0],&SndBuff[4]);	break;
		default:ret= PP_Comm(&buff[0],&SndBuff[4]);	break;
		}
		return(ret);
	}else{
		for(i= 0; i < TBQ(RsCommTbl); i++){
			if(memcmp(buff,RsCommTbl[i].CommChar,2) == 0){
				ret= RsCommTbl[i].RsCall(&buff[0],&SndBuff[4]);
				return(ret);
			}
		}
	}
	return(NG);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: InitPlcComm()												*/
/*	??	: Plc�f�o�b�O���N���A����									*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	InitPlcComm(void)
{
	WpFlag= 0;			/* WP�R?���h������ */
	memset(DevMon,0,sizeof(DevMon));
	ProgDownFlag= 0;
	memset(&Mon_Info,0,sizeof(Mon_Info));
	*GlpSysState &= ~(GLP_SYS_STATE_IO_IN | GLP_SYS_STATE_IO_OUT);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetBcc()													*/
/*	??	: ?�F�b�N�T?��t������B(�f??�̍Ō��)					*/
/*	����	: char *buff->�Ώۃo�b�t??								*/
/*			  int cnt->�Ώە�����										*/
/*	�߂�l	: ���M�J�E���g���iBCC�Ώە�����+HEAD(5)+BCC(2)�j			*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	SetBcc(char *buff,int cnt)
{
	int	sum;
	int	i;

	sum= 0;
	for(i= 0; i < cnt; i++){
		sum= sum ^ buff[i];
	}
	sprintf(&buff[cnt],"%02X",sum);
	return(cnt+7);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: MakeCodeTblSum()										*/
/*	??	: �w��̈��?�F�b�N�T?���v�Z����B						*/
/*			  unsigned short��sum���Ƃ�B								*/
/*	����	: unsigned short* src->�Ώۃo�b�t??						*/
/*			  int cnt->�Ώە�����										*/
/*	�߂�l	: sum														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
unsigned int MakeCodeTblSum(unsigned short* src,int cnt)
{
	int		i;
#ifdef	WIN32
	unsigned short data1;
	unsigned short data;
#endif
	unsigned int	ret;

	ret= 0;
	for(i= 0; i < cnt/2; i++)
	{
#ifdef	WIN32
		data1= *src++;
		data= (unsigned short)((data1 & 0xff) << 8);
		data |= (unsigned short)(data1 >> 8);
		ret += data;
#else
		ret += *src++;
#endif
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: ReciveEndProc()											*/
/*	??	: ��M�I�������B											*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	ReciveEndProc(void)
{
	int		fp;
	char	*ParamWork;
	int		cnt;
	int		ret= OK;

	/* 061104 */
	if(*TableCnt == 0){
		return(ret);
	}
	//Parameter File
	if(ProgDownFlag == PLC_PARAM){
		ParamWork= TakeMemory(MAX_PARAM_AREA);
		cnt= *TableCnt;
		if(cnt > MAX_PARAM_AREA-4){	cnt= MAX_PARAM_AREA-4;	}
		memcpy(&ParamWork[0x10],SWpWriteBuff,cnt);
		//DownLoad Cnt
		*(int *)ParamWork= cnt;
		//�o?�W����
		memcpy(&ParamWork[4],PlcPassword,strlen(PlcPassword));
#ifdef	WIN32
		memcpy(&GpFont[PLC_PARAM_FILE],ParamWork,cnt+0x10);
#else
		RamFlashEraze((short *)PLC_PARAM_FILE);
		RamFlashWrite((short *)PLC_PARAM_FILE,(short *)ParamWork,cnt+0x10);
#endif
		FreeMail(ParamWork);
		ParamIO2Fdevice();		//Move to Fdevice
		return(ret);
	}
	switch(ProgDownFlag){
	case PLC_PROC:	/* �I�� */
		Mon_Info.BpCnt= 0;			//Step Break Clear 2007.04.24
		PlcDataSram.Load_Count= PlcDataSram.CodeTableCnt/2;
		memcpy(PlcDataSram.Inst_Operand_Program,SWpWriteBuff,PlcDataSram.CodeTableCnt);
		PlcDataSram.CodeTableSum= MakeCodeTblSum(PlcDataSram.Inst_Operand_Program,*TableCnt);
		fp= mopen(PLC_PROG_NAME,_O_WRONLY);
		break;
	case PLC_LCOMENT:	fp= mopen(PLC_LCOM_NAME,_O_WRONLY);	break;
	case PLC_RCOMENT:	fp= mopen(PLC_RCOM_NAME,_O_WRONLY);	break;
	case PLC_VAL:		fp= mopen(PLC_VAL_NAME,_O_WRONLY);	break;
	case PLC_LABEL:		fp= mopen(PLC_LABEL_NAME,_O_WRONLY);break;
	case PLC_PROJ:		fp= mopen(PLC_PROJ_NAME,_O_WRONLY);	break;
	}
	if(fp != GP_ERROR){
		FileRetVal= mwrite(fp,&SWpWriteBuff[0],*TableCnt);
		if(FileRetVal < 0){	ret= NG;	}
		mfileDelete(FileRetVal,fp);	//write()�G��?�̎��t?�C�����������邽��
		mclose(fp);
//		Delay(50);
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PlcMainTaskStopWait()										*/
/*	??	: PLC���C��?�X�N�̏I����҂B								*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	PlcMainTaskStopWait(void)
{
	PlcSignalInf= OFF;			//0:Stop,1:Start
	while(1){
		if(PlcMainRunFlag == OFF){	break;	}
		Delay(20);
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: WP_Comm()													*/
/*	??	: "WP"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	WP_Comm(char *buff,char *SndBuff)
{
	int		i;
	int		ret;
	char	*sbuff;

	ret= NG;
	if(WpFlag == 0){		/* �ŏ��̃��R?�h */
		//�v���O��?�������ݒ�
//		*GlpSysState |= GLP_SYS_STATE_ONLINE_P;
		ProgDownFlag= buff[2];
		if((buff[2] >= PLC_PROC) && (buff[2] <= PLC_PROJ)){
			if((int)SWpWriteBuff != -1){		FreeMail(SWpWriteBuff);	}
			WpWriteBuff= (char *)TakeMemory(COM1BLK);
			SWpWriteBuff= WpWriteBuff;
			switch(buff[2]){
			case PLC_PROC:
				PlcMainTaskStopWait();	//Plc Main Stop
				TableCnt= &PlcDataSram.CodeTableCnt;
				break;
			case PLC_PARAM:
				TableCnt= &PlcDataSram.ParamTableCnt;
				break;
			case PLC_LCOMENT:
				TableCnt= &PlcDataSram.LComentTableCnt;
				break;
			case PLC_RCOMENT:
				TableCnt= &PlcDataSram.RComentTableCnt;
				break;
			case PLC_VAL:
				TableCnt= &PlcDataSram.ValTableCnt;
				break;
			case PLC_LABEL:
				TableCnt= &PlcDataSram.LabelTableCnt;
				break;
			case PLC_PROJ:
				TableCnt= &PlcDataSram.ProjTableCnt;
				break;
			}
			sbuff= &buff[3];
			switch(ProgDownFlag){
			case PLC_PROC:
			case PLC_PARAM:
			case PLC_PROJ:
				for(i= 0; i < (SmtStoRecCnt- 6)/2;i++){	/*�R?���h?���?ETX+BCC(2)*/
					*WpWriteBuff= Hex2nBin(sbuff++,2);
					sbuff++;
					WpWriteBuff++;
				}
				break;
			default:
				for(i= 0; i < SmtStoRecCnt- 6;i++){	/*ETX+BCC(2)*/
					*WpWriteBuff= *sbuff;
					sbuff++;
					WpWriteBuff++;
				}
				break;
			}
			*TableCnt= i;
			if(*sbuff == ETX){		//��M�I��
				ret= ReciveEndProc();
				if(SWpWriteBuff != (char*)-1){		//20090112
					FreeMail(SWpWriteBuff);
					SWpWriteBuff= (char*)-1;
				}
				//�v���O��?�������ݒ��N���A
//				*GlpSysState &= ~GLP_SYS_STATE_ONLINE_P;
			}else{			/*�������� */
				WpFlag= 1;
				DenubTimeoutCnt= 30;			/* ACK�҂�?�C?�A�E�g */
				MatrixRetryCnt= 3;
				ret= OK;
			}
		}
	}else{
		sbuff= &buff[0];
		switch(ProgDownFlag){
		case PLC_PROC:
		case PLC_PARAM:
		case PLC_PROJ:
			for(i= 0; i < (SmtStoRecCnt- 3)/2;i++){	/*ETX+BCC(2)*/
				*WpWriteBuff= Hex2nBin(sbuff++,2);
				sbuff++;
				WpWriteBuff++;
			}
			break;
		default:
			for(i= 0; i < SmtStoRecCnt- 3;i++){	/*ETX+BCC(2)*/
				*WpWriteBuff= *sbuff;
				sbuff++;
				WpWriteBuff++;
			}
			break;
		}
		*TableCnt += i;
		if(*sbuff == ETX){	/* �I�� */
			WpFlag= 0;
			ret= ReciveEndProc();
			if(SWpWriteBuff != (char*)-1){		//20090112
				FreeMail(SWpWriteBuff);
				SWpWriteBuff= (char*)-1;
			}
			//�v���O��?�������ݒ��N���A
//			*GlpSysState &= ~GLP_SYS_STATE_ONLINE_P;
		}else{
			DenubTimeoutCnt= 30;			/* ACK�҂�?�C?�A�E�g */
			MatrixRetryCnt= 3;
			ret= OK;
		}
	}
	if(ProgDownFlag == PLC_PROC){
		if(WpFlag == 0){	PlcSignalInf= ON;	}
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: Bin2HexByte()												*/
/*	??	: �o�C�i��?���g�d�w?�r�b�h�h�ɕω�����i�Q���j			*/
/*	����	: int data->�o�C�i��?�f??								*/
/*			  char *SndBuff->�i?�o�b�t??								*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	Bin2HexByte(int data,char *buff)
{

	buff[0]= Bin2Hex1((data & 0x00f0) >> 4);
	buff[1]= Bin2Hex1(data & 0x000f);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SerchChar()												*/
/*	??	: ��������̎w�蕶������������B							*/
/*	����	: unsigned char *buff->������								*/
/*			  int data->�����f??										*/
/*			  int MaxCnt->��������ő啶����							*/
/*	�߂�l	: �C���f�b�N�X												*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	SerchChar(unsigned char *buff,int data,int MaxCnt)
{
	int		i;
	for(i = 0;i < MaxCnt; i++){
		if(buff[i] == data){	i++;	break;	}
	}
	return(i);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: Serch1LineComment()										*/
/*	??	: ��������̎w�蕶�����Q�񌟍�����B						*/
/*	����	: unsigned char *buff->������								*/
/*			  int data->�����f??										*/
/*			  int MaxCnt->��������ő啶����							*/
/*			  int *EndIdx->�����ʒu�i?�̈�								*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	Serch1LineComment(unsigned char *buff,int data,int MaxCnt,int *EndIdx)
{
	int		ret= NG;
	int		i,flag;

	for(i = 0,flag= 0;i < MaxCnt; i++){
		if(buff[i] == data){
			if(flag != 0){
				i++;
				*EndIdx= i;
				ret= OK;
				break;
			}else{	flag= 1;	}
		}
	}
	if(flag == 0){	*EndIdx= i;	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: Serch1RungComment()										*/
/*	??	: ��������̎w�蕶������������B							*/
/*	����	: unsigned char *buff->������								*/
/*			  int data->�����f??										*/
/*			  int MaxCnt->��������ő啶����							*/
/*			  int *EndIdx->�����ʒu�i?�̈�								*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	Serch1RungComment(unsigned char *buff,int data,int MaxCnt,int *EndIdx)
{
	int		ret= NG;
	int		i;

	for(i = 0;i < MaxCnt; i++){
		if(buff[i] == data){
			i++;
			*EndIdx= i;
			ret= OK;
			break;
		}
	}
	if(ret == NG){	*EndIdx= i;	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: MoveMemory()												*/
/*	??	: �X??�g�ʒu����G���h�ʒu�܂ł̃f??���w��ʒu�ֈړ�����*/
/*	����	: unsigned char *StartAddr->�X??�g�ʒu					*/
/*			  unsigned char *EndAddr->�G���h�ʒu						*/
/*			  unsigned char *ObjAddr->�ړ��ʒu							*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	MoveMemory(unsigned char *StartAddr,unsigned char *EndAddr,unsigned char *ObjAddr)
{
	int		cnt;
	int		i;

	cnt= (int)EndAddr- (int)StartAddr;
	if(StartAddr < ObjAddr){
		ObjAddr= (unsigned char *)(ObjAddr+ cnt- 1);
		EndAddr--;
		for(i= 0; i < cnt; i++){
			*ObjAddr-- = *EndAddr--;
		}
	}else{	memcpy(ObjAddr,StartAddr,cnt);	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: EditLineComment()											*/
/*	??	: ���C���R�����g�̕ҏW����									*/
/*	����	: char *RecBuff->��M�o�b�t??(�f??�̈�(�ҏW���))		*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	EditLineComment(char *RecBuff)
{
	int		i;
	int		idx,NextIdx,oNextIdx;
	int		StepNo;
	int		StartIdx;
	int		tStepNo;
	int		work;
	int		EndIdx;
	int		wStepNo;
	int		ret= OK;
	int		EditFlag;
	int		fp;
	unsigned char	*workBuff;
	int		wFlag;

	workBuff= (unsigned char *)TakeMemory(COM1BLK);
	memset(workBuff,0xff,COM1BLK);
	fp= mopen(PLC_LCOM_NAME, _O_RDONLY);
	if(fp != GP_ERROR){
		mread(fp,workBuff,COM1BLK);
		mclose(fp);
	}
	wFlag= OFF;
	switch(RecBuff[0]){
	case 'I':			/* Insert */
		for(idx= 1; ; ){
			StartIdx= idx;
			/* �X�e�b�v�ԍ������o�� */
			StepNo= Hex2nBin((char *)&RecBuff[idx],4);
			idx += 4;
			EditCnt -= 4;
			/* ���C���R�����g�̈ʒu�����o�� */
			ret= Serch1RungComment((unsigned char*)&RecBuff[idx],0x0d,EditCnt,&NextIdx);
			if(ret == NG){	break;	}	//CR��������Ȃ�
			EndIdx= idx+ NextIdx;		//���̃C���f�b�N�X
			/* Data Set */
			EditFlag= 0;
			for(i= 0; i < PlcDataSram.LComentTableCnt; ){
				/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
				wStepNo= Hex2nBin((char *)&workBuff[i],4);
				tStepNo= i;
				if(wStepNo >= StepNo){			//�X�e�b�v�ԍ����������傫��
					if(wStepNo == StepNo){		/* ����X�e�b�v�ԍ� */
						ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LComentTableCnt,&oNextIdx);
						oNextIdx= tStepNo+ oNextIdx;
						/* ?�������󂯂� */
						MoveMemory(&workBuff[oNextIdx],&workBuff[PlcDataSram.LComentTableCnt],&workBuff[tStepNo+(EndIdx- StartIdx)]);
						memcpy(&workBuff[tStepNo],&RecBuff[StartIdx],EndIdx- StartIdx);
						PlcDataSram.LComentTableCnt= PlcDataSram.LComentTableCnt- (oNextIdx- tStepNo)+ (EndIdx- StartIdx);
					}else{
						/* �O��?������ */
						/* ?�������󂯂� */
						MoveMemory(&workBuff[tStepNo],&workBuff[PlcDataSram.LComentTableCnt],&workBuff[tStepNo+(EndIdx- StartIdx)]);
						memcpy(&workBuff[tStepNo],&RecBuff[StartIdx],EndIdx- StartIdx);
						PlcDataSram.LComentTableCnt= PlcDataSram.LComentTableCnt+ (EndIdx- StartIdx);
					}
					EditFlag= 1;
					wFlag= ON;
					break;
				}else{			//�X�e�b�v�ԍ���������������T��
					ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LComentTableCnt,&oNextIdx);
					i= tStepNo+ oNextIdx;
				}
			}
			if(EditFlag == 0){
				/* �ő�̃X�e�b�v�ԍ�(�ǉ�) */
				memcpy(&workBuff[PlcDataSram.LComentTableCnt],&RecBuff[StartIdx],EndIdx- StartIdx);
				PlcDataSram.LComentTableCnt= PlcDataSram.LComentTableCnt+ (EndIdx- StartIdx);
				wFlag= ON;
			}
			idx += NextIdx;
			EditCnt -= NextIdx;
			if(EditCnt <= 1){	break;	}
		}
		break;
	case 'D':			/* Delete */
		idx= 1;
		/* �X�e�b�v�ԍ������o�� */
		StepNo= Hex2nBin((char *)&RecBuff[idx],4);
		idx += 4;
		EndIdx= Hex2nBin((char *)&RecBuff[idx],4);
		/* �X??�g�X�e�b�v�ԍ���T�� */
		tStepNo= 0;		//Line Comment ���Ȃ����̂���
		oNextIdx= 0;
		for(i= 0; i < PlcDataSram.LComentTableCnt; ){
			/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
			wStepNo= Hex2nBin((char *)&workBuff[i],4);
			tStepNo= i;
			ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LComentTableCnt,&oNextIdx);
			if((wStepNo >= StepNo) && (wStepNo <= EndIdx)){
				i= tStepNo+ oNextIdx;
				oNextIdx= i;
				for(; i < PlcDataSram.LComentTableCnt; ){
					/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
					wStepNo= Hex2nBin((char *)&workBuff[i],4);
					work= i;
					if((wStepNo >= StepNo) && (wStepNo <= EndIdx)){
						ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LComentTableCnt,&oNextIdx);
						i= oNextIdx= work+ oNextIdx;
					}else{	break;	}
				}
				break;
			}else{	i= tStepNo+ oNextIdx;	}
		}
		/* �폜 */
		memcpy(&workBuff[tStepNo],&workBuff[oNextIdx],(PlcDataSram.LComentTableCnt- tStepNo)- (oNextIdx- tStepNo));
		PlcDataSram.LComentTableCnt= PlcDataSram.LComentTableCnt- (oNextIdx- tStepNo);
		wFlag= ON;
		break;
	case 'E':		//�ύX
		for(idx= 1; ; ){
			StartIdx= idx;
			/* �X�e�b�v�ԍ������o�� */
			StepNo= Hex2nBin((char *)&RecBuff[idx],4);
			idx += 4;
			EditCnt -= 4;
			/* ���C���R�����g�̈ʒu�����o�� */
			ret= Serch1RungComment((unsigned char*)&RecBuff[idx],0x0d,EditCnt,&NextIdx);
			if(ret == NG){	break;	}
			EndIdx= idx+ NextIdx;
			/* Data Set */
			EditFlag= 0;
			for(i= 0; i < PlcDataSram.LComentTableCnt; ){
				/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
				wStepNo= Hex2nBin((char *)&workBuff[i],4);
				tStepNo= i;
				if(wStepNo == StepNo){		/* ����X�e�b�v�ԍ� */
					ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LComentTableCnt,&oNextIdx);
					oNextIdx= tStepNo+ oNextIdx;
					/* ?�������󂯂� */
					MoveMemory(&workBuff[oNextIdx],&workBuff[PlcDataSram.LComentTableCnt],&workBuff[tStepNo+(EndIdx- StartIdx)]);
					memcpy(&workBuff[tStepNo],&RecBuff[StartIdx],EndIdx- StartIdx);
					PlcDataSram.LComentTableCnt= PlcDataSram.LComentTableCnt- (oNextIdx- tStepNo)+ (EndIdx- StartIdx);
					wFlag= ON;
					break;
				}else{
					ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LComentTableCnt,&oNextIdx);
					i= tStepNo+ oNextIdx;
				}
			}
			idx += NextIdx;
			EditCnt -= NextIdx;
			if(EditCnt <= 1){	break;	}
		}
		break;
	default:
		ret= NG;
		break;
	}
	if(wFlag == ON){
		fp= mopen(PLC_LCOM_NAME,_O_WRONLY);
		if(fp == GP_ERROR){	ret= NG;}
		else{
			FileRetVal= mwrite(fp,&workBuff[0],PlcDataSram.LComentTableCnt);
			if(FileRetVal < 0){	ret= NG;}
			else{
				mfileDelete(FileRetVal,fp);
				mclose(fp);
//				Delay(50);
			}
		}
	}
	FreeMail((char *)workBuff);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: ResetStepNo()												*/
/*	??	: ���C���R�����g�̃X�e�b�v�ԍ���ύX����B					*/
/*	����	: unsigned char *workBuff->�Y��LineComment�A�h���X			*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	ResetStepNo(unsigned char *workBuff)
{
	int		i;
	int		flag;
	int		SeqNo;
	int		StepNo;
	int		tStepNo;
	int		wStepNo;
	int		oNextIdx;
	char	work[2];

	/* �X�e�b�v�C���f�b�N�X��t������ */
	flag= 0;
	StepNo= 0;
	SeqNo= 1;
	for(i= 0; i < PlcDataSram.RComentTableCnt; ){
		/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
		wStepNo= Hex2nBin((char *)&workBuff[i],5);
		tStepNo= i;
		if(flag != 0){
			if(wStepNo/16 == StepNo/16){	Bin2Hex(SeqNo++,1,work);}		/* �X�e�b�v�ԍ������� */
			else{		SeqNo= 0;			Bin2Hex(SeqNo++,1,work);}
		}else{		/* ��ԍŏ��̃R�����g */
			SeqNo= 0;
			Bin2Hex(SeqNo++,1,work);
		}
		workBuff[i+4]= work[0];
		Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.RComentTableCnt,&oNextIdx);
		i= tStepNo+ oNextIdx;
		flag= 1;
		StepNo= wStepNo;
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: EditRungComment()											*/
/*	??	: RUNG�R�����g�̕ҏW����									*/
/*	����	: char *RecBuff->��M�o�b�t??(�f??�̈�(�ҏW���))		*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	EditRungComment(char *RecBuff)
{
	int		i;
	int		idx,NextIdx,oNextIdx;
	int		StepNo;
	int		StartIdx;
	int		tStepNo;
	int		EndIdx;
	int		wStepNo;
	int		ret= OK;
	int		work;
	int		EditFlag;
	int		fp;
	unsigned char	*workBuff;
	int		wFlag;

	workBuff= (unsigned char *)TakeMemory(COM1BLK);
	memset(workBuff,0xff,COM1BLK);
	fp= mopen(PLC_RCOM_NAME, _O_RDONLY);
	if(fp != GP_ERROR){
		mread(fp,workBuff,COM1BLK);
		mclose(fp);
	}
	wFlag= OFF;
	switch(RecBuff[0]){
	case 'I':			/* Insert */
		for(idx= 1; ; ){
			StartIdx= idx;
			/* �X�e�b�v�ԍ������o�� */
			StepNo= Hex2nBin((char *)&RecBuff[idx],5);
			idx += 5;
			EditCnt -= 5;
			/* ���C���R�����g�̈ʒu�����o�� */
			ret= Serch1RungComment((unsigned char*)&RecBuff[idx],0x0d,EditCnt,&NextIdx);
			if(ret == NG){	break;	}
			EndIdx= idx+ NextIdx;
			/* Data Set */
			EditFlag= 0;
			for(i= 0; i < PlcDataSram.RComentTableCnt; ){
				/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
				wStepNo= Hex2nBin((char *)&workBuff[i],5);
				tStepNo= i;
				ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.RComentTableCnt,&oNextIdx);
				if(wStepNo >= StepNo){
					/* �O��?������ */
					/* ?�������󂯂� */
					MoveMemory(&workBuff[tStepNo],&workBuff[PlcDataSram.RComentTableCnt],&workBuff[tStepNo+(EndIdx- StartIdx)]);
					memcpy(&workBuff[tStepNo],&RecBuff[StartIdx],EndIdx- StartIdx);
					PlcDataSram.RComentTableCnt= PlcDataSram.RComentTableCnt+ (EndIdx- StartIdx);
					EditFlag= 1;
					wFlag= ON;
					break;
				}else{	i= tStepNo+ oNextIdx;	}
			}
			if(EditFlag == 0){
				/* �ő�̃X�e�b�v�ԍ�(�ǉ�) */
				memcpy(&workBuff[PlcDataSram.RComentTableCnt],&RecBuff[StartIdx],EndIdx- StartIdx);
				PlcDataSram.RComentTableCnt= PlcDataSram.RComentTableCnt+ (EndIdx- StartIdx);
				wFlag= ON;
			}
			idx += NextIdx;
			EditCnt -= NextIdx;
			if(EditCnt <= 1){	break;	}
		}
		/* �X�e�b�v�C���f�b�N�X��t������ */
		ResetStepNo(workBuff);
		break;
	case 'D':
		idx= 1;
		/* �X�e�b�v�ԍ������o�� */
		StepNo= Hex2nBin((char *)&RecBuff[idx],5);
		idx += 5;
		EndIdx= Hex2nBin((char *)&RecBuff[idx],5);
		tStepNo= 0;		//Run Comment ���Ȃ����̂���
		oNextIdx= 0;
		/* �X??�g�X�e�b�v�ԍ���T�� */
		for(i= 0; i < PlcDataSram.RComentTableCnt; ){
			/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
			wStepNo= Hex2nBin((char *)&workBuff[i],5);
			tStepNo= i;
			if((wStepNo >= StepNo) && (wStepNo <= EndIdx)){
				ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.RComentTableCnt,&oNextIdx);
				i= tStepNo+ oNextIdx;
				oNextIdx= i;
				for(; i < PlcDataSram.RComentTableCnt; ){
					/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
					wStepNo= Hex2nBin((char *)&workBuff[i],5);
					work= i;
					if((wStepNo >= StepNo) && (wStepNo <= EndIdx)){
						ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.RComentTableCnt,&oNextIdx);
						i= oNextIdx= work+ oNextIdx;
					}else{	break;	}
				}
				break;
			}else{
				ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.RComentTableCnt,&oNextIdx);
				i= tStepNo+ oNextIdx;
			}
		}
		/* �폜 */
		memcpy(&workBuff[tStepNo],&workBuff[oNextIdx],(PlcDataSram.RComentTableCnt- tStepNo)- (oNextIdx- tStepNo));
		PlcDataSram.RComentTableCnt= PlcDataSram.RComentTableCnt- (oNextIdx- tStepNo);
		/* �X�e�b�v�C���f�b�N�X��t������ */
		ResetStepNo(workBuff);
		wFlag= ON;
		break;
	case 'E':			/* Insert */
		for(idx= 1; ; ){
			StartIdx= idx;
			/* �X�e�b�v�ԍ������o�� */
			StepNo= Hex2nBin((char *)&RecBuff[idx],5);
			idx += 5;
			EditCnt -= 5;
			/* ���C���R�����g�̈ʒu�����o�� */
			ret= Serch1RungComment((unsigned char*)&RecBuff[idx],0x0d,EditCnt,&NextIdx);
			if(ret == NG){
				break;
			}
			EndIdx= idx+ NextIdx;
			/* Data Set */
			for(i= 0; i < PlcDataSram.RComentTableCnt; ){
				/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
				wStepNo= Hex2nBin((char *)&workBuff[i],5);
				tStepNo= i;
				ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.RComentTableCnt,&oNextIdx);
				if(wStepNo == StepNo){
					/* �u�������� */
					ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.RComentTableCnt,&oNextIdx);
					oNextIdx= tStepNo+ oNextIdx;
					/* ?�������󂯂� */
					MoveMemory(&workBuff[oNextIdx],&workBuff[PlcDataSram.RComentTableCnt],&workBuff[tStepNo+(EndIdx- StartIdx)]);
					memcpy(&workBuff[tStepNo],&RecBuff[StartIdx],EndIdx- StartIdx);
					PlcDataSram.RComentTableCnt= PlcDataSram.RComentTableCnt+ (EndIdx- (oNextIdx- tStepNo+ 1));
					wFlag= ON;
					break;
				}else{	i= tStepNo+ oNextIdx;	}
			}
			idx += NextIdx;
			EditCnt -= NextIdx;
			if(EditCnt <= 1){	break;	}
		}
		/* �X�e�b�v�C���f�b�N�X��t������ */
		ResetStepNo(workBuff);
		break;
	default:
		ret= NG;
		break;
	}
	if(wFlag == ON){
		fp= mopen(PLC_RCOM_NAME,_O_WRONLY);
		if(fp == GP_ERROR){	ret= NG;	}
		else{
			FileRetVal= mwrite(fp,&workBuff[0],PlcDataSram.RComentTableCnt);
			if(FileRetVal < 0){	ret= NG;	}
			else{
				mfileDelete(FileRetVal,fp);
				mclose(fp);
//				Delay(50);
			}
		}
	}
	FreeMail((char *)workBuff);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: EditVariable()											*/
/*	??	: �ϐ��̕ҏW����											*/
/*	����	: char *RecBuff->��M�o�b�t??(�f??�̈�(�ҏW���))		*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	EditVariable(char *RecBuff)
{
	int		i;
	int		idx,NextIdx,oNextIdx;
	unsigned int	StepNo;
	char	Kind;
	char	wKind;
	int		StartIdx;
	int		tStepNo;
	int		EndIdx;
	unsigned int	wStepNo;
	int		ret= OK;
	int		EditFlag;
	int		fp;
	unsigned char	*workBuff;
	int		wFlag;
	int DelCnt;

	workBuff= (unsigned char *)TakeMemory(COM1BLK);
	memset(workBuff,0xff,COM1BLK);
	fp= mopen(PLC_VAL_NAME, _O_RDONLY);
	if(fp != GP_ERROR){
		mread(fp,workBuff,COM1BLK);
		mclose(fp);
	}
	wFlag= OFF;
	switch(RecBuff[0]){
	case 'A':			/* Add */
		for(idx= 1; ; ){
			StartIdx= idx;
			/* �X�e�b�v�ԍ������o�� */
			StepNo= Hex2nBin((char *)&RecBuff[idx],8);
			Kind= RecBuff[idx+8];
			idx += 9;
			EditCnt -= 9;
			/* ���C���R�����g�̈ʒu�����o�� */
			ret= Serch1LineComment((unsigned char*)&RecBuff[idx],0x0d,EditCnt,&NextIdx);
			if(ret == NG){	break;	}
			EndIdx= idx+ NextIdx;
			/* Data Set */
			EditFlag= 0;
			for(i= 0; i < PlcDataSram.ValTableCnt; ){
				/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
				wStepNo= Hex2nBin((char *)&workBuff[i],8);
				wKind= workBuff[i+8];
				tStepNo= i;
				ret= Serch1LineComment(&workBuff[i],0x0d,PlcDataSram.ValTableCnt,&oNextIdx);
				if((wStepNo == StepNo) && (Kind == wKind)){
					/* �㏑������ */
					i= tStepNo+ oNextIdx;
					/* ?�������󂯂� */
					MoveMemory(&workBuff[i],&workBuff[PlcDataSram.ValTableCnt],&workBuff[tStepNo+ (EndIdx- StartIdx)]);
					memcpy(&workBuff[tStepNo],&RecBuff[StartIdx],EndIdx- StartIdx);
					PlcDataSram.ValTableCnt= PlcDataSram.ValTableCnt- oNextIdx+ (EndIdx- StartIdx);
					EditFlag= 1;
					wFlag= ON;
					break;
				}else{	i= tStepNo+ oNextIdx;	}
			}
			if(EditFlag == 0){
				/* �ő�̃X�e�b�v�ԍ�(�ǉ�) */
				memcpy(&workBuff[PlcDataSram.ValTableCnt],&RecBuff[StartIdx],EndIdx- StartIdx);
				PlcDataSram.ValTableCnt= PlcDataSram.ValTableCnt+ (EndIdx- StartIdx);
				wFlag= ON;
			}
			idx += NextIdx;
			EditCnt -= NextIdx;
			if(EditCnt <= 1){	break;	}
		}
		break;
	case 'D':
		idx= 1;
		while(EditCnt > idx){
			if((idx+9) > EditCnt){	break;	}
			/* �X�e�b�v�ԍ������o�� */
			StepNo= Hex2nBin((char *)&RecBuff[idx],8);
			Kind= RecBuff[idx+8];
			idx += 9;
			/* �f�o�C�X��T�� */
			for(i= 0; i < PlcDataSram.ValTableCnt; ){
				/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
				wStepNo= Hex2nBin((char *)&workBuff[i],8);
				wKind= workBuff[i+8];
				tStepNo= i;
				if((wStepNo == StepNo) && (Kind == wKind)){
					ret= Serch1LineComment(&workBuff[i],0x0d,PlcDataSram.ValTableCnt,&oNextIdx);
					DelCnt= oNextIdx;
					oNextIdx= tStepNo+ oNextIdx;
					/* �폜 */
					memcpy(&workBuff[tStepNo],&workBuff[oNextIdx],PlcDataSram.ValTableCnt- (oNextIdx- tStepNo));
					PlcDataSram.ValTableCnt= PlcDataSram.ValTableCnt- DelCnt;
					wFlag= ON;
					break;
				}else{
					ret= Serch1LineComment(&workBuff[i],0x0d,PlcDataSram.ValTableCnt,&oNextIdx);
					i= tStepNo+ oNextIdx;
				}
			}
		}
		break;
	case 'E':			/* Add */
		for(idx= 1; ; ){
			StartIdx= idx;
			/* �X�e�b�v�ԍ������o�� */
			StepNo= Hex2nBin((char *)&RecBuff[idx],8);
			Kind= RecBuff[idx+8];
			idx += 9;
			EditCnt -= 9;
			/* ���C���R�����g�̈ʒu�����o�� */
			ret= Serch1LineComment((unsigned char*)&RecBuff[idx],0x0d,EditCnt,&NextIdx);
			if(ret == NG){	break;	}
			EndIdx= idx+ NextIdx;
			/* Data Set */
			for(i= 0; i < PlcDataSram.ValTableCnt; ){
				/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
				wStepNo= Hex2nBin((char *)&workBuff[i],8);
				wKind= workBuff[i+8];
				tStepNo= i;
				ret= Serch1LineComment(&workBuff[i],0x0d,PlcDataSram.ValTableCnt,&oNextIdx);
				if((wStepNo == StepNo) && (Kind == wKind)){
					/* �㏑������ */
					i= tStepNo+ oNextIdx;
					/* ?�������󂯂� */
					MoveMemory(&workBuff[i],&workBuff[PlcDataSram.ValTableCnt],&workBuff[tStepNo+ (EndIdx- StartIdx)]);
					memcpy(&workBuff[tStepNo],&RecBuff[StartIdx],EndIdx- StartIdx);
					PlcDataSram.ValTableCnt= PlcDataSram.ValTableCnt- oNextIdx+ (EndIdx- StartIdx);
					wFlag= ON;
					break;
				}else{	i= tStepNo+ oNextIdx;	}
			}
			idx += NextIdx;
			EditCnt -= NextIdx;
			if(EditCnt <= 1){	break;	}
		}
		break;
	default:
		ret= NG;
		break;
	}
	if(wFlag == ON){
		fp= mopen(PLC_VAL_NAME,_O_WRONLY);
		if(fp == GP_ERROR){	ret= NG;	}
		else{
			FileRetVal= mwrite(fp,&workBuff[0],PlcDataSram.ValTableCnt);
			if(FileRetVal < 0){	ret= NG;	}
			else{
				mfileDelete(FileRetVal,fp);
				mclose(fp);
//				Delay(50);
			}
		}
	}
	FreeMail((char *)workBuff);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: EditLabel()												*/
/*	??	: Label�̕ҏW����											*/
/*	����	: char *RecBuff->��M�o�b�t??(�f??�̈�(�ҏW���))		*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	EditLabel(char *RecBuff)
{
	int		i;
	int		idx,NextIdx,oNextIdx;
	int		StepNo;
	int		StartIdx;
	int		tStepNo;
	int		work;
	int		EndIdx;
	int		wStepNo;
	int		ret= OK;
	int		EditFlag;
	int		fp;
	unsigned char	*workBuff;
	int		wFlag;

	workBuff= (unsigned char *)TakeMemory(COM1BLK);
	memset(workBuff,0xff,COM1BLK);
	fp= mopen(PLC_LABEL_NAME, _O_RDONLY);
	if(fp != GP_ERROR){
		mread(fp,workBuff,COM1BLK);
		mclose(fp);
	}
	wFlag= OFF;
	switch(RecBuff[0]){
	case 'I':			/* Insert */
		for(idx= 1; ; ){
			StartIdx= idx;
			/* �X�e�b�v�ԍ������o�� */
			StepNo= Hex2nBin((char *)&RecBuff[idx],2);
			idx += 2;
			EditCnt -= 2;
			/* ���C���R�����g�̈ʒu�����o�� */
			ret= Serch1RungComment((unsigned char*)&RecBuff[idx],0x0d,EditCnt,&NextIdx);
			if(ret == NG){	break;	}
			EndIdx= idx+ NextIdx;
			/* Data Set */
			EditFlag= 0;
			for(i= 0; i < PlcDataSram.LabelTableCnt; ){
				/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
				wStepNo= Hex2nBin((char *)&workBuff[i],2);
				tStepNo= i;
				if(wStepNo >= StepNo){
					if(wStepNo == StepNo){		/* ����X�e�b�v�ԍ� */
						ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LabelTableCnt,&oNextIdx);
						oNextIdx= tStepNo+ oNextIdx;
						/* ?�������󂯂� */
						MoveMemory(&workBuff[oNextIdx],&workBuff[PlcDataSram.LabelTableCnt],&workBuff[tStepNo+(EndIdx- StartIdx)]);
						memcpy(&workBuff[tStepNo],&RecBuff[StartIdx],EndIdx- StartIdx);
						PlcDataSram.LabelTableCnt= PlcDataSram.LabelTableCnt- (oNextIdx- tStepNo)+ (EndIdx- StartIdx);
					}else{
						/* �O��?������ */
						/* ?�������󂯂� */
						MoveMemory(&workBuff[tStepNo],&workBuff[PlcDataSram.LabelTableCnt],&workBuff[tStepNo+(EndIdx- StartIdx)]);
						memcpy(&workBuff[tStepNo],&RecBuff[StartIdx],EndIdx- StartIdx);
						PlcDataSram.LabelTableCnt= PlcDataSram.LabelTableCnt+ (EndIdx- StartIdx);
					}
					EditFlag= 1;
					wFlag= ON;
					break;
				}else{
					ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LabelTableCnt,&oNextIdx);
					i= tStepNo+ oNextIdx;
				}
			}
			if(EditFlag == 0){
				/* �ő�̃X�e�b�v�ԍ�(�ǉ�) */
				memcpy(&workBuff[PlcDataSram.LabelTableCnt],&RecBuff[StartIdx],EndIdx- StartIdx);
				PlcDataSram.LabelTableCnt= PlcDataSram.LabelTableCnt+ (EndIdx- StartIdx);
				wFlag= ON;
			}
			idx += NextIdx;
			EditCnt -= NextIdx;
			if(EditCnt <= 1){	break;	}
		}
		break;
	case 'D':			/* Delete */
		idx= 1;
		/* �X�e�b�v�ԍ������o�� */
		StepNo= Hex2nBin((char *)&RecBuff[idx],2);
		idx += 2;
		EndIdx= Hex2nBin((char *)&RecBuff[idx],2);
		/* �X??�g�X�e�b�v�ԍ���T�� */
		tStepNo= 0;
		oNextIdx= 0;
		for(i= 0; i < PlcDataSram.LabelTableCnt; ){
			/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
			wStepNo= Hex2nBin((char *)&workBuff[i],2);
			tStepNo= i;
			if((wStepNo >= StepNo) && (wStepNo <= EndIdx)){
				ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LabelTableCnt,&oNextIdx);
				i= tStepNo+ oNextIdx;
				for(; i < PlcDataSram.LabelTableCnt; ){
					/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
					wStepNo= Hex2nBin((char *)&workBuff[i],2);
					work= i;
					if((wStepNo >= StepNo) && (wStepNo <= EndIdx)){
						ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LabelTableCnt,&oNextIdx);
						i= oNextIdx= work+ oNextIdx;
					}else{	break;	}
				}
				break;
			}else{
				ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LabelTableCnt,&oNextIdx);
				i= tStepNo+ oNextIdx;
			}
		}
		/* �폜 */
		memcpy(&workBuff[tStepNo],&workBuff[oNextIdx],(PlcDataSram.LabelTableCnt- tStepNo)- (oNextIdx- tStepNo));
		PlcDataSram.LabelTableCnt= PlcDataSram.LabelTableCnt- (oNextIdx- tStepNo);
		wFlag= ON;
		break;
	case 'E':			/* Insert */
		for(idx= 1; ; ){
			StartIdx= idx;
			/* �X�e�b�v�ԍ������o�� */
			StepNo= Hex2nBin((char *)&RecBuff[idx],2);
			idx += 2;
			EditCnt -= 2;
			/* ���C���R�����g�̈ʒu�����o�� */
			ret= Serch1RungComment((unsigned char*)&RecBuff[idx],0x0d,EditCnt,&NextIdx);
			if(ret == NG){	break;	}
			EndIdx= idx+ NextIdx;
			/* Data Set */
			for(i= 0; i < PlcDataSram.LabelTableCnt; ){
				/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
				wStepNo= Hex2nBin((char *)&workBuff[i],2);
				tStepNo= i;
				if(wStepNo == StepNo){		/* ����X�e�b�v�ԍ� */
					ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LabelTableCnt,&oNextIdx);
					oNextIdx= tStepNo+ oNextIdx;
					/* ?�������󂯂� */
					MoveMemory(&workBuff[oNextIdx],&workBuff[PlcDataSram.LabelTableCnt],&workBuff[tStepNo+(EndIdx- StartIdx)]);
					memcpy(&workBuff[tStepNo],&RecBuff[StartIdx],EndIdx- StartIdx);
					PlcDataSram.LabelTableCnt= PlcDataSram.LabelTableCnt- (oNextIdx- tStepNo)+ (EndIdx- StartIdx);
					wFlag= ON;
					break;
				}else{
					ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LabelTableCnt,&oNextIdx);
					i= tStepNo+ oNextIdx;
				}
			}
			idx += NextIdx;
			EditCnt -= NextIdx;
			if(EditCnt <= 1){	break;	}
		}
		break;
	default:
		ret= NG;
		break;
	}
	if(wFlag == ON){
		fp= mopen(PLC_LABEL_NAME,_O_WRONLY);
		if(fp == GP_ERROR){	ret= NG;	}
		else{
			FileRetVal= mwrite(fp,&workBuff[0],PlcDataSram.LabelTableCnt);
			if(FileRetVal < 0){	ret= NG;	}
			else{
				mfileDelete(FileRetVal,fp);
				mclose(fp);
//				Delay(50);
			}
		}
	}
	FreeMail((char *)workBuff);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: EP_Comm()													*/
/*	??	: "EP"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	EP_Comm(char *buff,char *SndBuff)
{
	int		i;
	char	*sbuff;

	if(WpFlag == 0){		/* �ŏ��̃��R?�h */
		EditCnt= 0;
		ProgDownFlag= buff[2];	/* ��ʕۑ� */
		if((buff[2] >= PLC_LCOMENT) && (buff[2] <= PLC_LABEL)){
			sbuff= &buff[3];
//			WpWriteBuff= (char *)&RecBuff[0];
			if((int)SWpWriteBuff != -1){		FreeMail(SWpWriteBuff);	}
			WpWriteBuff= (char *)TakeMemory(COM1BLK);
			SWpWriteBuff= WpWriteBuff;	//�o�b�t??��ۑ�����B
			for(i= 0; i < SmtStoRecCnt- 6;i++){	/*ETX+BCC(2)*/
				*WpWriteBuff= *sbuff;
				sbuff++;
				WpWriteBuff++;
			}
			EditCnt= i;
			if(*sbuff == ETB){			/*�������� */
				WpFlag= 3;
				DenubTimeoutCnt= 30;			/* ACK�҂�?�C?�A�E�g */
				MatrixRetryCnt= 3;
			}
			if(*sbuff == ETX){	/* �I�� */
				switch(ProgDownFlag){
				case PLC_LCOMENT:	EditLineComment(SWpWriteBuff);	break;		/* Line Comment */
				case PLC_RCOMENT:	EditRungComment(SWpWriteBuff);	break;		/* RUNG Comment */
				case PLC_VAL:		EditVariable(SWpWriteBuff);		break;		/* �ϐ� */
				case PLC_LABEL:		EditLabel(SWpWriteBuff);		break;		/* LABEL */
				}
				if(SWpWriteBuff != (char*)-1){		//20090112
					FreeMail(SWpWriteBuff);
					SWpWriteBuff= (char*)-1;
				}
			}
		}
	}else{
		sbuff= &buff[0];
		for(i= 0; i < SmtStoRecCnt- 3;i++){	/*ETX+BCC(2)*/
			*WpWriteBuff= *sbuff;
			sbuff++;
			WpWriteBuff++;
		}
		EditCnt+= i;
		if(*sbuff == ETX){			/* �����Ȃ� */
			WpFlag= 0;
			switch(ProgDownFlag){
			case PLC_LCOMENT:	EditLineComment(SWpWriteBuff);	break;		/* Line Comment */
			case PLC_RCOMENT:	EditRungComment(SWpWriteBuff);	break;		/* RUNG Comment */
			case PLC_VAL:		EditVariable(SWpWriteBuff);		break;		/* �ϐ� */
			case PLC_LABEL:		EditLabel(SWpWriteBuff);		break;		/* LABEL */
			}
			if(SWpWriteBuff != (char*)-1){		//20090112
				FreeMail(SWpWriteBuff);
				SWpWriteBuff= (char*)-1;
			}
		}else{
			DenubTimeoutCnt= 30;			/* ACK�҂�?�C?�A�E�g */
			MatrixRetryCnt= 3;
		}
	}
	return(0);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SerchProgIdx()											*/
/*	??	: �X�e�b�v�ԍ����j��?���j�b�N�̐擪����?�F�b�N���A		*/
/*			  �Ⴄ�ꍇ�͎�����j��?���j�b�N�̐擪��T���B				*/
/*	����	: int *StepNo->�X�e�b�v�i?�A�h���X(In,Out)					*/
/*	�߂�l	: �v���O��?�C���f�b�N�X									*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	SerchProgIdx(int *StepNo)
{
	int		i;

	for(i= *StepNo; i < PlcDataSram.MaxStepNo; i++){
		if(PlcDataSram.Inst_Point_Table[i] != -1){
			*StepNo= i;
			return(PlcDataSram.Inst_Point_Table[i]);
		}
	}
	return(PlcDataSram.Load_Count);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SerchLCommentIdx()										*/
/*	??	: Line Comment�̃C���f�b�N�X��T���B						*/
/*	����	: unsigned char *workBuff->Line Comment�i?�A�h���X			*/
/*			  int StepNo->�X�e�b�v�ԍ�									*/
/*			  int mode->0:�Y���R�����g�̐擪�ʒu,1:�Y���R�����g�̏I���ʒu */
/*	�߂�l	: ��?�h��?�����R�����g�ʒu								*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	SerchLCommentIdx(unsigned char *workBuff,int StepNo,int mode)
{
	int	idx,i;
	int	wStepNo,tStepNo,oNextIdx;
	int ret;

	/* �X??�g�X�e�b�v�ԍ���T�� */
	for(i= 0; i < PlcDataSram.LComentTableCnt; ){
		/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
		wStepNo= Hex2nBin((char *)&workBuff[i],4);
		tStepNo= i;
		ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LComentTableCnt,&oNextIdx);
		if(ret == NG){	break;}
		if(wStepNo >= StepNo){
			if(mode == 0){	idx= tStepNo;			}
			else{			idx= tStepNo+ oNextIdx;	}
			break;
		}else{	i= tStepNo+ oNextIdx;}
	}
	if(i >= PlcDataSram.LComentTableCnt){	idx= PlcDataSram.LComentTableCnt;}
	return(idx);

}
/*----------------------------------------------------------------------*/
/*	�֐���	: SerchRCommentIdx()										*/
/*	??	: Rung Comment�̃C���f�b�N�X��T���B						*/
/*	����	: unsigned char *workBuff->Rung Comment�i?�A�h���X			*/
/*			  int StepNo->�X�e�b�v�ԍ�									*/
/*			  int mode->0:�Y���R�����g�̐擪�ʒu,1:�Y���R�����g�̏I���ʒu */
/*	�߂�l	: ��?�h��?�����R�����g�ʒu								*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	SerchRCommentIdx(unsigned char *workBuff,int StepNo,int mode)
{
	int	idx,i;
	int	wStepNo,tStepNo,oNextIdx;
	int ret;

	/* �X??�g�X�e�b�v�ԍ���T�� */
	for(i= 0; i < PlcDataSram.RComentTableCnt; ){
		/* �ۑ��̈�̃X�e�b�v�ԍ������o�� */
		wStepNo= Hex2nBin((char *)&workBuff[i],4);
		tStepNo= i;
		ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.RComentTableCnt,&oNextIdx);
		if(ret == NG){	break;}
		if(wStepNo >= StepNo){
			if(mode == 0){	idx= tStepNo;			}
			else{			idx= tStepNo+ oNextIdx;	}
			break;
		}else{	i= tStepNo+ oNextIdx;}
	}
	if(i >= PlcDataSram.RComentTableCnt){	idx= PlcDataSram.RComentTableCnt;}
	return(idx);

}
/*----------------------------------------------------------------------*/
/*	�֐���	: RP_Comm()													*/
/*	??	: "RP"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	RP_Comm(char *buff,char *SndBuff)
{
	int		j;
	int		ret;
	int		ParamStartStepNo;
	int		ParamEndStepNo;
	unsigned char	*workBuff;
	int		fp;
//	int		pos,size;
	int		ParamStartPos;
	int		ParamEndPos;

	if((buff[2] >= PLC_PROC) && (buff[2] <= PLC_PROJ)){
//		workBuff= (unsigned char *)&Inst_Operand_AreaBack[0];
		if((int)SWpWriteBuff != -1){		FreeMail(SWpWriteBuff);	}
		workBuff= (unsigned char *)TakeMemory(COM1BLK);
		SWpWriteBuff= (char*)workBuff;
		memset(workBuff,0xff,COM1BLK);
		SndBuff[0]= STX;
		SndBuff[1]= 'R';
		SndBuff[2]= 'P';
		SndBuff[3]= buff[2];
		ProgDownFlag= buff[2];	/* ��ʕۑ� */
		CodeCnt= 0;
		switch(buff[2]){
		case PLC_PROC:
			ParamStartStepNo= Hex2nBin(&buff[3],4);
			ParamStartPos= SerchProgIdx(&ParamStartStepNo);
			ParamEndStepNo= Hex2nBin(&buff[7],4);
			//�Y���X�e�b�v�ԍ������݂�����A���̃X�e�b�v�܂ŒT��
			ParamEndPos= SerchProgIdx(&ParamEndStepNo);
//			ret= mfileserch2(PLC_PROG_NAME_DIR,&pos,&size);
//			if(ret == OK){
//				memcpy(workBuff,(unsigned char *)pos,size);
				memcpy(workBuff,(unsigned char *)PlcDataSram.Inst_Operand_Program,PlcDataSram.CodeTableCnt);
				WpWriteBuff= (char *)&workBuff[ParamStartPos*2];
				CodeCnt= (ParamEndPos- ParamStartPos)*2;
//			}
			break;
		case PLC_PARAM:
#ifdef	WIN32
			WpWriteBuff= (char *)&GpFont[PARAM_GLP_COMM];
#else
			WpWriteBuff= (char *)PARAM_GLP_COMM;
#endif
			memcpy(workBuff,WpWriteBuff,MAX_PARAM_AREA);
			if(PlcDataSram.ParamTableCnt > 0){
				SetParamdata((char*)workBuff);		//���ݎg�p���Ă���p����??�𑗂�B
			}
			WpWriteBuff= (char *)workBuff;
			CodeCnt= PlcDataSram.ParamTableCnt;
			break;
		case PLC_LCOMENT:
			fp= mopen(PLC_LCOM_NAME, _O_RDONLY);
			if(fp != GP_ERROR){
				mread(fp,workBuff,COM1BLK);
				mclose(fp);
				ParamStartStepNo= Hex2nBin(&buff[3],4);
				ParamStartPos= SerchLCommentIdx(workBuff,ParamStartStepNo,0);
				ParamEndStepNo= Hex2nBin(&buff[7],4);
				ParamEndPos= SerchLCommentIdx(workBuff,ParamEndStepNo,1);

				WpWriteBuff= (char *)&workBuff[ParamStartPos];
				CodeCnt= ParamEndPos- ParamStartPos;
			}
			break;
		case PLC_RCOMENT:
			fp= mopen(PLC_RCOM_NAME, _O_RDONLY);
			if(fp != GP_ERROR){
				mread(fp,workBuff,COM1BLK);
				mclose(fp);
				ParamStartStepNo= Hex2nBin(&buff[3],4);
				ParamStartPos= SerchRCommentIdx(workBuff,ParamStartStepNo,0);
				ParamEndStepNo= Hex2nBin(&buff[7],4);
				ParamEndPos= SerchRCommentIdx(workBuff,ParamEndStepNo,1);

				WpWriteBuff= (char *)&workBuff[ParamStartPos];
				CodeCnt= ParamEndPos- ParamStartPos;
			}
			break;
		case PLC_VAL:
			fp= mopen(PLC_VAL_NAME, _O_RDONLY);
			if(fp != GP_ERROR){
				mread(fp,workBuff,COM1BLK);
				mclose(fp);
				WpWriteBuff= (char *)&workBuff[0];
				CodeCnt= PlcDataSram.ValTableCnt;
			}
			break;
		case PLC_LABEL:
			fp= mopen(PLC_LABEL_NAME, _O_RDONLY);
			if(fp != GP_ERROR){
				mread(fp,workBuff,COM1BLK);
				mclose(fp);
				WpWriteBuff= (char *)&workBuff[0];
				CodeCnt= PlcDataSram.LabelTableCnt;
			}
			break;
		case PLC_PROJ:
			fp= mopen(PLC_PROJ_NAME, _O_RDONLY);
			if(fp != GP_ERROR){
				mread(fp,workBuff,COM1BLK);
				mclose(fp);
				WpWriteBuff= (char *)&workBuff[0];
				CodeCnt= PlcDataSram.ProjTableCnt;
			}
			break;
		}
		//���M�o�C�g��
		sprintf(&SndBuff[4],"%04X",CodeCnt);
		switch(ProgDownFlag){
		case PLC_PROC:
		case PLC_PROJ:
			if(fp != GP_ERROR){
				for(SndCodeCnt= 0,j= 0; SndCodeCnt < CodeCnt && j < 252; SndCodeCnt++,j++){
					Bin2HexByte(*WpWriteBuff++,&SndBuff[j*2+8]);
				}
			}else{
				SndCodeCnt= 0;
				j= 0;
			}
			if(SndCodeCnt < CodeCnt){	SndBuff[j*2+8] = ETB;}
			else{						SndBuff[j*2+8] = ETX;}
			ret= SetBcc(&SndBuff[1],j*2+8);
			break;
		case PLC_PARAM:
			if(CodeCnt > 0){
				for(SndCodeCnt= 0,j= 0; SndCodeCnt < CodeCnt && j < 252; SndCodeCnt++,j++){
					Bin2HexByte(*WpWriteBuff++,&SndBuff[j*2+8]);
				}
			}else{
				SndCodeCnt= 0;
				j= 0;
			}
			if(SndCodeCnt < CodeCnt){	SndBuff[j*2+8] = ETB;}
			else{						SndBuff[j*2+8] = ETX;}
			ret= SetBcc(&SndBuff[1],j*2+8);
			break;
		default:
			if(fp != GP_ERROR){
				for(SndCodeCnt= 0,j= 0; SndCodeCnt < CodeCnt && j < 504; SndCodeCnt++,j++){
					SndBuff[j+8]= *WpWriteBuff++;
				}
			}else{
				SndCodeCnt= 0;
				j= 0;
			}
			if(SndCodeCnt < CodeCnt){	SndBuff[j+8] = ETB;}
			else{						SndBuff[j+8] = ETX;}
			ret= SetBcc(&SndBuff[1],j+8);
			break;
		}
		Matrix_Mode= DATA_SEND_WAIT;
		DenubTimeoutCnt= 30;			/* ACK�҂�?�C?�A�E�g */
		MatrixRetryCnt= 3;
	}else{	ret= NG;				}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: RP_CommNext()												*/
/*	??	: "RP"�R?���h�ŕ������R?�h���M���鏈���B					*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	RP_CommNext(char *buff,char *SndBuff)
{
	int		j;
	int		ret;

	if(SndCodeCnt < CodeCnt){
		/* ���M�p�f??�쐬 */
		memcpy(&SndBuff[0],&RecStationno[2],2);
		memcpy(&SndBuff[2],&RecStationno[0],2);
		SndBuff[4]= STX;
		switch(ProgDownFlag){
		case PLC_PROC:
		case PLC_PROJ:
		case PLC_PARAM:
			for(j= 0; SndCodeCnt < CodeCnt && j < 256; SndCodeCnt++,j++){
				Bin2HexByte(*WpWriteBuff++,&SndBuff[j*2+5]);
			}
			if(SndCodeCnt < CodeCnt){	SndBuff[j*2+5] = ETB;}
			else{						SndBuff[j*2+5] = ETX;}
			ret= SetBcc(&SndBuff[5],j*2+1);
			break;
		default:
			for(j= 0; SndCodeCnt < CodeCnt && j < 510; SndCodeCnt++,j++){
				SndBuff[j+5]= *WpWriteBuff++;
			}
			if(SndCodeCnt < CodeCnt){	SndBuff[j+5] = ETB;}
			else{						SndBuff[j+5] = ETX;}
			ret= SetBcc(&SndBuff[5],j+1);
			break;
		}
//KSC20090112
//		Matrix_Mode= DATA_SEND_WAIT;
		DenubTimeoutCnt= 30;			/* ACK�҂�?�C?�A�E�g */
		MatrixRetryCnt= 3;
		return(ret);
	}else{
//KSC20090112
//		Matrix_Mode= IDLE;
		if(SWpWriteBuff != (char*)-1){		//20090112
			FreeMail(SWpWriteBuff);
			SWpWriteBuff= (char*)-1;
		}
		return(0);
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetProgPatch()											*/
/*	??	: �v���O��?�p�b?�����B									*/
/*	����	: char *RecBuff->��M�o�b�t??�i�f??�̐擪(�X�e�b�v�ԍ�)�j	*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	SetProgPatch(char *RecBuff)
{
	int		i;
	int		ParamStartStepNo;
	int		ParamEndStepNo;
	int		StartPos;
	int		EndPos;
	int		InsertStep;
	int		wStepNo,oNextIdx,tStepNo;
	char	work[8];
	unsigned char	*workBuff;
	int		fp;
	int ret;
//	int	size;
//	int	pos;

	Mon_Info.BpCnt= 0;			//Step Break Clear 2007.04.24
	/* �X�e�b�v�ԍ������o�� */
	ParamStartStepNo= RecBuff[0]*256+RecBuff[1];		//Start Step No
	StartPos= SerchProgIdx(&ParamStartStepNo);			//Start Step To Memory Index
	ParamEndStepNo= RecBuff[2]*256+RecBuff[3];		//Stop Step No
	EndPos= SerchProgIdx(&ParamEndStepNo);				//Stop Step To Memory Index
	//Program To Bacup Area
	//File����R�s?����
//	ret= mfileserch2(PLC_PROG_NAME_DIR,&pos,&size);
//	if(ret != OK){	return(NG);}		//Error
//	memcpy(&Inst_Operand_AreaBack[0],(char *)pos,size);
	if((PatchCodeTableCnt- 4) <= 0){		//Nothing Code Data 
		/* �폜 */
		//For Step No Reset(- Value)
		InsertStep= ParamStartStepNo- ParamEndStepNo;
		//Delete
		memcpy(&PlcDataSram.Inst_Operand_Program[StartPos],&PlcDataSram.Inst_Operand_Program[EndPos],PlcDataSram.CodeTableCnt- (EndPos- StartPos));
		//Code Count Reset
		PlcDataSram.CodeTableCnt= PlcDataSram.CodeTableCnt- (EndPos- StartPos)*2;
		PlcDataSram.Load_Count= PlcDataSram.CodeTableCnt/2;
	}else{
		/* ?���X�e�b�v�����v�Z���� */
		InsertStep= Culc_Instruction_Set((unsigned short *)&RecBuff[4],PatchCodeTableCnt- 4);
		if(InsertStep != NG){
			//Insert Step= Insert Step- Delete Step
			InsertStep= InsertStep- (ParamEndStepNo- ParamStartStepNo);
			/* ?�������󂯂� */
			MoveMemory((unsigned char *)&PlcDataSram.Inst_Operand_Program[EndPos],
				(unsigned char *)&PlcDataSram.Inst_Operand_Program[PlcDataSram.Load_Count],
				(unsigned char *)&PlcDataSram.Inst_Operand_Program[StartPos+ (PatchCodeTableCnt- 4)/2]);
			//��M�f??��?������
			memcpy(&PlcDataSram.Inst_Operand_Program[StartPos],&RecBuff[4],PatchCodeTableCnt- 4);
			//Code Count Reset
			PlcDataSram.CodeTableCnt= PlcDataSram.CodeTableCnt- ((EndPos- StartPos)*2)+PatchCodeTableCnt- 4;
			PlcDataSram.Load_Count= PlcDataSram.CodeTableCnt/2;
		}else{	return(NG);	}
	}
	PlcDataSram.CodeTableSum= MakeCodeTblSum(PlcDataSram.Inst_Operand_Program,PlcDataSram.CodeTableCnt);

	/* Line Comment */
	workBuff= (unsigned char *)TakeMemory(COM1BLK);
	memset(workBuff,0xff,COM1BLK);
	fp= mopen(PLC_LCOM_NAME, _O_RDONLY);
	if(fp != GP_ERROR){
		mread(fp,workBuff,COM1BLK);
		mclose(fp);
		for(i= 0; i < PlcDataSram.LComentTableCnt; ){
			wStepNo= Hex2nBin((char *)&workBuff[i],4);
			tStepNo= i;
			ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.LComentTableCnt,&oNextIdx);
			if(ret == NG){	break;	}	//CR��������Ȃ�
			if((wStepNo >= ParamStartStepNo) && (wStepNo < ParamEndStepNo)){
				/* �R�����g���폜���� */
				memcpy(&workBuff[tStepNo],&workBuff[oNextIdx+i],PlcDataSram.LComentTableCnt- oNextIdx);
				PlcDataSram.LComentTableCnt= PlcDataSram.LComentTableCnt- oNextIdx;
			}else if(wStepNo >= ParamEndStepNo){
				/* �R�����g�̃X�e�b�v�ԍ���ύX���� */
				wStepNo= wStepNo+ InsertStep;
				Bin2Hex(wStepNo,4,work);
				memcpy(&workBuff[i],work,4);
				i= tStepNo+ oNextIdx;
			}else{	i= tStepNo+ oNextIdx;}
			if(i >= PlcDataSram.LComentTableCnt){	break;}
		}
		ret= OK;
		fp= mopen(PLC_LCOM_NAME,_O_WRONLY);
		if(fp != GP_ERROR){
			FileRetVal= mwrite(fp,&workBuff[0],PlcDataSram.LComentTableCnt);
			if(FileRetVal < 0){	ret= NG;}
			else{
				mfileDelete(FileRetVal,fp);
				mclose(fp);
//				Delay(50);
			}
		}else{	ret= NG;}
		if(ret == NG){
			FreeMail((char *)workBuff);
			return(NG);
		}

	}
	/* Rung Comment */
	memset(workBuff,0xff,COM1BLK);
	fp= mopen(PLC_RCOM_NAME, _O_RDONLY);
	if(fp == GP_ERROR){		//Rung Comment�Ȃ�
		FreeMail((char *)workBuff);
		return(OK);
	}
	mread(fp,workBuff,COM1BLK);
	mclose(fp);
	for(i= 0; i < PlcDataSram.RComentTableCnt; ){
		wStepNo= Hex2nBin((char *)&workBuff[i],4);
		tStepNo= i;
		ret= Serch1RungComment(&workBuff[i],0x0d,PlcDataSram.RComentTableCnt,&oNextIdx);
		if(ret == NG){	break;}	//CR��������Ȃ�
		if((wStepNo >= ParamStartStepNo) && (wStepNo < ParamEndStepNo)){
			/* �R�����g���폜���� */
			memcpy(&workBuff[tStepNo],&workBuff[oNextIdx+i],PlcDataSram.RComentTableCnt- oNextIdx);
			PlcDataSram.RComentTableCnt= PlcDataSram.RComentTableCnt- oNextIdx;
		}else if(wStepNo >= ParamEndStepNo){
			/* �R�����g�̃X�e�b�v�ԍ���ύX���� */
			wStepNo= wStepNo+ InsertStep;
			Bin2Hex(wStepNo,4,work);
			memcpy(&workBuff[i],work,4);
			i= tStepNo+ oNextIdx;
		}else{	i= tStepNo+ oNextIdx;}
		if(i >= PlcDataSram.RComentTableCnt){	break;}
	}
	/* �X�e�b�v�C���f�b�N�X��t������ */
	ResetStepNo(workBuff);
	ret= OK;
	fp= mopen(PLC_RCOM_NAME,_O_WRONLY);
	if(fp != GP_ERROR){
		FileRetVal= mwrite(fp,&workBuff[0],PlcDataSram.RComentTableCnt);
		if(FileRetVal < 0){	ret= NG;}
		mfileDelete(FileRetVal,fp);
		mclose(fp);
//		Delay(50);
	}else{	ret= NG;}
	FreeMail((char *)workBuff);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PP_Comm()													*/
/*	??	: "PP"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	PP_Comm(char *buff,char *SndBuff)
{
	int		i;
	int		ret;
	char	*sbuff;
//	int		fp;

	ret= NG;
	PlcMainTaskStopWait();	//Plc Main Stop
	if(WpFlag == 0){		/* �ŏ��̃��R?�h */
		//�v���O��?�������ݒ�
//		*GlpSysState |= GLP_SYS_STATE_ONLINE_P;
		if((int)SWpWriteBuff != -1){		FreeMail(SWpWriteBuff);	}
		WpWriteBuff= (char *)TakeMemory(COM1BLK);
		SWpWriteBuff= WpWriteBuff;
		TableCnt= &PatchCodeTableCnt;
		sbuff= &buff[2];
		for(i= 0; i < (SmtStoRecCnt- 5)/2;i++){	/*�R?���h?���?ETX+BCC(2)*/
			*WpWriteBuff= Hex2nBin(sbuff++,2);
			sbuff++;
			WpWriteBuff++;
		}
		*TableCnt= i;
		ret= OK;
		if(*sbuff == ETB){			/*�������� */
			WpFlag= 2;
			DenubTimeoutCnt= 30;			/* NEXT�҂�?�C?�A�E�g */
			MatrixRetryCnt= 3;
		}else{
			ret= SetProgPatch(SWpWriteBuff);
			if(ret != NG){
//				fp= mopen(PLC_PROG_NAME,_O_WRONLY);
//				if(fp != GP_ERROR){
//					FileRetVal= mwrite(fp,&Inst_Operand_AreaBack[0],PlcDataSram.CodeTableCnt);
//					if(FileRetVal < 0){	ret= NG;}
//					mfileDelete(FileRetVal,fp);
//					mclose(fp);
//					Delay(300);
					//Step�����Ȃ��Ȃ邽�߁A�����Ōv�Z����B	
//					GetPlcProgram();			//Program From File
				memcpy(&PlcDataSram.Inst_Operand_Area[0],
						&PlcDataSram.Inst_Operand_Program[0],PlcDataSram.CodeTableCnt);
				/* Label Making */
				memset(PlcDataSram.Inst_Point_Table,-1,sizeof(PlcDataSram.Inst_Point_Table)) ;
				if(Instruction_Number_Set() == NG){   /* ���߁��I�y�����h�z��(�����Ƀ��x����)*/
					if(SWpWriteBuff != (char*)-1){		//20090112
						FreeMail(SWpWriteBuff);
						SWpWriteBuff= (char*)-1;
					}
					//�v���O��?�������ݒ�
//					*GlpSysState |= GLP_SYS_STATE_ONLINE_P;
					return(NG);
				}
				PlcSignalInf= ON;			//0:Stop,1:Start
			}else{
				PlcSignalInf= ON;			//0:Stop,1:Start
			}
			if(SWpWriteBuff != (char*)-1){		//20090112
				FreeMail(SWpWriteBuff);
				SWpWriteBuff= (char*)-1;
			}
			if(ret == NG){
				return(NG);
			}
			//�v���O��?�������ݒ�
//			*GlpSysState |= GLP_SYS_STATE_ONLINE_P;
		}
	}else{
		sbuff= &buff[0];
		for(i= 0; i < (SmtStoRecCnt- 3)/2;i++){	/*ETX+BCC(2)*/
			*WpWriteBuff= Hex2nBin(sbuff++,2);
			sbuff++;
			WpWriteBuff++;
		}
		*TableCnt += i;
		ret= OK;
		if(*sbuff == ETX){			/* �����Ȃ� */
			WpFlag= 0;
			/* �v���O��?���p�b?���� */
			ret= SetProgPatch(SWpWriteBuff);
//			fp= mopen(PLC_PROG_NAME,_O_WRONLY);
//			if(fp != GP_ERROR){
//				FileRetVal= mwrite(fp,&Inst_Operand_AreaBack[0],PlcDataSram.CodeTableCnt);
//				if(FileRetVal < 0){	ret= NG;}
//				mfileDelete(FileRetVal,fp);
//				mclose(fp);
//				Delay(300);
				//Step�����Ȃ��Ȃ邽�߁A�����Ōv�Z����B	
//				GetPlcProgram();			//Program From File
			memcpy(&PlcDataSram.Inst_Operand_Area[0],
					&PlcDataSram.Inst_Operand_Program[0],PlcDataSram.CodeTableCnt);
			/* Label Making */
			memset(PlcDataSram.Inst_Point_Table,-1,sizeof(PlcDataSram.Inst_Point_Table)) ;
			if(Instruction_Number_Set() == NG){   /* ���߁��I�y�����h�z��(�����Ƀ��x����)*/
				if(SWpWriteBuff != (char*)-1){		//20090112
					FreeMail(SWpWriteBuff);
					SWpWriteBuff= (char*)-1;
				}
				//�v���O��?�������ݒ�
//				*GlpSysState |= GLP_SYS_STATE_ONLINE_P;
				return(NG);
			}
			PlcSignalInf= ON;			//0:Stop,1:Start
			if(SWpWriteBuff != (char*)-1){		//20090112
				FreeMail(SWpWriteBuff);
				SWpWriteBuff= (char*)-1;
			}
			//�v���O��?�������ݒ�
//			*GlpSysState |= GLP_SYS_STATE_ONLINE_P;
		}else{
			DenubTimeoutCnt= 30;			/* NEXT�҂�?�C?�A�E�g */
			MatrixRetryCnt= 3;
		}
	}

	return(ret);
}
/********************************************/
/*	GO Command								*/
/********************************************/
void	SetStartStep2CurAdr(int step)
{
	int		i;

	if(PlcDataSram.Inst_Point_Table[step] >= 0){
		/* Start No OK */
		CodeData= &PlcDataSram.Inst_Operand_Area[PlcDataSram.Inst_Point_Table[step]];
	}else{
		/* Start No NG */
		for(i= step; i >= 0; i--){
			if(PlcDataSram.Inst_Point_Table[i] >= 0){
				CodeData= &PlcDataSram.Inst_Operand_Area[PlcDataSram.Inst_Point_Table[i]];
				break;
			}
		}
		if(i < 0){	CodeData= &PlcDataSram.Inst_Operand_Area[0];}
	}
}
void	SetStop2EndAddr(int step)
{
	int		i;

	/* End Step Check */
	if(PlcDataSram.Inst_Point_Table[step] >= 0){
		/* End No OK */
		GLP_StopAddr= PlcDataSram.Inst_Point_Table[step];
	}else{
		/* End No NG */
		for(i= step; i < MAX_STEP; i++){
			if(PlcDataSram.Inst_Point_Table[i] >= 0){
				GLP_StopAddr= PlcDataSram.Inst_Point_Table[i];
				break;
			}
		}
		if(i >= MAX_STEP){	GLP_StopAddr= -1;}
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: GO_Comm()													*/
/*	??	: "GO"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	GO_Comm(char *buff,char *SndBuff)
{
	int		ret;

	ret= NG;
	if((ProcMode != 0) && (PlcProcRunning == 0)){		/* DEBUG MODE�Œ�?�� */
		switch(buff[2]){
		case '0':		//�������O����X??�g
			StartStepNo= 0;
			CodeData= &PlcDataSram.Inst_Operand_Area[0];
			if( (ScanRunCnt > 0) &&		/* DEBUG MODE */
			    (ScanStartStep > 0) ){		//Scan Exe
				ScanRunCnt++;
			}
			ScanProc();		//����IO���f??����荞��
			DebugIoINSet();		//SET DEBUG IO
			GLP_StopStep= -1;
			GLP_StopAddr= -1;
			GLP_StopFlag= 0;
			ret= OK;
			break;
		case '1':		//�w��ʒu����X??�g
			StartStepNo= Hex2nBin(&buff[3],4);
			SetStartStep2CurAdr(StartStepNo);
			GLP_StopStep= -1;
			GLP_StopAddr= -1;
			GLP_StopFlag= 0;
			ret= OK;
			break;
		case '2':		//���݈ʒu����w��ʒu�܂�
			GLP_StopStep= Hex2nBin(&buff[3],4);
			SetStop2EndAddr(GLP_StopStep);
			GLP_StopFlag= 0;
			ret= OK;
			break;
		case '3':		//�w��ʒu����w��ʒu�܂�
			StartStepNo= Hex2nBin(&buff[3],4);
			SetStartStep2CurAdr(StartStepNo);
			GLP_StopStep= Hex2nBin(&buff[7],4);
			SetStop2EndAddr(GLP_StopStep);
			GLP_StopFlag= 0;
			ret= OK;
			break;
		case '4':		//�֐��𔲂���ʒu�܂�
			if(StackPointer > 0){
				GLP_StopAddr = (int)(StackArea[StackPointer-1]- &PlcDataSram.Inst_Operand_Area[0]);
				GLP_StopStep= GetCurr2Step(GLP_StopAddr);
				if(GLP_StopStep == -1){
					GLP_StopStep= 0;
				}
			}else{
				GLP_STCommFlag= 1;		/* ������? */
			}
			GLP_StopFlag= 0;
			ret= OK;
			break;
		default:
			break;
		}
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: ST_Comm()													*/
/*	??	: "ST"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	ST_Comm(char *buff,char *SndBuff)
{
	int		ret;

	ret= NG;
//	if((ProcMode != 0) && (PlcProcRunning == 1)){		/* DEBUG MODE��RUN�� */
	if(ProcMode != 0){
//		if(PlcProcRunning == 1){		/* DEBUG MODE��RUN�� */
			GLP_STCommFlag= 1;		/* ������? */
//		}
		ret= OK;
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SG_Comm()													*/
/*	??	: "SG"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	SG_Comm(char *buff,char *SndBuff)
{
	int		ret= OK;

	if((ProcMode != 0) && (PlcProcRunning == 0)){		/* DEBUG MODE�Œ�?�� */
		GLP_STCommFlag= 1;		/* ������? */
		GLP_StopFlag= 0;
	}else{
		ret= NG;
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SB_Comm()													*/
/*	??	: "SB"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	SB_Comm(char *buff,char *SndBuff)
{
	int		ret;
	int		cnt;
	int		i,j;

	ret= NG;
	if(ProcMode != 0){		/* DEBUG MODE */
		switch(buff[2]){
		case 'R':			/* RESET */
			cnt= Hex2nBin(&buff[3],2);
			for(i= 0; i < cnt; i++){
				ret= Hex2nBin(&buff[i*4+5],4);
				for(j= 0; j < Mon_Info.BpCnt; j++){
					if(Mon_Info.BpPos[j] == ret){
						break;
					}
				}
				if(j < Mon_Info.BpCnt){
					for(; j < Mon_Info.BpCnt; j++){
						Mon_Info.BpPos[j]= Mon_Info.BpPos[j+1];
					}
					Mon_Info.BpCnt--;
				}
			}
			ret= OK;
			break;
		case 'S':			/* SET */
			cnt= Hex2nBin(&buff[3],2);
			for(i= 0; (i < cnt) && (Mon_Info.BpCnt < MAX_BP_PRG); i++){
				ret= Hex2nBin(&buff[i*4+5],4);
				//����BP�͓o?���Ȃ�
				for(j= 0; j < Mon_Info.BpCnt; j++){
					if(Mon_Info.BpPos[j] == ret){	break;}
				}
				if(j >= Mon_Info.BpCnt){	Mon_Info.BpPos[Mon_Info.BpCnt++]= ret;}
			}
			ret= OK;
			break;
		case 'L':			/* LOAD */
			SndBuff[0]= STX;
			SndBuff[1]= 'S';
			SndBuff[2]= 'B';
			sprintf(&SndBuff[3],"%02X",Mon_Info.BpCnt);
			for(i= 0; i < Mon_Info.BpCnt; i++){
				sprintf(&SndBuff[i*4+5],"%04X",Mon_Info.BpPos[i]);
			}
			SndBuff[i*4+5]= ETX;
			ret= SetBcc(&SndBuff[1],Mon_Info.BpCnt*4+5);
			break;
		default:
			break;
		}
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: CB_Comm()													*/
/*	??	: "CB"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	CB_Comm(char *buff,char *SndBuff)
{
	int		ret;

	ret= NG;
	if(ProcMode != 0){		/* DEBUG MODE */
		Mon_Info.BpCnt= 0;
		ret= OK;
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: DB_Comm()													*/
/*	??	: "DB"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	DB_Comm(char *buff,char *SndBuff)
{
	int		i,j,k;
	int		cnt;
	int		code;
	int		addr;
	int		flag;
	int		ret;
	unsigned short*	DataAddr;
	int		idx;

	ret= NG;
	if(ProcMode != 0){		/* DEBUG MODE */
		cnt= Hex2nBin(&buff[3],2);
		switch(buff[2]){
		case 'C':
			Mon_Info.BpBit= 0;
			ret= OK;
			break;
		case 'R':		/* RESET */
			ret= OK;
			if(Mon_Info.BpBit == 0){	break;	}
			for(i= 0; i < cnt; i++){
				code = Hex2nBin(&buff[i*8+5],2);
				addr = ChangeDeviceAddr(0,&buff[i*8+7]);
				flag = buff[i*8+12];
				for(j= 0; j < Mon_Info.BpBit; j++){
					if((code == Mon_Info.Bit_Dev[j].DevCode) &&
						(addr == Mon_Info.Bit_Dev[j].DevAddr) &&
						(flag == Mon_Info.Bit_Dev[j].flag)){
						for(k= j; k < MAX_BP_BIT- 1; k++){
							memcpy(&Mon_Info.Bit_Dev[k],&Mon_Info.Bit_Dev[k+1],sizeof(DEV_BP));
						}
						Mon_Info.BpBit--;
						break;
					}
				}
			}
			break;
		case 'S':					/* SET */
			for(i= 0; i < cnt; i++){
				if(Mon_Info.BpBit >= MAX_BP_BIT){	break;	}
				code = Hex2nBin(&buff[i*8+5],2);
				addr = ChangeDeviceAddr(0,&buff[i*8+7]);
				flag = buff[i*8+12];
				for(j= 0; j < Mon_Info.BpBit; j++){
					if((code == Mon_Info.Bit_Dev[j].DevCode) &&
						(addr == Mon_Info.Bit_Dev[j].DevAddr) &&
						(flag == Mon_Info.Bit_Dev[j].flag)){
						break;
					}
				}
				if(j >= Mon_Info.BpBit){
					Mon_Info.Bit_Dev[Mon_Info.BpBit].DevCode = code;
					Mon_Info.Bit_Dev[Mon_Info.BpBit].DevAddr = addr;
					Mon_Info.Bit_Dev[Mon_Info.BpBit].flag = flag;
					GetBin_DevInfo((unsigned char)code,&DataAddr,&idx);
					Mon_Info.Bit_Dev[Mon_Info.BpBit].DeviceAddr= &DataAddr[addr>>4];
					Mon_Info.Bit_Dev[Mon_Info.BpBit].andData= AndTable[addr&0x000f];
					Mon_Info.BpBit++;
				}
			}
			ret= OK;
			break;
		case 'L':				/* LOAD */
			SndBuff[0]= STX;
			SndBuff[1]= 'D';
			SndBuff[2]= 'B';
			sprintf(&SndBuff[3],"%02X",Mon_Info.BpBit);
			for(i= 0; i < Mon_Info.BpBit; i++){
				sprintf(&SndBuff[i*8+5],"%02X",Mon_Info.Bit_Dev[i].DevCode);
				sprintf(&SndBuff[i*8+7],"%05X",Mon_Info.Bit_Dev[i].DevAddr);
				SndBuff[i*8+12]= (char)Mon_Info.Bit_Dev[i].flag;
			}
			SndBuff[i*8+5]= ETX;
			ret= SetBcc(&SndBuff[1],Mon_Info.BpBit*8+5);
			break;
		default:
			break;
		}
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: DW_Comm()													*/
/*	??	: "DW"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	DW_Comm(char *buff,char *SndBuff)
{
	int		i,j,k;
	int		cnt;
	int		code;
	int		addr;
	int		flag;
	int		ret;
	unsigned short*	DataAddr;
	int		idx;
	int		kind;

	ret= NG;
	if(ProcMode != 0){		/* DEBUG MODE */
		cnt= Hex2nBin(&buff[3],2);
		switch(buff[2]){
		case 'C':		/* Clear */
			Mon_Info.BpWord= 0;
			ret= OK;
			break;
		case 'R':		/* RESET */
			ret= OK;
			if(Mon_Info.BpWord == 0){	break;	}
			for(i= 0; i < cnt; i++){
				code = Hex2nBin(&buff[i*11+5],2);
				addr = ChangeDeviceAddr(1,&buff[i*11+7]);
				flag = Hex2nBin(&buff[i*11+11],4);
				for(j= 0; j < Mon_Info.BpWord; j++){
					if((code == Mon_Info.Word_Dev[j].DevCode) &&
						(addr == Mon_Info.Word_Dev[j].DevAddr) &&
						(flag == Mon_Info.Word_Dev[j].flag)){
						for(k= j; k < MAX_BP_WRD- 1; k++){
							memcpy(&Mon_Info.Word_Dev[k],&Mon_Info.Word_Dev[k+1],sizeof(DEV_BP));
						}
						Mon_Info.BpWord--;
						break;
					}
				}
			}
			break;
		case 'S':					/* SET */
			for(i= 0; i < cnt; i++){
				if(Mon_Info.BpWord >= MAX_BP_WRD){	break;	}
				code = Hex2nBin(&buff[i*11+5],2);
				addr = ChangeDeviceAddr(1,&buff[i*11+7]);
				flag = Hex2nBin(&buff[i*11+11],4);
				kind = buff[i*11+15]- '0';
				for(j= 0; j < Mon_Info.BpWord; j++){
					if((code == Mon_Info.Word_Dev[j].DevCode) &&
						(addr == Mon_Info.Word_Dev[j].DevAddr) &&
						(flag == Mon_Info.Word_Dev[j].flag)){
						break;
					}
				}
				if(j >= Mon_Info.BpWord){
					Mon_Info.Word_Dev[Mon_Info.BpWord].DevCode = code;
					Mon_Info.Word_Dev[Mon_Info.BpWord].DevAddr = addr;
					Mon_Info.Word_Dev[Mon_Info.BpWord].flag = flag;
					Mon_Info.Word_Dev[Mon_Info.BpWord].kind = kind;
					GetBin_DevInfo((unsigned char)code,&DataAddr,&idx);
					Mon_Info.Word_Dev[Mon_Info.BpWord].DeviceAddr= &DataAddr[addr];
					Mon_Info.BpWord++;
				}
			}
			ret= OK;
			break;
		case 'L':				/* LOAD */
			SndBuff[0]= STX;
			SndBuff[1]= 'D';
			SndBuff[2]= 'W';
			sprintf(&SndBuff[3],"%02X",Mon_Info.BpWord);
			for(i= 0; i < Mon_Info.BpWord; i++){
				sprintf(&SndBuff[i*10+5],"%02X",Mon_Info.Word_Dev[i].DevCode);
				sprintf(&SndBuff[i*10+7],"%04X",Mon_Info.Word_Dev[i].DevAddr);
				sprintf(&SndBuff[i*10+11],"%04X",Mon_Info.Word_Dev[i].flag);
			}
			SndBuff[i*10+5]= ETX;
			ret= SetBcc(&SndBuff[1],Mon_Info.BpWord*10+5);
			break;
		default:
			break;
		}
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: DR_Comm()													*/
/*	??	: "DR"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	DR_Comm(char *buff,char *SndBuff)
{
	int		ret;

	ret= NG;
	if(ProcMode != 0){		/* DEBUG MODE */
		switch(buff[2]){
		case '0':	Mon_Info.BpBit= 0;	Mon_Info.BpWord= 0;	ret= OK;	break;
		case '1':	Mon_Info.BpBit= 0;						ret= OK;	break;
		case '2':						Mon_Info.BpWord= 0;	ret= OK;	break;
		default:														break;
		}
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SC_Comm()													*/
/*	??	: "SC"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	SC_Comm(char *buff,char *SndBuff)
{
	int		cnt;
	int		ret;

	ret= NG;
	if(ProcMode != 0){		/* DEBUG MODE */
		cnt = Hex2nBin(&buff[2],8);
		ScanRunCnt= cnt;
		ScanStartStep= CodeData- &PlcDataSram.Inst_Operand_Area[0];
		ret= OK;
//		GLP_STCommFlag= 1;		/* ������? */
		GLP_StopFlag= 0;
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: IO_Comm()													*/
/*	??	: "IO"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	IO_Comm(char *buff,char *SndBuff)
{
	int		i,cnt;
	unsigned short*	DataAddr;
	int		idx;
	int		inflag,outflag;

	inflag= 0;
	outflag= 0;
	/* Not DEBUG MODE */
	if(ProcMode == 0){								return(NG);	}
	//I/O�ݒ�Enable?
//	if((*GlpSysRunMode & GLP_SYS_RUN_I_O) == 0){	return(NG);	}
	cnt = Hex2nBin(&buff[2],2);
	for(i= 0; (i < cnt) && (i < MAX_IO_SET); i++){
		Mon_Info.I_O_Dev[i].DevCode = Hex2nBin(&buff[i*8+4],2);
		Mon_Info.I_O_Dev[i].DevAddr = ChangeDeviceAddr(0,&buff[i*8+6]);
		Mon_Info.I_O_Dev[i].flag = buff[i*8+11];
		GetBin_DevInfo(Mon_Info.I_O_Dev[i].DevCode,&DataAddr,&idx);
		Mon_Info.I_O_Dev[i].DeviceAddr= &DataAddr[Mon_Info.I_O_Dev[i].DevAddr>>4];
		Mon_Info.I_O_Dev[i].andData= AndTable[Mon_Info.I_O_Dev[i].DevAddr&0x000f];
		if( (Mon_Info.I_O_Dev[i].DevCode ==  DEV_BX) && (Mon_Info.I_O_Dev[i].flag != 2) ){
			inflag= 1;
		}
		if( (Mon_Info.I_O_Dev[i].DevCode ==  DEV_BY) && (Mon_Info.I_O_Dev[i].flag != 2) ){
			outflag= 1;
		}
	}
	Mon_Info.I_O_Cnt= cnt;
	//�����h�n��?�h�n�m
	if(inflag == 1){
		*GlpSysState |= GLP_SYS_STATE_IO_IN;
	}else{
		*GlpSysState &= ~GLP_SYS_STATE_IO_IN;
	}
	if(outflag == 1){
		*GlpSysState |= GLP_SYS_STATE_IO_OUT;
	}else{
		*GlpSysState &= ~GLP_SYS_STATE_IO_OUT;
	}
	return(OK);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: RI_Comm()													*/
/*	??	: "RI"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	RI_Comm(char *buff,char *SndBuff)
{
	int		ret;
	int		i;

	SndBuff[0]= STX;
	SndBuff[1]= 'R';
	SndBuff[2]= 'I';
	sprintf(&SndBuff[3],"%02X",Mon_Info.I_O_Cnt);
	i= 0;
	if(Mon_Info.I_O_Cnt > 0){
		for(i= 0; i < Mon_Info.I_O_Cnt; i++){
			Bin2Hex(Mon_Info.I_O_Dev[i].DevCode,2,&SndBuff[i*8+5]);
			ChangeDeviceAddrDec(0,&SndBuff[i*8+7],Mon_Info.I_O_Dev[i].DevAddr);
			SndBuff[i*8+12]= Mon_Info.I_O_Dev[i].flag;
		}
	}
	SndBuff[i*8+5]= ETX;
	ret= SetBcc(&SndBuff[1],Mon_Info.I_O_Cnt*8+5);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: RV_Comm()													*/
/*	??	: "RV"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	RV_Comm(char *buff,char *SndBuff)
{
	int		ret;
	int		len;

	SndBuff[0]= STX;
	SndBuff[1]= 'R';
	SndBuff[2]= 'V';
	SndBuff[3]= buff[2];
	switch(buff[2]){
	case '1':
		sprintf(&SndBuff[4],"%04X",GP_TYPE_CODE);
		len= 8;
		break;
	case '2':
		memcpy(&SndBuff[4],GP_SYSVER,strlen(GP_SYSVER));
		len= strlen(GP_SYSVER)+ 4;
		break;
	case '3':
		memcpy(&SndBuff[4],GP_MODEL,strlen(GP_MODEL));
		len= strlen(GP_MODEL)+ 4;
		break;
	}
	SndBuff[len]= ETX;
	ret= SetBcc(&SndBuff[1],len);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: RA_Comm()													*/
/*	??	: "RA"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	RA_Comm(char *buff,char *SndBuff)
{
	int		ret;

	SndBuff[0]= STX;
	SndBuff[1]= 'R';
	SndBuff[2]= 'A';
//	memcpy(&SndBuff[3],PlcDataSram.PLC_Pass,16);
	memcpy(&SndBuff[3],GetPlcPassAddr(),16);		//20081108
	SndBuff[19]= ETX;
	ret= SetBcc(&SndBuff[1],19);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: WS_Comm()													*/
/*	??	: "WS"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	WS_Comm(char *buff,char *SndBuff)
{
//	memcpy(PlcDataSram.PLC_Pass,&buff[2],16);		20081108
	mWritePlcPass(&buff[2]);
	return(OK);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: CP_Comm()													*/
/*	??	: "CP"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	CP_Comm(char *buff,char *SndBuff)
{
	char	*mp;
	int		cnt,i;
	int		ret;
	int		sidx;

	ret= OK;
	switch(buff[2]){	//��ʂP
	case 'P':
		cnt = Hex2nBin(&buff[3],2);
		for(i= 0; i < cnt; i++){
			switch(buff[i+5]){
			case '0':	/* ALL */
				PlcMainTaskStopWait();	//Plc Main Stop
				PlcDataSram.CodeTableCnt= 0;
				PlcDataSram.CodeTableSum= 0;
				PlcDataSram.Load_Count= 0;
				PlcDataSram.ParamTableCnt= 0;
				PlcDataSram.LComentTableCnt= 0;
				PlcDataSram.RComentTableCnt= 0;
				PlcDataSram.ValTableCnt= 0;
				PlcDataSram.LabelTableCnt= 0;
				PlcDataSram.ProjTableCnt= 0;
				PlcDevAllClear();		//Data Clear
				PortOutProc();
				mformat2();
//#ifdef	WIN32
//				memset(&GpFont[PLC_PARAM_FILE],0,4);
//#else
				//�����O�X���O�ɂ���B
//				RamFlashWrite((short *)PLC_PARAM_FILE,(short *)&PlcDataSram.ParamTableCnt,4);
//#endif
				//PIO Slot 
				sidx= GetPioSlotNo();
				SetClearFilterInt(sidx);
				memset(&PlcDataSram.GlpIoInfo,0,sizeof(PlcDataSram.GlpIoInfo));
				SetClearFunc(sidx);
				InitParamFile();


				PlcSignalInf= ON;			//0:Stop,1:Start
				break;
			case PLC_PROC:	/* Program */
				PlcMainTaskStopWait();	//Plc Main Stop
				PlcDataSram.CodeTableCnt= 0;
				PlcDataSram.CodeTableSum= 0;
				PlcDataSram.Load_Count= 0;
				mp= DeleteFileOpen2(  );
				DeleteFile2( PLC_PROG_NAME_DIR, mp );
				DeleteFileClose2( mp );
				PlcDeviceClear();		//Data Clear
				PlcSpecialDevClear(ON,OFF,ON);	//���ꃌ�W�X??
				PlcSignalInf= ON;			//0:Stop,1:Start
				break;
			case PLC_PARAM:	/* param */
				PlcDataSram.ParamTableCnt= 0;
//	#ifdef	WIN32
//				memset(&GpFont[PLC_PARAM_FILE],0,4);
//	#else
//				//�����O�X���O�ɂ���B
//				RamFlashWrite((short *)PLC_PARAM_FILE,(short *)&PlcDataSram.ParamTableCnt,4);
//	#endif
				//PIO Slot 
				sidx= GetPioSlotNo();
				SetClearFilterInt(sidx);
				memset(&PlcDataSram.GlpIoInfo,0,sizeof(PlcDataSram.GlpIoInfo));
				SetClearFunc(sidx);
				InitParamFile();
				break;
			case PLC_LCOMENT:	/* ���C���b������������ */
				PlcDataSram.LComentTableCnt= 0;
				mp= DeleteFileOpen2(  );
				DeleteFile2( PLC_LCOM_NAME_DIR, mp );
				DeleteFileClose2( mp );
				break;
			case PLC_RCOMENT:	/* RUNG Comment */
				PlcDataSram.RComentTableCnt= 0;
				mp= DeleteFileOpen2(  );
				DeleteFile2( PLC_RCOM_NAME_DIR, mp );
				DeleteFileClose2( mp );
				break;
			case PLC_VAL:	/* �ϐ� */
				PlcDataSram.ValTableCnt= 0;
				mp= DeleteFileOpen2(  );
				DeleteFile2( PLC_VAL_NAME_DIR, mp );
				DeleteFileClose2( mp );
				break;
			case PLC_LABEL:	/* LABEL */
				PlcDataSram.LabelTableCnt= 0;
				mp= DeleteFileOpen2(  );
				DeleteFile2( PLC_LABEL_NAME_DIR, mp );
				DeleteFileClose2( mp );
				break;
			case PLC_PROJ:	/* Project */
				PlcDataSram.ProjTableCnt= 0;
				mp= DeleteFileOpen2(  );
				DeleteFile2( PLC_PROJ_NAME_DIR, mp );
				DeleteFileClose2( mp );
				break;
			case '8':	/* Data Clear */
				PlcDevAllClear();		//Data Clear
				PortOutProc();
				break;
			case '9':	/* Program Download */
				PlcMainTaskStopWait();	//Plc Main Stop
				PlcDataSram.CodeTableCnt= 0;
				PlcDataSram.CodeTableSum= 0;
				PlcDataSram.Load_Count= 0;
//				PlcDataSram.ParamTableCnt= 0;
				PlcDataSram.LComentTableCnt= 0;
				PlcDataSram.RComentTableCnt= 0;
				PlcDataSram.ValTableCnt= 0;
				PlcDataSram.LabelTableCnt= 0;
				PlcDataSram.ProjTableCnt= 0;
				PlcDeviceClear();		//Data Clear
				PlcSpecialDevClear(ON,OFF,ON);	//���ꃌ�W�X??
				mformat2();
				PlcSignalInf= ON;			//0:Stop,1:Start
				break;
			default:
				ret= NG;
				break;
			}
		}
		break;
	case 'D':
		cnt = Hex2nBin(&buff[3],2);
		for(i= 0; i < cnt; i++){
			ret= RsDevClear(&buff[i*2+5]);
			if(ret == NG){	break;	}
		}
		PortOutProc();
		break;
	default:
		ret= NG;
		break;
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: RM_Comm()													*/
/*	??	: "RM"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	RM_Comm(char *buff,char *SndBuff)
{
	int		ret;
	int		i;
	int		cnt;
	char	sbuff[20];
	unsigned char*	TitleAddr;

	SndBuff[0]= STX;
	SndBuff[1]= 'R';
	SndBuff[2]= 'M';
	sprintf(&SndBuff[3],"%02X",extInfo.extCnt);		/* ���W��?���� */
	for(i= 0; i < extInfo.extCnt; i++){
		sprintf(&SndBuff[30*i+5],"%02X",extInfo.ExtInfo[i].SlotNo);		/* �X���b�g�ԍ� */
		sprintf(&SndBuff[30*i+7],"%04X",extInfo.ExtInfo[i].ID);		/* ���W��?���h�c */
		memset(sbuff,' ',8);
		sbuff[8]= 0;
		memcpy(sbuff,extInfo.ExtInfo[i].Version,strlen(extInfo.ExtInfo[i].Version));
		memcpy(&SndBuff[30*i+11],sbuff,8);	/* �o?�W���� */
		memset(sbuff,' ',16);
		sbuff[16]= 0;
		if((extSlotInfo.ExtInfo[i].ID != 00) && (extSlotInfo.ExtInfo[i].ID != 0xff)){
#ifdef	WIN32
			TitleAddr= (unsigned char*)&GpFont[(PARAM_MODULE_NAME+ (extSlotInfo.ExtInfo[i].ID* 16))];
#else
			TitleAddr= (unsigned char*)(PARAM_MODULE_NAME+ (extSlotInfo.ExtInfo[i].ID* 16));
#endif
			cnt= strlen((char*)TitleAddr);
			if(cnt > 16){
				cnt= 16;
			}
			memcpy(sbuff,TitleAddr,cnt);
		}
		memcpy(&SndBuff[30*i+19],sbuff,16);	/* ���f���� */
	}
	SndBuff[30*i+5]= ETX;
	ret= SetBcc(&SndBuff[1],30*i+5);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: CN_Comm()													*/
/*	??	: "CN"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	CN_Comm(char *buff,char *SndBuff)
{
	return(0);
}
//Run/Stop Swich Proc
void	SetRunStopSwitch(int OnOff)
{
	if(OnOff == ON){
		GlpRunMode= 'R';
		*GlpSysMode =	GLP_SYS_MODE_RUN;
		ProcMode= 0;			//1:DEBUG ��?�h
		GLP_StopFlag= 0;		//�v���O��?�X??�g
#ifdef	WIN32
		BitRunOnOffWin32C(1);
#endif
		LedModeFlag= LED_MODE_RUN;
		/* Debug ��񏉊��� */
		memset(&Mon_Info,0,sizeof(Mon_Info));
		//�����h�n��?�h�N���A
		*GlpSysState &= ~(GLP_SYS_STATE_IO_IN | GLP_SYS_STATE_IO_OUT);
	}else{
		GlpRunMode= 'S';
		*GlpSysMode =	GLP_SYS_MODE_STOP;
		ProcMode= 0;
		GLP_STStopFlag= 1;		//�����I��
		GLP_STScanFlag= 1;		//�v���O��?�I��
		GLP_STCommFlag= 1;		/* ������? */
#ifdef	WIN32
		BitRunOnOffWin32C(8);
#endif
		LedModeFlag= LED_MODE_OFF;
		/* Debug ��񏉊��� */
		memset(&Mon_Info,0,sizeof(Mon_Info));
		//�����h�n��?�h�N���A
		*GlpSysState &= ~(GLP_SYS_STATE_IO_IN | GLP_SYS_STATE_IO_OUT);
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PM_Comm()													*/
/*	??	: "PM"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	PM_Comm(char *buff,char *SndBuff)
{
	int	ret;
	ret= NG;
	switch(buff[2]){
	case 'R':
		if(RunStopSwitch == ON){
			ProcMode= 0;			//1:DEBUG ��?�h
			GLP_StopFlag= 0;		//�v���O��?�X??�g
#ifdef	WIN32
			BitRunOnOffWin32C(1);
#endif
//			if(GlpRunMode != 'P'){
				//0 Start
//				CodeData= &PlcDataSram.Inst_Operand_Area[0];
//				ScanProc();		//����IO���f??����荞��
//				DebugIoINSet();		//SET DEBUG IO
//			}
			GlpRunMode= buff[2];
			SetLedMode();
			*GlpSysMode= GLP_SYS_MODE_RUN;
			/* Debug ��񏉊��� */
			memset(&Mon_Info,0,sizeof(Mon_Info));
			//�����h�n��?�h�N���A
			*GlpSysState &= ~(GLP_SYS_STATE_IO_IN | GLP_SYS_STATE_IO_OUT);
			ret= OK;		//Mode Error

			*GlpSysCulc &= ~GLP_SYS_CULC_ERR;				//2011.08.11 Scan Start Clear
		}
		break;
	case 'D':
		if(RunStopSwitch == ON){
			if((PlcProcRunning == 0) || (GLP_StopFlag == ON)){		//STOP
				GLP_StopFlag= 0;
			}
//			GLP_STStopFlag= 1;		//�����I��
			GLP_STScanFlag= 1;		//�v���O��?�I��
#ifdef	WIN32
			BitRunOnOffWin32C(2);
#endif
			GlpRunMode= buff[2];
			SetLedMode();
			*GlpSysMode =	GLP_SYS_MODE_DEBUG;
			//Break Point Clear	2007.04.25
			Mon_Info.BpCnt= 0;
			ret= OK;
			WdtStartFlag= 0;		//WDT Stop 2008.08.28  20080822

			*GlpSysCulc &= ~GLP_SYS_CULC_ERR;				//2011.08.11 Scan Start Clear
			memcpy(InDevArea.PlcDev.Debug_Y,InDevArea.PlcDev.Y,Device_Length_Y);		//2011.10.06
		}
		break;
	case 'P':
		if((RunStopSwitch == ON) &&
			(GlpRunMode == 'R')){
			ProcMode= 0;
//			GLP_STCommFlag= 1;		//�v���O��?��?
			GLP_STScanFlag= 1;		//�v���O��?�I��
#ifdef	WIN32
			BitRunOnOffWin32C(4);
#endif
			GlpRunMode= buff[2];
			SetLedMode();
			*GlpSysMode =	GLP_SYS_MODE_PAUS;
			/* Debug ��񏉊��� */
			memset(&Mon_Info,0,sizeof(Mon_Info));
			//�����h�n��?�h�N���A
			*GlpSysState &= ~(GLP_SYS_STATE_IO_IN | GLP_SYS_STATE_IO_OUT);
			ret= OK;

			*GlpSysCulc &= ~GLP_SYS_CULC_ERR;				//2011.08.11 Scan Start Clear
		}
		break;
	case 'S':
		if((RunStopSwitch == ON) &&
			(GlpRunMode != 'D')){
			ProcMode= 0;
			GLP_STStopFlag= 1;		//�����I��
			GLP_STScanFlag= 1;		//�v���O��?�I��
			GLP_STCommFlag= 1;		/* ������? */
#ifdef	WIN32
			BitRunOnOffWin32C(8);
#endif
			GlpRunMode= buff[2];
			SetLedMode();
			*GlpSysMode =	GLP_SYS_MODE_STOP;
			while(1){
				if(PlcMainRunFlag == OFF){	break;	}
				Delay(20);
			}
			/* Debug ��񏉊��� */
			memset(&Mon_Info,0,sizeof(Mon_Info));
			//�����h�n��?�h�N���A
			*GlpSysState &= ~(GLP_SYS_STATE_IO_IN | GLP_SYS_STATE_IO_OUT);
			ret= OK;
		}
		break;
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: RS_Comm()													*/
/*	??	: "RS"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	RS_Comm(char *buff,char *SndBuff)
{
	int		ret;

	SndBuff[0]= STX;
	SndBuff[1]= 'R';
	SndBuff[2]= 'S';
	if(RunStopSwitch == OFF){	SndBuff[3]= 'X';				}
	else{						SndBuff[3]= (char)GlpRunMode;	}
	SndBuff[4]= ETX;
	ret= SetBcc(&SndBuff[1],4);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: RC_Comm()													*/
/*	??	: "RC"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	RC_Comm(char *buff,char *SndBuff)
{
	int		ret;

	SndBuff[0]= STX;
	SndBuff[1]= 'R';
	SndBuff[2]= 'C';
	sprintf(&SndBuff[3],"%08X",PlcDataSram.CodeTableSum);
	SndBuff[11]= ETX;
	ret= SetBcc(&SndBuff[1],11);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SR_Comm()													*/
/*	??	: "SR"�R?���h����											*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	SR_Comm(char *buff,char *SndBuff)
{
	int		ret;

	SndBuff[0]= STX;
	SndBuff[1]= 'S';
	SndBuff[2]= 'R';
	SndBuff[10]= ETX;
	ret= SetBcc(&SndBuff[1],10);
	ret= 0;
	return(ret);
}
/************************************************/
/*	���j?�R?���h								*/
/************************************************/
/*----------------------------------------------------------------------*/
/*	�֐���	: ChangeDeviceAddr()										*/
/*	??	: HEX ASCII�A�h���X��BIN�A�h���X�ɕύX����B				*/
/*	����	: int flag->0:Bit,1:Word									*/
/*			  char *buff->HEX ASCII�o�b�t??							*/
/*	�߂�l	: BIN Address												*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	ChangeDeviceAddr(int flag,char *buff)
{
	int	addr;

	addr= 0;
	if(flag == 0){	addr = Hex2nBin(&buff[0],5);}		/* Bit Device */
	else{			addr = Hex2nBin(&buff[0],4);}		/* Word Device */
	if(ProcMode != 0){			//Debug Mode 2011.10.06
		if( (addr >= Device_Length_Y_ST) && (addr < Device_Length_BT_ST) ){
			addr= Debug_Y_ST+ (addr- Device_Length_Y_ST);
		}
	}
	return(addr);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: ChangeDeviceAddrDec()										*/
/*	??	: BIN�A�h���X��DEC ASCII�A�h���X�ɕύX����B				*/
/*	����	: int flag->0:Bit,1:Word									*/
/*			  char *buff->DEC ASCII�o�b�t??							*/
/*			  int paddr->BIN Address									*/
/*	�߂�l	: 0															*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	ChangeDeviceAddrDec(int flag,char *buff,int paddr)
{
	int	addr;

	addr= 0;
	if(flag == 0){		/* Bit Device */
		addr= paddr >> 4;
		sprintf(buff,"%04d",addr);
		sprintf(&buff[4],"%X",paddr & 0x000f);
	}else{	sprintf(buff,"%04d",paddr);	}
	return(0);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: BR_Comm()													*/
/*	??	: "BR"�R?���h����(Bit Monitor)								*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	SendInterPreter(int Command,char *buff,char *SndBuff)
{
	int	ret;
	T_MAIL*	mp;
	int	mbx;
	unsigned int	OldResp;

	mbx= TakeMbx();
	mp= (T_MAIL*)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd= Command;
	mp->mptr= (void*)buff;
	mp->mref= (void*)SndBuff;
	SendMail(T_PLCMAIN,(char *)mp);
	mp= (T_MAIL *)ReceiveMail( mbx );
	ret= (short)mp->mpec;
	ChangeMailResp( (char *)mp, OldResp );
	FreeMail( (char *)mp );
	FreeMbx( mbx );
	return(ret);
}
int	BR_Comm(char *buff,char *SndBuff)
{
	return(SendInterPreter(BR_COMM,buff,SndBuff));
}
int	BR_CommProc(char *buff,char *SndBuff)
{
	int	i;
	int	pcnt;
	int	addr;
	int	andData,idx;
	char	*ResBuf;
	int		ret;
	unsigned short	*obuff;

	pcnt= Hex2nBin(&buff[2],2);
	addr= ChangeDeviceAddr(0,&buff[4]);		/* Bit Address Change */
	SndBuff[0]= STX;
	memcpy(&SndBuff[1],buff,4);
	ResBuf= &SndBuff[5];
	andData= AndTable[addr & 0x000f];
	idx= addr >> 4;
	obuff= &InDevArea.UW[idx];
	for(i= 0; i < pcnt; i++){
		if(*obuff & andData){	*ResBuf++ = '1';}
		else{					*ResBuf++ = '0';}
		andData= andData << 1;
		if(andData > 0x8000){
			obuff++;
			andData= 0x0001;
		}
	}
	*ResBuf++ = ETX;
	ret= SetBcc(&SndBuff[1],pcnt+5);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: WR_Comm()													*/
/*	??	: "WR"�R?���h����(Word Monitor)							*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	WR_Comm(char *buff,char *SndBuff)
{
	return(SendInterPreter(WR_COMM,buff,SndBuff));
}
int	WR_CommProc(char *buff,char *SndBuff)
{
	int	i;
	int	pcnt;
	int	addr;
	char	*ResBuf;
	int		ret;
	unsigned short	*obuff;

	pcnt= Hex2nBin(&buff[2],2);
	addr= ChangeDeviceAddr(1,&buff[4]);			/* Word Address Change */
	SndBuff[0]= STX;
	memcpy(&SndBuff[1],buff,4);
	ResBuf= &SndBuff[5];
	obuff= &InDevArea.UW[addr];
	for(i= 0; i < pcnt; i++){
		Bin2Hex(*obuff++,4,&ResBuf[i*4]);
	}
	ResBuf[i*4]= ETX;
	ret= SetBcc(&SndBuff[1],pcnt*4+5);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: BW_Comm()													*/
/*	??	: "BW"�R?���h����(Bit Write)								*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	BW_Comm(char *buff,char *SndBuff)
{
	return(SendInterPreter(BW_COMM,buff,SndBuff));
}
int	BW_CommProc(char *buff,char *SndBuff)
{
	int	i;
	int	pcnt;
	int	addr;
	int	andData,idx;
	char	*ResBuf;
	int		ret;
	unsigned short	*obuff;

	pcnt= Hex2nBin(&buff[2],2);
	addr= ChangeDeviceAddr(0,&buff[4]);		/* Bit Address Change */
	ResBuf= &buff[9];
	andData= AndTable[addr & 0x000f];
	idx= addr >> 4;
	obuff= &InDevArea.UW[idx];
	for(i= 0; i < pcnt; i++){
		if(*ResBuf++ == '1'){	*obuff |= andData;	}
		else{					*obuff &= ~andData;	}
		andData= andData << 1;
		if(andData > 0x8000){
			obuff++;
			andData= 0x0001;
		}
	}
	ret= OK;
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: WW_Comm()													*/
/*	??	: "WW"�R?���h����(Word Write)								*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	WW_Comm(char *buff,char *SndBuff)
{
	return(SendInterPreter(WW_COMM,buff,SndBuff));
}
int	WW_CommProc(char *buff,char *SndBuff)
{
	int	i;
	int	pcnt;
	int	addr;
	char	*ResBuf;
	int		ret;
	unsigned short	*obuff;

	pcnt= Hex2nBin(&buff[2],2);
	addr= ChangeDeviceAddr(1,&buff[4]);			/* Word Address Change */
	ResBuf= &buff[8];
	obuff= &InDevArea.UW[addr];
	for(i= 0; i < pcnt; i++){
		*obuff++ = Hex2nBin(&ResBuf[i*4],4);
	}
	ret= OK;
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: ME_Comm()													*/
/*	??	: "ME"�R?���h����(Monitor Entry)							*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	ME_Comm(char *buff,char *SndBuff)
{
	int	bcnt;
	int	dcnt;
	int	ret;
	int	i;
	int	flag;
	int	temp;

	ret= NG;
	/* Data Length Check */
	bcnt= Hex2nBin(&buff[2],2);			/* block no */
	if((bcnt < 1) || (bcnt > 16)){	return(ret);	}
	bcnt--;
	dcnt= Hex2nBin(&buff[4],2);			/* Device no */
	flag= buff[6]- '0';
	if(flag == 0){		/* Bit */
		if((SmtStoRecCnt-10)/5 == dcnt){	ret = OK;}
	}else{
		if((SmtStoRecCnt-10)/4 == dcnt){	ret = OK;}
	}
	if((ret == NG) || ((dcnt <= 0) || (dcnt >= 80))){	return(NG);	}
	DevMon[bcnt].flag= buff[6]- '0';
	DevMon[bcnt].cnt= dcnt;
	for(i= 0; i < dcnt; i++){
		if(DevMon[bcnt].flag == 0){		//BIT DEVICE
			/* ��� */
			DevMon[bcnt].Device[i].kind= 0;
			/* Addres */
			temp= DevMon[bcnt].Device[i].addr= ChangeDeviceAddr(DevMon[bcnt].flag,&buff[i*5+7]);
			DevMon[bcnt].Device[i].DevAddr= &InDevArea.UW[temp >> 4];
			DevMon[bcnt].Device[i].idx= AndTable[temp & 0x000f];
		}else{							//WORD DEVICE
			/* ��� */
			DevMon[bcnt].Device[i].kind= 1;
			/* Addres */
			temp= DevMon[bcnt].Device[i].addr= ChangeDeviceAddr(DevMon[bcnt].flag,&buff[i*4+7]);
			DevMon[bcnt].Device[i].DevAddr= &InDevArea.UW[temp];
		}
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: MR_Comm()													*/
/*	??	: "MR"�R?���h����(Monitor Read)							*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	MR_Comm(char *buff,char *SndBuff)
{
	return(SendInterPreter(MR_COMM,buff,SndBuff));
}
//2011.10.06
unsigned short *SetDebugAddr(unsigned short *DevAddr)
{
	if( (DevAddr >= InDevArea.PlcDev.Y) && (DevAddr < InDevArea.PlcDev.BT) ){
		return(InDevArea.PlcDev.Debug_Y+ (DevAddr- InDevArea.PlcDev.Y));
	}else{
		return(DevAddr);
	}
}
int	MR_CommProc(char *buff,char *SndBuff)
{
	int	bcnt;
	int	ret;
	int	i;
	int	idx;
	MON_DEV_ITEM	*item;
	int	cnt;
	unsigned short *DevAddr;		//2011.10.06

	ret= NG;
	bcnt= Hex2nBin(&buff[2],2);			/* block no */
	if((bcnt < 1) || (bcnt > 16)){	return(ret);	}
	bcnt--;
	SndBuff[0]= STX;
	memcpy(&SndBuff[1],buff,4);
	/* ��� */
	SndBuff[5]= DevMon[bcnt].flag+ '0';
	/* ?�C���g�� */
	sprintf(&SndBuff[6],"%02X",DevMon[bcnt].cnt);
	idx= 8;
	item= &DevMon[bcnt].Device[0];
	cnt= DevMon[bcnt].cnt;
	if(DevMon[bcnt].flag == 0){		/* Bit Address */
		for(i= 0; i < cnt; i++, item++){
			if(ProcMode == 0){			//Debug Mode 2011.10.06
				DevAddr= item->DevAddr;
			}else{
				DevAddr= SetDebugAddr(item->DevAddr);
			}
//2011.10.06			if(*item->DevAddr & item->idx){	SndBuff[idx++]= '1';}
			if(*DevAddr & item->idx){	SndBuff[idx++]= '1';}
			else{						SndBuff[idx++]= '0';}
		}
	}else{
		for(i= 0; i < cnt; i++, item++){
			if(ProcMode == 0){			//Debug Mode 2011.10.06
				DevAddr= item->DevAddr;
			}else{
				DevAddr= SetDebugAddr(item->DevAddr);
			}
//2011.10.06			Bin2Hex(*item->DevAddr,4,&SndBuff[idx]);
			Bin2Hex(*DevAddr,4,&SndBuff[idx]);
			idx += 4;
		}
	}
	SndBuff[idx++]= ETX;
	ret= SetBcc(&SndBuff[1],idx-1);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: MC_Comm()													*/
/*	??	: "MC"�R?���h����(Monitor Clear)							*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	MC_Comm(char *buff,char *SndBuff)
{
	memset(DevMon,0,sizeof(DevMon));
	return(OK);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: RB_Comm()													*/
/*	??	: "RB"�R?���h����(Bit Continue Read)						*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	RB_Comm(char *buff,char *SndBuff)
{
	return(SendInterPreter(RB_COMM,buff,SndBuff));
}
int	RB_CommProc(char *buff,char *SndBuff)
{
	int	i;
	int	pcnt;
	int	addr;
	int	andData,idx;
	char	*ResBuf;
	int		ret;
	unsigned short	*obuff;

	pcnt= Hex2nBin(&buff[2],2);
	ret= NG;
	SndBuff[0]= STX;
	memcpy(&SndBuff[1],buff,4);
	ResBuf= &SndBuff[5];
	for(i= 0; i < pcnt; i++){
		addr= ChangeDeviceAddr(0,&buff[i*5+4]);		/* Bit Address Change */
		andData= AndTable[addr & 0x000f];
		idx= addr >> 4;
		obuff= &InDevArea.UW[idx];
		if(*obuff & andData){	*ResBuf++ = '1';}
		else{					*ResBuf++ = '0';}
		andData= andData << 1;
		if(andData > 0x8000){	obuff++;	andData= 0x0001;	}
	}
	*ResBuf++ = ETX;
	ret= SetBcc(&SndBuff[1],pcnt+5);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: RW_Comm()													*/
/*	??	: "RW"�R?���h����(Word Continue Read)						*/
/*	����	: char *buff->��M�o�b�t??�i�f??�̐擪(�R?���h)�j		*/
/*			  char *SndBuff->���M�o�b�t??(&Buff[4])					*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	RW_Comm(char *buff,char *SndBuff)
{
	return(SendInterPreter(RW_COMM,buff,SndBuff));
}
int	RW_CommProc(char *buff,char *SndBuff)
{
	int	i;
	int	pcnt;
	int	addr;
	char	*ResBuf;
	int		ret;
	unsigned short	*obuff;

	pcnt= Hex2nBin(&buff[2],2);
	ret= NG;
	SndBuff[0]= STX;
	memcpy(&SndBuff[1],buff,4);
	ResBuf= &SndBuff[5];
	for(i= 0; i < pcnt; i++){
		addr= ChangeDeviceAddr(1,&buff[i*4+4]);			/* Word Address Change */
		obuff= &InDevArea.UW[addr];
		Bin2Hex(*obuff++,4,&ResBuf[i*4]);
	}
	ResBuf[i*4]= ETX;
	ret= SetBcc(&SndBuff[1],pcnt*4+5);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: GetCurr2Step()											*/
/*	??	: �R?�h�̈�ʒu���X�e�b�v�ɕϊ�����B						*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �X�e�b�v													*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	GetCurr2Step(int pos)
{
	int		i;
	for(i= 0; i < MAX_STEP; i++){
		if(PlcDataSram.Inst_Point_Table[i] >= pos){	break;}
	}
	return(i);
}
int	GetCurrBeforStep(int pos)
{
	int	i;
	int	ret;

	if(PlcDataSram.Inst_Address2Step[pos] != (unsigned short)-1){
		ret= PlcDataSram.Inst_Address2Step[pos];
	}else{
		for(i= pos- 1; i >= 0; i--){
			if(PlcDataSram.Inst_Address2Step[i] != (unsigned short)-1){
				ret= PlcDataSram.Inst_Address2Step[i];
				break;
			}
		}
		if(i < 0){
			ret= 0;
		}
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: DenbunTimeoutProc()										*/
/*	??	: �v���g�R��?�C?�A�E�g����								*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: OK:Retry,NG:Timeout										*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	DenbunTimeoutProc(void)
{
	int	ret= NG;

	if(Matrix_Mode == DATA_SEND_WAIT){	/* UpLoad Time Out */
		MatrixRetryCnt--;
		if(MatrixRetryCnt <= 0){
			if(SWpWriteBuff != (char*)-1){
				FreeMail(SWpWriteBuff);
				SWpWriteBuff= (char*)-1;
			}
			Matrix_Mode= IDLE;
		}else{
			DenubTimeoutCnt= 30;			/* ACK�҂�?�C?�A�E�g */
			ret= OK;
			//�v���O��?�������ݒ��N���A
//			*GlpSysState &= ~GLP_SYS_STATE_ONLINE_P;
		}
	}else{								/* Next Time Out */
		MatrixRetryCnt--;
		if(MatrixRetryCnt <= 0){
			if(WpFlag == 1){	/* WP Next */
				*TableCnt= 0;	/* ��M�f??�N���A */
				if(SWpWriteBuff != (char*)-1){		//20090112
					FreeMail(SWpWriteBuff);
					SWpWriteBuff= (char*)-1;
				}
			}
			WpFlag= 0;
			//Plc Main Task Start
			if(PlcMainRunFlag == OFF){
				PlcMainRunFlag= ON;
			}
			Matrix_Mode= IDLE;
			//�v���O��?�������ݒ��N���A
//			*GlpSysState &= ~GLP_SYS_STATE_ONLINE_P;
		}else{
			DenubTimeoutCnt= 30;			/* ACK�҂�?�C?�A�E�g */
			ret= OK;
		}
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: MakeStopInf()												*/
/*	??	: Break���̍쐬(GlpSendBuff)								*/
/*	����	: int addr->�R?�h�̈�ʒu									*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SendPCData( unsigned char *SendBuff,int *SendCommCnt );
void	MakeStopInf(int addr)
{
	int		ret;
	int		step;
	unsigned char	*GlpSendBuff;
	int		GlpSendCnt;

	PlcProcRunning= 0;		/* �q�t�m?STOP */
	GLP_StopFlag = 1;		/* Stop         */

	GlpSendBuff= (unsigned char*)TakeMemory(sizeof(Sio1SndBuff));
	/* ���M�p�f??�쐬 */
	memcpy(&GlpSendBuff[0],&RecStationno[2],2);
	memcpy(&GlpSendBuff[2],&RecStationno[0],2);
	GlpSendBuff[4]= STX;
	GlpSendBuff[5]= 'S';
	GlpSendBuff[6]= 'T';
	step= GetCurr2Step(addr);
	sprintf((char *)&GlpSendBuff[7],"%04X",step);
	GlpSendBuff[11]= ETX;
	ret= SetBcc((char *)&GlpSendBuff[5],7);
	GlpSendCnt= ret;
	SendPCData(GlpSendBuff,(int *)&GlpSendCnt);
	FreeMail((char *)GlpSendBuff);
	//Step Change
	*GlpSysBreakStep= step;
}


extern	void	IndevWriteProc(T_MAIL *mp);
extern	void	IndevReadProc(T_MAIL *mp);
extern	void	UW_AllReadProc(int mode);

void	MonitorProc(T_MAIL* mp)
{
	int	ret= 0;

	switch(mp->mcmd){
	case BR_COMM:	ret= BR_CommProc((char*)mp->mptr,(char*)mp->mref);		break;
	case WR_COMM:	ret= WR_CommProc((char*)mp->mptr,(char*)mp->mref);		break;
	case BW_COMM:	ret= BW_CommProc((char*)mp->mptr,(char*)mp->mref);		break;
	case WW_COMM:	ret= WW_CommProc((char*)mp->mptr,(char*)mp->mref);		break;
	case MR_COMM:	ret= MR_CommProc((char*)mp->mptr,(char*)mp->mref);		break;
	case RB_COMM:	ret= RB_CommProc((char*)mp->mptr,(char*)mp->mref);		break;
	case RW_COMM:	ret= RW_CommProc((char*)mp->mptr,(char*)mp->mref);		break;
	case UW_READ:	IndevReadProc(mp);										break;
	case UW_WRITE:	IndevWriteProc(mp);										break;
	case UW_READ_ALL:	UW_AllReadProc(mp->mcod);							break;
	}
	mp->mpec= ret;
}

#endif

