/************************************************/
/*	IO�R���g��?���v���O��?					*/
/************************************************/
#include	"sgt.h"
#include	"PlcHed.h"


#define	ERR_BCC		0x01	/* BCC ERROR */
#define	ERR_FILE	0x02	/* File Error */

//#define	OLD_EDITOR


extern	int		PcDownloadStart;		/* 070207 */
extern	void	SetSpecialRegisterAddr(void);
extern	void	SetRunStopSwitch(int OnOff);

/************************************************/
/*	�ʐM?�C?�A�E�g�iEditor�j					*/
#define	EDIT_TIME_OUT	15000			/* 15S */
/***********************************************/
/**********************************/
/********************************************/
/*	PC UPLoad Info							*/
/********************************************/

/**********************************/
/****************************************/
/*	Bordrate Info						*/
/****************************************/
/**********************************/

void	_INITSCT( void )
{
#ifdef	LP_S044
	//INIT��PLCArea���A�N�Z�X���邽��
	SetSpecialRegisterAddr();
#endif
	HotStartCheck();
//	InitInClock();
}
void	_INIT( void )
{
	_INITSCT();
}

void	PrtHand( T_MAIL	*mp )
{
	int		mbx;
	int		OldResp;
	T_MAIL	*mp1;

	//061124
//	InDevArea.UB[10] |= W_PRT_ON;
	InDevArea.UW[5] |= W_PRT_ON;
	mbx = TakeMbx();
	mp1 = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp1, mbx );
	mp1->mcmd = RS_SEND;	/* ���M */
	mp1->mpar = mp->mext;	/* Length */
	mp1->mptr = mp->mptr;
	mp1->mpec = 0;
	mp1->mwrk= 3000;		/* 3s */
	if(Set.Ch1_iConnect == CH_CH0){	/* PLC = RS-422 */
		SendMail(T_SIO1DRV,(char *)mp1);
	}else{							/* PLC = RS-232C */
		SendMail(T_SIO0DRV,(char *)mp1);
	}
	mp1= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp1, OldResp );
	mp->mpec = mp1->mpec;
	FreeMbx(mbx);
	FreeMail((char *)mp1);
	//061124
//	InDevArea.UB[10] &= ~W_PRT_ON;
	InDevArea.UW[5] &= ~W_PRT_ON;
}
#ifdef	WIN32
char	BarData[32];
#endif
/****************************************************/
/*	�o?�R?�h���͏���								*/
/****************************************************/
void	BarcodeIn(char *buff)
{
	DEV_DATA DevInfo;
	char	*wBuff;
	int		i;
	int		Cnt;

	Cnt= CommonArea.SystemDev.Barcode_Dev.DevCnt;
	/* Read DEV-b6 */
	//061124
//	if(((InDevArea.UB[INDEV_READ_B] & R_BAR_DI) == 0) && (Cnt != 0)){
	if(((InDevArea.UW[INDEV_READ_B/2] & R_BAR_DI) == 0) && (Cnt != 0)){
#ifdef	WIN32
		wBuff= BarData;
#else
		wBuff= TakeMemory(Cnt*2);
#endif
		memset(wBuff,0x20,Cnt*2);
		for(i = 0;i < Cnt*2- 2; i++){
			if(buff[i] == 0x0d){
				break;
			}
			wBuff[i+2]= buff[i];
		}
//061124
//		wBuff[0]= i%256;
//		wBuff[1]= i/256;
		wBuff[0]= i/256;
		wBuff[1]= i%256;
		memcpy(DevInfo.DevName,CommonArea.SystemDev.Barcode_Dev.DevName,3);
		DevInfo.DevAddress= CommonArea.SystemDev.Barcode_Dev.DevAdd;
		DevInfo.DevCnt= Cnt;
		DevInfo.DevData= wBuff;
		DevInfo.DevFlag= DEVICE_WORD;		/* Word */

#ifdef	WIN32
#else
		PLCWrite(&DevInfo);
		FreeMail(wBuff);
#endif
		/* b5 ON */
		//061124
//		InDevArea.UB[INDEV_WRITE+9] |= W_BAR_ON;
		InDevArea.UW[INDEV_WRITE+4] |= W_BAR_ON;
/*		if(CommonArea.SystemDev.Write_Dev.DevName[0] != 0){*/
			SendTimeAction(10,0,0,0);							
/*		}*/
	}
}
/***********************************************/
/*  16�i�E2�i�ϊ�����   		                  */
/*       1995.11.8                             */
/***********************************************/
unsigned char LHexToBin(char as_data)
{
	unsigned char ret;

	ret = 0;
	if((as_data >= '0') && (as_data <= '9')){
		ret = (unsigned char)(as_data - '0');
	}
	else if((as_data >= 'A') && (as_data <= 'F')){
		ret = (unsigned char)(as_data - 'A' + 10);
	}
	return(ret);
}
/***********************************************/
/*  16�i�E2�i�ϊ�����   		                  */
/*       1995.11.8                             */
/***********************************************/
unsigned int LHexAsToBin(char *buff, int cnt)
{
	int		i;
	unsigned int hex_data;

	hex_data = 0;
	for(i = 0; i < cnt; i++){
		hex_data = hex_data << 4;
		hex_data += LHexToBin(buff[i]);
	}
	return(hex_data);
}
void	Bin2Hex2(char data, char *buf)
{
	unsigned char	high,low;

	high = (data & 0xf0) >> 4;
	low = data & 0x0f;
	if(high > 9){
		high += 55;
	}
	else{
		high += 48;
	}
	if(low > 9){
		low += 55;
	}
	else{
		low += 48;
	}
	buf[0] = high;
	buf[1] = low;
}
//void	InitInClock( void )
//{
//	In100MSecCnt= 0;
//	memset(&InDevArea.UW[INDEV_UN_W], 0, INDEV_UN_NO);
//}
//extern	int		SecChangFlag;		/* �b���ς������ON */
#ifdef	OLD
void	InClockProc( void )
{
#ifdef	GP_S044
	unsigned char	data;
	unsigned short	wdata;
#endif
#ifdef	GP_S057
	unsigned char	data;
	unsigned short	wdata;
#endif
/*int		i;*/
/*int		signal;*/
/*char	buff[32];*/
/*	int		i;*/
/*	T_MAIL	*mp;*/
	/* D8000 */
	if((_TimeMSec % 100) == 0){		/* 100ms */
		In100MSecCnt++;

/* 20080822 �� �κ��� GP�� LP ��� ����ϹǷ� �ϳ��� �ۼ��ؼ� �����ϴ� ������� ó�� */
#ifdef	GP_S044
		if((SecChangFlag == 1) && ((In100MSecCnt % 5) == 0)){	/* 0.5S */
//		if((In100MSecCnt % 5) == 0){	/* 0.5S */
			//061124
//			InDevArea.UB[10] += CLOCK05;
			data= InDevArea.UW[5] & 0x00ff;
			data += CLOCK05;
			wdata= (InDevArea.UW[5] & 0xff00) + data;
			InDevArea.UW[5]= wdata;
			SecChangFlag= 0;
		}
#endif
#ifdef	GP_S057
		if((SecChangFlag == 1) && ((In100MSecCnt % 5) == 0)){	/* 0.5S */
//		if((In100MSecCnt % 5) == 0){	/* 0.5S */
			//061124
//			InDevArea.UB[10] += CLOCK05;
			data= InDevArea.UW[5] & 0x00ff;
			data += CLOCK05;
			wdata= (InDevArea.UW[5] & 0xff00) + data;
			InDevArea.UW[5]= wdata;
			SecChangFlag= 0;
		}
#endif
/*
		if((In100MSecCnt % 10) == 0){
			mp = (T_MAIL *)TakeMail();
			mp->mcmd = RTC_READ_I;
			SendMail( T_RTCHAND, (char *)mp );
		}
*/
/*
if((In100MSecCnt % 10) == 0){
	signal = ReadSignal(SGN_PLC);
	if((signal & 0x01) != 0){
		sprintf(buff,"N%02d",_RunTaskNo);
		for(i= 0; i < 3; i++){
			Sio1SendChar(buff[i]);
		}
	}
}
*/
	}
}
#endif
/************************************************************/
/*	PC Data Analisys										*/
/************************************************************/
void	SetPCEditorBcc(unsigned char *SendBuff,int *SendCommCnt)
{
	unsigned char	bcc;
	int		i;

	bcc = 0;
	SendBuff[1] = (*SendCommCnt- 2)%256;
	SendBuff[2] = (*SendCommCnt- 2)/256;
	for(i = 0; i < *SendCommCnt- 1; i++){
		bcc += SendBuff[i + 1];
	}
	SendBuff[*SendCommCnt] = (char)bcc;
	(*SendCommCnt)++;
	SendBuff[0] = 0xff;
}
#ifdef	OLD_EDITOR
#define	TBL_REC_SIZE	15	/* Rec- NSize */
#else
#define	TBL_REC_SIZE	17	/* Rec- NSize */
#endif
void	MakePlcDevTable(int mode,int idx0)
{
	int		i;
	int		idx;
	int		Bcnt,Wcnt;
	unsigned int	Cnt;
	int		NSize;
	int		OffSet;
	char	*IndexTbl;
	char	*DeviceTbl;
#ifdef	WIN32			//Windows����Mts���g�p�ł��Ȃ�����
	char	IndexTblBuf[256];
	char	DeviceTblBuf[0x1000];
#endif

#ifdef	WIN32
	IndexTbl= IndexTblBuf;
	DeviceTbl= DeviceTblBuf;
#else
	IndexTbl= TakeMemory(256);
	DeviceTbl= TakeMemory(0x1000);
#endif
	memset(IndexTbl,0xff,256);
	memset(DeviceTbl,0xff,0x1000);
	HistIdx= (CommonSendBuf[idx0+1] * 256+ CommonSendBuf[idx0+2]);	/* �e?�u���T�C�Y */
	Bcnt= 0;	/* Byte Count */
	Wcnt= 0;	/* Word Count */
	NSize= CommonSendBuf[idx0+4];
	for(i = 5; i < HistIdx;i += (TBL_REC_SIZE+NSize)){		/* 14->15  15+NSize(1Record) */
		Cnt= CommonSendBuf[idx0+i+1];
		if(CommonSendBuf[idx0+i] == 1){	/* Byte */
			idx= Bcnt*32;
			if(Cnt < 256){
				IndexTbl[Cnt]= Bcnt;
			}
		}else{
			idx= Wcnt*32+0x800;
			if(Cnt < 256){
				IndexTbl[Cnt]= Wcnt;
			}
		}
		memset(&DeviceTbl[idx],0,32);
		memcpy(&DeviceTbl[idx],&CommonSendBuf[idx0+i],2);
		memcpy(&DeviceTbl[idx+2],&CommonSendBuf[idx0+i+2],NSize);
		OffSet= idx0+i+ 2+ NSize;
		DeviceTbl[idx+7]= CommonSendBuf[OffSet++];
#ifdef	OLD_EDITOR
		Cnt= CommonSendBuf[OffSet++]* 0x10000;
		Cnt+= CommonSendBuf[OffSet++]* 0x100;
		Cnt+= CommonSendBuf[OffSet++];
#else
		Cnt=  (unsigned int)CommonSendBuf[OffSet++] << 24;
		Cnt+= (unsigned int)CommonSendBuf[OffSet++] << 16;
		Cnt+= (unsigned int)CommonSendBuf[OffSet++] << 8;
		Cnt+= (unsigned int)CommonSendBuf[OffSet++];
#endif
		memcpy(&DeviceTbl[idx+8],&Cnt,4);
#ifdef	OLD_EDITOR
		Cnt= CommonSendBuf[OffSet++]* 0x10000;
		Cnt+= CommonSendBuf[OffSet++]* 0x100;
		Cnt+= CommonSendBuf[OffSet++];
#else
		Cnt=  (unsigned int)CommonSendBuf[OffSet++] << 24;
		Cnt+= (unsigned int)CommonSendBuf[OffSet++] << 16;
		Cnt+= (unsigned int)CommonSendBuf[OffSet++] << 8;
		Cnt+= (unsigned int)CommonSendBuf[OffSet++];
#endif
		memcpy(&DeviceTbl[idx+12],&Cnt,4);
		/* Min 2Byte */
		Cnt= CommonSendBuf[OffSet++]* 0x100;
		Cnt+= CommonSendBuf[OffSet++];
		memcpy(&DeviceTbl[idx+16],&Cnt,4);
		/* Max 2Byte */
		Cnt= CommonSendBuf[OffSet++]* 0x100;
		Cnt+= CommonSendBuf[OffSet++];
		memcpy(&DeviceTbl[idx+20],&Cnt,4);
		/* Keta 1Byte */
		Cnt= CommonSendBuf[OffSet++];
		memcpy(&DeviceTbl[idx+24],&Cnt,4);
		/* 16Bit(0)/32Bit(1)/48Bit(2)/64Bit(3) 1Byte */
		Cnt= CommonSendBuf[OffSet++];
		memcpy(&DeviceTbl[idx+28],&Cnt,4);
		if(CommonSendBuf[idx0+i] == 1){	/* Byte */
			Bcnt++;
		}else{
			Wcnt++;
		}
	}
	if(mode == 0){
		memcpy(&CommonSendBuf[(PLC1_DEV_TABLE+0x0100)-PLC1_DEV_TABLE],IndexTbl,256);
		memset(&CommonSendBuf[(PLC1_DEV_TABLE+0x0000)-PLC1_DEV_TABLE],0xff,0x100);
		memcpy(&CommonSendBuf[(PLC1_DEV_TABLE+0x0000)-PLC1_DEV_TABLE],&Bcnt,4);
		memcpy(&CommonSendBuf[(PLC1_DEV_TABLE+0x0004)-PLC1_DEV_TABLE],&Wcnt,4);
		Cnt= CommonSendBuf[3]- 1;			/* Low/High Flag */
		memcpy(&CommonSendBuf[(PLC1_DEV_TABLE+0x0008)-PLC1_DEV_TABLE],&Cnt,4);
		/* Device Table Set */
		memcpy(&CommonSendBuf[(PLC1_DEV_TABLE+0x0200)-PLC1_DEV_TABLE],DeviceTbl,0x1000);
	}else{
		memcpy(&CommonSendBuf[(PLC2_DEV_TABLE+0x0100)-PLC1_DEV_TABLE],IndexTbl,256);
		memset(&CommonSendBuf[(PLC2_DEV_TABLE+0x0000)-PLC1_DEV_TABLE],0xff,0x100);
		memcpy(&CommonSendBuf[(PLC2_DEV_TABLE+0x0000)-PLC1_DEV_TABLE],&Bcnt,4);
		memcpy(&CommonSendBuf[(PLC2_DEV_TABLE+0x0004)-PLC1_DEV_TABLE],&Wcnt,4);
		Cnt= CommonSendBuf[idx0+3]- 1;			/* Low/High Flag */
		memcpy(&CommonSendBuf[(PLC2_DEV_TABLE+0x0008)-PLC1_DEV_TABLE],&Cnt,4);
		/* Device Table Set */
		memcpy(&CommonSendBuf[(PLC2_DEV_TABLE+0x0200)-PLC1_DEV_TABLE],DeviceTbl,0x1000);
	}
#ifdef	WIN32
#else
	FreeMail(IndexTbl);
	FreeMail(DeviceTbl);
#endif
}
/****************************************/
/*	PLC�e?�u���쐬						*/
/****************************************/
void	MakePlcTable(void)
{
	int		i;
	int		idx;
	int		Cnt0;
	unsigned char	*src;
	unsigned char	*obj;
	int		Protocol2Tbl;
	int		ProtocolInfo;		/* ksc20090525 0x01:Protocol1,0x02:Protocol2,0x03:Protocol1,2 */


	/******************* Program Move(0x7000 V0.300�ǉ�) ******************/
	idx= 0;
	Protocol2Tbl= -1;
	if(CommonSendBuf[idx] == 0x21){			/* Table protocol1 */
		idx= (CommonSendBuf[idx+1] * 256+ CommonSendBuf[idx+2]);	/* �e?�u���T�C�Y */
	}
	if(CommonSendBuf[idx] == 0x22){			/* Table protocol2 */
		Protocol2Tbl= idx;
		idx += (CommonSendBuf[idx+1] * 256+ CommonSendBuf[idx+2]);	/* �e?�u���T�C�Y */
	}
	ProtocolInfo= 0;	/* ksc20090525 Protocol1,2 Check */
	if(CommonSendBuf[idx] == 0x23){			/* PLC 1 Protocol */
		idx += (CommonSendBuf[idx+1] * 256+ CommonSendBuf[idx+2]);	/* Protocol1 */
		ProtocolInfo |= 0x01;	/* ksc20090525 Protocol1,2 Check */
	}
	if(CommonSendBuf[idx] == 0x24){			/* PLC 2 Protocol */
		ProtocolInfo |= 0x02;	/* ksc20090525 Protocol1,2 Check */
		Cnt0 = (CommonSendBuf[idx+1] * 256+ CommonSendBuf[idx+2])- 3;	/* Protocol2�T�C�Y */
		idx += (CommonSendBuf[idx+1] * 256+ CommonSendBuf[idx+2])- 1;	/* �e?�u���T�C�Y */
		obj= (unsigned char *)&CommonSendBuf[(PLC2_PROTOCOL- PLC1_DEV_TABLE)+ Cnt0- 1];
		src= (unsigned char *)&CommonSendBuf[idx];
		for(i= 0; i < Cnt0; i++){
			*obj = *src;
			obj--;
			src--;
		}
	}else{
		/* PLC2 NOT USE */
#ifdef	WIN32
		/* �e?�u����?�h */
		CommonArea.PlcType2.AuxPlcUserFlag= 0;
		memcpy(&CommonSendBuf[(PLC2_DEV_TABLE- PLC1_DEV_TABLE)],&GpFont[PLC2_DEV_TABLE],
			(PLC2_DEV_TABLE+0x08000)- PLC2_DEV_TABLE);
#else
		CommonArea.PlcType2.AuxPlcUserFlag= 0;
		memcpy(&CommonSendBuf[(PLC2_DEV_TABLE- PLC1_DEV_TABLE)],(char *)PLC2_DEV_TABLE,
			(PLC2_DEV_TABLE+0x08000)- PLC2_DEV_TABLE);
#endif
	}
	/******************* Program Move(0x1000) *****************************/
	if(ProtocolInfo != 0x00){	/* ksc20090525 Protocol1,2 Check */
/*		if(ProtocolInfo == 1){	*//* Protocol1 Check */
		if(ProtocolInfo & 1){	/* ksc20090525 Protocol1 Check */
			idx= (CommonSendBuf[1] * 256+ CommonSendBuf[2]);	/* �e?�u���T�C�Y */
			if(Protocol2Tbl != -1){
/* 060519			idx += Protocol2Tbl;*/
				idx += (CommonSendBuf[Protocol2Tbl+1] * 256+ CommonSendBuf[Protocol2Tbl+2]);
			}
			Cnt0 = (CommonSendBuf[idx+ 1] * 256+ CommonSendBuf[idx+ 2])- 3;	/* �e?�u���T�C�Y */
			idx += (CommonSendBuf[idx+ 1] * 256+ CommonSendBuf[idx+ 2])- 1;	/* �e?�u���T�C�Y */
			obj= (unsigned char *)&CommonSendBuf[(PLC1_PROTOCOL- PLC1_DEV_TABLE)+ Cnt0- 1];
			src= (unsigned char *)&CommonSendBuf[idx];
			for(i= 0; i < Cnt0; i++){
				*obj = *src;
				obj--;
				src--;
			}
		}else{
//		Set.Ch1_iKind= 0;	//2008.12.09		/* �����v���g�R�� */
		}
		if(Protocol2Tbl != -1){		/* Protocol2 Table */
			MakePlcDevTable(1,Protocol2Tbl);
		}
		if(CommonSendBuf[0] == 0x21){			/* Protocol1 Table */
			/***************** �e?�u���쐬 ********************************/
			MakePlcDevTable(0,0);
		}else if(Protocol2Tbl == -1){			/* no Table */ 
#ifdef	WIN32
			/* �e?�u����?�h */
			memcpy(&CommonSendBuf[0x0000],(char *)&GpFont[PLC1_DEV_TABLE],0x10000);
#else
			memcpy(&CommonSendBuf[0x0000],(char *)PLC1_DEV_TABLE,0x10000);
#endif
		}
#ifdef	WIN32
		/* �t�H���g�e?�u����?�h */
		memcpy(&GpFont[PLC1_DEV_TABLE],&CommonSendBuf[0],0x10000);
#else
		/* ���b�Z?�W���t�H���g�e?�u����?�h */
		RamFlashEraze((short *)PLC1_DEV_TABLE);
		RamFlashWrite((short *)PLC1_DEV_TABLE,(short *)&CommonSendBuf[0],0x10000);
#endif
	}
/*	ProtocalDownLoad= 1;	ksc20090516	*/ /* Connect Change */ 
}
int	GetHexRec(void)
{
	int	ret;

	ret= NG;
	if(Hexidx == 0){
		for(;FontCnt < RecCommCnt- 1; FontCnt++){
			if(CommBuff[FontCnt] == 'S'){
				ret = OK;
				break;
			}
		}
	}else{
		ret= OK;
	}
	if(ret == OK){
		ret= NG;
		if(Hexidx >= 256){
			Hexidx= 0;
		}
		for(;FontCnt < RecCommCnt- 1 && Hexidx < 256; FontCnt++){
			Hexbuff[Hexidx++]= CommBuff[FontCnt];
			if(CommBuff[FontCnt] == 0x0d){
				Hexbuff[Hexidx++]= 0;
				Hexidx= 0;
				ret= OK;
				break;
			}
		}
		if(Hexidx >= 256){
			Hexidx= 0;
		}

	}
	return(ret);
}
void	SetErrorRec( int ErrCd,unsigned char *SendBuff,int *SendCommCnt,int Kind )
{
	Delay(100);
/*	CommMode = 0;*/
	CommCnt = 0;
	CommKind = 0;
	memcpy(&SendBuff[1],CommBuff,7);
	SendBuff[7] = (unsigned char)ErrCd;
	SendBuff[8] = Kind;
	*SendCommCnt = 9;
	SetPCEditorBcc(SendBuff,SendCommCnt);
}
void	SendPlcWaitFlag(void)
{
	int	iKind;

	if(Set.Ch1_iConnect == CH_CH1){		/* RS-232C */
		iKind= Set.Ch1_iKind;
	}else{
		iKind= Set.Ch2_iKind;
	}
	//PLC Aboat
	if(iKind != EDITER){
		AddFlag(T_SIO1DRV,1);
		AddFlag(T_SIO1DRV,1);
	}else{
		AddFlag(T_SIO0DRV,1);
		AddFlag(T_SIO0DRV,1);
	}
}
//2011.12.07///////////////////////
void	SetInitDownLoad(void)
{
	if(CommonArea.PcUpDownMode != 0){
		DownloadFileInfo= 0;
#ifndef	WIN32
		if((int)UpBaseNo != -1){
			FreeMail((char *)UpBaseNo);
			FreeMail((char *)UpWinNo);
			UpBaseNo= (char *)-1;
			UpWinNo= (char *)-1;
		}
#endif
		if(PcFilefp != -1){
			mclose(PcFilefp);
			PcFilefp= -1;
		}
	}
}
/****************************************/
int	GPDataCheck( unsigned char *CommBuff,unsigned char *SendBuff,int *SendCommCnt )
{
	int		i,j;
	int		cnt;
	int	CommKind;
	char	*mp;
	int		ret;
	char	FileName[32];
	void	(*AplLoadfunc)();
	int		signal;

	ret= OK;
	CommModeData = (unsigned char)CommBuff[2];
	CommModeData = (CommModeData << 8) | (unsigned char)CommBuff[3];

	switch(CommModeData){
	case PC_DOWNLD:		/* DownLoad */
		ProtocolDownloadFlag = 0;		/* �������� �ٿ�ε� �÷��� 20090610 */ 
		if(CommonArea.PcUpDownMode == 0){
			CommonArea.PcUpDownMode= 1;		/* DownLoad Mode */
			SendPlcWaitFlag();				/* 070205 */
#ifdef	LP_S044		/* 20080822 �ٿ�δ��� ���� ��� ������ ������� ����, �������� ��� �������� ���� */
						/* 20080829 �ٿ�δ��� PLC ������ �ʰ� ��� �޼����� �����ְ� �����ϵ��� ó�� - �ڸ�Ʈ ó�� */
/*			DownloadStopFlag= GlpRunMode;	*/
/*			SetRunStopSwitch(OFF);	*/
#endif
		/* 20081007 */
		signal = 0xffffffff;
		OffSignal(SGN_PLC,signal);		/* PLC Stop */
		OffSignal(S_PROJECT,signal);
		OffSignal(S_SCREEN,signal);


#ifndef	WIN32
			for(i= 0; i < 100; i++){				//5s Timeout			/* ksc20090525 Task�� �����Ҷ����� ��ٸ��� �ִ� �ð� 10S�� ���� */
				if((PlchandTask == 0) && (PlcstateTask == 0) && (ConnectTask == 0) &&
					(WaitDisplayTask == 0) && (Plc2handTask == 0)){			/* 20081007 */
					break;
				}
				Delay(100);
			}
#else
			Delay(100);
#endif
			PcDownloadStart= 1;				/* 2008.09.26 */
			Delay(500);
			if(CommBuff[6] == 0x01){	/* ALL Deleate */
				mformat();				/* �t?�C���V�X�e?�̏����� */
				init_filesystem();
				ClearHistry();
			}
/*			PcDownloadStart= 1;*/				/* 070207 */
			memcpy(&SendBuff[1],CommBuff,7);
			SendBuff[7] = ACK;
			SendBuff[8] = 0;
			*SendCommCnt = 9;
		}else{
/*			*SendCommCnt = 0;*/
			ret= NG;
		}
		break;
	case PC_COMMON:		/* Common Data */
		if((CommBuff[5] == 0x01) &&	/* Start */
			(DownloadFileInfo == 0)){		/* 0:NewFile,1:Openning 060121 */
			DownloadFileInfo= 1;			/* 0:NewFile,1:Openning		*/
			/* 050407 */
			if(PcFilefp != -1){
				mclose(PcFilefp);
			}
			PcFilefp= mopen("common.gp",_O_WRONLY);
			if(PcFilefp != GP_ERROR){
				FileRetVal= mwrite(PcFilefp,&CommBuff[0],RecCommCnt- 1);
			}
		}else{
			FileRetVal= mwrite(PcFilefp,&CommBuff[6],RecCommCnt- 7);
		}
		if(CommBuff[4] == 0x02){	/* End */
			mfileDelete(FileRetVal,PcFilefp);
			mclose(PcFilefp);
			DownloadFileInfo= 0;			/* 0:NewFile,1:Openning		*/
		}
		if((CommBuff[4] == 0x02) && (FileRetVal < 0)){	/* File Error */
			SetErrorRec(NAK,SendBuff,SendCommCnt,ERR_FILE);
		}else{
			memcpy(&SendBuff[1],CommBuff,7);
			SendBuff[7] = ACK;
			SendBuff[8] = 0;
			*SendCommCnt = 9;
		}
		break;
	case PC_PROJC:		/* Project */
		if((CommBuff[5] == 0x01) &&	/* Start */
			(DownloadFileInfo == 0)){		/* 0:NewFile,1:Openning 060121 */
			DownloadFileInfo= 1;			/* 0:NewFile,1:Openning		*/
			/* 050407 */
			if(PcFilefp != -1){
				mclose(PcFilefp);
			}
			PcFilefp= mopen("project.gp",_O_WRONLY);
			if(PcFilefp != GP_ERROR){
				FileRetVal= mwrite(PcFilefp,&CommBuff[0],RecCommCnt- 1);
			}
		}else{
			FileRetVal= mwrite(PcFilefp,&CommBuff[6],RecCommCnt- 7);
		}
		if(CommBuff[4] == 0x02){	/* End */
			mfileDelete(FileRetVal,PcFilefp);
			mclose(PcFilefp);
			DownloadFileInfo= 0;			/* 0:NewFile,1:Openning		*/
		}
		if((CommBuff[4] == 0x02) && (FileRetVal < 0)){	/* File Error */
			SetErrorRec(NAK,SendBuff,SendCommCnt,ERR_FILE);
		}else{
			memcpy(&SendBuff[1],CommBuff,7);
			SendBuff[7] = ACK;
			SendBuff[8] = 0;
			*SendCommCnt = 9;
		}
		break;
	case PC_BASE:		/* Base */
		if((CommBuff[5] == 0x01) &&	/* Start */
			(DownloadFileInfo == 0)){		/* 0:NewFile,1:Openning 060121 */
			DownloadFileInfo= 1;			/* 0:NewFile,1:Openning		*/
			CommKind = (CommBuff[6]&0x7f)*256 + CommBuff[7];
			sprintf(FileName,"Bas%05d.gp",CommKind);
			/* 050407 */
			if(PcFilefp != -1){
				mclose(PcFilefp);
			}
			PcFilefp= mopen(FileName,_O_WRONLY);
			FileRetVal= mwrite(PcFilefp,(char *)&CommBuff[0],RecCommCnt- 1);
		}else{
			FileRetVal= mwrite(PcFilefp,(char *)&CommBuff[6],RecCommCnt- 7);
		}
		if(CommBuff[4] == 0x02){	/* End */
			mfileDelete(FileRetVal,PcFilefp);
			mclose(PcFilefp);
			DownloadFileInfo= 0;			/* 0:NewFile,1:Openning		*/
		}
		if((CommBuff[4] == 0x02) && (FileRetVal < 0)){	/* File Error */
			SetErrorRec(NAK,SendBuff,SendCommCnt,ERR_FILE);
		}else{
			memcpy(&SendBuff[1],CommBuff,7);
			SendBuff[7] = ACK;
			SendBuff[8] = 0;
			*SendCommCnt = 9;
		}
		break;
	case PC_WINDW:		/* Window */
		if((CommBuff[5] == 0x01) &&	/* Start */
			(DownloadFileInfo == 0)){		/* 0:NewFile,1:Openning 060121 */
			DownloadFileInfo= 1;			/* 0:NewFile,1:Openning		*/
			CommKind = (CommBuff[6]&0x7f)*256 + CommBuff[7];
			/*CommKind = CommBuff[6]*256 + CommBuff[7];*/
			sprintf(FileName,"Win%05d.gp",CommKind);
			/* 050407 */
			if(PcFilefp != -1){
				mclose(PcFilefp);
			}
			PcFilefp= mopen(FileName,_O_WRONLY);
			FileRetVal= mwrite(PcFilefp,&CommBuff[0],RecCommCnt- 1);
		}else{
			FileRetVal= mwrite(PcFilefp,&CommBuff[6],RecCommCnt- 7);
		}
		if(CommBuff[4] == 0x02){
			mfileDelete(FileRetVal,PcFilefp);
			mclose(PcFilefp);
			DownloadFileInfo= 0;			/* 0:NewFile,1:Openning		*/
		}
		if((CommBuff[4] == 0x02) && (FileRetVal < 0)){	/* File Error */
			SetErrorRec(NAK,SendBuff,SendCommCnt,ERR_FILE);
		}else{
			memcpy(&SendBuff[1],CommBuff,7);
			SendBuff[7] = ACK;
			SendBuff[8] = 0;
			*SendCommCnt = 9;
		}
		break;
	case PC_UPLOAD:
		CommonArea.PcUpDownMode= 2;		/* UP LOAD */
		*SendCommCnt= 0;
		/* Upload Set */
#ifndef	WIN32
		UpBaseNo= (char *)TakeMemory(MAX_BASE_NO);
		UpWinNo= (char *)TakeMemory(MAX_WIN_NO);
#endif

/* 20080822 �� �����ߴ��� Ȯ�� �ʿ�, */
//		WriteRecipLast();			/* Recipe File Write V608 */
		


		if(CommBuff[6] == 0){		/* All Upload */
			memset(UpBaseNo,0x01,MAX_BASE_NO);
			memset(UpWinNo,0x01,MAX_WIN_NO);
			UpParts= 0x01;
			UpComment= 0x01;
			i= 7;
			UpHist= CommBuff[i++];
			UpFreq= CommBuff[i++];
		}else{
			memset(UpBaseNo,0x00,MAX_BASE_NO);
			memset(UpWinNo,0x00,MAX_WIN_NO);
			UpParts= 0x00;
			UpComment= 0x00;
			i= 7;
			UpHist= CommBuff[i++];
			UpFreq= CommBuff[i++];
			cnt= CommBuff[i++]* 256;
			cnt+= CommBuff[i++];
			for(j = 0; j < cnt; j++){
				CommKind= CommBuff[i++]* 256;
				CommKind+= CommBuff[i++];
				UpBaseNo[CommKind]= 0x01;
			}
			cnt= CommBuff[i++]* 256;
			cnt+= CommBuff[i++];
			for(j = 0; j < cnt; j++){
				CommKind= CommBuff[i++]* 256;
				CommKind+= CommBuff[i++];
				UpWinNo[CommKind]= 0x01;
			}
			UpParts= CommBuff[i++];
			UpComment= CommBuff[i++];
		}
		break;
	case PC_PROJHED:
		CommonArea.PcUpDownMode= 3;		/* UP LOAD Project Head */
		*SendCommCnt= 0;
		break;
	case PC_COMENT:
		if((CommBuff[5] == 0x01) &&	/* Start */
			(DownloadFileInfo == 0)){			/* 0:NewFile,1:Openning		*/
			DownloadFileInfo= 1;			/* 0:NewFile,1:Openning		*/
			/* 050407 */
			if(PcFilefp != -1){
				mclose(PcFilefp);
			}
			PcFilefp= mopen("comment.gp",_O_WRONLY);
			if(PcFilefp != GP_ERROR){
				FileRetVal= mwrite(PcFilefp,&CommBuff[0],RecCommCnt- 1);
			}
		}else{
			FileRetVal= mwrite(PcFilefp,&CommBuff[6],RecCommCnt- 7);
		}
		if(CommBuff[4] == 0x02){	/* End */
			mfileDelete(FileRetVal,PcFilefp);
			mclose(PcFilefp);
			DownloadFileInfo= 0;			/* 0:NewFile,1:Openning		*/
		}
		if((CommBuff[4] == 0x02) && (FileRetVal < 0)){	/* File Error */
			SetErrorRec(NAK,SendBuff,SendCommCnt,ERR_FILE);
		}else{
			memcpy(&SendBuff[1],CommBuff,7);
			SendBuff[7] = ACK;
			SendBuff[8] = 0;
			*SendCommCnt = 9;
		}
		break;
	case PC_PARTS:
		if((CommBuff[5] == 0x01) &&	/* Start */
			(DownloadFileInfo == 0)){		/* 0:NewFile,1:Openning 060121 */
			DownloadFileInfo= 1;			/* 0:NewFile,1:Openning		*/
			/* 050407 */
			if(PcFilefp != -1){
				mclose(PcFilefp);
			}
			PcFilefp= mopen("parts.gp",_O_WRONLY);
			if(PcFilefp != GP_ERROR){
				FileRetVal= mwrite(PcFilefp,&CommBuff[0],RecCommCnt- 1);
			}
		}else{
			FileRetVal= mwrite(PcFilefp,&CommBuff[6],RecCommCnt- 7);
		}
		if(CommBuff[4] == 0x02){	/* End */
			mfileDelete(FileRetVal,PcFilefp);
			mclose(PcFilefp);
			DownloadFileInfo= 0;			/* 0:NewFile,1:Openning		*/
		}
		if((CommBuff[4] == 0x02) && (FileRetVal < 0)){	/* File Error */
			SetErrorRec(NAK,SendBuff,SendCommCnt,ERR_FILE);
		}else{
			memcpy(&SendBuff[1],CommBuff,7);
			SendBuff[7] = ACK;
			SendBuff[8] = 0;
			*SendCommCnt = 9;
		}
		break;
	case PC_DOWNLDED:		/* DownLoad End*/
		memcpy(&SendBuff[1],CommBuff,7);
		SendBuff[7] = ACK;
		SendBuff[8] = 0;
		*SendCommCnt = 9;
/*		pcNewRec = 1;*/		/* Rec Compleat */
/*		ProtocalDownLoad = 1;*/
		CommonArea.PcUpDownMode= 0;		/* Idle */
		PcDownloadStart= 0;				/* 070207 */
		break;
	case PC_PROJEXT:		/* Extern Project */
		CommonArea.PcUpDownMode= 4;	/* UP LOAD Project Extern Head */
		*SendCommCnt= 0;
		break;
	case PC_PROJDEL:		/* Delete Project */
		if(CommBuff[6] == 0x01){	/* ALL Deleate */
			mformat();				/* �t?�C���V�X�e?�̏����� */
			init_filesystem();
			ClearHistry();
/*			memset(&CommonArea,0,sizeof(CommonArea));*/				/* 050616 */
/* ksc20050805 ���� ����Ÿ ���� ���� ������ ���� ����Ÿ ���� ���ο� dVersion �缳�� */
/*-------------------------------------------------------------------------------------*/
/*			strncpy(CommonArea.System,dVersion,6);*/
/*-------------------------------------------------------------------------------------*/
		}else{
			mp= DeleteFileOpen(  );
			i= 7;
			cnt= CommBuff[i++]* 256;
			cnt+= CommBuff[i++];
			for(j = 0; j < cnt; j++){
				CommKind= CommBuff[i++]* 256;
				CommKind+= CommBuff[i++];
				sprintf(FileName,"BAS%05dGP ",CommKind);
				DeleteFile( FileName, mp );
			}
			cnt= CommBuff[i++]* 256;
			cnt+= CommBuff[i++];
			for(j = 0; j < cnt; j++){
				CommKind= CommBuff[i++]* 256;
				CommKind+= CommBuff[i++];
				sprintf(FileName,"WIN%05dGP ",CommKind);
				DeleteFile( FileName, mp );
			}
			DeleteFileClose( mp );
		}
		
		vScreenDataSet();

		memcpy(&SendBuff[1],CommBuff,7);
		SendBuff[7] = ACK;
		SendBuff[8] = 0;			/* Error Code */
		cnt = GP_USER_DATA_SIZE- (CheckUserArea()* 512);
		SendBuff[9]= cnt/0x1000000;		/* User Size */
		cnt= cnt%0x1000000;
		SendBuff[10]= cnt/0x10000;		/* User Size */
		cnt= cnt%0x10000;
		SendBuff[11]= cnt/0x100;		/* User Size */
		SendBuff[12]= cnt%0x100;		/* User Size */
		*SendCommCnt = 13;
		ret= 1;					/* Deleate */
		break;
	case PC_PROJID:
		SetInitDownLoad();			//2011.12.06Download Cancel
		CommonArea.PcUpDownMode= 5;		/* UP LOAD Project ID */
		*SendCommCnt= 0;
		FontFirstFlag= 0;
		Hexidx= 0;
		Hexidx= 0;
		break;
	case PC_PASSWD:
		SetInitDownLoad();			//2011.12.06Download Cancel
		CommonArea.PcUpDownMode= 6;		/* UP LOAD PassWord */
		*SendCommCnt= 0;
		break;
	case PC_TABLEDW:			/* Device Table & Proc Load */
		ProtocolDownloadFlag = 1;		/* �������� �ٿ�ε� �÷��� 20090610 */ 
		if(PcDownloadStart == 0){				/* 20090117 */
			ret= NG;			//20090117
			*SendCommCnt= 0;	//20090117
			break;
		}
		if((CommBuff[5] == 0x01) &&	/* Start */
			(DownloadFileInfo == 0)){		/* 0:NewFile,1:Openning 060121 */
			DownloadFileInfo= 1;			/* 0:NewFile,1:Openning		*/
#ifdef	WIN32
			CommonSendBuf= &RecpRBuff[0];
#else
			/* 050407 */
			if((int)CommonSendBuf != -1){
			}else{
				CommonSendBuf= (unsigned char *)TakeMemory(0x10000);
			}
#endif
			memset(CommonSendBuf,0xff,0x10000);
			HistIdx= 0;
			memcpy(&CommonSendBuf[HistIdx],&CommBuff[6],RecCommCnt- 7);
			HistIdx= RecCommCnt- 7;
		}else{
			if((int)CommonSendBuf != -1){
				memcpy(&CommonSendBuf[HistIdx],&CommBuff[6],RecCommCnt- 7);
				HistIdx+= RecCommCnt- 7;
			}
		}
		if(CommBuff[4] == 0x02){	/* End */
			if((int)CommonSendBuf != -1){
				MakePlcTable();			/* �e?�u���쐬���������� */
#ifdef	WIN32
				CommonSendBuf= (unsigned char *)-1;
#else
				FreeMail((char *)CommonSendBuf);
				CommonSendBuf= (unsigned char *)-1;
#endif
			}
			DownloadFileInfo= 0;			/* 0:NewFile,1:Openning		*/
		}
		memcpy(&SendBuff[1],CommBuff,7);
		SendBuff[7] = ACK;
		SendBuff[8] = 0;
		*SendCommCnt = 9;
		break;
	case PC_FONT:			/*  */
		if((CommBuff[5] == 0x01) &&	/* Start */
			(DownloadFileInfo == 0)){		/* 0:NewFile,1:Openning 060121 */
			DownloadFileInfo= 1;			/* 0:NewFile,1:Openning		*/
			if(FontFirstFlag == 0){
#ifdef	WIN32
				CommonSendBuf= &RecpRBuff[0];
#else
				/* 050407 */
				if((int)CommonSendBuf != -1){
				}else{
					CommonSendBuf= (unsigned char *)TakeMemory(0x10000);
				}
#endif
				FontFirstFlag= 1;
				sLanguageCode= CommBuff[6];
				sFontCode= CommBuff[7];
				memset(sFontName,0,sizeof(sFontName));
				memcpy(sFontName,&CommBuff[8],10);
				seFontCode= CommBuff[18];
				memset(seFontName,0,sizeof(seFontName));
				memcpy(seFontName,&CommBuff[19],10);
				if(CommBuff[29] != 0){				/* Sysytem Message */
					FontCnt= 34;		/* Font Pos */
				}else{
					FontCnt= 30;		/* Font Pos */
				}
				f_base_adr= (char *)0xffffffff;
				Hexidx= 0;
			}else{
				FontCnt= 6;		/* Font Pos */
			}
			if(FontCnt < RecCommCnt- 2){
				while(1){
					i= GetHexRec();
					if(i == OK){
						FontLoad((char *)CommonSendBuf, &f_base_adr);
					}else{
						break;
					}
				}
			}
		}else{
			FontCnt= 6;		/* Font Pos */
			if(FontCnt < RecCommCnt- 2){
				while(1){
					i= GetHexRec();
					if(i == OK){
						FontLoad((char *)CommonSendBuf, &f_base_adr);
					}else{
						break;
					}
				}
			}
		}
		if(CommBuff[4] == 0x02){	/* End */

#ifdef	WIN32
#else
			FreeMail((char *)CommonSendBuf);
			CommonSendBuf= (unsigned char *)-1;
#endif
			Set.LanguageCode= sLanguageCode;
			Set.FontCode= sFontCode;
			Set.eFontCode= seFontCode;
			memcpy(Set.FontName,sFontName,10);
			memcpy(Set.eFontName,seFontName,10);
			mWriteSettei();			/* Langage Write */
			DownloadFileInfo= 0;			/* 0:NewFile,1:Openning		*/
			FontFirstFlag= 0;				/* 2009.07.01 add */
		}
		memcpy(&SendBuff[1],CommBuff,7);
		SendBuff[7] = ACK;
		SendBuff[8] = 0;
		*SendCommCnt = 9;
		break;
	case PC_PRG1:					/* Program Download Version Check */
		memcpy(&SendBuff[1],CommBuff,7);
		SendBuff[7] = ACK;
		SendBuff[8] = 0;
		strcpy ((char *)&SendBuff[9],GP_SYSVER);
		SendBuff[13] = 0;
		SendBuff[14] = 0;
		SendBuff[15] = VER_CHECK_CODE/0x100;
		SendBuff[16] = VER_CHECK_CODE%0x100;				/* Version Check */
		SendBuff[17] = GP_TYPE_CODE/0x100;
		SendBuff[18] = GP_TYPE_CODE%0x100;		/* GP TYPE */
		strcpy ((char *)&SendBuff[19],GP_RELEASE_DATE);
		*SendCommCnt = 27;
		break;
	case PC_PRG2:					/* �߿��� Program Download Start */
#ifndef	WIN32
		_di();
#ifdef	LP_S044		/* 20080822 �߿��� �ٿ�δ��� ��Ʈ �ʱ�ȭ  */
//		memset(&PlcDataSram.GlpIoInfo,0,sizeof(PlcDataSram.GlpIoInfo));
		SetClearFunc(0);
		PlcDeviceClear();		//Device Clear
		//Out Port
		PortOutProc();
#endif
#ifdef	OLD		/*070917 Boardrate Fix*/
		if(BoardRateFlag > 1){
			*(int *)APL_BOADRATE= BoardRateFlag- 1;
		}else{
			if(BoardRateFlag == 1){
				*(int *)APL_BOADRATE= 5;		/* 115200 */
			}else{
				*(int *)APL_BOADRATE= BoardRateFlag;
			}
		}
#else
		*(int *)APL_BOADRATE= GetEditBoadrate();

		if(((lcd_contrast - 5) <= Set.iLcdvalue) && (Set.iLcdvalue <= (lcd_contrast + 5))){ 
			*(int *)APL_CONTRAST= Set.iLcdvalue;
		}else{
			*(int *)APL_CONTRAST= lcd_contrast;
		}
//		*(int *)APL_CONTRAST_LCDCLK= lcd_clk;
#endif
//		WDT_Off();
#endif
		memcpy((char *)APLDW_START,(char *)APL_LOAD_ADDR,APLDW_SIZE);
		AplLoadfunc = (void (*)())APLDW_START;
		AplLoadfunc();
		break;
#ifdef	LP_S044
//PLC Control Command	2008.08.28
	case PC_PLC_CTL:
		if(SendBuff[7] == 0){	SetRunStopSwitch(OFF);	}
		else{					SetRunStopSwitch(ON);	}
		memcpy(&SendBuff[1],CommBuff,7);
		SendBuff[7] = ACK;
		SendBuff[8] = 0;
		*SendCommCnt = 9;
		break;
#endif

	default:				//20090113
		ret= NG;			//20090113
		*SendCommCnt= 0;	//20090113
		break;				//20090113

	}

	if(*SendCommCnt != 0){		/* Send Data */
		SetPCEditorBcc(SendBuff,SendCommCnt);
	}
	return(ret);
}
/********************************************/
/*	PC UPLoad								*/
/********************************************/
void	NextSendProjectData(unsigned char *SendBuff,int *SendCommCnt)
{
	int	i;
	int	idx;

	SendBuff[0]= 0xff;	/* Head */
	SendBuff[1]= 0x00;	/* Leng1 */
	SendBuff[2]= 0x00;	/* Leng2 */
	SendBuff[3]= 0x01;	/* Code1 */
	SendBuff[4]= 0x07;	/* Code2 */
	SendBuff[5]= 0x02;	/* BLK1 */		/* 2:End,1:Continue */
	SendBuff[6]= UpdateProjectBlkNo++;	/* BLK2 */
	idx= 7;
	for(i= 0; i < 29; i++){
		if(UpdateProjectBaseCnt < 1){	break;	}	/* End */
		memcpy(&SendBuff[idx],&UpdateProjectInf[UpdateProjectSendCnt*35],35);
		UpdateProjectSendCnt++;
		UpdateProjectBaseCnt--;
		idx += 35;
	}
	if(i < 29){
		for(; i < 29; i++){
			if(UpdateProjectWindowCnt < 1){	break;	}	/* End */
			memcpy(&SendBuff[idx],&UpdateProjectInf[UpdateProjectSendCnt*35],35);
			UpdateProjectSendCnt++;
			UpdateProjectWindowCnt--;
			idx += 35;
		}
	}
	*SendCommCnt= idx;
	if((UpdateProjectBaseCnt == 0) && (UpdateProjectWindowCnt == 0)){
		FreeMail((char*)UpdateProjectInf);
		UpdateProjectInf= NULL;
	}else{
		SendBuff[5]= 0x01;	/* BLK1 */		/* 2:End,1:Continue */
	}
	SetPCEditorBcc(SendBuff,SendCommCnt);
}
void	NextSendProjectDataExt(unsigned char *SendBuff,int *SendCommCnt)
{
	int	i;
	int	idx;

	SendBuff[0]= 0xff;	/* Head */
	SendBuff[1]= 0x00;	/* Leng1 */
	SendBuff[2]= 0x00;	/* Leng2 */
	SendBuff[3]= 0x01;	/* Code1 */
	SendBuff[4]= 0x0b;	/* Code2 */
	SendBuff[5]= 0x02;	/* BLK1 */		/* 2:End,1:Continue */
	SendBuff[6]= UpdateProjectBlkNo++;	/* BLK2 */
	idx= 7;
	for(i= 0; i < 29; i++){
		if(UpdateProjectBaseCnt < 1){	break;	}	/* End */
		memcpy(&SendBuff[idx],&UpdateProjectInf[UpdateProjectSendCnt*35],35);
		UpdateProjectSendCnt++;
		UpdateProjectBaseCnt--;
		idx += 35;
	}
	if(i < 29){
		for(; i < 29; i++){
			if(UpdateProjectWindowCnt < 1){	break;	}	/* End */
			memcpy(&SendBuff[idx],&UpdateProjectInf[UpdateProjectSendCnt*35],35);
			UpdateProjectSendCnt++;
			UpdateProjectWindowCnt--;
			idx += 35;
		}
	}
	*SendCommCnt= idx;
	if((UpdateProjectBaseCnt == 0) && (UpdateProjectWindowCnt == 0)){
		FreeMail((char*)UpdateProjectInf);
		UpdateProjectInf= NULL;
		/* Password Add */
		SendBuff[(*SendCommCnt)++]= (unsigned char)CommonArea.PasswordOnOff;
		memcpy(&SendBuff[*SendCommCnt],CommonArea.ProjPassword,16);
		(*SendCommCnt) += 16;
	}else{
		SendBuff[5]= 0x01;	/* BLK1 */		/* 2:End,1:Continue */
	}
	SetPCEditorBcc(SendBuff,SendCommCnt);
}
void	MakeUploadProjectData(void)
{
	int		ret;
	int		idx;
	int		i;
	unsigned char	*pos;
	int		size;
	char	wbuff[6];

	if(UpdateProjectInf == NULL){
		UpdateProjectInf= (char*)TakeMemory(0x10000);
	}
	UpdateProjectBaseCnt= 0;
	UpdateProjectWindowCnt= 0;
	idx= 0;
	ret= m_findfirst("bas*.*", ATTR_RDO, &UpFinddata);
	if(ret == OK){
		while(1){
			for(i = 0; i < 5; i++){
				wbuff[i]= UpFinddata.name[i+3];
			}
			wbuff[i]= 0;
			i= gatoi(wbuff);
			UpdateProjectInf[idx]= i / 256;
			UpdateProjectInf[idx+ 1]= i % 256;
			UpdateProjectInf[idx+ 2]= 32;
			ret= mfileserch(UpFinddata.name,(int *)&pos,&size);
			if(ret == OK){
				pos+= 8;
				pos= pos+ (*pos* 256 + *(pos+ 1))+ 5;
				memcpy(&UpdateProjectInf[idx+ 3],pos,32);
			}else{
				memset(&UpdateProjectInf[idx+ 3],0,32);
			}
			idx+= 35;
			UpdateProjectBaseCnt++;
			ret= m_findnext(&UpFinddata);
			if(ret != OK){
				break;
			}
		}
	}
	ret= m_findfirst("win*.*", ATTR_RDO, &UpFinddata);
	if(ret == OK){
		while(1){
			for(i = 0; i < 5; i++){
				wbuff[i]= UpFinddata.name[i+3];
			}
			wbuff[i]= 0;
			i= gatoi(wbuff);
			UpdateProjectInf[idx]= i / 256;
			UpdateProjectInf[idx+ 1]= i % 256;
			UpdateProjectInf[idx+ 2]= 32;
			ret= mfileserch(UpFinddata.name,(int *)&pos,&size);
			if(ret == OK){
				pos+= 8;
				pos= pos+ (*pos* 256 + *(pos+ 1))+ 5;
			}
			memcpy(&UpdateProjectInf[idx+ 3],pos,32);
			idx+= 35;
			UpdateProjectWindowCnt++;
			ret= m_findnext(&UpFinddata);
			if(ret != OK){
				break;
			}
		}
	}
}
int	MakeProjectHed(unsigned char *SendBuff,int *SendCommCnt)
{
	int		i;
	int		idx;

	MakeUploadProjectData();	// Make Data
	UpdateProjectBlkNo= 1;
	SendBuff[0]= 0xff;	/* Head */
	SendBuff[1]= 0x00;	/* Leng1 */
	SendBuff[2]= 0x00;	/* Leng2 */
	SendBuff[3]= 0x01;	/* Code1 */
	SendBuff[4]= 0x07;	/* Code2 */
	SendBuff[5]= 0x02;	/* BLK1 */		/* 2:End,1:Continue */
	SendBuff[6]= UpdateProjectBlkNo++;	/* BLK2 */
	/* BASE File Check */
	SendBuff[7]= UpdateProjectBaseCnt/256;	/* Base Cnt */
	SendBuff[8]= UpdateProjectBaseCnt%256;	/* Base Cnt */
	idx= 9;
	UpdateProjectSendCnt= 0;
	for(i= 0; i < 29; i++){
		if(UpdateProjectBaseCnt < 1){	break;	}	/* End */
		memcpy(&SendBuff[idx],&UpdateProjectInf[UpdateProjectSendCnt*35],35);
		UpdateProjectSendCnt++;
		UpdateProjectBaseCnt--;
		idx += 35;
	}
	if(i < 29){
		SendBuff[idx++]= UpdateProjectWindowCnt/256;	/* Base Cnt */
		SendBuff[idx++]= UpdateProjectWindowCnt%256;	/* Base Cnt */
		for(; i < 29; i++){
			if(UpdateProjectWindowCnt < 1){	break;	}	/* End */
			memcpy(&SendBuff[idx],&UpdateProjectInf[UpdateProjectSendCnt*35],35);
			UpdateProjectSendCnt++;
			UpdateProjectWindowCnt--;
			idx += 35;
		}
	}
	*SendCommCnt= idx;
	if((UpdateProjectBaseCnt == 0) && (UpdateProjectWindowCnt == 0)){
		FreeMail((char*)UpdateProjectInf);
		UpdateProjectInf= NULL;
	}else{
		SendBuff[5]= 0x01;	/* BLK1 */		/* 2:End,1:Continue */
	}
	SetPCEditorBcc(SendBuff,SendCommCnt);
	return(0);
}
int	MakeProjectHedExt(unsigned char *SendBuff,int *SendCommCnt)
{
	int		Cnt;
	int		i;
	int		ret;
	unsigned char	*pos;
	int		size;
	int		idx;

	MakeUploadProjectData();	// Make Data
	UpdateProjectBlkNo= 1;
	SendBuff[0]= 0xff;	/* Head */
	SendBuff[1]= 0x00;	/* Leng1 */
	SendBuff[2]= 0x00;	/* Leng2 */
	SendBuff[3]= 0x01;	/* Code1 */
	SendBuff[4]= 0x0b;	/* Code2 */
	SendBuff[5]= 0x02;	/* BLK1 */
	SendBuff[6]= UpdateProjectBlkNo++;	/* BLK2 */
	ret= mfileserch("project.gp", (int *)&pos, &size);
	if(ret != OK){		/* Project File Error */
		*SendCommCnt= 7;
		SendBuff[(*SendCommCnt)++]= 0xa4;	/* Project ID Code */
		for(i= 0; i < 4; i++){
			SendBuff[(*SendCommCnt)++]= 0;	/* Project ID */
		}
		SendBuff[(*SendCommCnt)++]= 0xa5;	/* Project Title Code */
		SendBuff[(*SendCommCnt)++]= 0;		/* Project Title Cnt */
	}else{
		/* Project Info */
		pos += 6;
		*SendCommCnt= 7;
		SendBuff[(*SendCommCnt)++]= *pos++;	/* Project ID Code */
		for(i= 0; i < 4; i++){
			SendBuff[(*SendCommCnt)++]= *pos++;	/* Project ID */
		}
		SendBuff[(*SendCommCnt)++]= *pos++;	/* Project Title Code */
		Cnt= *pos++;						/* Project Title Cnt */
		SendBuff[(*SendCommCnt)++]= Cnt;		/* Project Title Cnt */
		for(i= 0; i < Cnt; i++){
			SendBuff[(*SendCommCnt)++]= *pos++;	/* Project Title */
		}
	}
	SendBuff[(*SendCommCnt)++]= 0xab;	/* OS ID */
	SendBuff[(*SendCommCnt)++]= strlen(GP_SYSVER);	/* OS Cnt */
	Cnt= strlen(GP_SYSVER);
	for(i= 0; i < Cnt; i++){
		SendBuff[(*SendCommCnt)++]= GP_SYSVER[i];	/* Project Title */
	}
	Cnt= GetUserFileArea();
	SendBuff[(*SendCommCnt)++]= Cnt/0x1000000;		/* User Size */
	Cnt= Cnt%0x1000000;
	SendBuff[(*SendCommCnt)++]= Cnt/0x10000;		/* User Size */
	Cnt= Cnt%0x10000;
	SendBuff[(*SendCommCnt)++]= Cnt/0x100;		/* User Size */
	SendBuff[(*SendCommCnt)++]= Cnt%0x100;		/* User Size */
	Cnt = GP_USER_DATA_SIZE- (CheckUserArea()* 512);
	SendBuff[(*SendCommCnt)++]= Cnt/0x1000000;		/* User Size */
	Cnt= Cnt%0x1000000;
	SendBuff[(*SendCommCnt)++]= Cnt/0x10000;		/* User Size */
	Cnt= Cnt%0x10000;
	SendBuff[(*SendCommCnt)++]= Cnt/0x100;		/* User Size */
	SendBuff[(*SendCommCnt)++]= Cnt%0x100;		/* User Size */
	/* BASE File Check */
//	(*SendCommCnt)+= 2;
	idx= *SendCommCnt;
	SendBuff[idx++]= UpdateProjectBaseCnt/256;	/* Base Cnt */
	SendBuff[idx++]= UpdateProjectBaseCnt%256;	/* Base Cnt */
	UpdateProjectSendCnt= 0;
	for(i= 0; i < 29; i++){
		if(UpdateProjectBaseCnt < 1){	break;	}	/* End */
		memcpy(&SendBuff[idx],&UpdateProjectInf[UpdateProjectSendCnt*35],35);
		UpdateProjectSendCnt++;
		UpdateProjectBaseCnt--;
		idx += 35;
	}
	if(i < 29){
		SendBuff[idx++]= UpdateProjectWindowCnt/256;	/* Base Cnt */
		SendBuff[idx++]= UpdateProjectWindowCnt%256;	/* Base Cnt */
		for(; i < 29; i++){
			if(UpdateProjectWindowCnt < 1){	break;	}	/* End */
			memcpy(&SendBuff[idx],&UpdateProjectInf[UpdateProjectSendCnt*35],35);
			UpdateProjectSendCnt++;
			UpdateProjectWindowCnt--;
			idx += 35;
		}
	}
	*SendCommCnt= idx;

	if((UpdateProjectBaseCnt == 0) && (UpdateProjectWindowCnt == 0)){
		FreeMail((char*)UpdateProjectInf);
		UpdateProjectInf= NULL;
		/* Password Add */
		SendBuff[(*SendCommCnt)++]= (unsigned char)CommonArea.PasswordOnOff;
		memcpy(&SendBuff[*SendCommCnt],CommonArea.ProjPassword,16);
		(*SendCommCnt) += 16;
	}else{
		SendBuff[5]= 0x01;	/* BLK1 */		/* 2:End,1:Continue */
	}
	SetPCEditorBcc(SendBuff,SendCommCnt);
	return(0);
}
void	MakeProjectID( unsigned char *SendBuff,int *SendCommCnt )
{
	int		Cnt;

	SendBuff[0]= 0xff;	/* Head */
	SendBuff[1]= 0x00;	/* Leng1 */
	SendBuff[2]= 0x00;	/* Leng2 */
	SendBuff[3]= 0x02;	/* Code1 */
	SendBuff[4]= 0x01;	/* Code2 */
	SendBuff[5]= 0x02;	/* BLK1 */
	SendBuff[6]= 0x01;	/* BLK2 */
	memcpy(&SendBuff[7],CommonArea.ProjID,4);
	/* Memory Size */
	SendBuff[11]= 0;
	SendBuff[12]= 0;
	Cnt= CheckNoUseArea();
	SendBuff[13]= Cnt/256;			/* Sector Count */
	SendBuff[14]= Cnt%256;			/* Sector Count */
	memcpy(&SendBuff[15],Set.cPlcTypeCode,6);
	SendBuff[15]= GP_TYPE_CODE/0x100;
	SendBuff[16]= GP_TYPE_CODE%0x100;
	if(CommonArea.PlcType2.AuxPlcUserFlag == 0){	/* NOT USE */
		memset(&SendBuff[35],0,4);
	}else{
		memcpy(&SendBuff[35],Set.cPlcTypeCode2,4);
	}
	*SendCommCnt= 55;
	SendBuff[(*SendCommCnt)++]= Set.LanguageCode;
	SendBuff[(*SendCommCnt)++]= Set.FontCode;
	SendBuff[(*SendCommCnt)++]= Set.eFontCode;
	SetPCEditorBcc(SendBuff,SendCommCnt);
}
void	MakePassWord( unsigned char *SendBuff,int *SendCommCnt )
{
	int	ret;
	int	pos,size;

	SendBuff[0]= 0xff;	/* Head */
	SendBuff[1]= 0x00;	/* Leng1 */
	SendBuff[2]= 0x00;	/* Leng2 */
	SendBuff[3]= 0x02;	/* Code1 */
	SendBuff[4]= 0x02;	/* Code2 */
	SendBuff[5]= 0x02;	/* BLK1 */
	SendBuff[6]= 0x01;	/* BLK2 */
	SendBuff[7]= (unsigned char)CommonArea.PasswordOnOff;	/* BLK2 */
	memcpy(&SendBuff[8],CommonArea.ProjPassword,16);
	//?�E���ɂĒǉ�060730
	ret= mfileserch("project.gp", (int *)&pos, &size);
	if(ret == OK){		/* Project File Error */
		SendBuff[24]= 0xff;
		memcpy(&SendBuff[25],Set.cPlcTypeCode,6);
		SendBuff[25]= GP_TYPE_CODE/0x100;			/* 2008.12.10 */
		SendBuff[26]= GP_TYPE_CODE%0x100;			/* 2008.12.10 */
	}else{
		SendBuff[24]= 0;
		memset(&SendBuff[25],0,6);
	}
	*SendCommCnt= 31;
	SetPCEditorBcc(SendBuff,SendCommCnt);
}
int	SendFileRead(char *FileName,int code,unsigned char *SendBuff,int *SendCommCnt)
{
	int		len;
	unsigned char	*pos;
	int		size;
	int		ret;

	ret= mfileserch(FileName,(int *)&pos,&size);
	if(ret == OK){
		UpFileSize= size;
		PcFilefp= mopen(FileName,_O_RDONLY);
		len= mread(PcFilefp,&SendBuff[1],1024);
		UpFileSize-= len;
		if(UpFileSize <= 0){
			mclose(PcFilefp);
			PcFilefp= -1;
			UpLoadMode++;
			SendBuff[5]= 0x02;	/* BLK1 */
		}else{
			SendBuff[5]= 0x01;	/* BLK1 */
		}
		SendBuff[3]= code / 256;	/* Code1 */
		SendBuff[4]= code % 256;	/* Code2 */
		SendBuff[6]= BlockNo++;	/* BLK2 */
		(*SendCommCnt)= len+ 1;
		ret= 1;
	}else{
		UpLoadMode++;
		ret= 0;
	}
	return(ret);
}
int	BaseWindowFile(unsigned char *SendBuff,int *SendCommCnt)
{
	int		len;
	int		i;
	int		ret;
	char	wbuff[6];

	while(1){
		if(SerchFirstFlag == 0){
			switch(UpLoadMode){
			case PC_SEND_BASE:
				ret= m_findfirst("bas*.*", ATTR_RDO, &UpFinddata);
				break;
			case PC_SEND_WINDOW:	/* Window */
				ret= m_findfirst("Win*.*", ATTR_RDO, &UpFinddata);
				break;
			}
			if(ret == OK){
				SerchFirstFlag= 1;
			}
		}else{
			ret= m_findnext(&UpFinddata);
		}
		if(ret == OK){
			for(i = 0; i < 5; i++){
				wbuff[i]= UpFinddata.name[i+3];
			}
			wbuff[i]= 0;
			len= gatoi(wbuff);
			if(UpLoadMode == PC_SEND_BASE){
				if(UpBaseNo[len] != 0){
					break;
				}
			}else{
				if(UpWinNo[len] != 0){
					break;
				}
			}
		}else{
			break;
		}
	}
	if(ret == OK){
		PcFilefp= mopen(UpFinddata.name,_O_RDONLY);
		if(PcFilefp != GP_ERROR){
			UpFileSize= UpFinddata.size;
			len= mread(PcFilefp,&SendBuff[1],1024);
			UpFileSize-= len;
			if(UpFileSize <= 0){
				mclose(PcFilefp);
				PcFilefp= -1;
				SendBuff[5]= 0x02;	/* BLK1 */
			}else{
				SendBuff[5]= 0x01;	/* BLK1 */
			}
			if(UpLoadMode == PC_SEND_BASE){
				SendBuff[3]= 0x01;	/* Code1 */
				SendBuff[4]= 0x04;	/* Code2 */
			}else{
				SendBuff[3]= 0x01;	/* Code1 */
				SendBuff[4]= 0x05;	/* Code2 */
			}
			SendBuff[6]= BlockNo++;	/* BLK2 */
			(*SendCommCnt)= len+ 1;
			ret= 1;
		}else{
			ret= 0;
		}
	}else{
		SerchFirstFlag= 0;
		UpLoadMode++;
		ret= 0;
	}
	return(ret);
}
/********************************************/
/*	Alarm History File						*/
/********************************************/
int	MakeHistryData(int idx, char *buff)
{
	short	isyear,ismon,isday,ishour,ismin,issec;
	short	ieyear,iemon,ieday,iehour,iemin,iesec;
	char	cDisplayData[21];
	int		iColor;
	int		iLen;
	int		iPoint;
	char*	LineData;
#ifdef	WIN32
	char	cTempBuffer[40+1];
#else
	char	*cTempBuffer;
	cTempBuffer = (char *)TakeMemory(40+1);
#endif
	iLen = 40;
	memset(cTempBuffer,0,40+1);
	vCommentDataSet(CommonArea.AlarmHistRec[idx].DevNo+1,cTempBuffer,&iColor,&iLen);
	memset(cDisplayData,0,21);
	if(iLen>20){
		iLen = 20;
	}else{
		memset(cDisplayData,' ',20);
	}

/**************************************************/
	LineData = 0x00;
	LineData = strchr(cTempBuffer,0x0D);
	if(((int)LineData) != 0)
	{
		iPoint = ((int)LineData)-((int)cTempBuffer);
	}else
		iPoint = 0;
	if(iPoint>0 && iPoint<21)
	{
		memset(cTempBuffer+iPoint,0x00,iLen-iPoint);
		iLen = iPoint;
	}
/**************************************************/

	memcpy(cDisplayData,cTempBuffer,iLen);
	isyear = (CommonArea.AlarmHistRec[idx].sDateTime >> 26) + 2000;
	ismon  = (short)((CommonArea.AlarmHistRec[idx].sDateTime & 0x03c00000) >> 22);
	isday  = (short)((CommonArea.AlarmHistRec[idx].sDateTime & 0x003e0000) >> 17);
	ishour = (short)((CommonArea.AlarmHistRec[idx].sDateTime & 0x0001f000) >> 12);
	ismin  = (short)((CommonArea.AlarmHistRec[idx].sDateTime & 0x00000fc0) >>  6);
	issec  = (short)(CommonArea.AlarmHistRec[idx].sDateTime & 0x0000003f);

  if(CommonArea.AlarmHistRec[idx].flag==0x01){
		ieyear = (CommonArea.AlarmHistRec[idx].eDateTime >> 26) +2000;
		iemon  = (short)((CommonArea.AlarmHistRec[idx].eDateTime & 0x03c00000) >> 22);
		ieday  = (short)((CommonArea.AlarmHistRec[idx].eDateTime & 0x003e0000) >> 17);
		iehour = (short)((CommonArea.AlarmHistRec[idx].eDateTime & 0x0001f000) >> 12);
		iemin  = (short)((CommonArea.AlarmHistRec[idx].eDateTime & 0x00000fc0) >>  6);
		iesec  = (short)(CommonArea.AlarmHistRec[idx].eDateTime & 0x0000003f);
		sprintf(buff,"%d\t,%s \t,%4d-%02d-%02d \t,%02d:%02d:%02d \t, %4d-%02d-%02d \t,%02d:%02d:%02d \t,%d",
				CommonArea.AlarmHistRec[idx].DevNo,
				cDisplayData,
				isyear,ismon,isday,ishour,ismin,issec,
				ieyear,iemon,ieday,iehour,iemin,iesec,
				CommonArea.AlarmHistRec[idx].Cnt);
	}else{
		sprintf(buff,"%d\t,%s \t,%4d-%02d-%02d \t,%02d:%02d:%02d \t,            \t,         \t,%d",
				CommonArea.AlarmHistRec[idx].DevNo,
				cDisplayData,
				isyear,ismon,isday,ishour,ismin,issec,
				CommonArea.AlarmHistRec[idx].Cnt);
	}
#ifndef	WIN32
	FreeMail(cTempBuffer);
#endif
	return(strlen(buff));
}
int	MakeFreqData(int idx, char *buff)
{
	char	cDisplayData[21];
	int		iColor;
	int		iLen;
	int		iPoint;
	char*	LineData;
#ifdef	WIN32
	char	cTempBuffer[40+1];
#else
	char	*cTempBuffer;
	cTempBuffer = (char *)TakeMemory(40+1);
#endif

	iLen = 40;
	memset(cTempBuffer,0,40+1);
	vCommentDataSet(idx+1,cTempBuffer,&iColor,&iLen);
	iLen = strlen(cTempBuffer);
	memset(cDisplayData,0,21);
	if(iLen>20){
		iLen = 20;
	}else{
		memset(cDisplayData,' ',20);
	}

/**************************************************/
	LineData = 0x00;
	LineData = strchr(cTempBuffer,0x0D);
	if(((int)LineData) != 0)
	{
		iPoint = ((int)LineData)-((int)cTempBuffer);
	}else
		iPoint = 0;
	if(iPoint>0 && iPoint<21)
	{
		memset(cTempBuffer+iPoint,0x00,iLen-iPoint);
		iLen = iPoint;
	}
/**************************************************/

	memcpy(cDisplayData,cTempBuffer,iLen);
#ifndef	WIN32
	FreeMail(cTempBuffer);
#endif
	sprintf(buff,"%d\t,%s \t,%d",
			idx,
			cDisplayData,
			CommonArea.TotalCnt[idx]);
	return(strlen(buff));
}
int	MakeHistory( unsigned char *SendBuff,int *SendCommCnt )
{
	int	Continue;
	int	len;
	int	i;
#ifdef	WIN32
	char	HistWork[1024];
#else
	char	*HistWork;
#endif

	Continue= 0;
	SendBuff[0]= 0xff;	/* Head */
	SendBuff[1]= 0x00;	/* Leng1 */
	SendBuff[2]= 0x00;	/* Leng2 */
	SendBuff[3]= 0x01;	/* Code1 */
	SendBuff[4]= 0x0d;	/* Code2 */
	SendBuff[5]= 0x02;	/* BLK1 */
	SendBuff[6]= BlockNo++;	/* BLK2 */
	SendBuff[7]= CommonArea.EntryCnt/256;	/* Cnt-H */
	SendBuff[8]= CommonArea.EntryCnt%256;	/* Cnt-L */
	*SendCommCnt= 9;
	if(CommonArea.EntryCnt > 0){
#ifndef	WIN32
		HistWork= (char *)TakeMemory(1024);
#endif
		for(i = 0; i < CommonArea.EntryCnt; i++){
			/* Size(1) */
			len= MakeHistryData(i,HistWork);
			if((*SendCommCnt+ len) < 1023){
				SendBuff[(*SendCommCnt)++]= len;
				memcpy(&SendBuff[*SendCommCnt],HistWork,len);
				(*SendCommCnt)+= len;
			}else{
				HistIdx= i;
				PcHistryFlag= 1;
				Continue= 1;
				SendBuff[5]= 0x01;	/* BLK1 */
				break;
			}
		}
#ifndef	WIN32
		FreeMail((char *)HistWork);
#endif
	}
	return(Continue);
}
int	MakeHistoryContinue( unsigned char *SendBuff,int *SendCommCnt )
{
	int	i;
	int	len;
	int	Continue;
#ifdef	WIN32
	char	HistWork[1024];
#else
	char	*HistWork;
#endif

	Continue= 0;
	PcHistryFlag= 0;
	SendBuff[0]= 0xff;	/* Head */
	SendBuff[1]= 0x00;	/* Leng1 */
	SendBuff[2]= 0x00;	/* Leng2 */
	SendBuff[3]= 0x01;	/* Code1 */
	SendBuff[4]= 0x0d;	/* Code2 */
	SendBuff[5]= 0x02;	/* BLK1 */		/* 2:End,1:Continue */
	SendBuff[6]= BlockNo++;	/* BLK2 */
	*SendCommCnt= 7;
#ifndef	WIN32
	HistWork= (char *)TakeMemory(1024);
#endif
	for(i = HistIdx; i < CommonArea.EntryCnt; i++){
		/* Size(1) */
		len= MakeHistryData(i,HistWork);
		if((*SendCommCnt+ len) < 1023){
			SendBuff[(*SendCommCnt)++]= len;
			memcpy(&SendBuff[*SendCommCnt],HistWork,len);
			(*SendCommCnt)+= len;
		}else{
			HistIdx= i;
			PcHistryFlag= 1;
			Continue= 1;
			SendBuff[5]= 0x01;	/* BLK1 */
			break;
		}
	}
#ifndef	WIN32
	FreeMail((char *)HistWork);
#endif
	return(Continue);
}
int	MakeFreq( unsigned char *SendBuff,int *SendCommCnt )
{
	int	Continue;
	int	len;
	int	i;
#ifdef	WIN32
	char	HistWork[1024];
#else
	char	*HistWork;
#endif

	Continue= 0;
	SendBuff[0]= 0xff;	/* Head */
	SendBuff[1]= 0x00;	/* Leng1 */
	SendBuff[2]= 0x00;	/* Leng2 */
	SendBuff[3]= 0x01;	/* Code1 */
	SendBuff[4]= 0x0e;	/* Code2 */
	SendBuff[5]= 0x02;	/* BLK1 */
	SendBuff[6]= 0x01;	/* BLK2 */
	SendBuff[7]= CommonArea.SystemDev.Alarm_Dev.DevCnt/256;	/* Cnt-H */
	SendBuff[8]= CommonArea.SystemDev.Alarm_Dev.DevCnt%256;	/* Cnt-L */
	*SendCommCnt= 9;
	if(CommonArea.SystemDev.Alarm_Dev.DevCnt > 0){
#ifndef	WIN32
		HistWork= (char *)TakeMemory(1024);
#endif
		for(i = 0; i < CommonArea.SystemDev.Alarm_Dev.DevCnt; i++){
			/* Size(1) */
			len= MakeFreqData(i,HistWork);
			if(((*SendCommCnt)+ len) < 1023){
				SendBuff[(*SendCommCnt)++]= len;
				memcpy(&SendBuff[*SendCommCnt],HistWork,len);
				(*SendCommCnt)+= len;
			}else{
				HistIdx= i;
				PcHistryFlag= 2;
				Continue= 1;
				SendBuff[5]= 0x01;	/* BLK1 */
				break;
			}
		}
#ifndef	WIN32
		FreeMail((char *)HistWork);
#endif
	}
	return(Continue);
}
int	MakeFreqContinue( unsigned char *SendBuff,int *SendCommCnt )
{
	int	i;
	int	len;
	int	Continue;
#ifdef	WIN32
	char	HistWork[1024];
#else
	char	*HistWork;
#endif

	Continue= 0;
	PcHistryFlag= 0;
	SendBuff[0]= 0xff;	/* Head */
	SendBuff[1]= 0x00;	/* Leng1 */
	SendBuff[2]= 0x00;	/* Leng2 */
	SendBuff[3]= 0x01;	/* Code1 */
	SendBuff[4]= 0x0e;	/* Code2 */
	SendBuff[5]= 0x02;	/* BLK1 */
	SendBuff[6]= BlockNo++;	/* BLK2 */
	*SendCommCnt= 7;
#ifndef	WIN32
	HistWork= (char *)TakeMemory(1024);
#endif
	for(i = HistIdx; i < CommonArea.SystemDev.Alarm_Dev.DevCnt; i++){
		/* Size(1) */
		len= MakeFreqData(i,HistWork);
		if(((*SendCommCnt)+ len) < 1023){
			SendBuff[(*SendCommCnt)++]= len;
			memcpy(&SendBuff[*SendCommCnt],HistWork,len);
			(*SendCommCnt)+= len;
		}else{
			HistIdx= i;
			PcHistryFlag= 2;
			Continue= 1;
			SendBuff[5]= 0x01;	/* BLK1 */
			break;
		}
	}
#ifndef	WIN32
	FreeMail((char *)HistWork);
#endif
	return(Continue);
}
void	MakeSendData(unsigned char *SendBuff,int *SendCommCnt)
{
	int		len;
	int		FileOk;
	int		ret;


	if(PcHistryFlag != 0){	/* History Sendding */
		if(PcHistryFlag == 1){
			MakeHistoryContinue(SendBuff,SendCommCnt);
		}else{
			MakeFreqContinue(SendBuff,SendCommCnt);
		}
		if(PcHistryFlag == 0){
			UpLoadMode++;
		}
	}else{
		SendBuff[0]= 0xff;	/* Head */
		SendBuff[1]= 0x00;	/* Leng1 */
		SendBuff[2]= 0x00;	/* Leng2 */
		SendBuff[5]= 0x00;	/* BLK1 */
		SendBuff[6]= 0x00;	/* BLK2 */

		len= 0;
		if(PcFilefp != -1){			/* ���ɃI?�v�����Ă���t?�C����ǂݍ��� */
			len= mread(PcFilefp,&SendBuff[7],1024);
			(*SendCommCnt)= len+ 7;
			if(len > 0){
				UpFileSize-= len;
				if(UpFileSize <= 0){
					mclose(PcFilefp);
					PcFilefp= -1;
					if((UpLoadMode != PC_SEND_BASE) &&
						(UpLoadMode != PC_SEND_WINDOW)){
						UpLoadMode++;
					}
					SendBuff[5]= 0x02;	/* BLK1 */
				}else{
					SendBuff[5]= 0x01;	/* BLK1 */
				}
				SendBuff[6]= BlockNo++;	/* BLK1 */
			}else{
				mclose(PcFilefp);
				PcFilefp= -1;
				if((UpLoadMode != PC_SEND_BASE) &&
					(UpLoadMode != PC_SEND_WINDOW)){
					UpLoadMode++;
				}
			}
		}
		if(len <= 0){
			FileOk= 0;
			BlockNo= 1;
			SendBuff[6]= 0x00;	/* BLK2 */
			while(FileOk == 0){
				switch(UpLoadMode){
				case PC_SEND_COMMON:	/* Common */
					FileOk= SendFileRead("common.gp",PC_COMMON,SendBuff,SendCommCnt);
/*					FileOk= SendCommRead();*/
					break;
				case PC_SEND_PROJECT:	/* Project */
					FileOk= SendFileRead("project.gp",PC_PROJC,SendBuff,SendCommCnt);
					break;
				case PC_SEND_BASE:	/* Base */
				case PC_SEND_WINDOW:	/* Window */
					FileOk= BaseWindowFile(SendBuff,SendCommCnt);
					break;
				case PC_SEND_COMMENT:	/* Comment */
					if(UpComment != 0){
						FileOk= SendFileRead("Comment.gp",PC_COMENT,SendBuff,SendCommCnt);
					}else{
						UpLoadMode++;
					}
					break;
				case PC_SEND_PARTS:	/* Parts */
					if(UpParts != 0){
						FileOk= SendFileRead("Parts.gp",PC_PARTS,SendBuff,SendCommCnt);
					}else{
						UpLoadMode++;
					}
					break;
				case PC_SEND_HIST:	/* Alarm Hist */
					if(UpHist != 0){
						ret= MakeHistory(SendBuff,SendCommCnt);
						FileOk= 1;
						if(ret == 0){		/* One File */
							UpLoadMode++;
						}
					}else{
						UpLoadMode++;
					}
					break;
				case PC_SEND_FREQ:	/* Alarm Freq */
					if(UpFreq != 0){
						ret= MakeFreq(SendBuff,SendCommCnt);
						FileOk= 1;
						if(ret == 0){		/* One File */
							UpLoadMode++;
						}
					}else{
						UpLoadMode++;
					}
					break;
				case PC_SEND_END:
					SendBuff[3]= 0x01;	/* Code1 */
					SendBuff[4]= 0x0A;	/* Code2 */
					SendBuff[5]= 0x02;	/* BLK1 */
					SendBuff[6]= 0x01;	/* BLK1 */
					SendBuff[7]= ACK;	/* ACK */
					SendBuff[8]= 0;		/* Error */
					*SendCommCnt= 9;
					FileOk= 1;
					UpLoadMode++;
#ifndef	WIN32
					FreeMail(UpBaseNo);
					FreeMail(UpWinNo);
					UpBaseNo= (char *)-1;
					UpWinNo= (char *)-1;
#endif
					break;
				}
			}
		}
	}
	SetPCEditorBcc(SendBuff,SendCommCnt);
}
/****************************************/
/*	RS1 Initialize						*/
/****************************************/
void	initEditPort( void )
{
	if(Set.Ch1_iKind == EDITER){
		/* 070917 */
		SetEditorBoadrate( Set.Ch1_iConnect, 0 );
	}else{
		/* 070917 */
		SetEditorBoadrate( Set.Ch2_iConnect, 1 );
	}
	CommMode= 0;
	BoardRateFlag= 0;
	BoardRateChangingFlag= 0;
}
/****************************************************
*   FUNC  : Sio1 Send Program		                *
*	In    :											*
*	Out   : 										*
*   DATE  : 2002.10.01                              *
*****************************************************/
int	GetEditBoadrate( void )
{
	int		Speed;
	int		BoardRate;

	if(Set.Ch1_iKind == EDITER){
		Speed = Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed;
	}else{
		Speed = Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed;
	}
	switch(Speed){
	case RS_115200:
		BoardRate= 5;
		break;
	case RS_57600:
		BoardRate= 1;
		break;
	case RS_38400:
		BoardRate= 2;
		break;
	case RS_19200:
		BoardRate= 3;
		break;
	case RS_9600:
		BoardRate= 4;
		break;
	default:
		BoardRate= 0;		/* 9600 */
		break;
	}
	return(BoardRate);
}
void	SendPCData( unsigned char *SendBuff,int *SendCommCnt )
{
	T_MAIL	*mp;
	int		mbx;
	int OldResp;

//	SetSendSema();
	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RS_SEND;
	mp->mpar = *SendCommCnt;
	mp->mptr = SendBuff;
	mp->mext = 0;
	mp->mwrk= 3000;		/* 3s */
/*	if((Set.Ch1_iKind == EDITER) || (Set.Ch1_iKind == MONITOR)){*/	/* 20080822 �̺κ��� �ٽ� Ȯ���ؾߺ��ߵ� */
	if(Set.Ch1_iKind == EDITER){	/* 20080822 �̺κ��� �ٽ� Ȯ���ؾߺ��ߵ� */
		if(Set.Ch1_iConnect == CH_CH1){	/* PLC = RS-422 */
			SendMail(T_SIO1DRV,(char *)mp);
		}else{
			SendMail(T_SIO0DRV,(char *)mp);
		}
	}else{							/* PLC = RS-232C */
		if(Set.Ch2_iConnect == CH_CH1){	/* PLC = RS-422 */
			SendMail(T_SIO1DRV,(char *)mp);
		}else{
			SendMail(T_SIO0DRV,(char *)mp);
		}
	}
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	FreeMail((char *)mp);
	FreeMbx(mbx);
//	ResetSendSema();
}
/****************************************************
*   FUNC  : Sio1 Send Program		                *
*	In    :											*
*	Out   : 										*
*   DATE  : 2002.10.01                              *
*****************************************************/
void	SendPLCData( unsigned char *SendBuff,int *SendCommCnt )
{
	T_MAIL	*mp;
	int		mbx;
	int OldResp;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RS_SEND;
	mp->mpar = *SendCommCnt;
	mp->mptr = SendBuff;
	mp->mext = 0;
	mp->mwrk= 3000;		/* 3s */
	if(Set.Ch1_iConnect == CH_CH0){	/* PLC = RS-422 */
		SendMail(T_SIO0DRV,(char *)mp);
	}else{							/* PLC = RS-232C */
		SendMail(T_SIO1DRV,(char *)mp);
	}
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	FreeMail((char *)mp);
	FreeMbx(mbx);
}
/****************************************************
*   FUNC  : Clear Comm Flag			                *
*	In    :											*
*	Out   : 										*
*   DATE  : 2002.10.01                              *
*****************************************************/
void	ClearPcCom( void )
{
	SetInitDownLoad();			//2011.12.06Download Cancel
	CommMode = 0;
	CommCnt = 0;
	CommKind = 0;
	CommonArea.PcUpDownMode= 0;		/* DownLoad Mode */
	PcDownloadStart= 0;				/* 070207 */
}
/****************************************************
*   FUNC  : PC(Editor) Protocol		                *
*	In    :											*
*	Out   : 										*
*   DATE  : 2002.10.01                              *
*****************************************************/
extern	int		volatile	rs1Cnt;
void	PCEditorCommProc(int *CommMode,unsigned char *CommBuff,unsigned char *SendBuff,int *SendCommCnt)
{
	int		signal,ret;
//	unsigned char	bcc;
	int		SaveMode;
//char buff[10];

//	signal = 0xffffffff;
//	OffSignal(SGN_PLC,signal);		/* PLC Stop */
//	OffSignal(S_PROJECT,signal);
//	OffSignal(S_SCREEN,signal);
//	PlcSignalInf= OFF;			//PLC Proc Stop
	switch(*CommMode){
	case 0:				/* Parity Err */
		Delay(50);
		if((Set.Ch1_iConnect == CH_CH1 && Set.Ch1_iKind == EDITER) ||
			(Set.Ch2_iConnect == CH_CH1 && Set.Ch2_iKind == EDITER)){	/* PLC = RS-422C */
			switch(BoardRateFlag){
			case 0:
				InitSci1(RS_115200,RS_DATA8,RS_EVEN);
				BoardRateFlag= 1;
				break;
			case 1:
				InitSci1(RS_57600,RS_DATA8,RS_EVEN);
				BoardRateFlag= 2;
				break;
			case 2:
				InitSci1(RS_38400,RS_DATA8,RS_EVEN);
				BoardRateFlag= 3;
				break;
			case 3:
				InitSci1(RS_19200,RS_DATA8,RS_EVEN);
				BoardRateFlag= 4;
				break;
			case 4:
				InitSci1(RS_9600,RS_DATA8,RS_EVEN);
				BoardRateFlag= 5;
				break;
			case 5:
				InitSci1(RS_38400,RS_DATA8,RS_EVEN);	/*ksc20040715 RS_9600 �� RS_2400 �ƴ���? */
				BoardRateFlag= 0;
				break;
			}
		}else{
			switch(BoardRateFlag){
			case 0:
				InitSci0(RS_115200,RS_DATA8,RS_EVEN);
				BoardRateFlag= 1;
				break;
			case 1:
				InitSci0(RS_57600,RS_DATA8,RS_EVEN);
				BoardRateFlag= 2;
				break;
			case 2:
				InitSci0(RS_38400,RS_DATA8,RS_EVEN);
				BoardRateFlag= 3;
				break;
			case 3:
				InitSci0(RS_19200,RS_DATA8,RS_EVEN);
				BoardRateFlag= 4;
				break;
			case 4:
				InitSci0(RS_9600,RS_DATA8,RS_EVEN);
				BoardRateFlag= 5;
				break;
			case 5:
				InitSci0(RS_38400,RS_DATA7,RS_EVEN);	/*ksc20040715 RS_9600 �� RS_2400 �ƴ���? */
				BoardRateFlag= 0;
				break;
			}
		}
		signal = 0xffffffff;
		OffSignal(SGN_PLC,signal);		/* PLC Stop */
//		PlcSignalInf= OFF;			//PLC Proc Stop
//sprintf(buff,"No=%2d,%03x",BoardRateFlag,rs1Cnt);
//DotTextOut(10*8,10*16,buff,1,1, TRANS, T_WHITE, T_BLACK);							
//DrawLcdBank1();

		Delay(100);
/*		CommModeRec = 0;*/
/*		Sio1RecCnt = 0;*/
/*		CommMode = 0;*/
		BoardRateChangingFlag= 0;
/*		SetPCTimeOut((unsigned int)(_TimeMSec+ EDIT_TIME_OUT)); 061024 */
		SetPCTimeOut(EDIT_TIME_OUT);
		break;
	case 1:				/* Header Recieve */
		signal = 0xffffffff;
		OffSignal(SGN_PLC,signal);		/* PLC Stop */
//		PlcSignalInf= OFF;			//PLC Proc Stop
/*		SetPCTimeOut((unsigned int)(_TimeMSec+ 1500)); 061024 */	/* �P�o�C�g?�C?�A�E�g */
		SetPCTimeOut(1500);	/* �P�o�C�g?�C?�A�E�g */
		break;
	case 3:
/*		CommMode = 0;*/
		SetPCTimeOut((unsigned int)0);
//		bcc = 0;
//		for(i = 0; i < RecCommCnt- 1; i++){
//			bcc += CommBuff[i];
//		}
//		if(bcc == CommBuff[i]){
			if((CommonArea.PcUpDownMode == 0) || (CommonArea.PcUpDownMode == 1)){	/* Idle Or DownLoad */
				SaveMode= CommonArea.PcUpDownMode;
				ret= GPDataCheck(CommBuff,SendBuff,SendCommCnt);
				if(ret == NG){	/* 070207 */
					break;		/* Double Download Command */
				}
				if(SaveMode != CommonArea.PcUpDownMode){
					if((CommonArea.PcUpDownMode == 1) || (CommonArea.PcUpDownMode == 2)){
						Delay(100);
					}
				}

				if(*SendCommCnt != 0){		/* Send Data */
					SendPCData(SendBuff,SendCommCnt);
/* 					SetPCTimeOut((unsigned int)(_TimeMSec+ EDIT_TIME_OUT)); 061024 */
					SetPCTimeOut(EDIT_TIME_OUT);
				}
				if(ret == 1){			/* Project Delete */
					pcNewRec= 1;		/* PC_ON Send */
				}
				switch(CommonArea.PcUpDownMode){
				case 2:		/* Upload */
					UpLoadMode= PC_SEND_COMMON;
					SerchFirstFlag= 0;
					PcFilefp= -1;
					if(CommBuff[6] != NAK){
						CommBuff[6] = ACK;
					}
					break;
				case 3:		/* UpLoad Project Header */
					UpLoadMode= PC_SEND_PRJHED;
					if(CommBuff[6] != NAK){
						CommBuff[6] = ACK;
					}
					break;
				case 4:		/* UpLoad Project Header  extern */
					UpLoadMode= PC_SEND_PRJEXT;
					if(CommBuff[6] != NAK){
						CommBuff[6] = ACK;
					}
					break;
				case 5:		/* Upload Project ID */
				case 6:		/* Upload Password */
					UpLoadMode= PC_SEND_ELSE;
					if(CommBuff[6] != NAK){
						CommBuff[6] = ACK;
					}
					break;
				default:
					if(CommModeData == PC_DOWNLDED){
						SetPCTimeOut((unsigned int)0);
						pcNewRec = 1;		/* Rec Compleat */
						Delay(20);
						GetSendRecTimePlc1();
						initEditPort();
						OnSignal(SGN_PLC,0x01);		/* PLC Start */
//						PlcSignalInf= ON;		//PLC PROC Start
#ifdef	LP_S044		/* 20080822 LP�� RUN ���ǿ����� �ٿ�δ� �Ϸ��� RUN�ϵ��� �Ѻκ� - �ٿ�δ��� �������� �����Ƿ� �̺κе� �ڸ�Ʈ ó��  */
/*						if(DownloadStopFlag == 'R'){	*/
/*							SetRunStopSwitch(ON);	*/
/*						}	*/
#endif
					}
					break;
				}
			}
			switch(CommonArea.PcUpDownMode){
			case 2:		/* UpLoad */
					if(CommBuff[6] == ACK){
						if(UpLoadMode == PC_SEND_END+1){
							CommonArea.PcUpDownMode= 0;
							pcNewRec = 1;		/* Rec Compleat */
							Delay(20);
							GetSendRecTimePlc1();
							SetPCTimeOut((unsigned int)0);
							initEditPort();
							OnSignal(SGN_PLC,0x01);		/* PLC Start */
//							PlcSignalInf= ON;		//PLC PROC Start
						}else{
							MakeSendData(SendBuff,SendCommCnt);
							RetryCnt= 0;
							SendPCData(SendBuff,SendCommCnt);
/* 							SetPCTimeOut((unsigned int)(_TimeMSec+ EDIT_TIME_OUT)); 061024 */
							SetPCTimeOut(EDIT_TIME_OUT);
						}
					}else{
						RetryCnt++;
						if(RetryCnt > 3){
							CommonArea.PcUpDownMode= 0;
							pcNewRec = 1;		/* Rec Compleat */
							SetPCTimeOut((unsigned int)0);
							GetSendRecTimePlc1();
							initEditPort();
							OnSignal(SGN_PLC,0x01);		/* PLC Start */
//							PlcSignalInf= ON;		//PLC PROC Start
						}else{
							SendPCData(SendBuff,SendCommCnt);
/* 							SetPCTimeOut((unsigned int)(_TimeMSec+ EDIT_TIME_OUT)); 061024 */
							SetPCTimeOut(EDIT_TIME_OUT);
						}
					}
				break;
			case 3:		/* UpLoad Project Header */
			case 4:		/* UpLoad Project Header  extern */
			case 5:		/* Upload Project ID */
			case 6:		/* Upload Password */
#ifdef	WIN32
				if((CommBuff[6] == ACK) || (CommonArea.PcUpDownMode == 5)){
#else
				if(CommBuff[6] == ACK){
#endif
					if(UpLoadMode == PC_SEND_END){
						if(CommonArea.PcUpDownMode == 4){
							SetPCTimeOut((unsigned int)0);
							CommonArea.PcUpDownMode= 0;
							pcNewRec = 1;		/* Rec Compleat */
							Delay(20);
							GetSendRecTimePlc1();
							initEditPort();
							OnSignal(SGN_PLC,0x01);		/* PLC Start */
//							PlcSignalInf= ON;		//PLC PROC Start
						}
						CommonArea.PcUpDownMode= 0;
					}else{
						switch(CommonArea.PcUpDownMode){
						case 3:		/* UpLoad Project Header */
							if(RecCommCnt == 7){	//Comand
								MakeProjectHed(SendBuff,SendCommCnt);
							}else{
								NextSendProjectData(SendBuff,SendCommCnt);
							}
							if((UpdateProjectBaseCnt == 0) && (UpdateProjectWindowCnt == 0)){
								UpLoadMode= PC_SEND_END;
							}
							break;
						case 4:		/* UpLoad Project Header  extern */
							if(RecCommCnt == 7){	//Comand
								MakeProjectHedExt(SendBuff,SendCommCnt);
							}else{
								NextSendProjectDataExt(SendBuff,SendCommCnt);
							}
							if((UpdateProjectBaseCnt == 0) && (UpdateProjectWindowCnt == 0)){
								UpLoadMode= PC_SEND_END;
							}
							break;
						case 5:		/* Upload Project ID */
							MakeProjectID(SendBuff,SendCommCnt);
							/*PcUpDownMode= 0;*/	/* ACK�����Ȃ� 031031 */
							/* Error�̎��A��?�����܂܂ɂȂ邽�� */
/*							OnSignal(SGN_PLC,1);*/		/* PLC Stop */
/*							OnSignal(S_PROJECT,1);*/
/*							OnSignal(S_SCREEN,1);*/
							UpLoadMode= PC_SEND_END;
							break;
						case 6:		/* Upload Password */
							MakePassWord(SendBuff,SendCommCnt);
							UpLoadMode= PC_SEND_END;
							break;
						}
						RetryCnt= 0;
						SendPCData(SendBuff,SendCommCnt);
						/* ID��ACK�͌��Ȃ��悤�ɂ��� */
						if((CommonArea.PcUpDownMode == 5) || (CommonArea.PcUpDownMode == 6)){
							CommonArea.PcUpDownMode= 0;
						}else{
/* 							SetPCTimeOut((unsigned int)(_TimeMSec+ EDIT_TIME_OUT)); 061024 */
							SetPCTimeOut(EDIT_TIME_OUT);
						}
					}
				}else{
					RetryCnt++;
					if(RetryCnt > 3){
						SetPCTimeOut((unsigned int)100);
						CommonArea.PcUpDownMode= 0;
						Delay(20);
						initEditPort();
						OnSignal(SGN_PLC,0x01);		/* PLC Start */
//						PlcSignalInf= ON;		//PLC PROC Start
					}else{
						SendPCData(SendBuff,SendCommCnt);
/* 						SetPCTimeOut((unsigned int)(_TimeMSec+ EDIT_TIME_OUT)); 061024 */
						SetPCTimeOut(EDIT_TIME_OUT);
					}
				}
				break;
			default:
/* 				SetPCTimeOut((unsigned int)(_TimeMSec+ EDIT_TIME_OUT)); 061024 */
				SetPCTimeOut(EDIT_TIME_OUT);
				break;
			}
//		}else{
//			SetErrorRec(NAK,SendBuff,SendCommCnt,ERR_BCC);
//			SendPCData(SendBuff,SendCommCnt);
//			SetPCTimeOut((unsigned int)(_TimeMSec+ EDIT_TIME_OUT));
//		}
		break;
	default:
/* 		SetPCTimeOut((unsigned int)(_TimeMSec+ EDIT_TIME_OUT)); 061024 */
		SetPCTimeOut(EDIT_TIME_OUT);
		break;
	}
}
/********************************************/
/*	PC Communication						*/
/********************************************/
void	PC_CommProc(void)
{
/*	if(PC_CommMode != 99){*/		/* DownLoad OR UpLoad */
	if((Set.Ch1_iKind == EDITER) || (Set.Ch2_iKind == EDITER)){		/* DownLoad OR UpLoad */
		PCEditorCommProc((int *)&CommMode,CommBuff,SendBuff,(int *)&SendCommCnt);
	}else{
		PC_CommMode= 0;
		CommMode= 0;
		if(BoardRateChangingFlag == 1){
			/* Monitor Error */
			BoardRateChangingFlag = 0;
			Rs232cBordrateSet();
		}else{
/*			MonTimeout= _TimeMSec+ 10000; 061024 */	/* 10s Timeout */
			SaveMonTimeout= _TimeMSec;	/* 10s Timeout 2009 07.01*/
			MonTimeout= 10000;	/* 10s Timeout */
			switch(Set.Ch1_iKind){
			case UNIVERSAL:
				break;
			case DEFAULT_PLC:				/* FX Serease */
				LG_PLCFxThruProc((char *)CommBuff,(int *)&RecCommCnt,(char *)PlcThrueBuff,(int *)&PlcThrueCnt,PlcConnectFlag,PlcType);
				break;
			case ELSE_PLC:
//				if(ElsPlcOK == 1){
				if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
					PLC_THRU_PROC((char *)CommBuff,(int *)&RecCommCnt,(char *)PlcThrueBuff,(int *)&PlcThrueCnt,PlcConnectFlag,PlcType);
				}
				break;
			}
		}
	}
}
/************************************/
/* ���ʏ���							*/
/************************************/
int	Bin2Hex1(int data)
{
	int		ret;

	if(data > 9){
		ret= 'A'+ data- 10;
	}else{
		ret= '0'+ data;
	}
	return(ret);
}
void	Bin2Hex(int data,int cnt,char *buff)
{
	int		i;
	unsigned int AndData;

	AndData= 0x000f;
	for(i= 1; i < cnt; i++){
		AndData= AndData << 4;
	}
	for(i= 0; i < cnt; i++){
		buff[i]= Bin2Hex1((data & AndData) >> ((cnt- i- 1)*4));
		AndData = AndData >> 4;
	}
	buff[i]= 0;
}
void	Bin2dec(int data,int cnt,char *buff)
{
	int		i;
	int		AndData;

	AndData= 1;
	for(i= 1; i < cnt; i++){
		AndData= AndData* 10;
	}
	if(data < 0){			/* - check 041116 */
		
		data *= -1;
		buff[0]= '-';
		for(i= 1; i < cnt+1; i++){								/*cnt+1�̵� ������ */
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}else{
		for(i= 0; i < cnt; i++){
			buff[i]= '0'+ ((data / AndData) % 10);
			data= data % AndData;
			AndData = AndData / 10;
		}
	}
	buff[i]= 0;
}
int	gstrlen(char *buff)
{
	int		i;

	for(i= 0; ; i++){
		if(buff[i] == 0){
			break;
		}
	}
	return(i);
}
void	gmemset(char *buff,int data,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*buff= (char)data;
		buff++;
	}
}
void	gmemcpy(char *obj,char *src,int cnt)
{
	int		i;

	for(i= 0; i < cnt; i++){
		*obj= *src;
		src++;
		obj++;
	}
}
void	gstrcpy(char *obj,char *src)
{
	int		i;

	for(i= 0; ; i++){
		*obj= *src;
		if(*src == 0){
			break;
		}
		src++;
		obj++;
	}
	*obj= 0;
}
int	gstrcmp(char *src,char *obj)
{
	int		i;
	int		ret;

	ret= NG;
	for(i= 0; ; i++){
		if(src[i] == 0){
			if(obj[i] == 0){
				ret= OK;
			}
			break;
		}
		if(obj[i] == 0){
			break;
		}
		if(src[i] != obj[i]){
			break;
		}
	}
	return(ret);
}
int	gstrncmp(char *src,char *obj,int cnt)
{
	int		i;
	int		ret;

	ret= OK;
	for(i= 0; i < cnt; i++){
		if(src[i] != obj[i]){
			ret= NG;
			break;
		}
	}
	return(ret);
}
void	gstrcat(char *src,char *obj)
{
	int		i;

	for(i= 0; ; i++){
		if(*src == 0){
			break;
		}
		src++;
	}
	for(i= 0; ; i++){
		if(*obj == 0){
			*src= 0;
			break;
		}
		*src= *obj;
		src++;
		obj++;
	}
}
int	gatoi(char *buff)
{
	char	c;
	int	ret;
	int flag;

	ret= 0;
	flag= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){
			break;
		}
		if((c >= '0') && (c <= '9')){
			ret= ret*10;
			ret+= c- '0';
		}else{
			if(c == '+'){
				continue;
			}
			if(c == '-'){
				flag= 1;
				continue;
			}
			break;
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}
char	digitbuf[20];
char	shobuf[20];
char	edigitbuf[20];
float	gatof(char *buff)
{
	char	c;
	float	ret;
	int flag,i;
	int dflag;
	int eflag;
	int emflag;
	float	sho;
	int	digit_cnt;
	int	sho_cnt;
	int	edigit_cnt;
	int	eNo;

	ret= 0;
	flag= 0;
	dflag= 0;
	eflag= 0;
	emflag= 0;
	digit_cnt= sho_cnt= edigit_cnt= 0;
	while(1){
		c= *buff;
		buff++;
		if(c == 0){		break;		}
		if((c >= '0') && (c <= '9')){
			if(eflag == 1){			edigitbuf[edigit_cnt++]= c;	}
			else if(dflag == 0){	digitbuf[digit_cnt++]= c;	}
			else{					shobuf[sho_cnt++]= c;		}
		}else{
			if(c == '+'){	continue;			}
			if(c == '-'){
				if(eflag == 1){	emflag= 1;		}
				else{			flag= 1;		}
				continue;
			}
			if(c == '.'){	dflag= 1;	continue;	}
			if(c == 'E'){	eflag= 1;	continue;	}
		}
	}
	digitbuf[digit_cnt]= 0;
	shobuf[sho_cnt]= 0;
	edigitbuf[edigit_cnt]= 0;
	ret= (float)gatoi(digitbuf);
	sho= (float)gatoi(shobuf);
	eNo= gatoi(edigitbuf);
	for(i= 0; i < sho_cnt; i++){	sho /= 10;		}
	if(sho_cnt > 0){	ret += sho;	}
	if(eflag == 1){
		if(emflag == 1){
			for(i= 0; i < eNo; i++){	ret /= 10;		}
		}else{
			for(i= 0; i < eNo; i++){	ret *= 10;		}
		}
	}
	if(flag == 1){
		ret= ret * -1;
	}
	return(ret);
}
static	int	digit;
static	int	pcnt,mcnt;
int	ParcentEProcSub(float data)
{
	int	dlen;
	int	i,j;

	pcnt= mcnt= digit= 0;
	if(data == 0){	return -1;	}	
	digit= (int)data;
	if(digit == 0){
		for(i= 0; i < 38; i++){
			if((int)data != 0){		break;	}
			data *= 10;
		}
		if(i >= 38){	return -1;	}
		for(j= 0; j < 7 && i < 38; j++,i++){	data *= 10;	}
		digit= (int)data;
		mcnt= i;
	}else{
		itoa(digit,digitbuf,10);
		dlen= strlen(digitbuf);
		if(dlen > 7){
			for(j= dlen,pcnt= 6; j > 7; j--,pcnt++){	data /= 10;	}
		}else{
			for(j= dlen; j < 7; j++,mcnt++){
				data *= 10;
			}

		}
		digit= (int)data;
	}
	return 0;
}
void	ParcentEProc(char* buff,float data)
{
	int	dlen;
	int	idx;
	int	flag;

	if(ParcentEProcSub(data) == -1){	buff[0]= '0';	buff[1]= 0;	return;	}
	itoa(digit,digitbuf,10);
	dlen= strlen(digitbuf);
	idx= 0;
	flag= 0;
	if(digitbuf[idx] == '-'){
		buff[0]= digitbuf[idx++];
		buff[1]= digitbuf[idx++];
		buff[2]= '.';
		buff[3]= 0;
		flag= 1;
	}else{
		buff[0]= digitbuf[idx++];
		buff[1]= '.';
		buff[2]= 0;
	}
	strcat(buff,&digitbuf[idx]);
	if(pcnt > 0){
	}else{
		if(flag == 1){	dlen--;	}
		if(dlen > mcnt){
			pcnt= dlen- mcnt- 1;
			if(pcnt == 0){
				mcnt= dlen- mcnt- 1;
			}
		}else{
			mcnt= mcnt- dlen+ 1;
		}
	}
	if(pcnt > 0){
		itoa(pcnt,shobuf,10);
		strcat(buff,"E+");
		strcat(buff,shobuf);
	}else if(mcnt > 0){
		itoa(mcnt,shobuf,10);
		strcat(buff,"E-");
		strcat(buff,shobuf);
	}else{
		strcat(buff,"E+0");
	}
}
void	ParcentfProc(char* buff,float data,int keta,int sho)
{
	int	i,j,idx,scnt;
	int	dlen;

	ParcentEProcSub(data);
	itoa(digit,digitbuf,10);
	dlen= strlen(digitbuf);
//	if(pcnt > 0){
//	}else{
//		if(dlen > mcnt){
//			pcnt= dlen- mcnt- 1;
//		}else{
//			mcnt= mcnt- dlen+ 1;
//		}
//	}
//	if(mcnt < dlen){	//mcnt:1/10�̂���
//
//	}
//	for(i= 1; i < dlen ; i++){
//		if(pcnt > 0){	pcnt--;	}
//		else{			mcnt++;	}
//	}
	idx= 0;
	if(pcnt > 0){		//10�̂���
		if(sho > 0){	scnt= sho+1;	}
		else{			scnt= 0;		}
		if(pcnt > dlen- 1){
			for(i= 0; i < (keta- (dlen+(pcnt-dlen)+scnt)); i++){
				buff[idx++]= ' ';
			}
			for(i= 0; i < dlen; i++){
				buff[idx++]= digitbuf[i];
			}
			for(i= 0; i < pcnt- dlen+ 1; i++){
				buff[idx++]= '0';
			}
			if(sho > 0){
				buff[idx++]= '.';
				for(i= 0; i < sho; i++){
					buff[idx++]= '0';
				}
			}
		}else{
			for(i= 0; i < (keta- ((dlen- pcnt)+scnt)); i++){
				buff[idx++]= ' ';
			}
			for(i= 0; i < dlen; i++){
				buff[idx++]= digitbuf[i];
			}
			for(i= 0; i < pcnt; i++){
				buff[idx++]= '0';
			}
			if(sho > 0){
				buff[idx++]= '.';
				for(i= 0; i < sho; i++){
					buff[idx++]= '0';
				}
			}
		}
	}else if(mcnt > 0){
		if(mcnt < dlen){
			if(sho > 0){	scnt= sho+1+dlen-mcnt;	}
			else{			scnt= dlen-mcnt;		}
			for(i= 0; i < (keta- scnt); i++){
				buff[idx++]= ' ';
			}
			for(i= 0; i < dlen- mcnt; i++){
				buff[idx++]= digitbuf[i];
			}
			if(sho > 0){
				buff[idx++]= '.';
				for(j= 0; j < sho && i < dlen; j++){
					buff[idx++]= digitbuf[i++];
				}
				for(; j < sho; j++){
					buff[idx++]= '0';
				}
			}
		}else{
			if(sho > 0){	scnt= sho+2;	}
			else{			scnt= dlen-mcnt;		}
			for(i= 0; i < (keta- scnt); i++){
				buff[idx++]= ' ';
			}
			buff[idx++]= '0';
			if(sho > 0){
				buff[idx++]= '.';
				for(i= 0; i < sho && i < (mcnt- dlen); i++){
					buff[idx++]= '0';
				}
				for(j= 0; i < sho; i++,j++){
					buff[idx++]= digitbuf[j];
				}
			}
		}
	}else{
		if(sho > 0){	scnt= sho+1;	}
		else{			scnt= 0;		}
		if(dlen > (keta-(sho+1))){
		}else{
			for(i= 0; i < (keta-(scnt+dlen)); i++){
				buff[idx++]= ' ';
			}
		}
		for(i= 0; i < dlen; i++){
			buff[idx++]= digitbuf[i];
		}
		if(sho > 0){
			buff[idx++]= '.';
			for(; i < sho; i++){
				buff[idx++]= '0';
			}
		}
	}
}
/*****************END*********************************/

