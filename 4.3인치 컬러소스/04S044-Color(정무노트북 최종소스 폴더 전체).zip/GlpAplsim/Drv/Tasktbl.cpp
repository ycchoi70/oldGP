/******************************************************/
/*  ?�X�N?�w�b??                                  */
/*  1999.8.10                                         */
/******************************************************/

#include    "define.h"
#include    "Mts.h"
#include    "MtsCifp.h"
#include	"Taskhed.h"
#include	"s3c44b0x.h"
//#include	"bios.h"

int	_MyCpuNo = 1;			/**/
unsigned streg = 0;
unsigned short exvct = 0;	/* Exception trap Vector Number */

extern	void	HardInitial(void);
extern	void	_ei(void);

#ifdef	OLD
void	IniTaskaa( STTFrm* pSTT )
{
	int	flag;

	flag= 1;
	RunLed(ON);
	while(1){
#ifdef	WIN32
		Delay(100);
#else
		if(flag == 0){
			flag= 1;
			ErrorLed(ON);
		}else{
			flag= 0;
			ErrorLed(OFF);
		}
     	Delay(1000);	     	
#endif
	}
}
#endif
/******************************************************/
/*  Application Task                                  */
/******************************************************/
extern	void	IniTask( STTFrm* pSTT );
/*extern	void	SetTask( STTFrm* pSTT );*/
extern	void	DispAnalysis( STTFrm* pSTT );

/******************************************************/
/*  Drawing Task	                                  */
/******************************************************/
extern  void	KeyTask( STTFrm* pSTT );
/*extern  void	FileTask(STTFrm* pSTT );*/
extern  void	AlarmDetail_Task(STTFrm* pSTT );

extern  void    Classification_Task( STTFrm* pSTT );
extern  void	TouchKeyWatch_Task( STTFrm* pSTT );
extern	void	WindowDisplay_Task(STTFrm* pSTT);
/******************************************************/
/*  Handler Task                                      */
/******************************************************/
/******************************************************/
/*  Driver Task ?                                    */
/******************************************************/
extern	void    KeyDrv(STTFrm* pSTT);
extern	void    KeyHand(STTFrm* pSTT );
extern	void    RTCDrv(STTFrm* pSTT );
extern	void	PcState( STTFrm* pSTT );
extern	void	PlcState( STTFrm* pSTT );
extern	void	Plc2State( STTFrm* pSTT );
extern	void	PrtHand( STTFrm* pSTT );
extern	void	PlcHand( STTFrm* pSTT );
extern	void	Plc2Hand( STTFrm* pSTT );
extern	void	FloatState( STTFrm* pSTT );
extern	void	BuzDrv(STTFrm* pSTT);

extern	void	PlcSendRec( STTFrm* pSTT );
extern	void	Sio0Drv( STTFrm* pSTT );
extern	void	Sio0RecDrv( STTFrm* pSTT );
extern	void	Sio1Drv( STTFrm* pSTT );
extern	void	Sio1RecDrv( STTFrm* pSTT );
extern	void    RtcHand( STTFrm* pSTT );

extern	void	MsgTask( STTFrm* pSTT );
extern	void    DebugTask( STTFrm* pSTT );         /* ����������?�X�N */

extern	void	ObservTask( STTFrm* pSTT );
extern	void	ScreenState( STTFrm* pSTT );
extern	void	TimeSwitchTask( STTFrm* pSTT );
extern	void	PlcConnChk( STTFrm* pSTT );
extern	void	PlcMainTask(STTFrm* pSTT);


void	PlcTimIntTask( STTFrm* pSTT );		//Plc Timer 
void PlcIntrruptTask(STTFrm* pSTT);

/******************************************************/
/*  Interrupt? ?                                    */
/******************************************************/
#ifdef	WIN32
extern  interrupt   void    _SystemClockInterruptHandler( void );   /* �V�X�e??�C? */

#else

extern  void    _SystemClockInterruptHandler( void );   /* �V�X�e??�C? */


#endif
/******************************************************/
/*  STACK�̈�  ?                                    */
/******************************************************/
#ifdef	WIN32
	unsigned char	KeyDrvStack[8192];
	unsigned char	RTCDrvStack[8192];
	unsigned char	BuzDrvStack[8192];
	unsigned char	Sio0DrvStack[8192];
	unsigned char	Sio0RecDrvStack[8192];
	unsigned char	Sio1DrvStack[8192];
	unsigned char	Sio1RecDrvStack[8192];
	unsigned char	KeyHandStack[8192];
	unsigned char	Plc2HandStack[8192];
	unsigned char	PlcHandStack[8192];
	unsigned char	RtcHandStack[8192];
	unsigned char	PcStateStack[8192];
	unsigned char	PlcStateStack[8192];
/*	unsigned char	Plc2StateStack[8192];*/
	unsigned char	FloatStateStack[8192];
	unsigned char	MsgTaskStack[8192];
	unsigned char	DebugTaskStack[8192];
	unsigned char	ObservTaskStack[8192];
/*	unsigned char	ScreenStateStack[8192];*/
	unsigned char	TimeSwitchTaskStack[8192];

/*********************************/
	unsigned char	IniTaskStack[8192];
/*	unsigned char	SetTaskStack[8192];*/
	unsigned char	DispAnalysisStack[8192];
/*	unsigned char	FileReadStack[8192];*/
	unsigned char   Classification_Stack[8192];
	unsigned char   AlarmDetail_Stack[8192];
	unsigned char   WindowDisplay_Task_Stack[8192];

	unsigned char   PlcConnChk_Stack[8192];
	unsigned char   PlcMainTaskStack[8192];
	unsigned char	PlcTimIntTaskStack[8192];
	unsigned char	PlcIntrruptTaskStack[8192];
#else
	unsigned char	KeyDrvStack[2048];
	unsigned char	RTCDrvStack[2048];
	unsigned char	BuzDrvStack[2048];
	unsigned char	Sio0DrvStack[2048];
	unsigned char	Sio0RecDrvStack[2048];
	unsigned char	Sio1DrvStack[2048];
	unsigned char	Sio1RecDrvStack[2048];
	unsigned char	KeyHandStack[2048];
	unsigned char	Plc2HandStack[2048];
	unsigned char	PlcHandStack[2048];
	unsigned char	RtcHandStack[2048];
	unsigned char	PcStateStack[2048];
	unsigned char	PlcStateStack[2048];
/*	unsigned char	Plc2StateStack[2048];*/
	unsigned char	FloatStateStack[2048];
	unsigned char	MsgTaskStack[2048];
	unsigned char	DebugTaskStack[2048];
	unsigned char	ObservTaskStack[2048];
/*	unsigned char	ScreenStateStack[2048];*/
	unsigned char	TimeSwitchTaskStack[2048];

/*********************************/
	unsigned char	IniTaskStack[2048];
/*	unsigned char	SetTaskStack[2048];*/
	unsigned char	DispAnalysisStack[4096];
/*	unsigned char	FileReadStack[2048];*/
	unsigned char   Classification_Stack[2048];
	unsigned char   AlarmDetail_Stack[2048];
	unsigned char   WindowDisplay_Task_Stack[2048];

	unsigned char   PlcConnChk_Stack[2048];
	unsigned char   PlcMainTaskStack[2048];
	unsigned char	PlcTimIntTaskStack[2048];
	unsigned char	PlcIntrruptTaskStack[2048];
#endif
STTFrm  _StaticTaskTableUsr[]= { 
{ "INIT  TASK    ", T_INITASK,			0x05, 0, 0, IniTask,				{0,0,0}, IniTaskStack,				sizeof(IniTaskStack)			},
{ "CLASSIFY TASK ", T_CLASSIFICATION,	0x19, 0, 0, Classification_Task,	{0,0,0}, Classification_Stack,		sizeof(Classification_Stack)	},
{ "DISPLAY TASK  ", T_DISPANALYSIS,		0x18, 0, 0, DispAnalysis,			{0,0,0}, DispAnalysisStack,			sizeof(DispAnalysisStack)		},
{ "DISPLAY TASK  ", T_DISP_TASK,		0x18, 0, 0, WindowDisplay_Task,		{0,0,0}, WindowDisplay_Task_Stack,	sizeof(WindowDisplay_Task_Stack)},
{ "Key Drive     ", T_KEY,				0x17, 0, 0, KeyDrv,					{0,0,0}, KeyDrvStack,				sizeof(KeyDrvStack)				},
{ "Buzzer Drive  ", T_BZRDRV,			0x13, 0, 0, BuzDrv,					{0,0,0}, BuzDrvStack,				sizeof(BuzDrvStack)				},
{ "Key Hand      ", T_KEYHAND,			0x15, 0, 0, KeyHand,				{0,0,0}, KeyHandStack,				sizeof(KeyHandStack)			},
//Master is 15,Slave is 19
{ "Sio0 Drive    ", T_SIO0DRV,			0x15, 0, 0, Sio0Drv,				{0,0,0}, Sio0DrvStack,				sizeof(Sio0DrvStack)			},
{ "Sio0 RecDrive ", T_SIO0RCV,			0x13, 0, 0, Sio0RecDrv,				{0,0,0}, Sio0RecDrvStack,			sizeof(Sio0RecDrvStack)			},
//Master is 15,Slave is 19
{ "Sio1 Drive    ", T_SIO1DRV,			0x19, 0, 0, Sio1Drv,				{0,0,0}, Sio1DrvStack,				sizeof(Sio1DrvStack)			},

{ "Sio1 RecDrive ", T_SIO1RCV,			0x13, 0, 0, Sio1RecDrv,				{0,0,0}, Sio1RecDrvStack,			sizeof(Sio1RecDrvStack)			},
#ifdef	LP_S044
{ "RTC Drive     ", T_RTCDRV,			0x15, 0, 0, RTCDrv,					{0,0,0}, RTCDrvStack,				sizeof(RTCDrvStack)				},
#endif
#ifdef	GP_S057
{ "RTC Drive     ", T_RTCDRV,			0x13, 0, 0, RTCDrv,					{0,0,0}, RTCDrvStack,				sizeof(RTCDrvStack)				},
#endif
#ifdef	GP_S044
{ "RTC Drive     ", T_RTCDRV,			0x13, 0, 0, RTCDrv,					{0,0,0}, RTCDrvStack,				sizeof(RTCDrvStack)				},
#endif
{ "RTC Hand      ", T_RTCHAND,			0x14, 0, 0, RtcHand,				{0,0,0}, RtcHandStack,				sizeof(RtcHandStack)			},
{ "PLC Hand      ", T_PLCHAND,			0x15, 0, 0, PlcHand,				{0,0,0}, PlcHandStack,				sizeof(PlcHandStack)			},
{ "PLC Hand2     ", T_PLCHAND2,			0x16, 0, 0, Plc2Hand,				{0,0,0}, Plc2HandStack,				sizeof(Plc2HandStack)			},
{ "PC State      ", T_PCKANSI,			0x18, 0, 0, PcState,				{0,0,0}, PcStateStack,				sizeof(PcStateStack)			},
{ "PLC State     ", T_PLCKANSI,			0x19, 0, 0, PlcState,				{0,0,0}, PlcStateStack,				sizeof(PlcStateStack)			},
{ "Floating Alarm", T_FLTKANSI,			0x17, 0, 0, FloatState,				{0,0,0}, FloatStateStack,			sizeof(FloatStateStack)			},
{ "Msg Task      ", T_MSG_TASK,			0x21, 0, 0, MsgTask,				{0,0,0}, MsgTaskStack,				sizeof(MsgTaskStack)			},
{ "Debug Task    ", T_DEBUG,			0x21, 0, 0, DebugTask,				{0,0,0}, DebugTaskStack,			sizeof(DebugTaskStack)			},
{ "Project St Tsk", T_OBSERV,			0x20, 0, 0, ObservTask,				{0,0,0}, ObservTaskStack,			sizeof(ObservTaskStack)			},

{ "Time Prc Task ", T_TIME_PROC,		0x14, 0, 0, TimeSwitchTask,			{0,0,0}, TimeSwitchTaskStack,		sizeof(TimeSwitchTaskStack)		},
{ "Plc Cont Task ", T_PLCCON,			0x1f, 0, 0, PlcConnChk,				{0,0,0}, PlcConnChk_Stack,			sizeof(PlcConnChk_Stack)		},
#ifdef	LP_S044
{ "Plc Main Task ", T_PLCMAIN,			0x14, 0, 0, PlcMainTask,			{0,0,0}, PlcMainTaskStack,			sizeof(PlcMainTaskStack)		},
{ "GLP Time Task ", T_PLCTINT_TASK,		0x13, 0, 0, PlcTimIntTask,			{0,0,0}, PlcTimIntTaskStack,		sizeof(PlcTimIntTaskStack)		},
{ "GLP INT  Task ", T_PLCINTTASK,		0x13, 0, 0, PlcIntrruptTask,		{0,0,0}, PlcIntrruptTaskStack,		sizeof(PlcIntrruptTaskStack)	},
#endif
{ 0, }
};
SMTFrm  _SMT[]= {
    { 128, 0x00000040 }, /* ?   64�̃�?���� 128�� =  8KB      */
    {  32, 0x00000080 }, /* ?  128�̃�?���� 200�� =  4KB      */
    {   8, 0x00000400 }, /*   ?1K�̃�?����    8�� =  8KB      */
	{   8, 0x00000800 }, /*   ?2�j�̃�?����  16�� = 16KB      */
    {   4, 0x00001000 }, /*   ?4�j�̃�?����   4�� = 16KB      */
    {   2, 0x00002000 }, /*   ?�W�j�̃�?����  2�� = 16KB      */
    {   2, 0x00010000 }, /*   ?64�j�̃�?����  2�� =128KB      */
    {   0, 0x00000000 }  /*		�I���̂��邵         180KB    ?*/
};
char*  _MailAreaLast;
char   _MailArea[(8+4+8+16+16+16+128)*1024+((128+32+8+8+4+2+2)*32)];		/* KB + ��?���̐�*32   total*/

//int	CheckMailBox(unsigned int size)
//{
//	int		i;
//	int		ret;

//	for(i= 0; ; i++){
//		if(size <= _SMT[i].Size){
//			break;
//		}
//	}
//	if(_Mbx[i+0xf0].MailCount > 3){
//		ret= 0;
//	}else{
//		ret= -1;
//	}
//	return(ret);
//}




#ifdef	WIN32
VctFrm  _InterruptVectorTable[]= {
    { 0x1f, _SystemClockInterruptHandler  },
#else
const	VctFrm  _InterruptVectorTable[]= {
#endif
    { 0x00, 0                             }
};
