/*** Sst NOR type flash programming algorithm for RVD ***
  /  
 / /
/ / /\
\\\/ /// CLABSYS
 \\ ///  Cyber Lab System
  \\//
   \/


Revision history ___
2004-12-8 jyoon start
*/ 

#include "typedefs.h"
#include "manid.h"
#include "rvd.h"
#include "commonflash.h"
#include "asm.h"
#include "bustype.h"
#include "operations.h"
#include "deviceid.h"


#define FC_AT1          0xAAAAAAAA	// attention request 1 (OFF1)
#define FC_AT2          0x55555555	// attention request 2 (OFF2)
#define FC_ID_EN        0x90909090	// enter ID mode
#define FC_ID_EX        0xF0F0F0F0	// exit ID mode
#define FC_WRITE        0xA0A0A0A0	// start writing block
#define FC_ERASE        0x80808080	// start erase of segment/block
#define FC_SECTE        0x50505050	// Block erase (into sector)
#define FC_FASTMODE     0x20202020
#define OFFSET1	        0x5555
#define OFFSET2	        0x2aaa
#define PROTECTED_MASK  0xFF
#define OFFSET_MASK 0xFFFF0000

/* Publics */
WORD FlashGetDevIDSst(volatile WORD FlashAddress, WORD BusType, WORD DevID);
WORD FlashGetManIDSst(volatile WORD FlashAddress, WORD BusType, WORD FacID);
WORD FlashEraseSst(volatile WORD BlockAddress, WORD BusType,WORD DevID);
WORD FlashWriteSst(volatile WORD WriteAddress, WORD BufferAddress, const WORD Count, const WORD VerifyFlag, WORD BusType, WORD DevID);

/* Statics */
static WORD DefaultWriting(volatile WORD WriteAddress, WORD BufferAddress, const WORD Count, const WORD VerifyFlag, WORD BusType);
//static WORD FastWriting(volatile WORD WriteAddress, WORD BufferAddress, const WORD Count, const WORD VerifyFlag, WORD BusType);
static void ControlFlash( volatile WORD BlockAddress, const WORD Control, WORD BusType);
static WORD DataToggle(volatile WORD WriteAddress,WORD BusType);
//static WORD IsLocked(volatile WORD Address, WORD BusType, WORD Device);

/* External */
extern void KickTheDog(void);


/*** Public functions ***
 Public Public Public Public Public Public Public Public Public Public Public Public Public Public Public Public 
 Public Public Public Public Public Public Public Public Public Public Public Public Public Public Public Public 
*/
WORD FlashGetManIDSst(volatile WORD FlashAddress, WORD BusType, WORD FacID)
{
	WORD ManID;
	FlashAddress &= OFFSET_MASK;
	switch(BusType)
	{
	    case BUS1616:
	        REGISTER32(FlashAddress) = (WORD)FC_ID_EX;
	        ControlFlash(FlashAddress,FC_ID_EN,BusType);
	        ManID = REGISTER32( FlashAddress ) & 0xFFFF;    //return only lower 16-bits
        	REGISTER32( FlashAddress ) = FC_ID_EX;
        	break;
        default:
            ManID = 0;
            break;
	}
	return ManID;
}
WORD FlashGetDevIDSst(volatile WORD FlashAddress, WORD BusType, WORD DevID)
{
    FlashAddress &= OFFSET_MASK;
    switch(GETWIDTH(BusType))
    {
        case WIDTH_WORD:
            REGISTER32(FlashAddress) = (WORD)FC_ID_EX;
	        ControlFlash(FlashAddress,FC_ID_EN,BusType);
	        DevID = REGISTER32( (FlashAddress + 2));  //Base address + 2
        	REGISTER32( FlashAddress ) = (WORD)FC_ID_EX;
        	break;
        case WIDTH_HWORD:
            REGISTER16(FlashAddress) = (HWORD)FC_ID_EX;
	        ControlFlash(FlashAddress,FC_ID_EN,BusType);
	        DevID = REGISTER16((FlashAddress + 2));  //Base address + 2
        	REGISTER16( FlashAddress ) = (HWORD)FC_ID_EX;
        	break;
        default:
            break;
    }
    return DevID;
}

WORD FlashWriteSst(volatile WORD WriteAddress, WORD BufferAddress, const WORD Count, const WORD VerifyFlag, WORD BusType, WORD DevID)
{
    return DefaultWriting(WriteAddress, BufferAddress, Count, VerifyFlag, BusType);
}    
   
WORD FlashEraseSst(volatile WORD BlockAddress, WORD BusType, WORD DevID)
{
//    if(IsLocked(BlockAddress,BusType,DevID) == true)
//        return ERR_FLASH_LOCKED;
        
//    REGISTER32(BlockAddress) = FC_ID_EX; // for m29lv160DB
    
    ControlFlash(BlockAddress, FC_ERASE, BusType);	//Start erase mode 0x80
    ControlFlash(BlockAddress, NULL, BusType);	//send nothing for third,Send AA 55 only
    switch(GETWIDTH(BusType))
    {
        case WIDTH_WORD:
        	REGISTER32(BlockAddress) = FC_SECTE;
        	break;
        case WIDTH_HWORD:
        	REGISTER16(BlockAddress) = (HWORD)FC_SECTE;
        	break;
        default:
            break;
    }
    if(DataToggle(BlockAddress, BusType) != NO_ERR )
        return ERR_ERASE;
	return NO_ERR;
}

/*** Static function ***
 Static  Static  Static  Static  Static  Static  Static  Static  Static  Static  Static  Static  Static  Static 
 Static  Static  Static  Static  Static  Static  Static  Static  Static  Static  Static  Static  Static  Static 
*/ 

static void ControlFlash( volatile WORD BlockAddress, const WORD Control, WORD BusType)
{
    switch(GETWIDTH(BusType))
    {
        case WIDTH_WORD:
        	REGISTER32(((BlockAddress&OFFSET_MASK)|(OFFSET1<<2))) = FC_AT1; 
        	REGISTER32(((BlockAddress&OFFSET_MASK)|(OFFSET2<<2))) = FC_AT2; 
        	if(Control==NULL) return;
        	REGISTER32(((BlockAddress&OFFSET_MASK)|(OFFSET1<<2))) = Control; 
        	break;
        	
        case WIDTH_HWORD:
        	REGISTER16(((BlockAddress&OFFSET_MASK)|(OFFSET1<<1))) = (HWORD) FC_AT1; 
        	REGISTER16(((BlockAddress&OFFSET_MASK)|(OFFSET2<<1))) = (HWORD) FC_AT2; 
        	if(Control==NULL) return;
        	REGISTER16(((BlockAddress&OFFSET_MASK)|(OFFSET1<<1))) = Control; 
        	break;
        	
        default:
            break;
    }
	return;
}// ...ControlFlash(...)
static WORD DataToggle(volatile WORD WriteAddress,WORD BusType)
{
    WORD FirstRead = 0;
    WORD SecondRead = 0;
    WORD TryingNo = 0xff0000;
    do
    {
//        KickTheDog();
        switch(BusType)
        {
            case BUS1616:
        		FirstRead = REGISTER32(WriteAddress) & 0x00400040;	// While programming, DQ2 will toggle each reading.
        		SecondRead = REGISTER32(WriteAddress) & 0x00400040; 
        	 	break;
        	case BUS16:
        		FirstRead = REGISTER16(WriteAddress) & (1<<6);	// While programming, DQ6 will toggle each reading.
        		__asm{
            		NOP;    // For the lower speed device e.g. m29w160
        	    }
        		SecondRead = REGISTER16(WriteAddress) & (1<<6); 
        	 	break;
        	default:
        	    break;
        }
        if(FirstRead == SecondRead) 
            return NO_ERR;
    }while(TryingNo--);
	return ERROR;
}//... DataToggle(...)
static WORD DefaultWriting(volatile WORD WriteAddress, WORD BufferAddress, const WORD Count, const WORD VerifyFlag, WORD BusType)
{
	WORD i;
	
	switch(GETWIDTH(BusType))
	{
	    case WIDTH_WORD:
        	for(i = ( Count >> 2 ) ; i != 0 ; i--)  // 32-bits
        	{
        		ControlFlash(WriteAddress, FC_WRITE, BusType );
        		REGISTER32(WriteAddress)  = REGISTER32(BufferAddress);
        		if(DataToggle(WriteAddress,BusType) != NO_ERR )
        			return ERR_FLASHWR_WAIT;
        		if(VerifyFlag){
        			if( REGISTER32(WriteAddress) != REGISTER32(BufferAddress) )
        				return ERR_FLASHWR_VALIDATE;
        		}
        		WriteAddress += 4;  // 32-bits
        		BufferAddress += 4;//Next pointer
        	}
        	break;
         case WIDTH_HWORD:
        	for(i = ( Count >> 1 ) ; i != 0 ; i--)  // 16-bits
        	{
        		ControlFlash(WriteAddress, FC_WRITE, BusType );
        		REGISTER16(WriteAddress)  = REGISTER16(BufferAddress);
        		if(DataToggle(WriteAddress, BusType) != NO_ERR )
        			return ERR_FLASHWR_WAIT;
        		if(VerifyFlag)
        		{
        			if( REGISTER16(WriteAddress) != REGISTER16(BufferAddress) )
        				return ERR_FLASHWR_VALIDATE;
        		}
        		WriteAddress += 2;  // 16-bits
        		BufferAddress += 2;//Next pointer
        	}
        	break;
        default:
            break;
    }	
	return NO_ERR;
}// ...DefaultWriting(...)

