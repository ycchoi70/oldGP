#include <string.h>
//#include "CPU7014.h"
#include "define.h"
#include "Commbuff.h"

#define	TBQ(a)	(sizeof(a)/sizeof(a[0]))

#define	CONT_10MS		8949	/* 28.63636MHZ(1/32) 1.117 us = 8949*/
#define	CONT_400US		 358	/* 28.63636MHZ(1/32) 1.117 us = 358*/
#define	CONT_200US		 179	/* 28.63636MHZ(1/32) 1.117 us = 358*/

typedef struct{
	int type;
	void	*ptr;
	int  dat;
} InitDataTblFrm;

extern	void	di(void);
extern	void	ei(void);

/****************************************************************************
*	�@�\	CPU�������Ӄ��W���[���̏�����
*	����	
*	�ߒl	
*	���l	
****************************************************************************/
void SetCPU( void )
{
	int i;
	unsigned char *cp;
	unsigned short *sp;
	unsigned int	*wp;

	InitDataTblFrm InitDataTbl[] = {
		{1,	(void *)CPU_SMR0,		0x00},		/* SCI */
		{1,	(void *)CPU_BRR0,		0x00},
		{1,	(void *)CPU_SCR0,		0x00},
		{1,	(void *)CPU_TDR0,		0x00},
		{1,	(void *)CPU_SSR0,		0x00},
		{1,	(void *)CPU_RDR0,		0x00},
		{1,	(void *)CPU_SMR1,		0x00},
		{1,	(void *)CPU_BRR1,		0x00},
		{1,	(void *)CPU_SCR1,		0x00},
		{1,	(void *)CPU_TDR1,		0x00},
		{1,	(void *)CPU_SSR1,		0x00},
		{1,	(void *)CPU_RDR1,		0x00},

		{1, (void *)CPU_TSTR,		0x00},		/* MTU */
		{1,	(void *)CPU_TSYR,		0x00},
		{1,	(void *)CPU_TCR0,		0x00},
		{1,	(void *)CPU_TMDR0,		0x00},
		{1,	(void *)CPU_TIOR0H,		0x00},
		{1,	(void *)CPU_TIOR0L,		0x00},
		{1,	(void *)CPU_TIER0,		0x00},
		{1,	(void *)CPU_TSR0,		0x00},
		{2,	(void *)CPU_TCNT0,		0x0000},
		{2,	(void *)CPU_TGR0A,		0x0000},
		{2,	(void *)CPU_TGR0B,		0x0000},
		{2,	(void *)CPU_TGR0C,		0x0000},
		{2,	(void *)CPU_TGR0D,		0x0000},
		{1,	(void *)CPU_TCR1,		0x00},
		{1,	(void *)CPU_TMDR1,		0x00},
		{1,	(void *)CPU_TIOR1,		0x00},
		{1,	(void *)CPU_TIER1,		0x00},
		{1,	(void *)CPU_TSR1,		0x00},
		{2,	(void *)CPU_TCNT1,		0x0000},
		{2,	(void *)CPU_TGR1A,		0x0000},
		{2,	(void *)CPU_TGR1B,		0x0000},
		{1,	(void *)CPU_TCR2,		0x00},
		{1,	(void *)CPU_TMDR2,		0x00},
		{1,	(void *)CPU_TIOR2,		0x00},
		{1,	(void *)CPU_TIER2,		0x00},
		{1,	(void *)CPU_TSR2,		0x00},
		{2,	(void *)CPU_TCNT2,		0x0000},
		{2,	(void *)CPU_TGR2A,		0x0000},
		{2,	(void *)CPU_TGR2B,		0x0000},

		{2,	(void *)CPU_IPRA,		0x0000},	/* INTC */
		{2,	(void *)CPU_IPRB,		0x0000},
		{2,	(void *)CPU_IPRC,		0x0000},
		{2,	(void *)CPU_IPRD,		0x0000},
		{2,	(void *)CPU_IPRE,		0x0000},
		{2,	(void *)CPU_IPRF,		0x0000},
		{2,	(void *)CPU_IPRG,		0x0000},
		{2,	(void *)CPU_IPRH,		0x0000},
		{2,	(void *)CPU_ICR,		0x0000},
		{2,	(void *)CPU_ISR,		0x0000},

		{2,	(void *)CPU_PADRL,		0x0000},	/* I/O,PFC */
		{2,	(void *)CPU_PAIORL,		0x0000},
		{2,	(void *)CPU_PACRL1,		0x0000},
		{2,	(void *)CPU_PACRL2,		0x0000},
		{2,	(void *)CPU_PBDR,		0x0000},
		{2,	(void *)CPU_PCDR,		0x0000},
		{2,	(void *)CPU_PBIOR,		0x0000},
		{2,	(void *)CPU_PCIOR,		0x0000},
		{2,	(void *)CPU_PBCR1,		0x0000},
		{2,	(void *)CPU_PBCR2,		0x0000},
		{2,	(void *)CPU_PCCR,		0x0000},
		{2,	(void *)CPU_PDDRL,		0x0000},
		{2,	(void *)CPU_PDIORL,		0x0000},
		{2,	(void *)CPU_PDCRL,		0x0000},
		{2,	(void *)CPU_PEDR,		0x0000},
		{1,	(void *)CPU_PFDR,		0x0000},
		{2,	(void *)CPU_PEIOR,		0x0000},
		{2,	(void *)CPU_PECR1,		0x0000},
		{2,	(void *)CPU_PECR2,		0x0000},

		{2,	(void *)CPU_CMSTR,		0x0000},	/* CMT */
		{2,	(void *)CPU_CMCSR0,		0x0000},
		{2,	(void *)CPU_CMCNT0,		0x0000},
		{2,	(void *)CPU_CMCOR0,		0x0000},
		{2,	(void *)CPU_CMCSR1,		0x0000},
		{2,	(void *)CPU_CMCOR1,		0x0000},

		{1,	(void *)CPU_ADCSR,		0x00},		/* A/D */
		{1,	(void *)CPU_ADCR,		0x00},
		{2,	(void *)CPU_ADDRA,		0x0000},
		{2,	(void *)CPU_ADDRB,		0x0000},
		{2,	(void *)CPU_ADDRC,		0x0000},
		{2,	(void *)CPU_ADDRD,		0x0000},
		{2,	(void *)CPU_ADDRE,		0x0000},
		{2,	(void *)CPU_ADDRF,		0x0000},
		{2,	(void *)CPU_ADDRG,		0x0000},
		{2,	(void *)CPU_ADDRH,		0x0000},

		{1,	(void *)CPU_TCSR,		0x00},			/* WDT */
		{1,	(void *)CPU_TCNTW,		0x00},
		{1,	(void *)CPU_RSTCSRW,	0x00},
		{1,	(void *)CPU_RSTCSRR,	0x00},
		{1,	(void *)CPU_SBYCR,		0x00},

		{2,	(void *)CPU_BCR1,		0x4000},		/* BSC */
		{2,	(void *)CPU_BCR2,		0x1440},
		{2,	(void *)CPU_WCR1,		0x1440},
		{2,	(void *)CPU_WCR2,		0x1440},
		{2,	(void *)CPU_DCR,		0x0000},
		{2,	(void *)CPU_RTCSR,		0x0000},
		{2,	(void *)CPU_RTCNT,		0x0000},
		{2,	(void *)CPU_RTCOR,		0x0000},

		{2,	(void *)CPU_DMAOR,		0x0000},			/*�@DMA */
		{4,	(void *)CPU_SAR0,		0x00000000},
		{4,	(void *)CPU_DAR0,		0x00000000},
		{4,	(void *)CPU_DMATCR0,	0x00000000},
		{4,	(void *)CPU_CHCR0,		0x00000000},
		{4,	(void *)CPU_SAR1,		0x00000000},
		{4,	(void *)CPU_DAR1,		0x00000000},
		{4,	(void *)CPU_DMATCR1,	0x00000000},
		{4,	(void *)CPU_CHCR1,		0x00000000},

		{2,	(void *)CPU_CCR,		0x0000},			/*�@CAC */

	};
	
	for( i= 0; i < TBQ(InitDataTbl); i++ ){
		switch( InitDataTbl[i].type ){
		case 1:
			cp= (unsigned char  *)InitDataTbl[i].ptr;
			*cp= (unsigned char)InitDataTbl[i].dat;
			break;
		case 2:
			sp= (unsigned short *)InitDataTbl[i].ptr;
			*sp= (unsigned short)InitDataTbl[i].dat;
			break;
		case 4:
			wp= (unsigned int *)InitDataTbl[i].ptr;
			*wp= (unsigned int)InitDataTbl[i].dat;
			break;
		}
	}
}
void	IoPortRam( void )
{
	PortA = 0xfd5f;
	PortB = 0x0018;
	PortBIOR = 0x021c;
	PortE = 0xffee;
}
void	PinConfig(void)
{
	unsigned short	data;
	extern	void	LCD_Clear();

	*(unsigned short *)CPU_PACRL1 = 0;
	*(unsigned short *)CPU_PACRL2 = 0xa145;
	*(unsigned short *)CPU_PADRL = 0x8000;
	PortA = 0x8000;
	*(unsigned short *)CPU_PAIORL = 0x8200;
	*(unsigned short *)CPU_PBCR2 = 0xa400;
	*(unsigned short *)CPU_PBDR = 0x0018;	/* RTC DATA,CLOCK */
	PortB = 0x0018;
	*(unsigned short *)CPU_PBIOR = 0x021c;
	PortBIOR = 0x021c;
	*(unsigned short *)CPU_PECR1 = 0;
	*(unsigned short *)CPU_PECR2 = 0x0100;
	*(unsigned short *)CPU_PEDR = 0xffee;
	*(unsigned short *)CPU_PEIOR = 0xfffe;
	PortE = 0xffee;
	/* SCI */
	*(unsigned char *)CPU_SMR0 = 0x00;
	*(unsigned char *)CPU_BRR0 = 0x00;
	*(unsigned char *)CPU_SCR0 = 0x00;
	*(unsigned char *)CPU_TDR0 = 0x00;
	*(unsigned char *)CPU_SSR0 = 0x00;
	*(unsigned char *)CPU_RDR0 = 0x00;
	*(unsigned char *)CPU_SMR1 = 0x00;
	*(unsigned char *)CPU_BRR1 = 0x00;
	*(unsigned char *)CPU_SCR1 = 0x00;
	*(unsigned char *)CPU_TDR1 = 0x00;
	*(unsigned char *)CPU_SSR1 = 0x00;
	*(unsigned char *)CPU_RDR1 = 0x00;
	/* MTU */
	*(unsigned char *)CPU_TCR0 = 0;
	*(unsigned char *)CPU_TMDR0 = 0xc0;
	*(unsigned char *)CPU_TIOR0H = 0;
	*(unsigned char *)CPU_TIOR0L = 0;
	*(unsigned char *)CPU_TSR0 = 0xc0;
	*(unsigned short *)CPU_TCNT0 = 0x0000;
	*(unsigned short *)CPU_TGR0A = 0x0000;
	*(unsigned short *)CPU_TGR0B = 0x0000;
	*(unsigned short *)CPU_TGR0C = 0x0000;
	*(unsigned short *)CPU_TGR0D = 0x0000;
	*(unsigned char *)CPU_TIER0 = 0x40;
	*(unsigned char *)CPU_TCR1 = 0x22;
	*(unsigned char *)CPU_TMDR1 = 0xc0;
	*(unsigned char *)CPU_TIOR1 = 0;
	*(unsigned char *)CPU_TSR1 = 0xc0;
	*(unsigned short *)CPU_TCNT1 = 0x0000;
	*(unsigned short *)CPU_TGR1A = 0x00da;
	*(unsigned short *)CPU_TGR1B = 0x0000;
	*(unsigned char *)CPU_TIER1 = 0x40;
	*(unsigned char *)CPU_TCR2 = 0x00;
	*(unsigned char *)CPU_TMDR2 = 0xc0;
	*(unsigned char *)CPU_TIOR2 = 0;
	*(unsigned char *)CPU_TSR2 = 0xc0;
	*(unsigned short *)CPU_TCNT2 = 0x0000;
	*(unsigned short *)CPU_TGR2A = 0x0000;
	*(unsigned short *)CPU_TGR2B = 0x0000;
	*(unsigned char *)CPU_TIER2 = 0x40;
	*(unsigned char *)CPU_TSTR = 0x02;
#ifdef	OLD
	/* Interrupt */
	*(unsigned short *)CPU_IPRA = 0x0000;
	*(unsigned short *)CPU_IPRB = 0x0000;
	*(unsigned short *)CPU_IPRC = 0xeeee;
	*(unsigned short *)CPU_IPRD = 0xeefe;
	*(unsigned short *)CPU_IPRE = 0xeeee;
	*(unsigned short *)CPU_IPRF = 0xeeff;
	*(unsigned short *)CPU_IPRG = 0xeefe;
	*(unsigned short *)CPU_IPRH = 0xeeee;
	*(unsigned short *)CPU_ICR = 0x0000;
	*(unsigned short *)CPU_ISR = 0x0000;
#else
	*(unsigned short *)CPU_IPRA = 0x0000;
	*(unsigned short *)CPU_IPRB = 0x0000;
	*(unsigned short *)CPU_IPRC = 0x0000;
	*(unsigned short *)CPU_IPRD = 0x0000;
	*(unsigned short *)CPU_IPRE = 0x0000;
	*(unsigned short *)CPU_IPRF = 0x0000;
	*(unsigned short *)CPU_IPRG = 0x000d;		/* CMT */
	*(unsigned short *)CPU_IPRH = 0x0000;
	*(unsigned short *)CPU_ICR = 0x0000;
	*(unsigned short *)CPU_ISR = 0x0000;
#endif
	/* CMT */
	*(unsigned short *)CPU_CMSTR = 0x0000;
	*(unsigned short *)CPU_CMCNT0 = 0x0000;
	*(unsigned short *)CPU_CMCOR0 = CONT_400US;
	*(unsigned short *)CPU_CMCSR0 = 0x0041;
	*(unsigned short *)CPU_CMCNT1 = 0x0000;
	*(unsigned short *)CPU_CMCOR1 = CONT_10MS;
	*(unsigned short *)CPU_CMCSR1 = 0x0041;
	/* A/D */
	*(unsigned char *)CPU_ADCSR = 0x00;
	*(unsigned char *)CPU_ADCR = 0x00;
	*(unsigned short *)CPU_ADDRA = 0x0000;
	*(unsigned short *)CPU_ADDRB = 0x0000;
	*(unsigned short *)CPU_ADDRC = 0x0000;
	*(unsigned short *)CPU_ADDRD = 0x0000;
	*(unsigned short *)CPU_ADDRE = 0x0000;
	*(unsigned short *)CPU_ADDRF = 0x0000;
	*(unsigned short *)CPU_ADDRG = 0x0000;
	*(unsigned short *)CPU_ADDRH = 0x0000;
	/* W/D */
	*(unsigned char *)CPU_TCSR = 0x00;
	*(unsigned char *)CPU_TCNTW = 0x00;
	*(unsigned char *)CPU_RSTCSRW = 0x00;
	*(unsigned char *)CPU_RSTCSRR = 0x00;
	*(unsigned char *)CPU_SBYCR = 0x00;
	/* BSC */
	*(unsigned short *)CPU_BCR1 = 0x2007;
	*(unsigned short *)CPU_BCR2 = 0x4088;
	*(unsigned short *)CPU_WCR1 = 0x7211;
	*(unsigned short *)CPU_WCR2 = 0x0000;
	*(unsigned short *)CPU_DCR = 0x0534;
	*(unsigned short *)CPU_RTCSR = 0x0012;
	*(unsigned short *)CPU_RTCNT = 0x0000;
	*(unsigned short *)CPU_RTCOR = 0x0038;
	/* DMAC */
	*(unsigned short *)CPU_DMAOR = 0x0000;
	*(unsigned char *)CPU_SAR0 = 0x0000;
	*(unsigned long *)CPU_DAR0 = 0x00000000;
	*(unsigned long *)CPU_DMATCR0 = 0x00000000;
	*(unsigned long *)CPU_CHCR0 = 0x00000000;
	*(unsigned long *)CPU_SAR1 = 0x00000000;
	*(unsigned long *)CPU_DAR1 = 0x00000000;
	*(unsigned long *)CPU_DMATCR1 = 0x00000000;
	/* LCD */
	LCD_Clear();
	/* PIO */
	*(unsigned short *)CPU_PADRL = 0xfddf;
	PortA = 0xfddf;
	*(unsigned short *)CPU_PEDR = 0xffee;

	*(unsigned short *)CPU_CMSTR = 0x0002;		/* CMT1 Sart */

/*	memcpy((char *)0xfffff800,(char *)DISP_AREA,0x400);*/
}
void InitCPU( void )
{
/*	SetCPU();*/
	PinConfig();
}
void	CashOn( void )
{
#ifdef	WIN32
#else
	di();
	*(unsigned short *)CPU_CCR= 0x0000;
	memset((char *)0xfffff000,0,0x400);
	*(unsigned short *)CPU_CCR= 0x0005;
	ei();
#endif
}
void	CashOff( void )
{
#ifdef	WIN32
#else
	di();
	*(unsigned short *)CPU_CCR= 0x0000;
	memcpy((char *)0xfffff000,(char *)0x0000f000,0x800);
	ei();
#endif
}
