/******************************************************************************
*                         (�L)�R?�e�b�N 2001,2002                           
*******************************************************************************
* System             :FlashRom Filesystem                                   
* FileName           :Gb_filesys.c                                          
* Summary            :�t���b�V���t?�C���V�X�e?�֘A��?���s���܂��B          
* Programmer         :�S�ωp                                               
* Create Date        :2002/02/26                                           
******************************************************************************/
#ifdef	WIN32
#include <memory.h>
#include <time.h>
#endif
#include	"sgt.h"

extern	int		RewriteFlag;

I_FILE *GIO_BUF;

#ifdef	WIN32
char	strDirBuff[0x2000];
#endif
/******************************************************************************
'Procedure          :init_filesystem
'Summary            :̧�ټ��т̏���������
'Parameters         :�Ȃ�
'Return Value       :�Ȃ�
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
void init_filesystem()
{	int i;

    if ( GIO_BUF == NULL ) {
#ifdef	WIN32
		GIO_BUF=(I_FILE *)strDirBuff;
#else
        GIO_BUF=(I_FILE *)TakeMemory(sizeof(I_FILE)*MAX_FILE);
#endif
        FM_init();		
		for(i=0;i<MAX_FILE;i++){
			GIO_BUF[i].device_no=0x00;
		}
    }

    return;
}

/******************************************************************************
'Procedure          :isfilename
'Summary            :MS-DOS�g�p��?��������
'Parameters         :����
'Return Value       :1,0,-1,-3
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int isfilename(char c)
{
  /* �l�r?�c�n�r�̃t?�C�����Ŏg�p��?�ȕ����𔻒肷�� */
  /* �P�̂Ƃ��g�p��?�ȕ��� */
  switch(c&0xff) {
    case 'A': case 'B': case 'C': case 'D':
    case 'E': case 'F': case 'G': case 'H':
    case 'I': case 'J': case 'K': case 'L':
    case 'M': case 'N': case 'O': case 'P':
    case 'Q': case 'R': case 'S': case 'T':
    case 'U': case 'V': case 'W': case 'X':
    case 'Y': case 'Z':
    case '0': case '1': case '2': case '3':
    case '4': case '5': case '6': case '7':
    case '8': case '9':
    case '$': case '&': case '#': case '%':
    case '\'':  case '(': case ')': case '-':
    case '@': case '_': case '^': case '{':
    case '}': case '~': case '`': case '!':
    case ' ':
        return(1);
    case '\0':
        return(0);
    case '.':
        return(-1);
    default:
        return(-3);
  }
}

/******************************************************************************
'Procedure          :name_ana
'Summary            :�t?�C����?�g���q�ϊ�
'Parameters         :�ϊ���o�b�t?�A�ϊ����o�b�t?
'Return Value       :OK(0),ERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int  name_ana(char dst[],char name[])
{
    /* �啶���̃t?�C����?�g���q�ɕϊ����� */
    int i,rp;
	char	wName[32];

    rp = 0;
    /* ���������łȂ��� */
    if(name[0]=='\0'){
        return(GP_ERROR);
    }
    /* ��������啶���ɕϊ����� */
    for(i=0;name[i]!='\0';i++){
		if((name[i] >= 'a') && (name[i] <= 'z')){
			wName[i]= name[i]- 'a' + 'A';
		}else{
			wName[i]= name[i];
		}
    }
	wName[i]= 0;
    /* �t?�C�����W�����̏��� */
    for(i=0;i<8;i++){
		if(wName[rp] == '?'){
			dst[i]=wName[rp++];
		}else if(isfilename(wName[rp])>0){
            dst[i]=wName[rp++];
        }else{
            dst[i]=' ';
        }
    }
    /* �D��?�F�b�N */
    switch(isfilename(wName[rp])) {
        case -1:
            rp++;
            break;
        case  1:
            return(GP_ERROR);
    }
    /* �g���q�R�����̏��� */
    for(;i<11;i++){
		if(wName[rp] == '?'){
			dst[i]=wName[rp++];
		}else if(isfilename(wName[rp])>0){
	        dst[i]=wName[rp++];
        }else{
            dst[i]=' ';
        }
    }
    for(i = 0; i < 11; i++){
        if(dst[i] != ' '){
            break;
        }
    }
    if(i == 11){
        return(GP_ERROR);
    }
    /* �S�����ڂ���������G��? */
    if(isfilename(wName[rp])>0){
        return(GP_ERROR);
    }else{
        return(OK);
    }
}
/******************************************************************************
'Procedure          :chkdupopen
'Summary            :��d��������?
'Parameters         :�t?�C����?�g���q
'Return Value       :OK(0),ERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int  chkdupopen(char f_name[])
{
    int i;
    for(i=0;i<MAX_FILE;i++) {
/*		if(GIO_BUF[i].device_no==0x01) {*/
		if(GIO_BUF[i].device_no != 0x00) {
		  if(0==memcmp(GIO_BUF[i].name,f_name,8+3)) {
			return(GP_ERROR);
		  }
		}
    }
    return(OK);
}
/******************************************************************************
'Procedure          :mopen
'Summary            :̧�ٵ���?
'Parameters         :�t?�C�����A��?�h
'Return Value       :IO_BUF Index(i),ERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int mopen( char name[], int mode)
{
    int ret;
    unsigned int  i;
	int	devno;
    char    f_name[8+3];

/*    init_filesystem();*/
	devno= 0;
	if(memcmp(name,"B:",2) == 0){
		devno= 1;
		name += 2;
	}
    if( name_ana(f_name,name)<0 ){
      return ( GP_ERROR );
    }

#if _ON_DEBUG==1
printf("mopen 01\n");
#endif

    if((ret=chkdupopen(f_name))!=0){
         return( GP_ERROR );
    }
    /* �󂢂Ă���GIO_BUF�̃T?? */
    for(i=0;i<MAX_FILE;i++){
        if(GIO_BUF[i].device_no == 0x00){
          break;
        }
    }

#if _ON_DEBUG==1
printf("mopen 02\n");
#endif

    if(i==MAX_FILE){
        return(GP_ERROR);
    }

#if _ON_DEBUG==1
printf("mopen 03\n");
#endif

    /* �t?�C������ݒ肵�Ă��ꂼ��̃�?�h�ŃI?�v�� */
	if(devno == 0){
	    GIO_BUF[i].device_no =0x01;                   /* open�t���O�Z�b�g*/
	}else{
	    GIO_BUF[i].device_no =0x02;                   /* open�t���O�Z�b�g*/
	}
    memcpy(GIO_BUF[i].name,f_name,8+3);           /* �t?�C����?�g���q*/
    if ( (mode & _O_RDONLY) == _O_RDONLY ){       /* �I?�v������*/
      GIO_BUF[i].mode=MODE_READ;
    }
    else if ( (mode & _O_APPEND) == _O_APPEND ){
      GIO_BUF[i].mode=MODE_APPEND;
    }
    else{
      GIO_BUF[i].mode=MODE_WRITE;
    }
    GIO_BUF[i].time=GpGetCurrentTime();             /* �V�X�e?����*/
    GIO_BUF[i].date=GetCurrentDate();             /* �V�X�e?���t*/

	if(devno == 0){
	    ret = FM_Open(&GIO_BUF[i]);
	}else{
	    ret = FM_Open2(&GIO_BUF[i]);
	}
    if(ret == 0){
       return(i);
    }
#if _ON_DEBUG==1
printf("mopen 04\n");
#endif
    /* open���s*/
    GIO_BUF[i].device_no=0x00;
    return(GP_ERROR);
}

/******************************************************************************
'Procedure          :mclose
'Summary            :̧�ٸ۰�?
'Parameters         :IO_BUF Index
'Return Value       :OK(0),ERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int	mfileDelete(int flag,int hdl)
{
    I_FILE *id;

	if(flag >= 0){
		return(0);
	}
    if(hdl<0 || hdl>=MAX_FILE){
        return(GP_ERROR);
    }
    id=&GIO_BUF[hdl];
    if(id->device_no==0x00){
        return(GP_ERROR);
    }
    id->name[0]= 0xE5;
    return(0);
}
int mclose(int hdl)
{
    int ret=-1;
    I_FILE *id;

    if(hdl<0 || hdl>=MAX_FILE){
        return(GP_ERROR);
    }
    id=&GIO_BUF[hdl];
    if(id->device_no==0x00){
        return(GP_ERROR);
    }
	if(id->device_no == 0x01){
	    ret=FM_Close(id);
	}else{
	    ret=FM_Close2(id);
	}
    id->device_no=0x00;
    return(ret);
}
/******************************************************************************
'Procedure          :mread
'Summary            :̧��ذ��
'Parameters         :IO_BUF Index�A��?�h��o�b�t?�A�T�C�Y
'Return Value       :�Ǎ��񂾃T�C�Y�AERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int mread(int hdl, void *buf,unsigned int lcnt)
{
    I_FILE *id;
    /* �ő僊?�h�T�C�Y*/
/*    if( lcnt > 65534 ){
      return(GP_ERROR);
    }
*/
    if(hdl<0 || hdl>=MAX_FILE){
        return(GP_ERROR);
    }
    id=&GIO_BUF[hdl];
    if(id->device_no==0x00){
        return(GP_ERROR);
    }
    if(lcnt==0){
        return(0);
    }
	if(id->device_no == 0x01){
	    return(FM_ReadHandle((char *)buf,lcnt,id));
	}else{
	    return(FM_ReadHandle2((char *)buf,lcnt,id));
	}
}
/******************************************************************************
'Procedure          :mwrite
'Summary            :̧�ُ�������
'Parameters         :IO_BUF Index�A�����݌��o�b�t?�A�T�C�Y
'Return Value       :�������񂾃T�C�Y�AERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int mwrite(int hdl, void *buf,unsigned int lcnt)
{
    I_FILE *id;
    /* �ő发���݃T�C�Y*/
/*
    if( lcnt > 65533 ){
      return(GP_ERROR);
    }
*/
    if(hdl<0 || hdl>=MAX_FILE){
        return(GP_ERROR);
    }
    id=&GIO_BUF[hdl];
    if(id->device_no==0x00){
        return(GP_ERROR);
    }
    if(id->mode==MODE_READ){
        return(GP_ERROR);
    }
    if(lcnt==0){
        return(0);
    }
	if(id->device_no == 0x01){
	    return(FM_WriteHandle((char *)buf,lcnt,id));
	}else{
	    return(FM_WriteHandle2((char *)buf,lcnt,id));
	}
}

/******************************************************************************
'Procedure          :mseek
'Summary            :̧���߲���??
'Parameters         :IO_BUF Index�Aorigin ����̃o�C�g���A�����ʒu
'Return Value       :OK(0),GP_ERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
long mseek(int hdl, long offset,short origin)
{
    I_FILE          *id;

    if(hdl<0 || hdl>=MAX_FILE){
        return(GP_ERROR);
    }
    id=&GIO_BUF[hdl];
    if(id->device_no==0x00){
        return(GP_ERROR);
    }
	if(id->device_no == 0x01){
	    return(FM_MoveFilePointer(offset,origin,id));
	}else{
	    return(FM_MoveFilePointer2(offset,origin,id));
	}
}

/******************************************************************************
'Procedure          :mgetdiskfree
'Summary            :�󂫗e�ʎ��o��
'Parameters         :�󂫃N���X?���A�Z�N?�T�C�Y�A�S�N���X?��
'Return Value       :OK(0),ERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int mgetdiskfree(short *bx,short *cx,short *dx)
{
  return(FM_GetDiskSpace(0,bx,cx,dx));
}
int mgetdiskfree2(short *bx,short *cx,short *dx)
{
  return(FM_GetDiskSpace(1,bx,cx,dx));
}
/******************************************************************************
'Procedure          :mformat
'Summary            :�t���b�V���t?�C���V�X�e?�t�H??�b�g
'Parameters         :�Ȃ�
'Return Value       :OK(0),ERROR(-1)
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
int mformat(void)
{
    /*register  int ret;*/
    int ret;

    ret = FM_fmt_write(); /* format data write */
    if ( ret == 0 ){
        return ( OK );
    }else{
        return ( GP_ERROR  );
    }

}
int mformat2(void)
{
    /*register  int ret;*/
    int ret;

    ret = FM_fmt_write2(); /* format data write */
    if ( ret == 0 ){
        return ( OK );
    }else{
        return ( GP_ERROR  );
    }

}
/******************************************************************************
'Procedure          :mtell
'Summary            :�t?�C�� ?�C��?�̌��݈ʒu�𓾂܂��B
'Parameters         :IO_BUF Index
'Return Value       :�t?�C�� ?�C��?�̌��݈ʒu
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
long  mtell(int handle)
{
    I_FILE *id;

    if(handle < 0 || handle >= MAX_FILE){
        return(GP_ERROR );
    }
    id=&GIO_BUF[handle];
    if(id->device_no==0x00){
        return(GP_ERROR );
    }
    return(id->pos);
}


/******************************************************************************
'Procedure          :GetCurrentDate
'Summary            :�V�X�e?���t�����߂�
'Parameters         :�Ȃ�
'Return Value       :���t
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
short   GetCurrentDate( void )
{
    int     d,m,y;
    short   Date;
#ifdef	WIN32
    time_t tt;
    struct tm  *tp;

    time(&tt);
    tp = localtime(&tt);
    y =                 tp->tm_year+ 1900;
    m = (unsigned char) tp->tm_mon + 1;
    d = (unsigned char) tp->tm_mday;
#else
	y = SystemTime.year;
	m = SystemTime.mon;
	d = SystemTime.day;
#endif
    Date = (short)((y << 9) + (m << 5) + d);

    return(Date);
}
/******************************************************************************
'Procedure          :GetCurrentTime
'Summary            :�V�X�e?���������߂�
'Parameters         :�Ȃ�
'Return Value       :����
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
short   GpGetCurrentTime( void )
{
    int s,m,h;
    short   Time;
#ifdef	WIN32
    time_t tt;
    struct tm  *tp;

    time(&tt);
    tp = localtime(&tt);
    h    = (unsigned char) tp->tm_hour;
    m    = (unsigned char) tp->tm_min;
    s    = (unsigned char) tp->tm_sec;
#else
    h    = (unsigned char) SystemTime.hour;
    m    = (unsigned char) SystemTime.min;
    s    = (unsigned char) SystemTime.sec;
#endif
    /* Time data */
    Time = (short)((h << 11) + (m << 5) + (s >> 1));

    return(Time);
}
/******************************************************************************
'Procedure          :exit_filesystem
'Summary            :̧�ټ��т̏I������
'Parameters         :�Ȃ�
'Return Value       :�Ȃ�
'Comments           :
'Programmer         :�S�ωp
'Create Date        :2002/02/26
******************************************************************************/
void exit_filesystem(void)
{
    if ( GIO_BUF != NULL ) {
        FreeMail((char *)GIO_BUF);
    }
}
/******************************************************************
Fined First
*******************************************************************/
int	m_findfirst(char *wildspec, unsigned attr, struct find_t *finddata)
{
    int ret;
    unsigned int  i,j,k;
	char	name[8+3];
    char    f_name[8+3];
	I_FILE	ip;


	for(i = 0,j = 0; i < 8; i++){
		if(wildspec[i] == '*'){
			for(;j < 8; j++){
				name[j]= '?';
			}
			break;
		}
		if(wildspec[i] == 0){
			break;
		}
		name[j++] = wildspec[i];
	}
/*	name[j++]= '.';*/

	for(;i < 8; i++){
		if(wildspec[i] == '.'){
			i++;
			break;
		}else if(wildspec[i] == 0){
			break;
		}
	}
	for(k = 0;(i < 8+ 4) && (k < 3); i++,k++){
		if(wildspec[i] == 0){
			break;
		}
		if(wildspec[i] == '*'){
			for(; k < 3; k++){
				name[j++]= '?';
			}
			break;
		}
		name[j++]= wildspec[i];
	}
	name[j++]= 0;

    if( name_ana(f_name,name)<0 ){
      return ( GP_ERROR );
    }
	memcpy(finddata->reserved,name,11);
    
	if((ret=chkdupopen(f_name))!=0){
         return( GP_ERROR );
    }
    /* �t?�C������ݒ肵�Ă��ꂼ��̃�?�h�ŃI?�v�� */
    ip.device_no =0x01;                   /* open�t���O�Z�b�g*/
    memcpy(ip.name,f_name,8+3);           /* �t?�C����?�g���q*/
	ip.mode=MODE_READ;

    ret = FM_find_dir((char *)&ip.name,&ip,0,0);
    if(ret == 0){
		memcpy(&finddata->name,ip.name,12);
		finddata->name[12]= 0;
		finddata->attrib= ip.attr;
		finddata->size= ip.size;
		finddata->wr_date= ip.date;
		finddata->wr_time= ip.time;
	    memcpy(finddata->reserved,f_name,8+3);           /* �t?�C����?�g���q*/
		ip.dir_pos+= sizeof(struct dir);
		if(ip.dir_pos >= (512- sizeof(struct dir)+ 1)){
			ip.dir_sect++;
			ip.dir_pos= 0;
		}
		finddata->reserved[14]= (unsigned char)(ip.dir_sect/ 0x100);
		finddata->reserved[15]= (unsigned char)(ip.dir_sect% 0x100);
		finddata->reserved[16]= (unsigned char)(ip.dir_pos/ 0x100);
		finddata->reserved[17]= (unsigned char)(ip.dir_pos% 0x100);
		return(OK);
    }
	return(GP_ERROR);
}
int	m_findnext(struct find_t *finddata)
{
	int		ret;
	I_FILE	ip;
	int		sect;
	int		pos;

    ip.device_no =0x01;                   /* open�t���O�Z�b�g*/
    memcpy(ip.name,finddata->reserved,8+3);           /* �t?�C����?�g���q*/
	ip.mode=MODE_READ;
		sect= finddata->reserved[14]* 0x100;
		sect+= finddata->reserved[15];
		pos= finddata->reserved[16]* 0x100;
		pos+= finddata->reserved[17];

    ret = FM_find_dir((char *)&ip.name,&ip,sect,pos);
    if(ret == 0){
		memcpy(&finddata->name,ip.name,12);
		finddata->name[12]= 0;
		finddata->attrib= ip.attr;
		finddata->size= ip.size;
		finddata->wr_date= ip.date;
		finddata->wr_time= ip.time;
		ip.dir_pos+= sizeof(struct dir);
		if(ip.dir_pos >= (512- sizeof(struct dir)+ 1)){
			ip.dir_sect++;
			ip.dir_pos= 0;
		}
		finddata->reserved[14]= (unsigned char)(ip.dir_sect/ 0x100);
		finddata->reserved[15]= (unsigned char)(ip.dir_sect% 0x100);
		finddata->reserved[16]= (unsigned char)(ip.dir_pos/ 0x100);
		finddata->reserved[17]= (unsigned char)(ip.dir_pos% 0x100);
		return(OK);
    }
	return(GP_ERROR);
}
int	mfileserch(char *filename,int *pos,int *size)
{
	int		ret;
	long sectp;
	short attr;

	ret= FM_GetFileInfo(0,filename,&sectp,&attr,(long *)size);
	if(ret == OK){
		*pos= SetMemAddr((int)sectp);
	}
	return(ret);
}
int	mfileserch2(char *filename,int *pos,int *size)
{
	int		ret;
	long sectp;
	short attr;

	ret= FM_GetFileInfo(1,filename,&sectp,&attr,(long *)size);
	if(ret == OK){
		*pos= SetMemAddr2((int)sectp);
	}
	return(ret);
}

/*********************************** END OF FILE *****************************/
