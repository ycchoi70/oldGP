//////////////////////////////////////////////////////////////////////////
// InterPreter.cpp :
/**************************************************************
*   Update:07.10.17 M.Owashi
*           [keyword:GLP_071017] ���ꃌ�W�X?�A���荞�ݏ����Ή�
***************************************************************/


#define	INTER_PROC	1
//#define	DATA_FILE	1	//For Debug


#include	"sgt.h"

#include    "numnictbl.h"
#include "IPDefines.h"
#include "EachRoutins.h"
#include "Matrix.h"
#include "S3c44b0x.h"
#include    "Mtsscid.h"
#include    "Mtsschdp.h"
#include    "selib.h"


#ifdef	LP_S044


#ifdef	WIN32
extern	void BitDevYOnOffWin32(int nOnBits);
extern	void BitDevYOnOffWin32T(int nOnBits);
extern	void BitDevYOnOffWin32C(int nOnBits);
extern	void WordDevD0D1(unsigned short d[]);
extern	void BitDevXOnOffWin32(void);
extern	unsigned int	Xdevice;
extern	unsigned int	Tdevice;
extern	unsigned int	Cdevice;
extern	void BitRunOnOffWin32C(int nOnBits);
#endif

unsigned short WorkY[Device_Length_Y];  /* �o�̓���? */
const struct{
	int	start;
	int	end;
}DiDevTbl[]={
	{Device_Length_V_ST,Device_Length_V_ST+Device_Length_V},
	{Device_Length_F_ST,Device_Length_F_ST+Device_Length_F},
	{0x0000,0x0010}, /* 20080822  UW0 - UW15 */
};
int	CheckPlcDevAccess(int StartAddr,int EndAddr)
{
	int		i;
	int	ret= OK;

	for(i= 0; i < TBQ(DiDevTbl); i++){
		if(StartAddr < DiDevTbl[i].start){
			if(EndAddr >= DiDevTbl[i].start){
				ret= NG;
				break;
			}
		}else{
			if(StartAddr <= DiDevTbl[i].end){
				ret= NG;
				break;
			}
		}
	}
	return(ret);
}

/*----------------------------------------------------------------------*/
/*	�֐���	: IsProcEnd()												*/
/*	??	: �o�k�b�v���O��?�I����?�F�b�N����B						*/
/*	����	: unsigned short* pos:Prog Code Address(IN)					*/
/*	�߂�l	: TRUE->END,FALSE->Not End									*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	IsProcEnd(unsigned short* pos)
{
	int		ret;

	ret= FALSE;
	pos--;
	if(*pos == (unsigned short)END){
		ret= TRUE;
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: CheckGlpStop()											*/
/*	??	: �o�k�b�̒�?��?�F�b�N����B								*/
/*	����	: unsigned short *BefCodePos:�O�̃C���X�g���N�V�����o�n�r	*/
/*	�߂�l	: OK:STOP,NG:Continue										*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	CheckGlpStop(unsigned short *BefCodePos)
{
	int		ret= NG;
	int		i;
	int		addr;
	int     (*RsCall)( unsigned short* );

	/* ��??�F�b�N */
	if(GLP_STCommFlag != 0){		/* ��? */
		WdtStartFlag= 0;		//WDT Stop
		GLP_STCommFlag= 0;			/* ��?�N���A */
		addr= CodeData- &PlcDataSram.Inst_Operand_Area[0];
		if(ProcMode != 0){		/* DEBUG MODE */
			MakeStopInf(addr);
		}else{
			//Debug Mode�ȊO�Œ�?�����邽��
			PlcProcRunning= 0;		/* �q�t�m?STOP */
			GLP_StopFlag = 1;		/* Stop         */
		}
		return(OK);
	}
	if(ProcMode != 0){		/* DEBUG MODE */
		addr= CodeData- &PlcDataSram.Inst_Operand_Area[0];
		/* SG Check */
		if(GLP_StopStep >= 0){
			if(addr == GLP_StopAddr){
				MakeStopInf(addr);
				ret= OK;
			}
		}
		/* BP Check */
		for(i= 0; i < Mon_Info.BpCnt; i++){
			if(addr == PlcDataSram.Inst_Point_Table[Mon_Info.BpPos[i]]){
				MakeStopInf(addr);
				ret= OK;
				break;
			}
		}
		if((ret == NG) && (BefCodePos != NULL) &&
			((Mon_Info.BpBit != 0) || (Mon_Info.BpWord != 0))){
			if(*BefCodePos < MAX_INSTRUCT_CODE){
				/* Device(Bit,Word)Check */
				RsCall= InstDebugDeviceTbl[*BefCodePos++].RsCall;
				if(RsCall != NULL){
					ret= RsCall(BefCodePos);
					if(ret == OK){
						MakeStopInf(addr);
					}
				}
			}
		}
		//Scan Comnd Check
		if(ScanRunCnt > 0){		/* DEBUG MODE */
			if(addr == ScanStartStep){
				if(ScanRunCnt > 1){	ScanRunCnt--;	}
				else{
					MakeStopInf(addr);
					ScanRunCnt= 0;
					ret= OK;
					//�X�L����RUN�N���A?
				}
			}
		}
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: ScanProc()												*/
/*	??	: �O�����͂��f??����荞�ށB							*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	ScanProc(void)
{
#ifdef	WIN32
	InDevArea.PlcDev.X[0]= Xdevice;
	InDevArea.PlcDev.X[1]= 0;
	InDevArea.PlcDev.X[2]= 0;
	InDevArea.PlcDev.X[3]= 0;
#else
	int		i;
//    int		saveSyscfg;
	volatile	unsigned char *PortAddr;
	unsigned short XTemp0;
	unsigned short XTemp1;
	int		Flag32Bit;

	for(i= 0; i < extInfo.extCnt; i++){
		Flag32Bit= 0;
		switch(extInfo.ExtInfo[i].ID & 0xf0){
		case EXT_IO_IO:			//I/O
			PortAddr= (volatile unsigned char *)((unsigned int)extInfo.ExtInfo[i].address+EXT_IO_IN_ADDR);
			switch(extInfo.ExtInfo[i].ID & 0x0f){
			case EXT_IO_I32O00:			//INPUT 32
				XTemp0= ~*PortAddr++ & 0xff;
				XTemp0 += (unsigned short)(~*PortAddr++ & 0xff) << 8;
				XTemp1= ~*PortAddr++ & 0xff;
				XTemp1 += (unsigned short)(~*PortAddr++ & 0xff) << 8;
				Flag32Bit= 1;
				break;
			case EXT_IO_I28O04:			//INPUT 28
				XTemp0= ~*PortAddr++ & 0xff;
				XTemp0 += (unsigned short)(~*PortAddr++ & 0xff) << 8;
				XTemp1= ~*PortAddr++ & 0xff;
				XTemp1 += (unsigned short)(~*PortAddr++ & 0x0f) << 8;
				Flag32Bit= 1;
				break;
			case EXT_IO_I24O08:			//INPUT 24
				XTemp0= ~*PortAddr++ & 0xff;
				XTemp0 += (unsigned short)(~*PortAddr++ & 0xff) << 8;
				XTemp1= ~*PortAddr++ & 0xff;
				Flag32Bit= 1;
				break;
			case EXT_IO_I20O12:			//INPUT 20
				XTemp0= (~*PortAddr++ & 0xff);
				XTemp0 += (unsigned short)(~*PortAddr++ & 0xff) << 8;
				XTemp1= (~*PortAddr++ & 0x0f);
				Flag32Bit= 1;
				break;
			case EXT_IO_I16O16:			//INPUT 16
				XTemp0= (~*PortAddr++ & 0xff);
				XTemp0 += (unsigned short)(~*PortAddr++ & 0xff) << 8;
				break;
			case EXT_IO_I12O20:			//INPUT 12
				XTemp0= ~*PortAddr++ & 0xff;
				XTemp0 += (unsigned short)(~*PortAddr++ & 0x0f) << 8;
				break;
			case EXT_IO_I08O24:			//INPUT 8
				XTemp0= ~*PortAddr++ & 0xff;
				break;
			case EXT_IO_I04O28:			//INPUT 4
				XTemp0= ~*PortAddr++ & 0x0f;
				break;
			case EXT_IO_I00O32:			//INPUT 0
				XTemp0= InDevArea.PlcDev.X[0];
				break;
			}
			InDevArea.PlcDev.X[0]= XTemp0;
			if(Flag32Bit == 1){
				InDevArea.PlcDev.X[1]= XTemp1;
			}
			break;
		default:
			break;
		}
	}
#endif
//	memcpy(InDevArea.PlcDev.SX,InDevArea.PlcDev.X,sizeof(InDevArea.PlcDev.SX));
//	memcpy(InDevArea.PlcDev.SY,InDevArea.PlcDev.Y,sizeof(InDevArea.PlcDev.SY));
}
/*----------------------------------------------------------------------*/
/*	�֐���	: GetPioSlotNo()												*/
/*	??	: �h�n??�h�̃X���b�g�ԍ�����������B						*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	GetPioSlotNo(void)
{
	int		ret= NG;
	int		i;

//	for(i= 0; i < extSlotInfo.extCnt; i++){
	for(i= 0; i < MAX_EXT_CNT; i++){
		if((extSlotInfo.ExtInfo[i].ID & 0xf0) == EXT_IO_IO){			//I/O
			ret= i;
			break;
		}
	}
	return(ret);
}
#ifdef	WIN32
	char	pBuff[32];
char*	GetWin32Port(void)
{
	return(pBuff);
}
#endif
/*----------------------------------------------------------------------*/
/*	�֐���	: IoFunctionOut()											*/
/*	??	: �h�n??�h�̂e��������������?�c���������x??�g�ɏo�́B	*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
#ifdef	WIN32
unsigned short SaveY[Device_Length_Y] ;  /* �o�̓���? */
unsigned short SaveBT[Device_Length_BT] ;
unsigned short SaveBC[Device_Length_BC] ;
unsigned short SaveD[8];
#endif
void	IoFunctionOut(void)
{
	int	PortA,PortB;
	volatile	unsigned char *PortAddr;
	int	andData;
	int	InPortData;
	GLP_IO_INFO*	IoInfo;
	int	idx;

	idx= GetPioSlotNo();		//Pio Search(Slot No)
#ifdef	WIN32
	PortAddr= (volatile unsigned char *)GetWin32Port();
#else
	PortAddr= (volatile unsigned char *)((unsigned int)extSlotInfo.ExtInfo[idx].address+EXT_IO_OUT_ADDR);
#endif
	PortA= *PortAddr++;
	PortB= *PortAddr++;
	IoInfo= &PlcDataSram.GlpIoInfo[idx];		//Slot Io
	//10Key
	InPortData= (PortB << 8)+ PortA;
#ifdef	WIN32
	InPortData= 0xffff;
#endif
	andData= 0;
	if(IoInfo->TenkeyUse == IO_USE){
		if(IoInfo->Tenkey_Outreg == 0){	andData |= 0x000f;	}
		else{							andData |= 0x0f00;	}
	}
	if(IoInfo->Seg7Use == IO_USE){
		if(IoInfo->Seg7_Outreg == 0){	andData |= 0xff0f;	}
		else{							andData |= 0x0fff;	}
	}
	if(IoInfo->SyncSioUse == IO_USE){
		if(IoInfo->Sync_Outreg == 0){	andData |= 0x0070;	}
		else{							andData |= 0x7000;	}
	}
	if(andData != 0){
		InDevArea.PlcDev.Y[0]= (InDevArea.PlcDev.Y[0] & ~andData) | 
								(~InPortData & andData);
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PortOutProc()												*/
/*	??	: �x�f�o�C�X��??�g�ɏo�́B								*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	PortOutProc(void)
{
#ifdef	WIN32
	//�o�͋�?
	if(*GlpSysRunMode & GLP_SYS_RUN_NO_OUT){	return; }
	//�f�o�b�O���o�͂��Ȃ�
	if((ProcMode != 0) && ((*GlpSysRunMode & GLP_SYS_RUN_DBG_DI_OUT) == 0)){	return;	}
	if(OutDispFlag == 0){
		BitDevYOnOffWin32(InDevArea.PlcDev.Y[0]);
		BitDevYOnOffWin32T(InDevArea.PlcDev.BT[0]);
		BitDevYOnOffWin32C(InDevArea.PlcDev.BC[0]);
		WordDevD0D1(&InDevArea.PlcDev.D[0]);
		OutDispFlag= 1;
	}else{
		if(memcmp(&InDevArea.PlcDev.Y[0],&SaveY[0],sizeof(SaveY)) != 0){
			BitDevYOnOffWin32(InDevArea.PlcDev.Y[0]);
		}
		if(memcmp(&InDevArea.PlcDev.BT[0],&SaveBT[0],sizeof(SaveBT)) != 0){
			BitDevYOnOffWin32T(InDevArea.PlcDev.BT[0]);
		}
		if(memcmp(&InDevArea.PlcDev.BC[0],&SaveBC[0],sizeof(SaveBC)) != 0){
			BitDevYOnOffWin32C(InDevArea.PlcDev.BC[0]);
		}
		if(memcmp(&InDevArea.PlcDev.D[0],&SaveD[0],sizeof(SaveD)) != 0){
			WordDevD0D1(&InDevArea.PlcDev.D[0]);
		}
	}
	memcpy(&SaveY[0],&InDevArea.PlcDev.Y[0],sizeof(SaveY));
	memcpy(&SaveBT[0],&InDevArea.PlcDev.BT[0],sizeof(SaveBT));
	memcpy(&SaveBC[0],&InDevArea.PlcDev.BC[0],sizeof(SaveBC));
	memcpy(&SaveD[0],&InDevArea.PlcDev.D[0],sizeof(SaveD));
#else
	int		i;
	volatile	unsigned char *PortAddr;

	//�o�͋�?
	if(*GlpSysRunMode & GLP_SYS_RUN_NO_OUT){		return; }
	//�f�o�b�O���o�͂��Ȃ�
	if((ProcMode != 0) && ((GlpDbgInf & GLP_SYS_RUN_DBG_DI_OUT) == 0)){	return;	}
	for(i= 0; i < extInfo.extCnt; i++){
		switch(extInfo.ExtInfo[i].ID & 0xf0){
		case EXT_IO_IO:			//I/O
			PortAddr= (unsigned char *)((unsigned int)extInfo.ExtInfo[i].address+EXT_IO_IN_ADDR);
			switch(extInfo.ExtInfo[i].ID & 0x0f){
			case EXT_IO_I32O00:			//OUT 00
				break;
			case EXT_IO_I28O04:			//OUT 4
				PortAddr++;
				PortAddr++;
				PortAddr++;
				*PortAddr= ~((InDevArea.PlcDev.Y[0] & 0x0f) << 4);
				break;
			case EXT_IO_I24O08:			//OUT 8
				PortAddr++;
				PortAddr++;
				PortAddr++;
				*PortAddr= ~(InDevArea.PlcDev.Y[0] & 0xff);
				break;
			case EXT_IO_I20O12:			//OUT 12
				PortAddr++;
				PortAddr++;
				*PortAddr++= ~((InDevArea.PlcDev.Y[0]) & 0xff);
				*PortAddr= ~((InDevArea.PlcDev.Y[0] >> 8) & 0x0f);
				break;
			case EXT_IO_I16O16:			//OUT 16
				PortAddr++;
				PortAddr++;
				*(volatile unsigned char *)PortAddr++= ~(InDevArea.PlcDev.Y[0]);
				*(volatile unsigned char *)PortAddr= ~(InDevArea.PlcDev.Y[0] >> 8);
				break;
			case EXT_IO_I12O20:			//OUT 20
				PortAddr++;
				*PortAddr++= ~((InDevArea.PlcDev.Y[0]) & 0x0f);
				*PortAddr++= ~(InDevArea.PlcDev.Y[0] >> 4);
				*PortAddr++= ~(((InDevArea.PlcDev.Y[1] & 0x0f) << 4) | 
								(InDevArea.PlcDev.Y[0] >> 12));
				break;
			case EXT_IO_I08O24:			//OUT 24
				PortAddr++;
				*PortAddr++= ~(InDevArea.PlcDev.Y[0]);
				*PortAddr++= ~(InDevArea.PlcDev.Y[0] >> 8);
				*PortAddr++= ~(InDevArea.PlcDev.Y[1]);
				break;
			case EXT_IO_I04O28:			//OUT 28
				*PortAddr++= ~(InDevArea.PlcDev.Y[0] & 0x0f);
				*PortAddr++= ~(InDevArea.PlcDev.Y[0] >> 4);
				*PortAddr++= ~(((InDevArea.PlcDev.Y[1] & 0x0f) << 4) | 
								(InDevArea.PlcDev.Y[0] >> 12));
				*PortAddr++= ~((InDevArea.PlcDev.Y[1] >> 4) & 0xff);
				break;
			case EXT_IO_I00O32:			//OUT 32
				*PortAddr++= ~(InDevArea.PlcDev.Y[0]);
				*PortAddr++= ~(InDevArea.PlcDev.Y[0] >> 8);
				*PortAddr++= ~(InDevArea.PlcDev.Y[1]);
				*PortAddr++= ~(InDevArea.PlcDev.Y[1] >> 8);
				break;
			}
			break;
		default:
			break;
		}
	}
#endif
}
void	PortOutOffProc(void)
{
#ifdef	WIN32
	BitDevYOnOffWin32(0);
#else
	int		i;
	volatile	unsigned char *PortAddr;

	memset(WorkY,0,sizeof(WorkY));
	for(i= 0; i < extInfo.extCnt; i++){
		switch(extInfo.ExtInfo[i].ID & 0xf0){
		case EXT_IO_IO:			//I/O
			PortAddr= (unsigned char *)((unsigned int)extInfo.ExtInfo[i].address+EXT_IO_IN_ADDR);
			switch(extInfo.ExtInfo[i].ID & 0x0f){
			case EXT_IO_I32O00:			//OUT 00
				break;
			case EXT_IO_I28O04:			//OUT 4
				PortAddr++;
				PortAddr++;
				PortAddr++;
				*PortAddr= ~((WorkY[0] & 0x0f) << 4);
				break;
			case EXT_IO_I24O08:			//OUT 8
				PortAddr++;
				PortAddr++;
				PortAddr++;
				*PortAddr= ~(WorkY[0] & 0xff);
				break;
			case EXT_IO_I20O12:			//OUT 12
				PortAddr++;
				PortAddr++;
				*PortAddr++= ~((WorkY[0]) & 0xff);
				*PortAddr= ~((WorkY[0] >> 8) & 0x0f);
				break;
			case EXT_IO_I16O16:			//OUT 16
				PortAddr++;
				PortAddr++;
				*(volatile unsigned char *)PortAddr++= ~(WorkY[0]);
				*(volatile unsigned char *)PortAddr= ~(WorkY[0] >> 8);
				break;
			case EXT_IO_I12O20:			//OUT 20
				PortAddr++;
				*PortAddr++= ~((WorkY[0]) & 0x0f);
				*PortAddr++= ~(WorkY[0] >> 4);
				*PortAddr++= ~(((WorkY[1] & 0x0f) << 4) | 
								(WorkY[0] >> 12));
				break;
			case EXT_IO_I08O24:			//OUT 24
				PortAddr++;
				*PortAddr++= ~(WorkY[0]);
				*PortAddr++= ~(WorkY[0] >> 8);
				*PortAddr++= ~(WorkY[1]);
				break;
			case EXT_IO_I04O28:			//OUT 28
				*PortAddr++= ~(WorkY[0] & 0x0f);
				*PortAddr++= ~(WorkY[0] >> 4);
				*PortAddr++= ~(((WorkY[1] & 0x0f) << 4) | 
								(WorkY[0] >> 12));
				*PortAddr++= ~((WorkY[1] >> 4) & 0xff);
				break;
			case EXT_IO_I00O32:			//OUT 32
				*PortAddr++= ~(WorkY[0]);
				*PortAddr++= ~(WorkY[0] >> 8);
				*PortAddr++= ~(WorkY[1]);
				*PortAddr++= ~(WorkY[1] >> 8);
				break;
			}
			break;
		default:
			break;
		}
	}
#endif
}
/*----------------------------------------------------------------------*/
/*	�֐���	: DebugIoINSet()											*/
/*	??	: �f�o�b�O���̓��͋����h?�n�ݒ�B							*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	DebugIoINSet(void)
{
	int		i;

	if(ProcMode != 0){		/* DEBUG MODE */
		for(i= 0; i < Mon_Info.I_O_Cnt; i++){
			if(Mon_Info.I_O_Dev[i].flag == '0'){		//�����O
				*Mon_Info.I_O_Dev[i].DeviceAddr &= ~Mon_Info.I_O_Dev[i].andData;
			}else if(Mon_Info.I_O_Dev[i].flag == '1'){	//�����P
				*Mon_Info.I_O_Dev[i].DeviceAddr |= Mon_Info.I_O_Dev[i].andData;
			}
		}
#ifdef	WIN32
		Xdevice= InDevArea.PlcDev.X[0];
		BitDevXOnOffWin32();
#endif
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: DebugIoINSet()											*/
/*	??	: �f�o�b�O���̏o�͋����h?�n�ݒ�B							*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	DebugIoOutSet(void)
{
	int		i;

	if(ProcMode != 0){		/* DEBUG MODE */
		for(i= 0; i < Mon_Info.I_O_Cnt; i++){
			if(Mon_Info.I_O_Dev[i].flag == '0'){
				*Mon_Info.I_O_Dev[i].DeviceAddr &= ~Mon_Info.I_O_Dev[i].andData;
			}else if(Mon_Info.I_O_Dev[i].flag == '1'){
				*Mon_Info.I_O_Dev[i].DeviceAddr |= Mon_Info.I_O_Dev[i].andData;
			}
		}
#ifdef	WIN32
		BitDevXOnOffWin32();
#endif
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: GetInputScan()											*/
/*	??	: �O�����͂��f??����荞�ށB(Reflesh)					*/
/*	����	: int idx->Word Offset										*/
/*			  int BitPos->0x0001to0x8000 Bit Pos						*/
/*			  int cnt->Bit Length										*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	GetInputScan(int idx,int BitPos,int cnt)
{
	unsigned short XTemp[2];
	unsigned short andData[4];		//32Bit
	int		i,j,wcnt;
#ifndef	WIN32
	unsigned short XTemp0;
	unsigned short XTemp1;
	int		bidx;
	volatile	unsigned char *PortAddr;
#endif
	//Data Bit Patarn
	memset(andData,0,sizeof(andData));
	for(i= 0,j= 0; i < cnt; i++){
		andData[j] |= BitPos;
		BitPos <<= 1;
		if(BitPos > 0x8000){
			j++;
			BitPos = 0x0001;
		}
	}
	wcnt= j+1;
#ifdef	WIN32
	XTemp[0]= Xdevice;
#else
	bidx= GetPioSlotNo();
	PortAddr= (volatile unsigned char *)((unsigned int)extSlotInfo.ExtInfo[bidx].address+EXT_IO_IN_ADDR+idx*2);
	XTemp0= ~*PortAddr++ & 0xff;
	XTemp0 += (unsigned short)(~*PortAddr++ & 0xff) << 8;
	j--;
	if(j >= 0){
		XTemp1= ~*PortAddr++ & 0xff;
		XTemp1 += (unsigned short)(~*PortAddr++ & 0xff) << 8;
	}
	XTemp[0]= XTemp0;
	XTemp[1]= XTemp1;
#endif
	for(i= 0; i < wcnt; i++){
		InDevArea.PlcDev.X[idx+ i]= (InDevArea.PlcDev.X[idx+ i] & ~andData[i]) |
							 (XTemp[i] & andData[i]);
//		InDevArea.PlcDev.SX[idx+ i]= (InDevArea.PlcDev.SX[idx+ i] & ~andData[i]) |
//							 (XTemp[i] & andData[i]);
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetOutData()												*/
/*	??	: �O���o�͂Ƀf??�o�͂���B(Reflesh)�B						*/
/*	����	: int idx->Word Offset										*/
/*			  int BitPos->0x0001to0x8000 Bit Pos						*/
/*			  int cnt->Bit Length										*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SetOutData(int idx,int BitPos,int cnt)
{
	unsigned short andData[4];		//32Bit
	int		i,j,wcnt;

	//Data Bit Patarn
	memset(andData,0,sizeof(andData));
	for(i= 0,j= 0; i < cnt; i++){
		andData[j] |= BitPos;
		BitPos <<= 1;
		if(BitPos > 0x8000){	j++;	BitPos = 0x0001;	}
	}
	wcnt= j+1;
	for(i= 0; i < wcnt; i++){
		InDevArea.PlcDev.Y[idx+ i]= (InDevArea.PlcDev.Y[idx+ i] & ~andData[i]) |
							 (InDevArea.PlcDev.Y[i] & andData[i]);
	}
	IoFunctionOut();
	//Out Port
	PortOutProc();
}
/*----------------------------------------------------------------------*/
/*	�֐���	: InitParamFile()											*/
/*	??	: �k����?�a�������������G��?����ꃌ�W�X??�ɐݒ肷��B	*/
/*	����	: int mode:ON->Error,OFF->��								*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	InitParamFile(void)
{
	PARAM_FILE*	param;
	int			cnt;

	cnt= sizeof(PARAM_FILE)- 0x10;
	//CommonData
	param= (PARAM_FILE*)TakeMemory(sizeof(PARAM_FILE));
	memset(param,0,sizeof(PARAM_FILE));
	param->len= cnt;
	memcpy(&param->ver,PlcPassword,strlen(PlcPassword));
	param->comm.DebugIoOut= 0;	//0:1Scan,1:Out��
	param->comm.DefFilter= 0;
	param->comm.IoOut= 0;
	param->comm.DevLen[0]= 0;
	param->comm.DevLen[1]= 0;
	param->slotNum= 1;
	// Default Timer
	// 100ms
#ifdef	WIN32
	param->comm.TimerKind[0][0]= 0;			//Start
	param->comm.TimerKind[0][1]= 127*256;		//End
	// 10ms
	param->comm.TimerKind[1][0]= 128*256;		//Start
	param->comm.TimerKind[1][1]= 255*256;		//End
#else
	param->comm.TimerKind[0][0]= 0;			//Start
	param->comm.TimerKind[0][1]= 127;		//End
	// 10ms
	param->comm.TimerKind[1][0]= 128;		//Start
	param->comm.TimerKind[1][1]= 255;		//End
#endif

	//IO-Type
	param->io.ModuleID= EXT_IO_IO | EXT_IO_I16O16;
	param->io.Version[1]= 3;
#ifdef	WIN32
	memcpy(&GpFont[PLC_PARAM_FILE],param,sizeof(PARAM_FILE));
#else
	RamFlashEraze((short *)PLC_PARAM_FILE);
	RamFlashWrite((short *)PLC_PARAM_FILE,(short *)param,sizeof(PARAM_FILE));
#endif
	FreeMail((char*)param);

	PlcDataSram.ParamTableCnt= cnt;

	ParamIO2Fdevice();		//Move to Fdevice
	
}
/*----------------------------------------------------------------------*/
/*	�֐���	: GetPlcProgram()											*/
/*	??	: �o�k�b�v���O��?�Ƃq?�l��̃v���O��?���r�������ꍇ���̂܂܎g�p�B*/
/*			  ��rErr->�q?�l���t?�C���ɏ�������(RAM��EP�̂܂�)		*/
/*			  Password Err->�t?�C�����ǂݍ���						*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
enum{plcNON,plcREAD,plcWRITE};
void	GetPlcProgram(void)
{
	int	ret;
	int	pos,size;
	int	ReadWriteFlag;
	char	*cpos;
	char	*ramaddr;
#ifndef	DATA_FILE
	int		fp;
#endif
	int		i;
	unsigned int	CodeTableSum; 
	int	*ParamLenAddr;

	ReadWriteFlag= plcNON;
	//Data Version Check
	if(memcmp(PlcDataSram.password,PlcPassword,sizeof(PlcPassword)) != 0){
		strcpy(PlcDataSram.password,PlcPassword);
		/* Program */
		PlcDataSram.CodeTableCnt= 0;
		PlcDataSram.Load_Count= 0;
		PlcDataSram.CodeTableSum= 0;
		ReadWriteFlag= plcREAD;
#ifdef	WIN32
		ParamLenAddr= (int*)&GpFont[PLC_PARAM_FILE];
#else
		ParamLenAddr= (int*)PLC_PARAM_FILE;
#endif
		size= *ParamLenAddr;
		if(size > 0){
			PlcDataSram.ParamTableCnt= size;
			ParamIO2Fdevice();			//Paramerter Setting
		}else{
			//DEfault
			InitParamFile();
		}
	}else{
		//Plc Program Check
		ret= mfileserch2(PLC_PROG_NAME_DIR,&pos,&size);
		if(ret == OK){
			ramaddr= (char*)PlcDataSram.Inst_Operand_Program;
			cpos= (char*)pos;
			for(i= 0; i < size; i++){
				if(*ramaddr++ != *cpos++){	break;	}
			}
			if(i < size){
				CodeTableSum= MakeCodeTblSum(PlcDataSram.Inst_Operand_Program,PlcDataSram.CodeTableCnt);
				if(PlcDataSram.CodeTableSum == CodeTableSum){
					ReadWriteFlag= plcWRITE;
				}else{
					ReadWriteFlag= plcREAD;
				}

			}		//Write
		}
	}
#ifdef	DATA_FILE
	FILE	*fp_pc;

	fp_pc= fopen("SendData.dat","rb");
	if(fp_pc != NULL){
		size= fread(&PlcDataSram.Inst_Operand_Program[0],
			1,sizeof(PlcDataSram.Inst_Operand_Program),fp_pc);
		PlcDataSram.CodeTableCnt= size;
		PlcDataSram.Load_Count= PlcDataSram.CodeTableCnt/2;
		PlcDataSram.CodeTableSum= MakeCodeTblSum(&PlcDataSram.Inst_Operand_Program[0],size);
		fclose(fp_pc);
	}
#else
	if(ReadWriteFlag == plcREAD){
#ifdef	WIN32
		ret= mfileserch2(PLC_PROG_NAME_DIR,&pos,&size);
		if(ret == OK){
			Vmemcpy((volatile char*)&PlcDataSram.Inst_Operand_Program[0],(volatile char*)pos,size);
			PlcDataSram.CodeTableCnt= size;
			PlcDataSram.Load_Count= PlcDataSram.CodeTableCnt/2;
			PlcDataSram.CodeTableSum= MakeCodeTblSum(PlcDataSram.Inst_Operand_Program,size);
		}
#else
		ret= mfileserch2(PLC_PROG_NAME_DIR,&pos,&size);
		if(ret == OK){
			Vmemcpy((volatile char*)&PlcDataSram.Inst_Operand_Program[0],(volatile char*)pos,size);
			PlcDataSram.CodeTableCnt= size;
			PlcDataSram.Load_Count= PlcDataSram.CodeTableCnt/2;
			PlcDataSram.CodeTableSum= MakeCodeTblSum(PlcDataSram.Inst_Operand_Program,size);
		}
#endif
	}else if(ReadWriteFlag == plcWRITE){		//Write
		fp= mopen(PLC_PROG_NAME,_O_WRONLY);
		if(fp != GP_ERROR){
			FileRetVal= mwrite(fp,&PlcDataSram.Inst_Operand_Program[0],PlcDataSram.CodeTableCnt);
			if(FileRetVal >= 0){
				mfileDelete(FileRetVal,fp);
				mclose(fp);
				Delay(300);
			}
		}

	}
#endif
}
/*----------------------------------------------------------------------*/
/*	�֐���	: GetPlcFile()												*/
/*	??	: �e��?�E����?�h�f??��?�F�b�N�B						*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	GetPlcFile(void)
{
	int		len;
	int		ret;
	int		pos;
	int		i;
	char*	Passaddr;
	char	c;

#ifdef	WIN32
	Passaddr= (char*)&GpFont[PLC_SETTING_AREA];		//20081108
#else
	Passaddr= (char*)PLC_SETTING_AREA;		//20081108
#endif
	//Password Check
	for(i= 0; i < PLC_PASS_CNT; i++){
		c= *Passaddr++;
		if((c < ' ') || (c > 0x7f)){
			break;
		}
	}
	if(i < PLC_PASS_CNT){
		memset(PlcDataSram.PLC_Pass,' ',sizeof(PlcDataSram.PLC_Pass));
		mWritePlcPass(PlcDataSram.PLC_Pass);
	}

	PlcDataSram.ParamTableCnt= 0;
	PlcDataSram.LComentTableCnt= 0;
	PlcDataSram.RComentTableCnt= 0;
	PlcDataSram.ValTableCnt= 0;
	PlcDataSram.LabelTableCnt= 0;
	PlcDataSram.ProjTableCnt= 0;
#ifdef	WIN32
	PlcDataSram.ParamTableCnt= *(int *)&GpFont[PLC_PARAM_FILE];
#else
	PlcDataSram.ParamTableCnt= *(int *)PLC_PARAM_FILE;
#endif
	if(PlcDataSram.ParamTableCnt < 0){	PlcDataSram.ParamTableCnt= 0;	}
	ret= mfileserch2(&PLC_LCOM_NAME[2],&pos,&len);
	if(ret == OK){	PlcDataSram.LComentTableCnt= len;	}
	ret= mfileserch2(&PLC_RCOM_NAME[2],&pos,&len);
	if(ret == OK){	PlcDataSram.RComentTableCnt= len;	}
	ret= mfileserch2(&PLC_VAL_NAME[2],&pos,&len);
	if(ret == OK){	PlcDataSram.ValTableCnt= len;	}
	ret= mfileserch2(&PLC_LABEL_NAME[2],&pos,&len);
	if(ret == OK){	PlcDataSram.LabelTableCnt= len;	}
	ret= mfileserch2(&PLC_PROJ_NAME[2],&pos,&len);
	if(ret == OK){	PlcDataSram.ProjTableCnt= len;	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PlcStartOutDevClear()										*/
/*	??	: �o�̓f�o�C�X���N���A����B								*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	PlcStartOutDevClear(void)
{
	//Y Device Data����������
#ifndef	WIN32
//	if((*GlpSysRunMode & GLP_SYS_RUN_NO_RST) == 0){
		memset(&InDevArea.PlcDev.Y[0],0,sizeof(InDevArea.PlcDev.Y));
//	}
#endif
}
void	PlcStartOutStopDevClear(void)
{
	//Y Device Data����������
#ifndef	WIN32
//	if((*GlpSysRunMode & GLP_SYS_RUN_NO_RST) == 0){
		memset(&InDevArea.PlcDev.Y[0],0,sizeof(InDevArea.PlcDev.Y));
//	}
#endif
}
/*----------------------------------------------------------------------*/
/*	�֐���	: DiIo00()													*/
/*	??	: �h�n���荞�݋�?�B										*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
extern	const unsigned int	AndTable32[32];
void	DiIo00(int no)
{
	int	level= no- EINT_START_NO;
	if((level >= 0) && (level <= 31)){
		GlpSysInterruptIO[0] &= ~AndTable32[level];
	}
	if((level >= 32) && (level <= 63)){
		GlpSysInterruptIO[1] &= ~AndTable32[level%32];
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: EiIo00()													*/
/*	??	: �h�n���荞�݋��B										*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	EiIo00(int no)
{
	int	level= no- EINT_START_NO;
	if((level >= 0) && (level <= 31)){
		GlpSysInterruptIO[0] |= AndTable32[level];
	}
	if((level >= 32) && (level <= 63)){
		GlpSysInterruptIO[1] |= AndTable32[level%32];
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: DiTimer()													*/
/*	??	: ?�C??���荞�݋�?�B									*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	DiTimer(int no)
{
	int	level= no- TINT_START_NO;
	if((level >= 0) && (level <= 7)){
		GlpSysInterruptTimer &= ~AndTable32[level];
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: EiTimer()													*/
/*	??	: ?�C??���荞�݋��B									*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	EiTimer(int no)
{
	int	level= no- TINT_START_NO;
	if((level >= 0) && (level <= 7)){
		GlpSysInterruptTimer |= AndTable32[level];
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: DiPlcInt()												*/
/*	??	: ���荞�݋�?�B											*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	DiPlcInt(void)
{
	GlpSysInterrupt= 0;		//DI
}
/*----------------------------------------------------------------------*/
/*	�֐���	: EiPlcInt()												*/
/*	??	: ���荞�݋��B											*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	EiPlcInt(void)
{
	GlpSysInterrupt= 1;		//EI
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetSpecialRegisterAddr()									*/
/*	??	: ���ꃌ�W�X??�̊i?�̈�ݒ�B							*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SetSpecialRegisterAddr(void)
{
	//Read Device(Bit)
	GlpSysMode		= &InDevArea.PlcDev.FSave[GLP_SYS_MODE-GLP_SYSTEM_DEVICE];
	GlpSysSignal	= &InDevArea.PlcDev.FSave[GLP_SYS_SIGNAL-GLP_SYSTEM_DEVICE];
	GlpSysState		= &InDevArea.PlcDev.FSave[GLP_SYS_STATE-GLP_SYSTEM_DEVICE];
	GlpSysError		= &InDevArea.PlcDev.FSave[GLP_SYS_ERROR-GLP_SYSTEM_DEVICE];
	GlpSysModukeSts	= &InDevArea.PlcDev.FSave[GLP_SYS_MODULE_STS-GLP_SYSTEM_DEVICE];
	GlpSysClock		= &InDevArea.PlcDev.FSave[GLP_SYS_CLOCK-GLP_SYSTEM_DEVICE];
	GlpSysCulc		= &InDevArea.PlcDev.FSave[GLP_SYS_CULC-GLP_SYSTEM_DEVICE];
	//Write Device(Bit)
	GlpSysRunMode	= &InDevArea.UW[GLP_SYS_RUN_MODE];
	GlpSysTimeMode  = &InDevArea.UW[GLP_SYS_TIME_MODE];
	GlpSysModuleSet	= &InDevArea.UW[GLP_SYS_MODULE_SET];
	//Read(Word)
	GlpModelCode	= &InDevArea.PlcDev.FSave[GLP_MODEL_CODE-GLP_SYSTEM_DEVICE];
	GlpSysVersion	= &InDevArea.PlcDev.FSave[GLP_SYS_VERSION-GLP_SYSTEM_DEVICE];
	GlpVDate		= &InDevArea.PlcDev.FSave[GLP_SYS_V_DATE-GLP_SYSTEM_DEVICE];
	GlpSysNowSc		= &InDevArea.PlcDev.FSave[GLP_SYS_NOW_SC-GLP_SYSTEM_DEVICE];
	GlpSysMinSc		= &InDevArea.PlcDev.FSave[GLP_SYS_MIN_SC-GLP_SYSTEM_DEVICE];
	GlpSysMaxSc		= &InDevArea.PlcDev.FSave[GLP_SYS_MAX_SC-GLP_SYSTEM_DEVICE];
	GlpSysAvrSc		= &InDevArea.PlcDev.FSave[GLP_SYS_AVR_SC-GLP_SYSTEM_DEVICE];
	GlpSysScnCnt	= &InDevArea.PlcDev.FSave[GLP_SYS_SCN_CNT-GLP_SYSTEM_DEVICE];
	GlpSysCulcErrSetep  = &InDevArea.PlcDev.FSave[GLP_SYS_CULC_ERR_STEP-GLP_SYSTEM_DEVICE];
	GlpSysCulcErredSetep= &InDevArea.PlcDev.FSave[GLP_SYS_CULC_ERRED_STEP-GLP_SYSTEM_DEVICE];
	GlpSysErrorStep= &InDevArea.PlcDev.FSave[GLP_SYS_ERROR_STEP-GLP_SYSTEM_DEVICE];
	GlpSysBreakStep	= &InDevArea.PlcDev.FSave[GLP_SYS_BREAK_STEP-GLP_SYSTEM_DEVICE];
	GlpSysSelfTest	= &InDevArea.PlcDev.FSave[GLP_SYS_SELF_TEST-GLP_SYSTEM_DEVICE];
	//Write(Word)
	GlpSysYY		= &InDevArea.UW[GLP_SYS_YY];
	GlpSysMM		= &InDevArea.UW[GLP_SYS_MM];
	GlpSysDD		= &InDevArea.UW[GLP_SYS_DD];
	GlpSysHH		= &InDevArea.UW[GLP_SYS_HH];
	GlpSysMIN		= &InDevArea.UW[GLP_SYS_MIN];
	GlpSysSS		= &InDevArea.UW[GLP_SYS_SS];
	GlpSysWW		= &InDevArea.UW[GLP_SYS_WW];
	GlpSysInpFilter = &InDevArea.UW[GLP_SYS_INP_FILTER];
	GlpSysCscTime	= &InDevArea.UW[GLP_SYS_SCN_TIME];
	GlpSysWDTCnt	= &InDevArea.UW[GLP_SYS_WDT_COUNT];
	GlpSysTimeIntrval = &InDevArea.UW[GLP_SYS_TIME_INTVAL];

	GlpSysIoInit= 0;		//Init Flag Clear
//	memset(&PlcDataSram.GlpIoInfo,0,sizeof(PlcDataSram.GlpIoInfo));

	*GlpSysMinSc= 65535;
	*GlpSysMaxSc= 0;
	//�ŏ��͊��荞�݋�?�ɂ��Ă���
	DiPlcInt();
	memset(&GlpSysInterruptIO[0],0,sizeof(GlpSysInterruptIO));
	GlpSysInterruptTimer= 0;
	//Interrupt Clear
	TimerIntEntryCnt= 0;
	memset(&EntryTimerInt[0],0xff,sizeof(EntryTimerInt));
	memset(EntryIoInt,-1,sizeof(EntryIoInt));
//	InterruptKind= 0;
	InterruputIn_idx= 0;
	InterruputOut_idx= 0;
	memset(IntLebel,0xff,sizeof(IntLebel));
	TimeloopCnt = 0;		//Timer Start
	GlpDbgInf= 0;			//Debug Io Info
	*GlpSysCulcErredSetep= (unsigned short)-1;
}
/*----------------------------------------------------------------------*/
/*	�֐���	: CheckClearDev()											*/
/*	??	: �w�肳�ꂽ�f�o�C�X��Start,End Address���o���B			*/
/*	����	: int code->�f�o�C�X�R?�h									*/
/*			  int* Start->Start Address �i?�̈�						*/
/*			  int* End->End Address �i?�̈�							*/
/*	�߂�l	: OK,NG														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
typedef	struct{
	int	code;
	unsigned short*	startAddr;
	int	len;
}CLR_WORD_TBL;
const	CLR_WORD_TBL	ClearWordDevTbl[]={
	{W_UM,&InDevArea.UW[Device_Length_M_ST] ,Device_Length_M},
//	{W_UF,&InDevArea.UW[Device_Length_F_ST] ,Device_Length_F},
	{W_US,&InDevArea.UW[Device_Length_S_ST] ,Device_Length_S},
	{W_UL,&InDevArea.UW[Device_Length_L_ST] ,Device_Length_L},
	{W_UT,&InDevArea.UW[Device_Length_T_ST] ,Device_Length_T},		//T-Current
	{W_UC,&InDevArea.UW[Device_Length_C_ST] ,Device_Length_C},		//C-Current
	{W_UD,&InDevArea.UW[Device_Length_D_ST] ,Device_Length_D},
	{W_UR,&InDevArea.UW[Device_Length_R_ST] ,Device_Length_R},
};
const	CLR_WORD_TBL	ClearWordDevTbl2[]={
	{W_UT,&InDevArea.UW[Device_Length_BT_ST],Device_Length_BT},		//T-Bit
	{W_UT,&InDevArea.UW[Device_Length_ST_ST],Device_Length_ST},		//T-Settei
	{W_UC,&InDevArea.UW[Device_Length_BC_ST],Device_Length_BC},		//C-Bit
	{W_UC,&InDevArea.UW[Device_Length_SC_ST],Device_Length_SC},		//C-Settei
	{W_UZ,&InDevArea.UW[Device_Length_Z_ST] ,Device_Length_Z},
};
const	CLR_WORD_TBL	AllClearWordDevTbl[]={
	{W_UM,&InDevArea.UW[Device_Length_R_ST] ,Device_Length_R},
	{W_UM,&InDevArea.UW[Device_Length_V_ST] ,Device_Length_V},
	{W_UF,&InDevArea.UW[Device_Length_F_ST] ,Device_Length_F},
	{W_UF,&InDevArea.UW[Device_Length_Z_ST] ,Device_Length_Z},
	{W_UF,&InDevArea.UW[Device_Length_X_ST] ,Device_Length_X},
	{W_UF,&InDevArea.UW[Device_Length_Y_ST] ,Device_Length_Y},
	{W_UF,&InDevArea.UW[Device_Length_BT_ST] ,Device_Length_BT},
	{W_UT,&InDevArea.UW[Device_Length_T_ST] ,Device_Length_T},		//T-Current
	{W_UT,&InDevArea.UW[Device_Length_ST_ST] ,Device_Length_ST},		//T-Current
	{W_UF,&InDevArea.UW[Device_Length_BC_ST] ,Device_Length_BC},
	{W_UC,&InDevArea.UW[Device_Length_C_ST] ,Device_Length_C},		//C-Current
	{W_UF,&InDevArea.UW[Device_Length_SC_ST] ,Device_Length_SC},
	{W_UF,&InDevArea.UW[Device_Length_M_ST] ,Device_Length_M},
	{W_US,&InDevArea.UW[Device_Length_S_ST] ,Device_Length_S},
	{W_UL,&InDevArea.UW[Device_Length_L_ST] ,Device_Length_L},
	{W_UD,&InDevArea.UW[Device_Length_D_ST] ,Device_Length_D},
};
//Default Lach Area
const	struct{
	int	code;
	int	start;
	int	end;
}DefaultClearWordDevTbl[]={
	{W_UM,1000	,9999},
	{W_US,127	,255},
	{W_UL,500	,999},
	{W_UT,127	,255},	//T���ݒl
	{W_UC,127	,255},	//C���ݒl
	{W_UD,1000	,9999},
	{W_UR,0		,3999},
};
int	CheckDefaultDeiv(int code)
{
	int	i;

	for(i= 0; i < TBQ(DefaultClearWordDevTbl); i++){
		if(DefaultClearWordDevTbl[i].code == code){
			break;
		}
	}
	if(i >= TBQ(DefaultClearWordDevTbl)){
		i= -1;
	}
	return(i);
}
int	CheckClearDev(int code,int* Start,int* End)
{
	int	ret= NG;
	int	cnt,i;
	GLP_COMM*	GlpCommon;
	unsigned char	DevCode;
	int	defaultFlag;

	defaultFlag= 1;
	//DownLoad Table Check
	if(PlcDataSram.ParamTableCnt > 0){
#ifdef	WIN32
		GlpCommon= (GLP_COMM*)&GpFont[PARAM_GLP_COMM];
#else
		GlpCommon= (GLP_COMM*)PARAM_GLP_COMM;
#endif
		cnt= (GlpCommon->DevLen[0] << 8) + GlpCommon->DevLen[1];
		for(i= 0; i < cnt; i++){
			DevCode= (GlpCommon->ClearDev[i][0] & 0xff00) >> 8;
			if(GLPIndexTable[DevCode] == code){	break;	}
		}
		if(i < cnt){
			if( (GlpCommon->ClearDevUse[0] & AndTable[i]) &&
				(GlpCommon->ClearDevUse[1] & AndTable[i]) ){
				//�w��A�h���X��LACH����B
				ret= OK;
				*Start= (GlpCommon->ClearDev[i][0] & 0x00ff) << 16;
				*Start+= GlpCommon->ClearDev[i][1];
				*End= (GlpCommon->ClearDev[i][2] & 0x00ff) << 16;
				*End+= GlpCommon->ClearDev[i][3];
			}else{
				if( (GlpCommon->ClearDevUse[0] & AndTable[i]) &&
					!(GlpCommon->ClearDevUse[1] & AndTable[i]) ){
					defaultFlag= 0;//�S�ăN���A
				}else if( !(GlpCommon->ClearDevUse[0] & AndTable[i]) &&
						  !(GlpCommon->ClearDevUse[1] & AndTable[i]) ){
					//Default
					cnt= CheckDefaultDeiv(code);
					if(cnt != -1){
						ret= OK;
						*Start= DefaultClearWordDevTbl[cnt].start;
						*End= DefaultClearWordDevTbl[cnt].end;
					}
				}
			}
		}
	}
	if((ret == NG) && (defaultFlag == 1)){
		cnt= CheckDefaultDeiv(code);
		if(cnt != -1){
			ret= OK;
			*Start= DefaultClearWordDevTbl[cnt].start;
			*End= DefaultClearWordDevTbl[cnt].end;
		}
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: ClearItemDev()											*/
/*	??	: �w�肳�ꂽ�f�o�C�X�̃N���A�B								*/
/*	����	: int idx->�f�o�C�X�C���f�b�N�X(ClearWordDevTbl)			*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	ClearItemDev(int idx)
{
	int	Start,End;

	if(CheckClearDev(ClearWordDevTbl[idx].code,&Start,&End) == OK){	//�w�肠��
		if(Start > 0){
			//Start�܂ŃN���A
			memset(ClearWordDevTbl[idx].startAddr,0,Start*2);
			if((End+1) < ClearWordDevTbl[idx].len){
				//End����Ō�܂ŃN���A
				memset(ClearWordDevTbl[idx].startAddr+(End+1),0,(ClearWordDevTbl[idx].len-(End+1))*2);
			}else{
				;		//�X??�g����S���ۑ�
			}
		}else{
			if((End+1) < ClearWordDevTbl[idx].len){
				//End����Ō�܂ŃN���A
				memset(ClearWordDevTbl[idx].startAddr+(End+1),0,(ClearWordDevTbl[idx].len-(End+1))*2);
			}else{
				;		//�S�ĕۑ�
			}
		}
	}else{
		memset(ClearWordDevTbl[idx].startAddr,0,ClearWordDevTbl[idx].len*2);
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PlcDeviceClear()											*/
/*	??	: �o�̓f�o�C�X�ȊO�f�o�C�X�̃N���A�B						*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	PlcDeviceClear(void)
{
	int	i;
//	memset(&InDevArea.PlcDev.L,0,sizeof(InDevArea.PlcDev)- DUMY_DEV*2);
	//X,Y Device Clear
	memset(&InDevArea.PlcDev.X,0,Device_Length_X*2);
//	memset(&InDevArea.PlcDev.Y,0,Device_Length_Y*2);
	PlcStartOutDevClear();
	for(i= 0; i < TBQ(DefaultClearWordDevTbl); i++){
		ClearItemDev(i);
	}
	//�����N���A        200804111800
	for(i= 0; i < TBQ(ClearWordDevTbl2); i++){
		memset(ClearWordDevTbl2[i].startAddr,0,ClearWordDevTbl2[i].len*2);	
	}
}
void	Read2FdevArea(void)
{
	//Bit Read Area
	memcpy(&InDevArea.UW[GLP_SYS_MODE],&InDevArea.PlcDev.FSave[GLP_SYS_MODE-GLP_SYSTEM_DEVICE],7*2);
	//Word Read Area
	memcpy(&InDevArea.UW[GLP_MODEL_CODE],&InDevArea.PlcDev.FSave[GLP_MODEL_CODE-GLP_SYSTEM_DEVICE],50*2);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PlcSpDeviceClear()										*/
/*	??	: ���ꃌ�W�X?�̃N���A�B������									*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	PlcSpDeviceClear(void)
{
	int	work;
	char	buff[20];
extern	void	ChangeLowHighByte(char *buff,int cnt);

	memset(&InDevArea.PlcDev.FSave[0],0,Device_Length_F*2);
	memset(&InDevArea.PlcDev.F[0],0,Device_Length_F*2);
	//PLC Series Code
	//PLC Model Code
	*GlpModelCode= GP_TYPE_CODE;
	//System Version
	memcpy(&buff[0],GP_SYSVER,4);
	memcpy(&buff[4],dVersion,6);
	ChangeLowHighByte(buff,10);
	memcpy(GlpSysVersion,buff,10);
	//Version Date
	memcpy(buff,GP_RELEASE_DATE,4);
	buff[4]= 0;
	work= gatoi(buff);
	//Year
	*GlpVDate= BINtoBCD16((unsigned short)work);
	memcpy(buff,&GP_RELEASE_DATE[4],2);
	buff[2]= 0;
	work= gatoi(buff)*100;
	memcpy(buff,&GP_RELEASE_DATE[6],2);
	buff[2]= 0;
	work+= gatoi(buff);
	//Year
	*(GlpVDate+ 1)= BINtoBCD16((unsigned short)work);
	//Power On Clesr
	*GlpSysCulc= 0;
	//WDT Time
	*GlpSysWDTCnt= WDT_INIT;
//	*GlpSysCulcErredSetep= (unsigned short)-1;
	Read2FdevArea();		//Copy to F Device
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PlcSpecialDevClear()										*/
/*	??	: ���ꃌ�W�X�N���A�B											*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	PlcSpecialDevClear(int mode1,int mode2,int mode3)
{
	unsigned short*	DevAddr;
	int	i;

	if(mode1 == ON){		//DEVICE1 Clear
		*GlpSysState &= ~GLP_SYS_STATE_LOW_BATT;		//F002C
		*GlpSysRunMode &= ~GLP_SYS_RUN_STP_EXT;		//F0068
		*GlpSysCulcErrSetep= 0;	//GLP_SYS_CULC_ERR_STEP;		//F0120
		*GlpSysSelfTest= 0;		//GLP_SYS_SELF_TEST;			//F0140
	}
	if(mode2 == ON){		//DEVICE2 Clear
		*GlpSysState &= ~GLP_SYS_STATE_LOW_BAT_SET;	//F002D
		*GlpSysRunMode &= ~GLP_SYS_RUN_FILTER_SET;	//F0069
		*GlpSysCulcErrSetep= 0;	//GLP_SYS_CULC_ERRED_STEP;	//F0121
	}
	if(mode3 == ON){		//ELSE DEVICE Clear
		//Bit
		DevAddr= GlpSysMode;
		*DevAddr++;			//F0000�̓N���A���Ȃ�
		*DevAddr++ = 0;		//F0010
		*DevAddr++ &= (GLP_SYS_STATE_LOW_BATT | GLP_SYS_STATE_LOW_BAT_SET);
		*DevAddr++ &= 0x01;	//F0030 SysError�͏����Ȃ�
		*DevAddr++ = 0;		//F0040
		*DevAddr++ = 0;		//F0050
		*DevAddr++ &= (GLP_SYS_RUN_STP_EXT | GLP_SYS_RUN_FILTER_SET);
		*DevAddr++ = 0;		//F0070
		*DevAddr++ &= (GLP_SYS_TIME_TIME | GLP_SYS_TIME_30S);		//F0080
		*DevAddr++ = 0;		//F0090
		//Word
		DevAddr= GlpSysNowSc;		//F1100
		for(i= 0; i < 10; i++){
			*DevAddr++ = 0;		//F1100->F1190
		}
		DevAddr++;			//F1200
		DevAddr++;			//F1210
		for(i= 0; i < 18; i++){
			*DevAddr++ = 0;		//F1220->F1390
		}
		DevAddr++;			//F1400
		for(i= 0; i < 21; i++){
			*DevAddr++ = 0;		//F1410->F1610
		}
		DevAddr++;			//F1620(WDT)
		for(i= 0; i < 24; i++){
			*DevAddr++ = 0;		//F1630->F1860
		}
	}
}
void	PlcDevAllClear(void)
{
	int	i;

	for(i= 0; i < TBQ(AllClearWordDevTbl); i++){
		memset(AllClearWordDevTbl[i].startAddr,0,AllClearWordDevTbl[i].len*2);	
	}
	PlcSpDeviceClear();
}
void	InitExtInf(void)
{
	volatile unsigned char *PortAddr;
	unsigned char	DefFiter;
	int		j;

#ifdef	WIN32
	return;
#endif
	//DataClear
	PortAddr= (unsigned char *)((unsigned int)extInfo.ExtInfo[0].address+EXT_IO_OUT_ADDR);
	*PortAddr++ = 0xff;
	*PortAddr++ = 0xff;

	//IO INput16/16
	PortAddr= (volatile unsigned char *)((unsigned int)extSlotInfo.ExtInfo[0].address+FPG_PC_REG00);
	*PortAddr++ = 0x00;
	//Out Put
	*PortAddr++ = 0x00;
	*PortAddr++ = 0x00;
	*PortAddr++ = 0x00;
	*PortAddr++ = 0x00;
	//Set Io Filter
	DefFiter= 0x00;
	PortAddr= (volatile unsigned char *)((unsigned int)extSlotInfo.ExtInfo[0].address+EXT_IO_FILT_ADDR);
	for(j= 0; j < 2; j++){	//16-16
		*PortAddr++ = DefFiter;		//No Filter
	}
	//Set Io Interrupt
	PortAddr= (volatile unsigned char *)((unsigned int)extSlotInfo.ExtInfo[0].address+EXT_IO_INT_ADDR);
	for(j= 0; j < 2; j++){	//16-16
		*PortAddr++ = 0x00;		// No Interrupt
	}
}
void	StopPortOff(void)
{
	//Stop Mode Out Off
//	if(GlpRunMode == 'S'){
		if((*GlpSysRunMode & GLP_SYS_RUN_STP_EXT) == 0){
			//EXT Mode������������B
			InitExtInf();
			//Port��Off����B
			PortOutOffProc();
		}
//	}
}
void	ClearTimeInf(void)
{
	memset(&TimCnt,0,sizeof(TimCnt));
	memset(BefTimeOnOffInt,0,sizeof(BefTimeOnOffInt));
	memset(ResetTimeOnOffInt,0,sizeof(ResetTimeOnOffInt));
	WdtStartFlag= 0;

}
void	SetOnOffSignal(int mode)
{
//	if(mode == 0){	//Stop
//		//�펞ON
//		StopPortOff();
//	}
//	*GlpSysSignal &= ~GLP_SYS_SIG_ON;
//	//�펞OFF
//	*GlpSysSignal &= ~GLP_SYS_SIG_OFF;
	//���Z���N���A
	*GlpSysCulc &= ~GLP_SYS_CULC_CARRY;
	*GlpSysCulc &= ~GLP_SYS_CULC_ZERO;
}
int	Bcd2Bin2(int data)
{
	int	ret;

	ret= (((data & 0xf0) >> 4) * 10) + (data & 0x0f);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PlcWriteTime()											*/
/*	??	: �o�k�b��莞�Ԃ�ݒ肷��B								*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
extern	int	GetMaxDay(int year,int mon);
void	PlcWriteTime(int mode)
{
	RTC_DATA SetData;
#ifdef	OLD     //  200804101810
	SetData.year= Bcd2Bin2(*GlpSysYY);
	SetData.mon= Bcd2Bin2(*GlpSysMM);
	SetData.day= Bcd2Bin2(*GlpSysDD);
	SetData.hour= Bcd2Bin2(*GlpSysHH);
	SetData.min= Bcd2Bin2(*GlpSysMIN);
	SetData.sec= Bcd2Bin2(*GlpSysSS);
#else
	SetData.year= (*GlpSysYY);
	SetData.mon= (*GlpSysMM);
	SetData.day= (*GlpSysDD);
	SetData.hour= (*GlpSysHH);
	SetData.min= (*GlpSysMIN);
	SetData.sec= (*GlpSysSS);
#endif
	if(mode == 1){
		if(SetData.sec >= 0x30){
			SetData.sec= 0;
			SetData.min++;
			if(SetData.min > 59){
				SetData.min= 0;
				SetData.hour++;
				if(SetData.hour > 23){
					SetData.day++;
					if(SetData.day > GetMaxDay(SetData.year,SetData.mon)){
						SetData.day= 1;
						SetData.mon++;
						if(SetData.mon > 12){
							SetData.mon= 1;
							SetData.year++;
						}
					}
				}
			}
		}else{
			SetData.sec= 0;
		}
	}
	CheckSendDateTime(&SetData,0);
}
int	GetParaIOIdx(void)
{
	int		i;
	PARA_IO*	param;
	int		cnt;

#ifdef	WIN32
	param= (PARA_IO*)&GpFont[PARAM_SLOT_START];
	cnt= GpFont[PARAM_SLOT_CNT+3];
#else
	param= (PARA_IO*)PARAM_SLOT_START;
	cnt= *(int *)PARAM_SLOT_CNT;
#endif
	for(i= 0; i < cnt; i++){
		if((param->ModuleID & 0xf0) == EXT_IO_IO){
			break;
		}
		param++;
	}
	return(i);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetExtIntrrupt()											*/
/*	??	: �h?�n�C��??���v�g�̃�?�h��ݒ肷��B					*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SetExtIntrrupt(void)
{
	int		i;
	volatile unsigned char *PortAddr;
	unsigned char		OutData[MAX_IO_INT/8];
	int		sidx;		//Slot ID
	GLP_IO_INFO*	IoInfo;

	if(PlcDataSram.ParamTableCnt <= 0){		return;	}
	memset(OutData, 0, sizeof(OutData));
	sidx= GetPioSlotNo();		//Slot No
#ifdef	WIN32
	PortAddr= (volatile unsigned char *)GetWin32Port();
#else
	PortAddr= (volatile unsigned char *)((unsigned int)extSlotInfo.ExtInfo[sidx].address+EXT_IO_INT_ADDR);
#endif
	IoInfo= &PlcDataSram.GlpIoInfo[sidx];
	for(i= 0; i < MAX_IO_INT; i++){
		if(IoInfo->InterruptUse == IO_USE){	//Interrupt Use
			if(EntryIoInt[i] != 0xffff){	//Interrupt rtn setting
				OutData[i/8] |= IoInfo->InterVal[i/8] & (0x03 << (i%8)/2*2);
			}
		}
	}
	*PortAddr++ = OutData[0] & 0xff;
	*PortAddr = OutData[1] & 0xff;
}
/*----------------------------------------------------------------------*/
/*	�֐���	: ExtBordCheck()											*/
/*	??	: �ڑ�??�h��?�F�b�N����B								*/
/*			  Filter�͐ݒ�l�ɁAInterrupt�͂Ȃ��ɐݒ肷��B				*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
const	int	FilterChangeTbl[16]={
	0x00,		//0ms
	0x01,		//1ms
	0x04,		//2ms
	0x06,		//3ms
	0x09,		//4ms    
	0x0b,		//5ms    11
	0x0e,		//6ms    14
	0x11,		//7ms    17
	0x13,		//8ms    19
	0x16,		//9ms    22
	0x18,		//10ms   24
	0x25,		//15ms   37
	0x34,		//20ms   52
};
void	ExtBordCheck(void)
{
	volatile	unsigned char	*addr;
	unsigned char	id_data;
//    int		saveSyscfg;
	volatile unsigned char *PortAddr;
	int		i,j;
	unsigned char	DefFiter;
	int		version1,version2;

	memset(&extInfo,0,sizeof(extInfo));
	memset(&extSlotInfo,0,sizeof(extSlotInfo));
#ifdef	WIN32
	extInfo.extCnt= 0;
	extInfo.ExtInfo[extInfo.extCnt].ID= EXT_IO_I16O16;
	sprintf(&extInfo.ExtInfo[extInfo.extCnt].Version[0],"%02X%02X",0,3);
	extInfo.ExtInfo[extInfo.extCnt++].SlotNo= 0;
	extSlotInfo.extCnt= 0;
	extSlotInfo.ExtInfo[extSlotInfo.extCnt].ID= EXT_IO_I16O16;
	extSlotInfo.ExtInfo[extSlotInfo.extCnt++].SlotNo= 1;
	return;
#endif
	addr= (volatile	unsigned char *)(EXT_IO_ADDR);
//	addr= (volatile	unsigned char *)(EXT_IO_ADDR+0x100);
	extInfo.extCnt= 0;
//	_di();
//	saveSyscfg=rSYSCFG;
//	rSYSCFG=CACHOFF; 
	*GlpSysModukeSts= 0;
	for(i= 0; i < MAX_EXT_CNT; i++){
		id_data= *addr;
		extSlotInfo.ExtInfo[i].SlotNo= i;
		if((id_data != 0xff) && (id_data != 0x00)){
			version1 = *(addr+2);
			version2 = *(addr+3);

			extInfo.ExtInfo[extInfo.extCnt].ID= id_data;
			extInfo.ExtInfo[extInfo.extCnt].SlotNo= i;
			sprintf(&extInfo.ExtInfo[extInfo.extCnt].Version[0],"%02X%02X",version2,version1);
			extInfo.ExtInfo[extInfo.extCnt++].address= (unsigned char*)addr;
			extSlotInfo.ExtInfo[i].ID= id_data;
			extSlotInfo.ExtInfo[i].address= (unsigned char*)addr;
			*GlpSysModukeSts |= AndTable[i];
		}
		addr += EXT_IO_OFFSET;
		if((id_data & 0xf0) != EXT_IO_IO){	continue;	}
		//IO INput16/16
		PortAddr= (volatile unsigned char *)((unsigned int)extSlotInfo.ExtInfo[i].address+FPG_PC_REG00);
		*PortAddr++ = 0x00;
		//Out Put
		*PortAddr++ = 0x00;
		*PortAddr++ = 0x00;
		*PortAddr++ = 0x00;
		*PortAddr++ = 0x00;
		//Set Io Filter
		DefFiter= 0x00;
		if(PlcDataSram.ParamTableCnt > 0){	//Parameter File
//			DefFiter= (unsigned char)FilterChangeTbl[PlcDataSram.CommDefFilter & 0x0f];
			DefFiter= PlcDataSram.CommDefFilter & 0x7f;
		}
		PortAddr= (volatile unsigned char *)((unsigned int)extSlotInfo.ExtInfo[i].address+EXT_IO_FILT_ADDR);
		for(j= 0; j < 2; j++){	//16-16
			*PortAddr++ = DefFiter;		//No Filter
		}
		//Set Io Interrupt
		PortAddr= (volatile unsigned char *)((unsigned int)extSlotInfo.ExtInfo[i].address+EXT_IO_INT_ADDR);
		for(j= 0; j < 2; j++){	//16-16
			*PortAddr++ = 0x00;		// No Interrupt
//			*PortAddr++ = 0xaa;		// Riging
		}

	}
//    rSYSCFG=saveSyscfg;
//	_ei();
	//Interrupt Mask Off
	SetIntMask(BIT_EINT4567);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: Bin2Bcd2()												*/
/*	??	: �o�C�i��?����a�b�c�ϊ������i�a�b�c�Q���j				*/
/*	����	: int data:�o�C�i��?�f??									*/
/*	�߂�l	: �a�b�c�f??												*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	Bin2Bcd2(int data)
{
	int	ret;

	ret= ((data / 10) << 4)+ (data % 10);
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PlcTimeSetNowTime()										*/
/*	??	: ���v�f??����ꃌ�W�X?�ɐݒ肷��						*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
#ifdef	OLD
// bcd �� ǥ��   200804101810
void	PlcTimeSetNowTime(void)
{
	if(*GlpSysTimeMode & GLP_SYS_TIME_TIME){
	}else{
		*GlpSysYY = (Bin2Bcd2(SystemTime.year/100) << 16) + Bin2Bcd2(SystemTime.year);
		*GlpSysMM = Bin2Bcd2(SystemTime.mon);
		*GlpSysDD = Bin2Bcd2(SystemTime.day);
		*GlpSysHH = Bin2Bcd2(SystemTime.hour);
		*GlpSysMIN = Bin2Bcd2(SystemTime.min);
		*GlpSysSS = Bin2Bcd2(SystemTime.sec);
		*GlpSysWW = SystemTime.week;
	}
}
#else	
// bin ���� ǥ�� 
void	PlcTimeSetNowTime(void)
{
	if(*GlpSysTimeMode & GLP_SYS_TIME_TIME){
	}else{
		*GlpSysYY = ((SystemTime.year/100) << 16) + (SystemTime.year);
		*GlpSysMM = SystemTime.mon;
		*GlpSysDD = SystemTime.day;
		*GlpSysHH = SystemTime.hour;
		*GlpSysMIN = SystemTime.min;
		*GlpSysSS = SystemTime.sec;
		*GlpSysWW = SystemTime.week;
	}
}
#endif
/*----------------------------------------------------------------------*/
/*	�֐���	: SetClearFilterInt()										*/
/*	??	: �t�B��??�����N���A����B								*/
/*	����	: int sidx:�X���b�g�ԍ�										*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SetClearFilterInt(int sidx)
{
	int		i;
	volatile unsigned char *PortAddr;

#ifdef	WIN32
	PortAddr= (volatile unsigned char *)GetWin32Port();
#else
	PortAddr= (volatile unsigned char*)(extSlotInfo.ExtInfo[sidx].address+ FPG_FC_REG00);
#endif
	for(i= 0; i < 2; i++){
		*PortAddr++ = 0x00;
	}
#ifdef	WIN32
	PortAddr= (volatile unsigned char *)GetWin32Port();
#else
	PortAddr= (volatile unsigned char*)(extSlotInfo.ExtInfo[sidx].address+ FPG_IC_REG00);
#endif
	for(i= 0; i < 4; i++){
		*PortAddr++ = 0x00;
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetClearFunc()											*/
/*	??	: �h�n??�h�̃t?���N�V�������N���A����B					*/
/*	����	: int sidx:�X���b�g�ԍ�										*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SetClearFunc(int sidx)
{
	int		i;
	volatile unsigned char *PortAddr;

#ifdef	WIN32
	PortAddr= (volatile unsigned char *)GetWin32Port();
#else
	PortAddr= (volatile unsigned char*)(extSlotInfo.ExtInfo[sidx].address+ FPG_PC_REG00);
#endif
	for(i= 0; i < 5; i++){	//In;0x10,Out:0x11->0x14
		*PortAddr++ = 0x00;
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetTenkeyPara()											*/
/*	??	: �h�n??�h��Tenkey�t?���N�V�I����ݒ肷��B				*/
/*	����	: int sidx:�X���b�g�ԍ�										*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SetTenkeyPara(int sidx)
{
	volatile unsigned char *PortAddr;

#ifdef	WIN32
	PortAddr= (volatile unsigned char *)GetWin32Port();
#else
	PortAddr= (volatile unsigned char*)(extSlotInfo.ExtInfo[sidx].address+ FPG_PC_REG00);
#endif
	if(PlcDataSram.GlpIoInfo[sidx].TenkeyUse == IO_USE){
		//Tenkey_In param->matrix.Inreg
		if(PlcDataSram.GlpIoInfo[sidx].Tenkey_Inreg == 0){	*PortAddr= 0x00;		}
		else{									*PortAddr= 0x01;		}
		//Tenkey_Out param->matrix.Outreg
		if(PlcDataSram.GlpIoInfo[sidx].Tenkey_Outreg == 0){	*(PortAddr+1)= 0x55;	}
		else{									*(PortAddr+3)= 0x55;	}
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetTenkeyPara()											*/
/*	??	: �h�n??�h��7Seg�t?���N�V�I����ݒ肷��B				*/
/*	����	: int sidx:�X���b�g�ԍ�										*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	Set7SegPara(int sidx)
{
	volatile unsigned char*	PortAddr;

#ifdef	WIN32
	PortAddr= (volatile unsigned char *)GetWin32Port();
#else
	PortAddr= (volatile unsigned char*)(extSlotInfo.ExtInfo[sidx].address+ FPG_PC_REG00);
#endif
	if(PlcDataSram.GlpIoInfo[sidx].Seg7Use == IO_USE){
		//7Seg Out
		if(PlcDataSram.GlpIoInfo[sidx].Seg7_Outreg == 0){
			*(PortAddr+1)= 0x55;
			*(PortAddr+3)= 0xaa;
			*(PortAddr+4)= 0xaa;
		}else{
			*(PortAddr+1)= 0xaa;
			*(PortAddr+2)= 0xaa;
			*(PortAddr+4)= 0x55;
		}
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetTenkeyPara()											*/
/*	??	: �h�n??�h��Sio�t?���N�V�I����ݒ肷��B					*/
/*	����	: int sidx:�X���b�g�ԍ�										*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SetSyncSio(int sidx)
{
	volatile unsigned char *PortAddr;
	int	Bit;

#ifdef	WIN32
	PortAddr= (volatile unsigned char *)GetWin32Port();
#else
	PortAddr= (volatile unsigned char*)(extSlotInfo.ExtInfo[sidx].address+ FPG_PC_REG00);
#endif
	if(PlcDataSram.GlpIoInfo[sidx].SyncSioUse == IO_USE){
		//Sio Out
		//param->syncSio.Outreg
		if(PlcDataSram.GlpIoInfo[sidx].Sync_Outreg == 0){
			*(PortAddr+2)= (*(PortAddr+2) & 0xc0) | 0x15;
		}else{
			*(PortAddr+4)= (*(PortAddr+4) & 0xc0) | 0x15;
		}
#ifdef	WIN32
		PortAddr= (volatile unsigned char *)GetWin32Port();
#else
		PortAddr= (volatile unsigned char*)(extSlotInfo.ExtInfo[sidx].address+ FPG_SI_REG00);
#endif
		//param->syncSio.DataBit
//		Bit= PlcDataSram.GlpIoInfo[sidx].Sync_Bit + 4;
		Bit= PlcDataSram.GlpIoInfo[sidx].Sync_Bit;
		//Data Count
		*PortAddr++= (PlcDataSram.GlpIoInfo[sidx].Sync_DataCnt)* Bit;
		//Data Bit
		*PortAddr++= Bit;
		//DataOut
		SyncDataOut(sidx);
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: IOScanProc()												*/
/*	??	: �h�n??�h���X�L����(TenKey)����B						*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	IOScanProc(void)
{
	volatile unsigned char *PortAddr;
	unsigned short*	GlpTenkeyData;
	int sidx;

	//PIO SEarch
	sidx= GetPioSlotNo();
	if(sidx == NG){
		return;
	}

	//Tenkey Check
	if(PlcDataSram.GlpIoInfo[sidx].TenkeyUse == IO_USE){
#ifdef	WIN32
		PortAddr= (volatile unsigned char *)GetWin32Port();
#else
		PortAddr= (volatile unsigned char*)(extSlotInfo.ExtInfo[sidx].address+ FPG_SW_REG00);
#endif
		//Data Area
		if(PlcDataSram.GlpIoInfo[sidx].TenkeyDevUse == IO_USE){
			GlpTenkeyData= (unsigned short*)(PlcDataSram.GlpIoInfo[sidx].TenkeyDevAddr+2);
		}else{
			GlpTenkeyData= PlcDataSram.GlpIoInfo[sidx].TenkeyDevAddr;
		}
		*GlpTenkeyData= *PortAddr++;
		*GlpTenkeyData += *PortAddr++ << 8;
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: GetSlotPidx()												*/
/*	??	: �h�n??�h�̃X���b�g�ԍ�����o������?�e������?�h�c�w�ɕϊ�����B*/
/*	����	: int slotNo:�X���b�g�ԍ�									*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	GetSlotPidx(int slotNo)
{
	int		ret;
	int		i;
	PARA_IO*	param;
	int		cnt;

#ifdef	WIN32
	param= (PARA_IO*)&GpFont[PARAM_SLOT_START];
	cnt= GpFont[PARAM_SLOT_CNT+3];
#else
	param= (PARA_IO*)PARAM_SLOT_START;
	cnt= *(int *)PARAM_SLOT_CNT;
#endif
	for(i= 0; i < cnt; i++){
		if(param->slotNo == slotNo){
			ret = i;
			break;
		}
		param++;
	}
	return(ret);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetFilter()												*/
/*	??	: �h�n??�h�̃t�B��??��ݒ肷��B						*/
/*	����	: int pidx:Parameter Index									*/
/*			  int sidx:Slot No											*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SetFilter(int pidx,int sidx)
{
	volatile unsigned char *PortAddr;
	unsigned short	data;
	unsigned short	data2;

#ifdef	WIN32
	PortAddr= (volatile unsigned char *)GetWin32Port();
#else
	PortAddr= (volatile unsigned char *)((unsigned int)extSlotInfo.ExtInfo[sidx].address+EXT_IO_FILT_ADDR);
#endif
	if(PlcDataSram.GlpIoInfo[sidx].FilterUse == IO_USE){		//Module Filter Use
//		data  = PlcDataSram.GlpIoInfo[sidx].FilterVal[0];
//		data += PlcDataSram.GlpIoInfo[sidx].FilterVal[1] << 8;
		data  = PlcDataSram.GlpIoInfo[sidx].FilterVal[0];
		data2 = PlcDataSram.GlpIoInfo[sidx].FilterVal[1];
	}else{
//		data= (PlcDataSram.CommDefFilter & 0x0f) | ((PlcDataSram.CommDefFilter & 0x0f) << 4);
		data= PlcDataSram.CommDefFilter;
		data2= PlcDataSram.CommDefFilter;
	}
//	*PortAddr++ = (unsigned char)FilterChangeTbl[data & 0x000f];
//	*PortAddr++ = (unsigned char)FilterChangeTbl[(data & 0x00f0) >> 4];
	*PortAddr++ = (unsigned char)data & 0x007f;
	*PortAddr++ = (unsigned char)data2 & 0x007f;
}
void	SetDefaultFilter(int sidx)
{
	volatile unsigned char *PortAddr;
	unsigned short	data;

#ifdef	WIN32
	PortAddr= (volatile unsigned char *)GetWin32Port();
#else
	PortAddr= (volatile unsigned char *)((unsigned int)extSlotInfo.ExtInfo[sidx].address+EXT_IO_FILT_ADDR);
#endif
//	data= (PlcDataSram.CommDefFilter & 0x0f) | ((PlcDataSram.CommDefFilter & 0x0f) << 4);
//	*PortAddr++ = (unsigned char)FilterChangeTbl[data & 0x000f];
//	*PortAddr++ = (unsigned char)FilterChangeTbl[(data & 0x00f0) >> 4];
	data= PlcDataSram.CommDefFilter;
	*PortAddr++ = (unsigned char)data & 0x007f;
	*PortAddr++ = (unsigned char)data & 0x007f;
}
/*----------------------------------------------------------------------*/
/*	�֐���	: InitSlotModule()											*/
/*	??	: �h�n??�h�̏����ݒ��ݒ肷��B							*/
/*	����	: int slotNo:�X���b�g�ԍ�									*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	InitSlotModule(int slotNo)
{
	int	pidx;

	if(PlcDataSram.ParamTableCnt > 0){	//Parameter File
		pidx= GetSlotPidx(slotNo);	//�����X���b�g�ԍ��̃A�h���X�C���f�b�N�X
		if((pidx != NG) &&
		  ((extSlotInfo.ExtInfo[slotNo].ID & 0xf0) ==	EXT_IO_IO)){			//I/O
			SetExtIntrrupt();	//IO Interrupt Set
			SetFilter(pidx,slotNo);		//Filter
			SetClearFunc(slotNo);		//
			SetTenkeyPara(slotNo);	//10Key
			Set7SegPara(slotNo);		//7Seg
			SetSyncSio(slotNo);		//Sync Sio
		}
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: Seg7DataOut()												*/
/*	??	: �V�r�����f??���o�͂���B								*/
/*	����	: int sidx													*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	Seg7DataOut(int sidx)
{
	volatile unsigned char *PortAddr;
	unsigned short*	Glp7SegData;

	//Data Area
	if(PlcDataSram.GlpIoInfo[sidx].Seg7DevUse == IO_USE){
		Glp7SegData= (unsigned short*)(PlcDataSram.GlpIoInfo[sidx].Seg7DevAddr+1);
	}else{
		Glp7SegData= PlcDataSram.GlpIoInfo[sidx].Seg7DevAddr;
	}
#ifdef	WIN32
	PortAddr= (volatile unsigned char *)GetWin32Port();
#else
	PortAddr= (volatile unsigned char*)(extSlotInfo.ExtInfo[sidx].address+ FPG_7S_REG00);
#endif
	*PortAddr++ = (unsigned char)*Glp7SegData++;
	*PortAddr++ = (unsigned char)*Glp7SegData++;
	*PortAddr++ = (unsigned char)*Glp7SegData++;
	*PortAddr++ = (unsigned char)*Glp7SegData++;
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SyncDataOut()												*/
/*	??	: �r�����f??���o�͂���B									*/
/*	����	: int sidx													*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SyncDataOut(int sidx)
{
	volatile unsigned char *PortAddr;
	unsigned short *DataAddr;
	int		cnt,i,Bit;

	if(PlcDataSram.GlpIoInfo[sidx].SyncSioDevUse == IO_USE){
		DataAddr= (unsigned short*)(PlcDataSram.GlpIoInfo[sidx].SyncSioDevAddr+2);
	}else{
		DataAddr= PlcDataSram.GlpIoInfo[sidx].SyncSioDevAddr;
	}
#ifdef	WIN32
	PortAddr= (volatile unsigned char *)GetWin32Port();
#else
	PortAddr= (volatile unsigned char*)(extSlotInfo.ExtInfo[sidx].address+ FPG_SI_REG02);
#endif
	Bit= PlcDataSram.GlpIoInfo[sidx].Sync_Bit;
	cnt= PlcDataSram.GlpIoInfo[sidx].Sync_DataCnt;
#ifdef	XXXXX
	if(Bit == 4){
		for(i= 0; i < cnt; i++){
			switch(i%4){
			case 0:	*PortAddr    = (*DataAddr   & 0xf000) >>  8;	break;
			case 1:	*PortAddr++ += (*DataAddr   & 0x0f00) >>  8;	break;
			case 2:	*PortAddr    = (*DataAddr   & 0x00f0);			break;
			case 3:	*PortAddr++ += (*DataAddr++ & 0x000f);			break;
			}
		}
	}else{
		for(i= 0; i < cnt; i++){
			switch(i%2){
			case 0:	*PortAddr++ = (*DataAddr   & 0xff00) >> 8;	break;
			case 1:	*PortAddr++ = (*DataAddr++ & 0x00ff);		break;
			}
		}
	}
#else
	if(Bit == 4){
		for(i= 0; i < cnt; i++){
			switch(i%2){
			case 0:	*PortAddr    = (*DataAddr++ & 0x000f) << 4;	break;
			case 1:	*PortAddr++ += (*DataAddr++ & 0x000f);		break;
			}
		}
	}else{
		for(i= 0; i < cnt; i++){
			*PortAddr++ = (*DataAddr++ & 0x00ff);		break;
		}
	}
#endif
	if(PlcDataSram.GlpIoInfo[sidx].SyncSioDevUse == IO_USE){
		DataAddr= (unsigned short*)(PlcDataSram.GlpIoInfo[sidx].SyncSioDevAddr+2);
	}else{
		DataAddr= PlcDataSram.GlpIoInfo[sidx].SyncSioDevAddr;
	}
	memcpy(&PlcDataSram.GlpIoInfo[sidx].SyncSioData[0],DataAddr,PlcDataSram.GlpIoInfo[sidx].SyncSioDataCnt*2);
}
/*----------------------------------------------------------------------*/
/*	�֐���	: IOOutProc()												*/
/*	??	: �h?�n??�h�̏o�͂��s���B								*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	IOOutProc(void)
{
	int		andData;
	int		sidx;
	int		i;
	unsigned short *DataAddr;

	//Io Module Setting Check
	if(GlpSysIoInit != 0){
		for(i= 0, andData= 0x0001; i < MAX_SLOT_CNT; i++,andData <<= 1){
			if(GlpSysIoInit & andData){
				InitSlotModule(i);
				GlpSysIoInit &= ~andData;
			}
		}
	}
	//PIO Search
	sidx= GetPioSlotNo();
	if(sidx == NG){	return;	}
	//7Seg Check
	if(PlcDataSram.GlpIoInfo[sidx].Seg7Use == IO_USE){	Seg7DataOut(sidx);	}
	//Sync Sio Check
	if(PlcDataSram.GlpIoInfo[sidx].SyncSioUse == IO_USE){
		if(PlcDataSram.GlpIoInfo[sidx].SyncSioDevUse == IO_USE){
			DataAddr= (unsigned short*)(PlcDataSram.GlpIoInfo[sidx].SyncSioDevAddr+2);
		}else{
			DataAddr= PlcDataSram.GlpIoInfo[sidx].SyncSioDevAddr;
		}
		if(memcmp(&PlcDataSram.GlpIoInfo[sidx].SyncSioData[0],DataAddr,PlcDataSram.GlpIoInfo[sidx].SyncSioDataCnt*2) != 0){
			SyncDataOut(sidx);
		}
	}
	//Patarn Check

}
void	SetTimerKind(unsigned short* time_data)
{
	int	i,j,k;
	int	widx;
	int	OrData;
	int	AndData;
	int	Cnt;
	int	TotalCnt;

	memset(TimerCost,0,sizeof(TimerCost));
	TotalCnt= 0;
	for(i= 0,j= 2; i < 2; i++,j--){
#ifdef	WIN32
		widx= Get16Bit(time_data[i*2]) / 16;
		OrData= AndTable[Get16Bit(time_data[i*2])%16];
		Cnt= Get16Bit(time_data[i*2+1])- Get16Bit(time_data[i*2])+ 1;
#else
		widx= time_data[i*2] / 16;
		OrData= AndTable[time_data[i*2]%16];
		Cnt= time_data[i*2+1]- time_data[i*2]+ 1;
#endif
		TotalCnt += Cnt;
		if(TotalCnt > Device_Length_T_BIT){
			break;
		}
		for(k= 0; k < Cnt; k++){
			TimerCost[j].TimerValu[widx] |= OrData;
			OrData <<= 1;
			if(OrData > 0x8000){
				widx++;
				OrData= 0x0001;
			}
		}
	}
	//�ݒ肳��Ă��Ȃ��A�h���X�͂P�O�����Ƃ���B
	AndData= 0x0001;
	widx= 0;
	for(i= 0; i < Device_Length_T_BIT; i++){
		if((TimerCost[1].TimerValu[widx] & AndData) ||
			(TimerCost[2].TimerValu[widx] & AndData) ){
		}else{
			TimerCost[1].TimerValu[widx] |= AndData;
		}
		AndData <<= 1;
		if(AndData > 0x8000){
			AndData= 0x0001;
			widx++;
		}
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: ParamIO2Fdevice()											*/
/*	??	: �p����??�t?�C�����ݒ�l�����o���B					*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
const int	slotBit[MAX_SLOT_CNT]={
	0x0001,0x0002,0x0004,0x0008,0x0010,0x0020,0x0040,0x0080,
	0x0100,0x0200,0x0400,0x0800,0x1000,0x2000,0x4000,0x8000,
};
int	CheckFilter(unsigned short fdata)
{
	if(fdata <= 0x0d){
		return(OK);
	}else{
		return(NG);
	}
}
int	CheckInterrupt(unsigned short idata)
{
	if(idata <= 0x03){
		return(OK);
	}else{
		return(NG);
	}
}
int	CheckMatrix(unsigned short inreg,unsigned short outreg)
{
	if((inreg <= 0x01) && (outreg <= 0x01)){
		return(OK);
	}else{
		return(NG);
	}
}
int	Check7Seg(unsigned short idata)
{
	if(idata <= 0x01){
		return(OK);
	}else{
		return(NG);
	}
}
int	CheckSyncSio(unsigned short outreg,unsigned short bit,unsigned short dCnt)
{
	int	flag= NG;

	if( (dCnt == 4) || (dCnt == 8) || (dCnt == 12) || (dCnt == 16) || (dCnt == 30) ){
		flag = OK;
	}
	if((flag == OK) && (outreg <= 0x01) && ((bit >= 4) && (bit <= 7)) ){
		return(OK);
	}else{
		return(NG);
	}
}
void	SetInterruptKind(void)
{
	GLP_COMM*	glpComm;

	//2008.04.18
	if(PlcDataSram.ParamTableCnt <= 0){	return;	}
#ifdef	WIN32
	glpComm= (GLP_COMM*)&GpFont[PARAM_GLP_COMM];
#else
	glpComm= (GLP_COMM*)PARAM_GLP_COMM;
#endif
	//Timer Device Seeting
	SetTimerKind(&glpComm->TimerKind[0][0]);
}
void	ParamIO2Fdevice(void)
{
	GLP_COMM*	glpComm;
	PARA_IO*	param;
	int		i,j;
	int		pcnt;
	int		slotNo;
	unsigned short*	sAddr;
	unsigned short	sdata;
	GLP_IO_INFO*	ioinfo;
	int		scanTime;

	//Parameter Version Check
#ifdef	WIN32
	if(memcmp((char*)&GpFont[PLC_PARAM_FILE+4],PlcPassword,strlen(PlcPassword)) != 0){
#else
	if(memcmp((char*)(PLC_PARAM_FILE+4),PlcPassword,strlen(PlcPassword)) != 0){
#endif
		return;
	}
	//Common Area 
#ifdef	WIN32
	glpComm= (GLP_COMM*)&GpFont[PARAM_GLP_COMM];
	pcnt= GpFont[PARAM_SLOT_CNT+3];
#else
	glpComm= (GLP_COMM*)PARAM_GLP_COMM;
	pcnt= *(int*)PARAM_SLOT_CNT;
#endif
	//Common Area Save
	//Debug Out
	PlcDataSram.CommDebugIoUse= glpComm->DebugIoUse;
	if(PlcDataSram.CommDebugIoUse == 0){
		PlcDataSram.CommDebugIoOut= 0;		//���g�p
	}else{
		PlcDataSram.CommDebugIoOut= glpComm->DebugIoOut+1;	//0:No Out,1:Scan Out,2:Numonic Out
	}
	if(PlcDataSram.CommDebugIoUse == 1){
		GlpDbgInf |= GLP_SYS_RUN_DBG_DI_OUT;
	}else{
		GlpDbgInf &= ~GLP_SYS_RUN_DBG_DI_OUT;
	}
//	PlcDataSram.CommDefFilter   = glpComm->DefFilter;
	PlcDataSram.CommDefFilter   = FilterChangeTbl[glpComm->DefFilter];
	
	*GlpSysInpFilter= PlcDataSram.CommDefFilter;
	//Ext Module Setting
	PlcDataSram.CommIoOut       = glpComm->IoOut;		//Stop Io Out
	if(PlcDataSram.CommIoOut == 1){
		*GlpSysRunMode |= GLP_SYS_RUN_STP_EXT;
	}else{
		*GlpSysRunMode &= ~GLP_SYS_RUN_STP_EXT;
	}
	//Scan Time 
	scanTime=  glpComm->ScanTime[0] << 24;
	scanTime+= glpComm->ScanTime[1] << 16;
	scanTime+= glpComm->ScanTime[2] << 8;
	scanTime+= glpComm->ScanTime[3];
	if(scanTime == 0){
		*GlpSysRunMode &= ~GLP_SYS_RUN_CST_SC;
		*GlpSysCscTime= 0;
	}else{
		*GlpSysRunMode |= GLP_SYS_RUN_CST_SC;
		*GlpSysCscTime= scanTime;
	}
	//Timer Interrupt Cycle Time
	sAddr= GlpSysTimeIntrval;
	for(i= 0; i < 8; i++){
		sdata = glpComm->tInt[i].TimerTime[0] << 8;
		sdata += glpComm->tInt[i].TimerTime[1];
		*sAddr++ = sdata;
	}
	//Timer Device Setting
	SetTimerKind(&glpComm->TimerKind[0][0]);

	slotNo= 0x0000;
	memset(&PlcDataSram.GlpIoInfo,0,sizeof(PlcDataSram.GlpIoInfo));
	for(i= 0; i < pcnt; i++){
#ifdef	WIN32
		param= (PARA_IO*)&GpFont[(PARAM_SLOT_START+ PARAM_1SLOT_SIZE*i)];
#else
		param= (PARA_IO*)(PARAM_SLOT_START+ PARAM_1SLOT_SIZE*i);
#endif
		if((param->ModuleID & 0xf0) != EXT_IO_IO){		//NOT IO BOARD
			continue;
		}
		ioinfo= &PlcDataSram.GlpIoInfo[param->slotNo];
		//?�o?�W������ID��(EXT_IO_IO | EXT_IO_I16O16)�̂ݗL��
		if(param->ModuleID != (EXT_IO_IO | EXT_IO_I16O16)){	continue;	}
		//Filter
		ioinfo->FilterUse   = param->filter.UseFlag;
		if(ioinfo->FilterUse == IO_USE){
			ioinfo->FilterDevUse= param->filter.DevUseFlag;
			ioinfo->FilterVal[0]= FilterChangeTbl[param->filter.Val[0] & 0x0f];
			ioinfo->FilterVal[1]= FilterChangeTbl[(param->filter.Val[0] & 0xf0) >> 4];
		}else{
			ioinfo->FilterDevUse= IO_NOUSE;
			ioinfo->FilterVal[0]= 0;
			ioinfo->FilterVal[1]= 0;
		}
		if(ioinfo->FilterDevUse == IO_USE){
			if(GetGLPDevAddr((unsigned short*)&param->filter.DevAddr[0],&sAddr) == OK){
				memcpy(&ioinfo->FilterDev[0],&param->filter.DevAddr[0],4);
				ioinfo->FilterDevAddr= sAddr;
				*sAddr++             = ioinfo->FilterVal[0];
				*sAddr++             = ioinfo->FilterVal[1];
			}else{
				ioinfo->FilterUse= IO_NOUSE;
				ioinfo->FilterDevUse= IO_NOUSE;
			}
		}
		//Interrupt
		ioinfo->InterruptUse   = param->intctl.UseFlag;
		if(ioinfo->InterruptUse == IO_USE){
			ioinfo->InterruptDevUse= param->intctl.DevUseFlag;
			ioinfo->InterVal[0]= param->intctl.Val[0];
			ioinfo->InterVal[1]= param->intctl.Val[1];
		}else{
			ioinfo->InterruptDevUse= IO_NOUSE;
			ioinfo->InterVal[0]= 0;
			ioinfo->InterVal[1]= 0;
		}
		if(ioinfo->InterruptDevUse == IO_USE){
			if(GetGLPDevAddr((unsigned short*)&param->intctl.DevAddr[0],&sAddr) == OK){
				memcpy(&ioinfo->IntDev[0],&param->intctl.DevAddr[0],4);
				ioinfo->IntDevAddr= sAddr;
				for(j= 0; j < 2; j++){
					*sAddr++           = param->intctl.Val[j];
				}
			}else{
				ioinfo->InterruptUse= IO_NOUSE;
				ioinfo->InterruptDevUse= IO_NOUSE;
			}
		}
		//10Key
		ioinfo->TenkeyUse    = param->matrix.UseFlag;
		if(ioinfo->TenkeyUse == IO_USE){
			ioinfo->TenkeyDevUse = param->matrix.DevUseFlag;
			ioinfo->Tenkey_Inreg = param->matrix.Inreg;
			ioinfo->Tenkey_Outreg= param->matrix.Outreg;
		}else{
			ioinfo->TenkeyDevUse = IO_NOUSE;
			ioinfo->Tenkey_Inreg = 0;
			ioinfo->Tenkey_Outreg= 0;
		}
		if(ioinfo->TenkeyUse == IO_USE){
			if(GetGLPDevAddr((unsigned short*)&param->matrix.DevAddr[0],&sAddr) == OK){
				memcpy(&ioinfo->TenkeyDev[0],&param->matrix.DevAddr[0],4);
				ioinfo->TenkeyDevAddr= sAddr;
				if(ioinfo->TenkeyDevUse == IO_USE){
					*sAddr++= param->matrix.Inreg;
					*sAddr++= param->matrix.Outreg;
				}
			}else{
				ioinfo->TenkeyUse= IO_NOUSE;
			}
		}
		//7Seg
		ioinfo->Seg7Use    = param->seg7.UseFlag;
		if(ioinfo->Seg7Use == IO_USE){
			ioinfo->Seg7DevUse = param->seg7.DevUseFlag;
			ioinfo->Seg7_Outreg= param->seg7.Outreg;
		}else{
			ioinfo->Seg7DevUse = IO_NOUSE;
			ioinfo->Seg7_Outreg= 0;
		}
		if(ioinfo->Seg7Use == IO_USE){
			if(GetGLPDevAddr((unsigned short*)&param->seg7.DevAddr[0],&sAddr) == OK){
				memcpy(&ioinfo->Seg7Dev[0],&param->seg7.DevAddr[0],4);
				ioinfo->Seg7DevAddr= sAddr;
				if(ioinfo->Seg7DevUse == IO_USE){
					*sAddr++= param->seg7.Outreg;
				}
			}else{
				ioinfo->Seg7Use= IO_NOUSE;
			}
		}
		//Sync Sio
		ioinfo->SyncSioUse   = param->syncSio.UseFlag;
		if(ioinfo->SyncSioUse == IO_USE){
			ioinfo->SyncSioDevUse= param->syncSio.DevUseFlag;
			ioinfo->Sync_Outreg  = param->syncSio.Outreg;
			ioinfo->Sync_DataCnt = param->syncSio.Count;
			ioinfo->Sync_Bit     = param->syncSio.DataBit;
		}else{
			ioinfo->SyncSioDevUse= IO_NOUSE;
			ioinfo->Sync_Outreg  = 0;
			ioinfo->Sync_DataCnt = 0;
			ioinfo->Sync_Bit     = 0;
		}
		if(ioinfo->SyncSioUse == IO_USE){
			if(GetGLPDevAddr((unsigned short*)&param->syncSio.DevAddr[0],&sAddr) == OK){
				memcpy(&ioinfo->SyncSioDev[0],&param->syncSio.DevAddr[0],4);
				ioinfo->SyncSioDevAddr= sAddr;
				if(ioinfo->SyncSioDevUse == IO_USE){
					*sAddr++= param->syncSio.Outreg;
					*sAddr++= param->syncSio.DataBit;
					*sAddr++= param->syncSio.Count;
				}
			}else{
				ioinfo->SyncSioUse= IO_NOUSE;
			}
			ioinfo->SyncSioDataCnt= param->syncSio.Count;
		}
		//Defualt Debug
		//IO Setting Flag ON
		slotNo |= slotBit[param->slotNo];
	}
	GlpSysIoInit= slotNo;		//Slot No
}
/*----------------------------------------------------------------------*/
/*	�֐���	: ParamDev2In()												*/
/*	??	: �f�o�C�X�̈���ݒ�l�����o���B						*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	ParamDev2In(int sidx)
{
	int				i,j;
	GLP_IO_INFO*	ioinfo;
	unsigned short*	sAddr;
	unsigned short	sdata;
	unsigned short	sdata2;
	unsigned short	sdata3;
	int	okFlag;

	ioinfo= &PlcDataSram.GlpIoInfo[sidx];
	//Filter
	if((ioinfo->FilterUse == IO_USE) && (ioinfo->FilterDevUse == IO_USE)){
		//Filter Check
		sAddr= ioinfo->FilterDevAddr;
		sdata= *sAddr;
		if( (CheckFilter(sdata & 0xff) == OK) &&
			(CheckFilter(sdata >> 16) == OK) ){
			sAddr= ioinfo->FilterDevAddr;
			ioinfo->FilterVal[0]= (char)*sAddr++;
			ioinfo->FilterVal[1]= (char)*sAddr++;		//2008.08.28
		}else{
			*GlpSysError |= GLP_SYS_ERR_IO;
			*GlpSysSelfTest= GLP_SYS_SELF_BOAD;
		}
	}
	//Interrupt
	if((ioinfo->InterruptUse == IO_USE) && (ioinfo->InterruptDevUse == IO_USE)){
		sAddr= ioinfo->IntDevAddr;
		okFlag= OK;
		for(i= 0; (i < 2) && (okFlag == OK); i++){
			sdata= (char)*sAddr++;
			for(j= 0; j < 4; j++){
				if(CheckInterrupt(sdata & 0x03) == NG){
					okFlag= NG;
					break;
				}
				sdata >>= 2;
			}
		}
		if(okFlag == OK){
			sAddr= ioinfo->IntDevAddr;
			for(i= 0; i < 2; i++){
				ioinfo->InterVal[i]= (char)*sAddr++;
			}
		}else{
			*GlpSysError |= GLP_SYS_ERR_IO;
			*GlpSysSelfTest= GLP_SYS_SELF_PARA;
		}
	}
	//10Key
	if((ioinfo->TenkeyUse == IO_USE) && (ioinfo->TenkeyDevUse == IO_USE)){
		sdata= *ioinfo->TenkeyDevAddr;
		sdata2= *(ioinfo->TenkeyDevAddr+1);
		if(CheckMatrix(sdata,sdata2) == OK){
			ioinfo->Tenkey_Inreg= sdata;
			ioinfo->Tenkey_Outreg= sdata2;
		}else{
			*GlpSysError |= GLP_SYS_ERR_IO;
			*GlpSysSelfTest= GLP_SYS_SELF_PARA;
		}
	}
	//7Seg
	if((ioinfo->Seg7Use == IO_USE) && (ioinfo->Seg7DevUse == IO_USE)){
		sdata= *ioinfo->Seg7DevAddr;
		if(Check7Seg(sdata) == OK){
			ioinfo->Seg7_Outreg= sdata;
		}else{
			*GlpSysError |= GLP_SYS_ERR_IO;
			*GlpSysSelfTest= GLP_SYS_SELF_PARA;
		}
	}
	//Sync Sio
	if((ioinfo->SyncSioUse == IO_USE) && (ioinfo->SyncSioDevUse == IO_USE)){
		sAddr= ioinfo->SyncSioDevAddr;
		sdata= *sAddr++;
		sdata2= *sAddr++;
		sdata3= *sAddr;
		if(CheckSyncSio(sdata,sdata2,sdata3) == OK){
			ioinfo->Sync_Outreg = sdata;
			ioinfo->Sync_Bit    = sdata2;
			ioinfo->Sync_DataCnt= sdata3;
			ioinfo->SyncSioDataCnt= ioinfo->Sync_DataCnt;
		}else{
			*GlpSysError |= GLP_SYS_ERR_IO;
			*GlpSysSelfTest= GLP_SYS_SELF_PARA;
		}
	}
	GlpSysIoInit= slotBit[sidx];		//Slot No
}
void	FilterChange(void)
{
	PlcDataSram.CommDefFilter= *GlpSysInpFilter;
}
unsigned char	ChangeFilterIdx(unsigned short data)
{
	int	i;

	for(i= 0; i < TBQ(FilterChangeTbl); i++){
		if(data <= FilterChangeTbl[i]){
			break;
		}
	}
	if(i < TBQ(FilterChangeTbl)){	return(i);		}
	else{							return(i-1);	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetParamdata()											*/
/*	??	: �p����??���̎��o��									*/
/*	����	: char *wBuff->�p����??�o�̓o�b�t??						*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SetParamdata(char *wBuff)
{
	GLP_COMM*	glpComm;
	PARA_IO*	param;
	GLP_IO_INFO*	ioinfo;
	int			scanTime;
	unsigned short*	sAddr;
	unsigned short	sdata;
	int			pcnt;
	int			i,j;
	GLP_COMM*	fglpComm;

#ifdef	WIN32
	fglpComm= (GLP_COMM*)&GpFont[PARAM_GLP_COMM];
#else
	fglpComm= (GLP_COMM*)PARAM_GLP_COMM;
#endif
	//CommonArea
	glpComm= (GLP_COMM*)wBuff;
	//
	glpComm->DebugIoUse= (unsigned char)fglpComm->DebugIoUse;
	glpComm->DebugIoOut= (unsigned char)fglpComm->DebugIoOut;
	glpComm->DefFilter = (unsigned char)ChangeFilterIdx(PlcDataSram.CommDefFilter);
//	glpComm->IoOut     = (unsigned char)PlcDataSram.CommIoOut;		//Stop Io Out
	if(*GlpSysRunMode & GLP_SYS_RUN_STP_EXT){
		glpComm->IoOut= 1;		//Stop Io Out
	}else{
		glpComm->IoOut= 0;		//Stop Io Out
	}
	//Scan Time 
	scanTime= *GlpSysCscTime;
	glpComm->ScanTime[3]= scanTime & 0xff;
	scanTime >>= 8;
	glpComm->ScanTime[2]= scanTime & 0xff;
	scanTime >>= 8;
	glpComm->ScanTime[1]= scanTime & 0xff;
	scanTime >>= 8;
	glpComm->ScanTime[0]= scanTime;
	//Timer Interrupt Cycle Time
	sAddr= GlpSysTimeIntrval;
	for(i= 0; i < 8; i++){
		sdata= *sAddr++;
		glpComm->tInt[i].TimerTime[0]= sdata >> 8;
		glpComm->tInt[i].TimerTime[1]= sdata & 0xff;
	}
	//Slot Data Set
#ifdef	WIN32
	pcnt= *(char*)(wBuff+PARAM_COMMON_SIZE+3);
#else
	pcnt= *(int*)(wBuff+PARAM_COMMON_SIZE);
#endif
	for(i= 0; i < pcnt; i++){
		param= (PARA_IO*)(wBuff+(PARAM_COMMON_SIZE+4)+PARAM_MODULE_NAME_SIZE+(PARAM_1SLOT_SIZE*i));
		ioinfo= &PlcDataSram.GlpIoInfo[param->slotNo];
		//?�o?�W������ID��(EXT_IO_IO | EXT_IO_I16O16)�̂ݗL��
		if(param->ModuleID != (EXT_IO_IO | EXT_IO_I16O16)){	continue;	}
		//Filter
		if((ioinfo->FilterUse == IO_USE) && (ioinfo->FilterDevUse == IO_USE)){
			param->filter.Val[0]= ChangeFilterIdx(ioinfo->FilterVal[0]);
			param->filter.Val[0] += ChangeFilterIdx(ioinfo->FilterVal[1] << 4);
		}			
		//Interrupt
		if((ioinfo->InterruptUse == IO_USE) && (ioinfo->InterruptDevUse == IO_USE)){
			for(j= 0; j < 4; j++){
				param->intctl.Val[j]= ioinfo->InterVal[j];
			}
		}
		//10Key
		if((ioinfo->TenkeyUse == IO_USE) && (ioinfo->TenkeyDevUse == IO_USE)){
			param->matrix.Inreg = ioinfo->Tenkey_Inreg;
			param->matrix.Outreg= ioinfo->Tenkey_Outreg;
		}
		//7Seg
		if((ioinfo->Seg7Use == IO_USE) && (ioinfo->Seg7DevUse == IO_USE)){
			param->seg7.Outreg= ioinfo->Seg7_Outreg;
		}
		//Sync Sio
		if((ioinfo->SyncSioUse == IO_USE) && (ioinfo->SyncSioDevUse == IO_USE)){
			param->syncSio.Outreg = ioinfo->Sync_Outreg;
			param->syncSio.Count  = ioinfo->Sync_DataCnt;
			param->syncSio.DataBit= ioinfo->Sync_Bit;
		}
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetPlcTimeError()											*/
/*	??	: ���v�f??�G��?����ꃌ�W�X??�ɐݒ肷��B				*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SetPlcTimeError(void)
{
	*GlpSysError |= GLP_SYS_ERR_TIME_WRITE;
	*GlpSysSelfTest= GLP_SYS_SELF_RTC;
}
/*----------------------------------------------------------------------*/
/*	�֐���	: SetLowBattery()											*/
/*	??	: �k����?�a�������������G��?����ꃌ�W�X??�ɐݒ肷��B	*/
/*	����	: int mode:ON->Error,OFF->��								*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	SetLowBattery(int mode)
{
	if(mode == ON){
		*GlpSysState |= (GLP_SYS_STATE_LOW_BATT | GLP_SYS_STATE_LOW_BAT_SET);
		//Set Self Test Code
		*GlpSysSelfTest= GLP_SYS_SELF_BATT;
	}else{
		*GlpSysState &= ~GLP_SYS_STATE_LOW_BATT;
	}
}


//int	ExtIntCnt;
//int	ExtIntProcCnt;
/*----------------------------------------------------------------------*/
/*	�֐���	: PlcIntrruptTask()											*/
/*	??	: �o�k�b���荞��?�X�N�B									*/
/*	����	: STTFrm* pSTT												*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void PlcIntrruptTask(STTFrm* pSTT)
{
	unsigned short i_Bunrui_Code;
	unsigned short*	SaveCodeData;
	unsigned short* EndCodePos;
	int				Kind,Item;

//	ExtIntCnt= 0;
//	ExtIntProcCnt= 0;
	ClearFlag();
	while(1){
		InterTskFlag= 0;		//Interrupt Task Runnning(1)
		WaitFlag(1);
//		ExtIntProcCnt++;
		InterTskFlag= 1;		//Interrupt Task Runnning(1)
		Kind= IntLebel[InterruputOut_idx].IntKind;
		Item= IntLebel[InterruputOut_idx].IntItem;
		IntLebel[InterruputOut_idx].IntKind= -1;	//Clear
		InterruputOut_idx= (InterruputOut_idx+ 1) & 0x07;
		InterruputCnt--;
		if(Kind <= 0){	continue;	}
		if((PlcSignalInf == OFF) ||				//Task Signal
			(RunStopSwitch == OFF)){			//Hardware RUN/STOP
			continue;
		}
		//Code Save
		SaveCodeData= CodeData;
		IntLoad_BoolAddr= Load_BoolAddr;
		memcpy(IntLoad_Bool,Load_Bool,sizeof(IntLoad_Bool));
		Load_BoolAddr= &Load_Bool[0] - 1;
		memset(Load_Bool,0,sizeof(Load_Bool));
		// Vdevice Save
		memcpy(&IntSaveVArea[0],&InDevArea.PlcDev.V[0],Device_Length_V);

		EndCodePos= &PlcDataSram.Inst_Operand_Area[PlcDataSram.Load_Count];
		if(Kind == INT_TIMER){
			CodeData= &PlcDataSram.Inst_Operand_Area[EntryTimerInt[Item].TimerIntEnt];
		}else{
			CodeData= &PlcDataSram.Inst_Operand_Area[EntryIoInt[Item]];
		}
		Intrrupt_IRET= 0;
		while((Intrrupt_IRET == 0) && (CodeData < EndCodePos)){
			i_Bunrui_Code = *CodeData++;
			DeviceAddrError= OK;			//Device Address Error Clear
			Numonic_Table[i_Bunrui_Code].RsCall();
		}
		//Code Resave
		CodeData= SaveCodeData;
		Load_BoolAddr= IntLoad_BoolAddr;
		memcpy(Load_Bool,IntLoad_Bool,sizeof(Load_Bool));
		// Vdevice ReSave
		memcpy(&InDevArea.PlcDev.V[0],&IntSaveVArea[0],Device_Length_V);
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: _IoInterruptProc()										*/
/*	??	: �h?�n�C��??���v�g�����B								*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: ���荞�݋��h?�n->OK,else->NG							*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	_IoInterruptProc(void)
{
	int		i;
	unsigned int	ioInt;
	volatile unsigned char *PortAddr;
	int		idx;

	idx= GetPioSlotNo();
	//Bit Check
	PortAddr= (volatile unsigned char *)((unsigned int)extSlotInfo.ExtInfo[idx].address+EXT_IO_INT_DATA);
	ioInt= *PortAddr++;
	ioInt+= *PortAddr++ << 8;
	rEXTINTPND = 0x08;			//Clear EXTINT7
	if((ioInt & 0xffff) == 0){		return(-1);		}
	for(i= 0; i < MAX_IO_INT; i++){
		if( (InterruputCnt < 8) &&
			( (ioInt & AndTable32[i]) && 
			((GlpSysInterruptIO[0] & AndTable32[i]) != 0) &&
			(GlpSysInterrupt == 1) &&		//EI
			(EntryIoInt[i] != 0xffff) ) ){
			if(IntLebel[InterruputIn_idx].IntKind == -1){
				IntLebel[InterruputIn_idx].IntKind= INT_EXTIO;
				IntLebel[InterruputIn_idx].IntItem= i;
				InterruputIn_idx = (InterruputIn_idx+ 1) & 0x07;
				InterruputCnt++;
			}
			break;
		}
	}
	if(i < MAX_IO_INT){
//		ExtIntCnt++;
		return(0);
	}
	else{	return(-1);	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: _IoInterruptHandler()										*/
/*	??	: �h?�n�h����������������?�g�������������B				*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
#ifdef	WIN32
void _IoInterruptHandler(void)
#else
void __irq _IoInterruptHandler(void)
#endif
{
	int	Ret;

	Ret= _IoInterruptProc();
	if(Ret == 0){
   		_PendingRequest( ID_PAddFlag | T_PLCINTTASK << 16 | 1 );
	}
	rI_ISPC= rI_ISPC | BIT_EINT4567;				// Clear pending bits     
}

void	SetGlpClock(void)
{
//	int	ret= NG;

	//PLC Clock
	//0.01
	if(*GlpSysClock & GLP_SYS_CLOCK001S){
		*GlpSysClock &= ~GLP_SYS_CLOCK001S;
	}else{
		*GlpSysClock |= GLP_SYS_CLOCK001S;
	}
	//0.02
	if((TimeloopCnt & 1) == 0){
		if(*GlpSysClock & GLP_SYS_CLOCK002S){
			*GlpSysClock &= ~GLP_SYS_CLOCK002S;
		}else{
			*GlpSysClock |= GLP_SYS_CLOCK002S;
		}
	}
	//0.05		//2009.10.22
	if((TimeloopCnt % 5) == 0){
		if(*GlpSysClock & GLP_SYS_CLOCK005S){
			*GlpSysClock &= ~GLP_SYS_CLOCK005S;
		}else{
			*GlpSysClock |= GLP_SYS_CLOCK005S;
		}
		//0.1
		if((TimeloopCnt % 10) == 0){
			if(*GlpSysClock & GLP_SYS_CLOCK01S){
				*GlpSysClock &= ~GLP_SYS_CLOCK01S;
			}else{
				*GlpSysClock |= GLP_SYS_CLOCK01S;
			}
			//0.2
			if((TimeloopCnt % 20) == 0){
				if(*GlpSysClock & GLP_SYS_CLOCK02S){*GlpSysClock &= ~GLP_SYS_CLOCK02S;}
				else{								*GlpSysClock |= GLP_SYS_CLOCK02S;}
			}
			//0.5
			if((TimeloopCnt % 50) == 0){
				if(*GlpSysClock & GLP_SYS_CLOCK05S){*GlpSysClock &= ~GLP_SYS_CLOCK05S;}
				else{								*GlpSysClock |= GLP_SYS_CLOCK05S;}
				//1s
				if((TimeloopCnt % 100) == 0){
					if(*GlpSysClock & GLP_SYS_CLOCK1S){	*GlpSysClock &= ~GLP_SYS_CLOCK1S;}
					else{								*GlpSysClock |= GLP_SYS_CLOCK1S;}
					//2s
					if((TimeloopCnt % 200) == 0){
						if(*GlpSysClock & GLP_SYS_CLOCK2S){
							*GlpSysClock &= ~GLP_SYS_CLOCK2S;
//							RunLed(ON);
						}else{
							*GlpSysClock |= GLP_SYS_CLOCK2S;
//							RunLed(OFF);
						}
					}
					//5s
					if((TimeloopCnt % 500) == 0){
						if(*GlpSysClock & GLP_SYS_CLOCK5S){	*GlpSysClock &= ~GLP_SYS_CLOCK5S;}
						else{								*GlpSysClock |= GLP_SYS_CLOCK5S;}
						//10s
						if((TimeloopCnt % 1000) == 0){
							if(*GlpSysClock & GLP_SYS_CLOCK10S){
								*GlpSysClock &= ~GLP_SYS_CLOCK10S;
							}else{
								*GlpSysClock |= GLP_SYS_CLOCK10S;
							}
							//60s
							if((TimeloopCnt % 6000) == 0){
								TimeloopCnt= 0;
								if(*GlpSysClock & GLP_SYS_CLOCK60S){*GlpSysClock &= ~GLP_SYS_CLOCK60S;}
								else{								*GlpSysClock |= GLP_SYS_CLOCK60S;}
							}
						}
					}
				}
			}
		}
	}
//	return(ret);
}
void	CheckTimerInt(int TimerIntCnt)
{
	int		i,idx;
	unsigned int	TimerIntVal;

	//Module Init Check

	//Timer Interrupt
	if(GlpSysInterrupt == 1){		//EI
//	if(((*GlpSysInterrupt & GLP_SYS_INT_DI) == 0) &&
//		((*GlpSysInterrupt & GLP_SYS_INT_TIME) == 0) ){
		for(i= 0; i < TimerIntEntryCnt; i++){
			idx= EntryTimerInt[i].lebel;
			if((GlpSysInterruptTimer & AndTable32[idx]) != 0){		//TINT ON ?
				//Interval Timer Value Check
				TimerIntVal= GlpSysTimeIntrval[idx];
				if(TimerIntVal == 0){	continue;	}
				if((TimerIntCnt % TimerIntVal) == 0){
					if(InterruputCnt < 8){
						if(IntLebel[InterruputIn_idx].IntKind == -1){
							IntLebel[InterruputIn_idx].IntKind= INT_TIMER;
							IntLebel[InterruputIn_idx].IntItem= i;
							InterruputIn_idx = (InterruputIn_idx+ 1) & 0x07;
							AddFlag(T_PLCINTTASK,1);
							InterruputCnt++;
						}
					}
				}
			}
		}
	}
}
void	InitTimerInf(void)
{
	memset(TimerCost,0,sizeof(TimerCost));

//10ms
	memset(&TimerCost[1].TimerValu[8],0xff,16);
//100
	memset(&TimerCost[2].TimerValu[0],0xff,16);
}
/****************************************/
/*	System State						*/
/****************************************/
void	DispLed(void)
{
	//LED OUT
	switch(LedModeFlag){
	case LED_MODE_OFF:
		if(LedSettingFlag != LED_MODE_OFF){
			LedSettingFlag= LED_MODE_OFF;
			RunLed(OFF);			//All Clear
			LedBlinkTime= 0;
		}
		break;
	case LED_MODE_RUN:
		if(LedSettingFlag != LED_MODE_RUN){
			LedSettingFlag= LED_MODE_RUN;
			RunLed(ON);				//Green
			LedBlinkTime= 0;
		}
		break;
	case LED_MODE_ERR:
		if((_TimeMSec- LedBlinkTime) > 500){
			LedBlinkTime= _TimeMSec;
			if(LedSettingFlag != LED_MODE_ERR){
				LedSettingFlag= LED_MODE_ERR;
				ErrorLed(ON);				//Green
			}else{
				LedSettingFlag= LED_MODE_OFF;
				ErrorLed(OFF);			//All Clear
			}
		}
		break;
	case LED_MODE_DBG:
		if(LedSettingFlag != LED_MODE_DBG){
			LedSettingFlag= LED_MODE_DBG;
			DebugLed(ON);				//Green
			LedBlinkTime= 0;
		}
		break;
	case LED_MODE_PSE:
		if((_TimeMSec- LedBlinkTime) > 500){
			LedBlinkTime= _TimeMSec;
			if(LedSettingFlag != LED_MODE_PSE){
				LedSettingFlag= LED_MODE_PSE;
				RunLed(ON);				//Green
			}else{
				LedSettingFlag= LED_MODE_OFF;
				RunLed(OFF);			//All Clear
			}
		}
		break;
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PlcTimIntTask()												*/
/*	??	: �o�k�b?�C??���荞��?�X�N�B							*/
/*	����	: STTFrm* pSTT												*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	PlcTimerCheck(void)
{
	int	i,j;
	unsigned short *TimeOnOff;
	unsigned short *BefTimeOnOff;
	unsigned short *ResetTimeOnOff;
	int		AndData;
	int		idx;
	unsigned short *CT;
	unsigned short *ST;
	int		timeUpflag;

	if(TimerPuseFlag == 0){				//2008.05.23
		TimeOnOff= TimCnt.TimeOnOff;
		BefTimeOnOff= BefTimeOnOffInt;
		ResetTimeOnOff= ResetTimeOnOffInt;
		for(i= 0; i < Device_Length_T_BIT/16; i++,TimeOnOff++,BefTimeOnOff++,ResetTimeOnOff++){
			/* Timer Check */
			if(*TimeOnOff == 0){					continue;}
			AndData= 0x0001;
			for(j= 0; j < 16; j++,AndData <<= 1){
				//�X??�g?�C???�F�b�N
				if((*TimeOnOff & AndData) == 0){	continue;}
				idx= i*16+j;
				timeUpflag= 0;
				if(TimerCost[1].TimerValu[i] & AndData){
	//10ms Timer
					if(((*BefTimeOnOff & AndData) == 0) ||
						((*ResetTimeOnOff & AndData) != 0)){
						*ResetTimeOnOff &= ~AndData;
						Timer1msCnt[idx]= 9;
					}else{
						if(Timer1msCnt[idx] > 0){
							Timer1msCnt[idx]--;
							if(Timer1msCnt[idx] == 0){
								timeUpflag= 1;
							}
	//2008.04.18
						}else{
							Timer1msCnt[idx]= 9;
						}
	//2008.04.18
					}
				}else{
	//100ms Timer
					if((*BefTimeOnOff & AndData) == 0){
						Timer1msCnt[idx]= 99;
					}else{
						if(Timer1msCnt[idx] > 0){
							Timer1msCnt[idx]--;
							if(Timer1msCnt[idx] == 0){
								timeUpflag= 2;
							}
	//2008.04.18
						}else{
							Timer1msCnt[idx]= 99;		
						}
	//2008.04.18
					}
				}
				if(timeUpflag != 0){
					//UP ?�C??
					CT= &InDevArea.PlcDev.CT[idx];
					ST= &InDevArea.PlcDev.ST[idx];
					//ON-Timer,OFF-Timer
					if((TimCnt.TimeMode[idx] & 0x00ff) == 0){	//UP COUNTER
						if(*CT < *ST){	(*CT)++;	}
						if(*CT >= *ST){
							*CT= *ST;		//2008.05.21
							InDevArea.PlcDev.BT[i] |= AndData;
							//TMR���
							TimCnt.TimeTMR[i] &= ~AndData;
							if(TimCnt.TimeMode[idx] & 0xff00){
							}else{
								*TimeOnOff &= ~AndData;
							}
						}else{
							if(timeUpflag == 1){
								Timer1msCnt[idx]= 10;
							}else{
								Timer1msCnt[idx]= 100;
							}
						}
					}else{			//Down Counter
						if(*CT > 0){
							if(*CT > *ST){
								*CT= *ST;		//2008.05.21
							}
							(*CT)--;
						}
						if(*CT <= 0){
							InDevArea.PlcDev.BT[i] &= ~AndData;
							//TMR���
							TimCnt.TimeTMR[i] &= ~AndData;
							*TimeOnOff &= ~AndData;			//?�C??��?
						}else{
							if(timeUpflag == 1){
								Timer1msCnt[idx]= 10;
							}else{
								Timer1msCnt[idx]= 100;
							}
						}
					}
				}				
			}
		}
		memcpy(BefTimeOnOffInt,TimCnt.TimeOnOff,sizeof(BefTimeOnOffInt));
	}
#ifndef	WIN32
	//WDT Check
	if(WdtStartFlag == 1){		//WDT Start
		if(ResetWdtCnt == 1){	//WDT Reset
			ResetWdtCnt= 0;
			WdtCnt= *GlpSysWDTCnt;
			WdtNowCnt= 0;
		}
		WdtNowCnt++;
		if(WdtNowCnt > WdtCnt){				//WDT STOP
			GLP_STStopFlag= 1;		//�����I��
			GLP_STScanFlag= 1;		//�v���O��?�I��
			WdtStartFlag= 0;
			GlpRunMode= 'S';		//Stop Mode
			*GlpSysMode =	GLP_SYS_MODE_STOP;
			LedModeFlag= LED_MODE_OFF;
			*GlpSysError |= GLP_SYS_ERR_WDT;
		}
	}
#endif
}
void	PlcState10ms(int *TimerSetting)
{
	//���Ԑݒ�Ď�
	if(*TimerSetting != (*GlpSysTimeMode & (GLP_SYS_TIME_TIME|GLP_SYS_TIME_30S))){
		//GLP_SYS_TIME_TIME��������Ŏ��Ԑݒ�
		if(((*TimerSetting & GLP_SYS_TIME_TIME) != 0) &&
			((*GlpSysTimeMode & GLP_SYS_TIME_TIME) == 0)){
			PlcWriteTime(0);
		}
		//GLP_SYS_TIME_30S�������オ��Ŏ��Ԑݒ�
		if(((*TimerSetting & GLP_SYS_TIME_30S) == 0) &&
			((*GlpSysTimeMode & GLP_SYS_TIME_30S) != 0)){
			PlcWriteTime(1);
		}
	}
	*TimerSetting= (*GlpSysTimeMode & (GLP_SYS_TIME_TIME|GLP_SYS_TIME_30S));
	//Filter Check
	if(*GlpSysRunMode & GLP_SYS_RUN_FILTER_SET){
		*GlpSysRunMode &= ~GLP_SYS_RUN_FILTER_SET;
		FilterChange();
//		SetDefaultFilter(0);
		SetFilter(0,0);		//Filter(0,0)2008.04.09
	}
	//Module Setting
	if(*GlpSysModuleSet != 0){
		*GlpSysModuleSet= 0;
		ParamDev2In(0);
	}
	//GLP�͂����ŊĎ�
	StateSignal3();
	//GLP Swich Check
	if(RunSWRead() == ON){
		if(RunStopSwitch == OFF){
			RunStopSwitch= ON;
			SetRunStopSwitch(RunStopSwitch);
			PlcStartOutStopDevClear();
		}
	}else{
		if(RunStopSwitch == ON){
			RunStopSwitch= OFF;
			SetRunStopSwitch(RunStopSwitch);
		}
	}
	DispLed();
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PlcTimIntTask()											*/
/*	??	: �o�k�b?�C??���荞��?�X�N�B									*/
/*	����	: STTFrm* pSTT												*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	PlcTimIntTask( STTFrm* pSTT )
{
	unsigned int	loopCnt;
	unsigned int	TimerIntCnt;
	int		TimerSetting;

//	SetSpecialRegisterAddr();				//�D�悪��������
	InitTimerInf();							//Initialize Timer Info
	*GlpSysTimeMode &= ~(GLP_SYS_TIME_TIME | GLP_SYS_TIME_30S);	//���Ԑݒ�r�b�g�N���A
	DebugLoop= 0;
	memset(&TimCnt,0,sizeof(TimCnt));
	MatrixTimeoutCnt= 0;
	DenubTimeoutCnt= 0;
#ifndef	WIN32
	ClearFlag();
#endif
	loopCnt= 0;
	TimerIntCnt= 0;
	TimerSetting= 0;
	InterruputCnt= 0;
	InterruputIn_idx= 0;
	InterruputOut_idx= 0;

	LedModeFlag= LED_MODE_OFF;
	LedSettingFlag= 0;
	LedBlinkTime= 0;


/*	PcStateOn();*/
	if(RunSWRead() == ON){
		RunStopSwitch= ON;
		PlcStartOutStopDevClear();
	}else{
		RunStopSwitch= OFF;
	}
	SetRunStopSwitch(RunStopSwitch);

	while(1){
#ifdef	WIN32
		Delay(100);
#else
		WaitFlag(1);
#endif
		loopCnt++;

		//PLC Timer On/Off Check
//		PlcTimerCheck(loopCnt);
#ifdef	WIN32
		PlcTimerCheck();
		TimeloopCnt++;
		SetGlpClock();
#endif
		TimerIntCnt++;
		//Timer Interrupt Check
		CheckTimerInt(TimerIntCnt);
		if((loopCnt & 0x07) == 0){
			//PLC �Ď�
			PlcState10ms(&TimerSetting);
		}
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: _PlcTimerInterruptHandler()								*/
/*	??	: 10ms?�C??�C��??���v�g�n���h��?�B					*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	ClearPlcTime(void)
{
	TimeloopCnt= -1;
	Time1msloopCnt= 0;					//2008.04.08
	memset(BefTimeOnOffInt,0,sizeof(BefTimeOnOffInt));
	memset(ResetTimeOnOffInt,0,sizeof(ResetTimeOnOffInt));
	WdtStartFlag= 0;
	TimerPuseFlag= 0;
}
int	_PlcTimerInterruptProc(void)
{
	int	ret= -1;

	if(TimeloopCnt < 0){	return -1;	}
	Time1msloopCnt++;					//2008.04.08
	PlcTimerCheck();				//2008.04.08
	if((Time1msloopCnt % 5) == 0){	//2008.04.08
		TimeloopCnt++;
		SetGlpClock();
	}
	if((Time1msloopCnt % 10) == 0){	//Timer Interrupt Time(10ms)
		ret= 0;
	}
	return(ret);
}
//-------------------------------------------------
//	1ms Timer
//-------------------------------------------------
#ifdef	WIN32
void _PlcTimerInterruptHandler(void)
#else
void __irq _PlcTimerInterruptHandler(void)
#endif
{
	int		Ret;

	Ret = _PlcTimerInterruptProc();
	if(Ret == 0){
   		_PendingRequest( ID_PAddFlag | T_PLCTINT_TASK << 16 | 1 );
	}
   rI_ISPC= rI_ISPC | BIT_TIMER3;				// Clear pending bits     
}
/*----------------------------------------------------------------------*/
/*	�֐���	: _PlcInterruptHandler()									*/
/*	??	: 1ms?�C??�C��??���v�g�n���h��?�B						*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
int	_PlcInterruptProc(void)
{
	Plc1msCnt++;
	return(0);
}
#ifdef	WIN32
void	_PlcInterruptHandler( void )
#else
void	__irq _PlcInterruptHandler( void )
#endif
{
	int	Ret;

    rI_ISPC= rI_ISPC | BIT_TIMER4 ;//  (Rx_Int�ł���Ă���) //clear pending bits,Default value=0x0000000
	Ret = _PlcInterruptProc();
	if(Ret == 0){
   		_PendingRequest( ID_PAddFlag | GLP_MyTaskNo << 16 | 1 );
	}
}
void	SetLedMode(void)
{
	switch(GlpRunMode){
	case 'R':
//		SetOnOffSignal(ON);
		LedModeFlag= LED_MODE_RUN;
		break;
	case 'D':
//		SetOnOffSignal(ON);
		LedModeFlag= LED_MODE_DBG;
		break;
	case 'P':
//		SetOnOffSignal(ON);
		LedModeFlag= LED_MODE_PSE;
		break;
	default:
//		SetOnOffSignal(OFF);
		LedModeFlag= LED_MODE_OFF;
		break;
	}
}
void	CheckLoopTime(void)
{
#ifndef	WIN32
	unsigned int	PlcIntrNowCntms;	//Plc Process Time

	PlcIntrNowCntms= rTCNTO4;
	if(PlcIntrNowCntms < 60){
		ClearFlag();
		WaitFlag(1);
	}
#endif
}
void	CheckMonitor(void)
{
extern	void	MonitorProc(T_MAIL* mp);
	T_MAIL*	mp;
	//Monitor Mail Box Check
	mp= (T_MAIL*)AcceptMail(T_PLCMAIN);
	if(mp != R_NoMail) {
		MonitorProc(mp);
		ResponseMail((char*) mp);
	}
}
void	CheckMonitorAll(void)
{
extern	void	MonitorProc(T_MAIL* mp);
	T_MAIL*	mp;
	while(1){
		//Monitor Mail Box Check
		mp= (T_MAIL*)AcceptMail(T_PLCMAIN);
		if(mp == R_NoMail) {
			break;
		}
		MonitorProc(mp);
		ResponseMail((char*) mp);
	}
}
/*----------------------------------------------------------------------*/
/*	�֐���	: WaitDebugMode()											*/
/*	??	: GLP_StopFlag���n�e�e�ɂȂ�܂łv�������B					*/
/*	����	: �Ȃ�														*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void	WaitDebugMode( void )
{
	int		addr;
//	int		sFlag;

	PlcProcRunning= 0;		/* �q�t�m?STOP */
//	sFlag= 0;
	while(1){
		if(GLP_StopFlag == 0){	break; }
		//�����I��?�F�b�N
		if(GLP_STStopFlag != 0){
			GLP_STStopFlag= 0;
			if(GlpRunMode == 'S'){		//Stop Mode
//				SetOnOffSignal(0);		//Stop MOde
//				sFlag= 1;
//			}else{
//				if(sFlag == 1){
//					GlpSysIoInit= 0x01;		//Slot No
//					SetInterruptKind();		//Interrupt Setting
//				}
				break;
			}
		}
		if((PlcSignalInf == OFF) ||				//0:Stop,1:Start
			(RunStopSwitch == OFF)){			//0:Stop,1:Start
			if(RunStopSwitch == OFF){
				ProcMode= 0;		//Debug ����
//				RunLed(OFF);
			}
			break;
		}
		if(GLP_STCommFlag != 0){
			GLP_STCommFlag= 0;
			addr= CodeData- &PlcDataSram.Inst_Operand_Area[0];
			if(ProcMode != 0){	MakeStopInf(addr);	}		/* DEBUG MODE */
		}
		// 2008.06.10
		if(GlpRunMode != 'D'){		//Debug Else
			IOScanProc();
			IOOutProc();
			ScanProc();		//����IO���f??����荞��
			IoFunctionOut();
			PortOutProc();	//PLC- OFF�̎��o��
		}	
		Read2FdevArea();		//Copy to F Device
		CheckMonitorAll();
		Delay(100);
	}
	ClearFlag();
	if((GlpRunMode != 'S') &&		//Stop Mode
		(ProcMode != 0)){
		PlcProcRunning= 1;		/* �q�t�m?�� */
		GLP_STScanFlag= 0;
	}
}
int	CheckExeStep(unsigned short**BefCodePos)
{
	WdtStartFlag= 0;								//WDT Stop
	if((ProcMode != 0) && (PlcDataSram.CommDebugIoOut == 2)){			//Numonic Out
		memcpy(InDevArea.PlcDev.Debug_Y,InDevArea.PlcDev.Y,Device_Length_Y);		//2011.10.06
		DebugIoOutSet();							//SET DEBUG IO
		PortOutProc();								//Out Port
		ScanProc();									//����IO���f??����荞��
		DebugIoINSet();								//SET DEBUG IO
	}
	if(GlpRunMode == 'S'){	return(-1);			}	//Stop
	if(GlpRunMode == 'D'){
		if(ProcMode == 0){
			return(-1);
		}
	}	//Debug Mode
	if((GlpRunMode == 'P') || (GlpRunMode == 'D')){	TimerPuseFlag= 1;	}
	if(CheckGlpStop(*BefCodePos) == OK){
		WaitDebugMode();
		if(TimerPuseFlag != 0){	TimerPuseFlag= 0;	}
		if(GlpRunMode == 'S'){	return(-1);			}	//Stop
		if(GlpRunMode == 'D'){
			if(ProcMode == 0){
				return(-1);
			}
		}	//Debug Mode
	}
	*BefCodePos= CodeData;
	if(TimerPuseFlag != 0){	TimerPuseFlag= 0;	}
	if(PlcSignalInf == OFF){	//Signal
//		SetOnOffSignal(0);		//Stop MOde
		return(-1);
	}
	return(0);
}
int	Check1Scan(void)
{
	WdtStartFlag= 0;		//WDT Stop
	if(GlpRunMode == 'P'){
		TimerPuseFlag= 1;
		GLP_StopFlag= 1;
		WaitDebugMode();
		TimerPuseFlag= 0;
	}
	if((GlpRunMode == 'D') || (GlpRunMode == 'S')){		//Stop Mode
		//Timer Run Inf Clear
		memset(&TimCnt.TimeOnOff[0],0,sizeof(TimCnt.TimeOnOff));
		if(GlpRunMode == 'S'){
			//Stop Out Clear
			if((*GlpSysRunMode & GLP_SYS_RUN_STP_EXT) == 0){
				PlcDeviceClear();
			}
			StopPortOff();		//EXT IO
			GLP_StopFlag= 1;
			GLP_STCommFlag= 0;
			/* Debug ��񏉊��� */
			memset(&Mon_Info,0,sizeof(Mon_Info));
			//�����h�n��?�h�N���A
			*GlpSysState &= ~(GLP_SYS_STATE_IO_IN | GLP_SYS_STATE_IO_OUT);
		}else{
			if(ProcMode == 0){	//DEBUG MODE�ɓ������Ƃ�
				PlcDeviceClear();
			}
		}
		Read2FdevArea();		//Copy to F Device
		return(-1);
	}
	return(0);
}
void	ModeChangeWait(void)
{
	int	SaveRunMode;

	DiPlcInt();			//Interrupt Disable
	memset(&GlpSysInterruptIO[0],0,sizeof(GlpSysInterruptIO));
	GlpSysInterruptTimer= 0;


	GLP_STStopFlag= OFF;		//�����I��
	GLP_STScanFlag= OFF;		//�v���O��?�I��
	if(GlpRunMode == 'S'){
		GLP_STCommFlag= 0;
	}
//	PlcStartOutStopDevClear();

	if(GlpRunMode == 'D'){
		//DEBUG�ɐ؂�ւ���
		GLP_STCommFlag= 1;
		//STOP�͏���������
		//DEBUG�͏���������
		ProcMode= 1;			//DEBUG MODE ON
		return;
	}
	if((GLP_StopFlag == ON) || (RunStopSwitch == OFF)){			//0:Stop,1:Start
		SaveRunMode= GlpRunMode;
		while(1){
//			if(RunStopSwitch == OFF){
				//Param�ݒ蓮�쏈��
				IOScanProc();
				if(GLP_StopFlag == ON){									//2009.07.03 add
					if((*GlpSysRunMode & GLP_SYS_RUN_STP_EXT) != 0){	//2009.07.03
						IOOutProc();									//2009.07.03
					}													//2009.07.03
				}else{													//2009.07.03
					IOOutProc();
				}														//2009.07.03
				ScanProc();		//����IO���f??����荞��
				IoFunctionOut();
				PortOutProc();	//PLC- OFF�̎��o��
//				Read2FdevArea();		//Copy to F Device
//				if(PlcSignalInf == OFF){	break;	}
//			}
			if( (GLP_StopFlag == OFF) && (RunStopSwitch == ON) &&
				(PlcSignalInf == ON ) ){	break;	}
			Read2FdevArea();		//Copy to F Device
			CheckMonitorAll();
			Delay(100);
		}

		if(GlpRunMode == 'R'){
			GLP_STScanFlag= OFF;
			GLP_STCommFlag= OFF;
			if( (SaveRunMode == 'S') && 
				((*GlpSysRunMode & GLP_SYS_RUN_STP_EXT) != 0) ){
				PlcDeviceClear();
			}
		}
		if((SaveRunMode != 'D') && (GlpRunMode == 'D')){
			//DEBUG�ɐ؂�ւ���
			GLP_STCommFlag= 1;
			//STOP�͏���������
			//DEBUG�͏���������
			ProcMode= 1;			//DEBUG MODE ON
		}
		//Interrupt Task Wait Check
		while(1){
			if(InterTskFlag == 0){
				break;
			}
			Delay(20);
		}
	}
}
void	SetLachAreaTC(void)
{
	CheckClearDev(ClearWordDevTbl[3].code,&StartCTAddr,&EndCTAddr);	//CT
	CheckClearDev(ClearWordDevTbl[4].code,&StartCCAddr,&EndCCAddr);	//CT
}
/*----------------------------------------------------------------------*/
/*	�֐���	: PlcMainTask()												*/
/*	??	: �o�k�b���C��?�X�N�B										*/
/*	����	: STTFrm* pSTT												*/
/*	�߂�l	: �Ȃ�														*/
/*	�쐬��	: 2005/07/27 M.Owashi										*/
/*----------------------------------------------------------------------*/
void PlcMainTask(STTFrm* pSTT)
{
	unsigned short i_Bunrui_Code;
	int		EndFlag;
	unsigned	int	Old1msTimeCnt;
	unsigned short*	BefCodePos;
#ifndef	WIN32
	unsigned int	PlcIntrNowCntms;	//Plc Process Time
#endif

	GLP_MyTaskNo = _RunTaskNo;			//Mail�p?�X�N�ԍ�
	Plc1msCnt= 0;						//1ms Timer Count

	DiPlcInt();							//Interrupt Disable
	PlcSpDeviceClear();
	GlpSysInterruptTimer= 0;			// Interrupt level
#ifdef	WIN32
	OutDispFlag= 0;
	BitRunOnOffWin32C(1);
#endif
	GLP_STCommFlag= 0;					/* ��? */
	GLP_STScanFlag= 0;					/* �X�L�����X�g�b�v��� */
	GLP_STStopFlag= 0;					/* �����X�g�b�v��� */
	GLP_StopStep= -1;					/* DEBUG�p��?�X�e�b�v */
	ProcMode= 0;						/* RUN MODE�ݒ� */
	PlcProcRunning= 1;					/* �q�t�m?�� */
	memset(&TimCnt,0,sizeof(TimCnt));	// Timer ���

	GetPlcFile();						// �e�����ǂݍ���
	//RUN Mode
	GlpRunMode= 'R';					/* RUN MODE */
	*GlpSysMode= GLP_SYS_MODE_RUN;	// ���ꃌ�W�X?�̂q�t�m�ݒ�
	//F0013 is Start ON
	*GlpSysSignal |= GLP_SYS_SIG_1SC_OFF;
	//�펞ON
	*GlpSysSignal |= GLP_SYS_SIG_ON;
	//�펞OFF
	*GlpSysSignal &= ~GLP_SYS_SIG_OFF;
	//�P�X�L����OFF
	*GlpSysSignal |= GLP_SYS_SIG_1SC_OFF;
//	SetOnOffSignal(0);					//Stop mode
	*GlpSysClock= 0;					//Clock Bit Clear
	*GlpSysModuleSet= 0;				//Module Setting Device
	*GlpSysError= 0;					// System Error

	ExtBordCheck();						//�O��IO?�F�b�N
	PortOutOffProc();					//�O��IO?OFF

	*GlpSysScnCnt= 0;					//Scan Count

	PlcDeviceClear();					//PowrOn Dev Clear
	PlcSpecialDevClear(ON,ON,ON);
	*GlpSysCulc &= ~(GLP_SYS_CULC_ZERO | GLP_SYS_CULC_CARRY | GLP_SYS_CULC_BORROW |
					GLP_SYS_CULC_ERR | GLP_SYS_CULC_ERR_ED);	//2011.08.11 Power On Reset
	//Out Port
	PortOutProc();
	//WDT �����l
	WdtStartFlag= 0;
	*GlpSysWDTCnt= WDT_INIT;
	GetPlcProgram();			//Program From File
	Read2FdevArea();		//Copy to F Device
	while(1){
		PlcMainRunFlag=OFF;			//Main?�X�N��Wait��ԂɂȂ������̔�����
		if(PlcSignalInf == OFF){			//0:Stop,1:Start
			Read2FdevArea();		//Copy to F Device
			CheckMonitorAll();
			Delay(100);
			continue;
		}

		ModeChangeWait();
		
		PlcMainRunFlag=ON;			//Start ON
		TimerIntEntryCnt= 0;		//?�C??���荞�݃N���A
		memcpy(&PlcDataSram.Inst_Operand_Area[0],&PlcDataSram.Inst_Operand_Program[0],PlcDataSram.CodeTableCnt);
		/* Label Making */
		memset(PlcDataSram.Inst_Point_Table,-1,sizeof(PlcDataSram.Inst_Point_Table)) ;
		if(Instruction_Number_Set() == NG){ ;  /*�I�y�����h�G��?*/
			LedModeFlag= LED_MODE_ERR;
			PlcSignalInf= OFF;
			Delay(100);
			continue;
		}
		SetLedMode();
		//�o�͋�?
		if(*GlpSysRunMode & GLP_SYS_RUN_NO_OUT){
			PortOutOffProc();		//�O��??�gOFF
		}
		/* Debug ��񏉊��� */
		memset(&Mon_Info,0,sizeof(Mon_Info));
		//�����h�n��?�h�N���A
		*GlpSysState &= ~(GLP_SYS_STATE_IO_IN | GLP_SYS_STATE_IO_OUT);
		memset(&BeforeDevInfo[0],0,sizeof(BeforeDevInfo));
		memset(&BeforeDevInfo2[0],0,sizeof(BeforeDevInfo2));
		memset(&TimCnt.BefCntOnOff[0],0,sizeof(TimCnt.BefCntOnOff));
		memset(&TimCnt.BefCntOnOff2[0],0,sizeof(TimCnt.BefCntOnOff2));
		memset(&TimCnt.BefTimeOnOff[0],0,sizeof(TimCnt.BefTimeOnOff));
		//2008.04.17
		memset(BefTimeOnOffInt,0,sizeof(BefTimeOnOffInt));
		memset(ResetTimeOnOffInt,0,sizeof(ResetTimeOnOffInt));
		TimerPuseFlag= 0;	//2008.05.23
		//2008.04.18
		memset(Timer1msCnt,0,sizeof(Timer1msCnt));

		ScanRunCnt= 0;		//Scan Count Clear
		SetExtIntrrupt();	//IO Interrupt Set
		EiPlcInt();			//Interrupt Enable
		PlcSpecialDevClear(ON,OFF,ON);

		ParamIO2Fdevice();			//Paramerter Setting
		*GlpSysWDTCnt= WDT_INIT;
		GlpSysIoInit= 0x01;		//Slot No
		SetInterruptKind();		//Interrupt Setting

		memset(&TimCnt,0,sizeof(TimCnt));
//		SetOnOffSignal(1);		//Run MOde
		//�P�X�L����ON
		*GlpSysSignal |= GLP_SYS_SIG_1SC_ON;
		//�P�X�L����OFF
		*GlpSysSignal &= ~GLP_SYS_SIG_1SC_OFF;
		//Min Scan
		*GlpSysMinSc= 65535;
		//���Z���N���A
		*GlpSysCulc &= ~GLP_SYS_CULC_CARRY;
		*GlpSysCulc &= ~GLP_SYS_CULC_ZERO;
		//IO Clear
		PortOutOffProc();		//OUT OFF
		//Fdevice Save
		Read2FdevArea();		//Copy to F Device
		//Set Latch Area
		SetLachAreaTC();
		while(1){
			if(PlcSignalInf == OFF){			//0:Stop,1:Start
				InitExtInf();
				WdtStartFlag= 0;		//WDT Stop
				break;
			}
			if(RunStopSwitch == OFF){			//0:Stop,1:Start
				WdtStartFlag= 0;		//WDT Stop
				
				Check1Scan();										//2009.07.03
				if((*GlpSysRunMode & GLP_SYS_RUN_STP_EXT) == 0){	//2009.07.03
					PlcDeviceClear();
				}													//2009.07.03
//				PlcStartOutStopDevClear();
				GLP_STCommFlag= 0;
//				SetOnOffSignal(0);		//Stop MOde
				ClearTimeInf();
				break;
			}
			//�펞ON
			*GlpSysSignal |= GLP_SYS_SIG_ON;
			//�펞OFF
			*GlpSysSignal &= ~GLP_SYS_SIG_OFF;
			//Const Scan Check
			//�R���X?���g�X�L����?�F�b�N
			if(*GlpSysRunMode & GLP_SYS_RUN_CST_SC){
				*GlpSysState |= GLP_SYS_STATE_CNT_RUN;
			}else{
				*GlpSysState &= ~GLP_SYS_STATE_CNT_RUN;
			}
			//�f�o�b�O���o�͋�?
			if(GlpDbgInf & GLP_SYS_RUN_DBG_DI_OUT){
				*GlpSysState |= GLP_SYS_STATE_DB_DI_OUT;
			}else{
				*GlpSysState &= ~GLP_SYS_STATE_DB_DI_OUT;
				if(ProcMode != 0){		/* DEBUG MODE 080222 */
					PortOutOffProc();		//OUT OFF
				}
			}
			//Param�ݒ蓮�쏈��
			IOScanProc();
			IOOutProc();
#ifndef	WIN32
			PlcIntrNowCntms= rTCNTO4;
			if(PlcIntrNowCntms < 60){
				ClearFlag();
				WaitFlag(1);
			}
#endif
			//���ݎ��ԕۑ�
			Old1msTimeCnt= Plc1msCnt;
			/* Scan Inport */
			ScanProc();		//����IO���f??����荞��
			DebugIoINSet();		//SET DEBUG IO

			GlpDataClear();
			EndFlag= 0;
#ifndef	WIN32
			ClearFlag();
#endif
			//WDT Set 
			if(*GlpSysWDTCnt > WDT_MAX_CNT){	*GlpSysWDTCnt= WDT_INIT;		}
			ResetWdtCnt= 1;			//WDT Count Reset
			WdtStartFlag= 1;		//WDT Start
			//Fdevice Save
			Read2FdevArea();		//Copy to F Device
			/* Interpreter Run */
/////////////////////////////////////////////////////
//			Waitloop= 0;
/////////////////////////////////////////////////////
			EndCodePos= &PlcDataSram.Inst_Operand_Area[PlcDataSram.Load_Count];
			CodeData= &PlcDataSram.Inst_Operand_Area[0];
			BefCodePos= NULL;
			*GlpSysCulc &= ~GLP_SYS_CULC_ERR;				//2011.08.11 Scan Start Clear
			while(EndFlag == 0 && (CodeData < EndCodePos)) {
#ifndef	WIN32
				PlcIntrNowCntms= rTCNTO4;
				if(PlcIntrNowCntms < 60){
					WaitFlag(1);
					if(PlcSignalInf == OFF){			//0:Stop,1:Start
//						SetOnOffSignal(0);		//Stop MOde
						WdtStartFlag= 0;		//WDT Stop
						break;
					}
				}
#endif
				//�r��?�F�b�N
				if((GLP_STCommFlag != 0) ||	(ProcMode != 0)){		/* DEBUG MODE */
					if(CheckExeStep(&BefCodePos) != 0){
						break;		//Stop
					}
				}
				i_Bunrui_Code = *CodeData++;
				DeviceAddrError= OK;			//Device Address Error Clear
				if(i_Bunrui_Code < MAX_INSTRUCT_CODE){
					Numonic_Table[i_Bunrui_Code].RsCall();
				}else{
					if(IsProcEnd(CodeData) == TRUE){	EndFlag = 1;	}
				}
			}
			/* Port Out */
#ifndef	WIN32
			if(PlcDataSram.Load_Count == 0){
				LedModeFlag= LED_MODE_ERR;
			}
#endif
			IoFunctionOut();
//Scan End Proc
			if(ProcMode != 0){		//Debug Mode
				DebugIoOutSet();		//SET DEBUG IO
				if(PlcDataSram.CommDebugIoUse == 1){
					memcpy(InDevArea.PlcDev.Debug_Y,InDevArea.PlcDev.Y,Device_Length_Y);		//2011.10.06
					PortOutProc();			//Out Port
				}
			}else{
				PortOutProc();			//Out Port
			}
			//Scan Time Check
			//�X�L�����p���X
			if(*GlpSysSignal & GLP_SYS_SIG_SC_PULS){	*GlpSysSignal &= ~GLP_SYS_SIG_SC_PULS;	}
			else{										*GlpSysSignal |= GLP_SYS_SIG_SC_PULS;	}
			//�P�X�L����ON
			*GlpSysSignal &= ~GLP_SYS_SIG_1SC_ON;
			//�P�X�L����OFF
			*GlpSysSignal |= GLP_SYS_SIG_1SC_OFF;
			//�R���X?���g�X�L����?�F�b�N
			if(*GlpSysRunMode & GLP_SYS_RUN_CST_SC){
#ifndef	WIN32
				if(*GlpSysCscTime > SC_MAX_CNT){	*GlpSysCscTime= SC_CNT_INIT;		}
				//Scan Over Set
				if((Plc1msCnt- Old1msTimeCnt) > *GlpSysCscTime){
					*GlpSysError |= GLP_SYS_ERR_SC_OVR;
					*GlpSysSelfTest= GLP_SYS_SELF_SCAN;
				}else{
					*GlpSysError &= ~GLP_SYS_ERR_SC_OVR;
				}
				while(1){
					if((Plc1msCnt- Old1msTimeCnt) >= *GlpSysCscTime){	break;	}
					WaitFlag(1);
					//080114 ������?�Ŕ�����B
					if(GLP_STScanFlag != 0){		/* ������? */
						break;
					}
					if(PlcSignalInf == OFF){			//0:Stop,1:Start
//						SetOnOffSignal(0);		//Stop MOde
						ClearTimeInf();
						WdtStartFlag= 0;		//WDT Stop
						break;
					}
				}
#endif
			}
			//���݃X�L����
			*GlpSysNowSc= Plc1msCnt- Old1msTimeCnt;
			if(*GlpSysNowSc < *GlpSysMinSc){	*GlpSysMinSc= *GlpSysNowSc;	}
			if(*GlpSysNowSc > *GlpSysMaxSc){	*GlpSysMaxSc= *GlpSysNowSc;	}
			//�X�L�����J�E���g
			(*GlpSysScnCnt)++;
			/* �X�L������??�F�b�N */
			if(GLP_STScanFlag != 0){		/* ������? */
				if(Check1Scan() != 0){		break;		}		// Loop Wait
				ClearFlag();
			}
			Read2FdevArea();		//Copy to F Device
			//Monitor Mail Box Check
			CheckMonitorAll();
#ifdef	WIN32
			Delay(100);
#endif
			//Code���Ȃ����v�������i�j���Ȃ�����
			if(PlcDataSram.Load_Count == 0){		Delay(100);	}
			else{
#ifndef	WIN32
				PlcIntrNowCntms= rTCNTO4;
				if(PlcIntrNowCntms < 60){
					ClearFlag();
					WaitFlag(1);
				}
#endif
			}
		}
	}
}

int	GetStopInf(void)
{
	return(GLP_StopFlag);
}

/////////////////////////////////END/////////////////////////////////////
//	LP_S044
#endif

