
#ifdef _WINDOWS
//#include    "stdafx.h"
#endif
#define	MAIN
#include	"sgt.h"

void    BuzOn();
void    BuzOff();
#ifdef	WIN32
/*extern	char	LcdBuff[80][320/8];*/
/*extern	char	LcdBuff1[256][320/8];*/
#else
/*extern	unsigned short	LcdBuff[80][240/8];*/
/*extern	unsigned short	LcdBuff1[80][240/8];*/
#endif


_CIRCLE_INFO	CircleParam;
_ORGGATA_INFO	OogigataParam;
/*volatile	int	BaseChangeFlag;*/			/* Base Change Flag 0:normal,1:Changing */
/*volatile	int	BaseChangeFlag1;*/			/* Base Change Flag 0:normal,1:Changing */
extern	void	mReadSettei( void );
void	IniTask( STTFrm* pSTT )
{
	int		i;
	int		signal;
	char	buff[1500];
	char	buff1[1500];
	char	buff2[32];
	struct{
		char	x;
		char	y;
	}dem_data[32];
	int		fp;
extern	void	CalcAddrLine(int sx,int sy,int ex,int ey,char *buff);


	CalcAddrLine(9,2,2,6,(char *)dem_data);
	i= 0;
	TateYoko= 0;
	memset(buff,0x00,sizeof(buff));
	InitDispSema();
	i = 0;

#ifdef	OLD
	Set.iBackLightTime= 0;
	Set.iConnect= 0;
#else
	mReadSettei();
#endif
	Set.LanguageCode = 0;			/* Hangle */
	DeviceCnt = 0;		/* �Ď��p�f�o�C�X�� */
	signal = 0xffffffff;
	OffSignal(SGN_PLC,signal);
	KerRepeatFlag= 0;

/*	Set.iPrint= 0;*/			/*0:EDITOR,1:Printer,2:Bardode*/
	Set.Ch1_iSpeed= 5;			/* 9600 */
	Set.Ch1_iParity= 0;			/* 0:NONE,1:ODD,2:EVEN */
	Set.Ch1_iData1= 1;			/* 0:7,1:8 */
	Set.Ch1_iData2= 0;			/* 0:XON/XOF,1:DSR/DTR */
	Set.Ch1_iStop= 0;
	Set.Ch1_iConnect= 1;		/* 0:RS-232C,1:RS-422 */
/*	Set.iPlcType= 1;*/		/* 0:Universal,1:Fx-Seriase,2:Els */
	Set.LcdReverseOn= 0;
/*	data= MakeCheckDigit(0x45fcd500);*/


/*	FontSet();*/

	while(1){
#ifdef	OLD
		mp = (T_MAIL *)TakeMail();
		mp->mcmd =1;
		mp->mcod =i;
		SendMail(T_DISPANALYSIS,(char *)mp);
#endif
		Delay(1000);
		i++;
	}

}
extern	char	AlarmData[256];
void	FileTask( int mode )
{
	T_MAIL	*mp;
	int		ret;
	int		i,j;
	_LINE_INFO	param;
	_RECTANGLE_INFO	param1;
	char	dsp_buff[48];
	RTC_DATA SetTimeData;
	DEV_DATA	DevInfo;
#ifdef	OLD
	ClearDispBuff(2);
	OpenWindow(2,70,80);
	SetStartPos(2,150,0);
	i = 0;
/*	AreaRevers(0,0,69,99);*/
/*	AreaRevers(0,0,99,47);*/
	param1.iBackColor= T_WHITE;
	param1.iForeColor= T_WHITE;
	param1.iLineColor= 255;
	param1.iLineStyle= 1;
	param1.iPattern= 0;
	param.iLineColor= 255;
	param.iLineStyle= 1;
/*	LineOut( 0, 40, 69, 40, &param );*/
	RectAngleOut(0,0,69,79,&param1);
#endif
	j= 0;
	while(1){
		ret = KeyWait();
		if(ret != 0){
			if(j == 0){
				DevInfo.DevFlag= DEVICE_BIT;
				DevInfo.DevName[0]= 'Y';
				DevInfo.DevName[1]= 0;
				DevInfo.DevAddress= 1;
				DevInfo.DevCnt= 1;
				DevInfo.DevData= &dsp_buff[0];
				dsp_buff[0]= 1;
				PLCWrite(&DevInfo);
			}else{
				DevInfo.DevFlag= DEVICE_BIT;
				DevInfo.DevName[0]= 'Y';
				DevInfo.DevName[1]= 0;
				DevInfo.DevAddress= 1;
				DevInfo.DevCnt= 1;
				DevInfo.DevData= &dsp_buff[0];
				dsp_buff[0]= 0;
				PLCWrite(&DevInfo);
			}
			j= (j+1)%2;
		}

#ifdef	OLD
		sprintf(dsp_buff,"%2d",ret);
		DotTextOut(0, i*16,dsp_buff,1,1,T_REPLACE,3,0);
		if(ret != 0){
#ifdef	OLD
			dsp_buff[0]= (char)ret;
			WriteDev.DevFlag = 1;
			WriteDev.DevName[0] = 'D';
			WriteDev.DevName[1] = 0;
			WriteDev.DevAddress = 200;
			WriteDev.DevCnt = 1;
			WriteDev.DevData = (char *)&dsp_buff[0];
			PLCWrite(&WriteDev);
#else
			if(ret == 1){		/* Open */
#ifndef	OLD
				SetTimeData.year= 3;
				SetTimeData.mon= 2;
				SetTimeData.day= 17;
				SetTimeData.hour= 10;
				SetTimeData.min= 0;
				SetTimeData.sec= 0;	
				SetTimeData.week= 6;
				DateTimeSet(&SetTimeData);
#endif
				mp= (T_MAIL *)TakeMail();
				mp->mcmd= 1;	/* Open */
				mp->mcod= 1;
				mp->mpec= 1;
				SendMail(T_MSG_TASK,(char *)mp);
				
				mp= (T_MAIL *)TakeMail();
				mp->mcmd= 2;	/* Message */
				mp->mcod= 1;
				mp->mext= 14;
				memcpy(mp->mbuf,"\xb0\xb1\xb0\xb2\xb0\xb3\xb0\xb4\xb0\xb5\xb0\xb6\xb0\xb7",14);
				SendMail(T_MSG_TASK,(char *)mp);
				mp= (T_MAIL *)TakeMail();
				mp->mcmd= 2;	/* Message */
				mp->mcod= 2;
				mp->mext= 40;
				memcpy(mp->mbuf,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ9999",40);
				SendMail(T_MSG_TASK,(char *)mp);
			}
			if(ret == 60){
				mp= (T_MAIL *)TakeMail();
				mp->mcmd= 3;	/* Delete */
				mp->mcod= 2;
				SendMail(T_MSG_TASK,(char *)mp);
			}
#endif
		}
#endif
		i= (i+ 1) % 2;
	}
}
#ifdef	OLD
	char	wbuff[1024+12];
	char	rbuff[512];
#endif


extern	int		BoardRateFlag;		/* 0:9600.7.E,1:38400.8.E,2:19200.8.E,3:9600.8.E,4:BarCode,5:Printer */
extern	volatile	unsigned int	PcTimeout;
extern	int		loopScreen,loopProj,loopPc;
extern	void	SystemDevEntry( void );
extern	int		PlcKansiFlag;
extern	unsigned char	GrpPLCcombuf[512];			/* �O���[�vPLC�ʐM�f�[�^ */
extern	int	SendRecPLCBCC(int mode,char *combuf,unsigned char *rData,int *Cnt,int rmode);
extern		int		LineBit;
extern	void	__MoveTo( int sx, int sy, int Pattern, int Mode );
extern	void	__LineToPrn(int ex,int ey,int mode );
unsigned char bData[8][4]={
	{0x1},
	{0x2},
	{0x4},
	{0x8},
	{0x10},
	{0x20},
	{0x40},
	{0x80},
};
void	DispAnalysis( STTFrm* pSTT )
{
	int		i,j,x1,y1,x2,y2;
	int		LoopCnt;
	int		sIdx,flag,idx;
	unsigned	NewRec;
	char	dsp_buff[64];
	_RECTANGLE_INFO	param1;
	_LINE_INFO	param;
	DEV_DATA	DevInfo;
	int		work;

	ClearDispBuff(1);
	init_filesystem();

	DeviceCnt= 0;
	j= 0;
	DeviceDataHed[j].DevFlag = 1;
	DeviceDataHed[j].DevName[0] = 6;	/* D */
	DeviceDataHed[j].DevName[1] = 0;
	DeviceDataHed[j].DevAddress = 10;
	DeviceDataHed[j].DevCnt = 1;
	DeviceDataHed[j].DevData = &DeviceData[0];
	j++;
	DeviceDataHed[j].DevFlag = 1;
	DeviceDataHed[j].DevName[0] = 6;	/* D */
	DeviceDataHed[j].DevName[1] = 0;
	DeviceDataHed[j].DevAddress = 100;
	DeviceDataHed[j].DevCnt = 1;
	DeviceDataHed[j].DevData = &DeviceData[2];
	j++;
	DeviceDataHed[j].DevFlag = 0;
	DeviceDataHed[j].DevName[0] = 1;	/* P */
	DeviceDataHed[j].DevName[1] = 0;
	DeviceDataHed[j].DevAddress = 17;
	DeviceDataHed[j].DevCnt = 1;
	DeviceDataHed[j].DevData = &DeviceData[4];
	j++;
	DeviceCnt= j;

	LoopCnt= 72;
	j= 71;
	while(1){
		NewRec= _TimeMSec;


		param.iLineColor= 255;
		param.iLineStyle= 3;
		LineOut(10,5,50,5,&param);
		LineBit= 0;
		/* -> */
		__MoveTo(10,10,param.iLineStyle,0);
		for(i= 0; i < 50; i+=5){
			__LineToPrn(10+i,10,1);
		}
		/* <- */
		__MoveTo(80,20,param.iLineStyle,0);
		for(i= 0; i < 50; i+=5){
			__LineToPrn(80-i,20,1);
		}
		/* Up */
		__MoveTo(100,60,param.iLineStyle,0);
		for(i= 0; i < 50; i+=5){
			__LineToPrn(100,60-i,1);
		}
		/* Up */
		__MoveTo(150,10,param.iLineStyle,0);
		for(i= 0; i < 50; i+=5){
			__LineToPrn(150,10+i,1);
		}
		__MoveTo(10,10,param.iLineStyle,0);
		for(i= 0; i < 50; i+=5){
			__LineToPrn(10+i,10+i,1);
		}
#ifdef	OLD
		param1.iBackColor= 0;
		param1.iForeColor= 255;
		param1.iLineColor= 255;
		param1.iLineStyle= 1;
		param1.iPattern= 0;
		RectAngleOut(100,30,150,30,&param1);
#endif
#ifdef	OLD
		CircleParam.iBackColor= 0;
		CircleParam.iForeColor= 255;
		CircleParam.iLineColor= 255;
		CircleParam.iPattern= 2;
		DrawDaen( 119, 39, 119, 39, &CircleParam );

#endif
#ifdef	OLD
		OogigataParam.iColor= 255;
		OogigataParam.iScaleColor= 255;
		DrawOrggata( 20,22,16,  0,-16,  0, 16,3,1,&OogigataParam);
		DrawOrggata( 27,22,16,  0, 16,  0,-16,3,1,&OogigataParam);
		DrawOrggata( 24,62,19, 13, 13, 13,-13,3,1,&OogigataParam);
		DrawOrggata( 24,62,19,-13,-13,-13, 13,3,1,&OogigataParam);
		DrawOrggata( 67,54,20, 14,-14,-14,-14,3,1,&OogigataParam);
		DrawOrggata( 76,27,21,  0,-21, 21,  0,3,1,&OogigataParam);
		DrawOrggata(103,79,21,-14, 14, 14, 14,3,1,&OogigataParam);
		DrawOrggata(125,20,16,-16,  0, 16,  0,3,1,&OogigataParam);
		DrawOrggata(125,26,16, 16,  0,-16,  0,3,1,&OogigataParam);
		DrawOrggata(152,79,22,  0, 22, 22,  0,3,1,&OogigataParam);
		DrawOrggata(150,79,22,-22,  0,  0, 22,3,1,&OogigataParam);
		DrawOrggata(173,26,15, 15,  0, 15,  0,3,1,&OogigataParam);
		DrawOrggata(210,52,22, 22,  0,  0,-22,3,1,&OogigataParam);
		DrawOrggata(209,52,22,  0,-22,-22,  0,3,1,&OogigataParam);
#endif
/*		DotTextOut(0, 0,"\xb1\xb2",0,1,T_REPLACE,3,0);*/
#ifdef	OLD
		CircleParam.iBackColor= 0;
		CircleParam.iForeColor= 255;
		CircleParam.iLineColor= 255;
		CircleParam.iPattern= 2;
		DrawDaen( 40, 100, 10, 50, &CircleParam );
		param.iLineColor= 255;
		param.iLineStyle= 7;
		LineOut(0,0,0,79,&param);
		param.iLineStyle= 6;
		LineOut(10,0,10,79,&param);
		param1.iBackColor= 0;
		param1.iForeColor= 255;
		param1.iLineColor= 255;
		param1.iLineStyle= 6;
		param1.iPattern= 0;
		RectAngleOut(0,0,239,79,&param1);
		param1.iLineStyle= 7;
		RectAngleOut(11,11,228,68,&param1);
		param1.iLineStyle= 2;
		RectAngleOut(20,20,219,59,&param1);
#endif
/*		param1.iLineStyle= 3;*/
/*		RectAngleOut(30,30,209,49,&param1);*/
/*		PutImageGp(0,0,7,7,(char *)bData);*/
		DrawLcdBank1();
#ifdef	OLD
		if((NewRec+ 300) > _TimeMSec){
			Delay((NewRec+ 300) - _TimeMSec);
		}else{
			Delay(10);
		}
#else
/*		SendRecPLCBCC(2,"00E0202",GrpPLCcombuf,&i,0);*/

		Delay(500);
#endif
	}
}
/*************************************************************************/
/*	Aplication Proc */
/*************************************************************************/
int vCommentDataSet(int iNum, char *cDataBuffer, int *iColor, int *iLen)
{
	return(0);
}
void	AlarmHistSend( void )
{
}
void	AlarmListSend( void )
{
}
void	WindowDisplay_Task( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
void	AlarmDetail_Task( STTFrm* pSTT )
{
	while(1){
		Delay(100);
	}
}
void	Classification_Task( STTFrm* pSTT )
{
	while(1){
		Delay(300);
	}
}
void GetWordDevice(unsigned int iFOffsetVal, unsigned int iSOffsetVal, char* cTempBuff)
{
}
void	GetDeviceSet(unsigned char* cBuffer, char* cDevName, int* iDevAddress)
{
}
int PrintDataDisplay()
{
	return(0);
}
void	vScreenDataSet()
{
}
/**************************** END *****************************/
#ifdef	TEST
#ifndef	OLD
		LoopCnt= 0;
		j= 72;
#endif

#ifndef	OLD
		double sita= ((5.0 * (double)LoopCnt)/180.0) * 3.14;
		double sita0= ((5.0 * (double)j)/180.0) * 3.14;
#else
		double sita= (45.0/180.0)*3.14;
#endif
		AreaClear(0,0,239,79,0);
		OogigataParam.iColor= 255;
		OogigataParam.iScaleColor= 255;
		double work= 20*cos(sita0);
		if(work > 0){
			work+= 0.5;
		}else{
			work-= 0.5;
		}
		x1= (int)work;
		work= 20*sin(sita0);
		if(work > 0){
			work+= 0.5;
		}else{
			work-= 0.5;
		}
		y1= (int)work;
		work= 20*cos(sita);
		if(work > 0){
			work+= 0.5;
		}else{
			work-= 0.5;
		}
		x2= (int)work;
		work= 20*sin(sita);
		if(work > 0){
			work+= 0.5;
		}else{
			work-= 0.5;
		}
		y2= (int)work;
		DrawOrggataProc( 120, 40, 20, x1, y1, x2, y2,0,0,&OogigataParam);

		sprintf(dsp_buff,"I=%2d,%2d",j,LoopCnt);
		DotTextOut(0, 0,dsp_buff,1,1,T_REPLACE,3,0);
		DrawLcdBank1();

		LoopCnt++;
		if(LoopCnt > 72){
			LoopCnt= 0;
			j++;
			if(j > 72){
				j= 0;
			}
		}
#endif
void	PlcConnectDisp(void)
{
}
void	PlcConnectDispClr(void)
{
}
void	PasswordLevelWrite(void)
{
}
