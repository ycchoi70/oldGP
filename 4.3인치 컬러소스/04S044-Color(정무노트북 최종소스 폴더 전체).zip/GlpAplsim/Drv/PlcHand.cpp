/************************************************/
/*	PLC ����M�n���h��?						*/
/*	2002.5.31									*/
/************************************************/
/* 2006.05.19 PLC2�̑���?�F�b�N�C��			*/
/************************************************/
#include	"sgt.h"

#ifdef	WIN32
	extern	int	K3P_SereaseByteCnt;
	extern	DEV_PC_TBL	K3P_SereaseByte[32];
	extern	unsigned char IndexTable[256];
	extern	int	K3P_SereaseWordCnt;
	extern	DEV_PC_TBL	K3P_SereaseWord[32];

	extern	int U_LowHighFlag;				/* 0:L-H,1:H-L */
	extern	int	U_K3P_SereaseByteCnt;
	extern	DEV_PC_TBL	U_K3P_SereaseByte[32];
	extern	unsigned char U_IndexTable[256];
	extern	int	U_K3P_SereaseWordCnt;
	extern	DEV_PC_TBL	U_K3P_SereaseWord[32];
#else
	extern	const	int	K3P_SereaseByteCnt;
	extern	const	DEV_PC_TBL	K3P_SereaseByte[32];
	extern	const	unsigned char IndexTable[256];
	extern	const	int	K3P_SereaseWordCnt;
	extern	const	DEV_PC_TBL	K3P_SereaseWord[32];

	extern	const	int U_LowHighFlag;				/* 0:L-H,1:H-L */
	extern	const	int	U_K3P_SereaseByteCnt;
	extern	const	DEV_PC_TBL	U_K3P_SereaseByte[32];
	extern	const	unsigned char U_IndexTable[256];
	extern	const	int	U_K3P_SereaseWordCnt;
	extern	const	DEV_PC_TBL	U_K3P_SereaseWord[32];
#endif
/* 20060202 */
	extern	unsigned	_TimeMSec;
	unsigned int sync_time;		/* 20061025ksc */
	int	PlcFreeMbx;
/****************************************************/
/*	����PLC�v���O��?(TYPE2)						*/
/****************************************************/
void	IndevWriteProc(T_MAIL *mp);
void	IndevReadProc(T_MAIL *mp);
/****************************************************/
/*	����PLC�v���O��?								*/
/****************************************************/

/****************************************************/
/*	�W?PLC�iFX�V��?�Y�j							*/
/****************************************************/

/*********************************/
/*********************************/

/*********************************/
/*********************************/
/*	PLC Device Collect Buff      */
/*********************************/

/********************************/
/*	�ėp�ʐM					*/
/********************************/
/************************************/
/*********************************/
int	Hex2Bin(char *buff)
{
	int		ret;

	if(buff[0] > '9'){	ret = (buff[0] - 'A') + 10;	}
	else{				ret = buff[0] - '0';		}
	ret *= 16;
	if(buff[1] > '9'){	ret += (buff[1] - 'A') + 10;}
	else{				ret += buff[1] - '0';		}
	return(ret);
}
int	Hex2nBin(char *buff,int cnt)
{
	int		i;
	int		ret;

	ret= 0;
	for(i= 0; i < cnt; i++){
		ret= ret << 4;
		if(buff[i] > '9'){	ret += (buff[i] - 'A') + 10;	}
		else{				ret += buff[i] - '0';			}
	}
	return(ret);
}
int	Bin2Hex1Keta(int data)
{
	int		ret;

	if(data > 9){	ret= 'A'+ data- 10;	}
	else{			ret= '0'+ data;		}
	return(ret);
}

// 2011.11.25 by ycchoi
int short SwapShort(char *org, char *out)
{
	out[0] = org[1];
	out[1] = org[0];
	return 1;
}

/************************************/
/*	PLC	Protocol Check				*/
/************************************/
int	IsPlc1Protocol(void)
{
	int	ret;

	ret= NG;
	if(CommonArea.PlcType1.PlcUserFlag != 0){
#ifdef	WIN32
		if(memcmp((char *)&GpFont[PLC1_PROTOCOL],PLC1STATUS,7) == 0){
#else
		if(memcmp((char *)PLC1_PROTOCOL,PLC1STATUS,7) == 0){
#endif
			ret= OK;
		}
	}
	return(ret);
}
/************************************/
/*	PLC	Protocol Check				*/
/************************************/
int	IsPlc2Protocol(void)
{
	int	ret;

	ret= NG;
	if(CommonArea.PlcType2.AuxPlcUserFlag != 0){
#ifdef	WIN32	/* 2006.05.19 */
		if(memcmp((char *)&GpFont[PLC2_PROTOCOL],PLC2STATUS,8) == 0){
#else
		if(memcmp((char *)PLC2_PROTOCOL,PLC2STATUS,8) == 0){
#endif
			ret= OK;
		}
	}
	return(ret);
}
int	GetMsSel(void)
{
	if(IsPlc1Protocol() == OK){
		return(GET_MS_SEL());
	}else{
		return(0);
	}
}
void	GetPlc2Ver(char* chDsp_Ver)
{
	if(IsPlc2Protocol() == OK){		/* 2008.12.10 */
		GET_PLC2_VER(chDsp_Ver);
	}
}
/************************************/
/*	PLC	SEND Proc					*/
/************************************/
void	PLCSendProc(T_MAIL *mp)
{
	if(Set.Ch1_iConnect == CH_CH1){		/* RS-232C */
		SendMail( T_SIO1DRV, (char *)mp );
	}else{
		SendMail( T_SIO0DRV, (char *)mp );
	}
}
/****************************************************
*   FUNC  : Sio0 Send Program		                *
*	In    :	mode=0:Send Only,1:Send & Recive		*
*	Out   : 										*
*   DATE  : 2002.10.01                              *
*****************************************************/
int	SendPLC2PCData( int mode,int cnt,char *buff,int TimeOut )
{
	T_MAIL	*mp;
	int		mbx;
	int		OldResp;
	int		ret;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RS_SEND;
	mp->mpar = cnt;
	mp->mptr = buff;
	mp->mext = mode;
	mp->mwrk= TimeOut;		/* 3s */
	if(Set.Ch1_iConnect == CH_CH1){		/* RS-232C */
		SendMail( T_SIO0DRV, (char *)mp );
	}else{
		SendMail( T_SIO1DRV, (char *)mp );
	}
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	ret= (short)mp->mpec;
	FreeMail((char *)mp);
	FreeMbx(mbx);
	return(ret);
}
int	SendPC2PLCData( int mode,int cnt,char *buff,int TimeOut )
{
	T_MAIL	*mp;
	int		mbx;
	int		OldResp;
	int		ret;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RS_SEND;
	mp->mpar = cnt;
	mp->mptr = buff;
	mp->mext = mode;
	mp->mwrk= TimeOut;		/* 500ms(041214 800->500) */
	PLCSendProc(mp);
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	ret= (short)mp->mpec;
	FreeMail((char *)mp);
	FreeMbx(mbx);
	return(ret);
}
int	SendPC2PLCData2( int mode,int cnt,char *buff,int TimeOut )
{
	T_MAIL	*mp;
	int		mbx;
	int		OldResp;
	int		ret;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RS_SEND;
	mp->mpar = cnt;
	mp->mptr = buff;
	mp->mext = mode;
	mp->mwrk= TimeOut;		/* 500ms(041214 800->500) */
	if(Set.Ch1_iConnect == CH_CH1){		/* RS-232C */
		SendMail( T_SIO0DRV, (char *)mp );
	}else{
		SendMail( T_SIO1DRV, (char *)mp );
	}
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	ret= (short)mp->mpec;
	FreeMail((char *)mp);
	FreeMbx(mbx);
	return(ret);
}
const	struct{
	int	sadd;
	int	oadd;
}ChgUWTbl[66]={
	{ 0,    0},{ 1, 1000},{ 2, 2000},{ 3, 3000},{ 4, 4000},
	{ 5, 5000},{ 6, 6000},{ 7, 7000},{ 8, 7300},{ 9,   -1},
	{10, 7600},{11, 7700},{12,   -1},{13, 8000},{14,   -1},
	{15, 8300},{16, 8400},{17,   -1},{18, 8700},{19,   -1},
	{20, 9000},{21,10000},{22,11000},{23,12000},{24,13000},
	{25,14000},{26,15000},{27,16000},{28,17000},{29,18000},
	{30,   -1},{31,   -1},{32,   -1},{33,   -1},{34,   -1},
	{35,   -1},{36,19500},{37,   -1},{38,20000},{39,   -1},
	{40,21000},{41,22000},{42,23000},{43,24000},{44,25000},
	{45,26000},{46,27000},{47,28000},{48,29000},{49,30000},
	{50,   -1},{51,   -1},{52,   -1},{53,   -1},{54,   -1},
	{55,   -1},{56,   -1},{57,   -1},{58,   -1},{59,   -1},
	{60,31000},{61,32000},{62,   -1},{63,   -1},{64,   -1},
	{65,   -1},
};

const	struct{
	int	sadd;
	int	eadd;
}ChkUWTbl[66]={
	{   0,    14},{   15,    29},{   30,  1999},{ 2000,  5999},{6000, 6355},
	{6400,  6655},{ 6700,  6955},{ 7000,  7255},{ 7300,  7555},{7600, 7615},
	{7700,  7955},{ 8000,  8255},{ 8300,  8315},{ 8400,  8655},{8700, 8955},
	{9000, 18999},{19500, 19755},{20000, 20999},{21000, 30999},
};

/************************************************/
int	ChangeUWAddr(int bit_word,unsigned long* address)
{
	int	idx;
	int	ret;

	ret= NG;
	if(bit_word == PLC_BIT){
		idx= (*address/16000);
		if(ChgUWTbl[idx].oadd != -1){
			*address= (*address % 16000)+ (ChgUWTbl[idx].oadd << 4);
			ret= OK;
		}
	}else{
		idx= (*address/1000);
		if(ChgUWTbl[idx].oadd != -1){
			*address= (*address % 1000)+ ChgUWTbl[idx].oadd;
			ret= OK;
		}
	}
	return(ret);
}
/*********************************/
/*	PLC Read		             */
/*********************************/
int	PLCRead(DEV_DATA *DevInfo)
{
	T_MAIL	*mp;
	int	mbx;
	int OldResp;
	int	ret;
	T_MAIL	*Workmp;

	if((DevInfo->DevName[0] == 0x01) || (DevInfo->DevName[0] == 0x00)){	return(0);	}/* ?? DEVICE == OK */
	if(((DevInfo->DevName[0] == 0x7f) || ((unsigned char)DevInfo->DevName[0] == (unsigned char)0xef))){
		/* �����f�o�C�X�iGD,GB) */
		Workmp= (T_MAIL*)TakeMail();
		Workmp->mcmd= PLC_READ;		/* Read */
		Workmp->mpec = DevInfo->DevFlag;
		Workmp->mpar = DevInfo->DevAddress;
		memcpy((char *)Workmp->mbuf,(char *)DevInfo->DevName,2);
		Workmp->mbuf[2] = 0;
		Workmp->mptr = DevInfo->DevData;
		Workmp->mext = DevInfo->DevCnt;
#ifdef	LP_S044
		if(ChangeUWAddr(Workmp->mpec,&Workmp->mpar) == OK){		//Change UW address
			IndevRead(Workmp);
			ret= 0;
		}else{		ret= -1;	}					//Device Error
#endif
#ifdef	GP_S057
		IndevRead(Workmp);
		ret= 0;
#endif
#ifdef	GP_S044
		IndevRead(Workmp);
		ret= 0;
#endif
		FreeMail((char*)Workmp);
	}else{
/*------------------------------------------------------------------------------------ */
		if(PlcConnectFlag == 1){
			mbx = TakeMbx();
/*			mp= (T_MAIL *)TakeMail();*/
			mp= (T_MAIL *)ReceiveMail(PlcFreeMbx);
			OldResp = ChangeMailResp( (char *)mp, mbx );
			mp->mcmd= PLC_READ;		/* Read */
			mp->mpec = DevInfo->DevFlag;
			mp->mpar = DevInfo->DevAddress;
			memcpy((char *)mp->mbuf,(char *)DevInfo->DevName,2);
			mp->mbuf[2] = 0;
			mp->mptr = DevInfo->DevData;
			mp->mext = DevInfo->DevCnt;
			SendMail( T_PLCHAND, (char *)mp );
			mp= (T_MAIL *)ReceiveMail( mbx );
			ret= (short)mp->mpec;
			OldResp = ChangeMailResp( (char *)mp, OldResp );
			if((signed short)mp->mpec == -1){
				PlcConnectFlag= 0;
			}
/*			FreeMail((char *)mp);*/
			ResponseMail((char *)mp);
			FreeMbx(mbx);
		}else{
			ret= -1;
		}
/*------------------------------------------------------------------------------------ */
	}
	return(ret);
}
int	PLCIndevDirectRead(DEV_DATA *DevInfo)
{
	int	ret;
	T_MAIL	*Workmp;

	if((DevInfo->DevName[0] == 0x01) || (DevInfo->DevName[0] == 0x00)){	return(0);	}/* ?? DEVICE == OK */
	if(((DevInfo->DevName[0] == 0x7f) || ((unsigned char)DevInfo->DevName[0] == (unsigned char)0xef))){
		/* �����f�o�C�X�iGD,GB) */
		Workmp= (T_MAIL*)TakeMail();
		Workmp->mcmd= PLC_READ;		/* Read */
		Workmp->mpec = DevInfo->DevFlag;
		Workmp->mpar = DevInfo->DevAddress;
		memcpy((char *)Workmp->mbuf,(char *)DevInfo->DevName,2);
		Workmp->mbuf[2] = 0;
		Workmp->mptr = DevInfo->DevData;
		Workmp->mext = DevInfo->DevCnt;
#ifdef	LP_S044
		if(ChangeUWAddr(Workmp->mpec,&Workmp->mpar) == OK){		//Change UW address
			IndevReadProc(Workmp);
			ret= 0;
		}else{		ret= -1;	}					//Device Error
#endif
#ifdef	GP_S057
		IndevRead(Workmp);
		ret= 0;
#endif
#ifdef	GP_S044
		IndevRead(Workmp);
		ret= 0;
#endif
		FreeMail((char*)Workmp);
	}
	return(ret);
}
int	PLCReadNoWait(DEV_DATA *DevInfo)
{
	T_MAIL	*mp;

	if(((DevInfo->DevName[0] == 0x7f) || ((unsigned char)DevInfo->DevName[0] == (unsigned char)0xef))){
		mp= (T_MAIL *)TakeMail();
		/* �����f�o�C�X�iGD,GB) */
		mp->mcmd= PLC_READ;		/* Read */
		mp->mpec = DevInfo->DevFlag;
		mp->mpar = DevInfo->DevAddress;
		memcpy((char *)mp->mbuf,(char *)DevInfo->DevName,2);
		mp->mbuf[2] = 0;
		mp->mptr = DevInfo->DevData;
		mp->mext = DevInfo->DevCnt;
#ifdef	LP_S044
		if(ChangeUWAddr(mp->mpec,&mp->mpar) == OK){		//Change UW address
			IndevRead(mp);
		}
#endif
#ifdef	GP_S057
		IndevRead(mp);
#endif
#ifdef	GP_S044
		IndevRead(mp);
#endif
		FreeMail((char *)mp);
	}else{
		if(PlcConnectFlag != 0){
/*			mp= (T_MAIL *)TakeMail();*/
			mp= (T_MAIL *)ReceiveMail(PlcFreeMbx);
			mp->mcmd= PLC_READ;		/* Read */
			mp->mpec = DevInfo->DevFlag;
			mp->mpar = DevInfo->DevAddress;
			memcpy((char *)mp->mbuf,(char *)DevInfo->DevName,2);
			mp->mbuf[2] = 0;
			mp->mptr = DevInfo->DevData;
			mp->mext = DevInfo->DevCnt;
			SendMail( T_PLCHAND, (char *)mp );
		}
	}
	return(0);
}
/*********************************/
/*	PLC Write		             */
/*********************************/
int	PLCWrite(DEV_DATA *DevInfo)
{
	T_MAIL	*mp;
	int	mbx;
	int OldResp;
	int	ret;
	T_MAIL*	Workmp;

	if((DevInfo->DevName[0] == 0x01) || (DevInfo->DevName[0] == 0x00)){	return(0);	}/* ?? DEVICE == OK */
/*------------------------------------------------------------------------------------ */
	if(((DevInfo->DevName[0] == 0x7f) || ((unsigned char)DevInfo->DevName[0] == (unsigned char)0xef))){
		/* �����f�o�C�X�iGD,GB) */
		Workmp= (T_MAIL*)TakeMail();
		Workmp->mcmd= PLC_WRITE;		/* Write */
		Workmp->mpec = DevInfo->DevFlag;
		Workmp->mpar = DevInfo->DevAddress;
		Workmp->mptr = DevInfo->DevData;
		Workmp->mext = DevInfo->DevCnt;
		memcpy((char *)Workmp->mbuf,(char *)DevInfo->DevName,2);
		Workmp->mbuf[2] = 0;
#ifdef	LP_S044
		if(ChangeUWAddr(Workmp->mpec,&Workmp->mpar) == OK){		//Change UW address
			IndevWrite(Workmp);
			ret= 0;
		}else{	ret= -1;	}
#endif
#ifdef	GP_S057
		IndevWrite(Workmp);
		ret= 0;
#endif
#ifdef	GP_S044
		IndevWrite(Workmp);
		ret= 0;
#endif
		FreeMail((char*)Workmp);
	}else{
		if(PlcConnectFlag == 1){
			mbx = TakeMbx();
/*			mp= (T_MAIL *)TakeMail();*/
			mp= (T_MAIL *)ReceiveMail(PlcFreeMbx);
			OldResp = ChangeMailResp( (char *)mp, mbx );
			mp->mcmd= PLC_WRITE;		/* Write */
			mp->mpec = DevInfo->DevFlag;
			mp->mpar = DevInfo->DevAddress;
			mp->mptr = DevInfo->DevData;
			mp->mext = DevInfo->DevCnt;
			memcpy((char *)mp->mbuf,(char *)DevInfo->DevName,2);
			mp->mbuf[2] = 0;
			SendMail( T_PLCHAND, (char *)mp );
			mp= (T_MAIL *)ReceiveMail( mbx );
			ret= (short)mp->mpec;
			OldResp = ChangeMailResp( (char *)mp, OldResp );
			if((signed short)mp->mpec == -1){
				PlcConnectFlag= 0;
			}
/*			FreeMail((char *)mp);*/
			ResponseMail((char *)mp);
			FreeMbx(mbx);
		}else{						/* Connect Error */
			ret= -1;
		}
	}
/*------------------------------------------------------------------------------------ */
	return(ret);
}
/*********************************/
/*	PLC Write(No Wait)           */
/*	Write Data <= 28 Byte		 */
/*********************************/
void	PLCWriteNoWait(DEV_DATA *DevInfo)
{
	T_MAIL	*mp;
	int		cnt;

	cnt= DevInfo->DevCnt;
	if(DevInfo->DevFlag != 0){	cnt *= 2;	}	/* Word */
	if(cnt > (32- 8)){
		//224-8�ȏ�͂v������?�l������
		if(cnt > (224- 8)){
			PLCWrite(DevInfo);
		}else{
			if(((DevInfo->DevName[0] == 0x7f) || ((unsigned char)DevInfo->DevName[0] == (unsigned char)0xef))){
				/* �����f�o�C�X�iGD,GB) */
				mp= (T_MAIL *)TakeMail();
				mp->mcmd= PLC_WRITE;		/* Write */
				mp->mpec = DevInfo->DevFlag;
				mp->mpar = DevInfo->DevAddress;
				mp->mptr = DevInfo->DevData;
				mp->mext = DevInfo->DevCnt;
				memcpy((char *)mp->mbuf,(char *)DevInfo->DevName,2);
				mp->mbuf[2] = 0;
#ifdef	LP_S044
				if(ChangeUWAddr(mp->mpec,&mp->mpar) == OK){		//Change UW address
					IndevWrite(mp);
				}
#endif
#ifdef	GP_S057
				IndevWrite(mp);
#endif
#ifdef	GP_S044
				IndevWrite(mp);
#endif
				FreeMail((char *)mp);
			}else{
				/* Mail���P�O�ȉ��ɂȂ�����҂� */
				while(1)
				{
					/* 256 Mail */
					if(_Mbx[242].MailCount > 1){
						break;
					}
					Delay(10);
				}
				mp= (T_MAIL *)TakeMemory(256);
				mp->mcmd= PLC_WRITE;		/* Write */
				mp->mpec = DevInfo->DevFlag;
				memcpy(&mp->mbuf[8],DevInfo->DevData,cnt);
				mp->mpar = DevInfo->DevAddress;
				mp->mptr = &mp->mbuf[8];
				mp->mext = DevInfo->DevCnt;
				memcpy((char *)mp->mbuf,(char *)DevInfo->DevName,2);
				mp->mbuf[2] = 0;
				SendMail( T_PLCHAND, (char *)mp );
			}
		}
	}else{
		if(((DevInfo->DevName[0] == 0x7f) || ((unsigned char)DevInfo->DevName[0] == (unsigned char)0xef))){
			/* �����f�o�C�X�iGD,GB) */
			mp= (T_MAIL *)TakeMail();
			mp->mcmd= PLC_WRITE;		/* Write */
			mp->mpec = DevInfo->DevFlag;
			mp->mpar = DevInfo->DevAddress;
			mp->mptr = DevInfo->DevData;
			mp->mext = DevInfo->DevCnt;
			memcpy((char *)mp->mbuf,(char *)DevInfo->DevName,2);
			mp->mbuf[2] = 0;
#ifdef	LP_S044
			if(ChangeUWAddr(mp->mpec,&mp->mpar) == OK){		//Change UW address
				IndevWrite(mp);
			}
#endif
#ifdef	GP_S057
			IndevWrite(mp);
#endif
#ifdef	GP_S044
			IndevWrite(mp);
#endif
			FreeMail((char *)mp);
		}else{
			/* Mail���P�O�ȉ��ɂȂ�����҂� */
//			while(1)
//			{
//				if(_Mbx[240].MailCount > 1){
//					break;
//				}
//				Delay(10);
//			}
/*			mp= (T_MAIL *)TakeMail();*/
			mp= (T_MAIL *)ReceiveMail(PlcFreeMbx);
			mp->mcmd= PLC_WRITE;		/* Write */
			mp->mpec = DevInfo->DevFlag;
			memcpy(&mp->mbuf[8],DevInfo->DevData,cnt);
			mp->mpar = DevInfo->DevAddress;
			mp->mptr = &mp->mbuf[8];
			mp->mext = DevInfo->DevCnt;
			memcpy((char *)mp->mbuf,(char *)DevInfo->DevName,2);
			mp->mbuf[2] = 0;
			SendMail( T_PLCHAND, (char *)mp );
		}
	}
}
int	GetDevName(int bFlag,char *src,char *obj,int *DevInfo)
{
	int		ret;

	ret= -1;
	switch(Set.Ch1_iKind){
	case UNIVERSAL:		ret= UN_GetDevNamePLC(bFlag,(unsigned char *)src,obj,DevInfo);	break;
	case DEFAULT_PLC:	ret= LG_GetDevNamePLC(bFlag,(unsigned char *)src,obj,DevInfo);	break;
	case ELSE_PLC:
//		if(CommonArea.PlcType1.PlcUserFlag == 0){	//PLC1 No Use 071017
		if(IsPlc1Protocol() == NG){	/* 2008.12.10 */
			//����UNIVERSAL
			ret= UN_GetDevNamePLC(bFlag,(unsigned char *)src,obj,DevInfo);
			break;
		}
//		if(ElsPlcOK == 1){
//		if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
		ret= GET_PLC_NAME(bFlag,(unsigned char *)src,obj,DevInfo);
//		}
		break;
	default:		//20080903CH1��Printer,Barcode�̎�
		ret= UN_GetDevNamePLC(bFlag,(unsigned char *)src,obj,DevInfo);	break;
	}
	return(ret);
}
int		Device2Index(int bwflag,char *Name)
{
	int		ret;

	ret= -1;
	switch(Set.Ch1_iKind){
	case UNIVERSAL:		ret= UN_Device2IndexPLC(bwflag,Name);	break;
	case DEFAULT_PLC:	ret= LG_Device2IndexPLC(bwflag,Name);	break;
	case ELSE_PLC:
//		if(ElsPlcOK == 1){
		if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
			ret= DEVICE_2_INDEX(bwflag,Name);
		}else{
			ret= UN_Device2IndexPLC(bwflag,Name);
		}
		break;
	default:			ret= UN_Device2IndexPLC(bwflag,Name);	break;	//20080903

	}
	return(ret);
}
/************************************************/
/************************************************/
int		ElsCheckPLC_Addr(int bwflag,char *DevName,unsigned int *Address1,unsigned int *Address2)
{
	int		i;
	int		ret;
	int		PLCByteCnt;
	int		PLCWordCnt;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
//	unsigned char *PLCIndex;
	unsigned int		Max,Min;

#ifdef	WIN32
	PLCByteCnt= (int)GpFont[PLC1_DEV_TABLE];		/*  */
	ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
	PLCWordCnt= (int)GpFont[PLC1_DEV_TABLE+4];		/*  */
	WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
//	PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
	PLCByteCnt= *(int *)PLC1_DEV_TABLE;
	ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
	PLCWordCnt= *(int *)(PLC1_DEV_TABLE+4);		/*  */
	WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
//	PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
	ret= -1;
	Max= 0;
	Min= 99999999;		//070827 999999->99999999
	if(bwflag == 0){	/* Bit */
		for(i= 0; i< PLCByteCnt; i++){
			if(strcmp(ByteTbl->DevName,DevName) == 0){
				if((*Address1 >= ByteTbl->DeviceMin) && (*Address1 <= ByteTbl->DeviceMax)){
					ret= 0;
				}else{
					if((ByteTbl->DeviceMin > *Address1) && (ByteTbl->DeviceMin < Min)){
						Min= ByteTbl->DeviceMin;
					}
					if((ByteTbl->DeviceMax < *Address1) && (ByteTbl->DeviceMax > Max)){
						Max= ByteTbl->DeviceMax;
					}
				}
			}
			ByteTbl++;
		}
	}else{
		for(i= 0; i< PLCWordCnt; i++){
			if(strcmp(WordTbl->DevName,DevName) == 0){
				if((*Address1 >= WordTbl->DeviceMin) && (*Address1 <= WordTbl->DeviceMax)){
					ret= 0;
				}else{
					if((WordTbl->DeviceMin > *Address1) && (WordTbl->DeviceMin < Min)){
						Min= WordTbl->DeviceMin;
					}
					if((WordTbl->DeviceMax < *Address1) && (WordTbl->DeviceMax > Max)){
						Max= WordTbl->DeviceMax;
					}
				}
			}
			WordTbl++;
		}
	}
	*Address1= Max;
	*Address2= Min;
	return(ret);
}
int		CheckPlcDevice(int bwflag,char *Name,int *Address1,int *Address2)
{
	int		ret;

	ret= -1;
	switch(Set.Ch1_iKind){
	case UNIVERSAL:		ret= UN_CheckDevice_Addr(bwflag,Name,(unsigned int*)Address1,(unsigned int*)Address2);	break;
	case DEFAULT_PLC:	ret= CheckDevice_Addr(bwflag,Name,(unsigned int*)Address1,(unsigned int*)Address2);	break;
	case ELSE_PLC:
//		if(ElsPlcOK == 1){
		if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
			ret= ElsCheckPLC_Addr(bwflag,Name,(unsigned int*)Address1,(unsigned int*)Address2);
		}else{	/* Universal 2008.12.10 */
			ret= UN_CheckDevice_Addr(bwflag,Name,(unsigned int*)Address1,(unsigned int*)Address2);
		}
		break;
	default:		ret= UN_CheckDevice_Addr(bwflag,Name,(unsigned int*)Address1,(unsigned int*)Address2);	break;	//20080903
	}
	return(ret);
}
/*********************************/
/*	PLC Group Read & Make Group  */
/*********************************/
int	PlcGroopSend( int Comm )
{
	T_MAIL	*mp;
	int	mbx;
	int OldResp;
/* 20081002 */
	int	ret= 0;

	mbx = TakeMbx();
/*	mp= (T_MAIL *)TakeMail();*/
	mp= (T_MAIL *)ReceiveMail(PlcFreeMbx);
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd= Comm;		/* Write */
	SendMail( T_PLCHAND, (char *)mp );
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	ret= (short)mp->mpec;
	if(ret == -1){
		PlcConnectFlag= 0;
/* 20081002 */
		ret= -1;
	}
/*	FreeMail((char *)mp);*/
	ResponseMail((char *)mp);
	FreeMbx(mbx);
/* 20081002 */
	return(ret);
}
/************************************************/
/*	PLC ���M?PROC								*/
/************************************************/
/*	Func	SendRecPLC()						*/
/*	mode	0:read,1:write & ACK,2:write & read,3:write & ACK & Read*/
/*	*combuf Send Data							*/
/*	*rData  Read Data Save Area					*/
/*	cnt		Read Count							*/
/************************************************/
int	SendRecPLC(int mode,unsigned char *rData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)	/*ksc20040715 ADP���� PLC�� ���� ���� */ 
{
	int		j;
	int		ret;
	int		mbx;
	T_MAIL	*mp;
	int OldResp;
	unsigned char *RecBuf;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RS_SEND;	/* ���M */
	mp->mpar = sCnt;	/* Length */
	mp->mext = mode;	/* ACK��M */
	mp->mptr = sBuff;
	mp->mwrk = TimeOut;		/* 500ms(041214 800->500->1000(051102)) */ /*ksc20040715 ���� �۽��� �󸶰� ������ ��ٸ����ΰ��� ���� */
	PLCSendProc(mp);
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	ret = (signed short)mp->mpec;
	if(ret == 0){   /*ksc20040715 PLC�κ��� ����Ÿ�� ���ŵǾ��� ��� */
		RecBuf= (unsigned char *)mp->mptr;
		if((mode == 2) || (mode == 3)){				/* Read */
			if(rmode == 0){
				memcpy(rData,mp->mptr,mp->mext);
				*Cnt= mp->mext;
			}else{
				if(mp->mext > 5){
					for(j = 0; j < (int)((mp->mext- 4)/2); j++){
						*rData++ = (unsigned char)Hex2Bin((char *)&RecBuf[j*2+ 1]);
					}
				}else{
					ret= -1;
				}
			}
		}
		PlcErrorFlag= 0;
/*		memset(RecBuf,0,sizeof(RecBuf));*/
	}else{		/* Time Out */  
		if(Set.Ch1_iConnect == CH_CH1){	Comm1RecMode= 0;	}
		else{							Comm0RecMode= 0;	}
/*		PlcConnectFlag= 0;*/
/*		PlcErrorFlag= 1;*/
	}
	FreeMbx(mbx);
	FreeMail((char *)mp);
	return(ret);
}
/************************************************/
/*	Func	SendRecPLC()						*/
/*	mode	0:read,1:write & ACK,2:write & read,3:write & ACK & Read*/
/*	*combuf Send Data							*/
/*	*rData  Read Data Save Area					*/
/*	cnt		Read Count							*/
/************************************************/
int	SendRecPLC2(int mode,unsigned char *rData,int *Cnt,int rmode,int sCnt,char *sBuff,int TimeOut)
{
	int		j;
	int		ret;
	int		mbx;
	T_MAIL	*mp;
	int OldResp;
	unsigned char *RecBuf;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = RS_SEND;	/* ���M */
	mp->mpar = sCnt;	/* Length */
	mp->mext = mode;	/* ACK��M */
	mp->mptr = sBuff;
	mp->mwrk= TimeOut;		/* 500ms(041214 800->500) */
	if(Set.Ch1_iConnect == CH_CH1){		/* RS-232C */
		SendMail( T_SIO0DRV, (char *)mp );
	}else{
		SendMail( T_SIO1DRV, (char *)mp );
	}
	mp= (T_MAIL *)ReceiveMail( mbx );
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	ret = (signed short)mp->mpec;
	if(ret == 0){
		RecBuf= (unsigned char *)mp->mptr;
		if((mode == 2) || (mode == 3)){				/* Read */
			if(rmode == 0){
				memcpy(rData,mp->mptr,mp->mext);
				*Cnt= mp->mext;
			}else{
				if(mp->mext > 5){
					for(j = 0; j < (int)((mp->mext- 4)/2); j++){
						*rData++ = (unsigned char)Hex2Bin((char *)&RecBuf[j*2+ 1]);
					}
				}
			}
		}
	}else{
		ret= -1;
	}
	FreeMbx(mbx);
	FreeMail((char *)mp);
	return(ret);
}
/****************************/
/* PC <-----> PLC			*/
/****************************/
int	SendThruePLC(int mode,int cnt,char *sBuff,int TimeOut)
{
	int		ret;
	int		mbx;
	T_MAIL	*mp;
	int OldResp;
	int		i;

	mbx = TakeMbx();
	mp = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	for(i = 0; i < 3; i++){
		mp->mcmd = RS_SEND;	/* ���M */
		mp->mpar = cnt;	/* Length */
		mp->mext = mode;		/* DATA OR ACK��M */
		mp->mptr = sBuff;
		mp->mwrk= TimeOut;		/* 3s */
		PLCSendProc(mp);
		mp= (T_MAIL *)ReceiveMail( mbx );
		ret = (signed short)mp->mpec;
		if(ret == OK){
			break;
		}
	}
	OldResp = ChangeMailResp( (char *)mp, OldResp );
/* 20081003 */
	if((ret == OK) && (mode != 0)){
		memcpy(PlcThrueBuff,mp->mptr,mp->mext);
		PlcThrueCnt= mp->mext;
		/* PC�֑��M */
		OldResp = ChangeMailResp( (char *)mp, mbx );
		mp->mcmd = RS_SEND;
		mp->mpar = PlcThrueCnt;
		mp->mptr = PlcThrueBuff;
		mp->mext = 0;		/*  */
		mp->mwrk= TimeOut;		/* 3s */
		if(Set.Ch1_iConnect == CH_CH1){	/* PLC(RS-232C) */
			SendMail(T_SIO0DRV,(char *)mp);
		}else{
			SendMail(T_SIO1DRV,(char *)mp);
		}
		mp= (T_MAIL *)ReceiveMail( mbx );
		ret = (signed short)mp->mpec;
		OldResp = ChangeMailResp( (char *)mp, OldResp );
/* 20081003 */
		sBuff= (char*)PlcThrueBuff;		/* 20081002 */
	}
	FreeMbx(mbx);
	FreeMail((char *)mp);
	return(ret);
}
int	PlcControl( T_MAIL *mp )
{
	T_MAIL	*mp1;
	int	mbx;
	int OldResp;
	int	ret;

	mbx = TakeMbx();
	mp1 = (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp1, mbx );
	mp1->mcmd = 0;		/* control */
	mp1->mext = 0;		/* Initial */
	mp1->mpec = mp->mpec;
	mp1->minf = mp->minf;
	mp1->mcod = mp->mcod;
	mp1->mpar = mp->mpar;
	PLCSendProc(mp1);
	mp1= (T_MAIL *)ReceiveMail( mbx );
	ret= (short)mp1->mpec;
	OldResp = ChangeMailResp( (char *)mp1, OldResp );
	FreeMbx(mbx);
	FreeMail((char *)mp1);
//	return(mp1->mpec);
	return(ret);
}
/*********************************/
/*	PC <--> PLC Send Read        */
/*********************************/
/* 20081003 */
int	SendPLCPCData( void )
{
	T_MAIL	*mp;
	int		mbx;
	int OldResp;
/* 20081003 */
	int		ret;

	/* PLC�֑��M */
	mbx = TakeMbx();
/*	mp= (T_MAIL *)TakeMail();*/
	mp= (T_MAIL *)ReceiveMail(PlcFreeMbx);
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd = PLC_THRUE;	/* ���M */
	mp->mpar = PlcThrueCnt;	/* Length */
	mp->mptr= PlcThrueBuff;
	mp->mext = 2;
	SendMail( T_PLCHAND, (char *)mp );
	mp= (T_MAIL *)ReceiveMail( mbx );
/* 20081003 */
	ret= (short)mp->mpec;
	OldResp = ChangeMailResp( (char *)mp, OldResp );
/*	FreeMail((char *)mp);*/
	ResponseMail((char *)mp);
	FreeMbx(mbx);
/* 20081003 */
	return(ret);
}
/************************************************/
/*	FX1N										*/
/************************************************/
int	MakeGroupDev( void )
{
	int	ret= -1;

	switch(Set.Ch1_iKind){
	case UNIVERSAL:		ret= 0;								break;
	case DEFAULT_PLC:	ret= LG_MakeGroupDevPLC(PlcType);	break;
	case ELSE_PLC:
//		if(ElsPlcOK == 1){
		if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
			ret= PLC_MAKE_GROUP(PlcType);
		}
		break;
	}
	return(ret);
}
int	RecGroupDev( void )
{
	int	ret= -1;

	switch(Set.Ch1_iKind){
	case UNIVERSAL:		ret= 0;								break;
	case DEFAULT_PLC:	ret= LG_RecGroupPLCDev(PlcType);	break;
	case ELSE_PLC:
//		if(ElsPlcOK == 1){
		if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
			ret= PLC_GROUP_READ(PlcType);
		}
		break;
	}
	return(ret);
}
void	SendPLCGroup(void)
{
	MakeGroupDev();
	RecGroupDev();
}

/****************************************/
/*	PLC Connect Check					*/
/*	ret    0:NG,1:OK					*/
/****************************************/
#ifdef	WIN32
extern	int		SioPLCMode;
extern	int		SioPCMode;
extern	int		SioPCOpenFlag;
extern	int		SioPLCOpenFlag;
#endif
int	PlcConnectProc( void )				/* 20091222 */
{
	int	ret;
	int	param[9];		 /* 20061025 */ /* 20111017 */

	ret= 0;
	switch(Set.Ch1_iKind){
	case UNIVERSAL:					/* �ėp */
		PlcTimeout = 0;

		switch(Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed){		/* 20061025 */
		case 0:	sync_time = 50;		break;						/* 300bps */
		case 1:	sync_time = 30;		break;						/* 600bps */
		case 2:	case 3:	case 4:	case 5:
		case 6:	case 7:	case 8:
		case 9:	sync_time = 20;		break;
		default:sync_time = 50;		break;
		}
		if(Set.Ch1_iConnect == CH_CH1){		/* RS-232C */
/*			RsModeSet(RS_PC,*/
/*				      RS_INIT,*/
/*					  Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed,*/ 
/*				      Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1, */
/*					  Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity);*/ /* 20061025ksc */
			RsModeSetChanel(RS_PC,&Set.Ch1_Serial_Param[Set.Ch1_iKind]);		/* 2009.09.04 Add Stop */
		}else{						/* RS-422 */
/*			RsModeSet(RS_PLC,*/
/*				      RS_INIT,*/
/*					  Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed,*/
/*				      Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1,*/
/*					  Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity);*/ /* 20061025ksc */
			RsModeSetChanel(RS_PLC,&Set.Ch1_Serial_Param[Set.Ch1_iKind]);		/* 2009.09.04 Add Stop */
		}
		ret= 1;
		break;
	case DEFAULT_PLC:					/* Default */
		param[0]= PlcType;
		param[1]= Set.iGPSta;
		param[2]= Set.iDstSta;
		param[3]= Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed;  /* 20061025ksc */
		param[4]= Set.Ch2_iKind;  /* 20090704 */
		param[5]= CH_CH0;  /* 20100406 */
		param[6]= ((int)(unsigned char)Set.cPlcTypeCode[2] << 8)+(unsigned char)Set.cPlcTypeCode[3]; /* 20111017 */
//		param[6]= ((int)Set.cPlcTypeCode[2] << 8) + (int)Set.cPlcTypeCode[3]; /* 20111017 */
		param[7]= (int)(unsigned char)Set.cPlcTypeCode[4]; /* 20111017 */
		param[8]= (int)(unsigned char)Set.cPlcTypeCode[5]; /* 20111017 */

		ret= LG_Connection(param,Set.Ch1_iConnect);
		if(ret == 0){	PlcErrorFlag= 1;	}	/* �ʐM�G��? */
		else{			PlcErrorFlag= 0;	}
		break;
	case ELSE_PLC:
//#ifdef	WIN32
//		if(memcmp((char *)&GpFont[PLC1_PROTOCOL],PLC1STATUS,7) != 0){
//#else
//		if(memcmp((char *)PLC1_PROTOCOL,PLC1STATUS,7) != 0){
//#endif
		if(IsPlc1Protocol() == NG){	/* 2008.12.10 */
			break;
		}
		/* 20070206 */
		if((GET_MS_SEL() & 0xff00) != 0){		/* Protocol SET */
			if(Set.Ch1_iConnect == CH_CH1){		/* RS-232C */
/*				RsModeSet(RS_PC,*/
/*					  RS_INIT,*/
/*					  Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed,*/
/*					  Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1,*/
/*					  Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity);*/ /* 20061025ksc */
				RsModeSetChanel(RS_PC,&Set.Ch1_Serial_Param[Set.Ch1_iKind]);		/* 2009.09.04 Add Stop */
			}else{
/*				RsModeSet(RS_PLC,*/
/*					  RS_INIT,*/
/*					  Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed,*/
/*					  Set.Ch1_Serial_Param[Set.Ch1_iKind].iData1,*/
/* 					  (Set.Ch1_Serial_Param[Set.Ch1_iKind].iStop >>8 | Set.Ch1_Serial_Param[Set.Ch1_iKind].iParity));*/ /* 20061025ksc */
				RsModeSetChanel(RS_PLC,&Set.Ch1_Serial_Param[Set.Ch1_iKind]);		/* 2009.09.04 Add Stop */
			}
		}

//		ElsPlcOK= 1;		/* Els PLC Prog Info */
		param[0]= PlcType;
		param[1]= Set.iGPSta;
		param[2]= Set.iDstSta;
		param[3]= Set.Ch1_Serial_Param[Set.Ch1_iKind].iSpeed;  /* 20061025ksc */
		param[4]= Set.Ch2_iKind;  /* 20090704 */
		param[5]= CH_CH0;  /* 20100406 */
		param[6]= ((int)(unsigned char)Set.cPlcTypeCode[2] << 8)+(unsigned char)Set.cPlcTypeCode[3]; /* 20111017 */
//		param[6]= ((int)Set.cPlcTypeCode[2] << 8) + (int)Set.cPlcTypeCode[3]; /* 20111017 */
		param[7]= (int)(unsigned char)Set.cPlcTypeCode[4]; /* 20111017 */
		param[8]= (int)(unsigned char)Set.cPlcTypeCode[5]; /* 20111017 */

		ret= PLC_CONNECT(param,Set.Ch1_iConnect);
		if(ret == 0){	PlcErrorFlag= 1;	}	/* �ʐM�G��? */
		else{
			PlcType= param[0];
			PlcErrorFlag= 0;
		}
		if(ret > 0){	ret= 1;	}
		break;
	}
	if(ret == 1){	PlcKansiFlag = 0;	}	/* Kansi 1 Sicle End */
	return(ret);
}
void	ClearConnect( void )
{
	PlcConnectFlag= 0;
}
#ifdef	OLD  /* 20080822 */
/****************************************/
/*	�ėp�ʐMREAD						*/
/****************************************/
int	UniMakeAddr(char *Name,int Addr,int bFlag)
{
	int	ret;

	ret= -1;
	if((bFlag == 1) && (Name[0] == 1)){	/* D */
		if((Addr >= 0) && (Addr <= 4095)){
			ret= Addr* 2;
		}else if((Addr >= 8000) && (Addr <= 8015)){
			ret= (Addr- 8000)* 2+ 0x2100;
		}
	}else if((bFlag == 0) && (Name[0] == 1)){	/* M */
		if((Addr >= 0) && (Addr <= 2047)){
			ret= Addr/8+ 0x2000;
		}else if((Addr >= 8000) && (Addr <= 8063)){
			ret= (Addr- 8000)/ 8+ 0x2200;
		}
	}else if((bFlag == 0) && (Name[0] == 2)){ /* GB */
		if((Addr >= 0) && (Addr <= 1023)){
			ret= Addr/8;
		}
	}else if((bFlag == 1) && (Name[0] == 2)){	/* GD */
		ret= Addr;
	}
	return(ret);
}
#endif
#ifdef	OLD  /* 20080822 */
int	UniCommRead(T_MAIL *mp)
{
	int	idx;
	int	i;
	int	BitAndData;
	unsigned char	*SaveAddr;

	SaveAddr= (unsigned char *)mp->mptr;
	idx= UniMakeAddr((char *)mp->mbuf,mp->mpar,mp->mpec);
	if(idx != -1){
		if((mp->mpec == 0) && (mp->mbuf[0] == 1)){	/* M */
			BitAndData = 1;
			BitAndData = BitAndData << (mp->mpar % 8);
			for(i = 0; i < (int)mp->mext; i++){
				if((InDevArea.UB[INDEV_UN_B+idx] & BitAndData) == 0){
					*SaveAddr++ = 0;
				}else{
					*SaveAddr++ = 1;
				}
				BitAndData <<= 1;
				if(BitAndData > 128){
					BitAndData= 1;
					idx++;
				}
			}
		}else if((mp->mpec == 1) && (mp->mbuf[0] == 1)){	/* D */
			for(i = 0; i < (int)mp->mext; i++){
				*SaveAddr++= InDevArea.UB[INDEV_UN_B+idx++];
				*SaveAddr++= InDevArea.UB[INDEV_UN_B+idx++];
			}
		}else if((mp->mpec == 0) && (mp->mbuf[0] == 2)){	/* GB */
			BitAndData = 1;
			BitAndData = BitAndData << (mp->mpar % 16);
			for(i = 0; i < (int)mp->mext; i++){
				if((InDevArea.UW[idx] & BitAndData) == 0){
					*SaveAddr++ = 0;
				}else{
					*SaveAddr++ = 1;
				}
				BitAndData <<= 1;
				if(BitAndData > 0x8000){
					BitAndData= 1;
					idx++;
				}
			}
		}else if((mp->mpec == 1) && (mp->mbuf[0] == 2)){	/* GD */
			*SaveAddr++= InDevArea.UW[idx] % 256;
			*SaveAddr++= InDevArea.UW[idx] / 256;
		}else{
			return(-1);
		}
	}
	return(0);
}
#endif
#ifdef	OLD  /* 20080822 */
int	UniCommWrite(T_MAIL *mp)
{
	int	idx;
	int	i;
	int	BitAndData;
	unsigned char	*SaveAddr;

	SaveAddr= (unsigned char *)mp->mptr;
	idx= UniMakeAddr((char *)mp->mbuf,mp->mpar,mp->mpec);
	if(idx != -1){
		if((mp->mpec == 0) && (mp->mbuf[0] == 1)){	/* M */
			BitAndData = 1;
			BitAndData = BitAndData << (mp->mpar % 8);
			for(i = 0; i < (int)mp->mext; i++){
				if((*SaveAddr++ & BitAndData) == 0){
					InDevArea.UB[INDEV_UN_B+idx] &= ~BitAndData;
				}else{
					InDevArea.UB[INDEV_UN_B+idx] |= BitAndData;
				}
				BitAndData <<= 1;
				if(BitAndData > 128){
					BitAndData= 1;
					idx++;
				}
			}
		}else if((mp->mpec == 1) && (mp->mbuf[0] == 1)){	/* D */
			for(i = 0; i < (int)mp->mext; i++){
				InDevArea.UB[INDEV_UN_B+idx++]= *SaveAddr++;
				InDevArea.UB[INDEV_UN_B+idx++]= *SaveAddr++;
			}
		}else if((mp->mpec == 0) && (mp->mbuf[0] == 2)){	/* GB */
			BitAndData = 1;
			BitAndData = BitAndData << (mp->mpar % 16);
			for(i = 0; i < (int)mp->mext; i++){
				if((*SaveAddr++ & BitAndData) == 0){
					InDevArea.UW[idx] &= ~BitAndData;
				}else{
					InDevArea.UW[idx] |= BitAndData;
				}
				BitAndData <<= 1;
				if(BitAndData > 0x8000){
					BitAndData= 1;
					idx++;
				}
			}
		}else if((mp->mpec == 1) && (mp->mbuf[0] == 2)){	/* GD */
			for(i = 0; i < (int)mp->mext; i++){
				InDevArea.UW[idx]= *SaveAddr++;
				InDevArea.UW[idx++]+= (*SaveAddr++) * 256;
			}
		}else{
			return(-1);
		}
	}
	return(0);
}
#endif
/************************************************/
/*	PLC �����Ď� Proc							*/
/************************************************/
/****************************/
/* Plc State Init			*/
/****************************/
void	PlcDevInit( void )
{
	PlcKansiFlag= 0;
/*	PcThru1014Rec= 0;*/
	KansiFirst= 0;
}
void	ChangeAddressPLC16(int Digit1,int Digit0, int *Address)
{
	int		i;
	unsigned int	work;
	unsigned int	work1;
	unsigned int	work2;
	unsigned int	work3;

	work= (unsigned int)*Address;
	work3= work & 0x0f;
	work1= 0;
	work2= Digit1;
	for(i = 0;i < 7; i++){
		work= work >> 4;
		if((work & 0x0f) != 0){
			work1 += (work & 0x0f)* work2;
		}
		work2 *= Digit1;
		if(work == 0){
			break;
		}
	}
	work1= work1+ work3;
	*Address= work1;
}
int	SendPLC2RW(int mode,DEV_DATA *DevInfo,int ch)
{
	int	ret;
	T_MAIL	*mp;
	int	mbx;
	unsigned int	OldResp;

	mbx= TakeMbx();
	mp= (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mpec= DevInfo->DevFlag;
	mp->mbuf[0]= DevInfo->DevName[0];
	mp->mbuf[1]= 0;
	mp->mbuf[4]= ch;		/* Station No */
	mp->mpar= DevInfo->DevAddress;		/* Address */
	mp->mext= DevInfo->DevCnt;
	mp->mptr= DevInfo->DevData;
	if(mode == 0){		/* READ */
		mp->mcmd= PLC_READ2;
	}else{
		mp->mcmd= PLC_WRITE2;
	}
	SendMail(T_PLCHAND2,(char *)mp);
	mp= (T_MAIL *)ReceiveMail( mbx );
	ChangeMailResp( (char *)mp, OldResp );
	ret= (short)mp->mpec;
	if(ret == -1){		/* 060726 */
/*		PlcConnectFlag2= 0;*/		/* 20081007 */
		PlcConnectFlag2[ch]= 0;		/* 20081007 */
	}
	FreeMail((char *)mp);
	FreeMbx( mbx );
	return(ret);
}
/************************************************/
/* Culc Type 2 Address							*/
/*	2008.10.25									*/
/************************************************/
int	CulcPlc2Area(LINK_DEV *DevInf)
{
	int	i,cnt;
	int	StartAddr= 0;

	for(i= 0; i < MAX_PLC_LINK_DEVNO; i++){
		if(DevInf[i].ReadWrite != 0){		/* READ/WRITE FLAG */
			if(DevInf[i].DevFlag == 1){		/* BIT */
				cnt= DevInf[i].DevCnt/8;
				if(DevInf[i].DevCnt%8){
					cnt++;
				}
				if(cnt % 2){
					cnt++;
				}
				StartAddr += cnt/2;
				if(cnt % 2){
					StartAddr++;
				}
			}else{							/* Word */
				StartAddr += DevInf[i].DevCnt;
			}
		}
	}
	return(StartAddr);
}
/************************************************/
/*	Link Device Read Write Proc					*/
/************************************************/
int	LinkDevReadWrite(int mode,int *StartAddr,LINK_DEV *DevInf,char GpDevName,int ch)
{
	DEV_DATA GpDevInfo;
	DEV_DATA PlcDevInfo;
	int		i,j,k;
	char	*PlcData;
	char	*GpPlcData;
	unsigned short*	wDataAddr;	/* 20080822 Arm ������ ���, ����Ʈ ���������� ���� �������� ���� */
	int		cnt;
	int		OrData;
	int		ret;

#ifdef	WIN32
	/* 2011.11.25 by ycchoi */
	unsigned short bigEVal;
#endif

	GpDevInfo.DevName[0]= GpDevName;
	GpDevInfo.DevFlag= DEVICE_WORD;		/* Word Fix*/

	for(i= 0; i < MAX_PLC_LINK_DEVNO; i++){
		if(CommonArea.PcUpDownMode != 0){		/* 2008.09.26 */
			break;								/* 2008.09.26 */
		}										/* 2008.09.26 */
		if(DevInf[i].ReadWrite != 0){		/* READ/WRITE FLAG */
			if(DevInf[i].ReadWrite == 1){		/* PLC READ */
				if(DevInf[i].DevFlag == 1){		/* BIT */
					PlcData= TakeMemory(DevInf[i].DevCnt);
				}else{												/* WORD */
					PlcData= TakeMemory(DevInf[i].DevCnt*2);
				}
				PlcDevInfo.DevName[0]= DevInf[i].DevName;
				PlcDevInfo.DevFlag= DevInf[i].DevFlag- 1;	/* Bit/Word */
				PlcDevInfo.DevAddress= DevInf[i].DevAddr;
				PlcDevInfo.DevData= PlcData;
				PlcDevInfo.DevCnt= DevInf[i].DevCnt;	/* Read Count */
				if(mode == 0){
					ret= PLCRead(&PlcDevInfo);					/* PLC 1 READ */
				}else{
					ret= SendPLC2RW(0,&PlcDevInfo,ch);			/* PLC 2 READ */
				}
				if(ret == OK){
					if(DevInf[i].DevFlag == 1){		/* BIT */
						cnt= DevInf[i].DevCnt/8;
						if(DevInf[i].DevCnt%8){
							cnt++;
						}
						if(cnt % 2){
							cnt++;
						}
						GpPlcData= TakeMemory(cnt);
						wDataAddr= (unsigned short*)GpPlcData;
						memset(GpPlcData,0,cnt);


						/*
						// 2011.11.25 by ycchoi
						// ������ bit data�� short ������ ���� ��
						// mono model�� little-endian �������� �ֵ��� �����Ѵ�.
						// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
						// OrData = 0x0001;
						*/

#ifdef	WIN32						
						OrData = 0x0100;
#else
						OrData = 0x0001;
#endif
						k= 0;
						wDataAddr[k]= 0;
						for(j= 0; j < DevInf[i].DevCnt; j++){							
							if(PlcData[j] == 1){
								wDataAddr[k] |= OrData;
							}
							OrData = OrData << 1;




#ifdef	WIN32						
							if(OrData > 0x8000){	/* ���� byte ó���Ϸ� Ȯ�� */
								OrData = 0x0001;							
							}
							else if(j>0 && OrData== 0x0100) /* 1 word ó���Ϸ� Ȯ�� */
							{
								k++;
								wDataAddr[k]= 0;
							}
							/* <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< */
#else
							// 2011.11.25 by ycchoi
							// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
							if(OrData > 0x8000){
								OrData = 0x0001;
								k++;
								wDataAddr[k]= 0;
							}
#endif



						}



						GpDevInfo.DevData= GpPlcData;
						GpDevInfo.DevCnt= cnt/2;			/* Write Count */
						GpDevInfo.DevAddress= *StartAddr;
						ret= PLCWrite(&GpDevInfo);
						FreeMail(GpPlcData);
						*StartAddr += cnt/2;
						if(cnt % 2){
							(*StartAddr)++;
						}
					}else{												/* WORD */
						GpDevInfo.DevData= PlcData;
						GpDevInfo.DevCnt= DevInf[i].DevCnt;			/* Write Count */
						GpDevInfo.DevAddress= *StartAddr;
						ret= PLCWrite(&GpDevInfo);
						*StartAddr += DevInf[i].DevCnt;
					}
				}
				FreeMail(PlcData);
				if(ret == -1){		/* 060726 */
					break;
				}
			}else{									/* PLC WRITE */
				PlcDevInfo.DevName[0]= DevInf[i].DevName;
				PlcDevInfo.DevFlag= DevInf[i].DevFlag- 1;	/* Bit/Word */
				PlcDevInfo.DevAddress= DevInf[i].DevAddr;
				/* GP DEVICE READ */
				if(DevInf[i].DevFlag == 1){		/* BIT */
					cnt= DevInf[i].DevCnt/8;
					if(DevInf[i].DevCnt%8){
						cnt++;
					}
					if(cnt %2){
						cnt++;
					}
					GpPlcData= TakeMemory(cnt);
					GpDevInfo.DevData= GpPlcData;
					GpDevInfo.DevCnt= cnt/2;			/* Write Count */
					GpDevInfo.DevAddress= *StartAddr;
					ret= PLCRead(&GpDevInfo);
					wDataAddr= (unsigned short*)GpPlcData;
					PlcData= TakeMemory(DevInf[i].DevCnt);
					OrData = 0x0001;
					k= 0;


#ifdef	WIN32						
					// 2011.11.25 by ycchoi
					SwapShort((char*)&wDataAddr[k], (char*)&bigEVal);

#endif


					for(j= 0; j < DevInf[i].DevCnt; j++){

#ifdef	WIN32
						// 2011.11.25 by ycchoi
						if((bigEVal & OrData) == 0){
#else
						if((wDataAddr[k] & OrData) == 0){
#endif
							PlcData[j]= 0;
						}else{
							PlcData[j]= 1;
						}
						OrData = OrData << 1;
						if(OrData > 0x8000){
							OrData = 0x0001;
							k++;


#ifdef	WIN32						
							// 2011.11.25 by ycchoi
							SwapShort((char*)&wDataAddr[k], (char*)&bigEVal);
#endif

						}
					}
					PlcDevInfo.DevData= PlcData;
					PlcDevInfo.DevCnt= DevInf[i].DevCnt;	/* Read Count */
					if(mode == 0){							/* PLC 1 Write */
						ret= PLCWrite(&PlcDevInfo);
					}else{
						ret= SendPLC2RW(1,&PlcDevInfo,ch);	/* PLC 2 WRITE */
					}
					FreeMail(PlcData);
					FreeMail(GpPlcData);
					*StartAddr += cnt/2;
					if(cnt % 2){
						(*StartAddr)++;
					}
					if(ret == -1){		/* 060726 */
						break;
					}
				}else{												/* WORD */
					GpPlcData= TakeMemory(DevInf[i].DevCnt*2);
					GpDevInfo.DevData= GpPlcData;
					GpDevInfo.DevCnt= DevInf[i].DevCnt;			/* Write Count */
					GpDevInfo.DevAddress= *StartAddr;
					ret= PLCRead(&GpDevInfo);
					PlcDevInfo.DevData= GpPlcData;
					PlcDevInfo.DevCnt= DevInf[i].DevCnt;	/* Read Count */
					if(mode == 0){
						ret= PLCWrite(&PlcDevInfo);			/* PLC 1 WRITE */
					}else{
						ret= SendPLC2RW(1,&PlcDevInfo,ch);	/* PLC 2 WRITE */
					}
					FreeMail(GpPlcData);
					*StartAddr+= DevInf[i].DevCnt;
					if(ret == -1){		/* 060726 */
						break;
					}
				}
			}
		}
	}
	return(ret);
}
/************************************************/
/*	PLC Type2 Handler Proc						*/
/************************************************/
int	SendPlcType2Write( int ch,int *StartAddr )
{
	int		ret;

	/* PLC2 NOT USE */
//	if(CommonArea.PlcType2.AuxPlcUserFlag == 0){
	if(IsPlc2Protocol() == NG){	/* 2008.12.10 */
		return(0);
	}
	ret= LinkDevReadWrite(1,StartAddr,CommonArea.PlcType2.DevInf[ch],CommonArea.PlcType2.GpDevName,ch);
	return(ret);
}
void	SendPlcType1Write( void )
{
	int		StartAddr;

	/* PLC1 LINK USE FLAG */
//	if(CommonArea.PlcType1.PlcUserFlag == 0){
	if(IsPlc1Protocol() == NG){	/* 2008.12.10 */
		return;
	}
	StartAddr= CommonArea.PlcType1.GpDevAddr;
	LinkDevReadWrite(0,&StartAddr,&CommonArea.PlcType1.DevInf[0],CommonArea.PlcType1.GpDevName,0);
}
/************************************************/
/*	�Ď��e?�u����ύX�����Ƃ��ɌĂ΂��		*/
/************************************************/
void	ReadDevData(int i)
{
	int		j,idx;
	DEV_DATA	wDevData;

	if(DeviceDataSys[i].SameDevInf == -1){
		;
	}else if(DeviceDataSys[i].SameDevInf == 0){
		if(DeviceDataSys[i].Continus == 0){		/* Same DEV */
			PLCRead(&DeviceDataSys[i]);
		}else{									/* Continue DEV */
			if(DeviceDataSys[i].Patarn == 0){	/* All Continue */
				memcpy(&wDevData,&DeviceDataSys[i],sizeof(DEV_DATA));
				wDevData.DevCnt= wDevData.Continus+ wDevData.DevCnt;	/* �����̐��������Ă��Ȃ����� */
				wDevData.DevData= PlcDataReadBuff;
				if(PLCRead(&wDevData) == OK){
					idx= i;
					if(DeviceDataSys[i].DevFlag == 0){		/* Bit */
						for(j= 0; ; ){
							*DeviceDataSys[idx].DevData= PlcDataReadBuff[j];
							j++;
							idx= DeviceDataSys[idx].Order- 1;
							if(idx < 0){
								break;
							}
						}
					}else{									/* Word */
						for(j= 0; ; ){
							memcpy(DeviceDataSys[idx].DevData,&PlcDataReadBuff[j],DeviceDataSys[idx].DevCnt*2);
							j+= DeviceDataSys[idx].DevCnt* 2;
							idx= DeviceDataSys[idx].Order- 1;
							if(idx < 0){
								break;
							}
						}
					}
				}
			}else{		/* Patarn */
				memcpy(&wDevData,&DeviceDataSys[i],sizeof(DEV_DATA));
				wDevData.DevCnt= wDevData.Continus;				/*  */
				wDevData.DevData= PlcDataReadBuff;
				if(PLCRead(&wDevData) == OK){
					idx= i;
					if(DeviceDataSys[i].DevFlag == 0){		/* Bit */
						for(j= 0; ; ){
							*DeviceDataSys[idx].DevData= PlcDataReadBuff[j];
							idx= DeviceDataSys[idx].Order- 1;
							if(idx < 0){
								break;
							}
							j = DeviceDataSys[idx].Patarn- 1;
						}
					}else{									/* Word */
						for(j= 0; ; ){
							memcpy(DeviceDataSys[idx].DevData,&PlcDataReadBuff[j],DeviceDataSys[idx].DevCnt*2);
							idx= DeviceDataSys[idx].Order- 1;
							if(idx < 0){
								break;
							}
							j = DeviceDataSys[idx].Patarn* 2;
						}
					}
				}
			}
		}
	}else{
		if(DeviceDataSys[i].SameDevInf == 1){
			if(DeviceDataSys[i].DevFlag == 0){	/* ����Bit */
				for(j= 0; j < DeviceDataSys[i].DevCnt; j++){
					*(DeviceDataSys[i].DevData+ j) = *(DeviceDataSys[DeviceDataSys[i].Order- 1].DevData+ j);
				}
			}else{								/* ����Word */
				for(j= 0; j < DeviceDataSys[i].DevCnt*2; j++){
					*(DeviceDataSys[i].DevData+ j) = *(DeviceDataSys[DeviceDataSys[i].Order- 1].DevData+ j);
				}
			}
		}
	}
}
/* UW Device Write�� ������ �Ͼ���� ���� */
/* UW Device Read   LP���� ��������̽����� ��� �� ȭ�� ǥ�ÿ� ����̽��� Read */
void	UW_AllReadProc(int mode)
{
	int		i;
	int		signal;

	for(i = 0; i < DeviceCntSys; i++){
		signal = ReadSignal(SGN_PLC);	/* */
		if(mode == 0){					// Initial Read
			PLCIndevDirectRead(&DeviceDataSys[i]);
		}else{
			if((signal & 0x0001) == 0){		break;			}
			if(BaseChangeFlag != 0){		break;			}		/* Base Change Flag */
			if(((unsigned char)DeviceDataSys[i].DevName[0] == 0x7f) ||	//UW Device
				((unsigned char)DeviceDataSys[i].DevName[0] == 0xef)){
				PLCIndevDirectRead(&DeviceDataSys[i]);
			}
		}
	}
}
void	UW_AllRead(int mode)
{
#ifdef	LP_S044
	T_MAIL*	mp;
	int	mbx;
	unsigned int	OldResp;

	if(GetStopInf() == 0){
		mbx= TakeMbx();
		mp= (T_MAIL*)TakeMail();
		OldResp = ChangeMailResp( (char *)mp, mbx );
		mp->mcmd= UW_READ_ALL;
		mp->mcod= mode;
		SendMail(T_PLCMAIN,(char *)mp);
		mp= (T_MAIL *)ReceiveMail( mbx );
		ChangeMailResp( (char *)mp, OldResp );
		FreeMail((char*)mp);
		FreeMbx( mbx );
	}else{
		UW_AllReadProc(mode);
	}
#endif
#ifdef	GP_S057
	UW_AllReadProc(mode);
#endif
#ifdef	GP_S044
	UW_AllReadProc(mode);
#endif
}
/************************************************/
/*	�Ď��e?�u����ύX�����Ƃ��ɌĂ΂��		*/
/************************************************/
void	PlcDevInitRead( int mode )
{
	int		i,j;

	if(PlcConnectFlag == 1){			/* Connect OK */
		if(mode == 0){
/* 20081002 */
			if(PlcGroopSend(PLC_GR_MAK) != 0){	return;	}
		}
/* 20081002 */
		if(PlcGroopSend(PLC_GROOP) != 0){		return;	}
		//UW Read
		UW_AllRead(0);
		for(i = 0; i < DeviceCntSys; i++){
			if(((unsigned char)DeviceDataSys[i].DevName[0] != 0x7f) &&
				((unsigned char)DeviceDataSys[i].DevName[0] != 0xef)){
				ReadDevData(i);
			}
		}
	}else{
		PlcKansiFlag= 0;
		KansiFirst= 0;
		//UW Read
		UW_AllRead(0);
		for(i = 0; i < DeviceCntSys; i++){
			if(DeviceDataSys[i].SameDevInf == -1){
				;
			}else if(DeviceDataSys[i].SameDevInf == 0){
//				if(((unsigned char)DeviceDataSys[i].DevName[0] == 0x7f) ||
//					((unsigned char)DeviceDataSys[i].DevName[0] == 0xef)){
//					ReadDevData(i);
//				}
			}else{
				if(DeviceDataSys[i].SameDevInf == 1){
					if(DeviceDataSys[i].DevFlag == 0){	/* ����Bit */
						*DeviceDataSys[i].DevData = *DeviceDataSys[DeviceDataSys[i].Order- 1].DevData;
					}else{								/* ����Word */
						for(j= 0; j < DeviceDataSys[i].DevCnt*2; j++){
							*(DeviceDataSys[i].DevData+ j) = *(DeviceDataSys[DeviceDataSys[i].Order- 1].DevData+ j);
						}
					}
				}
			}
		}
	}
}
/************************************************/
void	IndevReadProc(T_MAIL *mp)
{
	int		i,j;
	unsigned char	*SaveAddr;
	int		InAddr;
	int		wCnt;
	int		BitAndData;
	unsigned short*	ReadWU;

	InAddr= mp->mpar;
	SaveAddr = (unsigned char *)mp->mptr;
	if(mp->mpec == PLC_BIT){
		BitAndData = 1;
		//061124
		wCnt = InAddr % 16;
		for(j = 0; j < wCnt; j++){
			BitAndData <<= 1;
		}
		ReadWU= &InDevArea.UW[InAddr/16];
		for(i = 0,j = InAddr/16; i < (signed)mp->mext; i++){
			if(j < MAX_UW_WORD){
				if(*ReadWU & BitAndData){
					*(unsigned char *)SaveAddr++ = 1;
				}else{
					*(unsigned char *)SaveAddr++ = 0;
				}
				BitAndData <<= 1;
				if(BitAndData > 0x8000){
					BitAndData = 1;
					j++;
					ReadWU++;
				}
			}
		}
	}else{		/* WORD */
		ReadWU= &InDevArea.UW[InAddr];
		for(i= 0,j= InAddr; i < (signed)mp->mext; i++, j++, ReadWU++){
			if(j < MAX_UW_WORD){
				*SaveAddr++ = (char)(*ReadWU / 256);	//High
				*SaveAddr++ = (char)(*ReadWU % 256);	//Low
			}
		}
	}
}
void	IndevRead(T_MAIL *mp)
{
#ifdef	LP_S044		/* 20080822 PLC SCAN �Ϸ��� ���� ����̽� �е��� ó�� */
	int	mbx;
	unsigned int	OldResp;

	if(GetStopInf() == 0){
		mbx= TakeMbx();
		OldResp = ChangeMailResp( (char *)mp, mbx );
		mp->mcmd= UW_READ;
		SendMail(T_PLCMAIN,(char *)mp);
		mp= (T_MAIL *)ReceiveMail( mbx );
		ChangeMailResp( (char *)mp, OldResp );
		FreeMbx( mbx );
	}else{	//PLC STOP 
		IndevReadProc(mp);
	}
#endif
#ifdef	GP_S057
	IndevReadProc(mp);
#endif
#ifdef	GP_S044
	IndevReadProc(mp);
#endif
}
void	IndevWriteProc(T_MAIL *mp)
{
	int		i,j;
	unsigned char	*SaveAddr;
	int		InAddr;
	unsigned short*	WriteWU;
	int		loop;				//2011.12.08

	InAddr= mp->mpar;

	SaveAddr= (unsigned char *)mp->mptr;
	if(mp->mpec == PLC_BIT){
		i= InAddr / 16;
		if(i < MAX_UW_WORD){
			j= 0x01 << (InAddr % 16);
			if(i < 15){	return;	}	/* Except PLC Write Area */		//2011.12.08
			for(loop= 0; loop < (int)mp->mext; loop++){		//2011.12.08
				if(*SaveAddr == 0){
					InDevArea.UW[i] &= ~j;
				}else{
					InDevArea.UW[i] |= j;
				}
				SaveAddr++;								//2011.12.08
				j <<= 1;								//2011.12.08
				if(j > 0x8000){							//2011.12.08
					j= 1;								//2011.12.08
					i++;								//2011.12.08
				}										//2011.12.08
			}
		}
	}else{
		WriteWU= &InDevArea.UW[InAddr];
		for(i= 0,j= InAddr; i < (signed)mp->mext; i++,WriteWU++,j++){
			if(j < MAX_UW_WORD){
				if(j < 15){		/* Write Area */
					continue;
				}
				*WriteWU = (*SaveAddr << 8);		//High
				SaveAddr++;
				*WriteWU += *SaveAddr;			//Low
				SaveAddr++;
			}
		}
	}
}
void	IndevWrite(T_MAIL *mp)
{
#ifdef	LP_S044
	int	mbx;
	unsigned int	OldResp;

	if(GetStopInf() == 0){
		mbx= TakeMbx();
		OldResp = ChangeMailResp( (char *)mp, mbx );
		mp->mcmd= UW_WRITE;
		SendMail(T_PLCMAIN,(char *)mp);
		mp= (T_MAIL *)ReceiveMail( mbx );
		ChangeMailResp( (char *)mp, OldResp );
		FreeMbx( mbx );
	}else{
		IndevWriteProc(mp);
	}
#endif
#ifdef	GP_S057
	IndevWriteProc(mp);
#endif
#ifdef	GP_S044
	IndevWriteProc(mp);
#endif
}
/************************************/
/*	Device & Address Change			*/
/************************************/
int	GetDevAddInf(int bwflag,unsigned char *src,int *Keta,int *LowMax)
{
	int		ret;
	DEV_PC_TBL	*ByteTbl;
	DEV_PC_TBL	*WordTbl;
	unsigned char *PLCIndex;

	switch(Set.Ch1_iKind)
	{
	case UNIVERSAL:
		ByteTbl= (DEV_PC_TBL *)&U_K3P_SereaseByte[0];
		WordTbl= (DEV_PC_TBL *)&U_K3P_SereaseWord[0];
		PLCIndex= (unsigned char *)&U_IndexTable[0];
		break;
	case DEFAULT_PLC:
		ByteTbl= (DEV_PC_TBL *)&K3P_SereaseByte[0];
		WordTbl= (DEV_PC_TBL *)&K3P_SereaseWord[0];
		PLCIndex= (unsigned char *)&IndexTable[0];
		break;
	case ELSE_PLC:
		if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
#ifdef	WIN32
			ByteTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0200];
			WordTbl= (DEV_PC_TBL *)&GpFont[PLC1_DEV_TABLE+0x0A00];
			PLCIndex= (unsigned char *)&GpFont[PLC1_DEV_TABLE+0x0100];
#else
			ByteTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0200);
			WordTbl= (DEV_PC_TBL *)(PLC1_DEV_TABLE+0x0A00);
			PLCIndex= (unsigned char *)(PLC1_DEV_TABLE+0x0100);
#endif
		}else{
			/* Univaersal */
			ByteTbl= (DEV_PC_TBL *)&U_K3P_SereaseByte[0];
			WordTbl= (DEV_PC_TBL *)&U_K3P_SereaseWord[0];
			PLCIndex= (unsigned char *)&U_IndexTable[0];
		}
		break;
	default:		//20080903	PLC���ڑ�
		ByteTbl= (DEV_PC_TBL *)&U_K3P_SereaseByte[0];
		WordTbl= (DEV_PC_TBL *)&U_K3P_SereaseWord[0];
		PLCIndex= (unsigned char *)&U_IndexTable[0];
		break;
	}
	ret= -1;
	if(bwflag == 0){	/* Bit */
		if(PLCIndex[src[0]] != 0xff){
			*Keta= ByteTbl[PLCIndex[src[0]]].LowKeta;
			*LowMax= ByteTbl[PLCIndex[src[0]]].LowDeviceMax;
			ret= 0;
		}
	}else{
		if(PLCIndex[src[0]] != 0xff){
			*Keta= WordTbl[PLCIndex[src[0]]].LowKeta;
			*LowMax= WordTbl[PLCIndex[src[0]]].LowDeviceMax;
			ret= 0;
		}
	}
	return(ret);
}
void	ChangeAddressPLC(int Digit1,int Digit0,int *Address,int LowMax,int Keta)
{
	int		i;
	unsigned int	work;
	unsigned int	work1;
	unsigned int	work2;
	unsigned int	work3;

	work= (unsigned int)*Address;
	work3= 0;
	work2= 1;
	for(i= 0; i < Keta; i++){
		if((work & 0x0f) != 0){
			work3 += (work & 0x0f)* work2;
		}
		work= work >> 4;
		work2 *= Digit0;
	}
	work1= 0;
	work2= 1;
	for(;i < 8; i++){
		if((work & 0x0f) != 0){
			work1 += (work & 0x0f)* work2;
		}
		work2 *= Digit1;
		work= work >> 4;
		if(work == 0){
			break;
		}
	}
	work1= (work1*LowMax)+ work3;
	*Address= work1;
}
int	GetDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int *Address)
{
	int		ret;
	int		Keta;
	int		LowMax;

	ret= GetDevName(bFlag,(char *)src,obj,DevInfo);
	if(ret == 0){
		ret= GetDevAddInf(bFlag,src,&Keta,&LowMax);
		if(ret == 0){
			LowMax++;
			switch(*DevInfo & 0x0f){
			case 0:		/* 8/8 */
				ChangeAddressPLC(8,8,Address,LowMax,Keta);
				break;
			case 1:		/* 8/10 */
				ChangeAddressPLC(8,10,Address,LowMax,Keta);
				break;
			case 2:		/* 8/16 */
				ChangeAddressPLC(8,16,Address,LowMax,Keta);
				break;
			case 3:		/* 10/8 */
				ChangeAddressPLC(10,8,Address,LowMax,Keta);
				break;
			case 4:		/* 10/10 */
				ChangeAddressPLC(10,10,Address,LowMax,Keta);
				break;
			case 5:		/* 10/16 */
				ChangeAddressPLC(10,16,Address,LowMax,Keta);
				break;
			case 6:		/* 16/8 */
				ChangeAddressPLC(16,8,Address,LowMax,Keta);
				break;
			case 7:		/* 16/10 */
				ChangeAddressPLC(16,10,Address,LowMax,Keta);
				break;
			case 8:		/* 16/16 */
	/*			ChangeAddressPLC(16,16,Address);*/
				break;
			case 9:		/* 16 */
				ChangeAddressPLC(10,10,Address,10,1);
				break;
			}
		}
	}
	return(ret);
}
int	GetLowAddressPLC(int Digit0,int Address,int Keta)
{
	int		i;
	unsigned int	work;
	unsigned int	work2;
	unsigned int	work3;

	work= Address;
	work3= 0;
	work2= 1;
	for(i= 0; i < Keta; i++){
		if((work & 0x0f) != 0){
			work3 += (work & 0x0f)* work2;
		}
		work= work >> 4;
		work2 *= Digit0;
	}
	return(work3);
}
int	CheckDevNamePLCAddr(int bFlag,unsigned char *src,char *obj,int *DevInfo,int Address)
{
	int		ret;
	int		Keta;
	int		LowMax;

	ret= GetDevName(bFlag,(char *)src,obj,DevInfo);
	if(ret == 0){
		ret= GetDevAddInf(bFlag,src,&Keta,&LowMax);
		if(ret == 0){
			LowMax++;
			switch(*DevInfo & 0x0f){
			case 0:		/* 8/8 */
				ret= GetLowAddressPLC(8,Address,Keta);
				break;
			case 1:		/* 8/10 */
				ret= GetLowAddressPLC(10,Address,Keta);
				break;
			case 2:		/* 8/16 */
				ret= GetLowAddressPLC(16,Address,Keta);
				break;
			case 3:		/* 10/8 */
				ret= GetLowAddressPLC(8,Address,Keta);
				break;
			case 4:		/* 10/10 */
				ret= GetLowAddressPLC(10,Address,Keta);
				break;
			case 5:		/* 10/16 */
				ret= GetLowAddressPLC(16,Address,Keta);
				break;
			case 6:		/* 16/8 */
				ret= GetLowAddressPLC(8,Address,Keta);
				break;
			case 7:		/* 16/10 */
				ret= GetLowAddressPLC(10,Address,Keta);
				break;
			case 8:		/* 16/16 */
				ret= GetLowAddressPLC(16,Address,Keta);
				break;
			case 9:		/* 16 */
				ret= GetLowAddressPLC(10,Address,1);
				break;
			}
			if(ret < LowMax){
				ret= 0;
			}else{
				ret= -1;
			}
		}
	}
	return(ret);
}
void	ChangeAddressUsr(int Digit1,int Digit0, int *Address,int LowMax,int Keta)
{
	int		i;
	unsigned int	work;
	unsigned int	work1;
	unsigned int	work2;

	work= (unsigned int)*Address;
	work1= work%LowMax;				/* 1Keta */
	work2= 0;
	for(i = 0;i < Keta; i++){
		work2 += (work1 % Digit0) << (i*4);
		work1= work1/Digit0;
	}
	work= work/LowMax;
	for(;i < 8; i++){
		if(work == 0){
			break;
		}
		work2 += (work % Digit1) << (i*4);
		work= work/Digit1;
	}
	*Address= work2;
}
/*********************************************************************/
int	SetPLCUsrAddr(int DevInfo,int Address,unsigned char idx,int bFlag)
{
	int		ret;
	int		LowMax;
	int		Keta;

	ret= GetDevAddInf(bFlag,&idx,&Keta,&LowMax);
	if(ret == 0){
		LowMax++;
		ret= Address;
		switch(DevInfo & 0x0f){
		case 0:		/* 8/8 */
			ChangeAddressUsr(8,8,&ret,LowMax,Keta);
			break;
		case 1:		/* 8/10 */
			ChangeAddressUsr(8,10,&ret,LowMax,Keta);
			break;
		case 2:		/* 8/16 */
			ChangeAddressUsr(8,16,&ret,LowMax,Keta);
			break;
		case 3:		/* 10/8 */
			ChangeAddressUsr(10,8,&ret,LowMax,Keta);
			break;
		case 4:		/* 10/10 */
			ChangeAddressUsr(10,10,&ret,LowMax,Keta);
			break;
		case 5:		/* 10/16 */
			ChangeAddressUsr(10,16,&ret,LowMax,Keta);
			break;
		case 6:		/* 16/8 */
			ChangeAddressUsr(16,8,&ret,LowMax,Keta);
			break;
		case 7:		/* 16/10 */
			ChangeAddressUsr(16,10,&ret,LowMax,Keta);
			break;
		case 8:		/* 16/16 */
/*			ChangeAddressUsr(16,16,&ret,LowMax,Keta);*/
			break;
		case 9:		/* 16 */
			ChangeAddressUsr(10,10,&ret,10,1);
			break;
		}
	}
	return(ret);
}
/************************************************/
/*	C,T Device Get								*/
/************************************************/
int	GetDevCntTime(int bwFlag,char *src, char *obj)
{
	int	address1;
	int	ret;

	ret= -1;
	switch(Set.Ch1_iKind){
	case UNIVERSAL:				/* �ėp�ʐM */
		break;
	case DEFAULT_PLC:
		ret= CheckDevice_Addr(bwFlag,src,(unsigned int*)&address1,(unsigned int*)&PlcType);
		obj[0]= (char)address1;
		break;
	case ELSE_PLC:			/* ���̑�PLC */
//		if(ElsPlcOK == 1){
		if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
			ret= CHECK_PLC_ADDR(bwFlag,src,&address1,&PlcType);
			obj[0]= (char)address1;
		}
		break;
	}
	return(ret);
}
int	GetSendRecTimePlc1(void)
{
	int		ret;

	switch(Set.Ch1_iKind){
	case UNIVERSAL:				/* �ėp�ʐM */
		ret= 0;
		break;
	case DEFAULT_PLC:
		ret= 0;
		break;
	case ELSE_PLC:			/* ���̑�PLC */
//		if(ElsPlcOK == 1){
		if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
			ret= GET_SEND_REC_TIME();
		}
		break;
	}
	return(ret);
}
int	GetSendRecTimePlc2(void)
{
	int		ret;

	switch(Set.Ch1_iKind){
	case UNIVERSAL:				/* �ėp�ʐM */
		ret= 0;
		break;
	case DEFAULT_PLC:
		ret= 0;
		break;
	case ELSE_PLC:			/* ���̑�PLC */
//		if(ElsPlcOK == 1){
		if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
			ret= GET_SEND_REC_TIME2();
		}
		break;
	}
	return(ret);
}
/************************************************/
/*	PLC Handler TASK							*/
/*	IN:T_MAIL *mp								*/
/*			  mp->mcd:PLC_CNTL					*/
/*					  PLC_READ					*/
/*					  PLC_WRITE					*/
/*					  PLC_THRUE					*/
/*					  PLC_GROOP					*/
/*					  PLC_GR_MAK				*/
/************************************************/
void	PlcHand( STTFrm* pSTT )
{
	T_MAIL	*mp;
	int		i;		/* 2008.05.23 */
	T_MAIL *recv;

//	int		ret;
/*char	dbuff[32];*/
#ifndef	WIN32
	Comm0RecMode = 0;
/*	PlcCommCnt = 0;*/
	PlcErrorFlag= 0;
	PlcType= 0;
/*	ElsPlcOK= 0; 061024 */		/* Els PLC Prog Info */
#endif
/* for Test */
/*	SetWindowNo(SCREEN_0);*/
/* 2009.05.23 Add*/
    PlcFreeMbx = TakeMbx();
    for( i=0; i<10; i++ ) {
        recv= (T_MAIL *)TakeMail();
        ChangeMailResp( (char*)recv, PlcFreeMbx );
        SendMail( PlcFreeMbx, (char*)recv );
    }
/* 2009.05.23 End */

	while(1){
		PlchandTask= 0;
		mp = (T_MAIL *)WaitRequest();
/*sprintf(dbuff,"%02d",mp->mcmd);*/
/*Sio1SendChar(dbuff[0]);*/
/*Sio1SendChar(dbuff[1]);*/
/*
sprintf(dbuff,"PHAND=%02d,%03d",mp->mcmd,_Mbx[240].MailCount);
DotTextOut(0, 48,dbuff,1,1,T_REPLACE,3,0);
DrawLcdBank1();
*/
/*NormalBuzzer();*/

		if(DModeFlag == 0){
//			ret = -1;
			switch(mp->mcmd){
			case PLC_CNTL:		/* Control */
				mp->mpec = PlcControl(mp);
				break;
			case PLC_READ:			/* Read */
				if((mp->mbuf[0] == 0x01) || (mp->mbuf[0] == 0x00)){		/* ?? DEVICE == OK */
					mp->mpec= 0; 
					break;
				}
				if( (PlcConnectFlag != 0) ||
					((mp->mbuf[0] == 0x7f) || (mp->mbuf[0] == 0xef)) ){
					/* �����f�o�C�X�iGD,GB) */
					if((mp->mbuf[0] == 0x7f) || (mp->mbuf[0] == 0xef)){
#ifdef	LP_S044
						if(ChangeUWAddr(mp->mpec,&mp->mpar) == OK){		//Change UW address
							IndevRead(mp);
							mp->mpec= 0;
						}else{	mp->mpec= (unsigned short)-1;	}
#endif
#ifdef	GP_S057
						IndevRead(mp);
						mp->mpec= 0;
#endif
#ifdef	GP_S044
						IndevRead(mp);
						mp->mpec= 0;
#endif
					}else{
						switch(Set.Ch1_iKind){
#ifdef	OLD		/*20080822 ���� ���������� �������� ��쿡 ����ϴ� ������. */
						case UNIVERSAL:				/* �ėp�ʐM */
							mp->mpec= UniCommRead(mp);
							break;
#endif
						case DEFAULT_PLC:				/* FX Siriase */
							mp->mbuf[4]= (unsigned char)Set.iDstSta;		/* Dst Station No */
							mp->mpec= LG_PLCCommRead(mp,rDataFx,PlcType);
							break;
						case ELSE_PLC:			/* ���̑�PLC */
//							if(ElsPlcOK == 1){
							if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
								PlchandTask= 1;
								mp->mbuf[4]= (unsigned char)Set.iDstSta;		/* Dst Station No */
								mp->mpec= PLC_DEV_READ(mp,rDataFx,PlcType);
							}
							break;
						}
					}
				}else{
/* 20080822 mp->mpec�� (unsigned short)�̹Ƿ� -1�� ������ 0xffff�� �ν��ϵ��� �ϱ� ���ؼ� LP�� Arm �����Ϸ����� ���� �߻� */
					mp->mpec= (unsigned short)-1;
				}
				break;
			case PLC_WRITE:			/* Write */
				if((mp->mbuf[0] == 0x01) || (mp->mbuf[0] == 0x00)){		/* ?? DEVICE == OK */
					mp->mpec= 0;
					break;
				}
				if( (PlcConnectFlag != 0) ||
					((mp->mbuf[0] == 0x7f) || (mp->mbuf[0] == 0xef)) ){		
					/* �����f�o�C�X�iGD,GB) */
					if((mp->mbuf[0] == 0x7f) || (mp->mbuf[0] == 0xef)){
#ifdef	LP_S044
						if(ChangeUWAddr(mp->mpec,&mp->mpar) == OK){		//Change UW address
							IndevWrite(mp);
							mp->mpec= 0;
						}else{	mp->mpec= (unsigned short)-1;	}
#endif
#ifdef	GP_S057
						IndevWrite(mp);
						mp->mpec= 0;
#endif
#ifdef	GP_S044
						IndevWrite(mp);
						mp->mpec= 0;
#endif
					}else{
						switch(Set.Ch1_iKind){
#ifdef	OLD		/*20080822 */
						case UNIVERSAL:				/* �ėp�ʐM */
							mp->mpec= UniCommWrite(mp);
							break;
#endif
						case DEFAULT_PLC:
							mp->mbuf[4]= (unsigned char)Set.iDstSta;		/* Dst Station No */
							mp->mpec= LG_PLCCommWrite(mp,rDataFx,PlcType);
							break;
						case ELSE_PLC:			/* ���̑�PLC */
//							if(ElsPlcOK == 1){
							if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
								PlchandTask= 1;
								mp->mbuf[4]= (unsigned char)Set.iDstSta;		/* Dst Station No */
								mp->mpec= PLC_DEV_WRITE(mp,rDataFx,PlcType);
							}
							break;
						}
					}

				
				}else{
					mp->mpec= (unsigned short)-1;
				}		

				break;
			case PLC_THRUE:		/* Thrue */
				if(PlcConnectFlag != 0){
					PlchandTask= 1;
					mp->mpec = SendThruePLC(2,mp->mpar,(char *)mp->mptr,3000);
				}else{
					mp->mpec= (unsigned short)-1;
				}
				break;
			case PLC_GROOP:		/* Groop Read */
				PlchandTask= 1;
/* 20081002 */
				if(PlcConnectFlag != 0){
					mp->mpec= RecGroupDev();
/* 20081002 */
				}else{
/* 20081002 */
					mp->mpec= (unsigned short)-1;
/* 20081002 */
				}
				break;
			case PLC_GR_MAK:
				PlchandTask= 1;
				if(PlcConnectFlag != 0){
					mp->mpec= MakeGroupDev();
				}else{
					mp->mpec= (unsigned short)-1;
				}
				break;
			case PLC_THRUE_PLC:		/* Thrue */
				switch(Set.Ch1_iKind){
				case UNIVERSAL:
					break;
				case DEFAULT_PLC:				/* FX Serease */
					LG_PLCFxThruProc((char *)CommBuff,(int *)&RecCommCnt,(char *)PlcThrueBuff,(int *)&PlcThrueCnt,PlcConnectFlag,PlcType);
					break;
				case ELSE_PLC:
//					if(ElsPlcOK == 1){
					if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
						PlchandTask= 1;
						PLC_THRU_PROC((char *)CommBuff,(int *)&RecCommCnt,(char *)PlcThrueBuff,(int *)&PlcThrueCnt,PlcConnectFlag,PlcType);
					}
					break;
				}
				break;
			case PLC_MONIT_OFF:		/*  */
/*				PcThru1014= 0;*/
				PlchandTask= 1;
				mp->mpec= MakeGroupDev();
				mp->mpec= RecGroupDev();
				break;
/*******************************************************************/
/*			case PLC_READ2:*/
/*				PlchandTask= 1;*/
/*				mp->mpec= PLC_DEV_READ2(mp,(unsigned char *)rDataPlc2,PlcType2Flag);*/
/*				break;*/
/*			case PLC_WRITE2:*/
/*				PlchandTask= 1;*/
/*				mp->mpec= PLC_DEV_WRITE2(mp,(unsigned char *)rDataPlc2,PlcType2Flag);*/
/*				break;*/
			case PLC_CON:
				PlchandTask= 1;
				mp->mpec= PlcConnectProc();
				break;
			}
		}
/*
sprintf(dbuff,"PHAND=00,000",mp->mcmd);
DotTextOut(0, 48,dbuff,1,1,T_REPLACE,3,0);
DrawLcdBank1();
*/
/*Sio1SendChar('E');*/
		ResponseMail((char *)mp);
	}
}
/* PLC2 Chanel No */
int	GetPlc2ChanelNo(int ch)
{
	int	i,j;
	int	ret;

	ret= -1;
	for(i= ch; i < MAX_PLC_LINK_ST_NO; i++)
	{
		for(j= 0; j < MAX_PLC_LINK_DEVNO; j++){
			if(CommonArea.PlcType2.DevInf[i][j].ReadWrite != 0){
				ret= i;
				break;
			}
		}
		if(ret != -1){
			break;
		}
	}
	return(ret);
}
/************************************************/
/*	PLC1 STATE TASK								*/
/************************************************/
void	PlcState( STTFrm* pSTT )
{
	int		signal;
	int		i,j;
	unsigned	NewRec;
	int		flag;
/*	int		Plc2Cnt;*/
/*	int		ret;	20081007 */
/*	int		Plc2Chanel;*/
	int		StartAddr;
	int		sStartAddr;		/* Save StartAddr 20081025 */
	int		NoPlc2;

	PlcKansiFlag= 0;
	PlcKansiOkFlag= 0;
	KansiFirst= 0;
	PlcConnectFlag= 0;
/*	Plc2Cnt= 0;*/
	Plc2ChanelNo= 0;

	while(1){
		PlcstateTask= 0;
		if(CommonArea.PcUpDownMode != 0){		/* 060628 */
			Delay(100);
			continue;
		}
		if(PlcConnectFlag == 1){			/* Connect OK */
			if(KansiFirst == 0){
				KansiFirst= 1;
				PlcKansiFlag= 0;
			}
			signal = ReadSignal(SGN_PLC);	/* */
			if((signal & 0x0001) != 0){		/* */
				PlcstateTask= 1;
				NewRec= _TimeMSec;
				flag= 0;
				if(PlcKansiFlag == 0){		/* �Ď��X??�g */
/* 20081002 */
					if(PlcGroopSend(PLC_GR_MAK) != 0){
						continue;
					}
					if(PlcGroopSend(PLC_GROOP) != 0){
						continue;
					}
					flag= 1;
				}
/* 20081002 */
				if(PlcGroopSend(PLC_GROOP) != 0){
					continue;
				}
				//UW Read
				UW_AllRead(1);
				//Else Dev Read
				for(i = 0; i < DeviceCntSys; i++){
					signal = ReadSignal(SGN_PLC);	/* */
					if((signal & 0x0001) != 0){		/* */
						if(BaseChangeFlag == 0){		/* 040815 */
							if((PlcKansiFlag == 0) && (flag == 0)){
								break;
							}
							if(((unsigned char)DeviceDataSys[i].DevName[0] != 0x7f) &&
								((unsigned char)DeviceDataSys[i].DevName[0] != 0xef)){
								ReadDevData(i);
							}
						}else{
							break;
						}

					}
				}
				if(flag == 1){
					PlcKansiFlag = 1;	/* Kansi 1 Sicle End */
				}
				PlcKansiOkFlag= 1;	/* Kansi Start(First) */
/********************************************************************/
/*		PLC2 Read/Write												*/
/********************************************************************/
/*				ret= Plc2Cnt % 2;*/
//				switch(ret){
//				case 0:
					/* PLC1 READ/WRITE */
					if(PlcConnectFlag == 1){			/* Connect OK */
						SendPlcType1Write();
					}
//					break;
//				case 1:
					/* PLC2 READ/WRITE */
//				if(CommonArea.PlcType2.AuxPlcUserFlag != 0){		/* 20081007 */
				if(IsPlc2Protocol() == OK){	/* 2008.12.10 */
/*					if(PlcConnectFlag2 == 1){	*/					/* 20081007 */
						NoPlc2= 0;
						if(Plc2ChanelNo == 0){
							StartAddr= CommonArea.PlcType2.GpDevAddr;
							if((Plc2ChanelNo= GetPlc2ChanelNo(Plc2ChanelNo)) == -1){
								NoPlc2= 1;
							}
						}else{
							if((Plc2ChanelNo= GetPlc2ChanelNo(Plc2ChanelNo)) == -1){
								Plc2ChanelNo= 0;
								StartAddr= CommonArea.PlcType2.GpDevAddr;
								if((Plc2ChanelNo= GetPlc2ChanelNo(Plc2ChanelNo)) == -1){
									NoPlc2= 1;
								}
							}
						}
						if(NoPlc2 == 0){
							sStartAddr= StartAddr;															/* 20081025 */
							if(PlcConnectFlag2[Plc2ChanelNo] == 1){	/* Connect OK */						/* 20081007 */
								SendPlcType2Write(Plc2ChanelNo,&StartAddr);									/* 20081007 */
							}
							StartAddr= sStartAddr+ CulcPlc2Area(CommonArea.PlcType2.DevInf[Plc2ChanelNo]);	/* 20081025 */
							Plc2ChanelNo++;
							Plc2ChanelNo= Plc2ChanelNo % MAX_PLC_LINK_ST_NO;
						}
				}																	/* 20081007 */
//					break;
//				}
/*				Plc2Cnt++;*/
/********************************************************************/
				if((NewRec+ 50) > _TimeMSec){
					Delay((NewRec+ 50) - _TimeMSec);
				}else{
					Delay(20);
				}
			}else{
/*				PlcKansiFlag= 0;*/
				Delay(100);		/* 10ms(00.09.13) */
			}
		}else{
/*			KansiFirst= 0;*/
			signal = ReadSignal(SGN_PLC);	/* */
/*			if((signal & 0x0001) != 0){	*/											/* 2008.09.26 */
			if(((signal & 0x0001) != 0) && (CommonArea.PcUpDownMode == 0)){			/* 2008.09.26 */
				PlcstateTask= 1;													/* 2008.09.26 */
				//UW Read
				UW_AllRead(1);
				for(i = 0; i < DeviceCntSys; i++){
					if(DeviceDataSys[i].SameDevInf == -1){
						;
					}else if(DeviceDataSys[i].SameDevInf == 0){
/* 20080822 PLC ������� �ʾ������ ���� ����̽��� ����ϹǷ� UW_AllRead �� �о� �Ա� ������ �ٽ� ���� ���� */
//						if(((unsigned char)DeviceDataSys[i].DevName[0] == 0x7f) ||
//							((unsigned char)DeviceDataSys[i].DevName[0] == 0xef)){
//							PLCRead(&DeviceDataSys[i]);
//						}
					}else{
						if(DeviceDataSys[i].SameDevInf == 1){
							if(DeviceDataSys[i].DevFlag == 0){	/* ����Bit */
								*DeviceDataSys[i].DevData = *DeviceDataSys[DeviceDataSys[i].Order- 1].DevData;
							}else{								/* ����Word */
								for(j= 0; j < DeviceDataSys[i].DevCnt*2; j++){
									*(DeviceDataSys[i].DevData+ j) = *(DeviceDataSys[DeviceDataSys[i].Order- 1].DevData+ j);
								}
							}
						}
					}
				}
/********************************************************************/
/*		PLC2 Read/Write												*/
/********************************************************************/
/*				ret= Plc2Cnt % 4;*/
/*				switch(ret){*/
/*				case 0:*/
					/* PLC1 READ/WRITE */
					if(PlcConnectFlag == 1){			/* Connect OK */
						SendPlcType1Write();
					}
/*					break;*/
/*				case 1:*/
					/* PLC2 READ/WRITE */
/*					if(PlcConnectFlag2 == 1){*/
//					if(CommonArea.PlcType2.AuxPlcUserFlag != 0){		/* 20081007 */
					if(IsPlc2Protocol() == OK){	/* 2008.12.10 */
						NoPlc2= 0;
						if(Plc2ChanelNo == 0){
							StartAddr= CommonArea.PlcType2.GpDevAddr;
							if((Plc2ChanelNo= GetPlc2ChanelNo(Plc2ChanelNo)) == -1){
								NoPlc2= 1;
							}
						}else{
							if((Plc2ChanelNo= GetPlc2ChanelNo(Plc2ChanelNo)) == -1){
								Plc2ChanelNo= 0;
								StartAddr= CommonArea.PlcType2.GpDevAddr;
								if((Plc2ChanelNo= GetPlc2ChanelNo(Plc2ChanelNo)) == -1){
									NoPlc2= 1;
								}
							}
						}
						if(NoPlc2 == 0){
							sStartAddr= StartAddr;															/* 20081025 */
							if(PlcConnectFlag2[Plc2ChanelNo] == 1){	/* Connect OK */						/* 20081007 */
								SendPlcType2Write(Plc2ChanelNo,&StartAddr);									/* 20081007 */
							}																				/* 20081007 */
							StartAddr= sStartAddr+ CulcPlc2Area(CommonArea.PlcType2.DevInf[Plc2ChanelNo]);	/* 20081025 */
							Plc2ChanelNo++;
							Plc2ChanelNo= Plc2ChanelNo % MAX_PLC_LINK_ST_NO;
						}
					}
/*					break;*/
/*				}*/
/*				Plc2Cnt++;*/
/********************************************************************/
				PlcKansiFlag = 1;	/* Kansi 1 Sicle End */
				PlcKansiOkFlag= 1;	/* Kansi Start */
/*				PlcConnectFlag= PlcConnectCheck();*/
				Delay(50);
			}else{
				PlcKansiFlag = 0;	/* Kansi 1 Sicle End */
				Delay(100);
			}
		}
	}
}
int	PlcConnectCheck(void)
{
	T_MAIL	*mp;
	int	mbx;
	int OldResp;
	int	ret;


	mbx = TakeMbx();
/*	mp= (T_MAIL *)TakeMail();*/
	mp= (T_MAIL *)ReceiveMail(PlcFreeMbx);
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd= PLC_CON;		/* Write */
	SendMail( T_PLCHAND, (char *)mp );
	mp= (T_MAIL *)ReceiveMail( mbx );
	ret= (short)mp->mpec;
	OldResp = ChangeMailResp( (char *)mp, OldResp );
/*	FreeMail((char *)mp);*/
	ResponseMail((char *)mp);
	FreeMbx(mbx);
	return(ret);
}
int	Plc2ConnectCheck(int ch)
{
	T_MAIL	*mp;
	int	mbx;
	int OldResp;
	int	ret;


	mbx = TakeMbx();
	mp= (T_MAIL *)TakeMail();
	OldResp = ChangeMailResp( (char *)mp, mbx );
	mp->mcmd= PLC_CON;		/* Write */
	mp->mpar= ch;
	SendMail( T_PLCHAND2, (char *)mp );
	mp= (T_MAIL *)ReceiveMail( mbx );
	ret= (short)mp->mpec;
	OldResp = ChangeMailResp( (char *)mp, OldResp );
	FreeMail((char *)mp);
	FreeMbx(mbx);
	return(ret);
}
/************************************************/
/*	PLC2 Connection Check						*/
/************************************************/
int	CheckPlc2Connect(void)
{
	int	i,idx;
	int	connected;

	idx= 0;
	connected= 0;
	for(i= 0; i < MAX_PLC_LINK_ST_NO; i++){
		idx= GetPlc2ChanelNo(idx);
		if(idx == -1){					break;	}			/* End */
		if(PlcConnectFlag2[idx] == 0){	break;	}		/* No Connect */
		connected= 1;
		idx++;
		idx= idx % MAX_PLC_LINK_ST_NO;
	}
	if((idx == -1) && (connected == 1)){	return(1);	}
	else{									return(0);	}
}
int	CheckPlc2Connect1(void)
{
	int	i,idx;

	idx= 0;
	for(i= 0; i < MAX_PLC_LINK_ST_NO; i++){
		idx= GetPlc2ChanelNo(idx);
		if(idx == -1){					break;	}			/* End */
		if(PlcConnectFlag2[idx] == 1){	break;	}		/* No Connect */
		idx++;
		idx= idx % MAX_PLC_LINK_ST_NO;
	}
	if(idx == -1){	return(0);	}
	else{			return(1);	}
}
/************************************************/
/*	PLC1 Connection Task						*/
/************************************************/
void	PlcConnChk( STTFrm* pSTT )
{
	int		signal;
/*	int	param[4];*/
	int	Plc2Chanel= 0;
	int	NoPlc2;
	int	cnt= 0;

	while(1){
		ConnectTask= 0;
/*		if((PlcConnectFlag == 1) || (CommonArea.PcUpDownMode != 0)){		*/	/* Connect OK *//* ksc20090522 */
		if(CommonArea.PcUpDownMode != 0){			/* Connect OK */
			;
		}else{
			signal = ReadSignal(SGN_PLC);	/* */
			if((signal & 0x0001) != 0){		/* */
				if(PlcConnectFlag == 0){				/* ksc20090522 */
					/* Use Flag Check 060628 */
	//				if(CommonArea.PlcType1.PlcUserFlag != 0){
					if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
						if((Set.Ch1_iKind == UNIVERSAL) ||    /*ksc20090513 */
							(Set.Ch1_iKind == DEFAULT_PLC) ||  
							(Set.Ch1_iKind == ELSE_PLC)){
							ConnectTask= 1;
	//#ifdef	WIN32
	//						if(memcmp((char *)&GpFont[PLC1_PROTOCOL],PLC1STATUS,7) == 0){
	//#else
	//						if(memcmp((char *)PLC1_PROTOCOL,PLC1STATUS,7) == 0){
	//#endif
	//						if(IsPlc1Protocol() == OK){	/* 2008.12.10 */
	//							ElsPlcOK= 1;		/* Els PLC Prog Info */
	//						}
							PlcConnectFlag= PlcConnectCheck();	/*ksc20040714 �ʱ� ����üũ */
							if(PlcConnectFlag == 1){
								PlcKansiFlag= 0;
								PasswordLevelWrite();		/* PassWord Write */
							}
						}
					}else{										/* 20081002 Default PLC Check */
						if((Set.Ch1_iKind == UNIVERSAL) ||    /*ksc20090513 */
							(Set.Ch1_iKind == DEFAULT_PLC)){		/* 20081002 */
							PlcConnectFlag= PlcConnectCheck();	/* 20081002 */
							if(PlcConnectFlag == 1){			/* 20081002 */
								PlcKansiFlag= 0;				/* 20081002 */
								PasswordLevelWrite();			/* 20081002 */
							}									/* 20081002 */
						}										/* 20081002 */
					}
				}
			}
			/* PLC2 State */
			signal = ReadSignal(SGN_PLC);	/* */
			if((signal & 0x0001) != 0){		/* */
	/*			ConnectTask= 1;	*/												/* 2008.09.26 */
				if((Set.Ch2_iKind == PLCTYPE2) &&		/* PLC2 */
	//			   (CommonArea.PlcType2.AuxPlcUserFlag != 0)){/* PLC2 USE */
				   (IsPlc2Protocol() == OK)){	/* 2008.12.10 */
	/*				if(PlcConnectFlag2 == 0){*/										/* 2008.09.26 */
	/*				if((PlcConnectFlag2 == 0) && (CommonArea.PcUpDownMode == 0)){*/	/* 2008.09.26 */
					if((CheckPlc2Connect() == 0) && (CommonArea.PcUpDownMode == 0) && (cnt++ % 2)){	/* 20081007 */
						ConnectTask= 1;												/* 2008.09.26 */

						NoPlc2= 0;													/* 20081007 */
						if(Plc2Chanel == 0){										/* 20081007 */
							if((Plc2Chanel= GetPlc2ChanelNo(Plc2Chanel)) == -1){	/* 20081007 */
								NoPlc2= 1;											/* 20081007 */
							}														/* 20081007 */
						}else{														/* 20081007 */
							if((Plc2Chanel= GetPlc2ChanelNo(Plc2Chanel)) == -1){	/* 20081007 */
								Plc2Chanel= 0;										/* 20081007 */
								if((Plc2Chanel= GetPlc2ChanelNo(Plc2Chanel)) == -1){/* 20081007 */
									NoPlc2= 1;										/* 20081007 */
								}													/* 20081007 */
							}														/* 20081007 */
						}															/* 20081007 */
						if((NoPlc2 == 0) && (PlcConnectFlag2[Plc2Chanel] == 0)){	/* 20081007 */
	//#ifndef	TEST_PROT
	//#ifdef	WIN32	/* 2006.05.19 */
	//						if(memcmp((char *)&GpFont[PLC2_PROTOCOL],"PLCPROC2",8) == 0){
	//#else
	//						if(memcmp((char *)PLC2_PROTOCOL,"PLCPROC2",8) == 0){
	//#endif
	//						if(IsPlc2Protocol() == OK){
	//#endif
								if(CheckPlc2Connect1() == 0){
									if((GET_MS_SEL2() & 0xff00) != 0){		/* Protocol SET */
										if(Set.Ch2_iConnect == CH_CH1){		/* RS-232C */
/*											RsModeSet(RS_PC,*/				/* PC PORT */
/*												  RS_INIT,*/
/*												  Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed,*/
/*												  Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1,*/
/*												  Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity);*/ /* 20061025ksc */
											RsModeSetChanel(RS_PC,&Set.Ch2_Serial_Param[Set.Ch2_iKind]);		/* 2009.09.04 Add Stop */
										}else{
/*											RsModeSet(RS_PLC,*/				/* PLC PORT */
/*												  RS_INIT,*/
/*												  Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed,*/
/*												  Set.Ch2_Serial_Param[Set.Ch2_iKind].iData1,*/
/* 												  Set.Ch2_Serial_Param[Set.Ch2_iKind].iParity);*/ /* 20061025ksc */
											RsModeSetChanel(RS_PLC,&Set.Ch2_Serial_Param[Set.Ch2_iKind]);		/* 2009.09.04 Add Stop */
										}
									}
								}
	/*							param[0]= PlcType2Flag;*/
	/*							param[1]= Set.iGPSta;*/
	/*							param[2]= 0;*/
	/*							param[2]= Plc2Chanel;*/								/* 20081007 */
	/*							param[3]= Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed;*/  /* 20061025ksc */

	/*							PlcConnectFlag2= PLC_CONNECT2(param,Set.Ch2_iConnect);*/	/* 20081007 */
								PlcConnectFlag2[Plc2Chanel]= Plc2ConnectCheck(Plc2Chanel);
	/*							PlcType2Flag= param[0];*/
								Plc2Chanel++;
								Plc2Chanel= Plc2Chanel % MAX_PLC_LINK_ST_NO;
	//#ifndef	TEST_PROT
	//						}
	//#endif
						}else{														/* 20081007 */
							if(NoPlc2 == 1){										/* 20081007 */
								Plc2Chanel= 0;										/* 20081007 */
							}else{													/* 20081007 */
								Plc2Chanel++;										/* 20081007 */
								Plc2Chanel= Plc2Chanel % MAX_PLC_LINK_ST_NO;		/* 20081007 */
							}														/* 20081007 */
						}
					}
				}
			}
		}
		ConnectTask= 0;		/* 2008.12.10 */
		Delay(500);	/*ksc20040720 100���� 300���� ����, ���ؼ� �õ��� ���� ���ؼ� �õ� �ð�  */
	}
}
unsigned int	GetNowTime(void)		/* 20060203 */
{
	return(_TimeMSec);
}
void	MonitorOffSet(void)
{
	T_MAIL	*mp;

/*	mp= (T_MAIL *)TakeMail();*/
	mp= (T_MAIL *)ReceiveMail(PlcFreeMbx);
	mp->mcmd= PLC_MONIT_OFF;		/*  */
	SendMail( T_PLCHAND, (char *)mp );
}
void	Plc2Hand( STTFrm* pSTT )
{
	T_MAIL	*mp;
//	int	param[5];	
	int	param[9];	/* 20111017 */

	while(1){
		Plc2handTask= 0;
		mp = (T_MAIL *)WaitRequest();
		Plc2handTask= 1;
		switch(mp->mcmd){
		case PLC_READ2:
			mp->mpec= PLC_DEV_READ2(mp,(unsigned char *)rDataPlc2,PlcType2Flag);
			break;
		case PLC_WRITE2:
			mp->mpec= PLC_DEV_WRITE2(mp,(unsigned char *)rDataPlc2,PlcType2Flag);
			break;
		case PLC_CON:
			param[0]= PlcType2Flag;
			param[1]= Set.iGPSta;
			param[2]= mp->mpar;								/* ch 20081007 */
			param[3]= Set.Ch2_Serial_Param[Set.Ch2_iKind].iSpeed;  /* 20061025ksc */
			param[4]= Set.Ch2_iKind;  /* 20090704 No Use */


			param[5]= CH_CH1;  /* 20100406 */
			param[6]= ((int)(unsigned char)Set.cPlcTypeCode2[0] << 8)+(unsigned char)Set.cPlcTypeCode2[1]; /* 20111017 */
	//		param[6]= ((int)Set.cPlcTypeCode2[2] << 8) + (int)Set.cPlcTypeCode2[3]; /* 20111017 */
			param[7]= (int)(unsigned char)Set.cPlcTypeCode2[2]; /* 20111017 */
			param[8]= (int)(unsigned char)Set.cPlcTypeCode2[3]; /* 20111017 */
			
			
			mp->mpec= PLC_CONNECT2(param,Set.Ch2_iConnect);
			PlcType2Flag= param[0];
			break;
		}
		ResponseMail((char *)mp);
	}
}
