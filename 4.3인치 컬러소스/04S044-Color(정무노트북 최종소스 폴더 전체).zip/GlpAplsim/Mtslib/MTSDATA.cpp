#include    "Mts.h"


int				_SystemStack[256];
SmpFrm          _Smp[16];
SigFrm          _Sig[16];
int             _RunTaskNo;
int				_SystemState;
TcbFrm*         _ReadyQue;
TcbFrm*         _SaveReadyQue;
TmqFrm*         _TimerQue;
int				_PenddingFlag;
unsigned*       _PendingInp;
unsigned*       _PendingOup;
unsigned        _PendingBuf[256];
MbxFrm          _Mbx[256];
/*TcbFrm          _Tcb[128];*/
TcbFrm          _Tcb[32];
#ifdef	WIN32
int             _SCBInx;
int             _SCBCount;
SCBFrm          _SCB[4096];
void interrupt  (*_InterruptVector[256])();
#endif
