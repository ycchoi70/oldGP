#include    "Mts.h"

/*
#define	MON	1
*/

#ifdef      WIN32
int             _RunTaskNo;
TcbFrm*         _ReadyQue;
TcbFrm*         _SaveReadyQue;
TmqFrm*         _TimerQue;
unsigned*       _PendingInp;
unsigned*       _PendingOup;
unsigned        _PendingBuf[1024];
SmpFrm          _Smp[16];
SigFrm          _Sig[16];
MbxFrm          _Mbx[256];
TcbFrm          _Tcb[128];
void interrupt  (*_InterruptVector[256])();
unsigned*       _SystemStackEnd;
int             _SCBInx;
int             _SCBCount;
SCBFrm          _SCB[4096];
#else
#pragma asm
#ifdef MON
   Section VectData,,D
__InterruptVector:
    ds.l    256     * Interrupt VectorTable	Section MtsCode,,C
#endif
   Section MtsData,,D
    xdef    __RunTaskNo
    xdef    __InterruptVector
    xdef    __ReadyQue
    xdef    __SaveReadyQue
    xdef    __TimerQue
    xdef    __PendingInp
    xdef    __PendingOup
    xdef    __PendingBuf
    xdef    __PendingBufEnd
    xdef    __Mbx
    xdef    __Smp
    xdef    __Sig
    xdef    __Tcb
    xdef    __SystemStack
    xdef    __SystemStackEnd
    xdef    __SystemState
*
#ifndef	MON
__InterruptVector:
    ds.l    256     * Interrupt VectorTable	Section MtsCode,,C
#endif
__SystemStack:
    ds.l    256
__SystemStackEnd:
__Smp:
    ds.l    16*4
__Sig:
    ds.l    16*4
__SystemState:
    ds.l    1
__RunTaskNo:
    ds.l    1
__ReadyQue:
    ds.l    1
__SaveReadyQue:
    ds.l    1
__TimerQue:
    ds.l    1
__PendingInp:
    ds.l    1
__PendingOup:
    ds.l    1
__PendingBuf:
#ifdef	MON
    ds.l    (__SystemStack+$1000-__PendingBuf)/4
#else
    ds.l    (__InterruptVector+$1000-__PendingBuf)/4
#endif
__PendingBufEnd:
__Tcb:
    ds.l    128*32
__Mbx:
    ds.l    256*4
#pragma endasm
#endif
