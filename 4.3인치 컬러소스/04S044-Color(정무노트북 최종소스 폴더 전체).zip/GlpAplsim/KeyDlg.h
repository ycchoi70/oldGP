// KeyDlg.h : �w�b�_�[ �t�@�C��
//

/////////////////////////////////////////////////////////////////////////////
// CKeyDlg �_�C�A���O

#define LcdWidth        320
#define LcdHeight       240
#ifdef	SIZE_2480_COL
	#define LcdWidthByte    LcdWidth*4
#else
	#define LcdWidthByte    LcdWidth/8
#endif
#define LcdByteSize     LcdWidthByte*LcdHeight

typedef unsigned char uchar;
typedef unsigned int  uint;
typedef char * DIB;

#include "ColorButundlg.h"

#include "CommThread.h" /* �@�ʐM�p�N���X*/


class CKeyDlg : public CDialog
{
// �R���X�g���N�V����
public:
	CKeyDlg(CWnd* pParent = NULL);   // �W���̃R���X�g���N�^
	~CKeyDlg();
	void MouseCheck(int, int, CPoint );
// �_�C�A���O �f�[�^
	//{{AFX_DATA(CKeyDlg)
	enum { IDD = IDD_KeyPanel };
	CColorButundlg	m_C3;
	CColorButundlg	m_C2;
	CColorButundlg	m_C1;
	CColorButundlg	m_C0;
	CColorButundlg	m_T3;
	CColorButundlg	m_T2;
	CColorButundlg	m_T1;
	CColorButundlg	m_T0;
	CColorButundlg	m_X7;
	CColorButundlg	m_X6;
	CColorButundlg	m_X5;
	CColorButundlg	m_X4;
	CColorButundlg	m_X3;
	CColorButundlg	m_X2;
	CColorButundlg	m_X1;
	CColorButundlg	m_X0;
	CStatic	m_LcdDisply;
	CString	m_strD0;
	CString	m_strD1;
	CString	m_strD2;
	CString	m_strVersion;
	CString	m_GpType;
	CString	m_strD3;
	CString	m_strD4;
	CString	m_strD5;
	CString	m_strD6;
	CString	m_strD7;
	//}}AFX_DATA
    CDC     m_LcdCDC;
    CBitmap m_LcdBmp;
    CWnd*   m_pLcdWnd;
    char*   m_pBitmapBits;

	int m_nPort;          /* �|�[�g*/
	int m_nBaudRate;      /* ���x*/
	int	m_nData;		/* �f�[�^�� */
	int	m_nParity;		/* �p���e�B */

	CCommThread m_ComuPort[20]; /* �A�ʐM�p�N���X*/

	// �I�[�o�[���C�h
	// ClassWizard �͉��z�֐��𐶐����I�[�o�[���C�h���܂��B
	//{{AFX_VIRTUAL(CKeyDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g
	//}}AFX_VIRTUAL
	void SerialInit(HWND m_hWnd);
	void SendRs(int port,char *buff);
	void SendPlcDataBCC(char *buff,int cnt);

	void	PLCDataRec( BYTE aByte );
	int	GOTDataRecieve( BYTE aByte );
	int	GPDataRecieve( BYTE aByte );
	void CKeyDlg::SendPcDataDlg(char *buff,int cnt);
	void CKeyDlg::DrawOnOffStatus();


// �C���v�������e�[�V����
protected:

	// �������ꂽ���b�Z�[�W �}�b�v�֐�
	//{{AFX_MSG(CKeyDlg)
	afx_msg void OnKey0();
	afx_msg void OnKey1();
	afx_msg void OnKey2();
	afx_msg void OnKey3();
	afx_msg void OnKey4();
	afx_msg void OnKey5();
	afx_msg void OnKey6();
	afx_msg void OnKey7();
	afx_msg void OnKey8();
	afx_msg void OnKey9();
	afx_msg void OnKeyBS();
	afx_msg void OnKeyCR();
	afx_msg void OnKeyDown();
	afx_msg void OnKeyESC();
	afx_msg void OnKeyHT();
	afx_msg void OnKeyLeft();
	afx_msg void OnKeyN();
	afx_msg void OnKeyRight();
	afx_msg void OnKeyUpper();
	afx_msg void OnKeyV();
	afx_msg void OnKeyW();
	afx_msg void OnKey();
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnClose();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	afx_msg void OnButton3();
	afx_msg void OnButton4();
	afx_msg void OnButton5();
	afx_msg void OnButton6();
	afx_msg void OnButton8();
	afx_msg void OnButton7();
	afx_msg void OnButton9();
	afx_msg void OnButton10();
	afx_msg void OnButton11();
	afx_msg void OnButton12();
	afx_msg void OnButton13();
	afx_msg void OnButton14();
	afx_msg void OnButton15();
	afx_msg void OnButton16();
	afx_msg void OnButton18();
	//}}AFX_MSG
    LONG OnPaintLcd( UINT RetInf, LONG ppCDM );
	afx_msg LONG OnCommunication(int,long); /* �BWM_COMM_READ CallBack�֐�*/
	DECLARE_MESSAGE_MAP()
};
